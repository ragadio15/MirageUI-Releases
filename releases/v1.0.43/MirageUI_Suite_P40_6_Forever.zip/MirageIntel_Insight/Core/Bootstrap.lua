-- Insight: read-only contextual intelligence and explicit utility actions.
local addonName,I=...
I.name=addonName
I.version="1.11.7"
I.apiVersion=1
I.core=MirageIntelCoreAPI
I.state={initialized=false,errors=0,status="STARTING",nativeVerification="NOT_RUN",events=0,
    tooltipCalls=0,tooltipLines=0,lastError=nil}
I.maxRecipes=3000
I.maxSourceIDs=2500
function I:Readable(v)
    if v==nil then return true end
    if type(issecretvalue)=="function" then
        local ok,secret=pcall(issecretvalue,v)
        if not ok or secret==true then return false end
    end
    if type(canaccessvalue)=="function" then
        local ok,available=pcall(canaccessvalue,v)
        if not ok or available==false then return false end
    end
    return true
end
function I:Number(v)
    return self:Readable(v) and type(v)=="number" and v==v and v<math.huge and v>-math.huge
end
function I:Integer(v) return self:Number(v) and v>0 and v%1==0 and v<=2147483647 end
function I:Text(v,max)
    max=max or 100
    return self:Readable(v) and type(v)=="string" and #v>0 and #v<=max and v or nil
end
function I:Label(v,max)
    if not self:Text(v,max) or v:find("[|%c]") then return nil end
    return v
end
function I:Call(fn,...)
    if not self:Readable(fn) or type(fn)~="function" then return nil,false end
    local ok,a,b,c,d,e,f,g,h,j,k,l=pcall(fn,...)
    if not ok then return nil,false end
    local values={a,b,c,d,e,f,g,h,j,k,l}
    for index=1,11 do
        if not self:Readable(values[index]) then return nil,false end
    end
    return a,true,b,c,d,e,f,g,h,j,k,l
end
function I:Now()
    local v,ok=self:Call(time)
    return ok and self:Number(v) and v>0 and math.floor(v) or 0
end
function I:Combat()
    local value,ok=self:Call(InCombatLockdown)
    -- A successful nil is the legacy WoW unlocked result, not an API failure.
    return not ok or (value~=nil and value~=false)
end
function I:Fault(code)
    self.state.errors=self.state.errors+1
    self.state.lastError=type(code)=="string" and code or "UNKNOWN"
end
function I:Print(msg)
    if DEFAULT_CHAT_FRAME and type(DEFAULT_CHAT_FRAME.AddMessage)=="function" then
        DEFAULT_CHAT_FRAME:AddMessage("|cffe8b77dMirage Insight:|r "..tostring(msg))
    end
end
function I:Copy(value)
    if self.core and type(self.core.Copy)=="function" then
        local ok,result=pcall(self.core.Copy,value)
        if ok then return result end
    end
    local budget,seen=2048,{}
    local function copy(v,depth)
        if not I:Readable(v) or depth>12 then return nil end
        local kind=type(v)
        if kind~="table" then
            if kind=="string" or kind=="boolean" or kind=="nil" or (kind=="number" and I:Number(v)) then return v end
            return nil
        end
        if seen[v] then return nil end
        seen[v]=true;local result={}
        for k,x in pairs(v) do
            budget=budget-1;if budget<0 then break end
            if I:Readable(k) and (type(k)=="string" or (type(k)=="number" and I:Number(k))) then result[k]=copy(x,depth+1) end
        end
        seen[v]=nil;return result
    end
    local ok,result=pcall(copy,value,0)
    return ok and result or nil
end
function I:Allowed()
    local core=self.core
    if type(core)~="table" or core.apiVersion~=1 or type(core.GetCapabilities)~="function" then return false end
    local ok,caps=pcall(core.GetCapabilities)
    if not ok or type(caps)~="table" or type(caps.client)~="table" then return false end
    local c=caps.client
    if c.allowed==true then
        self.state.clientBuild=c.build
        self.state.clientPatch=self:Label(c.patch,80)
        self.state.clientInterface=self:Integer(c.interface) and c.interface or nil
        return true
    end
    return false
end
function I:Initialize()
    if self.state.initialized then return end
    self.core=MirageIntelCoreAPI or self.core
    self.state.initializationPhase="COMMANDS"
    self.Commands:Install()
    if type(self.core)~="table" or self.core.apiVersion~=1 or type(self.core.GetCapabilities)~="function" then
        self.state.clientAllowed=false;self.state.status="WAITING_FOR_CORE"
        self.state.initializationPhase="WAITING_FOR_CORE"
        self.Storage.readOnly=true;self.Storage.reason="CORE_NOT_READY_NO_WRITES"
        return false
    end
    self.state.initializationAttempts=(self.state.initializationAttempts or 0)+1
    self.state.initializationPhase="STORAGE"
    self.state.clientAllowed=self:Allowed()
    self.Storage:Initialize()
    self.state.status=not self.state.clientAllowed and "UNSUPPORTED_BUILD" or
        self.Storage.readOnly and "STORAGE_READ_ONLY" or "READY_NATIVE_UNTESTED"
    self.state.initializationPhase="RECIPES"
    self.Recipes:RebuildIndex()
    if self.Recipes.Initialize then self.Recipes:Initialize() end
    self.state.initializationPhase="PUBLIC_API"
    self.API:Install()
    if self.core and type(self.core.RegisterModule)=="function" then
        self.core.RegisterModule("MirageIntel_Insight",1,{itemFacts=true,recipeRelationships=true,
            automaticRecipeObservations=true,marketPricesOptIn=true,exactLinkQuotes=true,
            tooltipPostCall=true,utilityRecordCards=true,explicitSourceActions=true})
    end
    self.state.initializationPhase="TOOLTIPS"
    self.Tooltip:Install()
    if self.Context then self.Context:Initialize() end
    self.state.initializationPhase="READY"
    self.state.initialized=true
end
