-- Exact-context tooltip presentation. Native essential content, ownership, hit
-- regions and comparison handling remain entirely native on build 71037.
local _,I=...
I.Tooltip={status="NOT_INSTALLED",states={},hooks=setmetatable({}, {__mode="k"}),
    generation=0,nativeAcceptance="NOT_RUN",externalOwners={},maxExternalOwners=8,
    methodHooks=setmetatable({}, {__mode="k"}),pendingCaptures={},captureAttempts=0,captureSuccesses=0,hookFailures=0,
    surfacePasses=0,renderSuccesses=0,setterContexts=setmetatable({}, {__mode="k"}),textOnly=setmetatable({}, {__mode="k"}),
    fading=setmetatable({}, {__mode="k"}),fadeReleases=0}
local T=I.Tooltip
local surfaces={"GameTooltip","ItemRefTooltip","ShoppingTooltip1","ShoppingTooltip2",
    "ItemRefShoppingTooltip1","ItemRefShoppingTooltip2"}
local families={GetBagItem="BAG",GetBagItemChild="BAG_CHILD",GetInventoryItem="EQUIPMENT",
    GetInventoryItemByID="EQUIPMENT",GetMerchantItem="MERCHANT",GetBuybackItem="MERCHANT",
    GetMerchantCostItem="MERCHANT",GetRecipeReagentItem="RECIPE_REAGENT",
    GetRecipeResultItem="RECIPE_OUTPUT",GetRecipeResultItemForOrder="RECIPE_OUTPUT",
    GetItemKey="AUCTION",GetHyperlink="ITEM_LINK",GetItemByID="ITEM",GetOwnedItemByID="ITEM",
    GetItemByGUID="ITEM",GetQuestItem="QUEST_ITEM",GetQuestLogItem="QUEST_ITEM",
    GetQuestLogSpecialItem="QUEST_ITEM",GetUnit="UNIT",GetWorldCursor="WORLD_CURSOR",
    GetMinimapMouseover="MINIMAP_UNIT",GetInboxItem="MAIL",GetSendMailItem="MAIL",
    GetTradePlayerItem="TRADE",GetTradeTargetItem="TRADE",GetLootItem="LOOT",GetLootRollItem="LOOT",
    GetGuildBankItem="BANK",GetToyByItemID="ITEM",GetSocketedItem="EQUIPMENT",
    GetExistingSocketGem="EQUIPMENT",GetSpellByID="SPELL",GetSpellBookItem="SPELL",GetAction="ACTION",
    GetRecipeRankInfo="RECIPE_OUTPUT",NativeComparisonData="COMPARISON",NativeItemData="ITEM",NativeSpellData="SPELL",NativeUnitData="UNIT"}
local function tableOK(value)
    if not I:Readable(value) or type(value)~="table" then return false end
    if type(canaccesstable)=="function" then
        local ok,available=pcall(canaccesstable,value)
        if not ok or available==false then return false end
    end
    return true
end
local function field(value,key)
    if not I:Readable(value) or (type(value)~="table" and type(value)~="userdata") then return nil end
    if type(value)=="table" and not tableOK(value) then return nil end
    local ok,result=pcall(function() return value[key] end)
    if ok and I:Readable(result) then return result,true end
    return nil,false
end
local function invoke(object,method,...)
    local fn=field(object,method)
    return I:Call(fn,object,...)
end
local function prefs()
    return I.Storage and I.Storage.account and I.Storage.account.preferences
end
local function nativeShown(frame)
    local value,ok=invoke(frame,"IsShown")
    return ok and (value==true or value==1)
end
local function ownerVisible(frame)
    local method=type(field(frame,"IsVisible"))=="function" and "IsVisible" or "IsShown"
    local value,ok=invoke(frame,method)
    if ok and (value==true or value==1) then return true,true end
    if ok and (value==nil or value==false or value==0) then return false,true end
    return nil,false
end
local function now()
    local value,ok=I:Call(GetTime)
    return ok and I:Number(value) and value or 0
end
local function copy(value)
    -- Models contain only readable scalars and bounded context tables, never native frame/data references.
    return I:Copy(value)
end
local function sameItem(a,b)
    if not I:Text(a,600) or not I:Text(b,600) then return false end
    return (a:match("|H(item:[^|]+)|h") or a)==(b:match("|H(item:[^|]+)|h") or b)
end
function T:Surface(tooltip)
    for index,name in ipairs(surfaces) do if tooltip==_G[name] then return index,name end end
end
function T:Detail(pref)
    return pref.professionDetails~=false and I.Recipes and I.Recipes.IsProfessionOpen and I.Recipes:IsProfessionOpen() or false
end
function T:RegisterExternalOwner(owner,resolver)
    if not I:Label(owner,80) or type(resolver)~="function" then return false end
    local count=0;for _ in pairs(self.externalOwners) do count=count+1 end
    if count>=self.maxExternalOwners and not self.externalOwners[owner] then return false end
    self.externalOwners[owner]=resolver;self:RefreshVisible("EXTERNAL_OWNER_CHANGED");return true
end
function T:UnregisterExternalOwner(owner,resolver)
    if self.externalOwners[owner]~=resolver then return false end
    self.externalOwners[owner]=nil;self:RefreshVisible("EXTERNAL_OWNER_CHANGED");return true
end
function T:ExternalOwner(tooltip)
    for owner,resolver in pairs(self.externalOwners) do
        local active,ok=I:Call(resolver,tooltip)
        if not ok or active==true then return owner end
    end
    -- Conservative coexistence with dedicated tooltip replacements. Mirage core
    -- delegates these six surfaces through the shared presentation API.
    local api=type(C_AddOns)=="table" and C_AddOns.IsAddOnLoaded or IsAddOnLoaded
    for _,name in ipairs({"TipTac","TipTacReborn","TinyTip"}) do
        local loaded,ok=I:Call(api,name)
        if ok and loaded==true then return name end
    end
end
function T:PresentationEnabled(tooltip)
    local pref=prefs()
    return self:Surface(tooltip)~=nil and I.state.clientAllowed==true and pref and not I.Storage.readOnly and
        pref.tooltip==true and pref.tooltipPresentation~="NATIVE" and pref.skinTooltips~=false and
        self:CoreAllows() and not self:ExternalOwner(tooltip) and true or false
end
function T:HideExpiredOwner(tooltip)
    if not nativeShown(tooltip) then return false end
    local owner,known=invoke(tooltip,"GetOwner")
    if not known or not owner then return false end
    local visible,read=ownerVisible(owner)
    if not read or visible~=false then return false end
    local forbidden,checked=invoke(tooltip,"IsForbidden")
    local protected,protectedRead=invoke(tooltip,"IsProtected")
    if checked and forbidden or protectedRead and protected and I:Combat() then return false end
    if invoke(tooltip,"GetOwner")~=owner then return false end
    local stillVisible,stillRead=ownerVisible(owner)
    if not stillRead or stillVisible~=false then return false end
    if invoke(tooltip,"GetOwner")~=owner then return false end
    -- A confirmed hidden native owner has ended this hover. Hide the native
    -- surface as its own OnLeave would; do not leave a restored Blizzard tip
    -- stranded after removing the Insight rows.
    local _,hidden=invoke(tooltip,"Hide")
    return hidden
end
function T:CoreAllows()
    local main=_G.MirageUI
    if type(main)~="table" then return true end
    if type(main.state)=="table" and main.state.safe==true then return false end
    local profile=type(main.profile)=="table" and main.profile
    if profile and profile.enabled==false then return false end
    local cfg=profile and type(profile.modules)=="table" and profile.modules.Tooltips
    if type(cfg)~="table" or not I:Number(cfg.presentationRevision) or cfg.presentationRevision<1 then return true end
    return cfg.enabled~=false and cfg.style~=false and cfg.primaryPresentation~=2
end
function T:PresentSurface(tooltip,source)
    local index=self:Surface(tooltip)
    if not index or not self:PresentationEnabled(tooltip) or not I.TooltipCard then return false end
    if self.fading[tooltip] or I.TooltipCard:IsRefreshing(tooltip) then return false end
    local owner=invoke(tooltip,"GetOwner")
    if owner then
        local visible,read=ownerVisible(owner)
        if read and visible==false then self:HideExpiredOwner(tooltip);return false end
    end
    local forbidden,forbiddenOK=invoke(tooltip,"IsForbidden")
    if forbiddenOK and forbidden then return false end
    local count,known=invoke(tooltip,"NumLines")
    if not known or not I:Number(count) or count<1 then return false end
    local ok,result,reason=pcall(I.TooltipCard.Present,I.TooltipCard,index,tooltip,prefs())
    if not ok or not result then
        self.lastPresentationReason=ok and reason or "TOOLTIP_STYLE_FAILED"
        local card=I.TooltipCard.cards[index];if card then card.styling=nil end
        return false
    end
    self.lastPresentationReason="MIRAGE_SURFACE_READY";self.surfacePasses=self.surfacePasses+1
    self:WakeWatcher()
    return true
end
function T:IsFading(tooltip) return self.fading[tooltip]~=nil end
function T:BeginFade(tooltip,index)
    -- The engine keeps a fading tooltip shown after clearing its data handler.
    -- Retain our passive child skin for that fade, but invalidate semantic
    -- claims immediately. A relayout Show here would cancel the engine fade.
    self.fading[tooltip]={at=now(),owner=invoke(tooltip,"GetOwner")}
    self.pendingCaptures[index]=nil;self.setterContexts[tooltip]=nil
    local state=self.states[index]
    if state and state.tooltip==tooltip then
        self.generation=self.generation+1;state.generation=self.generation
        if state.ownsMarket then self.marketDirty=true end
        state.context=nil;state.model=nil;state.prepared=false;state.ownsMarket=false
        state.reason="NATIVE_FADING";state.visualVisible=false
    end
    self.fadeReleases=self.fadeReleases+1
    self:WakeWatcher()
end
local function argsKey(args)
    if not tableOK(args) then return "" end
    local parts={}
    for index=1,6 do
        local value=field(args,index)
        if I:Number(value) or type(value)=="boolean" or I:Text(value,600) then
            parts[#parts+1]=type(value)..":"..tostring(value)
        elseif value==nil then parts[#parts+1]="nil"
        else parts[#parts+1]="opaque" end
    end
    return table.concat(parts,"\031")
end
local function itemLinkFromData(data)
    -- C_TooltipInfo is also the public source used by the native recipe
    -- setters. Read its exact item identity; do not synthesize an item link
    -- from a recipe's base output or assume a quality/recraft variant.
    if not tableOK(data) or not Enum or not Enum.TooltipDataType or
        field(data,"type")~=Enum.TooltipDataType.Item then return nil end
    local id=field(data,"id")
    if not I:Integer(id) then return nil end
    local guid,readable=field(data,"guid")
    if readable==false then return nil end
    local link
    if guid~=nil then
        if not I:Text(guid,180) then return nil end
        local value,known=I:Call(type(C_Item)=="table" and C_Item.GetItemLinkByGUID,guid)
        if known and I:Text(value,600) then link=value end
    end
    if not link then local value=field(data,"hyperlink");if I:Text(value,600) then link=value end end
    if link and I.Items:Parse(link)==id then return link,id end
end
function T:SetterCapture(tooltip,index,name,owner)
    local hint=self.setterContexts[tooltip]
    if not hint or hint.owner~=owner or hint.epoch~=(self.surfaceEpochs and self.surfaceEpochs[tooltip] or 0) then return nil end
    if hint.complete==false then return nil end
    local context={index=index,surface=name,owner=owner,argsKey=argsKey(hint.args),capturedAt=now(),
        dataInstanceID=hint.epoch,legacy=true,getter=hint.method,family="ITEM"}
    local args,method=hint.args,hint.method
    local link,unit,recipeID
    local function obtain(fn,...)
        local result,ok=I:Call(fn,...);return ok and I:Text(result,600) and result or nil
    end
    if method=="SetHyperlink" then link=I:Text(args[1],600)
    elseif method=="SetBagItem" then
        local api=type(C_Container)=="table" and C_Container
        link=obtain(api and api.GetContainerItemLink or GetContainerItemLink,args[1],args[2]);context.family="BAG"
        context.bagID=args[1];context.slotIndex=args[2]
        if link and api and type(api.GetContainerItemInfo)=="function" then
            local value,ok=I:Call(api.GetContainerItemInfo,args[1],args[2])
            local count=ok and tableOK(value) and field(value,"stackCount")
            if I:Integer(count) then context.stackCount=count end
        end
    elseif method=="SetInventoryItem" then link=obtain(GetInventoryItemLink,args[1],args[2]);context.family="EQUIPMENT"
    elseif method=="SetMerchantItem" then link=obtain(GetMerchantItemLink,args[1]);context.family="MERCHANT"
    elseif method=="SetBuybackItem" then link=obtain(GetBuybackItemLink,args[1]);context.family="MERCHANT"
    elseif method=="SetLootItem" then link=obtain(GetLootSlotLink,args[1]);context.family="LOOT"
    elseif method=="SetRecipeResultItem" or method=="SetRecipeResultItemForOrder" or method=="SetRecipeReagentItem" then
        local api=type(C_TooltipInfo)=="table" and C_TooltipInfo
        recipeID=I:Integer(args[1]) and args[1]
        local reagent=method=="SetRecipeReagentItem"
        if hint.complete then
            local getter=method=="SetRecipeReagentItem" and "GetRecipeReagentItem" or
                method=="SetRecipeResultItemForOrder" and "GetRecipeResultItemForOrder" or "GetRecipeResultItem"
            local data,known
            if reagent then data,known=I:Call(api and api[getter],args[1],args[2])
            else data,known=I:Call(api and api[getter],args[1],args[2],args[3],args[4],args[5]) end
            if known then link=itemLinkFromData(data) end
        end
        context.family=reagent and "RECIPE_REAGENT" or "RECIPE_OUTPUT"
    elseif method=="SetTradeSkillItem" or method=="SetCraftItem" then
        local craft=method=="SetCraftItem"
        if args[2]~=nil then
            link=obtain(craft and GetCraftReagentItemLink or GetTradeSkillReagentItemLink,args[1],args[2]);context.family="RECIPE_REAGENT"
        else link=obtain(craft and GetCraftItemLink or GetTradeSkillItemLink,args[1]);context.family="RECIPE_OUTPUT" end
    elseif method=="SetUnit" then unit=I:Text(args[1],80)
    elseif method=="SetItemByGUID" then
        link=obtain(type(C_Item)=="table" and C_Item.GetItemLinkByGUID,args[1])
    elseif method=="SetItemByID" then
        local getter=type(C_Item)=="table" and C_Item.GetItemInfo or GetItemInfo
        local _,read,value=I:Call(getter,args[1])
        if read and I:Text(value,600) and I.Items:Parse(value)==args[1] then link=value end
    elseif method=="SetAction" or method=="SetSpellByID" or method=="SetSpellBookItem" or
        method=="SetQuestItem" or method=="SetQuestLogItem" or method=="SetInboxItem" then
        local api=type(C_TooltipInfo)=="table" and C_TooltipInfo
        local getter="Get"..method:sub(4)
        local data,read=I:Call(api and api[getter],args[1],args[2],args[3])
        if read and tableOK(data) then
            link=itemLinkFromData(data)
            if not link and Enum and Enum.TooltipDataType and field(data,"type")==Enum.TooltipDataType.Spell then
                local id=field(data,"id")
                if I:Integer(id) then
                    context.kind="SPELL";context.spellID=id;context.identity="spell:"..id;context.family="SPELL"
                    return context
                end
            end
        end
    elseif method=="SetWorldCursor" or method=="SetMinimapMouseover" then
        -- Resolve the live public data again, rather than borrowing the last
        -- mouseover unit or inferring a creature from a displayed name.
        local api=type(C_TooltipInfo)=="table" and C_TooltipInfo
        local data,known=I:Call(api and api[method=="SetWorldCursor" and "GetWorldCursor" or "GetMinimapMouseover"])
        local guid=known and tableOK(data) and field(data,"guid")
        if I:Text(guid,180) then
            local token,read=I:Call(UnitTokenFromGUID,guid)
            if read and I:Text(token,80) and I:Call(UnitGUID,token)==guid then unit=token end
        end
    end
    if unit then
        local guid,known=I:Call(UnitGUID,unit)
        if known and I:Text(guid,180) then
            context.kind="UNIT";context.unit=unit;context.guid=guid;context.identity=guid..":"..unit;context.family="UNIT"
            return context
        end
    end
    local id=link and I.Items:Parse(link)
    if I:Integer(id) then
        context.kind="ITEM";context.itemID=id;context.link=link;context.identity=link;context.recipeID=recipeID
        return context
    end
end
function T:LegacyCapture(tooltip,index,name)
    -- Some native/custom container frames expose GetItem/GetUnit without the
    -- data-handler metadata. Resolve only these six native surfaces and read
    -- their current owner and complete item link; never invent item variants.
    local owner,ownerOK=invoke(tooltip,"GetOwner")
    if not ownerOK or not owner then return nil,"NATIVE_OWNER_UNAVAILABLE" end
    local visible,visibleOK=ownerVisible(owner)
    if visibleOK and visible==false then return nil,"NATIVE_OWNER_HIDDEN" end
    local _,itemOK,link=invoke(tooltip,"GetItem")
    local itemID=itemOK and I:Text(link,600) and I.Items:Parse(link)
    local context={index=index,surface=name,owner=owner,argsKey="",capturedAt=now(),
        dataInstanceID=self.surfaceEpochs and self.surfaceEpochs[tooltip] or 0,legacy=true}
    if I:Integer(itemID) then
        context.kind="ITEM";context.getter="NativeGetItem";context.family=index>=3 and "COMPARISON" or "ITEM"
        context.itemID=itemID;context.link=link;context.identity=link
        self.captureSuccesses=self.captureSuccesses+1
        return context
    end
    local _,unitOK,unit,guid=invoke(tooltip,"GetUnit")
    if unitOK and I:Text(unit,80) then
        local current,checked=I:Call(UnitGUID,unit)
        if checked and I:Text(current,180) and (guid==nil or current==guid) then
            context.kind="UNIT";context.getter="NativeGetUnit";context.family="UNIT"
            context.unit=unit;context.guid=current;context.identity=current..":"..unit
            self.captureSuccesses=self.captureSuccesses+1
            return context
        end
    end
    local resolved=self:SetterCapture(tooltip,index,name,owner)
    if resolved then self.captureSuccesses=self.captureSuccesses+1;return resolved end
    -- The reviewed combined-bag button uses its own GetBagID/GetID for every
    -- SetBagItem call. A native C-backed setter can supply no data-handler or
    -- GetItem result. Admit only that exact native button method, and read its
    -- item twice; arbitrary owners and stale stored item IDs are not accepted.
    local mixin=_G.ContainerFrameItemButtonMixin
    local update=field(owner,"OnUpdate")
    if index==1 and type(mixin)=="table" and type(field(mixin,"OnUpdate"))=="function" and
        update==field(mixin,"OnUpdate") then
        local bag,bagRead=invoke(owner,"GetBagID")
        local slot,slotRead=invoke(owner,"GetID")
        local api=type(C_Container)=="table" and C_Container
        local linkGetter=api and api.GetContainerItemLink or GetContainerItemLink
        if bagRead and slotRead and I:Number(bag) and bag%1==0 and bag>=-20 and bag<=100 and I:Integer(slot) and slot<=256 then
            local before,read=I:Call(linkGetter,bag,slot)
            local id=read and I:Text(before,600) and I.Items:Parse(before)
            local info,infoRead=I:Call(api and api.GetContainerItemInfo,bag,slot)
            local after,checked=I:Call(linkGetter,bag,slot)
            local currentOwner,ownerRead=invoke(tooltip,"GetOwner")
            local currentBag=invoke(owner,"GetBagID");local currentSlot=invoke(owner,"GetID")
            if I:Integer(id) and checked and sameItem(before,after) and ownerRead and currentOwner==owner and
                currentBag==bag and currentSlot==slot and field(owner,"OnUpdate")==update then
                context.kind="ITEM";context.getter="NativeBagOwner";context.family="BAG"
                context.itemID=id;context.link=before;context.identity=before;context.bagID=bag;context.slotIndex=slot
                local count=infoRead and tableOK(info) and field(info,"stackCount")
                if I:Integer(count) and count<=10000 then context.stackCount=count end
                self.captureSuccesses=self.captureSuccesses+1
                return context
            end
        end
    end
    return nil,"NATIVE_CURRENT_CONTENT_UNAVAILABLE"
end
function T:Capture(tooltip,data)
    self.captureAttempts=self.captureAttempts+1
    local index,name=self:Surface(tooltip)
    if not index then return nil,"UNQUALIFIED_TOOLTIP_SURFACE" end
    if self.fading[tooltip] then return nil,"NATIVE_FADING" end
    if self.textOnly[tooltip] then return nil,"NATIVE_TEXT_ONLY" end
    local primaryGetter,getterReadable=field(tooltip,"GetPrimaryTooltipData")
    if getterReadable==false then return nil,"NATIVE_PRIMARY_DATA_UNAVAILABLE" end
    local primary,ok=I:Call(primaryGetter,tooltip)
    if type(primaryGetter)=="function" and not ok then return nil,"NATIVE_PRIMARY_DATA_UNAVAILABLE" end
    if not ok or primary==nil then
        -- A native primary object which exists but is inaccessible must never
        -- be bypassed. Missing metadata can use the public native accessors.
        if primary~=nil then return nil,"NATIVE_PRIMARY_DATA_UNAVAILABLE" end
        if data~=nil then return nil,"NATIVE_PRIMARY_DATA_UNAVAILABLE" end
        return self:LegacyCapture(tooltip,index,name)
    end
    if not tableOK(primary) then return nil,"NATIVE_PRIMARY_DATA_UNAVAILABLE" end
    -- Native appendInfo postcalls are not a new primary item lifetime.
    if data and primary~=data then return nil,"SECONDARY_DATA_IGNORED" end
    data=primary
    local owner,ownerOK=invoke(tooltip,"GetOwner")
    if not ownerOK or not owner then return nil,"NATIVE_OWNER_UNAVAILABLE" end
    local visible,ownerVisibleOK=ownerVisible(owner)
    if ownerVisibleOK and visible==false then return nil,"NATIVE_OWNER_HIDDEN" end
    local info,infoOK=invoke(tooltip,"GetPrimaryTooltipInfo")
    if not infoOK or not tableOK(info) then return nil,"NATIVE_GETTER_CONTEXT_UNAVAILABLE" end
    local getter=field(info,"getterName")
    -- The reviewed comparison manager directly supplies tooltipData rather
    -- than a getter name. Qualify only its four native surfaces and native
    -- owning tooltip; do not generalize this to arbitrary custom providers.
    if getter==nil and index>=3 and (owner==_G.GameTooltip or owner==_G.ItemRefTooltip) and
        field(info,"tooltipData")==primary then getter="NativeComparisonData" end
    if getter==nil and field(info,"tooltipData")==primary and Enum and Enum.TooltipDataType then
        -- ProcessInfo may receive public data directly, without a getter name.
        -- Exact readable item/link or GUID matching below still qualifies the
        -- native lifetime; no displayed label is used to guess an identity.
        local kind=field(primary,"type")
        getter=kind==Enum.TooltipDataType.Item and "NativeItemData" or
            kind==Enum.TooltipDataType.Spell and "NativeSpellData" or
            kind==Enum.TooltipDataType.Unit and "NativeUnitData" or nil
    end
    if not I:Text(getter,80) or not families[getter] then return nil,"UNQUALIFIED_TOOLTIP_GETTER" end
    local args=field(info,"getterArgs")
    local family=index>=3 and "COMPARISON" or (name=="ItemRefTooltip" and getter=="GetHyperlink" and "CHAT_LINK" or families[getter])
    local kind=field(data,"type")
    local enum=Enum and Enum.TooltipDataType
    if not enum then return nil,"NATIVE_TOOLTIP_ENUM_UNAVAILABLE" end
    local context={index=index,surface=name,owner=owner,getter=getter,family=family,argsKey=argsKey(args),
        dataInstanceID=field(data,"dataInstanceID"),capturedAt=now()}
    if not I:Number(context.dataInstanceID) and not I:Text(context.dataInstanceID,100) then context.dataInstanceID=nil end
    if kind==enum.Spell and (family=="RECIPE_OUTPUT" or family=="SPELL") and self:Detail(prefs() or {}) then
        local recipeID=field(data,"id")
        local recipe=I.Storage.character and I.Storage.character.recipes[recipeID]
        local api=type(C_TooltipInfo)=="table" and C_TooltipInfo
        local result,known=I:Call(api and api.GetRecipeResultItem,recipeID)
        local link,itemID
        if known then link,itemID=itemLinkFromData(result) end
        if type(recipe)=="table" and I:Integer(itemID) and recipe.outputID==itemID then
            context.kind="ITEM";context.itemID=itemID;context.link=link;context.identity=link
            context.recipeID=recipeID;context.family="RECIPE_OUTPUT"
        else
            -- A public spell is still useful without an observed output recipe.
            -- Retain its real spell ID; never guess an item or profession.
            if not I:Integer(recipeID) then return nil,"SPELL_ID_UNREADABLE" end
            context.kind="SPELL";context.spellID=recipeID;context.identity="spell:"..recipeID
        end
    elseif kind==enum.Spell then
        local spellID=field(data,"id")
        if not I:Integer(spellID) then return nil,"SPELL_ID_UNREADABLE" end
        context.kind="SPELL";context.spellID=spellID;context.identity="spell:"..spellID
    elseif kind==enum.Item then
        local itemID=field(data,"id")
        if not I:Integer(itemID) then return nil,"ITEM_ID_UNREADABLE" end
        -- Match the native TooltipUtil precedence: GUID, then returned full hyperlink.
        local link;local guid,guidReadable=field(data,"guid")
        if guidReadable==false then return nil,"ITEM_GUID_UNREADABLE" end
        if guid~=nil then
            if not I:Text(guid,180) then return nil,"ITEM_GUID_UNREADABLE" end
            local api=type(C_Item)=="table" and C_Item
            local value,readable=I:Call(api and api.GetItemLinkByGUID,guid)
            if readable and I:Text(value,600) then link=value
            end
        end
        if not link then
            local _,readable,value=invoke(tooltip,"GetItem")
            if readable and I:Text(value,600) then link=value end
        end
        if not link then local value=field(data,"hyperlink");if I:Text(value,600) then link=value end end
        if not link and getter=="GetBagItem" and tableOK(args) then
            local bag,slot=field(args,1),field(args,2)
            if I:Number(bag) and I:Integer(slot) then
                local api=type(C_Container)=="table" and C_Container
                local value,readable=I:Call(api and api.GetContainerItemLink,bag,slot)
                if readable and I:Text(value,600) then link=value end
            end
        end
        if not link or not link:find("item:",1,true) then return nil,"FULL_ITEM_LINK_UNAVAILABLE" end
        local parsed=I.Items and I.Items:Parse(link)
        if parsed~=itemID then return nil,"NATIVE_ITEM_IDENTITY_MISMATCH" end
        context.kind="ITEM";context.itemID=itemID;context.link=link;context.identity=link
        if (family=="RECIPE_REAGENT" or family=="RECIPE_OUTPUT") and tableOK(args) then
            local recipeID=field(args,1)
            if I:Integer(recipeID) then context.recipeID=recipeID end
        end
        if getter=="GetBagItem" and tableOK(args) then
            local bag,slot=field(args,1),field(args,2)
            if I:Number(bag) and bag%1==0 and bag>=-20 and bag<=100 and I:Integer(slot) and slot<=256 then
                local api=type(C_Container)=="table" and C_Container
                local current,checked=I:Call(api and api.GetContainerItemLink,bag,slot)
                if checked and sameItem(current,link) then
                    context.bagID=bag;context.slotIndex=slot
                    local value,infoRead=I:Call(api.GetContainerItemInfo,bag,slot)
                    local after,afterRead=I:Call(api.GetContainerItemLink,bag,slot)
                    local count=tableOK(value) and field(value,"stackCount")
                    if infoRead and afterRead and sameItem(current,after) and I:Integer(count) and count<=10000 then
                        context.stackCount=count
                    end
                end
            end
        end
    elseif kind==enum.Unit and (getter=="GetUnit" or getter=="GetWorldCursor" or getter=="GetMinimapMouseover" or getter=="NativeUnitData") then
        local _,unitOK,unit,guid=invoke(tooltip,"GetUnit")
        local dataGUID=field(data,"guid")
        if not I:Text(dataGUID,180) then return nil,"UNIT_IDENTITY_UNAVAILABLE" end
        if not unitOK or not I:Text(unit,80) then
            local token,readable=I:Call(UnitTokenFromGUID,dataGUID)
            if readable and I:Text(token,80) then unit=token;guid=dataGUID
            elseif getter=="GetUnit" and tableOK(args) then unit=field(args,1);guid=dataGUID end
        end
        if not I:Text(unit,80) or (guid~=nil and dataGUID~=guid) then return nil,"UNIT_IDENTITY_UNAVAILABLE" end
        guid=dataGUID
        local current,checked=I:Call(UnitGUID,unit)
        if not checked or current~=guid then return nil,"UNIT_IDENTITY_CHANGED" end
        context.kind="UNIT";context.unit=unit;context.guid=guid;context.identity=guid..":"..unit
    else return nil,"UNQUALIFIED_TOOLTIP_TYPE" end
    self.captureSuccesses=self.captureSuccesses+1
    return context
end
local function matches(a,b)
    return a and b and a.kind==b.kind and a.identity==b.identity and a.owner==b.owner and
        a.getter==b.getter and a.argsKey==b.argsKey and a.dataInstanceID==b.dataInstanceID
end
function T:Release(index,reason)
    if reason~="NATIVE_HIDDEN" and reason~="NATIVE_CLEARED" then self.lastRenderReason=reason end
    local state=self.states[index]
    if state then
        if state.ownsMarket and reason~="NATIVE_CLEARED" and reason~="NATIVE_HIDDEN" then self.marketDirty=true end
        self.generation=self.generation+1;state.generation=self.generation
        state.context=nil;state.model=nil;state.prepared=false;state.ownsMarket=false
        state.reason=reason or "CLEARED";state.pendingAge=0;state.visualVisible=false
        if reason=="NATIVE_CLEARED" then state.blockedContext=nil end
    end
    -- Cleanup must never Show a native tooltip. An already fading world tip
    -- has no primary data; reopening it is the P16 stuck-tooltip failure.
    if I.TooltipCard then I.TooltipCard:Hide(index,reason=="NATIVE_CLEARED",true) end
end
function T:HideAll(reason)
    self.pendingCaptures={}
    self.fading=setmetatable({}, {__mode="k"})
    for index=1,#surfaces do self:Release(index,reason) end
    if self.watcher then self.watcher:Hide() end
    self.status=reason or "HIDDEN"
end
function T:Hook(tooltip,index)
    if self.hooks[tooltip]==true then return true end
    if self.hooks[tooltip]=="INSTALLING" then return false end
    self.hooks[tooltip]="INSTALLING"
    self.surfaceEpochs=self.surfaceEpochs or setmetatable({}, {__mode="k"})
    local hook=field(tooltip,"HookScript")
    if type(hook)~="function" then self.hooks[tooltip]=false;return false end
    self.scriptHooks=self.scriptHooks or setmetatable({}, {__mode="k"})
    local scripts=self.scriptHooks[tooltip] or {};self.scriptHooks[tooltip]=scripts
    local function install(script,fn)
        if scripts[script] then return true end
        local ok=pcall(hook,tooltip,script,fn)
        if ok then scripts[script]=true end
        return ok
    end
    local function ownsLifetime()
        local card=I.TooltipCard and I.TooltipCard.cards[index]
        local state=T.states[index]
        return card and card.native==tooltip or
            state and state.tooltip==tooltip and (not card or not card.native)
    end
    local a=install("OnTooltipCleared",function()
        T.fading[tooltip]=nil
        T.setterContexts[tooltip]=nil
        T.textOnly[tooltip]=nil
        T.surfaceEpochs[tooltip]=(T.surfaceEpochs[tooltip] or 0)+1
        if ownsLifetime() then T:Release(index,"NATIVE_CLEARED") end
    end)
    local b=install("OnHide",function()
        T.fading[tooltip]=nil
        T.setterContexts[tooltip]=nil
        T.textOnly[tooltip]=nil
        local pending=T.pendingCaptures[index]
        if pending and pending.tooltip==tooltip then T.pendingCaptures[index]=nil end
        if ownsLifetime() then T:Release(index,"NATIVE_HIDDEN") end
    end)
    local c=install("OnShow",function()
        if I.TooltipCard and I.TooltipCard:IsRefreshing(tooltip) then return end
        T.fading[tooltip]=nil
        -- Postcalls run before native Show in the reviewed handler. Re-read once
        -- now so any earlier Wealthcraft fallback owns its own existing section.
        local ok,rendered=pcall(T.Render,T,tooltip,nil,"NATIVE_SHOW")
        if not ok then T:Release(index,"SHOW_RECONCILIATION_FAILED") end
        if not ok or not rendered then T:QueueCapture(tooltip,index) end
        if index<=2 then
            -- Native comparisons may be prepared before the primary tooltip
            -- itself becomes visible. Reconcile them after their owner shows.
            for childIndex=3,#surfaces do
                local child=_G[surfaces[childIndex]]
                local owner=child and invoke(child,"GetOwner")
                if owner==tooltip and nativeShown(child) then
                    local prepared=pcall(T.Render,T,child,nil,"COMPARISON_OWNER_SHOWN")
                    if not prepared then T:Release(childIndex,"COMPARISON_RECONCILIATION_FAILED") end
                end
            end
        end
    end)
    self.hooks[tooltip]=a and b and c
    if not self.hooks[tooltip] then self.hookFailures=self.hookFailures+1 end
    return self.hooks[tooltip]
end
function T:QueueCapture(tooltip,index)
    if not index or not tooltip then return end
    local pref=prefs()
    if not I.state.clientAllowed or not pref or I.Storage.readOnly or pref.tooltip~=true or pref.tooltipPresentation=="NATIVE" or not self:CoreAllows() then return end
    local pending=self.pendingCaptures[index]
    if not pending or pending.tooltip~=tooltip then self.pendingCaptures[index]={tooltip=tooltip,attempts=0} end
    self:WakeWatcher()
end
function T:InstallMethodHooks(tooltip,index)
    if type(hooksecurefunc)~="function" then return end
    local hooks=self.methodHooks[tooltip]
    if not hooks then hooks={};self.methodHooks[tooltip]=hooks end
    local methods={"SetBagItem","SetInventoryItem","SetHyperlink","SetItemByID","SetItemByGUID",
        "SetMerchantItem","SetBuybackItem","SetQuestItem","SetQuestLogItem","SetLootItem","SetInboxItem",
        "SetRecipeReagentItem","SetRecipeResultItem","SetRecipeResultItemForOrder","SetUnit","SetWorldCursor","SetMinimapMouseover",
        "SetTradeSkillItem","SetCraftItem","SetSpellByID","SetSpellBookItem","SetAction","SetRecipeRankInfo"}
    for _,method in ipairs(methods) do
        if not hooks[method] and type(field(tooltip,method))=="function" then
            local ok=pcall(hooksecurefunc,tooltip,method,function(_, ...)
                if I.TooltipCard and I.TooltipCard:IsRefreshing(tooltip) then return end
                -- SetWorldCursor itself calls FadeOut when the pointer leaves
                -- an object. Its trailing hook is not a new hover lifetime.
                if T.fading[tooltip] and (method=="SetWorldCursor" or method=="SetMinimapMouseover") then return end
                T.fading[tooltip]=nil
                T.textOnly[tooltip]=nil
                local owner=invoke(tooltip,"GetOwner")
                local args={...};local public={};local complete=true
                for n=1,6 do
                    local value=args[n]
                    if not I:Readable(value) or value~=nil and type(value)~="string" and type(value)~="number" and type(value)~="boolean" then complete=false;break end
                    public[n]=value
                end
                T.setterContexts[tooltip]={method=method,args=public,complete=complete,owner=owner,epoch=T.surfaceEpochs and T.surfaceEpochs[tooltip] or 0}
                local state=T.states[index]
                if state and state.rendering then return end
                if state and state.prepared and matches(state.context,T:Capture(tooltip)) then return end
                -- The data callback normally owns this pass. Reconciliation
                -- here also covers native setters that do not dispatch it.
                local rendered,result=pcall(T.Render,T,tooltip,nil,"NATIVE_SETTER")
                if not rendered or not result then T:QueueCapture(tooltip,index) end
            end)
            if ok then hooks[method]=true else self.hookFailures=self.hookFailures+1 end
        end
    end
    if not hooks.FadeOut and type(field(tooltip,"FadeOut"))=="function" then
        local ok=pcall(hooksecurefunc,tooltip,"FadeOut",function()
            if nativeShown(tooltip) then T:BeginFade(tooltip,index) end
        end)
        if ok then hooks.FadeOut=true else self.hookFailures=self.hookFailures+1 end
    end
end
function T:InstallPresentationHooks(tooltip,index)
    if type(hooksecurefunc)~="function" then return end
    self.presentationHooks=self.presentationHooks or setmetatable({}, {__mode="k"})
    self.surfaceDirty=self.surfaceDirty or setmetatable({}, {__mode="k"})
    local hooks=self.presentationHooks[tooltip] or {};self.presentationHooks[tooltip]=hooks
    for _,method in ipairs({"Show","SetText","AddLine","AddDoubleLine","SetBackdrop","SetBackdropColor","SetBackdropBorderColor"}) do
        if not hooks[method] and type(field(tooltip,method))=="function" then
            local ok=pcall(hooksecurefunc,tooltip,method,function()
                if I.TooltipCard and I.TooltipCard:IsRefreshing(tooltip) then return end
                if method=="SetText" then
                    T.fading[tooltip]=nil
                    T.setterContexts[tooltip]=nil;T.textOnly[tooltip]=true
                    T.lastCaptureReason="NATIVE_TEXT_ONLY"
                    T:Release(index,"NATIVE_TEXT_CHANGED")
                end
                T.surfaceDirty[tooltip]=true
                if method=="Show" or method=="SetText" or method=="SetBackdrop" then
                    T:PresentSurface(tooltip,"NATIVE_SURFACE_REFRESH")
                end
            end)
            if ok then hooks[method]=true else self.hookFailures=self.hookFailures+1 end
        end
    end
    if not self.backdropHook and type(_G.SharedTooltip_SetBackdropStyle)=="function" then
        self.backdropHook=pcall(hooksecurefunc,_G,"SharedTooltip_SetBackdropStyle",function(tip)
            if T:Surface(tip) and not (I.TooltipCard and I.TooltipCard:IsRefreshing(tip)) then
                T:PresentSurface(tip,"NATIVE_BACKDROP_REFRESH")
            end
        end) or nil
    end
end
local function row(model,text,role,section)
    if #model.rows<14 and I:Text(text,800) then
        model.rows[#model.rows+1]={text=text,role=role or "text",section=section or "facts"}
    end
end
function T:UnitModel(context)
    local model={kind="UNIT",guid=context.guid,unit=context.unit,rows={},family="UNIT",status="PUBLIC_UNIT_CONTEXT",
        nativeBody="RETAINED",nativeAcceptance="NOT_RUN"}
    local p=prefs() or {}
    local isPlayer,known=I:Call(UnitIsPlayer,context.unit)
    if p.showUnitID~=false and known and isPlayer~=true and I:Text(context.guid,180) then
        local kind,id=context.guid:match("^(%a+)%-[^%-]*%-[^%-]*%-[^%-]*%-[^%-]*%-(%d+)%-")
        local number=tonumber(id)
        if (kind=="Creature" or kind=="Vehicle") and I:Integer(number) then
            model.rows[1]={label="Creature number",value=tostring(number),text="Creature number: "..number,role="muted",section="unit"}
        end
    end
    return model
end
function T:HasNativeSellPrice(context)
    local tip=_G[context.surface]
    local name,known=invoke(tip,"GetName")
    local count,read=invoke(tip,"NumLines")
    if not known or not read or not I:Text(name,120) or not I:Number(count) then return false end
    local card=I.TooltipCard and I.TooltipCard.cards[context.index]
    local ours={}
    for _,line in ipairs(card and card.lines or {}) do if line.left then ours[line.left]=true end end
    local label=I:Label(SELL_PRICE,100) or "Sell Price"
    label=label:lower()..":"
    for n=1,math.min(count,100) do
        local line=_G[name.."TextLeft"..n]
        if line and not ours[line] then
            local value,ok=invoke(line,"GetText")
            if ok and I:Text(value,2000) then
                value=value:gsub("|c%x%x%x%x%x%x%x%x",""):gsub("|r",""):lower()
                if value:sub(1,#label)==label then return true end
            end
        end
    end
    return false
end
function T:Build(context,data,pref)
    local detail=self:Detail(pref)
    local model
    if context.kind=="UNIT" then model=self:UnitModel(context,detail)
    elseif context.kind=="SPELL" then
        model={kind="SPELL",spellID=context.spellID,rows={},family=context.family,
            status="PUBLIC_SPELL_CONTEXT",nativeBody="RETAINED",nativeAcceptance="NOT_RUN"}
        if pref.showItemID~=false then
            model.rows[1]={label="Spell number",value=tostring(context.spellID),text="Spell number: "..context.spellID,
                role="muted",section="facts"}
        end
    else
        local options={detail=detail,limit=detail and 11 or 8,nativeData=data,family=context.family,
            bagID=context.bagID,slotIndex=context.slotIndex,stackCount=context.stackCount,recipeID=context.recipeID,
            passiveTooltip=true}
        if I.Context and type(I.Context.Build)=="function" then
            local value,ok=I:Call(I.Context.Build,I.Context,context.link,options)
            if ok and tableOK(value) then model=copy(value) end
        end
        if not model then
            local facts=I.Items:Facts(context.link)
            model={facts=facts,itemID=context.itemID,rows={},status="ITEM_FACTS_ONLY",locations={}}
        end
        if not tableOK(model.rows) then model.rows={} end
        -- Bounded copied rows are the only strings handed to the companion renderer.
        local valid={}
        local nativeSellPrice=self:HasNativeSellPrice(context)
        for _,source in ipairs(model.rows) do
            if #valid>=options.limit then break end
            if tableOK(source) and I:Text(source.text,800) then
                local singleVendor=source.section=="vendor" and source.vendorBasis=="UNIT"
                local bagStack=I:Integer(context.stackCount) and context.stackCount>1 and
                    (context.family=="BAG" or context.family=="BAG_CHILD")
                -- Native bag tooltips already quote the current stack's sell
                -- total. Omit that duplicate row and make
                -- the supplemental one-item price explicit. Recipe quantities
                -- and an item's maximum stack size never imply a hovered stack.
                local nativeStack=source.section=="vendor" and source.vendorBasis=="STACK" and bagStack and nativeSellPrice
                if not nativeStack and not (singleVendor and nativeSellPrice and not bagStack) then
                    local label=I:Text(source.label,100)
                    local value=I:Text(source.value,600)
                    valid[#valid+1]={text=label and value and label..": "..value or source.text,
                        label=label,value=value,role=I:Label(source.role,30),section=I:Label(source.section,40)}
                end
            end
        end
        model.rows=valid;model.kind="ITEM";model.item=context.link;model.exactLink=context.link;model.itemID=context.itemID
        local dependencies={};local count=0
        if tableOK(model.itemDependencies) then
            for itemID in pairs(model.itemDependencies) do
                if I:Integer(itemID) and count<5 then dependencies[itemID]=true;count=count+1 end
            end
        end
        model.itemDependencies=dependencies
        model.family=context.family;model.stackCount=context.stackCount
        model.nativeBody="RETAINED";model.nativeAcceptance="NOT_RUN"
        if pref.marketProvider=="Wealthcraft" and pref.showMarketTooltip==true and I.Market then
            local owner
            if type(I.Market.HasTooltipSection)=="function" then
                owner=I:Call(I.Market.HasTooltipSection,I.Market,_G[context.surface],context.link,"market")
            end
            if owner~="Wealthcraft" then
                local quote,queried,reason=I:Call(I.Market.Get,I.Market,context.link,{stackCount=context.stackCount})
                if not queried then quote=nil;reason="PROVIDER_QUERY_FAILED" end
                if quote and quote.requestedLink==context.link and I:Number(quote.priceCopper) then
                    local label="Market reference"
                    local value=I.Items:Coin(quote.priceCopper).." / item"
                    model.rows[#model.rows+1]={label=label,value=value,text=label..": "..value,role="market",section="market"}
                    if I:Number(quote.ageSeconds) and quote.ageSeconds>=0 then
                        local age=I:Call(I.Market.AgeLabel,I.Market,quote.ageSeconds)
                        if I:Label(age,60) then
                            model.rows[#model.rows+1]={label="Recorded",value=age,text="Recorded: "..age,role="muted",section="market"}
                        end
                    end
                    model.market=copy(quote);model.ownsMarket=true
                else
                    model.marketStatus=reason
                    if reason=="NO_EXACT_LINK_OBSERVATION" or reason=="NO_PRICED_LISTINGS" or reason=="NO_COMPLETE_SCAN" or reason=="NO_SAVED_QUOTE" then
                        model.rows[#model.rows+1]={label="Market reference",value="No verified quote",
                            text="Market reference: No verified quote",role="muted",section="market_status"}
                    end
                end
            else model.marketStatus="WEALTHCRAFT_NATIVE_SECTION_RETAINED" end
        end
    end
    model.detail=detail
    return model
end
function T:Render(tooltip,data,source)
    I.state.tooltipCalls=(I.state.tooltipCalls or 0)+1
    local index=self:Surface(tooltip)
    if not index then return false,"UNQUALIFIED_TOOLTIP_SURFACE" end
    if self.fading[tooltip] then return false,"NATIVE_FADING" end
    local pref=prefs()
    if not I.state.clientAllowed or not pref or I.Storage.readOnly or pref.tooltip~=true or pref.tooltipPresentation=="NATIVE" or not self:CoreAllows() then
        self:Release(index,"NATIVE_PRESENTATION_SELECTED");return false,"NATIVE_PRESENTATION_SELECTED"
    end
    local external=self:ExternalOwner(tooltip)
    if external then self:Release(index,"EXTERNAL_TOOLTIP_OWNER");return false,"EXTERNAL_TOOLTIP_OWNER" end
    local context,reason=self:Capture(tooltip,data)
    if not context then
        self.lastCaptureReason=reason
        if reason=="NATIVE_OWNER_HIDDEN" then self:HideExpiredOwner(tooltip) end
        if reason~="SECONDARY_DATA_IGNORED" then self:Release(index,reason) end
        if reason~="SECONDARY_DATA_IGNORED" then self:PresentSurface(tooltip,source) end
        return false,reason
    end
    if not self:Hook(tooltip,index) then self:Release(index,"LIFECYCLE_HOOK_UNAVAILABLE");return false,"LIFECYCLE_HOOK_UNAVAILABLE" end
    local state=self.states[index]
    if not state then state={index=index,tooltip=tooltip};self.states[index]=state end
    if state.blockedContext then
        if state.tooltip==tooltip and matches(state.blockedContext,context) then return false,"TOOLTIP_ROWS_REPLACED" end
        state.blockedContext=nil
    end
    if state.rendering then self.refreshPending=true;self:WakeWatcher();return false,"REENTRANT_RENDER_DEFERRED" end
    if state.tooltip~=tooltip or not matches(state.context,context) then
        self:Release(index,"NEW_TOOLTIP_CONTEXT");self.generation=self.generation+1
        state.generation=self.generation;state.context=context;state.tooltip=tooltip
    end
    self.pendingCaptures[index]=nil;self.lastCaptureReason="READY"
    local generation=state.generation
    state.rendering=true
    local primary=invoke(tooltip,"GetPrimaryTooltipData")
    local ok,model=pcall(self.Build,self,context,primary,pref)
    state.rendering=false
    if not ok or not tableOK(model) then
        self:Release(index,"CONTEXT_BUILD_FAILED");I:Fault("TOOLTIP_CONTEXT_BUILD_FAILED");return false,"CONTEXT_BUILD_FAILED"
    end
    -- Data providers can complete synchronously or re-enter another native hover.
    -- Never publish the old result after that tooltip's identity or owner changed.
    local current=self:Capture(tooltip)
    if state.generation~=generation or not matches(context,current) or context.stackCount~=current.stackCount then
        self:Release(index,"STALE_CONTEXT_DISCARDED");self.refreshPending=true;self:WakeWatcher()
        return false,"STALE_CONTEXT_DISCARDED"
    end
    model.generation=generation;model.surface=context.surface;model.ownerPolicy="NATIVE_UNMODIFIED"
    if not I.TooltipCard then self:Release(index,"CARD_RENDERER_UNAVAILABLE");return false,"CARD_RENDERER_UNAVAILABLE" end
    local prepared,status,positioned=I.TooltipCard:Prepare(index,tooltip,model,pref,source)
    if not prepared then
        self:Release(index,status)
        if status=="TOOLTIP_ROWS_REPLACED" then state.blockedContext=context end
        return false,status
    end
    state.context=context;state.model=model;state.prepared=true;state.reason=status
    self.renderSuccesses=self.renderSuccesses+1;self.lastRenderReason=status
    state.ownsMarket=model.ownsMarket==true and positioned==true;state.pendingAge=0
    self.lastIndex=index;self.status="INTEGRATED_TOOLTIP_READY"
    I.state.tooltipLines=(I.state.tooltipLines or 0)+#model.rows
    if nativeShown(tooltip) then
        local visible,showReason=I.TooltipCard:Show(index)
        state.visualVisible=visible==true
        if not visible then state.ownsMarket=false;state.reason=showReason end
        if context.kind=="ITEM" and now()>0 then self.recent={model=copy(model),at=now()} end
    else state.visualVisible=false
    end
    self:WakeWatcher()
    return true,status
end
function T:ClaimMarket(tooltip,data)
    local index=self:Surface(tooltip)
    if not index then return false end
    local ok,result=pcall(self.Render,self,tooltip,data,"MARKET_CLAIM")
    local state=self.states[index]
    -- Native postcalls precede Show. A fully prepared, positioned current card
    -- can own this section; a missing layout or unavailable renderer cannot.
    return ok and result==true and state and state.prepared==true and state.ownsMarket==true or false
end
function T:RefreshVisible(reason,itemID)
    if self.refreshing then self.refreshPending=true;return false end
    self.refreshing=true
    if I.TooltipCard then I.TooltipCard:DrainCleanup() end
    for index=1,#surfaces do
        local tooltip=_G[surfaces[index]];local state=self.states[index]
        local selected=not itemID or state and state.context and
            (state.context.itemID==itemID or state.model and state.model.itemDependencies and state.model.itemDependencies[itemID]==true)
        if not selected and tooltip and state and not state.prepared and nativeShown(tooltip) then
            -- A failed provider build releases its model. An item completion
            -- can still recover this visible surface from its current native
            -- identity, without retaining a failed or previous hover model.
            local current=self:Capture(tooltip)
            selected=current and current.itemID==itemID
        end
        if tooltip and selected then
            if nativeShown(tooltip) then
                local ok=pcall(self.Render,self,tooltip,nil,reason)
                if not ok then self:Release(index,"REFRESH_FAILED") end
            elseif state and not state.prepared then self:Release(index,"NATIVE_NOT_VISIBLE") end
        end
    end
    self.refreshing=false
    return true
end
function T:Tick(elapsed)
    self.elapsed=(self.elapsed or 0)+elapsed
    if self.elapsed<.15 then return end
    local delta=self.elapsed;self.elapsed=0;local any=false;local marketVisibilityChanged=false
    for index,pending in pairs(self.pendingCaptures) do
        if nativeShown(pending.tooltip) and pending.attempts<4 then
            pending.attempts=pending.attempts+1
            local ok,prepared=pcall(self.Render,self,pending.tooltip,nil,"NATIVE_SETTLED")
            if ok and prepared then self.pendingCaptures[index]=nil
            elseif pending.attempts<4 then any=true else self.pendingCaptures[index]=nil end
        else self.pendingCaptures[index]=nil end
    end
    for index=1,#surfaces do
        local state=self.states[index]
        if state and state.prepared then
            local current=self:Capture(state.tooltip)
            if not matches(state.context,current) then
                self:HideExpiredOwner(state.tooltip);self:Release(index,"CURRENT_OWNER_OR_IDENTITY_CHANGED")
            elseif not nativeShown(state.tooltip) then
                state.pendingAge=(state.pendingAge or 0)+delta
                if state.pendingAge>.45 then self:Release(index,"NATIVE_SHOW_NOT_OBSERVED") else any=true end
            else
                any=true;state.pendingAge=0
                local owner=state.context.owner
                local visible,ownerRead=ownerVisible(owner)
                if ownerRead and visible==false then self:HideExpiredOwner(state.tooltip);self:Release(index,"OWNER_HIDDEN")
                else
                    if state.context.stackCount~=current.stackCount then
                        self:Render(state.tooltip,nil,"CARRIED_STACK_CHANGED")
                    end
                    local previous=state.visualVisible
                    local visible,reason=I.TooltipCard:Tick(index,delta)
                    state.visualVisible=visible==true
                    if not visible then state.ownsMarket=false;state.reason=reason end
                    if previous~=state.visualVisible and state.model and state.model.ownsMarket then
                        marketVisibilityChanged=true
                        if state.visualVisible then self:Render(state.tooltip,nil,"LAYOUT_RECOVERED") end
                    end
                end
            end
        end
    end
    -- Styling is independent of optional item/unit intelligence. Spell-based
    -- profession tooltips and plain native text retain the Mirage presentation
    -- even when no exact semantic identity is publicly available.
    for index,name in ipairs(surfaces) do
        local tip=_G[name];local card=I.TooltipCard and I.TooltipCard.cards[index]
        if card and card.native==tip and nativeShown(tip) and not self.fading[tip] then
            if not self:CoreAllows() then self:Release(index,"NATIVE_PRESENTATION_SELECTED")
            elseif self:PresentationEnabled(tip) then
                any=true
                if self.surfaceDirty and self.surfaceDirty[tip] then
                    self.surfaceDirty[tip]=nil;self:PresentSurface(tip,"NATIVE_SURFACE_CHANGED")
                end
            end
        end
    end
    for tip in pairs(self.fading) do
        if nativeShown(tip) then any=true else self.fading[tip]=nil end
    end
    if (marketVisibilityChanged or self.marketDirty) and I.Market and type(I.Market.RefreshTooltipOwner)=="function" then
        self.marketDirty=false
        I.Market:RefreshTooltipOwner()
    end
    if self.refreshPending then
        self.refreshPending=false;self:RefreshVisible("DEFERRED_REFRESH")
        for _,state in pairs(self.states) do if state.prepared then any=true;break end end
    end
    local pref=prefs()
    if any and pref and pref.tooltip==true and pref.showMarketTooltip==true and pref.marketProvider=="Wealthcraft" and
        I.Market and type(I.Market.TooltipRevision)=="function" then
        self.marketElapsed=(self.marketElapsed or 0)+delta
        if self.marketElapsed>=1 then
            self.marketElapsed=0
            local revision,readable=I:Call(I.Market.TooltipRevision,I.Market)
            local token=readable and I:Text(revision,1000) or "PROVIDER_REVISION_UNAVAILABLE"
            if token~=self.marketRevision then
                self.marketRevision=token;self:RefreshVisible("MARKET_REVISION_CHANGED")
                if type(I.Market.RefreshTooltipOwner)=="function" then I.Market:RefreshTooltipOwner() end
            end
        end
    else self.marketElapsed=0;self.marketRevision=nil end
    if not any and self.watcher then self.watcher:Hide() end
end
function T:WakeWatcher()
    if not self.watcher and type(CreateFrame)=="function" then
        local ok,frame=pcall(CreateFrame,"Frame",nil,UIParent)
        if ok and frame then
            self.watcher=frame;frame:EnableMouse(false)
            frame:SetScript("OnUpdate",function(_,elapsed) T:Tick(elapsed) end)
        end
    end
    if self.watcher then self.watcher:Show() end
end
function T:OnEvent(event,...)
    if event=="ITEM_DATA_LOAD_RESULT" or event=="GET_ITEM_INFO_RECEIVED" then
        local itemID=...
        if I:Integer(itemID) then self:RefreshVisible(event,itemID) end
    elseif event=="MODIFIER_STATE_CHANGED" or event=="RECIPE_CATALOG_READY" or event=="WORLD_RECORDS_CHANGED" or
        event=="TRADE_SKILL_SHOW" or event=="TRADE_SKILL_CLOSE" or event=="TRADE_SKILL_DATA_SOURCE_CHANGED" then
        self:RefreshVisible(event)
    elseif event=="PLAYER_LEAVING_WORLD" then self.recent=nil;self:HideAll("WORLD_LEAVING")
    elseif event=="ADDON_LOADED" or event=="PLAYER_LOGIN" or event=="PLAYER_ENTERING_WORLD" then
        self:Install();self:RefreshVisible(event)
    elseif event=="PLAYER_REGEN_DISABLED" or event=="PLAYER_REGEN_ENABLED" then
        -- Public passive companions keep working in combat; protected or secret
        -- content fails Capture and stays entirely native.
        self:RefreshVisible(event)
    end
end
function T:GetContext(tooltip)
    local index=tooltip and self:Surface(tooltip) or self.lastIndex
    local state=index and self.states[index]
    if not state or not state.model or not state.prepared or not nativeShown(state.tooltip) then return nil,"NO_CURRENT_TOOLTIP" end
    local current=self:Capture(state.tooltip)
    if not matches(state.context,current) then
        self:HideExpiredOwner(state.tooltip);self:Release(index,"STALE_INSPECT_CONTEXT");return nil,"STALE_CONTEXT"
    end
    return copy(state.model),"AVAILABLE"
end
function T:OpenInspector(tooltip)
    local model,reason=self:GetContext(tooltip)
    if not model then model,reason=self:GetRecentContext(15) end
    if not model then return false,reason end
    if I.Actions and type(I.Actions.OpenForContext)=="function" then return I.Actions:OpenForContext(model) end
    return false,"INSPECTOR_UNAVAILABLE"
end
function T:GetRecentContext(maxAge)
    -- Used exclusively by the deliberate inspector command/key binding. It
    -- never refreshes a hover, owns a native section or triggers navigation.
    maxAge=I:Number(maxAge) and math.max(0,math.min(15,maxAge)) or 15
    local recent=self.recent;local clock=now()
    if not recent or not recent.model or clock<recent.at or clock-recent.at>maxAge then
        return nil,"NO_RECENT_ITEM_CONTEXT"
    end
    local model=copy(recent.model)
    if not model then return nil,"RECENT_CONTEXT_UNREADABLE" end
    model.inspectionScope="RECENT_TOOLTIP_SNAPSHOT";model.snapshotAgeSeconds=clock-recent.at
    return model,"AVAILABLE"
end
function T:GetStatus()
    local active,market=0,0
    for _,state in pairs(self.states) do
        if state.prepared then active=active+1 end
        if state.ownsMarket then market=market+1 end
    end
    return {status=self.status,registered=self.installed==true,activeContexts=active,marketOwners=market,
        hookStrategy=self.hookStrategy,hookFailures=self.hookFailures,captureAttempts=self.captureAttempts,
        captureSuccesses=self.captureSuccesses,lastCaptureReason=self.lastCaptureReason,
        renderSuccesses=self.renderSuccesses,lastRenderReason=self.lastRenderReason,surfacePasses=self.surfacePasses,fadeReleases=self.fadeReleases,
        lastPresentationReason=self.lastPresentationReason,
        maxContexts=#surfaces,generation=self.generation,presentation="INTEGRATED_MIRAGE_TOOLTIP",
        nativeBody="RETAINED",nativeComparison="RETAINED",nativeInput="UNMODIFIED",nativeAcceptance="NOT_RUN"}
end
function T:OpenItem(item)
    if not I.state.clientAllowed or I.Storage.readOnly then return false,"Insight is unavailable." end
    if I:Combat() then return false,"Open an item after combat." end
    local id,link,token=I.Items:Parse(item)
    if not id then return false,"Choose an item link or item number." end
    local payload=token or (link and (link:match("|H(item:[^|]+)|h") or link)) or ("item:"..id)
    if type(SetItemRef)=="function" then
        local _,ok=I:Call(SetItemRef,payload,link or "","LeftButton")
        if ok then return true,"ITEM_OPENED" end
    end
    local tip=_G.ItemRefTooltip
    if tip and type(tip.SetHyperlink)=="function" then
        local _,ok=I:Call(tip.SetHyperlink,tip,payload)
        if ok then return true,"ITEM_OPENED" end
    end
    return false,"This item tooltip could not open."
end
function T:Install()
    if I.TooltipCard then I.TooltipCard:Initialize() end
    local hooked=0
    -- Surface lifetimes are independent of data-processor availability. Install
    -- these first, and retry at login/enter-world/late native addon loads.
    for index,name in ipairs(surfaces) do
        local tip=_G[name]
        if tip then
            if self:Hook(tip,index) then hooked=hooked+1 end
            self:InstallMethodHooks(tip,index)
            self:InstallPresentationHooks(tip,index)
        end
    end
    local processor=TooltipDataProcessor;local enum=Enum and Enum.TooltipDataType
    self.processorRegistrations=self.processorRegistrations or setmetatable({}, {__mode="k"})
    if self.processor~=processor then
        self.processor=processor;self.registered=processor and self.processorRegistrations[processor] or {}
        if processor then
            self.registered=self.registered or {};self.processorRegistrations[processor]=self.registered
        end
    end
    if processor and type(processor.AddTooltipPostCall)=="function" and enum then
        self.registered=self.registered or {}
        for _,kind in ipairs({enum.Item,enum.Unit,enum.Spell}) do
            if kind~=nil and not self.registered[kind] then
                local ok=pcall(processor.AddTooltipPostCall,kind,function(tooltip,data)
                    local success=pcall(T.Render,T,tooltip,data,"NATIVE_POSTCALL")
                    if not success then
                        local index=T:Surface(tooltip);if index then T:Release(index,"POSTCALL_FAILED") end
                        I:Fault("TOOLTIP_RENDER_FAILED")
                    end
                end)
                if ok then self.registered[kind]=true else self.hookFailures=self.hookFailures+1 end
            end
        end
    end
    self.installed=hooked>0
    local postcalls=processor and enum and self.registered and self.registered[enum.Item] and self.registered[enum.Unit]
    self.hookStrategy=postcalls and "NATIVE_DATA_AND_SURFACE" or hooked>0 and "NATIVE_SURFACE" or "WAITING_FOR_NATIVE_SURFACE"
    self.status=self.installed and "TOOLTIP_HOOKS_READY" or "WAITING_FOR_NATIVE_TOOLTIP"
    if I.Market and type(I.Market.InstallTooltipOwner)=="function" then I.Market:InstallTooltipOwner() end
    return self.installed
end

-- P39-A: one bounded slice per existing tooltip capture, no tooltip contents.
local p39TooltipCapture=T.Capture
function T:Capture(...)
    local core=I.core
    local perf,started
    if type(core)=='table' and type(core.GetService)=='function' then
        local ok,service=pcall(core.GetService,'Performance',1)
        if ok and type(service)=='table' and type(service.Begin)=='function' then
            perf=service
            local good,value=pcall(perf.Begin)
            if good and type(value)=='number' then started=value end
        end
    end
    local result=p39TooltipCapture(self,...)
    if started then pcall(perf.Finish,'insight.tooltip_capture',started) end
    return result
end
