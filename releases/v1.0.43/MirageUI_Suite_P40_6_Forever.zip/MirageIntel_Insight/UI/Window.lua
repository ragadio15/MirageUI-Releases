-- Insight's window is exclusively preferences. Item information lives in tooltips.
local _,I=...
I.UI={currentView="settings",controls={}}
local U=I.UI
local function chrome() return I.core and I.core.Chrome end
local function label(parent,text,x,y,width,role)
    local t=parent:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    t:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y);t:SetWidth(width);t:SetJustifyH("LEFT")
    if t.SetWordWrap then t:SetWordWrap(true) end
    t:SetText(text)
    local c=chrome();if c then c.Font(t,role or "body");c.Tint(t,role=="title" and "secondary" or "text") end
    return t
end
local function button(parent,text,x,y,w,fn)
    local c=chrome()
    if c then return c.Button(parent,text,x,y,w,27,fn) end
    local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
    b:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y);b:SetSize(w,27);b:SetText(text);b:SetScript("OnClick",fn)
    return b
end
local groups={
    {title="Appearance",rows={
        {key="tooltip",title="Insight tooltip presentation",hint="Show Mirage styling and Insight details on supported tooltips."},
        {key="tooltipTextSize",title="Text size",hint="Changes Insight text size; whole-tooltip scale is separate."},
    }},
    {title="Prices",rows={
        {key="showVendorTooltip",title="Vendor sell price"},
        {key="showMarketTooltip",title="Market listing value",hint="Use recorded WealthCraft prices when available."},
    }},
    {title="Uses",rows={
        {key="showRecipes",title="Crafting professions"},
        {key="professionDetails",title="Recipe materials",hint="Include recipe and material details while a profession is open."},
        {key="showQuestUses",title="Related quests"},
    }},
    {title="Locations",rows={
        {key="showLocations",title="Recorded item locations"},
    }},
    {title="Advanced",rows={
        {key="autoScan",title="Record recipes when a profession is opened",hint="Turn off to pause new recipe recording; saved recipes remain."},
        {key="showItemID",title="Technical IDs: items and spells"},
        {key="showUnitID",title="Technical IDs: creatures"},
    }},
}
function U:Toggle(key)
    local p=I.Storage.account and I.Storage.account.preferences
    if not p then return false end
    local current=p[key]
    if key=="tooltip" then current=p.tooltip==true and p.tooltipPresentation~="NATIVE" end
    local value=not current
    if key=="showMarketTooltip" and value then I.API:SetPreference("marketProvider","Wealthcraft") end
    if key=="tooltip" and value then
        I.API:SetPreference("tooltipPresentation","AUTO");I.API:SetPreference("skinTooltips",true)
    end
    local ok,why=I.API:SetPreference(key,value)
    self:Update();return ok,why
end
function U:ClearRecordedRecipes()
    if not self.frame or not self.frame:IsShown() or self.section~="Advanced" or I:Combat() or I.Storage.readOnly then return false end
    local character=I.Storage.character
    if type(character)~="table" then return false end
    local count=0;for _ in pairs(character.recipes or {}) do count=count+1 end
    if not self.confirmRecipes or self.confirmRecipes.character~=character or self.confirmRecipes.revision~=character.revision then
        self.confirmRecipes={character=character,revision=character.revision}
        self.recipeNotice="Clear "..count.." recorded recipes from this character? Click again to confirm."
        self:Update();return false
    end
    local expected=self.confirmRecipes;self.confirmRecipes=nil
    local ok,why=I.API:ClearRecordedRecipes(expected.character,expected.revision)
    self.recipeNotice=why;self:Update();return ok
end
function U:Create()
    if self.frame then return true end
    if not UIParent or I:Combat() or type(CreateFrame)~="function" then return false end
    local f=CreateFrame("Frame","MirageIntelInsightPanel",UIParent,"BackdropTemplate")
    f:SetSize(600,390);f:SetPoint("CENTER",UIParent,"CENTER",0,20)
    f:SetFrameStrata("DIALOG");f:SetClampedToScreen(true);f:EnableMouse(true);f:SetMovable(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart",function(self)if not I:Combat() then self:StartMoving() end end)
    f:SetScript("OnDragStop",function(self)self:StopMovingOrSizing()end)
    local c=chrome()
    if c then c.Panel(f) else
        f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8x8",edgeFile="Interface\\Buttons\\WHITE8x8",edgeSize=1})
        f:SetBackdropColor(.060,.060,.065,.97);f:SetBackdropBorderColor(.26,.26,.26,1)
    end
    local title=label(f,"Insight",20,-18,420,"title")
    if c and c.Heading then c.Heading(f,title,20,-18,"insight") end
    button(f,"Close",508,-15,72,function()f:Hide()end)
    local sub=label(f,"Tooltips & professions",20,-49,540,"small")
    if c then c.Tint(sub,"muted") end
    self.pages={};self.tabs={};self.section=self.section or "Appearance"
    for index,group in ipairs(groups) do
        local section=group.title
        self.tabs[section]=button(f,section,20+(index-1)*112,-78,106,function()
            U.section=section;U.confirmRecipes=nil;U.recipeNotice=nil;U:Update()
        end)
        local pane=CreateFrame("Frame",nil,f);pane:SetPoint("TOPLEFT",f,"TOPLEFT",0,-122);pane:SetSize(600,224)
        self.pages[section]=pane
        local y=0
        for _,entry in ipairs(group.rows) do
            label(pane,entry.title,24,-y,440,"body")
            if entry.hint then
                local hint=label(pane,entry.hint,24,-y-21,440,"small")
                if c then c.Tint(hint,"muted") end
            end
            if entry.key=="tooltipTextSize" then
                local value=label(pane,"",478,-y-3,44,"body")
                self.sizeDown=button(pane,"−",446,-y,27,function()
                    local p=I.Storage.account and I.Storage.account.preferences
                    if p then I.API:SetPreference("tooltipTextSize",math.max(10,(p.tooltipTextSize or 12)-1)) end
                end)
                self.sizeUp=button(pane,"+",544,-y,27,function()
                    local p=I.Storage.account and I.Storage.account.preferences
                    if p then I.API:SetPreference("tooltipTextSize",math.min(16,(p.tooltipTextSize or 12)+1)) end
                end)
                self.sizeValue=value
            else
                local key=entry.key
                self.controls[key]=button(pane,"",500,-y,72,function()U:Toggle(key)end)
            end
            y=y+(entry.hint and 65 or 43)
        end
        if section=="Advanced" then
            self.clearRecipes=button(pane,"Clear recorded recipes",24,-170,260,function()U:ClearRecordedRecipes()end)
            self.recipeStatus=label(pane,"",24,-203,548,"small")
            if c then c.Tint(self.recipeStatus,"muted") end
        elseif section=="Appearance" then
            self.presentationStatus=label(pane,"",24,-y-8,548,"small")
            if c then c.Tint(self.presentationStatus,"muted") end
            self.coreSettings=button(pane,"Tooltip placement & scale",24,-188,260,function()
                local suite=_G.MirageUI
                if suite and type(suite.LoadOptions)=="function" then
                    suite:LoadOptions(true)
                    if suite.Workspace and suite.Workspace.Open then suite.Workspace:Open("Modules","Tooltips") end
                end
            end)
        end
    end
    local foot=label(f,"Changes save immediately.",24,-363,530,"small")
    if c then c.Tint(foot,"muted");c.Watch(f) end
    f:SetScript("OnShow",function()U:Update()end)
    f:SetScript("OnHide",function()U.confirmRecipes=nil;U.recipeNotice=nil end)
    f:Hide();self.frame=f;return true
end
function U:Update()
    if not self.frame then return end
    local p=I.Storage.account and I.Storage.account.preferences or {}
    local enabled=p.tooltip==true and p.tooltipPresentation~="NATIVE"
    local c=chrome()
    for section,pane in pairs(self.pages or {}) do
        if section==self.section then pane:Show() else pane:Hide() end
        if c then c.Active(self.tabs[section],section==self.section) end
    end
    if self.coreSettings then if type(_G.MirageUI)=="table" then self.coreSettings:Show() else self.coreSettings:Hide() end end
    if self.confirmRecipes and (I.Storage.character~=self.confirmRecipes.character or I.Storage.character.revision~=self.confirmRecipes.revision) then
        self.confirmRecipes=nil;self.recipeNotice="Recipe history changed. Review it again before clearing."
    end
    if self.clearRecipes then self.clearRecipes:SetEnabled(not I.Storage.readOnly and not I:Combat()) end
    if self.recipeStatus then self.recipeStatus:SetText(self.recipeNotice or "Recording resumes on the next profession opening when enabled.") end
    if self.presentationStatus then
        local core=I.Tooltip and I.Tooltip.CoreAllows and I.Tooltip:CoreAllows()
        self.presentationStatus:SetText(not enabled and "Insight tooltip presentation is off." or core==false and
            "MirageUI tooltip presentation is off. Enable it in Displays to show Insight details." or
            "Placement and whole-tooltip scale are managed by MirageUI Displays when installed.")
    end

    for key,b in pairs(self.controls) do
        local active=key=="tooltip" and enabled or key~="tooltip" and p[key]==true
        b:SetText(active and "On" or "Off")
        local c=chrome();if c and c.Active then c.Active(b,active) end
        local editable=not I.Storage.readOnly and (key=="tooltip" or key=="autoScan" or enabled)
        if key=="professionDetails" then editable=editable and p.showRecipes~=false end
        if b.SetEnabled then b:SetEnabled(editable) end
    end
    local size=p.tooltipTextSize or 12
    if self.sizeValue then self.sizeValue:SetText(tostring(size)) end
    if self.sizeDown and self.sizeDown.SetEnabled then self.sizeDown:SetEnabled(not I.Storage.readOnly and enabled and size>10) end
    if self.sizeUp and self.sizeUp.SetEnabled then self.sizeUp:SetEnabled(not I.Storage.readOnly and enabled and size<16) end
end
function U:Open()
    if I:Combat() then return false,"Open Insight after combat." end
    if not self:Create() then return false,"Insight settings are unavailable." end
    local c=chrome();if c and c.Fit and not c.Fit(self.frame) then return false,"There is not enough space for settings." end
    self:Update();self.frame:Show();return true
end
function U:OpenSettings() return self:Open() end
function U:SourceChanged() end
function U:ItemDataLoaded() end
function U:GetStatus()
    return {view="SETTINGS",visible=self.frame and self.frame:IsShown() or false,dataBrowser=false}
end
