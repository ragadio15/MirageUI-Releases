-- Insight integrates into the actual Blizzard tooltip. Native facts,
-- comparisons, anchors, owner, status bars and input handlers remain intact.
local _,I=...
I.TooltipCard={cards={},maxCards=6,maxRows=14,status="READY"}
local C=I.TooltipCard
local unpack=unpack or table.unpack
local colors={text={.90,.89,.87},muted={.63,.62,.60},accent={.96,.79,.36},
    warning={.91,.55,.18},market={.96,.79,.36},good={.70,.86,.72}}
local function call(object,name,...)
    if not object or not I:Readable(object) then return nil,false end
    local ok,fn=pcall(function()return object[name]end)
    if not ok then return nil,false end
    return I:Call(fn,object,...)
end
local function shown(frame)
    local value,ok=call(frame,"IsShown");return ok and value==true
end
local function allowed(native)
    if not native then return false end
    local forbidden,ok=call(native,"IsForbidden")
    if ok and forbidden then return false end
    local protected,known=call(native,"IsProtected")
    if known and protected and I:Combat() then return false end
    return true
end
local function fontSet(card,line,size)
    if not line or type(line.SetFont)~="function" then return end
    local path,ok,current,flags=call(line,"GetFont")
    if not ok or not I:Text(path,300) or not I:Number(current) then return end
    card.fonts=card.fonts or setmetatable({},{__mode="k"})
    if not card.fonts[line] then card.fonts[line]={path,current,flags or ""} end
    local saved=card.fonts[line]
    saved.writtenPath=path;saved.writtenSize=size;saved.writtenFlags=I:Text(flags,30) or ""
    if current~=size then
        local _,changed=call(line,"SetFont",path,size,I:Text(flags,30) or "")
        if changed then card.layoutDirty=true end
    end
end
local function sameText(line,value)
    local text,ok=call(line,"GetText")
    return ok and (text==value or (value==nil or value=="") and (text==nil or text==""))
end
local function ownsRow(line)
    return line.left and sameText(line.left,line.leftText) and
        (not line.rightOwned or line.right and sameText(line.right,line.rightText))
end
local function doubleRow(row)
    -- Long profession lists and crafting descriptions use the wrapping column.
    return row.section~="recipe_details" and row.section~="locations" and
        I:Text(row.label,100) and I:Text(row.value,96) and true or false
end
local background={.025,.027,.033,.98}
local border={.35,.29,.17,1}
local transparent={0,0,0,0}
local titleIcon="|TInterface\\AddOns\\MirageIntel_Insight\\Media\\Badge.tga:14:14:0:0|t "
local function colorMatches(object,method,color)
    local r,ok,g,b,a=call(object,method)
    return ok and I:Number(r) and I:Number(g) and I:Number(b) and I:Number(a) and
        math.abs(r-color[1])<.00001 and math.abs(g-color[2])<.00001 and
        math.abs(b-color[3])<.00001 and math.abs(a-color[4])<.00001
end
local function nativeLifetime(native)
    local data,ok=call(native,"GetPrimaryTooltipData")
    if not ok or data==nil then
        local epochs=I.Tooltip and I.Tooltip.surfaceEpochs
        local epoch=epochs and epochs[native]
        if epoch then return {native=native,instance=epoch,legacy=true} end
        return nil
    end
    if not I:Readable(data) or type(data)~="table" then return nil end
    local instance,read=I:Call(function()return data.dataInstanceID end)
    if not read or not (I:Number(instance) or I:Text(instance,100)) then instance=nil end
    return {native=native,data=data,instance=instance}
end
local function sameLifetime(a,b)
    return a and b and a.native==b.native and a.legacy==b.legacy and
        (a.instance~=nil and b.instance~=nil and a.instance==b.instance or
         a.instance==nil and b.instance==nil and a.data==b.data)
end
function C:Create(index)
    if not I:Integer(index) or index>self.maxCards then return nil end
    if not self.cards[index] then self.cards[index]={index=index,lines={}} end
    return self.cards[index]
end
function C:Initialize()
    -- Lightweight state pools only. No detached window or per-item frame.
    for index=1,self.maxCards do self:Create(index) end
end
function C:RestoreStyle(card)
    card.restoring=true
    if card.skin and shown(card.skin) then card.skin:Hide() end
    if card.nine and card.nineAlpha~=nil then
        local alpha=call(card.nine,"GetAlpha")
        if alpha==0 and alpha~=card.nineAlpha then call(card.nine,"SetAlpha",card.nineAlpha) end
    end
    if card.native and card.backdrop then
        if colorMatches(card.native,"GetBackdropColor",transparent) then call(card.native,"SetBackdropColor",unpack(card.backdrop)) end
        if colorMatches(card.native,"GetBackdropBorderColor",transparent) then call(card.native,"SetBackdropBorderColor",unpack(card.border)) end
    end
    for line,original in pairs(card.fonts or {}) do
        local path,ok,size,flags=call(line,"GetFont")
        if ok and path==original.writtenPath and size==original.writtenSize and (flags or "")==original.writtenFlags and
            (path~=original[1] or size~=original[2] or (flags or "")~=original[3]) then
            call(line,"SetFont",unpack(original));card.layoutDirty=true
        end
    end
    local title=card.title
    if title and sameText(title.line,title.written) then
        call(title.line,"SetText",title.original);card.layoutDirty=true
    end
    for object,entry in pairs(card.art or {}) do
        if call(object,"GetAlpha")==0 then call(object,"SetAlpha",entry) end
    end
    if card.health then
        local texture=call(card.health.bar,"GetStatusBarTexture")
        if texture and call(texture,"GetTexture")=="Interface\\Buttons\\WHITE8x8" then
            call(card.health.bar,"SetStatusBarTexture",card.health.texture)
        end
    end
    card.title=nil;card.art=nil;card.health=nil
    card.nine=nil;card.nineAlpha=nil;card.backdrop=nil;card.border=nil;card.fonts=nil;card.fontStamp=nil
    card.restoring=nil
end
function C:ApplyStyle(card)
    local native=card.native
    if not allowed(native) or not card.pref then return false end
    if card.pref.skinTooltips==false then self:RestoreStyle(card);return true end
    if card.styling then return true end
    card.styling=true
    if card.skin and card.skinParent~=native then
        -- Native tooltip globals can be replaced by another presentation owner.
        -- Move only our passive skin; never reparent the native tooltip itself.
        local _,moved=call(card.skin,"SetParent",native)
        if not moved then card.skin:Hide();card.skin=nil end
        if moved then
            call(card.skin,"ClearAllPoints")
            card.skin:SetPoint("TOPLEFT",native,"TOPLEFT",0,0)
            card.skin:SetPoint("BOTTOMRIGHT",native,"BOTTOMRIGHT",0,0)
            card.skinParent=native
        end
    end
    if not card.skin and type(CreateFrame)=="function" then
        local ok,skin=pcall(CreateFrame,"Frame",nil,native,"BackdropTemplate")
        if not ok or not skin then card.styling=nil;return false end
        skin:EnableMouse(false)
        skin:SetPoint("TOPLEFT",native,"TOPLEFT",0,0);skin:SetPoint("BOTTOMRIGHT",native,"BOTTOMRIGHT",0,0)
        if type(skin.SetBackdrop)=="function" then
            skin:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8x8",edgeFile="Interface\\Buttons\\WHITE8x8",edgeSize=1})
            skin:SetBackdropColor(unpack(background));skin:SetBackdropBorderColor(unpack(border))
        end
        local edge=skin:CreateTexture(nil,"BORDER")
        edge:SetTexture("Interface\\Buttons\\WHITE8x8")
        edge:SetPoint("TOPLEFT",skin,"TOPLEFT",1,-1);edge:SetPoint("TOPRIGHT",skin,"TOPRIGHT",-1,-1)
        -- One quiet keyline identifies the card. The title stays on the same
        -- neutral surface as its facts: short reagent and unit tips must not
        -- acquire a full-height colored banner or extra vertical padding.
        edge:SetHeight(1);edge:SetVertexColor(.86,.63,.30,.62)
        card.header=edge
        card.skin=skin;card.skinParent=native
    end
    -- Match the current native layer at Show/content boundaries. Tooltips may
    -- move strata/level when a native panel opens, even without replacement.
    -- The passive background remains beneath native text and status bars.
    if card.skin then
        local level=call(native,"GetFrameLevel")
        if I:Number(level) then
            level=math.max(0,level-1)
            if call(card.skin,"GetFrameLevel")~=level then call(card.skin,"SetFrameLevel",level) end
        end
        local strata=call(native,"GetFrameStrata")
        if I:Text(strata,40) and call(card.skin,"GetFrameStrata")~=strata then call(card.skin,"SetFrameStrata",strata) end
    end
    local nine=native.NineSlice
    if nine and type(nine.SetAlpha)=="function" then
        if card.nine~=nine then
            if card.nine and card.nineAlpha~=nil and call(card.nine,"GetAlpha")==0 then
                call(card.nine,"SetAlpha",card.nineAlpha)
            end
            card.nine=nine;card.nineAlpha=nil
        end
        if card.nineAlpha==nil then
            local alpha,ok=call(nine,"GetAlpha")
            if ok and I:Number(alpha) then card.nineAlpha=alpha end
        end
        if card.nineAlpha~=nil then
            if call(nine,"GetAlpha")~=0 then call(nine,"SetAlpha",0) end
            card.nine=nine
        end
    elseif type(native.SetBackdropColor)=="function" then
        if not card.backdrop then
            local r,ok,g,b,a=call(native,"GetBackdropColor")
            local er,eok,eg,eb,ea=call(native,"GetBackdropBorderColor")
            if ok and eok and I:Number(r) and I:Number(g) and I:Number(b) and I:Number(a) and
                I:Number(er) and I:Number(eg) and I:Number(eb) and I:Number(ea) then
                card.backdrop={r,g,b,a};card.border={er,eg,eb,ea}
            end
        end
        if card.backdrop then
            -- The authored skin sits beneath the native text frame. A legacy
            -- opaque backdrop would otherwise cover the new header and body.
            if not colorMatches(native,"GetBackdropColor",transparent) then call(native,"SetBackdropColor",unpack(transparent)) end
            if not colorMatches(native,"GetBackdropBorderColor",transparent) then call(native,"SetBackdropBorderColor",unpack(transparent)) end
        end
    end
    if card.skin and not shown(card.skin) then card.skin:Show() end
    local count,ok=call(native,"NumLines")
    local name=call(native,"GetName")
    if ok and I:Number(count) and I:Text(name,120) then
        local size=math.max(10,math.min(16,card.pref.tooltipTextSize or 12))
        -- Use the engine's measured title line: an inline official badge grows
        -- the real tooltip width and comparison envelope with the title. No
        -- detached overlay can collide with a long item or player name.
        local line=_G[name.."TextLeft1"] or native.TextLeft1
        local text,textOK=call(line,"GetText")
        if textOK and I:Text(text,2000) then
            if not card.title or card.title.line~=line or text~=card.title.written then
                local original=text
                if text:sub(1,#titleIcon)==titleIcon then original=text:sub(#titleIcon+1) end
                card.title={line=line,original=original,written=titleIcon..original}
            end
            if text~=card.title.written then call(line,"SetText",card.title.written);card.layoutDirty=true end
        end
        local stamp=tostring(count)..":"..size
        if card.fontStamp~=stamp then
            for n=1,math.min(count,100) do
                fontSet(card,_G[name.."TextLeft"..n],n==1 and size+1 or size)
                fontSet(card,_G[name.."TextRight"..n],size)
            end
            card.fontStamp=stamp
        end
    end
    -- The named health bar remains the game's live value source; only its
    -- decorative texture is replaced. Never hide health, money, comparison
    -- labels or inserted profession/item content.
    if native==_G.GameTooltip then
        local health=_G.GameTooltipStatusBar or native.StatusBar
        if health and allowed(health) then
            local texture=call(health,"GetStatusBarTexture")
            local path=texture and call(texture,"GetTexture")
            if I:Text(path,300) and path~="Interface\\Buttons\\WHITE8x8" then
                card.health={bar=health,texture=path};call(health,"SetStatusBarTexture","Interface\\Buttons\\WHITE8x8")
            end
            local regions,read=I:Call(function()return {health:GetRegions()}end)
            if read and type(regions)=="table" then
                for n=1,math.min(#regions,24) do
                    local region=regions[n]
                    if call(region,"GetTexture")=="Interface\\Tooltips\\UI-StatusBar-Border" then
                        local alpha,known=call(region,"GetAlpha")
                        if known and I:Number(alpha) then
                            card.art=card.art or {};if card.art[region]==nil then card.art[region]=alpha end
                            if alpha~=0 then call(region,"SetAlpha",0) end
                        end
                    end
                end
            end
        end
    end
    card.styling=nil
    card.stylePasses=(card.stylePasses or 0)+1
    self.status="INTEGRATED_TOOLTIP_READY"
    return true
end
function C:Style(card)
    local ok,result=pcall(self.ApplyStyle,self,card)
    if card then card.styling=nil end
    if not ok or result~=true then
        self.styleFailures=(self.styleFailures or 0)+1;self.status="TOOLTIP_STYLE_UNAVAILABLE"
        return false
    end
    return true
end
function C:IsRefreshing(native)
    for _,card in ipairs(self.cards) do
        if card.native==native and (card.refreshing or card.styling or card.restoring) then return true end
    end
    return false
end
function C:RefreshLayout(card)
    if not card or not card.layoutDirty or card.refreshing or not allowed(card.native) or not shown(card.native) then return false end
    if I.Tooltip and I.Tooltip.IsFading and I.Tooltip:IsFading(card.native) then return false end
    -- GameTooltip lays out appended or changed lines on Show. This is a refresh
    -- of an already shown surface only; the native handler owns its first Show.
    card.refreshing=true
    local _,ok=call(card.native,"Show")
    card.refreshing=false
    if ok then card.layoutDirty=false end
    return ok
end
local function append(card,row)
    local tip=card.native
    local count,ok=call(tip,"NumLines")
    if not ok or not I:Number(count) or count<0 or count>100 then return false end
    local name=call(tip,"GetName")
    if not I:Text(name,120) then return false end
    local color=colors[row.role] or colors.text
    local double=doubleRow(row) and type(tip.AddDoubleLine)=="function"
    local written
    if double then
        local _,success=call(tip,"AddDoubleLine",row.label,row.value,.63,.62,.60,color[1],color[2],color[3])
        written=success
    else
        local _,success=call(tip,"AddLine",row.text,color[1],color[2],color[3],true)
        written=success
    end
    if not written then return false end
    local left,right=_G[name.."TextLeft"..(count+1)],_G[name.."TextRight"..(count+1)]
    card.lines[#card.lines+1]={left=left,right=right,leftText=double and row.label or row.text,
        rightText=double and row.value or nil,double=double,rightOwned=double,role=row.role,wrapped=not double}
    card.layoutDirty=true
    return true
end
function C:Prepare(index,native,model,pref,source)
    local card=self:Create(index)
    if not card or not allowed(native) or type(model)~="table" or type(model.rows)~="table" then
        return false,"TOOLTIP_UNAVAILABLE"
    end
    if card.cleanupPending and not self:Hide(index,card.pendingCleared,card.pendingSuppress) then
        return false,"TOOLTIP_CLEANUP_PENDING"
    end
    if card.native and card.native~=native and not self:Hide(index) then return false,"TOOLTIP_CLEANUP_PENDING" end
    card.native=native;card.model=model;card.pref=pref
    if card.retired then
        local reusable=#card.lines==0 and sameLifetime(card.retired.lifetime,nativeLifetime(native))
        for _,line in ipairs(card.retired.lines) do if not ownsRow(line) then reusable=false;break end end
        if reusable then card.lines=card.retired.lines end
        card.retired=nil
    end
    -- A reused or foreign-edited row ends our ownership of this lifetime. Do
    -- not overwrite either column or abandon the other owned rows and append.
    for _,line in ipairs(card.lines) do
        if not ownsRow(line) then return false,"TOOLTIP_ROWS_REPLACED" end
    end
    local count=math.min(#model.rows,self.maxRows)
    local all=true
    for n=1,math.max(count,#card.lines) do
        local row=model.rows[n];local existing=card.lines[n]
        if n<=count and row and I:Text(row.text,800) then
            if existing and existing.left then
                local double=existing.double and doubleRow(row)
                local left=double and row.label or row.text
                local right=double and row.value or nil
                local color=colors[row.role] or colors.text
                if existing.leftText~=left or existing.rightText~=right then card.layoutDirty=true end
                if existing.leftText~=left then call(existing.left,"SetText",left) end
                if not shown(existing.left) then call(existing.left,"Show") end
                if existing.role~=row.role or existing.wrapped~=not double then
                    call(existing.left,"SetTextColor",double and .63 or color[1],double and .62 or color[2],double and .60 or color[3])
                end
                if existing.wrapped~=not double then call(existing.left,"SetWordWrap",not double);existing.wrapped=not double end
                if existing.rightOwned and existing.right then
                    if not sameText(existing.right,right) then call(existing.right,"SetText",right or "") end
                    if right then
                        if existing.role~=row.role then call(existing.right,"SetTextColor",color[1],color[2],color[3]) end
                        if not shown(existing.right) then call(existing.right,"Show") end
                    elseif shown(existing.right) then call(existing.right,"Hide") end
                end
                existing.leftText=left;existing.rightText=right;existing.role=row.role
            elseif not existing then
                if not append(card,row) then all=false;break end
            end
        elseif existing then
            if existing.leftText~="" or (existing.rightText and existing.rightText~="") then card.layoutDirty=true end
            if existing.left and existing.leftText~="" then call(existing.left,"SetText","");call(existing.left,"Hide");existing.leftText="" end
            if existing.rightOwned and existing.right and existing.rightText~="" then call(existing.right,"SetText","");call(existing.right,"Hide");existing.rightText="" end
        end
    end
    if not self:Style(card) then return false,"TOOLTIP_STYLE_UNAVAILABLE" end
    -- A postcall is already inside the native layout pass, which ends in Show.
    if source=="NATIVE_POSTCALL" then card.layoutDirty=false
    else self:RefreshLayout(card) end
    return all,all and "READY" or "TOOLTIP_ROWS_UNAVAILABLE",all
end
function C:Show(index)
    local card=self.cards[index]
    if not card or not card.native or not shown(card.native) then return false end
    if not self:Style(card) then return false,"TOOLTIP_STYLE_UNAVAILABLE" end
    self:RefreshLayout(card);return true
end
function C:Present(index,native,pref)
    local card=self:Create(index)
    if not card or not allowed(native) then return false,"TOOLTIP_UNAVAILABLE" end
    if card.native and card.native~=native and not self:Hide(index) then return false,"TOOLTIP_CLEANUP_PENDING" end
    card.native=native;card.pref=pref
    if not self:Style(card) then return false,"TOOLTIP_STYLE_UNAVAILABLE" end
    self:RefreshLayout(card)
    return true,"MIRAGE_SURFACE_READY"
end
function C:Tick(index)
    local card=self.cards[index]
    if not card or not card.native or not shown(card.native) then return false end
    if not allowed(card.native) then self:Hide(index);return false,"TOOLTIP_CLEANUP_PENDING" end
    -- Content/native Show boundaries own styling. Idle hovers only validate
    -- lifecycle and finish an outstanding layout; they do not repaint frames.
    self:RefreshLayout(card);return true
end
function C:Hide(index,cleared,suppressRefresh)
    local card=self.cards[index]
    if not card then return true end
    if cleared then card.retired=nil end
    if card.native and not allowed(card.native) then
        -- A tooltip can become restricted after preparation. Retain the exact
        -- cleanup journal until public access returns; never write through it.
        card.cleanupPending=true
        card.pendingCleared=card.pendingCleared or cleared
        card.pendingSuppress=card.pendingSuppress or suppressRefresh
        if card.skin then card.skin:Hide() end
        return false
    end
    local retired={}
    if not cleared then
        for _,line in ipairs(card.lines or {}) do
            if ownsRow(line) then
                if line.leftText~="" then call(line.left,"SetText","");call(line.left,"Hide");card.layoutDirty=true end
                if line.rightOwned and line.right and line.rightText~="" then call(line.right,"SetText","");call(line.right,"Hide");card.layoutDirty=true end
                line.leftText="";line.rightText=line.rightOwned and "" or nil
                retired[#retired+1]=line
            end
        end
        if card.native and #retired>0 then
            local lifetime=nativeLifetime(card.native)
            if lifetime then card.retired={lines=retired,lifetime=lifetime} end
        end
    end
    self:RestoreStyle(card)
    if not cleared and not suppressRefresh then self:RefreshLayout(card) end
    card.lines={};card.model=nil;card.native=nil;card.pref=nil
    card.layoutDirty=nil;card.refreshing=nil
    card.cleanupPending=nil;card.pendingCleared=nil;card.pendingSuppress=nil
    return true
end
function C:DrainCleanup()
    for index,card in ipairs(self.cards) do
        if card.cleanupPending and allowed(card.native) then self:Hide(index,card.pendingCleared,card.pendingSuppress) end
    end
end
function C:HideAll()
    for index=1,self.maxCards do self:Hide(index) end
end
function C:Status()
    local visible=0
    for _,card in ipairs(self.cards) do if card.native and shown(card.native) then visible=visible+1 end end
    return {status=self.status,allocated=#self.cards,visible=visible,maximum=self.maxCards,
        styleFailures=self.styleFailures or 0,presentation="MIRAGE_AUTHORED_TOOLTIP",nativeBody="RETAINED",nativeComparison="RETAINED",nativeInput="UNMODIFIED"}
end
