-- MirageUI: original suite coordinator. Native gameplay controls are never owned globally.
local addonName, M = ...
_G.MirageUI = M
M.name, M.version, M.schema = addonName, "1.0.43-rc.12", 1
M.modules, M.surfaces, M.services = {}, {}, {}
M.state = { initialized=false, safe=false, world=false, edit=false, revision=0 }
M.stats = { batches=0, evaluations=0, effects=0, denied=0, faults=0 }
M.faults, M.samples = {}, {}
M.cleanupModules = {}
M.order = {}
M.ownedRoots = {}

-- Session-only authored evidence. Native errors and event/gameplay values never
-- enter this journal. Keep it private so a consumer cannot rewrite history by
-- editing a diagnostic snapshot, and bound both attempts and cleanup work.
local function enums(words)
    local values={};for word in words:gmatch("%S+") do values[word]=word end;return values
end
local triggers=enums("PROFILE PROFILE_COMMIT SETUP PROFILE_ROLLBACK RECOVER CANDIDATE_OPT_IN WORLD_ENTERED COMBAT_ENDED OWNER_CHANGED RESIZE")
local phases=enums("PRECHECK RECOVERY_RESET NATIVE_RELEASE ADAPTIVE_LAYOUT TYPOGRAPHY_BEGIN POLICY MODULE_INITIALIZE MODULE_RESUME MODULE_CONFIG MODULE_SUSPEND MODULE_CLEANUP THEME FONTS LAYOUT EVENTS SIGNALS PRESENTATION CVE MANAGED_CONFIGURE RESOURCE_PREFERENCE TYPOGRAPHY_END COMPLETE")
local results=enums("NOT_RUN RUNNING COMPLETE FAILED DEFERRED BLOCKED STOPPED")
local categories=enums("NONE PROFILE_APPLY_FAILED FINALIZE_FAILED OWNERSHIP_CHANGED RECOVERY_RESET_FAILED")
local reasons=enums("USER_REQUEST USER_BINDING USER_SETTINGS SAVED_SAFE_MODE CORE_FAULT NATIVE_ACTION_BLOCKED FOREVER_CANDIDATE_DISABLED")
local cleanupReasons=enums("COMBAT_LOCKDOWN FRAME_UNAVAILABLE OWNERSHIP_CHANGED STOP_UNCONFIRMED CALLBACK_UNAVAILABLE NATIVE_RELEASE_PENDING CALLBACK_FAILED PROFILE_BUSY")
local moduleNames=enums("Core Cursor Minimap Chat Tooltips QuestTracker UnitFrames Nameplates ActionBars UnderCharacterHUD ResourceBars Auras Cooldowns PartyRaid BlizzardSkin Bags DataBars DamageMeters PvP TacticalSignals Preparations Notifications")
local function authored(values,value,fallback)
    local ok,result=pcall(function() return values[value] end)
    return ok and result or fallback
end
local runtime={serial=0,history={},lastSuccessfulApply=0,cleanupSerial=0}
local applyingAttempt,applyRow,cleanupRequest,cleanupRunning
local rootCustody={}
local function applyCopy(row)
    if not row then return nil end
    return {id=row.id,parent=row.parent,trigger=row.trigger,phase=row.phase,module=row.module,result=row.result,category=row.category}
end
function M:BeginApplyAttempt(trigger,parent)
    if applyingAttempt then return nil end
    runtime.serial=math.min(runtime.serial+1,2147483647)
    local parentID=0
    for _,old in ipairs(runtime.history) do if rawequal(parent,old.id) then parentID=old.id;break end end
    local row={id=runtime.serial,parent=parentID,trigger=authored(triggers,trigger,"PROFILE"),phase="PRECHECK",module="Core",result="RUNNING",category="NONE"}
    runtime.history[#runtime.history+1]=row
    if #runtime.history>8 then table.remove(runtime.history,1) end
    runtime.apply=row;applyRow=row;applyingAttempt={}
    return applyingAttempt
end
function M:ApplyPhase(attempt,phase,module)
    if not rawequal(applyingAttempt,attempt) then return false end
    applyRow.phase=authored(phases,phase,"PRECHECK");applyRow.module=authored(moduleNames,module,"Core")
    return true
end
function M:RecordApplyFailure(attempt,category)
    if not rawequal(applyingAttempt,attempt) then return false end
    applyRow.category=authored(categories,category,"PROFILE_APPLY_FAILED")
    local failure=applyCopy(applyRow);failure.result="FAILED"
    runtime.firstFailure=runtime.firstFailure or failure;runtime.lastFailure=failure
    return true
end
function M:FinishApplyAttempt(attempt,result,category)
    if not rawequal(applyingAttempt,attempt) then return false end
    local row=applyRow
    row.result=authored(results,result,"FAILED");row.category=authored(categories,category,"NONE")
    if row.result=="COMPLETE" then
        runtime.lastSuccessfulApply=row.id
        if not self.state.safe and not self.state.safeCleanupPending then runtime.safeReason=nil;self.state.safeReason=nil end
    end
    if row.result=="FAILED" then self:RecordApplyFailure(attempt,row.category) end
    applyingAttempt=nil;applyRow=nil
    return row.id
end
function M:RestoreSafeIntent()
    if self.state.safe and self.db and self.db.safe==true then
        local saved=self.Incidents and self.Incidents:StopReason()
        runtime.safeReason=authored(reasons,saved,"SAVED_SAFE_MODE");self.state.safeReason=runtime.safeReason
        runtime.safeReasonScope=self.Incidents and self.Incidents.StopScope and self.Incidents:StopScope() or "PERSISTED_RECORD"
        if self.Incidents and self.Incidents.HistoricalNativeStop and self.Incidents:HistoricalNativeStop() then
            runtime.historicalNativeResume="PENDING"
        elseif self.Incidents and self.Incidents.HistoricalPatchedStop and self.Incidents:HistoricalPatchedStop() then
            runtime.historicalPatchedResume="PENDING";runtime.historicalPatch="P19_KEY_LABEL_FONT_ORDER"
        end
    end
end
-- Retain the established startup entrypoint for the two separately qualified
-- repairs: historical native-action stops, and the exact P19 font-order layout
-- stop fixed in P20. Their evidence and reporting remain distinct. A previous
-- process owns no live leases; current faults, pauses and cleanup still veto.
function M:ResumeHistoricalNativeStop()
    local field,proof,reason,receipt
    if runtime.historicalNativeResume=="PENDING" or runtime.historicalNativeResume=="WAITING_COMBAT" then
        field,proof,reason,receipt="historicalNativeResume","HistoricalNativeStop","NATIVE_ACTION_BLOCKED","HISTORICAL_NATIVE_STOP_RETIRED"
    elseif runtime.historicalPatchedResume=="PENDING" or runtime.historicalPatchedResume=="WAITING_COMBAT" then
        field,proof,reason,receipt="historicalPatchedResume","HistoricalPatchedStop","CORE_FAULT","P19_KEY_LABEL_STOP_RETIRED"
    else return false end
    local state,db,profiles,client,journal,profile=self.state,self.db,self.Profiles,self.Client,self.Incidents,self.profile
    local function intentOwned()
        return self.state==state and self.db==db and self.Profiles==profiles and self.Client==client
            and self.Incidents==journal and self.profile==profile and state.safe and db and db.safe==true
            and runtime.safeReason==reason and not state.safeCleanupPending and not cleanupRequest
            and client.allowed and not profiles.readOnly and profile and profile.enabled
            and not (self.Rework and (self.Rework.nativeBlocksThisSession or 0)>0)
    end
    local function startupHistory()
        -- An active or failed activation belongs to this process. A stopped
        -- startup and a combat-deferred world precheck carry no failure debt.
        for _,row in ipairs(runtime.history) do
            local waitingStartup=row.result=="DEFERRED" and row.trigger=="WORLD_ENTERED"
                and row.phase=="PRECHECK" and row.category=="NONE"
            if row.result~="STOPPED" and not waitingStartup then return false end
        end
        return true
    end
    local function eligible()
        if not intentOwned() or not startupHistory() or not journal or type(journal[proof])~="function" then return false end
        local proven=journal[proof](journal)
        -- The proof observes readability through native APIs. Recheck roots,
        -- intent and current attempts after it, with no intervening callbacks.
        return proven and intentOwned() and startupHistory()
    end
    if not eligible() then
        runtime[field]="CANCELLED";return false
    end
    if self.Safety:InCombat() then runtime[field]="WAITING_COMBAT";return false end
    -- Native observation can dispatch callbacks. Recheck the candidate and its
    -- ownership immediately before the data-only saved-intent write.
    if not eligible() then runtime[field]="CANCELLED";return false end
    local ok,written=pcall(profiles.WriteSafeIntent,profiles,false)
    if not ok or written~=true or self.state~=state or self.db~=db or self.Profiles~=profiles or self.Client~=client
        or self.Incidents~=journal or self.profile~=profile or db.safe~=false or journal:StopReason()~=nil
        or runtime.safeReason~=reason or state.safeCleanupPending then
        runtime[field]="WRITE_BLOCKED";return false
    end
    state.safe=false;state.safeReason=nil;runtime.safeReason=nil;runtime.safeReasonScope=nil
    runtime[field]="RESUMED"
    journal:Record("RECOVERY","Core","STARTUP",receipt)
    return true
end
function M:RuntimeSnapshot()
    local history={};for i,row in ipairs(runtime.history) do history[i]=applyCopy(row) end
    local cleanup={id=0,status="NOT_RUN",reason="NONE",phase="NONE",requested=0,completed=0,pending=0,blocked=0,attempts=0,steps={}}
    local r=cleanupRequest
    if r then
        cleanup.id=r.id;cleanup.status=r.status;cleanup.reason=r.reason;cleanup.phase=r.phase
        cleanup.requested=#r.steps;cleanup.attempts=r.attempts
        for i,step in ipairs(r.steps) do
            cleanup.steps[i]={id=step.id,status=step.status,reason=step.reason,attempts=step.attempts}
            if step.status=="COMPLETE" then cleanup.completed=cleanup.completed+1
            elseif step.status=="BLOCKED" then cleanup.blocked=cleanup.blocked+1
            else cleanup.pending=cleanup.pending+1 end
        end
    end
    return {schema=1,safeReason=runtime.safeReason or "NONE",safeReasonScope=runtime.safeReason and (runtime.safeReasonScope or "CURRENT_SESSION") or "NONE",
        historicalNativeResume=runtime.historicalNativeResume or "NONE",
        historicalPatchedResume=runtime.historicalPatchedResume or "NONE",historicalPatch=runtime.historicalPatch or "NONE",apply=applyCopy(runtime.apply) or
        {id=0,parent=0,trigger="PROFILE",phase="PRECHECK",module="Core",result="NOT_RUN",category="NONE"},
        lastSuccessfulApply=runtime.lastSuccessfulApply,firstFailure=applyCopy(runtime.firstFailure),lastFailure=applyCopy(runtime.lastFailure),history=history,cleanup=cleanup}
end

function M:Print(message)
    if DEFAULT_CHAT_FRAME then
        DEFAULT_CHAT_FRAME:AddMessage("|cffff9c3aMirageUI:|r " .. message)
    end
end

function M:Copy(value, depth, seen)
    depth, seen = depth or 0, seen or {}
    if depth > 24 then return nil end
    if type(value) ~= "table" then
        if type(value)=="string" or type(value)=="boolean" or type(value)=="number" then return value end
        return nil
    end
    if seen[value] then return nil end
    seen[value]=true
    local result={}
    for key, item in pairs(value) do
        if type(key)=="string" or type(key)=="number" then result[key]=self:Copy(item,depth+1,seen) end
    end
    seen[value]=nil
    return result
end

function M:Fault(owner, reason, evidence)
    -- Only local, enumerated categories. Never retain native error text or event payloads.
    owner = self.modules[owner] and owner or "Core"
    local row=self.faults[owner] or {count=0, reason="NONE"}
    row.count=row.count+1; row.reason=reason or "CALL_FAILED"; self.faults[owner]=row
    self.stats.faults=self.stats.faults+1;self.state.forceEvaluate=true
    if self.Incidents then self.Incidents:Record("FAULT",owner,applyRow and applyRow.phase or "RUNTIME",reason or "CALL_FAILED",nil,evidence) end
    if owner=="Core" then
        -- Intent is latched before any cleanup/editor callback can fail.
        self.state.safe=true;self.state.safeReason="CORE_FAULT";runtime.safeReason="CORE_FAULT";runtime.safeReasonScope="CURRENT_SESSION"
        if self.StartupPresentation then pcall(self.StartupPresentation.Cancel,self.StartupPresentation,"CORE_FAULT") end
        self.state.safeCleanupPending=true
        if cleanupRequest and cleanupRequest.status=="COMPLETE" then cleanupRequest=nil end
        if cleanupRequest then cleanupRequest.reason="CORE_FAULT" end
        if self.Profiles and self.Profiles.WriteSafeIntent then pcall(self.Profiles.WriteSafeIntent,self.Profiles,true) end
    end
    if row.count>=3 and self.modules[owner] then
        self.modules[owner].quarantined=true
        self.modules[owner].status="FAULTED"
        self.cleanupModules[owner]=true
    end
end

function M:Guard(owner, fn, ...)
    if type(fn)~="function" then return false end
    local started=self.Profiler and self.Profiler.running and self.Profiler:BeginCallback(owner)
    local previous=self.activeGuardOwner
    self.activeGuardOwner=self.modules[owner] and owner or nil
    local ok, a,b,c=pcall(fn,...)
    self.activeGuardOwner=previous
    if started then self.Profiler:EndCallback(owner,started,ok) end
    if not ok then self:Fault(owner,"CALL_FAILED"); return false end
    return true,a,b,c
end

function M:TrackRoot(owner,frame,passiveVisual,cleanupGuard)
    local registry=self.ownedRoots;registry[owner]=registry[owner] or {}
    local roots=registry[owner];local index=#roots+1;roots[index]=frame
    local parent,known
    local ok,value=pcall(function() return frame:GetParent() end)
    if ok and self.Safety:Readable(value) then parent=value;known=true end
    rootCustody[owner]=rootCustody[owner] or {}
    rootCustody[owner][#rootCustody[owner]+1]={frame=frame,parent=parent,parentKnown=known,registry=registry,roots=roots,index=index,module=self.modules[owner],modules=self.modules,passiveVisual=passiveVisual==true,
        cleanupGuard=type(cleanupGuard)=="function" and cleanupGuard or nil}
    return frame
end
local function rootCurrent(owner,row)
    return rawequal(M.ownedRoots,row.registry) and rawequal(row.registry[owner],row.roots)
        and rawequal(row.roots[row.index],row.frame) and rawequal(M.modules,row.modules)
        and rawequal(row.modules[owner],row.module)
end
local function rootLegal(owner,row)
    if not rootCurrent(owner,row) then return false,"OWNERSHIP_CHANGED" end
    if M.Safety:InCombat() then return false,"COMBAT_LOCKDOWN" end
    if row.cleanupGuard then
        -- Native controls may still depend on this owned wrapper during a
        -- deferred handback. Its creator's captured guard must authorize each
        -- cleanup write; a generic root sweep cannot conceal recovery access.
        local ok,ready,reason=pcall(row.cleanupGuard)
        if not rootCurrent(owner,row) then return false,"OWNERSHIP_CHANGED" end
        if not ok then return false,"CALLBACK_FAILED" end
        if ready~=true then return false,reason=="OWNERSHIP_CHANGED" and reason or "NATIVE_RELEASE_PENDING" end
        if M.Safety:InCombat() then return false,"COMBAT_LOCKDOWN" end
    end
    if not row.parentKnown then return false,"FRAME_UNAVAILABLE" end
    local node,seen=row.frame,{}
    for depth=1,32 do
        if not rootCurrent(owner,row) then return false,"OWNERSHIP_CHANGED" end
        if not M.Safety:Frame(node,false) or not rootCurrent(owner,row) then return false,"FRAME_UNAVAILABLE" end
        if seen[node] then return false,"FRAME_UNAVAILABLE" end;seen[node]=true
        local ok,parent=pcall(function() return node:GetParent() end)
        if not ok or not M.Safety:Readable(parent) then return false,"FRAME_UNAVAILABLE" end
        if not rootCurrent(owner,row) then return false,"OWNERSHIP_CHANGED" end
        if depth==1 and not rawequal(parent,row.parent) then return false,"OWNERSHIP_CHANGED" end
        if parent==nil then
            local combat=M.Safety:InCombat()
            if not rootCurrent(owner,row) then return false,"OWNERSHIP_CHANGED" end
            return not combat,"COMBAT_LOCKDOWN"
        end
        node=parent
    end
    return false,"FRAME_UNAVAILABLE"
end
function M:CleanupOwned(owner)
    local complete,why=true,"NONE"
    for _,row in ipairs(rootCustody[owner] or {}) do
        local legal,reason=rootLegal(owner,row)
        if legal then
            local frame=row.frame;local hide,shown=frame.Hide,frame.IsShown
            local function call(fn,guard,...)
                local ready,blocked=rootLegal(owner,row)
                if not ready then return false,blocked end
                if guard and not guard() then return false,"OWNERSHIP_CHANGED" end
                if type(fn)~="function" then return true end
                if not pcall(fn,...) then return false,"CALLBACK_FAILED" end
                if not rootCurrent(owner,row) then return false,"OWNERSHIP_CHANGED" end
                return true
            end
            local ok,blocked=true,"NONE"
            local function retain(good,failure)
                if not good then ok=false;if blocked=="NONE" or failure=="OWNERSHIP_CHANGED" then blocked=failure end end
            end
            -- Registration failures are independent debt. They cannot starve
            -- the still-legal Hide, and Hide alone cannot certify completion.
            -- Only roots enrolled as secure/watchable controls need secure deregistration.
            -- Authored passive Cards never acquired those registrations. Calling the
            -- native unregister APIs on them can create unrelated cleanup debt.
            if not row.passiveVisual then
                retain(call(UnregisterUnitWatch,nil,frame))
                retain(call(UnregisterStateDriver,nil,frame,"visibility"))
                retain(call(UnregisterStateDriver,nil,frame,"page"))
            end
            local hiddenCall,hiddenWhy=call(hide,function() return rawequal(frame.Hide,hide) and rawequal(frame.IsShown,shown) end,frame)
            retain(hiddenCall,hiddenWhy)
            if hiddenCall then
                local hidden,state=M.Safety:Public(shown,"boolean",frame)
                local legal,reason=rootLegal(owner,row)
                if not legal then retain(false,reason)
                elseif not rawequal(frame.Hide,hide) or not rawequal(frame.IsShown,shown) then retain(false,"OWNERSHIP_CHANGED")
                elseif state~="KNOWN" or hidden~=false then retain(false,"STOP_UNCONFIRMED") end
            end
            if not ok then complete=false;why=blocked end
        else complete=false;why=reason end
    end
    return complete,why
end

function M:RegisterModule(id, module)
    assert(type(id)=="string" and not self.modules[id], "Duplicate MirageUI module")
    assert(type(module)=="table" and type(module.Initialize)=="function", "Invalid MirageUI module")
    module.id=id; module.status="DISABLED"; module.initialized=false
    self.modules[id]=module; self.order[#self.order+1]=id
end

function M:IsModuleActive(id)
    local mod=self.modules[id];local cfg=self:ModuleConfig(id)
    return self.state.initialized and self.state.world and self.Client.allowed and self.profile and self.profile.enabled
        and not self.state.safe and mod and mod.initialized and not mod.quarantined and not mod.suspended and cfg and cfg.enabled==true
end

-- A protected control cannot always be removed at the moment SAFE is requested.
-- Sustain only its essential display until the legal out-of-combat handback.
function M:IsSecureCleanupActive(id)
    local mod=self.modules[id]
    return self.state.world and self.Client.allowed and mod and mod.initialized and mod.pendingDisable==true
        and not mod.maintenanceFailed and type(mod.MaintainSecure)=="function" and self.Safety:InCombat()
end
function M:MaintainSecure(id,event,...)
    local mod=self.modules[id]
    if not self:IsSecureCleanupActive(id) then return end
    local ok=pcall(mod.MaintainSecure,mod,event,...)
    if not ok then
        mod.maintenanceFailed=true
        if mod.ClearSecureDisplay then pcall(mod.ClearSecureDisplay,mod) end
        self:Fault(id,"SECURE_DISPLAY_UNAVAILABLE")
    end
end

function M:ProcessQuarantines()
    local changed=false
    for id in pairs(self.cleanupModules) do
        local mod=self.modules[id]
        if mod then
            -- A blocked native callback is not evidence that its Suspend can
            -- safely run on the next combat tick. Leave the first attempt
            -- pending until legal state is known, just like provider release.
            -- Ordinary fault quarantines retain their existing semantics.
            if not mod.nativeBlocked or not self.Safety:InCombat() then
                if not mod.quarantineAttempted then
                    -- One cleanup attempt per quarantine; never call a failing Suspend every frame.
                    mod.quarantineAttempted=true
                    mod.quarantineSuspended=not mod.Suspend or pcall(mod.Suspend,mod)
                    changed=true
                end
                if not self.Safety:InCombat() then
                    self:CleanupOwned(id);self.Native:Restore(id);self.cleanupModules[id]=nil;changed=true
                end
            end
            mod.status="FAULTED"
        else self.cleanupModules[id]=nil end
    end
    if changed then self:RefreshEvents();self.CVE:Tick(true) end
end

function M:ModuleConfig(id)
    return self.profile and self.profile.modules[id]
end

function M:LoadOptions(loadOnly)
    if self.Safety:InCombat() then self:Print("Open settings after combat. /mirage safe remains available."); return end
    local loader=C_AddOns and C_AddOns.LoadAddOn or LoadAddOn
    if not self.Options and type(loader)=="function" then self:Guard("Core",loader,"MirageUIOptions") end
    if loadOnly then
        local options=self.Options
        -- Loading may run addon callbacks. A newer shell request, even one
        -- already cancelled, owns that intent; never adopt or replay it.
        if options and options==self.Options and not options.shellWork and not options.frame and not options.draft then return options end
        return nil
    end
    if self.Options then self.Options:Open() else self:Print("The MirageUIOptions folder is missing or unavailable.") end
end

local function retained(rows,predicate)
    if type(rows)~="table" then return false end
    local count=0
    for _,row in next,rows do
        count=count+1;if count>512 then return true end
        if type(row)~="table" or predicate(row) then return true end
    end
    return false
end
local function nativePending()
    local n=M.Native
    if n and (retained(n.records,function(s) return s.restorePending or s.quietRestorePending or s.lastWrittenAlpha~=nil end)
        or retained(n.decorations,function(s) return s.pending end)) then return true end
    if M.NativeLayout and retained(M.NativeLayout.rows,function(s) return s.pending or s.original~=nil end) then return true end
    if M.StyleLease and retained(M.StyleLease.rows,function() return true end) then return true end
    return false
end
local function managedPending()
    if M.NativePresentation then
        local ok,pending=pcall(M.NativePresentation.Pending,M.NativePresentation)
        if not ok or pending~=false then return true end
    end
    return M.ManagedNative and retained(M.ManagedNative.rows,function(row)
        return row.active or row.restorePending or row.presentationPending or row.parentAttempt or row.pointsAttempt or row.scaleAttempt or row.sizeAttempt
            or retained(row.art,function(s) return s.pending or s.reloadRequired or (not s.released and (s.written~=nil or s.attempt~=nil)) end)
    end)
end
local function buildCleanup(reason)
    runtime.cleanupSerial=math.min(runtime.cleanupSerial+1,2147483647)
    local r={id=runtime.cleanupSerial,status="PENDING",reason=reason,phase="REQUESTED",steps={},attempts=0,state=M.state,profile=M.profile,modules=M.modules,nextAt=0}
    r.current=function() return rawequal(M.state,r.state) and rawequal(M.profile,r.profile) and rawequal(M.modules,r.modules) end
    local function step(id,fn,current,observe)
        r.steps[#r.steps+1]={id=id,run=fn,current=current,observe=observe,status="PENDING",reason="REQUESTED",attempts=0}
    end
    local profiles,db=M.Profiles,M.db
    if profiles and profiles.WriteSafeIntent then
        local write=profiles.WriteSafeIntent
        step("SAFE_INTENT",function()
            local ok,why=write(profiles,true)
            if why=="READ_ONLY" then return true end -- preserve an unknown format
            return ok,why
        end,function() return rawequal(M.Profiles,profiles) and rawequal(profiles.WriteSafeIntent,write) and rawequal(M.db,db) end)
    end
    local function service(id,key,method,argument,verify,observe)
        local object=M[key]
        if not object then return end
        local fn=object[method]
        local records,decorations,rows=object.records,object.decorations,object.rows
        local function current()
            if not rawequal(M[key],object) or not rawequal(object[method],fn) then return false end
            if key=="Native" then return rawequal(object.records,records) and rawequal(object.decorations,decorations) end
            if key=="ManagedNative" then return rawequal(object.rows,rows) end
            return true
        end
        step(id,function()
            if type(fn)~="function" then return false,"CALLBACK_UNAVAILABLE" end
            local result=fn(object,argument)
            if not current() then return false,"OWNERSHIP_CHANGED" end
            if verify then return verify(object,result) end
            if result==false then return false,"STOP_UNCONFIRMED" end
            return true
        end,current,observe)
    end
    local function panel(id,key)
        local object=M[key];local frame=object and object.frame
        if not frame then return end
        local hide,shown=frame.Hide,frame.IsShown
        local function current() return rawequal(M[key],object) and rawequal(object.frame,frame)
            and rawequal(frame.Hide,hide) and rawequal(frame.IsShown,shown) end
        step(id,function()
            if M.Safety:InCombat() then return false,"COMBAT_LOCKDOWN" end
            if not M.Safety:Frame(frame,true) then return false,"FRAME_UNAVAILABLE" end
            if not current() then return false,"OWNERSHIP_CHANGED" end
            if M.Safety:InCombat() or not current() then return false,"COMBAT_LOCKDOWN" end
            hide(frame)
            local visible,status=M.Safety:Public(shown,"boolean",frame)
            if not current() then return false,"OWNERSHIP_CHANGED" end
            return status=="KNOWN" and visible==false,"STOP_UNCONFIRMED"
        end,current)
    end
    service("KEYBIND_WORKSPACE","KeybindWorkspace","StopForLifecycle",nil,
        function(object) return not object.session and not object.restorePending,"NATIVE_RELEASE_PENDING" end)
    service("HUD_EDITOR","HUDEditor","Close")
    panel("VISUAL_PREVIEW","VisualPreview");panel("LAYOUT_PREVIEW","LayoutPreview");panel("SOURCE_LIBRARY","SourceLibrary")
    service("POLICY","Policy","Invalidate","SAFE_MODE")
    service("BINDING_EDITOR","BindingEditor","Close")
    service("ACTION_KEYS","ActionKeys","Cancel")
    service("EDITOR","Editor","Close")
    service("WORLD_COMBAT_TEXT_RESTORE","WorldCombatText","Restore",nil,
        function(object) return not object:Pending(),"NATIVE_RELEASE_PENDING" end,
        function() return not M.WorldCombatText:Pending() end)
    local seen={}
    for index,id in ipairs(M.order) do
        if index>64 then break end
        local name=authored(moduleNames,id,nil);local mod=M.modules[id]
        if name and not seen[name] and mod and (mod.initialized or mod.initializationFailed or rootCustody[id]) then
            seen[name]=true
            local references={}
            for _,key in ipairs({"frame","surface","view","views","bars","buttons","summaryFrame","summarySurface","browserFrame","panel","panelSurface","anchor","cursorAnchor","smartAnchor","classFrame","totemFrame","runeFrame","gcd","cast"}) do
                local value=rawget(mod,key)
                if value==nil or type(value)=="table" or type(value)=="userdata" then references[#references+1]={key=key,value=value} end
            end
            local function current()
                if not r.current() or not rawequal(r.modules[id],mod) then return false end
                for _,field in ipairs(references) do if not rawequal(rawget(mod,field.key),field.value) then return false end end
                return true
            end
            if type(mod.Suspend)=="function" then
                local suspend=mod.Suspend
                step("SUSPEND_"..name,function()
                    mod.suspended=true
                    local result=suspend(mod)
                    if mod.pendingDisable then return false,"COMBAT_LOCKDOWN" end
                    if mod.anchorRestorePending then return false,"NATIVE_RELEASE_PENDING" end
                    if result==false then return false,"STOP_UNCONFIRMED" end
                    return true
                end,function() return current() and rawequal(mod.Suspend,suspend) end)
            end
            if rootCustody[id] then
                local cleanup=M.CleanupOwned
                step("ROOTS_"..name,function() return cleanup(M,id) end,function() return current() and rawequal(M.CleanupOwned,cleanup) end)
            end
        end
    end
    -- Visibility reconciliation may submit a native original-opacity write.
    -- Run it before final handback so it cannot recreate an alpha lease after
    -- the restore step has already declared that lease released.
    service("CVE","CVE","Tick",true)
    service("NATIVE_RESTORE","Native","RestoreAll",nil,function() return not nativePending(),"NATIVE_RELEASE_PENDING" end,function() return not nativePending() end)
    service("NATIVE_RETRY","Native","RetryRestores",nil,function() return not nativePending(),"NATIVE_RELEASE_PENDING" end,function() return not nativePending() end)
    service("CONTEXTUAL_NATIVE_RESTORE","ContextualNative","RestoreAll",nil,function() return not M.ContextualNative:Pending(),"CONTEXT_RELEASE_PENDING" end,function() return not M.ContextualNative:Pending() end)
    service("NAVIGATION_STYLE_RESTORE","NavigationStyle","Restore",nil,function() return not M.NavigationStyle:Pending(),"STYLE_RELEASE_PENDING" end,function() return not M.NavigationStyle:Pending() end)
    service("NATIVE_PRESENTATION_RESTORE","NativePresentation","RestoreAll",nil,
        function(object) return not object:Pending(),"NATIVE_RELEASE_PENDING" end,
        function() return not M.NativePresentation:Pending() end)
    service("MANAGED_RESTORE","ManagedNative","RestoreAll",nil,function() return not managedPending(),"NATIVE_RELEASE_PENDING" end,function() return not managedPending() end)
    local managed,profiles,account=M.ManagedNative,M.Profiles,M.Profiles and M.Profiles.account
    if managed and account then
        local preference=managed.ResourcePreference
        step("RESOURCE_PREFERENCE",function()
            if rawget(account,"managedPRD")==nil then return true end
            if M.Safety:InCombat() then return false,"COMBAT_LOCKDOWN" end
            local result=preference(managed,false)
            return result==true and rawget(account,"managedPRD")==nil,"NATIVE_RELEASE_PENDING"
        end,function() return rawequal(M.ManagedNative,managed) and rawequal(managed.ResourcePreference,preference) and rawequal(M.Profiles,profiles) and rawequal(profiles.account,account) end)
    end
    local refresh=M.RefreshEvents
    step("EVENTS",function() refresh(M);return true end,function() return rawequal(M.state,r.state) and rawequal(M.RefreshEvents,refresh) end)
    return r
end
function M:ProcessSafeCleanup(explicit)
    if cleanupRunning then return false,"PENDING" end
    if not self.state.safe and not self.state.safeCleanupPending then return true,"COMPLETE" end
    if not cleanupRequest then cleanupRequest=buildCleanup(runtime.safeReason or "CORE_FAULT") end
    local r=cleanupRequest
    if not r.current() then r.status="BLOCKED";r.phase="OWNERSHIP_CHANGED";return false,"BLOCKED" end
    if r.status=="COMPLETE" then self.state.safeCleanupPending=nil;return true,"COMPLETE" end
    if not explicit and r.status=="BLOCKED" then return false,"BLOCKED" end
    local now=self.Safety:Now()
    if not explicit and now<r.nextAt then return false,"PENDING" end
    cleanupRunning=true;r.attempts=math.min(r.attempts+1,2147483647);r.nextAt=now+1
    for _,step in ipairs(r.steps) do
        local before=step.attempts
        local attempted=pcall(function()
        if step.status~="COMPLETE" and step.status~="BLOCKED" then
            r.phase=step.id
            local owns,owned=pcall(step.current)
            if not r.current() or not owns or owned~=true then
                step.status="BLOCKED";step.reason="OWNERSHIP_CHANGED"
            elseif step.reason=="COMBAT_LOCKDOWN" and self.Safety:InCombat() then
                -- Retain the same request until the legal transition. Do not
                -- repeatedly dispatch its native writers during lockdown.
            else
                step.attempts=step.attempts+1
                local ok,done,why=pcall(step.run)
                local still,current=pcall(step.current)
                if not r.current() or not still or current~=true then
                    step.status="BLOCKED";step.reason="OWNERSHIP_CHANGED"
                elseif ok and done==true then step.status="COMPLETE";step.reason="NONE"
                else
                    step.reason=ok and authored(cleanupReasons,why,"STOP_UNCONFIRMED") or "CALLBACK_FAILED"
                    if ok and (step.reason=="NATIVE_RELEASE_PENDING" or step.reason=="STOP_UNCONFIRMED") and self.Safety:InCombat() then step.reason="COMBAT_LOCKDOWN" end
                    -- Combat/unknown legality does not consume the bounded
                    -- callback retry allowance. Wait for a legal transition.
                    if step.reason=="COMBAT_LOCKDOWN" or step.reason=="PROFILE_BUSY" then step.attempts=step.attempts-1 end
                    if step.reason=="OWNERSHIP_CHANGED" or step.attempts>=3 then step.status="BLOCKED" else step.status="PENDING" end
                end
            end
        end
        end)
        if not attempted then
            step.attempts=math.min(3,math.max(before+1,step.attempts));step.reason="CALLBACK_FAILED"
            step.status=step.attempts>=3 and "BLOCKED" or "PENDING"
        end
    end
    -- A later independent release may settle an earlier native debt in this
    -- same pass. Observe authored lease records once, under the old custody;
    -- dispatch success alone is never used as a completion receipt.
    for _,step in ipairs(r.steps) do
        if step.observe and step.status~="COMPLETE" and step.reason=="NATIVE_RELEASE_PENDING" then
            local ok,done=pcall(function() return r.current() and step.current() and step.observe() and step.current() end)
            if ok and done==true then step.status="COMPLETE";step.reason="NONE" end
        end
    end
    local pending,blocked=false,false
    for _,step in ipairs(r.steps) do pending=pending or step.status=="PENDING";blocked=blocked or step.status=="BLOCKED" end
    r.status=pending and "PENDING" or blocked and "BLOCKED" or "COMPLETE";r.phase="COMPLETE"
    if rawequal(self.state,r.state) then self.state.safeCleanupPending=r.status~="COMPLETE" or nil end
    cleanupRunning=nil
    return r.status=="COMPLETE",r.status
end
function M:SafeMode(reason)
    -- A native rejection can be delivered repeatedly while the first callback
    -- is still unwinding. Keep its one cleanup receipt and retry budget. User
    -- requests and explicit recovery remain new, deliberate operations.
    if reason=="NATIVE_ACTION_BLOCKED" and self.state.safe and runtime.safeReason==reason then
        return cleanupRequest and cleanupRequest.status=="COMPLETE" or false,
            cleanupRequest and cleanupRequest.status or "PENDING"
    end
    if self.KeybindWorkspace then pcall(self.KeybindWorkspace.StopForLifecycle,self.KeybindWorkspace) end
    if self.StartupPresentation then pcall(self.StartupPresentation.Cancel,self.StartupPresentation,"SAFE_MODE") end
    if self.Experience then pcall(self.Experience.ClosePreview,self.Experience) end
    self.state.safe=true
    runtime.safeReason=authored(reasons,reason,"USER_REQUEST");self.state.safeReason=runtime.safeReason
    runtime.safeReasonScope="CURRENT_SESSION"
    self.state.safeCleanupPending=true
    -- A deliberate new request can retry failed callbacks. In-flight work is
    -- never replaced by a callback; its captured owners remain authoritative.
    if not cleanupRunning then cleanupRequest=buildCleanup(runtime.safeReason) end
    return self:ProcessSafeCleanup(true)
end

local function rearmRetainedPetCleanup()
    local rework=M.Rework
    local pet=rework and rework.PetLayout
    local lease=pet and pet.lease
    if not lease then return true end
    local owner,rearm=rework.UnitFrames,pet.RearmRetainedCleanup
    if type(rearm)~="function" then return false end
    local ok,ready=pcall(rearm,pet,owner)
    return ok and ready==true and rawequal(M.Rework,rework) and rawequal(rework.PetLayout,pet)
        and rawequal(rework.UnitFrames,owner) and rawequal(pet.RearmRetainedCleanup,rearm) and rawequal(pet.lease,lease)
end

-- Prepare one explicit intended-experience transaction without reapplying the
-- old profile between cleanup and the new preset. No cleanup debt is discarded.
function M:PrepareExperienceActivation()
    if self.applying or applyingAttempt or cleanupRunning or not self.state.initialized then return false,"Interface changes are already being applied." end
    if self.Profiles.readOnly or not self.Client.allowed or self.Safety:InCombat() then return false,"Setup requires an admitted client, writable settings, and no combat." end
    local rework=self.Rework
    if rework and (not rework:TargetMatched() or not rework.storageReady or rework.rolledBack or rework.rollbackPendingReload) then
        return false,"The custom presentation or its recovery storage is unavailable. Open /mirage check and copy /mirage export before changing settings."
    end
    local package=self.BuildInfo and self.BuildInfo:Inspect()
    if not package or package.status~="MATCHED" then
        return false,"MirageUI and MirageUIOptions could not be matched to this release. Replace both core folders from the same ZIP, then reload. Standalone suite addons have their own versions."
    end
    local profile,profiles,state,client,modules=self.profile,self.Profiles,self.state,self.Client,self.modules
    local function current() return self.profile==profile and self.Profiles==profiles and self.state==state and self.Client==client
        and self.modules==modules and self.Rework==rework end
    if state.safe or state.safeCleanupPending then
        if not rearmRetainedPetCleanup() or not current() then return false,"Native pet cleanup ownership could not be verified. MirageUI remains stopped." end
        cleanupRequest=buildCleanup(runtime.safeReason or "USER_REQUEST")
        if not self:ProcessSafeCleanup(true) or not current() then return false,"MirageUI is stopped while display cleanup is pending. Open Help and copy the support report." end
    end
    if rework then
        local ready,why=rework:Retry()
        if not ready then return false,"Display recovery is pending: "..(why or "RETRY_REQUIRED")..". Open /mirage check; reload if incomplete controls are reported." end
    end
    if not current() or not profiles:WriteSafeIntent(false) or not current() then return false,"Settings ownership changed during setup." end
    state.safe=false;state.safeReason=nil;runtime.safeReason=nil;cleanupRequest=nil
    for id,mod in pairs(self.modules) do if not mod.initializationFailed then
        mod.quarantined=nil;mod.nativeBlocked=nil;mod.quarantineSuspended=nil;mod.quarantineAttempted=nil;self.cleanupModules[id]=nil
    end end
    return true
end

function M:Recover()
    local function stopped(why) self:Print(why);return false,why end
    if self.applying or applyingAttempt or not self.state.initialized then return stopped("Settings activation is already running or not ready. Try recovery after the current operation.") end
    local state,profile,profiles,db,client,modules,rework=self.state,self.profile,self.Profiles,self.db,self.Client,self.modules,self.Rework
    local apply,write=self.ApplyProfile,profiles.WriteSafeIntent
    local previousReason=runtime.safeReason
    local function current()
        return rawequal(self.state,state) and rawequal(self.profile,profile) and rawequal(self.Profiles,profiles)
            and rawequal(self.db,db) and rawequal(MirageUIDB,db) and rawequal(self.Client,client) and rawequal(self.modules,modules)
            and rawequal(self.ApplyProfile,apply) and rawequal(profiles.WriteSafeIntent,write) and rawequal(self.Rework,rework)
    end
    if self.Profiles.readOnlyReason=="SECRET_BOUNDARY_UNAVAILABLE" then
        return stopped("Required restricted-value checks are unavailable. Your saved settings are preserved. Reload on a supported client before recovery.")
    end
    if self.Profiles.readOnly or not self.db then return stopped("The unknown settings format is preserved. Restore a compatible profile backup before recovery.") end
    if self.Safety:InCombat() then return stopped("Leave combat before restoring optional modules.") end
    if not current() then return stopped("Settings ownership changed. Recovery did not resume a different profile.") end
    if not self.Client.allowed then return stopped(self.Diagnostics:Status()) end
    if not profile or not profile.enabled then return stopped("MirageUI presentation is disabled in this profile. Enable presentation in settings before resuming.") end
    if self.state.safe or self.state.safeCleanupPending then
        if cleanupRunning then return stopped("MirageUI cleanup is already running. Wait for it to finish before resuming.") end
        -- Explicit Resume is a new request. Automatic continuations never
        -- adopt a callback or owner displaced during an earlier request.
        if not rearmRetainedPetCleanup() or not current() then return stopped("Native pet cleanup ownership could not be verified. MirageUI remains stopped.") end
        cleanupRequest=buildCleanup(runtime.safeReason or "CORE_FAULT")
        local complete=self:ProcessSafeCleanup(true)
        if not current() then return stopped("Settings ownership changed during cleanup. Recovery did not resume a different profile.") end
        if not complete then return stopped("MirageUI remains stopped. Some cleanup is pending or blocked; use /mirage export for the retained cleanup details.") end
    end
    if not write(profiles,false) or not current() then return stopped("Saved settings ownership changed. MirageUI remains stopped; reload before recovery.") end
    self.state.safe=false;self.state.safeReason=nil;runtime.safeReason=nil
    for id,mod in pairs(self.modules) do if not mod.initializationFailed then mod.quarantined=nil;mod.nativeBlocked=nil;mod.quarantineSuspended=nil;mod.quarantineAttempted=nil;self.cleanupModules[id]=nil;if self.faults[id] then self.faults[id].count=0;self.faults[id].reason="RECOVERED" end end end
    local applied=apply(self,nil,"RECOVER")
    if not current() then return stopped("Settings ownership changed during activation. Recovery did not confirm the current profile.") end
    if applied~=true or self.state.safe or self.state.safeCleanupPending then
        if not self.state.safe then self:SafeMode(previousReason or "CORE_FAULT") end
        return stopped("MirageUI could not resume and remains stopped. The failed phase is retained in /mirage export; native test status is unchanged.")
    end
    cleanupRequest=nil
    local status=self.Diagnostics and self.Diagnostics:ActivationState()
    local message=status and status.code=="RUNNING_PARTIAL" and
        "MirageUI resumed, but some displays could not start. Their original controls remain available; copy the support report from Help." or
        "MirageUI resumed."
    self:Print(message);return true,message
end
