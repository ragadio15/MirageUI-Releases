local _,M=...
-- Required native tasks keep their native presentation and geometry. Optional
-- Mirage art yields only where its own public rectangle actually overlaps one
-- of these named windows. This is not a UIParent or descendant-tree scanner.
local S=M.Safety
local D={rows={},active={},dirty=true,discoveryDirty=true,nextDiscovery=0,revision=0,
 hooks=setmetatable({},{__mode="k"}),stats={discoveries=0,rectReads=0,queries=0}}
M.DisplayOcclusion=D
local tasks={
 "GameMenuFrame","SettingsPanel","InterfaceOptionsFrame","VideoOptionsFrame","AudioOptionsFrame","AddonList","AddonDialog","HelpFrame",
 "CharacterFrame","InspectFrame","EquipmentFlyoutFrame","GearManagerPopupFrame","PlayerSpellsFrame","SpellBookFrame","PlayerTalentFrame",
 "ClassTalentLoadoutCreateDialog","ClassTalentLoadoutEditDialog","ClassTalentLoadoutImportDialog","HeroTalentsSelectionDialog",
 "ProfessionsFrame","ProfessionsCustomerOrdersFrame","TradeSkillFrame","CraftFrame","ClassTrainerFrame","MacroFrame","MacroPopupFrame",
 "AuctionHouseFrame","AuctionFrame","MerchantFrame","MailFrame","OpenMailFrame","TradeFrame","GossipFrame","QuestFrame",
 "QuestLogFrame","QuestMapFrame","WorldMapFrame","ItemInteractionFrame","ItemSocketingFrame","ItemUpgradeFrame","ScrappingMachineFrame",
 "TransmogFrame","PetStableFrame","FriendsFrame","SocialUIFrame","FriendsFriendsFrame","AddFriendFrame","BattleNetInviteFrame",
 "CommunitiesFrame","CommunitiesSettingsDialog","GuildFrame","GuildControlUI","GuildInviteFrame","GuildRegistrarFrame","PetitionFrame","TabardFrame",
 "PVEFrame","PVPFrame","RaidParentFrame","RaidFrame","RaidInfoFrame","LFGListApplicationDialog","LFGListInviteDialog",
 "LFGDungeonReadyPopup","LFGReadyCheckPopup","LFDRoleCheckPopup","LFGInvitePopup","ReadyCheckFrame","RolePollPopup","RoleChangedFrame",
 "PVPReadyDialog","PVPReadyPopup","PVPRoleCheckPopup","InstanceAbandonPopup","InstanceAbandonFrame",
 "AchievementFrame","CollectionsJournal","CalendarFrame","EncounterJournal","DressUpFrame","SideDressUpFrame","ClickBindingFrame",
 "ReportCheatingDialog","StaticPopup1","StaticPopup2","StaticPopup3","StaticPopup4"
}
local inventory={"ContainerFrameCombinedBags","BankFrame","GuildBankFrame"}
for i=1,32 do inventory[#inventory+1]="ContainerFrame"..i end
local function field(frame,key)
 if not S:Frame(frame,false) then return nil end
 local ok,v=pcall(function() return frame[key] end)
 return ok and S:Readable(v) and v or nil
end
local function public(frame,key,kind,...)
 return S:Public(field(frame,key),kind,frame,...)
end
local function enabled()
 return M.state and M.state.world and not M.state.safe and M.profile and M.profile.enabled
end
function D:Invalidate(row)
 if row then row.dirty=true else for _,r in pairs(self.rows) do r.dirty=true end end
 self.dirty=true;self.revision=self.revision+1
 if M.state then M.state.forceEvaluate=true end
end
function D:Rect(frame)
 local get=field(frame,"GetRect")
 if type(get)~="function" then return nil,"GEOMETRY_UNAVAILABLE" end
 local ok,left,bottom,width,height=pcall(get,frame)
 if not ok or not S:Number(left) or not S:Number(bottom) or not S:Number(width) or not S:Number(height)
  or width<=0 or height<=0 then return nil,"GEOMETRY_UNAVAILABLE" end
 local scale=public(frame,"GetEffectiveScale","number")
 if not S:Number(scale) or scale<=0 then return nil,"SCALE_UNAVAILABLE" end
 local x,y,w,h=left*scale,bottom*scale,width*scale,height*scale
 if not S:Number(x) or not S:Number(y) or not S:Number(w) or not S:Number(h)
  or not S:Number(x+w) or not S:Number(y+h) then return nil,"GEOMETRY_UNAVAILABLE" end
 self.stats.rectReads=self.stats.rectReads+1
 return {left=x,bottom=y,right=x+w,top=y+h}
end
function D:Watch(row)
 local frame=row.frame
 -- Hooks are observers, never replacement handlers. A root discovered during
 -- lockdown remains readable; observer installation waits for legal setup.
 if S:InCombat() then row.hooksPending=true;return end
 local hooks=self.hooks[frame]
 if not hooks then hooks={names={}};self.hooks[frame]=hooks end
 hooks.names[row.name]=true
 local function changed()
  if M.DisplayOcclusion~=D then return end
  for name in pairs(hooks.names) do
   local current=D.rows[name]
   if current and current.frame==frame and _G[name]==frame then D:Invalidate(current) end
  end
 end
 local hook=field(frame,"HookScript")
 for _,script in ipairs({"OnShow","OnHide","OnSizeChanged"}) do
  if not hooks[script] and type(hook)=="function" then
   local ok,result=pcall(hook,frame,script,changed)
   if ok and result~=false then hooks[script]=true end
  end
 end
 -- Native panel managers move their named roots directly. These post-hooks
 -- invalidate geometry without touching native anchors, scale or scripts.
 for _,method in ipairs({"SetPoint","ClearAllPoints","SetAllPoints","SetScale"}) do
  if not hooks[method] and type(hooksecurefunc)=="function" and type(field(frame,method))=="function" then
   local ok,result=pcall(hooksecurefunc,frame,method,changed)
   if ok and result~=false then hooks[method]=true end
  end
 end
 row.hooksPending=not (hooks.OnShow and hooks.OnHide and hooks.OnSizeChanged) or nil
end
function D:Discover(now)
 if not self.discoveryDirty and now>=self.lastDiscovery and now<self.nextDiscovery then return end
 self.stats.discoveries=self.stats.discoveries+1
 self.discoveryDirty=false;self.lastDiscovery=now;self.nextDiscovery=now+2
 local function collect(names,isInventory)
  for _,name in ipairs(names) do
   local frame=_G[name];local row=self.rows[name]
   if not S:Frame(frame,false) then
    if row then self.rows[name]=nil;self.dirty=true end
   elseif not row or row.frame~=frame then
    row={name=name,frame=frame,inventory=isInventory,dirty=true};self.rows[name]=row;self.dirty=true
    self:Watch(row)
   else
    if row.hooksPending then self:Watch(row) end
    -- Unreadable geometry is retried only on this bounded discovery cadence.
    -- Settled frames use their event-invalidated cache between probes.
    if row.pending or row.hooksPending then row.dirty=true;self.dirty=true end
   end
  end
 end
 collect(tasks,false);collect(inventory,true)
end
function D:Refresh(now)
 self:Discover(now)
 if not self.dirty then return end
 local active,pending={},0
 for name,row in pairs(self.rows) do
  if row.dirty then
   row.dirty=nil;row.rect=nil;row.pending=nil
   local shown,status=public(row.frame,"IsVisible","boolean")
   row.visible=status=="KNOWN" and shown==true
   if status~="KNOWN" then row.pending="VISIBILITY_UNAVAILABLE"
   elseif shown then row.rect,row.pending=self:Rect(row.frame) end
  end
  if row.visible and row.rect then active[#active+1]=row end
  if row.pending or row.hooksPending then pending=pending+1 end
 end
 self.active=active;self.pendingCount=pending;self.dirty=false
end
function D:Blocks(frame,includeInventory)
 self.stats.queries=self.stats.queries+1
 local now=S:Now();self:Refresh(now)
 if #self.active==0 then return false,(self.pendingCount or 0)>0 and "OCCLUSION_GEOMETRY_PENDING" or "NO_OVERLAP" end
 local rect,why=self:Rect(frame)
 if not rect then return false,why end
 for _,row in ipairs(self.active) do
  if row.frame~=frame and _G[row.name]==row.frame and (includeInventory==true or not row.inventory) then
   local other=row.rect
   if rect.left<other.right and rect.right>other.left and rect.bottom<other.top and rect.top>other.bottom then
    return true,row.inventory and "CUSTOM_INVENTORY_OVERLAP" or "NATIVE_TASK_OVERLAP",row.name
   end
  end
 end
 return false,(self.pendingCount or 0)>0 and "OCCLUSION_GEOMETRY_PENDING" or "NO_OVERLAP"
end
function D:Event(event)
 if event=="ADDON_LOADED" or event=="PLAYER_ENTERING_WORLD" or event=="PLAYER_REGEN_ENABLED" then self.discoveryDirty=true end
 if event=="ADDON_LOADED" or event=="PLAYER_ENTERING_WORLD" or event=="PLAYER_LEAVING_WORLD"
  or event=="UI_SCALE_CHANGED" or event=="DISPLAY_SIZE_CHANGED" or event=="PLAYER_REGEN_ENABLED" then self:Invalidate() end
end
function D:Intent(surface)
 -- Aggregate canvases do not describe the position of their individual cards.
 -- Their owners may query Blocks for each actual view or local receipt instead.
 if not enabled() or not surface or surface.userOpened or surface.noOcclusion or surface.floor
  or surface.module=="Bags" or surface.module=="Nameplates" or surface.module=="Cursor" or surface.module=="Notifications" then return nil end
 local blocked,reason=self:Blocks(surface.occlusionFrame or surface.frame,true)
 surface.occlusionReason=blocked and reason or nil
 if not blocked then return nil end
 -- A native input subtree may not be hidden from ordinary code in lockdown.
 -- Keep its visible access floor and report the limit; never alpha-zero a live
 -- protected click area to simulate a successful overlap handoff.
 if S:InCombat() and (surface.security=="SECURE_PREDECLARED" or surface.security=="NATIVE_PROTECTED") then
  if public(surface.frame,"IsVisible","boolean")==true then
   surface.occlusionReason="NATIVE_COMBAT_ACCESS_FLOOR"
   return {state="VISIBLE",id="NATIVE_COMBAT_ACCESS_FLOOR",priority=0,tieRank=58,eligible=true}
  end
  return nil
 end
 return {state="HIDDEN",id=reason,priority=0,tieRank=58,eligible=true}
end
function D:Report()
 return "display_occlusion=NAMED_PUBLIC_RECTANGLES_ONLY\ndisplay_occlusion_pending="..(self.pendingCount or 0)..
  "\ndisplay_occlusion_native_access=PROTECTED_COMBAT_FLOOR_RETAINED"
end
