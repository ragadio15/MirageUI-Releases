local _,M=...
-- P39-J premium optical presentation, based strictly on P39-I.
-- One precomposed, optically aligned official mark/wordmark; directional,
-- softly banded moving sunlight and unified three-stage mirage evaporation.
-- Startup readiness, prompt priority, loading concealment and fail-open
-- gameplay/input safety are retained from P39-I.
-- No native frame ownership, protected attribute changes or new SavedVariables.
local S=M.Safety
local A={state="NOT_STARTED",reason="NOT_STARTED",duration=7,elapsedMs=0,
 settleSeconds=.75,settleFrames=8,maxFrameGap=.25,
 renderFrames=0,stallFrames=0,stallStreak=0,pausedFrames=0,
 resumeFrames=0,lowFPSFallback=false,renderErrors=0,
 hiddenFrames=0,promptCancellations=0,clockFailures=0,coverSuppressed=false,
 safetyTimeoutSeconds=18,reducedDuration=2.50,fallbackFadeSeconds=1.35}
M.StartupAnimation=A
local orange={232/255,140/255,46/255}
local gold={245/255,201/255,92/255}
local art="Interface\\AddOns\\MirageUI\\Media\\Startup\\"
local font="Interface\\AddOns\\MirageUI\\Media\\Fonts\\OpenSans-CondBold.ttf"
local function clamp(v) return math.max(0,math.min(1,v)) end
local function smooth(v) v=clamp(v);return v*v*(3-2*v) end
local function code(v) return S:Text(v) and #v<=64 and v:match("^[A-Z][A-Z0-9_]*$") and v or "UNAVAILABLE" end
local function blend(a,b,t) return a+(b-a)*t end
-- Read-only visibility probes: only confirmed hidden/public values block playback.
-- Any unknown native-object result fails closed for modifying the native UI:
-- the animation never changes or reparents those objects.
local function shown(frame)
 if not frame then return nil end
 local method=frame.IsVisible or frame.IsShown
 if type(method)~="function" then return nil end
 local value,status=S:Public(method,"boolean",frame)
 if status=="KNOWN" then return value end
 return nil
end
local function nativePromptVisible()
 for i=1,4 do
  if shown(_G["StaticPopup"..i])==true then return true end
 end
 return shown(_G.ReadyCheckFrame)==true
end
local function gameplayVisible()
 if shown(UIParent)==false then return false end
 if shown(_G.WorldFrame)==false then return false end
 return true
end
local function quietCall(object,method,...)
 if object and type(object[method])=="function" then pcall(object[method],object,...) end
end
local function cursorVisibility(active)
 local bridge=_G.MirageUICursorNavBridge
 if type(bridge)=="table" and type(bridge.SetStartupPresentation)=="function" then
  pcall(bridge.SetStartupPresentation,active)
 end
end
function A:InitializePreferences()
 local saved=MirageUIExperienceDB
 if saved==nil then saved={schema=1};MirageUIExperienceDB=saved end
 self.preferences=nil;self.preferencesReadOnly=true
 if not S:Readable(saved) or type(saved)~="table" or getmetatable(saved)~=nil or saved.schema~=1 then return false end
 if saved.startupAnimation==nil then saved.startupAnimation=true end
 if saved.startupReduceMotion==nil then saved.startupReduceMotion=false end
 self.preferences=saved;self.preferencesReadOnly=false
 return true
end
function A:GetPreference(key)
 if not self.preferences then self:InitializePreferences() end
 if not self.preferences then return false end
 if key=="enabled" then return self.preferences.startupAnimation==true end
 if key=="reduceMotion" then return self.preferences.startupReduceMotion==true end
 return false
end
function A:SetPreference(key,value)
 if type(value)~="boolean" or key~="enabled" and key~="reduceMotion" then return false end
 if not self:InitializePreferences() then return false end
 self.preferences[key=="enabled" and "startupAnimation" or "startupReduceMotion"]=value
 if key=="enabled" and not value then self:Cancel("PREFERENCE_DISABLED") end
 if M.InstallerBridge then M.InstallerBridge:Request("PREFERENCE_CHANGED") end
 return true
end
function A:Allowed(preview)
 local state=M.state
 if not state or not state.initialized or not M.profile or not M.profile.enabled then return false,"MIRAGEUI_DISABLED" end
 if not state.world then return false,"WORLD_UNAVAILABLE" end
 if state.safe or state.safeCleanupPending then return false,"SAFE_MODE" end
 if M.Client and M.Client.allowed~=true then return false,"CLIENT_UNAVAILABLE" end
 if S:InCombat() then return false,"COMBAT" end
 if select(2,S:Public(GetTime,"number"))~="KNOWN" then return false,"CLOCK_UNAVAILABLE" end
 if self.loading then return false,"LOADING_SCREEN" end
 if self.cinematic then return false,"CINEMATIC" end
 if not gameplayVisible() then return false,"UI_HIDDEN" end
 if nativePromptVisible() then return false,"NATIVE_DIALOG" end
 if not preview and not self:GetPreference("enabled") then return false,"PREFERENCE_DISABLED" end
 return true
end
function A:Prepare()
 if self.prepared and self.frame then return true end
 if self.frame and not self.prepared then self.frame=nil end
 if S:InCombat() or type(CreateFrame)~="function" or not UIParent then return false end
 local f=CreateFrame("Frame",nil,UIParent)
 if type(f.EnableKeyboard)~="function" or type(f.SetPropagateKeyboardInput)~="function" then
  quietCall(f,"Hide");return false
 end
 self.frame=f
 f:Hide();f:SetAllPoints(UIParent);f:SetFrameStrata("FULLSCREEN_DIALOG");f:SetFrameLevel(200)
 f:EnableMouse(false)
 -- No protected or native frames are manipulated; keyboard input propagates.
 f:EnableKeyboard(false);f:SetPropagateKeyboardInput(true)
 local backdrop=f:CreateTexture(nil,"BACKGROUND",nil,-8)
 backdrop:SetAllPoints(f);backdrop:SetColorTexture(.018,.019,.022,1);self.backdrop=backdrop
 -- Lockup includes BOTH the original emblem and the complete 'MirageUI'
 -- wordmark, with their optically visible bounds aligned on one baseline.
 -- Every subsequent effect uses this same 760 x 200 reference coordinate system.
 local group=CreateFrame("Frame",nil,f)
 group:SetSize(760,200);group:SetPoint("CENTER",f,"CENTER",0,18)
 group:EnableMouse(false);self.group=group
 local glow=group:CreateTexture(nil,"BACKGROUND",nil,0)
 glow:SetSize(240,240);glow:SetPoint("CENTER",group,"LEFT",145,0)
 glow:SetTexture(art.."Glow.tga")
 glow:SetVertexColor(unpack(gold));glow:SetAlpha(0);self.glow=glow
 self.heatVeils={}
 for i=1,2 do
  local veil=group:CreateTexture(nil,"ARTWORK",nil,-4+i)
  veil:SetTexture(art.."Heat.tga");veil:SetSize(755,90)
  veil:SetPoint("CENTER",group,"CENTER",0,0)
  veil:SetVertexColor(unpack(gold));veil:SetAlpha(0)
  self.heatVeils[i]=veil
 end
 local base=group:CreateTexture(nil,"ARTWORK",nil,0)
 base:SetSize(760,200);base:SetPoint("CENTER",group,"CENTER",0,0)
 base:SetTexture(art.."Lockup.tga");base:SetVertexColor(unpack(orange));base:SetAlpha(1)
 self.lockup=base
 local gilt=group:CreateTexture(nil,"ARTWORK",nil,1)
 gilt:SetTexture(art.."Lockup.tga");gilt:SetWidth(1);gilt:SetHeight(200)
 gilt:SetPoint("LEFT",group,"LEFT",0,0);gilt:SetTexCoord(0,.001,0,1)
 gilt:SetVertexColor(unpack(gold));gilt:SetAlpha(0)
 self.goldLockup=gilt
 -- Glow restricted to the visible glyph silhouette; the separate sunshaft
 -- texture provides the soft, cloud-banded light traveling left to right.
 local hot=group:CreateTexture(nil,"OVERLAY",nil,0)
 hot:SetTexture(art.."Lockup.tga");hot:SetWidth(1);hot:SetHeight(200)
 hot:SetPoint("LEFT",group,"LEFT",0,0);hot:SetTexCoord(0,.001,0,1)
 hot:SetVertexColor(1,.9,.65);hot:SetAlpha(0)
 if type(hot.SetBlendMode)=="function" then hot:SetBlendMode("ADD") end
 self.hotBand=hot
 local vaporA=group:CreateTexture(nil,"OVERLAY",nil,1)
 vaporA:SetSize(760,200);vaporA:SetPoint("CENTER",group,"CENTER",0,0)
 vaporA:SetTexture(art.."EvaporationA.tga")
 vaporA:SetVertexColor(unpack(gold));vaporA:SetAlpha(0);self.evaporationA=vaporA
 local vaporB=group:CreateTexture(nil,"OVERLAY",nil,2)
 vaporB:SetSize(760,200);vaporB:SetPoint("CENTER",group,"CENTER",0,0)
 vaporB:SetTexture(art.."EvaporationB.tga")
 vaporB:SetVertexColor(unpack(gold));vaporB:SetAlpha(0);self.evaporationB=vaporB
 local shaft=group:CreateTexture(nil,"OVERLAY",nil,3)
 shaft:SetTexture(art.."Sunbreak.tga");shaft:SetSize(225,240)
 shaft:SetPoint("CENTER",group,"LEFT",0,0)
 shaft:SetVertexColor(1,.89,.67);shaft:SetAlpha(0)
 if type(shaft.SetBlendMode)=="function" then shaft:SetBlendMode("ADD") end
 self.sunbreak=shaft
 local hint=f:CreateFontString(nil,"OVERLAY")
 hint:SetFont(font,13,"");hint:SetText("Esc to skip")
 hint:SetPoint("BOTTOM",f,"BOTTOM",0,36);hint:SetTextColor(.65,.63,.59)
 self.hint=hint
 f:SetScript("OnKeyDown",function(_,key)
  if key=="ESCAPE" then A:Cancel("ESCAPE") end
 end)
 f:SetScript("OnHide",function()
  if A.active or A.armed then
   if not gameplayVisible() then A:SuppressCover("UI_HIDDEN")
   else A:Cancel("HIDDEN") end
  end
 end)
 f:SetScript("OnShow",function()
  if A.active or A.armed then cursorVisibility(true) end
  if (A.active or A.armed) and A.coverSuppressed then
   A.suspended=true;A.resumeWaiting=true
   A.resumeSeconds=0;A.resumeFrames=0;A.lastFrameAt=nil
  end
 end)
 self.prepared=true
 return true
end

local LOCKUP_WIDTH=760
-- Visible glyph bounds of baked high-fidelity lockup in UI-space:
-- x=62..695, centered around (380,100) with optical mark/text alignment.
local GLYPH_LEFT=62
local GLYPH_RIGHT=695
local EVAPORATION_BEGIN=5.14
local EVAPORATION_SPAN=1.86
local function updateUV(texture,from,to)
 local lo=clamp(from);local hi=clamp(to)
 if hi<=lo+.001 then
  texture:SetWidth(.1);texture:SetTexCoord(lo,math.min(1,lo+.001),0,1)
 else
  texture:SetWidth(LOCKUP_WIDTH*(hi-lo));texture:SetTexCoord(lo,hi,0,1)
 end
 texture:ClearAllPoints();texture:SetPoint("LEFT",A.group,"LEFT",LOCKUP_WIDTH*lo,0)
end
function A:Paint(t)
 -- All phases, including moving light and evaporation, derive from one
 -- visible-frame clock. A low-FPS fallback freezes the current frame and
 -- fades it instead of suddenly switching to unrelated artwork.
 local limit=self.playDuration or self.duration
 t=math.max(0,math.min(limit,t or 0))
 local sample=self.lowFPSFallback and (self.fallbackExitStart or 0) or t
 local fallbackAlpha=1
 if self.lowFPSFallback and self.fallbackExitStart then
  fallbackAlpha=1-smooth((t-self.fallbackExitStart)/(self.fallbackFadeSpan or self.fallbackFadeSeconds))
 end
 local reduced=self.reduced
 local sweep=reduced and 1 or smooth((sample-.35)/3.55)
 local evap=reduced and 0 or smooth((sample-EVAPORATION_BEGIN)/EVAPORATION_SPAN)
 local reducedExit=reduced and smooth((sample-.95)/1.55) or 0
 local backdropAlpha=(1-(reduced and reducedExit or evap))*fallbackAlpha
 self.backdrop:SetAlpha(backdropAlpha)
 self.group:SetAlpha(fallbackAlpha)
 -- Three overlapping positions: native lockup -> soft refracted image ->
 -- vaporous fragmented echo -> nothing. No visible seams, strips or flicker.
 local baseAlpha,echoA,echoB=1,0,0
 if not reduced and evap>0 then
  local stage=evap*3
  if stage<1 then
   local k=smooth(stage);baseAlpha=1-k;echoA=k*.98
  elseif stage<2 then
   local k=smooth(stage-1);baseAlpha=0;echoA=(1-k)*.98;echoB=k*.88
  else
   local k=smooth(stage-2);baseAlpha=0;echoA=0;echoB=(1-k)*.88
  end
 end
 if reduced then baseAlpha=1-reducedExit end
 self.lockup:SetVertexColor(unpack(reduced and gold or orange))
 self.lockup:SetAlpha(baseAlpha)
 -- One gold wipe crosses the *entire* optically aligned mark and wordmark.
 local edge=math.max(.001,(GLYPH_LEFT+(GLYPH_RIGHT-GLYPH_LEFT)*sweep)/LOCKUP_WIDTH)
 if not self.lastUV or math.abs(self.lastUV-edge)>.00035 then
  updateUV(self.goldLockup,0,edge);self.lastUV=edge
 end
 self.goldLockup:SetAlpha((not reduced and sweep>0) and baseAlpha or 0)
 self.evaporationA:SetAlpha(echoA)
 self.evaporationB:SetAlpha(echoB)
 local rise=(not reduced) and smooth((sample-3.05)/1.0) or 0
 local tail=1-smooth((sample-5.30)/1.15)
 local haze=(reduced or self.lowFPSFallback) and 0 or rise*tail
 self.glow:SetAlpha(reduced and .03*(1-reducedExit) or (.035+.095*sweep)*(1-evap))
 for i,veil in ipairs(self.heatVeils or {}) do
  local drift=haze>0 and .0035*math.sin(sample*(i==1 and 2.1 or 1.8)+i*.8) or 0
  if haze>0 then veil:SetTexCoord(drift,1+drift,0,1) end
  veil:SetAlpha(haze*(i==1 and .065 or .042))
 end
 -- Natural banded light: a diffuse corona AND an additive glyph highlight,
 -- both at the identical moving X. The band follows the gold sweep, never
 -- races ahead or continues after the letters start evaporating.
 local x=GLYPH_LEFT+(GLYPH_RIGHT-GLYPH_LEFT)*sweep
 local lightEnvelope=(1-smooth((sample-3.72)/.53))*smooth((sample-.20)/.38)
 local sunAlpha=(reduced or self.lowFPSFallback) and 0 or .35*lightEnvelope*(1-evap)
 local sunHue=smooth((sample-.75)/2.9)
 self.sunbreak:SetVertexColor(1,blend(.64,.93,sunHue),blend(.39,.75,sunHue))
 self.sunbreak:SetAlpha(sunAlpha)
 if not self.lastLightX or math.abs(self.lastLightX-x)>.12 then
  self.sunbreak:ClearAllPoints();self.sunbreak:SetPoint("CENTER",self.group,"LEFT",x,0)
  self.lastLightX=x
 end
 local u0=math.max(0,(x-27)/LOCKUP_WIDTH)
 local u1=math.min(1,(x+27)/LOCKUP_WIDTH)
 if not self.lastBandX or math.abs(self.lastBandX-x)>.12 then
  updateUV(self.hotBand,u0,u1);self.lastBandX=x
 end
 self.hotBand:SetAlpha(sunAlpha*.80)
 -- Evaporation moves only the ghost material a few UI pixels upward; no
 -- independent per-letter/per-strip motion or opacity clocks.
 if evap>0 and not reduced and not self.lowFPSFallback then
  local ox=evap*5;local oy=evap*13
  if not self.lastVaporY or math.abs(self.lastVaporY-oy)>.06 then
   self.evaporationB:ClearAllPoints();self.evaporationB:SetPoint("CENTER",self.group,"CENTER",ox,oy)
   self.lastVaporY=oy
  end
 else
  if self.lastVaporY~=0 then
   self.evaporationB:ClearAllPoints();self.evaporationB:SetPoint("CENTER",self.group,"CENTER",0,0)
   self.lastVaporY=0
  end
 end
 local hint=reduced and (1-smooth((sample-.45)/.75)) or (1-smooth((sample-4.75)/.80))
 self.hint:SetAlpha(hint*fallbackAlpha)
 self.lastEvaporation=evap;self.lastSweep=sweep;self.lastBackdropAlpha=backdropAlpha
end
function A:SuppressCover(reason)
 if self.coverSuppressed or not self.frame then return end
 self.coverSuppressed=true;self.coverReason=code(reason or "VISIBILITY_PAUSED")
 -- Suppression may be triggered by an event before OnUpdate runs. Mark the
 -- resume gate immediately, including on single-frame loading transitions.
 self.suspended=true;self.resumeWaiting=true
 self.resumeSeconds=0;self.resumeFrames=0
 self.pausedFrames=(self.pausedFrames or 0)+1
 quietCall(self.frame,"SetAlpha",0)
 -- The frame remains shown to keep its OnUpdate observer alive. The keyboard
 -- handler is disabled while there is no visible cinematic to skip.
 quietCall(self.frame,"EnableKeyboard",false)
end
function A:RestoreCover()
 if not self.coverSuppressed or not self.frame then return end
 self.coverSuppressed=false;self.coverReason="NONE"
 quietCall(self.frame,"SetAlpha",1)
 if not S:InCombat() then quietCall(self.frame,"EnableKeyboard",true) end
end
function A:EnterFallback(reason)
 if self.lowFPSFallback then return end
 self.lowFPSFallback=true;self.fallbackReason=code(reason or "SUSTAINED_FRAME_GAPS")
 self.fallbackExitStart=self.armed and 0 or (self.playedSeconds or 0)
 local remaining=(self.playDuration or self.duration)-self.fallbackExitStart
 self.fallbackFadeSpan=math.max(.001,math.min(remaining,self.fallbackFadeSeconds))
 self.playDuration=math.min(self.playDuration or self.duration,self.fallbackExitStart+self.fallbackFadeSpan)
end
function A:Cancel(reason)
 local was=self.active or self.armed
 self.active=false;self.armed=false;self.pending=false
 -- Elapsed describes the artwork actually presented, not time spent inside
 -- a blocked client or behind its native loading screen.
 self.elapsedMs=math.floor(math.max(0,self.playedSeconds or 0)*1000+.5)
 self.state=reason=="DEADLINE" and "COMPLETE" or "CANCELLED";self.reason=code(reason or "CANCELLED")
 if self.frame then
  quietCall(self.frame,"SetScript","OnUpdate",nil)
  quietCall(self.frame,"EnableKeyboard",false)
  quietCall(self.frame,"Hide")
 end
 self.startedAt=nil;self.lastFrameAt=nil;self.firstFrameAt=nil
 self.suspended=false;self.resumeWaiting=false;self.coverSuppressed=false
 if was then cursorVisibility(false) end
 if was and M.InstallerBridge then M.InstallerBridge:Request("STARTUP_PRESENTATION") end
 return true
end
function A:Update(frameElapsed)
 if not self.active and not self.armed then return end
 -- Gameplay safety outranks any startup ornament. In particular, do not
 -- attempt to manipulate a native frame when its client state is uncertain.
 if S:InCombat() then self:Cancel("COMBAT");return end
 if not M.state or M.state.safe or M.state.safeCleanupPending then self:Cancel("SAFE_MODE");return end
 if not M.profile or not M.profile.enabled then self:Cancel("PROFILE_DISABLED");return end
 if M.Client and M.Client.allowed~=true then self:Cancel("CLIENT_UNAVAILABLE");return end
 if nativePromptVisible() then
  self.promptCancellations=self.promptCancellations+1
  self:Cancel("NATIVE_DIALOG");return
 end
 local now,status=S:Public(GetTime,"number")
 if status~="KNOWN" or not S:Number(now) then
  self.clockFailures=self.clockFailures+1
  if self.clockFailures>=3 then self:Cancel("CLOCK_UNAVAILABLE") end
  return
 end
 self.clockFailures=0
 if not self.lastFrameAt then self.lastFrameAt=now;return end
 local gap=now-self.lastFrameAt
 self.lastFrameAt=now
 if gap<0 then return end
 -- Always recheck actual loading-screen visibility. Event ordering alone is
 -- not sufficient on slow login and reload paths.
 local boundary=self:ReconcileLoadingBoundary()
 local blocked=not boundary or self.cinematic or not M.state.world or not gameplayVisible()
 if blocked then
  local why=self.cinematic and "CINEMATIC" or (not boundary and "LOADING_SCREEN" or "UI_HIDDEN")
  self:SuppressCover(why)
  if not self.suspended then self.suspended=true;self.pausedFrames=self.pausedFrames+1 end
  self.hiddenFrames=self.hiddenFrames+1
  self.resumeWaiting=true;self.resumeSeconds=0;self.resumeFrames=0
  return
 end
 -- A long single frame gap is real elapsed wall time even when its artwork
 -- delta is dropped; never let two huge stalls hide an unbounded curtain.
 if self.active and not self.suspended and not self.resumeWaiting then
  self.visibleWallSeconds=(self.visibleWallSeconds or 0)+gap
  if self.visibleWallSeconds>self.safetyTimeoutSeconds then
   self:Cancel("PLAYBACK_BUDGET");return
  end
 end
 local dt=gap
 if S:Number(frameElapsed) and frameElapsed>=0 then dt=math.min(dt,frameElapsed) end
 local stall=gap>self.maxFrameGap or dt>self.maxFrameGap
 if stall then
  self.stallFrames=self.stallFrames+1;self.stallStreak=self.stallStreak+1
  if self.stallStreak>=3 then self:EnterFallback("SUSTAINED_FRAME_GAPS") end
  if not self.lowFPSFallback then
   if self.armed then self.stableSeconds=0;self.stableFrames=0 end
   if self.resumeWaiting then self.resumeSeconds=0;self.resumeFrames=0 end
   return
  end
  dt=math.min(gap,.08)
 else
  self.stallStreak=0
 end
 if self.suspended then
  self.suspended=false;self.resumeWaiting=true;self.resumeSeconds=0;self.resumeFrames=0
 end
 local settleSeconds=self.lowFPSFallback and .45 or self.settleSeconds
 local settleFrames=self.lowFPSFallback and 4 or self.settleFrames
 if self.resumeWaiting and not self.armed then
  self.resumeSeconds=self.resumeSeconds+dt
  self.resumeFrames=self.resumeFrames+1
  self.pausedFrames=self.pausedFrames+1
  if self.resumeSeconds<settleSeconds or self.resumeFrames<settleFrames then return end
  self.resumeWaiting=false;self:RestoreCover()
  return -- Resume only on the *next* presented frame.
 end
 if self.armed then
  self.stableSeconds=(self.stableSeconds or 0)+dt
  self.stableFrames=(self.stableFrames or 0)+1
  if self.stableSeconds<settleSeconds or self.stableFrames<settleFrames then return end
  self.armed=false;self.active=true;self.startedAt=now;self.playedSeconds=0
  self.state="PLAYING";self.reason=self.preview and "PREVIEW" or "SESSION_START"
  self:RestoreCover();self:Paint(0);return
 end
 if (self.playedSeconds or 0)>=5.18 and not self.lowFPSFallback and not self.reduced then
  dt=math.min(dt,.05)
 end
 local limit=self.playDuration or self.duration
 local t=math.min(limit,(self.playedSeconds or 0)+dt)
 self.playedSeconds=t;self.renderFrames=self.renderFrames+1
 self.elapsedMs=math.floor(t*1000+.5)
 self:Paint(t)
 if t>=limit then self:Cancel("DEADLINE") end
end
function A:Layout()
 if not self.prepared then return end
 local width=S:Public(self.frame.GetWidth,"number",self.frame) or 1280
 local height=S:Public(self.frame.GetHeight,"number",self.frame) or 720
 local scale=math.max(.32,math.min(3.5,width/1500,height/850))
 self.group:SetScale(scale)
 self.hint:SetFont(font,13*math.max(.75,scale),"")
 self.hint:ClearAllPoints();self.hint:SetPoint("BOTTOM",self.frame,"BOTTOM",0,36*math.max(.75,scale))
 -- UI scale and monitor changes must retain the current visual frame.
 self:Paint(self.playedSeconds or 0)
end
function A:Start(preview)
 self.preview=preview==true
 local allowed,reason=self:Allowed(self.preview)
 if not allowed then self.state="SKIPPED";self.reason=reason;return false,reason end
 local ok,ready=pcall(self.Prepare,self)
 if not ok or not ready then self:Cancel("PRESENTATION_UNAVAILABLE");return false,"PRESENTATION_UNAVAILABLE" end
 self:Cancel("RESTART")
 self.preview=preview==true;self.reduced=self:GetPreference("reduceMotion");self.elapsedMs=0;self.playedSeconds=0
 self.playDuration=self.reduced and self.reducedDuration or self.duration
 self.fallbackExitStart=nil;self.fallbackFadeSpan=nil;self.fallbackReason="NONE"
 self.lastVisible=nil;self.lastWarm=nil;self.lastUV=nil;self.lastGoldAlpha=nil
 self.lastLightX=nil;self.lastBandX=nil;self.lastVaporY=nil;self.lastSweep=0;self.lastEvaporation=0
 self.visibleWallSeconds=0;self.hiddenFrames=0;self.promptCancellations=0;self.clockFailures=0
 self.coverSuppressed=false;self.coverReason="NONE"
 quietCall(self.frame,"SetAlpha",1)
 self.stableSeconds=0;self.stableFrames=0;self.lastFrameAt=nil;self.firstFrameAt=nil
 self.resumeSeconds=0;self.resumeFrames=0;self.resumeWaiting=false;self.suspended=false
 self.renderFrames=0;self.stallFrames=0;self.stallStreak=0;self.pausedFrames=0
 self.lowFPSFallback=false
 self.armed=true;self.state="SETTLING";self.reason="VISIBLE_FRAME_BUFFER"
 local painted=pcall(function() self:Layout();self:Paint(0) end)
 if not painted then self:Cancel("PRESENTATION_UNAVAILABLE");return false,"PRESENTATION_UNAVAILABLE" end
 self.frame:SetScript("OnUpdate",function(_,elapsed)
  local success=pcall(A.Update,A,elapsed)
  if not success then A:Cancel("PRESENTATION_FAILED") end
 end)
 -- Propagation was set by Prepare before combat and is never toggled here.
 self.frame:EnableKeyboard(true);self.frame:Show()
 return true
end
function A:Preview() return self:Start(true) end
function A:TryStart()
 if not self.pending then return false end
 if not self:ReconcileLoadingBoundary() then return false end
 if not M.state or not M.state.initialized or not M.state.world or not M.profile then return false end
 -- An event may arrive before the world/profile/clock has settled. Leave
 -- pending intact and retry through the lightweight 100-ms event poll.
 local allowed,why=self:Allowed(false)
 if not allowed then
  if why=="CLOCK_UNAVAILABLE" or why=="WORLD_UNAVAILABLE" or why=="LOADING_SCREEN"
  or why=="CINEMATIC" or why=="UI_HIDDEN" then return false end
  self.pending=false;self.state="SKIPPED";self.reason=code(why)
  return false
 end
 self.pending=false
 return self:Start(false)
end
function A:ReconcileLoadingBoundary()
 -- Loading-screen visibility takes priority even if DISABLED fires early.
 -- Recheck while pending instead of missing the launch permanently.
 local panel=_G.LoadingScreenFrame
 if panel and type(panel.IsShown)=="function" then
  local visible,status=S:Public(panel.IsShown,"boolean",panel)
  if status=="KNOWN" then
   if visible then self.loading=true;return false end
   if self.loading then self.boundary="LOADING_FRAME_CLEARED" end
   self.loading=false;return true
  end
 end
 if not self.loading then return true end
 if not panel and not self.sawLoadingEnabled then
  self.loading=false;self.boundary="WORLD_ENTRY_NO_LOADING_FRAME";return true
 end
 return false
end
function A:WorldEntry(initial,reload)
 if self.seenWorld then return end
 self.seenWorld=true
 -- Nil payloads on an older client still identify this fresh UI session;
 -- explicit false/false is an ordinary zone transition, never an intro.
 if initial==false and reload==false then self.state="SKIPPED";self.reason="ZONE_TRANSITION";return end
 self:InitializePreferences()
 if not self:GetPreference("enabled") then self.state="SKIPPED";self.reason="PREFERENCE_DISABLED";return end
 -- Cold loading may exceed eight seconds; wait for real rendering readiness.
 -- Native dialogs are independently prioritized in Allowed/Update.
 self.pending=true;self.state="WAITING"
 self:ReconcileLoadingBoundary()
 self.reason=self.loading and "LOADING_SCREEN" or "WORLD_ENTRY_PENDING"
end
function A:Event(event)
 if event=="LOADING_SCREEN_ENABLED" then
  self.loading=true;self.sawLoadingEnabled=true
  -- New loading screens pause a running intro; never skip unseen seconds.
  if self.active or self.armed then self:SuppressCover("LOADING_SCREEN") end
 elseif event=="LOADING_SCREEN_DISABLED" then
  self.loading=false;self.sawLoadingEnabled=false;self.boundary="LOADING_SCREEN_DISABLED"
  self:TryStart()
 elseif event=="CINEMATIC_START" or event=="PLAY_MOVIE" then
  self.cinematic=true
  if self.active or self.armed then self:SuppressCover("CINEMATIC") end
 elseif event=="CINEMATIC_STOP" or event=="STOP_MOVIE" then self.cinematic=false
 elseif event=="PLAYER_REGEN_DISABLED" then self:Cancel("COMBAT")
 elseif event=="DISPLAY_SIZE_CHANGED" or event=="UI_SCALE_CHANGED" then if self.active or self.armed then self:Layout() end
 elseif event=="PLAYER_LOGOUT" then self:Cancel("WORLD_LEFT") end
end
function A:Report()
 return "startup_animation="..code(self.state).."; reason="..code(self.reason).."; elapsed_ms="..self.elapsedMs
  .."; sequence_seconds=7; clock=VISIBLE_FRAME_PROGRESS; settle_buffer_ms=750; settle_frames=8"
  .."; cancellation=ESC_COMBAT_OPT_OUT_OR_COMPLETE"
  .."; enabled="..tostring(self:GetPreference("enabled")).."; reduced_motion="..tostring(self:GetPreference("reduceMotion"))
  .."; renderer=P39J_PREMIUM_LIGHT; gold_wipe=ONE_LOCKUP_LEFT_TO_RIGHT"
  .."; compositing=OPTICALLY_ALIGNED_PRECOMPOSITE; dissolve=THREE_STAGE_MIRAGE_EVAPORATION"
  .."; sunbreak=BANDED_CLOUD_LIGHT; locked_baseline=TRUE; light_sweep="..tostring(math.floor((self.lastSweep or 0)*100+.5))
   .."; evaporation="..tostring(math.floor((self.lastEvaporation or 0)*100+.5))
   .."; render_frames="..tostring(self.renderFrames or 0).."; stall_frames="..tostring(self.stallFrames or 0)
  .."; paused_frames="..tostring(self.pausedFrames or 0).."; low_fps_fallback="..tostring(self.lowFPSFallback==true)
  .."; standard_duration_ms=7000; reduced_duration_ms=2500; playback_duration_ms="..tostring(math.floor((self.playDuration or self.duration)*1000+.5))
  .."; visible_wall_ms="..tostring(math.floor((self.visibleWallSeconds or 0)*1000+.5))
  .."; clock_failures="..tostring(self.clockFailures or 0).."; hidden_frames="..tostring(self.hiddenFrames or 0)
  .."; prompt_cancellations="..tostring(self.promptCancellations or 0)
  .."; cover_suppressed="..tostring(self.coverSuppressed==true).."; fallback_reason="..code(self.fallbackReason or "NONE")
  .."; ending_frame_cap_ms=50; loading_boundary="..code(self.boundary or "UNAVAILABLE")
  .."; readiness_gate=PENDING_RETRY_AND_STABLE_FRAMES; activity_reset=NONE; native_root_changes=NONE; native_rendering=NOT_RUN"
end
-- Wrap only the existing core dispatcher. Provider work and error handling
-- retain their established ownership and ordering.
local event=M.Event
function M:Event(name,...)
 if name=="PLAYER_ENTERING_WORLD" then
  local okay=pcall(A.WorldEntry,A,...)
  if not okay then A:Cancel("PRESENTATION_FAILED") end
 elseif name=="PLAYER_LEAVING_WORLD" or name=="PLAYER_LOGOUT" or name=="PLAYER_REGEN_DISABLED" then A:Event(name) end
 local a,b=event(self,name,...)
 if name=="PLAYER_ENTERING_WORLD" then
  local okay=pcall(A.TryStart,A)
  if not okay then A:Cancel("PRESENTATION_FAILED") end
 end
 return a,b
end
if M.StartupPresentation then
 local cancel=M.StartupPresentation.Cancel
 function M.StartupPresentation:Cancel(reason,...)
  -- Safety faults and first-run setup cancel; routine provider context
  -- changes cannot steal the cinematic or mutate its scene graph.
  if reason=="ESCAPE" or reason=="COMBAT" or reason=="SAFE_MODE"
    or reason=="CORE_FAULT" or reason=="SETUP_WINDOW" then A:Cancel(reason) end
  return cancel(self,reason,...)
 end
 local report=M.StartupPresentation.Report
 function M.StartupPresentation:Report(...) return report(self,...).."\n"..A:Report() end
end
if type(CreateFrame)=="function" then
 local f=CreateFrame("Frame")
 -- On initial loading the enabled event may precede addon file loading.
 -- Wait for the disabled boundary instead of consuming the sequence behind
 -- Blizzard's loading screen. A missing boundary leaves no visible cover.
 local okay,registered=pcall(f.RegisterEvent,f,"LOADING_SCREEN_DISABLED")
 if okay and registered~=false then A.loading=true end
 for _,name in ipairs({"LOADING_SCREEN_ENABLED","LOADING_SCREEN_DISABLED","CINEMATIC_START","CINEMATIC_STOP","PLAY_MOVIE","STOP_MOVIE","DISPLAY_SIZE_CHANGED","UI_SCALE_CHANGED"}) do pcall(f.RegisterEvent,f,name) end
 f:SetScript("OnEvent",function(_,name)
  local okay=pcall(A.Event,A,name)
  if not okay then A:Cancel("PRESENTATION_FAILED") end
 end)
 f:SetScript("OnUpdate",function(_,dt)
  if not A.pending then return end
  A.pendingPoll=(A.pendingPoll or 0)+(type(dt)=="number" and dt or 0)
  if A.pendingPoll<.10 then return end
  A.pendingPoll=0
  local okay=pcall(A.TryStart,A)
  if not okay then A:Cancel("PRESENTATION_FAILED") end
 end)
end
-- Native prompts and ordinary player input are intentionally non-cancelling.
-- Mouse interaction passes through the artwork and keyboard input propagates.
