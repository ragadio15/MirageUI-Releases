local _,M=...
-- User-approved beta.14 direction: a single coordinated experience, explicitly
-- accepted before changing the current layout or native presentation.
M.Managed={revision=14,status="NOT_ACCEPTED",pendingResize=false}
local E,S=M.Managed,M.Safety
-- Dismissal is scope metadata, not an applied settings transaction. In
-- particular, it must not replace the user's profile, Undo or setup backup.
-- Raw, callback-free custody checks allow this data-only choice during combat.
local function dismissalStore(expected)
    local function plain(v) return type(v)=="table" and getmetatable(v)==nil end
    if not plain(M) or not rawequal(rawget(M,"Managed"),E) then return nil end
    local p,client,state=rawget(M,"Profiles"),rawget(M,"Client"),rawget(M,"state")
    local a,c=MirageUIDB,MirageUICharacterDB
    if not plain(p) or not plain(client) or not plain(state) or not plain(expected)
        or not plain(a) or not plain(c) or rawequal(a,c) then return nil end
    if rawget(p,"readOnly")~=false or rawget(state,"initialized")~=true or rawget(M,"applying")
        or not rawequal(rawget(M,"profile"),expected) or not rawequal(rawget(M,"db"),a) then return nil end
    for _,root in ipairs({a,c}) do local schema=rawget(root,"schema");if schema~=1 and schema~=2 then return nil end end
    local family=rawget(client,"family");local ac,cc=rawget(a,"clients"),rawget(c,"clients")
    if type(family)~="string" or not plain(ac) or not plain(cc) then return nil end
    local account,character=rawget(ac,family),rawget(cc,family)
    if not plain(account) or not plain(character) or rawequal(account,character)
        or not rawequal(rawget(p,"account"),account) or not rawequal(rawget(p,"character"),character) then return nil end
    local mode=rawget(character,"useCharacter")
    if mode~=nil and type(mode)~="boolean" then return nil end
    local store=mode and character or account
    if rawequal(store,expected) or not rawequal(rawget(store,"profile"),expected) then return nil end
    for _,owner in ipairs({a,c,ac,cc}) do if rawequal(store,owner) then return nil end end
    local marker=rawget(store,"managedSetupDismissed")
    if marker~=nil and type(marker)~="boolean" then return nil end
    return store
end
function E:Dismissed()
    if not rawequal(self,E) then return false end
    local store=dismissalStore(rawget(M,"profile"))
    return store and rawget(store,"managedSetupDismissed")==true or false
end
function E:DismissalToken(expected)
    if not rawequal(self,E) then return nil end
    local store=dismissalStore(expected);if not store then return nil end
    return {profile=expected,store=store,profiles=M.Profiles,client=M.Client,family=M.Client.family,
        account=MirageUIDB,character=MirageUICharacterDB,accountSchema=rawget(MirageUIDB,"schema"),characterSchema=rawget(MirageUICharacterDB,"schema")}
end
function E:Dismiss(token)
    if not rawequal(self,E) then return false,"Setup owner changed; no settings were changed." end
    local store=type(token)=="table" and getmetatable(token)==nil and dismissalStore(rawget(token,"profile")) or nil
    if not store or not rawequal(store,rawget(token,"store")) or not rawequal(M.Profiles,rawget(token,"profiles"))
        or not rawequal(M.Client,rawget(token,"client")) or M.Client.family~=rawget(token,"family")
        or not rawequal(MirageUIDB,rawget(token,"account")) or not rawequal(MirageUICharacterDB,rawget(token,"character"))
        or rawget(MirageUIDB,"schema")~=rawget(token,"accountSchema") or rawget(MirageUICharacterDB,"schema")~=rawget(token,"characterSchema") then
        return false,"Settings were left unchanged; setup dismissal could not be saved for this profile."
    end
    rawset(store,"managedSetupDismissed",true)
    return true
end
function E:Enabled()
    return M.profile and M.profile.managed==true and M.profile.enabled and M.Client.allowed and not M.state.safe
end
function E:Preflight()
    if S:InCombat() then return false,"Finish combat, then set up MirageUI." end
    local activation=M.Diagnostics:ActivationState()
    local explicitRetry=activation.code=="APPLY_FAILED" and M.Experience
        and M.Experience:MayRetrySetup()==true
    if activation.setupBlocked and not explicitRetry then return false,activation.help end
    if M.Native:Conflict() then return false,"Disable the other interface suite at character selection, then reload." end
    local w,h=M.AdaptiveLayout:Screen();if not w then return false,h end
    return true,w,h
end
function E:Build(pending)
    local ok,w,h=self:Preflight();if not ok then return nil,w end
    local p=M:Copy(M.profile)
    p.enabled=true;p.managed=true;p.autoLayout=true;p.managedDismissed=false
    p.onboarding=true;p.onboardingDismissed=false
    p.preset="Immersive";p.rules={};p.fade=.22;p.idle=0;p.movementHold=0;p.combatHold=0
    -- Modules are enabled together. Alternate presentations of the same fact
    -- are not all painted at once; native special controls remain authoritative.
    for _,cfg in pairs(p.modules) do cfg.enabled=true;cfg.visibility="Contextual";cfg.alpha=1;cfg.style=true end
    p.presentation=M.Presentation:Defaults()
    p.presentation.health="UnderCharacterHUD";p.presentation.resource="UnderCharacterHUD"
    p.presentation.cast="UnderCharacterHUD";p.presentation.gcd="Native"
    local hud=p.modules.UnderCharacterHUD
    -- Explicit managed setup adopts the approved public combat OR target mode.
    -- Profile loading and ordinary refits do not migrate a saved policy choice.
    hud.health=true;hud.resource=true;hud.cast=true;hud.policy=2;hud.layoutOrder=1;hud.layoutRevision=1;hud.rowPitch=14;hud.y=-math.floor(math.max(72,math.min(210,h*.13)))-40;hud.backdrop=0;hud.trackOpacity=76;hud.gap=4
    local n=p.modules.Nameplates
    n.cards=true;n.cardAuras=true;n.cardCast=true;n.cardPercent=true;n.panelOpacity=12
    n.cardWidth=220;n.cardIconSize=20;n.cardAuraCount=4;n.nameSize=12
    n.subtle=true;n.compact=true;n.extended=false;n.nameBacking=false
    for _,id in ipairs({"UnitFrames","PartyRaid"}) do
        local c=p.modules[id]
        c.panelOpacity=10;c.nativeAuras=true;c.showCast=true;c.showAuras=true;c.showBuffs=true
        c.showNames=true;c.showPower=true;c.showPercent=id=="UnitFrames";c.nameBacking=false
        c.auraSlots=id=="UnitFrames" and 4 or 2
    end
    p.modules.PartyRaid.compactRaid=true;p.modules.PartyRaid.nativeGroups=false
    -- Native action buttons retain paging, flyouts, overrides and existing keys.
    p.modules.ActionBars.contextual=true
    local r=p.modules.ResourceBars
    r.classResource=true;r.classSegments=true;r.runes=true;r.totems=true;r.empoweredStages=false
    -- Native aura data remains authoritative; the tracked cooldown row replaces
    -- the old separate viewers without changing action slots or native tracking.
    p.modules.Auras.playerPanel=false;p.modules.Auras.privateAuras=false
    p.modules.Cooldowns.tracker=false
    p.modules.Cooldowns.centralGroup=false;p.modules.Cooldowns.rowEnabled=true;p.modules.Cooldowns.rowFollowHUD=true
    p.modules.Cooldowns.rowVisibility=3;p.modules.Cooldowns.iconSize=50;p.modules.Cooldowns.gap=3
    p.modules.Cooldowns.showNumbers=true;p.modules.Cooldowns.ignoreGCD=false
    p.modules.QuestTracker.compactPanel=false
    p.b35Revision=1;p.modules.DataBars.showXP=false;p.modules.DataBars.showFPS=true;p.modules.DataBars.showCoordinates=true;p.modules.DataBars.showMoney=true
    n.customFriendlyPlayers=false;n.customFriendlyNPCs=false;n.customPets=true;n.customNeutral=true
    -- Ambient friendly names and titles stay in Blizzard's world renderer.
    -- A selected friend can use a single available native nameplate anchor.
    n.selectedFriendlyPlate=true
    n.friendlyVisibility=1;n.friendlyNPCVisibility=1;n.friendlyPetVisibility=1
    n.enemyPetVisibility=2;n.cardAuraCount=6;n.maximumDistance=60
    p.nameplateWorldNamesRevision=1;p.beta48Revision=1;p.beta49Revision=1
    p.modules.ActionBars.actionExperience=2;p.modules.ActionBars.interfaceScale=100
    p.modules.ActionBars.allowRearrange=true
    p.modules.UnitFrames.panelOpacity=12
    p.modules.Minimap.square=true;p.modules.QuestTracker.matchMinimap=true
    p.modules.Minimap.hideWhenQuiet=true;p.modules.Minimap.moveNative=false
    p.modules.Chat.hideWhenQuiet=true;p.modules.Chat.moveNative=false;p.modules.Chat.messageCue=true
    p.modules.QuestTracker.hideWhenQuiet=true;p.modules.QuestTracker.moveNative=false
    p.modules.Tooltips.fixedAnchor=false;p.modules.Tooltips.cursorAnchor=false
    p.modules.Bags.browser=true;p.modules.DamageMeters.summary=false
    p.modules.PvP.automaticLens=true;p.modules.PvP.contacts=false;p.modules.PvP.badge=false
    p.modules.TacticalSignals.legend=false
    -- Cursor Companion owns its separate profile and presentation.
    -- Explicit managed setup gets the same current defaults as an upgraded
    -- profile, including the supplied class-specific tracking order. Ordinary
    -- profile loading still uses the once-only revision marker.
    if M.Profiles and M.Profiles.RefineBeta51 then
        p.beta51Revision=0;M.Profiles.RefineBeta51(p)
    else p.beta51Revision=1 end
    if M.Profiles and M.Profiles.RefineBeta52 then
        p.beta52Revision=0;M.Profiles.RefineBeta52(p)
    else p.beta52Revision=1 end
    if M.Profiles and M.Profiles.RefineBeta57NativeNames then
        p.beta57NativeNamesRevision=0;M.Profiles.RefineBeta57NativeNames(p)
    else
        n.friendlyVisibility=1;n.friendlyNPCVisibility=1;n.friendlyPetVisibility=1
        n.customFriendlyPlayers=false;n.customFriendlyNPCs=false;p.beta57NativeNamesRevision=1
    end
    n.maximumDistance=0;n.plateDistanceRevision=1
    local good,why=M.AdaptiveLayout:ApplyTo(p,w,h)
    if not good then return nil,why end
    return p
end
function E:Accept(pending)
    local proposal,why=self:Build(pending);if not proposal then return false,why end
    local ready=M.Readiness:Inspect(proposal)
    if not ready.canFinish then
        for _,v in ipairs(ready.issues) do if v.blocking then return false,v.text end end
    end
    local store=M.Profiles.character.useCharacter and M.Profiles.character or M.Profiles.account
    local old=M:Copy(M.profile)
    local ok,reason=M.Profiles:Commit(proposal,nil,"SETUP")
    if not ok then return false,reason end
    -- One bounded snapshot, not an expanding history of profiles or identities.
    if not store.managedBackup then store.managedBackup=old end
    self.status="ACTIVE_CANDIDATE";self.pendingResize=false
    return true,"MirageUI is ready. Play normally; adjust appearance later in Settings."
end
function E:RestorePrevious()
    if S:InCombat() then return false,"Restore the previous setup after combat. /mirage safe stops MirageUI effects and returns native access as protected changes become legal." end
    if M.Profiles.readOnly or not M.Profiles.character or not M.Profiles.account then
        return false,"Your saved settings are preserved. Restore a compatible profile backup before changing them."
    end
    local store=M.Profiles.character.useCharacter and M.Profiles.character or M.Profiles.account
    if not store or not store.managedBackup then return false,"There is no automatic-setup backup for this profile." end
    local proposal=M:Copy(store.managedBackup)
    proposal.managed=false;proposal.managedDismissed=true
    local ok,why=M.Profiles:Commit(proposal)
    if ok then store.managedBackup=nil;self.status="RESTORED" end
    return ok,why or "Your previous MirageUI setup was restored."
end
function E:BuildRefit(input)
    if S:InCombat() then return nil,"Fit the layout after combat." end
    if M.Profiles.readOnly then return nil,"Your saved settings need recovery before changing the layout." end
    if not input or not input.managed then return nil,"Complete automatic setup first." end
    local p=M:Copy(input);p.autoLayout=true
    local w,h=M.AdaptiveLayout:Screen();if not w then return nil,h end
    local ok,why=M.AdaptiveLayout:ApplyTo(p,w,h);if not ok then return nil,why end
    return p
end
function E:BuildCooldownRefit(input,enabled)
    if type(enabled)~="boolean" then return nil,"Choose a central or standard refit." end
    if not input or not input.managed then return nil,"Complete automatic setup before staging a cooldown refit." end
    if enabled and input.modules.UnderCharacterHUD.layoutOrder~=2 and input.modules.UnderCharacterHUD.layoutRevision~=1 then
        return nil,"Choose reserved HUD geometry before the central cooldown refit."
    end
    local p=M:Copy(input);p.modules.Cooldowns.centralGroup=enabled
    return self:BuildRefit(p)
end
function E:Refit()
    local p,why=self:BuildRefit(M.profile);if not p then return false,why end
    return M.Profiles:Commit(p)
end
-- The native 70938 PixelUtil converts physical pixels into a 768-unit
-- canvas BEFORE applying a frame's effective scale. UIParent dimensions are
-- local UI units, not pixels. Native UIParentUtil may also inset its TOPLEFT
-- for a notch/debug bar, so only observed screen anchors describe its bounds.
local viewportLimit=131072
local function sameNumber(a,b,epsilon)
    return a==nil and b==nil or S:Number(a) and S:Number(b) and math.abs(a-b)<epsilon
end
local function sameViewport(a,b)
    if not a or not b or a.anchorMode~=b.anchorMode then return false end
    for _,key in ipairs({"width","height","physicalWidth","physicalHeight","leftInset","rightInset","topInset","bottomInset"}) do
        if not sameNumber(a[key],b[key],.01) then return false end
    end
    return sameNumber(a.scale,b.scale,.00001)
end
local function dimension(v) return S:Number(v) and v>0 and v<=viewportLimit end
local function publicNumber(fn,object)
    local v,status=S:Public(fn,"number",object)
    if status=="KNOWN" and S:Number(v) then return v end
end
local function readScreenAnchors(row)
    if type(UIParent.GetNumPoints)~="function" or type(UIParent.GetPoint)~="function" then
        row.anchorMode="LOGICAL_ONLY";return true
    end
    local n=publicNumber(UIParent.GetNumPoints,UIParent)
    if not n or n<0 or n>8 or n%1~=0 then return false end
    local left,top,right,bottom
    local screenOnly=true
    for i=1,n do
        local ok,point,relative,relativePoint,x,y=pcall(UIParent.GetPoint,UIParent,i)
        if not ok or not S:Text(point) or not S:Readable(relative) or not S:Text(relativePoint)
            or not S:Number(x) or not S:Number(y) or math.abs(x)>viewportLimit or math.abs(y)>viewportLimit then return false end
        -- UIParentUtil uses SetPoint("TOPLEFT",0,-topOffset), relative to
        -- the native screen. Other ancestry is not evidence of screen bounds.
        if relative~=nil or point~=relativePoint then screenOnly=false
        elseif point=="TOPLEFT" then left,top=x,-y
        elseif point=="BOTTOMRIGHT" then right,bottom=-x,y
        else screenOnly=false end
    end
    if screenOnly and left~=nil and right~=nil then
        row.anchorMode="SCREEN_ANCHORS"
        row.leftInset,row.rightInset,row.topInset,row.bottomInset=left,right,top,bottom
    else row.anchorMode="LOGICAL_ONLY" end
    return true
end
local function readViewportOnce()
    local row={}
    row.width=publicNumber(UIParent.GetWidth,UIParent)
    row.height=publicNumber(UIParent.GetHeight,UIParent)
    row.scale=publicNumber(UIParent.GetEffectiveScale,UIParent)
    if not dimension(row.width) or not dimension(row.height) or not row.scale or row.scale<.1 or row.scale>8 then
        return nil,"VIEWPORT_UNAVAILABLE",row
    end
    if not readScreenAnchors(row) then return nil,"VIEWPORT_ANCHORS_UNAVAILABLE",row end
    if type(GetPhysicalScreenSize)=="function" then
        local ok,x,y=pcall(GetPhysicalScreenSize)
        if S:Number(x) then row.physicalWidth=x end
        if S:Number(y) then row.physicalHeight=y end
        if not ok or not dimension(x) or not dimension(y) then return nil,"PHYSICAL_VIEWPORT_UNAVAILABLE",row end
        -- Exact pinned native formula, independent of render scale or DPI.
        row.pixelToUI=768/y
        if row.anchorMode=="SCREEN_ANCHORS" then
            row.expectedWidth=x*row.pixelToUI/row.scale-row.leftInset-row.rightInset
            row.expectedHeight=768/row.scale-row.topInset-row.bottomInset
            if not dimension(row.expectedWidth) or not dimension(row.expectedHeight) then return nil,"VIEWPORT_ANCHORS_UNAVAILABLE",row end
            local errorX=math.abs(row.width-row.expectedWidth)*row.scale/row.pixelToUI
            local errorY=math.abs(row.height-row.expectedHeight)*row.scale/row.pixelToUI
            if errorX>math.max(2,x*.002) or errorY>math.max(2,y*.002) then return nil,"VIEWPORT_CANVAS_SETTLING",row end
        end
    else
        -- An absent optional physical-size API cannot establish a conversion.
        -- Retain bounded public logical observations; never invent pixel data.
        row.anchorMode="LOGICAL_ONLY"
    end
    return row,nil,row
end
function E:ReadViewport()
    self.viewportReads=(self.viewportReads or 0)+1
    local first,why,observed=readViewportOnce()
    self.viewportObserved=observed
    if first then
        -- Catch callbacks whose getters straddle a native update. Temporal
        -- settlement below additionally rejects short-lived coherent changes.
        local second,reason,last=readViewportOnce()
        self.viewportObserved=last
        if not second then first=nil;why=reason
        elseif not sameViewport(first,second) then first=nil;why="VIEWPORT_READ_CHANGED"
        else first=second end
    end
    self.viewportRejection=why
    if why then self.viewportRejected=(self.viewportRejected or 0)+1;self.viewportLastRejection=why end
    return first,why
end
function E:Viewport()
    local row=self.viewportStable
    if not row and not self.pendingResize then self:Resize() end
    if row then return row.width,row.height,row.scale end
end
function E:Resize(observed)
    self.pendingResize=true;self.viewportCandidate=nil;self.viewportSamples=0
    self.viewportAllowDebtRetry=observed~=true
    self.viewportEvents=(self.viewportEvents or 0)+1
    if observed then self.viewportDetections=(self.viewportDetections or 0)+1
    else self.viewportNotifyAttempts=0;self.viewportNotifyDue=0 end
    self.viewportDue=S:Now()+.10;self.viewportStatus="VIEWPORT_SETTLING"
end
local function viewportWritable()
    return M.profile and M.profile.enabled~=false and M.state and M.state.initialized and M.state.world and not M.state.safe
end
function E:NotifyViewportReady(now)
    if not self.viewportNotifyPending or not S:Number(now) or now<(self.viewportNotifyDue or 0) then return end
    self.viewportNotifyDue=now+.25
    if not viewportWritable() then self.viewportWakeStatus="SUSPENDED";return end
    if (self.viewportNotifyAttempts or 0)>=3 then self.viewportWakeStatus="RETRY_LIMIT";return end
    if S:InCombat() then self.viewportWakeStatus="COMBAT_DEFERRED";return end
    if M.Rework and M.Rework.NativeEditState and M.Rework:NativeEditState()~="CLOSED" then self.viewportWakeStatus="EDITOR_DEFERRED";return end
    local rework=M.Rework
    if not rework or type(rework.ResumeViewportPending)~="function" then self.viewportWakeStatus="UNAVAILABLE";return end
    local generation=self.viewportGeneration
    self.viewportNotifyAttempts=(self.viewportNotifyAttempts or 0)+1
    local ok,complete=pcall(rework.ResumeViewportPending,rework,generation)
    if not ok or complete==false then self.viewportWakeStatus="RETRY_PENDING";return end
    -- A callback can queue work, but cannot acknowledge a later publication.
    if self.viewportGeneration==generation then
        self.viewportNotifyPending=nil;self.viewportNotifiedGeneration=generation
        self.viewportWakes=(self.viewportWakes or 0)+1;self.viewportWakeStatus="QUEUED"
    end
end
function E:ProfileApplied(fitted)
    if fitted==false then self.viewportApplyFailed=true;self.viewportStatus="VIEWPORT_REFIT_PENDING";return end
    self.viewportApplied=self.viewportStable;self.viewportApplyFailed=nil
end
function E:ApplyViewport()
    if S:InCombat() or not viewportWritable() then self.viewportApplyFailed=true;return false end
    self.viewportRefreshes=(self.viewportRefreshes or 0)+1
    local profile=M.profile
    local typography=M.UnitTypography
    local typographyStarted=false
    local refitFailed=false
    local stage="PRECHECK"
    local failureEvidence
    local function captureFailure(failedPhase)
        if not failureEvidence then
            failureEvidence={origin="VIEWPORT",phase=failedPhase,locations="SOURCE_LOCATIONS_UNAVAILABLE"}
            local incidents=M.Incidents
            if incidents and type(incidents.CaptureFailure)=="function" then
                local good,evidence=pcall(incidents.CaptureFailure,incidents,"VIEWPORT",failedPhase)
                if good and type(evidence)=="table" then failureEvidence=evidence end
            end
        end
        return false
    end
    local ok=xpcall(function()
        if typography then stage="TYPOGRAPHY_BEGIN";typography:Invalidate("VIEWPORT");typographyStarted=true;typography:Begin("VIEWPORT") end
        -- A settled geometry refresh preserves provider generations, native
        -- leases, action assignments, profile choices and visibility state.
        if self:Enabled() and profile.autoLayout and M.AdaptiveLayout then
            stage="ADAPTIVE_LAYOUT"
            local refreshed,detail=M.AdaptiveLayout:Refresh(profile)
            -- false,nil means an unchanged plan. An explicit failure reason
            -- means the new viewport could not fit the automatic layout.
            if refreshed==false and detail~=nil then refitFailed=true;return end
        end
        stage="LAYOUT"
        if M.profile~=profile then error("VIEWPORT_OWNER_CHANGED",0) end
        if M.Layout then M.Layout:ApplyAll() end
        stage="MANAGED_CONFIGURE"
        if M.ManagedNative and self:Enabled() then M.ManagedNative.reconcilePending=true end
        stage="PRESENTATION"
        M.state.forceEvaluate=true
    end,function() return captureFailure(stage) end)
    if typographyStarted then
        local finished=xpcall(function() return typography:End() end,function() return captureFailure("TYPOGRAPHY_END") end)
        ok=ok and finished
    end
    local applied=ok and not refitFailed
    self.viewportStatus=not ok and "VIEWPORT_LAYOUT_FAILED" or refitFailed and "VIEWPORT_REFIT_PENDING" or "VIEWPORT_READY"
    self.viewportApplyFailed=not applied or nil
    if applied then self.viewportApplied=self.viewportStable end
    if not ok then M:Fault("Core","VIEWPORT_LAYOUT_FAILED",failureEvidence) end
    return applied
end
function E:TickViewport(now)
    if not S:Number(now) then return end
    if not viewportWritable() then
        if self.pendingResize then self.viewportStatus="VIEWPORT_SUSPENDED" end
        if self.viewportNotifyPending then self.viewportWakeStatus="SUSPENDED" end
        return
    end
    if not self.pendingResize then
        self:NotifyViewportReady(now)
        -- Native anchor/scale changes need not dispatch a display event. One
        -- bounded read per second detects them; an unchanged sample performs
        -- no geometry work and never spends retained layout failure retries.
        if not self.viewportStable or now<(self.viewportWatchDue or 0) then return end
        self.viewportWatchDue=now+1
        local sample=self:ReadViewport()
        if sameViewport(sample,self.viewportStable) then return end
        self:Resize(true)
    end
    if now<(self.viewportDue or 0) then return end
    self.viewportDue=now+.10
    local sample,why=self:ReadViewport()
    if not sample then
        self.viewportStatus=why;self.viewportCandidate=nil;self.viewportSamples=0;return
    end
    if sameViewport(sample,self.viewportStable) then
        if self.viewportApplyFailed and self.viewportAllowDebtRetry then
            -- Measurement settlement is not proof of a successful layout.
            -- A later resize notification retries retained application debt
            -- once; a failed attempt never loops on every rendered frame.
            if S:InCombat() then self.viewportStatus="VIEWPORT_COMBAT_DEFERRED";return end
            if M.Rework and M.Rework.NativeEditState and M.Rework:NativeEditState()~="CLOSED" then self.viewportStatus="VIEWPORT_EDITOR_DEFERRED";return end
            self.pendingResize=false;self.viewportCandidate=nil;self.viewportSamples=0;self:ApplyViewport();self:NotifyViewportReady(now);return
        end
        -- A normal alt-tab returned to the original geometry. No refit,
        -- profile apply, provider retirement or scale multiplication is due.
        self.pendingResize=false;self.viewportCandidate=nil;self.viewportSamples=0;self.viewportStatus=self.viewportApplyFailed and "VIEWPORT_REFIT_PENDING" or "VIEWPORT_UNCHANGED"
        self.viewportUnchanged=(self.viewportUnchanged or 0)+1;self:NotifyViewportReady(now);return
    end
    if not sameViewport(sample,self.viewportCandidate) or now<(self.viewportSince or now) then
        self.viewportCandidate=sample;self.viewportSince=now;self.viewportSamples=1;self.viewportStatus="VIEWPORT_SETTLING";return
    end
    self.viewportSamples=self.viewportSamples+1
    if self.viewportSamples<3 or now-self.viewportSince<.35 then return end
    if S:InCombat() then self.viewportStatus="VIEWPORT_COMBAT_DEFERRED";return end
    if M.Rework and M.Rework.NativeEditState and M.Rework:NativeEditState()~="CLOSED" then
        self.viewportStatus="VIEWPORT_EDITOR_DEFERRED";return
    end
    self.viewportStable=sample;self.pendingResize=false;self.viewportCandidate=nil;self.viewportSamples=0
    self.viewportGeneration=(self.viewportGeneration or 0)+1
    self.viewportNotifyPending=true;self.viewportNotifyDue=now;self.viewportNotifyAttempts=0;self.viewportWatchDue=now+1
    self:ApplyViewport()
    -- First publication wakes startup-deferred providers too. Each provider
    -- consumes its own generation once; refit failure never blocks healthy rows.
    self:NotifyViewportReady(now)
end
local viewportStatuses={INITIAL=true,VIEWPORT_SETTLING=true,VIEWPORT_SUSPENDED=true,VIEWPORT_UNAVAILABLE=true,
    VIEWPORT_ANCHORS_UNAVAILABLE=true,PHYSICAL_VIEWPORT_UNAVAILABLE=true,VIEWPORT_CANVAS_SETTLING=true,
    VIEWPORT_READ_CHANGED=true,VIEWPORT_COMBAT_DEFERRED=true,VIEWPORT_EDITOR_DEFERRED=true,
    VIEWPORT_UNCHANGED=true,VIEWPORT_LAYOUT_FAILED=true,VIEWPORT_REFIT_PENDING=true,VIEWPORT_READY=true}
local function viewportNumber(value,digits)
    if not S:Number(value) or math.abs(value)>viewportLimit then return "UNAVAILABLE" end
    return string.format("%."..(digits or 3).."f",value)
end
local function viewportCount(value)
    if not S:Number(value) or value<0 or value%1~=0 then return "0" end
    return string.format("%.0f",math.min(value,1000000000))
end
local function viewportStatus(value)
    return type(value)=="string" and viewportStatuses[value] and value or "UNAVAILABLE"
end
local function viewportRow(row)
    row=type(row)=="table" and row or {}
    local mode=row.anchorMode=="SCREEN_ANCHORS" and "SCREEN_ANCHORS" or row.anchorMode=="LOGICAL_ONLY" and "LOGICAL_ONLY" or "UNAVAILABLE"
    return "ui="..viewportNumber(row.width).."x"..viewportNumber(row.height).."; effective_scale="..viewportNumber(row.scale,6)..
        "; physical="..viewportNumber(row.physicalWidth).."x"..viewportNumber(row.physicalHeight)..
        "; pixel_to_ui="..viewportNumber(row.pixelToUI,8).."; bounds="..mode..
        "; insets="..viewportNumber(row.leftInset)..","..viewportNumber(row.rightInset)..","..viewportNumber(row.topInset)..","..viewportNumber(row.bottomInset)..
        "; expected_ui="..viewportNumber(row.expectedWidth).."x"..viewportNumber(row.expectedHeight)
end
function E:ViewportReport()
    -- Captured public observations only. Export never probes native dimensions,
    -- starts a measurement, retries a provider, or performs any layout write.
    local wake=self.viewportWakeStatus
    if wake~="COMBAT_DEFERRED" and wake~="EDITOR_DEFERRED" and wake~="UNAVAILABLE" and wake~="RETRY_PENDING" and wake~="RETRY_LIMIT" and wake~="SUSPENDED" and wake~="QUEUED" then wake="INITIAL" end
    return "viewport_status="..viewportStatus(self.viewportStatus or "INITIAL").."; generation="..viewportCount(self.viewportGeneration)..
        "; pending="..tostring(self.pendingResize==true).."; apply_debt="..tostring(self.viewportApplyFailed==true)..
        "; wake_debt="..tostring(self.viewportNotifyPending==true).."; wake="..wake..
        "\nviewport_counts=requests:"..viewportCount(self.viewportEvents).."; reads:"..viewportCount(self.viewportReads)..
        "; rejected:"..viewportCount(self.viewportRejected).."; samples:"..viewportCount(self.viewportSamples)..
        "; detections:"..viewportCount(self.viewportDetections).."; wake_attempts:"..viewportCount(self.viewportNotifyAttempts).."; refreshes:"..viewportCount(self.viewportRefreshes).."; unchanged:"..viewportCount(self.viewportUnchanged).."; wakes:"..viewportCount(self.viewportWakes)..
        "\nviewport_observed="..viewportRow(self.viewportObserved)..
        "\nviewport_stable="..viewportRow(self.viewportStable)..
        "\nviewport_rejection="..viewportStatus(self.viewportRejection).."; last="..viewportStatus(self.viewportLastRejection)
end
function E:Report()
    local mode=self:Enabled() and "AUTOMATIC" or "UNCHANGED"
    return "MIRAGE_MANAGED=1\nmode="..mode.."\nlayout="..(M.profile.autoLayout and "AUTOMATIC" or "CUSTOM")..
        "\nbackground_opacity="..tostring(M.profile.modules.Nameplates.panelOpacity)..
        "\nviewport="..(self.viewportStatus or "INITIAL").."; requests="..(self.viewportEvents or 0).."; refreshes="..(self.viewportRefreshes or 0).."; unchanged="..(self.viewportUnchanged or 0).."; pending="..tostring(self.pendingResize==true).."; apply_debt="..tostring(self.viewportApplyFailed==true)..
        "\n"..(M.ManagedNative and M.ManagedNative:Report() or "native=NOT_STARTED")
end
