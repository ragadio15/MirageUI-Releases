local _,M=...
M.Rework=M.Rework or {}
local R,S=M.Rework,M.Safety
local N={status="NOT_INITIALIZED",monitors=setmetatable({},{__mode="k"}),events={
 PLAYER_REGEN_ENABLED=true,PLAYER_ENTERING_WORLD=true,LOADING_SCREEN_DISABLED=true,ADDON_LOADED=true,EDIT_MODE_LAYOUTS_UPDATED=true,
 ZONE_CHANGED=true,ZONE_CHANGED_INDOORS=true,ZONE_CHANGED_NEW_AREA=true,MINIMAP_UPDATE_ZOOM=true,MINIMAP_UPDATE_TRACKING=true,DIEL_CYCLE_CHANGED=true,CVAR_UPDATE=true,DISPLAY_SIZE_CHANGED=true,UI_SCALE_CHANGED=true}}
R.Minimap=N
local squareMask="Interface\\AddOns\\MirageUI\\Media\\SquareMask.tga"
local roundMask="ui-hud-minimap-frame-generic-mask"
local white="Interface\\Buttons\\WHITE8X8"
local utilityRecoveryLimit=4
local blobRingKinds={"Quest","Arch","Task"}
local blobRingRetryLimit=3
local function field(o,k)
 if not S:Frame(o,false) then return nil end
 local ok,v=pcall(function() return o[k] end)
 if ok and S:Readable(v) then return v end
end
local function call(o,k,...)
 local fn=R.NativeMethod and R.NativeMethod(o,k) or field(o,k);if type(fn)~="function" then return false end
 return pcall(fn,o,...)
end
local function write(o,k,...)
 local ok,result=call(o,k,...)
 return ok and result~=false
end
local function value(o,k,kind,...)
 return S:Public(field(o,k),kind,o,...)
end
-- Utility navigation reads the actual chrome regions instead of guessing a
-- fixed inset. These are read-only references; terrain pins are not obstacles.
function N:GetNavigationObstacles(map)
 if not self.active or not self.record or self.record.map~=map or map~=_G.Minimap then return nil end
 local regions={}
 if self.header then regions[#regions+1]=self.header end
 -- The toolbar background is transparent. Reserve the actual buttons so a
 -- southbound route can use the open terrain between left and right controls.
 local controls=0
 for _,key in ipairs({"settingsButton","mapButton","zoomOut","zoomIn"}) do
  if self[key] then regions[#regions+1]=self[key];controls=controls+1 end
 end
 -- A partially prepared/legacy owner with no button references stays
 -- conservative until its explicit control envelopes are available.
 if controls==0 and self.toolbar then regions[#regions+1]=self.toolbar end
 -- Native utilities can wrap above the toolbar on a narrow layout. Reserve
 -- only their admitted slot envelopes while the corresponding control is
 -- actually visible; never scan arbitrary child map/gather pins.
 local slots={}
 for key,slot in pairs(self.utilitySlots or {}) do
  local row=self.record.utilities and self.record.utilities[key]
  if row and row.written and not row.displaced and row.owner and row.owner.active
   and value(row.object,"IsVisible","boolean")==true then slots[#slots+1]={key=key,region=slot} end
 end
 table.sort(slots,function(a,b)return a.key<b.key end)
 for _,entry in ipairs(slots) do regions[#regions+1]=entry.region end
 -- The AddOns menu can clamp upward over the terrain on short displays.
 if M.SuiteLauncher and M.SuiteLauncher.frame then regions[#regions+1]=M.SuiteLauncher.frame end
 return regions
end
local function screen()
 if M.Layout and M.Layout.Screen then return M.Layout:Screen() end
 if M.Managed and M.Managed.Viewport then return M.Managed:Viewport() end
 return value(UIParent,"GetWidth","number"),value(UIParent,"GetHeight","number")
end
local function legal(o)
 if not S:Frame(o,false) then return false end
 if not S:InCombat() then return true end
 local protected,state=value(o,"IsProtected","boolean")
 return state=="KNOWN" and not protected
end
local function points(o)
 local n,state=value(o,"GetNumPoints","number")
 if state~="KNOWN" or n<0 or n>8 or n%1~=0 then return nil end
 local out={}
 for i=1,n do
  local ok,p,to,rp,x,y=call(o,"GetPoint",i)
  if not ok or not S:Text(p) or not S:Readable(to) or not S:Text(rp) or not S:Number(x) or not S:Number(y) then return nil end
  out[#out+1]={p,to,rp,x,y}
 end
 return out
end
local function putPoints(o,list)
 if not write(o,"ClearAllPoints") then return false end
 for _,p in ipairs(list) do if not write(o,"SetPoint",unpack(p)) then return false end end
 return true
end
local function near(a,b) return S:Number(a) and S:Number(b) and math.abs(a-b)<.001 end
local function samePoints(a,b)
 if not a or not b or #a~=#b then return false end
 for i=1,#a do
  for j=1,5 do
   if j>=4 then if not near(a[i][j],b[i][j]) then return false end
   elseif a[i][j]~=b[i][j] then return false end
  end
 end
 return true
end
local function eligible() return R:Qualified() and R:Selected("minimap",M.profile) and not M.state.safe end
local function wanted() return eligible() and not R:NativeEditing() end
local function healthResult(self)
 -- Layout/sidebar callbacks may recover or fail an auxiliary outside Tick.
 -- Compare against the last returned health result, not a status snapshot at
 -- Tick entry, so the registry receives that edge on its normal .25s cadence.
 self.reportedStatus=self.status
 if self.status=="OWNED_CUSTOM_CANVAS_ART_PENDING" then return R:Result("PARTIAL","MINIMAP_AUXILIARY_PARTIAL","Minimap") end
 return true,self.status
end
function N:Failure(why,stage)
 -- Fixed, public reason tokens survive Configure -> Foundation -> Suspend.
 -- A failed native property must never collapse into PROVIDER_UNAVAILABLE.
 self.status=why;self.lastFailure=why;self.failureStage=stage or "ACQUIRE"
 return false,why
end
function N:AbortCanvas(why,stage)
 self.writing=nil
 self.lastFailure=why;self.failureStage=stage
 local restored=self:Suspend(why)
 self.rollbackStatus=restored and "VERIFIED" or "PENDING"
 if restored then self.status=why end
 return false,why
end
local function text(parent,size)
 local f=M.UI:Text(parent,"",0,0,size);f:ClearAllPoints();f.mirageSemanticColor=true
 f:SetTextColor(.90,.89,.87,1);f:SetJustifyH("LEFT");f:SetHeight(size+4)
 if f.SetShadowColor then f:SetShadowColor(0,0,0,.9) end
 if f.SetShadowOffset then f:SetShadowOffset(1,-1) end
 if f.SetWordWrap then f:SetWordWrap(false) end
 if f.SetMaxLines then f:SetMaxLines(1) end
 return f
end
local function button(parent,label,width,handler)
 local f=CreateFrame("Button",nil,parent,"BackdropTemplate");f:SetSize(width,20)
 f:SetBackdrop({bgFile=white,edgeFile=white,edgeSize=1});f:SetBackdropColor(.060,.060,.065,.97);f:SetBackdropBorderColor(.26,.26,.26,1)
 f.label=text(f,11);f.label:SetAllPoints();f.label:SetJustifyH("CENTER");f.label:SetJustifyV("MIDDLE");f.label:SetText(label)
 f:SetScript("OnClick",handler);f:RegisterForClicks("LeftButtonUp")
 f:SetScript("OnEnter",function()
  f:SetBackdropBorderColor(.91,.55,.18,1);if N.surface then M.CVE:Hold(N.surface,.4) end
  if f.tooltip and _G.GameTooltip then
   call(GameTooltip,"SetOwner",f,"ANCHOR_LEFT");call(GameTooltip,"SetText",f.tooltip);call(GameTooltip,"Show")
  end
 end)
 f:SetScript("OnLeave",function()
  f:SetBackdropBorderColor(.26,.26,.26,1)
  if _G.GameTooltip and value(GameTooltip,"GetOwner")==f then call(GameTooltip,"Hide") end
 end)
 return f
end
function N:Initialize()
 if self.surface then return true end
 if S:InCombat() then return self:Failure("SETUP_COMBAT_DEFERRED","SETUP") end
 if not R:Qualified() then return self:Failure("UNQUALIFIED_CLIENT","SETUP") end
 if not screen() then self.viewportPending=true;self.status="VIEWPORT_PENDING";return false,self.status end
 self.viewportPending=nil
 local f=CreateFrame("Frame","MirageUIReworkMinimap",UIParent,"BackdropTemplate");self.frame=f
 f:SetSize(225,225);f:SetClampedToScreen(true);S:Passive(f)
 f:SetBackdrop({bgFile=white,edgeFile=white,edgeSize=1});f:SetBackdropColor(.035,.035,.038,.96);f:SetBackdropBorderColor(.91,.55,.18,.9)
 -- Status and compact controls overlay the square terrain. Only individual
 -- buttons accept input; the surrounding overlay is passive and transparent.
 -- Native click, wheel and ping handlers stay on the adopted map.
 local overlay=CreateFrame("Frame",nil,f);self.overlay=overlay
 overlay:SetAllPoints(f);S:Passive(overlay)
 self.header=overlay:CreateTexture(nil,"BACKGROUND");self.header:SetColorTexture(.035,.035,.038,.36)
 self.header:SetPoint("TOPLEFT",1,-1);self.header:SetPoint("TOPRIGHT",-1,-1);self.header:SetHeight(26)
 self.toolbar=CreateFrame("Frame",nil,overlay);S:Passive(self.toolbar)
 self.toolbar:SetPoint("BOTTOMLEFT",1,1);self.toolbar:SetPoint("BOTTOMRIGHT",-1,1);self.toolbar:SetHeight(28)
 self.toolbarFill=self.toolbar:CreateTexture(nil,"BACKGROUND");self.toolbarFill:SetAllPoints();self.toolbarFill:SetColorTexture(.035,.035,.038,0);self.toolbarFill:Hide()
 self.location=text(overlay,12)
 self.navigationInfo=text(overlay,10);self.navigationInfo:SetTextColor(.77,.78,.78,1)
 -- Intrinsic text measurement must not inherit the distance label's previous
 -- width: GetStringWidth may otherwise describe its already ellipsized text.
 self.navigationMeasure=text(overlay,10);self.navigationMeasure:Hide()
 self.navigationArrow=overlay:CreateTexture(nil,"ARTWORK")
 self.navigationArrow:SetTexture("Interface\\AddOns\\MirageUI\\Media\\MirageUIBadge.tga")
 for _,label in ipairs({self.location,self.navigationInfo}) do
  if label.SetShadowColor then label:SetShadowColor(0,0,0,1) end
  if label.SetShadowOffset then label:SetShadowOffset(1,-1) end
  if label.SetWordWrap then label:SetWordWrap(false) end
  if label.SetJustifyV then label:SetJustifyV("MIDDLE") end
 end
 self.settingsButton=button(overlay,"",20,function() if type(M.LoadOptions)=="function" then M:LoadOptions() end end)
 self.settingsButton.tooltip="MirageUI AddOns — right click for settings"
 self.settingsButton.icon=self.settingsButton:CreateTexture(nil,"ARTWORK")
 self.settingsButton.icon:SetTexture("Interface\\AddOns\\MirageUI\\Media\\MirageUIBadge.tga")
 self.settingsButton.icon:SetPoint("TOPLEFT",2,-2);self.settingsButton.icon:SetPoint("BOTTOMRIGHT",-2,2)
 self.settingsButton:SetPoint("BOTTOMLEFT",7,5)
 if M.SuiteLauncher then M.SuiteLauncher:BindButton(self.settingsButton) end
 self.mapButton=button(overlay,"",20,function() if type(ToggleWorldMap)=="function" then ToggleWorldMap() end end)
 self.mapButton.tooltip=_G.WORLD_MAP or "World map"
 -- A tiny folded-map pictogram uses the known white primitive, avoiding
 -- locale-specific glyph support or an unverified external icon atlas.
 self.mapButton.icon={}
 for i=1,3 do
  local piece=self.mapButton:CreateTexture(nil,"ARTWORK");piece:SetColorTexture(.91,.91,.79,i==2 and .68 or 1)
  piece:SetSize(4,11);piece:SetPoint("CENTER",self.mapButton,"CENTER",(i-2)*4,i==2 and -1 or 1)
  self.mapButton.icon[i]=piece
 end
 self.mapButton:SetPoint("BOTTOMLEFT",31,5)
 local function zoom(delta)
  local map=N.record and N.record.map;if not map or not N.active then return end
  local current,cs=value(map,"GetZoom","number");local levels,ls=value(map,"GetZoomLevels","number")
  if cs=="KNOWN" and ls=="KNOWN" then call(map,"SetZoom",math.max(0,math.min(levels-1,current+delta))) end
 end
 self.zoomOut=button(overlay,"−",22,function() zoom(-1) end);self.zoomOut:SetPoint("BOTTOMRIGHT",-33,5)
 self.zoomIn=button(overlay,"+",22,function() zoom(1) end);self.zoomIn:SetPoint("BOTTOMRIGHT",-7,5)
 self.zoomOut.tooltip=_G.ZOOM_OUT or "Zoom out";self.zoomIn.tooltip=_G.ZOOM_IN or "Zoom in"
 f:Hide()
 local surface={id="Minimap.nativePosition",layoutID="Minimap.nativePosition",module="Minimap",frame=f,editable=true,
  groups={navigation=true},fallback="PRESERVE",security="SECURE_PREDECLARED",minWidth=195,minHeight=195,
  layout={x=.39,y=.29,width=225,height=225,scale=1},reworkProvider=self}
 self.surface=surface;M.CVE:Register(surface)
 surface.desired=nil -- the first contextual decision owns the first reveal
 local applied,why=M.Layout:Apply(surface)
 if applied==false then
  if why=="VIEWPORT_PENDING" then self.viewportPending=true;self.status=why;return false,why end
  return self:Failure(why or "MAP_SURFACE_LAYOUT_FAILED","SURFACE")
 end
 self.status="READY";return true
end
function N:ResolveLayout(surface,profile)
 return M.Layout:Get(surface or self.surface,profile or M.profile)
end
function N:OwnsSettingsLauncher()
 local r,frame,overlay,button,profile=self.record,self.frame,self.overlay,self.settingsButton,M.profile
 if self.active~=true or not r or not r.canvasCommitted or r.conflict or not wanted() or _G.Minimap~=r.map then return false end
 local mapParent=value(r.map,"GetParent")
 local buttonParent=value(button,"GetParent");local overlayParent=value(overlay,"GetParent")
 return mapParent==frame and buttonParent==overlay and overlayParent==frame and self.active==true
  and self.record==r and self.frame==frame and self.overlay==overlay and self.settingsButton==button
  and M.profile==profile and not M.state.safe and not r.conflict and _G.Minimap==r.map
end
function N:ApplyLayout(surface)
 if surface~=self.surface or not self.frame then return false,"SURFACE_UNAVAILABLE" end
 if S:InCombat() then surface.layoutPending=true;return false,"LAYOUT_COMBAT_DEFERRED" end
 local width,height=screen()
 if not width then surface.layoutPending=true;self.viewportPending=true;self.status="VIEWPORT_PENDING";return false,self.status end
 self.viewportPending=nil
 local profile,frame,record,active=M.profile,self.frame,self.record,self.active
 local transaction={};self.layoutTransaction=transaction
 local function current()
  return self.layoutTransaction==transaction and self.surface==surface and self.frame==frame
   and self.record==record and self.active==active and M.profile==profile and not S:InCombat()
 end
 local layout=self:ResolveLayout(surface);local scale=layout.scale or 1
 if not current() then return false,"MAP_LAYOUT_SUPERSEDED" end
 if not width or not height then return false,"SCREEN_GEOMETRY_UNAVAILABLE" end
 frame:SetSize(layout.width,layout.height);if not current() then return false,"MAP_LAYOUT_SUPERSEDED" end
 frame:SetScale(scale);if not current() then return false,"MAP_LAYOUT_SUPERSEDED" end
 frame:ClearAllPoints();if not current() then return false,"MAP_LAYOUT_SUPERSEDED" end
 frame:SetPoint("CENTER",UIParent,"CENTER",layout.x*width/scale,layout.y*height/scale)
 if not current() then return false,"MAP_LAYOUT_SUPERSEDED" end
 self.layout=layout
 local ok,why=true
 if self.active then ok,why=self:LayoutCanvas() end
 if not ok then return false,why or self.status end
 if not current() then return false,"MAP_LAYOUT_SUPERSEDED" end
 surface.layoutPending=not ok or nil
 if M.SidebarLayout then M.SidebarLayout:RefreshFollowers() end
 if not current() then return false,"MAP_LAYOUT_SUPERSEDED" end
 return ok,ok and "SIDEBAR_LAYOUT_APPLIED" or self.status
end
function N:Watch(o)
 if self.monitors[o] then return true end
 if type(hooksecurefunc)~="function" then return false end
 local monitor={};self.monitors[o]=monitor
 for _,k in ipairs({"SetParent","SetPoint","SetSize","SetWidth","SetHeight","SetScale","SetAlpha","Show","Hide","SetShown","SetMaskTexture","SetFrameLevel","SetFrameStrata","EnableMouse"}) do
  if type(field(o,k))=="function" then
   local ok=pcall(hooksecurefunc,o,k,function(object,new)
    local r=N.record
    if not r then return end
    -- A different setter can run inside one of our geometry callbacks. Even
    -- during a layout/restore, a foreign mask takes precedence on handback.
    if object==r.map and k=="SetMaskTexture" then
     if not S:Readable(new) or new~=r.mask and new~=r.originalMask then
      r.maskDisplaced=true;r.conflict="EXTERNAL_MASK_CHANGE"
     elseif N.active and new~=r.mask then
      N.maskDirty=true;r.nativeMaskResets=(r.nativeMaskResets or 0)+1
     end
     return
    end
    if N.writing then return end
    if object==r.map then
     if N.active and (k=="SetAlpha" or k=="Show" or k=="Hide" or k=="SetShown") then
      r.terrainDirty=true;r.terrainCause=k
     end
     if k=="SetParent" and S:Readable(new) and new~=N.frame and new~=r.parent then r.conflict="EXTERNAL_PARENT_CHANGE" end
     if N.active and (k=="SetParent" or k=="SetPoint" or k=="SetSize" or k=="SetWidth" or k=="SetHeight" or k=="SetScale") then N.nativeGeometryDirty=true end
     if k=="SetFrameLevel" and S:Readable(new) and new~=r.ownedLevel then r.externalLevel=true end
     if k=="SetFrameStrata" and S:Readable(new) and new~=r.ownedStrata then r.externalStrata=true end
    else
     if not N.active then return end
     if r.clusterInput and r.clusterInput.object==object then r.clusterInput.dirty=true end
     for _,a in ipairs(r.art) do
      if a.object==object then
       -- Camelot changes the underlay's visibility with Rotate Minimap.
       -- Preserve the latest native choice for handback in this session.
       if object==_G.MinimapCompassTextureUnderlay then
        if k=="Show" then a.shown=true elseif k=="Hide" then a.shown=false
        elseif k=="SetShown" and S:Readable(new) and type(new)=="boolean" then a.shown=new end
       end
       a.dirty=true;break
      end
     end
    end
   end)
   if not ok then self.monitors[o]=nil;return false end
  end
 end
 return true
end
function N:ArtManifest(map)
 -- Fixed presentation-only manifest. Functional tracking, queue, mail, calendar,
 -- addon launchers and map pins remain live; no descendant enumeration or event removal.
 local cluster=_G.MinimapCluster;local list={};local seen={};self.artGaps=0
 local function add(o)
  if not S:Readable(o) then self.artGaps=self.artGaps+1;return end
  if o~=nil and not S:Frame(o,false) then self.artGaps=self.artGaps+1;return end
  if S:Frame(o,false) and not seen[o] and type(field(o,"GetAlpha"))=="function" and type(field(o,"SetAlpha"))=="function" then
   seen[o]=true;list[#list+1]=o
  end
 end
 for _,name in ipairs({"MinimapCompassTexture","MinimapCompassTextureUnderlay","MinimapBorder","MinimapBorderTop","MinimapNorthTag","MinimapZoneText","MinimapZoneTextButton","TimeManagerClockButton","MinimapZoomIn","MinimapZoomOut"}) do add(_G[name]) end
 add(field(cluster,"ZoneTextButton"));add(field(map,"ZoomIn"));add(field(map,"ZoomOut"));add(field(map,"ZoomHitArea"))
 -- Camelot creates this independent day/night ornament under MinimapContainer,
 -- not under the adopted terrain. Keep its native event controller untouched;
 -- the owned header renders the public day/night state and fades with the map.
 add(field(cluster,"DielFrame"))
 add(field(_G.MinimapBackdrop,"StaticOverlayTexture"))
 return list
end
function N:CaptureArt()
 local r=self.record;if not r then return end
 local known={};for _,a in ipairs(r.art) do known[a.object]=true end
 for _,o in ipairs(self:ArtManifest(r.map)) do
  if not known[o] then
   local a,st=value(o,"GetAlpha","number");local shown,vs=value(o,"IsShown","boolean")
   local mouse,ms=value(o,"IsMouseEnabled","boolean")
   if st=="KNOWN" and vs=="KNOWN" then
    r.art[#r.art+1]={object=o,alpha=a,shown=shown,mouse=ms=="KNOWN" and mouse or nil,dirty=true}
    self:Watch(o)
   end
  end
 end
end
function N:WatchBlobRing(map,row)
 -- These are engine-drawn quest-area ring decorations, not Diel or compass
 -- textures. The exact client has alpha setters but no getter/reset default.
 -- Observe real later writes before submitting our session-only policy; never
 -- invent the initial alpha or alter the separate fill/boundary/pin channels.
 self.blobObservers=self.blobObservers or setmetatable({},{__mode="k"})
 local observed=self.blobObservers[map]
 if not observed then observed={};self.blobObservers[map]=observed end
 local state=observed[row.kind]
 if not state then state={sequence=0};observed[row.kind]=state end
 row.observed=state
 if state.hooked then return true end
 if type(field(map,row.method))~="function" or type(hooksecurefunc)~="function" then return false end
 local kind=row.kind
 local ok=pcall(hooksecurefunc,map,row.method,function(object,alpha)
  local token=N.blobWrite
  if token and token.map==object and token.state==state and not token.observed and not token.foreign
   and state.sequence==token.sequence and S:Number(alpha) and alpha==token.alpha then
   token.observed=true;return
  end
  local overlap=token and token.map==object and token.state==state and token.foreign
  if token and token.map==object and token.state==state then token.foreign=true end
  -- An outer posthook can arrive after a nested foreign setter. Its argument
  -- is then stale, not a readback of the final native value. Retain the foreign
  -- pixels and invalidate the ambiguous observation instead of capturing0.
  state.sequence=state.sequence+1;state.known=not overlap and S:Number(alpha);state.value=state.known and alpha or nil
  local r=N.record;local binding=r and r.map==object and r.blobRings and r.blobRings[kind]
  if binding and binding.observed==state and binding.attempted then
   binding.displaced=true;binding.status="EXTERNAL_ALPHA_RETAINED";r.blobDirty=true
  end
  local last=N.lastBlobRows and N.lastBlobRows[kind]
  if last and last.observed==state and last.released then last.restore="EXTERNAL_ALPHA_RETAINED" end
 end)
 state.hooked=ok or nil
 return ok
end
function N:WriteBlobRing(r,row,alpha,current)
 if self.blobWrite then return false,"RING_WRITE_IN_PROGRESS" end
 if not current() then return false,"BINDING_CHANGED" end
 local state=row.observed
 if not state or row.displaced or state.sequence~=row.sequence then return false,"EXTERNAL_ALPHA_RETAINED" end
 local method=field(r.map,row.method)
 if type(method)~="function" or not current() then return false,"SETTER_UNAVAILABLE" end
 if row.displaced or state.sequence~=row.sequence then return false,"EXTERNAL_ALPHA_RETAINED" end
 row.attempted=true
 local token={map=r.map,state=state,alpha=alpha,sequence=state.sequence};self.blobWrite=token
 local sent,result=pcall(method,r.map,alpha)
 if self.blobWrite==token then self.blobWrite=nil end
 if not current() then return false,"BINDING_CHANGED" end
 if row.displaced or token.foreign or state.sequence~=token.sequence then return false,"EXTERNAL_ALPHA_RETAINED" end
 if not sent or result==false or not token.observed then return false,"ALPHA_SUBMISSION_FAILED" end
 -- The posthook establishes which setter call was submitted. It is not an
 -- engine getter or proof of the resulting native raster.
 return true,"ALPHA_ZERO_SUBMITTED_NO_NATIVE_READBACK"
end
function N:ApplyBlobRings()
 local r,profile,frame=self.record,M.profile,self.frame
 if not r then return false end
 local function current()
  if self.record~=r or self.frame~=frame or not self.active or M.profile~=profile or M.state.safe or S:InCombat()
   or _G.Minimap~=r.map or r.conflict then return false end
  local parent,known=value(r.map,"GetParent")
  return known=="KNOWN" and parent==frame and self.record==r and self.frame==frame and self.active
   and M.profile==profile and not M.state.safe and not S:InCombat() and _G.Minimap==r.map and not r.conflict
 end
 if not current() then return false end
 r.blobRings=r.blobRings or {};self.lastBlobRows=r.blobRings;r.blobRetryPending=nil
 local complete=true
 for _,kind in ipairs(blobRingKinds) do
  if not current() then return false end
  local row=r.blobRings[kind]
  if not row then row={kind=kind,method="Set"..kind.."BlobRingAlpha",attempts=0};r.blobRings[kind]=row end
  if not row.submitted and not row.displaced and row.attempts<blobRingRetryLimit then
   row.attempts=row.attempts+1
   local watched=self:WatchBlobRing(r.map,row)
   if not current() then return false end
   if watched then
    if not row.captured then
     row.captured=true;row.originalKnown=row.observed.known==true;row.original=row.observed.value;row.sequence=row.observed.sequence
    end
    row.submitted,row.status=self:WriteBlobRing(r,row,0,current)
    if not current() then return false end
   else row.status="ALPHA_OBSERVER_UNAVAILABLE" end
  end
  if row.displaced then row.status="EXTERNAL_ALPHA_RETAINED" end
  if not row.submitted or row.displaced then
   complete=false
   if not row.displaced and row.attempts<blobRingRetryLimit then r.blobRetryPending=true end
  end
 end
 r.blobDirty=nil
 self.blobRingStatus=complete and "ALPHA_ZERO_SUBMITTED_NO_NATIVE_READBACK" or "DECORATIVE_RING_POLICY_PARTIAL"
 return complete
end
function N:ReleaseBlobRings(r)
 -- Native terrain/input handback never waits on an unobservable ring default.
 -- If we saw a real native alpha before taking ownership, submit that exact
 -- inverse. Otherwise the decoration remains suppressed until a UI reload.
 local profile,frame=M.profile,self.frame
 local function current()
  if self.record~=r or self.frame~=frame or self.active or M.profile~=profile or S:InCombat() or _G.Minimap~=r.map or r.conflict then return false end
  local parent,known=value(r.map,"GetParent")
  return known=="KNOWN" and (parent==frame or parent==r.parent) and self.record==r and self.frame==frame and not self.active
   and M.profile==profile and not S:InCombat() and _G.Minimap==r.map and not r.conflict
 end
 for _,kind in ipairs(blobRingKinds) do
  local row=r.blobRings and r.blobRings[kind]
  if row and row.attempted and not row.released then
   if row.displaced or not row.observed or row.observed.sequence~=row.sequence then row.restore="EXTERNAL_ALPHA_RETAINED"
   elseif not current() then row.restore="CUSTODY_CHANGED_NO_RING_RESTORE"
   elseif not row.originalKnown then row.restore="INITIAL_ALPHA_UNKNOWN_RELOAD_REQUIRED"
   else
    local okay,why=self:WriteBlobRing(r,row,row.original,current)
    row.restore=okay and "OBSERVED_ALPHA_RESTORE_SUBMITTED" or why=="EXTERNAL_ALPHA_RETAINED" and why or "RING_RESTORE_UNCONFIRMED_RELOAD_REQUIRED"
   end
   row.released=true
  end
 end
 self.blobRingStatus="SESSION_POLICY_RELEASED"
end
function N:BlobRingDetails()
 local list={}
 for _,kind in ipairs(blobRingKinds) do
  local row=self.lastBlobRows and self.lastBlobRows[kind]
  if row then list[#list+1]=kind..":"..(row.restore or row.status or "NOT_SUBMITTED")..":"..tostring(row.attempts).."/"..blobRingRetryLimit end
 end
 return #list>0 and table.concat(list,",") or "NOT_SUBMITTED"
end
-- QuestPOIs is the native minimap-only tracking filter. Do not clear the
-- super-tracked quest, change the world-map questPOI CVar, touch other tracking
-- filters, or hide the unrelated world-navigation controller.
function N:QuestFilterSnapshot()
 local api=_G.C_Minimap
 local filters=S:FieldAccess(_G.Enum,"MinimapTrackingFilter")
 local quest=S:FieldAccess(filters,"QuestPOIs")
 local count=S:Public(S:FieldAccess(api,"GetNumTrackingTypes"),"number")
 if not S:Number(quest) or not count or count<1 or count>64 or count%1~=0 then return nil end
 local getFilter=S:FieldAccess(api,"GetTrackingFilter")
 local getInfo=S:FieldAccess(api,"GetTrackingInfo")
 local setter=S:FieldAccess(api,"SetTracking")
 if type(getFilter)~="function" or type(getInfo)~="function" or type(setter)~="function" then return nil end
 for index=1,count do
  local filter=S:Public(getFilter,nil,index)
  if S:FieldAccess(filter,"filterID")==quest then
   local info=S:Public(getInfo,nil,index)
   local active,state=S:FieldAccess(info,"active")
   if state=="KNOWN" and type(active)=="boolean" then return {api=api,index=index,active=active,setter=setter,filterID=quest} end
  end
 end
end
function N:WatchQuestFilter(api)
 if self.questFilterHookAPI==api then return true end
 if type(hooksecurefunc)~="function" then return false end
 local okay=pcall(hooksecurefunc,api,"SetTracking",function(index,on)
  local r=N.record;local row=r and r.questFilter
  if not N.active or N.questFilterWriting or not row or row.api~=api then return end
  if S:Number(index) and index==row.index and S:Readable(on) and type(on)=="boolean" then
   -- Preserve an explicit native/user preference for handback, including a
   -- request to keep this filter off. Reconcile later, never in this hook.
   row.restoreActive=on;r.questFilterDirty=true
  end
 end)
 if okay then self.questFilterHookAPI=api end
 return okay
end
function N:ApplyQuestFilter()
 local r,profile=self.record,M.profile
 if not r or not self.active or r.map~=_G.Minimap or not r.canvasCommitted then return false end
 if S:InCombat() then r.questFilterDirty=true;self.questFilterStatus="NATIVE_QUEST_FILTER_COMBAT_DEFERRED";return false end
 local snapshot=self:QuestFilterSnapshot()
 local function current() return self.active and self.record==r and M.profile==profile and r.map==_G.Minimap and not r.conflict and not M.state.safe and not S:InCombat() end
 if not current() then return false end
 if not snapshot then
  r.questFilterDirty=nil;self.questFilterStatus="NATIVE_QUEST_FILTER_UNAVAILABLE";return nil
 end
 local row=r.questFilter
 if not row then row={api=snapshot.api,index=snapshot.index,restoreActive=snapshot.active,attempts=0};r.questFilter=row end
 if row.api~=snapshot.api then self.questFilterStatus="NATIVE_QUEST_FILTER_API_CHANGED";r.questFilterDirty=nil;return false end
 row.index=snapshot.index
 if not self:WatchQuestFilter(snapshot.api) then self.questFilterStatus="NATIVE_QUEST_FILTER_OBSERVATION_UNAVAILABLE";return false end
 if not snapshot.active then
  row.attempts=0;r.questFilterDirty=nil;self.questFilterStatus="NATIVE_QUEST_FILTER_SUPPRESSED_READBACK";return true
 end
 if row.attempts>=3 then r.questFilterDirty=nil;self.questFilterStatus="NATIVE_QUEST_FILTER_RETRY_REQUIRED";return false end
 row.attempts=row.attempts+1;row.attempted=true
 self.questFilterWriting=true
 local okay,result=pcall(snapshot.setter,snapshot.index,false)
 self.questFilterWriting=nil
 if not current() then return false end
 local after=self:QuestFilterSnapshot()
 if not current() then return false end
 okay=okay and result~=false and after and after.api==snapshot.api and after.active==false
 row.written=okay or row.written;r.questFilterDirty=not okay and row.attempts<3 or nil
 if okay then row.attempts=0 end
 self.questFilterStatus=okay and "NATIVE_QUEST_FILTER_SUPPRESSED_READBACK" or "NATIVE_QUEST_FILTER_RETRY_REQUIRED"
 return okay and true or false
end
function N:ReleaseQuestFilter(r)
 local row=r and r.questFilter
 if not row or not row.attempted then self.questFilterStatus="NATIVE_QUEST_FILTER_UNCHANGED";return true end
 local before=self:QuestFilterSnapshot()
 if not before or before.api~=row.api then self.questFilterStatus="NATIVE_QUEST_FILTER_RESTORE_UNAVAILABLE";return false end
 -- A later explicit enable already restored native presentation. Only undo
 -- the zero value this minimap lease submitted; never write a guessed default.
 if before.active==row.restoreActive or before.active~=false then self.questFilterStatus="NATIVE_QUEST_FILTER_RESTORED";return true end
 if S:InCombat() then self.questFilterStatus="NATIVE_QUEST_FILTER_RESTORE_DEFERRED";return false end
 self.questFilterWriting=true
 local okay,result=pcall(before.setter,before.index,row.restoreActive)
 self.questFilterWriting=nil
 local after=self:QuestFilterSnapshot()
 okay=okay and result~=false and after and after.api==row.api and after.active==row.restoreActive
 self.questFilterStatus=okay and "NATIVE_QUEST_FILTER_RESTORED" or "NATIVE_QUEST_FILTER_RESTORE_UNAVAILABLE"
 return okay and true or false
end
-- The 71091 Blizzard_Minimap TOC loads Mainline/Minimap.xml and the Camelot
-- Lua override. Both rotation modes submit roundMask to the container's map.
-- Source: Gethe/wow-ui-source c01a87b549bbc19e0f284c1616d18654c91297de,
-- Interface/AddOns/Blizzard_Minimap/Camelot/Minimap.lua. This narrow pin
-- must not grant broader reviewed-client permissions to other providers.
local function sourceMaskContract()
 local client=M.Client
 if not client then return nil end
 if client.family=="Forever" and client.patch=="1.60.1" and client.build=="71091"
  and client.interface==16001 and client.key=="Forever:1.60.1:71091:16001"
  and S:Public(client.IsRuntimeClient,"boolean",client)==true then
  return "SOURCE_71091_MINIMAP_ONLY"
 end
 if S:Public(client.IsReviewedPresentationClient,"boolean",client)==true then return "SOURCE_BASELINE_SETTER_ONLY" end
end
function N:NativeMaskFallback()
 if self.record then return nil end
 local map=_G.Minimap
 if not S:Frame(map,false) or type(field(map,"SetMaskTexture"))~="function"
  or type(field(map,"GetMaskTexture"))=="function" then return nil end
 if sourceMaskContract() then self.nativeMaskFallback=nil;return nil end
 self.nativeMaskFallback=true
 self.active=false;self.maskContract="NATIVE_INVERSE_NOT_OBSERVABLE"
 self.maskSubmission="NO_MASK_WRITE";self.rollbackStatus="NOT_REQUIRED"
 self.failureStage="NONE";self.lastFailure=nil
 self.status="NATIVE_MINIMAP_RETAINED_UNREVIEWED"
 return R:Result("PARTIAL",self.status,"Minimap")
end
function N:Acquire()
 if self.record then return true end
 if S:InCombat() then return self:Failure("SETUP_COMBAT_DEFERRED","ACQUIRE") end
 local map=_G.Minimap
 if not S:Frame(map,false) or type(field(map,"SetMaskTexture"))~="function" then return self:Failure("MAP_UNAVAILABLE","CAPTURE") end
 for _,name in ipairs({"SexyMap","Chinchilla","BasicMinimap"}) do if S:Loaded(name) then return self:Failure("OTHER_MINIMAP_OWNER","CAPTURE") end end
 local parent,ps=value(map,"GetParent");local width,ws=value(map,"GetWidth","number",true);local height,hs=value(map,"GetHeight","number",true)
 local scale,ss=value(map,"GetScale","number");local alpha,as=value(map,"GetAlpha","number");local anchors=points(map)
 local shown,vs=value(map,"IsShown","boolean")
 for _,capture in ipairs({{"PARENT",ps},{"WIDTH",ws},{"HEIGHT",hs},{"SCALE",ss},{"ALPHA",as},{"SHOWN",vs}}) do
  if capture[2]~="KNOWN" then return self:Failure("MAP_CAPTURE_"..capture[1].."_UNAVAILABLE","CAPTURE") end
 end
 if not anchors then return self:Failure("MAP_CAPTURE_POINTS_UNAVAILABLE","CAPTURE") end
 local level,ls=value(map,"GetFrameLevel","number");local strata,fs=value(map,"GetFrameStrata","string")
 if ls~="KNOWN" or fs~="KNOWN" then return self:Failure("MAP_CAPTURE_LAYER_UNAVAILABLE","CAPTURE") end
 local originalMask,maskContract
 if type(field(map,"GetMaskTexture"))=="function" then
  local state;originalMask,state=value(map,"GetMaskTexture")
  if state~="KNOWN" or (not S:Text(originalMask) and not S:Number(originalMask)) then return self:Failure("MASK_CAPTURE_UNAVAILABLE","CAPTURE") end
  maskContract="GETTER_READBACK"
 else
  maskContract=sourceMaskContract()
  if not maskContract then return self:Failure("MASK_INVERSE_UNAVAILABLE","CAPTURE") end
  if maskContract=="SOURCE_71091_MINIMAP_ONLY" then
   local container=field(_G.MinimapCluster,"MinimapContainer")
   if parent~=container or field(container,"Minimap")~=map then return self:Failure("MAP_NATIVE_CONTAINER_MISMATCH","CAPTURE") end
   local shape=_G.GetMinimapShape
   if not S:Readable(shape) or shape~=nil and S:Public(shape,"string")~="ROUND" then
    return self:Failure("OTHER_MINIMAP_OWNER","CAPTURE")
   end
  end
  originalMask=roundMask
 end
 if not self:Watch(map) then return self:Failure("MAP_GUARD_UNAVAILABLE","CAPTURE") end
 local r={map=map,parent=parent,width=width,height=height,scale=scale,alpha=alpha,shown=shown,points=anchors,originalMask=originalMask,
  level=level,strata=strata,art={}}
 r.maskContract=maskContract
 self.maskContract=r.maskContract;self.maskSubmission="NOT_SUBMITTED";self.rollbackStatus=nil
 -- Ring decoration removal is an explicit session policy, applied only after
 -- terrain commit. Native scale, quest fill/boundary textures and pins remain
 -- unchanged. Initial alpha is never described as captured without evidence.
 local cluster=_G.MinimapCluster
 if S:Frame(cluster,false) then
  -- The old empty cluster must not become an invisible world-click blocker.
  -- Disabling this frame's input leaves its functional child buttons enabled.
  local enabled,ms=value(cluster,"IsMouseEnabled","boolean")
  if ms=="KNOWN" then r.clusterInput={object=cluster,original=enabled,dirty=true};self:Watch(cluster) end
 end
 for _,o in ipairs(self:ArtManifest(map)) do
  local a,st=value(o,"GetAlpha","number");local show,sh=value(o,"IsShown","boolean")
  local mouse,ms=value(o,"IsMouseEnabled","boolean")
  if st=="KNOWN" and sh=="KNOWN" then
   r.art[#r.art+1]={object=o,alpha=a,shown=show,mouse=ms=="KNOWN" and mouse or nil,dirty=true}
   self:Watch(o)
  end
 end
 self.record=r;self.active=true;self.dirty=true
 self.originalShape=GetMinimapShape
 self.shapeFunction=function(...)
  if N.active and N.record and N.record.canvasCommitted and N.record.mask==squareMask then return "SQUARE" end
  if type(N.originalShape)=="function" then return N.originalShape(...) end
  return "ROUND"
 end
 GetMinimapShape=self.shapeFunction
 -- Resolve current sidebar geometry and commit once through the registered
 -- surface. A skipped dispatch cannot establish a custom canvas.
 local applied,why=M.Layout:Apply(self.surface)
 return applied==true and self.record==r and r.canvasCommitted==true,why or "MAP_LAYOUT_PENDING"
end
function N:SuppressArt()
 local r=self.record;if not r then return false end
 local complete=(self.artGaps or 0)==0
 if r.clusterInput then
  local o=r.clusterInput.object
  if r.clusterInput.dirty and legal(o) then
   self.writing=true
    r.clusterInput.attempted=true
   complete=call(o,"EnableMouse",false) and value(o,"IsMouseEnabled","boolean")==false and complete
   self.writing=nil;r.clusterInput.dirty=not complete
  elseif r.clusterInput.dirty then complete=false end
 end
 for _,a in ipairs(r.art) do
  local o=a.object
  if a.dirty and legal(o) then
   self.writing=true
   a.attempted=true
   local ok=call(o,"SetAlpha",0)
   if a.mouse~=nil then ok=call(o,"EnableMouse",false) and ok end
   -- Alpha is authoritative for compass textures re-shown by native rotation.
   -- Hide only these named decorations/buttons, never an engine controller.
   ok=call(o,"Hide") and ok
   ok=value(o,"GetAlpha","number")==0 and value(o,"IsShown","boolean")==false and ok
   if a.mouse~=nil then ok=value(o,"IsMouseEnabled","boolean")==false and ok end
   self.writing=nil;a.written=ok or a.written;a.dirty=not ok
   complete=ok and complete
  elseif a.dirty then complete=false end
 end
 return complete
end
function N:CoordinateObjects()
 local object=field(field(_G.MinimapCluster,"MinimapContainer"),"PlayerCoords")
 return object,field(object,"CoordText")
end
function N:WatchCoordinates(row,object)
 if not S:Frame(object,false) then return false end
 self.coordinateHooks=self.coordinateHooks or setmetatable({},{__mode="k"})
 if self.coordinateHooks[object] then return true end
 if type(hooksecurefunc)~="function" then return false end
 for _,method in ipairs({"SetAlpha","Show","SetShown","SetParent","SetIgnoreParentAlpha"}) do
  if type(field(object,method))=="function" then
   local ok=pcall(hooksecurefunc,object,method,function()
    local current=N.record and N.record.coordinates
    if not N.active or not current or N.writing or (current.owner.leaseWriteDepth or 0)>0 then return end
    if current.object==object or current.text==object then current.dirty=true;current.cause=method end
   end)
   if not ok then return false end
  end
 end
 self.coordinateHooks[object]=true;return true
end
function N:CoordinatesCurrent()
 local r=self.record;if not r then return false end
 local object,child=self:CoordinateObjects();local row=r.coordinates
 if not object and not row then self.coordinateStatus="NATIVE_ABSENT";return true end
 if not row or row.object~=object or row.text~=child then self.coordinateStatus="COORDINATE_IDENTITY_PENDING";return false end
 local alpha,state=value(object,"GetAlpha","number")
 local textAlpha,textState
 if child then textAlpha,textState=value(child,"GetAlpha","number") end
 row.observedAlpha=state=="KNOWN" and alpha or nil
 row.observedTextAlpha=textState=="KNOWN" and textAlpha or nil
 local current=state=="KNOWN" and alpha==0 and (not child or textState=="KNOWN" and textAlpha==0 and value(child,"GetParent")==object)
 self.coordinateStatus=current and "NATIVE_COORDINATES_SUPPRESSED" or row.blocked and "COORDINATE_REPEATED_CONFLICT" or "COORDINATE_MASK_PENDING"
 return current
end
function N:LayoutCoordinates(layout)
 local r,L=self.record,R.CombatLeases;if not r or not L then return false end
 local object,child=self:CoordinateObjects()
 local row=r.coordinates
 if row and (row.object~=object or row.text~=child) then
  row.owner.active=false
  if not L:Release(row.owner) then self.coordinateStatus="RESTORE_PENDING";return false end
  r.coordinates=nil;row=nil
  if self.rootLeaseOwners then self.rootLeaseOwners.Coordinates=nil end
 end
 if not object then self.coordinateStatus="NATIVE_ABSENT";return true end
 if not row then
  local owner={id="minimap",active=true};L:Begin(owner)
  row={object=object,text=child,owner=owner,dirty=true};r.coordinates=row
  self.rootLeaseOwners=self.rootLeaseOwners or {};self.rootLeaseOwners.Coordinates=owner
 end
 -- PlayerCoords is a native sibling of the terrain, not a child of the adopted
 -- map. DataBars is retired: there is deliberately no second coordinate home.
 -- Lease the exact passive text too, so IgnoreParentAlpha cannot leak it past
 -- the group. Native coordinates/controller/CVar and original values survive.
 local watched=self:WatchCoordinates(row,object)
 if child then watched=self:WatchCoordinates(row,child) and value(child,"GetParent")==object and watched end
 if not watched then self.coordinateStatus="COORDINATE_GUARD_UNAVAILABLE";return false end
 local ok=L:Alpha(row.owner,object,0)
 if child then ok=L:Alpha(row.owner,child,0) and ok end
 row.dirty=not ok;row.attempts=(row.attempts or 0)+1
 return self:CoordinatesCurrent() and ok
end
function N:TerrainCurrent()
 local r=self.record
 if not r or not r.canvasCommitted then self.terrainStatus="MAP_CANVAS_PENDING";return false end
 if _G.Minimap~=r.map then self.terrainStatus="MAP_IDENTITY_CHANGED";return false end
 local parent,ps=value(r.map,"GetParent")
 local alpha,as=value(r.map,"GetAlpha","number")
 local shown,ss=value(r.map,"IsShown","boolean")
 r.terrainAlpha=as=="KNOWN" and alpha or nil
 if ss=="KNOWN" then r.terrainShown=shown else r.terrainShown=nil end
 if ps~="KNOWN" or as~="KNOWN" or ss~="KNOWN" then self.terrainStatus="MAP_LIVENESS_READBACK_UNAVAILABLE";return false end
 if parent~=self.frame then self.terrainStatus="MAP_PARENT_PENDING";return false end
 local current=alpha==1 and shown==true
 self.terrainStatus=current and "LOCAL_ALPHA_ONE_SHOWN" or "MAP_LIVENESS_PENDING"
 return current
end
function N:QueueTerrainRefresh(reason)
 local r=self.record
 if not r or not r.canvasCommitted then return end
 r.terrainRefreshRevision=(r.terrainRefreshRevision or 0)+1
 r.terrainRefreshPending=true;r.terrainRefreshAt=S:Now()+.05;r.terrainRefreshAttempts=0
 r.terrainRefreshCause=reason or "CANVAS_CHANGED"
 self.terrainRefreshStatus="WAITING_FOR_VISIBLE_SETTLED_CANVAS"
end
-- A resized native minimap can retain part of its previous terrain cache until
-- movement/zoom invalidates it. Public geometry readback cannot certify pixels.
-- Use one real adjacent zoom transition and restore the observed zoom in the
-- same callback, after layout has settled. Never submit a guessed zoom or use
-- a same-value SetZoom call as evidence of a native redraw.
function N:ReleaseTerrainZoom(r)
 local receipt=r and r.terrainZoom
 if not receipt then return true,"UNCHANGED" end
 local map=r.map
 local function current() return self.record==r and r.terrainZoom==receipt and map==_G.Minimap end
 if not current() then return false,"RETIRED" end
 local parent,state=value(map,"GetParent")
 if not current() then return not r.terrainZoom,"RETIRED" end
 if state~="KNOWN" then return false,"UNKNOWN" end
 if parent~=self.frame and parent~=r.parent then
  r.terrainZoom=nil;self.terrainRefreshStatus="EXTERNAL_MAP_OWNER_RETAINED";return true,"EXTERNAL"
 end
 local zoom,known=value(map,"GetZoom","number")
 if not current() then return not r.terrainZoom,"RETIRED" end
 if known~="KNOWN" then self.terrainRefreshStatus="ZOOM_RESTORE_READBACK_PENDING";return false,"UNKNOWN" end
 if zoom==receipt.original then r.terrainZoom=nil;return true,"ORIGINAL" end
 if zoom~=receipt.pulse then
  r.terrainZoom=nil;self.terrainRefreshStatus="EXTERNAL_ZOOM_CHOICE_RETAINED";return true,"EXTERNAL"
 end
 local editable=not S:InCombat() and S:Frame(map,true)
 if not current() then return not r.terrainZoom,"RETIRED" end
 if not editable then self.terrainRefreshStatus="ZOOM_RESTORE_COMBAT_DEFERRED";return false,"DEFERRED" end
 -- An ancestry getter can synchronously retire this lease. Seal custody again
 -- before the inverse write, just as the main canvas transaction does.
 parent,state=value(map,"GetParent")
 if not current() then return not r.terrainZoom,"RETIRED" end
 if state~="KNOWN" or parent~=self.frame and parent~=r.parent then return false,"CUSTODY" end
 if S:InCombat() or not current() then return false,"DEFERRED" end
 write(map,"SetZoom",receipt.original)
 local restored,observed=value(map,"GetZoom","number")
 if not current() then return not r.terrainZoom,"RETIRED" end
 if observed=="KNOWN" and restored==receipt.original then r.terrainZoom=nil;return true,"ORIGINAL" end
 self.terrainRefreshStatus="ZOOM_RESTORE_PENDING";return false,"UNKNOWN"
end
function N:FinishTerrainRefresh(r,receipt,restored,kind)
 if self.record~=r or not self.active then return false end
 if restored and kind=="ORIGINAL" and receipt.pulseObserved then
  if not receipt.counted then r.terrainRefreshCount=(r.terrainRefreshCount or 0)+1;receipt.counted=true end
  if r.terrainRefreshRevision==receipt.revision then r.terrainRefreshPending=nil end
  self.terrainRefreshStatus="ZOOM_CYCLE_RESTORED_RASTER_UNVERIFIED"
  return true
 end
 if restored and kind=="EXTERNAL" then
  if r.terrainRefreshRevision==receipt.revision then r.terrainRefreshPending=nil end
  return true -- preserve a newer native/user zoom choice without another pulse
 end
 return false
end
function N:RefreshTerrainRaster(now)
 local r=self.record
 if not r or self.terrainRefreshing then return false end
 if r.terrainZoom then
  local receipt=r.terrainZoom
  local restored,kind=self:ReleaseTerrainZoom(r)
  if not restored then return false end
  if self:FinishTerrainRefresh(r,receipt,restored,kind) then return true end
 end
 if not r.terrainRefreshPending then return true end
 local profile,frame,revision=M.profile,self.frame,r.terrainRefreshRevision
 local function current()
  return self.active and self.record==r and r.map==_G.Minimap and self.frame==frame and M.profile==profile
   and not M.state.safe and r.canvasCommitted and not r.conflict and r.terrainRefreshRevision==revision
 end
 if not current() then return false end
 if S:InCombat() or not S:Frame(r.map,true) then self.terrainRefreshStatus="REFRESH_COMBAT_DEFERRED";return false end
 if not current() then return false end
 now=now or S:Now()
 if now<(r.terrainRefreshAt or 0) then return false end
 local map=r.map;local transaction={};local receipt
 local function read(method,kind)
  if not current() then error(transaction,0) end
  local v,state=value(map,method,kind)
  if not current() then error(transaction,0) end
  return v,state
 end
 self.terrainRefreshing=true
 local okay,result=pcall(function()
  local visible,shown=read("IsVisible","boolean")
  local alpha,alphaKnown=read("GetEffectiveAlpha","number")
  if shown~="KNOWN" or not visible or alphaKnown=="KNOWN" and alpha<=.01 then
   self.terrainRefreshStatus="WAITING_FOR_VISIBLE_CANVAS";return false
  end
  if read("GetParent")~=frame or not near(read("GetWidth","number"),r.canvasWidth)
   or not near(read("GetHeight","number"),r.canvasHeight) then
   self.terrainRefreshStatus="WAITING_FOR_SETTLED_CANVAS";return false
  end
  local zoom,zs=read("GetZoom","number");local levels,ls=read("GetZoomLevels","number")
  if zs~="KNOWN" or ls~="KNOWN" or zoom%1~=0 or levels%1~=0 or levels<2 or levels>128
   or zoom<0 or zoom>=levels or type(field(map,"SetZoom"))~="function" then
   if current() then r.terrainRefreshPending=nil;self.terrainRefreshStatus="NATIVE_ZOOM_REFRESH_UNAVAILABLE" end
   return false
  end
  if (r.terrainRefreshAttempts or 0)>=2 then
   r.terrainRefreshPending=nil;self.terrainRefreshStatus="NATIVE_ZOOM_REFRESH_RETRY_REQUIRED";return false
  end
  -- Final native read and combat check precede the only forward mutation.
  if read("GetParent")~=frame or S:InCombat() or not current() then return false end
  receipt={original=zoom,pulse=zoom==0 and 1 or zoom-1,revision=revision}
  r.terrainZoom=receipt;r.terrainRefreshAttempts=(r.terrainRefreshAttempts or 0)+1
  write(map,"SetZoom",receipt.pulse)
  local observed,known=read("GetZoom","number")
  receipt.pulseObserved=known=="KNOWN" and observed==receipt.pulse
  return true
 end)
 local restored,kind=true,"UNCHANGED"
 if receipt then restored,kind=self:ReleaseTerrainZoom(r) end
 self.terrainRefreshing=nil
 if not current() then return false end
 if receipt and self:FinishTerrainRefresh(r,receipt,restored,kind) then return true end
 if not okay then
  if result~=transaction then self.terrainRefreshStatus="NATIVE_ZOOM_REFRESH_CALLBACK_FAILED" end
  return false
 end
 if receipt and restored then
  r.terrainRefreshAt=now+.5
  self.terrainRefreshStatus="NATIVE_ZOOM_REFRESH_PENDING"
 end
 return false
end
function N:ReconcileTerrain(now)
 local r=self.record
 if self:TerrainCurrent() then r.terrainDirty=nil;return true end
 if not r or not r.canvasCommitted or r.map~=_G.Minimap or value(r.map,"GetParent")~=self.frame then return false end
 if r.terrainBlocked then self.terrainStatus=r.terrainBlocked;return false end
 if S:InCombat() or not S:Frame(r.map,true) then self.terrainStatus="MAP_LIVENESS_DEFERRED";return false end
 now=now or S:Now()
 if not r.terrainWindow or now-r.terrainWindow>2 then r.terrainWindow=now;r.terrainAttempts=0 end
 if (r.terrainAttempts or 0)>=4 then r.terrainBlocked="MAP_LIVENESS_REPEATED_CONFLICT";self.terrainStatus=r.terrainBlocked;return false end
 r.terrainAttempts=(r.terrainAttempts or 0)+1
 local profile=M.profile
 local function current() return self.active and self.record==r and r.map==_G.Minimap and M.profile==profile and wanted() and value(r.map,"GetParent")==self.frame end
 if not current() then return false end
 self.writing=true
 local ok=true
 if r.terrainAlpha~=1 then r.alphaAttempted=true;ok=write(r.map,"SetAlpha",1);r.alphaObserved=value(r.map,"GetAlpha","number") end
 if current() and r.terrainShown~=true then r.showAttempted=true;ok=write(r.map,"Show") and ok end
 self.writing=nil
 if not current() then return false end
 local observed=self:TerrainCurrent();r.terrainDirty=not observed
 return ok and observed
end
function N:RefreshAuxiliaryStatus(art)
 if art~=nil then self.auxArtReady=art end
 local r=self.record
 if not r or not r.canvasCommitted or r.conflict or self.maskDirty then return false end
 local coordinates=self:CoordinatesCurrent()
 local utilities=type(self.utilityStatus)=="string" and self.utilityStatus:match("^NATIVE_ROUTES_DOCKED:%d+$")~=nil
 local complete=self.auxArtReady==true and coordinates and utilities and self:TerrainCurrent() and self.blobRingStatus=="ALPHA_ZERO_SUBMITTED_NO_NATIVE_READBACK" and self.questFilterReady~=false
 self.status=complete and "OWNED_CUSTOM_CANVAS" or "OWNED_CUSTOM_CANVAS_ART_PENDING"
 return complete
end
function N:UtilityTargets()
 local cluster=_G.MinimapCluster
 return {
  {key="tracking",object=field(cluster,"Tracking")},
  {key="calendar",object=_G.GameTimeFrame},
  {key="addons",object=_G.AddonCompartmentFrame},
  {key="queue",object=_G.QueueStatusButton},
  -- Keep the indicator container intact: its mail child calls its parent's
  -- native Layout() when mail state changes.
  {key="indicators",object=field(cluster,"IndicatorFrame")},
  {key="expansion",object=_G.ExpansionLandingPageMinimapButton},
  {key="external",object=field(_G.MinimapBackdrop,"ExternalEventURLButton")},
 }
end
function N:UtilityEnvelope(object,key)
 local width,ws=value(object,"GetWidth","number");local height,hs=value(object,"GetHeight","number")
 if ws~="KNOWN" or hs~="KNOWN" or width<=0 or height<=0 then return nil end
 -- The reviewed Tracking wrapper is 17x17, but its native centered clickable
 -- Button is 23x23. Fit the actual button as well as its wrapper; scaling only
 -- the wrapper makes a 27px button overflow the 20px toolbar slot.
 if key=="tracking" then
  local readable,child=pcall(function() return object.Button end)
  if not readable or not S:Readable(child) then return nil end
  if child then
   local cw,cws=value(child,"GetWidth","number");local ch,chs=value(child,"GetHeight","number")
   local scale,ss=value(child,"GetScale","number")
   if cws~="KNOWN" or chs~="KNOWN" or ss~="KNOWN" or cw<=0 or ch<=0 or scale<=0
    or value(child,"GetParent")~=object or not samePoints(points(child),{{"CENTER",object,"CENTER",0,0}}) then return nil end
   width=math.max(width,cw*scale);height=math.max(height,ch*scale)
  end
 end
 return width,height
end
function N:KnownUtilityLayout(row,key)
 local object=row.object;local parent=value(object,"GetParent")
 if parent~=self.overlay and parent~=row.parent then return false end
 local scale=value(object,"GetScale","number")
 if not near(scale,row.writtenScale) and not near(scale,row.scale) then return false end
 local anchors=points(object)
 if samePoints(anchors,row.points) or samePoints(anchors,row.originalPoints) then return true end
 -- These exact reset anchors come from the reviewed Camelot minimap source.
 -- They can run after adoption when rotate/header settings change. Any other
 -- writer retains its own position and is released from our toolbar lease.
 if key=="addons" then
  return samePoints(anchors,{{"TOP",_G.GameTimeFrame,"BOTTOM",0,1}})
   or samePoints(anchors,{{"BOTTOM",_G.GameTimeFrame,"TOP",0,-1}})
 elseif key=="indicators" then
  return samePoints(anchors,{{"BOTTOMLEFT",field(_G.MinimapCluster,"ZoneTextButton"),"TOPLEFT",0,0}})
 elseif key=="external" then
  return samePoints(anchors,{{"TOPLEFT",parent,"TOPLEFT",9,-110}})
 end
 return false
end
function N:WatchUtility(row)
 if type(hooksecurefunc)~="function" then return false end
 for _,method in ipairs({"SetParent","SetPoint","SetScale"}) do
  if type(field(row.object,method))=="function" then
   local ok=pcall(hooksecurefunc,row.object,method,function()
    if N.active and N.record and N.record.utilities and N.record.utilities[row.key]==row and row.owner.active
     and not row.displaced and (row.owner.leaseWriteDepth or 0)==0 then N.utilitiesDirty=true end
   end)
   if not ok then return false end
  end
 end
 self:WatchPendingUtility(row.object,row.key)
 if row.key=="tracking" then
  local child=field(row.object,"Button")
  if child then self:WatchPendingUtility(child,row.key,row.object) end
 end
 return true
end
function N:WatchPendingUtility(object,key,utility)
 -- A newly created native button can expose a zero rectangle before layout.
 -- The same fixed native objects also resize after admission (mail, expansion
 -- icon or delayed tracking layout). Observe these dimensions throughout the
 -- lease. Callbacks only enqueue, so cold layout can settle before repaint.
 utility=utility or object
 self.utilityPendingHooks=self.utilityPendingHooks or setmetatable({},{__mode="k"})
 local hooks=self.utilityPendingHooks[object]
 if not hooks then hooks={};self.utilityPendingHooks[object]=hooks end
 if hooks[key] then return end
 if type(hooksecurefunc)~="function" then return end
 hooks[key]=true
 local function changed()
   local r=N.record;local recovery=r and r.utilityRecovery and r.utilityRecovery[key]
   local row=r and r.utilities and r.utilities[key]
   if N.active and not N.writing and recovery and recovery.object==utility
    and (not row or (row.owner.leaseWriteDepth or 0)==0)
    and (recovery.geometryPending or row and row.object==utility and row.owner.active and not row.displaced) then
    recovery.attempts=0;N.utilitiesDirty=true
   end
 end
 for _,method in ipairs({"SetSize","SetWidth","SetHeight"}) do
  if type(field(object,method))=="function" then pcall(hooksecurefunc,object,method,changed) end
 end
 -- Calculated extents can settle a frame after SetSize without another setter.
 if type(field(object,"HookScript"))=="function" then call(object,"HookScript","OnSizeChanged",changed) end
 if object~=utility then
  for _,method in ipairs({"SetScale","SetPoint","ClearAllPoints","SetParent"}) do
   if type(field(object,method))=="function" then pcall(hooksecurefunc,object,method,changed) end
  end
 end
end
function N:OriginalUtilityLayout(row)
 -- A successful rollback is necessary but not sufficient for reacquisition:
 -- a later writer may have moved the button after the rollback completed.
 -- Require the complete captured native geometry/layer before another try.
 local object=row.object
 return value(object,"GetParent")==row.parent and samePoints(points(object),row.originalPoints)
  and near(value(object,"GetWidth","number"),row.width) and near(value(object,"GetHeight","number"),row.height)
  and near(value(object,"GetScale","number"),row.scale)
  and value(object,"GetFrameLevel","number")==row.level and value(object,"GetFrameStrata","string")==row.strata
end
function N:LayoutUtilities(layout)
 local r,L=self.record,R.CombatLeases
 if not r or not L then return false end
 local profile,overlay,canvas=M.profile,self.overlay,self.canvasTransaction
 local transaction={};self.utilityTransaction=transaction
 local function current()
  return self.active and self.record==r and M.profile==profile and self.overlay==overlay
   and self.utilityTransaction==transaction and self.canvasTransaction==canvas and not S:InCombat() and not M.state.safe
 end
 local function ensure() if not current() then error(transaction,0) end end
 local function lease(method,...)
  ensure();local result,why=L[method](L,...);ensure();return result,why
 end
 local okay,result=pcall(function()
 ensure()
 r.utilities=r.utilities or {};r.utilityRecovery=r.utilityRecovery or {};r.utilityRetryPending=nil
 local complete=true;local present=0
 local control=self.controlSize or 20
 local step=control+4
 local columns=math.max(1,math.floor((layout.width-14+4)/step))
 -- Reserve the first bottom slot for MirageUI settings and the next for the
 -- world map. At narrow/high-text sizes, wrap the native calendar before it
 -- could overlap the two right-aligned zoom buttons.
 local firstRow=math.max(2,math.floor((layout.width-14-2*step+4)/step))
 local extra=math.max(0,4-firstRow)
 self.utilitySlots=self.utilitySlots or {}
 for _,spec in ipairs(self:UtilityTargets()) do
  ensure()
  local object=spec.object;local row=r.utilities[spec.key]
  local recovery=r.utilityRecovery[spec.key]
  if not recovery or recovery.object~=object then recovery={object=object,attempts=0};r.utilityRecovery[spec.key]=recovery end
  if row and row.object~=object then
   row.owner.active=false
   if lease("Release",row.owner) then
    r.utilities[spec.key]=nil;row=nil
    if self.rootLeaseOwners then self.rootLeaseOwners["Utility."..spec.key]=nil end
   else complete=false end
  end
  if S:Frame(object,false) and (not row or row.object==object) then
   present=present+1
   local envelopeWidth,envelopeHeight=self:UtilityEnvelope(object,spec.key)
   ensure()
   local attempted=false
   if row and row.retryable and not row.rollbackPending and recovery.attempts<utilityRecoveryLimit then
    if self:OriginalUtilityLayout(row) then
     row.displaced=nil;row.retryable=nil;row.failure=nil;lease("Begin",row.owner)
    else row.retryable=nil;row.failure="UTILITY_RETRY_CUSTODY_CHANGED";recovery.status="CUSTODY_CHANGED" end
   end
   if not row and recovery.attempts<utilityRecoveryLimit then
    recovery.attempts=recovery.attempts+1;attempted=true
    local width,ws=value(object,"GetWidth","number");local height,hs=value(object,"GetHeight","number")
    local scale,ss=value(object,"GetScale","number")
    local level,ls=value(object,"GetFrameLevel","number");local strata,fs=value(object,"GetFrameStrata","string")
    if ws=="KNOWN" and hs=="KNOWN" and ss=="KNOWN" and ls=="KNOWN" and fs=="KNOWN" and width>0 and height>0 and scale>0 and envelopeWidth then
     local owner={id="minimap",active=true};lease("Begin",owner)
     row={key=spec.key,object=object,owner=owner,width=width,height=height,scale=scale,
      level=level,strata=strata,parent=value(object,"GetParent"),originalPoints=points(object)};r.utilities[spec.key]=row
     self.rootLeaseOwners=self.rootLeaseOwners or {};self.rootLeaseOwners["Utility."..spec.key]=owner
     recovery.geometryPending=nil
     if not row.originalPoints or not self:WatchUtility(row) then row.displaced=true;complete=false end
    else
     recovery.geometryPending=true;recovery.status="GEOMETRY_PENDING";self:WatchPendingUtility(object,spec.key)
     local child=spec.key=="tracking" and field(object,"Button")
     if child then self:WatchPendingUtility(child,spec.key,object) end
     complete=false
    end
   end
   if row then
    local owner=row.owner
    local level=self.overlay:GetFrameLevel()+2;local strata=self.overlay:GetFrameStrata()
    if row.written and not self:KnownUtilityLayout(row,spec.key) then
     row.displaced=true;owner.active=false;complete=lease("Release",owner) and complete
     row.failure="UTILITY_CUSTODY_CHANGED";recovery.status="CUSTODY_CHANGED"
    end
    if not row.displaced and not envelopeWidth then
     -- Do not divide by a cold/unknown extent or hand off a good native route.
     -- Its size notification wakes this row when the native layout settles.
     recovery.geometryPending=true;recovery.status="GEOMETRY_PENDING";complete=false
    elseif not row.displaced then
     if not row.written and not attempted then recovery.attempts=recovery.attempts+1 end
     owner.active=true
     local scale=control/math.max(envelopeWidth,envelopeHeight)
     -- The primary buttons share one unscaled grid. Offsets placed on
     -- differently scaled native launchers are themselves scaled by WoW and
     -- can overlap. A zero-offset anchor to an owned slot keeps all centers
     -- equally spaced, independently of the launcher's original dimensions.
     local slot=self.utilitySlots[spec.key]
     if not slot then
      slot=CreateFrame("Frame",nil,self.overlay,"BackdropTemplate");S:Passive(slot)
      if spec.key=="tracking" or spec.key=="calendar" then
       slot:SetBackdrop({bgFile=white,edgeFile=white,edgeSize=1})
       slot:SetBackdropColor(.060,.060,.065,.97);slot:SetBackdropBorderColor(.26,.26,.26,1)
      end
      self.utilitySlots[spec.key]=slot
     end
     local column,line
     if spec.key=="tracking" or spec.key=="calendar" then
      local index=spec.key=="tracking" and 2 or 3
      if index<firstRow then column,line=index,0
      else column,line=(index-firstRow)%columns,1+math.floor((index-firstRow)/columns) end
     else column,line=extra%columns,1+math.floor(extra/columns);extra=extra+1 end
     slot:SetFrameStrata(strata);slot:SetFrameLevel(level-1);slot:SetSize(control,control)
     slot:ClearAllPoints();slot:SetPoint("BOTTOMLEFT",self.overlay,"BOTTOMLEFT",7+column*step,5+line*step)
     local ok=lease("Scalar",owner,object,"frameStrata","GetFrameStrata","SetFrameStrata",strata)
     ok=lease("Scalar",owner,object,"frameLevel","GetFrameLevel","SetFrameLevel",level) and ok
     ok=lease("Write",owner,object,"parent",function(o)
      local parent,state=value(o,"GetParent");if state=="KNOWN" then return L.Pack(parent) end
     end,function(o,v,fence)
      -- This inverse is used during Release too. Fence the exact receipt and
      -- entry lifecycle, not a blanket active-owner predicate that would make
      -- restoration impossible. A reentrant handback must stop the remaining
      -- layer setters after SetParent returns.
      local profile,record,active,generation=M.profile,N.record,owner.active,owner.generation
      local lookup=owner.lookup;local entries=lookup and lookup[o];local receipt=entries and entries.parent
      local releasing=owner.releasing
      local function current()
       return receipt and M.profile==profile and N.record==record and owner.active==active
        and owner.generation==generation and owner.releasing==releasing and owner.lookup==lookup
        and lookup[o]==entries and entries.parent==receipt and (not fence or fence())
      end
      if not current() then return false end
      local oldLevel,ls=value(o,"GetFrameLevel","number");local oldStrata,ss=value(o,"GetFrameStrata","string")
      if not current() or ls~="KNOWN" or ss~="KNOWN" then return false end
      local sent=write(o,"SetParent",v[1])
      if not current() or not sent or value(o,"GetParent")~=v[1] or not current() then return false end
      sent=write(o,"SetFrameStrata",oldStrata)
      if not current() or not sent then return false end
      sent=write(o,"SetFrameLevel",oldLevel)
      if not current() or not sent then return false end
      return value(o,"GetFrameLevel","number")==oldLevel and value(o,"GetFrameStrata","string")==oldStrata and current()
     end,L.Pack(self.overlay)) and ok
     ok=lease("Scalar",owner,object,"scale","GetScale","SetScale",scale) and ok
     ok=lease("Points",owner,object,L.Pack("CENTER",slot,"CENTER",0,0)) and ok
     if ok then
      row.written=true;row.points=points(object);row.writtenScale=scale;row.retryable=nil
      row.envelopeWidth,row.envelopeHeight=envelopeWidth,envelopeHeight;recovery.geometryPending=nil;recovery.status="CONFIRMED";slot:Show()
     else
      slot:Hide()
      -- A native launcher is indivisible: do not leave its parent moved while
      -- its scale/anchor was rejected. Hand this row back before retaining the
      -- independently usable terrain. A finite retry may reacquire it only
      -- after verified rollback and a fresh original-custody observation.
      if row.written then recovery.attempts=1 end
      owner.active=false;row.displaced=true;row.failure="UTILITY_LAYOUT_FAILED"
      row.rollbackPending=not lease("Release",owner) or nil
      row.retryable=not row.rollbackPending and self:OriginalUtilityLayout(row) or nil
      if not row.rollbackPending then row.written=nil end
      recovery.status=row.rollbackPending and "ROLLBACK_PENDING" or row.retryable and "RETRY_PENDING" or "CUSTODY_CHANGED"
     end
     complete=ok and complete
    else
     if self.utilitySlots[spec.key] then self.utilitySlots[spec.key]:Hide() end
     complete=false
    end
   else complete=false end
   if not row and recovery.geometryPending or row and row.retryable then
    if recovery.attempts<utilityRecoveryLimit then r.utilityRetryPending=true
    else recovery.status="RETRY_EXHAUSTED" end
   end
  elseif object~=nil then complete=false
  elseif self.utilitySlots[spec.key] then self.utilitySlots[spec.key]:Hide() end
 end
 ensure()
 self.utilityStatus=complete and ("NATIVE_ROUTES_DOCKED:"..present) or "NATIVE_UTILITY_LAYOUT_PENDING"
 return complete
 end)
 if not okay then
  if current() then self.utilityStatus="NATIVE_UTILITY_LAYOUT_PENDING" end
  return false
 end
 return result
end
function N:LayoutHeader(layout,fontScale)
 self.headerLayout={width=layout.width,fontScale=fontScale}
 local icon=math.max(14,math.min(22,16*fontScale))
 local lineHeight=math.max(14,14*fontScale)
 local height=math.max(icon,lineHeight)+8
 self.header:SetHeight(height)
 self.navigationArrow:ClearAllPoints();self.navigationArrow:SetSize(icon,icon)
 self.navigationArrow:SetPoint("TOPLEFT",self.overlay,"TOPLEFT",7,-(height-icon)/2)
 local inset=icon+12
 local distance=self.headerText and self.headerText.detail or ""
 local path,size,flags
 local got;got,path,size,flags=call(self.navigationInfo,"GetFont")
 if not got or not S:Text(path) or not S:Number(size) then path=STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF";size=10 end
 -- The distance has priority over the destination name. Keep its own font
 -- unconstrained while measuring, including on the first nonempty snapshot
 -- and when the number grows from three to four digits.
 local measure=self.navigationMeasure
 local measured
 if measure then
  write(measure,"SetFont",path,size,S:Text(flags) and flags or "")
  write(measure,"SetWidth",0);write(measure,"SetText",distance)
  measured=value(measure,"GetUnboundedStringWidth","number") or value(measure,"GetStringWidth","number")
 end
 if not measured or measured<=0 then measured=#distance*size*.67 end
 local distanceWidth=distance~="" and math.ceil(measured+6) or 0
 local available=math.max(1,layout.width-inset-8-8-16)
 -- Very narrow/high-text-scale layouts can dedicate a separate line instead
 -- of truncating a number or silently dropping its unit.
 local stacked=distanceWidth>available
 if stacked then height=height+lineHeight+2;self.header:SetHeight(height) end
 self.location:ClearAllPoints();self.location:SetPoint("TOPLEFT",inset,-(height-lineHeight)/2)
 self.location:SetSize(math.max(16,layout.width-inset-8-(stacked and 0 or distanceWidth+(distanceWidth>0 and 8 or 0))),lineHeight)
 self.navigationInfo:ClearAllPoints();self.navigationInfo:SetPoint("TOPRIGHT",self.overlay,"TOPRIGHT",-8,-(height-lineHeight)/2)
 self.navigationInfo:SetSize(math.max(1,distanceWidth),lineHeight)
 if stacked then
  self.location:ClearAllPoints();self.location:SetPoint("TOPLEFT",inset,-4)
  self.navigationInfo:ClearAllPoints();self.navigationInfo:SetPoint("TOPRIGHT",self.overlay,"TOPRIGHT",-8,-lineHeight-6)
  self.navigationArrow:ClearAllPoints();self.navigationArrow:SetPoint("TOPLEFT",self.overlay,"TOPLEFT",7,-4)
 end
 self.navigationInfo:SetJustifyH("RIGHT")
 self.headerFit=stacked and "NAVIGATION_DISTANCE_SECOND_ROW" or "NAVIGATION_SINGLE_ROW"
end
function N:UpdateNavigationHeader()
 local profile,record=M.profile,self.record
 local titleRegion,detailRegion,arrow=self.location,self.navigationInfo,self.navigationArrow
 local transaction={};self.headerTransaction=transaction
 local function current()
  return self.active and self.record==record and M.profile==profile and self.headerTransaction==transaction
   and self.location==titleRegion and self.navigationInfo==detailRegion and self.navigationArrow==arrow
 end
 local api=_G.MirageNavigateAPI
 local getter,access=S:FieldAccess(api,"GetHeaderSnapshot")
 local snapshot,state=S:Public(access=="KNOWN" and getter or nil,nil)
 if not current() then return false end
 local title,detail,status,angle="Wayfinder","Navigation unavailable","UNAVAILABLE",nil
 if state=="KNOWN" and S:Readable(snapshot) and type(snapshot)=="table" then
  local t,ts=S:FieldAccess(snapshot,"title");local d,ds=S:FieldAccess(snapshot,"detail")
  local st,ss=S:FieldAccess(snapshot,"status");local a,as=S:FieldAccess(snapshot,"angle")
  if ts=="KNOWN" and S:Text(t) then title=t:sub(1,240) end
  if ds=="KNOWN" and S:Text(d) then detail=d:sub(1,160) end
  if ss=="KNOWN" and S:Text(st) then status=st end
  if as=="KNOWN" and S:Number(a) and (status=="GUIDING" or status=="NEAR_DESTINATION") then angle=a end
 end
 -- One baseline: direction, destination, distance. State messages replace the
 -- destination only when guidance is unavailable; never add a second row.
 if status=="GUIDING" or status=="NEAR_DESTINATION" then
  local distance,known=S:FieldAccess(snapshot,"distance")
  if known=="KNOWN" and S:Number(distance) and distance>=0 then detail=string.format("%.0f yards",distance)
  else local digits=detail:match("^(%d+)%s+y[da]");detail=digits and digits.." yards" or "" end
 else title=detail~="" and detail or title;detail="" end
 if not current() then return false end
 self.headerText=self.headerText or {}
 local changed=false
 for _,entry in ipairs({{"title",titleRegion,title},{"detail",detailRegion,detail}}) do
  local content=entry[3]:gsub("|","||")
  if self.headerText[entry[1]]~=content then
   local applied=write(entry[2],"SetText",content)
   if not current() then return false end
   if applied then self.headerText[entry[1]]=content;changed=true end
  end
 end
 if changed and self.headerLayout then
  self:LayoutHeader(self.headerLayout,self.headerLayout.fontScale)
  if not current() then return false end
 end
 -- A refused bearing must not leave a stale arrow presented as current. Retry
 -- on the existing bounded tick, using a neutral badge (or no icon if even its
 -- rotation cannot be reset) until the direction setter succeeds.
 local rotation=angle or 0
 local rotated=self.headerAngle==rotation
 if not rotated then
  rotated=write(arrow,"SetRotation",rotation)
  if not current() then return false end
  self.headerAngle=rotated and rotation or nil
  if rotated then changed=true end
 end
 local visible=rotated
 if not rotated and rotation~=0 then
  visible=write(arrow,"SetRotation",0)
  if not current() then return false end
  if visible then self.headerAngle=0;changed=true end
 end
 local icon=angle~=nil and rotated and "Interface\\AddOns\\MirageIntel_Navigate\\UI\\Arrow.tga"
  or "Interface\\AddOns\\MirageUI\\Media\\MirageUIBadge.tga"
 if self.headerIcon~=icon then
  local applied=write(arrow,"SetTexture",icon)
  if not current() then return false end
  if applied then self.headerIcon=icon;changed=true else visible=false end
 end
 if self.headerArrowVisible~=visible then
  local applied=write(arrow,visible and "Show" or "Hide")
  if not current() then return false end
  if applied then self.headerArrowVisible=visible;changed=true end
 end
 self.navigationStatus=status
 return changed
end
function N:LayoutCanvas()
 local r=self.record;if not self.active or not r or not wanted() then return self:Failure("MAP_OWNER_UNAVAILABLE","CANVAS") end
 if S:InCombat() then return self:Failure("COMBAT_LOCKDOWN","CANVAS") end
 if r.conflict then return self:AbortCanvas(r.conflict,"CUSTODY") end
 -- A native setter may synchronously hand the map back, switch profile, or
 -- start a newer layout. Retire the outer transaction before another setter;
 -- its obsolete receipt must never repaint the restored native map.
 local profile,frame=M.profile,self.frame
 local transaction={};self.canvasTransaction=transaction
 local expectedParent
 local function current()
  local function identity()
   return self.active and self.record==r and self.frame==frame and r.map==_G.Minimap
    and self.canvasTransaction==transaction and M.profile==profile and not M.state.safe
  end
  return identity() and wanted() and identity()
 end
 local nativeValue,nativeWrite,nativeCall,nativePoints=value,write,call,points
 local function ensure(readOnly)
  if not current() or r.conflict or not readOnly and S:InCombat() then error(transaction,0) end
  if expectedParent then
   local parent,state=nativeValue(r.map,"GetParent")
   if not current() then error(transaction,0) end
   if state~="KNOWN" or parent~=expectedParent then
    r.conflict="EXTERNAL_PARENT_CHANGE";error(transaction,0)
   end
  end
 end
 local function value(...)
  ensure(true);local result,state=nativeValue(...);ensure(true);return result,state
 end
 local function write(...)
  ensure();local result=nativeWrite(...);ensure(true);return result
 end
 local function call(...)
  ensure();local ok,result=nativeCall(...);ensure(true);return ok,result
 end
 local function points(...)
  ensure(true);local result=nativePoints(...);ensure(true);return result
 end
 local ok,result,why=pcall(function()
 ensure()
 local f,map=self.frame,r.map;local l=self.layout or M.Layout:Get(self.surface)
 -- The requested sidebar uses a square canvas regardless of an old round
 -- preference. SidebarLayout preserves that old preference/rectangle in saved
 -- storage and supplies one shared runtime width for all three elements.
 local width=math.max(1,l.width-2);local height=width
 local canvasY=0
 local refreshTerrain=not r.canvasCommitted or r.canvasWidth~=width or r.canvasHeight~=height
 -- This widget is the native Minimap, not its EditModeSystemMixin cluster.
 -- Use its own documented region methods. Clear the captured anchors before
 -- sizing: two-point anchors can otherwise override SetSize's effective size.
 -- Keep every attempted value before dispatch so even a partly rejected
 -- setter can be handed back. No utility/control lease starts before commit.
 r.priorCanvasWidth,r.priorCanvasHeight,r.priorCanvasY=r.canvasWidth,r.canvasHeight,r.canvasY
 r.canvasY=canvasY;r.canvasWidth=width;r.canvasHeight=height;r.mask=squareMask
 self.writing=transaction
 if not r.parentAttempted and value(map,"GetParent")~=r.parent then
  r.conflict="EXTERNAL_PARENT_CHANGE";return self:AbortCanvas(r.conflict,"CUSTODY")
 end
 r.parentAttempted=true;r.restoreGeometry=true
 if value(map,"GetParent")~=f and not write(map,"SetParent",f) then return self:AbortCanvas("MAP_PARENT_WRITE_FAILED","PARENT") end
 local parent,parentState=value(map,"GetParent")
 if parentState~="KNOWN" then return self:AbortCanvas("MAP_PARENT_READBACK_UNAVAILABLE","PARENT") end
 if parent~=f then return self:AbortCanvas("MAP_PARENT_READBACK_MISMATCH","PARENT") end
 expectedParent=f
 r.ownedLevel=value(map,"GetFrameLevel","number");r.ownedStrata=value(map,"GetFrameStrata","string")
 r.geometryAttempted=true
 local cleared=write(map,"ClearAllPoints");r.clearPointsObserved=points(map)
 if not cleared then return self:AbortCanvas("MAP_CLEAR_POINTS_WRITE_FAILED","POINTS") end
 local count,countState=value(map,"GetNumPoints","number")
 if countState~="KNOWN" or count~=0 then return self:AbortCanvas("MAP_CLEAR_POINTS_READBACK_FAILED","POINTS") end
 r.scaleAttempted=true
 local scaled=write(map,"SetScale",1);r.scaleObserved=value(map,"GetScale","number")
 if not scaled then return self:AbortCanvas("MAP_SCALE_WRITE_FAILED","SCALE") end
 r.sizeAttempted=true
 local sized=write(map,"SetSize",width,height)
 -- The engine can cache the old on-screen rectangle until the next frame.
 -- Read the just-submitted dimensions here. Terrain refresh separately checks
 -- the settled, visible rectangle before pulsing native zoom.
 r.widthObserved=value(map,"GetWidth","number",true);r.heightObserved=value(map,"GetHeight","number",true)
 if not sized then return self:AbortCanvas("MAP_SIZE_WRITE_FAILED","SIZE") end
 local anchored=write(map,"SetPoint","CENTER",f,"CENTER",0,canvasY);r.pointsObserved=points(map)
 if not anchored then return self:AbortCanvas("MAP_POINT_WRITE_FAILED","POINTS") end
 if not samePoints(r.pointsObserved,{{"CENTER",f,"CENTER",0,canvasY}}) then return self:AbortCanvas("MAP_POINT_READBACK_MISMATCH","POINTS") end
 for _,spec in ipairs({{"WIDTH","GetWidth",width},{"HEIGHT","GetHeight",height},{"SCALE","GetScale",1}}) do
  local got,state
  if spec[2]=="GetScale" then got,state=value(map,spec[2],"number")
  else got,state=value(map,spec[2],"number",true) end
  if state=="KNOWN" then r[spec[1]:lower().."Observed"]=got end
  if state~="KNOWN" then return self:AbortCanvas("MAP_"..spec[1].."_READBACK_UNAVAILABLE",spec[1]) end
  if not near(got,spec[3]) then return self:AbortCanvas("MAP_"..spec[1].."_READBACK_MISMATCH",spec[1]) end
 end
 r.maskAttempted=true
 self.maskDirty=nil
 if not write(map,"SetMaskTexture",r.mask) then return self:AbortCanvas("MAP_MASK_WRITE_FAILED","MASK") end
 if type(field(map,"GetMaskTexture"))=="function" then
  local mask,state=value(map,"GetMaskTexture")
  if state~="KNOWN" then return self:AbortCanvas("MAP_MASK_READBACK_UNAVAILABLE","MASK") end
  if mask~=r.mask then return self:AbortCanvas("MAP_MASK_READBACK_MISMATCH","MASK") end
 end
 self.maskSubmission=r.maskContract=="GETTER_READBACK" and "MASK_READBACK_MATCHED" or "MASK_SUBMITTED_NO_NATIVE_READBACK"
 r.alphaAttempted=true
 local alphaSet=write(map,"SetAlpha",1);r.alphaObserved=value(map,"GetAlpha","number")
 if not alphaSet then return self:AbortCanvas("MAP_ALPHA_WRITE_FAILED","ALPHA") end
 if r.alphaObserved~=1 then return self:AbortCanvas("MAP_ALPHA_READBACK_MISMATCH","ALPHA") end
 r.showAttempted=true
 if not write(map,"Show") then return self:AbortCanvas("MAP_SHOW_WRITE_FAILED","SHOWN") end
 if value(map,"IsShown","boolean")~=true then return self:AbortCanvas("MAP_SHOW_READBACK_MISMATCH","SHOWN") end
 local level,levelState=value(map,"GetFrameLevel","number")
 local strata,strataState=value(map,"GetFrameStrata","string")
 if levelState~="KNOWN" or strataState~="KNOWN" then return self:AbortCanvas("MAP_LAYER_READBACK_UNAVAILABLE","LAYER") end
 r.ownedLevel=level;r.ownedStrata=strata
 local layered=write(self.overlay,"SetFrameStrata",strata) and write(self.overlay,"SetFrameLevel",level+5)
 for _,control in ipairs({self.settingsButton,self.mapButton,self.zoomOut,self.zoomIn}) do layered=write(control,"SetFrameLevel",level+6) and layered end
 if not layered or value(self.overlay,"GetFrameStrata","string")~=strata or value(self.overlay,"GetFrameLevel","number")~=level+5 then
  return self:AbortCanvas("MAP_OVERLAY_LAYER_FAILED","LAYER")
 end
 if self.writing==transaction then self.writing=nil end
 ensure()
 r.written=true;r.canvasCommitted=true
 -- Guidance uses one compact line; native utilities wrap
 -- within the square. The translucent status strip does not consume map
 -- height or intercept clicks. The remaining terrain retains native pings.
 local fontScale=M.profile and M.profile.textScale or 1
 if not S:Number(fontScale) then fontScale=1 end;fontScale=math.max(.65,math.min(2,fontScale))
 self.controlSize=math.max(20,math.min(28,12*fontScale+8));self.toolbarHeight=self.controlSize+10
 self.toolbar:SetHeight(self.toolbarHeight);self.header:Show();self.toolbarFill:Hide()
 for _,control in ipairs({self.settingsButton,self.mapButton,self.zoomOut,self.zoomIn}) do control:SetSize(self.controlSize,self.controlSize);control:ClearAllPoints() end
 self.settingsButton:SetPoint("BOTTOMLEFT",7,5)
 self.mapButton:SetPoint("BOTTOMLEFT",7+self.controlSize+4,5)
 self.zoomIn:SetPoint("BOTTOMRIGHT",-7,5)
 self.zoomOut:SetPoint("RIGHT",self.zoomIn,"LEFT",-4,0)
 self:LayoutHeader(l,fontScale)
 ensure();self:LayoutCoordinates(l)
 ensure();self:LayoutUtilities(l)
 ensure();self:ApplyBlobRings()
 ensure();self.questFilterReady=self:ApplyQuestFilter()
 ensure()
 for _,row in pairs(r.utilities or {}) do
  if row.rollbackPending then return self:AbortCanvas("MAP_UTILITY_RESTORE_PENDING","UTILITIES") end
 end
 local art=self:SuppressArt();ensure();self.dirty=nil;self.maskFailures=nil;self.utilitiesDirty=nil
 if refreshTerrain then self:QueueTerrainRefresh("CANVAS_CHANGED") end
 self:RefreshAuxiliaryStatus(art)
 return true,self.status
 end)
 if self.writing==transaction then self.writing=nil end
 if not ok then
  if result==transaction then
   if self.record==r and self.canvasTransaction==transaction and r.conflict then
    return self:AbortCanvas(r.conflict,"CUSTODY")
   end
   if current() and S:InCombat() then return self:AbortCanvas("COMBAT_LOCKDOWN","CANVAS") end
   return false,"MAP_LAYOUT_SUPERSEDED"
  end
  if current() then return self:AbortCanvas("MAP_CANVAS_CALLBACK_FAILED","CANVAS") end
  return false,"MAP_LAYOUT_SUPERSEDED"
 end
 return result,why
end
function N:KnownNativeLayout()
 local r=self.record;if not r then return false end
 local parent=value(r.map,"GetParent");local current=points(r.map)
 if parent~=self.frame and parent~=r.parent then return false end
 if not samePoints(current,{{"CENTER",self.frame,"CENTER",0,r.canvasY or 0}}) and not samePoints(current,r.points) then return false end
 for _,spec in ipairs({{"GetWidth",r.canvasWidth,r.width},{"GetHeight",r.canvasHeight,r.height},{"GetScale",1,r.scale}}) do
  local v=value(r.map,spec[1],"number")
  if not near(v,spec[2]) and not near(v,spec[3]) then return false end
 end
 return true
end
function N:Visibility()
 if not self.active then return end
 local desired=self.surface.desired
 if desired==nil then return true,"CONTEXT_DECISION_PENDING" end
 if not legal(self.frame) then self.status="VISIBILITY_COMBAT_DEFERRED";return false end
 local a=desired=="HIDDEN" and 0 or desired=="AMBIENT" and .25 or 1
 local cfg=M.profile.modules.Minimap
 if S:Number(cfg.alpha) then a=a*cfg.alpha end
 local groups=M.PresentationGroups
 local grouped=groups and groups:Enabled()
 if grouped and (S:InCombat() or groups:State().actualCombat==true) then a=(cfg.alpha or 1)*.5 end
 if M.state.keybindWorkspace then a=0 end
 local effects=M.Effects
 if effects and effects.Transition and S:Frame(self.frame,true) then
  local profile,record,keybindMode=M.profile,self.record,M.state.keybindWorkspace==true
  local hover=self.surface.localHover==true or desired=="HIDDEN" and self.contextHover==true
  if grouped and groups:Demand("NAV")==true then hover=false end
  self.contextHover=hover
  return effects:Transition(self,self.frame,a>0,{alpha=a,
   now=grouped and groups:TransitionClock("NAV") or nil,constantRate=grouped,ceiling=cfg.alpha or 1,guard=function()
   return N.active and N.record==record and M.profile==profile and wanted() and not M.state.safe and (M.state.keybindWorkspace==true)==keybindMode
  end})
 end
 local ok=true
 if value(self.frame,"GetAlpha","number")~=a then ok=call(self.frame,"SetAlpha",a) end
 if value(self.frame,"IsShown","boolean")~=(a>0) then ok=call(self.frame,a>0 and "Show" or "Hide") and ok end
 return ok
end
function N:Configure()
 if not eligible() then return self:Suspend("UNSELECTED") end
 local editing=R:NativeEditState()
 if editing=="UNKNOWN" then return R:Result("DEFERRED_HANDOFF","NATIVE_EDIT_UNKNOWN") end
 if editing=="OPEN" then return self:Suspend("NATIVE_EDIT_HANDOFF") end
 if not screen() then self.viewportPending=true;self.status="VIEWPORT_PENDING";return R:Result("WAITING",self.status) end
 self.viewportPending=nil
 if self.blockedProfile==M.profile then return self:Failure(self.blockedReason,"CUSTODY") end
 if self.record and not self.active then if not self:Suspend(self.restoreReason) then return false,"STYLE_RESTORE_PENDING" end end
 local nativeFallback=self:NativeMaskFallback()
 if nativeFallback then return nativeFallback end
 self.nativeMaskFallback=nil
 local initialized,why=self:Initialize();if not initialized then return false,why or self.status end
 if self.record and self.record.map~=_G.Minimap then if not self:Suspend("MAP_REPLACED") then return false,"STYLE_RESTORE_PENDING" end end
 if not self.record then
  local acquired,detail=self:Acquire();if not acquired then return false,detail or self.status end
 else
  if self.record.conflict then return self:Failure(self.record.conflict,"CUSTODY") end
  self:CaptureArt()
  if not S:InCombat() then
   local applied,layoutWhy=M.Layout:Apply(self.surface)
   if applied==false then return false,layoutWhy or self.status end
  end
 end
 self:Visibility()
 return healthResult(self)
end
function N:NeedsRuntimeTick()
 if self.viewportPending and not screen() then return false end
 -- Retain this provider's existing native identity/terrain liveness cadence.
 return nil
end
function N:Tick(now)
 now=S:Number(now) and now or S:Now()
 if now<(self.nextTick or 0) then return end
 -- A guarded native fallback does not poll its unobservable mask at 4 Hz.
 self.nextTick=now+(self.nativeMaskFallback and 2 or .25)
 if not eligible() then return self:Suspend("UNSELECTED") end
 local editing=R:NativeEditState()
 if editing=="UNKNOWN" then return R:Result("DEFERRED_HANDOFF","NATIVE_EDIT_UNKNOWN") end
 if editing=="OPEN" then return self:Suspend("NATIVE_EDIT_HANDOFF") end
 if not self.active then return self:Configure() end
 local r=self.record
 if not r or r.map~=_G.Minimap then return self:Configure() end
 local work=false
 if r.conflict then local why=r.conflict;self:Suspend(why);return R:Result("CONFLICT",why,"Minimap") end
 if self.nativeGeometryDirty and not S:InCombat() then
  self.nativeGeometryDirty=nil
  if value(r.map,"GetParent")~=self.frame or not samePoints(points(r.map),{{"CENTER",self.frame,"CENTER",0,r.canvasY or 0}})
   or not near(value(r.map,"GetWidth","number"),r.canvasWidth) or not near(value(r.map,"GetHeight","number"),r.canvasHeight)
   or not near(value(r.map,"GetScale","number"),1) then
   if self:KnownNativeLayout() then
    -- Count only a verified displacement of the owned map. Addon loading,
    -- scale notifications and content refreshes also dirty the provider but
    -- do not establish another geometry owner or consume this retry budget.
    if not self.driftWindow or now-self.driftWindow>2 then self.driftWindow=now;self.driftCount=0 end
    self.driftCount=(self.driftCount or 0)+1
    if self.driftCount>8 then r.conflict="REPEATED_NATIVE_LAYOUT_CONFLICT";self:Suspend(r.conflict);return end
    self.dirty=true;r.nativeLayoutResets=(r.nativeLayoutResets or 0)+1
   else
    r.conflict="NATIVE_MINIMAP_LAYOUT_RECLAIMED";self:Suspend(r.conflict)
    return R:Result("CONFLICT",r.conflict,"Minimap")
   end
  end
 end
 if self.dirty and not S:InCombat() then
  local applied,why=self:ApplyLayout(self.surface)
  if not applied then return false,why or self.status end
  work=true
 elseif self.maskDirty and not S:InCombat() then
  -- Camelot UpdateMinimapConfig reapplies the reviewed round mask (including
  -- rotateMinimap changes). Reconcile that exact default without reacquiring
  -- geometry or yielding to a merely cosmetic native configuration pass.
  self.writing=true;self.maskDirty=nil
  local sent,result=call(r.map,"SetMaskTexture",squareMask)
  local okay=sent and result~=false and not self.maskDirty
  if type(field(r.map,"GetMaskTexture"))=="function" then okay=value(r.map,"GetMaskTexture")==squareMask and okay end
  self.writing=nil
  if self.record~=r or not self.active then return end
  if r.conflict then local why=r.conflict;self:Suspend(why);return R:Result("CONFLICT",why,"Minimap") end
  self.maskDirty=not okay
  work=true
  if okay then
   self.maskSubmission=r.maskContract=="GETTER_READBACK" and "MASK_READBACK_MATCHED" or "MASK_SUBMITTED_NO_NATIVE_READBACK"
   self.maskFailures=nil
   self:RefreshAuxiliaryStatus(self:SuppressArt())
  else
   self.maskFailures=(self.maskFailures or 0)+1;self.status="MAP_MASK_APPLY_PENDING"
   if self.maskFailures>=3 then
    self:Suspend("MAP_MASK_APPLY_FAILED")
    return R:Result("PARTIAL","MAP_MASK_APPLY_FAILED","Minimap")
   end
  end
 end
 if (self.utilitiesDirty or r.utilityRetryPending) and not S:InCombat() then
  self.utilitiesDirty=nil
  self.utilityRecoveryPasses=(self.utilityRecoveryPasses or 0)+1
  self:LayoutUtilities(self.layout)
  work=true
  for _,row in pairs(r.utilities or {}) do
   if row.rollbackPending then return self:AbortCanvas("MAP_UTILITY_RESTORE_PENDING","UTILITIES") end
  end
  self:RefreshAuxiliaryStatus()
 end
 if (r.blobDirty or r.blobRetryPending) and not S:InCombat() then
  self:ApplyBlobRings();work=true
  self:RefreshAuxiliaryStatus()
 end
 if r.questFilterDirty and not S:InCombat() then
  self.questFilterReady=self:ApplyQuestFilter();work=true;self:RefreshAuxiliaryStatus()
 end
 for _,a in ipairs(r.art) do
  if a.dirty then self:RefreshAuxiliaryStatus(self:SuppressArt());work=true;break end
 end
 if r.clusterInput and r.clusterInput.dirty then self:RefreshAuxiliaryStatus(self:SuppressArt());work=true end
 -- Cheap local-state reads catch engine/native writes that bypass a Lua method
 -- hook. They do not infer whether the terrain raster refreshed on screen.
 local terrainBefore,coordinatesBefore=self.terrainStatus,self.coordinateStatus
 if not self:TerrainCurrent() then self:ReconcileTerrain(now);work=true end
 if r.terrainRefreshPending or r.terrainZoom then self:RefreshTerrainRaster(now);work=true end
 if not self:CoordinatesCurrent() then
  local coordinateRow=r.coordinates
  if not S:InCombat() and (not coordinateRow or not coordinateRow.blocked) then
   if coordinateRow and (not coordinateRow.window or now-coordinateRow.window>2) then coordinateRow.window=now;coordinateRow.repairs=0 end
   if coordinateRow and (coordinateRow.repairs or 0)>=4 then coordinateRow.blocked=true;self.coordinateStatus="COORDINATE_REPEATED_CONFLICT"
   else
    if coordinateRow then coordinateRow.repairs=(coordinateRow.repairs or 0)+1 end
    self:LayoutCoordinates(self.layout)
   end
  end
  work=true
 end
 if terrainBefore~=self.terrainStatus or coordinatesBefore~=self.coordinateStatus or work then self:RefreshAuxiliaryStatus() end
 self:Visibility()
 if self:UpdateNavigationHeader() then work=true end
 if work or self.reportedStatus~=self.status then return healthResult(self) end
end
function N:OnEvent(event,arg1)
 local trackingCVar=event=="CVAR_UPDATE" and S:Text(arg1) and arg1:lower():match("^minimaptrackedinfo")~=nil
 if self.active and self.record and not self.questFilterWriting and (event=="MINIMAP_UPDATE_TRACKING" or event=="PLAYER_ENTERING_WORLD" or event=="ADDON_LOADED" or trackingCVar) then
  self.record.questFilterDirty=true
  if S:InCombat() then self.questFilterReady=false;self.questFilterStatus="NATIVE_QUEST_FILTER_COMBAT_DEFERRED" end
 end
 if event=="PLAYER_REGEN_ENABLED" or event=="PLAYER_ENTERING_WORLD" then
  local r=self.record
  if r then r.terrainBlocked=nil;r.terrainAttempts=0;if r.coordinates then r.coordinates.blocked=nil;r.coordinates.repairs=0 end end
 end
 if event=="PLAYER_ENTERING_WORLD" or event=="LOADING_SCREEN_DISABLED" or event=="ZONE_CHANGED_NEW_AREA" then
  self:QueueTerrainRefresh(event)
 end
 if event=="ADDON_LOADED" and self.active then
  self:CaptureArt()
  local coordinates=field(field(_G.MinimapCluster,"MinimapContainer"),"PlayerCoords")
  local row=self.record and self.record.coordinates
  if coordinates~=(row and row.object) then self.dirty=true end
  self.dirty=true -- newly loaded native utility buttons join the fixed toolbar.
 elseif event=="PLAYER_ENTERING_WORLD" or event=="EDIT_MODE_LAYOUTS_UPDATED" then self.dirty=true
 elseif event=="DISPLAY_SIZE_CHANGED" or event=="UI_SCALE_CHANGED" then self.dirty=true;self.nextText=0
 elseif event=="CVAR_UPDATE" and S:Text(arg1) and arg1:lower()=="rotateminimap" then self.maskDirty=true
 elseif event=="DIEL_CYCLE_CHANGED" then self.nextText=0;self:CaptureArt()
 elseif event=="ZONE_CHANGED" or event=="ZONE_CHANGED_INDOORS" or event=="ZONE_CHANGED_NEW_AREA" or event=="MINIMAP_UPDATE_ZOOM" then self.nextText=0 end
end
function N:Retry()
 if S:InCombat() then return false end
 if self.active and self.record and not self.record.conflict then
  local r=self.record;r.terrainBlocked=nil;r.terrainAttempts=0;r.terrainDirty=true
  self:QueueTerrainRefresh("EXPLICIT_RECOVER")
  r.questFilterDirty=true;if r.questFilter then r.questFilter.attempts=0 end
  if r.coordinates then r.coordinates.blocked=nil;r.coordinates.repairs=0;r.coordinates.dirty=true end
  return true
 end
 if self.record then return false end
 self.blockedProfile=nil;self.blockedReason=nil;self.nativeGeometryDirty=nil;self.maskDirty=nil;self.maskFailures=nil;self.utilitiesDirty=nil
 self.nativeMaskFallback=nil;self.nextTick=0
 return true
end
function N:Suspend(reason)
 local r=self.record;self.active=false
 if M.Effects and M.Effects.CancelTransition and self.frame then M.Effects:CancelTransition(self,self.frame,false) end
 self.restoreReason=reason
 if reason=="EXTERNAL_MASK_CHANGE" or reason=="EXTERNAL_PARENT_CHANGE" or reason=="REPEATED_NATIVE_LAYOUT_CONFLICT" or reason=="NATIVE_MINIMAP_LAYOUT_RECLAIMED" or reason=="MAP_MASK_APPLY_FAILED" then self.blockedProfile=M.profile;self.blockedReason=reason end
 if not r then if self.frame and legal(self.frame) then self.frame:Hide() end;self.status=reason or "SUSPENDED";return true end
 if S:InCombat() then self.status="RESTORE_COMBAT_DEFERRED";return false,"COMBAT_LOCKDOWN" end
 self:ReleaseBlobRings(r)
 self.writing=true;local complete=self:ReleaseQuestFilter(r)
 complete=self:ReleaseTerrainZoom(r) and complete
 if r.coordinates then
  r.coordinates.owner.active=false
  complete=R.CombatLeases:Release(r.coordinates.owner) and complete
 end
 for _,row in pairs(r.utilities or {}) do row.owner.active=false;complete=R.CombatLeases:Release(row.owner) and complete end
 if S:Frame(r.map,false) then
  local parent,parentState=value(r.map,"GetParent")
  if parentState~="KNOWN" then complete=false end
  -- A different addon may have taken the map. Its parent/geometry wins recovery.
  if parent==self.frame or (r.restoreGeometry and parent==r.parent) then
   r.restoreGeometry=true
   if parent==self.frame then complete=write(r.map,"SetParent",r.parent) and value(r.map,"GetParent")==r.parent and complete end
   local current=points(r.map);local owned={{"CENTER",self.frame,"CENTER",0,r.canvasY or 0}}
   local restorePoints=false
   if not current then complete=false
   elseif samePoints(current,r.points) then r.inversePointsObserved=nil;r.inversePointsUnobserved=nil
   elseif samePoints(current,owned) or (r.priorCanvasY~=nil and samePoints(current,{{"CENTER",self.frame,"CENTER",0,r.priorCanvasY}}))
    or samePoints(current,r.pointsObserved) or samePoints(current,r.clearPointsObserved)
    or samePoints(current,r.inversePointsObserved) or r.geometryAttempted and #current==0 then restorePoints=true
   elseif r.inversePointsUnobserved then complete=false end
   local function restoreNumber(get,set,original,last,prior,attempted,observed)
    if not attempted then return true end
    local debt=r.inverseNumbers and r.inverseNumbers[get]
    local function readNumber()
     if get=="GetWidth" or get=="GetHeight" then return value(r.map,get,"number",true) end
     return value(r.map,get,"number")
    end
    local current,state=readNumber()
    if state~="KNOWN" then return false end
    if near(current,original) then if r.inverseNumbers then r.inverseNumbers[get]=nil end;return true end
    if near(current,last) or near(current,prior) or near(current,observed) or debt and near(current,debt.observed) then
     local sent=write(r.map,set,original)
     local actual,known=readNumber()
     if sent and known=="KNOWN" and near(actual,original) then
      if r.inverseNumbers then r.inverseNumbers[get]=nil end
      return true
     end
     -- The inverse can partially mutate before returning false or throwing.
     -- Its immediate public result belongs to this restoration transaction,
     -- not to a newer external writer. Opaque results retain debt without
     -- guessing a value that would authorize another native mutation.
     r.inverseNumbers=r.inverseNumbers or {}
     r.inverseNumbers[get]={observed=not sent and known=="KNOWN" and actual or nil,unobserved=known~="KNOWN"}
     return false
    end
    if debt and debt.unobserved then return false end
    return true -- a newer external scalar wins independently of other fields
   end
   complete=restoreNumber("GetWidth","SetWidth",r.width,r.canvasWidth,r.priorCanvasWidth,r.sizeAttempted,r.widthObserved) and complete
   complete=restoreNumber("GetHeight","SetHeight",r.height,r.canvasHeight,r.priorCanvasHeight,r.sizeAttempted,r.heightObserved) and complete
   complete=restoreNumber("GetScale","SetScale",r.scale,1,nil,r.scaleAttempted,r.scaleObserved) and complete
   complete=restoreNumber("GetAlpha","SetAlpha",r.alpha,1,nil,r.alphaAttempted,r.alphaObserved) and complete
   -- Restore scalar dimensions before reinstating an anchor pair that could
   -- conceal the last attempted size in its effective-width getter.
   if restorePoints then
    local restored=putPoints(r.map,r.points);local actual=points(r.map)
    if restored and samePoints(actual,r.points) then r.inversePointsObserved=nil;r.inversePointsUnobserved=nil
    else
     -- ClearAllPoints plus several SetPoint calls is one inverse transaction.
     -- Keep a successfully restored prefix if a later anchor setter refuses.
     r.inversePointsObserved=actual;r.inversePointsUnobserved=not actual or nil;complete=false
    end
   end
   -- SetParent can inherit a different native frame level/strata. Restore the
   -- captured layer only while its public posthook has not observed a later
   -- external layer writer. A changed parent still wins the whole handback.
   if r.parentAttempted and not r.externalLevel then complete=write(r.map,"SetFrameLevel",r.level) and value(r.map,"GetFrameLevel","number")==r.level and complete end
   if r.parentAttempted and not r.externalStrata then complete=write(r.map,"SetFrameStrata",r.strata) and value(r.map,"GetFrameStrata","string")==r.strata and complete end
   if r.showAttempted then
    local shown,state=value(r.map,"IsShown","boolean")
    if state~="KNOWN" then complete=false
    elseif shown==true and r.shown==false then complete=write(r.map,"Hide") and value(r.map,"IsShown","boolean")==false and complete end
   end
  end
  if r.maskAttempted and not r.maskDisplaced and r.conflict~="EXTERNAL_MASK_CHANGE"
   and (parent==self.frame or parent==r.parent) then
   local getter=type(field(r.map,"GetMaskTexture"))=="function"
   local current,known
   if getter then current,known=value(r.map,"GetMaskTexture") end
   if getter and known~="KNOWN" then complete=false
   elseif getter and current~=r.mask and current~=r.originalMask then r.conflict="EXTERNAL_MASK_CHANGE"
   elseif not getter or current~=r.originalMask then
    local restored=write(r.map,"SetMaskTexture",r.originalMask)
    if getter then restored=value(r.map,"GetMaskTexture")==r.originalMask and restored end
    complete=restored and complete
    self.maskSubmission=restored and (getter and "NATIVE_MASK_RESTORED" or "NATIVE_MASK_RESTORE_SUBMITTED_NO_GETTER") or "NATIVE_MASK_RESTORE_PENDING"
   end
  end
 else complete=false end
 for _,a in ipairs(r.art) do
  if a.attempted and S:Frame(a.object,false) then
   local alpha,as=value(a.object,"GetAlpha","number")
   if as~="KNOWN" then complete=false end
   if alpha==0 then
    complete=call(a.object,"SetAlpha",a.alpha) and complete
    complete=near(value(a.object,"GetAlpha","number"),a.alpha) and complete
   end
   if a.mouse~=nil then
    local mouse,ms=value(a.object,"IsMouseEnabled","boolean")
    if ms~="KNOWN" then complete=false
    elseif mouse==false then complete=call(a.object,"EnableMouse",a.mouse) and value(a.object,"IsMouseEnabled","boolean")==a.mouse and complete end
   end
   local shown,vs=value(a.object,"IsShown","boolean")
   if vs~="KNOWN" then complete=false
   elseif shown==false then
    complete=call(a.object,a.shown and "Show" or "Hide") and complete
    complete=value(a.object,"IsShown","boolean")==a.shown and complete
   end
  elseif a.attempted then complete=false end
 end
 if r.clusterInput and r.clusterInput.attempted then
  local o=r.clusterInput.object;local current,state=value(o,"IsMouseEnabled","boolean")
  if state~="KNOWN" or not legal(o) then complete=false
  elseif current==false then complete=call(o,"EnableMouse",r.clusterInput.original) and value(o,"IsMouseEnabled","boolean")==r.clusterInput.original and complete end
 end
 if GetMinimapShape==self.shapeFunction then GetMinimapShape=self.originalShape end
 self.writing=nil
 if self.frame and legal(self.frame) then
  local coordinatesHeld=r.coordinates and value(r.coordinates.object,"GetParent")==self.overlay
  local utilitiesHeld=false;for _,row in pairs(r.utilities or {}) do if value(row.object,"GetParent")==self.overlay then utilitiesHeld=true;break end end
  if complete or value(r.map,"GetParent")~=self.frame and not coordinatesHeld and not utilitiesHeld then self.frame:Hide() else self.frame:SetAlpha(1);self.frame:Show() end
 end
 if complete then
  self.coordinateStatus=r.coordinates and "NATIVE_RESTORED" or "NATIVE_UNCHANGED"
  self.utilityStatus=next(r.utilities or {}) and "NATIVE_ROUTES_RESTORED" or "NATIVE_ROUTES_UNCHANGED"
  self.record=nil;self.dirty=nil;self.maskDirty=nil;self.utilitiesDirty=nil;self.nativeGeometryDirty=nil
  self.rootLeaseOwners=nil;self.terrainStatus="NATIVE_RESTORED"
  if self.rollbackStatus=="PENDING" then self.rollbackStatus="VERIFIED" end
  self.status=reason or "SUSPENDED";return true
 end
 self.status="RESTORE_PENDING";return false,"RESTORE_PENDING"
end
function N:Bounds()
 if not self.surface then return nil end
 return M.Layout:Get(self.surface),self.frame
end
function N:Status()
 local auxiliary={};for key,row in pairs(self.record and self.record.utilities or {}) do
  if row.failure then auxiliary[#auxiliary+1]=key..":"..row.failure..":"..(row.owner.leaseDiagnostics and row.owner.leaseDiagnostics.first or "NONE") end
 end;table.sort(auxiliary)
 local recovery={};for key,row in pairs(self.record and self.record.utilityRecovery or {}) do
  if row.status and row.status~="CONFIRMED" then recovery[#recovery+1]=key..":"..row.status..":"..tostring(row.attempts).."/"..utilityRecoveryLimit end
 end;table.sort(recovery)
 local r=self.record;local canvas=r and r.canvasCommitted and r.canvasWidth and r.canvasHeight and (r.canvasWidth.."x"..r.canvasHeight) or r and "pending" or "released"
 return self.status.."; canvas="..canvas.."; shape="..(r and r.canvasCommitted and r.mask==squareMask and "SQUARE_SUBMITTED" or r and "HANDOFF_PENDING" or "NATIVE").."; sidebar=SHARED_WIDTH; coordinates="..(self.coordinateStatus or "NOT_RUN")
  .."; utilities="..(self.utilityStatus or "NOT_RUN").."; native_mask_resets="..tostring(r and r.nativeMaskResets or 0)
  .."; art_gaps="..tostring(self.artGaps or 0).."; mask_contract="..(self.maskContract or "NOT_CAPTURED").."; mask_state="..(self.maskSubmission or "NOT_SUBMITTED")
  .."; last_failure="..(self.lastFailure or "NONE").."; failure_stage="..(self.failureStage or "NONE").."; rollback="..(self.rollbackStatus or "NOT_REQUIRED")
  .."; auxiliary_failures="..(#auxiliary>0 and table.concat(auxiliary,",") or "NONE")
  .."; auxiliary_recovery="..(#recovery>0 and table.concat(recovery,",") or "NONE").."; auxiliary_recovery_passes="..tostring(self.utilityRecoveryPasses or 0)
  .."; navigation_header="..(self.navigationStatus or "NOT_RUN")
  .."; header_fit="..(self.headerFit or "NOT_RUN").."; terrain_liveness="..(self.terrainStatus or "NOT_RUN")
  .."; terrain_local_alpha="..tostring(r and r.terrainAlpha or "UNKNOWN").."; terrain_shown="..tostring(r and r.terrainShown)
  .."; terrain_last_cause="..(r and r.terrainCause or "NONE")
  .."; terrain_refresh="..(self.terrainRefreshStatus or "NOT_REQUESTED")
  .."; terrain_refresh_count="..tostring(r and r.terrainRefreshCount or 0).."; terrain_refresh_cause="..(r and r.terrainRefreshCause or "NONE")
  .."; coordinate_owner="..(r and r.coordinates and R.CombatLeases:Diagnostics(r.coordinates.owner) or "NONE")
  .."; utility_sizing=NATIVE_CURRENT_ENVELOPE; settings_launcher="..(self:OwnsSettingsLauncher() and "MINIMAP_BOTTOM_LEFT" or "FALLBACK")
  .."; native_blob_overlays=FILL_BOUNDARY_NATIVE; native_blob_alpha=DECORATIVE_RING_SESSION_POLICY; native_blob_scale=NATIVE_UNMODIFIED"
  .."; native_blob_ring_policy="..(self.blobRingStatus or "NOT_SUBMITTED").."; native_blob_ring_details="..self:BlobRingDetails()
  .."; native_blob_ring_restore=OBSERVED_VALUES_ONLY_OTHERWISE_RELOAD"
  .."; native_quest_filter="..(self.questFilterStatus or "NOT_RUN").."; native_quest_selection=RETAINED; world_map_quest_POIs=RETAINED"
  .."; native_raster=NOT_RUN; native_input=RETAINED_NOT_RUN"
end
