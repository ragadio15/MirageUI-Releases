local _, M = ...
-- M1 ordinary main-bar provider. Real secure actions; no copied action data,
-- simulated input, permanent binding edits, or wholesale native event removal.
-- Native infrastructure remains authoritative for special states and key input.
M.Rework = M.Rework or {}
local R, S = M.Rework, M.Safety
local A = { id="M1_MAIN_ACTION", layoutID="ActionBars.bar1", buttons={}, active=false,
    events={PLAYER_ENTERING_WORLD=true, PLAYER_REGEN_ENABLED=true, UPDATE_BINDINGS=true,
        ACTIONBAR_SLOT_CHANGED=true, ACTIONBAR_PAGE_CHANGED=true, ACTIONBAR_UPDATE_COOLDOWN=true,
        ACTIONBAR_UPDATE_STATE=true, ACTIONBAR_UPDATE_USABLE=true, UPDATE_BONUS_ACTIONBAR=true,
        UPDATE_SHAPESHIFT_FORM=true, UPDATE_SHAPESHIFT_FORMS=true, UPDATE_MACROS=true,
        SPELL_UPDATE_CHARGES=true, SPELLS_CHANGED=true, CURSOR_CHANGED=true,
        UNIT_ENTERED_VEHICLE=true, UNIT_EXITED_VEHICLE=true, UPDATE_OVERRIDE_ACTIONBAR=true,
        UPDATE_VEHICLE_ACTIONBAR=true, UPDATE_POSSESS_BAR=true,
        PET_BATTLE_OPENING_START=true, PET_BATTLE_CLOSE=true, PLAYER_TARGET_CHANGED=true,
        UNIT_POWER_UPDATE=true, BAG_UPDATE_DELAYED=true} }
R.MainAction=A
-- P21: native action scripts own their visibility lifetime. An insecure
-- ancestor Hide/Show dispatches ActionButton OnHide/OnShow and mutates native
-- watcher tables; pet bars also run Edit Mode layout. Paint/input leases avoid
-- that callback path entirely. No native event, action field, paging method,
-- or Show/Hide implementation is replaced.
local NP={owners=setmetatable({},{__mode="k"})}
R.NativeActionPresentation=NP
-- P22: the native restricted compiler rejects nested functions and table
-- literals before executing any body. Keep these fixed receipts inline; a
-- successful ordinary Lua compilation is not secure-snippet admission.
NP.program=[=[
 local root=self:GetFrameRef("mui-native-root")
 local parent=self:GetFrameRef("mui-native-parent")
 local releasing=not self:GetAttribute("mui-native-live")
 local paintOnly=self:GetAttribute("mui-native-paint-only")==true
 local restoreInput=not paintOnly and (not releasing or self:GetAttribute("mui-native-restore-input")==true)
 local valid=root and parent and (releasing or root:GetParent()==parent)
 local shown=releasing or self:GetAttribute("mui-native-request")~=false
 local fault=not valid
 local structural=not valid
 local faultKind=not valid and "ROOT_PARENT_CHANGED" or nil
 local faultNode=not valid and 1 or nil
 for i=1,(self:GetAttribute("mui-native-count") or 0) do
  local f=self:GetFrameRef("mui-native-node"..i)
  local p=self:GetFrameRef("mui-native-node-parent"..i)
  local input=self:GetAttribute("mui-native-input"..i)
  if not f or not releasing and f:GetParent()~=p then
   fault=true;structural=true
   if not faultKind then faultKind=not f and "NODE_UNAVAILABLE" or "NODE_PARENT_CHANGED";faultNode=i end
  elseif input~=nil and (f:IsMouseClickEnabled()~=input or f:IsMouseMotionEnabled()~=input) then
   fault=true
   if not faultKind then faultKind="NODE_INPUT_CHANGED";faultNode=i end
  end
 end
 -- A changed ancestor can still carry our alpha=0. Re-enabling its children
 -- here would create invisible hit regions. Keep these exact receipts until
 -- the out-of-combat inverse can verify and return each owned property.
 if structural then
  self:SetAttribute("mui-native-fault-kind",faultKind);self:SetAttribute("mui-native-fault-node",faultNode)
  self:SetAttribute("mui-native-fault",true);self:SetAttribute("mui-native-shown",nil)
  return
 end
 if fault then shown=true end
 -- Disable input before hiding pixels. Restore pixels before enabling input.
 if shown then
  for i=1,(self:GetAttribute("mui-native-count") or 0) do
   local f=self:GetFrameRef("mui-native-node"..i)
   local last=self:GetAttribute("mui-native-alpha-last"..i)
   local nodeShown=shown and (releasing or self:GetAttribute("mui-native-subrequest"..i)~=false)
   if nodeShown and f and (releasing or f:GetParent()==self:GetFrameRef("mui-native-node-parent"..i)) and last~=nil then
    local original=self:GetAttribute("mui-native-alpha"..i)
    if last~=original then
     self:SetAttribute("mui-native-alpha-attempt"..i,original)
     f:SetAlpha(original)
     if not paintOnly then
      self:SetAttribute("mui-native-alpha-last"..i,original)
      self:SetAttribute("mui-native-alpha-attempt"..i,nil)
     end
    end
    if not paintOnly then self:SetAttribute("mui-native-alpha-last"..i,original) end
   end
  end
 end
 for i=1,(self:GetAttribute("mui-native-count") or 0) do
  local f=self:GetFrameRef("mui-native-node"..i)
  local last=self:GetAttribute("mui-native-input"..i)
  if restoreInput and f and (releasing or f:GetParent()==self:GetFrameRef("mui-native-node-parent"..i)) and last~=nil
   and f:IsMouseClickEnabled()==last and f:IsMouseMotionEnabled()==last then
   local nodeShown=shown and (releasing or self:GetAttribute("mui-native-subrequest"..i)~=false)
   local want=nodeShown and self:GetAttribute("mui-native-input-original"..i) or false
   if last~=want then
    self:SetAttribute("mui-native-input-attempt"..i,want)
    f:EnableMouse(want)
    if f:IsMouseClickEnabled()==want and f:IsMouseMotionEnabled()==want then
     self:SetAttribute("mui-native-input"..i,want)
     self:SetAttribute("mui-native-input-attempt"..i,nil)
    else
     fault=true
     if not faultKind then faultKind="NODE_INPUT_WRITE_REFUSED";faultNode=i end
    end
   end
  end
 end
 if not fault and not paintOnly then
  for i=1,(self:GetAttribute("mui-native-count") or 0) do
   local f=self:GetFrameRef("mui-native-node"..i)
   local last=self:GetAttribute("mui-native-alpha-last"..i)
   local nodeShown=shown and (releasing or self:GetAttribute("mui-native-subrequest"..i)~=false)
   if not nodeShown and last~=nil then
    if last~=0 then
     self:SetAttribute("mui-native-alpha-attempt"..i,0)
     f:SetAlpha(0)
     self:SetAttribute("mui-native-alpha-last"..i,0)
     self:SetAttribute("mui-native-alpha-attempt"..i,nil)
    end
    self:SetAttribute("mui-native-alpha-last"..i,0)
   end
  end
 end
 -- A refused input write never leaves a newly invisible click target.
 if fault then
  for i=1,(self:GetAttribute("mui-native-count") or 0) do
   local f=self:GetFrameRef("mui-native-node"..i)
   if f and (releasing or f:GetParent()==self:GetFrameRef("mui-native-node-parent"..i)) then
    local alpha=self:GetAttribute("mui-native-alpha-last"..i)
    if alpha~=nil then
     local original=self:GetAttribute("mui-native-alpha"..i)
     if alpha~=original then
      self:SetAttribute("mui-native-alpha-attempt"..i,original)
      f:SetAlpha(original)
      if not paintOnly then
       self:SetAttribute("mui-native-alpha-last"..i,original)
       self:SetAttribute("mui-native-alpha-attempt"..i,nil)
      end
     end
     if not paintOnly then self:SetAttribute("mui-native-alpha-last"..i,original) end
    end
    local last=self:GetAttribute("mui-native-input"..i)
    if restoreInput and last~=nil and f:IsMouseClickEnabled()==last and f:IsMouseMotionEnabled()==last then
     local want=self:GetAttribute("mui-native-input-original"..i)
     if last~=want then
      self:SetAttribute("mui-native-input-attempt"..i,want)
      f:EnableMouse(want)
      if f:IsMouseClickEnabled()==want and f:IsMouseMotionEnabled()==want then
       self:SetAttribute("mui-native-input"..i,want)
       self:SetAttribute("mui-native-input-attempt"..i,nil)
      end
     end
    end
   end
  end
 end
 self:SetAttribute("mui-native-fault-kind",fault and faultKind or nil)
 self:SetAttribute("mui-native-fault-node",fault and faultNode or nil)
 self:SetAttribute("mui-native-fault",fault and true or false)
 self:SetAttribute("mui-native-shown",shown or fault)
]=]
-- MainMenuBarVehicleLeaveButton is a native MainActionBar descendant. Its
-- contextual companion submits a request to the main tree's ONE paint/input
-- owner. It must never capture a second "original" after the main owner has
-- disabled input. Every state transition uses the same receipts, irrespective
-- of the order of the main-state and companion-state callbacks.
NP.sharedProgram=[=[
 if self:GetAttribute("mui-native-shared-retired") then return end
 local owner=self:GetFrameRef("mui-native-shared-owner")
 local root=self:GetFrameRef("mui-native-root")
 local parent=self:GetFrameRef("mui-native-parent")
 local releasing=not self:GetAttribute("mui-native-live")
 if not owner or not root or not parent or not releasing and root:GetParent()~=parent then
  self:SetAttribute("mui-native-fault",true)
  return
 end
 local request=self:GetAttribute("mui-native-request")~=false
 for i=1,(self:GetAttribute("mui-native-count") or 0) do
  local index=self:GetAttribute("mui-native-shared-index"..i)
  if releasing then owner:SetAttribute("mui-native-subrequest"..index,nil)
  else owner:SetAttribute("mui-native-subrequest"..index,request) end
 end
 owner:RunAttribute("mui-native-present")
 self:SetAttribute("mui-native-fault",owner:GetAttribute("mui-native-fault"))
 self:SetAttribute("mui-native-shown",request and owner:GetAttribute("mui-native-shown"))
]=]
local function npRead(f,method,kind,...)
 if f and type(f[method])=="function" then return S:Public(f[method],kind,f,...) end
end
local function npField(object,key)
 if type(S.FieldAccess)=="function" then return S:FieldAccess(object,key) end
 return nil,"UNKNOWN"
end
local function npReceipt(gate,key,kind)
 -- A missing owned receipt is an explicit relinquishment, not an unreadable
 -- native property. Safety:Public intentionally treats nil as UNKNOWN.
 local okay,value=pcall(gate.GetAttribute,gate,key)
 if okay and S:Readable(value) and (value==nil or type(value)==kind) then return value,"KNOWN" end
 return nil,"UNKNOWN"
end
local function npTree(root)
 local nodes,seen={},{}
 local function visit(f,depth)
  if depth>20 or #nodes>=512 or seen[f] or not S:Frame(f,false) then return false end
  seen[f]=true
  local parent,known=npRead(f,"GetParent")
  local click,ck=npRead(f,"IsMouseClickEnabled","boolean")
  local motion,mk=npRead(f,"IsMouseMotionEnabled","boolean")
  local ignores,ik=npRead(f,"IsIgnoringParentAlpha","boolean")
  -- Restricted handles expose EnableMouse, not split input setters. Refuse a
  -- mixed native input contract rather than silently changing its semantics.
  if known~="KNOWN" or not parent or ck~="KNOWN" or mk~="KNOWN" or click~=motion then return false end
  if ik~="KNOWN" then return false end
  local alpha
  if f==root or ignores or root==_G.MainActionBar and f==_G.MainMenuBarVehicleLeaveButton then
   alpha=npRead(f,"GetAlpha","number");if not S:Number(alpha) then return false end
  end
  nodes[#nodes+1]={frame=f,parent=parent,input=click,alpha=alpha}
  if type(f.GetChildren)~="function" then return false end
  local children={pcall(f.GetChildren,f)}
  if not children[1] then return false end
  for i=2,#children do if not S:Readable(children[i]) or not visit(children[i],depth+1) then return false end end
  return true
 end
 return visit(root,0) and nodes or nil
end
function NP:ObserveFaults(lease)
 local gate=lease.gate
 self.faultObservers=self.faultObservers or setmetatable({},{__mode="k"})
 local observer=self.faultObservers[gate]
 if not observer then
  if type(gate.HookScript)~="function" then return false end
  observer={}
  local okay,installed=pcall(gate.HookScript,gate,"OnAttributeChanged",function(_,key,value)
   local live=observer.lease
   if not S:Text(key) or key~="mui-native-fault" or not S:Readable(value) or value~=true
    or not live or live.retired or not live.prepared then return end
   local owner=live.shared or live
   -- Secure fallback has already restored native access. Wake the existing
   -- reconciliation path immediately; a quiet action scheduler otherwise
   -- leaves both presentations alive until the next manual configuration.
   if A.lease==owner then A.nativeDirty=true;A.pendingWork=true end
   local families=R.ActionFamilies
   for _,row in pairs(families and families.families or {}) do
    if row.lease==owner or row.interfacePresentation==live or row.interfacePresentation==owner then
     row.nativeDirty=true;families.pendingWork=true;A.pendingWork=true
    end
   end
  end)
  if not okay or installed==false then return false end
  self.faultObservers[gate]=observer
 end
 observer.lease=lease
 return true
end
function NP:Dispatch(lease,shown)
 if not lease or S:InCombat() then return false,"COMBAT_LOCKDOWN" end
 local gate=lease.gate
 local previous,known=npReceipt(gate,"state-muinativerefresh","string")
 if known~="KNOWN" then return false,"NATIVE_ACTION_REFRESH_UNAVAILABLE" end
 -- The gate survives lease retirement. Its attribute, not a new lease's local
 -- counter, determines the next token; setting an unchanged state need not run
 -- the native handler. Nil on a genuinely fresh gate is a known first state.
 local revision=previous=="1" and "2" or "1"
 local okay=pcall(function()
  if shown~=nil then gate:SetAttribute("mui-native-request",shown==true) end
  -- Require a fresh completion receipt. A swallowed restricted-call error must
  -- never inherit the success flag from an earlier native state transition.
  gate:SetAttribute("mui-native-fault",nil)
  gate:SetAttribute("state-muinativerefresh",revision)
 end)
 return okay and npRead(gate,"GetAttribute","boolean","mui-native-fault")==false
end
function NP:UpdateDriver(lease,driver)
 if not lease or lease.retired or lease.shared then return false,"NATIVE_ACTION_PRESENTATION_CHANGED" end
 if S:InCombat() then return false,"COMBAT_LOCKDOWN" end
 if not S:Text(driver) or not self:Current(lease) then return false,"NATIVE_ACTION_PRESENTATION_CHANGED" end
 if lease.driver==driver then return true end
 -- Family preparation can change which native special-state alternative is
 -- needed. Keep that accepted driver with the lease so native Attach/Detach
 -- renewal never reintroduces the earlier fallback policy. A refused or
 -- throwing registration retains a pending receipt and cannot look current.
 lease.driver=driver;lease.driverPending=true
 local called,accepted=pcall(RegisterStateDriver,lease.gate,"muinative",driver)
 if not called or accepted==false then return false,"NATIVE_ACTION_GATE_REGISTRATION_FAILED" end
 local state,known=npRead(lease.gate,"GetAttribute","string","state-muinative")
 if known~="KNOWN" or state~="show" and state~="hide" then return false,"NATIVE_ACTION_GATE_STATE_UNAVAILABLE" end
 -- Equal state values do not run the native state handler. Require a fresh
 -- restricted completion even when the policy changed but its state did not.
 if not self:Dispatch(lease,state=="show") then return false,"NATIVE_ACTION_PRESENTATION_UNCONFIRMED" end
 lease.driverPending=nil
 if not self:Current(lease) then lease.driverPending=true;return false,"NATIVE_ACTION_PRESENTATION_UNCONFIRMED" end
 self.driverUpdates=(self.driverUpdates or 0)+1
 return true
end
function NP:AcquireShared(root,nodes,owner,gate,driver)
 -- This exact hierarchy is reviewed in VehicleLeaveButton.xml. Other nested
 -- owners are refused, including arbitrary descendants with matching names.
 if root~=_G.MainMenuBarVehicleLeaveButton or owner.frame~=_G.MainActionBar
  or root==owner.frame or owner.retired or nodes[1].parent~=owner.frame
  or owner.shared or owner.sharedChildren and owner.sharedChildren[root]
  or not self:Current(owner) then return nil,"NATIVE_ACTION_OWNER_CONFLICT" end
 local indices,byFrame={},{}
 for i,node in ipairs(owner.nodes) do byFrame[node.frame]=i end
 for i,node in ipairs(nodes) do
  local index=byFrame[node.frame]
  if not index or self.owners[node.frame]~=owner then return nil,"NATIVE_ACTION_OWNER_CONFLICT" end
  indices[i]=index
 end
 if owner.nodes[indices[1]].alpha==nil then return nil,"NATIVE_ACTION_SHARED_PAINT_UNAVAILABLE" end
 gate=gate or CreateFrame("Frame",nil,UIParent,"SecureHandlerStateTemplate")
 if not S:InitializeSecureHandler(gate) then return nil,"NATIVE_ACTION_HANDLER_UNAVAILABLE" end
 local lease={frame=root,parent=nodes[1].parent,gate=gate,nodes=nodes,shared=owner,indices=indices}
 local okay,ready=pcall(function()
  gate:SetAttribute("mui-native-live",false);gate:SetAttribute("mui-native-shared-retired",nil)
  gate:SetAttribute("mui-native-present",self.sharedProgram)
  gate:SetAttribute("_onstate-muinativerefresh",[[ self:RunAttribute("mui-native-present") ]])
  gate:SetAttribute("_onstate-muinative",[[ self:SetAttribute("mui-native-request",newstate~="hide");self:RunAttribute("mui-native-present") ]])
  gate:SetFrameRef("mui-native-root",root);gate:SetFrameRef("mui-native-parent",lease.parent)
  gate:SetFrameRef("mui-native-shared-owner",owner.gate)
  gate:SetAttribute("mui-native-count",#indices)
  for i,index in ipairs(indices) do gate:SetAttribute("mui-native-shared-index"..i,index) end
  owner.sharedChildren=owner.sharedChildren or {};owner.sharedChildren[root]=lease
  gate:SetAttribute("mui-native-request",true);gate:SetAttribute("mui-native-live",true);lease.prepared=true
  self:ObserveFaults(lease)
  if driver then
   lease.driver=driver;if RegisterStateDriver(gate,"muinative",driver)==false then return false end
   local state,known=npRead(gate,"GetAttribute","string","state-muinative")
   if known~="KNOWN" or state~="show" and state~="hide" then return false end
   return self:Dispatch(lease,state=="show")
  end
  return self:Dispatch(lease)
 end)
 if not lease.prepared then return nil,"NATIVE_ACTION_HANDLER_UNAVAILABLE" end
 if not okay or not ready or not self:Current(lease) then return lease,"NATIVE_ACTION_PRESENTATION_UNCONFIRMED" end
 self.sharedAdmissions=(self.sharedAdmissions or 0)+1
 return lease
end
function NP:Acquire(root,gate,driver)
 if S:InCombat() then return nil,"COMBAT_LOCKDOWN" end
 local nodes=npTree(root)
 if not nodes then return nil,"NATIVE_ACTION_INPUT_UNAVAILABLE" end
 local owner=self.owners[root]
 if owner and not owner.retired then return self:AcquireShared(root,nodes,owner,gate,driver) end
 for _,node in ipairs(nodes) do
  local occupied=self.owners[node.frame]
  if occupied and not occupied.retired then return nil,"NATIVE_ACTION_OWNER_CONFLICT" end
 end
 gate=gate or CreateFrame("Frame",nil,UIParent,"SecureHandlerStateTemplate")
 if not S:InitializeSecureHandler(gate) then return nil,"NATIVE_ACTION_HANDLER_UNAVAILABLE" end
 local lease={frame=root,parent=nodes[1].parent,gate=gate,nodes=nodes}
 local okay,ready=pcall(function()
  gate:SetAttribute("mui-native-live",false)
  gate:SetAttribute("mui-native-restore-input",false)
  gate:SetAttribute("mui-native-paint-only",nil)
  gate:SetAttribute("mui-native-present",self.program)
  gate:SetAttribute("_onstate-muinativerefresh",[[ self:RunAttribute("mui-native-present") ]])
  gate:SetAttribute("_onstate-muinative",[[ self:SetAttribute("mui-native-request",newstate~="hide");self:RunAttribute("mui-native-present") ]])
  gate:SetFrameRef("mui-native-root",root);gate:SetFrameRef("mui-native-parent",lease.parent)
  gate:SetAttribute("mui-native-count",#nodes)
  for i,node in ipairs(nodes) do
   gate:SetFrameRef("mui-native-node"..i,node.frame);gate:SetFrameRef("mui-native-node-parent"..i,node.parent)
   gate:SetAttribute("mui-native-input-original"..i,node.input);gate:SetAttribute("mui-native-input"..i,node.input)
   gate:SetAttribute("mui-native-input-attempt"..i,nil)
   gate:SetAttribute("mui-native-subrequest"..i,nil)
   gate:SetAttribute("mui-native-alpha"..i,node.alpha);gate:SetAttribute("mui-native-alpha-last"..i,node.alpha)
   gate:SetAttribute("mui-native-alpha-attempt"..i,nil)
  end
  gate:SetAttribute("mui-native-request",true);gate:SetAttribute("mui-native-live",true)
  lease.prepared=true -- No native property can be written before this boundary.
  self:ObserveFaults(lease)
  for _,node in ipairs(nodes) do self.owners[node.frame]=lease end
  if driver then
   lease.driver=driver;if RegisterStateDriver(gate,"muinative",driver)==false then return false end
   -- Native registration immediately resolves its condition, but deliberately
   -- does not write a state attribute when that value is unchanged. Use the
   -- actual resolved state even when reusing a previously registered gate.
   local state,known=npRead(gate,"GetAttribute","string","state-muinative")
   if known~="KNOWN" or state~="show" and state~="hide" then return false end
   return self:Dispatch(lease,state=="show")
  end
  return self:Dispatch(lease)
 end)
 if not lease.prepared then return nil,"NATIVE_ACTION_HANDLER_UNAVAILABLE" end
 if not okay or not ready or not self:Current(lease) then return lease,"NATIVE_ACTION_PRESENTATION_UNCONFIRMED" end
 self:ObserveMainParent(lease)
 return lease
end
local function npCurrent(lease,renewing)
 if not lease or lease.retired then return false,"LEASE_RETIRED" end
 if lease.driverPending then return false,"DRIVER_UPDATE_PENDING" end
 if lease.shared then
  local owner=lease.shared
  if owner.retired or not owner.sharedChildren or owner.sharedChildren[lease.frame]~=lease
   or lease.frame~=_G.MainMenuBarVehicleLeaveButton or owner.frame~=_G.MainActionBar then return false,"SHARED_OWNER_CHANGED",1 end
  local parent,known=npRead(lease.frame,"GetParent")
  if known~="KNOWN" then return false,"ROOT_PARENT_UNREADABLE",1 end
  if parent~=lease.parent then return false,"ROOT_PARENT_CHANGED",1 end
  local request,known=npRead(lease.gate,"GetAttribute","boolean","mui-native-request")
  if known~="KNOWN" then return false,"SHARED_REQUEST_UNREADABLE",1 end
  for i,index in ipairs(lease.indices) do
   if npRead(owner.gate,"GetAttribute","boolean","mui-native-subrequest"..index)~=request
    or owner.nodes[index].frame~=lease.nodes[i].frame then return false,"SHARED_REQUEST_CHANGED",i end
  end
  local current,reason,index=npCurrent(owner,renewing)
  return current,reason,index,owner
 end
 local parent,known=npRead(lease.frame,"GetParent")
 if known~="KNOWN" then return false,"ROOT_PARENT_UNREADABLE",1 end
 if not renewing and parent~=lease.parent then return false,"ROOT_PARENT_CHANGED",1 end
 local fault,state=npRead(lease.gate,"GetAttribute","boolean","mui-native-fault")
 if state~="KNOWN" then return false,"PROGRAM_COMPLETION_UNCONFIRMED" end
 if fault and not renewing then
  local index=npRead(lease.gate,"GetAttribute","number","mui-native-fault-node")
  if not S:Number(index) or index%1~=0 or index<1 or index>#lease.nodes then index=nil end
  return false,"PROGRAM_FAULT",index
 end
 if npRead(lease.gate,"GetAttribute","boolean","mui-native-paint-only")==true then return false,"PAINT_HANDOFF_PENDING" end
 for i,node in ipairs(lease.nodes) do
  local parent,ps=npRead(node.frame,"GetParent")
  if ps~="KNOWN" then return false,"NODE_PARENT_UNREADABLE",i end
  if (not renewing or i~=1) and parent~=node.parent then return false,"NODE_PARENT_CHANGED",i end
  local last,ls=npRead(lease.gate,"GetAttribute","boolean","mui-native-input"..i)
  local click,cs=npRead(node.frame,"IsMouseClickEnabled","boolean")
  local motion,ms=npRead(node.frame,"IsMouseMotionEnabled","boolean")
  if ls~="KNOWN" or cs~="KNOWN" or ms~="KNOWN" then return false,"NODE_INPUT_UNREADABLE",i end
  if click~=last or motion~=last then return false,"NODE_INPUT_CHANGED",i end
  if renewing then
   local attempt,known=npReceipt(lease.gate,"mui-native-input-attempt"..i,"boolean")
   if known~="KNOWN" or attempt~=nil then return false,"INPUT_ATTEMPT_PENDING",i end
  end
  if node.alpha~=nil then
   local actual=npRead(node.frame,"GetAlpha","number")
   local expected=npRead(lease.gate,"GetAttribute","number","mui-native-alpha-last"..i)
   if not S:Number(actual) or not S:Number(expected) then return false,"NODE_ALPHA_UNREADABLE",i end
   if actual~=expected then return false,"NODE_ALPHA_CHANGED",i end
   if renewing then
    local attempt,known=npReceipt(lease.gate,"mui-native-alpha-attempt"..i,"number")
    if known~="KNOWN" or attempt~=nil then return false,"ALPHA_ATTEMPT_PENDING",i end
   end
  end
 end
 return true
end
function NP:Current(lease)
 local ready,reason,index,owner=npCurrent(lease)
 if not ready and lease and not lease.retired then
  owner=owner or lease
  local node=index and owner.nodes[index]
  local name=node and npRead(node.frame,"GetName","string") or npRead(owner.frame,"GetName","string")
  local detail=npRead(owner.gate,"GetAttribute","string","mui-native-fault-kind")
  if not S:Text(detail) or not detail:match("^[A-Z_]+$") or #detail>64 then detail=nil end
  self.lastChange={reason=reason,node=index,name=S:Text(name) and name:sub(1,96) or "UNNAMED",secureReason=detail}
  lease.presentationChange=reason;lease.presentationNode=index
 end
 return ready,reason,index
end
function NP:ObserveMainParent(lease)
 local root=lease.frame
 if root~=_G.MainActionBar or type(hooksecurefunc)~="function" then return false end
 self.mainObservers=self.mainObservers or setmetatable({},{__mode="k"})
 local observer=self.mainObservers[root]
 if not observer then
  observer={root=root,methods={},sources={}}
  local okay=pcall(hooksecurefunc,root,"SetParent",function()
   local live=observer.lease
   if not live or live.retired then return end
   -- A later arbitrary SetParent invalidates the completed native receipt,
   -- even if it writes the same value. Native Attach/Detach publishes its own
   -- receipt only after its complete source-owned callback has returned.
   live.nativeParentIntent=nil
   if A.lease==live then A.nativeDirty=true;A.pendingWork=true end
  end)
  if not okay then return false end
  observer.parentMethod=root.SetParent;self.mainObservers[root]=observer
 end
 observer.lease=lease;lease.parentObserver=observer
 for _,key in ipairs({"AttachToFrame","DetachFromFrame"}) do
  if not observer.methods[key] then
   local native,state=npField(MainActionBarMixin,key)
   if state=="KNOWN" and type(native)=="function" and root[key]==native then
    local okay=pcall(hooksecurefunc,root,key,function(frame,requested)
     local live=observer.lease
     if not live or live.retired or frame~=root or root~=_G.MainActionBar
      or root[key]~=observer.methods[key] or root.SetParent~=observer.parentMethod
      or npField(MainActionBarMixin,key)~=observer.sources[key] then return end
     local expected=key=="AttachToFrame" and requested or UIParent
     local attached,known=npField(root,"attachedFrame")
     if key=="AttachToFrame" and (known~="KNOWN" or attached~=requested)
      or key=="DetachFromFrame" and known~="ABSENT" then return end
     if not S:Frame(expected,false) or npRead(root,"GetParent")~=expected then return end
     live.nativeParentIntent={parent=expected,method=key,observer=observer}
     if A.lease==live then A.nativeDirty=true;A.pendingWork=true end
    end)
    if okay then observer.methods[key]=root[key];observer.sources[key]=native end
   end
  end
 end
 return true
end
function NP:RenewNativeParent(lease)
 local intent=lease and lease.nativeParentIntent
 local observer=intent and intent.observer
 if not intent or not observer or observer.lease~=lease or lease.retired
  or intent.parent==lease.parent
  or lease.frame~=_G.MainActionBar or lease.frame.SetParent~=observer.parentMethod
  or lease.frame[intent.method]~=observer.methods[intent.method]
  or npField(MainActionBarMixin,intent.method)~=observer.sources[intent.method]
  or npRead(lease.frame,"GetParent")~=intent.parent then return nil,"NATIVE_ACTION_PRESENTATION_CHANGED" end
 -- Only the root parent may differ. Opaque/changed paint, input, child
 -- ancestry or incomplete setter attempts keep their original recovery path.
 local current=npCurrent(lease,true)
 if not current then return nil,"NATIVE_ACTION_PRESENTATION_CHANGED" end
 if S:InCombat() then return nil,"COMBAT_LOCKDOWN" end
 local children={}
 for _,child in pairs(lease.sharedChildren or {}) do
  local requested,known=npRead(child.gate,"GetAttribute","boolean","mui-native-request")
  if known~="KNOWN" or child.retired then return nil,"NATIVE_ACTION_PRESENTATION_CHANGED" end
  children[#children+1]={lease=child,frame=child.frame,gate=child.gate,driver=child.driver,requested=requested}
 end
 local frame,gate,driver=lease.frame,lease.gate,lease.driver
 if not self:Release(lease) then return nil,"NATIVE_ACTION_PRESENTATION_RESTORE_PENDING" end
 local renewed,why=self:Acquire(frame,gate,driver)
 if renewed and not why then
  -- Keep existing companion handles and secure frame references usable when
  -- the source-owned main parent moves. Rebind the same gate to the freshly
  -- verified owner; do not leave a live handle pointing at a retired lease.
  for _,retained in ipairs(children) do
   local nextChild,childWhy=self:Acquire(retained.frame,retained.gate,retained.driver)
   if nextChild then
    local previous=retained.lease
    for key in pairs(previous) do previous[key]=nil end
    for key,value in pairs(nextChild) do previous[key]=value end
    renewed.sharedChildren[retained.frame]=previous
    if not self:Dispatch(previous,retained.requested) then childWhy=childWhy or "NATIVE_ACTION_PRESENTATION_UNCONFIRMED" end
   end
   if childWhy or not nextChild then why=childWhy or "NATIVE_ACTION_PRESENTATION_UNCONFIRMED";break end
  end
 end
 if renewed and not why then self.parentRepairs=(self.parentRepairs or 0)+1 end
 return renewed,why
end
function NP:Status()
 local change=self.lastChange
 return "native_presentation_last_change="..(change and change.reason or "NONE")..
  ";native_presentation_node="..(change and change.name or "NONE")..
  ";native_presentation_secure_reason="..(change and change.secureReason or "NONE")..
  ";native_parent_repairs="..tostring(self.parentRepairs or 0)..
  ";native_driver_updates="..tostring(self.driverUpdates or 0)..
  ";native_shared_ownership=SINGLE_TREE_RECEIPTS;native_shared_admissions="..tostring(self.sharedAdmissions or 0)
end
local function npInputPaintReady(lease,changed)
 local captured={}
 for _,node in ipairs(lease.nodes) do captured[node.frame]=node end
 for i,node in ipairs(lease.nodes) do
  if changed[i].input==false and node.input==true then
   -- Only a still-owned false -> true inverse needs this barrier. Follow its
   -- current ancestry so a reparented or ignore-parent-alpha control is not
   -- held by unrelated paint elsewhere in the captured tree.
   local frame,complete=node.frame,false
   for _=1,32 do
    local ancestor=captured[frame]
    if not ancestor then complete=true;break end
    if ancestor.alpha~=nil then
     local alpha,known=npRead(frame,"GetAlpha","number")
     if known~="KNOWN" or ancestor.alpha>0 and alpha<=0 then return false end
    end
    local ignores,known=npRead(frame,"IsIgnoringParentAlpha","boolean")
    if known~="KNOWN" then return false end
    if ignores or frame==lease.frame then complete=true;break end
    frame,known=npRead(frame,"GetParent")
    if known~="KNOWN" then return false end
   end
   if not complete then return false end
  end
 end
 return true
end
local function npRelease(self,lease)
 if not lease or lease.retired then return true end
 if S:InCombat() then return false end
 if lease.driver then
  if UnregisterStateDriver(lease.gate,"muinative")==false then return false end
  lease.driver=nil
 end
 -- Alpha is deliberately absent from restricted HANDLE getters. Compare all
 -- owned properties before handback and preserve newer input/cosmetic writes.
 -- Native parent custody is independent: a newly parented control can still
 -- carry our alpha=0 or mouse=false and needs that exact receipt returned.
 local changed,restoreNeeded={},false
 for i,node in ipairs(lease.nodes) do
  local click,ck=npRead(node.frame,"IsMouseClickEnabled","boolean")
  local motion,mk=npRead(node.frame,"IsMouseMotionEnabled","boolean")
  local last,lk=npReceipt(lease.gate,"mui-native-input"..i,"boolean")
  local attempt,tk=npReceipt(lease.gate,"mui-native-input-attempt"..i,"boolean")
  if ck~="KNOWN" or mk~="KNOWN" or lk~="KNOWN" or tk~="KNOWN" then return false end
  local ours=last~=nil and click==last and motion==last or attempt~=nil and click==attempt and motion==attempt
  changed[i]={inputOwned=ours}
  if ours then changed[i].input=click;if click~=node.input then restoreNeeded=true end end
  if node.alpha~=nil then
   local actual,known=npRead(node.frame,"GetAlpha","number")
   local prior,pk=npReceipt(lease.gate,"mui-native-alpha-last"..i,"number")
   local attempted,tk=npReceipt(lease.gate,"mui-native-alpha-attempt"..i,"number")
   if known~="KNOWN" or pk~="KNOWN" or tk~="KNOWN" then return false end
   if prior~=nil and actual==prior or attempted~=nil and actual==attempted then
    changed[i].alpha=actual;if actual~=node.alpha then restoreNeeded=true end
   end
  end
 end
 for i,property in ipairs(changed) do
  lease.gate:SetAttribute("mui-native-input"..i,property.input)
  lease.gate:SetAttribute("mui-native-input-attempt"..i,nil)
  lease.gate:SetAttribute("mui-native-alpha-last"..i,property.alpha)
  lease.gate:SetAttribute("mui-native-alpha-attempt"..i,nil)
 end
 lease.gate:SetAttribute("mui-native-live",false)
 lease.gate:SetAttribute("mui-native-restore-input",false)
 lease.gate:SetAttribute("mui-native-paint-only",nil)
 -- An admission failure before any native write has no inverse to execute.
 -- Retire only after every relevant property was read and either already
 -- matches its captured original or is no longer ours. Re-running a rejected
 -- secure program here used to strand perfectly usable native controls.
 if not restoreNeeded then lease.retired=true;return true end
 -- Restricted handles have no alpha getter. Restore paint first, then verify
 -- the exact public native readbacks before any hidden native input is enabled.
 -- A SetAlpha call that returns without effect is a refusal, not a foreign edit.
 lease.gate:SetAttribute("mui-native-restore-input",false)
 local painted=self:Dispatch(lease,true)
 local paintVerified=painted
 for i,node in ipairs(lease.nodes) do
  if changed[i].alpha~=nil then
   local actual,known=npRead(node.frame,"GetAlpha","number")
   if known~="KNOWN" then
    paintVerified=false
    -- Preserve both possibilities until a native readback is available. The
    -- setter may have applied the original or silently retained our old alpha.
    lease.gate:SetAttribute("mui-native-alpha-last"..i,changed[i].alpha)
    lease.gate:SetAttribute("mui-native-alpha-attempt"..i,node.alpha)
   elseif actual~=node.alpha then
    paintVerified=false
    -- Retain exact failed-write custody. A different intervening native value
    -- relinquishes only that cosmetic property; it is never overwritten here.
    lease.gate:SetAttribute("mui-native-alpha-last"..i,actual==changed[i].alpha and actual or nil)
    lease.gate:SetAttribute("mui-native-alpha-attempt"..i,nil)
   end
  end
 end
 if not paintVerified or not npInputPaintReady(lease,changed) then return false end
 lease.gate:SetAttribute("mui-native-restore-input",true)
 if not self:Dispatch(lease,true) then return false end
 local complete=true
 for i,node in ipairs(lease.nodes) do
  local click,ck=npRead(node.frame,"IsMouseClickEnabled","boolean")
  local motion,mk=npRead(node.frame,"IsMouseMotionEnabled","boolean")
  local last=npRead(lease.gate,"GetAttribute",nil,"mui-native-input"..i)
  if ck~="KNOWN" or mk~="KNOWN" then complete=false
  elseif last~=nil and click==last and motion==last and (click~=node.input or motion~=node.input) then complete=false end
  if node.alpha~=nil then
   local alpha,ak=npRead(node.frame,"GetAlpha","number")
   local lastAlpha=npRead(lease.gate,"GetAttribute",nil,"mui-native-alpha-last"..i)
   if ak~="KNOWN" or lastAlpha~=nil and alpha==lastAlpha and alpha~=node.alpha then complete=false end
  end
 end
 if complete then lease.retired=true end
 return complete
end
function NP:CompleteSharedRequest(owner)
 local shown,known=npRead(owner.gate,"GetAttribute","boolean","mui-native-request")
 if known~="KNOWN" then return false end
 local before,changed={},false
 for i,node in ipairs(owner.nodes) do
  local request,rk=npReceipt(owner.gate,"mui-native-subrequest"..i,"boolean")
  local input,ik=npReceipt(owner.gate,"mui-native-input"..i,"boolean")
  if rk~="KNOWN" or ik~="KNOWN" or input==nil then return false end
  local visible=shown and request~=false
  before[i]={visible=visible};if visible then before[i].input=input end
  if visible and input~=node.input then changed=true end
  if node.alpha~=nil then
   local alpha,ak=npReceipt(owner.gate,"mui-native-alpha-last"..i,"number")
   if ak~="KNOWN" or alpha==nil then return false end
   before[i].alpha=alpha
   if visible and alpha~=node.alpha then changed=true end
  end
 end
 if not changed then return true end
 -- Retiring a concealed companion can reveal input while the main native
 -- tree stays active. Use a separate paint-only pass and public readbacks;
 -- a successful SetAlpha return alone never authorizes newly visible input.
 owner.gate:SetAttribute("mui-native-paint-only",true)
 local verified=self:Dispatch(owner)
 for i,node in ipairs(owner.nodes) do
  local prior=before[i]
  if prior.visible and node.alpha~=nil then
   local actual,ak=npRead(node.frame,"GetAlpha","number")
   if ak~="KNOWN" then
    verified=false
    owner.gate:SetAttribute("mui-native-alpha-last"..i,prior.alpha)
    owner.gate:SetAttribute("mui-native-alpha-attempt"..i,node.alpha)
   elseif actual~=node.alpha then
    verified=false
    owner.gate:SetAttribute("mui-native-alpha-last"..i,actual==prior.alpha and actual or nil)
    owner.gate:SetAttribute("mui-native-alpha-attempt"..i,nil)
   else
    owner.gate:SetAttribute("mui-native-alpha-last"..i,actual)
    owner.gate:SetAttribute("mui-native-alpha-attempt"..i,nil)
   end
  end
 end
 -- Keep the paint-only hold on any refusal/unknown result. Later native gate
 -- notifications may restore pixels, but cannot enable invisible input. The
 -- owner's normal verified inverse removes this hold during legal recovery.
 if not verified or not npInputPaintReady(owner,before) then return false end
 owner.gate:SetAttribute("mui-native-paint-only",nil)
 return self:Dispatch(owner) and self:Current(owner)==true
end
function NP:Release(lease)
 local okay,complete=pcall(function()
  if not lease or lease.retired then return true end
  if S:InCombat() then return false end
  if lease.shared then
   if lease.driver then
    if UnregisterStateDriver(lease.gate,"muinative")==false then return false end
    lease.driver=nil
   end
   local owner=lease.shared
   local current=self:Current(owner)==true
   lease.gate:SetAttribute("mui-native-live",false)
   -- A shared handle owns a request, never a second native input value. A
   -- native mutation can fault the master pass; its original receipts remain
   -- with that owner for the verified paint-before-input inverse below.
   -- Check public paint/input before a new secure pass: restricted handles do
   -- not expose alpha getters. A competing alpha write must survive removal
   -- of this request, just as it survives the owner's normal handback.
   for _,index in ipairs(lease.indices) do owner.gate:SetAttribute("mui-native-subrequest"..index,nil) end
   if current and not self:CompleteSharedRequest(owner) then return false end
   for _,index in ipairs(lease.indices) do
    local value,known=npReceipt(owner.gate,"mui-native-subrequest"..index,"boolean")
    if known~="KNOWN" or value~=nil then return false end
   end
   lease.gate:SetAttribute("mui-native-shared-retired",true)
   if owner.sharedChildren and owner.sharedChildren[lease.frame]==lease then owner.sharedChildren[lease.frame]=nil end
   lease.retired=true;return true
  end
  for _,child in pairs(lease.sharedChildren or {}) do if not self:Release(child) then return false end end
  local restored=npRelease(self,lease)
  if restored then
   for _,node in ipairs(lease.nodes) do if self.owners[node.frame]==lease then self.owners[node.frame]=nil end end
  end
  return restored
 end)
 return okay and complete==true
end

local white="Interface\\Buttons\\WHITE8X8"
local world=M.VisualTokens.world
local identity=M.VisualTokens.options
local special="[vehicleui] hide; [overridebar] hide; [possessbar] hide; [shapeshift] hide; [petbattle] hide; "
local nativeGateDriver="[vehicleui] show; [overridebar] show; [possessbar] show; [shapeshift] show; [petbattle] show; hide"
local pagePrefix="[vehicleui] 0; [overridebar] 0; [possessbar] 0; [shapeshift] 0; [petbattle] 0; "..
    "[bar:2] 2; [bar:3] 3; [bar:4] 4; [bar:5] 5; [bar:6] 6; "..
    "[bonusbar:5] 11; [bonusbar:4] 10; [bonusbar:3] 9; [bonusbar:2] 8; [bonusbar:1] 7; "
-- This is fixed source, never profile text. No insecure CallMethod is made from
-- the restricted pass. Mirroring the native parent's actionpage keeps ordinary
-- ACTIONBUTTONn key commands on the same action as the custom button.
A.pageProgram=[[
    local page=tonumber(newstate) or 1
    if page>0 then
        self:SetAttribute("actionpage",page)
        for i=1,12 do
            local button=self:GetFrameRef("slot"..i)
            local action=(page-1)*12+i
            button:SetAttribute("action",action)
            local hold=false
            if GetActionInfo and IsPressHoldReleaseSpell then
                local kind, id=GetActionInfo(action)
                if kind=="spell" and id then hold=IsPressHoldReleaseSpell(id) and true or false end
            end
            button:SetAttribute("pressAndHoldAction",hold)
        end
        local native=self:GetFrameRef("nativeMain")
        if native then native:SetAttribute("actionpage",page) end
    end
    self:RunAttribute("mui-bindings")
    local hub=self:GetFrameRef("mui-interface")
    if hub then
        -- Public occupancy belongs to the previous page until sampled again.
        -- Retain the new page conservatively during combat; never hide an
        -- unknown destination merely because the old page was empty.
        self:SetAttribute("mui-content-unknown",true)
        hub:RunAttribute("mui-interface")
    end
]]
-- Keys are captured out of combat, but the route is selected inside the SAME
-- secure page transition. A flyout on page 1 cannot strand click-routing on an
-- empowered spell on page 2. Only flyouts override the native command at all.
A.bindingProgram=[[
    self:ClearBindings()
    local page=tonumber(self:GetAttribute("state-muipage")) or 1
    if page>0 then
        for i=1,12 do
            local button=self:GetFrameRef("slot"..i)
            local action=button:GetAttribute("action")
            local kind=GetActionInfo and GetActionInfo(action)
            if kind=="flyout" and not button:GetAttribute("mui-keybind-editing") then
                local count=button:GetAttribute("mui-key-count") or 0
                for k=1,count do
                    local key=button:GetAttribute("mui-key-"..k)
                    if key then self:SetBindingClick(false,key,button,"MUIFlyoutKey") end
                end
            end
        end
    end
]]
A.clickProgram=[[
    if self:GetAttribute("mui-keybind-editing") then return false end
    -- A modified physical mouse click belongs to the drag gesture. Consume it
    -- before the native action handler; pressAndHoldAction can otherwise select
    -- the down phase even if useOnKeyDown is false. Virtual flyout key clicks
    -- have a distinct button token and never become pickup mouse gestures.
    if button=="LeftButton" then
        local pickup=self:GetAttribute("mui-pickup-pending")
        if down then
            if self:GetAttribute("mui-editable") and IsModifiedClick("PICKUPACTION") and self:IsUnderMouse() then
                self:SetAttribute("mui-pickup-pending",true)
                return false
            elseif pickup then self:SetAttribute("mui-pickup-pending",nil) end
        elseif pickup then
            self:SetAttribute("mui-pickup-pending",nil)
            return false
        end
    end
    local action=self:GetAttribute("action")
    local kind=GetActionInfo and GetActionInfo(action)
    if kind=="flyout" then
        local bar=self:GetParent()
        bar:SetAttribute("mui-flyout-reveal",true)
        bar:Show()
    end
]]
-- Action identities can change without a page transition (drag/drop or macros).
-- Re-evaluate the hold attribute in the restricted environment. Release routing
-- remains actionrelease on every slot, including ordinary actions.
A.holdProgram=[[
    local action=self:GetAttribute("action")
    local hold=false
    if action and GetActionInfo and IsPressHoldReleaseSpell then
        local kind, id=GetActionInfo(action)
        if kind=="spell" and id then hold=IsPressHoldReleaseSpell(id) and true or false end
    end
    self:SetAttribute("pressAndHoldAction",hold)
]]
-- Observe the native per-slot grid mask inside the same restricted environment
-- as action paging. Hiding the real empty button removes its mouse hit target;
-- native key bindings remain on Blizzard's unchanged action commands.
A.gridProgram=[[
    local parent=self:GetParent()
    if not parent or not parent:GetAttribute("mui-grid-active") then return end
    local within=self:GetAttribute("mui-visible-slot")~=false
    if parent:GetAttribute("mui-main-visible")==false and not self:GetAttribute("mui-reserve-slot") then
        self:Hide();return
    end
    if parent:GetAttribute("mui-main-visible")==false and not self:GetAttribute("mui-fixed-slot")
        and not self:GetAttribute("mui-overflow-slot") then self:Hide();return end
    if self:GetAttribute("mui-reserve-slot") and not parent:GetAttribute("mui-reserve-open") then
        self:Hide()
        return
    end
    local native=self:GetFrameRef("mui-grid-native")
    local grid=native and tonumber(native:GetAttribute("showgrid"))
    local action=self:GetAttribute("action")
    local has=action and HasAction and HasAction(action)
    local editor=self:GetAttribute("mui-grid-editor")
    -- The CVar-only grid (bit 1) is editor chrome, not gameplay information.
    -- Keep empty drop targets for native drag/spell-collection reasons (2/4),
    -- the Mirage editor and unknown state; never change the native CVar.
    local temporaryGrid=grid and grid>=2
    local shown=within and (self:GetAttribute("mui-fixed-slot") or editor or grid==nil or temporaryGrid or has~=false)
    if shown then self:Show() else self:Hide() end
]]
local function method(object,key,...)
    if object and type(object[key])=="function" then return pcall(object[key],object,...) end
end
local function field(object,key) return S:Field(object,key) end
local function value(fn,kind,...) return S:Public(fn,kind,...) end
local function cfg(profile)
    return profile and profile.modules and profile.modules.ActionBars or M:ModuleConfig("ActionBars") or {}
end
local function number(v,fallback,low,high)
    if not S:Number(v) then return fallback end
    return math.max(low,math.min(high,v))
end
local function actionSlot(button)
    local slot=value(button.GetAttribute,"number",button,"action")
    if slot and slot>=1 and slot<=180 and slot%1==0 then return slot end
end
local function shortKey(key)
    return key:gsub("SHIFT%-","S-"):gsub("CTRL%-","C-"):gsub("ALT%-","A-"):
        gsub("MOUSEWHEELUP","WU"):gsub("MOUSEWHEELDOWN","WD"):gsub("BUTTON","M")
end
local function text(parent,size,point,x,y,align)
    local f=parent:CreateFontString(nil,"OVERLAY")
    f:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",size,"OUTLINE")
    f:SetPoint(point,parent,point,x,y);f:SetJustifyH(align or "CENTER");f:SetText("")
    return f
end
local function edge(parent,side)
    local t=parent:CreateTexture(nil,"BORDER");t:SetColorTexture(world.stroke[1],world.stroke[2],world.stroke[3],.70)
    if side=="TOP" or side=="BOTTOM" then
        t:SetPoint(side.."LEFT",parent,side.."LEFT",0,0)
        t:SetPoint(side.."RIGHT",parent,side.."RIGHT",0,0);t:SetHeight(1)
    else
        t:SetPoint("TOP"..side,parent,"TOP"..side,0,0)
        t:SetPoint("BOTTOM"..side,parent,"BOTTOM"..side,0,0);t:SetWidth(1)
    end
    return t
end
-- Prominent shortcuts share one passive text layer above the cooldown swipe.
-- The engine still supplies countdowns; their small corner label leaves the
-- centred shortcut legible without discarding timer or stack-count data.
function A:ShortKey(key) return shortKey(key) end
local function keyFont(font,path,size,flags)
    local ok,applied=method(font,"SetFont",path,size,flags)
    if not ok or not S:Readable(applied) or applied==false then return false end
    if applied==true then return true end
    -- SetFont returns success on the reviewed client. A client without that
    -- return must provide an exact public readback before the probe gets text.
    local read,actual,height,outline=method(font,"GetFont")
    return read and S:Readable(actual) and actual==path and S:Number(height)
        and math.abs(height-size)<.001 and S:Readable(outline) and (outline or "")==flags
end
function A:FitKeyLabel(label,button,c,centered)
    local width=value(button.GetWidth,"number",button) or 30
    local height=value(button.GetHeight,"number",button) or width
    local innerWidth,innerHeight=math.max(1,width-4),math.max(1,height-4)
    local auto=centered and c.autoSizeHotkeys==true
    local fontSize=auto and math.min(96,innerHeight) or centered and math.min(number(c.hotkeySize,16,10,24),height*.44) or 9
    local flags=centered and "THICKOUTLINE" or "OUTLINE"
    local content=value(label.GetText,"string",label) or ""
    local fontPath=value(label.GetFont,nil,label)
    if not (S:Text(fontPath) and fontPath~="" or S:Number(fontPath) and fontPath>0) then
        fontPath=STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"
    end
    -- Measure on a separate unconstrained string: the displayed label retains
    -- a complete, centred slot rectangle even while its font is changing.
    -- GetStringWidth on a width-constrained native label can report the already
    -- ellipsized text and therefore approve a chord that still does not fit.
    local measure=button.keyMeasure
    if not measure and button.textLayer then
        local created=value(button.textLayer.CreateFontString,nil,button.textLayer,nil,"OVERLAY")
        if created and (type(created)=="table" or type(created)=="userdata") then
            measure=created;button.keyMeasure=created
        end
    end
    if measure then
        method(measure,"SetAlpha",0);method(measure,"SetWordWrap",false);method(measure,"SetMaxLines",1)
        method(measure,"SetWidth",0);method(measure,"SetHeight",0)
        -- The probe is optional. A missing/rejected cosmetic API must never
        -- turn a usable action slot into a provider failure or visible ghost.
        if value(measure.GetAlpha,"number",measure)~=0 then measure=nil end
    end
    local measured,lineHeight
    local measuredExactly=true
    for attempt=1,3 do
        measured,lineHeight=nil,nil
        if measure and keyFont(measure,fontPath,fontSize,flags) then
            -- An untemplated FontString has no font: initialize successfully
            -- BEFORE SetText, including the empty binding on the first layout.
            local textOK,accepted=method(measure,"SetText",content)
            if textOK and S:Readable(accepted) and accepted~=false then
                measured=value(measure.GetUnboundedStringWidth,"number",measure) or value(measure.GetStringWidth,"number",measure)
                lineHeight=value(measure.GetStringHeight,"number",measure) or value(measure.GetLineHeight,"number",measure)
            end
        end
        if not measured or measured<0 or content~="" and measured==0 then measured=#content*fontSize;measuredExactly=false end
        if not lineHeight or lineHeight<=0 then lineHeight=fontSize*1.25;measuredExactly=false end
        -- Leave one extra pixel per side for the outline/shadow. Fit complete
        -- chords even when they need a size below the old eight-unit floor.
        local ratio=math.min(1,(innerWidth-2)/math.max(1,measured),(innerHeight-2)/math.max(1,lineHeight))
        if ratio>=1 then break end
        fontSize=math.max(1,math.floor(fontSize*math.max(.01,ratio)*10)/10)
    end
    local fitted=keyFont(label,fontPath,fontSize,flags)
    button.keyLabelFit=fitted and (measuredExactly and "MEASURED" or "ESTIMATED_METRICS") or "FONT_CHANGE_UNCONFIRMED"
    method(label,"SetWidth",innerWidth);method(label,"SetHeight",centered and innerHeight or math.min(innerHeight,math.max(1,lineHeight or fontSize)))
    local backing=button.keyBacking
    if backing then
        local visible=centered and c.showHotkeys~=false and content~="" and width>4 and height>4
        backing:SetShown(visible and true or false)
        if visible then
            -- A small translucent badge supports the glyphs while leaving the
            -- icon's perimeter, colour, cooldown and stack count recognizable.
            backing:SetSize(math.min(width-2,math.max(fontSize+4,(measured or #content*fontSize*.75)+6)),math.min(height*.58,(lineHeight or fontSize)+4))
        end
    end
end
function A:StyleKeyLabel(label,button,c,centered)
    label:ClearAllPoints();label:SetWidth(math.max(1,(value(button.GetWidth,"number",button) or 30)-4))
    label:SetPoint(centered and "CENTER" or "TOPRIGHT",button,centered and "CENTER" or "TOPRIGHT",centered and 0 or -2,centered and 0 or -2)
    label:SetJustifyH(centered and "CENTER" or "RIGHT")
    method(label,"SetJustifyV","MIDDLE");method(label,"SetWordWrap",false);method(label,"SetMaxLines",1)
    method(label,"SetTextColor",1,1,.96,1);method(label,"SetShadowColor",0,0,0,1);method(label,"SetShadowOffset",1,-1)
    self:FitKeyLabel(label,button,c,centered)
end
function A:ArrangeKeyLabels(button,c,workspace)
    local centered=workspace==true or c.centerHotkeys==true and c.showHotkeys~=false
    self:StyleKeyLabel(button.hotkey,button,c,centered)
    if button.textLayer then button.textLayer:SetFrameLevel(button:GetFrameLevel()+6) end
    local cd=button.cooldown
    local font=cd and value(cd.GetCountdownFontString,nil,cd)
    if font and type(font.ClearAllPoints)=="function" and type(font.GetFont)=="function" then
        if centered and not button.keyCountdownLease then
            local ok,path,size,flags=pcall(font.GetFont,font)
            local count=value(font.GetNumPoints,"number",font)
            if ok and (S:Text(path) or S:Number(path)) and S:Number(size) and S:Readable(flags) and count and count<=8 then
                local points={};local valid=true
                for i=1,count do
                    local result={pcall(font.GetPoint,font,i)}
                    if not result[1] then valid=false;break end
                    table.remove(result,1)
                    for j=1,5 do if not S:Readable(result[j]) then valid=false end end
                    points[#points+1]=result
                end
                if valid then button.keyCountdownLease={font=font,path=path,size=size,flags=flags,points=points,
                    justify=value(font.GetJustifyH,"string",font)} end
            end
        end
        local lease=button.keyCountdownLease
        if lease and lease.font==font then
            font:ClearAllPoints()
            if centered then
                font:SetPoint("TOPRIGHT",button,"TOPRIGHT",-2,-2)
                font:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",10,"OUTLINE");method(font,"SetJustifyH","RIGHT")
            else
                for _,point in ipairs(lease.points) do font:SetPoint(unpack(point)) end
                font:SetFont(lease.path,lease.size,lease.flags)
                if lease.justify then font:SetJustifyH(lease.justify) end
                button.keyCountdownLease=nil
            end
        end
    end
end
function A:Available(profile)
    if not R.Qualified or not R:Qualified() then return false,"CLIENT_UNQUALIFIED" end
    if M.state and (M.state.safe or not M.state.world) then return false,"SESSION_INACTIVE" end
    if M.Profiles and M.Profiles.readOnly then return false,"PROFILE_READ_ONLY" end
    if R.Selected and not R:Selected("main",profile or M.profile) then return false,"NOT_SELECTED" end
    if M.Native and M.Native:Conflict() then return false,"CONFLICT_NATIVE_OWNER" end
    local editing=R:NativeEditState()
    if editing=="UNKNOWN" then return false,"NATIVE_EDIT_UNKNOWN" end
    if editing=="OPEN" then return false,"NATIVE_EDIT_HANDOFF" end
    if self.contested then
        local parent=value(MainActionBar and MainActionBar.GetParent,nil,MainActionBar)
        if not self.active and self.homeParent and parent==self.homeParent then self.contested=nil
        else return false,"CONFLICT_NATIVE_PARENT" end
    end
    return true
end
function A:CreateButton(bar,i,name,action,command,barIndex)
    local owner=self
    local b=CreateFrame("CheckButton",name,bar,"SecureActionButtonTemplate,SecureHandlerStateTemplate")
    if not S:InitializeSecureHandler(b) then error("SECURE_BUTTON_HANDLER_UNAVAILABLE",0) end
    b:SetID(0);b:SetSize(34,34);b:SetAttribute("type","action");b:SetAttribute("typerelease","actionrelease")
    b:SetAttribute("action",action);b:RegisterForClicks("AnyDown","AnyUp");b:RegisterForDrag("LeftButton")
    -- The client CVar remains the user's authority for key-down behavior.
    -- Both phases are registered to allow the engine's hold/release route.
    b:SetAttribute("checkselfcast",true);b:SetAttribute("checkfocuscast",true);b:SetAttribute("checkmouseovercast",true)
    b:SetAttribute("_onstate-muihold",self.holdProgram)
    SecureHandlerWrapScript(b,"OnClick",b,self.holdProgram..self.clickProgram)
    b:SetAttribute("mui-grid",self.gridProgram)
    SecureHandlerWrapScript(b,"OnAttributeChanged",b,[[
        if name=="action" or name=="mui-visible-slot" or name=="mui-grid-editor" or name=="mui-grid-revision" then
            self:RunAttribute("mui-grid")
        end
    ]])
    b.gridReady=true
    b.GetPopupDirection=function(button)
        return value(button.GetAttribute,"string",button,"flyoutDirection") or "UP"
    end
    b.slot=i;b.barIndex=barIndex or 1;b.nativeCommand=command
    local bg=b:CreateTexture(nil,"BACKGROUND");bg:SetAllPoints();bg:SetColorTexture(.03,.045,.05,.88)
    b.edges={};for _,side in ipairs({"TOP","BOTTOM","LEFT","RIGHT"}) do b.edges[#b.edges+1]=edge(b,side) end
    b.icon=b:CreateTexture(nil,"ARTWORK");b.icon:SetPoint("TOPLEFT",2,-2);b.icon:SetPoint("BOTTOMRIGHT",-2,2)
    b.icon:SetTexCoord(.07,.93,.07,.93)
    local pushed=b:CreateTexture(nil,"OVERLAY");pushed:SetAllPoints();pushed:SetColorTexture(identity.accent[1],identity.accent[2],identity.accent[3],.24)
    b:SetPushedTexture(pushed)
    local highlight=b:CreateTexture(nil,"HIGHLIGHT");highlight:SetAllPoints();highlight:SetColorTexture(identity.secondary[1],identity.secondary[2],identity.secondary[3],.22)
    b:SetHighlightTexture(highlight)
    local checked=b:CreateTexture(nil,"OVERLAY");checked:SetAllPoints();checked:SetColorTexture(world.health[1],world.health[2],world.health[3],.20)
    b:SetCheckedTexture(checked)
    b.proc=b:CreateTexture(nil,"OVERLAY");b.proc:SetAllPoints();b.proc:SetColorTexture(identity.accent[1],identity.accent[2],identity.accent[3],.18);b.proc:Hide()
    b.keyPress=b:CreateTexture(nil,"OVERLAY");b.keyPress:SetAllPoints();b.keyPress:SetColorTexture(identity.accent[1],identity.accent[2],identity.accent[3],.24);b.keyPress:Hide()
    local nativePrefixes={"ActionButton","MultiBarBottomLeftButton","MultiBarBottomRightButton","MultiBarRightButton","MultiBarLeftButton","MultiBar5Button","MultiBar6Button","MultiBar7Button"}
    b.nativeBackingName=(nativePrefixes[barIndex or 1] or "ActionButton")..i
    b.nativeBacking=_G[b.nativeBackingName];self:AttachGridBacking(b)
    b.cooldown=CreateFrame("Cooldown",nil,b,"CooldownFrameTemplate");b.cooldown:SetAllPoints(b.icon)
    b.chargeCooldown=CreateFrame("Cooldown",nil,b,"CooldownFrameTemplate");b.chargeCooldown:SetAllPoints(b.icon)
    method(b.cooldown,"SetHideCountdownNumbers",false);method(b.chargeCooldown,"SetHideCountdownNumbers",true)
    method(b.cooldown,"SetSwipeColor",.02,.03,.04,.72)
    method(b.chargeCooldown,"SetDrawSwipe",false);method(b.chargeCooldown,"SetDrawEdge",true)
    method(b.chargeCooldown,"SetEdgeTexture",white);method(b.chargeCooldown,"SetEdgeScale",.5)
    b.textLayer=CreateFrame("Frame",nil,b);b.textLayer:SetAllPoints(b);b.textLayer:EnableMouse(false)
    b.textLayer:SetFrameLevel(b:GetFrameLevel()+6)
    b.keyBacking=b.textLayer:CreateTexture(nil,"BACKGROUND");b.keyBacking:SetPoint("CENTER",b,"CENTER",0,0)
    b.keyBacking:SetColorTexture(0,0,0,.72);b.keyBacking:Hide()
    b.hotkey=text(b.textLayer,9,"TOPRIGHT",-2,-2,"RIGHT")
    b.count=text(b.textLayer,10,"BOTTOMRIGHT",-2,2,"RIGHT")
    b.macro=text(b.textLayer,8,"BOTTOM",0,2,"CENTER")
    b:SetScript("OnDragStart",function(button,mouse)
        owner.dragInput=button;owner.inputUntil=S:Now()+.4
        if M.ActionEditing then M.ActionEditing:Pickup(button,mouse) end
        owner:MarkVisual("content",actionSlot(button));owner.holdDirty=true;owner.bindingsDirty=true
    end)
    b:SetScript("OnReceiveDrag",function(button)
        owner.dragInput=nil;owner.inputUntil=S:Now()+.4
        if M.ActionEditing then M.ActionEditing:Drop(button) end
        owner:MarkVisual("content",actionSlot(button));owner.holdDirty=true;owner.bindingsDirty=true
    end)
    -- The secure API requires a string pre-body, and Wrapped_Drag only calls
    -- its post-body when the pre-body returns a message. Install after the
    -- ordinary handler so SetScript cannot replace the secure wrapper.
    SecureHandlerWrapScript(b,"OnReceiveDrag",b,[[ return "message", true ]],[[ self:RunAttribute("mui-grid") ]])
    b:SetScript("OnEnter",function(button)
        owner.inputUntil=S:Now()+.4
        if M.KeybindWorkspace and M.KeybindWorkspace:IsActive() then M.KeybindWorkspace:Hover(button);return end
        local tooltip=A.tooltip or GameTooltip
        if cfg(owner.profile).showTooltips==false or not tooltip then return end
        local slot=actionSlot(button);if not slot then return end
        local ok=pcall(function() tooltip:SetOwner(button,"ANCHOR_TOP");tooltip:SetAction(slot);tooltip:Show() end)
        owner.tooltipStatus=ok and "ACTION_TOOLTIP" or "TOOLTIP_UNAVAILABLE"
    end)
    b:SetScript("OnLeave",function(button)
        owner.inputUntil=S:Now()+.4;local tooltip=A.tooltip or GameTooltip;if tooltip then method(tooltip,"Hide") end
        if M.KeybindWorkspace then M.KeybindWorkspace:Leave(button) end
    end)
    -- Observe the existing button's delivered input; no invisible acquisition
    -- region is created. A held press survives the end of a cosmetic cue.
    b:HookScript("OnMouseDown",function(button,mouseButton)
        if M.KeybindWorkspace and M.KeybindWorkspace:IsActive() then M.KeybindWorkspace:Mouse(button,mouseButton);return end
        owner.pressed=owner.pressed or {};owner.pressed[button]=true
    end)
    b:HookScript("OnMouseUp",function(button)
        if owner.pressed then owner.pressed[button]=nil end;owner.inputUntil=S:Now()+.4
    end)
    b:HookScript("OnDragStop",function() owner.dragInput=nil;owner.inputUntil=S:Now()+.4 end)
    b:HookScript("OnHide",function(button)
        if owner.pressed then owner.pressed[button]=nil end
        if owner.dragInput==button then owner.dragInput=nil end
    end)
    b:HookScript("OnShow",function(button)
        if owner.active and not owner.pendingDisable then owner:RefreshButton(button,{},nil,true) end
    end)
    b:Show();self.buttons[i]=b;bar:SetFrameRef("slot"..i,b)
    return b
end
function A:Build()
    if self.ready then return true end
    -- Named secure widgets and installed wrappers cannot be destroyed safely.
    -- Keep native controls after a partial construction and rebuild on reload.
    if self.frame then return false,"RELOAD_REQUIRED_CONTROLS_INCOMPLETE" end
    if S:InCombat() then return false,"COMBAT_LOCKDOWN" end
    if type(CreateFrame)~="function" or type(RegisterStateDriver)~="function" or
       type(UnregisterStateDriver)~="function" or type(GetActionTexture)~="function" or
       type(SecureHandlerWrapScript)~="function" or type(ClearOverrideBindings)~="function" or
       not S:Frame(MainActionBar,false) then return false,"MAIN_ACTION_CAPABILITY_UNAVAILABLE" end
    if M.surfaces[self.layoutID] then return false,"CONFLICT_MAIN_SURFACE" end
    -- Create once, initially hidden. The bar does not depend on the optional
    -- typography/appearance pipeline to become a valid action control.
    local interface=M.ActionInterface
    local parent=interface and interface.ParentFor and interface:ParentFor(self.layoutID) or UIParent
    local bar=CreateFrame("Frame","MirageM1MainActionBar",parent,"SecureHandlerStateTemplate")
    self.frame=bar;bar:Hide();bar:SetSize(464,42)
    if not S:InitializeSecureHandler(bar) then return false,"SECURE_HANDLER_UNAVAILABLE" end
    M:TrackRoot("ActionBars",bar,false,interface and interface.cleanupGuard)
    local panel=bar:CreateTexture(nil,"BACKGROUND");panel:SetAllPoints();panel:SetColorTexture(.025,.035,.04,.22)
    self.nativeGate=CreateFrame("Frame","MirageM1NativeMainGate",UIParent,"SecureHandlerStateTemplate")
    self.nativeGate:Hide()
    self.bindingOwner=bar
    for i=1,12 do
        self:CreateButton(bar,i,"MirageM1MainAction"..i,i,"ACTIONBUTTON"..i,1)
    end
    bar:SetFrameRef("nativeMain",MainActionBar);bar:SetAttribute("_onstate-muipage",self.pageProgram)
    bar:SetAttribute("mui-bindings",self.bindingProgram)
    bar:SetAttribute("_onstate-muibindings",[[ self:RunAttribute("mui-bindings") ]])
    self.surface={id=self.layoutID,module="ActionBars",frame=bar,security="SECURE_PREDECLARED",
        editable=true,minWidth=24,minHeight=20,groups={combat=true},
        layout={x=0,y=-.41,width=464,height=42,scale=1},reworkProvider=self}
    self.surface.OnLayout=function(_,layout) return A:Arrange(layout) end
    bar.surface=self.surface;M.CVE:Register(self.surface)
    self.ready=true;self:AttachVisualWake();self.status="CONTROLS_READY"
    return true
end
function A:Arrange(layout)
    if S:InCombat() then self.pendingConfigure=true;return false,"COMBAT_LOCKDOWN" end
    local c=cfg(self.profile);local count=math.floor(number(c.buttonCount,12,1,12));local columns=math.floor(number(c.columns,12,1,12))
    if c.vertical or (columns==12 and layout.height>layout.width) then columns=1 end
    columns=math.min(columns,count)
    self.frame:SetAlpha(number(c.alpha,1,.2,1))
    local gap=number(c.gap,4,0,12);local rows=math.ceil(count/columns)
    -- The actual saved envelope is the runtime envelope. Small saved dimensions
    -- reduce the gap and icon size instead of silently replacing the geometry.
    local availableW=math.max(1,layout.width-8);local availableH=math.max(1,layout.height-8)
    gap=math.min(gap,availableW/math.max(1,columns*2),availableH/math.max(1,rows*2))
    local size=math.max(1,math.min((availableW-(columns-1)*gap)/columns,(availableH-(rows-1)*gap)/rows))
    local usedW=columns*size+(columns-1)*gap;local usedH=rows*size+(rows-1)*gap
    local x=(layout.width-usedW)/2;local y=-(layout.height-usedH)/2
    local flyoutDirection=rows>columns and ((layout.x or 0)>=0 and "LEFT" or "RIGHT") or
        ((layout.y or 0)>=0 and "DOWN" or "UP")
    for i,b in ipairs(self.buttons) do
        b:SetSize(size,size);b:ClearAllPoints()
        b:SetPoint("TOPLEFT",self.frame,"TOPLEFT",x+((i-1)%columns)*(size+gap),y-math.floor((i-1)/columns)*(size+gap))
        A:ArrangeKeyLabels(b,c,M.state.keybindWorkspace);b.macro:SetWidth(math.max(1,size-4))
        b.hotkey:SetShown(c.showHotkeys~=false);b.macro:SetShown(c.hideMacroText~=true and size>=25);b.count:SetShown(size>=20)
        b:SetAttribute("mui-editable",c.allowRearrange==true)
        b:SetAttribute("flyoutDirection",flyoutDirection)
        b:SetAttribute("mui-visible-slot",i<=count);b:SetShown(i<=count)
    end
    self.layout={width=layout.width,height=layout.height,scale=layout.scale or 1,columns=columns,rows=rows,buttonSize=size,gap=gap,count=count}
    if self.active then self:RefreshGrid(true) else self.gridDirty=true end
    return true
end
function A:NativeGateDriver() return nativeGateDriver end
function A:LeaseNative()
    if self.lease then return self:ReconcileNative() end
    if not S:Frame(MainActionBar,false) then return false,"MAIN_NATIVE_UNAVAILABLE" end
    local lease,why=NP:Acquire(MainActionBar,self.nativeGate,self:NativeGateDriver())
    if not lease then return false,why end
    self.lease=lease;self.homeParent=lease.parent
    return why==nil,why
end
function A:ReconcileNative()
    if not self.lease then return false,"NO_NATIVE_LEASE" end
    if NP:Current(self.lease) then self.nativeDirty=false;return true end
    self.nativeDirty=true
    local renewed,reason=NP:RenewNativeParent(self.lease)
    if renewed then
        self.lease=renewed;self.homeParent=renewed.parent
        if not reason then self.nativeDirty=false;return true end
    end
    return false,reason or "NATIVE_ACTION_PRESENTATION_CHANGED"
end
function A:RefreshNativeDriver()
    if not self.lease then return true end
    local ready,reason=self:ReconcileNative()
    if ready then ready,reason=NP:UpdateDriver(self.lease,self:NativeGateDriver()) end
    if not ready then self.nativeDirty=true;self.pendingWork=true end
    return ready,reason
end
function A:ReleaseNative()
    if not NP:Release(self.lease) then return false,"NATIVE_ACTION_PRESENTATION_RESTORE_PENDING" end
    self.lease=nil;self.nativeDirty=nil
    return true
end
function A:InputHeld(now)
    now=now or S:Now()
    if self.inputProfile~=M.profile then self.inputProfile=M.profile;self.inputUntil=nil;self.pressed=nil;self.dragInput=nil end
    if self.pressed and next(self.pressed) then return true end
    local cursor,known=nil,"UNKNOWN"
    if type(GetCursorInfo)=="function" then
        local ok,kind=pcall(GetCursorInfo)
        if ok and S:Readable(kind) and (kind==nil or type(kind)=="string") then cursor,known=kind,"KNOWN" end
    end
    local assignment=known=="KNOWN" and (cursor=="spell" or cursor=="item" or cursor=="macro" or cursor=="flyout" or cursor=="petaction")
    -- A real cursor assignment intentionally offers visible drop targets. The
    -- spellbook simply being open, or unrelated keyboard focus, does not.
    if assignment and cfg(self.profile).allowRearrange==true then return true end
    if self.dragInput then
        local down,state=value(IsMouseButtonDown,"boolean")
        if state~="KNOWN" or down==true or known~="KNOWN" then return true end
        self.dragInput=nil
    end
    if self.frame and value(self.frame.IsVisible,"boolean",self.frame)==true and value(self.frame.IsMouseOver,"boolean",self.frame)==true
        and not (M.DisplayOcclusion and M.DisplayOcclusion:Blocks(self.frame,true)) then self.inputUntil=now+.4 end
    if M.PresentationGroups and M.PresentationGroups:Enabled() and self.frame then
        local hovered,due=M.PresentationGroups:Hover(self,self.frame,now)
        if hovered then self.inputUntil=due end
        self.contextHover=hovered or (self.inputUntil or 0)>now
    end
    return (self.inputUntil or 0)>now
end
function A:VisibilityDriver(profile)
    local c=cfg(profile);local combat,ordinary="show","show"
    local rules=profile and profile.elementContexts and profile.elementContexts[self.layoutID] or {}
    if rules.Combat=="HIDE" then combat="hide" end
    local snapshot=M.Store and M.Store:Snapshot() or {}
    local context=M.ElementRules and M.ElementRules:Context(snapshot)
    local current=(context=="Moving") and rules.Moving or rules.Idle
    if current=="HIDE" or (not current and c.contextual==true) then ordinary="hide" end
    if profile.managed and profile.preset=="Immersive" and M.ScopedActivity and current~="SHOW" then
        ordinary=M.ScopedActivity:Demand("COMBAT",snapshot,S:Now())==false and "hide" or "show"
        if current=="HIDE" then ordinary="hide" end
    end
    if c.visibility=="Always" then ordinary="show";combat="show"
    elseif c.visibility=="Manual" then ordinary="hide";combat="hide" end
    local revealing=M.state and (M.state.edit or (M.state.revealUntil or 0)>S:Now())
    local input=self:InputHeld(S:Now())
    if revealing or self.flyoutReveal or input then ordinary="show";combat="show" end
    if ordinary=="show" and not input and not self.flyoutReveal and M.DisplayOcclusion and M.DisplayOcclusion:Blocks(self.frame,true) then
        ordinary="hide" -- native task geometry wins; secure combat still owns its access floor
    end
    -- A stale target/focus, motion, general task, or a cast does not reveal the
    -- action cluster. Secure combat/special actions retain their exact drivers.
    return special.."[combat] "..combat.."; "..ordinary
end
function A:SetVisibilityDriver(driver)
    local frame=self.frame
    if S:InCombat() or not frame then return false,"COMBAT_LOCKDOWN" end
    local function owns()
        return self.frame==frame and self.profile==M.profile and not self.pendingDisable
            and not M.state.safe and (self.ready==true or self.controlsReady==true)
    end
    local ok,why
    if M.Effects and M.Effects.RegisterVisibility then ok,why=M.Effects:RegisterVisibility(self,frame,driver,owns)
    else ok=RegisterStateDriver(frame,"visibility",driver)~=false end
    if ok then self.visibleDriver=driver end
    return ok,why
end
function A:ClearVisibilityDriver()
    if M.Effects and M.Effects.UnregisterVisibility then M.Effects:UnregisterVisibility(self,self.frame)
    elseif self.frame then UnregisterStateDriver(self.frame,"visibility") end
    self.visibleDriver=nil
end
-- Binding contexts and labels are stable until the native binding change or
-- login event. Rendering never enumerates the binding map on a cooldown tick.
-- The same cache also feeds secure flyout routing; stored assignments are never
-- written. A failed lookup is cached until an applicable event/retry.
A.keyCache={}
A.metrics={bindingLookups=0,visualPasses=0,buttonPaints=0,dormantSkips=0}
function A:InvalidateKeys()
    A.keyCache={};A.keyRevision=(A.keyRevision or 0)+1
end
function A:Keys(command)
    if not S:Text(command) then return nil end
    local cached=A.keyCache[command]
    if cached~=nil then return cached~=false and cached or nil end
    A.metrics.bindingLookups=A.metrics.bindingLookups+1
    local result
    if M.ActionKeys and M.ActionKeys:IsAction(command) then result=M.ActionKeys:Keys(command)
    elseif type(GetBindingKey)=="function" then
        local context,known
        if C_KeyBindings then context,known=value(C_KeyBindings.GetBindingContextForAction,"number",command) end
        if not C_KeyBindings or known=="KNOWN" and context>=0 and context%1==0 then
            local values={pcall(GetBindingKey,command,nil,context)}
            if values[1] then
                result={}
                for i=2,math.min(#values,33) do
                    if not S:Text(values[i]) or #values[i]>80 or values[i]:find("[%c| ]") then result=nil;break end
                    result[#result+1]=values[i]
                end
            end
        end
    end
    A.keyCache[command]=result or false
    return result
end
function A:MarkVisual(kind,slot)
    self.visualDirty=self.visualDirty or {}
    if kind=="all" then self.visualDirtyAll=true
    elseif kind=="content" and S:Number(slot) and slot>=1 and slot<=180 and slot%1==0 then
        self.slotDirty=self.slotDirty or {};self.slotDirty[slot]=true
    else self.visualDirty[kind]=true end
end
local function setText(button,key,region,text)
    if button[key]~=text then region:SetText(text);button[key]=text end
end
local function setShown(button,key,region,shown)
    if region and button[key]~=shown then region:SetShown(shown);button[key]=shown end
end
function A:RefreshButton(b,flags,slots,all)
    local slot=actionSlot(b)
    if not slot then
        if b.renderSlot~=false then b.icon:SetTexture(nil);b.count:SetText("");b.macro:SetText("");b.renderSlot=false;b.renderTexture=nil;b.renderCount=nil;b.renderMacro=nil end
        return
    end
    all=all or slot~=b.renderSlot or slots and slots[slot]==true
    flags=flags or {}
    b.renderSlot=slot
    if not all and not next(flags) then return end
    A.metrics.buttonPaints=A.metrics.buttonPaints+1
    if all or flags.content then
        local icon=value(GetActionTexture,nil,slot)
        if b.renderTexture~=icon then b.icon:SetTexture(icon);b.renderTexture=icon end
        setText(b,"renderMacro",b.macro,value(C_ActionBar and C_ActionBar.GetActionText or GetActionText,"string",slot) or "")
    end
    if all or flags.content or flags.count or flags.cooldown then
        local displayCount=value(C_ActionBar and C_ActionBar.GetActionDisplayCount,nil,slot)
        local charges=value(C_ActionBar and C_ActionBar.GetActionCharges,"table",slot)
        local maxCharges=field(charges,"maxCharges");local currentCharges=field(charges,"currentCharges")
        local countText
        if S:Number(maxCharges) and maxCharges>1 and S:Number(currentCharges) then countText=tostring(currentCharges)
        elseif S:Text(displayCount) or S:Number(displayCount) then countText=tostring(displayCount)
        else local count=value(GetActionCount,"number",slot);countText=count and count>1 and tostring(count) or "" end
        setText(b,"renderCount",b.count,countText)
    end
    if all or flags.content or flags.cooldown then
        -- Native widgets retain their duration objects and animate between
        -- actual cooldown/charge changes; a liveness poll never resubmits them.
        b.cooldownStatus=M.Display:Cooldown(b.cooldown,C_ActionBar and C_ActionBar.GetActionCooldownDuration,slot)
        b.chargeStatus=M.Display:Cooldown(b.chargeCooldown,C_ActionBar and C_ActionBar.GetActionChargeDuration,slot)
    end
    if all or flags.content or flags.overlay then
        local overlay=false
        if b.proc and type(GetActionInfo)=="function" then
            local ok,kind,id=pcall(GetActionInfo,slot)
            if ok and S:Text(kind) and S:Number(id) then
                if kind=="macro" then id=value(GetMacroSpell,"number",id) end
                if id then overlay=value(C_SpellActivationOverlay and C_SpellActivationOverlay.IsSpellOverlayed,"boolean",id)==true end
            end
        end
        setShown(b,"renderProc",b.proc,overlay)
    end
    if all or flags.dynamic or flags.state then
        if b.keyPress then
            local backing=b.nativeBacking
            local state=backing and value(backing.GetButtonState,"string",backing)
            setShown(b,"renderPress",b.keyPress,state=="PUSHED" or (b.pressUntil or 0)>S:Now())
        end
        local current=value(C_ActionBar and C_ActionBar.IsCurrentAction or IsCurrentAction,"boolean",slot)
        local repeatAction=value(C_ActionBar and C_ActionBar.IsAutoRepeatAction or IsAutoRepeatAction,"boolean",slot)
        local checked=current==true or repeatAction==true
        if b.renderChecked~=checked then method(b,"SetChecked",checked);b.renderChecked=checked end
    end
    if all or flags.dynamic or flags.usability then
        local usable,noMana
        local fn=IsUsableAction or C_ActionBar and C_ActionBar.IsUsableAction
        if type(fn)=="function" then
            local ok,u,n=pcall(fn,slot)
            if ok and S:Readable(u) and S:Readable(n) then usable,noMana=u,n end
        end
        local tint=noMana==true and "MANA" or usable==false and "UNUSABLE" or "READY"
        if b.renderTint~=tint then
            if tint=="MANA" then b.icon:SetVertexColor(.48,.62,.95,1)
            elseif tint=="UNUSABLE" then b.icon:SetVertexColor(.45,.45,.45,1)
            else b.icon:SetVertexColor(1,1,1,1) end
            b.renderTint=tint
        end
    end
    if all or flags.dynamic or flags.range then
        local range=value(C_ActionBar and C_ActionBar.IsActionInRange or IsActionInRange,nil,slot)
        local outOfRange=(type(range)=="number" and range==0) or range==false
        if b.renderRange~=outOfRange then
            for _,t in ipairs(b.edges) do
                if outOfRange then t:SetColorTexture(world.accents.Bleed[1],world.accents.Bleed[2],world.accents.Bleed[3],.95)
                else t:SetColorTexture(world.stroke[1],world.stroke[2],world.stroke[3],.70) end
            end
            b.renderRange=outOfRange
        end
    end
    if all or flags.hotkeys then
        local keys=self:Keys(b.nativeCommand)
        setText(b,"renderHotkey",b.hotkey,keys and keys[1] and shortKey(keys[1]) or "")
        A:FitKeyLabel(b.hotkey,b,cfg(self.profile),M.state.keybindWorkspace==true or cfg(self.profile).centerHotkeys==true)
    end
end
function A:Refresh(flags,slots,all)
    A.metrics.visualPasses=A.metrics.visualPasses+1
    if flags==nil then all=true;flags={} end
    for _,b in ipairs(self.buttons) do self:RefreshButton(b,flags,slots,all) end
    self.dirty=false
    self.visualDirtyAll=nil
    if self.visualDirty then for key in pairs(self.visualDirty) do self.visualDirty[key]=nil end end
    if self.slotDirty then for slot in pairs(self.slotDirty) do self.slotDirty[slot]=nil end end
end
function A:VisualActive()
    if not self.frame then return false end
    local visible,state=value(self.frame.IsVisible or self.frame.IsShown,"boolean",self.frame)
    if state=="KNOWN" and not visible then return false end
    local alpha,known=value(self.frame.GetEffectiveAlpha or self.frame.GetAlpha,"number",self.frame)
    return known~="KNOWN" or alpha>0
end
function A:RefreshVisual(now,force)
    if not force and not self:VisualActive() then
        self.visualWasVisible=false;A.metrics.dormantSkips=A.metrics.dormantSkips+1;return
    end
    now=S:Number(now) and now or S:Now()
    local all=force or self.visualWasVisible~=true or self.visualDirtyAll or self.dirty
    self.visualWasVisible=true
    self.visualDirty=self.visualDirty or {}
    if now-(self.lastDynamic or -1)>=.2 then self.visualDirty.dynamic=true;self.lastDynamic=now end
    if all or next(self.visualDirty) or self.slotDirty and next(self.slotDirty) then
        self:Refresh(self.visualDirty,self.slotDirty,all)
    end
end
function A:AttachVisualWake()
    if self.visualWake or not self.frame or type(self.frame.HookScript)~="function" then return end
    self.visualWake=true
    local owner=self
    self.frame:HookScript("OnShow",function()
        if owner.active and not owner.pendingDisable then owner:RefreshVisual(S:Now(),true) end
    end)
    self.frame:HookScript("OnHide",function() owner.visualWasVisible=false end)
    if type(hooksecurefunc)=="function" and type(self.frame.SetAlpha)=="function" then
        hooksecurefunc(self.frame,"SetAlpha",function(_,alpha)
            if owner.active and not owner.pendingDisable and owner.visualWasVisible~=true and S:Number(alpha) and alpha>0 then owner:RefreshVisual(S:Now(),true) end
        end)
    end
end
function A:GridStatus()
    -- Read the client's actual per-button reason mask rather than infer the
    -- user's Always Show Buttons choice from a screenshot or an empty icon.
    -- The observer follows this choice; no native CVar or assignment is changed.
    local filled,empty,unknown,on,off,unreadable,cvarOnly,temporary=0,0,0,0,0,0,0,0
    for _,b in ipairs(self.buttons) do
        local slot=actionSlot(b)
        local has=slot and value(C_ActionBar and C_ActionBar.HasAction or HasAction,"boolean",slot)
        if has==true then filled=filled+1 elseif has==false then empty=empty+1 else unknown=unknown+1 end
        local backing=b.nativeBacking
        local grid=backing and value(backing.GetAttribute,"number",backing,"showgrid")
        if S:Number(grid) and grid>=0 then
            if grid>0 then on=on+1 else off=off+1 end
            if grid==1 then cvarOnly=cvarOnly+1 elseif grid>=2 then temporary=temporary+1 end
        else unreadable=unreadable+1 end
    end
    return "filled:"..filled..",empty:"..empty..",unknown:"..unknown..",grid_on:"..on..",grid_cvar_only:"..cvarOnly..",grid_temporary:"..temporary..",grid_off:"..off..",grid_unknown:"..unreadable..",editor:"..tostring(self.gridEditor==true)..",visibility:POPULATED_OR_NATIVE_DRAG_GRID"
end
function A:AttachGridBacking(button)
    if S:InCombat() or not button.gridReady then return end
    local native=button.nativeBackingName and _G[button.nativeBackingName] or button.nativeBacking
    if not S:Frame(native,false) or button.gridBacking==native then return end
    button.nativeBacking=native;button:SetFrameRef("mui-grid-native",native)
    SecureHandlerWrapScript(native,"OnAttributeChanged",button,[[
        if name=="showgrid" and control:GetFrameRef("mui-grid-native")==self then
            local bar=control:GetParent()
            local hub=bar and bar:GetFrameRef("mui-interface")
            if hub then hub:RunAttribute("mui-interface") else control:RunAttribute("mui-grid") end
        end
    ]])
    button.gridBacking=native
end
function A:RefreshGrid(force)
    if S:InCombat() then self.gridDirty=true;return end
    local editor=M.state.edit==true or (M.ActionInterface and M.ActionInterface:EditingOpen())==true
    if not force and not self.gridDirty and self.gridEditor==editor then return end
    self.gridEditor=editor;self.gridDirty=nil;self.gridRevision=(self.gridRevision or 0)+1
    for _,button in ipairs(self.buttons) do
        if button.gridReady then
            self:AttachGridBacking(button)
            button:SetAttribute("mui-grid-editor",editor)
            button:SetAttribute("mui-grid-revision",self.gridRevision)
        end
    end
end
function A:RefreshBindings()
    if S:InCombat() then self.bindingsDirty=true;return false,"COMBAT_LOCKDOWN" end
    local keysByButton={};local pieces={}
    for _,b in ipairs(self.buttons) do
        local keys=self:Keys(b.nativeCommand)
        if not keys then return false,"BINDING_CONTEXT_UNAVAILABLE" end
        keysByButton[b]=keys
        for _,key in ipairs(keys) do pieces[#pieces+1]=key..":"..b:GetName() end
    end
    local signature=table.concat(pieces,"|")
    if self.bindingSignature~=signature then
        for _,b in ipairs(self.buttons) do
            local keys=keysByButton[b];local previous=value(b.GetAttribute,"number",b,"mui-key-count") or 0
            for i=1,math.max(previous,#keys) do b:SetAttribute("mui-key-"..i,keys[i]) end
            b:SetAttribute("mui-key-count",#keys)
        end
    end
    self.bindingRevision=(self.bindingRevision or 0)+1
    self.frame:SetAttribute("state-muibindings",tostring(self.bindingRevision))
    self.bindingSignature=signature;self.bindingsDirty=false
    return true
end
function A:RefreshHold()
    if S:InCombat() then self.holdDirty=true;return end
    self.holdRevision=(self.holdRevision or 0)+1
    -- State changes execute a fixed predeclared snippet, rather than guessing a
    -- secret spell identity in ordinary Lua. No function body is changed here.
    for _,b in ipairs(self.buttons) do
        if not self.holdSlots or self.holdSlots[actionSlot(b)] then b:SetAttribute("state-muihold",tostring(self.holdRevision)) end
    end
    self.holdSlots=nil;self.holdDirty=false
end
function A:PageDriver()
    local clauses=""
    -- Source-observed Forever powershift repair: a druid's form can remain set
    -- while its bonusbar condition briefly disappears. Real class/form values
    -- are read only out of combat; manual and valid bonus pages retain priority.
    if not S:InCombat() and type(UnitClass)=="function" and type(GetShapeshiftFormInfo)=="function" then
        local ok,_,class=pcall(UnitClass,"player")
        local count=value(GetNumShapeshiftForms,"number")
        if ok and S:Text(class) and class=="DRUID" and count and count>=0 and count<=10 and count%1==0 then
            for i=1,count do
                local read,_,_,_,spell=pcall(GetShapeshiftFormInfo,i)
                if read and S:Number(spell) then
                    if spell==768 then clauses=clauses.."[form:"..i..",nostealth] 7; "
                    elseif spell==5487 or spell==9634 then clauses=clauses.."[form:"..i.."] 9; " end
                end
            end
        end
    end
    return pagePrefix..clauses.."1"
end
function A:Initialize(profile)
    local allowed,why=self:Available(profile)
    if not allowed then self.status=why;return false,why end
    local ok,reason=self:Build()
    if not ok then self.status=reason;return false,reason end
    return self:Configure(profile)
end
function A:Configure(profile)
    self.failureEvidence=nil
    profile=profile or M.profile
    local allowed,why=self:Available(profile)
    if not allowed then
        if why=="NATIVE_EDIT_UNKNOWN" then self.pendingConfigure=true;return false,why end
        self:Suspend(why);return false,why
    end
    self.profile=profile
    if S:InCombat() then self.pendingConfigure=true;self.status="QUEUED_CONFIGURE";return false,"COMBAT_LOCKDOWN" end
    if not self.ready then return self:Initialize(profile) end
    self.pendingDisable=nil;self.pendingConfigure=nil;self.quiesced=nil;self.runtimeStopReason=nil
    local ok,reason=xpcall(function()
        M.Layout:Apply(self.surface)
        self.pageDriver=self:PageDriver();RegisterStateDriver(self.frame,"muipage",self.pageDriver)
        local visible=self:VisibilityDriver(profile)
        assert(self:SetVisibilityDriver(visible),"VISIBILITY_DRIVER_UNAVAILABLE")
        self:RefreshHold();self:Refresh()
        local bound,err=self:RefreshBindings();if not bound then error(err,0) end
        local leased,err2=self:LeaseNative();if not leased then error(err2,0) end
    end,function(err)
        if M.Incidents and type(M.Incidents.CaptureFailure)=="function" then
            local captured,evidence=pcall(M.Incidents.CaptureFailure,M.Incidents,"PROVIDER","MODULE_CONFIG")
            if captured and type(evidence)=="table" then self.failureEvidence=evidence end
        end
        -- Keep authored categories and bounded source evidence. Native error
        -- text may contain payloads and is not a persistent support category.
        return S:Text(err) and #err<96 and err:match("^[A-Z][A-Z0-9_]*$") and err or "ACTION_CONFIGURE_ERROR"
    end)
    if not ok then
        self:Suspend("CONFIGURE_FAILED");self.status="CONFIGURE_FAILED"
        self.reason=S:Text(reason) and reason or "ACTION_CONFIGURE_ERROR"
        return false,self.reason
    end
    self.active=true;self.frame:SetAttribute("mui-grid-active",true);self:RefreshGrid(true)
    self:AttachVisualWake();self.status="CUSTOM_MAIN_ACTIVE";self.reason=nil
    return true
end
function A:InvalidateEvent(event,arg1)
    -- Content/page changes can alter the secure flyout/hold route, but they do
    -- not alter the assignment map. Reuse cached keys for those routing updates.
    if event=="UPDATE_BINDINGS" or event=="PLAYER_ENTERING_WORLD" then
        if self==A then self:InvalidateKeys() end
        self.bindingsDirty=true;self:MarkVisual("hotkeys")
    end
    if event=="ACTIONBAR_SLOT_CHANGED" then
        if S:Number(arg1) and arg1>=1 and arg1<=180 and arg1%1==0 then
            local affected=false
            for _,button in ipairs(self.buttons) do if actionSlot(button)==arg1 then affected=true;break end end
            if not affected then return end
            self.holdSlots=self.holdSlots or {};self.holdSlots[arg1]=true
        else self.holdSlots=nil end
        self:MarkVisual("content",arg1);self.bindingsDirty=true;self.holdDirty=true;self.gridDirty=true
    elseif event=="ACTIONBAR_PAGE_CHANGED" or event=="UPDATE_MACROS" or event=="SPELLS_CHANGED" or
        event=="UPDATE_SHAPESHIFT_FORM" or event=="UPDATE_BONUS_ACTIONBAR" or event=="PLAYER_ENTERING_WORLD" then
        self:MarkVisual("all");self.bindingsDirty=true;self.holdDirty=true;self.holdSlots=nil;self.gridDirty=true
    elseif event=="ACTIONBAR_UPDATE_COOLDOWN" or event=="SPELL_UPDATE_CHARGES" then self:MarkVisual("cooldown")
    elseif event=="ACTIONBAR_UPDATE_USABLE" or event=="UNIT_POWER_UPDATE" then
        if event~="UNIT_POWER_UPDATE" or arg1=="player" or arg1==nil then self:MarkVisual("usability") end
    elseif event=="ACTIONBAR_UPDATE_STATE" then self:MarkVisual("state")
    elseif event=="PLAYER_TARGET_CHANGED" then self:MarkVisual("range");self:MarkVisual("usability")
    elseif event=="BAG_UPDATE_DELAYED" then self:MarkVisual("count")
    elseif event=="ACTIONBAR_SHOWGRID" or event=="ACTIONBAR_HIDEGRID" or event=="ADDON_LOADED" or event=="EDIT_MODE_LAYOUTS_UPDATED" then self.gridDirty=true
    elseif event=="SPELL_ACTIVATION_OVERLAY_GLOW_SHOW" or event=="SPELL_ACTIVATION_OVERLAY_GLOW_HIDE" then self:MarkVisual("overlay") end
end
function A:OnEvent(event,...)
    if not self.ready then return end
    self:InvalidateEvent(event,...)
    if event=="PLAYER_ENTERING_WORLD" then self.nativeDirty=true end
    if event=="UPDATE_SHAPESHIFT_FORMS" then self.pendingConfigure=true end
    if event=="PLAYER_REGEN_ENABLED" and self.pendingDisable then return self:Suspend(self.pendingDisable) end
end
function A:Tick(now)
    if self.pendingDisable then
        if S:InCombat() then return false,"COMBAT_LOCKDOWN" end
        local reason=self.pendingDisable
        local released,why=self:Suspend(reason)
        return false,released and reason or why or reason
    end
    if self.pendingConfigure and not S:InCombat() then return self:Configure(M.profile) end
    if not self.active then
        -- A native fault can retire the presentation while sliced family
        -- preparation still reports WAITING. nil means no work, so it cannot
        -- communicate this handback to the provider lifecycle or recovery.
        if self.runtimeStopReason then return false,self.runtimeStopReason end
        return
    end
    local allowed,why=self:Available(M.profile)
    if not allowed then
        if why=="NATIVE_EDIT_UNKNOWN" then return false,why end
        local released,pending=self:Suspend(why)
        return false,released and why or pending or why
    end
    if self.nativeDirty then
        local ok,reason=self:ReconcileNative()
        if not ok and reason~="COMBAT_LOCKDOWN" then
            local released,pending=self:Suspend(reason)
            return false,released and reason or pending or reason
        end
    end
    if not S:InCombat() then
        self:RefreshGrid()
        local reveal=value(self.frame.GetAttribute,"boolean",self.frame,"mui-flyout-reveal")
        local shown=SpellFlyout and value(SpellFlyout.IsShown,"boolean",SpellFlyout)
        if reveal then
            if shown==false or not SpellFlyout then
                self.frame:SetAttribute("mui-flyout-reveal",nil);self.flyoutReveal=nil
            else self.flyoutReveal=true end
        else self.flyoutReveal=nil end
        local driver=self:VisibilityDriver(M.profile)
        if driver~=self.visibleDriver and not self:SetVisibilityDriver(driver) then
            local released,pending=self:Suspend("VISIBILITY_DRIVER_UNAVAILABLE")
            return false,released and "VISIBILITY_DRIVER_UNAVAILABLE" or pending or "VISIBILITY_DRIVER_UNAVAILABLE"
        end
        if self.holdDirty then self:RefreshHold() end
        if self.bindingsDirty then
            local ok,reason=self:RefreshBindings()
            if not ok then
                local released,pending=self:Suspend(reason)
                return false,released and reason or pending or reason
            end
        end
    end
    now=S:Number(now) and now or S:Now()
    self:RefreshVisual(now)
end
function A:Suspend(reason)
    self.runtimeStopReason=reason or "ACTION_PRESENTATION_STOPPED"
    if S:InCombat() then
        if self.quiesced or (not self.frame and not self.lease) then self.active=false;self.status=reason or "SUSPENDED";return true end
        self.pendingDisable=reason or "SUSPENDED";self.pendingConfigure=nil;self.status="QUEUED_SUSPEND"
        return false,"COMBAT_LOCKDOWN"
    end
    if self.frame then
        self.frame:SetAttribute("mui-grid-active",false)
        self:ClearVisibilityDriver();UnregisterStateDriver(self.frame,"muipage");self.frame:Hide()
    end
    if self.bindingOwner and type(ClearOverrideBindings)=="function" then ClearOverrideBindings(self.bindingOwner) end
    self.bindingSignature=nil;self.visualWasVisible=false
    self.flyoutReveal=nil
    if self.frame then self.frame:SetAttribute("mui-flyout-reveal",nil) end
    self.inputUntil=nil;self.pressed=nil;self.dragInput=nil
    self.active=false -- control quiescence is separate from native restoration debt
    local ok,why=self:ReleaseNative()
    if not ok then self.status=why;self.pendingDisable=reason or "SUSPENDED";return false,why end
    self.active=false;self.quiesced=true;self.pendingDisable=nil;self.pendingConfigure=nil;self.nativeDirty=false
    self.status=reason or "SUSPENDED"
    return true
end
function A:Bounds()
    if not self.frame then return nil,"NOT_CREATED" end
    return {frame=self.frame,layoutID=self.layoutID,provider=self.id,
        width=value(self.frame.GetWidth,"number",self.frame),height=value(self.frame.GetHeight,"number",self.frame),
        scale=value(self.frame.GetScale,"number",self.frame),left=value(self.frame.GetLeft,"number",self.frame),
        bottom=value(self.frame.GetBottom,"number",self.frame),active=self.active==true}
end
function A:Status()
    local page=self.frame and value(self.frame.GetAttribute,"number",self.frame,"actionpage")
    return "buttons="..#self.buttons..";page="..(page and tostring(page) or "UNKNOWN")..
        ";native_main="..(self.lease and "LEASED_ORDINARY" or "RELEASED")..
        ";key_queries="..tostring(A.metrics.bindingLookups)..";visual_passes="..tostring(A.metrics.visualPasses)..
        ";dormant_skips="..tostring(A.metrics.dormantSkips)..";special_states=NATIVE_DELEGATED;bindings=SAVED_UNCHANGED;slots="..self:GridStatus()..";"..NP:Status()..";native_validation=NOT_RUN"
end
