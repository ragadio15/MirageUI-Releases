local _,M=...
-- WP11: the complete engine objective model supplies secure interactions and
-- specialized content. Mirage owns the viewport, readable text renderer, headers,
-- item presentation and controls. There is no quest-count or objective-line cap.
local R,S,L=M.Rework,M.Safety,M.Rework.CombatLeases
local pack=L.Pack
local O={id="objectives",module="QuestTracker",status="NOT_INITIALIZED",cooperativeStyle=true,nativeRoots={ObjectiveTrackerFrame=true},
 navigationRecipient="TRACKER",
 layoutIDs={["QuestTracker.nativePosition"]=true},events={ADDON_LOADED=true,PLAYER_ENTERING_WORLD=true,
 PLAYER_REGEN_ENABLED=true,QUEST_LOG_UPDATE=true,QUEST_WATCH_UPDATE=true,QUEST_WATCH_LIST_CHANGED=true,
 QUEST_ACCEPTED=true,QUEST_REMOVED=true,QUEST_TURNED_IN=true,QUEST_DATA_LOAD_RESULT=true,
 SCENARIO_UPDATE=true,SCENARIO_CRITERIA_UPDATE=true,SCENARIO_COMPLETED=true,
 TRACKED_ACHIEVEMENT_UPDATE=true,TRACKED_ACHIEVEMENT_LIST_CHANGED=true,
 SUPER_TRACKING_CHANGED=true,ZONE_CHANGED=true,ZONE_CHANGED_NEW_AREA=true,
 CONTENT_TRACKING_UPDATE=true,TRACKED_RECIPE_UPDATE=true,MONTHLY_ACTIVITIES_UPDATED=true,
 EDIT_MODE_LAYOUTS_UPDATED=true,DISPLAY_SIZE_CHANGED=true,UI_SCALE_CHANGED=true},
 mirrors=setmetatable({},{__mode="k"}),owned=setmetatable({},{__mode="k"}),fontHooks=setmetatable({},{__mode="k"}),
 geometryHooks=setmetatable({},{__mode="k"}),dirtyFonts=setmetatable({},{__mode="k"})}
R.Objectives=O
local families={"ScenarioObjectiveTracker","UIWidgetObjectiveTracker","CampaignQuestObjectiveTracker",
 "QuestObjectiveTracker","AdventureObjectiveTracker","AchievementObjectiveTracker","MonthlyActivitiesObjectiveTracker",
 "InitiativeTasksObjectiveTracker","ProfessionsRecipeTracker","BonusObjectiveTracker","WorldQuestObjectiveTracker"}
local maximumContentHeight=32768
local frameStrata={WORLD=true,BACKGROUND=true,LOW=true,MEDIUM=true,HIGH=true,DIALOG=true,FULLSCREEN=true,FULLSCREEN_DIALOG=true,TOOLTIP=true}
local visibilityProgram=[[
 if newstate=="hide" then
  self:CallMethod("MirageObjectiveStopFade")
  self:Hide()
  self:CallMethod("MirageObjectiveHidden")
 elseif newstate=="quiet" then
  self:CallMethod("MirageObjectiveFade",false)
 else
  local alpha=(self:GetAttribute("mirage-objective-alpha") or 1)*(newstate=="ambient" and .25 or 1)
  if newstate~="show" then self:CallMethod("MirageObjectiveStopFade") end
  self:SetAlpha(alpha)
  self:Show()
  if newstate=="show" then self:CallMethod("MirageObjectiveFade",true) end
 end
]]
local function live() return O.active and R:Qualified() and R:Selected("objectives") and not M.state.safe and not R:NativeEditing() end
local function f(o,k) return L:Field(o,k) end
local function call(o,k,...) return L:Call(o,k,...) end
local function public(o,k,kind,...) return L:Public(o,k,kind,...) end
local function screen()
 if M.Layout and M.Layout.Screen then return M.Layout:Screen() end
 if M.Managed and M.Managed.Viewport then return M.Managed:Viewport() end
 return public(UIParent,"GetWidth","number"),public(UIParent,"GetHeight","number")
end
local function styleMillis()
 if type(debugprofilestop)~="function" then return end
 local ok,value=pcall(debugprofilestop);if ok and S:Number(value) then return value end
end
local function styleStep(quantum)
 if quantum.remaining<=0 then return false end
 if quantum.started and quantum.steps>=1 then
  local clock=styleMillis();if clock and clock-quantum.started>=.35 then return false end
 end
 quantum.remaining=quantum.remaining-1;quantum.steps=quantum.steps+1;return true
end
local function within(node,root)
 -- A retained traversal must not paint a pooled child moved into another
 -- native window between chunks. Only public ancestry establishes custody.
 for _=1,16 do
  if node==root then return true end
  local parent,state=public(node,"GetParent")
  if state~="KNOWN" or not parent or not S:Frame(parent,false) then return false end
  node=parent
 end
 return false
end
function O:InvalidateFamily(key,reason)
 self.dirtyFamilies=self.dirtyFamilies or {}
 if key then self.dirtyFamilies[key]=true else self.fullScan=true end
 self.dirty=true;self.contentMeasureDirty=true;self.invalidationReason=reason or "NATIVE_CONTENT_CHANGED"
end
function O:MarkNativeWindowDirty(frame)
 -- Native fonts have exact change hooks. Structural callbacks invalidate the
 -- current containing family instead of eleven unrelated content models.
 local object=frame
 for _=1,16 do
  local key=self.familyRoots and self.familyRoots[object]
  if key then self:InvalidateFamily(key,"NATIVE_FAMILY_CHANGED");return true end
  if object==self.native then self:InvalidateFamily("Root","NATIVE_ROOT_CHANGED");return true end
  object=public(object,"GetParent")
  if not object or not S:Frame(object,false) then break end
 end
 self:InvalidateFamily(nil,"NATIVE_TOPOLOGY_CHANGED");return true
end
function O:WatchContent(object,method)
 L:Hook(self,object,method,function() O:MarkNativeWindowDirty(object) end)
end
function O:WatchFamilyLayout(object,key)
 -- The pinned native module finishes each real rebuild with EndLayout.
 -- Register this before any hidden-branch pruning: a currently empty family
 -- must still wake when its first objective is allocated or shown.
 self:WatchContent(object,"EndLayout")
 self:WatchContent(object,"SetCollapsed")
 self:WatchContent(object,"SetHeader")
 local hooks=self.hooks and self.hooks[object]
 local observed=hooks and hooks.EndLayout==true and hooks.generations and hooks.generations.EndLayout==self.generation
 self.familyLayoutMethods=self.familyLayoutMethods or setmetatable({},{__mode="k"})
 local method=f(object,"EndLayout")
 local registered=self.familyLayoutMethods[object]
 if registered and registered~=method then observed=false
 elseif observed then self.familyLayoutMethods[object]=method end
 if not observed then self:WatchContent(object,"Update") end
 self.layoutObservers=self.layoutObservers or {}
 self.layoutObservers[key]=observed and {object=object,generation=self.generation,method=method} or nil
end
function O:ContentEvent(key,reason)
 -- Event payloads can be unchanged cache deliveries. A source-qualified
 -- EndLayout posthook plus exact font setters already observes actual native
 -- content changes. Such a notification only requires a fresh extent read;
 -- unsupported/replaced families keep the conservative full-family scan.
 local object=_G[key]
 local observer=self.layoutObservers and self.layoutObservers[key]
 local receipt=self.familyReceipts and self.familyReceipts[key]
 if observer and observer.object==object and observer.generation==self.generation and S:Frame(object,false)
  and receipt and receipt.root==object and receipt.kind=="READY"
  and observer.method==f(object,"EndLayout") and f(object,"parentContainer")==self.native then
  self.contentMeasureDirty=true;self.healthDirty=true
  self.observedContentEvents=(self.observedContentEvents or 0)+1
 else self:InvalidateFamily(key,reason) end
end
function O:FirstContentReady()
 if not self.native or (self.scanRemaining or 0)>0 or self.modelSettlePending or self.contentMeasurePending then return false end
 if self.truncated or self.contentOverflow or (self.gaps or 0)>0 or (self.contentGaps or 0)>0 then return false end
 if self.measuredNative~=self.native then return false end
 return self:ObserveViewport()==true
end
local function dimension(owner,object,key,want)
 local getter=key=="width" and "GetWidth" or "GetHeight"
 local setter=key=="width" and "SetWidth" or "SetHeight"
 -- Explicit dimension readback does not wait for the screen rectangle cache
 -- to settle after adoption into a scroll child. Keep this local: ordinary
 -- labels elsewhere may intentionally use their computed layout dimensions.
 return L:Write(owner,object,key,function(x) return pack(x[getter](x,true)) end,
  function(x,v) return x[setter](x,v[1]) end,pack(want))
end
local function nativeLayout(object)
 local parent,state=public(object,"GetParent")
 if state~="KNOWN" then return end
 local width=public(object,"GetWidth","number",true)
 local height=public(object,"GetHeight","number",true)
 local scale=public(object,"GetScale","number")
 local count=public(object,"GetNumPoints","number")
 if not width or not height or not scale or not count or count<0 or count>8 or count%1~=0 then return end
 local layout={parent=parent,width=width,height=height,scale=scale,points={}}
 for i=1,count do
  local ok,point,relative,relativePoint,x,y=call(object,"GetPoint",i)
  if not ok or not S:Text(point) or not S:Readable(relative) or not S:Text(relativePoint) or not S:Number(x) or not S:Number(y) then return end
  layout.points[i]={point,relative,relativePoint,x,y}
 end
 return layout
end
local function sameNativeLayout(object,original)
 local current=nativeLayout(object)
 if not current or current.parent~=original.parent or #current.points~=#original.points
  or not L:GeometryEqual(current.width,original.width) or not L:GeometryEqual(current.height,original.height)
  or not L:GeometryEqual(current.scale,original.scale) then return false end
 for i,point in ipairs(current.points) do
  local before=original.points[i]
  if point[1]~=before[1] or point[2]~=before[2] or point[3]~=before[3]
   or not L:GeometryEqual(point[4],before[4]) or not L:GeometryEqual(point[5],before[5]) then return false end
 end
 return true
end
local function safeGetter(o,k,fallback)
 local v=public(o,k,"string");return v or fallback
end
local function theme(key,fallback) return M.Theme and M.Theme[key] or fallback end
function O:PaintChrome(headerHeight,collapsed)
 if not self.frame then return end
 local bg=theme("background",{.035,.035,.038,.98});local alpha=math.max(0,math.min(1,bg[4] or 1));local body=alpha*.8
 self.frame:SetBackdropColor(bg[1],bg[2],bg[3],body)
 if not self.headerBackground then
  self.headerBackground=self.frame:CreateTexture(nil,"BACKGROUND");self.owned[self.headerBackground]=true
 end
 local header=self.headerBackground
 header:ClearAllPoints();header:SetPoint("TOPLEFT",1,-1);header:SetPoint("TOPRIGHT",-1,-1)
 header:SetHeight(math.max(1,(headerHeight or self.collapsedContentHeight or 32)+(collapsed and 14 or 8)))
 -- Restore only the first line's previous composite opacity. The owned
 -- background never changes native text, buttons, clipping or contextual alpha.
 header:SetColorTexture(bg[1],bg[2],bg[3],(alpha-body)/math.max(.0001,1-body))
 self.headerOpacity=alpha;self.bodyOpacity=body
end
local function styleText(parent,size)
 local t=M.UI:Text(parent,"",0,0,size);t:ClearAllPoints();t.mirageSemanticColor=true
 t:SetJustifyH("LEFT");t:SetTextColor(.92,.95,.96,1);O.owned[t]=true
 if t.SetShadowColor then t:SetShadowColor(0,0,0,.95) end
 if t.SetShadowOffset then t:SetShadowOffset(1,-1) end
 if R.WindowKit then R.WindowKit.owned[t]=true end
 return t
end
function O:Initialize()
 if self.initialized then return true end
 if self.frame then return false,"OBJECTIVE_SETUP_RELOAD_REQUIRED" end
 if S:InCombat() or not R:Qualified() then return false,"SETUP_COMBAT_DEFERRED" end
 local frame=CreateFrame("Frame","MirageUIObjectives",UIParent,"SecureHandlerStateTemplate,BackdropTemplate");self.frame=frame;self.owned[frame]=true
 if not S:InitializeSecureHandler(frame) then return false,"OBJECTIVE_SECURE_HANDLER_UNAVAILABLE" end
 frame.MirageObjectiveFade=function(_,shown)
  local effects=M.Effects
  if not live() then return end
  local ok=O.protectedFadeReady and effects and effects.TransitionProtected and effects:TransitionProtected(O,frame,shown)
  if not ok and not S:InCombat() then
   frame:SetAlpha(public(frame,"GetAttribute","number","mirage-objective-alpha") or 1);frame:SetShown(shown)
  end
 end
 frame.MirageObjectiveStopFade=function() if M.Effects and M.Effects.StopProtected then M.Effects:StopProtected(O,frame) end end
 frame.MirageObjectiveHidden=function() if M.Effects and M.Effects.ObserveProtectedHidden then M.Effects:ObserveProtectedHidden(O,frame) end end
 frame:SetAttribute("_onstate-muiobjectives",visibilityProgram)
 self.baseSetSize=frame.SetSize;self.baseSetParent=frame.SetParent
 frame:SetSize(300,420);frame:SetClampedToScreen(true);S:Passive(frame);frame:SetAlpha(0);frame:Hide()
 frame:HookScript("OnShow",function() O:AnimateReveal() end)
 frame:HookScript("OnHide",function()
  if M.Effects and M.Effects.ObserveProtectedHidden then M.Effects:ObserveProtectedHidden(O,frame) end
 end)
 -- A solid fill gives this block four square corners at every UI scale. The
 -- shared panel art has transparent bevels and must not shape the quest list.
 frame:SetBackdrop({bgFile=L.white,edgeFile=L.white,edgeSize=1})
 frame:SetBackdropColor(unpack(theme("background",{.035,.035,.038,.98})));frame:SetBackdropBorderColor(unpack(theme("edge",{.26,.26,.26,1})))
 self:PaintChrome(32,false)
 self.topRule=frame:CreateTexture(nil,"OVERLAY");self.owned[self.topRule]=true
 self.topRule:SetColorTexture(unpack(theme("accent",{.91,.55,.18,1})));self.topRule:SetPoint("TOPLEFT",1,-1);self.topRule:SetPoint("TOPRIGHT",-1,-1);self.topRule:SetHeight(1)
 local scroll=CreateFrame("ScrollFrame",nil,frame);self.scroll=scroll;self.owned[scroll]=true
 scroll:SetPoint("TOPLEFT",10,-8);scroll:SetPoint("BOTTOMRIGHT",-18,8);scroll:EnableMouseWheel(true)
 self.emptyScrollChild=CreateFrame("Frame",nil,scroll);self.owned[self.emptyScrollChild]=true
 self.emptyScrollChild:SetSize(1,1);S:Passive(self.emptyScrollChild)
 -- The engine's tracker uses its parent height to decide how many blocks it
 -- creates. A viewport-sized parent truncates that model before scrolling can
 -- reveal it. This separate, passive content host supplies a stable extent;
 -- the visible viewport and scroll range still use actual native contents.
 self.contentHost=CreateFrame("Frame",nil,scroll);self.owned[self.contentHost]=true
 self.contentHost:SetSize(300,maximumContentHeight);S:Passive(self.contentHost)
 scroll:SetScript("OnMouseWheel",function(_,delta)
  if not live() or not S:Number(delta) then return end
  O:SetScroll((O.offset or 0)-delta*36)
  if O.surface then M.CVE:Hold(O.surface,.4) end
 end)
 scroll:SetScript("OnVerticalScroll",function() if O.active then O.scrollDirty=true end end)
 self.track=CreateFrame("Frame",nil,frame,"BackdropTemplate");self.owned[self.track]=true;S:Passive(self.track)
 self.track:SetPoint("TOPRIGHT",-8,-8);self.track:SetPoint("BOTTOMRIGHT",-8,8);self.track:SetWidth(3)
 self.track:SetBackdrop({bgFile=L.white});self.track:SetBackdropColor(unpack(theme("panel",{.060,.060,.065,.97})))
 self.thumb=self.track:CreateTexture(nil,"OVERLAY");self.owned[self.thumb]=true
 self.thumb:SetColorTexture(unpack(theme("accent",{.91,.55,.18,1})));self.thumb:SetWidth(3);self.thumb:SetHeight(24)
 local surface={id="QuestTracker.nativePosition",layoutID="QuestTracker.nativePosition",module="QuestTracker",frame=frame,
  security="SECURE_PREDECLARED",editable=true,holdOnHover=true,fallback="PRESERVE",groups={objectives=true},
  minWidth=195,minHeight=160,layout={x=.36,y=.06,width=225,height=420,scale=1},reworkProvider=self}
 self.surface=surface;M.CVE:Register(surface)
 surface.desired=nil -- the first contextual decision owns the first reveal
 if M.TrackRoot then M:TrackRoot(self.module,frame) end
 self.initialized=true
 return true
end
function O:ResolveLayout(surface,profile)
 return M.Layout:Get(surface or self.surface,profile or M.profile)
end
function O:ApplyLayout(surface,contentOnly)
 if not self.active or not live() or surface~=self.surface then return false,"NOT_SELECTED" end
 if S:InCombat() then surface.layoutPending=true;return false,"LAYOUT_COMBAT_DEFERRED" end
 local generation,profile,native=self.generation,M.profile,self.native
 local function current() return live() and self.generation==generation and M.profile==profile and self.native==native and self.surface==surface end
 local l=self:ResolveLayout(surface);local root=self.frame;local scale=l.scale or 1
 local target=l.anchorTo and M.surfaces[l.anchorTo];local relative=target and S:Frame(target.frame,false) and target.frame or UIParent
 local w,h=screen()
 if not w then surface.layoutPending=true;self.viewportPending=true;return false,"VIEWPORT_PENDING" end
 self.viewportPending=nil
 local collapsed,collapseAccess=public(self.native,"IsCollapsed","boolean")
 if collapseAccess~="KNOWN" then collapsed=self.collapsed==true end
 local expandedHeight=l.height
 local headerHeight=public(f(self.native,"Header"),"GetHeight","number")
 if not headerHeight or headerHeight<16 or headerHeight>128 then headerHeight=32 end
 -- The authored rectangle is the maximum scroll viewport. Fit the visible
 -- backdrop to the actual native list, retaining that rectangle's top edge
 -- below the XP track. The content host remains tall enough for long lists.
 local content=collapsed and headerHeight or self.measuredNative==self.native and self.contentHeight or headerHeight
 if not S:Number(content) or content<0 then content=headerHeight end
 l=M:Copy(l);l.height=math.min(expandedHeight,math.max(headerHeight,content)+16)
 l.y=l.y+(expandedHeight-l.height)*scale/(2*h)
 if not current() then return false,"LAYOUT_SUPERSEDED" end
 if contentOnly and self.layout and self.collapsed==collapsed and not self.layoutDirty
  and L:GeometryEqual(self.layout.height,l.height) and L:GeometryEqual(self.layout.width,l.width)
  and L:GeometryEqual(self.layout.x,l.x) and L:GeometryEqual(self.layout.y,l.y)
  and L:GeometryEqual(self.layout.scale or 1,scale) then return true end
 if not current() then return false,"LAYOUT_SUPERSEDED" end
 root:SetSize(l.width,l.height);if not current() then return false,"LAYOUT_SUPERSEDED" end
 root:SetScale(scale);if not current() then return false,"LAYOUT_SUPERSEDED" end
 root:ClearAllPoints();if not current() then return false,"LAYOUT_SUPERSEDED" end
 root:SetPoint("CENTER",relative,"CENTER",l.x*w/scale,l.y*h/scale)
 if not current() then return false,"LAYOUT_SUPERSEDED" end
 local wasCollapsed=self.collapsed
 self.layout=l;self.expandedHeight=expandedHeight;self.collapsed=collapsed;self.collapsedContentHeight=headerHeight;surface.layoutPending=nil
 local warning=R.DurabilityDisplay
 if warning and warning.frame and warning.provider and warning.provider.active then
  local okay,applied=pcall(warning.ApplyLayout,warning)
  if not okay or applied==false then warning.layoutDirty=true end
 end
 if not current() then return false,"LAYOUT_SUPERSEDED" end
 self:PaintChrome(headerHeight,collapsed)
 local scrollInset=18
 self.contentWidth=math.max(134,l.width-10-scrollInset)
 self.scroll:ClearAllPoints();self.scroll:SetPoint("TOPLEFT",10,-8);self.scroll:SetPoint("BOTTOMRIGHT",-scrollInset,8)
 self.track:ClearAllPoints();self.track:SetPoint("TOPRIGHT",-8,-8);self.track:SetPoint("BOTTOMRIGHT",-8,8)
 if collapsed then self.track:Hide() end
 if self.native and not contentOnly then
  local width=self.contentWidth
  self.contentHost:SetSize(width,maximumContentHeight)
  self.writing=true
  -- Native UpdateHeight now agrees with the content host (default placement)
  -- and its leased editModeHeight (custom placement). Do not fight it on each
  -- ordinary native update or reconfigure the visible viewport to this height.
  local good=dimension(self,self.native,"width",width)
  good=L:Scalar(self,self.native,"scale","GetScale","SetScale",1) and good
  good=L:Points(self,self.native,pack("TOPLEFT",self.contentHost,"TOPLEFT",0,0)) and good
  for _,name in ipairs(families) do
   local module=_G[name]
   if S:Frame(module,false) and f(module,"parentContainer")==self.native then
    good=dimension(self,module,"width",width) and good
    local header=f(module,"Header")
    if header then dimension(self,header,"width",width) end
    local text=f(header,"Text");if text then dimension(self,text,"width",math.max(70,width-44)) end
    if header then self:AlignCollapseControl(header) end
    if not current() then self.writing=nil;return false,"LAYOUT_SUPERSEDED" end
   end
  end
  local header=f(self.native,"Header")
  if header then dimension(self,header,"width",width) end
  local text=f(header,"Text");if text then dimension(self,text,"width",math.max(70,width-44)) end
  if header then self:AlignCollapseControl(header) end
  if not current() then self.writing=nil;return false,"LAYOUT_SUPERSEDED" end
  self.writing=nil
  if not good then return false,"TRACKER_LAYOUT_PENDING" end
 end
 if collapsed~=wasCollapsed then
  if collapsed then
   self.expandedScrollOffset=self.offset or 0;self.contentHeight=headerHeight;self.scrollPending=0
  else
   self.scrollPending=self.expandedScrollOffset or 0;self.expandedScrollOffset=nil
  end
 end
 return true
end
function O:ContentEnvelope(frame)
 if not self.contentHost or S:InCombat() then return false,"TRACKER_CONTENT_EXTENT_DEFERRED" end
 local value,state=S:FieldAccess(frame,"editModeHeight")
 if state~="ABSENT" and (state~="KNOWN" or value~=nil and not S:Number(value)) then return false,"TRACKER_CONTENT_EXTENT_UNAVAILABLE" end
 self.writing=true
 -- This is the exact frame-local field read by the reviewed native
 -- UpdateHeight custom-placement branch. It does not edit a saved layout or
 -- replace a native function. Nil is captured and restored as nil.
 local ok=L:Write(self,frame,"objectiveContentHeight",function(object)
  local height,known=S:FieldAccess(object,"editModeHeight")
  assert(known=="ABSENT" or known=="KNOWN" and (height==nil or S:Number(height)),"OBJECTIVE_HEIGHT_UNREADABLE")
  return pack(height)
 end,function(object,values) object.editModeHeight=values[1] end,pack(maximumContentHeight))
 ok=dimension(self,frame,"height",maximumContentHeight) and ok
 self.writing=nil
 if not ok then return false,"TRACKER_CONTENT_EXTENT_PENDING" end
 -- The engine stores geometry in scaled native floats. Keep the observed
 -- value and use the shared geometry comparison on later native refreshes.
 self.nativeHeight=public(frame,"GetHeight","number",true)
 return true
end
function O:DetachNativeManager(frame)
 local manager,state=S:FieldAccess(frame,"layoutParent")
 if state=="ABSENT" then self.managerState="UNMANAGED";return true end
 if state~="KNOWN" or manager~=_G.RightManagedFrameContainer or not S:Frame(manager,false)
  or type(f(manager,"AddManagedFrame"))~="function" or type(f(manager,"RemoveManagedFrame"))~="function" then
  return false,"TRACKER_NATIVE_MANAGER_UNAVAILABLE"
 end
 local members,known=S:FieldAccess(manager,"showingFrames")
 if known~="KNOWN" or type(members)~="table" then return false,"TRACKER_NATIVE_MANAGER_UNAVAILABLE" end
 local member,memberState=S:FieldAccess(members,frame)
 if memberState~="ABSENT" and (memberState~="KNOWN" or member~=frame) then return false,"TRACKER_NATIVE_MANAGER_UNAVAILABLE" end
 if self.nativeManager and self.nativeManager~=manager then return false,"TRACKER_NATIVE_MANAGER_CHANGED" end
 self.nativeManager=manager
 local registered=member==frame
 local originallyShown=public(frame,"IsShown","boolean")
 if originallyShown==nil then return false,"TRACKER_NATIVE_VISIBILITY_UNAVAILABLE" end
 local originalLayout=nativeLayout(frame)
 if not originalLayout then return false,"TRACKER_NATIVE_LAYOUT_UNAVAILABLE" end
 -- This native opt-out is checked by AddManagedFrame. Removing the existing
 -- registration is also necessary: UpdateManagedFrames walks its retained set
 -- without checking the flag, and would otherwise reparent the scroll child.
 -- The flag receipt owns the inverse. On release, native registration is
 -- restored through its own method if it originally existed or previously
 -- empty content became visible. Native eligibility still decides whether to
 -- register; an intervening writer of the flag is never overwritten. The
 -- manager's registration call itself rewrites geometry, so it is legal only
 -- if earlier property inverses restored the original parent/anchors/size.
 -- A newer layout writer must survive even when it never changed this flag.
 local ok=L:Write(self,frame,"objectiveManagedPosition",function(object)
  assert(f(object,"layoutParent")==manager,"OBJECTIVE_MANAGER_CHANGED")
  local value,access=S:FieldAccess(object,"ignoreFramePositionManager")
  assert(access=="ABSENT" or access=="KNOWN" and type(value)=="boolean","OBJECTIVE_MANAGER_FLAG_UNREADABLE")
  return pack(value)
 end,function(object,values)
  assert(f(object,"layoutParent")==manager,"OBJECTIVE_MANAGER_CHANGED")
  object.ignoreFramePositionManager=values[1]
  if values[1]==true then manager:RemoveManagedFrame(object)
  elseif (registered or originallyShown==false) and sameNativeLayout(object,originalLayout) then manager:AddManagedFrame(object) end
 end,pack(true))
 if not ok then return false,"TRACKER_NATIVE_MANAGER_PENDING" end
 local current,access=S:FieldAccess(members,frame)
 if access~="ABSENT" then return false,"TRACKER_NATIVE_MANAGER_STILL_REGISTERED" end
 self.managerState="DETACHED"
 return true
end
function O:ViewportReceipt(status)
 if self.viewportStatus~=status then self.viewportStatus=status;self.healthDirty=true end
 if status~="CONFIRMED" and self.acquired and self.active then self.viewportDirty=true end
 return status=="CONFIRMED",status
end
function O:ObserveViewport()
 -- SetScrollChild/SetVerticalScroll acceptance proves neither clipping nor
 -- the current render hierarchy. Native ObjectiveTrackerFrame is explicitly
 -- LOW in both reviewed XMLs. Keep its input and native strata untouched;
 -- the owned viewport joins that layer and supplies its own clip boundary.
 if not self.scroll or not self.contentHost or not self.native then return self:ViewportReceipt("OBJECTIVE_VIEWPORT_UNAVAILABLE") end
 local child,childState=public(self.scroll,"GetScrollChild")
 if childState~="KNOWN" or child~=self.contentHost then return self:ViewportReceipt("OBJECTIVE_SCROLL_CHILD_CHANGED") end
 local clip,clipState=public(self.scroll,"DoesClipChildren","boolean")
 if clipState~="KNOWN" or clip~=true then return self:ViewportReceipt("OBJECTIVE_VIEWPORT_CLIP_UNCONFIRMED") end
 local strata=public(self.native,"GetFrameStrata","string")
 if not strata or not frameStrata[strata] then return self:ViewportReceipt("OBJECTIVE_VIEWPORT_LAYER_UNAVAILABLE") end
 for _,object in ipairs({self.frame,self.scroll,self.contentHost}) do
  if public(object,"GetFrameStrata","string")~=strata then return self:ViewportReceipt("OBJECTIVE_VIEWPORT_LAYER_CHANGED") end
 end
 if public(self.contentHost,"GetParent")~=self.scroll or public(self.native,"GetParent")~=self.contentHost then
  return self:ViewportReceipt("OBJECTIVE_VIEWPORT_PARENT_CHANGED")
 end
 return self:ViewportReceipt("CONFIRMED")
end
function O:BindViewport(frame)
 if S:InCombat() then return false,"OBJECTIVE_VIEWPORT_COMBAT_DEFERRED" end
 local strata=public(frame,"GetFrameStrata","string")
 if not strata or not frameStrata[strata] then return self:ViewportReceipt("OBJECTIVE_VIEWPORT_LAYER_UNAVAILABLE") end
 self.writing=true
 local good=true
 for _,object in ipairs({self.frame,self.scroll,self.contentHost,self.emptyScrollChild}) do
  if public(object,"GetFrameStrata","string")~=strata then
   local written,result=call(object,"SetFrameStrata",strata)
   good=written and result~=false and public(object,"GetFrameStrata","string")==strata and good
  end
 end
 -- This boundary is separate from native module/block slide clipping, which
 -- the native EndSlide method legitimately disables. The exact viewport
 -- rectangle follows the visible list; its height is never the content envelope.
 local written,result=call(self.scroll,"SetClipsChildren",true)
 good=written and result~=false and public(self.scroll,"DoesClipChildren","boolean")==true and good
 if good then
  written,result=call(self.scroll,"SetScrollChild",self.contentHost)
  good=written and result~=false and public(self.scroll,"GetScrollChild")==self.contentHost
 end
 self.writing=nil
 if not good then return self:ViewportReceipt("OBJECTIVE_VIEWPORT_BIND_UNCONFIRMED") end
 self.viewportNativeStrata=strata
 return true
end
function O:SettleStartupLayer()
 -- Adoption is not finished until native OnShow, layout and visibility have
 -- run. They may invalidate an owned layer after BindViewport's first
 -- receipt. Repair only our three objects once at the end of Configure;
 -- never write the native layer or reassert revoked clip/child custody.
 -- Runtime changes continue to use the strict handback path in Tick.
 local matched,why=self:ObserveViewport()
 if matched or why~="OBJECTIVE_VIEWPORT_LAYER_CHANGED" then return matched,why end
 local strata=public(self.native,"GetFrameStrata","string")
 if strata~=self.viewportNativeStrata or not frameStrata[strata]
  or public(self.scroll,"DoesClipChildren","boolean")~=true
  or public(self.scroll,"GetScrollChild")~=self.contentHost
  or public(self.contentHost,"GetParent")~=self.scroll
  or public(self.native,"GetParent")~=self.contentHost then return false,why end
 self.startupLayerPasses=(self.startupLayerPasses or 0)+1
 self.writing=true
 for _,object in ipairs({self.frame,self.scroll,self.contentHost}) do
  if public(object,"GetFrameStrata","string")~=strata then call(object,"SetFrameStrata",strata) end
 end
 self.writing=nil
 return self:ObserveViewport()
end
function O:Acquire(frame)
 if self.native==frame and self.acquired then
  if public(frame,"GetParent")~=self.contentHost then return false,"TRACKER_CUSTODY_CHANGED" end
  return self:ObserveViewport()
 end
 if self.native and self.native~=frame then return false,"TRACKER_ROOT_REPLACED" end
 if S:InCombat() or not S:Frame(frame,false) then return false,"TRACKER_ACQUIRE_DEFERRED" end
 if not self.native then self.origin=M.Elements and M.Elements:Measure(frame) end
 self.native=frame
 local bound,boundWhy=self:BindViewport(frame)
 if not bound then return false,boundWhy end
 local detached,managerWhy=self:DetachNativeManager(frame)
 if not detached then return false,managerWhy end
 -- EditModeSystemTemplate is clampedToScreen=true in both reviewed builds.
 -- A tall scroll child must not be independently pushed back onto the screen;
 -- only the visible Mirage viewport retains screen clamping.
 if not L:Scalar(self,frame,"objectiveScreenClamp","IsClampedToScreen","SetClampedToScreen",false) then
  return false,"TRACKER_CONTENT_CLAMP_PENDING"
 end
 -- Setting a ScrollChild is an explicit OOC adoption. Capture the original
 -- parent before calling it so partial writes remain recoverable.
 local parent=public(frame,"GetParent")
 if not parent then self.native=nil;return false,"TRACKER_PARENT_UNAVAILABLE" end
 local ok=L:Write(self,frame,"parent",function(x) return pack(x:GetParent()) end,function(x,v)
  self.baseSetParent(x,v[1])
 end,pack(self.contentHost))
 if not ok then return false,"TRACKER_PARENT_PENDING" end
 local envelope,extentWhy=self:ContentEnvelope(frame)
 if not envelope then return false,extentWhy end
 local observed,viewportWhy=self:ObserveViewport()
 if not observed then return false,viewportWhy end
 local function viewportChanged() O.viewportDirty=true;O.healthDirty=true end
 for _,object in ipairs({self.frame,self.scroll,self.contentHost,frame}) do L:Hook(self,object,"SetFrameStrata",viewportChanged) end
 for _,method in ipairs({"SetClipsChildren","SetScrollChild"}) do L:Hook(self,self.scroll,method,viewportChanged) end
 L:Hook(self,frame,"Update",function()
  -- The native container has finished sorting and anchoring every module at
  -- this point. Fit once from that completed model before the next render;
  -- this does not call native Update again or rewrite native widths.
  if O.native~=frame then return end
  local generation,profile=O.generation,M.profile
  O:MeasureContent()
  if O.active and O.native==frame and O.generation==generation and M.profile==profile then
   -- Family Update/EndLayout hooks and exact font hooks carry changed data.
   -- The container publishes finished geometry, not a whole-tree repaint.
   O.contentMeasureDirty=true;O.healthDirty=true;O:RequestModelSettle("NATIVE_MODEL_UPDATED")
  end
 end)
 L:Hook(self,frame,"SetCollapsed",function()
  local collapsed,access=public(frame,"IsCollapsed","boolean")
  if access=="KNOWN" and collapsed~=O.collapsed then O.layoutDirty=true;O:InvalidateFamily("Root","COLLAPSE_CHANGED") end
 end)
 L:Hook(self,frame,"SetHeight",function()
  local height,state=public(frame,"GetHeight","number",true)
  if state~="KNOWN" or not L:GeometryEqual(height,O.nativeHeight) then O.nativeHeight=height;O.contentMeasureDirty=true;O.healthDirty=true end
 end)
 if not self.geometryHooks[frame] and type(hooksecurefunc)=="function" then
  self.geometryHooks[frame]=true
  for _,method in ipairs({"SetWidth","SetSize","SetPoint","ClearAllPoints","SetScale","SetParent"}) do
   if type(f(frame,method))=="function" then pcall(hooksecurefunc,frame,method,function()
    if O.active and O.native==frame and not O.writing and not O.painting and (O.leaseWriteDepth or 0)==0 then O.geometryDirty=true;O.dirty=true end
   end) end
  end
 end
 local manager=_G.ObjectiveTrackerManager
 if manager then
  for _,method in ipairs({"AcquireFrame","ReleaseFrame","ShowRewardsToast","HideRewardsToast"}) do
   L:Hook(self,manager,method,function() O:InvalidateFamily(nil,"TRACKER_TOPOLOGY_CHANGED") end)
  end
  L:Hook(self,manager,"UpdateAll",function() O.contentMeasureDirty=true;O.healthDirty=true end)
 end
 self.acquired=true
 return true
end
function O:ScrollGeometry()
 local viewport=public(self.scroll,"GetHeight","number")
 if not viewport or viewport<=0 then viewport=math.max(1,(self.layout and self.layout.height or 420)-16) end
 local range=math.max(0,(self.contentHeight or 0)-viewport)
 return viewport,range
end
function O:ScrollReceipt(status)
 if self.scrollStatus~=status then self.scrollStatus=status;self.healthDirty=true end
end
function O:ObserveScroll(requested)
 if not self.scroll then return false end
 local offset,state=public(self.scroll,"GetVerticalScroll","number")
 if state~="KNOWN" then self:ScrollReceipt("OBJECTIVE_SCROLL_READBACK_UNAVAILABLE");return false end
 local viewport,range=self:ScrollGeometry()
 self.offset=offset;self.scrollRange=range;self.viewportHeight=viewport;self.scrollDirty=nil
 local status=requested and not L:GeometryEqual(offset,requested) and "OBJECTIVE_SCROLL_WRITE_UNCONFIRMED" or "CONFIRMED"
 if offset<0 or offset>range and not L:GeometryEqual(offset,range) then
  local correction=math.max(0,math.min(range,offset))
  if requested and L:GeometryEqual(correction,requested) then
   -- The current request already tried this correction. Keep a truthful
   -- partial receipt instead of retrying the same ignored writer every tick.
   status="OBJECTIVE_SCROLL_WRITE_UNCONFIRMED";self.scrollPending=nil
  else status="OBJECTIVE_SCROLL_RANGE_CHANGED";self.scrollPending=correction end
 end
 self:ScrollReceipt(status)
 local trackHeight=public(self.track,"GetHeight","number")
 if not trackHeight or trackHeight<=0 then trackHeight=math.max(1,viewport-45) end
 local thumbHeight=math.min(trackHeight,math.max(18,trackHeight*math.min(1,viewport/math.max(1,self.contentHeight or 1))))
 if not S:InCombat() then
  self.thumb:SetHeight(thumbHeight);self.thumb:ClearAllPoints()
  self.thumb:SetPoint("TOP",self.track,"TOP",0,-(range>0 and (trackHeight-thumbHeight)*math.max(0,math.min(1,offset/range)) or 0))
  self.track:SetShown(not self.collapsed and range>0)
 end
 return self.scrollStatus=="CONFIRMED"
end
function O:SetScroll(value)
 if not live() or not self.scroll or not S:Number(value) then return false end
 -- The scroll parent may inherit protection from a quest item. Retain the last
 -- legal viewport in combat instead of moving a protected descendant.
 if S:InCombat() and not S:Frame(self.scroll,true) then self.scrollPending=value;return false end
 local _,range=self:ScrollGeometry()
 local requested=math.max(0,math.min(range,value))
 local written,result=call(self.scroll,"SetVerticalScroll",requested)
 if not written or result==false then
  -- A setter can reject after a partial write. Reflect its public position,
  -- but never certify rejection or turn it into a repeating repair job.
  self:ObserveScroll();self.scrollPending=nil;self:ScrollReceipt("OBJECTIVE_SCROLL_WRITE_FAILED");return false
 end
 return self:ObserveScroll(requested)
end
function O:AnimateReveal()
 if self.setupQuiet then return false end
 -- A hidden native subtree may publish its computed rectangle only when its
 -- parent first becomes visible. Renew only previously observed truncation
 -- debt; the ordinary reveal path never rebuilds a healthy native model.
 if live() and not S:InCombat() then self:RequestModelSettle("FIRST_VISIBLE_RECTANGLE") end
 local effects=M.Effects
 if not live() or not self.protectedFadeReady or not effects or not effects.TransitionProtected then return false end
 local state=public(self.frame,"GetAttribute","string","state-muiobjectives")
 if state=="show" then
  return effects:TransitionProtected(self,self.frame,true)
 end
 if effects.StopProtected then effects:StopProtected(self,self.frame) end
 return false
end
function O:Visibility()
 if not live() or not self.frame or not self.surface then return false,"OBJECTIVE_NOT_ACTIVE" end
 if self.surface.desired==nil then return true,"CONTEXT_DECISION_PENDING" end
 if S:InCombat() then
  -- Native quest-item click controls use a predeclared combat driver. The
  -- reviewed client has no movement macro condition: do not pretend a cosmetic
  -- alpha-zero request safely hid those protected hit regions in combat.
  self.visibilityBoundary=M.PresentationGroups and M.PresentationGroups:Enabled() and "PREDECLARED_COMBAT_CONCEAL" or "NATIVE_COMBAT_ACCESS_FLOOR"
  if self.surface then self.surface.nativeBoundary=self.visibilityBoundary end
  self.visibilityDesired=self.surface.desired;self.visibilityCombat=true
  return true,self.visibilityBoundary
 end
 self.visibilityBoundary=nil;if self.surface then self.surface.nativeBoundary=nil end
 if type(RegisterStateDriver)~="function" or type(UnregisterStateDriver)~="function" then return false,"OBJECTIVE_VISIBILITY_UNAVAILABLE" end
 local effects=M.Effects
 local cfg=M:ModuleConfig(self.module)
 local alpha=cfg and S:Number(cfg.alpha) and math.max(0,math.min(1,cfg.alpha)) or 1
 self.protectedFadeReady=false
 if effects and effects.PrepareProtected then
  local generation,profile,native=self.generation,M.profile,self.native
  local prepared=effects:PrepareProtected(self,self.frame,function()
   return live() and O.generation==generation and M.profile==profile and O.native==native
  end,alpha)
  self.protectedFadeReady=prepared==true
  if prepared and public(self.frame,"IsShown","boolean")==false and effects.ObserveProtectedHidden then
   effects:ObserveProtectedHidden(self,self.frame)
  end
 end
 local desired=self.surface.desired
 local tail=desired=="HIDDEN" and "hide" or desired=="AMBIENT" and "ambient" or "show"
 self.contextHover=self.surface.localHover==true or desired=="HIDDEN" and self.contextHover==true
 if M.PresentationGroups and M.PresentationGroups:Enabled() and M.PresentationGroups:Demand("TRACKER")==true then self.contextHover=false end
 local combat=M.ElementRules and M.ElementRules:Preference(self.surface.id,"Combat")
 if tail=="hide" and self.protectedFadeReady then tail="quiet" end
 local combatHidden=combat=="HIDE" or M.PresentationGroups and M.PresentationGroups:Enabled()
 local expression="[petbattle] hide; [combat] "..(combatHidden and "hide" or "show").."; "..tail
 if self.initialPresentationPending then
  -- The first bounded local paint may take several dispatches. Keep this
  -- one surface hidden until it has real content and current geometry; there
  -- is no global mask or dependency on another provider finishing first.
  expression="hide";tail="hide"
 end
 if self.visibilityExpression~=expression or self.visibilityAlpha~=alpha then
  self.visibilityAttempt=true
  local ok=pcall(function()
   self.frame:SetAttribute("mirage-objective-alpha",alpha)
   RegisterStateDriver(self.frame,"muiobjectives",expression)
  end)
  if not ok then return false,"OBJECTIVE_VISIBILITY_PENDING" end
  self.visibilityExpression=expression;self.visibilityAlpha=alpha;self.visibilityAttempt=nil
 end
 -- Update immediately outside combat too: a changed opacity does not cause
 -- the secure state expression itself to transition. Read only our own state.
 local state=public(self.frame,"GetAttribute","string","state-muiobjectives") or tail
 local a=alpha*(state=="ambient" and .25 or 1)
 local animated=false
 if state=="quiet" and self.protectedFadeReady and effects and effects.TransitionProtected then
  -- A quiet driver leaves the frame visible only for the finite conceal. Its
  -- animation finish hides the protected descendants outside combat.
  animated=effects:TransitionProtected(self,self.frame,false)
 elseif state=="show" and self.protectedFadeReady and effects and effects.TransitionProtected then
  animated=effects:TransitionProtected(self,self.frame,true)
 end
 if not animated then
  if effects and effects.StopProtected then effects:StopProtected(self,self.frame) end
  if public(self.frame,"GetAlpha","number")~=a then call(self.frame,"SetAlpha",a) end
  local shown=state~="hide" and state~="quiet"
  if public(self.frame,"IsShown","boolean")~=shown then call(self.frame,"SetShown",shown) end
 end
 self.surface.actual="SECURE_NATIVE";self.surface.appliedReason="SECURE_DRIVER_OWNS_VISIBILITY"
 self.visibilityDesired=self.surface.desired;self.visibilityCombat=false
 return true
end
local function channel(value)
 value=math.max(0,math.min(1,value))
 return value<=.04045 and value/12.92 or ((value+.055)/1.055)^2.4
end
local function luminance(r,g,b) return .2126*channel(r)+.7152*channel(g)+.0722*channel(b) end
function O:ReadableColor(r,g,b)
 if not S:Number(r) or not S:Number(g) or not S:Number(b) then return .92,.95,.96 end
 r,g,b=math.max(0,math.min(1,r)),math.max(0,math.min(1,g)),math.max(0,math.min(1,b))
 -- Keep the native semantic hue. Lift only low-contrast colors toward white;
 -- the reference background includes the brightest world behind our 88% fill.
 local background=luminance(.018*.88+.12,.025*.88+.12,.032*.88+.12)
 if (luminance(r,g,b)+.05)/(background+.05)>=5 then return r,g,b end
 local low,high=0,1
 for _=1,10 do
  local mix=(low+high)/2
  if (luminance(r+(1-r)*mix,g+(1-g)*mix,b+(1-b)*mix)+.05)/(background+.05)>=5 then high=mix else low=mix end
 end
 return r+(1-r)*high,g+(1-g)*high,b+(1-b)*high
end
function O:ReadableText(text)
 -- Quest labels remain text-only. Strip the two native inline image forms,
 -- preserving escaped pipes, hyperlinks, literal punctuation and numbers.
 -- This is reached only after the existing public-string qualification.
 text=text:gsub("(|+)([TA])([^|]-)|([ta])",function(pipes,open,payload,close)
  if #pipes%2==1 and open:lower()==close then return pipes:sub(1,#pipes-1) end
  return pipes..open..payload.."|"..close
 end)
 return text:gsub("(|+)([cC])(%x%x)(%x%x)(%x%x)(%x%x)",function(pipes,marker,a,r,g,b)
  if #pipes%2==0 then return pipes..marker..a..r..g..b end
  local rr,gg,bb=self:ReadableColor(tonumber(r,16)/255,tonumber(g,16)/255,tonumber(b,16)/255)
  return pipes..marker..a..string.format("%02x%02x%02x",math.ceil(rr*255),math.ceil(gg*255),math.ceil(bb*255))
 end)
end
-- Resolve horizontal constraints within the tracker itself. Reading GetLeft
-- immediately after native layout can return last frame's rectangle and make
-- repeated indentation repairs drift. Anchor constraints are current even
-- while a scroll child is hidden or moving; vertical anchors are left intact.
local pointFactor={TOPLEFT=0,LEFT=0,BOTTOMLEFT=0,TOP=.5,CENTER=.5,BOTTOM=.5,TOPRIGHT=1,RIGHT=1,BOTTOMRIGHT=1}
local function contentLeft(object,root,seen,depth,current)
 if current and not current() then return nil end
 if object==root then return 0 end
 if not S:Frame(object,false) or (depth or 0)>20 then return nil end
 seen=seen or {};if seen[object] then return nil end;seen[object]=true
 local count=public(object,"GetNumPoints","number")
 if current and not current() then seen[object]=nil;return nil end
 if not count or count<1 or count>8 then seen[object]=nil;return nil end
 -- Prefer a left edge: it does not depend on a text width or wrapping cache.
 for wanted=0,2 do
  for i=1,count do
   local ok,point,relative,relativePoint,x=call(object,"GetPoint",i)
   if current and not current() then seen[object]=nil;return nil end
   local factor=ok and pointFactor[point]
   if factor~=nil and factor*2==wanted and S:Number(x) then
    if type(relative)=="string" then relative=_G[relative] end
    relative=relative or public(object,"GetParent")
    local rf=pointFactor[relativePoint or point]
    local origin=rf~=nil and contentLeft(relative,root,seen,(depth or 0)+1,current)
    local ownWidth=factor==0 and 0 or public(object,"GetWidth","number",true)
    local relativeWidth=rf==0 and 0 or public(relative,"GetWidth","number",true)
    if current and not current() then seen[object]=nil;return nil end
    if origin and ownWidth and relativeWidth then
     seen[object]=nil;return origin+relativeWidth*rf+x-ownWidth*factor
    end
   end
  end
 end
 seen[object]=nil
end
function O:AlignCollapseControl(header)
 local native,generation,profile=self.native,self.generation,M.profile
 local control=f(header,"MinimizeButton")
 local parent=control and public(control,"GetParent")
 local function current()
  if self.native~=native or self.generation~=generation or M.profile~=profile or not live() or S:InCombat() then return false end
  return f(header,"MinimizeButton")==control and public(control,"GetParent")==parent
   and self.native==native and self.generation==generation and M.profile==profile
 end
 if not native or not parent or not current() or not within(header,native) then return false end
 local left=contentLeft(control,header,nil,nil,current)
 local width=public(control,"GetWidth","number",true)
 local headerWidth=public(header,"GetWidth","number",true)
 if not current() or not left or not width or width<=0 or not headerWidth then return false end
 -- Inset the native button itself. Its hit rectangle, glyph panel and child
 -- anchors move together; an artwork-only nudge leaves a misleading click area.
 local delta=headerWidth-width-6-left
 if math.abs(delta)>.01 then
  if math.abs(delta)>96 then return false end
  local count=public(control,"GetNumPoints","number");local points={n=0}
  if not current() or not count or count<1 or count>8 then return false end
  for i=1,count do
   local ok,point,relative,relativePoint,x,y=call(control,"GetPoint",i)
   if not current() or not ok or not S:Text(point) or not S:Readable(relative) or not S:Text(relativePoint) or not S:Number(x) or not S:Number(y) then return false end
   local tuple=pack(point,relative,relativePoint,x+delta,y)
   for j=1,5 do points.n=points.n+1;points[points.n]=tuple[j] end
  end
  if not current() or not L:Points(self,control,points) or not current() then return false end
 end
 for _,method in ipairs({"SetPoint","SetAllPoints","ClearAllPoints"}) do if current() then L:Hook(self,control,method) end end
 return current()
end
function O:AlignContentText(source)
 local native,generation,profile=self.native,self.generation,M.profile
 local function retained()
  return self.active and not M.state.safe and self.native==native and self.generation==generation and M.profile==profile
 end
 if not native or not retained() or S:InCombat() or not retained() then return false end
 local parent=public(source,"GetParent")
 local function current()
  if not retained() then return false end
  local actual,state=public(source,"GetParent")
  return state=="KNOWN" and actual==parent and live() and not S:InCombat() and retained()
 end
 -- Anchor/parent getters may run native layout or profile callbacks. The
 -- lease seals its own entry, so retain this earlier measurement's owner too.
 if not parent or not current() or (f(parent,"HeaderText")~=source and f(parent,"Text")~=source) then return false end
 local reference=f(f(native,"Header"),"Text")
 if not reference then
  for _,name in ipairs(families) do reference=f(f(_G[name],"Header"),"Text");if reference then break end end
 end
 if not current() or not reference or reference==source or parent==f(native,"Header") then return false end
 for _,name in ipairs(families) do if parent==f(_G[name],"Header") then return false end end
 -- Specialized progress/timer/widget labels keep their own local geometry.
 if f(parent,"SetPercent") or f(parent,"OnUpdate") or self.widgetContainers and self.widgetContainers[parent] then return false end
 -- An objective's dash and text are one native line. Move that line's
 -- leading edge, preserving its dash-to-text spacing and native click region.
 -- Quest titles use HeaderText; their HeaderButton follows that FontString.
 local aligned=f(parent,"Text")==source and f(parent,"Dash") and parent or source
 if not current() then return false end
 -- Recursive reads only need the cheap identity seal; validate source
 -- parentage and legal ownership again before admitting any geometry write.
 local desired,position=contentLeft(reference,native,nil,nil,retained),contentLeft(aligned,native,nil,nil,retained)
 if not current() or not desired or not position then return false end
 local delta=desired-position
 if math.abs(delta)>.01 and math.abs(delta)<=96 then
  local count=public(aligned,"GetNumPoints","number");local points={n=0}
  if not count or count<1 or count>8 then return false end
  for i=1,count do
   local ok,point,relative,relativePoint,x,y=call(aligned,"GetPoint",i)
   if not current() or not ok or not S:Text(point) or not S:Readable(relative) or not S:Text(relativePoint) or not S:Number(x) or not S:Number(y) then return false end
   local tuple=pack(point,relative,relativePoint,x+delta,y)
   for j=1,5 do points.n=points.n+1;points[points.n]=tuple[j] end
  end
  if not current() or not L:Points(self,aligned,points) or not current() then return false end
  self.alignedContentCount=(self.alignedContentCount or 0)+1
 end
 for _,method in ipairs({"SetPoint","SetAllPoints","ClearAllPoints"}) do
  if not current() then return false end
  L:Hook(self,aligned,method)
 end
 return current()
end
function O:MirrorFont(source,nativeText)
 if self.owned[source] or (R.WindowKit and R.WindowKit.owned[source]) or not S:Frame(source,false) then return end
 if not nativeText then self:AlignContentText(source) end
 local row=self.mirrors[source]
 if nativeText then
  if row then
   row.nativeText=true;row.mirror:Hide()
   self.writing=true;L:Alpha(self,source,row.opacity or 1);self.writing=nil
  end
  return -- animation/widget-owned labels keep their permitted engine channel.
 end
 if not row then
  if S:InCombat() then self.combatPending=true;return end
  if (self.mirrorCount or 0)>=2048 then self.contentOverflow=true;return L:Gap(self) end
  local parent=public(source,"GetParent")
  if not S:Frame(parent,false) or type(f(parent,"CreateFontString"))~="function" then return end
  local text,state=public(source,"GetText","string")
  if state=="RESTRICTED" then return end -- keep the engine's supported restricted channel.
  local alpha=public(source,"GetAlpha","number");if alpha==nil then return L:Gap(self) end
  local mirror=styleText(parent,12);mirror.mirageManualFont=true;mirror:SetAllPoints(source)
  row={source=source,mirror=mirror,opacity=alpha,dirty=true};self.mirrors[source]=row;self.mirrorCount=(self.mirrorCount or 0)+1
  if type(hooksecurefunc)=="function" and not self.fontHooks[source] then
   self.fontHooks[source]=true
   for _,method in ipairs({"SetText","SetFormattedText","SetTextColor","Show","Hide","SetShown","SetFont","SetFontObject","SetJustifyH","SetJustifyV","SetMaxLines","SetSpacing","SetWordWrap","SetNonSpaceWrap"}) do
    if type(f(source,method))=="function" then pcall(hooksecurefunc,source,method,function() if O.active then local r=O.mirrors[source];if r then r.dirty=true;O.dirtyFonts[source]=true end end end) end
   end
   if type(f(source,"SetAlpha"))=="function" then pcall(hooksecurefunc,source,"SetAlpha",function(_,a)
    if O.active and not O.writing and not O.painting and (O.leaseWriteDepth or 0)==0 and S:Number(a) then local r=O.mirrors[source];if r then r.opacity=a;r.dirty=true;r.suppressionDirty=true;O.dirtyFonts[source]=true end end
   end) end
  end
 end
 if row.generation~=self.generation then row.opacity=public(source,"GetAlpha","number") or row.opacity;row.generation=self.generation end
 row.nativeText=nil
 self.writing=true;local captured=L:Alpha(self,source,0);self.writing=nil
 if not captured then return L:Gap(self) end
 row.dirty=true;self.dirtyFonts[source]=true
 -- A new mirror's native label is suppressed above. Paint its public content
 -- in this same chunk, so a yield never leaves an empty replacement on screen.
 if self:PaintText(source,row) then self.dirtyFonts[source]=nil end
end
function O:HeaderColor(source)
 -- Use the native header identities rather than English strings. Quest
 -- titles, objective difficulty colors and localized labels keep their own
 -- semantic colors; only these two hierarchy levels take the suite palette.
 if source==f(f(self.native,"Header"),"Text") then return theme("accent",{.91,.55,.18,1}) end
 local quests=_G.QuestObjectiveTracker
 if quests and f(quests,"parentContainer")==self.native and source==f(f(quests,"Header"),"Text") then
  return theme("secondary",{.96,.79,.36,1})
 end
end
function O:PaintText(source,row)
 local profile,generation,native=M.profile,self.generation,self.native
 local mirror=row.mirror;local combat=S:InCombat()
 row.paintSerial=(row.paintSerial or 0)+1;local serial=row.paintSerial
 local transaction={}
 local function retained()
  return self.active and not M.state.safe and M.profile==profile and self.generation==generation
   and self.native==native and self.mirrors[source]==row and row.mirror==mirror and row.paintSerial==serial
 end
 local function current() return retained() and S:InCombat()==combat end
 local function ensure() if not current() then error(transaction,0) end end
 local nativePublic,nativeCall,nativeGetter=public,call,safeGetter
 local function public(...)
  ensure();local result,state=nativePublic(...);ensure();return result,state
 end
 local function call(...)
  ensure();local result=pack(nativeCall(...));ensure();return unpack(result,1,result.n)
 end
 local function safeGetter(...)
  ensure();local result=nativeGetter(...);ensure();return result
 end
 local function paint(method,...)
  ensure();local sent,result=nativeCall(mirror,method,...);ensure()
  if not sent or result==false then error("OBJECTIVE_TEXT_WRITE_FAILED",0) end
 end
 local function alpha(value)
  ensure();local result=L:Alpha(self,source,value);ensure();return result
 end
 local okay,result=pcall(function()
 ensure()
 -- Animation/widget-owned text no longer belongs to this paint queue. Native
 -- updates can still trigger our permanent observation hooks after handback.
 if row.nativeText then row.dirty=nil;row.combatDeferred=nil;return true end
 if row.dirty then
  row.combatDeferred=nil
  if row.suppressionDirty then
   if S:InCombat() and not S:Frame(source,true) then paint("SetText","");row.combatDeferred=true;return false end
   self.writing=transaction;local owned=alpha(0);self.writing=nil
   if not owned then paint("SetText","");return false end
   row.suppressionDirty=nil
  end
  row.dirty=nil
  if not S:Frame(source,false) or not S:Frame(row.mirror,false) then self.contentGaps=(self.contentGaps or 0)+1
  else
   -- These are our own FontString paint operations, not protected frame/input
   -- or layout changes. Public quest text must keep updating during combat.
   local text,state=public(source,"GetText","string")
   if state=="KNOWN" then
    if row.restricted then
     -- A pooled label returning to a public payload must exchange renderers
     -- again; it must never display the same text twice after restriction.
     if S:InCombat() then row.dirty=true;row.combatDeferred=true;self.combatPending=true;return false end
     self.writing=transaction;local owned=alpha(0);self.writing=nil
     if not owned then row.dirty=true;return false end
     row.restricted=nil
    end
    local shown=public(source,"IsShown","boolean")
    local heading=self:HeaderColor(source)
    local rendered=self:ReadableText(text)
    if heading then rendered=rendered:gsub("|c%x%x%x%x%x%x%x%x",""):gsub("|r","") end
    paint("SetText",shown==true and (row.opacity or 1)>0 and rendered or "")
    if not S:InCombat() then
     paint("SetJustifyH",safeGetter(source,"GetJustifyH","LEFT"));paint("SetJustifyV",safeGetter(source,"GetJustifyV","TOP"))
     local ok,path,size,flags=call(source,"GetFont")
     if ok and S:Text(path) and S:Number(size) and S:Text(flags or "") then paint("SetFont",path,size,flags or "") end
     for _,pair in ipairs({{"GetMaxLines","SetMaxLines","number"},{"GetSpacing","SetSpacing","number"},
      {"CanWordWrap","SetWordWrap","boolean"},{"CanNonSpaceWrap","SetNonSpaceWrap","boolean"}}) do
      local value,state=public(source,pair[1],pair[3])
      if state=="KNOWN" and type(f(row.mirror,pair[2]))=="function" then call(row.mirror,pair[2],value) end
     end
    end
    local good,r,g,b,a=call(source,"GetTextColor")
    if good and S:Number(r) and S:Number(g) and S:Number(b) and S:Number(a) then
     if heading then r,g,b=unpack(heading) else r,g,b=self:ReadableColor(r,g,b) end
     paint("SetTextColor",r,g,b,a*(row.opacity or 1))
    end
    -- Keep the region allocated/shown; empty text represents a hidden label.
    -- Combat updates use text/color only, never protected Show/Hide/SetAlpha.
    if not S:InCombat() then paint("Show");paint("SetAlpha",1) end
   elseif state=="RESTRICTED" then
    -- A previously public label may become restricted on reuse. Do not inspect
    -- or copy it. Restore the native text channel until readable data returns.
    row.restricted=true;paint("SetText","");if not S:InCombat() then self.writing=transaction;alpha(row.opacity or 1);self.writing=nil else row.dirty=true;row.combatDeferred=true;self.combatPending=true end
   else paint("SetText","") end
  end
 end
 return not row.dirty
 end)
 if self.writing==transaction then self.writing=nil end
 if not okay then
  -- A combat boundary cancels the current setter policy, not its pending
  -- payload. Keep the same owned row dirty for the next legal paint pass.
  if retained() then row.dirty=true end
  return false
 end
 return result
end
function O:RefreshText()
 local combat=S:InCombat()
 -- A protected/restricted renderer exchange cannot complete in combat. Park
 -- it until the boundary changes rather than spending every text budget on
 -- the same labels. New public labels retain the normal immediate queue.
 if not combat and self.combatFonts then
  for source in pairs(self.combatFonts) do
   self.combatFonts[source]=nil
   local row=self.mirrors[source]
   if row then row.combatDeferred=nil;self.dirtyFonts[source]=true end
  end
 end
 self.fontBatch=self.fontBatch or setmetatable({},{__mode="k"})
 if not next(self.fontBatch) then
  -- The dirty set remains the complete public work ledger. Snapshot only its
  -- bounded keys (at most2048 mirrors); retries wait until this wave drains.
  for source in pairs(self.dirtyFonts) do self.fontBatch[source]=true end
 end
 local batch=self.fontBatch
 local profile,generation=M.profile,self.generation
 local transaction={};self.textRefreshToken=transaction
 local function current()
  return self.active and self.generation==generation and M.profile==profile
   and self.fontBatch==batch and self.textRefreshToken==transaction and not M.state.safe
 end
 local count,started=0,styleMillis()
 for source in pairs(batch) do
  if count>=32 then break end
  if started and count>=4 then local clock=styleMillis();if clock and clock-started>=.20 then break end end
  count=count+1;batch[source]=nil;self.dirtyFonts[source]=nil
  local row=self.mirrors[source]
  local complete=not row or not (combat and row.combatDeferred) and self:PaintText(source,row)
  if not current() then return end
  if not complete then
   if combat and row.combatDeferred then
    self.combatFonts=self.combatFonts or setmetatable({},{__mode="k"});self.combatFonts[source]=true
   else
    -- Failures join the next wave. They cannot repeatedly take the first32
    -- slots while an older wave still contains unvisited public labels.
    self.dirtyFonts[source]=true
   end
  end
 end
end
local decorationFields={"Background","HeaderGlow","HeaderTop","GlowTexture","GoldCurlies","Filigree","FiligreeGlow",
 "BarFrame","BarFrame2","BarFrame3","BorderLeft","BorderRight","BorderMid","Border","IconBG","QuestIconBadgeBorder",
 "BorderTopLeft","BorderTopRight","BorderBotLeft","BorderBotRight","BorderTop","BorderBottom","BorderLeft","BorderRight",
 "NormalBG","ThemeOverlay","FinalBG","TimerBGBack","TimerBG","BG","BGAnim","BorderAnim","RewardsTop","RewardsBottom",
 "RewardsShadow","ItemBorder","QuestIconBg","Shine","BarGlow","Sheen","Starburst","BlackBar","DownLineGlow","UpLineGlow",
 "DownLine","UpLine","AnimTopLine","AnimBottomLine","AnimBarGlow"}
function O:FitSpecialized(node)
 local width=public(self.native,"GetWidth","number")
 if not width then return end
 local available=math.max(80,width-24)
 local bar=f(node,"Bar")
 local progress=type(f(node,"SetPercent"))=="function"
 local timer=type(f(node,"GetTextColor"))=="function" and f(node,"Label")~=nil and type(f(node,"OnUpdate"))=="function"
 if (progress or timer) and bar and public(bar,"GetObjectType","string")=="StatusBar" then
  dimension(self,node,"width",available)
  dimension(self,bar,"width",math.max(36,available-(timer and 54 or 12)))
  L:Points(self,bar,pack("LEFT",node,"LEFT",timer and 48 or 6,0))
  if timer and f(node,"Label") then dimension(self,f(node,"Label"),"width",44) end
 end
 if self.widgetContainers and self.widgetContainers[node] then
  local nativeWidth=public(node,"GetWidth","number")
  if nativeWidth and nativeWidth>0 then L:Scalar(self,node,"scale","GetScale","SetScale",math.min(1,available/nativeWidth)) end
  for _,method in ipairs({"SetWidth","SetSize","SetScale","AttachToBlockAndShow","UnattachFromBlockAndHide"}) do L:Hook(self,node,method) end
 end
end
-- b43 removes quest icons in every state, including the native animations.
-- Animation alpha and vertex alpha compose independently: zero vertex alpha
-- keeps a checkmark/POI invisible while the engine completes its animation and
-- lifecycle normally. The ledger restores the original tint on handback.
function O:MaskQuestIcon(region)
 if not S:Frame(region,false) or self.owned[region] or public(region,"GetObjectType","string")~="Texture" then return end
 local ok,r,g,b,a=call(region,"GetVertexColor")
 if not ok or not S:Number(r) or not S:Number(g) or not S:Number(b) or not S:Number(a) then return L:Gap(self,"color","QUEST_ICON_COLOR_UNAVAILABLE") end
 L:Write(self,region,"questIconColor",function(object)
  local good,rr,gg,bb,aa=call(object,"GetVertexColor")
  if good and S:Number(rr) and S:Number(gg) and S:Number(bb) and S:Number(aa) then return pack(rr,gg,bb,aa) end
 end,function(object,v) return object:SetVertexColor(v[1],v[2],v[3],v[4]) end,pack(r,g,b,0))
 L:DecorativeAlpha(self,region,0)
 for _,method in ipairs({"SetAtlas","SetTexture","SetVertexColor"}) do L:Hook(self,region,method) end
end
function O:MaskQuestTextures(frame)
 if not S:Frame(frame,false) then return end
 local get=f(frame,"GetRegions")
 if type(get)~="function" then return end
 local ok,regions=pcall(function() return {get(frame)} end)
 if not ok or #regions>64 then return L:Gap(self,"icon","QUEST_ICON_REGIONS_UNAVAILABLE") end
 for _,region in ipairs(regions) do self:MaskQuestIcon(region) end
end
function O:PolishQuestBadge(block)
 local poi=f(block,"poiButton")
 if not S:Frame(poi,false) or public(poi,"GetParent")~=block then return end
 self:MaskQuestTextures(poi)
 local display=f(poi,"Display")
 if S:Frame(display,false) and public(display,"GetParent")==poi then self:MaskQuestTextures(display) end
 -- Native title input still opens/tracks the quest. An icon that has been
 -- intentionally removed must not retain a disconnected invisible hit area.
 if type(f(poi,"IsMouseEnabled"))=="function" and type(f(poi,"EnableMouse"))=="function" then
  L:Scalar(self,poi,"objectiveBadgeMouse","IsMouseEnabled","EnableMouse",false)
 end
 for _,method in ipairs({"UpdateButtonStyle","UpdateUnderlay","UpdateSubTypeIcon","UpdateLockIcon"}) do L:Hook(self,poi,method) end
 L:Hook(self,block,"AddPOIButton")
end
function O:PolishQuestContent(node)
 -- Exact native animated-line topology. Do not stop CheckAnim/GlowAnim or
 -- write its state: completion and subsequent row retirement still belong to
 -- the tracker. Their visual icon sinks alone are suppressed.
 if f(node,"Text") and f(node,"CheckAnim") and type(f(node,"SetState"))=="function" then
  for _,key in ipairs({"Icon","CheckGlow","Glow"}) do self:MaskQuestIcon(f(node,key)) end
  for _,method in ipairs({"SetState","OnFree","SetNoIcon"}) do L:Hook(self,node,method) end
 end
 -- Reward imagery uses separate texture fields; its amounts/labels survive.
 for _,key in ipairs({"ItemIcon","ItemOverlay"}) do self:MaskQuestIcon(f(node,key)) end
 local item=f(node,"ItemButton")
 if S:Frame(item,false) and public(item,"GetParent")==node then
  -- Keep this original native button, item attributes, tooltip and modifiers.
  -- Its visible action is text, so removal of the artwork does not hide the
  -- only route to a quest item or leave an unexplained click region.
  local glyph=L:Glyph(self,item,"Use")
  if glyph then self.owned[glyph]=true;if glyph.label then self.owned[glyph.label]=true end end
  self:MaskQuestTextures(item)
 end
 local icon=f(node,"Icon")
 if public(node,"GetObjectType","string")=="Button" and public(icon,"GetAtlas","string")=="socialqueuing-icon-eye"
  and type(f(node,"SetUp"))=="function" then
  local glyph=L:Glyph(self,node,"Group")
  if glyph then
   self.owned[glyph]=true
   if glyph.label then self.owned[glyph.label]=true;glyph.label:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",9,"") end
  end
  self:MaskQuestTextures(node)
 end
end
function O:StyleNode(node,depth,seen,budget,nativeText,skip)
 budget.queue=budget.queue or {{node,depth,nativeText,false}};budget.root=budget.root or node
 local quantum=self.styleBudget or {remaining=32,steps=0,started=styleMillis()}
 local function visit(entry)
  local object,level,engineText,fontOnly=entry[1],entry[2],entry[3],entry[4]
  if self.owned[object] or (R.WindowKit and R.WindowKit.owned[object]) or seen[object] or level>14 or skip and skip[object] then return end
  if not S:Frame(object,false) then return L:Gap(self) end
  if not within(object,budget.root) then self.scanAgain=true;return end
  -- Local IsShown is intentional: an entire contextual viewport may be
  -- hidden while its first contents are prepared. Only dormant native child
  -- branches are pruned; ancestry visibility must not suppress first paint.
  if not fontOnly and object~=budget.root and public(object,"IsShown","boolean")==false then
   if R.WindowKit then R.WindowKit:HookScript(self,object,"OnShow") end
   local hooks=self.windowScriptHooks and self.windowScriptHooks[object]
   if not hooks or not hooks.OnShow then return L:Gap(self,"visibility","OBJECTIVE_SHOW_OBSERVER_UNAVAILABLE") end
   self.dormantBranches=(self.dormantBranches or 0)+1
   return
  end
  seen[object]=true
  local kind=public(object,"GetObjectType","string")
  if fontOnly then
   if kind=="FontString" then self:MirrorFont(object,engineText) end
   return
  end
  budget.n=(budget.n or 0)+1
  if budget.n>4096 then self.contentOverflow=true;budget.queue={};return L:Gap(self) end
  engineText=engineText or self.widgetContainers and self.widgetContainers[object] or f(object,"Anim")~=nil
  if kind=="FontString" then self:MirrorFont(object,engineText);return end
  self:FitSpecialized(object)
  self:PolishQuestBadge(object)
  self:PolishQuestContent(object)
  for _,key in ipairs(decorationFields) do
   local texture=f(object,key)
   if texture and public(texture,"GetObjectType","string")=="Texture" then
    -- Alpha alone suppresses stock decoration and has a complete inverse.
    -- Clearing its source first creates unnecessary texture restoration debt.
    L:Alpha(self,texture,0)
    self:WatchContent(texture,"SetAtlas");self:WatchContent(texture,"SetTexture")
   end
  end
  local header=f(object,"Header")
  if header and S:Frame(header,false) and public(header,"GetObjectType","string")~="FontString" then
   L:Panel(self,header,header,"objectiveHeader",.30)
   local minimize=f(header,"MinimizeButton")
   if minimize then
    local native,generation,profile=self.native,self.generation,M.profile
    self:AlignCollapseControl(header)
    if self.native~=native or self.generation~=generation or M.profile~=profile or not live() or S:InCombat()
     or f(header,"MinimizeButton")~=minimize or budget.current and not budget.current() then return end
    local glyph=L:Glyph(self,minimize,public(object,"IsCollapsed","boolean")==true and "+" or "−")
    if glyph and not S:InCombat() then
     self.owned[glyph]=true;if glyph.label then self.owned[glyph.label]=true end
     -- Glyph uses the shared lease panel, whose retained default edge predates
     -- the neutral Cursor Companion chrome. Recolor only its owned artwork;
     -- the native collapse button and its input/selection state stay native.
     for _,side in ipairs({"TOP","BOTTOM","LEFT","RIGHT"}) do
      local edge=glyph.miragePanelPieces and glyph.miragePanelPieces[side]
      if edge then call(edge,"SetVertexColor",unpack(theme("edge",{.26,.26,.26,1}))) end
     end
    end
   end
  end
  -- GetBlock/GetLine also return existing pooled objects. Read-only lookups
  -- must not restart a complete traversal; EndLayout observes real rebuilds.
  for _,method in ipairs({"SetCollapsed","EndLayout","SetHeader","SetProgress","SetTimer"}) do self:WatchContent(object,method) end
  local regions=f(object,"GetRegions")
  if type(regions)=="function" then
   local ok,list=pcall(function() return {regions(object)} end)
   if ok and #list<=128 then
    for _,region in ipairs(list) do if not self.owned[region] then budget.queue[#budget.queue+1]={region,level+1,engineText,true} end end
   else L:Gap(self) end
  end
  local children=f(object,"GetChildren")
  if not budget.framesSupplied and type(children)=="function" then
   local ok,list=pcall(function() return {children(object)} end)
   if ok and #list<=512 then for _,child in ipairs(list) do budget.queue[#budget.queue+1]={child,level+1,engineText,false} end
   else L:Gap(self) end
  end
 end
 while #budget.queue>0 do
  if S:InCombat() or budget.current and not budget.current() then return false,"OBJECTIVE_WORK_QUEUED" end
  if not styleStep(quantum) then return false,"OBJECTIVE_WORK_QUEUED" end
  visit(table.remove(budget.queue))
 end
 return true
end
function O:Scan()
 if not self.native or not R.WindowKit then return false,"TRACKER_DEPENDENCY_UNAVAILABLE" end
 if (self.scanRemaining or 0)>0 then self.scanAgain=true;return true end
 self.combatPending=nil
 self.familyReceipts=self.familyReceipts or {}
 self.familyRoots=self.familyRoots or setmetatable({},{__mode="k"})
 self.dirtyFamilies=self.dirtyFamilies or {}
 local full=self.fullScan or not self.scanRuns or not next(self.dirtyFamilies)
 self.fullScan=nil
 if full then self.contentOverflow=nil end
 self.widgetContainers={}
 local scenario=_G.ScenarioObjectiveTracker
 for _,widget in pairs({main=_G.ObjectiveTrackerUIWidgetContainer,top=L:Path(scenario,"TopWidgetContainerBlock","WidgetContainer"),
  bottom=L:Path(scenario,"BottomWidgetContainerBlock","WidgetContainer")}) do
  if S:Frame(widget,false) then self.widgetContainers[widget]=true end
 end
 local rootSkip={};for object in pairs(self.owned) do rootSkip[object]=true end
 local parts={{key="Root",root=self.native,limit=512,depth=10,skip=rootSkip}}
 self.familyRoots[self.native]="Root"
 for _,name in ipairs(families) do
  local module=_G[name]
  if S:Frame(module,false) then
   rootSkip[module]=true
   if f(module,"parentContainer")==self.native then
    self.familyRoots[module]=name
    self:WatchFamilyLayout(module,name)
    parts[#parts+1]={key=name,sourceName=name,root=module,limit=1024,depth=14,skip=self.owned}
   end
  else self.familyReceipts[name]=nil;self.dirtyFamilies[name]=nil;R:RecordSurface(self,name,"EMPTY","NATIVE_MODEL_ABSENT") end
 end
 local toasts=f(_G.ObjectiveTrackerManager,"rewardsToastPool")
 if toasts then L:Pool(self,toasts,24,function(toast)
  local key="Toast"..(#parts+1);self.familyRoots[toast]=key
  parts[#parts+1]={key=key,root=toast,limit=192,depth=8,skip=self.owned}
 end) end
 local selected,present={},{}
 for _,part in ipairs(parts) do
  present[part.key]=true
  local receipt=self.familyReceipts[part.key]
  if full or self.dirtyFamilies[part.key] or not receipt or receipt.root~=part.root then
   selected[#selected+1]=part;self.dirtyFamilies[part.key]=nil
  else self.cachedFamilies=(self.cachedFamilies or 0)+1 end
 end
 for key in pairs(self.familyReceipts) do if not present[key] then self.familyReceipts[key]=nil end end
 parts=selected
 self.lastScanFamilies=#parts;self.lastScanFull=full==true
 if #parts==0 then self.contentMeasureDirty=true;self.healthDirty=true;return true end
 self.scanSerial=(self.scanSerial or 0)+1;self.scanRemaining=#parts;self.scanCallbacks={}
 self.scanRuns=(self.scanRuns or 0)+1
 self.windowJobs=self.windowJobs or setmetatable({},{__mode="k"})
 self.completedTrees=self.completedTrees or setmetatable({},{__mode="k"});self.stylePending=nil
 local serial,generation,profile,native=self.scanSerial,self.generation,M.profile,self.native
 local function current() return self.active and not M.state.safe and self.scanSerial==serial and self.generation==generation
  and M.profile==profile and self.native==native end
 local function finish(part,kind,why)
  if part.finished then return end
  part.finished=true;self.scanRemaining=math.max(0,(self.scanRemaining or 1)-1)
  self.windowJobs[part.root]=nil
  self.stylePending=next(self.windowJobs) and true or nil
  R:RecordSurface(self,part.key,kind,why)
  self.familyReceipts[part.key]={root=part.root,kind=kind,reason=why,nodes=part.mirrorBudget and part.mirrorBudget.n or 0}
  self.contentGaps=0
  for _,receipt in pairs(self.familyReceipts) do if receipt.kind=="PARTIAL" then self.contentGaps=self.contentGaps+1 end end
  -- One provider dispatch publishes completion after independent scan jobs
  -- drain, including a rejected continuation. Idle suppression must not leave
  -- the report stuck at the preceding OBJECTIVE_CONTENT_QUEUED result.
  if self.scanRemaining==0 then self.healthDirty=true;self.contentMeasureDirty=true end
 end
 local function queue(part)
  if M.RuntimeScheduler then
   if M.RuntimeScheduler:Request("Rework.objectives.scan."..part.key,part.process,{owner="objectives",combat="defer",priority=4,guard=current}) then return true end
   part.failed=true;finish(part,"PARTIAL","STYLE_QUEUE_FULL");return false
  end
  self.scanCallbacks[#self.scanCallbacks+1]=part.process;return true
 end
 for _,entry in ipairs(parts) do
  local part=entry
  -- WindowKit supplies each admitted frame once. The objective continuation
  -- paints those frames and their FontStrings without walking GetChildren a
  -- second time. Its queue remains separately bounded by the shared quantum.
  part.seen={};part.mirrorBudget={n=0,root=part.root,current=current,queue={},framesSupplied=true}
  part.engineText=setmetatable({},{__mode="k"});part.gaps=0
  local function partCurrent()
   return current() and (not part.sourceName or _G[part.sourceName]==part.root and f(part.root,"parentContainer")==native)
  end
  R:RecordSurface(self,part.key,"WAITING","STYLE_QUEUED")
  part.process=function()
   if not current() or part.finished then return end
   if not partCurrent() then self.scanAgain=true;part.failed=true;finish(part,"PARTIAL","NATIVE_MODEL_CHANGED");return end
   if R:NativeEditing() then finish(part,"WAITING","STYLE_QUEUED");self.dirty=true;return end
   if S:InCombat() then queue(part);return end
   local prior=self.gaps or 0
   self.painting=true;self.writing=true;self.paintingToken=serial
   self.styleBudget={remaining=32,steps=0,started=styleMillis()}
   local started=self.styleBudget.started
   self.scanChunks=(self.scanChunks or 0)+1
   local ok,complete=pcall(function()
    if #part.mirrorBudget.queue>0 then
     local painted=self:StyleNode(part.root,0,part.seen,part.mirrorBudget,nil,part.skip)
     if not painted then return false end
    end
    if not part.treeDone then
     local done,why=R.WindowKit:StyleTree(self,part.root,{maxNodes=part.limit,maxDepth=part.depth,budgetNodes=32,
      fill=.10,header=false,buttons=false,fonts=false,role="content",skip=part.skip,
      watchNative=function(frame,method)
       if method~="Update" then return true end
       if frame==native then return false end
       -- Container.Update calls every family, including the source's clean
       -- early-return branch. EndLayout is the actual rebuild boundary; a
       -- no-op family Update must not invalidate its stable presentation.
       return not (self.familyRoots[frame] and type(f(frame,"EndLayout"))=="function")
      end,
      visit=function(frame)
       if not partCurrent() or not within(frame,part.root) then return false end
       local shown,access=public(frame,"IsShown","boolean")
       if access~="KNOWN" then L:Gap(self,"visibility","OBJECTIVE_LOCAL_VISIBILITY_UNAVAILABLE");return false end
       if not shown then
        local hooks=self.windowScriptHooks and self.windowScriptHooks[frame]
        if not hooks or not hooks.OnShow then L:Gap(self,"visibility","OBJECTIVE_SHOW_OBSERVER_UNAVAILABLE")
        else self.dormantBranches=(self.dormantBranches or 0)+1 end
        return false
       end
       return true
      end,
      painted=function(frame)
       if not partCurrent() or not within(frame,part.root) then self.scanAgain=true;return end
       local parent=public(frame,"GetParent")
       local engineText=part.engineText[parent] or self.widgetContainers and self.widgetContainers[frame] or f(frame,"Anim")~=nil
       part.engineText[frame]=engineText==true
       part.mirrorBudget.queue[#part.mirrorBudget.queue+1]={frame,0,engineText,false}
      end})
     if not done and why=="WINDOW_WORK_QUEUED" then return false end
     part.treeDone=true
     if not done then part.failed=true end
    end
    return self:StyleNode(part.root,0,part.seen,part.mirrorBudget,nil,part.skip)
   end)
   self.painting=nil;self.writing=nil;self.paintingToken=nil;self.styleBudget=nil
   local ended=started and styleMillis()
   if ended then
    local elapsed=math.max(0,ended-started)
    self.scanWorkMs=(self.scanWorkMs or 0)+elapsed;self.scanChunkMaxMs=math.max(self.scanChunkMaxMs or 0,elapsed)
   end
   if not current() then return end
   part.gaps=part.gaps+math.max(0,(self.gaps or 0)-prior)
   if not ok then
    part.failed=true;finish(part,"PARTIAL","CONTENT_STYLE_FAILED")
   elseif not complete then
    R:RecordSurface(self,part.key,"WAITING","STYLE_QUEUED")
    queue(part);return
   else
    finish(part,not part.failed and part.gaps==0 and "READY" or "PARTIAL","NATIVE_CONTENT_STYLED")
   end
   if self.scanRemaining==0 then
    -- The native model is complete; measure once for the coalesced family
    -- batch, not once after each of eleven independent styling jobs.
    self:MeasureContent();self.contentMeasureDirty=nil;self:RefreshText()
    local pending=self.scrollPending or self.offset or 0;self.scrollPending=nil;self:SetScroll(pending)
    if self.initialPresentationPending and self:FirstContentReady() then self.initialPresentationPending=nil end
    self:Visibility()
    self:Readiness()
    if self.scanAgain then self.scanAgain=nil;self.dirty=true end
   end
  end
  queue(part)
 end
 return true
end
function O:MeasureContent()
 local native,generation,profile=self.native,self.generation,M.profile
 if not native then return false end
 local function current()
  if not live() or self.native~=native or self.generation~=generation or M.profile~=profile then return false end
  local parent,access=self.contentHost,"KNOWN"
  if self.acquired then parent,access=public(native,"GetParent") end
  return access=="KNOWN" and parent==self.contentHost and self.native==native and self.generation==generation and M.profile==profile and self.active==true
 end
 if not current() then return false end
 local familyCount,truncated,truncatedFamilies=0,false,{}
 local fallback,known={},{}
 for _,name in ipairs(families) do
  local module=_G[name]
  if S:Frame(module,false) and f(module,"parentContainer")==native then
   familyCount=familyCount+1;fallback[#fallback+1]=module;known[module]=name
  end
 end
 -- Native Update anchors each positive-height module below the preceding
 -- module's frame, including its bottom spacing. Read the native sorted list
 -- and explicit dimensions; the final extent excludes only its empty bottom
 -- spacing. This follows the actual layout instead of adding a fixed footer
 -- and an extra gap after every family.
 local ordered={};local modules=f(native,"modules")
 if type(modules)=="table" and S:Readable(modules) then
  for i=1,64 do
   local module=f(modules,i);if module==nil then break end
   if S:Frame(module,false) and f(module,"parentContainer")==native then ordered[#ordered+1]=module end
  end
 else ordered=fallback end
 local headerHeight=public(f(native,"Header"),"GetHeight","number")
 if not headerHeight or headerHeight<16 or headerHeight>128 then headerHeight=32 end
 local top=f(native,"topModulePadding");if not S:Number(top) or top<0 then top=headerHeight+6 end
 local gap=f(native,"moduleSpacing");if not S:Number(gap) or gap<0 then gap=10 end
 local bottom,extent,count=top,headerHeight,0
 for _,module in ipairs(ordered) do
  local height=public(module,"GetContentsHeight","number")
  if not height or height<0 then
   if current() then self.contentMeasurePending=true;self.healthDirty=true end
   return false -- an unavailable content read is not an empty list
  end
  if height and height>0 then
   local actual=public(module,"GetHeight","number",true)
   if not actual or actual<height then actual=height end
   local padding=f(module,"bottomSpacing");if not S:Number(padding) or padding<0 then padding=0 end
   local start=count==0 and top or bottom+gap
   extent=math.max(headerHeight,start+math.max(height,actual-padding))
   bottom=start+actual;count=count+1
  end
  if public(module,"IsTruncated","boolean")==true then
   truncated=true;truncatedFamilies[#truncatedFamilies+1]=known[module] or "NATIVE_MODULE"
  end
  if not current() then return false end
 end
 local collapsed,access=public(native,"IsCollapsed","boolean")
 if collapsed==true then extent=headerHeight;truncated=false;truncatedFamilies={} end
 local height=public(native,"GetHeight","number",true)
 if not current() then return false end
 local changed=not L:GeometryEqual(self.contentHeight,extent) or access=="KNOWN" and collapsed~=self.collapsed
 self.familyCount=familyCount;self.contentHeight=extent;self.nativeHeight=height;self.measuredNative=native;self.contentMeasurePending=nil
 self.truncated=truncated;self.truncatedFamilies=truncatedFamilies
 if changed and self.layout then
  if S:InCombat() then self.layoutDirty=true
  else
   local fitted=self:ApplyLayout(self.surface,true)
   if not current() then return false end
   if not fitted then self.layoutDirty=true end
  end
  if current() then
   self.scrollDirty=true
   -- Keep a valid native scroll offset when completion/collapse shortened the
   -- list. SetScroll already defers protected geometry during combat.
   self:SetScroll(self.scrollPending or self.offset or 0)
  end
 end
 return true
end
function O:RequestModelSettle(reason)
 -- Native GetAvailableHeight reads the computed screen rectangle, whereas
 -- our geometry receipt deliberately reads explicit dimensions. Immediately
 -- after adoption or delayed native population those values can differ.
 -- One bounded deferred native refresh repairs only that observed race; quest
 -- events and idle ticks still never poll/rebuild the native content model.
 if not self.truncated or not self.native or not M.RuntimeScheduler then return end
 if self.modelSettlePending then return true end -- native callbacks coalesce
 local native,generation,profile=self.native,self.generation,M.profile
 local explicit=public(native,"GetHeight","number",true)
 local computed=public(native,"GetHeight","number")
 if not live() or self.native~=native or self.generation~=generation or M.profile~=profile then return end
 local matches=computed~=nil and L:GeometryEqual(explicit,computed)
 if not explicit or matches and not (reason=="FIRST_VISIBLE_RECTANGLE" and self.modelSettleStatus=="RECTANGLE_UNCONFIRMED") then return end
 local serial=(self.modelSettleSerial or 0)+1;self.modelSettleSerial=serial
 self.modelSettlePending=true;self.modelSettleAttempts=0;self.modelSettleStatus="QUEUED";self.modelSettleReason=reason or "CONFIGURE"
 local function current()
  return live() and O.native==native and O.generation==generation and M.profile==profile and O.modelSettleSerial==serial
 end
 local process
 local function finish(status)
  if not current() then return end
  O.modelSettlePending=nil;O.modelSettleStatus=status;O.healthDirty=true
 end
 local function queue()
  if not current() then return end
  local delay=math.min(.20,.04*(O.modelSettleAttempts+1))
  if not M.RuntimeScheduler:Request("Rework.objectives.settle",process,{owner="objectives",combat="defer",priority=4,delay=delay,guard=current}) then
   finish("QUEUE_UNAVAILABLE")
  end
 end
 process=function()
  if not current() then return end
  local anchored,point,relative,relativePoint,x,y=call(native,"GetPoint",1)
  local retained=public(native,"GetParent")==O.contentHost and anchored and point=="TOPLEFT" and relative==O.contentHost and relativePoint=="TOPLEFT"
   and L:GeometryEqual(x,0) and L:GeometryEqual(y,0) and L:GeometryEqual(public(native,"GetWidth","number",true),O.contentWidth)
   and L:GeometryEqual(public(native,"GetScale","number"),1)
  if not current() then return end
  if not retained then finish("CUSTODY_CHANGED");return end
  O.modelSettleAttempts=O.modelSettleAttempts+1
  local height=public(native,"GetHeight","number")
  local wanted=public(native,"GetHeight","number",true)
  if not current() then return end
  if not height or not wanted or not L:GeometryEqual(wanted,explicit) or not L:GeometryEqual(height,wanted) then
   if O.modelSettleAttempts<8 then queue() else finish("RECTANGLE_UNCONFIRMED") end
   return
  end
  -- The queue admitted this callback outside lockdown, but a native getter
  -- above can cross the combat boundary. Preserve the same pending repair
  -- for the scheduler's legal next dispatch; never turn a read into a write
  -- using an earlier combat observation.
  if S:InCombat() then queue();return end
  if not current() then return end
  local token,prior={},O.writing;O.writing=token
  local updated,result=call(native,"Update")
  if O.writing==token then O.writing=prior end
  if not current() then return end
  if updated and result~=false then
   O.modelSettleRefreshes=(O.modelSettleRefreshes or 0)+1
   O:MeasureContent()
   if not current() then return end
   O.dirty=true;finish("REFRESHED")
  else finish("NATIVE_UPDATE_FAILED") end
 end
 queue()
end
-- Readiness follows the current model and bounded scan, not a successful Tick
-- return. An empty/missing engine model or retained content gap cannot become
-- READY merely because a later heartbeat has no repaint work to do.
function O:Readiness()
 local kind,status
 if not self.native or _G.ObjectiveTrackerFrame==nil then kind,status="WAITING","WAITING_FOR_OBJECTIVE_MODEL"
 elseif _G.ObjectiveTrackerFrame~=self.native then kind,status="PARTIAL","OBJECTIVE_MODEL_REPLACED"
 elseif self.scroll and not self:ObserveViewport() then kind,status="PARTIAL",self.viewportStatus
 elseif (self.scanRemaining or 0)>0 then kind,status="WAITING","OBJECTIVE_CONTENT_QUEUED"
 elseif self.combatPending then kind,status="DEFERRED_COMBAT","OBJECTIVE_STYLE_COMBAT_DEFERRED"
 elseif self.modelSettlePending then kind,status="WAITING","OBJECTIVE_NATIVE_RECTANGLE_SETTLING"
 elseif self.contentMeasurePending then kind,status="WAITING","OBJECTIVE_CONTENT_MEASUREMENT_PENDING"
 elseif self.truncated then kind,status="PARTIAL","OBJECTIVE_MODEL_TRUNCATED"
 elseif self.contentOverflow then kind,status="PARTIAL","OBJECTIVE_RENDER_BUDGET_EXCEEDED"
 elseif self.scroll and self.scrollStatus and self.scrollStatus~="CONFIRMED" then kind,status="PARTIAL",self.scrollStatus
 elseif (self.gaps or 0)>0 or (self.contentGaps or 0)>0 then kind,status="PARTIAL","OBJECTIVE_PRESENTATION_PARTIAL"
 elseif (self.familyCount or 0)<#families then kind,status="WAITING","OBJECTIVE_FAMILIES_PENDING"
 else kind,status="READY","CUSTOM_OBJECTIVES_READY" end
 self.status=status
 return R:Result(kind,status)
end
function O:StartupPrepared()
 if not live() or self.dirty or self.layoutDirty or self.geometryDirty or self.viewportDirty
  or next(self.dirtyFonts) or self.fontBatch and next(self.fontBatch) then return false end
 local result=self:Readiness()
 return result and result.kind=="READY"
end
function O:Configure()
 if self.releasing then return false,"RESTORE_REENTERED" end
 if not R:Qualified() or not R:Selected(self.id) or M.state.safe then return self:Suspend("UNSELECTED") end
 local editing=R:NativeEditState()
 if editing=="UNKNOWN" then return R:Result("DEFERRED_HANDOFF","NATIVE_EDIT_UNKNOWN") end
 if editing=="OPEN" then return self:Suspend("NATIVE_EDIT_HANDOFF") end
 if not screen() then self.viewportPending=true;self.status="VIEWPORT_PENDING";return R:Result("WAITING",self.status) end
 self.viewportPending=nil
 if S:InCombat() then self.dirty=true;return false,"SETUP_COMBAT_DEFERRED" end
 if M.RuntimeScheduler then M.RuntimeScheduler:CancelPrefix("Rework.objectives.scan.");M.RuntimeScheduler:Cancel("Rework.objectives.settle") end
 self.modelSettleSerial=(self.modelSettleSerial or 0)+1;self.modelSettlePending=nil;self.modelSettleStatus=nil
 self.viewportDirty=nil;self.viewportCombatPending=nil
 self.scanRemaining=0;self.scanAgain=nil;self.scanCallbacks=nil;self.scanSerial=(self.scanSerial or 0)+1
 self.healthDirty=nil
 self.initialPresentationPending=true;self.familyReceipts={};self.familyRoots=setmetatable({},{__mode="k"});self.layoutObservers={}
 self.dirtyFamilies={};self.fullScan=true;self.contentGaps=0;self.contentMeasureDirty=nil
 self.windowJobs=nil;self.completedTrees=nil;self.stylePending=nil
 local initialized,initialWhy=self:Initialize();if not initialized then return false,initialWhy or "SETUP_DEFERRED" end
 if not self.active then self.active=true;L:Begin(self) end
 self.gaps,self.styled,self.expected=0,0,0
 local map=R.Minimap and R.Minimap.frame
 if S:Frame(map,false) then for _,method in ipairs({"SetPoint","SetSize","SetScale"}) do L:Hook(self,map,method) end end
 local frame=_G.ObjectiveTrackerFrame
 if frame==nil then self.dirty=nil;return self:Readiness() end
 if not S:Frame(frame,false) then return false,"TRACKER_FORBIDDEN" end
 local acquired,why=self:Acquire(frame);if not acquired then return false,why end
 -- Native OnShow may settle its model during adoption, but this temporary
 -- setup visibility must not flash a sidebar whose current context is quiet.
 self.setupQuiet=self.surface.desired==nil or self.surface.desired=="HIDDEN"
 if self.setupQuiet then
  if M.Effects and M.Effects.StopProtected then M.Effects:StopProtected(self,self.frame) end
  self.frame:SetAlpha(0)
 end
 self.frame:Show() -- let the native OnShow settle before the qualified geometry write.
 self.setupQuiet=nil
 local applied,layoutWhy=self:ApplyLayout(self.surface);if not applied then return false,layoutWhy end
 -- Call only the exact client's native content/layout refresh, once after the
 -- custom envelope is installed; native hooks merely mark our next pass dirty.
 if type(f(frame,"Update"))=="function" then self.writing=true;call(frame,"Update");self.writing=nil end
 local ok,scanWhy=self:Scan();if not ok then return false,scanWhy end
 if public(frame,"GetParent")~=self.contentHost then return false,"TRACKER_CUSTODY_CHANGED" end
 self:MeasureContent();self:RequestModelSettle();self:RefreshText();self:SetScroll(self.offset or 0)
 self.surface.disabled=false;self.dirty=nil
 if self:FirstContentReady() then self.initialPresentationPending=nil end
 local visible,visibilityWhy=self:Visibility();if not visible then return false,visibilityWhy end
 if self.surface.desired==nil then self.frame:Hide() end
 self:SettleStartupLayer()
 self.geometryDirty=nil
 return self:Readiness()
end
function O:Tick(now)
 if self.viewportPending and not self.active and screen() then return self:Configure() end
 if not live() then return end
 self.healthDirty=nil
 if self.contentMeasureDirty and not S:InCombat() then self:MeasureContent();self.contentMeasureDirty=nil end
 if self.initialPresentationPending and not S:InCombat() and self.scanRuns and (self.scanRemaining or 0)==0
  and not self.modelSettlePending and ((self.contentGaps or 0)>0 or (self.gaps or 0)>0 or self.contentOverflow or self.truncated) then
  -- A failed first presentation returns the usable native tracker. A quiet
  -- initial surface is never allowed to conceal content indefinitely.
  local restored,why=self:Suspend("OBJECTIVE_INITIAL_CONTENT_HANDOFF")
  return R:Result("PARTIAL",restored and "OBJECTIVE_INITIAL_CONTENT_HANDOFF" or why or "OBJECTIVE_RESTORE_PENDING")
 end
 if self.initialPresentationPending and not S:InCombat() and self:FirstContentReady() then
  self.initialPresentationPending=nil;self.healthDirty=true
 end
 local visible,visibilityWhy=self:Visibility()
 if not visible and not S:InCombat() then self:Suspend(visibilityWhy);return false,visibilityWhy end
 if self.viewportDirty or self.viewportCombatPending and not S:InCombat() then
  local bound,why=self:ObserveViewport()
  if not bound then
   if S:InCombat() then
    self.viewportCombatPending=true;self.viewportDirty=nil;self.healthDirty=nil
    return R:Result("DEFERRED_COMBAT",why)
   end
   -- A revoked clip, ScrollChild or layer receipt returns native access; do
   -- not repeatedly seize it back or display an overflowing custom tracker.
   self:Suspend(why);return R:Result("PARTIAL",why)
  end
  self.viewportDirty=nil;self.viewportCombatPending=nil
 end
 if not S:InCombat() and self.scanCallbacks and #self.scanCallbacks>0 then
  local continuation=table.remove(self.scanCallbacks,1);continuation()
 end
 self:RefreshText()
 if self.scrollDirty then self:ObserveScroll() end
 if not S:InCombat() and self.scrollPending then local pending=self.scrollPending;self.scrollPending=nil;self:SetScroll(pending) end
 if not self.dirty and not self.layoutDirty then
  self.healthDirty=nil -- this return publishes any synchronous scroll receipt.
  return self:Readiness()
 end
 if S:InCombat() then self.combatPending=true;self.status="OBJECTIVE_STYLE_COMBAT_DEFERRED";return end
 if now<(self.nextPass or 0) then return end
 self.nextPass=now+.15
 if self.geometryDirty then
  self.geometryDirty=nil
  local good,point,parent,relative,x,y=call(self.native,"GetPoint",1)
  if not good or point~="TOPLEFT" or parent~=self.contentHost or relative~="TOPLEFT" or not L:GeometryEqual(x,0) or not L:GeometryEqual(y,0)
   or public(self.native,"GetParent")~=self.contentHost then
   self:Suspend("OBJECTIVE_NATIVE_LAYOUT_CHANGED")
   return R:Result("CONFLICT","OBJECTIVE_NATIVE_LAYOUT_CHANGED","ObjectiveTrackerFrame")
  end
 end
 if self.layoutDirty then
  local ok,why=self:ApplyLayout(self.surface);if not ok then return R:Result(why=="VIEWPORT_PENDING" and "WAITING" or "PARTIAL",why) end
  self.layoutDirty=nil
  -- Native SetCollapsed updates its content model before our posthook. On
  -- expansion, refresh that range before the saved scroll request is consumed
  -- on a later tick; the old header-only range would otherwise clamp it to 0.
  self:MeasureContent()
 end
 if not self.native then return self:Configure() end
 self.dirty=nil
 -- Content updates discover/repaint only. No root reacquisition, profile
 -- apply, native Update(), or geometry rewrite occurs on a quest event.
 local ok,why=self:Scan()
 if not ok then
  return R:Result("PARTIAL",why or "OBJECTIVE_CONTENT_PENDING")
 end
 return self:Readiness()
end
function O:NeedsRuntimeTick(now,combat)
 if self.viewportPending and not self.active then
  return not combat and R:Qualified() and R:Selected(self.id) and not M.state.safe and not R:NativeEditing() and screen()~=nil
 end
 if not live() then return false end
 if self.surface and self.visibilityDesired~=self.surface.desired or self.visibilityCombat~=(combat==true) then return true end
 if self.healthDirty or self.scrollDirty or self.viewportDirty or next(self.dirtyFonts) or self.fontBatch and next(self.fontBatch) then return true end
 if combat then return false end
 if self.combatFonts and next(self.combatFonts) then return true end
 return self.contentMeasureDirty==true or self.viewportCombatPending==true or self.dirty==true or self.layoutDirty==true or self.geometryDirty==true or self.scrollPending~=nil
  or self.scanCallbacks and #self.scanCallbacks>0 or false
end
function O:OnEvent(event)
 if event=="PLAYER_REGEN_ENABLED" then
  if self.combatPending then self.combatPending=nil;self.dirty=true end
 elseif event=="DISPLAY_SIZE_CHANGED" or event=="UI_SCALE_CHANGED" then self.layoutDirty=true;self:InvalidateFamily(nil,event)
 elseif event=="QUEST_LOG_UPDATE" or event=="QUEST_WATCH_UPDATE" or event=="QUEST_WATCH_LIST_CHANGED"
  or event=="QUEST_ACCEPTED" or event=="QUEST_REMOVED" or event=="QUEST_TURNED_IN" or event=="QUEST_DATA_LOAD_RESULT" then
  for _,name in ipairs({"QuestObjectiveTracker","CampaignQuestObjectiveTracker","AdventureObjectiveTracker","BonusObjectiveTracker","WorldQuestObjectiveTracker"}) do self:ContentEvent(name,event) end
 elseif event=="SCENARIO_UPDATE" or event=="SCENARIO_CRITERIA_UPDATE" or event=="SCENARIO_COMPLETED" then
  self:ContentEvent("ScenarioObjectiveTracker",event);self:ContentEvent("UIWidgetObjectiveTracker",event)
 elseif event=="TRACKED_ACHIEVEMENT_UPDATE" or event=="TRACKED_ACHIEVEMENT_LIST_CHANGED" then self:ContentEvent("AchievementObjectiveTracker",event)
 elseif event=="TRACKED_RECIPE_UPDATE" then self:ContentEvent("ProfessionsRecipeTracker",event)
 elseif event=="MONTHLY_ACTIVITIES_UPDATED" then self:ContentEvent("MonthlyActivitiesObjectiveTracker",event)
 else self:InvalidateFamily(nil,event) end
end
function O:Suspend(reason)
 if M.Effects and M.Effects.CancelProtected and self.frame then M.Effects:CancelProtected(self,self.frame,false) end
 self.active=false;self.generation=(self.generation or 0)+1;self.dirty=nil
 self.healthDirty=nil
 self.dirtyFonts=setmetatable({},{__mode="k"});self.fontBatch=nil;self.combatFonts=nil;self.textRefreshToken=nil
 self.viewportDirty=nil;self.viewportCombatPending=nil;self.modelSettleSerial=(self.modelSettleSerial or 0)+1;self.modelSettlePending=nil
 self.scanSerial=(self.scanSerial or 0)+1;self.scanRemaining=0;self.scanAgain=nil;self.scanCallbacks=nil
 self.initialPresentationPending=nil;self.dirtyFamilies=nil;self.familyReceipts=nil;self.familyRoots=nil;self.layoutObservers=nil;self.contentMeasureDirty=nil;self.fullScan=nil
 self.windowJobs=nil;self.completedTrees=nil;self.stylePending=nil;self.paintingToken=nil;self.styleBudget=nil
 if M.RuntimeScheduler then M.RuntimeScheduler:CancelPrefix("Rework.objectives.scan.");M.RuntimeScheduler:Cancel("Rework.objectives.settle") end
 if S:InCombat() then return false,"COMBAT_LOCKDOWN" end
 if self.visibilityExpression or self.visibilityAttempt then
  if type(UnregisterStateDriver)~="function" or not pcall(UnregisterStateDriver,self.frame,"muiobjectives") then
   self.status="OBJECTIVE_VISIBILITY_RESTORE_PENDING";return false,self.status
  end
  self.visibilityExpression=nil;self.visibilityAlpha=nil;self.visibilityAttempt=nil
 end
 for _,row in pairs(self.mirrors) do if S:Frame(row.mirror,false) then row.mirror:Hide() end end
 local ok,why=L:Release(self)
 if ok then
  if self.scroll and self.emptyScrollChild and public(self.scroll,"GetScrollChild")==self.contentHost then call(self.scroll,"SetScrollChild",self.emptyScrollChild) end
  if self.frame then self.frame:Hide() end
  self.native=nil;self.acquired=nil;self.nativeManager=nil;self.managerState=nil;self.scrollStatus=nil;self.scrollDirty=nil;self.scrollPending=nil;self.status=reason or "SUSPENDED"
  if self.surface then self.surface.disabled=true end
 else self.status=why or "OBJECTIVE_RESTORE_PENDING" end
 return ok,why
end
function O:Bounds(id)
 if id~="QuestTracker.nativePosition" or not self.surface then return nil end
 local l=self.layout or self:ResolveLayout(self.surface)
 return {frame=self.frame,id=id,x=l.x,y=l.y,width=l.width,height=l.height,scale=l.scale or 1,anchorTo=l.anchorTo,source="CUSTOM_SCROLL_VIEWPORT"}
end
function O:GetFrame(id) return id=="QuestTracker.nativePosition" and self.frame or nil end
function O:Status()
 return self.status.."; families="..(self.familyCount or 0).."/11; readable_labels="..(self.mirrorCount or 0)
  .."; viewport_fit=NATIVE_CONTENT_TO_MAXIMUM; footer=NONE; content_indent=HEADER_ALIGNED; aligned_labels="..(self.alignedContentCount or 0)
  .."; text=OWNED_RENDERER; model=ALL_NATIVE_MODULES; item_and_modifier_clicks=NATIVE_RETAINED; scroll=VIEWPORT; scan_chunks="..(self.scanChunks or 0)
  .."; chunk_node_limit=32; native_extent="..tostring(self.nativeHeight or "UNKNOWN")
  .."; scan_runs="..tostring(self.scanRuns or 0).."; viewport_receipt="..tostring(self.viewportStatus or "NOT_RUN")
  .."; last_scan_families="..tostring(self.lastScanFamilies or 0).."; cached_family_reuses="..tostring(self.cachedFamilies or 0)
  .."; traversal=SINGLE_FRAME_WALK_LOCAL_SHOWN_BRANCHES; dormant_branches="..tostring(self.dormantBranches or 0).."; observed_content_events="..tostring(self.observedContentEvents or 0)
  .."; scan_work_ms="..string.format("%.3f",self.scanWorkMs or 0).."; scan_chunk_max_ms="..string.format("%.3f",self.scanChunkMaxMs or 0)
  .."; first_content="..(self.initialPresentationPending and "PENDING" or "COMMITTED").."; last_invalidation="..tostring(self.invalidationReason or "INITIAL")
  .."; startup_layer_passes="..tostring(self.startupLayerPasses or 0)
  .."; model_settle="..tostring(self.modelSettleStatus or "NOT_NEEDED").."; model_settle_attempts="..tostring(self.modelSettleAttempts or 0)
  .."; model_settle_refreshes="..tostring(self.modelSettleRefreshes or 0)
  .."; native_manager="..tostring(self.managerState or "UNKNOWN").."; native_clamped="..tostring(self.native and public(self.native,"IsClampedToScreen","boolean"))
  .."; scroll_offset="..tostring(self.offset or 0).."; content_height="..tostring(self.contentHeight or "UNKNOWN")
  .."; viewport_height="..tostring(self.viewportHeight or "UNKNOWN").."; scroll_receipt="..tostring(self.scrollStatus or "NOT_RUN")
  .."; truncated_families="..(#(self.truncatedFamilies or {})>0 and table.concat(self.truncatedFamilies,",") or "NONE").."; native=NOT_RUN"
end
