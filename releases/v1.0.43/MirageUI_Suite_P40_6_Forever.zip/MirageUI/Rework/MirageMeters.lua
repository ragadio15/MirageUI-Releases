local _,M=...
-- P21 owns the presentation; C_DamageMeter owns collection, pet attribution,
-- session boundaries, rankings and retained history. No native child is moved,
-- reskinned, reparented or given an addon input handler.
local R,S,L,D=M.Rework,M.Safety,M.Rework.CombatLeases,M.MirageMeterData
local P={id="meters",module="DamageMeters",runtimeInterval=.20,nativeRoots={DamageMeter=true},layoutIDs={["DamageMeters.mirage"]=true},
 roots={},surfaces={},rows={},events={ADDON_LOADED=true,PLAYER_ENTERING_WORLD=true,PLAYER_LEAVING_WORLD=true,
 PLAYER_REGEN_DISABLED=true,PLAYER_REGEN_ENABLED=true,DAMAGE_METER_COMBAT_SESSION_UPDATED=true,
 DAMAGE_METER_CURRENT_SESSION_UPDATED=true,DAMAGE_METER_RESET=true,DISPLAY_SIZE_CHANGED=true,
 UI_SCALE_CHANGED=true,CVAR_UPDATE=true,EDIT_MODE_LAYOUTS_UPDATED=true},status="NOT_INITIALIZED"}
R.CombatMeters=P;R.MirageMeters=P
local WHITE="Interface\\Buttons\\WHITE8X8"
local FONT="Fonts\\FRIZQT__.TTF"
local COMPACT_HEADER=28
local HEADER_DURATION=.18
local HEADER_EXIT_DELAY=.30
local function color(key,fallback) return M.Theme and M.Theme[key] or fallback end
local function accent() return color("accent",{.91,.55,.18,1}) end
local function muted() return color("muted",{.63,.62,.60,1}) end
local function cfg() return M.profile and M.profile.modules and M.profile.modules.DamageMeters or {} end
local function chosen() return R:Qualified() and R:Selected("meters") and not M.state.safe and cfg().enabled~=false end
local function result(kind,reason) return R:Result(kind,reason) end
local function call(o,name,...)
 if not S:Frame(o,false) then return false end
 local fn=L:Field(o,name);if type(fn)~="function" then return false end
 return pcall(fn,o,...)
end
local function read(o,name,kind,...) return L:Public(o,name,kind,...) end
local function ownedFrame(kind,parent,key,name,template)
 parent.mirageMeterFrames=parent.mirageMeterFrames or {}
 local f=parent.mirageMeterFrames[key]
 if not f then f=CreateFrame(kind,name,parent,template);parent.mirageMeterFrames[key]=f end
 return f
end
local function ownedTexture(parent,key,layer)
 parent.mirageMeterTextures=parent.mirageMeterTextures or {}
 local texture=parent.mirageMeterTextures[key]
 if not texture then texture=parent:CreateTexture(nil,layer);parent.mirageMeterTextures[key]=texture end
 return texture
end
local function font(parent,size,align,key)
 parent.mirageMeterFonts=parent.mirageMeterFonts or {}
 local f=parent.mirageMeterFonts[key]
 if not f then f=parent:CreateFontString(nil,"OVERLAY");parent.mirageMeterFonts[key]=f end
 f:SetFont(M.Theme and M.Theme.font or STANDARD_TEXT_FONT or M.Visual and M.Visual.font or FONT,size,"");f:SetTextColor(unpack(color("text",{.90,.89,.87,1})))
 f.mirageMeterTextLayout=nil
 f:SetJustifyH(align or "LEFT");f:SetJustifyV("MIDDLE");f:SetText("")
 if f.SetWordWrap then f:SetWordWrap(false) end
 return f
end
local function button(parent,text,w,h,key)
 local f=ownedFrame("Button",parent,key,nil,"BackdropTemplate")
 f:SetSize(w,h);M.UI:Backdrop(f,true)
 f.label=font(f,11,"CENTER","label");f.label:SetAllPoints();f.label:SetText(text)
 local gloss=ownedTexture(f,"gloss","BORDER");gloss:SetAllPoints(f);gloss:SetTexture("Interface\\AddOns\\MirageUI\\Media\\ButtonGloss.tga")
 if gloss.SetVertexColor then gloss:SetVertexColor(.96,.79,.36,.22) end
 local stripe=ownedTexture(f,"stripe","OVERLAY");stripe:SetColorTexture(unpack(accent()))
 stripe:ClearAllPoints();stripe:SetPoint("TOPLEFT",f,"TOPLEFT",1,-3);stripe:SetPoint("BOTTOMLEFT",f,"BOTTOMLEFT",1,3);stripe:SetWidth(2);stripe:Hide()
 f:SetScript("OnEnter",function(self)
  self:SetBackdropColor(unpack(color("hover",{.15,.12,.08,.98})));self:SetBackdropBorderColor(unpack(accent()));stripe:Show()
  if gloss.SetVertexColor then gloss:SetVertexColor(.96,.79,.36,.58) end
 end)
 f:SetScript("OnLeave",function(self)
  self:SetBackdropColor(unpack(color("panel",{.060,.060,.065,.97})));self:SetBackdropBorderColor(unpack(color("edge",{.26,.26,.26,1})));stripe:Hide()
  if gloss.SetVertexColor then gloss:SetVertexColor(.96,.79,.36,.22) end
 end)
 return f
end
local function dropdown(parent,text,key)
 local f=button(parent,text,140,24,key)
 -- A quiet one-pixel outline distinguishes a selector without competing with
 -- the report. Its hover treatment is local; shared menu chrome is untouched.
 f.mirageMeterDropdown=true
 local function paint(hover)
  local edge=color("edge",{.26,.26,.26,1});local bg=color("panel",{.060,.060,.065,.97})
  f:SetBackdropBorderColor(edge[1],edge[2],edge[3],hover and .72 or .38)
  f:SetBackdropColor(bg[1],bg[2],bg[3],(bg[4] or 1)*(key=="mode" and 1 or .8))
  if f.mirageMeterTextures.gloss then f.mirageMeterTextures.gloss:Hide() end
  if f.mirageMeterTextures.stripe then f.mirageMeterTextures.stripe:Hide() end
 end
 f:SetScript("OnEnter",function() paint(true) end);f:SetScript("OnLeave",function() paint(false) end);paint(false)
 f.label:ClearAllPoints();f.label:SetPoint("LEFT",9,0);f.label:SetPoint("RIGHT",-24,0);f.label:SetJustifyH("LEFT")
 -- Two small, pixel-snapped strokes keep the affordance crisp at any scale;
 -- the dropdown never depends on unrelated Blizzard button artwork or fonts.
 f.chevron=f.chevron or {}
 for i=1,2 do
  local line=ownedTexture(f,"chevron"..i,"OVERLAY");f.chevron[i]=line
  line:SetColorTexture(unpack(color("secondary",{.96,.79,.36,1})));line:SetSize(6,1.5)
  line:ClearAllPoints();line:SetPoint("RIGHT",f,"RIGHT",i==1 and -14 or -10,0)
  call(line,"SetRotation",i==1 and -math.pi/4 or math.pi/4)
  call(line,"SetSnapToPixelGrid",true);call(line,"SetTexelSnappingBias",0)
 end
 return f
end
local function textHeight(label,text,width,size)
 width=math.max(1,width)
 -- This is a one-entry cache on an owned font, never a retained combat-data
 -- cache. Opaque values always go through the engine measurement path and
 -- are not compared, hashed, converted or used as keys.
 local public=S:Text(text);local cached=label.mirageMeterTextLayout
 local fontOK,face,fontSize,flags=call(label,"GetFont")
 local knownFont=fontOK and S:Text(face) and S:Number(fontSize) and S:Readable(flags) and (flags==nil or S:Text(flags))
 if public and knownFont and cached and cached.text==text and cached.width==width and cached.size==size
  and cached.face==face and cached.fontSize==fontSize and cached.flags==flags then return cached.height end
 label:SetWidth(width)
 call(label,"SetWordWrap",true);call(label,"SetNonSpaceWrap",true);call(label,"SetMaxLines",0)
 local height=read(label,"GetStringHeight","number")
 local measured=height and height>0
 if not height or height<=0 then
  -- Only public strings participate in fallback measurement. Opaque text is
  -- still sent directly to the engine's permitted font sink, never inspected.
  local length=S:Text(text) and #text:gsub("[\128-\191]","") or 24
  height=math.max(size+2,math.ceil(length*size*.62/math.max(1,width))*(size+2))
 end
 label:SetHeight(height)
 label.mirageMeterTextLayout=public and knownFont and measured and {text=text,width=width,size=size,height=height,face=face,fontSize=fontSize,flags=flags} or nil
 return height
end
function P:PaintChrome()
 local f=self.frame or self.buildFrame;if not f then return end
 local bg=color("background",{.035,.035,.038,.98});local alpha=math.max(0,math.min(1,bg[4] or 1));local body=alpha*.8
 f:SetBackdropColor(bg[1],bg[2],bg[3],body)
 self.headerBackground=self.headerBackground or ownedTexture(f,"headerBackground","BACKGROUND")
 self.headerBackground:ClearAllPoints();self.headerBackground:SetPoint("TOPLEFT",1,-1);self.headerBackground:SetPoint("TOPRIGHT",-1,-1)
 self.headerBackground:SetHeight(self.minimized and 40 or math.min(40,self.headerHeight or COMPACT_HEADER)-1)
 -- Source-over composition restores the original header opacity exactly.
 self.headerBackground:SetColorTexture(bg[1],bg[2],bg[3],(alpha-body)/math.max(.0001,1-body))
 self.headerOpacity=alpha;self.bodyOpacity=body
 for _,art in ipairs({f.miragePanelShine,f.miragePanelGlass}) do call(art,"SetAlpha",.8) end
end
local function slimScroll(parent,key,changed)
 local f=ownedFrame("Slider",parent,key);f:SetWidth(11);f:EnableMouse(true);f:EnableMouseWheel(true)
 call(f,"SetOrientation","VERTICAL");call(f,"SetValueStep",1);call(f,"SetObeyStepOnDrag",false)
 local track=ownedTexture(f,"track","BACKGROUND");track:SetColorTexture(unpack(color("panel",{.060,.060,.065,.97})))
 track:ClearAllPoints();track:SetPoint("TOP",0,0);track:SetPoint("BOTTOM",0,0);track:SetWidth(3)
 call(f,"SetThumbTexture",WHITE)
 f.thumb=read(f,"GetThumbTexture") or ownedTexture(f,"thumb","OVERLAY")
 call(f.thumb,"SetTexture",WHITE);call(f.thumb,"SetVertexColor",unpack(accent()));call(f.thumb,"SetWidth",3)
 f:SetScript("OnValueChanged",function(_,value)
  if not f.syncing and S:Number(value) then changed(value) end
 end)
 f:SetScript("OnMouseWheel",function(_,delta)
  if S:Number(delta) then changed((f.position or 0)-delta*(f.wheelStep or 1)) end
 end)
 f:Hide();return f
end
local function scrollState(f,offset,range,viewport,content)
 if not f then return end
 offset=math.max(0,math.min(range,offset));f.syncing=true
 if f.range~=range then f:SetMinMaxValues(0,math.max(1,range));f.range=range end
 if f.position~=offset then f:SetValue(offset);f.position=offset end
 local height=math.max(18,viewport*math.min(1,viewport/math.max(1,content)))
 height=math.min(viewport,height)
 if f.thumbHeight~=height then call(f.thumb,"SetHeight",height);f.thumbHeight=height end
 f.syncing=nil;if read(f,"IsShown","boolean")~=(range>0) then f:SetShown(range>0) end
end
local function over(f)
 if not f or read(f,"IsVisible","boolean")~=true then return false end
 local inside,state=read(f,"IsMouseOver","boolean")
 if state=="KNOWN" then return inside end
 return S:Public(MouseIsOver,"boolean",f)
end
-- P28 keeps the report body in place while its two control lines unfold above
-- it. Only owned geometry changes; the authored layout and native collection
-- are unaffected. The visible root is observed without a full-panel mouse
-- blocker, so empty space retains the existing game input behavior.
function P:HeaderWanted()
 if self.minimized then return false end
 if M.state.edit==true then return true end
 if self.popup and self:PopupOwned(self.popup) and read(self.popup.frame,"IsVisible","boolean")==true then return true end
 if S:Now()<(self.headerInspectUntil or 0) then return true end
 if over(self.frame)==true or over(self.rowsHost)==true then return true end
 for _,frame in ipairs({self.modeButton,self.sessionButton,self.menuButton,self.minButton,self.backButton,self.rowScroll}) do
  if over(frame)==true then return true end
 end
 for _,row in ipairs(self.rows) do if over(row)==true then return true end end
 return false
end
function P:ResetHeader()
 self.headerProgress=M.state.edit==true and 1 or 0;self.headerTarget=self.headerProgress
 self.headerLeaveAt=nil;self.headerPoll=0;self.headerInspectUntil=nil;self.headerHeight=nil
end
function P:UpdateHeader(elapsed)
 if not self.active or not self.frame or read(self.frame,"IsVisible","boolean")~=true then return end
 elapsed=S:Number(elapsed) and math.max(0,math.min(.10,elapsed)) or 0
 self.headerPoll=(self.headerPoll or 0)+elapsed
 local moving=self.headerProgress~=self.headerTarget
 if self.headerPoll>=.05 or moving or M.state.edit==true then
  self.headerPoll=0
  local now=S:Now();local wanted=self:HeaderWanted()
  if wanted then self.headerLeaveAt=nil;self.headerTarget=1
  elseif self.minimized then self.headerLeaveAt=nil;self.headerTarget=0
  elseif self.headerTarget==1 then
   self.headerLeaveAt=self.headerLeaveAt or now
   if now-self.headerLeaveAt>=HEADER_EXIT_DELAY then self.headerTarget=0 end
  end
 end
 local before=self.headerProgress or 0;local target=self.headerTarget or 0
 local reduced=M.StartupAnimation and M.StartupAnimation.GetPreference and M.StartupAnimation:GetPreference("reduceMotion")==true
 if M.state.edit==true or reduced or self.minimized then self.headerProgress=target
 elseif before<target then self.headerProgress=math.min(target,before+elapsed/HEADER_DURATION)
 elseif before>target then self.headerProgress=math.max(target,before-elapsed/HEADER_DURATION) end
 if self.headerProgress~=before and self.snapshot then self:Render(self.snapshot) end
end
local function points(f)
 local list={};local n=read(f,"GetNumPoints","number")
 if not n or n<0 or n>8 then return nil end
 for i=1,n do
  local method=L:Field(f,"GetPoint");if type(method)~="function" then return nil end
  local ok,p=pcall(function() return {method(f,i)} end)
  if not ok then return nil end
  for _,v in pairs(p) do if not S:Readable(v) then return nil end end
  list[i]=p
 end
 return list
end
local function samePoints(f,expected)
 local actual=points(f)
 if not expected or not actual or #actual~=#expected then return false end
 for i,p in ipairs(expected) do for k=1,5 do if actual[i][k]~=p[k] then return false end end end
 return true
end
function P:PopupOwned(t,hidden)
 if not t or M.UI~=t.ui or t.frame.mirageMeterPopup~=t then return false end
 if t.kind=="choice" then
  return t.ui.choices==t.frame and (t.frame.choiceToken==t.identity or hidden and t.frame.choiceToken==nil and read(t.frame,"IsShown","boolean")==false)
 elseif t.kind=="copy" then
  return t.ui.copy==t.frame and t.ui.copyRequest==t.request and (t.ui.copyToken==t.identity or hidden and t.ui.copyToken==nil and read(t.frame,"IsShown","boolean")==false)
 elseif t.kind=="hint" then return GameTooltip==t.frame and read(t.frame,"GetOwner")==t.anchor end
 return false
end
function P:RestorePopup(t)
 if not t or t.restoring then return end
 t.restoring=true
 -- The shared copy window can be reused without first hiding. Its new text
 -- request must retire our observer, while still returning our unchanged
 -- cosmetic properties and hook to the shared owner. No payload is restored.
 local function current()
  return M.UI==t.ui and t.frame.mirageMeterPopup==t
   and (t.kind=="choice" and t.ui.choices==t.frame or t.kind=="copy" and t.ui.copy==t.frame
    or t.kind=="hint" and GameTooltip==t.frame)
 end
 local function write(o,method,...) if current() then return call(o,method,...) end end
 if current() and read(t.frame,"GetScript",nil,"OnHide")==t.hideScript then write(t.frame,"SetScript","OnHide",t.previousHide) end
 if t.scroll and current() then
  if read(t.scroll,"GetScript",nil,"OnMouseWheel")==t.wheelScript then write(t.scroll,"SetScript","OnMouseWheel",t.previousWheel) end
  if t.wheelEnabled~=nil then write(t.scroll,"EnableMouseWheel",t.wheelEnabled) end
  if t.scrollPoints and samePoints(t.scroll,t.appliedScrollPoints) then
   write(t.scroll,"ClearAllPoints");for _,p in ipairs(t.scrollPoints) do write(t.scroll,"SetPoint",unpack(p)) end
  end
  if t.rail then write(t.rail,"Hide") end
  if t.stock then write(t.stock,"SetShown",t.stockShown) end
 end
 if t.width and read(t.frame,"GetWidth","number")==t.appliedWidth then write(t.frame,"SetWidth",t.width) end
 if t.height and read(t.frame,"GetHeight","number")==t.appliedHeight then write(t.frame,"SetHeight",t.height) end
 if t.childWidth and read(t.child,"GetWidth","number")==t.appliedRowWidth then write(t.child,"SetWidth",t.childWidth) end
 for row,width in pairs(t.rowWidths or {}) do if read(row,"GetWidth","number")==t.appliedRowWidth then write(row,"SetWidth",width) end end
 for label,width in pairs(t.labelWidths or {}) do if read(label,"GetWidth","number")==t.appliedLabelWidth then write(label,"SetWidth",width) end end
 if current() then t.frame.mirageMeterPopup=nil end
 t.restoring=nil
end
function P:DismissPopup(reason)
 local t=self.popup;if not t then return false end
 local owned=self:PopupOwned(t,true)
 self:RestorePopup(t)
 if self.popup==t then self.popup=nil;self.popupCloseReason=reason end
 -- Restoration can itself yield to a newer shared-dialog request. Recheck the
 -- original request before hiding anything; a successor keeps its own input.
 local same=M.UI==t.ui and (t.kind=="choice" and t.ui.choices==t.frame and t.frame.choiceToken==t.identity
  or t.kind=="copy" and t.ui.copy==t.frame and t.ui.copyToken==t.identity and t.ui.copyRequest==t.request
  or t.kind=="hint" and GameTooltip==t.frame and read(t.frame,"GetOwner")==t.anchor)
 if owned and same then call(t.frame,"Hide") end
 if t.kind=="hint" and self.tooltipAnchor==t.anchor then self:ForgetTooltip() end
 if not self.popup and self.popupObserver then call(self.popupObserver,"Hide") end
 return owned
end
function P:PopupOutsideClick()
 local t=self.popup;if not t or not self:PopupOwned(t) then return end
 if over(t.frame)==true or t.anchor and over(t.anchor)==true then return end
 self:DismissPopup("OUTSIDE_CLICK")
end
function P:SyncPopup(t)
 if not self:PopupOwned(t) then return end
 if t.scroll then
  local viewport=read(t.scroll,"GetHeight","number") or 0
  local range=read(t.scroll,"GetVerticalScrollRange","number")
  if not range then range=math.max(0,(read(t.child,"GetHeight","number") or 0)-viewport) end
  local offset=read(t.scroll,"GetVerticalScroll","number") or 0
  if t.stock and read(t.stock,"IsShown","boolean")==true then call(t.stock,"Hide") end
  if viewport>0 then scrollState(t.rail,offset,math.max(0,range),viewport,viewport+range) end
 end
end
function P:PopupObserver()
 if self.popupObserver then return self.popupObserver end
 local f=ownedFrame("Frame",UIParent,"meterPopupObserver","MirageUIMeterPopupObserver")
 self.popupObserver=f;f:EnableMouse(false);f:EnableKeyboard(false);f:Hide()
 -- This zero-input observer is an Escape participant, not a full-screen
 -- mouse blocker. Clicking the world or another native control still reaches it.
 if type(UISpecialFrames)=="table" then table.insert(UISpecialFrames,"MirageUIMeterPopupObserver") end
 call(f,"RegisterEvent","GLOBAL_MOUSE_DOWN")
 f:SetScript("OnEvent",function(_,event) if event=="GLOBAL_MOUSE_DOWN" then self:PopupOutsideClick() end end)
 f:SetScript("OnHide",function() if self.popup then self:DismissPopup("ESCAPE") end end)
 f:SetScript("OnUpdate",function()
  local t=self.popup;if not t then return end
  if not self:PopupOwned(t) or read(t.frame,"IsVisible","boolean")~=true or not self:InteractionCurrent(t.view) then
   self:DismissPopup("OWNER_RETIRED");return
  end
  local down=S:Public(IsMouseButtonDown,"boolean")
  if down==true and t.mouseDown~=true then self:PopupOutsideClick() end
  t.mouseDown=down
  if self.popup==t then self:SyncPopup(t) end
 end)
 return f
end
function P:ObservePopup(f,kind,anchor,scroll,child)
 if not f or read(f,"IsVisible","boolean")~=true then return end
 self:DismissPopup("REPLACED")
 local t={frame=f,kind=kind,anchor=anchor,ui=M.UI,view=self:InteractionToken(anchor),scroll=scroll,child=child,
  identity=kind=="choice" and f.choiceToken or kind=="copy" and M.UI.copyToken or anchor,request=M.UI.copyRequest}
 if not t.identity then return end
 self.popup=t;f.mirageMeterPopup=t;t.mouseDown=S:Public(IsMouseButtonDown,"boolean")
 t.previousHide=read(f,"GetScript",nil,"OnHide")
 t.hideScript=function(...)
  local identity=kind=="choice" and f.choiceToken or kind=="copy" and t.ui.copyToken or read(f,"GetOwner")
  self:RestorePopup(t)
  if self.popup==t then self.popup=nil end
  if not self.popup and self.popupObserver then call(self.popupObserver,"Hide") end
  -- Run the original cleanup only for the hidden request that invoked us.
  -- Never clear a reentrant successor's choice/copy token.
  local same=kind=="choice" and f.choiceToken==identity or kind=="copy" and t.ui.copyToken==identity or kind=="hint" and read(f,"GetOwner")==identity
  if same and read(f,"IsShown","boolean")==false and type(t.previousHide)=="function" then t.previousHide(...) end
 end
 f:SetScript("OnHide",t.hideScript)
 if scroll then
  t.scrollPoints=points(scroll);t.stock=L:Field(scroll,"ScrollBar");t.stockShown=t.stock and read(t.stock,"IsShown","boolean")==true
  t.previousWheel=read(scroll,"GetScript",nil,"OnMouseWheel");t.wheelEnabled=read(scroll,"IsMouseWheelEnabled","boolean")
  local function move(value)
   if self.popup~=t or not self:PopupOwned(t) or not self:InteractionCurrent(t.view) then return end
   local range=t.rail and t.rail.range or 0
   call(scroll,"SetVerticalScroll",math.max(0,math.min(range,value)));self:SyncPopup(t)
  end
  t.rail=slimScroll(f,"popupScroll",move);t.rail.wheelStep=30;t.rail:ClearAllPoints()
  if kind=="copy" then
   -- The shared Copy chrome may have fitted a larger heading/navigation row.
   -- Follow its existing viewport; changing those points would invalidate its
   -- own text-scale receipt or crowd the transfer controls.
   t.rail:SetPoint("TOPLEFT",scroll,"TOPRIGHT",5,0);t.rail:SetPoint("BOTTOMLEFT",scroll,"BOTTOMRIGHT",5,0)
  else t.rail:SetPoint("TOPRIGHT",-4,-7);t.rail:SetPoint("BOTTOMRIGHT",-4,7) end
  t.wheelScript=function(_,delta) if S:Number(delta) then move((read(scroll,"GetVerticalScroll","number") or 0)-delta*30) end end
  scroll:EnableMouseWheel(true);scroll:SetScript("OnMouseWheel",t.wheelScript)
  if t.stock then call(t.stock,"Hide") end
  if kind=="choice" then
   scroll:ClearAllPoints();scroll:SetPoint("TOPLEFT",6,-6);scroll:SetPoint("BOTTOMRIGHT",-18,6);t.appliedScrollPoints=points(scroll)
   t.width=read(f,"GetWidth","number");t.height=read(f,"GetHeight","number");t.childWidth=read(child,"GetWidth","number");t.rowWidths={};t.labelWidths={}
   local screen,screenHeight=M.Layout:Screen();local width=math.min(330,math.max(240,self.renderWidth or 320),screen and screen-24 or 330)
   f:SetWidth(width);if screenHeight and t.height then f:SetHeight(math.min(t.height,math.max(60,screenHeight-24))) end
   child:SetWidth(width-24)
   for _,row in ipairs(f.rows or {}) do
    t.rowWidths[row]=read(row,"GetWidth","number");row:SetWidth(width-24)
    if row.label then t.labelWidths[row.label]=read(row.label,"GetWidth","number");row.label:SetWidth(width-40) end
   end
   t.appliedWidth=width;t.appliedHeight=read(f,"GetHeight","number");t.appliedRowWidth=width-24;t.appliedLabelWidth=width-40
  end
  self:SyncPopup(t)
 end
 if self:PopupOwned(t) then self:PopupObserver():Show() end
end
function P:Choose(anchor,values,current,callback)
 local view=self:InteractionToken(anchor);if not self:InteractionCurrent(view) then return end
 if self.popup and self.popup.anchor==anchor and self:PopupOwned(self.popup) then self:DismissPopup("TOGGLE");return end
 self:DismissPopup("REPLACED")
 local ui=M.UI;ui:Choose(anchor,values,current,callback)
 local f=ui.choices
 if M.UI==ui and self:InteractionCurrent(view) and f then self:ObservePopup(f,"choice",anchor,f.scroll,f.child) end
end
function P:Current(generation,profile,view)
 return self.active and generation==self.generation and self.profile==profile and M.profile==profile and chosen()
  and cfg().metersEnabled~=false and R:NativeEditState()=="CLOSED" and not self.releasing
  and (view==nil or view==(self.viewRevision or 0))
end
function P:Mode() return self.runtimeMode~=nil and self.runtimeMode or cfg().meterMode or 0 end
function P:Session() return self.runtimeSession~=nil and self.runtimeSession or cfg().metersSession or 1 end
-- A retained menu/tooltip belongs to one configured view. A profile or fight
-- change must not let its delayed callback mutate a newer view.
function P:InteractionToken(anchor)
 return {generation=self.generation,profile=self.profile,view=self.viewRevision or 0,anchor=anchor}
end
function P:InteractionCurrent(token)
 return token and self:Current(token.generation,token.profile) and token.view==(self.viewRevision or 0)
  and self:CanShow() and (not token.anchor or read(token.anchor,"IsVisible","boolean")==true)
end
function P:OwnsTooltip()
 return self.tooltipShown and self.tooltipAnchor and S:Frame(GameTooltip,false)
  and read(GameTooltip,"GetOwner")==self.tooltipAnchor
end
function P:ForgetTooltip()
 self.tooltipShown=nil;self.tooltipAnchor=nil;self.tooltipTitle=nil;self.tooltipBody=nil;self.inspectedRow=nil
end
function P:HideTooltip()
 if self:OwnsTooltip() then call(GameTooltip,"Hide") end
 self:ForgetTooltip()
end
function P:Hint(anchor,title,body)
 if not self.active or M.state.trackerWorkspace or M.state.keybindWorkspace or not S:Frame(GameTooltip,false) then return false end
 local generation,profile,view=self.generation,self.profile,self.viewRevision or 0
 local function current() return self:Current(generation,profile,view) and read(GameTooltip,"GetOwner")==anchor end
 local function failed()
  -- A native setter may fail after assigning this owner. Withdraw only that
  -- partial hint; a newer foreign owner must retain its tooltip.
  if read(GameTooltip,"GetOwner")==anchor then call(GameTooltip,"Hide") end
  if self.tooltipAnchor==anchor or not self:OwnsTooltip() then self:ForgetTooltip() end
  return false
 end
 if not call(GameTooltip,"SetOwner",anchor,"ANCHOR_LEFT") or not current() then return failed() end
 local r,g,b=unpack(accent())
 if not call(GameTooltip,"SetText",title,r,g,b) or not current() then return failed() end
 r,g,b=unpack(color("text",{.90,.89,.87,1}))
 if body and (not call(GameTooltip,"AddLine",body,r,g,b,true) or not current()) then return failed() end
 if not call(GameTooltip,"Show") or not current() then return failed() end
 self.tooltipShown=true;self.tooltipAnchor=anchor;self.tooltipTitle=title;self.tooltipBody=body;self.inspectedRow=nil
 return true
end
function P:Inspect(row,anchor,refresh)
 if not row then return self:HideTooltip() end
 if refresh and not self:OwnsTooltip() then return self:HideTooltip() end
 local title=row.publicName or "Meter entry"
 local mode=self.snapshot and self.snapshot.mode or D:Mode(self:Mode())
 local lines={}
 -- Only public values become tooltip text. Opaque values continue to use the
 -- native number/font sinks in the row, without string conversion here.
 if row.amount and row.amount.state=="PUBLIC" then lines[#lines+1]="Total: "..D:FormatPublic(row.amount.value) end
 if mode and mode.rateLabel and row.rate and row.rate.state=="PUBLIC" then lines[#lines+1]=mode.rateLabel..": "..D:FormatPublic(row.rate.value) end
 if row.spellID then
  lines[#lines+1]="Spell ID "..row.spellID
  if row.avoidable then lines[#lines+1]="Avoidable" end
  if row.deadly then lines[#lines+1]="Killing blow" end
 elseif row.guid or row.creatureID then lines[#lines+1]="Click for the ability breakdown."
 else lines[#lines+1]="Ability details will appear when available." end
 if row.overkill and row.overkill.state=="PUBLIC" and row.overkill.value>0 then lines[#lines+1]="Overkill: "..D:FormatPublic(row.overkill.value) end
 local body=table.concat(lines,"\n")
 if refresh and self.tooltipTitle==title and self.tooltipBody==body then return true end
 if self:Hint(anchor,title,body) then self.inspectedRow=anchor;return true end
end
function P:RefreshRowTooltip()
 local anchor=self.inspectedRow
 if not anchor then return end
 if self.minimized or not self:CanShow() or not anchor.data then self:HideTooltip()
 else self:Inspect(anchor.data,anchor,true) end
end
function P:ClearView()
 self:DismissPopup("VIEW_CHANGED")
 self.viewRevision=(self.viewRevision or 0)+1
 self.actor=nil;self.offset=0;self.snapshot=nil;self.dataDirty=true;self.resetArmed=nil
 D:Invalidate("VIEW_CHANGED");self:HideTooltip()
end
function P:SetPreference(key,value)
 if not self.active or self.profile~=M.profile then return end
 self.preferenceRevision=(self.preferenceRevision or 0)+1
 self.pendingPreferences=self.pendingPreferences or {};self.pendingPreferences[key]=value;self.preferenceSaveFailed=nil
 if key=="meterMode" then self.runtimeMode=value elseif key=="metersSession" then self.runtimeSession=value;self.sessionID=nil end
 self:ClearView()
end
function P:CommitPreferences()
 if not self.pendingPreferences or self.preferenceSaveFailed or S:InCombat() or self.profile~=M.profile then return nil end
 local pending,profile,revision=self.pendingPreferences,self.profile,self.preferenceRevision
 local draft=M:Copy(profile)
 for key,value in pairs(pending) do draft.modules.DamageMeters[key]=value end
 local okay,why=false,"Preferences cannot be saved right now."
 if M.Profiles and type(M.Profiles.Commit)=="function" then okay,why=M.Profiles:Commit(draft) end
 if okay then
  if self.pendingPreferences==pending then self.pendingPreferences=nil end
  if self.preferenceRevision==revision then self.preferenceSaveFailed=nil end
  return true
 end
 -- Keep failed choices for an explicit Refresh/new selection, without retrying
 -- a rejected transaction on every meter tick or claiming it was saved.
 -- Profiles:Commit provisionally applies a detached candidate, then applies
 -- the original again on a late failure. Both Configure calls retire pending
 -- state. Recover this request only after that exact original owner returns;
 -- a newer explicit choice or a real profile handoff owns its own state.
 if self.active and self.profile==profile and M.profile==profile and self.preferenceRevision==revision
  and (self.pendingPreferences==nil or self.pendingPreferences==pending) then
  self.pendingPreferences=pending
  if pending.meterMode~=nil then self.runtimeMode=pending.meterMode end
  if pending.metersSession~=nil then self.runtimeSession=pending.metersSession;self.sessionID=nil end
  self:ClearView()
  self.preferenceSaveFailed=true
  self.notice="Not saved. Refresh to retry.";self.dataDirty=true
 end
 return false,S:Text(why) and why or "Preferences could not be saved."
end
function P:ChooseMode()
 if not self.active then return end
 local token=self:InteractionToken(self.modeButton)
 self:Choose(self.modeButton,D:Modes(),self:Mode(),function(value) if self:InteractionCurrent(token) then self:SetPreference("meterMode",value) end end)
end
function P:ChooseSession()
 if not self.active then return end
 local token=self:InteractionToken(self.sessionButton)
 local values={{value="current",label="Current fight · automatic"},{value="overall",label="Overall"}}
 local sessions=D:Sessions()
 -- Preserve the client's retained-session order, as its native menu does.
 for _,entry in ipairs(sessions) do
  local label=entry.name
  if S:Number(entry.duration) and entry.duration>=0 then label=label..string.format(" · %d:%02d",math.floor(entry.duration/60),math.floor(entry.duration%60)) end
  values[#values+1]={value=entry.id,label=label}
 end
 local selected=self.sessionID or (self:Session()==0 and "overall" or "current")
 if not self:InteractionCurrent(token) then return end
 self:Choose(self.sessionButton,values,selected,function(value)
  if not self:InteractionCurrent(token) then return end
  if value=="current" or value=="overall" then self:SetPreference("metersSession",value=="overall" and 0 or 1)
  elseif S:Number(value) then self.sessionID=value;self:ClearView() end
 end)
end
function P:ResetHistory()
 if not self.active or self.profile~=M.profile then return false end
 if S:InCombat() then self.notice="Reset is available after combat.";return false end
 local now=S:Now()
 if not self.resetArmed or now>self.resetArmed then
  self.resetArmed=now+8;self.notice="Choose Reset again to clear all game meter history.";return false
 end
 self.resetArmed=nil
 if not C_DamageMeter or type(C_DamageMeter.ResetAllCombatSessions)~="function" then self.notice="The game cannot reset meter history here.";return false end
 local generation,profile=self.generation,self.profile
 local ok=pcall(C_DamageMeter.ResetAllCombatSessions)
 if not self:Current(generation,profile) then return ok end
 if ok then
  -- The resulting DAMAGE_METER_RESET event only invalidates this view. It must
  -- never trigger a second native reset (which can break native collection).
  self.viewRevision=(self.viewRevision or 0)+1
  self.sessionID=nil;self.actor=nil;self.offset=0;self.snapshot=nil
  D:Invalidate("USER_RESET");self.notice="Meter history cleared.";self.dataDirty=true
 else self.notice="The game did not accept the reset." end
 return ok
end
function P:Menu()
 local token=self:InteractionToken(self.menuButton)
 local values={{value="refresh",label="Refresh"},{value="copy",label="Copy readable results"},
  {value="reset",label=self.resetArmed and S:Now()<=self.resetArmed and "Confirm: reset all game meter history" or "Reset all game meter history…"},
  {value="help",label="How Meters works"}}
 self:Choose(self.menuButton,values,nil,function(value)
  if not self:InteractionCurrent(token) then return end
  if value=="refresh" then self:Refresh()
  elseif value=="reset" then self:ResetHistory()
  elseif value=="copy" then
   self:Paint();if not self:InteractionCurrent(token) then return end
   local text,why=D:Report(self.snapshot)
   if not self:InteractionCurrent(token) then return end
   if text then
    local ui=M.UI;local previous=ui.copyRequest;local opened=ui:CopyWindow("Meters",text)
    if opened==true and M.UI==ui and ui.copyRequest~=previous and self:InteractionCurrent(token) then
     self:ObservePopup(ui.copy,"copy",self.menuButton,ui.copyScroll,ui.copyBox)
    end
   else self.notice=why;self.dataDirty=true end
  elseif value=="help" then
   local shown=self:Hint(self.menuButton,"Meters","Collects automatically through the game meter. Choose Current for each new fight, Overall for the combined total, or a retained fight. Click a name for abilities; scroll to see more. DPS / HPS and owner / pet attribution are supplied by the game. Reset clears the shared game history. History retention and combat data availability follow the client.")
   if shown and self:OwnsTooltip() then self:ObservePopup(GameTooltip,"hint",self.menuButton) end
  end
 end)
end
function P:Create()
 if self.created then return true end
 if S:InCombat() then return false end
 -- Retain an unpublished construction graph. A failed native font/frame call
 -- resumes the same widgets on retry; it cannot admit a partial ready panel.
 local f=self.buildFrame
 if not f then f=CreateFrame("Frame","MirageUIMeters",UIParent,"BackdropTemplate");self.buildFrame=f end
 f:Hide();f:SetFrameStrata("MEDIUM");M.UI:Backdrop(f,false)
 if f.SetClampedToScreen then f:SetClampedToScreen(true) end
 self.headerChrome=ownedFrame("Frame",f,"headerChrome");self.headerChrome:SetPoint("TOPLEFT",0,0);self.headerChrome:SetPoint("TOPRIGHT",0,0);self.headerChrome:EnableMouse(false)
 self.headerClips=call(self.headerChrome,"SetClipsChildren",true)
 self.title=font(self.headerChrome,12,nil,"title");self.title:SetPoint("TOPLEFT",10,-9);self.title:SetSize(48,24);self.title:SetText("Meters");self.title:SetTextColor(unpack(accent()))
 self.compactHeader=font(f,10,nil,"compactHeader");self.compactHeader:SetPoint("TOPLEFT",10,-4);self.compactHeader:SetHeight(18);self.compactHeader:SetTextColor(unpack(muted()))
 self.compactChevron={}
 for i=1,2 do
  local line=ownedTexture(f,"compactChevron"..i,"OVERLAY");self.compactChevron[i]=line;line:SetColorTexture(unpack(accent()));line:SetSize(5,1.5)
  line:ClearAllPoints();line:SetPoint("TOPRIGHT",f,"TOPRIGHT",i==1 and -16 or -13,-12)
  call(line,"SetRotation",i==1 and -math.pi/4 or math.pi/4);call(line,"SetSnapToPixelGrid",true);call(line,"SetTexelSnappingBias",0)
 end
 self.menuButton=button(f,"···",24,24,"menu");self.menuButton:SetPoint("BOTTOMRIGHT",-38,9);self.menuButton:SetScript("OnClick",function() self:Menu() end)
 self.minButton=button(f,"−",24,24,"minimize");self.minButton:SetPoint("BOTTOMRIGHT",-10,9)
 self.minButton:SetScript("OnClick",function()
  if self.active then self:DismissPopup("MINIMIZED");self.minimized=not self.minimized;self.layoutDirty=true;self.dataDirty=true;self:HideTooltip();self:ApplyLayout() end
 end)
 self.modeButton=dropdown(self.headerChrome,"Damage","mode");self.modeButton:SetPoint("TOPLEFT",66,-9);self.modeButton:SetScript("OnClick",function() self:ChooseMode() end)
 self.reportsTitle=font(self.headerChrome,11,nil,"reportsTitle");self.reportsTitle:SetPoint("TOPLEFT",10,-46);self.reportsTitle:SetSize(48,24);self.reportsTitle:SetText("Reports");self.reportsTitle:SetTextColor(unpack(color("secondary",{.96,.79,.36,1})))
 self.sessionButton=dropdown(self.headerChrome,"Current fight","session");self.sessionButton:SetPoint("TOPLEFT",66,-46);self.sessionButton:SetScript("OnClick",function() self:ChooseSession() end)
 self.backButton=button(f,"‹ Players",74,20,"back");self.backButton:SetPoint("TOPLEFT",9,-71);self.backButton:Hide()
 self.backButton:SetScript("OnClick",function()
  if not self.active then return end
  self:DismissPopup("VIEW_CHANGED");self.viewRevision=(self.viewRevision or 0)+1;self.resetArmed=nil;self.actor=nil;self.offset=0;self.dataDirty=true;self:HideTooltip()
 end)
 self.context=font(f,10,"CENTER","context");self.context:SetPoint("TOPLEFT",10,-71);self.context:SetSize(76,20);self.context:SetTextColor(unpack(muted()))
 self.total=font(f,11,"CENTER","total");self.total:SetPoint("TOPRIGHT",-10,-71);self.total:SetSize(70,20)
 self.totalLabel=font(f,10,"CENTER","totalLabel");self.totalLabel:SetPoint("RIGHT",self.total,"LEFT",-4,0);self.totalLabel:SetSize(40,20);self.totalLabel:SetTextColor(unpack(muted()))
 self.empty=font(f,11,"CENTER","empty");self.empty:SetPoint("CENTER",0,-8);self.empty:SetWidth(280)
 if self.empty.SetWordWrap then self.empty:SetWordWrap(true) end
 self.empty:SetTextColor(unpack(muted()))
 self.noticeLabel=font(f,10,"CENTER","notice");self.noticeLabel:SetTextColor(unpack(color("secondary",{.96,.79,.36,1})));self.noticeLabel:Hide()
 self.actorLabel=font(f,11,"CENTER","actor");self.actorLabel:Hide()
 self.tableHeader=ownedFrame("Frame",f,"tableHeader");self.tableHeader:SetHeight(20)
 self.columns={}
 for _,key in ipairs({"rank","name","percent","rate","amount"}) do
  self.columns[key]=font(self.tableHeader,10,"CENTER",key);self.columns[key]:SetTextColor(unpack(muted()))
 end
 self.rowsHost=ownedFrame("Frame",f,"rowsHost");self.rowsHost:SetPoint("TOPLEFT",9,-96);self.rowsHost:SetPoint("BOTTOMRIGHT",-9,42)
 self.rowScroll=slimScroll(f,"rowsScroll",function(value)
  if not self.active or not self.snapshot or self.minimized then return end
  self.offset=math.floor(value+.5);self:Render(self.snapshot)
 end)
 self.rowScroll:SetPoint("TOPRIGHT",-4,-96);self.rowScroll:SetPoint("BOTTOMRIGHT",-4,30)
 self.rowsHost:EnableMouseWheel(true)
 self.rowsHost:SetScript("OnMouseWheel",function(_,delta)
  if not self.active or not self.snapshot then return end
  self.offset=math.max(0,math.min(self.scrollRange or 0,(self.offset or 0)-delta));self:Render(self.snapshot)
 end)
 for i=1,15 do
  local row=ownedFrame("Button",self.rowsHost,i);row:SetHeight(23);row:SetPoint("TOPLEFT",0,-(i-1)*23);row:SetPoint("TOPRIGHT",0,-(i-1)*23)
  local background=ownedTexture(row,"background","BACKGROUND");background:SetAllPoints();background:SetColorTexture(unpack(color("panel",{.060,.060,.065,.97})))
  row.fill=ownedFrame("StatusBar",row,"fill");row.fill:SetAllPoints();row.fill:SetStatusBarTexture(WHITE);row.fill:SetMinMaxValues(0,1);row.fill:SetValue(0);row.fill:EnableMouse(false)
  row.fill:SetStatusBarColor(.66,.43,.16,.30)
  local layer=ownedFrame("Frame",row,"layer");layer:SetAllPoints();layer:SetFrameLevel(row.fill:GetFrameLevel()+1);layer:EnableMouse(false)
  row.accent=ownedTexture(layer,"accent","OVERLAY");row.accent:SetColorTexture(unpack(accent()));row.accent:SetPoint("TOPLEFT",0,-1);row.accent:SetPoint("BOTTOMLEFT",0,1);row.accent:SetWidth(2);row.accent:Hide()
  row.rank=font(layer,10,"RIGHT","rank");row.rank:SetPoint("LEFT",3,0);row.rank:SetWidth(20);row.rank:SetTextColor(unpack(muted()))
  row.icon=ownedTexture(layer,"icon","ARTWORK");row.icon:SetSize(17,17);row.icon:SetPoint("LEFT",25,0);row.icon:SetTexCoord(.08,.92,.08,.92)
  row.name=font(layer,11,"CENTER","name");row.name:SetPoint("LEFT",46,0)
  row.amount=font(layer,11,"CENTER","amount");row.amount:SetPoint("RIGHT",-5,0);row.amount:SetWidth(62)
  row.rate=font(layer,11,"CENTER","rate");row.rate:SetPoint("RIGHT",row.amount,"LEFT",-5,0);row.rate:SetWidth(50)
  row.percent=font(layer,11,"CENTER","percent");row.percent:SetPoint("RIGHT",row.rate,"LEFT",-4,0);row.percent:SetWidth(38);row.percent:SetTextColor(unpack(muted()))
  row.labels={}
  for _,key in ipairs({"percent","rate","amount"}) do row.labels[key]=font(layer,9,"CENTER",key.."Label");row.labels[key]:SetTextColor(unpack(muted())) end
  row:SetScript("OnEnter",function() self:Inspect(row.data,row) end);row:SetScript("OnLeave",function() self:HideTooltip() end)
  row:SetScript("OnClick",function()
   local data=row.data
   if self.active and data and not self.actor and (data.guid or data.creatureID) then
    self:DismissPopup("VIEW_CHANGED")
    self.viewRevision=(self.viewRevision or 0)+1;self.resetArmed=nil
    self.actor={guid=data.guid,creatureID=data.creatureID,class=data.class,name=data.publicName};self.offset=0;self.dataDirty=true;self:HideTooltip()
   end
  end)
  row:Hide();self.rows[i]=row
 end
 self.frame=f
 self:ResetHeader()
 f:SetScript("OnUpdate",function(_,elapsed) self:UpdateHeader(elapsed) end)
 f:SetScript("OnHide",function() self:ResetHeader() end)
 f:SetScript("OnShow",function() if self.snapshot then self:Render(self.snapshot) end end)
 self:PaintChrome()
 self.surface=self.surface or {id="DamageMeters.mirage",label="Meters",module="DamageMeters",frame=f,security="OWNED_VISUAL",
 groups={combat=true},fallback="HIDDEN",editable=true,minWidth=240,minHeight=195,reworkProvider=self,
 layout={x=.36,y=-.32,width=320,height=310,scale=1}}
 self.surface.Intent=function() return self:Intent() end
 self.surface.Apply=function(_,alpha,state,options) return self:ApplyVisibility(state,alpha,options) end
 if not self.surfaceRegistered then M.CVE:Register(self.surface);self.surfaceRegistered=true end
 self.surfaces[self.surface.id]=self.surface
 if M.TrackRoot and not self.rootTracked then M:TrackRoot("DamageMeters",f,true);self.rootTracked=true end
 self.created=true;self.buildFrame=nil
 return true
end
function P:ApplyVisibility(state,alpha,options)
 options=options or {};local frame=self.frame
 if not S:Frame(frame,true) then return "PRESERVED" end
 local effects=M.Effects;local generation,profile=self.generation,self.profile
 local function current() return self.frame==frame and self:Current(generation,profile) and self:CanShow() end
 local available=current();local show=state~="HIDDEN" and available
 if not show then self:DismissPopup("DISPLAY_HIDDEN");self:HideTooltip() end
 if not available then
  if effects and effects.CancelTransition then effects:CancelTransition(self,frame,false) end
  frame:Hide();return "HIDDEN"
 end
 local shown=read(frame,"IsShown","boolean")
 if show and shown~=true then
  if self.hasPresented then self.dataDirty=true;self.nextUpdate=0 end
  self.hasPresented=true
 end
 local opacity=S:Number(alpha) and math.max(0,math.min(1,alpha)) or 1
 if effects and effects.Transition then
  local accepted=effects:Transition(self,frame,show,{alpha=opacity,ceiling=cfg().alpha or 1,guard=current,recipient="COMBAT",
   reason=options.reason or self.surface and self.surface.reason,urgent=options.urgent,duration=options.immediate and 0 or nil})
  if accepted then return show and "VISIBLE" or "HIDDEN" end
 end
 frame:SetAlpha(opacity);frame:SetShown(show)
 return show and "VISIBLE" or "HIDDEN"
end
function P:CanShow()
 return self.active and self.presentationReady and self.nativeSuppressed==true and self.profile==M.profile and chosen() and cfg().metersEnabled~=false
  and not M.state.trackerWorkspace and not M.state.keybindWorkspace and R:NativeEditState()=="CLOSED"
end
function P:GetMeterBounds()
 -- Actual displayed bounds in UIParent coordinates. A consumer must not use
 -- the saved layout as evidence that this contextual display is on screen.
 local f=self.frame
 local generation,profile=self.generation,self.profile
 if not self:CanShow() or self.surface and self.surface.desired=="HIDDEN" or read(f,"IsVisible","boolean")~=true then return nil end
 local opacity=read(f,"GetEffectiveAlpha","number") or read(f,"GetAlpha","number")
 if not opacity or opacity<=.01 then return nil end
 local left,right,bottom,top=read(f,"GetLeft","number"),read(f,"GetRight","number"),read(f,"GetBottom","number"),read(f,"GetTop","number")
 local scale,screenScale=read(f,"GetEffectiveScale","number"),read(UIParent,"GetEffectiveScale","number")
 if not left or not right or not bottom or not top or right<=left or top<=bottom or not scale or not screenScale or screenScale<=0 then return nil end
 if not self:Current(generation,profile) or self.frame~=f or not self:CanShow() or self.surface and self.surface.desired=="HIDDEN"
  or read(f,"IsVisible","boolean")~=true then return nil end
 local ratio=scale/screenScale
 return {left=left*ratio,right=right*ratio,bottom=bottom*ratio,top=top*ratio,frame=f,visible=true}
end
function P:Intent()
 local show=self:CanShow()
 -- Readiness does not establish combat relevance. The normal combat group,
 -- context overrides, manual visibility and explicit inspection own that
 -- decision. Only loss of presentation authority needs an immediate veto.
 if not show then return "HIDDEN","METERS_PAUSED",0 end
 -- Unknown combat relevance cannot reveal a passive meter. The surface's
 -- quiet fallback remains in force until context or an explicit choice speaks.
 return nil,"MIRAGE_METERS_CONTEXTUAL"
end
function P:RefreshVisibility()
 if not self.surface then return end
 local state=self:Intent();local alpha=cfg().alpha or 1
 -- Opacity changes are renewed through the same CVE/Effects owner so a
 -- profile edit cannot interrupt an in-progress shared contextual fade.
 if self.visibilityAlpha~=nil and self.visibilityAlpha~=alpha and self.surface.desired and self.surface.desired~="HIDDEN"
  and self.frame and read(self.frame,"IsShown","boolean")==true then
  self:ApplyVisibility(self.surface.desired,alpha*(self.surface.desired=="AMBIENT" and .25 or 1),{reason=self.surface.reason})
 end
 if self.visibilityIntent~=state or self.visibilityAlpha~=alpha then
  self.visibilityIntent=state;self.visibilityAlpha=alpha;M.state.forceEvaluate=true
 end
 -- Showing belongs to CVE, which also observes startup, cinematics, Alt-Z,
 -- editor workspaces and profile policy. A provider tick must not undo its
 -- decision. Withdrawal remains immediate if this provider loses authority.
 if state=="HIDDEN" and self.frame and S:Frame(self.frame,true) and S:Public(self.frame.IsShown,"boolean",self.frame)==true then
  if M.Effects and M.Effects.CancelTransition then M.Effects:CancelTransition(self,self.frame,false) end
  self:DismissPopup("DISPLAY_HIDDEN");self.frame:Hide();self:HideTooltip()
 end
end
function P:DataVisible()
 if M.state.trackerWorkspace or M.state.keybindWorkspace or M.state.cinematic or M.state.world==false then return false end
 local why=self.surface and self.surface.reason
 if why=="STARTUP_QUIET" or why=="NATIVE_UI_HIDDEN" or why=="MODULE_STOPPED" then return false end
 if not self.presentationReady then return true end
 if self.minimized then return false end
 return self:CanShow()==true and (not self.surface or self.surface.desired~="HIDDEN")
end
function P:ResolveLayout(surface,profile)
 profile=profile or M.profile
 local w,h=M.Layout:Screen();if not w then return nil,"VIEWPORT_PENDING" end
 local c=profile.modules.DamageMeters or {};local saved=profile.layouts and profile.layouts["DamageMeters.mirage"]
 local l=M:Copy(saved or {width=320,height=126+(c.meterRows or 8)*23,scale=1})
 l.width=math.max(240,math.min(700,l.width or 320));l.height=math.max(195,math.min(600,l.height or 310));l.scale=math.max(.6,math.min(2,l.scale or 1))
 l.scale=math.min(l.scale,math.max(1,w-32)/l.width,math.max(1,h-32)/l.height)
 if not saved then l.x=.5-(l.width*l.scale/2+18)/w;l.y=-.5+(l.height*l.scale/2+18)/h end
 l.x=l.x or 0;l.y=l.y or 0
 return M.Layout:Clamp(l),w,h
end
function P:ApplyLayout()
 if not self.frame or not self.active then return false,"METERS_INACTIVE" end
 -- This tree contains only Mirage-owned visual widgets. Safe explicit
 -- minimize/expand remains responsive in combat; native geometry is untouched.
 local l,w,h=self:ResolveLayout(self.surface);if not l then self.surface.layoutPending=true;return false,w end
 local f=self.frame;local relative=l.anchorTo and M.surfaces[l.anchorTo] and M.surfaces[l.anchorTo].frame or UIParent
 if not S:Frame(f,true) or not S:Frame(relative,false) then return false,"METERS_LAYOUT_UNAVAILABLE" end
 local height=self.minimized and 42 or l.height
 f:SetSize(l.width,height);f:SetScale(l.scale);f:ClearAllPoints();f:SetPoint("CENTER",relative,"CENTER",l.x*w/l.scale,l.y*h/l.scale-(l.height-height)/2)
 self.modeButton:SetWidth(l.width-76);self.sessionButton:SetWidth(l.width-76)
 self.empty:SetWidth(l.width-32)
 self.renderWidth=l.width;self.renderHeight=l.height;self.resolvedLayout=l;self.layoutScreenWidth=w;self.layoutScreenHeight=h;self.layoutRelative=relative
 self.reportFrameGeometry=nil
 self.visibleCount=math.max(1,math.min(15,cfg().meterRows or 8,math.floor((l.height-142)/26)))
 self:PaintChrome()
 self.surface.layoutPending=nil;self.layoutDirty=nil
 self.modeButton:SetShown(not self.minimized);self.sessionButton:SetShown(not self.minimized);self.reportsTitle:SetShown(not self.minimized);self.rowsHost:SetShown(not self.minimized)
 if self.minimized then self.rowScroll:Hide() end
 self.context:Hide();self.total:Hide();self.totalLabel:Hide()
 self.tableHeader:SetShown(not self.minimized);self.noticeLabel:SetShown(not self.minimized and self.noticeText~=nil)
 self.actorLabel:SetShown(not self.minimized and self.actor~=nil);self.minButton.label:SetText(self.minimized and "+" or "−")
 self.dataDirty=true
 if self.snapshot then self:Render(self.snapshot) end
 return true
end
local function getCVar()
 local api=C_CVar and C_CVar.GetCVar or GetCVar
 return S:Public(api,"string","damageMeterEnabled")
end
function P:RestoreNative()
 local receipt=R.store and R.store.cvars and R.store.cvars.damageMeterEnabled
 if not receipt or receipt.owner~="meters" then self.cvarLease=nil;self.nativeSuppressed=nil;return true end
 if type(R.RestoreCVars)~="function" then return false,"METERS_NATIVE_JOURNAL_UNAVAILABLE" end
 self.cvarWriting=true
 local okay,why=R:RestoreCVars("meters","damageMeterEnabled")
 self.cvarWriting=nil
 if okay then self.cvarLease=nil;self.nativeSuppressed=nil end
 return okay,why
end
function P:SuppressNative()
 if cfg().meterReplaceNative==false then
  local ok,why=self:RestoreNative()
  if ok then self.nativeSuppressed=true end -- explicitly allow both displays
  return ok,why
 end
 if self.cvarOverride then self.nativeSuppressed=nil;return false,"METERS_NATIVE_PREFERENCE_CHANGED" end
 local now,state=getCVar()
 if state~="KNOWN" or now~="0" and now~="1" then return false,"METERS_NATIVE_SETTING_UNAVAILABLE" end
 -- This CVar gates ShouldBeShown in the reviewed native DamageMeter.lua. It
 -- controls the native window, not C_DamageMeter's server-side collection.
 -- No native Lua state, Show/Hide, parent, alpha, input or registry is changed.
 if S:InCombat() then
  if now=="0" and self.nativeSuppressed then return true end
  return false,"METERS_NATIVE_HANDOFF_COMBAT_DEFERRED"
 end
 if type(R.WriteCVar)~="function" then return false,"METERS_NATIVE_JOURNAL_UNAVAILABLE" end
 self.cvarWriting=true
 local okay,why=R:WriteCVar("meters","damageMeterEnabled",0,self.explicitRetry==true)
 self.cvarWriting=nil;self.explicitRetry=nil
 if okay then
  self.cvarLease=R.store and R.store.cvars and R.store.cvars.damageMeterEnabled
  self.nativeSuppressed=true;return true
 end
 self.nativeSuppressed=nil
 return false,why or "METERS_NATIVE_HANDOFF_PENDING"
end
function P:DisplayName(data)
 local display=data and data.name
 -- Shorten only a public character label. Opaque name sinks, NPCs, pets and
 -- ability names keep their native values. Identity, detail lookups, reports
 -- and tooltips always retain the complete source name.
 if self.actor or cfg().meterFirstName==false or not display or display.state~="PUBLIC"
  or not S:Text(display.value) or data.creatureID
  or not (data.localPlayer or data.class or S:Text(data.guid) and data.guid:match("^Player%-")) then return display end
 local text=display.value:gsub("\194\160"," "):gsub("\226\128\175"," "):gsub("\227\128\128"," ")
 local first=text:match("^%s*(%S+)")
 if not first then return display end
 return {state="PUBLIC",value=first}
end
local function sameColumns(a,b)
 if not a or #a~=#b then return false end
 for i,column in ipairs(b) do
  local old=a[i]
  if old.key~=column.key or old.title~=column.title or old.x~=column.x or old.width~=column.width then return false end
 end
 return true
end
local function publicLineWidth(label,text,size)
 local measured=read(label,"GetUnboundedStringWidth","number") or read(label,"GetStringWidth","number")
 if measured and measured>0 then return measured,true end
 -- A public-only conservative estimate is temporary. Retry on the next paint
 -- so a loading font cannot leave a permanent compressed or elided label.
 return S:Text(text) and #text:gsub("[\128-\191]","")*size*.62 or nil,false
end
local function measuredLine(label,text,size,slot)
 if not S:Text(text) then return nil end
 local face=M.Theme and M.Theme.font or STANDARD_TEXT_FONT or M.Visual and M.Visual.font or FONT
 local cache=label.mirageMeterMeasures
 local saved=cache and cache[slot]
 if saved and saved.text==text and saved.face==face and saved.size==size then return saved.width end
 label:SetFont(face,size,"");label:SetText(text)
 local span,measured=publicLineWidth(label,text,size)
 cache=cache or {};label.mirageMeterMeasures=cache
 -- There are at most four fixed slots per font, not a history of combat
 -- values. A temporarily unavailable native measurement is never cached.
 cache[slot]=measured and {text=text,face=face,size=size,width=span} or nil
 return span
end
local function numberText(number,compact)
 if not number or number.state=="UNAVAILABLE" then return "—" end
 if number.state~="PUBLIC" then return nil end
 local value=number.value;local text=D:FormatPublic(value)
 if #text>8 then text=string.format("%.3g",value):gsub("e%+","e") end
 if not compact or compact==0 or value<1000 then return text end
 -- Only a crowded table needs the shorter variant. Preserve three useful
 -- digits first; exceptionally large values may use two. Engineering powers
 -- avoid wasting a decimal point when, for example, 1.23e308 is 123e306.
 local exponent=math.floor(math.log(value)/math.log(1000))*3
 local scaled=value/10^exponent
 if scaled<1 then exponent=exponent-3;scaled=scaled*1000 end
 if scaled>=1000 then exponent=exponent+3;scaled=scaled/1000 end
 local digits=scaled>=100 and 3 or scaled>=10 and 2 or 1
 local decimals=math.max(0,(compact==1 and 3 or 2)-digits)
 local rounded=string.format("%."..decimals.."f",scaled)
 if tonumber(rounded)>=1000 then exponent=exponent+3;rounded="1" end
 if rounded:find("%.") then rounded=rounded:gsub("0+$",""):gsub("%.$","") end
 local suffix=exponent==3 and "k" or exponent==6 and "m" or exponent==9 and "b" or "e"..exponent
 local candidate=rounded..suffix
 return #candidate<=#text and candidate or text
end
-- One shared column layout keeps every heading and row aligned. Ordinary
-- first names get real space before unused numeric-cell padding does. The
-- values remain native-backed; only their public presentation is fitted.
function P:ReportColumns(width,mode,rows)
 local nameOffset=self.actor and 44 or 24
 local nameTitle=self.actor and "Ability" or "Player"
 local title={rate=mode and mode.rateLabel or "/ sec",amount="Total"}
 local heading={}
 for _,key in ipairs({"rate","amount"}) do heading[key]=(measuredLine(self.columns[key],title[key],10,"heading") or 0)+1 end
 local minimumName=(measuredLine(self.columns.name,nameTitle,10,"heading") or 0)+1
 local preferredName=minimumName
 local presentations={}
 for i,data in ipairs(rows or {}) do
  local display=self:DisplayName(data)
  local text=display and display.state=="PUBLIC" and display.value or nil
  local first=display and display~=data.name and S:Text(text) and #text:gsub("[\128-\191]","")<=12
  presentations[i]={display=display,nameText=text,firstName=first==true}
  if first then
   local span=measuredLine(self.rows[i].name,text,11,"name") or 0
   minimumName=math.max(minimumName,span*9/11+1)
   preferredName=math.max(preferredName,span+1)
  end
 end
 local minimum,preferred
 for compact=0,2 do
  minimum={rate=heading.rate,amount=heading.amount}
  preferred={rate=math.max(heading.rate,math.min(64,width*.21)),amount=math.max(heading.amount,math.min(76,width*.25))}
  for i,data in ipairs(rows or {}) do
   for _,key in ipairs({"rate","amount"}) do
    local text=numberText(data[key],compact);presentations[i][key.."Text"]=text
    if text then
     local span=measuredLine(self.rows[i][key],text,11,"number"..compact) or 0
     minimum[key]=math.max(minimum[key],span*8/11+1)
     preferred[key]=math.max(preferred[key],span+1)
    else
     -- Opaque values still go directly to the engine abbreviation/text
     -- sinks. Do not measure or inspect them to decide column geometry.
     minimum[key]=math.max(minimum[key],key=="rate" and 32 or 36)
    end
   end
  end
  if minimum.rate+minimum.amount+minimumName+nameOffset+12<=width then break end
 end
 local floor=minimum.rate+minimum.amount
 local ceiling=preferred.rate+preferred.amount
 local budget=math.min(ceiling,math.max(floor,width-nameOffset-12-preferredName))
 local fraction=ceiling>floor and (budget-floor)/(ceiling-floor) or 0
 local rateWidth=minimum.rate+(preferred.rate-minimum.rate)*fraction
 local amountWidth=minimum.amount+(preferred.amount-minimum.amount)*fraction
 local rateX=width-amountWidth-rateWidth-6
 return {{key="rate",title=title.rate,x=rateX,width=rateWidth},
  {key="amount",title=title.amount,x=width-amountWidth,width=amountWidth}},rateX-6,presentations
end
local function fitLine(label,text,width,size,minimum,elide)
 width=math.max(1,width)
 local face=M.Theme and M.Theme.font or STANDARD_TEXT_FONT or M.Visual and M.Visual.font or FONT
 local public=S:Text(text);local cached=label.mirageMeterLineLayout
 local fontOK,currentFace,currentSize,currentFlags=call(label,"GetFont")
 if public and cached and cached.text==text and cached.width==width and cached.face==face and cached.size==size
  and fontOK and S:Text(currentFace) and S:Number(currentSize) and S:Readable(currentFlags)
  and currentFace==face and currentSize==cached.fittedSize and currentFlags=="" then
  if cached.shown~=text then label:SetText(cached.shown) end
  return cached.fittedSize
 end
 label:SetFont(face,size,"");label:SetWidth(width);label:SetHeight(18)
 call(label,"SetWordWrap",false);call(label,"SetNonSpaceWrap",false);call(label,"SetMaxLines",1)
 local fitted,shown,measured=size,text,false
 -- Opaque values are never read back, compared, stringified, measured or used
 -- as cache keys. They continue directly through the native text sinks.
 if public then
  local span;span,measured=publicLineWidth(label,text,size)
  if span and span>width then
   fitted=math.max(minimum,math.min(size,size*width/span))
   fitted=math.floor(fitted*100)/100;label:SetFont(face,fitted,"")
   if elide and span*fitted/size>width then
    -- Character first names normally fit in full. Opt-in full names and long
    -- spell titles keep a readable floor and expose their full identity on
    -- hover/copy instead of wrapping into another character's data line.
    local chars={};for c in text:gmatch("[\1-\127\194-\244][\128-\191]*") do chars[#chars+1]=c end
    local low,high,best=0,#chars-1,"…"
    while low<=high do
     local middle=math.floor((low+high)/2);local candidate=table.concat(chars,"",1,middle).."…"
     label:SetText(candidate)
     local candidateWidth=publicLineWidth(label,candidate,fitted)
     if candidateWidth and candidateWidth<=width then best=candidate;low=middle+1 else high=middle-1 end
    end
    shown=best;label:SetText(shown)
   end
  end
 end
 label.mirageMeterLineLayout=public and measured and {text=text,shown=shown,width=width,face=face,size=size,fittedSize=fitted} or nil
 return fitted
end
function P:LayoutReportRow(view,data,mode,columns,nameWidth,presentation)
 local display=presentation and presentation.display or self:DisplayName(data);D:SetName(view.name,display)
 -- Player/spec portraits are deliberately absent from the four-column table;
 -- ability details retain a small useful spell icon in their own name cell.
 local hasIcon=self.actor and S:Number(data.icon) and data.icon>0
 local nameOffset=self.actor and 44 or 24
 local nameText=display and display.state=="PUBLIC" and display.value or nil
 fitLine(view.name,nameText,nameWidth-nameOffset,11,9,not (presentation and presentation.firstName))
 D:SetNumber(view.amount,data.amount);D:SetNumber(view.rate,data.rate)
 for _,column in ipairs(columns) do
  local number=column.key=="amount" and data.amount or data.rate
  local text=presentation and presentation[column.key.."Text"] or numberText(number,0)
  if text then view[column.key]:SetText(text) end
  fitLine(view[column.key],text,column.width,11,8,false)
 end
 local height=26
 local previous=view.mirageReportLayout
 if not previous or previous.nameOffset~=nameOffset or previous.nameWidth~=nameWidth
  or previous.height~=height or not sameColumns(previous.columns,columns) then
  view.rank:ClearAllPoints();view.rank:SetPoint("LEFT",3,0);view.rank:SetJustifyH("CENTER");view.rank:SetSize(16,18)
  view.icon:ClearAllPoints();view.icon:SetPoint("LEFT",24,0);view.icon:SetSize(16,16)
  view.name:ClearAllPoints();view.name:SetPoint("LEFT",nameOffset,0)
  for _,key in ipairs({"percent","rate","amount"}) do view[key]:Hide();view.labels[key]:Hide() end
  for _,column in ipairs(columns) do
   local value=view[column.key]
   value:ClearAllPoints();value:SetPoint("LEFT",column.x,0);value:Show()
  end
  view:SetHeight(height)
  view.mirageReportLayout={nameOffset=nameOffset,nameWidth=nameWidth,height=height,columns=columns}
 end
 view.percent:SetText("");view.percent:Hide();view.icon:SetShown(hasIcon==true)
 return height
end
function P:Render(snapshot)
 if not self.frame then return end
 local mode=snapshot.mode or D:Mode(self:Mode());local width=self.renderWidth or 320
 self.modeButton.label:SetText(mode and mode.label or "Damage")
 local session=self.sessionID and (snapshot.sessionLabel or "Recent fight") or (self:Session()==0 and "Overall" or "Current fight")
 self.sessionButton.label:SetText(session)
 local sessionHeight=math.max(24,textHeight(self.sessionButton.label,session,width-109,11)+10)
 self.sessionButton:SetHeight(sessionHeight);self.reportsTitle:SetHeight(sessionHeight)
 local expandedTop=46+sessionHeight+10
 local progress=self.minimized and 0 or math.max(0,math.min(1,self.headerProgress or 0))
 if M.state.edit==true and not self.minimized then progress=1;self.headerProgress=1;self.headerTarget=1 end
 local eased=progress*progress*(3-2*progress)
 local withdrawn=(expandedTop-COMPACT_HEADER)*(1-eased)
 local reportTop=expandedTop-withdrawn;self.headerHeight=reportTop
 local expanded=not self.minimized and progress>0 and (self.headerClips or progress==1)
 self.headerChrome:SetHeight(math.max(1,reportTop-4));self.headerChrome:SetAlpha(math.max(0,(progress-1/3)*1.5));self.headerChrome:SetShown(expanded)
 -- Hidden or partially unfolded selectors never keep invisible mouse targets.
 self.modeButton:EnableMouse(not self.minimized and progress==1);self.sessionButton:EnableMouse(not self.minimized and progress==1)
 self.compactHeader:ClearAllPoints();self.compactHeader:SetPoint("TOPLEFT",10,self.minimized and -12 or -4)
 local caption=self.minimized and "Meters" or (S:Text(mode and mode.label) and mode.label or "Meters").." · "..(S:Text(session) and session or "Current fight")
 self.compactHeader:SetText(caption);fitLine(self.compactHeader,caption,width-(self.minimized and 84 or 40),10,10,true)
 self.compactHeader:SetTextColor(unpack(self.minimized and accent() or muted()))
 self.compactHeader:SetAlpha(self.minimized and 1 or math.max(0,1-progress*3));self.compactHeader:SetShown(self.minimized or progress<1/3)
 for _,line in ipairs(self.compactChevron) do line:SetAlpha(math.max(0,1-progress*3));line:SetShown(not self.minimized and progress<1/3) end
 self:PaintChrome()
 self.backButton:ClearAllPoints();self.backButton:SetPoint("TOPLEFT",9,-reportTop)
 self.backButton:SetShown(self.actor~=nil and not self.minimized)
 -- Retire the old aggregate strip without affecting the native session data.
 self.context:SetText("");self.context:Hide();self.total:SetText("");self.total:Hide();self.totalLabel:SetText("");self.totalLabel:Hide()
 if self.notice then self.noticeText=self.notice;self.notice=nil;self.noticeUntil=S:Now()+6
 elseif self.noticeUntil and S:Now()>=self.noticeUntil then self.noticeUntil=nil;self.noticeText=nil end
 -- Errors/confirmations remain actionable above the data. There is no idle
 -- status footer; report limitations are disclosed only when they apply.
 local notice=self.noticeText
 if snapshot.truncated then notice=(notice and notice.." · " or "").."First "..#snapshot.rows.." only" end
 if snapshot.partial then notice=(notice and notice.." · " or "").."Some data unavailable" end
 self.noticeLabel:SetText(notice or "");self.noticeLabel:SetShown(notice~=nil and not self.minimized)
 local top=reportTop+(self.actor and 25 or 0)
 if notice then
  self.noticeLabel:ClearAllPoints();self.noticeLabel:SetPoint("TOPLEFT",10,-top)
  top=top+textHeight(self.noticeLabel,notice,width-20,10)+6
 end
 self.actorLabel:SetShown(self.actor~=nil and not self.minimized)
 if self.actor then
  local name=self.actor.name or "Ability breakdown";self.actorLabel:SetText(name)
  self.actorLabel:ClearAllPoints();self.actorLabel:SetPoint("TOPLEFT",10,-top)
  top=top+textHeight(self.actorLabel,name,width-20,11)+6
 end
 self.stackedRows=false
 -- The body retains the same row capacity and bottom anchor during hover.
 -- A selector opening must not move a player row out from under the cursor.
 local maxRows=math.max(1,math.min(15,cfg().meterRows or 8));local available=math.max(1,(self.renderHeight or 310)-(top+withdrawn)-42-20)
 local count=math.max(1,math.min(maxRows,math.floor(available/26)))
 local rows,offset,heights,used,columns,nameWidth,presentations,gutter,range
 while true do
  rows,offset,range=D:VisibleRows(snapshot,count,self.offset,cfg().meterPinPlayer~=false and not self.actor)
  gutter=range>0 and 10 or 0
  columns,nameWidth,presentations=self:ReportColumns(width-18-gutter,mode,rows);heights={};used=0
  for i,data in ipairs(rows) do heights[i]=self:LayoutReportRow(self.rows[i],data,mode,columns,nameWidth,presentations[i]);used=used+heights[i] end
  if used<=available or count<=1 then break end
  count=count-1
 end
 self.offset=offset;self.visibleCount=count;self.rowGutter=gutter;self.scrollRange=range
 self.tableHeader:ClearAllPoints();self.tableHeader:SetPoint("TOPLEFT",9,-top);self.tableHeader:SetWidth(width-18-gutter);self.tableHeader:SetShown(not self.minimized)
 self.columns.rank:ClearAllPoints();self.columns.rank:SetPoint("TOPLEFT",3,0);self.columns.rank:SetSize(16,18);self.columns.rank:SetText("#")
 local nameOffset=self.actor and 44 or 24
 self.columns.name:ClearAllPoints();self.columns.name:SetPoint("TOPLEFT",nameOffset,0);self.columns.name:SetSize(nameWidth-nameOffset,18);self.columns.name:SetText(self.actor and "Ability" or "Player")
 for _,key in ipairs({"percent","rate","amount"}) do self.columns[key]:Hide() end
 for _,column in ipairs(columns) do
  local label=self.columns[column.key];label:ClearAllPoints();label:SetPoint("TOPLEFT",column.x,0);label:SetSize(column.width,18);label:SetText(column.title);label:Show()
 end
 top=top+20
 -- Notices and a long retained-fight selector may require additional room;
 -- player rows remain single-line and never rewrite the saved rectangle.
 local height=math.max((self.renderHeight or 310)-withdrawn,top+used+42)
 if not self.minimized and self.resolvedLayout then
  local l=self.resolvedLayout;local w,h=self.layoutScreenWidth,self.layoutScreenHeight
  local expandedHeight=height+withdrawn
  -- Fit once against the fully unfolded panel. Hover must not rescale the
  -- report or move its rows when the panel is near a viewport edge.
  local scale=math.min(l.scale,math.max(1,w-32)/width,math.max(1,h-32)/expandedHeight)
  local relative=self.layoutRelative;local rx,ry=w/2,h/2
  if relative~=UIParent then
   local ok,x,y=call(relative,"GetCenter");local rs,ps=read(relative,"GetEffectiveScale","number"),read(UIParent,"GetEffectiveScale","number")
   if ok and S:Number(x) and S:Number(y) and rs and ps and ps>0 then rx,ry=x*rs/ps,y*rs/ps end
  end
  local centerX=rx+l.x*w;local centerY=ry+l.y*h+(expandedHeight*scale-l.height*l.scale)/2
  centerX=math.max(16+width*scale/2,math.min(w-16-width*scale/2,centerX))
  centerY=math.max(16+expandedHeight*scale/2,math.min(h-16-expandedHeight*scale/2,centerY))-withdrawn*scale/2
  local x,y=(centerX-rx)/scale,(centerY-ry)/scale;local previous=self.reportFrameGeometry
  if not previous or previous.height~=height or previous.scale~=scale or previous.relative~=relative or previous.x~=x or previous.y~=y then
   self.frame:SetHeight(height);self.frame:SetScale(scale);self.frame:ClearAllPoints()
   self.frame:SetPoint("CENTER",relative,"CENTER",x,y)
   self.reportFrameGeometry={height=height,scale=scale,relative=relative,x=x,y=y}
  end
  self.fittedReportScale=scale
 end
 self.rowsTop=top;self.rowsBottom=top+used
 self.rowsHost:ClearAllPoints();self.rowsHost:SetPoint("TOPLEFT",9,-top);self.rowsHost:SetPoint("BOTTOMRIGHT",-9-gutter,42)
 self.empty:ClearAllPoints();self.empty:SetPoint("CENTER",self.rowsHost,"CENTER",0,0)
 self.rowScroll:ClearAllPoints();self.rowScroll:SetPoint("TOPRIGHT",-4,-top);self.rowScroll:SetHeight(math.max(1,height-top-42))
 if self.minimized then self.rowScroll:Hide() else scrollState(self.rowScroll,offset,range,math.max(1,height-top-42),math.max(1,height-top-42)*math.max(1,#snapshot.rows)/count) end
 local y=0
 for i=1,15 do
  local view=self.rows[i];local data=rows[i];view.data=data
  if data and not self.minimized then
   local r,g,b=unpack(accent())
   if cfg().meterClassColors~=false and data.class then
    local c=RAID_CLASS_COLORS and RAID_CLASS_COLORS[data.class]
    if c and S:Number(c.r) and S:Number(c.g) and S:Number(c.b) then r,g,b=c.r,c.g,c.b end
   end
   if view.mirageReportY~=y then
    view:ClearAllPoints();view:SetPoint("TOPLEFT",0,-y);view:SetPoint("TOPRIGHT",0,-y);view.mirageReportY=y
   end
   y=y+heights[i]
   view.mirageMeterTextures.background:SetColorTexture(.06,.06,.065,.06)
   view.fill:SetStatusBarColor(r,g,b,.216);D:SetBar(view.fill,data.amount,snapshot.maximum)
   view.accent:SetShown(data.localPlayer==true);view.rank:SetText(data.rank)
   if self.actor and data.icon and S:Number(data.icon) and data.icon>0 then view.icon:SetTexture(data.icon);view.icon:Show() else view.icon:Hide() end
   view:Show()
  else view.data=nil;view:Hide() end
 end
 local empty=#rows==0 and not self.minimized;self.empty:SetShown(empty)
 if empty then
  local messages={EMPTY="Ready for your next fight",RESTRICTED="The game is keeping these values private.",UNAVAILABLE="Waiting for game meter data…",
   UNSUPPORTED="The client meter is unavailable.",DETAIL_RESTRICTED="Ability details will appear when available.",UNSUPPORTED_DETAIL="The game does not provide this breakdown."}
  self.empty:SetText(self.actor and snapshot.state=="EMPTY" and "No abilities recorded for this view." or messages[snapshot.state] or "Waiting for meter data…")
 end
 self:RefreshRowTooltip()
end
function P:PresentationDue(now)
 return not self.minimized and self.snapshot~=nil and self:DataVisible()
  and (self.notice~=nil or self.noticeUntil~=nil and now>=self.noticeUntil)
end
function P:Paint()
 if not self.active or self.profile~=M.profile then return false end
 local generation,profile,view=self.generation,self.profile,self.viewRevision or 0
 local snapshot=D:Read({mode=self:Mode(),session=self:Session(),sessionID=self.sessionID,actor=self.actor})
 if not self:Current(generation,profile,view) then return false end
 if snapshot.state=="SESSION_EXPIRED" then self.viewRevision=(self.viewRevision or 0)+1;view=self.viewRevision;self.sessionID=nil;self.actor=nil;self.offset=0;self.notice="This fight expired. Showing the current fight.";self.runtimeSession=1
  snapshot=D:Read({mode=self:Mode(),session=1})
 end
 if not self:Current(generation,profile,view) then return false end
 self.snapshot=snapshot;self:Render(snapshot)
 self.presentationReady=snapshot.state=="READY" or snapshot.state=="EMPTY" or self.actor~=nil and (snapshot.state=="DETAIL_RESTRICTED" or snapshot.state=="UNSUPPORTED_DETAIL")
 self.status=self.presentationReady and (snapshot.state=="EMPTY" and "METERS_READY_FOR_COMBAT" or "MIRAGE_METERS_RUNNING") or "METERS_"..snapshot.state
 self.dataDirty=nil;self.nextUpdate=S:Now()+(self.presentationReady and self.runtimeInterval or 1)
 return self.presentationReady
end
function P:Initialize()
 if not chosen() then return false,"NOT_SELECTED" end
 if S:InCombat() then return false,"SETUP_COMBAT_DEFERRED" end
 return true
end
function P:Configure()
 self:DismissPopup("RECONFIGURED")
 if not chosen() or cfg().metersEnabled==false then
  local ok,why=self:Suspend("METERS_DISABLED");return result(ok and "READY" or "DEFERRED_HANDOFF",why or "NATIVE_METERS_RETAINED")
 end
 if R:NativeEditState()~="CLOSED" then return result("DEFERRED_HANDOFF","NATIVE_EDIT_HANDOFF") end
 if S:InCombat() then return result("DEFERRED_COMBAT","SETUP_COMBAT_DEFERRED") end
 if not M.Layout:Screen() then return result("WAITING","VIEWPORT_PENDING") end
 if self.profile~=M.profile then self.resetArmed=nil;self.notice=nil;self.noticeText=nil;self.noticeUntil=nil;self:HideTooltip();self.pendingPreferences=nil;self.preferenceSaveFailed=nil;self.runtimeMode=nil;self.runtimeSession=nil;self.sessionID=nil;self.actor=nil;self.offset=0 end
 self.active=true;self.profile=M.profile;self.generation=(self.generation or 0)+1;self.dataDirty=true;self.cvarOverride=nil
 if not self:Create() then return result("WAITING","METERS_CREATE_PENDING") end
 self.surface.disabled=false
 local layout,why=self:ApplyLayout();if not layout then return result("WAITING",why) end
 local enabled,enableWhy=D:Availability();self.collectionState=enabled and "NATIVE_API_READY" or enableWhy
 self:Paint()
 local handoff,why
 if self.presentationReady then handoff,why=self:SuppressNative() else handoff,why=self:RestoreNative() end
 self.nextNativeCheck=S:Now()+1;self:RefreshVisibility()
 if not handoff then self.status=why;return result("PARTIAL",why) end
 return result(self.presentationReady and (self.nativeSuppressed and "READY" or "PARTIAL") or "WAITING",self.status)
end
function P:OnEvent(event,value,sessionID)
 if event=="PLAYER_LEAVING_WORLD" then return self:Suspend("WORLD_LEFT") end
 if event=="CVAR_UPDATE" then
  if not S:Text(value) or value:lower()~="damagemeterenabled" then return end
  if not self.cvarWriting and self.cvarLease then
   local current,state=getCVar()
   if state=="KNOWN" and current~=self.cvarLease.written then self.cvarLease=nil;self.cvarOverride=true;self.nativeSuppressed=nil end
  end
  self.nativeDirty=true;self:RefreshVisibility();return
 end
 if event=="ADDON_LOADED" and value~="Blizzard_DamageMeter" then return end
 if event=="DAMAGE_METER_CURRENT_SESSION_UPDATED" and (self.sessionID~=nil or self:Session()~=1) then return end
 if event=="DAMAGE_METER_COMBAT_SESSION_UPDATED" then
  local mode=D:Mode(self:Mode())
  if S:Number(value) and mode and value~=mode.id then return end
  -- The native source dispatches both an overall (0) and concrete-session
  -- event. Follow its window contract: one relevant event per view, not all
  -- modes and both copies. Unknown payloads conservatively request a read.
  if S:Number(sessionID) then
   if self.sessionID~=nil and sessionID~=self.sessionID then return end
   if self.sessionID==nil and sessionID~=0 then return end
  end
 end
 if event=="DAMAGE_METER_RESET" or event=="DAMAGE_METER_CURRENT_SESSION_UPDATED" then
  D:Invalidate(event);self.resetArmed=nil
  if event=="DAMAGE_METER_RESET" or self.sessionID==nil and self:Session()==1 then
   self.viewRevision=(self.viewRevision or 0)+1
   self:DismissPopup("FIGHT_CHANGED");self.snapshot=nil;self.actor=nil;self.offset=0;self:HideTooltip()
   if event=="DAMAGE_METER_RESET" then self.sessionID=nil end
  end
 elseif event=="DISPLAY_SIZE_CHANGED" or event=="UI_SCALE_CHANGED" then self.layoutDirty=true;return
 end
 if event=="PLAYER_REGEN_ENABLED" then self.nativeDirty=true end
 self.dataDirty=true
end
function P:OnViewportReady() self.layoutDirty=true;return self.active end
function P:NeedsRuntimeTick(now)
 if not self.active then return false end
 local combat=S:InCombat()
 local visible=self:DataVisible()
 return self:PresentationDue(now) or self.dataDirty and visible or self.layoutDirty and not combat or self.nativeDirty or self.pendingPreferences and not self.preferenceSaveFailed and not combat
  or now>=(self.nextNativeCheck or 0) or visible and (combat or not self.presentationReady) and now>=(self.nextUpdate or 0),self.runtimeInterval
end
function P:Tick(now)
 if not self.active then return end
 if not chosen() or cfg().metersEnabled==false then return self:Suspend("UNSELECTED") end
 if R:NativeEditState()~="CLOSED" then return self:Suspend("NATIVE_EDIT_HANDOFF") end
 if self.profile~=M.profile then return self:Suspend("PROFILE_CHANGED") end
 if self:CommitPreferences() then return result("READY","METERS_PREFERENCES_SAVED") end
 if self.layoutDirty and not S:InCombat() then self:ApplyLayout() end
 now=S:Number(now) and now or S:Now()
 -- A completed native fight is stable between meter events. Polling its
 -- rate after combat can extend a client duration and make DPS drift down.
 if self:DataVisible() and (self.dataDirty or (S:InCombat() or not self.presentationReady) and now>=(self.nextUpdate or 0)) then self:Paint() end
 -- Notice deadlines repaint the existing snapshot only. Stable completed
 -- sessions do not need a new native read to remove a confirmation message.
 if self:PresentationDue(now) then self:Render(self.snapshot) end
 if self.nativeDirty or now>=(self.nextNativeCheck or 0) then
  self.nativeDirty=nil;self.nextNativeCheck=now+1
  if self.presentationReady then
   local ok,why=self:SuppressNative();if not ok then self.status=why end
  else self:RestoreNative() end
 end
 self:RefreshVisibility()
 return result(self.presentationReady and (self.nativeSuppressed and "READY" or "PARTIAL") or "WAITING",self.status)
end
function P:Refresh() self.preferenceSaveFailed=nil;D:Invalidate("EXPLICIT_REFRESH");self.dataDirty=true;self.nativeDirty=true;self:HideTooltip() end
function P:Open()
 self.minimized=false;self.layoutDirty=true;self.dataDirty=true;self.headerInspectUntil=S:Now()+2;M.state.revealUntil=S:Now()+20
 if not self.active then R:RequestConfigure("meters","EXPLICIT_RETRY") else self:RefreshVisibility() end
end
function P:Retry() self.preferenceSaveFailed=nil;self.explicitRetry=true;self.cvarOverride=nil;self.dataDirty=true;self.nativeDirty=true;self.layoutDirty=true end
function P:Suspend(reason)
 if self.frame and M.Effects and M.Effects.CancelTransition then M.Effects:CancelTransition(self,self.frame,false) end
 self:DismissPopup(reason or "SUSPENDED")
 self.resetArmed=nil;self.notice=nil;self.noticeText=nil;self.noticeUntil=nil
 self.active=false;self.generation=(self.generation or 0)+1;self.presentationReady=false;self.snapshot=nil;self.actor=nil;self.pendingPreferences=nil;self.preferenceSaveFailed=nil;self:HideTooltip()
 self.visibilityIntent=nil;self.visibilityAlpha=nil;M.state.forceEvaluate=true
 if self.frame and S:Frame(self.frame,true) then self.frame:Hide() end
 if self.surface then self.surface.disabled=true end
 local native,why=self:RestoreNative()
 self.status=native and (reason or "SUSPENDED") or why
 return native,self.status
end
function P:Status()
 return self.status.."; renderer=MIRAGEUI_METERS; source=C_DAMAGE_METER; ordering=NATIVE; pet_attribution=NATIVE"
  .."; collection="..(self.collectionState or "NOT_STARTED").."; rows="..tostring(self.snapshot and #self.snapshot.rows or 0)
  .."; preferences="..(self.preferenceSaveFailed and "SAVE_FAILED_RETRY_AVAILABLE" or self.pendingPreferences and "PENDING_SAVE" or "SAVED")
  .."; live_read_interval="..tostring(self.runtimeInterval).."; idle_reads=METER_EVENTS_ONLY; hidden_reads=PAUSED_NATIVE_COLLECTION_RETAINED"
  .."; header=HOVER_EXPAND; header_rows=STABLE; header_popup_hold=ENABLED"
  .."; history=GAME_RETAINED; combat_values=ENGINE_DISPLAY_ONLY; native_acceptance=NOT_RUN"
end
function P:Coverage() return self:Status() end
