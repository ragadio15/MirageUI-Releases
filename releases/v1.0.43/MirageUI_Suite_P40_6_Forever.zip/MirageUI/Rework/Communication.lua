local _,M=...
-- WP10: the game owns routing/filtering/input and its history ring; Mirage owns
-- the displayed message canvas. Never replace AddMessage, an event handler, a
-- chat filter, a hyperlink route or an editbox script. Focus post-hooks reveal
-- only the already admitted public message canvas; structural work stays queued.
local R,S=M.Rework,M.Safety
local L=R.CombatLeases
local C={id="chat",status="NOT_INITIALIZED",rows={},hooks=setmetatable({},{__mode="k"}),nativeRoots={},scopedWindowInvalidation=true,
 layoutIDs={["Chat.nativePosition"]=true},events={UPDATE_CHAT_WINDOWS=true,UPDATE_FLOATING_CHAT_WINDOWS=true,
 PLAYER_ENTERING_WORLD=true,PLAYER_REGEN_ENABLED=true,ADDON_LOADED=true,UPDATE_CHAT_COLOR=true,
 CHAT_MSG_CHANNEL_NOTICE=true,CHANNEL_UI_UPDATE=true,ZONE_CHANGED_NEW_AREA=true,SHARD_TRANSFER_IMMINENT=true,
 UI_SCALE_CHANGED=true,DISPLAY_SIZE_CHANGED=true,PLAYER_LOGOUT=true}}
R.Communication=C
for i=1,128 do C.nativeRoots["ChatFrame"..i]=true end
local unpack=unpack or table.unpack
local function tone(key,fallback) return unpack(M.Theme and M.Theme[key] or fallback) end
local function pack(...) return {n=select("#",...),...} end
local function field(o,k) return L:Field(o,k) end
local function public(o,k,t,...) return L:Public(o,k,t,...) end
local function call(o,k,...) return L:Call(o,k,...) end
local function screen()
 if M.Layout and M.Layout.Screen then return M.Layout:Screen() end
 if M.Managed and M.Managed.Viewport then return M.Managed:Viewport() end
 local w,h=public(UIParent,"GetWidth","number"),public(UIParent,"GetHeight","number")
 return w,h,public(UIParent,"GetEffectiveScale","number")
end
local function eligible() return R:Qualified() and R:Selected("chat") and not M.state.safe end
local function wanted() return eligible() and not R:NativeEditing() end
function C:Current(row,generation,profile,native)
 local function current()
  return self.active and self.generation==generation and M.profile==profile and self.rows[row.name]==row
   and row.native==native and _G[row.name]==native
 end
 return current() and wanted() and current()
end
-- Preallocated/hidden chat frames and docked tabs are one chat location,
-- not separate movable windows. Detached visible windows retain a named entry.
function C:CustomizeVisible(surface)
 if not surface or surface.id=="Chat.nativePosition" then return true end
 local id=tonumber(surface.id and surface.id:match("^Chat%.messages(%d+)$"))
 if not id then return true end
 local row=self.rows["ChatFrame"..id]
 if not row or row.surface~=surface or row.native~=_G[row.name] then return false end
 local docked=field(row.native,"isDocked")
 if docked==true or docked==1 or field(row.native,"isInitialized")==0 then return false end
 return public(row.native,"IsVisible","boolean")==true
end
function C:Typing(row)
 local edit=row and field(row.native,"editBox")
 if not S:Frame(edit,false) then return false end
 local focus,known=public(edit,"HasFocus","boolean")
 if known=="KNOWN" and focus then return true end
 local active,state=S:Public(ChatEdit_GetActiveWindow,nil)
 return state=="KNOWN" and active==edit and public(edit,"IsShown","boolean")==true or false
end
function C:WatchInput(row)
 local edit=field(row.native,"editBox")
 if not S:Frame(edit,false) or type(field(edit,"HookScript"))~="function" then return end
 self.inputHooks=self.inputHooks or setmetatable({},{__mode="k"})
 if self.inputHooks[edit]==row then return end
 self.inputHooks[edit]=row
 for _,event in ipairs({"OnEditFocusGained","OnEditFocusLost","OnShow","OnHide"}) do
  pcall(edit.HookScript,edit,event,function()
   if not C.active or C.rows[row.name]~=row or row.native~=_G[row.name] or not wanted() then return end
   row.visibilityDirty=true;C.pendingWork=true;M.state.forceEvaluate=true
   if row.committed and not row.blocked and C:Typing(row) then C:Visibility(row) end
  end)
 end
 -- Native attention fades can continue after focus was gained. Keep the
 -- active input at its readable endpoint without replacing that native fade.
 if type(hooksecurefunc)=="function" and type(field(edit,"SetAlpha"))=="function" then
  pcall(hooksecurefunc,edit,"SetAlpha",function()
   if C.active and row.committed and not row.blocked and not row.chromeBusy and C.rows[row.name]==row
    and row.native==_G[row.name] and wanted() and C:Typing(row) then C:ChromeAlpha(row,row.visibilityAlpha or 1) end
  end)
 end
end
function C:CanRoute(row)
 if self.rows[row.name]~=row or row.native~=_G[row.name] or not S:Frame(row.native,false) then return false end
 if self.active then return true end
 -- A refused native handback can leave the owned canvas as the only usable
 -- view. Its original native input routes remain available until that exact
 -- receipt releases; this does not start a provider or reopen other windows.
 return row.accessFallback==true and row.bodyReady==true and R:TargetMatched()
end
function C:PresentCanvas(row,visibleBody,current)
 local body,buffer,filtered,staging=row.body,row.buffer,row.filterBody,row.filterBuffer
 local function owned()
  return current() and row.body==body and row.buffer==buffer and row.filterBody==filtered and row.filterBuffer==staging
 end
 if visibleBody~=nil and visibleBody~=body and visibleBody~=filtered then return false end
 for _,sink in pairs({body,buffer,filtered,staging})do
  if sink~=visibleBody then
   if not owned()then return false end
   sink:Hide()
   if not owned()then return false end
  end
 end
 if not owned()then return false end
 if visibleBody then visibleBody:Show()end
 return owned()
end
function C:RetainAccess(row)
 if not row.combatLog and row.textMask and not self:MaskCurrent(row) then self:RetireCanvas(row,"CHAT_NATIVE_MASK_LOST");return false end
 if not row.bodyReady or not row.body or row.native~=_G[row.name] or not S:Frame(row.frame,true) or not R:TargetMatched() then return false end
 local generation,profile,native,body,frame=self.generation,M.profile,row.native,row.body,row.frame
 local function current()
  return self.generation==generation and M.profile==profile and self.rows[row.name]==row and row.native==native
   and _G[row.name]==native and row.body==body and row.bodyReady
 end
 if not current() then return false end
 row.view="GENERAL";row.filterJob=nil
 if row.empty then row.empty:Hide() end
 self:PaintTabs(row,current)
 if not current()then return false end
 if not self:PresentCanvas(row,body,current)then return false end
 row.accessFallback=true;row.committed=true
 if M.Effects then M.Effects:CancelTransition(row,frame,false) end
 if not current() then return false end
 local shown=public(native,"IsShown","boolean")==true
 if not current() then return false end
 frame:SetAlpha(1);if not current() then return false end
 frame:SetShown(shown);if not current() then return false end
 local interactive=shown and field(native,"isUninteractable")~=true
 if not current() then return false end
 body:EnableMouse(interactive);if not current() then return false end
 body:EnableMouseWheel(interactive);if not current() then return false end
 if body.SetHyperlinksEnabled then body:SetHyperlinksEnabled(interactive) end
 if not current() then return false end
 row.interactive=interactive;row.visibilityAlpha=shown and 1 or 0;row.visibilityShown=shown
 return true
end
function C:AccessScroll(row)
 if not row.accessFallback or not self:CanRoute(row) then return end
 local generation,body,native=self.generation,row.body,row.native
 local function current() return self.generation==generation and row.body==body and row.native==native and self:CanRoute(row) end
 local offset,state=public(native,"GetScrollOffset","number")
 if state=="KNOWN" and current() then call(body,"SetScrollOffset",offset);if current() then row.visibleOffset=offset end end
end
-- Native controls remain in their original parent hierarchy. These small
-- receipts only multiply public alpha and gate mouse input with the owned
-- message canvas; they never replace chat routing, focus or control scripts.
function C:TrackChrome(row,control,shared)
 if not S:Frame(control,true) then return false end
 -- TrackChrome also supports a retained isolated presentation journal before
 -- a canvas is registered. Seal that admission explicitly; a managed row can
 -- never become isolated merely because its registry slot was later retired.
 if not row.chromeScope then
  row.chromeScope={native=row.native,global=_G[row.name],isolated=self.rows[row.name]==nil}
 end
 if self.rows[row.name]==row then row.chromeScope.managed=true end
 row.chrome=row.chrome or {};if row.chrome[control] then return true end
 local alpha,state=public(control,"GetAlpha","number")
 local mouse,ms=public(control,"IsMouseEnabled","boolean")
 if state~="KNOWN" then return false end
 local lease={alpha=alpha,lastAlpha=alpha,shared=shared==true,input=control==field(row.native,"editBox")}
 if ms=="KNOWN" then lease.mouse=mouse end
 row.chrome[control]=lease
 return true
end
local function chromePass(self,row,alpha,restore,current)
 local complete=true
 local sharedAlpha=alpha
 for _,window in pairs(self.rows) do
  if not current() then return false end
  local shown=not window.blocked and public(window.native,"IsShown","boolean")==true
  if not current() then return false end
  if shown then sharedAlpha=math.max(sharedAlpha,window.visibilityAlpha or 0) end
 end
 for control,lease in pairs(row.chrome or {}) do
  local function retained() return current() and row.chrome[control]==lease end
  if not retained() then return false end
  local editable=S:Frame(control,true)
  if not retained() then return false end
  if not editable then complete=false
  else
   local visibility=lease.shared and sharedAlpha or alpha
   local focused=not restore and lease.input and self:Typing(row)
   local primary=self.rows.ChatFrame1
   local drawer=not restore and lease.drawer and primary and primary.controlsOpen==true
   if not retained() then return false end
   if not restore and lease.suppressed then visibility=0 elseif focused then visibility=1 end
   if not restore and lease.drawer and not drawer then visibility=0 end
   if not restore and row.view and row.view~="GENERAL" and
    (control==field(row.native,"ScrollBar") or control==field(row.native,"ScrollToBottomButton") or control==field(row.native,"buttonFrame")) then visibility=0 end
   -- Alpha and mouse are independent properties: a native attention fade can
   -- supersede our alpha while the input gate is still ours to restore.
   if not lease.alphaRetired then
    local current,state=public(control,"GetAlpha","number")
    if not retained() then return false end
    local ours=state=="KNOWN" and (math.abs(current-lease.lastAlpha)<=.0001
     or lease.alphaAttempt~=nil and math.abs(current-lease.alphaAttempt)<=.0001)
    if state~="KNOWN" then complete=false
    elseif restore and (lease.displaced or not ours) then lease.alphaRetired=true
    else
     if not ours then lease.alpha=current;lease.lastAlpha=current;lease.alphaAttempt=nil end
     -- Native attention fades can leave the edit box at zero when this
     -- lease starts. Focus must never multiply that zero into invisible input.
     local target=restore and lease.alpha or focused and 1 or drawer and visibility or lease.alpha*visibility
     local confirmed=math.abs(current-target)<=.0001
     if not confirmed then
      lease.alphaAttempt=target
      local sent=call(control,"SetAlpha",target)
      if not retained() then return false end
      local after,known=public(control,"GetAlpha","number")
      if not retained() then return false end
      confirmed=sent and known=="KNOWN" and math.abs(after-target)<=.0001
      if confirmed then lease.lastAlpha=after;lease.alphaAttempt=nil end
     end
     if not confirmed then complete=false elseif restore then lease.alphaRetired=true end
    end
   end
   if lease.mouse==nil then lease.mouseRetired=true
   elseif not lease.mouseRetired then
    local current,known=public(control,"IsMouseEnabled","boolean")
    if not retained() then return false end
    local expected=lease.lastMouse
    if expected==nil then expected=lease.mouse end
    local ours=known=="KNOWN" and (current==expected or lease.mouseAttempt~=nil and current==lease.mouseAttempt)
    if known~="KNOWN" then complete=false
    elseif lease.mouseDisplaced or not ours then
     lease.mouseDisplaced=true
     if restore then lease.mouseRetired=true end
    else
     local target=lease.mouse
     if not restore then target=visibility>.02 and lease.mouse or false end
     local confirmed=current==target
     if not confirmed then
      lease.mouseAttempt=target
      local sent=call(control,"EnableMouse",target)
      if not retained() then return false end
      local after,state=public(control,"IsMouseEnabled","boolean")
      if not retained() then return false end
      confirmed=sent and state=="KNOWN" and after==target
      if confirmed then lease.lastMouse=after;lease.mouseAttempt=nil end
     end
     if not confirmed then complete=false elseif restore then lease.mouseRetired=true end
    end
   end
   if restore and lease.alphaRetired and lease.mouseRetired then row.chrome[control]=nil end
  end
 end
 return complete
end
function C:TrackDrawer(row,control,shared)
 if not self:TrackChrome(row,control,shared) then return false end
 row.chrome[control].drawer=true
 self.drawerHooks=self.drawerHooks or setmetatable({},{__mode="k"})
 if not self.drawerHooks[control] and type(hooksecurefunc)=="function" then
  local installed=pcall(hooksecurefunc,control,"SetAlpha",function()
   if C.active and row.committed and not row.chromeBusy and C.rows[row.name]==row and row.native==_G[row.name] and wanted() then
    C:ChromeAlpha(row,row.visibilityAlpha or 0)
   end
  end)
  if installed then self.drawerHooks[control]=true end
 end
 return true
end
function C:ChromeAlpha(row,alpha,restore)
 -- A native setter may enter Safe/handback before it commits. Retain the
 -- inverse receipt and serialize that restore after the setter has unwound.
 if row.chromeBusy then
  if restore then row.chromeRestoreQueued={generation=self.generation,profile=M.profile,chrome=row.chrome,native=row.native,
   registered=self.rows[row.name],scope=row.chromeScope} end
  return false
 end
 local completed=false
 for pass=1,8 do
  local generation,profile,native,chrome,active=self.generation,M.profile,row.native,row.chrome,self.active
  local scope,registered=row.chromeScope,self.rows[row.name]==row
  if registered and scope then scope.managed=true end
  local token={};row.chromeBusy=token
  local function current()
   local function identity()
    local custody=registered and self.rows[row.name]==row and (restore or _G[row.name]==native)
     or not registered and scope and scope.isolated and not scope.managed and self.rows[row.name]==nil
      and scope.native==native and (restore or _G[row.name]==scope.global)
    return custody and self.generation==generation and M.profile==profile
     and row.native==native and row.chrome==chrome and row.chromeScope==scope
     and row.chromeBusy==token and self.active==active
   end
   return identity() and (restore or active and wanted()) and identity()
  end
  local called,result=pcall(function() return current() and chromePass(self,row,alpha,restore,current) end)
  completed=called and result==true
  if row.chromeBusy==token then row.chromeBusy=nil end
  local pending=row.chromeRestoreQueued;row.chromeRestoreQueued=nil
  if not pending then return completed end
  if self.generation~=pending.generation or M.profile~=pending.profile or row.chrome~=pending.chrome
   or self.rows[row.name]~=pending.registered or row.chromeScope~=pending.scope or row.native~=pending.native then return false end
  alpha=1;restore=true
 end
 return false
end
function C:SuppressScrollArrows(row)
 local controls,seen={},{}
 local function add(control)
  if S:Frame(control,true) and not seen[control] then seen[control]=true;controls[#controls+1]=control end
 end
 local n=row.native
 for _,root in pairs({field(n,"ScrollBar"),field(n,"buttonFrame")}) do
  for _,key in ipairs({"Back","Forward","ScrollUpButton","ScrollDownButton","UpButton","DownButton","BottomButton"}) do add(field(root,key)) end
 end
 for _,suffix in ipairs({"ButtonFrameUpButton","ButtonFrameDownButton","ButtonFrameBottomButton","ScrollBarScrollUpButton","ScrollBarScrollDownButton"}) do add(_G[row.name..suffix]) end
 add(field(n,"ScrollToBottomButton"))
 local ok=true
 for _,control in ipairs(controls) do
  if self:TrackChrome(row,control) then
   row.chrome[control].suppressed=true
   self.arrowHooks=self.arrowHooks or setmetatable({},{__mode="k"})
   if not self.arrowHooks[control] and type(hooksecurefunc)=="function" then
    local installed=pcall(hooksecurefunc,control,"SetAlpha",function()
     if C.active and row.committed and not row.chromeBusy and C.rows[row.name]==row and row.native==_G[row.name] and wanted() then
      C:ChromeAlpha(row,row.visibilityAlpha or 0)
     end
    end)
    if installed then self.arrowHooks[control]=true end
   end
  else ok=false end
 end
 row.scrollArrowCount=#controls
 return ok
end
function C:CanvasInput(row,interactive,current)
 if not row.body or row.interactive==interactive and row.interactiveView==row.view then return true end
 local body=row.view and row.view~="GENERAL" and row.filterBody or row.body
 for _,other in pairs({row.body,row.filterBody}) do
  if not current() then return false end
  if other~=body then other:EnableMouse(false);other:EnableMouseWheel(false);if other.SetHyperlinksEnabled then other:SetHyperlinksEnabled(false) end end
 end
 if not body then return true end
 if not current() then return false end
 body:EnableMouse(interactive)
 if not current() then return false end
 body:EnableMouseWheel(interactive)
 if not current() then return false end
 if body.SetHyperlinksEnabled then body:SetHyperlinksEnabled(interactive) end
 if not current() then return false end
 row.interactive=interactive;row.interactiveView=row.view
 return true
end
local function text(parent,size)
 local f=parent:CreateFontString(nil,"OVERLAY");f:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",size,"")
 f:SetTextColor(.93,.95,.96,1);return f
end
local function data(row,index,source)
 source=source or row.native
 local fn=field(source,"GetMessageInfo");if type(fn)~="function" then return nil end
 local ok,result=pcall(function() return pack(fn(source,index)) end)
 return ok and result or nil
end
-- Only public history is persisted, without player/access/line identifiers.
-- The source ring remains the authority for restricted text and all live data.
local function publicLine(v)
 if not v or not S:Text(v[1]) or #v[1]>4096 then return nil end
 for i=2,4 do
  if not S:Readable(v[i]) or v[i]~=nil and (not S:Number(v[i]) or v[i]<0 or v[i]>1) then return nil end
 end
 if not S:Readable(v[5]) or v[5]~=nil and (not S:Number(v[5]) or v[5]%1~=0 or v[5]<0 or v[5]>4096) then return nil end
 return {text=v[1],r=v[2],g=v[3],b=v[4],type=v[5]}
end
local function publicTable(value)
 if not S:Readable(value) or type(value)~="table" then return false end
 -- FieldAccess also verifies canaccesstable on clients which expose it.
 local _,state=S:FieldAccess(value,1)
 return state=="KNOWN" or state=="ABSENT"
end
-- The server's permanent channel IDs are independent of local /1, /2, etc.
-- Only accepted native CHAT_MSG_CHANNEL records with public event metadata
-- enter a focused view. Never infer a channel from the displayed name, a local
-- number reused after travel, or the contents of a message.
function C:ChannelView(channelID)
 if not S:Number(channelID) or channelID%1~=0 then return nil end
 if channelID==2 then return "TRADE" end
 if channelID==(self.generalChannelID or 1) or channelID==22 then return "ZONE" end
end
function C:LineInView(values,view)
 if view=="GENERAL" then return true end
 if not values or not S:Text(values[8]) or values[8]~="CHAT_MSG_CHANNEL" or not publicTable(values[9]) then return false end
 local channelID,state=S:FieldAccess(values[9],7)
 return state=="KNOWN" and self:ChannelView(channelID)==view
end
function C:RefreshChannels()
 self.channelsDirty=nil;self.channelAvailable={TRADE=false,ZONE=false}
 local api=_G.C_ChatInfo
 local getter=api and field(api,"GetGeneralChannelID")
 local general=S:Public(getter,"number")
 if general and general>0 and general%1==0 then self.generalChannelID=general end
 local identify=api and field(api,"GetChannelInfoFromIdentifier")
 if type(GetChannelList)~="function" or type(identify)~="function" then return end
 local ok,list=pcall(function() return pack(GetChannelList()) end)
 if not ok or list.n>60 then return end
 for i=1,list.n,3 do
  local localID,name,disabled=list[i],list[i+1],list[i+2]
  if S:Number(localID) and localID>=1 and localID<=20 and S:Text(name) and S:Readable(disabled) and disabled~=true then
   local info=S:Public(identify,"table",name)
   if publicTable(info) and field(info,"localID")==localID and field(info,"channelType")==1 then
    local view=self:ChannelView(field(info,"zoneChannelID"))
    if view then self.channelAvailable[view]=true end
   end
  end
 end
end
function C:PaintTabs(row,current)
 if not row.tabs then return end
 for key,tab in pairs(row.tabs) do
  if current and not current()then return false end
  local selected=row.view==key
  tab.fill:SetColorTexture(tone(selected and "hover" or "panel",selected and {.15,.12,.08,.98} or {.060,.060,.065,.97}))
  if current and not current()then return false end
  tab.rule:SetShown(selected)
  if current and not current()then return false end
  tab.label:SetTextColor(tone(selected and "secondary" or "text",selected and {.96,.79,.36,1} or {.90,.89,.87,1}))
 end
 return not current or current()
end
function C:SelectView(row,view)
 if not row.tabs or not row.tabs[view] or not self:CanRoute(row) or not self.active or not wanted() then return false end
 if row.view==view then return true end
 row.view=view;row.viewGeneration=(row.viewGeneration or 0)+1;row.filterJob=nil;row.filterDirty=view~="GENERAL"
 row.interactive=nil;row.visibleOffset=nil;row.visibilityDirty=true;self.pendingWork=true;self.channelsDirty=true
 local generation,profile,native,revision,tabs=self.generation,M.profile,row.native,row.viewGeneration,row.tabs
 local function current()return self:Current(row,generation,profile,native)and row.view==view and row.viewGeneration==revision and row.tabs==tabs end
 -- Only the published presentation pass may reveal a sink. A view change
 -- can race a completed filtered copy whose old sink is now a staging buffer.
 if not self:PaintTabs(row,current)then return false end
 self:Visibility(row)
 if not current()then return false end
 M.CVE:Hold(row.surface,2)
 return true
end
function C:CreateTabs(row,header,rule)
 row.view="GENERAL";row.tabs={};row.bodyTop=33;row.header=header;row.headerRule=rule;row.controlsOpen=false
 row.empty=text(row.frame,11);row.empty:SetPoint("TOPLEFT",12,-35);row.empty:SetPoint("BOTTOMRIGHT",-30,32)
 row.empty:SetJustifyH("CENTER");row.empty:SetJustifyV("MIDDLE");row.empty:SetTextColor(tone("muted",{.63,.62,.60,1}));row.empty:Hide()
 for i,spec in ipairs({{"GENERAL","General"},{"TRADE","Trade"},{"ZONE","Zone"}}) do
  local key,label=spec[1],spec[2]
  local tab=CreateFrame("Button",nil,row.frame);row.tabs[key]=tab;tab.index=i
  tab.fill=tab:CreateTexture(nil,"BACKGROUND");tab.fill:SetAllPoints()
  tab.rule=tab:CreateTexture(nil,"BORDER");tab.rule:SetColorTexture(1,.66,.20,1)
  tab.rule:SetPoint("BOTTOMLEFT",2,0);tab.rule:SetPoint("BOTTOMRIGHT",-2,0);tab.rule:SetHeight(2)
  tab.label=text(tab,11);tab.label:SetAllPoints();tab.label:SetJustifyH("CENTER");tab.label:SetJustifyV("MIDDLE");tab.label:SetText(label)
  tab:SetScript("OnClick",function() C:SelectView(row,key) end)
  tab:SetScript("OnEnter",function() if C:CanRoute(row) then M.CVE:Hold(row.surface,.6);tab.label:SetTextColor(1,.86,.57,1) end end)
  tab:SetScript("OnLeave",function() C:PaintTabs(row) end)
 end
 local controls=CreateFrame("Button",nil,row.frame);row.controls=controls
 controls:SetSize(22,24);controls:SetPoint("TOPRIGHT",-7,-2)
 controls.label=text(controls,12);controls.label:SetAllPoints();controls.label:SetJustifyH("CENTER");controls.label:SetJustifyV("MIDDLE");controls.label:SetText("...")
 controls:SetScript("OnClick",function()
  if not C.active or not C:CanRoute(row) or not wanted() then return end
  local requested=row.controlsRequested
  if requested==nil then requested=row.controlsOpen end
  row.controlsRequested=not requested;row.geometryDirty=true;row.visibilityDirty=true;C.pendingWork=true
  -- The intent can be toggled back during combat. Only the existing legal
  -- geometry writer commits it; input focus and protected controls stay put.
  M.CVE:Hold(row.surface,3)
 end)
 controls:SetScript("OnEnter",function()
  if C:CanRoute(row) then M.CVE:Hold(row.surface,.6) end
  if _G.GameTooltip then
   call(GameTooltip,"SetOwner",controls,"ANCHOR_TOP");call(GameTooltip,"SetText","Chat tabs and settings")
   if S:InCombat() then call(GameTooltip,"AddLine","Opens after combat; click again to cancel.",.75,.8,.82) end
   call(GameTooltip,"Show")
  end
 end)
 controls:SetScript("OnLeave",function() if _G.GameTooltip and public(GameTooltip,"GetOwner")==controls then call(GameTooltip,"Hide") end end)
 self:PaintTabs(row)
end
function C:LayoutHeader(row,current)
 if not row.tabs then return true end
 current=current or function() return self.active and self.rows[row.name]==row and not S:InCombat() and wanted() end
 local function set(object,method,...)
  if not current() then return false end
  local sent,result=call(object,method,...)
  return sent and result~=false and current()
 end
 if not current() then return false end
 local open=row.controlsOpen
 if row.controlsRequested~=nil then open=row.controlsRequested end
 local bodyTop=open and 59 or 33
 if not set(row.header,"SetHeight",open and 50 or 24) or not set(row.headerRule,"ClearAllPoints")
  or not set(row.headerRule,"SetPoint","TOPLEFT",row.frame,"TOPLEFT",9,-(bodyTop-8))
  or not set(row.headerRule,"SetPoint","TOPRIGHT",row.frame,"TOPRIGHT",-9,-(bodyTop-8)) then return false end
 local width=public(row.frame,"GetWidth","number") or 380
 if not current() then return false end
 local tabWidth=math.max(48,(width-46)/3)
 for _,tab in pairs(row.tabs) do
  if not set(tab,"SetSize",tabWidth,24) or not set(tab,"ClearAllPoints") or not set(tab,"SetPoint","TOPLEFT",10+(tab.index-1)*tabWidth,-2) then return false end
 end
 for _,body in pairs({row.body,row.buffer,row.filterBody,row.filterBuffer}) do
  if not set(body,"ClearAllPoints") or not set(body,"SetPoint","TOPLEFT",10,-bodyTop) or not set(body,"SetPoint","BOTTOMRIGHT",-28,32) then return false end
 end
 if not set(row.empty,"ClearAllPoints") or not set(row.empty,"SetPoint","TOPLEFT",12,-(bodyTop+2)) or not set(row.empty,"SetPoint","BOTTOMRIGHT",-30,32)
  or not set(row.controls.label,"SetTextColor",open and 1 or .73,.79,open and .39 or .81,1) then return false end
 row.bodyTop=bodyTop;row.controlsOpen=open;row.controlsRequested=nil
 return true
end
function C:FilterBuffer(row)
 if row.filterBuffer then return row.filterBuffer end
 if S:InCombat() then return nil end
 local body=CreateFrame("ScrollingMessageFrame",nil,row.frame)
 body:Hide();body:SetPoint("TOPLEFT",10,-(row.bodyTop or 33));body:SetPoint("BOTTOMRIGHT",-28,32)
 body:SetFading(false);body:SetMaxLines(10000);body:SetJustifyH("LEFT");body:EnableMouse(false);body:EnableMouseWheel(false)
 if body.SetHyperlinksEnabled then body:SetHyperlinksEnabled(false) end
 if body.SetTextCopyable then body:SetTextCopyable(true) end
 if body.SetSpacing then body:SetSpacing(3) end
 for _,event in ipairs({"OnHyperlinkClick","OnHyperlinkEnter","OnHyperlinkLeave","OnMouseWheel","OnMouseUp"}) do body:SetScript(event,row.body:GetScript(event)) end
 local _,path,size,flags=call(row.body,"GetFont");body:SetFont(path or STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",size or 13,flags or "")
 row.filterBuffer=body;return body
end
function C:SyncFilter(row)
 if not row.view or row.view=="GENERAL" or not row.filterDirty then return true end
 local generation,profile,native,source,view=self.generation,M.profile,row.native,row.body,row.view
 local viewGeneration=row.viewGeneration
 local function current() return self:Current(row,generation,profile,native) and row.body==source and row.view==view and row.viewGeneration==viewGeneration end
 local function retired() return false,self:Current(row,generation,profile,native) and "CHAT_HISTORY_QUEUED" or "CHAT_OWNER_RETIRED" end
 if not current() then return retired() end
 local count=public(source,"GetNumMessages","number")
 local capacity=row.bodyCapacity
 if not count or not capacity then return false,"CHAT_HISTORY_QUEUED" end
 local job=row.filterJob
 if job and (job.source~=source or job.view~=view or job.epoch~=row.displayEpoch) then job=nil;row.filterJob=nil end
 if not job then
  local body=self:FilterBuffer(row)
  if not body then return false,"CHAT_HISTORY_QUEUED" end
  if not current() then return retired() end
  for _,operation in ipairs({{"Hide"},{"Clear"},{"SetMaxLines",capacity}}) do
   if not current() then return retired() end
   local sent=call(body,unpack(operation))
   if not current() then return retired() end
   if not sent then return false,"CHAT_MESSAGE_SINK_FAILED" end
  end
  job={body=body,source=source,view=view,epoch=row.displayEpoch,next=1,initialCount=count,baseAppends=row.displayAppends or 0}
  row.filterJob=job
 end
 local total=job.initialCount+(row.displayAppends or 0)-job.baseAppends
 local shift=math.max(0,total-capacity)
 if count~=math.min(capacity,total) then row.filterJob=nil;return false,"CHAT_HISTORY_QUEUED" end
 local first=math.max(job.next,shift+1);local last=math.min(total,first+math.max(0,self.messageBudget or 128)-1)
 for i=first,last do
  local values=data(row,i-shift,source)
  if not current() or row.filterJob~=job then return retired() end
  self.lastMessageReads=(self.lastMessageReads or 0)+1;self.messageBudget=math.max(0,(self.messageBudget or 128)-1)
  if not values then row.filterJob=nil;return false,"CHAT_HISTORY_QUEUED" end
  if self:LineInView(values,view) then
   local sent=call(job.body,"AddMessage",unpack(values,1,values.n))
   if not current() or row.filterJob~=job then return retired() end
   if not sent then return false,"CHAT_MESSAGE_SINK_FAILED" end
  end
  if not current() or row.filterJob~=job then return retired() end
 end
 job.next=last+1
 if job.next<=total then return false,"CHAT_HISTORY_QUEUED" end
 call(job.body,"ScrollToBottom")
 if not current() or row.filterJob~=job then return retired() end
 -- Publish the finished sink without invoking presentation callbacks. The
 -- single Visibility pass below hands off all four owned message layers.
 -- Showing a staging sink before this seal can expose a second text layer
 -- when a native callback retires the producer during Show/Hide.
 local old=row.filterBody
 row.filterBody=job.body;row.filterBuffer=old;row.filterJob=nil;row.filterDirty=nil;row.filterView=view
 row.interactive=nil;row.visibleOffset=nil;row.visibilityDirty=true
 return true
end
local function signature(row)
 if row.id<1 or row.id>10 or row.id==2 or field(row.native,"isTemporary")==true then return nil end
 local name=S:Public(GetChatWindowInfo,"string",row.id)
 if not name or #name>256 then return nil end
 -- Named private-message selectors may carry restricted targets and can
 -- change the meaning of an otherwise identical window. Do not persist them.
 for _,key in ipairs({"privateMessageList","excludePrivateMessageList"}) do
  local list,state=S:FieldAccess(row.native,key)
  if state~="ABSENT" then
   if state~="KNOWN" or not publicTable(list) then return nil end
   local first=next(list);if not S:Readable(first) or first~=nil then return nil end
  end
 end
 local messages,channels,zones=field(row.native,"messageTypeList"),field(row.native,"channelList"),field(row.native,"zoneChannelList")
 if not publicTable(messages) or not publicTable(channels) or not publicTable(zones) then return nil end
 local values={}
 for k,v in pairs(messages) do
  if not S:Number(k) or k<1 or k>256 or k%1~=0 or not S:Text(v) or #v>256 then return nil end
  values[#values+1]=#v..":"..v
 end
 table.sort(values)
 local parts={tostring(row.id),#name..":"..name,table.concat(values,";")};values={}
 for k,v in pairs(channels) do
  if not S:Number(k) or k<1 or k>256 or k%1~=0 or not S:Text(v) or #v>256 then return nil end
  local zone,state=S:FieldAccess(zones,k)
  if state~="KNOWN" or not S:Number(zone) or zone<0 or zone>65535 or zone%1~=0 then return nil end
  values[#values+1]=#v..":"..v..":"..zone
 end
 for k in pairs(zones) do
  if not S:Number(k) or k<1 or k>256 or k%1~=0 or S:FieldAccess(channels,k)==nil then return nil end
 end
 table.sort(values);parts[#parts+1]=table.concat(values,";")
 return table.concat(parts,"\031")
end
function C:HistoryStore(create)
 local store=R.characterStore;if type(store)~="table" then return nil end
 local h=store.communication
 if type(h)~="table" or h.schema~=1 or type(h.windows)~="table" then
  if not create then return nil end
  h={schema=1,windows={}};store.communication=h
 end
 return h
end
local function validateHistory(record,sig)
 if not publicTable(record) or not S:Text(record.signature) or record.signature~=sig or not publicTable(record.lines) or #record.lines>250 then return nil end
 for key in pairs(record) do if not S:Text(key) or key~="signature" and key~="lines" then return nil end end
 local out={}
 for i,line in ipairs(record.lines) do
  if not publicTable(line) then return nil end
  for key in pairs(line) do
   if not S:Text(key) or key~="text" and key~="r" and key~="g" and key~="b" and key~="type" then return nil end
  end
  local checked=publicLine({line.text,line.r,line.g,line.b,line.type})
  if not checked then return nil end;out[i]=checked
 end
 for k in pairs(record.lines) do if not S:Number(k) or k%1~=0 or k<1 or k>#out then return nil end end
 return out
end
local function sameLine(a,b)
 return a and b and a.text==b.text and a.r==b.r and a.g==b.g and a.b==b.b and a.type==b.type
end
function C:SaveHistory(row)
 local sig=signature(row);if not sig then return end
 local count,state=public(row.native,"GetNumMessages","number")
 if state~="KNOWN" or count<0 or count>10000 or count%1~=0 then return end
 local h=self:HistoryStore(true);if not h then return end
 local lines={}
 for i=math.max(1,count-249),count do
  local line=publicLine(data(row,i));if line then lines[#lines+1]=line end
 end
 h.windows[row.id]={signature=sig,lines=lines}
end
function C:RestoreHistory(row)
 if row.replayed then return true end
 row.replayed=true -- set before callbacks; reconfiguration never backfills again
 local sig=signature(row);local h=self:HistoryStore(false)
 local lines=sig and h and validateHistory(h.windows[row.id],sig)
 if not lines or #lines==0 then return true end
 local count,state=public(row.native,"GetNumMessages","number")
 if state~="KNOWN" or count<0 or count>10000 or type(field(row.native,"BackFillMessage"))~="function" then return false end
 local first={};for i=1,math.min(count,#lines) do first[i]=publicLine(data(row,i)) or false end
 -- Native reload/backfill may already have retained the previous tail. Only
 -- prepend the portion before the longest exact suffix/prefix overlap.
 local overlap=0
 for n=math.min(#lines,count),1,-1 do
  local matches=true
  for i=1,n do if not sameLine(lines[#lines-n+i],first[i]) then matches=false;break end end
  if matches then overlap=n;break end
 end
 local capacity=public(row.native,"GetMaxLines","number")
 if not capacity or capacity<1 or capacity>10000 or capacity%1~=0 then return false end
 local added=math.min(#lines-overlap,math.max(0,capacity-count))
 for i=#lines-overlap,#lines-overlap-added+1,-1 do
  local v=lines[i]
  if not call(row.native,"BackFillMessage",v.text,v.r,v.g,v.b,v.type) then return false end
 end
 row.restored=added;return true
end
function C:Mark(row,content,layout,append,geometry)
 if self.writing or row.native~=_G[row.name] then return end
 if content then
  row.contentGeneration=(row.contentGeneration or 0)+1
  if append then row.totalAppends=(row.totalAppends or 0)+1
  else row.mutationGeneration=(row.mutationGeneration or 0)+1 end
  if append and row.messageCount~=nil and not row.fullSync then row.pendingAdds=math.min(10001,(row.pendingAdds or 0)+1)
  else row.pendingAdds=nil;row.fullSync=true end
  row.contentDirty=true
 end
 if layout then row.fontDirty=true end
 if geometry then row.geometryDirty=true end
 row.visibilityDirty=true;self.pendingWork=true
end
function C:TextMask(row)
 -- Reviewed 70959 ScrollingMessageFrame.xml declares this passive child;
 -- AcquireFontString/AcquireHighlightTexture parent both native pools to it.
 -- Validate the actual identity/public tree instead of assuming the template
 -- or interpreting a successful SetAlpha as native raster qualification.
 local n=row.native;local child=field(n,"FontStringContainer")
 if S:Frame(child,true) and public(child,"GetParent")==n and public(child,"GetObjectType","string")=="Frame"
  and public(child,"IsMouseEnabled","boolean")==false then return child,"PASSIVE_TEXT_CONTAINER" end
 -- A missing/unqualified child retains the existing root-mask contract. It
 -- gets the same immediate mask-loss fallback; no unknown child is mutated.
 if S:Frame(n,true) then return n,"LEGACY_ROOT_MASK" end
 return nil,"CHAT_TEXT_MASK_UNAVAILABLE"
end
function C:MaskCurrent(row)
 if row.combatLog then return true end
 local object=row.textMask
 if not object or row.native~=_G[row.name] then return false end
 if row.maskKind=="PASSIVE_TEXT_CONTAINER" and (field(row.native,"FontStringContainer")~=object or public(object,"GetParent")~=row.native) then return false end
 local alpha,state=public(object,"GetAlpha","number")
 row.maskObserved=state=="KNOWN" and alpha or nil
 return state=="KNOWN" and alpha==0
end
function C:RestoreCanvasMouse(row)
 -- Emergency handback touches only the public, unprotected native input
 -- fields this exact canvas lease already changed. Unlike generic structural
 -- lease release this is legal for a verified passive chat tree in combat.
 -- Keep the journal: the ordinary OOC release observes each original endpoint.
 local lease=row.canvasLease
 if not lease or not lease.lookup then return true end
 local generation,profile,native=self.generation,M.profile,row.native
 local function current() return self.generation==generation and M.profile==profile and self.rows[row.name]==row and row.native==native and _G[row.name]==native and row.canvasLease==lease end
 local complete=true
 for _,object in ipairs({native,field(native,"clickAnywhereButton")}) do
  local receipt=lease.lookup[object] and lease.lookup[object].mouse
  if receipt then
   if not current() then return false end
   local mouse,state=public(object,"IsMouseEnabled","boolean")
   if not current() then return false end
   if state~="KNOWN" then complete=false
   elseif mouse==receipt.original[1] then -- already native
   elseif receipt.written and mouse==receipt.written[1] or receipt.attempt and mouse==receipt.attempt[1] then
    if not S:Frame(object,true) or not current() then complete=false
    else
     local sent,result=call(object,"EnableMouse",receipt.original[1])
     complete=sent and result~=false and current() and public(object,"IsMouseEnabled","boolean")==receipt.original[1] and complete
    end
   end -- a newer public input choice wins
  end
 end
 return complete
end
function C:RetireCanvas(row,reason)
 if row.combatLog then return false end
 if row.frame and S:Frame(row.frame,true) then
  if M.Effects then M.Effects:CancelTransition(row,row.frame,false) end
  row.frame:Hide()
 end
 row.visibilityShown=false;row.visibilityAlpha=0;row.accessFallback=nil
 row.committed=false;row.canvasDirty=true;row.maskLost=reason or "CHAT_NATIVE_MASK_LOST"
 row.renderer="NATIVE_FALLBACK";row.visibilityDirty=true
 row.nativeInputFallback=self:RestoreCanvasMouse(row)
 if self:ChromeAlpha(row,1,true) then row.chromeNeedsRenew=true end
 row.dirty=true;row.styled=nil
 if row.surface then row.surface.reworkReadiness="PARTIAL" end
 R:RecordSurface(self,row.name,"PARTIAL",row.maskLost)
 self.pendingWork=true
 return row.nativeInputFallback
end
function C:WatchTextMask(row,object)
 self.maskHooks=self.maskHooks or setmetatable({},{__mode="k"})
 if self.maskHooks[object]==row then return true end
 if type(hooksecurefunc)~="function" then return false end
 for _,method in ipairs({"SetAlpha","SetParent","SetIgnoreParentAlpha","Show","SetShown"}) do
  if type(field(object,method))=="function" then
   local ok=pcall(hooksecurefunc,object,method,function()
    local current=C.rows[row.name]
    if current~=row or not C.active or C.writing or not row.committed or row.textMask~=object
     or row.canvasLease and (row.canvasLease.leaseWriteDepth or 0)>0 then return end
    if not C:MaskCurrent(row) then C.maskLosses=(C.maskLosses or 0)+1;C:RetireCanvas(row,"CHAT_NATIVE_MASK_LOST") end
   end)
   if not ok then return false end
  end
 end
 self.maskHooks[object]=row;return true
end
function C:Watch(row)
 local native=row.native
 if type(hooksecurefunc)~="function" then return false end
 local seen=self.hooks[native];if not seen then seen={};self.hooks[native]=seen end
 for _,method in ipairs({"AddMessage","BackFillMessage","RemoveMessagesByPredicate","TransformMessages","AdjustMessageColors",
  "Clear","SetMaxLines","SetFont","SetScrollOffset","ScrollUp","ScrollDown","PageUp","PageDown","ScrollToTop","ScrollToBottom","ScrollByAmount",
  "SetPoint","SetSize","SetWidth","SetHeight","SetScale","SetAlpha","Show","Hide"}) do
  if not seen[method] and type(field(native,method))=="function" then
   local content=method=="AddMessage" or method=="BackFillMessage" or method=="RemoveMessagesByPredicate" or method=="TransformMessages"
    or method=="AdjustMessageColors" or method=="Clear" or method=="SetMaxLines"
   local layout=method=="SetFont"
   local geometry=method=="SetPoint" or method=="SetSize" or method=="SetWidth" or method=="SetHeight" or method=="SetScale"
   local ok=pcall(hooksecurefunc,native,method,function(object,...)
    local message,red,green,blue,typeID=...
    if (method=="Show" or method=="Hide") and C.active and not C.writing and row.committed then
     local shown,state=public(native,"IsShown","boolean")
     if state=="KNOWN" and shown==row.nativeShown and C.active and C.rows[row.name]==row
      and row.native==native and _G[row.name]==native and row.committed then
      C.nativeVisibilityNoops=(C.nativeVisibilityNoops or 0)+1;return
     end
    end
    if method=="SetAlpha" and C.active and not C.writing and row.committed then
     -- Native fade code may write zero every rendered frame even though our
     -- admitted message canvas already masks the native text at zero. That
     -- is not a new visibility/content/layout change. Read the actual result:
     -- a nonzero or unreadable result must still take the normal repair path.
     local alpha,state=public(native,"GetAlpha","number")
      if row.textMask and C:MaskCurrent(row) and state=="KNOWN" and C.active and C.rows[row.name]==row
      and row.native==native and _G[row.name]==native and row.committed then
      C.nativeAlphaNoops=(C.nativeAlphaNoops or 0)+1
      return
     end
      if row.textMask and not C:MaskCurrent(row) then C.maskLosses=(C.maskLosses or 0)+1;C:RetireCanvas(row,"CHAT_NATIVE_MASK_LOST") end
    end
    if method=="AddMessage" and C.active and not C.writing and M.ScopedActivity then
     M.ScopedActivity:NotifyChatType(native,typeID)
    end
    if method=="Clear" and row.native==_G[row.name] then
     local h=C:HistoryStore(false);if h then h.windows[row.id]=nil end;row.replayed=true
    end
    if C.active then
     C:Mark(row,content,layout,method=="AddMessage",geometry)
     if method=="SetAlpha" and not C.writing and row.committed then row.canvasDirty=true end
    end
    if row.accessFallback and not C.writing and C:CanRoute(row) then
     -- One accepted insertion is forwarded to one retained display sink.
     -- No history scan, payload interpretation, fresh cue or background loop.
     if method=="AddMessage" then call(row.body,"AddMessage",...)
     elseif method=="Clear" then call(row.body,"Clear")
     elseif method=="Show" or method=="Hide" then C:RetainAccess(row) end
    end
   end)
   if not ok then return false end;seen[method]=true
  end
 end
 return true
end
function C:CreateView(native,name,id)
 if S:InCombat() or not S:Frame(native,false) then return nil end
 local f=CreateFrame("Frame",nil,UIParent,"BackdropTemplate")
 f:Hide();f:SetClampedToScreen(true);f:SetFrameStrata("LOW")
 f:SetFrameLevel((public(native,"GetFrameLevel","number") or 5)+4)
 f:SetBackdrop({bgFile=L.white})
 f:SetBackdropColor(tone("background",{.035,.035,.038,.98}))
 local row={native=native,name=name,id=id,frame=f,combatLog=id==2,dirty=true,layoutDirty=true,contentDirty=true,committed=false,firstCommit=true}
 local header=f:CreateTexture(nil,"BACKGROUND");header:SetColorTexture(tone("panel",{.060,.060,.065,.97}))
 header:SetPoint("TOPLEFT",f,"TOPLEFT",1,-1);header:SetPoint("TOPRIGHT",f,"TOPRIGHT",-1,-1);header:SetHeight(24)
 local rule=f:CreateTexture(nil,"BORDER");rule:SetColorTexture(.91,.55,.18,.70)
 rule:SetPoint("TOPLEFT",f,"TOPLEFT",9,-25);rule:SetPoint("TOPRIGHT",f,"TOPRIGHT",-9,-25);rule:SetHeight(1)
 row.heading=text(f,11);row.heading:SetPoint("TOPLEFT",10,-7);row.heading:SetTextColor(tone("text",{.90,.89,.87,1}))
 row.heading:SetText("CHAT")
 row.footer=text(f,9);row.footer:SetPoint("BOTTOMLEFT",10,5);row.footer:SetTextColor(tone("muted",{.63,.62,.60,1}))
 row.footer:SetText("Enter to chat")
 if not row.combatLog then
  local body=CreateFrame("ScrollingMessageFrame",nil,f);row.body=body
  body:SetPoint("TOPLEFT",10,-33);body:SetPoint("BOTTOMRIGHT",-28,32)
  body:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",13,"");body:SetJustifyH("LEFT")
  body:SetFading(false);body:SetMaxLines(10000);body:EnableMouse(true);body:EnableMouseWheel(true)
  if body.SetHyperlinksEnabled then body:SetHyperlinksEnabled(true) end
  if body.SetTextCopyable then body:SetTextCopyable(true) end
  body:SetScript("OnHyperlinkClick",function(_,link,label,button)
   if not C:CanRoute(row) then return end
   local handler=field(row.native,"OnHyperlinkClick")
   if type(handler)=="function" then handler(row.native,link,label,button) end
  end)
  body:SetScript("OnHyperlinkEnter",function(_,...) if C:CanRoute(row) then call(row.native,"OnHyperlinkEnter",...) end end)
  body:SetScript("OnHyperlinkLeave",function() if C:CanRoute(row) then call(row.native,"OnHyperlinkLeave") end end)
  body:SetScript("OnMouseWheel",function(_,delta)
   if not C:CanRoute(row) or not S:Number(delta) then return end
   local direction=delta>0 and 1 or -1
   local fast=S:Public(IsShiftKeyDown,"boolean")==true
   local target=row.view and row.view~="GENERAL" and row.filterBody or row.native
   call(target,fast and (direction>0 and "PageUp" or "PageDown") or (direction>0 and "ScrollUp" or "ScrollDown"))
   C:AccessScroll(row)
   C:Mark(row,false);M.CVE:Hold(row.surface,.4)
  end)
  body:SetScript("OnMouseUp",function(_,button)
   if not C:CanRoute(row) or button~="LeftButton" then return end
   M.CVE:Hold(row.surface,.4)
  end)
  if body.SetSpacing then body:SetSpacing(3) end
  row.unread=text(f,10);row.unread:SetPoint("BOTTOMRIGHT",-28,5);row.unread:SetTextColor(.94,.74,.41,1)
  local latest=CreateFrame("Button",nil,f);row.latest=latest
  latest:SetSize(88,18);latest:SetPoint("BOTTOMRIGHT",-28,1)
  latest:SetScript("OnClick",function()
   if C:CanRoute(row) then
    local target=row.view and row.view~="GENERAL" and row.filterBody or row.native
    call(target,"ScrollToBottom");C:AccessScroll(row);row.visibleOffset=nil;row.visibilityDirty=true;C.pendingWork=true;M.CVE:Hold(row.surface,.4)
   end
  end)
  latest:Hide()
 end
 local surface={id=id==1 and "Chat.nativePosition" or "Chat.messages"..id,module="Chat",frame=f,
  groups={chat=true},security="OWNED_VISUAL",fallback="VISIBLE",editable=id==1,holdOnHover=true,
  layout={x=-.37,y=-.29,width=380,height=170,scale=1},minWidth=220,minHeight=id==1 and 140 or 96,reworkProvider=self,
  label=id==1 and "Chat" or id==2 and "Combat log" or "Chat window "..id}
 surface.Apply=function(_,alpha) row.requestedAlpha=alpha;C:Visibility(row);return alpha<=0 and "HIDDEN" or alpha<1 and "AMBIENT" or "VISIBLE" end
 surface.OnLayout=function() C.pendingWork=true;row.geometryDirty=true;row.layoutDirty=true end
 surface.activityChatFrame=native
 surface.Intent=function()
  if not M.ScopedActivity then return "HIDDEN","CHAT_NO_LOCAL_DEMAND",2 end
  local shown=M.ScopedActivity:ChatWindow(native,S:Now()) or M.ScopedActivity:ChatDockCue(native,S:Now())
  return shown and "VISIBLE" or "HIDDEN",shown and "CHAT_ROUTED_ACTIVITY" or "CHAT_QUIET",2
 end
 row.surface=surface
 if id==1 then
  self:CreateTabs(row,header,rule)
  row.body:ClearAllPoints();row.body:SetPoint("TOPLEFT",10,-row.bodyTop);row.body:SetPoint("BOTTOMRIGHT",-28,32)
  self:FilterBuffer(row);row.filterBody=row.filterBuffer;row.filterBuffer=nil;self:FilterBuffer(row)
 end
 if M.surfaces[surface.id] then f:Hide();return nil end
 M.CVE:Register(surface);self.rows[name]=row
 -- Native controls retain their original parents, so they do not inherit the
 -- shell's animation alpha. Follow only actual shell alpha writes rather than
 -- waiting for the provider heartbeat or running a new idle update loop.
 if type(hooksecurefunc)=="function" then
  pcall(hooksecurefunc,f,"SetAlpha",function(_,alpha)
   if not C.active or not row.committed or row.blocked or C.rows[name]~=row
    or row.native~=_G[name] or not wanted() or not S:Number(alpha) then return end
   local generation,profile,body=C.generation,M.profile,row.body
   local function current() return C:Current(row,generation,profile,native) and row.body==body and row.frame==f and row.committed and not row.blocked end
   if not current() then return end
   local shown=public(row.native,"IsShown","boolean")==true
   if not current() then return end
   row.visibilityAlpha=shown and math.max(0,math.min(1,alpha)) or 0
   C:ChromeAlpha(row,row.visibilityAlpha)
   if not current() then return end
   if body then
    local interact=row.visibilityAlpha>0 and field(row.native,"isUninteractable")~=true
    if not current() then return end
    C:CanvasInput(row,interact,current)
   end
  end)
 end
 if id==1 then self.surface=surface;self.frame=f end
 if not self:Watch(row) then return nil end
 self:WatchInput(row)
 return row
end
function C:ResolveLayout(surface,profile,unfitted)
 profile=profile or M.profile
 local function fit(layout)
  local factor=profile.textScale
  if not S:Number(factor) then factor=1 end;factor=math.max(.65,math.min(2,factor))
  -- Native-origin rectangles bypass Layout:Get; old 96px chat layouts also
  -- need room for the tab row, editor and three readable lines.
  -- Resolve preview and runtime through this same copy; never rewrite saved
  -- size/position just because the text scale or active presentation changes.
  layout.width=math.max(220,layout.width)
  layout.height=math.max(140,33+32+3*(13*factor+3),layout.height)
  if not unfitted and M.Layout.Fit then layout=M.Layout:Fit(surface,layout,profile) end
  return M.Layout:Clamp(layout)
 end
 if profile.layouts and profile.layouts[surface.id] then
  return fit(unfitted and M.Layout.Unfitted and M.Layout:Unfitted(surface,profile) or M.Layout:Get(surface,profile))
 end
 if self.nativeOrigin then return fit(M:Copy(self.nativeOrigin)) end
 local n=_G.ChatFrame1
 local w,h,us=screen()
 local scale=public(n,"GetEffectiveScale","number")
 local cx,cy
 local ok,x,y=call(n,"GetCenter");if ok and S:Number(x) and S:Number(y) then cx,cy=x,y end
 local width,height=public(n,"GetWidth","number"),public(n,"GetHeight","number")
 if cx and w and h and scale and us and width and height and us>0 and w>0 and h>0 then
  self.nativeOrigin={x=cx*scale/us/w-.5,y=cy*scale/us/h-.5,width=width,height=height,scale=scale/us}
  return fit(M:Copy(self.nativeOrigin))
 end
 return fit(unfitted and M.Layout.Unfitted and M.Layout:Unfitted(surface,profile) or M.Layout:Get(surface,profile))
end
function C:AuthoredLayout(surface,profile)
 return self:ResolveLayout(surface,profile,true)
end
function C:ApplyLayout(surface)
 if S:InCombat() then surface.layoutPending=true;return false end
 if not surface or not surface.frame or surface.id~="Chat.nativePosition" then return false end
 local w,h=screen();if not w then surface.layoutPending=true;return false,"VIEWPORT_PENDING" end
 local l=self:ResolveLayout(surface,M.profile);local f=surface.frame
 local target=l.anchorTo and M.surfaces[l.anchorTo];local scale=l.scale or 1
 f:SetSize(l.width,l.height);f:SetScale(scale);f:ClearAllPoints()
 f:SetPoint("CENTER",target and target.frame or UIParent,"CENTER",l.x*w/scale,l.y*h/scale)
 surface.layoutPending=nil;self.serverNoticeDirty=true
 return true
end
local function pendingReceipts(owner)
 for _,receipt in ipairs(owner and owner.records or {}) do if receipt.pending then return true end end
 return false
end
local function queued(why)
 return why=="CHAT_STYLE_QUEUED" or why=="CHAT_HISTORY_QUEUED" or why=="CHAT_CANVAS_QUEUED" or why=="WINDOW_WORK_QUEUED"
end
local function styleClock()
 if type(debugprofilestop)=="function" then local ok,value=pcall(debugprofilestop);if ok and S:Number(value) then return value end end
end
-- Forever's world-refresh countdown is a native social toast with a
-- separate minimize control. Anchor those exact controls; leave the native
-- timer, visibility, click route and refresh confirmation entirely game-owned.
function C:PositionServerNotice()
 local row=self.rows.ChatFrame1
 if not self.active or not row or not row.committed or not wanted() then return false end
 if S:InCombat() then self.serverNoticeDirty=true;return false end
 local notice=_G.ShardTransferImminentFrame
 local button=_G.ShardTransferImminentMinimizeButton
 if not S:Frame(notice,true) then
  self.serverNoticeDirty=nil;self.serverNoticeStatus="NATIVE_NOTICE_NOT_AVAILABLE";return true
 end
 local generation,profile=self.generation,M.profile
 local function current() return self:Current(row,generation,profile,row.native) and _G.ShardTransferImminentFrame==notice end
 if not current() then return false end
 self.noticeHooks=self.noticeHooks or setmetatable({},{__mode="k"})
 for _,frame in pairs({notice,button}) do
  if S:Frame(frame,true) and not self.noticeHooks[frame] and type(hooksecurefunc)=="function" then
   local ok=pcall(hooksecurefunc,frame,"SetPoint",function()
    if C.active and not C.noticeWriting and wanted() then C.serverNoticeDirty=true;C.pendingWork=true end
   end)
   if ok then self.noticeHooks[frame]=true end
  end
 end
 self.noticeWriting=true
 local ok=L:Points(self,notice,pack("BOTTOMLEFT",row.frame,"TOPLEFT",29,8))
 if current() and S:Frame(button,true) then
  ok=L:Points(self,button,pack("TOPRIGHT",notice,"TOPLEFT",-5,0)) and ok
 end
 self.noticeWriting=nil
 if not current() then return false end
 self.serverNoticeDirty=nil
 self.serverNoticeStatus=ok and "ABOVE_CHAT_NATIVE_LIFETIME" or "NATIVE_NOTICE_POSITION_PENDING"
 return ok
end
function C:ControlLayer(row,control)
 if not S:Frame(control,false) then return true end
 local level=public(control,"GetFrameLevel","number")
 local base=public(row.frame,"GetFrameLevel","number")
 if not S:Number(level) or not S:Number(base) then return false end
 -- The owned message shell used to sit above its native input controls.
 -- Keep native parents and scripts; lease only their drawing level.
 return L:Scalar(row.lease,control,"frameLevel","GetFrameLevel","SetFrameLevel",math.max(level,base+2))
end
function C:RefreshGeometry(row)
 local lease,n=row.lease,row.native
 local generation,profile=self.generation,M.profile
 local function current() return self:Current(row,generation,profile,n) and row.lease==lease end
 if not lease or not lease.active or S:InCombat() then return false,"CHAT_STYLE_QUEUED" end
 if not current() then return false,"CHAT_OWNER_RETIRED" end
 if not screen() then row.layoutDirty=true;return false,"CHAT_STYLE_QUEUED" end
 local ok=true;self.writing=true
 if row.id==1 then
  local applied=self:ApplyLayout(row.surface)
  if applied==false then self.writing=nil;return false,"CHAT_STYLE_QUEUED" end
  if current() then ok=self:LayoutHeader(row,current) and ok end
  if current() then ok=L:Points(lease,n,pack("TOPLEFT",row.frame,"TOPLEFT",0,0,"BOTTOMRIGHT",row.frame,"BOTTOMRIGHT",0,0)) and ok end
  if current() then ok=L:Scalar(lease,n,"scale","GetScale","SetScale",1) and ok end
 else row.frame:ClearAllPoints();row.frame:SetAllPoints(n) end
 -- Attach every native chat component to the same message shell. The old
 -- native edit box/dock/scrollbar anchors sat outside its border, producing
 -- several disconnected panels even though they shared a visibility lease.
 local edit=field(n,"editBox")
 if current() and S:Frame(edit,false) then
  ok=L:AnchoredSize(lease,edit,nil,26,pack("BOTTOMLEFT",row.frame,"BOTTOMLEFT",1,1,"BOTTOMRIGHT",row.frame,"BOTTOMRIGHT",-1,1)) and ok
 end
 local scrollbar=field(n,"ScrollBar")
 if current() and S:Frame(scrollbar,false) then
  ok=L:AnchoredSize(lease,scrollbar,14,0,pack("TOPRIGHT",row.frame,"TOPRIGHT",-5,-(row.bodyTop or 33),"BOTTOMRIGHT",row.frame,"BOTTOMRIGHT",-5,36)) and ok
 end
 local bottom=field(n,"ScrollToBottomButton")
 if current() and S:Frame(bottom,false) then
  ok=L:AnchoredSize(lease,bottom,16,16,pack("BOTTOMRIGHT",row.frame,"BOTTOMRIGHT",-4,16)) and ok
 end
 local resize=field(n,"ResizeButton")
 if current() and S:Frame(resize,false) then
  ok=L:AnchoredSize(lease,resize,12,12,pack("BOTTOMRIGHT",row.frame,"BOTTOMRIGHT",-2,2)) and ok
 end
 local buttons=field(n,"buttonFrame")
 if current() and S:Frame(buttons,false) then
  ok=L:AnchoredSize(lease,buttons,20,0,pack("TOPRIGHT",row.frame,"TOPRIGHT",-3,-(row.bodyTop and row.bodyTop-2 or 31),"BOTTOMRIGHT",row.frame,"BOTTOMRIGHT",-3,30)) and ok
 end
 if row.id==1 then
  local dock=_G.GeneralDockManager
  if current() and S:Frame(dock,false) then
   ok=L:AnchoredSize(lease,dock,nil,24,pack("TOPLEFT",row.frame,"TOPLEFT",6,-27,"TOPRIGHT",row.frame,"TOPRIGHT",-78,-27)) and ok
   row.heading:Hide()
  else row.heading:Hide() end
 end
 local tab=_G[row.name.."Tab"]
 local dockState=field(n,"isDocked")
 local docked=dockState==true or dockState==1 or row.id==1 and S:Frame(_G.GeneralDockManager,false)
 if row.chrome and row.chrome[tab] then row.chrome[tab].drawer=docked and true or nil end
 if current() and not docked and S:Frame(tab,false) then
  ok=L:AnchoredSize(lease,tab,nil,26,pack("TOPLEFT",row.frame,"TOPLEFT",6,-1)) and ok
  row.heading:Hide()
 end
 for _,control in pairs({edit,scrollbar,bottom,resize,buttons,row.id==1 and _G.GeneralDockManager or nil,tab}) do
  if current() then ok=self:ControlLayer(row,control) and ok end
 end
 self.writing=nil
 if not current() then return false,"CHAT_OWNER_RETIRED" end
 if ok then row.layoutDirty=nil;row.geometryDirty=nil end
 if ok then return ok end
 return ok,"CHAT_GEOMETRY_PENDING"
end
function C:RefreshFont(row)
 if row.combatLog then row.fontDirty=nil;return true end
 local generation,profile,native,body=self.generation,M.profile,row.native,row.body
 local function current() return self:Current(row,generation,profile,native) and row.body==body end
 if not current() then return false,"CHAT_OWNER_RETIRED" end
 local good,path,size=call(row.native,"GetFont")
 if not current() then return false,"CHAT_OWNER_RETIRED" end
 local factor=M.profile.textScale or 1
 path=good and S:Text(path) and path or STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"
 size=math.max(8,math.min(36,(S:Number(size) and size or 13)*factor))
 local ok=call(row.body,"SetFont",path,size,"")
 if not current() then return false,"CHAT_OWNER_RETIRED" end
 if row.buffer then ok=call(row.buffer,"SetFont",path,size,"") and ok end
 if not current() then return false,"CHAT_OWNER_RETIRED" end
 for _,filtered in pairs({row.filterBody,row.filterBuffer}) do
  ok=call(filtered,"SetFont",path,size,"") and ok
  if not current() then return false,"CHAT_OWNER_RETIRED" end
 end
 row.fontDirty=nil;return ok
end
-- Native scrollbars, dock tabs and edit controls update independently. Their
-- generic native Update/OnShow hooks used to restart every chat-control tree,
-- including unrelated shared controls. Keep the invalidation with the exact
-- leased tree; structural/profile changes still request a complete pass.
local function currentStyleTree(frame,root)
 -- A cached node-to-root association is only a candidate. Native dock/pool
 -- code can move the node between style passes. Unknown or changed ancestry
 -- must invalidate the whole lease so its new containing tree is revisited.
 for _=0,8 do
  if frame==root then return true end
  local parent,state=public(frame,"GetParent")
  if state~="KNOWN" or not S:Frame(parent,false) then return false end
  frame=parent
 end
 return false
end
function C:MarkNativeWindowDirty(frame,lease)
 if not self.active or self.painting or not lease or not lease.active or lease.parentOwner~=self
  or lease.parentGeneration~=self.generation then return true end
 local row=lease.chatRow
 if lease~=self.sharedLease and (not row or self.rows[row.name]~=row or row.lease~=lease or row.native~=_G[row.name]) then return true end
 local root=lease.chatStyleRoots and lease.chatStyleRoots[frame]
 if root and currentStyleTree(frame,root) then
  lease.chatDirtyTrees=lease.chatDirtyTrees or setmetatable({},{__mode="k"})
  lease.chatDirtyTrees[root]=true
 else lease.chatFullStyle=true end
 lease.dirty=true;self.pendingWork=true
 if lease==self.sharedLease then self.sharedDirty=true end
 return true
end
local function resetStyleTrees(lease,full)
 local dirty=lease.chatDirtyTrees
 if full or lease.chatFullStyle or not dirty or not next(dirty) or not lease.completedTrees then
  lease.paintingToken=(lease.paintingToken or 0)+1
  lease.windowJobs=nil;lease.completedTrees=nil
  lease.chatStyleRoots=setmetatable({},{__mode="k"})
 else
  for root in pairs(dirty) do
   lease.completedTrees[root]=nil
   if lease.windowJobs then lease.windowJobs[root]=nil end
  end
 end
 lease.chatDirtyTrees=nil;lease.chatFullStyle=nil
 lease.stylePending=nil;lease.windowScanLimited=nil;lease.gaps=0;lease.dirty=nil
end
function C:StartStyle(row)
 local K=R.WindowKit;if not K then return false,"WINDOW_KIT_UNAVAILABLE" end
 local generation,profile,native=self.generation,M.profile,row.native
 if row.chromeNeedsRenew then row.chrome=nil;row.chromeScope=nil;row.chromeNeedsRenew=nil end
 local lease=row.lease
 if lease and lease.parentGeneration~=generation then
  lease.active=false;local clean=L:Release(lease)
  if not self:Current(row,generation,profile,native) then return false,"CHAT_OWNER_RETIRED" end
  if not clean then return false,"CHAT_PRESENTATION_RESTORE_PENDING" end
  lease=nil;row.lease=nil
 end
 if not lease then lease={id="chat",module="Chat",parentOwner=self};row.lease=lease end
 if lease.parentGeneration~=self.generation then lease.active=true;lease.parentGeneration=self.generation;L:Begin(lease) end
 self.rootLeaseOwners=self.rootLeaseOwners or {};self.rootLeaseOwners[row.name]=lease
 lease.cooperativeStyle=true;lease.chatRow=row
 resetStyleTrees(lease,row.dirty==true)
 row.dirty=nil;row.styled=nil
 local plan={tasks={},index=1,profile=M.profile,generation=self.generation,native=row.native}
 row.styleWork=plan
 local function add(fn) plan.tasks[#plan.tasks+1]=fn end
 local function tree(frame,opts,prepare)
  if not S:Frame(frame,false) then return end
  opts.visit=function(node) lease.chatStyleRoots[node]=frame;return true end
  local prepared=false
  add(function()
   if not prepared then
    if prepare and prepare()==false then return false,"CHAT_PRESENTATION_PENDING" end
    prepared=true
   end
   opts.budgetNodes=24
   return K:StyleTree(lease,frame,opts)
  end)
 end
 local n=row.native
 add(function()
  local title=S:Public(GetChatWindowInfo,"string",row.id)
  if not self:Current(row,generation,profile,native) or row.styleWork~=plan then return false,"CHAT_OWNER_RETIRED" end
  row.heading:SetText(title or (row.combatLog and "COMBAT LOG" or "CHAT"))
  if not self:Current(row,generation,profile,native) or row.styleWork~=plan then return false,"CHAT_OWNER_RETIRED" end
  row.headingDirty=nil
  if row.surface then row.surface.label=row.id==1 and "Chat" or row.combatLog and "Combat log" or title and ("Chat — "..title) or ("Chat window "..row.id) end
  return true
 end)
 for _,key in ipairs({"editBox","ScrollBar","ScrollToBottomButton","ResizeButton","buttonFrame"}) do
  local control=field(n,key)
  tree(control,{role="content",maxNodes=128,maxDepth=6,fill=.88},function()
   if row.combatLog then return true end
   local ok=L:Scalar(lease,control,"ignoreParentAlpha","IsIgnoringParentAlpha","SetIgnoreParentAlpha",true)
   if key=="editBox" then self:WatchInput(row) end
   return self:TrackChrome(row,control) and ok
  end)
 end
 local tab=_G[row.name.."Tab"]
 tree(tab,{role="content",maxNodes=48,maxDepth=4,fill=.9},function()
  local docked=field(n,"isDocked")
  return (row.id==1 or docked==true or docked==1) and self:TrackDrawer(row,tab,true) or self:TrackChrome(row,tab,true)
 end)
 for _,suffix in ipairs({"Background","TopLeftTexture","BottomLeftTexture","TopRightTexture","BottomRightTexture","LeftTexture","RightTexture","BottomTexture","TopTexture",
  "ButtonFrameBackground","ButtonFrameTopLeftTexture","ButtonFrameBottomLeftTexture","ButtonFrameTopRightTexture","ButtonFrameBottomRightTexture","ButtonFrameLeftTexture","ButtonFrameRightTexture","ButtonFrameBottomTexture","ButtonFrameTopTexture"}) do
  local art=_G[row.name..suffix]
  -- FCF_FadeInChatFrame writes alpha to every shown CHAT_FRAME_TEXTURES
  -- region. Lease shown-state so hover cannot revive native window art.
  if S:Frame(art,false) then add(function() return L:Scalar(lease,art,"shown","IsShown","SetShown",false) end) end
 end
 if S:Frame(tab,false) then
  add(function()
   local ok=K:Panel(lease,tab,.65)
   for _,key in ipairs({"Left","Middle","Right"}) do local art=field(tab,key);if S:Frame(art,false) then ok=L:Alpha(lease,art,0) and ok end end
   return ok
  end)
  for _,key in ipairs({"ActiveLeft","ActiveMiddle","ActiveRight","HighlightLeft","HighlightMiddle","HighlightRight","glow"}) do
   local art=field(tab,key)
   if S:Frame(art,false) then add(function()
    local texture=L.DecorativeTexture or L.Texture
    local ok=texture(L,lease,art,L.white)
    ok=L:Points(lease,art,pack("BOTTOMLEFT",tab,"BOTTOMLEFT",3,1,"BOTTOMRIGHT",tab,"BOTTOMRIGHT",-3,1)) and ok
    ok=L:Scalar(lease,art,"height","GetHeight","SetHeight",2) and ok
    return L:Color(lease,art,"chatTabTint","GetVertexColor","SetVertexColor",1,.66,.20,.8) and ok
   end) end
  end
 end
 local edit=field(n,"editBox")
 if S:Frame(edit,false) then
  for _,suffix in ipairs({"Left","Right","Mid"}) do
   local art=_G[row.name.."EditBox"..suffix]
   if S:Frame(art,false) then add(function() return L:Alpha(lease,art,0) end) end
  end
  for _,key in ipairs({"focusLeft","focusRight","focusMid"}) do
   local art=field(edit,key)
   if S:Frame(art,false) then add(function()
    local texture=L.DecorativeTexture or L.Texture
    local ok=texture(L,lease,art,L.white)
    ok=L:Points(lease,art,pack("BOTTOMLEFT",edit,"BOTTOMLEFT",1,1,"BOTTOMRIGHT",edit,"BOTTOMRIGHT",-1,1)) and ok
    ok=L:Scalar(lease,art,"height","GetHeight","SetHeight",1) and ok
    return L:Color(lease,art,"chatFocusTint","GetVertexColor","SetVertexColor",1,.66,.20,1) and ok
   end) end
  end
 end
 if row.id==1 then
  for i,name in ipairs({"ChatFrameMenuButton","ChatFrameChannelButton","TextToSpeechButtonFrame"}) do
   local control=_G[name]
   if S:Frame(control,true) then tree(control,{role="content",maxNodes=32,maxDepth=4,fill=.88},function()
    local ok=self:TrackDrawer(row,control,true)
    ok=self:ControlLayer(row,control) and ok
    return L:AnchoredSize(lease,control,18,18,pack("TOPRIGHT",row.frame,"TOPRIGHT",-6-(i-1)*22,-30)) and ok
   end) end
  end
  add(function()
   local ok=true
   for _,name in ipairs({"GeneralDockManager","QuickJoinToastButton"}) do
    if S:Frame(_G[name],true) then
     ok=(name=="GeneralDockManager" and self:TrackDrawer(row,_G[name],true) or self:TrackChrome(row,_G[name],true)) and ok
    end
   end
   return ok
  end)
 end
 tree(_G[row.name.."Minimized"],{role="content",maxNodes=48,maxDepth=4,fill=.8})
 if row.combatLog then
  tree(n,{role="content",maxNodes=350,maxDepth=8})
  add(function() row.frame:SetFrameLevel(math.max(0,(public(n,"GetFrameLevel","number") or 5)-1));return true end)
 else add(function() return self:RefreshFont(row) end) end
 -- The native rectangle remains intact while its hidden canvas is prepared.
 -- Geometry is the final staged task, immediately before canvas admission.
 add(function() return self:SuppressScrollArrows(row) end)
 add(function() if row.layoutDirty or row.geometryDirty then return self:RefreshGeometry(row) end;return true end)
 return true
end
function C:Style(row)
 if S:InCombat() then return false,"CHAT_STYLE_QUEUED" end
 if not self.active or not S:Frame(row.native,false) or row.native~=_G[row.name] then return false,"CHAT_FRAME_REPLACED" end
 local generation,profile,native=self.generation,M.profile,row.native
 local function ownerCurrent() return self:Current(row,generation,profile,native) end
 local plan=row.styleWork
 if plan and (plan.profile~=M.profile or plan.generation~=self.generation or plan.native~=row.native) then
  row.styleWork=nil;return false,"CHAT_OWNER_RETIRED"
 end
 if not plan then local ok,why=self:StartStyle(row);if not ok then return false,why end;plan=row.styleWork end
 if not ownerCurrent() then return false,"CHAT_OWNER_RETIRED" end
 local function current() return ownerCurrent() and row.styleWork==plan end
 local lease=row.lease
 lease.styleBudget=self.styleBudget or {remaining=24,steps=0,started=styleClock()}
 self.writing=true;self.painting=true;lease.writing=true;lease.painting=true
 local complete,why=true,nil
 local steps=0
 while plan.index<=#plan.tasks and steps<8 do
  if not current() then complete=false;why="CHAT_OWNER_RETIRED";break end
  local ok,done,reason=pcall(plan.tasks[plan.index])
  if not current() then complete=false;why="CHAT_OWNER_RETIRED";break end
  if not ok then complete=false;why="CHAT_STYLE_EXCEPTION";break end
  if done==false then complete=false;why=queued(reason) and "CHAT_STYLE_QUEUED" or reason or "CHAT_PRESENTATION_PENDING";break end
  plan.index=plan.index+1;steps=steps+1
  if lease.styleBudget.remaining<=0 then complete=false;why="CHAT_STYLE_QUEUED";break end
 end
 lease.writing=nil;lease.painting=nil;lease.styleBudget=nil;self.writing=nil;self.painting=nil
 if not current() then return false,"CHAT_OWNER_RETIRED" end
 if not complete then return false,why end
 if plan.index<=#plan.tasks then return false,"CHAT_STYLE_QUEUED" end
 row.styleWork=nil
 if (lease.gaps or 0)>0 or pendingReceipts(lease) or lease.windowScanLimited then return false,"CHAT_PRESENTATION_PENDING" end
 row.styled=true
 return true
end
-- Native text/input are leased only after a complete owned message canvas and
-- its controls exist. A rejected local skin leaves native chat fully usable.
function C:CommitCanvas(row)
 if row.committed and not row.combatLog and row.textMask and not self:MaskCurrent(row) then self:RetireCanvas(row,"CHAT_NATIVE_MASK_LOST") end
 if row.committed and not row.canvasDirty then return true end
 if not row.styled or not row.combatLog and not row.bodyReady then return false,"CHAT_CANVAS_QUEUED" end
 if not row.committed and S:InCombat() then return false,"CHAT_CANVAS_QUEUED" end
 if row.combatLog then row.committed=true;row.canvasDirty=nil;return true end
 local generation,profile,native,body=self.generation,M.profile,row.native,row.body
 local function ownerCurrent() return self:Current(row,generation,profile,native) and row.body==body and row.bodyReady end
 local function current() return ownerCurrent() and row.styled end
 if not current() then return false,"CHAT_OWNER_RETIRED" end
 local mask,kind=self:TextMask(row)
 if not mask then return false,kind end
 local lease=row.canvasLease
 if lease and (lease.parentGeneration~=generation or row.textMask and row.textMask~=mask) then
  local reason=lease.parentGeneration~=generation and "CHAT_CANVAS_GENERATION_CHANGED" or "CHAT_MASK_IDENTITY_CHANGED"
  if row.committed then self:RetireCanvas(row,reason) end
  -- Retirement deliberately invalidates the styling proof. It does not
  -- invalidate the row/native owner. A profile refresh must finish releasing
  -- that old lease and queue a fresh style pass, rather than block the row on
  -- its own intentional reset (the former CHAT_ROWS_PARTIAL failure).
  if not ownerCurrent() then return false,"CHAT_OWNER_RETIRED" end
  if S:InCombat() then return false,"CHAT_CANVAS_QUEUED" end
  lease.active=false;local clean=L:Release(lease)
  if not ownerCurrent() then return false,"CHAT_OWNER_RETIRED" end
  if not clean then return false,"CHAT_CANVAS_HANDOFF_PENDING" end
  if self.rootLeaseOwners and self.rootLeaseOwners[row.name.."Canvas"]==lease then self.rootLeaseOwners[row.name.."Canvas"]=nil end
  lease=nil;row.canvasLease=nil
  row.textMask=nil;row.maskKind=nil
  if not row.styled then return false,"CHAT_CANVAS_QUEUED" end
 end
 if not lease then lease={id="chat",module="Chat",parentOwner=self};row.canvasLease=lease end
 if lease.parentGeneration~=self.generation then lease.active=true;lease.parentGeneration=self.generation;L:Begin(lease) end
 self.rootLeaseOwners=self.rootLeaseOwners or {};self.rootLeaseOwners[row.name.."Canvas"]=lease
 row.textMask=mask;row.maskKind=kind
 if not self:WatchTextMask(row,mask) then return false,"CHAT_MASK_GUARD_UNAVAILABLE" end
 local n=row.native
 self.writing=true
 -- The reviewed native chat fade writes its own alpha repeatedly. Reconcile
 -- only this exact admitted canvas; never schedule a complete control-tree scan.
 local ok=L:Write(lease,mask,"alpha",function(o) return pack(o:GetAlpha()) end,function(o,v) return o:SetAlpha(v[1]) end,pack(0),row.committed==true)
 if not current() then self.writing=nil;return false,"CHAT_OWNER_RETIRED" end
 ok=L:Scalar(lease,n,"mouse","IsMouseEnabled","EnableMouse",false) and ok
 if not current() then self.writing=nil;return false,"CHAT_OWNER_RETIRED" end
 local click=field(n,"clickAnywhereButton")
 if click then ok=L:Scalar(lease,click,"mouse","IsMouseEnabled","EnableMouse",false) and ok end
 self.writing=nil
 if not current() then return false,"CHAT_OWNER_RETIRED" end
 if not ok or pendingReceipts(lease) or not self:MaskCurrent(row) then
  if not self:MaskCurrent(row) then self:RetireCanvas(row,"CHAT_NATIVE_MASK_LOST") end
  return false,"CHAT_CANVAS_HANDOFF_PENDING"
 end
 row.committed=true;row.accessFallback=nil;row.canvasDirty=nil;row.maskLost=nil;row.renderer="MIRAGE_CANVAS";row.visibilityDirty=true;return true
end
function C:Buffer(row)
 if row.buffer then return row.buffer end
 local generation,profile,native,original=self.generation,M.profile,row.native,row.body
 local function current() return self:Current(row,generation,profile,native) and row.body==original end
 if not current() then return nil end
 local body=CreateFrame("ScrollingMessageFrame",nil,row.frame)
 body:Hide();body:SetPoint("TOPLEFT",10,-(row.bodyTop or 33));body:SetPoint("BOTTOMRIGHT",-28,32)
 body:SetFading(false);body:EnableMouse(false);body:EnableMouseWheel(false)
 if body.SetHyperlinksEnabled then body:SetHyperlinksEnabled(false) end
 if body.SetTextCopyable then body:SetTextCopyable(true) end
 if body.SetSpacing then body:SetSpacing(3) end
 body:SetJustifyH("LEFT")
 for _,event in ipairs({"OnHyperlinkClick","OnHyperlinkEnter","OnHyperlinkLeave","OnMouseWheel","OnMouseUp"}) do body:SetScript(event,row.body:GetScript(event)) end
 local _,path,size,flags=call(row.body,"GetFont");body:SetFont(path or STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",size or 13,flags or "")
 if not current() then body:Hide();return nil end
 row.buffer=body;return body
end
function C:Sync(row)
 local generation,profile,native,original=self.generation,M.profile,row.native,row.body
 local slice=self.styleBudget
 local function ownerCurrent()
  return self:Current(row,generation,profile,native) and row.body==original and self.styleBudget==slice
 end
 if not ownerCurrent() then return false,"CHAT_OWNER_RETIRED" end
 if row.combatLog then row.contentDirty=nil;row.bodyReady=true;return true end
 local revision=row.contentGeneration
 local count,state=public(native,"GetNumMessages","number")
 if not ownerCurrent() then return false,"CHAT_OWNER_RETIRED" end
 if state~="KNOWN" or count<0 or count>10000 or count%1~=0 then return false,"CHAT_HISTORY_UNAVAILABLE" end
 local capacity=public(native,"GetMaxLines","number") or math.max(128,count)
 if not ownerCurrent() then return false,"CHAT_OWNER_RETIRED" end
 if capacity<1 or capacity>10000 or capacity%1~=0 then return false,"CHAT_HISTORY_CAPACITY_UNSUPPORTED" end
 local budget=math.max(0,self.messageBudget or 128)
 if budget==0 then return false,"CHAT_HISTORY_QUEUED" end
 local additions=row.pendingAdds
 local append=row.bodyReady and not row.syncJob and not row.fullSync and S:Number(additions) and additions>0
  and additions<=math.min(count,budget) and S:Number(row.messageCount) and count==math.min(capacity,row.messageCount+additions)
 local job=row.syncJob
 local function current()
  return ownerCurrent() and row.syncJob==job and (append or job and job.body==row.buffer and job.body~=original)
 end
 if not append then
  if job and (job.profile~=profile or job.generation~=generation or job.native~=native or job.body~=row.buffer or job.body==original
   or job.capacity~=capacity or job.mutation~=(row.mutationGeneration or 0)) then job=nil;row.syncJob=nil end
  if not job then
   local body=self:Buffer(row)
   if not ownerCurrent() then return false,"CHAT_OWNER_RETIRED" end
   if not body or body==original then return false,"CHAT_MESSAGE_SINK_FAILED" end
   job={body=body,profile=profile,generation=generation,native=native,capacity=capacity,
    initialCount=count,baseAppends=row.totalAppends or 0,mutation=row.mutationGeneration or 0,next=1}
   row.syncJob=job
   for _,operation in ipairs({{"Hide"},{"Clear"},{"SetMaxLines",capacity}}) do
    if not current() then return false,"CHAT_OWNER_RETIRED" end
    local sent=call(body,unpack(operation))
    if not current() then return false,"CHAT_OWNER_RETIRED" end
    if not sent then return false,"CHAT_MESSAGE_SINK_FAILED" end
   end
  end
 end
 if not current() then return false,"CHAT_OWNER_RETIRED" end
 local total=append and count or job.initialCount+(row.totalAppends or 0)-job.baseAppends
 local shift=math.max(0,total-capacity)
 if count~=math.min(capacity,total) then row.syncJob=nil;row.fullSync=true;return false,"CHAT_HISTORY_QUEUED" end
 local first=append and count-additions+1 or math.max(job.next,shift+1)
 local last=append and count or math.min(total,first+budget-1)
 local values={}
 for i=first,last do
  if not current() then return false,"CHAT_OWNER_RETIRED" end
  local v=data(row,append and i or i-shift)
  if not current() then return false,"CHAT_OWNER_RETIRED" end
  self.lastMessageReads=(self.lastMessageReads or 0)+1
  if not v then return false,"CHAT_HISTORY_READ_FAILED" end
  values[#values+1]=v
 end
 self.messageBudget=budget-#values
 if not current() then return false,"CHAT_OWNER_RETIRED" end
 if row.contentGeneration~=revision then return false,"CHAT_HISTORY_QUEUED" end
 local body=append and original or job.body
 if append and row.bodyCapacity~=capacity then
  local sent=call(body,"SetMaxLines",capacity)
  if not current() then return false,"CHAT_OWNER_RETIRED" end
  if not sent then return false,"CHAT_MESSAGE_SINK_FAILED" end
 end
 for _,v in ipairs(values) do
  if not current() then return false,"CHAT_OWNER_RETIRED" end
  local sent=call(body,"AddMessage",unpack(v,1,v.n))
  if not current() then return false,"CHAT_OWNER_RETIRED" end
  if not sent then return false,"CHAT_MESSAGE_SINK_FAILED" end
 end
 if row.contentGeneration~=revision then
  if append then row.fullSync=true;row.pendingAdds=nil else job.next=last+1 end
  return false,"CHAT_HISTORY_QUEUED"
 end
 if not append then
  job.next=last+1
  if job.next<=total then return false,"CHAT_HISTORY_QUEUED" end
 end
 local offset=public(native,"GetScrollOffset","number") or 0
 if not current() then return false,"CHAT_OWNER_RETIRED" end
 call(body,"SetScrollOffset",offset)
 if not current() then return false,"CHAT_OWNER_RETIRED" end
 if not append then
  -- Native ring entries that aged out before their slice were skipped. Any
  -- older copied entries are evicted by the owned sink's identical capacity.
  -- This allows a saturated ring to converge while new messages arrive.
  -- No visibility callback may run before this atomic ownership swap. The
  -- former sink remains the only displayed layer until Visibility commits
  -- the finished sink; partially copied history never reaches the screen.
  row.body=body;row.buffer=original
  row.syncJob=nil;row.interactive=nil
 end
 row.messageCount=count;row.bodyCapacity=capacity;row.bodyReady=true;row.contentDirty=nil;row.pendingAdds=nil;row.fullSync=nil;row.historyDirty=true
 if row.tabs then
  if append then
   row.displayAppends=(row.displayAppends or 0)+#values
   if row.filterView==row.view and not row.filterDirty and row.view~="GENERAL" then
    for _,v in ipairs(values) do
     if not self:Current(row,generation,profile,native) then return false,"CHAT_OWNER_RETIRED" end
     if self:LineInView(v,row.view) then call(row.filterBody,"AddMessage",unpack(v,1,v.n)) end
    end
   elseif row.view~="GENERAL" then row.filterDirty=true end
  else row.displayEpoch=(row.displayEpoch or 0)+1;row.filterJob=nil;row.filterDirty=true end
 end
 row.visibilityDirty=true
 row.appendPasses=(row.appendPasses or 0)+(append and 1 or 0);row.fullPasses=(row.fullPasses or 0)+(append and 0 or 1)
 return true
end
function C:Visibility(row)
 if row.committed and not row.combatLog and row.textMask and not self:MaskCurrent(row) then self:RetireCanvas(row,"CHAT_NATIVE_MASK_LOST");return end
 if row.accessFallback then self:RetainAccess(row);return end
 if not self.active or row.blocked or row.committed==false or not S:Frame(row.frame,true) then return end
 local generation,profile,native,frame,body=self.generation,M.profile,row.native,row.frame,row.body
 local buffer,filteredBody,filterBuffer,view=row.buffer,row.filterBody,row.filterBuffer,row.view
 local function current()
  return self:Current(row,generation,profile,native) and row.frame==frame and row.body==body and row.buffer==buffer
   and row.filterBody==filteredBody and row.filterBuffer==filterBuffer and row.view==view and row.committed~=false and not row.blocked
 end
 if not current() then return end
 local nativeShown=public(native,"IsShown","boolean")==true
 if not current() then return end
 local alpha=row.requestedAlpha
 if alpha==nil then
  -- A newly prepared row waits for its first scoped policy result. It must
  -- not flash a chat panel at idle between canvas commit and the next CVE pass.
  local desired=row.surface.desired or "HIDDEN";alpha=(desired=="HIDDEN" and 0 or desired=="AMBIENT" and .25 or 1)*(profile.modules.Chat.alpha or 1)
 end
 local typing=self:Typing(row)
 if not current() then return end
 local keybindMode=(M.state.keybindWorkspace==true or M.state.trackerWorkspace==true)
 row.keybindVisibleState=keybindMode
 row.keybindCueUntil=nil
 if keybindMode then
  local cue,_,untilAt
  if M.ScopedActivity then
   cue,_,untilAt=M.ScopedActivity:ChatWindow(native,S:Now(),true)
   if not cue then cue,untilAt=M.ScopedActivity:ChatDockCue(native,S:Now(),true) end
  end
  alpha=(typing or cue) and 1 or 0
  row.keybindCueUntil=untilAt
 end
 row.footer:SetShown(not typing)
 if not current() then return end
 if typing and nativeShown then alpha=math.max(alpha,1) end
 local target=nativeShown and alpha or 0
 local hover=row.surface.localHover==true or target==0 and row.contextHover==true
 row.contextHover=hover
 -- First handoff and focused typing are exact endpoints, never a half-faded
 -- input layer waiting for the next shared animation callback.
 local immediate=typing or row.firstCommit or keybindMode
 if immediate and M.Effects then M.Effects:CancelTransition(row,frame,false) end
 local accepted=not immediate and M.Effects and M.Effects.Transition and M.Effects:Transition(row,frame,target>0,{alpha=target,constantRate=true,guard=current,onFinished=function()
  -- The shared fade clock can finish between cached CVE evaluations. Wake
  -- one last local pass so native chrome/input reaches the exact endpoint.
  if current() then row.visibilityDirty=true;C.pendingWork=true end
 end})
 if not current() then return end
 if not accepted then
  frame:SetAlpha(target)
  if not current() then return end
  frame:SetShown(target>0)
 end
 row.firstCommit=nil
 if not current() then return end
 local visible=public(frame,"IsShown","boolean")==true
 if not current() then return end
 alpha=visible and (public(frame,"GetAlpha","number") or 0) or 0
 if not current() then return end
 row.nativeShown=nativeShown;row.visibilityAlpha=alpha;row.visibilityShown=visible;row.visibilityDirty=nil
 self:ChromeAlpha(row,nativeShown and alpha or 0)
 if not current() then return end
 if body then
  local interact=alpha>0 and nativeShown and field(native,"isUninteractable")~=true
  if not current() or not self:CanvasInput(row,interact,current) then return end
  local filtered=view and view~="GENERAL"
  local visibleBody=filtered and row.filterView==view and filteredBody or not filtered and body or nil
  -- A pooled sink has exactly one presentation owner. Always withdraw the
  -- retired/general/filter staging layers before showing the published one.
  -- This also repairs a retained visible buffer after a prior interrupted
  -- handoff without scanning native fonts, changing history, or replaying text.
  if not self:PresentCanvas(row,visibleBody,current)then return end
  if row.empty then
   local count=filtered and row.filterView==row.view and public(row.filterBody,"GetNumMessages","number") or 0
   row.empty:SetShown(filtered and (count==0 or row.filterView~=row.view))
   if filtered then
    local title=row.view=="TRADE" and "Trade" or "Zone"
    row.empty:SetText(row.filterDirty and "Loading messages..." or self.channelAvailable and self.channelAvailable[row.view] and ("No "..string.lower(title).." messages yet.") or (title.." channel unavailable here."))
   end
  end
  local offset=public(filtered and visibleBody or native,"GetScrollOffset","number") or 0
  if not current() then return end
  if row.visibleOffset~=offset then
   if not filtered then call(body,"SetScrollOffset",offset) end
   if not current() then return end
   row.visibleOffset=offset
   row.unread:SetText(offset>0 and "Latest" or "")
   if not current() then return end
   row.latest:SetShown(offset>0)
   if not current() then return end
  end
  local footerText=offset>0 and "Scrollback · Shift + wheel to page" or filtered and "Filtered view · Enter to chat" or "Enter to chat"
  if filtered and not (self.channelAvailable and self.channelAvailable[row.view]) then
   footerText=(row.view=="TRADE" and "Trade" or "Zone").." unavailable here · History"
  end
  if row.footerText~=footerText then row.footer:SetText(footerText);row.footerText=footerText end
  if not current() then return end
  if row.latest then row.latest:SetShown(offset>0 and not typing) end
  if not current() then return end
  if row.unread then row.unread:SetShown(not typing) end
 end
end
function C:BlockRow(row,why)
 row.blocked=why or "CHAT_ROW_PENDING";row.contentDirty=nil;row.styleWork=nil;row.syncJob=nil
 row.surface.reworkReadiness="PARTIAL";R:RecordSurface(self,row.name,"PARTIAL",row.blocked)
 if not row.combatLog and row.textMask and not self:MaskCurrent(row) then self:RetireCanvas(row,row.maskLost or "CHAT_NATIVE_MASK_LOST") end
 if S:InCombat() then row.recoverPending=true;return false end
 if (row.restoreAttempts or 0)>=3 then row.recoverPending=true;return false end
 row.restoreAttempts=(row.restoreAttempts or 0)+1
 local clean=self:ChromeAlpha(row,1,true);local canvasClean=true
 if row.canvasLease then row.canvasLease.active=false;canvasClean=L:Release(row.canvasLease);clean=canvasClean and clean end
 if canvasClean and row.lease then row.lease.active=false;clean=L:Release(row.lease) and clean end
 row.recoverPending=not clean
 if canvasClean then
  if M.Effects then M.Effects:CancelTransition(row,row.frame,false) end
  row.frame:Hide();row.visibilityShown=nil;row.surface.disabled=true;row.committed=false;row.accessFallback=nil
 else self:RetainAccess(row) end
 return clean
end
-- Discovery records named candidates only. Creation, tree styling and history
-- copying are serviced by the shared budget below, never by one global scan.
function C:CandidateRequired(native,id)
 local docked=field(native,"isDocked");local inUse=field(native,"inUse");local minimized=field(native,"minimized")
 -- FloatingChatFrameMixin marks every prototype isInitialized on the same
 -- update event, including unused hidden windows. That flag is not demand.
 -- Shown, docked, minimized and in-use temporary windows are real channels;
 -- an unused hidden prototype keeps only this lightweight watcher.
 return id==1 or public(native,"IsShown","boolean")==true or docked==1 or docked==true
  or inUse==true or minimized==true
end
function C:WatchCandidate(native,id)
 self.candidateHooks=self.candidateHooks or setmetatable({},{__mode="k"})
 self.candidateStates=self.candidateStates or setmetatable({},{__mode="k"})
 self.candidateStates[native]=self:CandidateRequired(native,id)
 if self.candidateHooks[native] or type(hooksecurefunc)~="function" then return end
 for _,method in ipairs({"Show","Hide","SetShown"}) do
  if type(field(native,method))=="function" then pcall(hooksecurefunc,native,method,function()
   if C.active and not C.writing then
    local required=C:CandidateRequired(native,id)
    if C.candidateStates[native]~=required then
     C.candidateStates[native]=required;C.discoveryDirty=true;C.pendingWork=true
    end
   end
  end) end
 end
 self.candidateHooks[native]=true
end
function C:Discover()
 local names,ordered={},{};local list=_G.CHAT_FRAMES;local inspected=0
 local limited=false
 if S:Readable(list) and type(list)=="table" then
  for _,name in pairs(list) do
   inspected=inspected+1;if inspected>256 then limited=true;break end
   if S:Text(name) and name:match("^ChatFrame%d+$") then
    local id=tonumber(name:match("(%d+)$"));if id and id>=1 and id<=128 then names[name]=id else limited=true end
   end
  end
 end
 for i=1,10 do if S:Frame(_G["ChatFrame"..i],false) then names["ChatFrame"..i]=i end end
 local required=0
 for name,id in pairs(names) do
  local native=_G[name];local needed=self:CandidateRequired(native,id)
  ordered[#ordered+1]={name=name,id=id,required=needed}
  if needed then required=required+1 end
  if S:Frame(native,false) then self:WatchCandidate(native,id) end
 end
 table.sort(ordered,function(a,b) return a.id<b.id end)
 self.windowOrder=ordered;self.windowCount=required;self.candidateCount=#ordered;self.discoveryLimited=limited
 self.windowFailures={};self.discoveryDirty=nil;self.sharedDirty=true;self.sharedFullStyle=true;self.pendingWork=true
 return self:Readiness()
end
function C:RowNeedsWork(row,combat,entry)
 if entry and entry.required==false and not (row and row.blocked and row.recoverPending) then return false end
 if not row then return not combat end
 if row.blocked then return not combat and row.recoverPending and (row.restoreAttempts or 0)<3 or false end
 if row.contentDirty or row.canvasDirty and row.committed or row.view and row.view~="GENERAL" and row.filterDirty then return true end
 return not combat and (not row.committed or row.dirty or row.styleWork or row.geometryDirty or row.layoutDirty or row.fontDirty or row.headingDirty
  or row.lease and row.lease.dirty) or false
end
function C:ProcessRow(entry)
 local name,id=entry.name,entry.id;local row=self.rows[name];local native=_G[name]
 local generation,profile=self.generation,M.profile
 local function current() return row and self:Current(row,generation,profile,native) end
 if not S:Frame(native,false) then
  self.windowFailures[name]="CHAT_WINDOW_UNAVAILABLE";R:RecordSurface(self,name,"PARTIAL","CHAT_WINDOW_UNAVAILABLE");return
 end
 if row and row.native~=native then self:BlockRow(row,"CHAT_FRAME_REPLACED");return end
 if row and row.blocked then self:BlockRow(row,row.blocked);return end
 if not row then
  row=self:CreateView(native,name,id)
  if not row then self.windowFailures[name]="CHAT_VIEW_SETUP_FAILED";R:RecordSurface(self,name,"PARTIAL","CHAT_VIEW_SETUP_FAILED");return end
 end
 if not current() then return end
 if not row.replayed then
  local restored=self:RestoreHistory(row)
  if not current() then return end
  if not restored then self:BlockRow(row,"CHAT_HISTORY_BACKFILL_FAILED");return end
 end
 local pending=false
 local function accept(ok,why)
  if not current() then return false end
  if ok then return true end
  if queued(why) then pending=true;return true end
  self:BlockRow(row,why);return false
 end
 -- Prepare message history before any native geometry is changed. Startup
 -- no longer anchors native chat to a still-hidden, uncommitted shell.
 if row.contentDirty then if not accept(self:Sync(row)) then return end end
 if row.contentDirty and not row.committed then
  row.surface.reworkReadiness="WAITING";R:RecordSurface(self,name,"WAITING","CHAT_HISTORY_QUEUED");return
 end
 if row.styleWork or row.dirty or row.lease and row.lease.dirty then
  if not accept(self:Style(row)) then return end
 elseif row.geometryDirty or row.layoutDirty then
  if not accept(self:RefreshGeometry(row)) then return end
 end
 if row.fontDirty and not row.styleWork then if not accept(self:RefreshFont(row)) then return end end
 if row.headingDirty then
  local title=S:Public(GetChatWindowInfo,"string",row.id)
  if not current() then return end
  row.heading:SetText(title or (row.combatLog and "COMBAT LOG" or "CHAT"))
  row.surface.label=row.id==1 and "Chat" or row.combatLog and "Combat log" or title and ("Chat — "..title) or ("Chat window "..row.id)
  if not current() then return end
  row.headingDirty=nil
 end
 if not row.contentDirty and row.filterDirty and row.view and row.view~="GENERAL" then if not accept(self:SyncFilter(row)) then return end end
 if not accept(self:CommitCanvas(row)) then return end
 if not current() then return end
 row.surface.disabled=false
 if pending or self:RowNeedsWork(row,false) then
  row.surface.reworkReadiness="WAITING";R:RecordSurface(self,name,"WAITING","CHAT_WORK_QUEUED")
 else row.surface.reworkReadiness="READY";R:RecordSurface(self,name,"READY","NATIVE_ROUTES_RETAINED") end
 self:Visibility(row)
end
-- Native dock tabs are reparented into GeneralDockManager by FCFDock_UpdateTabs.
-- Reserve every discovered native window's controls before its Mirage row is
-- built; otherwise the shared pass can lease a later row's tab first. The same
-- table is refreshed between work slices so a new docked tab stays excluded.
local function sharedSkip(self,skip)
 skip=skip or {}
 local function window(native,name)
  if not S:Frame(native,false) then return end
  skip[native]=true
  local tab=_G[name.."Tab"];if tab then skip[tab]=true end
  for _,key in ipairs({"editBox","ScrollBar","ScrollToBottomButton","ResizeButton","buttonFrame"}) do
   local child=field(native,key);if child then skip[child]=true end
  end
 end
 for _,entry in ipairs(self.windowOrder or {}) do window(_G[entry.name],entry.name) end
 for _,row in pairs(self.rows) do window(row.native,row.name) end
 -- Header controls belong to row1. Chat settings is a native task window,
 -- including its dynamically allocated login-time checkbox families.
 for _,name in ipairs({"ChatFrameMenuButton","ChatFrameChannelButton","TextToSpeechButtonFrame","ChatConfigFrame"}) do
  if _G[name] then skip[_G[name]]=true end
 end
 return skip
end
function C:SharedResult(kind,why,root)
 self.sharedState=kind;self.sharedRoot=root or self.sharedRoot or "NONE"
 if kind=="PARTIAL" then self.sharedFailed=why else self.sharedFailed=nil end
 R:RecordSurface(self,"ChatSharedControls",kind,why)
 return kind=="READY",why
end
function C:StyleShared()
 if S:InCombat() then return false,"CHAT_STYLE_QUEUED" end
 local generation,profile=self.generation,M.profile
 local function ownerCurrent() return self.active and self.generation==generation and M.profile==profile end
 if not ownerCurrent() then return false,"CHAT_OWNER_RETIRED" end
 local K=R.WindowKit
 if not K then return self:SharedResult("PARTIAL","WINDOW_KIT_UNAVAILABLE","NONE") end
 local plan=self.sharedWork
 if not plan then
  local lease=self.sharedLease
  if lease and lease.parentGeneration~=generation then
   lease.active=false;local clean=L:Release(lease)
   if not ownerCurrent() then return false,"CHAT_OWNER_RETIRED" end
   if not clean then return self:SharedResult("PARTIAL","CHAT_SHARED_RESTORE_PENDING") end
   lease=nil;self.sharedLease=nil
  end
  if not lease then lease={id="chat",module="Chat",parentOwner=self};self.sharedLease=lease end
  if lease.parentGeneration~=generation then lease.active=true;lease.parentGeneration=generation;L:Begin(lease) end
  self.rootLeaseOwners=self.rootLeaseOwners or {};self.rootLeaseOwners.ChatSharedControls=lease
  plan={roots={},index=1,skip=sharedSkip(self),profile=profile,generation=generation,lease=lease}
  for _,name in ipairs({"GeneralDockManager","QuickJoinToastButton","CombatLogQuickButtonFrame_Custom"}) do
   if S:Frame(_G[name],false) then plan.roots[#plan.roots+1]={name=name,frame=_G[name]} end
  end
  lease.cooperativeStyle=true
  resetStyleTrees(lease,self.sharedFullStyle==true)
  lease.windowNodes=0
  self.sharedWork=plan;self.sharedDirty=nil;self.sharedFullStyle=nil;self.sharedFailed=nil
  self.sharedRoot="NONE";self:SharedResult("WAITING","CHAT_STYLE_QUEUED")
 end
 local function current() return ownerCurrent() and self.sharedWork==plan and self.sharedLease==plan.lease end
 if not current() or plan.profile~=profile or plan.generation~=generation then return false,"CHAT_OWNER_RETIRED" end
 local lease=plan.lease
 local root=plan.roots[plan.index]
 if root then
  if _G[root.name]~=root.frame then self.sharedWork=nil;self.sharedDirty=true;self.sharedFullStyle=true;return false,"CHAT_STYLE_QUEUED" end
  sharedSkip(self,plan.skip);self.sharedRoot=root.name
  self.painting=true;self.writing=true;lease.painting=true;lease.writing=true;lease.styleBudget=self.styleBudget
  local ok,done,why=pcall(K.StyleTree,K,lease,root.frame,{role="content",maxNodes=256,maxDepth=8,budgetNodes=24,skip=plan.skip,
   visit=function(node) lease.chatStyleRoots[node]=root.frame;return true end})
  lease.painting=nil;lease.writing=nil;lease.styleBudget=nil
  if not current() then return false,"CHAT_OWNER_RETIRED" end
  self.painting=nil;self.writing=nil
  if not ok or not done and not queued(why) then
   self.sharedWork=nil
   return self:SharedResult("PARTIAL",lease.windowScanLimited and "CHAT_SHARED_SCAN_LIMIT" or "CHAT_SHARED_PRESENTATION_PENDING",root.name)
  end
  if not done then return false,"CHAT_STYLE_QUEUED" end
  if (lease.gaps or 0)>0 or pendingReceipts(lease) or lease.windowScanLimited then
   self.sharedWork=nil
   return self:SharedResult("PARTIAL",lease.windowScanLimited and "CHAT_SHARED_SCAN_LIMIT"
    or pendingReceipts(lease) and "CHAT_SHARED_RESTORE_PENDING" or "CHAT_SHARED_PROPERTY_GAP",root.name)
  end
  plan.index=plan.index+1
 end
 if plan.index<=#plan.roots then return false,"CHAT_STYLE_QUEUED" end
 self.sharedWork=nil
 if pendingReceipts(lease) then return self:SharedResult("PARTIAL","CHAT_SHARED_RESTORE_PENDING") end
 return self:SharedResult("READY","NATIVE_ROUTES_RETAINED","NONE")
end
function C:Readiness()
 local partial=self.discoveryLimited or self.sharedFailed~=nil
 local waiting=self.discoveryDirty or self.sharedDirty or self.sharedWork~=nil or (self.windowCount or 0)==0
 for _,entry in ipairs(self.windowOrder or {}) do
  local row=self.rows[entry.name]
  if self.windowFailures and self.windowFailures[entry.name] or row and row.blocked then partial=true
   elseif entry.required~=false and (not row or self:RowNeedsWork(row,false,entry)) then waiting=true end
  if row and row.maskLost then partial=true end
 end
 self.status=partial and "CHAT_ROWS_PARTIAL" or waiting and "CHAT_WORK_QUEUED" or "CUSTOM_CHAT_NATIVE_ROUTES"
 if (self.windowCount or 0)==0 and not partial then self.status="WAITING_FOR_CHAT_WINDOWS" end
 return R:Result(partial and "PARTIAL" or waiting and "WAITING" or "READY",self.status)
end
function C:Initialize()
 if S:InCombat() then return false,"COMBAT_LOCKDOWN" end
 if not self.globalHooks then
  self.globalHooks={}
   local structural={FCF_OpenNewWindow=true,FCF_OpenTemporaryWindow=true,FCF_Close=true,FCF_DockFrame=true,FCF_UnDockFrame=true,FCF_SelectDockFrame=true,
   FCF_MaximizeFrame=true,FCF_MinimizeFrame=true}
  for _,name in ipairs({"FCF_OpenNewWindow","FCF_OpenTemporaryWindow","FCF_Close","FCF_DockFrame","FCF_UnDockFrame","FCF_SelectDockFrame",
   "FCF_SetWindowName","FCF_SetWindowColor","FCF_SetWindowAlpha","FCF_SetChatWindowFontSize","FCF_SetLocked","FCF_SetUninteractable","FCF_MaximizeFrame","FCF_MinimizeFrame","FCF_StopDragging","FCFDock_SetPrimary","FCFDock_UpdateTabs","FCF_UpdateButtonSide","FCF_UpdateScrollbarAnchors"}) do
   if type(_G[name])=="function" and type(hooksecurefunc)=="function" then
    if pcall(hooksecurefunc,name,function(frame)
     if not C.active or C.writing then return end
     if structural[name] then C.discoveryDirty=true;C.sharedDirty=true;C.sharedFullStyle=true end
     local nativeFrame=S:Number(frame) and frame>=1 and frame<=128 and frame%1==0 and _G["ChatFrame"..frame] or frame
     for _,row in pairs(C.rows) do
      row.visibilityDirty=true
      if name=="FCFDock_SetPrimary" or name=="FCFDock_UpdateTabs" or name=="FCF_UpdateButtonSide" or name=="FCF_UpdateScrollbarAnchors" then row.geometryDirty=true end
      if S:Readable(nativeFrame) and nativeFrame==row.native then
       if name=="FCF_SetWindowName" then row.headingDirty=true
       elseif name=="FCF_SetChatWindowFontSize" then row.fontDirty=true
       elseif name=="FCF_SetWindowColor" then row.dirty=true
       elseif name=="FCF_StopDragging" then row.geometryDirty=true end
      end
     end
     C.pendingWork=true;M.state.forceEvaluate=true
    end) then self.globalHooks[name]=true end
   end
  end
 end
 return true
end
function C:Configure()
 if self.suspending then return false,"CHAT_HANDOFF_IN_PROGRESS" end
 if not eligible() then return self:Suspend("NOT_SELECTED") end
 local editing=R:NativeEditState()
 if editing=="UNKNOWN" then return R:Result("DEFERRED_HANDOFF","NATIVE_EDIT_UNKNOWN") end
 if editing=="OPEN" then return self:Suspend("NATIVE_EDIT_HANDOFF") end
 if S:InCombat() then return false,"COMBAT_LOCKDOWN" end
 if not self.active and (self.cleanupPending or self.records and #self.records>0) then local ok,why=self:Suspend("HANDOFF");if not ok then return false,why end end
 local ready,why=self:Initialize();if not ready then return false,why end
 self.active=true;self.writing=nil;self.painting=nil;L:Begin(self);self.discoveryDirty=true;self.sharedDirty=true;self.sharedFullStyle=true;self.sharedWork=nil;self.sharedFailed=nil
 self.nextHistory=S:Now()+5;self.pendingWork=true;self.channelsDirty=true;self.serverNoticeDirty=true
 for _,row in pairs(self.rows) do
  row.dirty=true;row.layoutDirty=true;row.styleWork=nil;row.syncJob=nil;row.filterJob=nil;row.filterDirty=true;row.visibilityAlpha=nil;row.visibilityShown=nil;row.restoreAttempts=0
  if not row.committed then row.firstCommit=true end
  if row.recoverPending then self:BlockRow(row,row.blocked) end
  if not row.recoverPending then
   row.blocked=nil;row.fullSync=true;row.contentDirty=true;row.bodyReady=false;row.canvasDirty=true
  end
 end
 self:Discover()
 return self:Tick(S:Now())
end
function C:RuntimeDemand(now,combat)
 if not self.active then return nil end
 if not screen() then return nil end
 if self.channelsDirty then return "CHANNELS" end
 if combat==nil then combat=S:InCombat() end
 if not combat then
  if self.discoveryDirty then return "DISCOVERY" end
  if self.dirty or self.sharedDirty or self.sharedWork then return "SHARED_STYLE" end
  if self.serverNoticeDirty and self.rows.ChatFrame1 and self.rows.ChatFrame1.committed then return "SERVER_NOTICE" end
 end
 for _,entry in ipairs(self.windowOrder or {}) do
  local row=self.rows[entry.name]
   if row and row.committed and not row.combatLog and row.textMask and not self:MaskCurrent(row) then return "RENDERER_SAFETY" end
   if not (self.windowFailures and self.windowFailures[entry.name]) and self:RowNeedsWork(row,combat,entry) then return "ROW_CONTENT_OR_STYLE" end
  if row and not row.blocked then
   if (row.keybindVisibleState==true)~=((M.state.keybindWorkspace==true or M.state.trackerWorkspace==true)) or row.keybindCueUntil and now>=row.keybindCueUntil then return "VISIBILITY" end
   if row.visibilityDirty or M.Effects and M.Effects.transitions[row.frame] then return "VISIBILITY" end
   if row.historyDirty and now>=(self.nextHistory or 0) then return "HISTORY_SAVE" end
  end
 end
 return nil
end
function C:NeedsRuntimeTick(now,combat)
 return self:RuntimeDemand(now,combat)~=nil
end
function C:Tick(now)
 if not self.active then return end
 if not eligible() then return self:Suspend("NOT_SELECTED") end
 local editing=R:NativeEditState()
 if editing=="UNKNOWN" then return R:Result("DEFERRED_HANDOFF","NATIVE_EDIT_UNKNOWN") end
 if editing=="OPEN" then return self:Suspend("NATIVE_EDIT_HANDOFF") end
 if not screen() then self.status="VIEWPORT_PENDING";return R:Result("WAITING",self.status) end
 now=S:Number(now) and now or S:Now()
 local combat=S:InCombat()
 local generation,profile=self.generation,M.profile
 self.lastWorkReason=self:RuntimeDemand(now,combat) or "EXPLICIT_REFRESH"
 self.workReasons=self.workReasons or {};self.workReasons[self.lastWorkReason]=(self.workReasons[self.lastWorkReason] or 0)+1
 self.workSlices=(self.workSlices or 0)+1;self.lastMessageReads=0;self.messageBudget=128
 local budget={remaining=24,steps=0,started=styleClock()};self.styleBudget=budget;self.pendingWork=nil
 local function current() return self.active and self.generation==generation and M.profile==profile and self.styleBudget==budget end
 -- Safety is serviced before fair history/style work, even during combat.
 -- This pass never changes native geometry or protected visibility.
 for _,row in pairs(self.rows) do
  if row.committed and not row.combatLog and row.textMask and not self:MaskCurrent(row) then self:RetireCanvas(row,"CHAT_NATIVE_MASK_LOST") end
  if not current() then return R:Result("WAITING","CHAT_OWNER_RETIRED") end
 end
 if self.discoveryDirty and not combat then self:Discover() end
 if self.channelsDirty then
  self:RefreshChannels()
  for _,row in pairs(self.rows) do if row.tabs then row.visibilityDirty=true end end
 end
 if self.dirty then
  local localDirty=false
  for _,row in pairs(self.rows) do if row.lease and row.lease.dirty then localDirty=true;break end end
  if not localDirty then self.sharedDirty=true;self.sharedFullStyle=true end
  self.dirty=nil
 end
 local worked=false;local order=self.windowOrder or {};local size=#order
 -- The primary/selected window completes its handoff before unused native
 -- templates. Subsequent content work retains the fair round-robin order.
 local preferred
 for _,entry in ipairs(order) do
  local row=self.rows[entry.name]
  if not (self.windowFailures and self.windowFailures[entry.name]) and (not row or not row.committed)
    and self:RowNeedsWork(row,combat,entry) and (entry.id==1 or public(_G[entry.name],"IsShown","boolean")==true) then
   preferred=entry;break
  end
 end
 if preferred then self:ProcessRow(preferred);worked=true end
 for offset=1,worked and 0 or size do
  local index=((self.workCursor or 0)+offset-1)%size+1
  local entry=order[index];local row=self.rows[entry.name]
   if not (self.windowFailures and self.windowFailures[entry.name]) and self:RowNeedsWork(row,combat,entry) then
   self.workCursor=index;self:ProcessRow(entry);worked=true;break
  end
 end
 if not current() then return R:Result("WAITING","CHAT_OWNER_RETIRED") end
 if not combat and (self.sharedDirty or self.sharedWork) and self.styleBudget.remaining>0 then self:StyleShared();worked=true end
 if not current() then return R:Result("WAITING","CHAT_OWNER_RETIRED") end
 for _,row in pairs(self.rows) do
  if not row.blocked and (row.visibilityDirty or (row.keybindVisibleState==true)~=((M.state.keybindWorkspace==true or M.state.trackerWorkspace==true))
   or row.keybindCueUntil and now>=row.keybindCueUntil or M.Effects and M.Effects.transitions[row.frame]) then self:Visibility(row) end
  if not current() then return R:Result("WAITING","CHAT_OWNER_RETIRED") end
 end
 if not combat and self.serverNoticeDirty then self:PositionServerNotice() end
 -- At most one changed public history tail is persisted on a callback. Cold
 -- history/tree work does not also pay for every window's saved history tail.
 if not worked and now>=(self.nextHistory or 0) then
  local more=false
  for _,entry in ipairs(order) do
   local row=self.rows[entry.name]
   if row and row.historyDirty then
    if not more then self:SaveHistory(row);row.historyDirty=nil;more=true
    else more="MORE";break end
   end
  end
  if more~="MORE" then self.nextHistory=now+5 end
 end
 if not current() then return R:Result("WAITING","CHAT_OWNER_RETIRED") end
 self.maxMessageReads=math.max(self.maxMessageReads or 0,self.lastMessageReads)
 self.lastStyleNodes=self.styleBudget.steps;self.maxStyleNodes=math.max(self.maxStyleNodes or 0,self.lastStyleNodes)
 self.styleBudget=nil;self.messageBudget=nil
 self:ContinuePreparation(combat)
 return self:Readiness()
end
function C:ContinuePreparation(combat)
 if combat or not self.active or not M.RuntimeScheduler then return end
 local pending=self.sharedDirty or self.sharedWork
 for _,entry in ipairs(self.windowOrder or {}) do
  local row=self.rows[entry.name]
  if not (self.windowFailures and self.windowFailures[entry.name]) and (not row or not row.committed)
    and self:RowNeedsWork(row,false,entry) then pending=true;break end
 end
 if not pending then return end
 local provider=R.providers and R.providers.chat
 if provider and provider.tickCallback then
  -- Reuse the shared queue's frame fence and timing budget. No second timer
  -- or idle polling loop; the continuation disappears once preparation ends.
  M.RuntimeScheduler:Request("Rework.Tick.chat",provider.tickCallback,{combat="defer",priority=3,owner="Rework.chat",guard=provider.tickGuard})
 end
end
function C:OnEvent(event)
 if event=="SHARD_TRANSFER_IMMINENT" or event=="ADDON_LOADED" or event=="PLAYER_ENTERING_WORLD" then self.serverNoticeDirty=true end
 if event=="PLAYER_LOGOUT" then for _,row in pairs(self.rows) do self:SaveHistory(row) end;return end
 if event=="CHAT_MSG_CHANNEL_NOTICE" or event=="CHANNEL_UI_UPDATE" or event=="ZONE_CHANGED_NEW_AREA" or event=="PLAYER_ENTERING_WORLD" then
  self.channelsDirty=true;self.pendingWork=true
  if event~="PLAYER_ENTERING_WORLD" then return end
 end
 if event=="PLAYER_REGEN_ENABLED" then self.pendingWork=true;return end
 if event=="UPDATE_CHAT_WINDOWS" or event=="UPDATE_FLOATING_CHAT_WINDOWS" or event=="PLAYER_ENTERING_WORLD" or event=="ADDON_LOADED" then self.discoveryDirty=true end
 if event=="UPDATE_CHAT_COLOR" or event=="UI_SCALE_CHANGED" or event=="DISPLAY_SIZE_CHANGED" then
  for _,row in pairs(self.rows) do
   if event=="UPDATE_CHAT_COLOR" then row.dirty=true else row.geometryDirty=true;row.fontDirty=true end
  end
 end
 self.pendingWork=true
end
function C:Suspend(reason)
 if self.suspending then return false,"CHAT_HANDOFF_IN_PROGRESS" end
 self.suspending=true
 for _,row in pairs(self.rows) do if row.historyDirty then self:SaveHistory(row);row.historyDirty=nil end end
 self.active=false;self.writing=nil;self.painting=nil
 if S:InCombat() then
  self.cleanupPending=true;self.suspending=nil
  for _,row in pairs(self.rows) do if row.committed and row.bodyReady then self:RetainAccess(row) end end
  return false,"COMBAT_LOCKDOWN"
 end
 local clean,why,canvasPending=true,nil,false
 for _,row in pairs(self.rows) do
  clean=self:ChromeAlpha(row,1,true) and clean
  local canvasClean,detail=true,nil
  if row.canvasLease then row.canvasLease.active=false;canvasClean,detail=L:Release(row.canvasLease) end
  if canvasClean then
   if row.lease then row.lease.active=false;local done,restoreWhy=L:Release(row.lease);if not done then clean=false;why=restoreWhy end end
   if M.Effects then M.Effects:CancelTransition(row,row.frame,false) end
   row.frame:Hide();row.visibilityShown=nil;row.committed=false;row.accessFallback=nil;row.bodyReady=false;row.styled=nil
  else
   -- Keep the prepared text and native input routes usable until the exact
   -- alpha/mouse receipt has handed back. The structural lease still keeps
   -- the native edit box independent of its temporarily masked parent.
   clean=false;canvasPending=true;why=detail;row.recoverPending=true
   self:RetainAccess(row)
  end
  row.contentDirty=true;row.fullSync=true;row.pendingAdds=nil;row.syncJob=nil;row.filterJob=nil;row.styleWork=nil
 end
 if not canvasPending then
  if self.sharedLease then self.sharedLease.active=false;local done,detail=L:Release(self.sharedLease);if not done then clean=false;why=detail end end
  local done,detail=L:Release(self);if not done then clean=false;why=detail end
 end
 self.cleanupPending=not clean;self.suspending=nil
 self.sharedWork=nil;self.status=clean and (reason or "STOPPED") or why or "CHAT_PRESENTATION_RESTORE_PENDING"
 return clean,why
end
function C:Bounds() return self.surface and self:ResolveLayout(self.surface,M.profile),self.frame end
function C:Status()
 local messages,restored=0,0
 for _,row in pairs(self.rows) do messages=messages+(row.messageCount or 0);restored=restored+(row.restored or 0) end
 local pending={}
 for _,entry in ipairs(self.windowOrder or {}) do
  local row=self.rows[entry.name];local flags={}
   if not row and entry.required~=false then flags[1]="DISCOVERY"
   elseif not row then -- dormant prototype; no custom canvas or pending work
  elseif row.blocked then flags[1]="BLOCKED"
  else
   for _,item in ipairs({{"contentDirty","CONTENT"},{"canvasDirty","CANVAS"},{"dirty","STYLE"},
    {"styleWork","STYLE_SLICE"},{"geometryDirty","GEOMETRY"},{"layoutDirty","LAYOUT"},
    {"fontDirty","FONT"},{"headingDirty","HEADING"},{"visibilityDirty","VISIBILITY"}}) do
    if row[item[1]] then flags[#flags+1]=item[2] end
   end
   if row.lease and row.lease.dirty then flags[#flags+1]="CONTROL_STYLE" end
   if row.view and row.view~="GENERAL" and row.filterDirty then flags[#flags+1]="CHANNEL_VIEW" end
   if not row.committed then flags[#flags+1]="CANVAS_NOT_COMMITTED" end
  end
  if #flags>0 then pending[#pending+1]=entry.name..":"..table.concat(flags,"+") end
  if #pending>=8 then break end
 end
 local primary=self.rows.ChatFrame1
 local work={}
  for _,key in ipairs({"RENDERER_SAFETY","DISCOVERY","SHARED_STYLE","CHANNELS","ROW_CONTENT_OR_STYLE","VISIBILITY","HISTORY_SAVE","SERVER_NOTICE","EXPLICIT_REFRESH"}) do
  if self.workReasons and self.workReasons[key] then work[#work+1]=key..":"..self.workReasons[key] end
 end
  local renderers={};for _,entry in ipairs(self.windowOrder or {}) do local row=self.rows[entry.name]
   if row then renderers[#renderers+1]=entry.name..":"..(row.maskLost and "NATIVE_FALLBACK" or row.combatLog and "NATIVE_COMBAT_LOG" or row.committed and "MIRAGE_CANVAS" or "PREPARING")..":"..(row.maskKind or "UNADMITTED")..":"..(row.maskLost or "NONE") end
  end
  return self.status.."; windows="..tostring(self.windowCount or 0).."; candidates="..tostring(self.candidateCount or self.windowCount or 0).."; messages="..messages.."; restored_public="..restored.."; work_slices="..tostring(self.workSlices or 0).."; max_live_history_reads="..tostring(self.maxMessageReads or 0).."; max_style_nodes="..tostring(self.maxStyleNodes or 0)
  .."; channel_view="..(primary and primary.view or "GENERAL").."; trade_available="..tostring(self.channelAvailable and self.channelAvailable.TRADE or false).."; zone_available="..tostring(self.channelAvailable and self.channelAvailable.ZONE or false)
  .."; native_alpha_noops="..tostring(self.nativeAlphaNoops or 0).."; native_visibility_noops="..tostring(self.nativeVisibilityNoops or 0)
  .."; last_work="..(self.lastWorkReason or "NONE").."; work_reasons="..(#work>0 and table.concat(work,",") or "NONE")
  .."; style_invalidation=NATIVE_SUBTREE; contextual_fade=COMMON_DURATION"
  .."; mask_losses="..tostring(self.maskLosses or 0).."; renderers="..(#renderers>0 and table.concat(renderers,",") or "NONE").."; native_chat_raster=NOT_RUN"
  .."; pending_rows="..(#pending>0 and table.concat(pending,",") or "NONE")
  .."; shared_state="..(self.sharedState or "NOT_RUN").."; shared_root="..(self.sharedRoot or "NONE").."; shared_reason="..(self.sharedFailed or "NONE")
  .."; shared_nodes="..tostring(self.sharedLease and self.sharedLease.windowNodes or 0).."; shared_gaps="..tostring(self.sharedLease and self.sharedLease.gaps or 0)
  .."; server_notice="..(self.serverNoticeStatus or "WAITING").."; input=FOCUS_IMMEDIATE; startup=STAGED_PRIMARY_FIRST; arrows=SUPPRESSED; header=COMPACT_NATIVE_TOOLS; chat_settings=NATIVE_BY_DESIGN; native_routes=RETAINED; content_export=OMITTED"
end
