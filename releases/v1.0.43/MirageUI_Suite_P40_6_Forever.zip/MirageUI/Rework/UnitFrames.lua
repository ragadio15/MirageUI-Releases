local _, M = ...
-- Mirage unit artwork is attached to visible native unit controls. Native input,
-- secure attributes, aura children, ancestry and lifetime retain their authority.
M.Rework=M.Rework or {}
local R,S=M.Rework,M.Safety
local U={id="units",views={},status="NOT_INITIALIZED",events={
 ADDON_LOADED=true,PLAYER_ENTERING_WORLD=true,PLAYER_TARGET_CHANGED=true,PLAYER_FOCUS_CHANGED=true,PLAYER_REGEN_ENABLED=true,
 EDIT_MODE_LAYOUTS_UPDATED=true,UI_SCALE_CHANGED=true,DISPLAY_SIZE_CHANGED=true,
 UNIT_HEALTH=true,UNIT_MAXHEALTH=true,UNIT_POWER_UPDATE=true,UNIT_MAXPOWER=true,
 UNIT_NAME_UPDATE=true,UNIT_CONNECTION=true,UNIT_FLAGS=true,UNIT_DISPLAYPOWER=true,
 UNIT_LEVEL=true,UNIT_PET=true,UNIT_TARGET=true,CVAR_UPDATE=true,UNIT_ENTERED_VEHICLE=true,UNIT_EXITED_VEHICLE=true,
 UNIT_ENTERING_VEHICLE=true,UNIT_EXITING_VEHICLE=true,PLAYER_ROLES_ASSIGNED=true,
 READY_CHECK=true,READY_CHECK_CONFIRM=true,READY_CHECK_FINISHED=true,UNIT_AURA=true,
 GROUP_ROSTER_UPDATE=true,INSTANCE_ENCOUNTER_ENGAGE_UNIT=true,UNIT_TARGETABLE_CHANGED=true}}
R.UnitFrames=U
U.nativeRoots={PlayerFrame=true,TargetFrame=true,FocusFrame=true,PetFrame=true,BossTargetFrameContainer=true}
U.layoutIDs={}
for event in pairs(M.UnitExtras.events) do U.events[event]=true end
local rows={{"player","Player",-.19,-.22,"PlayerFrame"},{"target","Target",.19,-.22,"TargetFrame"},
 {"focus","Focus",.32,-.09,"FocusFrame"},{"pet","Pet",-.19,-.28,"PetFrame"},
 {"targettarget","Target's Target",.19,-.28,"TargetFrameToT"}}
for i=1,5 do rows[#rows+1]={"boss"..i,"Boss "..i,.37,.20-(i-1)*.065,"Boss"..i.."TargetFrame"} end
for _,row in ipairs(rows) do U.nativeRoots[row[5]]=true;U.layoutIDs["UnitFrames."..row[1]]=true end
local fontKeys={"name","level","separator","detail","healthPercent","powerPercent"}
local function selected()
 return not M.state.safe and R.Qualified and R:Qualified() and R.Selected and R:Selected("units",M.profile)
end
local function cfg(view) return M:ModuleConfig(view and view.owner or "UnitFrames") or {} end
local function knownUnit(value)
 if not S:Text(value) then return false end
 if value=="player" or value=="target" or value=="targettarget" or value=="focus" or value=="pet" or value=="vehicle" then return true end
 local n=value:match("^boss([1-5])$") or value:match("^party([1-4])$") or value:match("^partypet([1-4])$")
 if n then return true end
 n=value:match("^raid([1-9]%d?)$") or value:match("^raidpet([1-9]%d?)$")
 return n and tonumber(n)<=40 or false
end
local function activeUnit(view)
 -- A secure template resolves vehicle substitution; do not assign frame.unit.
 local actual=S:Public(SecureButton_GetUnit,"string",view.inputFrame or view.frame)
 if view.nativeBacked and not knownUnit(actual) then
  local native=S:Field(view.inputFrame,"unit");if knownUnit(native) then actual=native end
 end
 local modified=S:Public(SecureButton_GetModifiedUnit,"string",view.inputFrame or view.frame)
 if modified=="playerpet" then modified="pet" elseif modified=="playertarget" then modified="target" end
 if modified=="pet" and actual~="pet" then modified="vehicle" end
 local unit=knownUnit(modified) and modified or knownUnit(actual) and actual or not view.dynamicUnit and view.baseUnit or nil
 if unit~=view.baseUnit then
  local exists=S:Public(UnitExists,"boolean",unit)
  -- Do not display data from a unit whose secure substitution is still pending.
  if exists~=true and not view.dynamicUnit then return view.baseUnit end
 end
 return unit
end
local function extra(view,method,...)
 if view.nativeBacked and not view.plateRole then return true end
 local fn=M.UnitExtras[method]
 if type(fn)~="function" then return true end
 local ok=pcall(fn,M.UnitExtras,view,...)
 if not ok then view.extraStatus="DEGRADED_OPTIONAL_CONTENT" end
 return ok
end
function U:Extras(view,method,...) return extra(view,method,...) end
function U:EffectiveUnit(view) return activeUnit(view) end
local function singleLine(font)
 -- Bounded native text overflow, without inspecting content or shrinking fonts.
 if font.SetWordWrap then font:SetWordWrap(false) end
 if font.SetNonSpaceWrap then font:SetNonSpaceWrap(false) end
 if font.SetMaxLines then font:SetMaxLines(1) end
end
function U:Layout(view,layout)
 if S:InCombat() then view.surface.layoutPending=true;return false end
 return M.Display:WithUnitGeometry(view,function(write)
 local c=cfg(view);local w,h=layout.width,layout.height;local scale=M.profile.textScale or 1
 view.layoutWidth,view.layoutHeight=w,h;view.powerLayoutPending=nil
 if view.plateRole or view.headerRole then
  local inset,levelWidth,separatorWidth=7,25,8
  -- Pet/group cards share the target's level-first identity row. Compact
  -- native raid cells retain their native rectangle and input; fit the two
  -- tracks inside that rectangle instead of placing them below its bottom.
  local grouped=view.headerRole=="group"
  local percentages=c.showPercent==true and (not grouped or w>=110 and h>=44)
  local reserve=percentages and 43 or 7
  if grouped and w<180 then inset,levelWidth,separatorWidth=4,21,6 end
  local nameX=grouped and inset+levelWidth+separatorWidth+2 or 47
  local nameHeight=math.max(16,12*scale+4)
  write(view.level,"ClearAllPoints");write(view.level,"SetPoint","TOPLEFT",inset,-4);write(view.level,"SetSize",levelWidth,nameHeight);view.level:SetJustifyH("LEFT")
  write(view.separator,"ClearAllPoints");write(view.separator,"SetPoint","TOPLEFT",inset+levelWidth+2,-4);write(view.separator,"SetSize",separatorWidth,nameHeight)
  write(view.name,"ClearAllPoints");write(view.name,"SetPoint","TOPLEFT",nameX,-4);write(view.name,"SetSize",math.max(1,w-nameX-inset),nameHeight)
  write(view.detail,"ClearAllPoints");write(view.detail,"SetPoint","TOPRIGHT",-7,-5);write(view.detail,"SetSize",67,13);view.detail:SetJustifyH("RIGHT")
  local extraHeight=math.max(0,nameHeight-16)
  local healthY,powerY,barHeight=25+extraHeight,40+extraHeight,5
  if grouped then
   -- Native raid cells can be 32 units high. Keep the selected font size and
   -- compress only the two decorative tracks when the header needs more room.
   barHeight=math.max(1,math.min(5,math.floor((h-nameHeight-8)/2)))
   powerY=math.min(powerY,h-2-barHeight)
   healthY=math.min(healthY,powerY-2-barHeight)
  end
  write(view.health,"ClearAllPoints");write(view.health,"SetPoint","TOPLEFT",inset,-healthY);write(view.health,"SetSize",math.max(1,w-inset-reserve),barHeight)
  write(view.power,"ClearAllPoints");write(view.power,"SetPoint","TOPLEFT",inset,-powerY);write(view.power,"SetSize",math.max(1,w-inset-reserve),barHeight)
  write(view.healthPercent,"ClearAllPoints");write(view.healthPercent,"SetPoint","TOPRIGHT",-6,-healthY+2);write(view.healthPercent,"SetSize",36,15)
  write(view.powerPercent,"ClearAllPoints");write(view.powerPercent,"SetPoint","TOPRIGHT",-6,-powerY+2);write(view.powerPercent,"SetSize",36,15)
  local power=c.showPower~=false and view.powerPresence~="ABSENT"
  view.power:SetShown(power);view.powerPercent:SetShown(power and percentages);view.healthPercent:SetShown(percentages)
  for _,key in ipairs(fontKeys) do singleLine(view[key]);if key~="powerPercent" and key~="healthPercent" then view[key]:Show() end end
  -- Pet names receive the complete header width; native group status/role,
  -- ready checks and aura children retain their own native presentation.
  if view.headerRole then view.detail:Hide() end
  M.NameplateCard:Panel(view.frame,(c.panelOpacity or 12)/100)
  if view.grayscale then
   view.frame.miragePanel:SetColorTexture(.018,.018,.018,1)
   M.UI:BeamTrack(view.health,.30,.30,.30,.76);M.UI:BeamTrack(view.power,.30,.30,.30,.76)
  end
  M.Visual:NameBacking(view,false);M.NameplateCard:TextBackings(view,percentages);extra(view,"Layout",nil,w)
  view.overflowPolicy="NATIVE_SINGLE_LINE_CLIP";return true
 end
 local inset=math.min(8,math.max(0,(w-1)/4));local percentWidth=c.showPercent and math.ceil(33*scale)+5 or 0
 local levelWidth=math.ceil(22*scale)+5
 local nameHeight=math.ceil(12*scale)+2;local detailHeight=math.ceil(9*scale)+1
 local textHeight=math.ceil(11*scale)+2
 local compact=view.owner=="PartyRaid" and (h<nameHeight+detailHeight+14 or w<130)
 local percentFits=w>=130 and h>=textHeight*2+5
 if compact and not percentFits then percentWidth=0 end
 local power=c.showPower~=false and view.powerPresence~="ABSENT"
 local available=math.max(1,math.min(h-2,h-nameHeight-(compact and 0 or detailHeight)-4))
 local healthHeight=power and math.min(5,math.max(1,math.floor((available-1)/2))) or math.min(5,available)
 local powerHeight=math.min(5,math.max(1,available-healthHeight-1))
 if h<5 then healthHeight=math.max(.25,h/3);powerHeight=healthHeight end
 local bottomInset=h>=5 and 2 or 0
 local powerTop=math.max(0,h-bottomInset-powerHeight)
 local healthTop=math.max(0,power and powerTop-1-healthHeight or h-bottomInset-healthHeight)
 local trackWidth=math.max(1,w-inset*2-percentWidth)
 write(view.health,"ClearAllPoints");write(view.health,"SetPoint","TOPLEFT",inset,-healthTop);write(view.health,"SetSize",trackWidth,healthHeight)
 write(view.power,"ClearAllPoints");write(view.power,"SetPoint","TOPLEFT",inset,-powerTop);write(view.power,"SetSize",trackWidth,powerHeight)
 view.power:SetShown(power)
 write(view.name,"ClearAllPoints");write(view.name,"SetPoint","TOPLEFT",inset,-2)
 write(view.name,"SetSize",math.max(1,w-inset*2-percentWidth-levelWidth-7),math.min(nameHeight,h))
 write(view.level,"ClearAllPoints");write(view.level,"SetPoint","TOPRIGHT",-inset-percentWidth,-2);write(view.level,"SetSize",levelWidth,nameHeight)
 write(view.separator,"ClearAllPoints");write(view.separator,"SetPoint","TOPRIGHT",-inset-percentWidth-levelWidth,-2);write(view.separator,"SetSize",7,nameHeight)
 write(view.detail,"ClearAllPoints");write(view.detail,"SetPoint","TOPLEFT",inset,-2-nameHeight)
 write(view.detail,"SetSize",math.max(1,w-inset*2-percentWidth),detailHeight)
 -- Small authored boxes keep both selected percentages in a separate column.
 -- Only their positions change; font sizes and saved frame dimensions do not.
 local powerTextTop=math.min(h-2-textHeight,powerTop-(textHeight-powerHeight)/2)
 local healthTextTop=healthTop-(textHeight-healthHeight)/2
 if power and healthTextTop+textHeight>=powerTextTop then healthTextTop=powerTextTop-textHeight-1 end
 healthTextTop=math.max(2,healthTextTop)
 for _,entry in ipairs({{view.healthPercent,healthTextTop},{view.powerPercent,powerTextTop}}) do
  local font,y=entry[1],entry[2];write(font,"ClearAllPoints");write(font,"SetPoint","TOPRIGHT",-inset,-y)
  write(font,"SetSize",math.max(24,percentWidth-5),textHeight)
 end
 for _,key in ipairs(fontKeys) do singleLine(view[key]) end
 -- Small raid cells keep the compact name/bars inside their actual hit box.
 -- Optional detail remains available in the hover band, rather than overlapping
 -- the name or forcing a larger saved rectangle.
 view.compactStatusInTooltip=compact
 if view.compactStatusInTooltip then
  view.detail:Hide();view.level:Hide();view.separator:Hide()
  write(view.name,"SetWidth",math.max(1,w-inset*2-percentWidth))
 else view.detail:Show();view.level:Show();view.separator:Show() end
 view.name:SetShown(h>=nameHeight+8)
 view.healthPercent:SetShown(not compact or percentFits);view.powerPercent:SetShown(not compact or percentFits)
 M.Visual:Panel(view.frame,(c.panelOpacity or 12)/100)
 if view.grayscale then
  view.frame.miragePanel:SetColorTexture(.018,.018,.018,1)
  M.UI:BeamTrack(view.health,.30,.30,.30,.76);M.UI:BeamTrack(view.power,.30,.30,.30,.76)
 end
 M.Visual:NameBacking(view,c.nameBacking==true)
 extra(view,"Layout",nil,w)
 view.overflowPolicy="NATIVE_SINGLE_LINE_CLIP"
 return true
 end)
end
local function paintName(view)
 local c=cfg(view);if c.showNames==false or not knownUnit(view.unit) then view.name:SetText("");return end
 local color,source=M.Visual:ClassColor(view.unit)
 if view.grayscale then color,source={.88,.88,.88},"FIXED_UNIT_GRAYSCALE" end
 view.name:SetTextColor(color[1],color[2],color[3],1);view.nameColorSource=source
 -- The unreadable branch sends UnitName straight to a display sink. There is
 -- no equality, concatenation, measurement, serialization, or logging of it.
 local ok,value=pcall(UnitName,view.unit)
 if not ok then view.name:SetText("");view.nameStatus="PENDING";return end
 if S:Readable(value) then
  if type(value)~="string" then view.name:SetText("");view.nameStatus="PENDING";return end
  view.name:SetText(value:gsub("|","||"):gsub("[%z\1-\31]",""));view.nameStatus="PUBLIC"
 else
  local sent=pcall(view.name.SetText,view.name,value)
  if not sent then view.name:SetText("") end
  view.nameStatus=sent and "NATIVE_SINK" or "PENDING"
 end
end
local function safeName(view)
 if not pcall(paintName,view) then
  pcall(view.name.SetText,view.name,"");view.nameStatus="PENDING"
 end
end
function U:Paint(view,refresh)
 local resolved=activeUnit(view)
 local exists,existsState=S:Public(UnitExists,"boolean",resolved)
 view.contentPresence=existsState=="KNOWN" and (exists and "PRESENT" or "NOT_PRESENT") or "UNOBSERVED"
 if resolved~=view.unit then extra(view,"Clear");view.unit=resolved;refresh=true;view.unitChanged=true end
 local priorPower=view.powerPresence
 local ok=pcall(M.Display.UnitBars,M.Display,view,resolved,refresh==true)
 if not ok then
  view.healthOK=false;view.powerOK=false;view.providerStatus="DEGRADED_DATA"
 end
 -- Baseline opaque health/power sinks are reused, but its sizing and whole-name
 -- typography admission are not the authority for this provider.
 if not S:InCombat() and (priorPower~=view.powerPresence or view.powerLayoutPending) then
  self:Layout(view,{width=view.layoutWidth or 300,height=view.layoutHeight or 55})
 end
 safeName(view)
 if view.plateRole then
  local detail=S:Text(view.detailText) and view.detailText or ""
  if detail=="" then
   if S:Public(UnitIsPVP,"boolean",view.unit)==true then detail="PVP"
   elseif view.plateRole=="player" and S:Public(IsResting,"boolean")==true then detail="RESTING"
   elseif S:Public(UnitAffectingCombat,"boolean",view.unit)==true then detail="COMBAT"
   elseif S:Public(UnitIsGroupLeader,"boolean",view.unit)==true then detail="LEADER"
   else
    local classification=S:Public(UnitClassification,"string",view.unit)
    if classification=="worldboss" then detail="BOSS" elseif classification=="elite" or classification=="rareelite" then detail="ELITE" elseif classification=="rare" then detail="RARE" end
   end
  end
  view.detail:SetText(detail)
  -- Text contents are native display sinks, but their width is geometry on a
  -- child of a secure control. Retain its prepared width through lockdown.
  if not S:InCombat() then
   view.name:SetWidth(math.max(35,(view.layoutWidth or 240)-53-(detail~="" and 70 or 0)))
  end
 end
 -- Palette membership is independent of the plate-like layout. Pet geometry,
 -- ancestry and extras stay native-backed while its owned artwork is grayscale.
 if view.grayscale then
  M.UI:BeamColor(view.health,.84,.84,.84,view.healthOK and 1 or 0)
  M.UI:BeamColor(view.power,.64,.64,.64,view.powerPresence~="ABSENT" and view.powerOK and 1 or 0)
  for _,key in ipairs({"level","separator","detail","healthPercent","powerPercent"}) do view[key]:SetTextColor(.82,.82,.82,1) end
  if view.accentEdges then M.Visual:Accent(view,nil) end
 end
 view.providerStatus=(ok and view.healthOK and view.powerOK) and "CUSTOM_RUNTIME" or "DEGRADED_DATA"
 if view.unitChanged then extra(view,"RefreshCast");extra(view,"RefreshAuras");view.unitChanged=nil end
end
-- Native secure unit buttons retain input, unit membership and their own
-- lifetime. Mirage supplies passive artwork; an admitted secure parent can
-- conceal that complete native subtree without invisible input rectangles.
-- Player/target/focus consume their saved Mirage positions outside combat.
-- The original native control moves with its artwork. Pet geometry has a
-- separate opt-in envelope; untouched unit geometry retains its native layout.
-- Each authored control has its own reversible receipt.
local N={cards=setmetatable({},{__mode="k"}),regionMasks=setmetatable({},{__mode="k"}),barMasks=setmetatable({},{__mode="k"})}
R.NativeUnitPresentation=N
U.nativeBacked=true
U.geometryRoots={['UnitFrames.pet']='PetFrame',['UnitFrames.targettarget']='TargetFrameToT'}
-- Older pet layouts belonged to an inactive renderer. A new key records a
-- deliberate native-control edit; upgrading or opening Customize never moves it.
U.layoutIDs['UnitFrames.petControl']=true
U.layoutIDs['UnitFrames.targettargetControl']=true
function U:LayoutKey(id)
 return id=='UnitFrames.pet' and 'UnitFrames.petControl' or id=='UnitFrames.targettarget' and 'UnitFrames.targettargetControl' or id
end
function U:OwnsGeometry(id,profile) return self.geometryRoots[id]~=nil and (profile or M.profile).managed==true end
local primaryPositions={['UnitFrames.player']=true,['UnitFrames.target']=true,['UnitFrames.focus']=true}
local primaryControls={['UnitFrames.player']='PlayerFrame',['UnitFrames.target']='TargetFrame',['UnitFrames.focus']='FocusFrame'}
function U:OwnsPosition(id,profile)
 return primaryPositions[id]==true and (profile or M.profile).managed==true
end
function U:ResolveLayout(surface,profile)
 profile=profile or M.profile
 if self:OwnsGeometry(surface.id,profile) then return N:GeometryLayout(self,surface.id,profile) end
 local saved=profile.layouts and profile.layouts[surface.id]
 local fallback=surface.layout
 if not saved and self:OwnsPosition(surface.id,profile) and M.AdaptiveLayout then
  local w,h=M.AdaptiveLayout:Screen()
  if w then
   local modules=profile.modules
   local plan=M.AdaptiveLayout:Plan(w,h,modules.UnderCharacterHUD,modules.Cooldowns.centralGroup,modules.UnitFrames.referenceLayout)
   fallback=plan and plan.layouts[surface.id] or fallback
  end
 end
 local layout=M.Layout:Get({id=surface.id,layout=fallback},profile)
 local bounds=self:Bounds(surface.id)
 if bounds then
  -- Placement is authored; the original native control still determines its
  -- width and scale. The preview and edge clamp use that real input footprint.
  layout.width,layout.height,layout.scale=bounds.width,bounds.height,bounds.scale
  layout=M.Layout:Clamp(layout)
 end
 return layout
end
function U:PositionBounds(surface,profile,seen)
 profile=profile or M.profile;seen=seen or {}
 if seen[surface.id] then return nil end
 seen[surface.id]=true
 local layout=self:ResolveLayout(surface,profile)
 if layout.anchorTo then
  local target=M.surfaces[layout.anchorTo]
  local saved=profile.layouts and profile.layouts[layout.anchorTo]
  if self:OwnsPosition(layout.anchorTo,profile) and saved then
   local anchor=self:PositionBounds(target or {id=layout.anchorTo,layout=saved},profile,seen)
   if not anchor then return nil end
   layout.x,layout.y=layout.x+anchor.x,layout.y+anchor.y
  elseif target then
   local x,y=M.Layout:Position(layout.anchorTo,profile)
   layout.x,layout.y=layout.x+x,layout.y+y
  end
 end
 layout.anchorTo=nil
 return M.Layout:Clamp(layout)
end
function U:PositionCurrent(view)
 local points=view.positionPoints;local frame=view.inputFrame
 if not points then return true end
 local l=R.CombatLeases
 local count=l:Public(frame,'GetNumPoints','number')
 if count~=1 then return false end
 local ok,a,b,c,x,y=pcall(frame.GetPoint,frame,1)
 return ok and S:Readable(a) and S:Readable(b) and S:Readable(c) and a==points[1] and b==points[2] and c==points[3]
  and l:GeometryEqual(x,points[4]) and l:GeometryEqual(y,points[5]) or false
end
-- A point journal is not a root-scoped cosmetic provider. Bind its inverse to
-- the original input parent explicitly, and fence each native point setter:
-- a getter or post-hook can hand this control to a different profile/owner.
-- The restore route is allowed in safe/Edit HUD, but never after reparenting.
local function positionWrite(owner,frame,points)
 local l=R.CombatLeases
 local writeGeneration=owner.generation
 local function get(object)
  local n=object:GetNumPoints();if not S:Number(n) or n<0 or n>8 or n%1~=0 then return nil end
  local value={n=0}
  for i=1,n do
   local point=l.Pack(object:GetPoint(i));if point.n~=5 then return nil end
   for j=1,5 do value.n=value.n+1;value[value.n]=point[j] end
  end
  return value
 end
 local function set(object,value)
  local generation,request=owner.generation,owner.positionRequest
  local releasing=owner.releasing==true
  local receipt=owner.lookup and owner.lookup[object] and owner.lookup[object].points
  if receipt then receipt.parentTracked=true;receipt.nativeParent=owner.positionParent end
  local function current()
   local okay=releasing or request and request.current()
   local parent,state=l:Public(object,'GetParent')
   local combat=S:InCombat()
   local editing=releasing or R:NativeEditState()=='CLOSED'
   return not combat and okay and editing and (releasing or request.same())
    and owner.generation==generation and (owner.releasing==true)==releasing
    and owner.positionRequest==request and owner.positionFrame==object
    and owner.positionView.positionOwner==owner and state=='KNOWN' and parent==owner.positionParent
    and _G[owner.positionName]==object
  end
  assert(current(),'NATIVE_POSITION_CUSTODY_CHANGED')
  -- Clearing anchors is itself an observable partial write. Retain its exact
  -- attempt before calling native code so a safe/profile handoff in that
  -- post-hook can restore it instead of treating empty points as a new writer.
  if receipt then receipt.attempt={n=0} end
  assert(R.NativeClearPoints(object),'NATIVE_CLEAR_UNCONFIRMED')
  for i=1,value.n,5 do
   assert(current(),'NATIVE_POSITION_CUSTODY_CHANGED')
   if receipt then
    local attempt={n=i+4};for j=1,i+4 do attempt[j]=value[j] end
    receipt.attempt=attempt
   end
   assert(R.NativeSetPoint(object,unpack(value,i,i+4)),'NATIVE_POINT_UNCONFIRMED')
  end
  assert(current(),'NATIVE_POSITION_CUSTODY_CHANGED')
 end
 local okay=l:Write(owner,frame,'points',get,set,points)
 -- A refusal before the setter can still retain a pending journal entry.
 -- It must carry the same inverse custody as a successful/partial write.
 local receipt=owner.lookup and owner.lookup[frame] and owner.lookup[frame].points
 if receipt and owner.generation==writeGeneration then receipt.parentTracked=true;receipt.nativeParent=owner.positionParent end
 return okay
end
function U:Position(view)
 local profile,generation,cards=M.profile,self.generation,self.nativeCards
 local surface,frame=view.surface,view.inputFrame
 if not self:OwnsPosition(surface.id,profile) then return true end
 local inFlight=view.positionOwner
 if inFlight and (inFlight.releasing or (inFlight.leaseWriteDepth or 0)>0) then
  surface.layoutPending=true;return false,'POSITION_REENTRY_DEFERRED'
 end
 local key=surface.id:match('^UnitFrames%.(.+)$');local name=primaryControls[surface.id]
 view.positionSequence=(view.positionSequence or 0)+1;local sequence=view.positionSequence
 local function same()
  return M.profile==profile and self.active and self.generation==generation and self.nativeCards==cards
   and cards and cards[key]==view and view.surface==surface and view.inputFrame==frame
   and view.positionSequence==sequence and _G[name]==frame
 end
 local function current()
  local combat=S:InCombat();local editing=R:NativeEditState();local chosen=selected()
  return not combat and editing=='CLOSED' and chosen and same()
 end
 if S:InCombat() then view.surface.layoutPending=true;view.positionStatus='DEFERRED_COMBAT';return false end
 if R:NativeEditState()~='CLOSED' then view.positionStatus='NATIVE_EDIT_HOLD';return false end
 if not current() then return false,'POSITION_SUPERSEDED' end
 local l=R.CombatLeases
 local layout=self:PositionBounds(surface,profile)
 local w=l:Public(UIParent,'GetWidth','number');local h=l:Public(UIParent,'GetHeight','number')
 local fs=l:Public(frame,'GetEffectiveScale','number');local us=l:Public(UIParent,'GetEffectiveScale','number')
 local parent,parentState=l:Public(frame,'GetParent')
 if not current() then return false,'POSITION_SUPERSEDED' end
 if not layout or not w or not h or not fs or not us or w<=0 or h<=0 or fs<=0 or us<=0 then
  view.positionStatus='POSITION_GEOMETRY_UNAVAILABLE';return false
 end
 if parentState~='KNOWN' or not S:Frame(parent,false) then view.positionStatus='POSITION_CUSTODY_UNAVAILABLE';return false end
 if not current() then return false,'POSITION_SUPERSEDED' end
 local owner=view.positionOwner
 if owner and owner.positionParent~=parent then
  view.positionStatus='POSITION_CUSTODY_CHANGED';return false
 end
 local unchanged=self:PositionCurrent(view)
 if not current() or view.positionOwner~=owner then return false,'POSITION_SUPERSEDED' end
 if owner and not unchanged then
  -- A native relayout is a newer writer. Retire the old position receipt
  -- without restoring over it, then lease the new native baseline so a later
  -- safe-mode/Edit HUD handback returns the latest genuine native position.
  owner.active=false
  local released=l:Release(owner)
  if not current() or view.positionOwner~=owner then return false,'POSITION_SUPERSEDED' end
  if not released then view.positionStatus='POSITION_HANDOFF_PENDING';return false end
  view.positionPoints=nil
 end
 if not owner then
  owner={id='units',parentOwner=self,positionFrame=frame,positionName=name,positionParent=parent,positionView=view}
  view.positionOwner=owner
 end
 if not current() or view.positionOwner~=owner then return false,'POSITION_SUPERSEDED' end
 owner.active=true;owner.parentGeneration=generation;l:Begin(owner)
 local leaseGeneration=owner.generation
 local function receiptSame() return same() and not M.state.safe and view.positionOwner==owner and owner.generation==leaseGeneration end
 owner.positionRequest={same=receiptSame,current=function() return current() and receiptSame() end}
 local points=l.Pack('CENTER',UIParent,'CENTER',layout.x*w/(fs/us),layout.y*h/(fs/us))
 local okay=positionWrite(owner,frame,points)
 if not current() or view.positionOwner~=owner or owner.generation~=leaseGeneration then return false,'POSITION_SUPERSEDED' end
 view.positionStatus=okay and 'AUTHORED_POSITION_APPLIED' or 'POSITION_APPLY_PARTIAL'
 if okay then view.positionPoints=points;view.surface.layoutPending=nil end
 return okay
end
local nativeContainers={"PlayerFrameContainer","PlayerFrameContent","PlayerFrameContentMain","PlayerFrameContentContextual","PlayerRestLoop","TargetFrameContainer","TargetFrameContent","TargetFrameContentMain","TargetFrameContentContextual","HitIndicator",
 "PetFrameContainer","PetFrameContent","PetFrameContentMain","HealthBarContainer","HealthBarsContainer","ManaBarContainer","ManaBarArea","TempMaxHealthLossDivider"}
local nativeArt={"FrameTexture","VehicleFrameTexture","AlternatePowerFrameTexture","BossPortraitFrameTexture","PlayerPortrait","Portrait","portrait","Texture","VehicleTexture","texture","background","Background","LevelBackgroundCircle","FrameFlash","Flash","StatusTexture",
 "PlayerPortraitCornerIcon","PrestigePortrait","PrestigeBadge","PVPIcon","PvpIcon","PvpBackgroundIcon","AttackIcon","RestTexture","LeaderIcon","GuideIcon","RoleIcon","BossIcon","HighLevelTexture","threatIndicator","overAbsorbGlow","overHealAbsorbGlow",
 "ReputationColor","Spark","HealthBarTexture","ManaBarTexture","TempMaxHealthLossTexture","TempHPLossDivider","TempHPLossDividerShadow","OverAbsorbGlow","OverHealAbsorbGlow"}
local animatedArt={PlayerPortrait=true,Portrait=true,portrait=true,FrameFlash=true,Flash=true,StatusTexture=true,RestTexture=true,threatIndicator=true,overAbsorbGlow=true,overHealAbsorbGlow=true}
local unitContexts={player="PlayerFrame",target="TargetFrame",targettarget="TargetFrame",focus="FocusFrame",pet="PetFrame"}
local bossElements={"UnitFrames.boss1","UnitFrames.boss2","UnitFrames.boss3","UnitFrames.boss4","UnitFrames.boss5"}
local nativeText={"name","Name","NameText","nameText","levelText","LevelText","TextString","textString","HealthBarText","ManaBarText","CenterText","LeftText","RightText","HitText","DeadText","UnconsciousText"}
local nativeBars={"healthbar","healthBar","HealthBar","manabar","manaBar","ManaBar","powerBar","PowerBar","tempMaxHealthLossBar","TempMaxHealthLoss","PlayerFrameTempMaxHealthLoss","PlayerFrameHealthBarAnimatedLoss"}
local nativeSegments={"myHealPredictionBar","otherHealPredictionBar","totalAbsorbBar","healAbsorbBar","myManaCostPredictionBar","tempMaxHealthLossBar"}
local segmentArt={"Fill","TiledFillOverlay","LeftShadow","RightShadow"}
-- Camelot's pet XML exports these as named globals, not PetFrame parent keys.
local petGlobalArt={"PetFrameTexture","PetFrameFlash","PetAttackModeTexture","PetFrameOverAbsorbGlow","PetFrameOverHealAbsorbGlow"}
-- Exact pinned PetFrame/PartyAuraFrame/PetHappiness/CastingBarFrame paths.
-- This palette lease owns paint only: native aura identity, pooling, tooltip,
-- duration, shown state, input and pet-cast controller remain untouched.
local petCastTextures={"DropShadow","TextBorder","InterruptGlow","ChargeGlow","Background","EnergyGlow","BorderShield","Icon","Border",
 "Flakes01","Flakes02","Flakes03","BaseGlow","WispGlow","Sparkles01","Sparkles02","Flash","ChargeFlash","Spark","Shine","StandardGlow","CraftGlow","ChannelShadow"}
local unpackPalette=unpack or table.unpack
N.petPaletteHooks=setmetatable({},{__mode="k"})
local function petPaletteCurrent(view)
 local owner=view.chromeOwner;local provider=owner and owner.parentOwner
 return view.grayscale and view.baseUnit=="pet" and view.inputFrame==_G.PetFrame and owner and owner.active
  and provider and provider.active and owner.parentGeneration==provider.generation and view.petPaletteProfile==M.profile
  and not M.state.safe and R:NativeEditState()=="CLOSED"
end
local function paletteSnapshot(object,getter,boolean)
 local ok,a,b,c,d=pcall(getter,object)
 if not ok then return nil end
 if boolean then return S:Readable(a) and type(a)=="boolean" and {a} or nil end
 if not S:Number(a) or not S:Number(b) or not S:Number(c) or d~=nil and not S:Number(d) then return nil end
 return {a,b,c,d==nil and 1 or d}
end
local function paletteEqual(a,b)
 if not a or not b or #a~=#b then return false end
 for i=1,#a do
  if type(a[i])=="number" then if not R.CombatLeases:ColorEqual(a[i],b[i]) then return false end
  elseif a[i]~=b[i] then return false end
 end
 return true
end
local function paletteWritable(object)
 return S:Frame(object,false) and R.CombatLeases:Public(object,"IsProtected","boolean")==false
end
local function paletteDirty(view)
 if petPaletteCurrent(view) then view.petPaletteDirty=true;view.reworkProvider.pendingWork=true end
end
function N:PetPaletteProperty(view,object,key,getName,setName,boolean,gray)
 local l=R.CombatLeases
 local owner,profile,revision=view.chromeOwner,M.profile,view.petPaletteRevision
 local provider=owner and owner.parentOwner;local generation=provider and provider.generation
 local function current()
  return petPaletteCurrent(view) and view.chromeOwner==owner and M.profile==profile
   and owner.parentOwner==provider and provider.generation==generation and view.petPaletteRevision==revision
 end
 if not current() or not paletteWritable(object) then return false end
 local get,set=l:Field(object,getName),l:Field(object,setName)
 if type(get)~="function" or type(set)~="function" then return false end
 local now=paletteSnapshot(object,get,boolean);local parent,known=l:Public(object,"GetParent")
 if not now or known~="KNOWN" or not current() then return false end
 local hooks=self.petPaletteHooks[object]
 if not hooks then hooks={};self.petPaletteHooks[object]=hooks end
 local row=hooks[key]
 if row and (row.writing or row.view and row.view~=view) then return false end
 if not row then
  if type(hooksecurefunc)~="function" then return false end
  row={object=object,get=get,set=set,boolean=boolean};hooks[key]=row
  local okay=pcall(hooksecurefunc,object,setName,function()
   local current=row.view
   if row.writing or not current or not petPaletteCurrent(current) then return end
   -- Observe only this public paint property, never aura/cast payloads.
   row.native=paletteSnapshot(object,row.get,row.boolean);row.written=nil
   paletteDirty(current)
  end)
  if not okay then hooks[key]=nil;return false end
 end
 if not current() or row.view and row.parent~=parent then return false end
 view.petPaletteRecords=view.petPaletteRecords or {}
 if not row.view then
  if #view.petPaletteRecords>=256 then return false end
  row.view=view;row.parent=parent;row.native=now;view.petPaletteRecords[#view.petPaletteRecords+1]=row
 elseif not row.written or not paletteEqual(now,row.written) then row.native=now end
 row.seen=view.petPaletteRevision
 local want=boolean and {true} or {gray,gray,gray,now[4]}
 if not paletteEqual(now,want) then
  if not current() or l:Public(object,"GetParent")~=parent then return false end
  -- Hold the inverse receipt through the setter and its readback. A native
  -- post-hook may request safe/profile handback before the write returns.
  -- That handback must defer, rather than retire a not-yet-published write.
  row.writing=true;local okay,result=pcall(row.set,object,unpackPalette(want))
  local after=paletteSnapshot(object,row.get,boolean)
  row.writing=nil
  if after and not paletteEqual(after,now) then row.written=after end
  if not current() or row.view~=view or l:Public(object,"GetParent")~=parent then return false end
  if not okay or result==false or not paletteEqual(after,want) then return false end
 end
 if not current() then return false end
 row.written=want
 return true
end
function N:ReleasePetPalette(view,unseen)
 local complete=true;local records=view.petPaletteRecords or {}
 for i=#records,1,-1 do
  local row=records[i]
  if not unseen or row.seen~=view.petPaletteRevision then
   if row.writing then complete=false
   else
   local parent,state=R.CombatLeases:Public(row.object,"GetParent")
   local now=paletteSnapshot(row.object,row.get,row.boolean)
   local okay=state=="KNOWN" and now~=nil
   if okay and parent==row.parent and row.written and paletteEqual(now,row.written) then
    okay=row.native~=nil and paletteWritable(row.object)
    if okay and not paletteEqual(now,row.native) then
     row.writing=true;local success,result=pcall(row.set,row.object,unpackPalette(row.native));row.writing=nil
     okay=success and result~=false and paletteEqual(paletteSnapshot(row.object,row.get,row.boolean),row.native)
    end
   end
   -- A reparented/reused native object or newer writer wins; never restore
   -- presentation belonging to its former owner into the new native context.
   if okay then row.view=nil;row.written=nil;row.native=nil;table.remove(records,i) else complete=false end
   end
  end
 end
 return complete
end
function N:PetPaletteHook(view,object,method)
 local l=R.CombatLeases;local fn=l:Field(object,method)
 if type(fn)~="function" or type(hooksecurefunc)~="function" then return false end
 view.petUpdateHooks=view.petUpdateHooks or setmetatable({},{__mode="k"})
 local seen=view.petUpdateHooks[object] or {};view.petUpdateHooks[object]=seen
 if seen[method] then return true end
 local okay=pcall(hooksecurefunc,object,method,function() paletteDirty(view) end)
 if okay then seen[method]=true end
 return okay
end
function N:StylePetPalette(view)
 if not view.grayscale or view.baseUnit~="pet" then return true end
 view.petPaletteProfile=M.profile
 if not petPaletteCurrent(view) then return false end
 view.petPaletteRevision=(view.petPaletteRevision or 0)+1;view.petPaletteDirty=nil
 local l=R.CombatLeases;local okay=true;local completePool=true
 local function texture(object,gray,desaturationOnly)
  if not object then return end
  if l:Public(object,"GetObjectType","string")~="Texture" then okay=false;return end
  local desaturated=N:PetPaletteProperty(view,object,"desaturated","IsDesaturated","SetDesaturated",true)
  local neutral=desaturationOnly or N:PetPaletteProperty(view,object,"vertex","GetVertexColor","SetVertexColor",false,gray or 1)
  okay=desaturated and neutral and okay
 end
 local function font(object)
  if object then okay=N:PetPaletteProperty(view,object,"text","GetTextColor","SetTextColor",false,.86) and okay end
 end
 local frame=view.inputFrame;local container=l:Field(frame,"AuraFrameContainer");local pool=l:Field(frame,"AuraFramePool")
 if S:Frame(container,false) and type(l:Field(pool,"EnumerateActive"))=="function" then
  local success=pcall(function()
   local iterator,state,first=pool:EnumerateActive()
   if type(iterator)~="function" then error("PUBLIC_POOL_UNAVAILABLE") end
   local count=0
   for aura in iterator,state,first do
    count=count+1;if count>32 then error("ACTIVE_POOL_LIMIT") end
    if not S:Frame(aura,false) or l:Public(aura,"GetParent")~=container then error("AURA_PARENT_CHANGED") end
    local icon=l:Field(aura,"Icon");if not icon then error("AURA_ICON_UNAVAILABLE") end
    texture(icon);texture(l:Field(aura,"DebuffBorder"),.72);font(l:Field(aura,"Count"))
   end
  end)
  okay=success and okay;completePool=success
 else okay=false;completePool=false end
 okay=self:PetPaletteHook(view,frame,"UpdateAuras") and okay
 local happiness=_G.PetFrameHappiness
 if happiness then
  if S:Frame(happiness,false) and l:Public(happiness,"GetParent")==frame then
   local art=l:Field(happiness,"Texture");if art then texture(art) else okay=false end
   okay=self:PetPaletteHook(view,happiness,"UpdateHappiness") and okay
  else okay=false end
 end
 local cast=_G.PetCastingBarFrame
 if cast then
  if S:Frame(cast,false) and l:Public(cast,"GetObjectType","string")=="StatusBar" and l:Field(cast,"unit")=="pet" then
   -- StatusBarColor owns the native fill tint; do not lease the same fill
   -- texture's vertex color again and create competing repaint owners.
   local fill=l:Public(cast,"GetStatusBarTexture")
   if fill then texture(fill,nil,true) else okay=false end
   okay=self:PetPaletteProperty(view,cast,"barColor","GetStatusBarColor","SetStatusBarColor",false,.84) and okay
   for _,key in ipairs(petCastTextures) do texture(l:Field(cast,key)) end
   font(l:Field(cast,"Text"));font(l:Field(cast,"CastTimeText"));font(l:Field(cast,"CastTargetNameText"))
   for _,spec in ipairs({{"StagePips",{"BasePip","PipGlow","FlakesBottom","FlakesTop","FlakesTop02","FlakesBottom02"}},
    {"StageTiers",{"Normal","Disabled","Glow"}}}) do
    local list=l:Field(cast,spec[1])
    if list then
     for i=1,8 do local child=l:Field(list,i);if child then for _,key in ipairs(spec[2]) do texture(l:Field(child,key)) end end end
     if l:Field(list,9) then okay=false end
    end
   end
   for _,method in ipairs({"UpdateBarFillTexture","SetLook","OnEvent"}) do okay=self:PetPaletteHook(view,cast,method) and okay end
   if type(l:Field(cast,"AddStages"))=="function" then okay=self:PetPaletteHook(view,cast,"AddStages") and okay end
  else okay=false end
 end
 if completePool then okay=self:ReleasePetPalette(view,true) and okay end
 local status=okay and "PET_NATIVE_EXTRAS_GRAYSCALE" or "PET_PALETTE_UNAVAILABLE_KEEP_NATIVE"
 if view.petPaletteStatus~=status then
  view.petPaletteStatus=status
  local provider=view.reworkProvider;local id=view.surface and view.surface.id and view.surface.id..".palette"
  if provider then provider.nativePaletteChanged=true end
  if provider and id then
   if okay then if provider.surfaceStates then provider.surfaceStates[id]=nil end
   else R:RecordSurface(provider,id,"PARTIAL",status) end
  end
 end
 return okay
end
function N:Bounds(frame,id)
 local l=R.CombatLeases
 if not l or not S:Frame(frame,false) then return nil end
 local w=l:Public(frame,"GetWidth","number");local h=l:Public(frame,"GetHeight","number")
 local scale=l:Public(frame,"GetEffectiveScale","number");local ui=l:Public(UIParent,"GetEffectiveScale","number")
 local sw=l:Public(UIParent,"GetWidth","number");local sh=l:Public(UIParent,"GetHeight","number")
 local ok,x,y=pcall(function() return frame:GetCenter() end)
 if not ok or not S:Number(w) or not S:Number(h) or not S:Number(scale) or not S:Number(ui) or not S:Number(sw) or not S:Number(sh)
  or not S:Number(x) or not S:Number(y) or w<=0 or h<=0 or ui<=0 or sw<=0 or sh<=0 then return nil end
 scale=scale/ui
 return {frame=frame,id=id,width=w,height=h,scale=scale,x=x*scale/sw-.5,y=y*scale/sh-.5,source="NATIVE_BACKED_GEOMETRY",nativeObserved=true}
end
function U:TargetTargetPlan()
 local l=R.CombatLeases
 local player=N:Bounds(_G.PlayerFrame);local pet=N:Bounds(_G.PetFrame);local target=N:Bounds(_G.TargetFrame)
 local sw=l:Public(UIParent,"GetWidth","number");local sh=l:Public(UIParent,"GetHeight","number")
 if player and pet and target and sw and sh and pet.scale>0 and target.scale>0 then
  return {width=pet.width,height=pet.height,scale=pet.scale/target.scale,
   points=l.Pack("CENTER",_G.TargetFrame,"CENTER",(pet.x-player.x)*sw/pet.scale,(pet.y-player.y)*sh/pet.scale),
   reference=string.format("%.3f/%.3f/%.3f/%.3f/%.4f",pet.width,pet.height,(pet.x-player.x)*sw,(pet.y-player.y)*sh,pet.scale/target.scale),
   status="MIRRORED_PET_GEOMETRY"}
 end
 -- PetFrame is normally allocated even without a summoned pet. If a client
 -- has not allocated it yet, use the same readable card dimensions and a
 -- below-target anchor until public reference geometry becomes available.
 local height=55+math.max(0,12*(M.profile.textScale or 1)+4-16)
 return {width=232,height=height,scale=1,points=l.Pack("TOPLEFT",_G.TargetFrame,"BOTTOMLEFT",0,-8),
  reference="PET_REFERENCE_PENDING",status="PET_REFERENCE_PENDING"}
end
function U:PositionTargetTarget(view,plan)
 local profile,generation=M.profile,self.generation
 local frame=view.inputFrame;local l=R.CombatLeases
 if not S:Frame(_G.TargetFrame,false) or frame~=_G.TargetFrameToT then return false,"TARGET_CONTROL_UNAVAILABLE" end
 if S:InCombat() or R:NativeEditState()~="CLOSED" then return false,"DEFERRED_COMBAT" end
 local parent=l:Public(frame,"GetParent")
 if parent~=_G.TargetFrame then return false,"TARGET_PARENT_CHANGED" end
 local owner=view.positionOwner
 if owner and (owner.releasing or (owner.leaseWriteDepth or 0)>0) then return false,"POSITION_REENTRY_DEFERRED" end
 if owner and owner.positionParent~=parent then return false,"POSITION_HANDOFF_PENDING" end
 if not owner then
  owner={id=self.id,parentOwner=self,positionFrame=frame,positionName="TargetFrameToT",positionParent=parent,positionView=view}
  view.positionOwner=owner
 end
 owner.active=true;owner.parentGeneration=generation;l:Begin(owner)
 local leaseGeneration=owner.generation
 local function same()
  return self.active and self.generation==generation and M.profile==profile and self.nativeCards.targettarget==view
   and view.positionOwner==owner and owner.generation==leaseGeneration and _G.TargetFrameToT==frame
 end
 local function current()
  return same() and not M.state.safe and not S:InCombat() and R:NativeEditState()=="CLOSED"
   and l:Public(frame,"GetParent")==parent
 end
 owner.positionRequest={same=same,current=current}
 if not current() then return false,"POSITION_SUPERSEDED" end
 local okay=l:Scalar(owner,frame,"scale","GetScale","SetScale",plan.scale)
 local receipt=owner.lookup and owner.lookup[frame] and owner.lookup[frame].scale
 if receipt then receipt.parentTracked=true;receipt.nativeParent=parent end
 if not current() then return false,"POSITION_SUPERSEDED" end
 if okay then okay=positionWrite(owner,frame,plan.points) end
 if not current() then return false,"POSITION_SUPERSEDED" end
 if okay then
  view.positionPoints=plan.points;view.mirrorReference=plan.reference;view.positionStatus=plan.status
 end
 return okay,okay and plan.status or "POSITION_APPLY_PARTIAL"
end
function N:GeometryLayout(provider,id,profile)
 profile=profile or M.profile
 local key=provider.LayoutKey and provider:LayoutKey(id) or id
 local saved=profile.layouts and profile.layouts[key]
 if saved then return M.Layout:Get({id=key},profile) end
 local frame=_G[provider.geometryRoots[id]]
 local bounds=self:Bounds(frame,id)
 if bounds then
  local width,height=bounds.width*bounds.scale,bounds.height*bounds.scale
  local scale=math.max(.6,math.min(1.6,bounds.scale),width/1200,height/800)
  if scale<=1.6 then return {x=bounds.x,y=bounds.y,width=math.max(24,width/scale),height=math.max(16,height/scale),scale=scale} end
 end
 local definition=M.Elements and M.Elements.definitions[id]
 return M.Layout:Get({id=key,layout=definition and definition.layout},profile)
end
function N:GeometryPreview(provider,id,profile)
 local layout=self:GeometryLayout(provider,id,profile)
 local frame=_G[provider.geometryRoots[id]]
 local bounds=self:Bounds(frame,id)
 if not bounds then return nil,'NATIVE_CONTROL_UNAVAILABLE' end
 local referenceWidth,referenceHeight,scaleCeiling=bounds.width,bounds.height,nil
 if type(provider.GeometryReference)=='function' then
  referenceWidth,referenceHeight,scaleCeiling=provider:GeometryReference(id,frame,bounds,layout)
 end
 if not S:Number(referenceWidth) or not S:Number(referenceHeight) or referenceWidth<=0 or referenceHeight<=0 then return nil,'GEOMETRY_UNAVAILABLE' end
 local ratio=math.min(layout.width*layout.scale/referenceWidth,layout.height*layout.scale/referenceHeight)
 if S:Number(scaleCeiling) and scaleCeiling>0 then ratio=math.min(ratio,scaleCeiling) end
 bounds.referenceWidth,bounds.referenceHeight,bounds.scaleCeiling=referenceWidth,referenceHeight,scaleCeiling
 if not S:Number(ratio) or ratio<=0 then return nil,'GEOMETRY_UNAVAILABLE' end
 local x,y=layout.x,layout.y
 if layout.anchorTo then
  local ax,ay=M.Layout:Position(layout.anchorTo,profile)
  x,y=x+ax,y+ay
 end
 return M.Layout:Clamp({x=x,y=y,width=bounds.width,height=bounds.height,scale=ratio}),bounds
end
function N:GeometryCurrent(row)
 if not row or not row.positionPoints or row.geometryName and _G[row.geometryName]~=row.inputFrame then return false end
 local l=R.CombatLeases;local frame=row.inputFrame
 if not row.positionOwner or l:Public(frame,'GetParent')~=row.positionOwner.positionParent then return false end
 local fs=l:Public(frame,'GetEffectiveScale','number');local us=l:Public(UIParent,'GetEffectiveScale','number')
 return fs and us and us>0 and U:PositionCurrent(row)
  and l:GeometryEqual(l:Public(frame,'GetScale','number'),row.geometryScale)
  and l:GeometryEqual(fs/us,row.geometryEffectiveScale)
  and l:GeometryEqual(l:Public(frame,'GetWidth','number'),row.geometryWidth)
  and l:GeometryEqual(l:Public(frame,'GetHeight','number'),row.geometryHeight) or false
end
function N:GeometryHealth(provider,id,kind,reason)
 local key=id..'.geometry';local previous=provider.surfaceStates and provider.surfaceStates[key]
 if kind then R:RecordSurface(provider,key,kind,reason)
 elseif provider.surfaceStates then provider.surfaceStates[key]=nil end
 if previous~=(provider.surfaceStates and provider.surfaceStates[key]) then provider.nativeGeometryChanged=true end
end
function N:ReleaseGeometry(provider,id,retainAttempts)
 local row=provider.geometryRows and provider.geometryRows[id]
 if not row or not row.positionOwner then
  self:GeometryHealth(provider,id)
  return true,'NATIVE_GEOMETRY_RESTORED'
 end
 local owner=row.positionOwner
 if (owner.leaseWriteDepth or 0)>0 then return false,'GEOMETRY_REENTRY_DEFERRED' end
 owner.active=false
 local complete=R.CombatLeases:Release(owner)
 if complete then
  row.positionOwner=nil;row.positionPoints=nil;row.geometryScale=nil;row.geometryEffectiveScale=nil;row.geometryWidth=nil;row.geometryHeight=nil
  if not retainAttempts then row.attempts=0 end
  row.status='NATIVE_GEOMETRY_RESTORED'
  self:GeometryHealth(provider,id)
 else row.status='UNIT_GEOMETRY_HANDOFF_PENDING' end
 return complete,row.status
end
function N:ApplyGeometry(provider,id)
 local profile,generation=M.profile,provider.generation
 if not provider.geometryRoots or not provider.geometryRoots[id] then return false,'UNSUPPORTED_GEOMETRY' end
 local name=provider.geometryRoots[id];local frame=_G[name]
 local key=provider.LayoutKey and provider:LayoutKey(id) or id
 local layouts=profile.layouts;local authored=layouts and layouts[key]
 if not authored or not provider:OwnsGeometry(id,profile) then return self:ReleaseGeometry(provider,id) end
 local requested={x=authored.x,y=authored.y,width=authored.width,height=authored.height,scale=authored.scale,anchorTo=authored.anchorTo}
 if S:InCombat() then return false,'DEFERRED_COMBAT' end
 if R:NativeEditState()~='CLOSED' then return false,'NATIVE_EDIT_HOLD' end
 if not provider.active or M.state.safe or not R:Selected(provider.id,profile) then return false,'OWNER_UNAVAILABLE' end
 local l=R.CombatLeases
 provider.geometryRows=provider.geometryRows or {}
 local rows=provider.geometryRows;local row=rows[id]
 if row and row.positionOwner and (row.positionOwner.releasing or (row.positionOwner.leaseWriteDepth or 0)>0) then return false,'GEOMETRY_REENTRY_DEFERRED' end
 if row and row.inputFrame==frame and (row.attempts or 0)>=3 then return false,row.status or 'UNIT_GEOMETRY_RETRY_REQUIRED' end
 if row and row.positionOwner and (row.inputFrame~=frame or not self:GeometryCurrent(row)) then
  if not self:ReleaseGeometry(provider,id,true) then return false,'UNIT_GEOMETRY_HANDOFF_PENDING' end
 end
 if not S:Frame(frame,false) then return false,'NATIVE_CONTROL_UNAVAILABLE' end
 if not row or row.inputFrame~=frame then row={inputFrame=frame,geometryName=name,surface={id=id},attempts=0};rows[id]=row end
 if type(provider.GeometryContentReady)=='function' then
  local content,reason=provider:GeometryContentReady(id)
  if content~=true then
   row.deferred=true;row.status=reason or 'WAITING_FOR_GROUP_LAYOUT'
   row.measurements={requestedWidth=requested.width,requestedHeight=requested.height,requestedScale=requested.scale,content=row.status}
   self:GeometryHealth(provider,id,'WAITING',row.status)
   return false,row.status
  end
 end
 row.deferred=nil
 if (row.attempts or 0)>=3 then return false,row.status or 'UNIT_GEOMETRY_RETRY_REQUIRED' end
 local parent,parentState=l:Public(frame,'GetParent')
 local preview,bounds=self:GeometryPreview(provider,id,profile)
 local w=l:Public(UIParent,'GetWidth','number');local h=l:Public(UIParent,'GetHeight','number')
 local ps=l:Public(parent,'GetEffectiveScale','number');local us=l:Public(UIParent,'GetEffectiveScale','number')
 local function same()
  return provider.active and provider.generation==generation and M.profile==profile and not M.state.safe
   and provider:OwnsGeometry(id,profile)
   and provider.geometryRows==rows and rows[id]==row and row.inputFrame==frame and _G[name]==frame
   and profile.layouts==layouts and layouts[key]==authored and authored.x==requested.x and authored.y==requested.y
   and authored.width==requested.width and authored.height==requested.height and authored.scale==requested.scale and authored.anchorTo==requested.anchorTo
 end
 local function current()
  return same() and not S:InCombat() and R:NativeEditState()=='CLOSED' and R:Selected(provider.id,profile)
   and l:Public(frame,'GetParent')==parent and same()
 end
 if not current() then return false,'GEOMETRY_SUPERSEDED' end
 row.measurements={requestedWidth=requested.width,requestedHeight=requested.height,requestedScale=requested.scale,
  nativeWidth=type(bounds)=='table' and bounds.width or nil,nativeHeight=type(bounds)=='table' and bounds.height or nil,
  referenceWidth=type(bounds)=='table' and bounds.referenceWidth or nil,referenceHeight=type(bounds)=='table' and bounds.referenceHeight or nil,
  scaleCeiling=type(bounds)=='table' and bounds.scaleCeiling or nil,
  parentScale=ps,uiScale=us,viewportWidth=w,viewportHeight=h,previewScale=preview and preview.scale or nil,content='OBSERVED'}
 if parentState~='KNOWN' or not preview or not w or not h or not ps or not us or ps<=0 or us<=0 or w<=0 or h<=0 then
  row.deferred=true;row.status=provider.id=='groups' and 'WAITING_FOR_GROUP_LAYOUT' or 'GEOMETRY_UNAVAILABLE'
  return false,row.status
 end
 local scale=preview.scale*us/ps
 row.measurements.requestedNativeScale=scale
 if scale<.2 or scale>4 then row.deferred=true;row.status='UNIT_GEOMETRY_SCALE_LIMIT';return false,row.status end
 local owner=row.positionOwner
 if owner and owner.positionParent~=parent then return false,'UNIT_GEOMETRY_CUSTODY_CHANGED' end
 if not owner then
  owner={id=provider.id,parentOwner=provider,positionFrame=frame,positionName=name,positionParent=parent,positionView=row}
  row.positionOwner=owner
 end
 owner.active=true;owner.parentGeneration=generation;l:Begin(owner)
 local leaseGeneration=owner.generation
 local function receiptSame() return same() and row.positionOwner==owner and owner.generation==leaseGeneration end
 owner.positionRequest={same=receiptSame,current=function() return current() and receiptSame() end}
 local function scaleSet(object,value,allowed)
  local receipt=owner.lookup and owner.lookup[object] and owner.lookup[object].scale
  if receipt then receipt.parentTracked=true;receipt.nativeParent=parent end
  assert(owner.releasing or current() and receiptSame(),'UNIT_GEOMETRY_SUPERSEDED')
  if type(allowed)=='function' then assert(allowed(),'UNIT_GEOMETRY_SUPERSEDED') end
  assert(_G[name]==object and l:Public(object,'GetParent')==parent,'UNIT_GEOMETRY_CUSTODY_CHANGED')
  assert(R.NativeScale(object,value[1]),'UNIT_GEOMETRY_SCALE_FAILED')
  assert(owner.releasing or current() and receiptSame(),'UNIT_GEOMETRY_SUPERSEDED')
  if type(allowed)=='function' then assert(allowed(),'UNIT_GEOMETRY_SUPERSEDED') end
 end
 row.attempts=(row.attempts or 0)+1
 local okay=l:Write(owner,frame,'scale',function(object) return l.Pack(object:GetScale()) end,scaleSet,l.Pack(scale))
 local receipt=owner.lookup and owner.lookup[frame] and owner.lookup[frame].scale
 if receipt then receipt.parentTracked=true;receipt.nativeParent=parent end
 if not current() or not receiptSame() then return false,'GEOMETRY_SUPERSEDED' end
 if okay then
  local points=l.Pack('CENTER',UIParent,'CENTER',preview.x*w/preview.scale,preview.y*h/preview.scale)
  okay=positionWrite(owner,frame,points)
  if okay and current() and receiptSame() then
   row.positionPoints=points;row.geometryScale=scale;row.geometryEffectiveScale=preview.scale
   row.geometryWidth,row.geometryHeight=preview.width,preview.height;row.attempts=0
  end
 end
 if not current() or not receiptSame() then return false,'GEOMETRY_SUPERSEDED' end
 row.status=okay and 'MIRAGE_UNIT_GEOMETRY_APPLIED' or 'UNIT_GEOMETRY_APPLY_PARTIAL'
 self:GeometryHealth(provider,id,okay and 'READY' or 'PARTIAL',row.status)
 return okay,row.status
end
function N:GeometryTick(provider)
 if S:InCombat() or R:NativeEditState()~='CLOSED' then return end
 for id in pairs(provider.geometryRoots or {}) do
  local key=provider.LayoutKey and provider:LayoutKey(id) or id
  local authored=provider:OwnsGeometry(id,M.profile) and M.profile.layouts and M.profile.layouts[key]
  local row=provider.geometryRows and provider.geometryRows[id]
  if authored and (not row or provider.geometryDirty or not row.deferred and not self:GeometryCurrent(row))
   or not authored and (row and row.positionOwner or provider.surfaceStates and provider.surfaceStates[id..'.geometry']) then
   local okay,reason=self:ApplyGeometry(provider,id)
   if not okay then self:GeometryHealth(provider,id,(reason=='NATIVE_CONTROL_UNAVAILABLE' or type(reason)=='string' and reason:match('^WAITING_')) and 'WAITING' or 'PARTIAL',reason) end
  end
 end
 provider.geometryDirty=nil
end
function N:GeometryReport(provider,id)
 local row=provider.geometryRows and provider.geometryRows[id]
 local m=row and row.measurements
 if not m then return row and row.status or 'NATIVE_POSITION_UNEDITED' end
 local out={row.status or 'NOT_APPLIED'}
 for _,key in ipairs({'requestedWidth','requestedHeight','requestedScale','nativeWidth','nativeHeight','referenceWidth','referenceHeight','scaleCeiling','parentScale','uiScale','viewportWidth','viewportHeight','previewScale','requestedNativeScale'}) do
  out[#out+1]=key..'='..(S:Number(m[key]) and string.format('%.4f',m[key]) or 'UNAVAILABLE')
 end
 return table.concat(out,'/')
end
function U:GeometryPreview(id,profile) return N:GeometryPreview(self,id,profile) end
function N:MaskFailure(mask)
 if mask.failed then return end
 mask.failed=true
 local owner=mask.owner;local provider=owner and owner.parentOwner
 if provider then
  provider.nativeArtFailed=true;provider.pendingWork=true;provider.status="PARTIAL_NATIVE_BACKED"
  local view=owner.unitView
  if view and view.surface then
   view.nativeArtStatus="NATIVE_ART_MASK_UNAVAILABLE"
   R:RecordSurface(provider,view.surface.id,"PARTIAL","NATIVE_ART_MASK_UNAVAILABLE")
  end
 end
end
local function maskable(region)
 local l=R.CombatLeases
 -- Only currently public, nonforbidden, unprotected drawing regions qualify.
 -- A protected native ancestor is never the mutation target. If this exact
 -- region gains protection or secret security state, retain native artwork
 -- and expose partial readiness instead of attempting a protected Hide.
 local kind=l:Public(region,"GetObjectType","string")
 return S:Frame(region,false) and (kind=="Texture" or kind=="FontString")
  and l:Public(region,"IsProtected","boolean")==false
end
function N:MaskAnimatedRegion(owner,region)
 local l=R.CombatLeases
 if not maskable(region) then return false end
 local mask=self.regionMasks[region]
 if mask and mask.owner and mask.owner~=owner then return false end
 if not mask then
  if type(hooksecurefunc)~="function" then return false end
  mask={region=region};self.regionMasks[region]=mask
  local function observe(method,shown)
   local current=mask.owner;local provider=current and current.parentOwner
   if mask.writing or not current or not current.active or not provider or not provider.active
    or current.parentGeneration~=provider.generation or current.generation~=mask.generation
    or mask.profile~=M.profile or M.state.safe then return end
   local native=current.nativeName and _G[current.nativeName]
   if current.nativeName and (not S:Readable(native) or not S:Readable(current.nativeFrame) or native~=current.nativeFrame)
    or l:Public(region,"GetParent")~=mask.parent or not maskable(region) then
    N:MaskFailure(mask);return
   end
   -- Native unit updates reset bar alpha, portraits, names and classifications.
   -- Conceal the exact replaced drawing region, leaving all controller frames,
   -- input and native paint updates alone. There is no tree walk or provider wake.
   if method=="Show" then shown=true elseif method=="Hide" then shown=false end
   if not S:Readable(shown) or type(shown)~="boolean" then N:MaskFailure(mask);return end
   mask.nativeShown=shown
   if not shown then return end
   mask.writing=true
   local ok,result=pcall(l:Field(region,"Hide"),region)
   mask.writing=nil
   if not ok or result==false or l:Public(region,"IsShown","boolean")~=false then N:MaskFailure(mask) end
  end
  for _,method in ipairs({"Show","Hide","SetShown"}) do
   local methodName=method
   if type(l:Field(region,methodName))~="function" then return false end
   local ok=pcall(hooksecurefunc,region,methodName,function(_,shown) observe(methodName,shown) end)
   if not ok then return false end
  end
  mask.observe=observe
  mask.hooked=true
 end
 if not mask.hooked then return false end
 if not mask.owner then
  local shown,status=l:Public(region,"IsShown","boolean")
  local parent,parentStatus=l:Public(region,"GetParent")
  if status~="KNOWN" or parentStatus~="KNOWN" then return false end
  mask.nativeShown=shown;mask.parent=parent
 elseif l:Public(region,"GetParent")~=mask.parent then
  self:MaskFailure(mask);return false
 end
 owner.regionMasks=owner.regionMasks or {};owner.regionMasks[region]=mask
 mask.owner=owner;mask.profile=M.profile;mask.generation=owner.generation;mask.failed=nil
 if l:Public(region,"IsShown","boolean")~=false then
  mask.writing=true;local ok,result=pcall(l:Field(region,"Hide"),region);mask.writing=nil
  if not ok or result==false or l:Public(region,"IsShown","boolean")~=false then self:MaskFailure(mask);return false end
 end
 return true
end
function N:AuditRegionMasks(provider,now)
 -- This recovery addresses the source-pinned fixed player/target/pet art.
 -- Do not turn a raid roster into a new periodic native-region scan.
 if provider.id~="units" or not provider.active or M.state.safe or R:NativeEditState()~="CLOSED" then return end
 now=S:Number(now) and now or S:Now()
 if now<(provider.nextArtAudit or 0) then return end
 provider.nextArtAudit=now+.10
 local l=R.CombatLeases
 for _,view in pairs(provider.nativeCards or {}) do
  local owner=view.chromeOwner
  if view.controlReady and owner and owner.active and owner.parentGeneration==provider.generation
   and l:Public(view.frame,"IsVisible","boolean")==true then
   -- Native TextureMetatable writers (source-pinned UnitFrameUtil) and engine
   -- animations need not invoke per-object post-hooks. Reconcile only our
   -- already-admitted drawing regions, never scan a native frame/aura tree.
   for region,mask in pairs(owner.regionMasks or {}) do
    if mask.owner==owner and not mask.failed and mask.observe then
     local shown,state=l:Public(region,"IsShown","boolean")
     if state~="KNOWN" then self:MaskFailure(mask)
     elseif shown then
      mask.observe("Show",true)
      if not mask.failed then provider.artRepairs=(provider.artRepairs or 0)+1 end
     end
    end
   end
  end
 end
end
-- SetStatusBarTexture and native power-type updates can restore the engine's
-- fill directly, bypassing a Texture object's Show post-hook. Reconcile the
-- admitted drawing region before that native update returns, rather than
-- waiting for the ten-Hz fallback audit and exposing a one-frame stock fill.
-- This never hides or alters the protected StatusBar/input controller.
function N:RepairBarMask(bar)
 local binding=self.barMasks[bar];if not binding then return end
 local owner,region=binding.owner,binding.region
 local provider=owner and owner.parentOwner;local mask=region and self.regionMasks[region]
 if not provider or not provider.active or not owner.active or owner.parentGeneration~=provider.generation
  or M.state.safe or R:NativeEditState()~="CLOSED" or not mask or mask.owner~=owner
  or mask.profile~=M.profile or owner.generation~=mask.generation then return end
 local l=R.CombatLeases
 local fill,state=l:Public(bar,"GetStatusBarTexture")
 if state~="KNOWN" or fill~=region then
  -- A replacement texture needs fresh admission outside combat. Never reuse
  -- an old texture's custody receipt for a different drawing object.
  self:MaskFailure(mask);return
 end
 local shown,status=l:Public(region,"IsShown","boolean")
 if status~="KNOWN" then self:MaskFailure(mask)
 elseif shown and mask.observe then
  mask.observe("Show",true)
  if not mask.failed then provider.immediateArtRepairs=(provider.immediateArtRepairs or 0)+1 end
 end
end
function N:BindBarMask(owner,bar,region)
 if not region or not self.regionMasks[region] or self.regionMasks[region].owner~=owner then return false end
 local binding=self.barMasks[bar]
 if not binding or not binding.hooked then
  if type(hooksecurefunc)~="function" then return false end
  binding=binding or {};self.barMasks[bar]=binding
  if type(R.CombatLeases:Field(bar,"SetStatusBarTexture"))~="function" then return false end
  local ok=pcall(hooksecurefunc,bar,"SetStatusBarTexture",function() N:RepairBarMask(bar) end)
  if not ok then return false end
  binding.hooked=true
 end
 binding.owner,binding.region=owner,region
 self.nativeBarHooks=self.nativeBarHooks or {}
 local complete=true
 for _,name in ipairs({"UnitFrameManaBar_UpdateType","UnitFrameManaBar_Update","UnitFrameHealthBar_Update"}) do
  if type(_G[name])=="function" and not self.nativeBarHooks[name] then
   local ok=pcall(hooksecurefunc,name,function(nativeBar) N:RepairBarMask(nativeBar) end)
   if ok then self.nativeBarHooks[name]=true else complete=false end
  end
 end
 return binding.hooked==true and complete
end
function N:ReleaseRegionMasks(owner)
 local complete=true;local l=R.CombatLeases
 for region,mask in pairs(owner.regionMasks or {}) do if mask.owner==owner then
  local shown,status
  local restored=S:Frame(region,false)
  if restored then shown,status=l:Public(region,"IsShown","boolean");restored=status=="KNOWN" end
  local parent,parentState
  if restored then parent,parentState=l:Public(region,"GetParent");restored=parentState=="KNOWN" end
  -- Reused/reparented native regions belong to their new native container.
  -- Retire our hook without injecting the former owner's shown state there.
  if restored and parent~=mask.parent then
   mask.owner=nil;mask.failed=nil
  elseif restored and shown==false and mask.nativeShown==true then
   mask.writing=true;local ok,result=pcall(l:Field(region,"Show"),region);mask.writing=nil
   restored=ok and result~=false and l:Public(region,"IsShown","boolean")==true
  end
  -- Native Hide/SetShown(false) calls made during concealment were retained;
  -- restoration never invents a shown portrait or threat flash.
  if restored then mask.owner=nil;mask.failed=nil else complete=false end
 end end
 for bar,binding in pairs(self.barMasks) do if binding.owner==owner then binding.owner=nil;binding.region=nil end end
 return complete
end
local function ownsArtView(owner,view)
 return view and (view.chromeOwner==owner or view.decorationOwner==owner)
end
function N:HideNativeShownArt(owner,region,slotName)
 local l=R.CombatLeases
 -- Camelot's target/focus PvP delegate owns a possibly-secret Shown aspect.
 -- Its copied TextureMetatable writer cannot be observed by per-object Show
 -- hooks. It never changes alpha: lease that independent public paint channel
 -- and leave native visibility, texture selection and lifetime untouched.
 -- 71037 also reads HighLevelTexture:IsShown() in CheckBattlePet. Its native
 -- CheckLevel owns Show/Hide, so a shown-state mask would change that decision
 -- and restore overlapping level/skull art. Only these exact contextual slots
 -- may use the independent alpha channel; no new frame/input lease is granted.
 if slotName~=nil and slotName~="HighLevelTexture" then return false end
 local slot=slotName or "PvpBackgroundIcon"
 local failure=slotName and "NATIVE_LEVEL" or "NATIVE_PVP"
 local view,frame,name=owner.unitView,owner.nativeFrame,owner.nativeName
 local generation,profile,provider,parentGeneration=owner.generation,M.profile,owner.parentOwner,owner.parentGeneration
 local lookup,records=owner.lookup,owner.records
 local function retained()
  return owner.generation==generation and M.profile==profile and owner.parentOwner==provider and owner.parentGeneration==parentGeneration
   and provider and provider.active and provider.generation==parentGeneration and owner.active and not M.state.safe
   and owner.lookup==lookup and owner.records==records and owner.unitView==view and ownsArtView(owner,view)
   and view.inputFrame==frame and owner.nativeFrame==frame and owner.nativeName==name
 end
 local beforeMap=lookup and lookup[region];local beforeReceipt=beforeMap and beforeMap.alpha
 local function preflightCurrent()
  return retained() and lookup[region]==beforeMap and (not beforeMap or beforeMap.alpha==beforeReceipt)
 end
 if not preflightCurrent() then return false end
 local parent,parentState=l:Public(region,"GetParent")
 if not preflightCurrent() then return false end
 local alpha,alphaState=l:Public(region,"GetAlpha","number")
 if not preflightCurrent() then return false end
 if parentState~="KNOWN" or alphaState~="KNOWN" then return l:Gap(owner,"alpha",failure.."_ALPHA_UNAVAILABLE") end
 local function custody(allowed)
  local function current()
   local observedGeneration,observedProfile,observedLookup,observedRecords=owner.generation,M.profile,owner.lookup,owner.records
   local observedMap=observedLookup and observedLookup[region];local observedReceipt=observedMap and observedMap.alpha
   local observedProvider,observedParentGeneration,observedActive=owner.parentOwner,owner.parentGeneration,owner.active
   local observedProviderGeneration=observedProvider and observedProvider.generation
   if not ownsArtView(owner,view) or owner.unitView~=view or view.inputFrame~=frame or owner.nativeFrame~=frame
    or owner.nativeName~=name or not (allowed and allowed() or not allowed and retained()) then return false end
   local currentSlot=l:Path(frame,"TargetFrameContent","TargetFrameContentContextual",slot)
   local native=frame;if name then native=_G[name] end
   if not S:Readable(native) or not S:Readable(currentSlot) then return false end
   return native==frame and currentSlot==region and ownsArtView(owner,view) and owner.unitView==view and view.inputFrame==frame
    and owner.nativeFrame==frame and owner.nativeName==name
    and owner.generation==observedGeneration and M.profile==observedProfile and owner.lookup==observedLookup and owner.records==observedRecords
    and observedLookup[region]==observedMap and (not observedMap or observedMap.alpha==observedReceipt)
    and owner.parentOwner==observedProvider and owner.parentGeneration==observedParentGeneration and owner.active==observedActive
    and observedProvider and observedProvider.generation==observedProviderGeneration
    and (owner.releasing or retained())
  end
  if not current() then return false end
  local actual,state=l:Public(region,"GetParent")
  return state=="KNOWN" and actual==parent and current()
 end
 -- A newer native/addon alpha is not a request to reassert our old paint.
 -- The optional decoration owner retains that writer's value independently
 -- of the essential name, portrait, health and resource body.
 if beforeReceipt and beforeReceipt.written and not l:ColorEqual(alpha,beforeReceipt.written[1]) then
  return l:Gap(owner,"alpha",failure.."_ALPHA_DISPLACED")
 end
 if not custody() or alpha~=0 and not maskable(region) then
  if preflightCurrent() then return l:Gap(owner,"alpha",failure.."_ALPHA_CUSTODY_UNAVAILABLE") end
  return false
 end
 if not preflightCurrent() then return false end
 owner.nativeShownArt=owner.nativeShownArt or {};owner.nativeShownArt[region]={parent=parent,frame=frame,name=name,slot=slot}
 local applicationOpen,initialRead=true,true
 local okay=l:Write(owner,region,"alpha",function(object)
  local map=lookup[object];local receipt=map and map.alpha
  local value,state=l:Public(object,"GetAlpha","number")
  if state~="KNOWN" then return nil end
  if applicationOpen and not owner.releasing then
   if not retained() or lookup[object]~=map or map and map.alpha~=receipt then return nil end
   if initialRead then
    initialRead=false
    if map~=beforeMap or receipt~=beforeReceipt or receipt and receipt.written and not l:ColorEqual(value,receipt.written[1]) then return nil end
   end
  end
  return l.Pack(value)
 end,function(object,value,allowed)
  local row=owner.lookup and owner.lookup[object] and owner.lookup[object].alpha
  assert(custody(allowed) and maskable(object) and custody(allowed),failure.."_ALPHA_CUSTODY_CHANGED")
  if row then row.parentTracked=true;row.nativeParent=parent end
  object:SetAlpha(value[1])
 end,l.Pack(0))
 applicationOpen=false
 if not retained() then return false end
 local map=lookup[region];local receipt=map and map.alpha
 if not custody() or not retained() or lookup[region]~=map or map and map.alpha~=receipt then return false end
 if receipt then receipt.parentTracked=true;receipt.nativeParent=parent end
 if okay then
  owner.artMasked=(owner.artMasked or 0)+1
 end
 return okay
end
function N:ReleaseNativeShownArt(owner)
 -- An exact drawing region can be recycled or moved while the card remains.
 -- Retire only our obsolete alpha receipt; never restore its former paint
 -- into a different native owner. Other body-property inverses stay intact.
 local l=R.CombatLeases
 local generation,profile,provider,parentGeneration=owner.generation,M.profile,owner.parentOwner,owner.parentGeneration
 local entries,lookup,records=owner.nativeShownArt,owner.lookup,owner.records
 local active,providerActive=owner.active,provider and provider.active
 local view,frame=owner.unitView,owner.nativeFrame
 local function retained()
  return owner.generation==generation and M.profile==profile and owner.parentOwner==provider and owner.parentGeneration==parentGeneration
   and provider and provider.generation==parentGeneration and owner.active==active and provider.active==providerActive
   and owner.nativeShownArt==entries and owner.lookup==lookup and owner.records==records and owner.unitView==view
   and owner.nativeFrame==frame and ownsArtView(owner,view) and view.inputFrame==frame
 end
 for region,entry in pairs(entries or {}) do
  local map=lookup and lookup[region];local receipt=map and map.alpha
  local function current() return retained() and entries[region]==entry and lookup[region]==map and (not map or map.alpha==receipt) end
  if not current() then return false end
  local parent,state=l:Public(region,"GetParent")
  if not current() then return false end
  local displaced=state=="KNOWN" and parent~=entry.parent
  local slot=l:Path(entry.frame,"TargetFrameContent","TargetFrameContentContextual",entry.slot or "PvpBackgroundIcon")
  local native=entry.frame;if entry.name then native=_G[entry.name] end
  if S:Readable(native) and native~=entry.frame then displaced=true end
  if slot~=nil and S:Readable(slot) and S:Readable(region) and slot~=region then displaced=true end
  if not current() then return false end
  if displaced then
   if receipt then
    map.alpha=nil
    for i=#records,1,-1 do if records[i]==receipt then table.remove(records,i);break end end
   end
   entries[region]=nil
  end
 end
 return true
end
function N:ReleaseOptionalArt(view)
 local owner=view.decorationOwner
 if not owner then return true end
 owner.active=false
 if not self:ReleaseNativeShownArt(owner) then return false end
 local complete=R.CombatLeases:Release(owner)
 view.decorationReleasePending=not complete or nil
 return complete
end
function N:StyleOptionalPvP(view,region)
 if not view or (view.baseUnit~="target" and view.baseUnit~="focus") then return true end
 local provider,chrome=view.reworkProvider,view.chromeOwner
 local owner=view.decorationOwner
 local id=view.surface.id..".pvpDecoration"
 if owner and (owner.nativeFrame~=view.inputFrame or owner.region~=region) then
  if not self:ReleaseOptionalArt(view) then
   view.decorationStatus="OPTIONAL_PVP_HANDOFF_PENDING";R:RecordSurface(provider,id,"PARTIAL",view.decorationStatus);return false
  end
  view.decorationOwner=nil;owner=nil
 end
 if not region then
  view.decorationStatus="OPTIONAL_PVP_ABSENT"
  if provider.surfaceStates then provider.surfaceStates[id]=nil end
  return true
 end
 -- A displaced optional mask is a localized retained-native decoration.
 -- Retry only after its identity changes or the user's explicit recovery;
 -- repeated target refreshes must not fight the writer or exhaust body paint.
 if owner and owner.retainedNative then return false end
 if not owner then
  owner={id=provider.id,parentOwner=provider,unitView=view,nativeFrame=view.inputFrame,region=region}
  view.decorationOwner=owner
 end
 owner.active=true;owner.parentGeneration=provider.generation;owner.nativeName=chrome.nativeName
 R.CombatLeases:Begin(owner)
 local okay=self:HideNativeShownArt(owner,region)
 if okay then
  view.decorationStatus="OPTIONAL_PVP_MASKED"
  if provider.surfaceStates then provider.surfaceStates[id]=nil end
 else
  owner.retainedNative=true
  view.decorationStatus=self:ReleaseOptionalArt(view) and "OPTIONAL_PVP_NATIVE_RETAINED" or "OPTIONAL_PVP_HANDOFF_PENDING"
  R:RecordSurface(provider,id,"PARTIAL",view.decorationStatus)
 end
 return okay
end
function N:HideRegion(owner,region,animated,keepNativeShown)
 local l=R.CombatLeases
 if not region then return true end
 if not S:Readable(region) then return l:Gap(owner,"shown","NATIVE_ART_RESTRICTED") end
 if type(region)~="table" and type(region)~="userdata" then return true end
 local kind=l:Public(region,"GetObjectType","string")
 if not kind then return l:Gap(owner,"shown","NATIVE_ART_TYPE_UNAVAILABLE") end
 if kind~="Texture" and kind~="FontString" then return true end
 if keepNativeShown then return self:HideNativeShownArt(owner,region) end
 -- A one-time alpha write is insufficient: native mana-type changes explicitly
 -- reset fill alpha, and target changes refresh the original portrait chrome.
 -- Keep the legacy alpha lease for static art as well as the shown-state mask;
 -- native metatable paint updates cannot defeat one by changing the other.
 local masked=self:MaskAnimatedRegion(owner,region)
 if not masked then return l:Gap(owner,"shown","NATIVE_ART_MASK_UNAVAILABLE") end
 owner.artMasked=(owner.artMasked or 0)+1
 if animated then return true end
 -- Compact group paint may expose a restricted animation alpha even though
 -- its Texture/FontString shown state is public. The verified shown mask is
 -- already the native-art contract for animated regions. Keep that same
 -- contract for these group regions instead of making a second, redundant
 -- alpha snapshot withdraw the whole card. An existing alpha debt still has
 -- to finish through its original journal; a failed mask is never optional.
 local view=owner.unitView
 local alphaReceipt=owner.lookup and owner.lookup[region] and owner.lookup[region].alpha
 if view and view.owner=="PartyRaid" and not alphaReceipt then
  local _,alphaState=l:Public(region,"GetAlpha","number")
  local mask=self.regionMasks[region]
  if alphaState~="KNOWN" and mask and mask.owner==owner and not mask.failed
   and mask.generation==owner.generation and mask.profile==M.profile
   and l:Public(region,"GetParent")==mask.parent and l:Public(region,"IsShown","boolean")==false then
   owner.shownOnlyGroupArt=owner.shownOnlyGroupArt or {};owner.shownOnlyGroupArt[region]=true
   return true
  end
 end
 -- A region is not a native hit target. Alpha is never leased on a Frame,
 -- Button, StatusBar, container, ancestor or dynamically created aura button.
 local okay=l:Alpha(owner,region,0)
 -- The companion alpha receipt must have the same exact-parent custody as
 -- the shown-state mask. Never restore old paint into a recycled native region.
 local receipt=owner.lookup and owner.lookup[region] and owner.lookup[region].alpha
 if receipt then receipt.parentTracked=true;receipt.nativeParent=self.regionMasks[region].parent end
 return okay
end
function N:BodyContract(owner,frame)
 local l=R.CombatLeases;local view=owner.unitView
 local unit=view and view.baseUnit
 if not view or not (view.owner=="PartyRaid" or unit=="player" or unit=="pet" or unit=="target" or unit=="targettarget" or unit=="focus" or unit and unit:match("^boss[1-5]$")) then return true end
 local expected,observed,first=0,0,nil
 local function region(value,label)
  expected=expected+1
  local kind=l:Public(value,"GetObjectType","string")
  local belongs=false;local node=value
  for _=1,12 do
   if node==frame then belongs=true;break end
   local parent,state=l:Public(node,"GetParent")
   if state~="KNOWN" then break end
   node=parent
  end
  if belongs and (kind=="Texture" or kind=="FontString") and maskable(value) then observed=observed+1
  else first=first or label end
 end
 local function bar(value,label)
  if l:Public(value,"GetObjectType","string")~="StatusBar" then expected=expected+1;first=first or label;return end
  region(l:Public(value,"GetStatusBarTexture"),label.."Fill")
 end
 if view.owner=="PartyRaid" then
  -- PartyMemberFrameTemplate has capitalized Texture/VehicleTexture fields;
  -- compact raid cells use healthBar/powerBar. Require the real source body
  -- before reporting a ready replacement instead of accepting an empty scan.
  region(l:Field(frame,"name") or l:Field(frame,"Name"),"GroupName")
  bar(l:Field(frame,"healthbar") or l:Field(frame,"healthBar") or l:Path(frame,"HealthBarContainer","HealthBar"),"GroupHealth")
  bar(l:Field(frame,"manabar") or l:Field(frame,"powerBar") or l:Field(frame,"ManaBar"),"GroupPower")
  if l:Field(frame,"Texture") then
   region(l:Field(frame,"Texture"),"GroupChassis")
   region(l:Field(frame,"Portrait"),"GroupPortrait")
  else region(l:Field(frame,"background"),"GroupBackground") end
  owner.artRequired=expected;owner.artObserved=observed;owner.artFirstMissing=first
  owner.artStatus=first and "NATIVE_BODY_SOURCE_UNAVAILABLE" or "BODY_SOURCE_OBSERVED"
  return not first
 end
 -- These aliases are assigned by the pinned UnitFrame_Initialize before a
 -- native root is usable. An absent probe is not evidence of concealed art.
 region(l:Field(frame,"name"),"Name")
 bar(l:Field(frame,"healthbar"),"Health")
 bar(l:Field(frame,"manabar"),"Power")
 if unit=="player" then
  region(l:Path(frame,"PlayerFrameContainer","FrameTexture"),"PlayerChassis")
  region(l:Path(frame,"PlayerFrameContainer","PlayerPortrait"),"PlayerPortrait")
  region(l:Path(frame,"PlayerFrameContent","PlayerFrameContentMain","LevelBackgroundCircle"),"PlayerLevelCircle")
  region(_G.PlayerLevelText,"PlayerLevel")
 elseif unit=="pet" then
  region(_G.PetFrameTexture,"PetChassis")
  region(l:Field(frame,"portrait"),"PetPortrait")
 elseif unit=="targettarget" then
  region(l:Field(frame,"FrameTexture"),"TargetTargetChassis")
  region(l:Field(frame,"Portrait"),"TargetTargetPortrait")
 else
  region(l:Path(frame,"TargetFrameContainer","FrameTexture"),"TargetChassis")
  region(l:Path(frame,"TargetFrameContainer","Portrait"),"TargetPortrait")
  region(l:Path(frame,"TargetFrameContent","TargetFrameContentMain","LevelBackgroundCircle"),"TargetLevelCircle")
  region(l:Path(frame,"TargetFrameContent","TargetFrameContentMain","LevelText"),"TargetLevel")
  region(l:Path(frame,"TargetFrameContent","TargetFrameContentMain","ReputationColor"),"TargetReputation")
 end
 owner.artRequired=expected;owner.artObserved=observed;owner.artFirstMissing=first
 owner.artStatus=first and "NATIVE_BODY_SOURCE_UNAVAILABLE" or "BODY_SOURCE_OBSERVED"
 return not first
end
function N:StyleNativeBody(owner,frame)
 local l=R.CombatLeases;local queue={{frame,0}};local seen={}
 local generation,profile,provider,parentGeneration=owner.generation,M.profile,owner.parentOwner,owner.parentGeneration
 local function current()
  return owner.generation==generation and M.profile==profile and owner.parentOwner==provider and owner.parentGeneration==parentGeneration
   and provider and provider.active and provider.generation==parentGeneration and owner.active
 end
 owner.artMasked=0
 local unit=owner.unitView and owner.unitView.baseUnit
 local nativeShownPvP=(unit=="target" or unit=="focus") and l:Path(frame,"TargetFrameContent","TargetFrameContentContextual","PvpBackgroundIcon")
 local nativeShownLevel=(unit=="target" or unit=="focus") and l:Path(frame,"TargetFrameContent","TargetFrameContentContextual","HighLevelTexture")
 if unit=="target" or unit=="focus" then self:StyleOptionalPvP(owner.unitView,nativeShownPvP or nil) end
 -- Party decoration is explicitly omitted by the revised visual design.
 -- Mask only textures/fonts inside exact indicator containers: native unit
 -- buttons, tooltip routes, child aura widgets and their event lifetime stay.
 if owner.unitView and owner.unitView.owner=="PartyRaid" and not owner.unitView.isRaid then
  local function indicators(object)
   if not object then return end
   local kind=l:Public(object,"GetObjectType","string")
   if kind=="Texture" or kind=="FontString" then self:HideRegion(owner,object,true);return end
   if not S:Frame(object,false) then return end
   local getter=l:Field(object,"GetRegions")
   if type(getter)~="function" then return end
   local ok,regions=pcall(function() return {getter(object)} end)
   if not ok or #regions>32 then l:Gap(owner,"shown","NATIVE_GROUP_INDICATOR_UNAVAILABLE");return end
   for _,region in ipairs(regions) do self:HideRegion(owner,region,true) end
  end
  for _,key in ipairs({"PartyMemberOverlay","ReadyCheck","NotPresentIcon","ResurrectableIndicator",
   "roleIcon","readyCheckIcon","centerStatusIcon","selectionHighlight","aggroHighlight","statusText"}) do
   indicators(l:Field(frame,key))
  end
 end
 if frame==_G.PetFrame then
  for _,name in ipairs(petGlobalArt) do
   local art=_G[name]
   if art and not self:HideRegion(owner,art,true) then l:Gap(owner,"shown","NATIVE_PET_ART_UNAVAILABLE") end
  end
  self:HideRegion(owner,_G.PetHitIndicator)
 end
 while #queue>0 do
  local row=table.remove(queue);local body,depth=row[1],row[2]
  if not seen[body] and S:Frame(body,false) then
   seen[body]=true
   for _,key in ipairs(nativeArt) do
    local region=l:Field(body,key)
    if not current() then return false end
    local hidden
    if region~=nil and region==nativeShownPvP then hidden=true
    elseif region~=nil and region==nativeShownLevel then hidden=self:HideNativeShownArt(owner,region,"HighLevelTexture")
    else hidden=self:HideRegion(owner,region,animatedArt[key]) end
    if not current() then return false end
    if not hidden then l:Gap(owner,"shown","NATIVE_ART_UNAVAILABLE") end
   end
   for _,key in ipairs(nativeText) do self:HideRegion(owner,l:Field(body,key)) end
   for _,key in ipairs(nativeSegments) do
    local segment=l:Field(body,key)
    if segment then for _,art in ipairs(segmentArt) do
     if not self:HideRegion(owner,l:Field(segment,art),true) then l:Gap(owner,"shown","NATIVE_SEGMENT_ART_UNAVAILABLE") end
    end end
   end
   for _,key in ipairs(nativeBars) do
    local bar=l:Field(body,key)
    if S:Frame(bar,false) and l:Public(bar,"GetObjectType","string")=="StatusBar" then
     local fill,fillStatus=l:Public(bar,"GetStatusBarTexture")
     if fillStatus~="KNOWN" then l:Gap(owner,"shown","NATIVE_BAR_FILL_UNAVAILABLE")
     else
      local masked=self:HideRegion(owner,fill,true)
      if masked and not self:BindBarMask(owner,bar,fill) then l:Gap(owner,"shown","NATIVE_BAR_BOUNDARY_UNAVAILABLE") end
     end
     for _,textKey in ipairs(nativeText) do self:HideRegion(owner,l:Field(bar,textKey)) end
     for _,artKey in ipairs({"background","Background","HealthBarBackground","Spark","OverAbsorbGlow","OverHealAbsorbGlow"}) do self:HideRegion(owner,l:Field(bar,artKey),true) end
     -- The original mana bar's feedback and full-resource pulse are native
     -- visual children, not independent combat information or input controls.
     local feedback=l:Field(bar,"FeedbackFrame")
     for _,artKey in ipairs({"BarTexture","LossGlowTexture","GainGlowTexture"}) do self:HideRegion(owner,l:Field(feedback,artKey),true) end
     local pulse=l:Field(bar,"FullPowerFrame")
     for _,path in ipairs({{"SpikeFrame","BigSpikeGlow"},{"SpikeFrame","AlertSpikeStay"},{"PulseFrame","YellowGlow"},{"PulseFrame","SoftGlow"}}) do
      self:HideRegion(owner,l:Path(pulse,path[1],path[2]),true)
     end
    end
   end
   if depth<4 then for _,key in ipairs(nativeContainers) do local child=l:Field(body,key);if child then queue[#queue+1]={child,depth+1} end end end
  end
 end
 owner.artStatus=(owner.gaps or 0)==0 and "REPLACED_REGIONS_MASKED" or "NATIVE_ART_PARTIAL"
 return (owner.gaps or 0)==0
end
function N:RepairGroupBody(frame)
 local view=self.cards[frame];local provider=view and view.reworkProvider
 local owner=view and view.chromeOwner
 if not view or view.owner~="PartyRaid" or not view.controlReady or not provider or not provider.active
  or not owner or not owner.active or owner.parentGeneration~=provider.generation
  or M.state.safe or R:NativeEditState()~="CLOSED" then return end
 -- Native setup may paint through engine texture writers, bypassing a
 -- per-region Show hook. Reconcile only this card's admitted drawing regions
 -- at the end of that setup; never walk the roster from the idle heartbeat.
 local l=R.CombatLeases
 for region,mask in pairs(owner.regionMasks or {}) do
  if mask.owner==owner and not mask.failed and mask.observe then
   local shown,state=l:Public(region,"IsShown","boolean")
   if state~="KNOWN" then self:MaskFailure(mask)
   elseif shown then mask.observe("Show",true) end
  end
 end
end
function N:ObserveGroupBody(view)
 if view.owner~="PartyRaid" or type(hooksecurefunc)~="function" then return end
 self.groupBodyHooks=self.groupBodyHooks or setmetatable({},{__mode="k"})
 local frame=view.inputFrame;local l=R.CombatLeases
 if not self.groupBodyHooks[frame] and type(l:Field(frame,"UpdateArt"))=="function" then
  local ok=pcall(hooksecurefunc,frame,"UpdateArt",function() N:RepairGroupBody(frame) end)
  if ok then self.groupBodyHooks[frame]=true end
 end
 self.compactBodyHooks=self.compactBodyHooks or {}
 for _,name in ipairs({"DefaultCompactUnitFrameSetup","CompactUnitFrame_UpdateAll"}) do
  if not self.compactBodyHooks[name] and type(_G[name])=="function" then
   local ok=pcall(hooksecurefunc,name,function(nativeFrame) N:RepairGroupBody(nativeFrame) end)
   if ok then self.compactBodyHooks[name]=true end
  end
 end
end
function N:ReleaseCard(provider,view)
 if not view then return true end
 local l=R.CombatLeases
 local chrome,generation,profile,providerGeneration=view.chromeOwner,view.chromeOwner and view.chromeOwner.generation,M.profile,provider.generation
 local card,input=view.frame,view.inputFrame
 local function current()
  return view.chromeOwner==chrome and (not chrome or chrome.generation==generation) and M.profile==profile
   and provider.generation==providerGeneration and view.frame==card and view.inputFrame==input
 end
 local function pending(phase)
  if current() then view.handbackPhase=phase;view.releasePending=true end
  return false
 end
 local function withdraw()
  if not current() or S:InCombat() then return false end
  extra(view,"Clear")
  if not current() or S:InCombat() then return false end
  local ok,result=pcall(card.Hide,card)
  local shown,state=l:Public(card,"IsShown","boolean")
  local hidden=ok and result~=false and state=="KNOWN" and shown==false
  if not current() then return false end
  if hidden then
   view.controlReady=false;view.stockOwned=false
   if view.surface then view.surface.disabled=true end
  end
  return hidden
 end
 if S:InCombat() then return pending("COMBAT") end
 view.handbackAttempts=math.min(9999,(view.handbackAttempts or 0)+1)
 if view.positionOwner then
  local positionOwner=view.positionOwner
  if (positionOwner.leaseWriteDepth or 0)>0 then return pending("POSITION_WRITE_IN_PROGRESS") end
  local positionGeneration=positionOwner.generation
  positionOwner.active=false
  local restored=l:Release(positionOwner)
  if view.positionOwner~=positionOwner or positionOwner.generation~=positionGeneration then return false end
  if not restored then view.positionStatus='POSITION_HANDOFF_PENDING';return pending("POSITION") end
  view.positionOwner=nil
  view.positionPoints=nil;view.positionStatus='NATIVE_POSITION_RESTORED'
 end
 if not current() then return false end
 if chrome then chrome.active=false end
 local paletteRestored=self:ReleasePetPalette(view)
 if not current() then return false end
 local masksRestored=not chrome or self:ReleaseRegionMasks(chrome)
 if not current() then return false end
 local releaseOK,released=true,true
 if chrome then
  if not self:ReleaseNativeShownArt(chrome) or not current() then return false end
  releaseOK,released=pcall(l.Release,l,chrome)
 end
 if not current() then return false end
 released=releaseOK and released==true and masksRestored and paletteRestored
 local optionalRestored=self:ReleaseOptionalArt(view)
 if not current() then return false end
 -- Keep a visible, live Mirage card until the native region ledger is restored.
 -- Hiding our artwork first could expose a native input rectangle whose body
 -- regions are still transparent after a failed cosmetic handback.
 if not released then
  -- An unreadable cosmetic indicator alpha does not make the already-restored
  -- native name, portrait and bars unavailable. Retain that exact inverse
  -- as debt, but withdraw the duplicate passive card once every other native
  -- property and shown mask has returned. No secret alpha is guessed here.
  local onlyShownAlpha=releaseOK and masksRestored and paletteRestored and chrome and #(chrome.records or {})>0
  local levelAlpha=false
  if onlyShownAlpha then for _,receipt in ipairs(chrome.records) do
   local entry=chrome.nativeShownArt and chrome.nativeShownArt[receipt.object]
   if receipt.key~="alpha" or not entry then onlyShownAlpha=false;break end
   if entry.slot=="HighLevelTexture" then levelAlpha=true end
  end end
  if onlyShownAlpha and withdraw() then view.ownershipStatus=levelAlpha and "NATIVE_BODY_WITH_INDICATOR_ALPHA_DEBT" or "NATIVE_BODY_WITH_PVP_ALPHA_DEBT" end
  return pending(not paletteRestored and "PET_PALETTE" or not masksRestored and "NATIVE_REGIONS" or "BODY_PROPERTIES")
 end
 local hidden=withdraw()
 if not current() then return false end
 if hidden and chrome then chrome.nativeShownArt=nil end
 view.releasePending=not hidden or not optionalRestored or nil
 view.handbackPhase=not optionalRestored and "OPTIONAL_PVP_DECORATION" or hidden and "COMPLETE" or "PASSIVE_CARD"
 if hidden and optionalRestored then
  view.decorationOwner=nil
  if provider.surfaceStates and view.surface then provider.surfaceStates[view.surface.id..".pvpDecoration"]=nil end
 end
 return hidden and optionalRestored
end

function N:ExtraPolicy(view)
 if not view.plateRole or view.plateRole=="player" then return true end
 local frame,chrome=view.inputFrame,view.chromeOwner;local l=R.CombatLeases
 local ready,reason=M.UnitExtras:Ready(view)
 if not ready then view.extraStatus=reason;return false end
 M.UnitExtras:RefreshAuras(view);M.UnitExtras:RefreshCast(view)
 if view.extraAuraState~="NATIVE_CONTAINER_SUBMITTED" then view.extraStatus="AURA_CHANNEL_UNAVAILABLE_KEEP_NATIVE";return false end
 if view.extraCastState=="UNAVAILABLE" then view.extraStatus="CAST_CHANNEL_UNAVAILABLE_KEEP_NATIVE";return false end
 -- Target/Focus's native source treats zero as an explicit empty aura policy.
 -- Its own ConfigureAuraContainer/Hide remains the lifetime authority. Lease
 -- the documented limits, not a transparent parent or a guessed child tree.
 local configure=l:Field(frame,"ConfigureAuraContainer")
 local okay=type(configure)=="function"
 if okay then for _,key in ipairs({"maxBuffs","maxDebuffs"}) do
  local good=l:Write(chrome,frame,"mirage:"..key,function(x)
   local success,value=pcall(function() return x[key] end)
   if not success or not S:Readable(value) or value~=nil and not S:Number(value) then return nil end
   return l.Pack(value)
  end,function(x,value) x[key]=value[1];x:ConfigureAuraContainer() end,l.Pack(0))
  okay=good and okay
 end end
 local bar=l:Field(frame,"spellbar")
 if bar and type(l:Field(bar,"SetAndUpdateShowCastbar"))=="function" then
  local good=l:Write(chrome,bar,"castEnabled",function(x)
   local value=l:Field(x,"showCastbar");if type(value)~="boolean" then return nil end;return l.Pack(value)
  end,function(x,value) x:SetAndUpdateShowCastbar(value[1]) end,l.Pack(false))
  okay=good and okay
 else okay=false end
 view.extraStatus=okay and "BUFFS_BELOW_CAST" or "NATIVE_EXTRA_POLICY_PARTIAL"
 return okay
end
function N:Context(provider,name,module,element,elements)
 local contexts=M.ContextualNative
 if not contexts or not name then return false,"NATIVE_CONTEXT_UNAVAILABLE" end
 provider.nativeContexts=provider.nativeContexts or {};provider.nativeContexts[name]=module
 if name=="PlayerFrame" and type(contexts.SyncOwnedPlayerPresentation)=="function" then
  return contexts:SyncOwnedPlayerPresentation(provider,element)
 end
 local ready,status=contexts:OwnedReady(provider,name)
 if ready then return true,status end
 return contexts:AcquireOwned(provider,name,module,element,elements)
end
function N:ContextHealth(provider)
 local contexts=M.ContextualNative
 if not contexts or not provider.active then return true end
 local ready=true
 provider.contextHealth=provider.contextHealth or {}
 local playerReady,playerStatus,petReady,petStatus
 local paired=provider.nativeContexts and provider.nativeContexts.PlayerFrame and provider.nativeContexts.PetFrame
  and contexts.nativeChildren and contexts.nativeChildren.PetFrame and type(contexts.OwnedPlayerPetReady)=="function"
 if paired then playerReady,playerStatus,petReady,petStatus=contexts:OwnedPlayerPetReady(provider) end
 for name,module in pairs(provider.nativeContexts or {}) do
  local active,status
  if paired and name=="PlayerFrame" then active,status=playerReady,playerStatus
  elseif paired and name=="PetFrame" then active,status=petReady,petStatus
  else active,status=contexts:OwnedReady(provider,name) end
  local previous=provider.contextHealth[name];local token=active and "READY" or status
  local context=contexts.rows and contexts.rows[name]
  if not active and context and context.ownedOwner==provider and context.ownerHandback and not context.playerLease then
   -- Both pending and completed owner-held inverses share the public status.
   -- Their cached receipt is a distinct recovery edge, even if that label did
   -- not change after an explicit retry finished the native input return.
   token=tostring(status)..":INPUT_RETURNED"
  end
  if token~=previous then
   provider.contextHealth[name]=token
   if not active and context and context.ownedOwner==provider and provider.id=="groups" then
    -- Group contexts renew through discovery. The public pending label can
    -- remain unchanged when the final input inverse completes, so include
    -- that receipt edge and request one new census, not an idle retry loop.
    provider.nativeDiscoveryDirty=true
    provider.nativeDiscoveryRevision=(provider.nativeDiscoveryRevision or 0)+1
   end
   if name=="PetFrame" and provider.nativeCards and provider.nativeCards.pet then
    -- Parent context recovery changes readiness without changing the native
    -- pet identity. Re-evaluate that one card once; do not reparent its owner.
    provider.nativeDirty=provider.nativeDirty or {};provider.nativeDirty.pet=true
   end
   if name=="PlayerFrame" and not active and provider.nativeCards and provider.nativeCards.player then
    -- A completed contextual handback is not a permanent native fallback.
    -- Queue this owner once when its state changes; never retry a failed
    -- inverse every frame or reset the context's bounded cleanup attempts.
    provider.nativeDirty=provider.nativeDirty or {};provider.nativeDirty.player=true
   end
   local id=module..".context."..name
   if active then if provider.surfaceStates then provider.surfaceStates[id]=nil end
   else R:RecordSurface(provider,id,"PARTIAL",status) end
  end
  if not active then ready=false end
  for _,view in pairs(provider.nativeCards or {}) do if view.contextRoot==name then
   view.contextReady=active==true;view.contextStatus=status
   view.visibilityStatus=active and "SECURE_CONTEXT_NATIVE_LIFETIME" or "NATIVE_CONTEXT_UNAVAILABLE"
  end end
 end
 provider.contextReady=ready
 return ready
end
function N:RuntimeDemand(provider,now,combat)
 -- A dirty protected layout is debt, not work that can run during combat.
 -- Essential unit events already paint synchronously. Native unit/vehicle
 -- substitution still has its one-second liveness pass when no event arrives.
 -- Only owned flags are read here; readiness never borrows a cached census.
 if not provider.active then return false,"INACTIVE" end
 if not S:Number(now) then return nil,"CLOCK_UNKNOWN" end
 if provider.nativeHealthDirty then return true,"CONTEXT_CHANGE" end
 for _,view in pairs(provider.nativeCards or {}) do
  if view.controlReady and view.dataDirty then return true,"UNIT_DATA" end
  if view.controlReady and view.petPaletteDirty and petPaletteCurrent(view) then return true,"PET_PALETTE" end
 end
 if not combat then
  if provider.targetTargetRetryAt and now>=provider.targetTargetRetryAt then return true,"NATIVE_PREFERENCE" end
  if provider.nativeDiscoveryDirty then return true,"NATIVE_DISCOVERY" end
  if provider.geometryDirty then return true,"NATIVE_GEOMETRY" end
  for key in pairs(provider.nativeDirty or {}) do
   if not (provider.nativeFailed and provider.nativeFailed[key]) then return true,"NATIVE_CARD" end
  end
 end
 if now>=(provider.nextRuntimeReview or 0) then return true,"LIVENESS" end
 return false,combat and "COMBAT_DEBT_WAITING" or "SETTLED"
end
function N:BeginRuntimeTick(provider,now)
 now=S:Number(now) and now or S:Now()
 local _,reason=self:RuntimeDemand(provider,now,S:InCombat())
 provider.runtimeTickReasons=provider.runtimeTickReasons or {}
 provider.runtimeTickReasons[reason]=(provider.runtimeTickReasons[reason] or 0)+1
 provider.nextRuntimeReview=now+1
 provider.nativeHealthDirty=nil
end
function N:RuntimeDemandStatus(provider)
 local counts=provider.runtimeTickReasons or {};local parts={}
 for _,key in ipairs({"UNIT_DATA","PET_PALETTE","CONTEXT_CHANGE","NATIVE_CARD","NATIVE_GEOMETRY","NATIVE_DISCOVERY","NATIVE_PREFERENCE","LIVENESS"}) do
  parts[#parts+1]=key..":"..(counts[key] or 0)
 end
 return "runtime_demand=ACTIONABLE_WORK_WITH_1S_LIVENESS; native_root_recoveries="..(provider.nativeReplacementRecoveries or 0)
  .."; runtime_tick_reasons="..table.concat(parts,",")
end
function N:RearmReplacedRoot(provider,key,frame)
 -- A terminal paint belongs to one native object, not to its reusable roster
 -- key forever. A different observed root gets one ordinary admission path;
 -- Prepare still returns every old artwork receipt before accepting it.
 local failures=provider.nativeFailureFrames
 local previous=failures and failures[key]
 if not previous or previous==frame or not provider.nativeFailed[key] then return false end
 local generation,profile=provider.generation,M.profile
 if not S:Frame(frame,false) or provider.generation~=generation or M.profile~=profile
  or provider.nativeFailureFrames~=failures or failures[key]~=previous then return false end
 provider.nativeFailed[key]=nil;failures[key]=nil;provider.nativeDirty[key]=true
 provider.nativeReplacementRecoveries=math.min(999999,(provider.nativeReplacementRecoveries or 0)+1)
 return true
end
function N:Prepare(provider,key,unit,frame,label,ownerName,id)
 if S:InCombat() then return nil,"DEFERRED_COMBAT" end
 local l=R.CombatLeases
 if not l then return nil,"WAITING" end
 local view=provider.nativeCards[key]
 if view and view.inputFrame~=frame then
  if not self:ReleaseCard(provider,view) then return nil,"DEFERRED_HANDOFF" end
  provider.nativeCards[key]=nil;view=nil
 end
 if not S:Frame(frame,false) then return nil,"WAITING" end
 if view and view.releasePending then
  if (view.releaseAttempts or 0)>=3 then return nil,"DEFERRED_HANDOFF" end
  view.releaseAttempts=(view.releaseAttempts or 0)+1
  if not self:ReleaseCard(provider,view) then return nil,"DEFERRED_HANDOFF" end
 end
 local contextReady,contextStatus=true,"NATIVE_GROUP_CONTEXT"
 if ownerName=="UnitFrames" then
  local root=unitContexts[key] or "BossTargetFrameContainer"
  if root=="BossTargetFrameContainer" and not _G[root] then contextStatus="NATIVE_BOSS_LIFETIME"
  else contextReady,contextStatus=self:Context(provider,root,ownerName,key=="targettarget" and "UnitFrames.target" or id,root=="BossTargetFrameContainer" and bossElements or nil) end
 end
 if not view then
  view=self.cards[frame]
  if view and view.reworkProvider~=provider then return nil,"CONFLICT" end
  if not view then
   view=M.Display:CreateUnit(nil,unit,label,frame,ownerName,true)
   self.cards[frame]=view
   view.inputFrame=frame;view.baseUnit=unit;view.dynamicUnit=ownerName=="PartyRaid";view.nativeBacked=true;view.reworkProvider=provider
   view.grayscale=ownerName=="UnitFrames" and (unit=="player" or unit=="pet" or unit=="target" or unit=="targettarget" or unit=="focus") or false
   view.headerRole=ownerName=="PartyRaid" and "group" or (unit=="pet" or unit=="targettarget") and ownerName=="UnitFrames" and "pet" or nil
   if ownerName=="UnitFrames" and (unit=="player" or unit=="target" or unit=="focus") then
    view.plateRole=unit
    view.extraConfig={showCast=unit~="player",showAuras=false,showBuffs=unit~="player",nativeAuras=true,majorBuffs=false,auraSlots=8,auraSize=20}
   end
   view.controlKey=key;view.chromeOwner={id=provider.id or (ownerName=="PartyRaid" and "groups" or "units"),parentOwner=provider}
   view.surface={id=id,module=ownerName,frame=view.frame,editable=false,security="NATIVE_BACKED",nativeEdit=true,reworkProvider=provider,
    layout={x=0,y=0,width=300,height=55,scale=1}}
   -- Native dispatch only invalidates presentation. Child cards inherit native
   -- visibility immediately; no addon callback hides a native frame in combat.
   for _,event in ipairs({"OnShow","OnSizeChanged","OnAttributeChanged"}) do
    local geometry=event~="OnAttributeChanged"
    local hook=l:Field(frame,"HookScript")
    if type(hook)=="function" then pcall(hook,frame,event,function()
     if provider.active and provider.nativeCards and provider.nativeCards[view.controlKey]==view
      and view.inputFrame==frame and view.reworkProvider==provider then
      if geometry then provider.nativeDirty[view.controlKey]=true end
      provider.pendingWork=true;provider.nativeDataRevision=(provider.nativeDataRevision or 0)+1;view.dataDirty=true
     end
    end) end
   end
  end
  if view.controlKey and view.controlKey~=key and provider.nativeCards[view.controlKey]==view then provider.nativeCards[view.controlKey]=nil end
  view.controlKey=key;provider.nativeCards[key]=view
 end
 local bounds=self:Bounds(frame,id)
 if not bounds then return nil,"WAITING" end
 view.inputFrame=frame;view.baseUnit=unit;view.unit=unit;view.dynamicUnit=ownerName=="PartyRaid"
 view.contextRoot=ownerName=="PartyRaid" and (unit:match('^raid') and "CompactRaidFrameContainer" or "PartyFrame")
  or unitContexts[key] or (_G.BossTargetFrameContainer and "BossTargetFrameContainer" or nil)
 if ownerName=="PartyRaid" then contextReady=provider.contextReady~=false end
 local chrome=view.chromeOwner;chrome.active=true;chrome.parentGeneration=provider.generation
 chrome.unitView=view;chrome.nativeFrame=frame
 local nativeName=l:Public(frame,"GetName","string")
 chrome.nativeName=nativeName and _G[nativeName]==frame and nativeName or nil
 l:Begin(chrome)
 local paintGeneration,paintProfile=chrome.generation,M.profile
 local function stillPreparing()
  return provider.nativeCards[key]==view and view.chromeOwner==chrome and chrome.generation==paintGeneration and M.profile==paintProfile
   and chrome.parentOwner==provider and chrome.parentGeneration==provider.generation and chrome.active and provider.active
 end
 if not self:BodyContract(chrome,frame) then
  view.nativeArtStatus=chrome.artStatus
  if not self:ReleaseCard(provider,view) then return view,"DEFERRED_HANDOFF" end
  return nil,"PARTIAL"
 end
 if view.headerRole=="pet" then
  -- The old 120-unit native pet rectangle leaves only a few letters after
  -- the level. Use the target's normal 232-unit body width, without changing
  -- the pet's native unit, parent, click bindings or managed-layout custody.
  -- Both dimensions are reversible cosmetic leases acquired outside combat.
  local width=math.max(232,bounds.width)
  if not l:Scalar(chrome,frame,"width","GetWidth","SetWidth",width) then self:ReleaseCard(provider,view);return nil,"PARTIAL" end
 end
 if view.plateRole or view.headerRole=="pet" then
  local bodyHeight=55+math.max(0,12*(M.profile.textScale or 1)+4-16)
  if not l:Scalar(chrome,frame,"height","GetHeight","SetHeight",bodyHeight) then self:ReleaseCard(provider,view);return nil,"PARTIAL" end
  bounds=self:Bounds(frame,id);if not bounds then self:ReleaseCard(provider,view);return nil,"WAITING" end
  if view.plateRole then extra(view,"Configure") end
 end
 if provider==U and unit=="targettarget" then
  local plan=U:TargetTargetPlan()
  local authored=M.profile.layouts and M.profile.layouts[U:LayoutKey(id)]
  -- All typography and both tracks reuse the pet card. Dimensions follow the
  -- actual prepared pet control, including the user's Customize resize.
  if not l:Scalar(chrome,frame,"width","GetWidth","SetWidth",plan.width)
   or not l:Scalar(chrome,frame,"height","GetHeight","SetHeight",plan.height) then
   self:ReleaseCard(provider,view);return nil,"PARTIAL"
  end
  if not authored then
   local positioned,reason=U:PositionTargetTarget(view,plan)
   if not positioned then
    if reason=="POSITION_SUPERSEDED" or reason=="POSITION_REENTRY_DEFERRED" then return nil,"DEFERRED_HANDOFF" end
    self:ReleaseCard(provider,view);return nil,"PARTIAL"
   end
  elseif view.positionOwner then
   view.positionOwner.active=false
   if not l:Release(view.positionOwner) then return nil,"DEFERRED_HANDOFF" end
   view.positionOwner=nil;view.positionPoints=nil;view.mirrorReference=nil
  end
  bounds=self:Bounds(frame,id);if not bounds then self:ReleaseCard(provider,view);return nil,"WAITING" end
 end
 if provider==U and U:OwnsPosition(id) then
  view.surface.editable=true
  local positioned,reason=U:Position(view)
  if not positioned then
   -- A synchronous observer may already have prepared a successor using the
   -- same view. The superseded invocation cannot hand its newer receipt back.
   if reason=='POSITION_SUPERSEDED' or reason=='POSITION_REENTRY_DEFERRED' then return nil,'DEFERRED_HANDOFF' end
   self:ReleaseCard(provider,view);return nil,'PARTIAL'
  end
 end
 view.surface.disabled=nil
 local card=view.frame
 card:ClearAllPoints();card:SetAllPoints(frame);card:SetScale(1)
 -- The artwork never receives clicks. Native child aura/cast controls remain
 -- drawn by the native engine, including children created during combat.
 M.Safety:Passive(card)
 local level=l:Public(frame,"GetFrameLevel","number")
 if level and card.SetFrameLevel then card:SetFrameLevel(level+1) end
 U:Layout(view,{width=bounds.width,height=bounds.height})
 -- Prepare all passive data while the new card is hidden. Apply the existing
 -- ordinary context before first publication; native input stays authoritative.
 local paintDataRevision=provider.nativeDataRevision or 0
 U:Paint(view,true)
 if M.ContextualNative and type(M.ContextualNative.PrimeOwned)=="function" and view.contextRoot then
  if ownerName=="UnitFrames" and (key=="player" or key=="pet") then
   local ready,status=M.ContextualNative:SyncOwnedPlayerPresentation(provider,"UnitFrames.player")
   if key=="player" then contextReady,contextStatus=ready,status
   else contextReady,contextStatus=M.ContextualNative:OwnedReady(provider,"PetFrame") end
  elseif ownerName=="PartyRaid" then
   local row=M.ContextualNative.rows[view.contextRoot]
   if row and row.groupPresentation then contextReady=M.ContextualNative:RefreshGroupPresentation(row) end
  end
  if contextReady then M.ContextualNative:PrimeOwned(provider,view.contextRoot) end
 end
 card:Show();view.controlReady=true;view.stockOwned=true
 view.ownershipStatus="PREPARED_NATIVE_BACKED_CARD"
 card:SetAlpha(1)
 if frame==_G.PlayerFrame then self:HideRegion(chrome,_G.PlayerLevelText) end
 if not stillPreparing() then return nil,"DEFERRED_HANDOFF" end
 local okay=self:StyleNativeBody(chrome,frame)
 if not stillPreparing() then return nil,"DEFERRED_HANDOFF" end
 self:ObserveGroupBody(view)
 view.nativeArtStatus=chrome.artStatus
 self:StylePetPalette(view)
 local extrasReady=self:ExtraPolicy(view)
 if not stillPreparing() then return nil,"DEFERRED_HANDOFF" end
 if not okay or not extrasReady then
  view.paintAttempts=(view.paintAttempts or 0)+1
  if view.paintAttempts>=3 then provider.nativeFailed[key]=true;provider.nativeFailureFrames[key]=frame end
  if not self:ReleaseCard(provider,view) then
   -- The passive artwork is already prepared within the real hit rectangle.
   -- Keep it visible if native body restoration is pending, never invisible.
   if view.ownershipStatus~="NATIVE_BODY_WITH_PVP_ALPHA_DEBT" then
    view.controlReady=true;view.stockOwned=true;view.ownershipStatus="VISIBLE_HANDOFF_PENDING"
   end
   return view,"DEFERRED_HANDOFF"
  end
  return nil,"PARTIAL"
 end
 view.controlReady=true;view.stockOwned=true;view.releaseAttempts=0;view.paintAttempts=0;view.ownershipStatus="VISIBLE_NATIVE_BACKED_CARD"
 view.handbackPhase=nil
 view.extraFallbackRequested=nil
 if ownerName=="UnitFrames" and (key=="player" or key=="pet") and M.ContextualNative
  and type(M.ContextualNative.SyncOwnedPlayerPresentation)=="function" then
  local ready,status=M.ContextualNative:SyncOwnedPlayerPresentation(provider,"UnitFrames.player")
  if key=="player" then contextReady,contextStatus=ready,status
  else contextReady,contextStatus=M.ContextualNative:OwnedReady(provider,"PetFrame") end
 end
 if not stillPreparing() then return nil,"DEFERRED_HANDOFF" end
 view.visibilityStatus=contextReady and "SECURE_CONTEXT_NATIVE_LIFETIME" or "NATIVE_CONTEXT_UNAVAILABLE"
 view.contextReady=contextReady==true;view.contextStatus=contextStatus;view.leaseStatus="NATIVE_INPUT_RETAINED"
 -- Native unit/vehicle callbacks can run synchronously inside display sinks
 -- or style methods. This paint selected its unit before those callbacks;
 -- preserve their newer wake until another passive paint consumes it.
 view.dataDirty=(provider.nativeDataRevision or 0)~=paintDataRevision or nil
 return view,contextReady and extrasReady and "READY" or "PARTIAL"
end
function N:Outcome(provider)
 provider.nativePaletteChanged=nil
 provider.nativeGeometryChanged=nil
 local ready,partial,waiting=0,0,0
 self:ContextHealth(provider)
 local artFailed=false
 for _,view in pairs(provider.nativeCards or {}) do
  for _,mask in pairs(view.chromeOwner and view.chromeOwner.regionMasks or {}) do
   if mask.owner==view.chromeOwner and mask.failed then artFailed=true;break end
  end
 end
 provider.nativeArtFailed=artFailed or nil
 for _,state in pairs(provider.surfaceStates or {}) do
  if state.kind=="READY" then ready=ready+1
  elseif state.kind=="PARTIAL" or state.kind=="DEFERRED_HANDOFF" or state.kind=="FAULT" or state.kind=="CONFLICT" then partial=partial+1
  else waiting=waiting+1 end
 end
 if artFailed or provider.contextReady==false then partial=partial+1 end
 provider.status=partial>0 and "PARTIAL_NATIVE_BACKED" or ready>0 and "VISIBLE_NATIVE_BACKED_CARDS" or "WAITING_FOR_NATIVE_CONTENT"
 return R:Result(partial>0 and "PARTIAL" or ready>0 and "READY" or "WAITING",provider.status)
end
function N:Refresh(provider,key,unit,frame,label,owner,id)
 local generation,profile=provider.generation,M.profile
 local cards,dirty=provider.nativeCards,provider.nativeDirty
 local function current()
  return provider.generation==generation and M.profile==profile and provider.nativeCards==cards and provider.nativeDirty==dirty
 end
 -- Consume the request before calling native-aware preparation. A Show,
 -- size or setup callback that occurs during this work is a new request,
 -- even when it targets the same card. Never erase it at the old completion.
 dirty[key]=nil
 local ok,view,kind=pcall(self.Prepare,self,provider,key,unit,frame,label,owner,id)
 if not current() then return nil,"SUPERSEDED" end
 if not ok then
  local prior=provider.nativeCards[key]
  local released=not prior or self:ReleaseCard(provider,prior)
  if not current() then return nil,"SUPERSEDED" end
  view=not released and prior or nil
  kind=not released and "DEFERRED_HANDOFF" or "PARTIAL";provider.nativeFailed[key]=true;provider.nativeFailureFrames[key]=frame
  if M.Incidents then M.Incidents:Record("FAULT",provider.id,"NATIVE_CARD","SURFACE_PAINT_FAILED",id) end
 end
 local resultKind=kind or "WAITING"
 R:RecordSurface(provider,id,resultKind,resultKind=="READY" and "VISIBLE_NATIVE_INPUT" or resultKind=="WAITING" and "NATIVE_ROOT_UNAVAILABLE" or resultKind=="DEFERRED_HANDOFF" and "ROOT_HANDOFF_PENDING" or "NATIVE_CARD_PARTIAL")
 return type(view)=="table" and view or nil
end
function N:Configure(provider)
 if S:InCombat() then return R:Result("DEFERRED_COMBAT","STYLE_COMBAT_DEFERRED") end
 if R:NativeEditState()~="CLOSED" then return R:Result("DEFERRED_HANDOFF","NATIVE_EDIT_UNKNOWN") end
 provider.active=true;provider.initialized=true;provider.generation=(provider.generation or 0)+1
 provider.nativeCards=provider.nativeCards or {};provider.nativeDirty=provider.nativeDirty or {};provider.nativeFailed=provider.nativeFailed or {}
 provider.nativeFailureFrames=provider.nativeFailureFrames or {}
 for _,view in pairs(provider.nativeCards) do
  if view.chromeOwner then view.chromeOwner.parentGeneration=provider.generation end
  if view.decorationOwner then view.decorationOwner.parentGeneration=provider.generation end
 end
 return true
end
function N:Suspend(provider)
 provider.active=false
 local module=M.modules[provider.id=="groups" and "PartyRaid" or "UnitFrames"]
 if S:InCombat() then
  provider.suspendPending=true
  if module then module.pendingDisable=true end
  return false,"COMBAT_LOCKDOWN"
 end
 local contexts=M.ContextualNative
 if contexts then for _,row in pairs(contexts.rows) do if row.ownedOwner==provider then contexts:HoldForOwner(row) end end end
 local complete=true
 for id in pairs(provider.geometryRows or {}) do complete=self:ReleaseGeometry(provider,id) and complete end
 for _,view in pairs(provider.nativeCards or {}) do complete=self:ReleaseCard(provider,view) and complete end
 if complete and contexts then complete=contexts:ReleaseOwner(provider) end
 provider.suspendPending=not complete or nil
 if module then module.pendingDisable=not complete or nil end
 provider.status=complete and "NATIVE_PRESENTATION_RESTORED" or "STYLE_RESTORE_PENDING"
 return complete,provider.status
end
function N:Paint(provider,event,unit)
 local generation,profile,cards=provider.generation,M.profile,provider.nativeCards
 local function current()
  return provider.generation==generation and M.profile==profile and provider.nativeCards==cards
 end
 local dataRevision=provider.nativeDataRevision or 0
 if event=="TICK" then self:AuditRegionMasks(provider,S:Now()) end
 local module=M.modules[provider.id=="groups" and "PartyRaid" or "UnitFrames"]
 if module then
  if event=="READY_CHECK" then module.readyActive=true
  elseif event=="READY_CHECK_FINISHED" or event=="PLAYER_ENTERING_WORLD" then module.readyActive=false end
 end
 for _,view in pairs(provider.nativeCards or {}) do
  if view.controlReady and view.grayscale and view.baseUnit=="pet" and
   (view.petPaletteDirty or event=="UNIT_AURA" and unit=="pet" or event=="PLAYER_ENTERING_WORLD" or event=="UNIT_PET")
   and petPaletteCurrent(view) then self:StylePetPalette(view) end
  if view.controlReady and (event~="TICK" or view.dataDirty) and (not unit or unit==view.unit or unit==view.baseUnit
   or event=="UNIT_TARGET" and unit=="target" and view.baseUnit=="targettarget") then
   -- Paint sinks on owned passive artwork only. No aura tree walk or native
   -- input audit runs from health/power events or a render heartbeat.
   local key,frame,chrome=view.controlKey,view.inputFrame,view.chromeOwner
   local chromeGeneration=chrome and chrome.generation
   local paintRevision=provider.nativeDataRevision or 0
   local function sameView()
    return current() and cards and cards[key]==view and view.controlKey==key and view.inputFrame==frame
     and view.chromeOwner==chrome and (not chrome or chrome.generation==chromeGeneration)
   end
   if not sameView() then return end
   local previousUnit=view.unit
   local ok=pcall(U.Paint,U,view,event~=nil or view.dataDirty)
   if not sameView() then return end
   if view.unit~=previousUnit then provider.nativeUnitRevision=(provider.nativeUnitRevision or 0)+1 end
   if view.plateRole then
    if event=="TICK" then extra(view,"Tick",S:Now())
    elseif event then extra(view,"Event",event);if event=="UNIT_AURA" or event=="PLAYER_TARGET_CHANGED" or event=="PLAYER_FOCUS_CHANGED" or event=="PLAYER_ENTERING_WORLD" then extra(view,"RefreshAuras") end end
    if view.plateRole~="player" and not view.extraFallbackRequested and (view.extraCastState=="UNAVAILABLE" or view.extraAuraState=="NATIVE_CONTAINER_UNAVAILABLE_KEEP_NATIVE") then
     view.extraFallbackRequested=true;provider.nativeDirty[view.controlKey]=true
     R:RecordSurface(provider,view.surface.id,"PARTIAL","NATIVE_EXTRA_HANDOFF_PENDING")
    end
   end
   if not sameView() then return end
   if ok then view.dataDirty=(provider.nativeDataRevision or 0)~=paintRevision or nil
   else view.providerStatus="DEGRADED_DATA" end
  end
 end
 if current() and (provider.nativeDataRevision or 0)==dataRevision then
  local pending=false
  if event~="TICK" then
   for _,view in pairs(provider.nativeCards or {}) do if view.dataDirty then pending=true;break end end
  end
  -- A failed paint gets the normal bounded idle retry, not a permanent 10 Hz
  -- error loop. A different unit's event must not consume an unpainted wake.
  provider.pendingWork=pending or nil
 end
end
function U:Initialize() return self:Configure() end
function U:TargetTargetNativePolicy(fallback)
 local value,state=S:Public(C_CVar and C_CVar.GetCVar or GetCVar,"string","showTargetOfTarget")
 local ready=state=="KNOWN" and value=="1"
 self.targetTargetCVarStatus=ready and "NATIVE_TARGET_TARGET_ENABLED" or state=="KNOWN" and "NATIVE_TARGET_TARGET_DISABLED" or fallback or "TARGET_TARGET_POLICY_UNAVAILABLE"
 local id="UnitFrames.targettarget.nativePolicy"
 if ready then
  self.targetTargetRetryAt=nil;self.targetTargetRetryState="NONE"
  if self.surfaceStates then self.surfaceStates[id]=nil end
 else
  local why=self.targetTargetWriteStatus
  if why==nil or why=="APPLIED" or why=="CVAR_ALREADY_SATISFIED" or why=="NATIVE_PREFERENCE_CHANGED" then why=self.targetTargetCVarStatus end
  R:RecordSurface(self,id,self.targetTargetRetryAt and "WAITING" or "PARTIAL",why)
 end
 return ready
end
local targetTargetTransient={NOT_QUALIFIED=true,CVAR_DEFERRED=true,CVAR_UNAVAILABLE=true}
function U:RequestTargetTargetPreference()
 self.targetTargetAttempts=(self.targetTargetAttempts or 0)+1
 self.targetTargetWriteInProgress=true
 local okay,reason
 if type(R.WriteCVar)=="function" then okay,reason=R:WriteCVar("units","showTargetOfTarget",1)
 else okay,reason=false,"CVAR_API_UNAVAILABLE" end
 self.targetTargetWriteInProgress=nil
 self.targetTargetWriteStatus=okay and (reason or "APPLIED") or reason or "CVAR_UNAVAILABLE"
 self.targetTargetRetryAt=nil
 if not okay and targetTargetTransient[self.targetTargetWriteStatus] then
  if self.targetTargetAttempts<3 then
   self.targetTargetRetryAt=S:Now()+(self.targetTargetAttempts==1 and 1 or 3)
   self.targetTargetRetryState="QUEUED"
  else self.targetTargetRetryState="RETRY_REQUIRED" end
 else self.targetTargetRetryState=okay and "NONE" or "NATIVE_PREFERENCE_RETAINED" end
 -- Observe public truth independently of the write receipt. A disabled CVar
 -- must not erase the refusal that explains why the native frame is absent.
 return self:TargetTargetNativePolicy(self.targetTargetWriteStatus)
end
function U:Configure()
 if not selected() then return self:Suspend() end
 local result=N:Configure(self);if result~=true then return result end
 self.id="units"
 self.targetTargetAttempts=0;self.targetTargetRetryAt=nil
 self:RequestTargetTargetPreference()
 self.geometryDirty=true
 for _,row in ipairs(rows) do self.nativeDirty[row[1]]=true end
 return N:Outcome(self)
end
function U:ApplyLayout(surface)
 if surface and self:OwnsGeometry(surface.id) then return N:ApplyGeometry(self,surface.id) end
 if not surface or not self:OwnsPosition(surface.id) then return false,"NATIVE_BACKED_GEOMETRY" end
 local unit=surface.id:match('^UnitFrames%.(.+)$');local view=self.nativeCards and self.nativeCards[unit]
 if not self.active or not selected() or not view or not view.controlReady then return false,"NATIVE_CONTROL_UNAVAILABLE" end
 return self:Position(view)
end
function U:Tick(now)
 if not self.active then return end
 if R:NativeEditState()~="CLOSED" then return end
 if not selected() then return self:Suspend() end
 N:BeginRuntimeTick(self,now)
 N:ContextHealth(self)
 -- Native secure unit/vehicle changes invalidate the passive card even when
 -- no matching UNIT event follows. Paint the pending data before deferring
 -- layout/region work; an entire combat interval must not retain the old unit.
 N:Paint(self,"TICK")
 local policyUpdated
 if not S:InCombat() then
  if self.targetTargetRetryAt and now>=self.targetTargetRetryAt then self:RequestTargetTargetPreference();policyUpdated=true end
  if now>=(self.nextNativeProbe or 0) then
   self.nextNativeProbe=now+1
   for _,row in ipairs(rows) do local view=self.nativeCards[row[1]]
    N:RearmReplacedRoot(self,row[1],_G[row[5]])
    if (view and view.inputFrame or nil)~=_G[row[5]] or view and view.controlReady and not self:PositionCurrent(view) then self.nativeDirty[row[1]]=true end
   end
   local tot=self.nativeCards.targettarget
   if tot and not (M.profile.layouts and M.profile.layouts[self:LayoutKey("UnitFrames.targettarget")]) then
    local plan=self:TargetTargetPlan()
    if tot.mirrorReference~=plan.reference then self.nativeDirty.targettarget=true end
   end
  end
  for _,row in ipairs(rows) do if self.nativeDirty[row[1]] and not self.nativeFailed[row[1]] then
   local view=N:Refresh(self,row[1],row[1],_G[row[5]],row[2],"UnitFrames","UnitFrames."..row[1])
   if view then self.views[row[1]]=view;M.modules.UnitFrames.views[row[1]]=view
   elseif not self.nativeCards[row[1]] then self.views[row[1]]=nil;M.modules.UnitFrames.views[row[1]]=nil end
   return N:Outcome(self)
  end end
  -- Initial native card admission establishes the secure context parent.
  -- Acquire authored pet geometry only after queued admission has settled,
  -- so that our own context gate cannot invalidate a just-captured parent.
  N:GeometryTick(self)
 end
 if policyUpdated or self.nativeArtFailed or self.contextReady==false or self.nativePaletteChanged or self.nativeGeometryChanged then return N:Outcome(self) end
end
function U:NeedsRuntimeTick(now,combat) return N:RuntimeDemand(self,now,combat) end
function U:OnNativeContextHealthChanged() self.pendingWork=true;self.nativeHealthDirty=true;N:ContextHealth(self) end
function U:OnEvent(event,unit)
 if not self.active then return end
 if event=="CVAR_UPDATE" and S:Text(unit) and unit:lower()=="showtargetoftarget" then
  -- A later game setting is observed, never fought or silently overridden.
  if not self.targetTargetWriteInProgress then
   self.targetTargetWriteStatus="NATIVE_PREFERENCE_CHANGED"
   self.targetTargetRetryAt=nil;self.targetTargetRetryState="NATIVE_PREFERENCE_RETAINED"
  end
  self:TargetTargetNativePolicy();return N:Outcome(self)
 end
 -- Combat completion releases work already invalidated by native callbacks;
 -- it does not invalidate all nine prepared cards or their geometry itself.
 -- Unit/size/show/layout events retain their normal deferred repair path.
 if event=="ADDON_LOADED" or event=="PLAYER_ENTERING_WORLD" or event=="INSTANCE_ENCOUNTER_ENGAGE_UNIT"
  or event=="EDIT_MODE_LAYOUTS_UPDATED" or event=="UI_SCALE_CHANGED" or event=="DISPLAY_SIZE_CHANGED" then
  self.geometryDirty=true
  for _,row in ipairs(rows) do self.nativeDirty[row[1]]=true end
 end
 N:Paint(self,event,S:Text(unit) and unit or nil)
end
function U:MaintainSecure(event,unit) if self.active or self.suspendPending then N:Paint(self,event,S:Text(unit) and unit or nil) end end
function U:Retry()
 if S:InCombat() then return false end
 if R.PetLayout then R.PetLayout:Retry(self) end
 if not N:Suspend(self) then return false end
 if M.ContextualNative then M.ContextualNative:RetryOwned(self) end
 self.nativeFailed={};self.nativeFailureFrames={}
 self.geometryDirty=true;for _,row in pairs(self.geometryRows or {}) do row.attempts=0 end
 for _,view in pairs(self.nativeCards or {}) do view.releaseAttempts=0;view.paintAttempts=0 end
 for _,row in ipairs(rows) do self.nativeDirty[row[1]]=true end
 return true
end
function U:Suspend()
 self.targetTargetRetryAt=nil;self.targetTargetRetryState="SUSPENDED"
 local okay,reason=N:Suspend(self)
 if okay and type(R.RestoreCVars)=="function" then
  local restored,why=R:RestoreCVars("units","showTargetOfTarget")
  if not restored then self.suspendPending=true;return false,why end
 end
 return okay,reason
end
function U:GetView(unit) return self.views[unit] end
function U:IsReady(unit) local v=self.views[unit];return self.active and v and v.controlReady==true and v.contextReady~=false or false end
function U:Bounds(id)
 local unit=S:Text(id) and (id:match("^UnitFrames%.(.+)$") or id)
 local v=unit and (self.views[unit] or self.nativeCards and self.nativeCards[unit])
 return v and N:Bounds(v.inputFrame,"UnitFrames."..unit) or nil
end
function U:OptionalBounds() return {} end
function U:CapabilitySummary()
 -- Diagnostics consumes cached public receipts only. A prepared body is not
 -- a native rendering/input qualification, and an absent target is normal.
 local out={}
 for _,unit in ipairs({'player','pet','target','targettarget','focus'}) do
  local view=self.nativeCards and self.nativeCards[unit]
  if not view or view.contentPresence=='NOT_PRESENT' then
   out[#out+1]=unit..'=NOT_PRESENT'
  else
   out[#out+1]=unit..'=body:'..(self.active and view.controlReady and 'PREPARED' or 'NATIVE')
    ..'/context:'..(self.active and view.contextReady and 'READY' or 'UNAVAILABLE')
    ..'/decoration:'..(view.decorationStatus or 'NONE')
    ..'/content:'..(view.contentPresence or 'UNOBSERVED')
  end
 end
 return table.concat(out,'; ')..'; targettarget_native='..(self.targetTargetCVarStatus or 'NOT_OBSERVED')
  ..'; targettarget_preference='..(self.targetTargetWriteStatus or 'NOT_REQUESTED')
  ..'; targettarget_retry='..(self.targetTargetRetryState or 'NONE')..'; native_input=NOT_QUALIFIED'
end
function U:Status()
 local pet=self.nativeCards and self.nativeCards.pet
 local petContext=M.ContextualNative and M.ContextualNative.status.PetFrame or "NOT_OBSERVED"
 local petLayout=R.PetLayout and R.PetLayout:Status() or "UNAVAILABLE"
 local expected,observed,masked,first=0,0,0,nil
 for _,view in pairs(self.nativeCards or {}) do
  local owner=view.chromeOwner
  if owner then
   expected=expected+(owner.artRequired or 0);observed=observed+(owner.artObserved or 0)
   first=first or owner.artFirstMissing
   for _,mask in pairs(owner.regionMasks or {}) do if mask.owner==owner and not mask.failed then masked=masked+1 end end
  end
 end
 local positions={}
 for _,unit in ipairs({'player','target','focus','targettarget'}) do local view=self.views[unit];positions[#positions+1]=unit..':'..(view and view.positionStatus or 'WAITING_FOR_NATIVE_CONTROL') end
 local petGeometry=self.geometryRows and self.geometryRows['UnitFrames.pet']
 local handbacks={}
 for _,row in ipairs(rows) do
  local view=self.nativeCards and self.nativeCards[row[1]]
  if view and view.releasePending then
   local journal=view.handbackPhase=="POSITION" and view.positionOwner or view.chromeOwner
   local diagnostic=journal and journal.leaseDiagnostics
   handbacks[#handbacks+1]=row[1]..":"..(view.handbackPhase or "PENDING")..":"..(diagnostic and diagnostic.last or "NONE")
  end
 end
 local playerContext=M.ContextualNative and M.ContextualNative.rows.PlayerFrame
 local capabilities={}
 for _,spec in ipairs(rows) do local view=self.nativeCards and self.nativeCards[spec[1]]
  if view then capabilities[#capabilities+1]=spec[1]..":body="..(view.controlReady and "PREPARED" or "NATIVE")
   .."/context="..(view.contextReady and "READY" or "UNAVAILABLE").."/decoration="..(view.decorationStatus or "NONE") end
 end
 return (self.status or "WAITING_FOR_NATIVE_CONTENT").."; input=NATIVE_ORIGINAL; visibility="..(self.contextReady==true and "SECURE_CONTEXT_NATIVE_LIFETIME" or "CONTEXT_PARTIAL_NATIVE_INPUT_RETAINED").."; unit_capabilities="..table.concat(capabilities,',').."; geometry=NATIVE_CONTROLS_WITH_READABLE_PET_BODY; pet_header=LEVEL_FULL_NAME; authored_layout=PRIMARY_UNIT_POSITIONS_AND_PET_ENVELOPE; positions="..table.concat(positions,',').."; targettarget_native="..(self.targetTargetCVarStatus or "NOT_OBSERVED").."; targettarget_preference="..(self.targetTargetWriteStatus or "NOT_REQUESTED").."; targettarget_retry="..(self.targetTargetRetryState or "NONE").."; targettarget_attempts="..(self.targetTargetAttempts or 0).."; pet_geometry="..(petGeometry and petGeometry.status or 'NATIVE_POSITION_UNEDITED').."; player=GRAYSCALE_NO_EXTRAS; target_focus=EIGHT_BUFFS_BELOW_CAST; pet_palette="..(pet and pet.petPaletteStatus or "WAITING_FOR_NATIVE_CONTENT").."; pet_context="..petContext.."; pet_layout="..petLayout.."; pet_context_coupling=NATIVE_PLAYER_ANCESTRY; player_input_refreshes="..(playerContext and playerContext.playerRefreshes or 0).."; card_handback="..(#handbacks>0 and table.concat(handbacks,"|") or "NONE").."; art_required="..expected.."; art_observed="..observed.."; art_masked="..masked.."; art_repaints_repaired="..(self.artRepairs or 0).."; art_boundary_repairs="..(self.immediateArtRepairs or 0).."; art_first_missing="..(first or "NONE").."; "..N:RuntimeDemandStatus(self).."; native=NOT_RUN"
end
