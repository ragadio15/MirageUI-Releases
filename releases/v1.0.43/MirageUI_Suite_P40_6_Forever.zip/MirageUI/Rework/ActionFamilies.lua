local _,M=...
-- WP05: eight ordinary owned secure bars, with fully styled native secure
-- backing for the special families. Never replace native input/event methods,
-- register native broadcasters, or call native Edit Mode visibility setters.
local R,S=M.Rework,M.Safety
local A=R.MainAction
-- Share behavior/constants, never the main bar's mutable lease or flags.
local actionMethods={__index=function(_,key)
 local v=A[key]
 if type(v)=="function" or key=="holdProgram" or key=="clickProgram" or key=="bindingProgram" or key=="pageProgram" or key=="gridProgram" then return v end
end}
local F={families={},skins={},regions={},native="NOT_RUN",active=false,dirty=true}
R.ActionFamilies=F
local white="Interface\\Buttons\\WHITE8X8"
local theme=M.VisualTokens.options
local world=M.VisualTokens.world
local ordinary={
 {2,"MultiBarBottomLeft",61,"MULTIACTIONBAR1BUTTON"},
 {3,"MultiBarBottomRight",49,"MULTIACTIONBAR2BUTTON"},
 {4,"MultiBarRight",25,"MULTIACTIONBAR3BUTTON"},
 {5,"MultiBarLeft",37,"MULTIACTIONBAR4BUTTON"},
 {6,"MultiBar5",145,"MULTIACTIONBAR5BUTTON"},
 {7,"MultiBar6",157,"MULTIACTIONBAR6BUTTON"},
 {8,"MultiBar7",169,"MULTIACTIONBAR7BUTTON"},
}
local special={
 {"PetActionBar","PetActionButton",10,0,-.31,400,40},
 {"StanceBar","StanceButton",10,0,-.25,400,40},
 {"MultiCastActionBarFrame",nil,0,0,-.21,280,38},
 {"PossessActionBar","PossessButton",2,0,-.19,88,40},
 {"OverrideActionBar","OverrideActionBarButton",6,0,-.36,520,108},
 {"MainMenuBarVehicleLeaveButton",nil,1,.20,-.31,42,42},
 {"ExtraAbilityContainer",nil,0,.20,-.20,140,68},
}
F.nativeOwners={MainActionBar=true}
F.layouts={ ["ActionBars.bar1"]=true }
for _,d in ipairs(ordinary) do F.nativeOwners[d[2]]=true;F.layouts["ActionBars.bar"..d[1]]=true end
for _,d in ipairs(special) do F.nativeOwners[d[1]]=true;F.layouts["NativeControls."..d[1]]=true end
F.events={ADDON_LOADED=true,PET_BAR_UPDATE=true,PET_BAR_UPDATE_COOLDOWN=true,PET_BAR_SHOWGRID=true,PET_BAR_HIDEGRID=true,
 UPDATE_SHAPESHIFT_FORM=true,UPDATE_SHAPESHIFT_FORMS=true,UPDATE_SHAPESHIFT_COOLDOWN=true,UPDATE_POSSESS_BAR=true,
 UPDATE_OVERRIDE_ACTIONBAR=true,UPDATE_VEHICLE_ACTIONBAR=true,UPDATE_EXTRA_ACTIONBAR=true,UNIT_ENTERED_VEHICLE=true,
 UNIT_EXITED_VEHICLE=true,ZONE_CHANGED_NEW_AREA=true,ZONE_CHANGED=true,SPELLS_CHANGED=true,UPDATE_BINDINGS=true,
 UPDATE_MULTI_CAST_ACTIONBAR=true,PLAYER_TOTEM_UPDATE=true,
 ACTIONBAR_SHOWGRID=true,ACTIONBAR_HIDEGRID=true,SPELL_ACTIVATION_OVERLAY_GLOW_SHOW=true,
 SPELL_ACTIVATION_OVERLAY_GLOW_HIDE=true,EDIT_MODE_LAYOUTS_UPDATED=true,PLAYER_REGEN_ENABLED=true,PLAYER_ENTERING_WORLD=true}
for e in pairs(F.events) do A.events[e]=true end
A.nativeRoots=F.nativeOwners;A.layoutIDs=F.layouts

local function call(o,k,...)
 if not o or type(o[k])~="function" then return nil,"UNAVAILABLE" end
 return S:Public(o[k],nil,o,...)
end
local function field(o,k) return S:Field(o,k) end
local function n(v,default,lo,hi) return S:Number(v) and math.max(lo,math.min(hi,v)) or default end
local function cfg() return M.profile and M.profile.modules and M.profile.modules.ActionBars or {} end
-- Recovery releases native custody before retrying. Retain the authored
-- reason separately from that current RELEASED state, so an in-game report
-- can still identify the family and property that originally refused work.
function F:Failure(row,reason,phase)
 if not row then return end
 reason=S:Text(reason) and #reason<=96 and reason:match("^[A-Z][A-Z0-9_]*$") and reason or "FAMILY_SETUP_EXCEPTION"
 row.firstFailure=row.firstFailure or reason;row.lastFailure=reason
 row.failurePhase=phase or "CONFIGURE";row.failureCount=math.min(9999,(row.failureCount or 0)+1)
end
function F:GeometryFailure(row,rec,reason)
 local name=rec and call(rec.frame,"GetName")
 if not S:Text(name) or #name>96 or not name:match("^[A-Za-z0-9_]+$") then name="NATIVE_CONTROL" end
 row.lastGeometryFailure=name..":"..(reason or "NATIVE_GEOMETRY_UNAVAILABLE")
 row.firstGeometryFailure=row.firstGeometryFailure or row.lastGeometryFailure
end
local function propertyFailure(owner,key,reason)
 local id=type(owner)=="table" and owner.owner or owner
 local row=F.families[id]
 if row then
  row.firstPropertyFailure=row.firstPropertyFailure or key..":"..reason
  row.lastPropertyFailure=key..":"..reason
 elseif id=="ACTION_FLYOUT" then F.flyoutFailure=key..":"..reason end
 return false
end
local function points(f)
 local count=call(f,"GetNumPoints");if not S:Number(count) or count<0 or count>8 then return nil end
 local p={}
 for i=1,count do
  local ok,a,b,c,x,y=pcall(f.GetPoint,f,i)
  if not ok or not S:Text(a) or not S:Readable(b) or not S:Text(c) or not S:Number(x) or not S:Number(y) then return nil end
  p[#p+1]={a,b,c,x,y}
 end
 return p
end
local function samePoints(a,b)
 if not a or not b or #a~=#b then return false end
 for i=1,#a do for j=1,5 do
  if type(a[i][j])=="number" and type(b[i][j])=="number" then
   if math.abs(a[i][j]-b[i][j])>.01 then return false end
  elseif a[i][j]~=b[i][j] then return false end
 end end
 return true
end
-- Explicit dimensions and the resolved on-screen rectangle are different
-- documented API values. Native LayoutFrame also uses ignoreRect=true after
-- child size changes. Lease the explicit SetSize values, never a stale or
-- opposing-anchor rectangle, and validate the complete placement afterward.
local function sizeNow(f)
 local w,h=call(f,"GetWidth",true),call(f,"GetHeight",true)
 if S:Number(w) and S:Number(h) then return {w,h} end
end
local function capture(f)
 if not S:Frame(f,false) then return nil end
 local p=points(f);local parent,known=call(f,"GetParent")
 local size,scale=sizeNow(f),call(f,"GetScale")
 if not p or known~="KNOWN" or not size or not S:Number(scale) then return nil end
 return {frame=f,parent=parent,points=p,width=size[1],height=size[2],scale=scale}
end
local function sizeSame(a,b) return a and b and math.abs(a[1]-b[1])<.01 and math.abs(a[2]-b[2])<.01 end
local function scaleSame(a,b) return S:Number(a) and S:Number(b) and math.abs(a-b)<.001 end
local function geometryDrift(rec)
 if not rec or rec.nativeManaged then return false end
 -- A content refresh and a repeated same-value SetPoint both invalidate a
 -- family without reclaiming its layout. Only a public, changed native value
 -- may consume the bounded contention budget. Unavailable reads remain the
 -- normal geometry transaction's responsibility, never proof of a writer.
 local parent,state=call(rec.frame,"GetParent")
 if state=="KNOWN" and parent~=rec.parent then return true end
 local current=points(rec.frame)
 if current and not samePoints(current,rec.pointWritten or rec.points) then return true end
 current=sizeNow(rec.frame)
 if current and not sizeSame(current,rec.sizeWritten or {rec.width,rec.height}) then return true end
 current=call(rec.frame,"GetScale")
 return S:Number(current) and not scaleSame(current,rec.scaleWritten or rec.scale) or false
end
local function familyGeometryDrift(row)
 if not row.active then return false end
 if geometryDrift(row.lease) then return true end
 for _,rec in ipairs(row.records or {}) do if geometryDrift(rec) then return true end end
 for _,rec in pairs(row.auxRecords or {}) do if geometryDrift(rec) then return true end end
 return false
end
local function geometryCall(frame,key,...)
 -- Only the reviewed Edit Mode substitutions need their base widget method.
 -- Other widgets keep their own native method, including native button sizes.
 local fn=R.NativeMethod and R.NativeMethod(frame,key) or field(frame,key)
 if type(fn)~="function" then return false end
 local ok,result=pcall(fn,frame,...)
 return ok and result~=false
end
local function observePoints(rec)
 local actual=points(rec.frame)
 if actual then rec.pointWritten=actual;rec.pointUnobserved=nil
 else rec.pointUnobserved=true end
 return actual
end
local function writePoints(rec,target)
 local f=rec.frame
 rec.pointAttempt={}
 local ok=geometryCall(f,"ClearAllPoints")
 observePoints(rec)
 if not ok then return false end
 for i,p in ipairs(target) do
  local wanted={};for j=1,i do wanted[j]=target[j] end
  rec.pointAttempt=wanted
  ok=geometryCall(f,"SetPoint",p[1],p[2],p[3],p[4],p[5])
  observePoints(rec)
  if not ok then return false end
 end
 if not samePoints(points(f),target) then return false end
 rec.pointAttempt=nil;return true
end
local function scalarNow(frame,key)
 if key=="size" then return sizeNow(frame) end
 return call(frame,"GetScale")
end
local function scalarWrite(rec,key,wanted)
 local f=rec.frame
 rec[key.."Attempt"]=wanted
 local ok=key=="size" and geometryCall(f,"SetSize",wanted[1],wanted[2]) or
  key=="scale" and geometryCall(f,"SetScale",wanted)
 local actual=scalarNow(f,key)
 if key=="size" and actual or key=="scale" and S:Number(actual) then
  rec[key.."Written"]=actual;rec[key.."Unobserved"]=nil
 else rec[key.."Unobserved"]=true end
 return ok
end
local function geometry(rec,w,h,relative,x,y,scale)
 if S:InCombat() then return false,"COMBAT_LOCKDOWN" end
 if not R:Qualified() then return false,"UNQUALIFIED_CLIENT" end
 local f=rec.frame
 if call(f,"GetParent")~=rec.parent then return false,"NATIVE_PARENT_CHANGED" end
 if not S:Number(w) or not S:Number(h) or w<=0 or h<=0 or w>8192 or h>8192
  or scale and (not S:Number(scale) or scale<=0 or scale>8) then return false,"NATIVE_GEOMETRY_INVALID" end
 local target={{"CENTER",relative,"CENTER",x or 0,y or 0}}
 local desiredSize={w,h};local desiredScale=scale or call(f,"GetScale")
 if samePoints(points(f),target) and sizeSame(sizeNow(f),desiredSize) and scaleSame(call(f,"GetScale"),desiredScale) then return true end
 -- Clear -> scale -> size -> anchor is one transaction. A rect invalidated by
 -- ClearAllPoints, or awaiting native layout, is not an intermediate rejection.
 -- Every public post-write value is journaled even when a setter rejects work.
 if not writePoints(rec,{}) then return false,"NATIVE_ANCHOR_CLEAR_FAILED" end
 if not scaleSame(call(f,"GetScale"),desiredScale) and not scalarWrite(rec,"scale",desiredScale) then return false,"NATIVE_SCALE_SETTER_REJECTED" end
 if not sizeSame(sizeNow(f),desiredSize) and not scalarWrite(rec,"size",desiredSize) then return false,"NATIVE_SIZE_SETTER_REJECTED" end
 if not writePoints(rec,target) then return false,"NATIVE_ANCHOR_WRITE_FAILED" end
 if call(f,"GetParent")~=rec.parent then return false,"NATIVE_PARENT_CHANGED" end
 if not sizeSame(sizeNow(f),desiredSize) then return false,"NATIVE_SIZE_READBACK_MISMATCH" end
 if not scaleSame(call(f,"GetScale"),desiredScale) then return false,"NATIVE_SCALE_READBACK_MISMATCH" end
 if not samePoints(points(f),target) then return false,"NATIVE_ANCHOR_READBACK_MISMATCH" end
 rec.sizeAttempt=nil;rec.scaleAttempt=nil
 return true
end
local function restoreGeometry(rec)
 if not rec or rec.nativeManaged then return true end
 if S:InCombat() then return false end
 local f=rec.frame;local done=true
 local parent,known=call(f,"GetParent")
 if known~="KNOWN" then return false end
 if parent~=rec.parent then
  -- An external/native new parent owns its layout. Never pull it back into an
  -- earlier family merely because a cosmetic size receipt still exists.
  rec.external=true
  for _,key in ipairs({"point","size","scale"}) do rec[key.."Written"]=nil;rec[key.."Attempt"]=nil;rec[key.."Unobserved"]=nil end
  return true
 end
 -- Restore explicit scalar values before restoring possible opposing anchors.
 for _,key in ipairs({"scale","size"}) do
  if rec[key.."Written"] or rec[key.."Attempt"] then
   local current=scalarNow(f,key)
   local original=key=="size" and {rec.width,rec.height} or rec.scale
   local same=key=="size" and sizeSame or scaleSame
   local observed=key=="size" and current~=nil or key=="scale" and S:Number(current)
   if not observed then done=false
   elseif same(current,original) then rec[key.."Written"]=nil;rec[key.."Attempt"]=nil;rec[key.."Unobserved"]=nil
   elseif same(current,rec[key.."Written"]) or same(current,rec[key.."Attempt"]) then
    local ok=scalarWrite(rec,key,original)
    local actual=scalarNow(f,key)
    if ok and same(actual,original) then rec[key.."Written"]=nil;rec[key.."Attempt"]=nil;rec[key.."Unobserved"]=nil
    else done=false end
   elseif rec[key.."Unobserved"] then done=false
   else rec.external=true;rec[key.."Written"]=nil;rec[key.."Attempt"]=nil end
  end
 end
 if rec.pointWritten or rec.pointAttempt then
  local current=points(f)
  if not current then done=false
  elseif samePoints(current,rec.points) then rec.pointWritten=nil;rec.pointAttempt=nil;rec.pointUnobserved=nil
  elseif samePoints(current,rec.pointWritten) or samePoints(current,rec.pointAttempt) then
   if writePoints(rec,rec.points) then rec.pointWritten=nil;rec.pointAttempt=nil;rec.pointUnobserved=nil else done=false end
  elseif rec.pointUnobserved then done=false
  else rec.external=true;rec.pointWritten=nil;rec.pointAttempt=nil end
 end
 return done
end
local function publicValues(fn,object)
 if type(fn)~="function" then return nil end
 local function pack(...) return {n=select("#",...),...} end
 local result=pack(pcall(fn,object));if not result[1] then return nil end
 local out={n=result.n-1}
 for i=2,result.n do if not S:Readable(result[i]) then return nil end;out[i-1]=result[i] end
 return out
end
local function assetSame(a,b)
 -- Native getters may return a file ID for a path passed to a setter. Resolve
 -- that identity through the client's public lookup; never bless an arbitrary
 -- post-write value merely because the setter did not throw.
 local leases=R.CombatLeases
 if leases and type(leases.AssetEqual)=="function" then return leases:AssetEqual(a,b) end
 return a==b
end
local function valuesSame(a,b,key)
 if not a or not b or a.n~=b.n then return false end
 for i=1,a.n do
  local asset=(key=="source" and i==2 and a[1]=="texture" and b[1]=="texture") or
   ((key=="statusTexture" or key=="font") and i==1)
  if asset then if not assetSame(a[i],b[i]) then return false end
  elseif S:Number(a[i]) and S:Number(b[i]) then
   local colors=key=="vertex" or key=="statusColor"
   local leases=R.CombatLeases
   if colors and leases and leases.ColorEqual then
    if not leases:ColorEqual(a[i],b[i]) then return false end
   elseif math.abs(a[i]-b[i])>.001 then return false end
  elseif a[i]~=b[i] then return false end
 end
 return true
end
local function restorableFont(v)
 return v and v.n==3 and ((S:Text(v[1]) and v[1]~="") or
  (S:Number(v[1]) and v[1]>0 and v[1]%1==0)) and S:Number(v[2]) and v[2]>0 and
  (v[3]==nil or S:Text(v[3]))
end
local function knownRequestedAsset(key,current,desired)
 local i=key=="source" and desired[1]=="texture" and 2 or
  (key=="statusTexture" or key=="font") and 1
 if not i or not S:Text(desired[i]) or type(GetFileIDFromPath)~="function" then return true end
 if (key~="source" or current[1]==desired[1]) and assetSame(current[i],desired[i]) then return true end
 local id,state=S:Public(GetFileIDFromPath,"number",desired[i])
 -- All requested action assets are built-in files. An unresolved file cannot
 -- be verified after mutation; leave the native source untouched instead.
 return state=="KNOWN" and id>0 and id%1==0
end
F.properties={}
local function property(object,key,get,set,desired,owner)
 if not S:Frame(object,false) then return propertyFailure(owner,key,"PROPERTY_OBJECT_UNAVAILABLE") end
 local current=publicValues(get,object);if not current then return propertyFailure(owner,key,"PROPERTY_SOURCE_UNREADABLE") end
 if not knownRequestedAsset(key,current,desired) then return propertyFailure(owner,key,"PROPERTY_ASSET_UNAVAILABLE") end
 local owners=F.properties[object];if not owners then owners={};F.properties[object]=owners end
 local row=owners[key]
 if row and row.owner~=owner then return propertyFailure(owner,key,"PROPERTY_OWNER_CONFLICT") end
 if not row then row={owner=owner,get=get,set=set,original=current};owners[key]=row end
 if valuesSame(current,desired,key) then return true end
 if row.written and not valuesSame(current,row.written,key) and not valuesSame(current,row.original,key) and not valuesSame(current,row.attempt,key) then row.conflict=true;return propertyFailure(owner,key,"PROPERTY_EXTERNAL_VALUE") end
 row.attempt=desired
 local sent,result=pcall(set,object,unpack(desired,1,desired.n));sent=sent and result~=false
 local actual=publicValues(get,object)
 if valuesSame(actual,desired,key) then
  row.written=actual;row.attempt=nil
  if not sent then return propertyFailure(owner,key,"PROPERTY_SETTER_REJECTED") end
  return true
 end
 -- A failed setter/readback may still have changed native presentation. Keep
 -- its immediately observed result for rollback without declaring success.
 if actual and not valuesSame(actual,current,key) then row.written=actual end
 return propertyFailure(owner,key,sent and "PROPERTY_READBACK_MISMATCH" or "PROPERTY_SETTER_REJECTED")
end
local function restoreProperties(owner)
 local done=true
 for object,properties in pairs(F.properties) do
  for key,row in pairs(properties) do if row.owner==owner then
   local current=publicValues(row.get,object)
   if not current then done=false
   elseif valuesSame(current,row.original,key) then properties[key]=nil
   elseif valuesSame(current,row.written,key) or valuesSame(current,row.attempt,key) then
    row.attempt=row.original
    local called,result=pcall(row.set,object,unpack(row.original,1,row.original.n))
    local actual=publicValues(row.get,object)
    if called and result~=false and valuesSame(actual,row.original,key) then properties[key]=nil
    else
     -- A rejected inverse may already have changed the property. Preserve
     -- that exact observed result as our own restore debt; a later retry must
     -- not mistake it for an unrelated native/external presentation writer.
     if not called or result==false then
      if actual then row.written=actual;row.restoreUnobserved=nil
      else row.restoreUnobserved=true end
     end
     done=false
    end
   elseif row.restoreUnobserved then done=false
   else properties[key]=nil end -- newer presentation belongs to its new owner
  end end
  if next(properties)==nil then F.properties[object]=nil end
 end
 return done
end
local function regionAlpha(region,alpha,owner)
 if not region or not S:Frame(region,false) or type(region.GetAlpha)~="function" or type(region.SetAlpha)~="function" then return true end
 return property(region,"alpha",region.GetAlpha,region.SetAlpha,{n=1,alpha},owner)
end
local function ownRegion(button,layer)
 local t=button:CreateTexture(nil,layer or "BORDER");t:SetTexture(white);return t
end
local function color(t,c,a) t:SetColorTexture(c[1],c[2],c[3],a or c[4] or 1) end
local function texCoords(icon)
 local v={icon:GetTexCoord()}
 if #v==4 then return v[1],v[3],v[1],v[4],v[2],v[3],v[2],v[4] end
 return unpack(v)
end
local function textureSource(t)
 local atlas=type(t.GetAtlas)=="function" and t:GetAtlas()
 local kind,value=atlas and "atlas" or "texture",atlas or t:GetTexture()
 if type(t.GetTexCoord)=="function" and type(t.SetTexCoord)=="function" then return kind,value,texCoords(t) end
 return kind,value
end
local function setTextureSource(t,kind,value,...)
 local sent
 if kind=="atlas" then sent=t:SetAtlas(value) else sent=t:SetTexture(value) end
 if sent==false then return false end
 if select("#",...)>0 then return t:SetTexCoord(...) end
end
local function flatTexture(t)
 if type(t.GetTexCoord)=="function" and type(t.SetTexCoord)=="function" then return {n=10,"texture",white,0,0,0,1,1,0,1,1} end
 return {n=2,"texture",white}
end
local function vertexRGB(t)
 local r,g,b,a=t:GetVertexColor()
 if not S:Number(r) or not S:Number(g) or not S:Number(b) or not S:Number(a) then error("VERTEX_SOURCE_UNREADABLE") end
 return r,g,b
end
local function setVertexRGB(t,r,g,b)
 -- Texture alpha and GetVertexColor's fourth channel are the same native
 -- property. Pet UpdateButtonState deliberately switches checked alpha between
 -- 0.5 (attack) and 1 (other active actions). Only tint belongs to this lease;
 -- preserve that live alpha even while restoring the original RGB.
 local _,_,_,a=t:GetVertexColor()
 if not S:Number(a) then return false end
 return t:SetVertexColor(r,g,b,a)
end
local function buttonSkin(button,owner,label)
 if not S:Frame(button,false) then return nil end
 local skin=F.skins[button]
 if skin then skin.owner=owner;skin.active=true;return skin end
 -- Texture/font regions are unprotected visual objects; even a flyout first
 -- opened in combat can receive these without changing its secure widget.
 -- No Mirage fields or script replacements are placed on native buttons.
 skin={button=button,owner=owner,active=true,custom={},swaps={}}
 F.skins[button]=skin
 local bg=ownRegion(button,"BACKGROUND");bg:SetAllPoints();bg:SetColorTexture(.025,.038,.045,.94);skin.custom[#skin.custom+1]=bg
 for _,side in ipairs({"TOP","BOTTOM","LEFT","RIGHT"}) do
  local t=ownRegion(button,"BORDER");color(t,world.stroke,.85)
  if side=="TOP" or side=="BOTTOM" then t:SetPoint(side.."LEFT",button,side.."LEFT",0,0);t:SetPoint(side.."RIGHT",button,side.."RIGHT",0,0);t:SetHeight(1)
  else t:SetPoint("TOP"..side,button,"TOP"..side,0,0);t:SetPoint("BOTTOM"..side,button,"BOTTOM"..side,0,0);t:SetWidth(1) end
  skin.custom[#skin.custom+1]=t
 end
 skin.stateTextures={}
 for _,kind in ipairs({"Pushed","Highlight","Checked"}) do
  local get=button["Get"..kind.."Texture"]
  if type(get)=="function" then
   local t=call(button,"Get"..kind.."Texture")
   if t then skin.stateTextures[#skin.stateTextures+1]={kind=kind,object=t} end
  end
 end
 skin.proc=ownRegion(button,"OVERLAY");skin.proc:SetAllPoints();color(skin.proc,theme.accent,.18);skin.proc:Hide()
 if owner=="NativeControls.PetActionBar" then
  skin.auto=ownRegion(button,"OVERLAY");skin.auto:SetPoint("BOTTOMLEFT",button,"BOTTOMLEFT",3,2);skin.auto:SetPoint("BOTTOMRIGHT",button,"BOTTOMRIGHT",-3,2);skin.auto:SetHeight(2);color(skin.auto,theme.accent,1);skin.auto:Hide()
 end
 if label then
  local t=button:CreateFontString(nil,"OVERLAY");t:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",11,"OUTLINE")
  t:SetPoint("CENTER");t:SetText(label);t:SetTextColor(theme.accent[1],theme.accent[2],theme.accent[3]);skin.custom[#skin.custom+1]=t
 end
 return skin
end
local nativeDecor={"NormalTexture","Border","SlotBackground","FloatingBG","Flash","SpellHighlightTexture","IconBorder","IconOverlay","style","Style","QuickKeybindHighlightTexture","QuickKeybindGlow"}
local function paintState(skin)
 if not skin or not skin.active then return end
 local b=skin.button
 if call(b,"IsVisible")==false then return end
 local petIndex=skin.owner=="NativeControls.PetActionBar" and call(b,"GetID")
 if skin.auto and S:Number(petIndex) and type(GetPetActionInfo)=="function" then
  local ok,_,_,_,_,allowed,enabled=pcall(GetPetActionInfo,petIndex)
  if ok and S:Readable(allowed) and S:Readable(enabled) then
   local shown=allowed==true and enabled==true
   if skin.autoShown~=shown then skin.auto:SetShown(shown);skin.autoShown=shown end

  elseif skin.autoShown~=false then skin.auto:Hide();skin.autoShown=false end
 end
 local action=field(b,"action")
 if not S:Number(action) then action=call(b,"GetAttribute","action") end
 local proc=false
 if S:Number(action) and type(GetActionInfo)=="function" then
  local ok,kind,id=pcall(GetActionInfo,action)
  if ok and S:Text(kind) and S:Number(id) then
   if kind=="macro" then id=S:Public(GetMacroSpell,"number",id) end
   if id and C_SpellActivationOverlay then proc=S:Public(C_SpellActivationOverlay.IsSpellOverlayed,"boolean",id)==true end
  end
 end
 if skin.proc and skin.procShown~=proc then skin.proc:SetShown(proc);skin.procShown=proc end

end
local function paintSkin(skin)
 if not skin or not skin.active then return true end
 local b,owner=skin.button,skin
 if not S:Frame(b,false) then return false end
 local complete=true
 for _,key in ipairs(nativeDecor) do complete=regionAlpha(field(b,key),0,owner) and complete end
 if type(b.GetNormalTexture)=="function" then complete=regionAlpha(call(b,"GetNormalTexture"),0,owner) and complete end
 for _,t in ipairs(skin.custom) do t:SetAlpha(1) end
 -- The engine keeps its original pointer/checked-state texture objects.
 -- Only their pixels/colors change; no native button method or script is tainted.
 for _,row in ipairs(skin.stateTextures) do
  local t=row.object;local c=row.kind=="Checked" and world.health or theme.accent
  -- Vehicle exit changes its highlight source when an early taxi landing is
  -- requested. Keep that native acknowledgement and its button state lifetime.
  local nativeSource=skin.owner=="NativeControls.MainMenuBarVehicleLeaveButton" and row.kind=="Highlight"
  if not nativeSource and type(t.GetTexture)=="function" then complete=property(t,"source",textureSource,setTextureSource,flatTexture(t),owner) and complete end
  local strength=row.kind=="Highlight" and .19 or .24
  if type(t.GetBlendMode)=="function" and type(t.SetBlendMode)=="function" then
   complete=property(t,"blend",t.GetBlendMode,t.SetBlendMode,{n=1,"ADD"},owner) and complete
  else complete=propertyFailure(owner,"blend","PROPERTY_SOURCE_UNREADABLE") and complete end
  -- Premultiplied additive RGB supplies Mirage's restrained glow without
  -- claiming native state alpha. Native alpha=1 never becomes an opaque fill.
  if type(t.GetVertexColor)=="function" and type(t.SetVertexColor)=="function" then
   complete=property(t,"vertex",vertexRGB,setVertexRGB,{n=3,c[1]*strength,c[2]*strength,c[3]*strength},owner) and complete
  end
 end
 local icon=field(b,"icon") or field(b,"Icon")
 if icon and type(icon.GetTexCoord)=="function" and type(icon.SetTexCoord)=="function" then
  complete=property(icon,"coords",texCoords,icon.SetTexCoord,{n=8,.07,.07,.07,.93,.93,.07,.93,.93},owner) and complete
 end
 local mask=field(b,"IconMask")
 if mask and type(mask.GetTexture)=="function" and type(mask.SetTexture)=="function" then
  complete=property(mask,"source",textureSource,setTextureSource,flatTexture(mask),owner) and complete
 end
 paintState(skin)
 if skin.auto and not S:InCombat() then complete=regionAlpha(field(b,"AutoCastOverlay"),0,owner) and complete end
 local nativeProc=field(b,"SpellActivationAlert")
 if nativeProc and not S:InCombat() then complete=regionAlpha(nativeProc,0,owner) and complete end
 if not S:InCombat() then
  skin.fontWaiting=0
  for _,key in ipairs({"HotKey","Count","Name"}) do
   local font=field(b,key)
   if font and type(font.GetFont)=="function" and type(font.SetFont)=="function" then
    local current=publicValues(font.GetFont,font)
    if not restorableFont(current) then
     -- Optional native labels can be empty before their template/content
     -- initialises them. Preserve that exact state; do not guess a font asset
     -- or fail unrelated secure input because a blank label has no receipt.
     local receipt=F.properties[font] and F.properties[font].font
     local text=publicValues(field(font,"GetText"),font)
     if not receipt and text and text.n<=1 and (text[1]==nil or text[1]=="") then skin.fontWaiting=skin.fontWaiting+1
     else complete=propertyFailure(owner,"font","PROPERTY_SOURCE_UNREADABLE") and complete end
    else
     local size=key=="HotKey" and 9 or key=="Count" and 10 or 8
     -- The readable native face is already a proven asset. Typography changes
     -- size/outline only; STANDARD_TEXT_FONT may be an unresolved alias here.
     complete=property(font,"font",font.GetFont,font.SetFont,{n=3,current[1],size,"OUTLINE"},owner) and complete
    end
   end
  end
 end
 local hotkey=field(b,"HotKey")
 if hotkey then complete=regionAlpha(hotkey,cfg().showHotkeys==false and 0 or 1,owner) and complete end
 local name=field(b,"Name")
 if name then complete=regionAlpha(name,cfg().hideMacroText==true and 0 or 1,owner) and complete end
 return complete
end
local function restoreSkin(skin)
 for _,t in ipairs(skin.custom) do t:SetAlpha(0) end
 if skin.proc then skin.proc:Hide();skin.procShown=false end;if skin.auto then skin.auto:Hide();skin.autoShown=false end
 local done=restoreProperties(skin)
 skin.active=not done;skin.pending=not done or nil;return done
end

local nativeArt={
 PetActionBar={"Background","BackgroundSmall","BackgroundLarge"},StanceBar={"Background","BackgroundSmall","BackgroundLarge"},
 PossessActionBar={"Background","BackgroundSmall","BackgroundLarge"},
 OverrideActionBar={"EndCapL","EndCapR","Divider1","Divider2","Divider3","_BG","_Border","MicroBGL","_MicroBGMid","MicroBGR","ButtonBGL","_ButtonBGMid","ButtonBGR","PitchOverlay","PitchBG","PitchButtonBG","ExitBG"},
 -- Highlight is the vehicle button's functional state texture, already styled
 -- above. Suppressing it here would cross-write our own vertex alpha receipt.
 ExtraAbilityContainer={},MainMenuBarVehicleLeaveButton={},
}
local function paintNativeArt(row)
 local complete=true
 for _,key in ipairs(nativeArt[row.name] or {}) do complete=regionAlpha(field(row.native,key),0,row.id) and complete end
 local art=field(row.native,"BackgroundArtTextures")
 if type(art)=="table" and S:Readable(art) then
  for i=1,64 do
   local region,state=S:FieldAccess(art,i)
   if state=="ABSENT" then break end
   if state~="KNOWN" then return false end
   complete=regionAlpha(region,0,row.id) and complete
  end
 end
 return complete
end
function F:CreateOrdinary(def)
 local index,name,first,command=unpack(def);local id="ActionBars.bar"..index
 local row={name=name,id=id,index=index,buttons={},native=_G[name],ordinary=true,definition=def,profile=M.profile,status="PREPARING"}
 row.layoutID=id;setmetatable(row,actionMethods);self.families[id]=row
 if M.surfaces[id] then return nil,"CONFLICT_ACTION_SURFACE" end
 local interface=M.ActionInterface
 local parent=interface and interface.ParentFor and interface:ParentFor(id) or UIParent
 local bar=CreateFrame("Frame","MirageM2ActionBar"..index,parent,"SecureHandlerStateTemplate")
 row.frame=bar;bar:Hide();bar:SetSize(420,38)
 if not S:InitializeSecureHandler(bar) then return nil,"SECURE_HANDLER_UNAVAILABLE" end
 M:TrackRoot("ActionBars",bar,false,interface and interface.cleanupGuard)
 row.bindingOwner=bar
 for i=1,12 do row:CreateButton(bar,i,"MirageM2Action"..index.."_"..i,first+i-1,command..i,index) end
 bar:SetAttribute("actionpage",math.floor((first-1)/12)+1)
 bar:SetAttribute("state-muipage",math.floor((first-1)/12)+1)
 bar:SetAttribute("mui-bindings",A.bindingProgram)
 bar:SetAttribute("_onstate-muibindings",[[ self:RunAttribute("mui-bindings") ]])
 row.surface={id=id,module="ActionBars",frame=bar,security="SECURE_PREDECLARED",editable=true,minWidth=24,minHeight=20,
  groups={combat=true},layout={x=(index==4 or index==5) and (.46-(index-4)*.03) or 0,y=index<=3 and (-.43+(index-1)*.05) or index<=5 and 0 or (-.28+(index-6)*.05),width=(index==4 or index==5) and 38 or 420,height=(index==4 or index==5) and 420 or 38,scale=1},reworkProvider=A}
 row.surface.OnLayout=function(_,layout) return row:Arrange(layout) end
 bar.surface=row.surface;M.CVE:Register(row.surface);row:AttachVisualWake();row.controlsReady=true
 return row
end
function F:Ordinary(row)
 if row.controlsReady~=true then row.status="RELOAD_REQUIRED_CONTROLS_INCOMPLETE";return false end
 local native=_G[row.name]
 if not S:Frame(native,false) then row.status="WAITING_NATIVE_CONTROL";return false end
 if row.native and row.native~=native and row.lease then
  if not self:Release(row) then row.status="FAMILY_RESTORE_PENDING";return false end
  row.visibleDriver=nil;row.holdDirty=true;row.bindingsDirty=true
 end
 if not row.lease then
  local lease,why=R.NativeActionPresentation:Acquire(native,nil,"hide")
  if not lease then row.status=why;return false end
  row.lease=lease;row.homeParent=row.homeParent or lease.parent;row.native=native
  if why then row.status=why;return false end
 end
 if row.hookedNative~=native and type(hooksecurefunc)=="function" then
  hooksecurefunc(native,"SetParent",function()
   if F.active and row.native==native and row.lease then row.nativeDirty=true;F.pendingWork=true;A.pendingWork=true end
  end)
  row.hookedNative=native
 end
 if not R.NativeActionPresentation:Current(row.lease) then row.status="NATIVE_ACTION_PRESENTATION_CHANGED";return false end
 row.profile=M.profile
 local fresh=not row.active
 if fresh or row.layoutDirty then M.Layout:Apply(row.surface);row.layoutDirty=nil end
 local driver=row:VisibilityDriver(M.profile)
 if driver~=row.visibleDriver and not row:SetVisibilityDriver(driver) then row.status="VISIBILITY_DRIVER_UNAVAILABLE";return false end
 if fresh or row.holdDirty then row:RefreshHold() end
 if fresh or row.bindingsDirty then
  local bound,why=row:RefreshBindings();if not bound then row.status=why;return false end
 end
 row.active=true;row.status="CUSTOM_ORDINARY_ACTIVE";row.nativeDirty=nil
 row.frame:SetAttribute("mui-grid-active",true);row:RefreshGrid(fresh)
 row:RefreshVisual(S:Now(),fresh)
 return true
end

function F:CreateSpecial(def)
 local name,prefix,count,x,y,w,h=unpack(def);local id="NativeControls."..name
 local row={id=id,name=name,definition=def,prefix=prefix,count=count,controls={},records={},status="PREPARING",
  nativeManaged=name=="ExtraAbilityContainer"};self.families[id]=row
 if M.surfaces[id] then return nil,"CONFLICT_ACTION_SURFACE" end
 local interface=M.ActionInterface
 local parent=interface and interface.ParentFor and interface:ParentFor(id) or UIParent
 local frame=CreateFrame("Frame","MirageM2Host"..name,parent,"SecureHandlerStateTemplate");row.frame=frame
 frame:SetSize(w,h);frame:EnableMouse(false)
 if not S:InitializeSecureHandler(frame) then return nil,"SECURE_HANDLER_UNAVAILABLE" end
 M:TrackRoot("ActionBars",frame,false,interface and interface.cleanupGuard)
 row.surface={id=id,module="ActionBars",frame=frame,security="SECURE_PREDECLARED",editable=not row.nativeManaged,minWidth=24,minHeight=24,
  groups={combat=true},layout={x=x,y=y,width=w,height=h,scale=1},reworkProvider=A}
 row.surface.OnLayout=function(_,l) row.layout=l;row.dirty=true end
 frame.surface=row.surface;M.CVE:Register(row.surface);row.controlsReady=true
 return row
end
function F:AddControl(row,button,label,list)
 if not S:Frame(button,false) then return false end
 if not label and not S:Frame(field(button,"icon") or field(button,"Icon"),false) then row.status="CONTROL_ICON_UNAVAILABLE";return false end
 row.recordMap=row.recordMap or {}
 local rec=row.recordMap[button]
 if not rec then
  if row.nativeManaged then rec={frame=button,nativeManaged=true}
  else rec=capture(button) end
  if not rec then row.status="CONTROL_GEOMETRY_UNREADABLE";return false end
  row.recordMap[button]=rec;row.records[#row.records+1]=rec
 end
 local skin=buttonSkin(button,row.id,label)
 if not skin then row.status="CONTROL_STYLE_UNAVAILABLE";return false end
 if not skin.wakeHooks and type(hooksecurefunc)=="function" then
  skin.wakeHooks=true
  for _,method in ipairs({"SetNormalTexture","SetPushedTexture","SetHighlightTexture","SetCheckedTexture"}) do
   if type(button[method])=="function" then
    hooksecurefunc(button,method,function()
     if F.active and row.active and not F.writing then row.presentationDirty=true;F.pendingWork=true end
    end)
   end
  end
 end
 list[#list+1]=button;return true
end
function F:DiscoverSpecial(row)
 local list={};local ready=true
 if row.prefix then
  for i=1,row.count do ready=self:AddControl(row,_G[row.prefix..i],nil,list) and ready end
 elseif row.name=="MainMenuBarVehicleLeaveButton" then ready=self:AddControl(row,row.native,"Exit",list)
 elseif row.name=="MultiCastActionBarFrame" then
  -- Retain native internal positions, flyouts and recall/summon scripts.
  for i=1,4 do local b=_G["MultiCastActionButton"..i]
   if S:Frame(b,false) then ready=self:AddControl(row,b,nil,list) and ready end
  end
  for _,name in ipairs({"MultiCastSummonSpellButton","MultiCastRecallSpellButton"}) do
   local b=_G[name];if S:Frame(b,false) then ready=self:AddControl(row,b,nil,list) and ready end
  end
 elseif row.name=="ExtraAbilityContainer" then
  -- Exact ExtraAbilityContainerMixin contract: only its registered frame
  -- pairs represent live encounter/zone controls. A loaded ExtraActionButton1
  -- by itself is not proof of content and must never create a placeholder.
  local frames=field(row.native,"frames")
  if type(frames)~="table" or not S:Readable(frames) then row.status="NATIVE_CONTENT_UNAVAILABLE";return false end
  local extra,zone=false,false
  for i=1,8 do
   local pair,state=S:FieldAccess(frames,i)
   if state=="ABSENT" then break end
   if state~="KNOWN" or type(pair)~="table" then row.status="NATIVE_CONTENT_UNAVAILABLE";return false end
   local frame,known=S:FieldAccess(pair,"frame")
   if known~="KNOWN" or not S:Frame(frame,false) then row.status="NATIVE_CONTENT_UNAVAILABLE";return false end
   if frame==_G.ExtraActionBarFrame then extra=true
   elseif frame==_G.ZoneAbilityFrame then zone=true
   else row.status="NATIVE_CONTENT_UNREVIEWED";return false end
  end
  local overflow,state=S:FieldAccess(frames,9)
  if state~="ABSENT" then row.status="NATIVE_CONTENT_LIMIT";return false end
  if extra then ready=self:AddControl(row,_G.ExtraActionButton1,nil,list) and ready end
  row.zoneStatus=zone and "WAITING_ZONE_POOL" or "ZONE_INACTIVE"
  if zone then
   local nativeZone=_G.ZoneAbilityFrame;local holder=field(nativeZone,"SpellButtonContainer")
   if not holder or type(field(holder,"EnumerateActive"))~="function" then row.status="ZONE_POOL_UNAVAILABLE";return false end
   local count=0
   local ok=pcall(function()
    for button in holder:EnumerateActive() do
     count=count+1;if count>20 then error("ZONE_POOL_LIMIT",0) end
     if not self:AddControl(row,button,nil,list) then error("ZONE_CONTROL_UNAVAILABLE",0) end
    end
   end)
   if not ok then row.status="ZONE_POOL_UNAVAILABLE";return false end
   row.zoneStatus="ZONE_POOL_READY"
   ready=regionAlpha(field(nativeZone,"Style"),0,row.id) and ready
  end
  row.nativeContent=extra or zone

 end
 if row.name=="OverrideActionBar" then
  ready=self:AddControl(row,field(row.native,"PitchUpButton"),"+",list) and ready
  ready=self:AddControl(row,field(row.native,"PitchDownButton"),"-",list) and ready
  ready=self:AddControl(row,field(row.native,"LeaveButton"),"Exit",list) and ready
 end
 if not ready then row.status="WAITING_NATIVE_BUTTONS";return false end
 local active={};for _,b in ipairs(list) do active[b]=true end
 -- A pooled zone button may have been returned or reused since the last pass.
 -- Release only geometry that still matches this family's previous write.
 for _,b in ipairs(row.controls) do if not active[b] then
  if not restoreGeometry(row.recordMap[b]) then row.status="POOLED_CONTROL_RESTORE_PENDING";return false end
  if not restoreSkin(self.skins[b]) then row.status="POOLED_STYLE_RESTORE_PENDING";return false end
  row.recordMap[b]=nil
  for i=#row.records,1,-1 do if row.records[i].frame==b then table.remove(row.records,i) end end
 end end
 row.controls=list;row.controlSet=active
 return true
end
local function skinStatus(row,bar,colorValue)
 if not S:Frame(bar,false) then return false end
 if type(bar.GetStatusBarTexture)~="function" or type(bar.SetStatusBarTexture)~="function" then return false end
 local function source(object)
  local texture=object:GetStatusBarTexture()
  return texture and texture:GetTexture()
 end
 local ok=property(bar,"statusTexture",source,bar.SetStatusBarTexture,{n=1,white},row.id)
 if type(bar.GetOrientation)=="function" and type(bar.SetOrientation)=="function" then
  ok=property(bar,"orientation",bar.GetOrientation,bar.SetOrientation,{n=1,"HORIZONTAL"},row.id) and ok
 end
 if type(bar.GetStatusBarColor)=="function" and type(bar.SetStatusBarColor)=="function" then
  ok=property(bar,"statusColor",bar.GetStatusBarColor,bar.SetStatusBarColor,{n=4,colorValue[1],colorValue[2],colorValue[3],1},row.id) and ok
 end
 row.barBackdrops=row.barBackdrops or {}
 if not row.barBackdrops[bar] then
  local bg=ownRegion(bar,"BACKGROUND");bg:SetAllPoints();bg:SetColorTexture(.025,.038,.045,.94);row.barBackdrops[bar]=bg
 end
 row.barBackdrops[bar]:SetAlpha(1)
 return ok
end
function F:OverrideDetails(row,l)
 row.auxRecords=row.auxRecords or {}
 local keys={"healthBar","powerBar","xpBar"}
 local colors={world.health,world.mana,theme.accent}
 local height=math.min(9,math.max(2,l.height/10));local width=math.max(1,(l.width-16)/2)
 for i,key in ipairs(keys) do
  local bar=field(row.native,key)
  if not S:Frame(bar,false) then row.status="OVERRIDE_STATUS_UNAVAILABLE";return false end
  local rec=row.auxRecords[bar]
  if not rec then rec=capture(bar);if not rec then return false end;row.auxRecords[bar]=rec end
  local w=i==3 and math.max(1,l.width-12) or width
  local x=i==3 and 0 or (i==1 and -(width+4)/2 or (width+4)/2)
  local y=i==3 and -l.height/2+height/2+3 or l.height/2-height/2-3
  local placed,reason=geometry(rec,w,height,row.native,x,y,1)
  if not placed then self:GeometryFailure(row,rec,reason);return false end
  if not skinStatus(row,bar,colors[i]) then return false end
 end
 for _,key in ipairs({"HealthBarBG","HealthBarOverlay","PowerBarBG","PowerBarOverlay"}) do regionAlpha(field(row.native,key),0,row.id) end
 local xp=field(row.native,"xpBar")
 for _,key in ipairs({"XpL","XpMid","XpR","XpBackground","XpOverlay"}) do regionAlpha(field(xp,key),0,row.id) end
 for i=1,19 do regionAlpha(field(xp,"XpDiv"..i),0,row.id) end
 -- The native pitch indicator retains its value calculation. Its atlas is
 -- replaced and the guide moved inside the same authored override envelope.
 local guide,marker=field(row.native,"PitchOverlay"),field(row.native,"PitchMarker")
 if guide and marker then
  local rec=row.auxRecords[guide]
  if not rec then rec=capture(guide);if rec then row.auxRecords[guide]=rec end end
  if rec then
   local placed,reason=geometry(rec,6,math.max(36,l.height-32),row.native,l.width/2-5,0,1)
   if not placed then self:GeometryFailure(row,rec,reason);return false end
  end
  if type(marker.GetTexture)=="function" then property(marker,"source",textureSource,setTextureSource,flatTexture(marker),row.id) end
 end
 return true
end
local contextFamilies={PetActionBar=true,StanceBar=true,PossessActionBar=true}
function F:SpecialContext(row)
 if not contextFamilies[row.name] then
  -- Native override, encounter actions and exits retain their own lifetime.
  row.contextStatus="NATIVE_ESSENTIAL_LIFETIME";return true
 end
 row.contextRequested=true
 local contexts=M.ContextualNative
 if not contexts then row.contextStatus="CONTEXT_UNAVAILABLE";return false end
 local ready,status=contexts:OwnedReady(self,row.name)
 if ready then row.contextReady=true;row.contextStatus=status;return true end
 row.contextReady,row.contextStatus=contexts:AcquireOwned(self,row.name,"ActionBars",row.id)
 return row.contextReady
end
function F:ContextHealth()
 local complete=true
 for _,row in pairs(self.families) do if row.contextRequested then
  row.contextReady,row.contextStatus=M.ContextualNative:OwnedReady(self,row.name)
  if not row.contextReady then complete=false end
 end end
 return complete
end
function F:OnNativeContextHealthChanged()
 self.pendingWork=true;self.complete=false;self.completionDirty=true
 if A.active then A.pendingWork=true end
end
function F:Special(row)
 if row.controlsReady~=true then row.status="RELOAD_REQUIRED_CONTROLS_INCOMPLETE";return false end
 local native=_G[row.name]
 if row.name=="MultiCastActionBarFrame" and not S:Frame(native,false) then
  row.status="NOT_APPLICABLE_NATIVE_TOTEM_BAR";row.dirty=nil;return true
 end
 if not S:Frame(native,false) then row.status="WAITING_NATIVE_FAMILY";return false end
 if row.native and row.lease and row.native~=native then row.status="CONFLICT_NATIVE_IDENTITY";return false end
 -- Establish functional visibility before optional layout/skin work. Its
 -- native fallback keeps this gate even if one cosmetic property is refused.
 if not self:SpecialContext(row) then row.status="NATIVE_CONTEXT_UNAVAILABLE";return false end
 row.native=native
 if row.nativeManaged then
  -- Native encounter/zone host ownership is deliberate. Its OnShow/OnHide
  -- participates in ManagedFrameSystem and its empty state has no useful
  -- rect. Retain that lifetime, ancestry and placement; skin live controls.
  row.layoutAuthority="NATIVE_MANAGED_LAYOUT"
  if row.managedHooked~=native and type(hooksecurefunc)=="function" then
   for _,method in ipairs({"AddFrame","RemoveFrame","UpdateLayoutIndicies"}) do
    if type(field(native,method))=="function" then hooksecurefunc(native,method,function()
     if F.active and row.native==native and not F.writing then row.dirty=true;F.pendingWork=true end
    end) end
   end
   row.managedHooked=native
  end
  if not self:DiscoverSpecial(row) then return false end
  for _,b in ipairs(row.controls) do
   if not paintSkin(self.skins[b]) then row.status="CONTROL_STYLE_FAILED";return false end
  end
  if not paintNativeArt(row) then row.status="NATIVE_ART_WRITE_FAILED";return false end
  row.active=true;row.status=row.nativeContent and "CUSTOM_NATIVE_MANAGED_ACTIVE" or "WAITING_NATIVE_CONTENT"
  row.dirty=nil;row.presentationDirty=nil
  return true
 end
 if not row.lease then
  row.lease=capture(native);if not row.lease then row.status="NATIVE_GEOMETRY_UNREADABLE";return false end
  if row.hookedNative~=native and type(hooksecurefunc)=="function" then
   for _,method in ipairs({"SetPoint","ClearAllPoints","SetSize","SetScale","SetParent"}) do
    if type(native[method])=="function" then hooksecurefunc(native,method,function() if F.active and row.active and row.native==native and not F.writing then row.dirty=true end end) end
   end
   if type(native.Show)=="function" then hooksecurefunc(native,"Show",function()
    if F.active and row.active and row.native==native and not F.writing then row.presentationDirty=true;F.pendingWork=true end
   end) end
   row.hookedNative=native
  end
 end
 if call(native,"GetParent")~=row.lease.parent then row.status="CONFLICT_NATIVE_PARENT";return false end
 if not self:DiscoverSpecial(row) then return false end
 local count=#row.controls
 if row.name=="StanceBar" then
  -- The native template creates ten buttons even when the character only has
  -- a few forms. Fit the public active count instead of shrinking three real
  -- stances to make room for seven hidden placeholders. Hidden native slots
  -- keep their identities and geometry; native lifetime still hides zero forms.
  local forms,state=S:Public(GetNumShapeshiftForms,"number")
  if state=="KNOWN" and forms>=0 and forms<=count and forms<=10 and forms%1==0 then
   count=forms;row.formCountStatus="PUBLIC_ACTIVE_FORMS"
  else row.formCountStatus="NATIVE_CAPACITY_FALLBACK" end
  row.formCount=count
 end
 M.Layout:Apply(row.surface)
 local l=row.layout or row.surface.layout
 local pscale=call(row.lease.parent,"GetEffectiveScale");local ownedScale=call(row.frame,"GetEffectiveScale")
 if not S:Number(pscale) or pscale<=0 or not S:Number(ownedScale) then row.status="NATIVE_SCALE_UNREADABLE";return false end
 self.writing=true
 local w,h,scale=l.width,l.height,ownedScale/pscale
 if row.name=="MultiCastActionBarFrame" then
  w,h=row.lease.width,row.lease.height
  scale=scale*math.min(l.width/math.max(1,w),l.height/math.max(1,h))
 end
 local moved,why=geometry(row.lease,w,h,row.frame,0,0,scale)
 self.writing=nil
 if not moved then self:GeometryFailure(row,row.lease,why);row.status=why or "NATIVE_GEOMETRY_FAILED";return false end
 local columns=math.min(math.max(1,count),math.floor(n(cfg().columns,12,1,12)))
 local fixed=M.ActionInterface and M.ActionInterface.specs[row.id]
 if fixed then columns=math.max(1,count)
 elseif cfg().vertical then columns=1 end
 local rows=math.ceil(math.max(1,count)/columns)
 local padY=row.name=="OverrideActionBar" and math.min(20,l.height/3) or 8
 local availableW,availableH=math.max(1,l.width-(fixed and 16 or 8)),math.max(1,l.height-padY)
 local gap=math.min(fixed and 4 or n(cfg().gap,4,0,12),availableW/math.max(1,columns*2),availableH/math.max(1,rows*2))
 local size=math.max(1,math.min((availableW-(columns-1)*gap)/columns,(availableH-(rows-1)*gap)/rows))
 local left=-((columns-1)*(size+gap))/2;local top=((rows-1)*(size+gap))/2
 for i,b in ipairs(row.controls) do
  local rec=row.recordMap[b]
  if b~=native and row.name~="MultiCastActionBarFrame" and (row.name~="StanceBar" or i<=count) then
   self.writing=true;local placed,reason=geometry(rec,size,size,native,left+((i-1)%columns)*(size+gap),top-math.floor((i-1)/columns)*(size+gap),1);self.writing=nil
   if not placed then self:GeometryFailure(row,rec,reason);row.status="CONTROL_LAYOUT_FAILED";return false end
  end
  if not paintSkin(self.skins[b]) then row.status="CONTROL_STYLE_FAILED";return false end
 end
 if row.name=="OverrideActionBar" then
  self.writing=true;local ok=self:OverrideDetails(row,l);self.writing=nil
  if not ok then row.status="OVERRIDE_DETAIL_LAYOUT_FAILED";return false end
 end
 if not paintNativeArt(row) then row.status="NATIVE_ART_WRITE_FAILED";return false end
 row.active=true;row.status="CUSTOM_NATIVE_BACKING_ACTIVE";row.dirty=nil;row.presentationDirty=nil
 return true
end
function F:Release(row,keepContext)
 if S:InCombat() then row.pending=true;return false end
 local done=true
 if row.ordinary then
  if row.frame then row.frame:SetAttribute("mui-grid-active",false);row:ClearVisibilityDriver();ClearOverrideBindings(row.frame);row.frame:Hide() end
  for _,b in ipairs(row.buttons) do if b.keyPress then b.keyPress:Hide();b.pressUntil=nil end end
  if row.lease then
   done=R.NativeActionPresentation:Release(row.lease)
   if done then row.lease=nil end
  end
 else
  self.writing=true
  for _,rec in ipairs(row.records) do if rec.frame~=row.native then done=restoreGeometry(rec) and done end end
  for _,rec in pairs(row.auxRecords or {}) do done=restoreGeometry(rec) and done end
  if row.lease then
   done=restoreGeometry(row.lease) and done
  end
  self.writing=nil
  for _,skin in pairs(self.skins) do if skin.owner==row.id and (skin.active or skin.pending) then done=restoreSkin(skin) and done end end
  for _,bg in pairs(row.barBackdrops or {}) do bg:SetAlpha(0) end
  done=restoreProperties(row.id) and done
  if done then
   row.lease=nil;row.records={};row.recordMap={};row.auxRecords={};row.controls={};row.controlSet={}
   if not keepContext and M.ContextualNative then
    done=M.ContextualNative:ReleaseOwned(self,row.name)
    if done then row.contextReady=nil end
   end
  end
 end
 row.active=false;row.pending=not done or nil
 if done then row.status=row.external and "RELEASED_EXTERNAL_PRESERVED" or "RELEASED" else row.status="FAMILY_RESTORE_PENDING" end
 return done
end
local function waiting(status)
 return status=="WAITING_NATIVE_FAMILY" or status=="WAITING_NATIVE_CONTROL" or status=="WAITING_NATIVE_BUTTONS"
end
function F:RunFamily(row,method)
 if row.blocked then return false end
 if row.pending then
  if not self:Release(row) then return false end
 end
 local ok,ready=pcall(method,self,row)
 if ok and ready then return true end
 self.complete=false
 local why=ok and row.status or "FAMILY_SETUP_EXCEPTION"
 local releasedOK,released=pcall(self.Release,self,row,true);self.writing=nil
 released=releasedOK and released==true
 row.status=why;self:Failure(row,why,"CONFIGURE")
 if not waiting(why) then row.blocked=true end
 if not released then row.pending=true end
 return false
end
function F:Press(row,index,down)
 if not self.active or not A.active or not row or not row.active or M.state.safe then return end
 if not S:Number(index) or index<1 or index>12 or index%1~=0 then return end
 local button=row.buttons[index];if not button or not button.keyPress then return end
 button.pressUntil=down and S:Now()+.18 or 0
 button.keyPress:SetShown(down==true);button.renderPress=down==true
end
function F:PreparePressHooks()
 if self.pressHooks or type(hooksecurefunc)~="function" then return end
 self.pressHooks=true
 -- These are post-notifications used by the supplied EUI press presentation.
 -- They paint only addon-owned textures; native input and return values stand.
 local names={ActionButtonDown=true,ActionButtonUp=false,MultiActionButtonDown=true,MultiActionButtonUp=false}
 for name,down in pairs(names) do
  if type(_G[name])=="function" then
   local multi=name:sub(1,5)=="Multi"
   hooksecurefunc(name,function(bar,index)
    if multi then
     if not S:Text(bar) then return end
     local row
     for _,d in ipairs(ordinary) do if d[2]==bar then row=F.families["ActionBars.bar"..d[1]];break end end
     F:Press(row,index,down)
    else F:Press(A,bar,down) end
   end)
  end
 end
end
-- Each secure family remains an atomic transaction, but unrelated families
-- must not share one non-preemptible setup/tick callback. The ordinary main
-- twelve controls are prepared by ActionBar; unopened families stay native.
local prepareKey="Rework.main.prepare"
local function familyDefinition(index)
 if index<=#ordinary then local d=ordinary[index];return d,"ActionBars.bar"..d[1],true end
 local d=special[index-#ordinary];return d,"NativeControls."..d[1],false
end
function F:ReconcileCompletion()
 if self.complete then return true end
 if not self.active or not A.active or self.preparing or self.preparationFault or self.nativeGateFault then return false end
 -- An expected late native family can succeed without another whole-profile
 -- Configure. Read the completed family outcomes rather than retaining the
 -- earlier partial result forever; blocked/restoring families never qualify.
 for index=1,#ordinary+#special do
  local _,id=familyDefinition(index);local row=self.families[id]
  if not row or row.controlsReady~=true or row.blocked or row.pending or row.visualConflict
   or row.nativeDirty or row.dirty
   or row.active~=true and row.status~="NOT_APPLICABLE_NATIVE_TOTEM_BAR" then return false end
 end
 if not self:ContextHealth() then return false end
 self.complete=true;self.prepareReason="ACTION_FAMILIES_READY";A.pendingWork=true
 return true
end
function F:CancelWork()
 self.workRevision=(self.workRevision or 0)+1
 local queue=M.RuntimeScheduler
 if queue then queue:Cancel(prepareKey);queue:CancelPrefix("Rework.main.family.") end
 self.preparation=nil;self.preparing=nil
end
function F:PreparationIdentity(plan)
 return self.active and A.active and self.preparation==plan and plan.revision==self.workRevision
  and plan.profile==M.profile and plan.generation==(M.state.settingsGeneration or 0)
  and not M.state.safe
end
function F:PreparationCurrent(plan)
 return self:PreparationIdentity(plan) and R:Selected("main",plan.profile)
end
function F:FailPreparation(plan,reason)
 -- Contain an unexpected continuation failure once. Neither the scheduler's
 -- pcall nor another provider tick may repeatedly retry a half-finished step.
 if self.preparation~=plan or self.workRevision~=plan.revision then return false end
 local receipt={reason=reason,revision=plan.revision}
 self.preparationFaultReceipt=receipt;self.preparationFault=reason;self.prepareReason=reason
 self.preparationFaults=math.min(9999,(self.preparationFaults or 0)+1);self.complete=false
 local index=plan.index
 if type(index)=="number" and index>=1 and index<=#ordinary+#special and index%1==0 then
  local _,id=familyDefinition(index);local row=self.families[id]
  if row then self:Failure(row,reason,"PREPARE");row.blocked=true end
 end
 self:CancelWork();self.dirty=false
 -- The native main visibility gate can have changed before a throwing setter
 -- returns. Return all current action input ancestry through the established
 -- inverse, rather than guessing which alternative is still visible.
 local called,released=pcall(A.Suspend,A,reason);self.writing=nil
 if self.preparationFaultReceipt==receipt then
  self.preparationHandback=called and released==true and "NATIVE_RESTORED" or "RESTORE_PENDING"
  self.complete=false;A.familyPreparing=nil;A.pendingWork=true
  if not called or released~=true then A.pendingDisable=reason end
 end
 return false
end
function F:QueuePreparation(plan)
 if not self:PreparationIdentity(plan) or plan.queued then return false end
 local queue=M.RuntimeScheduler
 if not queue then return false end
 local accepted=queue:Request(prepareKey,function()
  plan.queued=nil
  if not self:PreparationIdentity(plan) then return end
  local okay=pcall(self.PrepareFamily,self,plan)
  if not okay then self:FailPreparation(plan,"ACTION_FAMILY_PREPARATION_EXCEPTION") end
 end,{combat="defer",priority=3,owner="ActionBars",guard=function() return self:PreparationIdentity(plan) end})
 plan.queued=accepted==true or nil
 if not accepted then self.prepareReason="ACTION_FAMILY_QUEUE_PENDING";A.pendingWork=true end
 return accepted
end
function F:PrepareFamily(plan)
 if not self:PreparationCurrent(plan) or S:InCombat() then return end
 local editing=R:NativeEditState()
 if editing~="CLOSED" then self.prepareReason=editing=="OPEN" and "NATIVE_EDIT_HANDOFF" or "NATIVE_EDIT_UNKNOWN";return end
 local definition,id,isOrdinary=familyDefinition(plan.index)
 local row=self.families[id]
 if not row then
  local called,created,why=pcall(isOrdinary and self.CreateOrdinary or self.CreateSpecial,self,definition)
  row=called and created or self.families[id]
  if not called or not created then
   if row then
    self:Failure(row,called and why or "FAMILY_SETUP_EXCEPTION","PREPARE")
    row.blocked=true;row.status=called and why or "FAMILY_SETUP_EXCEPTION"
    local okay,released=pcall(self.Release,self,row,true);row.pending=not okay or not released or nil
   end
   plan.complete=false;self.complete=false;row=nil
  end
 end
 if not self:PreparationCurrent(plan) then return end
 if row then
  if isOrdinary then row.layoutDirty=true end
  plan.complete=self:RunFamily(row,isOrdinary and self.Ordinary or self.Special) and plan.complete
 end
 if not self:PreparationCurrent(plan) then return end
 -- Override acquisition changes the native main-bar visibility alternative.
 -- Update that secure gate in the same legal transaction, not on a later tick.
 if not isOrdinary and definition[1]=="OverrideActionBar" and A.lease then
  local okay,ready,reason=pcall(A.RefreshNativeDriver,A)
  if not okay or not ready then self:FailPreparation(plan,reason or "NATIVE_ACTION_GATE_REGISTRATION_FAILED");return end
 end
 self.preparedFamilies=plan.index;plan.index=plan.index+1
 if M.ActionInterface then M.ActionInterface.badgeDirty=true end
 A.pendingWork=true
 if plan.index>#ordinary+#special then
  self.preparing=nil;self.preparation=nil;self.complete=plan.complete and self.complete~=false
  self.prepareReason=self.complete and "ACTION_FAMILIES_READY" or "ACTION_FAMILIES_PARTIAL"
  self.prepareCompletedAt=S:Now()
 else self.prepareReason="ACTION_FAMILIES_PREPARING";self:QueuePreparation(plan) end
end
function F:Configure(profile)
 if S:InCombat() then self.dirty=true;return false,"COMBAT_LOCKDOWN" end
 local editing=R:NativeEditState()
 if not R:Selected("main",profile) or editing=="OPEN" or M.state.safe then return self:Suspend("INACTIVE") end
 if editing=="UNKNOWN" then self.dirty=true;return false,"NATIVE_EDIT_UNKNOWN" end
 if not self.hidden then
  self.hidden=CreateFrame("Frame","MirageM2ActionNativeHolder",UIParent);self.hidden:SetAllPoints(UIParent);self.hidden:Hide()
  A.tooltip=CreateFrame("GameTooltip","MirageM2ActionTooltip",UIParent,"GameTooltipTemplate")
  local tip=A.tooltip
  local bg=ownRegion(tip,"BACKGROUND");bg:SetAllPoints();color(bg,theme.background)
  for _,side in ipairs({"TOP","BOTTOM","LEFT","RIGHT"}) do
   local t=ownRegion(tip,"BORDER");color(t,theme.accent,.8)
   if side=="TOP" or side=="BOTTOM" then t:SetPoint(side.."LEFT",tip,side.."LEFT",0,0);t:SetPoint(side.."RIGHT",tip,side.."RIGHT",0,0);t:SetHeight(1)
   else t:SetPoint("TOP"..side,tip,"TOP"..side,0,0);t:SetPoint("BOTTOM"..side,tip,"BOTTOM"..side,0,0);t:SetWidth(1) end
  end
  tip:HookScript("OnShow",function()
   local nine=field(tip,"NineSlice");if nine then nine:SetAlpha(0) end
  end)
 end
 self:CancelWork()
 self.preparationFault=nil;self.preparationFaultReceipt=nil;self.preparationHandback=nil;self.nativeGateFault=nil
 self.active=true;self.complete=true;self:PreparePressHooks()
 if M.RuntimeScheduler then
  local plan={profile=profile or M.profile,generation=M.state.settingsGeneration or 0,revision=self.workRevision,index=1,complete=true}
  self.preparation=plan;self.preparing=true;self.preparedFamilies=0;self.prepareReason="ACTION_FAMILIES_PREPARING";self.prepareStartedAt=S:Now()
  self.dirty=false;self:QueuePreparation(plan)
  return true,"ACTION_FAMILIES_PREPARING"
 end
 for _,d in ipairs(ordinary) do
  local id="ActionBars.bar"..d[1];local row=self.families[id]
  if not row then row=self:CreateOrdinary(d) end
  if row then row.layoutDirty=true end
  self.complete=row~=nil and self:RunFamily(row,self.Ordinary) and self.complete
 end
 for _,d in ipairs(special) do
  local id="NativeControls."..d[1];local row=self.families[id]
  if not row then row=self:CreateSpecial(d) end
  self.complete=row~=nil and self:RunFamily(row,self.Special) and self.complete
 end
 self.dirty=false
 if A.lease then
  local ready,reason=A:RefreshNativeDriver()
  if not ready then return false,reason end
 end
 for _,row in pairs(self.families) do if row.pending then return false,"FAMILY_RESTORE_PENDING" end end
 return true
end
local specialEvents={
 PET_BAR_UPDATE="PetActionBar",
 UPDATE_MULTI_CAST_ACTIONBAR="MultiCastActionBarFrame",PLAYER_TOTEM_UPDATE="MultiCastActionBarFrame",
 UPDATE_SHAPESHIFT_FORMS="StanceBar",UPDATE_SHAPESHIFT_FORM="StanceBar",
 UPDATE_POSSESS_BAR="PossessActionBar",UPDATE_OVERRIDE_ACTIONBAR="OverrideActionBar",
 UPDATE_VEHICLE_ACTIONBAR="OverrideActionBar",UPDATE_EXTRA_ACTIONBAR="ExtraAbilityContainer",
}
function F:OnEvent(event,...)
 self.pendingWork=true
 for _,row in pairs(self.families) do
  if row.ordinary then
   row:InvalidateEvent(event,...)
   if (event=="ADDON_LOADED" or event=="PLAYER_ENTERING_WORLD") and (not row.active or row.native~=_G[row.name]) then row.nativeDirty=true end
  else
   local structural=specialEvents[event]==row.name or event=="UNIT_ENTERED_VEHICLE" or event=="UNIT_EXITED_VEHICLE"
   if structural or event=="EDIT_MODE_LAYOUTS_UPDATED" then row.dirty=true end
   if structural or event=="UPDATE_BINDINGS" or event=="SPELLS_CHANGED" then row.presentationDirty=true end
   if row.name=="PetActionBar" and (event=="PET_BAR_SHOWGRID" or event=="PET_BAR_HIDEGRID") then row.presentationDirty=true end
   if event=="ADDON_LOADED" or event=="PLAYER_ENTERING_WORLD" then
    if not row.active or row.native~=_G[row.name] then row.dirty=true else row.presentationDirty=true end
   end
  end
 end
end
function F:TickFamily(row,now)
  local overrideActive=row.name=="OverrideActionBar" and row.active==true
  local priorStatus,priorActive,priorPending=row.status,row.active,row.pending
  local priorDirty=row.dirty or row.nativeDirty
  if row.ordinary then
   if row.active then
    if not S:InCombat() then
     row:RefreshGrid()
     local reveal=call(row.frame,"GetAttribute","mui-flyout-reveal")
     local shown=SpellFlyout and call(SpellFlyout,"IsShown")
     row.flyoutReveal=reveal and shown or nil
     if reveal and not shown then row.frame:SetAttribute("mui-flyout-reveal",nil) end
     local driver=row:VisibilityDriver(M.profile)
     if driver~=row.visibleDriver and not row:SetVisibilityDriver(driver) then
      self:Failure(row,"VISIBILITY_DRIVER_UNAVAILABLE","TICK");self:Release(row);row.status="VISIBILITY_DRIVER_UNAVAILABLE"
     end
     -- Parent repair is independent of content/cooldown refresh. Hold and
     -- flyout routing update secure metadata without a geometry transaction.
     if row.nativeDirty or row.layoutDirty then self:RunFamily(row,self.Ordinary)
     else
      if row.holdDirty then row:RefreshHold() end
      if row.bindingsDirty then
       local ok,why=row:RefreshBindings()
       if not ok then self:Failure(row,why,"BINDINGS");self:Release(row);row.status=why;row.blocked=true;self.complete=false end
      end
     end
    end
    if row.active then row:RefreshVisual(now) end
   elseif not row.blocked and not S:InCombat() and row.nativeDirty then self:RunFamily(row,self.Ordinary) end
  else
   if row.active then
    local visible=call(row.native,"IsVisible")~=false and call(row.native,"GetAlpha")~=0
    if visible then
     for _,b in ipairs(row.controls) do paintState(self.skins[b]) end
     if row.presentationDirty then
      local presentation=true
      for _,b in ipairs(row.controls) do presentation=paintSkin(self.skins[b]) and presentation end
      presentation=paintNativeArt(row) and presentation
      row.presentationDirty=nil
      if not presentation then row.visualConflict=true;self.complete=false end
     end
    end
    if not S:InCombat() then
     if row.visualConflict then
      self:Failure(row,"CONFLICT_NATIVE_PRESENTATION","TICK")
      self:Release(row);row.blocked=true;row.status="CONFLICT_NATIVE_PRESENTATION";row.visualConflict=nil
     end
    end
   end
   if row.dirty and not row.blocked and not S:InCombat() then
    if row.nativeManaged then
     -- Registered encounter/zone content churn is not competing geometry.
     -- Hooks coalesce to this one bounded pass; no reset budget is consumed.
     self:RunFamily(row,self.Special)
    else
     -- Native method availability can change after acquisition. This is a
     -- read-only preflight, outside RunFamily's transaction guard; an
     -- unavailable observation is never evidence of layout contention.
     -- RunFamily still rechecks geometry and retains restoration debt if
     -- the native method remains unavailable during its guarded attempt.
     local observed,drift=pcall(familyGeometryDrift,row)
     drift=observed and drift==true
     if drift then
      if now-(row.resetWindow or 0)>10 then row.resets=0;row.resetWindow=now end
      row.resets=(row.resets or 0)+1
     end
     if drift and row.resets>8 then self:Failure(row,"NATIVE_LAYOUT_CONTENTION","LAYOUT");self:Release(row);row.status="NATIVE_LAYOUT_CONTENTION";row.blocked=true
     else self:RunFamily(row,self.Special) end
    end
    row.dirty=nil
   end
  end
  -- A late native override family can become ready (or return to fallback)
  -- after startup. Publish its native alternative in the same legal family
  -- pass, including the receipt used by subsequent main-parent renewal.
  if row.name=="OverrideActionBar" and overrideActive~=(row.active==true) and not S:InCombat() then
   local ready,reason=A:RefreshNativeDriver()
   if not ready then self.complete=false;self.nativeGateFault=reason or "NATIVE_ACTION_GATE_REGISTRATION_FAILED" end
  end
  if row.status~=priorStatus or row.active~=priorActive or row.pending~=priorPending
   or priorDirty and not row.dirty and not row.nativeDirty then self:ReconcileCompletion() end
end
function F:QueueFamilyTick(row,index,now)
 local queue=M.RuntimeScheduler
 if not queue then return self:TickFamily(row,now) end
 local profile,revision,generation=M.profile,self.workRevision,M.state.settingsGeneration or 0
 local retained=row.runtimeTask
 if retained and retained.profile==profile and retained.revision==revision and retained.generation==generation then
  return queue:Request("Rework.main.family."..index,retained.callback,retained.options)
 end
 local function current()
  return self.active and A.active and self.families[row.id]==row and self.workRevision==revision
   and M.profile==profile and (M.state.settingsGeneration or 0)==generation and not M.state.safe and R:Selected("main",profile)
 end
 local function callback(clock)
  if not current() or R:NativeEditState()~="CLOSED" then return end
  local complete,status,pending=self.complete,row.status,row.pending
  local okay=pcall(self.TickFamily,self,row,clock)
  if not okay and current() then
   self:Failure(row,"FAMILY_TICK_EXCEPTION","TICK")
   local releasedOK,released=pcall(self.Release,self,row)
   row.blocked=true;row.pending=not releasedOK or not released or nil;row.status="FAMILY_TICK_EXCEPTION";self.complete=false
  end
  if current() and (self.complete~=complete or row.status~=status or row.pending~=pending) then A.pendingWork=true end
 end
 local options={combat="allow",priority=4,owner="ActionBars",guard=current}
 row.runtimeTask={profile=profile,revision=revision,generation=generation,callback=callback,options=options}
 return queue:Request("Rework.main.family."..index,callback,options)
end
function F:Tick(now)
 if not self.active then return end
 if self.nativeGateFault then return false,self.nativeGateFault end
 local editing=R:NativeEditState()
 if not R:Selected("main") or editing=="OPEN" or M.state.safe then self:Suspend("INACTIVE");return end
 if editing=="UNKNOWN" then return false,"NATIVE_EDIT_UNKNOWN" end
 now=S:Number(now) and now or S:Now()
 if now-(self.last or 0)<.2 and not self.dirty and not self.pendingWork then return end
 self.last=now;self.pendingWork=nil
 if not self:ContextHealth() then self.complete=false
 elseif self.completionDirty then self:ReconcileCompletion() end
 self.completionDirty=nil
 if self.preparation then
  local plan=self.preparation
  if not self:PreparationIdentity(plan) then
   self:CancelWork();self.dirty=true;self.preparing=true;self.prepareReason="ACTION_FAMILIES_PREPARING";A.pendingWork=true
  elseif not S:InCombat() then self:QueuePreparation(plan) end
 end
 if not S:InCombat() and self.dirty then self:Configure(M.profile) end
 for index=1,#ordinary+#special do
  local _,id=familyDefinition(index);local row=self.families[id]
  if row then self:QueueFamilyTick(row,index,now) end
 end
 self:Flyout()
 if self.nativeGateFault then return false,self.nativeGateFault end
 if self.flyoutPending then return false,"FAMILY_RESTORE_PENDING" end
 for _,row in pairs(self.families) do if row.pending then return false,"FAMILY_RESTORE_PENDING" end end
 return true
end
function F:Suspend(reason)
 self:CancelWork()
 self.complete=false;self.prepareReason=reason or "ACTION_FAMILIES_SUSPENDED"
 A.familyPreparing=nil;A.familyHealthPending=nil
 local done=true
 for _,row in pairs(self.families) do
  local ok,released=pcall(self.Release,self,row);if not ok or not released then done=false end
 end
 if not S:InCombat() then
  for _,skin in pairs(self.skins) do if skin.owner=="ACTION_FLYOUT" then done=restoreSkin(skin) and done end end
  done=restoreProperties("ACTION_FLYOUT") and done
  if done then self.flyoutPending=nil end
  if A.tooltip then A.tooltip:Hide() end
 end
 self.active=false;self.status=done and (reason or "SUSPENDED") or "FAMILY_RESTORE_PENDING"
 self.flyoutVisible=nil;self.flyoutOwned=nil;self.flyoutDirty=true
 return done,done and "COMPLETE" or S:InCombat() and "COMBAT_LOCKDOWN" or "FAMILY_RESTORE_PENDING"
end
function F:Retry()
 if S:InCombat() then return false,"COMBAT_LOCKDOWN" end
 if M.ContextualNative then M.ContextualNative:RetryOwned(self) end
 local drained=true
 for _,row in pairs(self.families) do
  local context=M.ContextualNative and M.ContextualNative.rows[row.name]
  if row.pending or context and context.ownedOwner==self and (context.pending or context.ownerHandback) then
   local ok,released=pcall(self.Release,self,row)
   if not ok or not released then drained=false end
  end
 end
 if not drained then return false,"FAMILY_RESTORE_PENDING" end
 for _,row in pairs(self.families) do
  if row.controlsReady~=true then
   row.blocked=true;row.status="RELOAD_REQUIRED_CONTROLS_INCOMPLETE"
   return false,row.status
  end
 end
 for _,row in pairs(self.families) do
  local foreign=row.external and row.homeParent and row.native and call(row.native,"GetParent")~=row.homeParent
 if not foreign then row.blocked=nil;row.resets=0;row.resetWindow=S:Now();row.external=nil end
 end
 self.preparationFault=nil;self.preparationFaultReceipt=nil;self.preparationHandback=nil;self.nativeGateFault=nil
 self.dirty=true;return true
end
function F:Flyout()
 local flyout=_G.SpellFlyout
 if not S:Frame(flyout,false) then return end
 if self.flyoutHookFrame~=flyout and not S:InCombat() and type(hooksecurefunc)=="function" then
  for _,method in ipairs({"OnShow","UpdateLayout"}) do
   if type(field(flyout,method))=="function" then
    hooksecurefunc(flyout,method,function() if F.active and F.flyoutHookFrame==flyout then F.flyoutDirty=true;F.pendingWork=true end end)
   end
  end
  self.flyoutHookFrame=flyout
 end
 if call(flyout,"IsShown")~=true then self.flyoutVisible=nil;return end
 local parent=call(flyout,"GetParent");local ours=false
 for _,button in ipairs(A.buttons) do if parent==button then ours=true;break end end
 if not ours then for _,row in pairs(self.families) do
  if row.ordinary and row.active then for _,button in ipairs(row.buttons) do if parent==button then ours=true;break end end end
 end end
 if not ours then
  if not self.flyoutOwned and not self.flyoutPending then return end
  local done=true
  for _,skin in pairs(self.skins) do if skin.owner=="ACTION_FLYOUT" and (skin.active or skin.pending) then done=restoreSkin(skin) and done end end
  done=restoreProperties("ACTION_FLYOUT") and done
  self.flyoutPending=not done or nil;self.flyoutStatus=done and "NATIVE_FLYOUT_HANDOFF" or "FLYOUT_RESTORE_PENDING"
  self.flyoutOwned=nil;self.flyoutVisible=nil
  return
 end
 if self.flyoutVisible and self.flyoutParent==parent and not self.flyoutDirty then
  for _,skin in ipairs(self.flyoutSkins or {}) do paintState(skin) end
  return
 end
 local list=field(flyout,"buttons")
 if type(list)~="table" or not S:Readable(list) then self.flyoutStatus="FLYOUT_BUTTONS_UNAVAILABLE";return end
 local skins={}
 for i=1,40 do
  local button,state=S:FieldAccess(list,i)
  if state=="ABSENT" then break end
  if state~="KNOWN" or not S:Frame(button,false) then self.flyoutStatus="FLYOUT_BUTTON_UNAVAILABLE";return end
  local skin=buttonSkin(button,"ACTION_FLYOUT")
  if not skin or not paintSkin(skin) then self.flyoutStatus="FLYOUT_STYLE_PENDING";return end
  skins[#skins+1]=skin
 end
 local overflow,state=S:FieldAccess(list,41)
 if state~="ABSENT" then self.flyoutStatus="FLYOUT_POOL_LIMIT";return end
 local background=field(flyout,"Background")
 for _,key in ipairs({"End","Start","HorizontalMiddle","VerticalMiddle"}) do regionAlpha(field(background,key),0,"ACTION_FLYOUT") end
 self.flyoutSkins=skins;self.flyoutVisible=true;self.flyoutOwned=true;self.flyoutParent=parent;self.flyoutDirty=nil
 self.flyoutStatus="CUSTOM_NATIVE_FLYOUT"
end
function F:Bounds(id)
 local row=self.families[id];if not row then return nil,"NOT_CREATED" end
 local f=row.ordinary and row.frame or row.native
 if not f then return nil,"NATIVE_FAMILY_UNAVAILABLE" end
 return {frame=f,layoutID=id,provider="M2_ACTION_FAMILIES",width=call(f,"GetWidth"),height=call(f,"GetHeight"),scale=call(f,"GetScale"),active=row.active==true}
end
function F:Status()
 local lines={};local waiting=0
 local function evidence(row)
  if not row or not row.firstFailure then return "" end
  return ":first="..row.firstFailure..":last="..(row.lastFailure or row.firstFailure)..":phase="..(row.failurePhase or "CONFIGURE")
   ..":failures="..(row.failureCount or 0)..(row.lastPropertyFailure and ":property="..row.lastPropertyFailure or "")
   ..(row.lastGeometryFailure and ":geometry="..row.lastGeometryFailure or "")
 end
 for _,skin in pairs(self.skins) do if skin.active then waiting=waiting+(skin.fontWaiting or 0) end end
 for _,d in ipairs(ordinary) do local row=self.families["ActionBars.bar"..d[1]];lines[#lines+1]="bar"..d[1].."="..(row and row.status or "NOT_CREATED")..evidence(row)..(row and ":"..row:GridStatus() or "") end
 for _,d in ipairs(special) do
  local row=self.families["NativeControls."..d[1]]
  local context=M.ContextualNative and M.ContextualNative.status[d[1]] or row and row.contextStatus
  lines[#lines+1]=d[1].."="..(row and row.status or "NOT_CREATED")..evidence(row)..(context and ":context="..context or "")..(row and row.zoneStatus and ":"..row.zoneStatus or "")..(row and row.layoutAuthority and ":layout="..row.layoutAuthority or "")
 end
 lines[#lines+1]="font_waiting="..waiting
 lines[#lines+1]="preparation="..(self.preparing and "WAITING" or self.prepareReason or "SYNCHRONOUS_COMPLETE")
 lines[#lines+1]="prepared_families="..(self.preparedFamilies or (#ordinary+#special))
 lines[#lines+1]="family_schedule="..(M.RuntimeScheduler and "KEYED_PER_FAMILY" or "SYNCHRONOUS_NO_SCHEDULER")
 lines[#lines+1]="preparation_fault="..(self.preparationFault or "NONE")..":count="..(self.preparationFaults or 0)..":handback="..(self.preparationHandback or "NOT_NEEDED")
 return table.concat(lines,";")
end
local configure,tick,event,suspend,bounds,status=A.Configure,A.Tick,A.OnEvent,A.Suspend,A.Bounds,A.Status
local pageDriver,visibilityDriver=A.PageDriver,A.VisibilityDriver
local function pageIndex(api,fallback)
 local value,state=S:Public(api,"number")
 if state=="KNOWN" and value>=1 and value<=15 and value%1==0 then return value end
 return fallback -- exact pinned action-controller indices, never guessed slots
end
function A:PageDriver()
 local driver=pageDriver(self)
 driver=driver:gsub("%[possessbar%] 0;", "[possessbar] "..pageIndex(GetVehicleBarIndex or (C_ActionBar and C_ActionBar.GetVehicleBarIndex),12)..";")
 driver=driver:gsub("%[shapeshift%] 0;", "[shapeshift] "..pageIndex(GetTempShapeshiftBarIndex or (C_ActionBar and C_ActionBar.GetTempShapeshiftBarIndex),13)..";")
 return driver
end
function A:VisibilityDriver(profile)
 local driver=visibilityDriver(self,profile)
 -- Temporary forms/possessions use the custom main controls on their real page.
 -- They are required input even out of combat: an ordinary idle-hide outcome
 -- must not hide those actions. Vehicle/override/pet-battle controllers retain
 -- their earlier secure hide clauses, and secondary ordinary families stay hidden.
 if self==A then
  driver=driver:gsub("%[possessbar%] hide; ","[possessbar] show; "):gsub("%[shapeshift%] hide; ","[shapeshift] show; ")
  driver="[petbattle] hide; "..driver:gsub("%[petbattle%] hide; ","")
 end
 return driver
end
function A:NativeGateDriver()
 local override=F.families["NativeControls.OverrideActionBar"]
 return override and override.active and "[petbattle] show; hide" or "[vehicleui] show; [overridebar] show; [petbattle] show; hide"
end
function A:Retry()
 if self.frame and not self.ready then
  self.status="RELOAD_REQUIRED_CONTROLS_INCOMPLETE";return false,self.status
 end
 self:InvalidateKeys()
 local ok,why=F:Retry();if not ok then return false,why end
 if M.DelegatedNative and M.DelegatedNative.Retry then
  -- Bags/menu have their own native input, context gates and artwork leases.
  -- An incomplete utility skin must remain PARTIAL, but cannot prevent the
  -- already-released main/secondary combat controls from being reacquired.
  -- Configure/Tick below still consult the utility owner's actual health.
  local called,ready,reason=pcall(M.DelegatedNative.Retry,M.DelegatedNative)
  self.utilityRetryStatus=called and ready==true and "READY" or not called and "UTILITY_RETRY_EXCEPTION"
   or S:Text(reason) and #reason<=96 and reason:match("^[A-Z][A-Z0-9_]*$") and reason or "NATIVE_UTILITIES_PENDING"
 end
 if self.contested and call(MainActionBar,"GetParent")~=self.homeParent then return false,"CONFLICT_NATIVE_PARENT" end
 self.contested=nil;return true
end
function A:Configure(profile)
 local ok,why=configure(self,profile);if not ok then return ok,why end
 self.familyHealthPending=nil
 local family,reason=F:Configure(profile or M.profile)
 if not family then
  if reason=="NATIVE_EDIT_UNKNOWN" then self.pendingConfigure=true;return false,reason end
  self:Suspend(reason);self.status=reason;return false,reason
 end
 if F.preparing then
  self.familyPreparing=true
  if F.complete==false then return R:Result("PARTIAL","ACTION_FAMILIES_PARTIAL") end
  return R:Result("WAITING",F.prepareReason or "ACTION_FAMILIES_PREPARING")
 end
 if not F.complete then self.familyHealthPending=true;return R:Result("PARTIAL","ACTION_FAMILIES_PARTIAL") end
 if M.DelegatedNative and not M.DelegatedNative:ContextHealth() then
  self.utilityHealthPending=true;return R:Result("PARTIAL","NATIVE_UTILITIES_PARTIAL")
 end
 self.utilityHealthPending=nil
 return true
end
function A:Tick(now)
 self.pendingWork=nil
 local main,reason=tick(self,now)
 if main==false and reason=="NATIVE_EDIT_UNKNOWN" then
  self.pendingWork=true;return R:Result("DEFERRED_HANDOFF",reason)
 end
 if main==false then return main,reason end
 if F.preparationFault then return R:Result("PARTIAL",F.preparationFault) end
 if self.active then
  local ok,why=F:Tick(now)
  if ok==false and why=="NATIVE_EDIT_UNKNOWN" then
   self.pendingWork=true;return R:Result("DEFERRED_HANDOFF",why)
  end
  if ok==false then self.active=false;self.pendingDisable=why;self.status=why;return false,why end
  if F.preparing then
   self.familyPreparing=true
   if F.complete==false then return R:Result("PARTIAL","ACTION_FAMILIES_PARTIAL") end
   return R:Result("WAITING",F.prepareReason or "ACTION_FAMILIES_PREPARING")
  end
  if ok~=false and not F.complete then self.familyHealthPending=true;return R:Result("PARTIAL","ACTION_FAMILIES_PARTIAL") end
  if ok~=false and M.DelegatedNative and not M.DelegatedNative:ContextHealth() then
   self.utilityHealthPending=true;return R:Result("PARTIAL","NATIVE_UTILITIES_PARTIAL")
  end
  -- A bounded native layout wait can finish between provider ticks. Publish
  -- that one actual recovery so a nil main tick does not retain obsolete
  -- NATIVE_UTILITIES_PARTIAL health. Explicit main outcomes keep precedence.
  if (self.familyPreparing or self.familyHealthPending) and (main==nil or main==true) then
   self.familyPreparing=nil;self.familyHealthPending=nil
   if main==nil then return true,"CUSTOM_RUNTIME_READY" end
  end
  if self.utilityHealthPending and M.DelegatedNative and (main==nil or main==true) then
   self.utilityHealthPending=nil
   if main==nil then return true,"CUSTOM_RUNTIME_READY" end
  end
 end
 -- An initial deferred Configure runs through the main Tick. Its explicit
 -- waiting, failure or success result must reach the lifecycle registry.
 return main,reason
end
function A:OnEvent(name,...) event(self,name,...);F:OnEvent(name,...) end
function A:Suspend(why)
 local families,reason=F:Suspend(why);local main,mainWhy=suspend(self,why)
 if main then for _,b in ipairs(self.buttons) do if b.keyPress then b.keyPress:Hide();b.pressUntil=nil end end end
 if not families then return false,reason end
 return main,mainWhy
end
function A:Bounds(id) if id and id~=self.layoutID then return F:Bounds(id) end;return bounds(self) end
function A:SupportsLayout(id) return F.layouts[id]==true end
function A:NativeOwners() return F.nativeOwners end
function A:Status() return status(self):gsub("special_states=NATIVE_DELEGATED","special_states=M2_CUSTOM_PRESENTATION")..";"..F:Status()..";families_complete="..tostring(F.complete==true)..";utility_retry="..(self.utilityRetryStatus or "NOT_RUN")..";flyout="..(F.flyoutStatus or "NOT_OPENED")..";native_special=FUNCTIONAL_BACKING_CUSTOM_PRESENTATION" end
