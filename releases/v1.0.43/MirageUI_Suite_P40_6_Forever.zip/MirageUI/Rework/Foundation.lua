-- M0 provider lifecycle. Native validation is evidence, never a runtime boolean.
local _,M=...
local R={version=3,milestone="M06",providers={},order={},native="NOT_RUN",serial=0,pendingProviders={}}
M.Rework=R
local S=M.Safety
local modules={main="ActionBars",units="UnitFrames",groups="PartyRaid",minimap="Minimap",nameplates="Nameplates",auras="Auras",cooldowns="Cooldowns",meters="DamageMeters",casts="UnderCharacterHUD",alerts="Notifications",
 chat="Chat",tooltips="Tooltips",maps="BlizzardSkin",objectives="QuestTracker",inventory="Bags",tasks="BlizzardSkin",character="BlizzardSkin",system="BlizzardSkin"}
local nativeOwners={MainActionBar="main",PlayerFrame="units",TargetFrame="units",MinimapCluster="minimap",Minimap="minimap"}
local layoutOwners={["ActionBars.bar1"]="main",["UnitFrames.player"]="units",["UnitFrames.target"]="units",["Minimap.nativePosition"]="minimap"}
R.nativeOwners=nativeOwners;R.layoutOwners=layoutOwners
-- Providers no longer receive an unconditional 10 Hz heartbeat.  These are
-- maximum idle intervals for providers that genuinely need liveness checks;
-- events and explicit dirty work wake a provider immediately.
local tickIntervals={main=.20,units=1.00,groups=1.00,minimap=.25,nameplates=.25,auras=.50,cooldowns=.50,meters=.50,
 casts=.25,alerts=.50,chat=.50,tooltips=0,maps=.50,objectives=.25,inventory=.50,tasks=.50,character=.75,system=.75}
R.tickIntervals=tickIntervals
local tickFlags={"dirty","pendingWork","pendingConfigure","pendingDisable","nativeDirty","nativeDiscoveryDirty","discoveryDirty",
 "topologyDirty","limitPending","nativeGeometryDirty","layoutDirty","contentDirty","combatPending","scrollPending","suspendPending",
 "recoverPending","releasePending","pendingParts","gridDirty","bindingsDirty","holdDirty","visualDirtyAll","geometryDirty"}
local function tableHas(t) return type(t)=="table" and next(t)~=nil end
local function viewportReady()
 if M.Layout and type(M.Layout.Screen)=="function" then
  local w,h=M.Layout:Screen();return w~=nil and h~=nil
 end
 if M.Managed and type(M.Managed.Viewport)=="function" then
  local w,h=M.Managed:Viewport();return w~=nil and h~=nil
 end
 return true -- legacy clients/fixtures without the shared viewport observer
end
function R:NeedsProviderTick(row,clock,combat)
 if not row or row.state~="ACTIVE" or not row.started or not row.object.Tick then return false end
 -- An absent first coordinate space cannot be repaired by calling the same
 -- Configure hundreds of times. Publication queues the specific setup or
 -- continuation below; no unrelated provider's demand is suppressed.
 if row.readinessReason=="VIEWPORT_PENDING" and not viewportReady() then return false end
 if row.viewportResumePending then
  if combat==nil then combat=S:InCombat() end
  return not combat and viewportReady()
 end
 local o=row.object
 -- A provider can distinguish actionable work from retained/blocked debt.
 -- true/false is authoritative, including its own necessary liveness deadline;
 -- nil or an unavailable probe preserves the legacy dirty/deadline contract.
 -- Probes inspect owned state only: they do not paint, scan native trees, or
 -- consume the work. Events still reach OnEvent before this decision is made.
 if type(o.NeedsRuntimeTick)=="function" then
  if combat==nil then combat=S:InCombat() end
  local ok,needed=pcall(o.NeedsRuntimeTick,o,clock,combat)
  row.demandProbeFailed=not ok or nil
  if ok and type(needed)=="boolean" then return needed end
 end
 for _,key in ipairs(tickFlags) do
  local pending=o[key]
  -- Dirty sets remain allocated after their last entry is consumed. An empty
  -- table is truthy in Lua, but does not represent pending provider work.
  if type(pending)=="table" then
   if next(pending)~=nil then return true end
  elseif pending then return true end
 end
 if tableHas(o.queue) or tableHas(o.slotDirty) or tableHas(o.visualDirty) or tableHas(o.nativeDirty) then return true end
 if row.pending or row.configurePending then return true end
 local interval=tickIntervals[row.id] or .50
 if interval<=0 then return false end
 return clock>=(row.nextRuntimeTick or 0)
end
local statuses={STANDBY=true,PREPARING=true,ACTIVE=true,DEFERRED=true,RECOVERY=true,STOPPED=true,NATIVE_EDIT=true,UNSUPPORTED=true}
local function reason(v)
 return S:Text(v) and #v<96 and v:match("^[A-Z][A-Z0-9_]*$") and v or "PROVIDER_UNAVAILABLE"
end
-- A native setter can synchronously emit an event, stop the current owner or
-- publish new settings. The old callback's return value is no longer evidence
-- about that successor. Cleanup deliberately survives a profile change, but
-- never a different provider object or a newer lifecycle of the same row.
local function providerDispatch(registry,row,method,cleanup)
 local rows,object=registry.providers,row.object
 local callback=object[method]
 local lifetime=row.lifecycleRevision or 0
 local state,profile=M.state,M.profile
 local generation=state.settingsGeneration or 0
 local safe,world=state.safe,state.world
 return function()
  return M.Rework==registry and registry.providers==rows and rows[row.id]==row
   and row.object==object and object[method]==callback and (row.lifecycleRevision or 0)==lifetime
   and (cleanup or M.state==state and M.profile==profile and (state.settingsGeneration or 0)==generation
    and state.safe==safe and state.world==world)
 end,callback,object
end
function R:DiscardProviderCallback()
 self.supersededCallbacks=math.min(999999,(self.supersededCallbacks or 0)+1)
end
function R:HealthObserverFailed(stage)
 self.healthObserverFailures=math.min(999999,(self.healthObserverFailures or 0)+1)
 self.lastHealthObserver=stage
end
function R:TargetMatched()
 local c=M.Client
 local runtime=c and (c.RuntimeAvailable or c.IsReviewedPresentationClient)
 return self==R and c and type(runtime)=="function" and runtime(c) and S:BoundaryReady() or false
end
function R:ObserveTarget()
 -- Reporting and retained cleanup need a read-only distinction between a
 -- known source mismatch and an unavailable observation. This grants no
 -- acquisition and does not clear a recorded lifecycle failure.
 local ok,value=pcall(self.TargetMatched,self)
 if ok and type(value)=="boolean" then return value,"KNOWN" end
 return nil,"UNKNOWN"
end
function R:Qualified() return self:TargetMatched() and M.Client.allowed==true or false end
-- OPEN/CLOSED describe an observed editor edge. UNKNOWN denies new contested
-- writes but must never masquerade as an open/close transition.
function R:NativeEditState()
 if M.Elements and type(M.Elements.NativeEditorState)=="function" then
  local ok,state=pcall(M.Elements.NativeEditorState,M.Elements)
  if ok and (state=="OPEN" or state=="CLOSED" or state=="UNKNOWN") then
   self.editorObservationFailed=nil;return state
  end
  -- An unreadable/failed observation is not an editor-open edge. In
  -- particular it must not reach the old whole-provider restoration path.
  if not self.editorObservationFailed then
   self.editorObservationFailures=(self.editorObservationFailures or 0)+1
  end
  self.editorObservationFailed=true
  return "UNKNOWN"
 end
 local f=_G.EditModeManagerFrame
 if not S:Readable(f) then return "UNKNOWN" end
 if f==nil then return "CLOSED" end
 if not S:Frame(f,false) then return "UNKNOWN" end
 local shown,state=S:Public(f.IsShown,"boolean",f)
 if state~="KNOWN" then return "UNKNOWN" end
 return shown and "OPEN" or "CLOSED"
end
function R:NativeEditing() return self:NativeEditState()~="CLOSED" end
function R:RecordLifecycleFailure(phase,now)
 self.lastError="LIFECYCLE_FAILED"
 self.lifecycleAttempts=math.min(3,(self.lifecycleAttempts or 0)+1)
 self.lifecycleBlocked=self.lifecycleAttempts>=3 or nil
 self.lastLifecyclePhase=reason(phase or "SHARED_OBSERVATION")
 self.lastLifecycleAt=S:Number(now) and now or S:Now();self.nextTick=self.lastLifecycleAt+1
 if self.lifecycleAttempts==1 and M.Incidents then
  pcall(M.Incidents.Record,M.Incidents,"FAULT","Rework",self.lastLifecyclePhase,"LIFECYCLE_FAILED")
 end
end
local resultKinds={READY=true,EMPTY=true,WAITING=true,DEFERRED_COMBAT=true,DEFERRED_HANDOFF=true,PARTIAL=true,CONFLICT=true,FAULT=true}
local pendingReasons={COMBAT_LOCKDOWN="DEFERRED_COMBAT",COMBAT_PENDING="DEFERRED_COMBAT",SETUP_COMBAT_DEFERRED="DEFERRED_COMBAT",
 STYLE_COMBAT_DEFERRED="DEFERRED_COMBAT",WAITING_FOR_OUT_OF_COMBAT="DEFERRED_COMBAT",WAITING_FOR_NATIVE_CONTENT="WAITING",
 WAITING_FOR_OBJECTIVE_MODEL="WAITING",WAITING_FOR_CHAT_WINDOWS="WAITING",PRESENTATION_WORK_QUEUED="WAITING",CHAT_ROWS_PARTIAL="PARTIAL",PARTIAL_NATIVE_BACKED="PARTIAL",
 NATIVE_ROOT_UNAVAILABLE="WAITING",NOT_INITIALIZED="WAITING",ROOT_HANDOFF_PENDING="DEFERRED_HANDOFF",STYLE_RESTORE_PENDING="DEFERRED_HANDOFF",
 WINDOW_ROW_HANDOFF_PENDING="PARTIAL",TOOLTIP_PRESENTATION_PENDING="PARTIAL",MENU_PRESENTATION_PENDING="PARTIAL",
 MIRAGE_NATIVE_PRESENTATION_PARTIAL="PARTIAL",PARTIAL_NATIVE_FALLBACK="PARTIAL",BASELINE_RESTORE_PENDING="DEFERRED_HANDOFF",VIEWPORT_PENDING="WAITING",
 STYLE_DISPATCH_SUPERSEDED="DEFERRED_HANDOFF",NATIVE_EDIT_UNKNOWN="DEFERRED_HANDOFF"}
function R:Result(kind,why,surface)
 assert(resultKinds[kind],"Invalid provider result")
 return {kind=kind,reason=reason(why or kind),surface=S:Text(surface) and #surface<=96 and surface:match("^[%w_%.:%-]+$") and surface or nil}
end
function R:ResultKind(value,why,object)
 if type(value)=="table" and resultKinds[value.kind] then return value.kind,reason(value.reason or value.kind),value.surface end
 if value==false then
  local token=reason(why)
  return pendingReasons[token] or "FAULT",token
 end
 local token=reason(why or object and object.status or "CUSTOM_RUNTIME_READY")
 return pendingReasons[token] or "READY",token
end
function R:RecordSurface(owner,key,kind,why)
 if not resultKinds[kind] or not S:Text(key) or #key>96 or not key:match("^[%w_%.:%-]+$") then return false end
 owner.surfaceStates=owner.surfaceStates or {}
 local old=owner.surfaceStates[key];why=reason(why or kind)
 if old and old.kind==kind and old.reason==why and old.generation==(owner.generation or 0) then return true end
 if not old then local n=0;for _ in pairs(owner.surfaceStates) do n=n+1 end;if n>=512 then return false end end
 owner.surfaceStates[key]={kind=kind,reason=why,at=S:Now(),generation=owner.generation or 0,native="NOT_RUN"}
 return true
end
function R:Health(row,kind,why,surface,evidence)
 kind=resultKinds[kind] and kind or "FAULT";why=reason(why or kind)
 local object,lifetime,profile,state=row.object,row.lifecycleRevision or 0,M.profile,M.state
 local generation=state.settingsGeneration or 0
 -- Status observers must not turn a completed native presentation into a
 -- provider failure or leave Configure's transaction lock latched. Keep the
 -- production state authoritative and report observer faults separately.
 if M.StartupPresentation and M.StartupPresentation.ProviderState then
  local ok=pcall(M.StartupPresentation.ProviderState,M.StartupPresentation,row.id,kind,why)
  if not ok then self:HealthObserverFailed("STARTUP_PRESENTATION") end
 end
 if self.providers[row.id]~=row or row.object~=object or (row.lifecycleRevision or 0)~=lifetime
  or M.profile~=profile or M.state~=state or (state.settingsGeneration or 0)~=generation then return false end
 if row.readiness==kind and row.readinessReason==why and row.surface==surface then
  if evidence then self:RecordHealthIncident(row,kind,why,surface,evidence) end
  return
 end
 row.readiness=kind;row.readinessReason=why;row.surface=surface
 row.healthRevision=(row.healthRevision or 0)+1
 row.healthAt=S:Now()
 self:RecordHealthIncident(row,kind,why,surface,evidence)
end
function R:RecordHealthIncident(row,kind,why,surface,evidence)
 if M.Incidents and (kind=="FAULT" or kind=="CONFLICT") then
  local ok=pcall(M.Incidents.Record,M.Incidents,kind,row.id,"PROVIDER",why,surface,evidence)
  if not ok then self:HealthObserverFailed("INCIDENT_REPORT") end
 end
end
function R:RequestConfigure(id,why)
 if id then
  local row=self.providers[id];if not row then return false end
  local generation=M.state.settingsGeneration or 0
  if row.configureGeneration~=generation or why=="EXPLICIT_RETRY" or why=="NATIVE_EDIT_CLOSED" or why=="WORLD_ENTERED" then
   row.configureAttempts=0;row.configureBlocked=nil;row.configureGeneration=generation
  end
  if row.configureBlocked then return false end
  self.pendingProviders[id]=reason(why or "CONFIGURATION_CHANGED");row.configurePending=true
 else
  for _,providerID in ipairs(self.order) do self:RequestConfigure(providerID,why) end
 end
 return true
end
function R:DeferConfiguration(id,why)
 for _,providerID in ipairs(self.order) do if not id or id==providerID then
  local row=self.providers[providerID]
  row.configureAttempts=(row.configureAttempts or 0)+1
  self:Health(row,"DEFERRED_HANDOFF",why)
  if row.configureAttempts>=3 then
   row.configureBlocked=true;row.configurePending=nil;self.pendingProviders[providerID]=nil
  else self:RequestConfigure(providerID,why) end
 end end
end
function R:ResumeViewportPending(generation)
 -- Called after a stable sample is published. This is a queue notification,
 -- never a new profile transaction, native write, or recovery-budget reset.
 if not S:Number(generation) or generation<1 or generation%1~=0 or not viewportReady() then return false end
 local profile,settings=M.profile,M.state.settingsGeneration or 0
 if not profile or not profile.enabled or not M.state.world or M.state.safe or not self.storageReady or self.rolledBack or self.lifecycleBlocked then return true end
 local complete,queued=true,0
 for _,id in ipairs(self.order) do
  local row=self.providers[id]
  if row.started and row.state=="ACTIVE" and not row.pending and not row.failed and not row.configureBlocked
   and row.profile==profile and row.settingsGeneration==settings and self:Selected(id)
   and not (row.viewportWakeGeneration==generation and row.viewportWakeProfile==profile) then
   local object=row.object
   local waiting=row.readinessReason=="VIEWPORT_PENDING"
   local ok,resume=true,false
   if waiting and object.active~=true then
    resume=self:RequestConfigure(id,"VIEWPORT_READY")
   elseif object.active==true then
    if type(object.OnViewportReady)=="function" then
     ok,resume=pcall(object.OnViewportReady,object,generation)
    end
    if ok and (waiting or resume==true) then
     row.viewportResumePending=true;row.nextRuntimeTick=0;resume=true
    end
   end
   if ok then
    row.viewportWakeGeneration=generation;row.viewportWakeProfile=profile;row.viewportWakeFailure=nil
    if resume then queued=queued+1;row.viewportWakes=(row.viewportWakes or 0)+1 end
   else
    -- Other rows still receive their wake. Retain this notification's debt
    -- for a later explicit viewport retry; do not erase a provider failure.
    row.viewportWakeFailure=true;complete=false
   end
   if M.profile~=profile or (M.state.settingsGeneration or 0)~=settings then return false end
  end
 end
 self.viewportWakeGeneration=generation
 self.viewportWakeCount=(self.viewportWakeCount or 0)+queued
 return complete
end
local function phase(label,fn,object,...)
 local profiler=M.Profiler
 local token=profiler and type(profiler.BeginPhase)=="function" and profiler:BeginPhase(label)
 local ok,a,b=pcall(fn,object,...)
 if profiler and type(profiler.EndPhase)=="function" then profiler:EndPhase(token,ok) end
 return ok,a,b
end
-- Primary presentation and optional enhancements have independent meanings.
-- Mode 0 preserves the effective legacy provider choice, 1 explicitly selects
-- Mirage, and 2 explicitly returns presentation to the game. No optional switch
-- is rewritten. Managed actions previously ran even when supplemental bars were
-- disabled, so that historical flag cannot silently turn off the primary bars.
R.moduleForProvider=modules
function R:PrimaryChoice(id,profile)
 if M.NativeWindowPolicy and M.NativeWindowPolicy:ProviderNative(id) then return false,"NATIVE_BY_DESIGN" end
 local module=modules[id]
 if type(profile)~="table" or type(profile.modules)~="table" then return false,"MISSING_MODULE" end
 local cfg=profile.modules[module]
 if cfg==nil then return false,"MISSING_MODULE" end
 -- Inactive/named historical bodies are checkpointed without hydration. Their
 -- opaque values may be reported, but must never be indexed as runtime options.
 if type(cfg)~="table" then return false,"OPAQUE_PRIMARY_DATA" end
 local mode=cfg.primaryPresentation;if mode==nil then mode=0 end
 if mode~=0 and mode~=1 and mode~=2 or cfg.enabled~=nil and type(cfg.enabled)~="boolean" then return false,"OPAQUE_PRIMARY_DATA" end
 if mode==2 then return false,"EXPLICIT_NATIVE_RECOVERY" end
 if mode==1 then return true,"EXPLICIT_CUSTOM" end
 if id=="main" and profile.managed==true then return true,"LEGACY_MANAGED_ACTIONS" end
 if cfg.enabled==true then return true,"ENABLED_CUSTOM" end
 return false,"DISABLED_PRIMARY_UNRESOLVED"
end
function R:Selected(id,profile)
 if M.NativeWindowPolicy and M.NativeWindowPolicy:ProviderNative(id) then return false end
 profile=profile or M.profile
 local module=modules[id];local cfg=profile and profile.modules and profile.modules[module]
 local implementation=M.modules and M.modules[module]
 if M.Profiles and M.Profiles.readOnly then return false end
 local row=self.providers[id]
 local chosen=self:PrimaryChoice(id,profile)
 if row and type(row.object.selection)=="function" and (not cfg or (cfg.primaryPresentation or 0)==0) then
  local ok,value=pcall(row.object.selection,profile);chosen=ok and value==true
 end
 -- These packs retain the BlizzardSkin preference for compatibility, but
 -- never inherit the retired umbrella implementation's runtime failure.
 if module~="BlizzardSkin" and implementation and (implementation.quarantined or implementation.initializationFailed or implementation.maintenanceFailed) then return false end
 return module~=nil and self:Qualified() and self.storageReady==true and not self.rolledBack
  and profile and profile.enabled==true and chosen or false
end
function R:SurfaceActive(surface)
 if not surface or not surface.reworkProvider or M.state.safe or self:NativeEditState()=="OPEN" then return false end
 if surface.reworkReadiness=="CONFLICT" or surface.reworkReadiness=="FAULT" then return false end
 for _,id in ipairs(self.order) do
  local row=self.providers[id]
  if row.object==surface.reworkProvider then
   return row.started==true and row.object.active==true and not row.pending and not row.failed and self:Selected(id)
  end
 end
 return false
end
function R:ClaimsNative(name)
 local id=nativeOwners[name];local row=id and self.providers[id]
 return id and self:Selected(id) and not M.state.safe and self:NativeEditState()~="OPEN"
  and (not row or row.state~="RECOVERY") or false
end
function R:ProviderForLayout(id,profile)
 local owner=layoutOwners[id]
 return owner and self:Selected(owner,profile) and self.providers[owner] or nil
end
function R:ApplySurfaceLayout(surface)
 -- Core layout runs before the integration layer configures providers. A
 -- retained action surface can therefore exist while its owner is stopped,
 -- failed, or merely queued for retry. Only the registered current owner may
 -- dispatch a live layout; inactive callbacks wait for its Configure path.
 local surfaceID=surface and surface.id
 local id=surfaceID and layoutOwners[surfaceID]
 local registry=self.providers;local row=id and registry[id]
 local object=surface and surface.reworkProvider
 if not row or row.object~=object or not M.surfaces or M.surfaces[surfaceID]~=surface then
  return false,"LAYOUT_OWNER_UNAVAILABLE"
 end
 local state,profile,generation=M.state,M.profile,M.state.settingsGeneration or 0
 local lifetime=row.lifecycleRevision or 0
 local surfaces,frame,callback=M.surfaces,surface.frame,object.ApplyLayout
 local function current()
  return M.Rework==self and self.providers==registry and registry[id]==row and row.object==object
   and M.surfaces==surfaces and surfaces[surfaceID]==surface and surface.id==surfaceID and surface.frame==frame
   and surface.reworkProvider==object and layoutOwners[surfaceID]==id
   and object.ApplyLayout==callback and M.state==state and M.profile==profile
   and (state.settingsGeneration or 0)==generation and (row.lifecycleRevision or 0)==lifetime
 end
 local function skip(why)
  if current() then
   surface.layoutPending=true;row.layoutDispatch=why;row.layoutSurface=surfaceID
   row.layoutSkips=(row.layoutSkips or 0)+1
  end
  return false,why
 end
 if state.safe or not state.world or not profile or not profile.enabled or not self:Selected(id,profile) then
  return skip("LAYOUT_PROVIDER_NOT_SELECTED")
 end
 if row.failed or row.pending or row.state=="RECOVERY" then return skip("LAYOUT_PROVIDER_RECOVERING") end
 if not row.started or row.state~="ACTIVE" and row.state~="PREPARING" then return skip("LAYOUT_PROVIDER_INACTIVE") end
 if self:NativeEditState()~="CLOSED" then return skip("LAYOUT_NATIVE_EDIT_PENDING") end
 if S:InCombat() then return skip("COMBAT_LOCKDOWN") end
 if not current() then return false,"LAYOUT_DISPATCH_SUPERSEDED" end
 if state.safe or not state.world or not profile.enabled then return skip("LAYOUT_PROVIDER_NOT_SELECTED") end
 if row.failed or row.pending or row.state=="RECOVERY" then return skip("LAYOUT_PROVIDER_RECOVERING") end
 if not row.started or row.state~="ACTIVE" and row.state~="PREPARING" then return skip("LAYOUT_PROVIDER_INACTIVE") end
 -- Configure owns its own error boundary. Keep errors visible to that caller:
 -- several providers intentionally treat a false layout result as deferred
 -- work, so swallowing an exception here could falsely complete initialization.
 if self.activeProvider==id then
  row.layoutDispatch="PROVIDER_OWNED_LAYOUT";row.layoutSurface=surfaceID
  return callback(object,surface)
 end
 if row.state~="ACTIVE" or object.active~=true then return skip("LAYOUT_PROVIDER_INACTIVE") end
 row.layoutCalls=(row.layoutCalls or 0)+1;row.layoutSurface=surfaceID
 local previous=self.activeProvider;self.activeProvider=id
 local evidence
 local ok,value,why=xpcall(function() return callback(object,surface) end,function()
  -- Capture only allowlisted source locations while the failing stack exists.
  -- Never retain the native error string, text/binding content or arguments.
  if M.Incidents and type(M.Incidents.CaptureFailure)=="function" then
   local captured,source=pcall(M.Incidents.CaptureFailure,M.Incidents,"PROVIDER","LAYOUT")
   if captured then evidence=source end
  end
  return false
 end)
 self.activeProvider=previous
 if not current() then return false,"LAYOUT_DISPATCH_SUPERSEDED" end
 if row.nativeBlocked then return skip("NATIVE_ACTION_BLOCKED") end
 if not ok then
  surface.layoutPending=true;row.layoutDispatch="LAYOUT_FAILED"
  row.layoutFailures=(row.layoutFailures or 0)+1
  self:Health(row,"FAULT","LAYOUT_FAILED",surfaceID,evidence)
  if not current() then self:DiscardProviderCallback();return false,"LAYOUT_DISPATCH_SUPERSEDED" end
  self:RetireFault(row,"LAYOUT_FAILED")
  return false,"LAYOUT_FAILED"
 end
 row.layoutDispatch=value==false and "LAYOUT_DEFERRED" or "LAYOUT_RETURNED"
 return value,why
end
function R:RegisterProvider(id,provider)
 assert(modules[id] and not self.providers[id] and type(provider)=="table","Invalid rework provider")
 assert(type(provider.Initialize)=="function" and type(provider.Configure)=="function" and type(provider.Suspend)=="function","Incomplete rework provider")
 local row={id=id,module=modules[id],object=provider,state="STANDBY",reason="NOT_STARTED",readiness="WAITING",readinessReason="NOT_STARTED",faults=0,revision=0,nextRuntimeTick=0}
 local providerID=id
 row.tickCallback=function() self:RunProviderTick(providerID,S:Now()) end
 row.configureCallback=function() self:Configure(providerID) end
 row.tickGuard=function() return self.providers[providerID]==row and row.state=="ACTIVE" and row.started and self:Selected(providerID) and not M.state.safe end
 row.configureGuard=function() return self.providers[providerID]==row and not self.lifecycleBlocked and self:Selected(providerID) and not M.state.safe and M.profile and M.profile.enabled end
 for name in pairs(provider.nativeRoots or {}) do
  assert(not nativeOwners[name] or nativeOwners[name]==id,"Duplicate native provider: "..name)
  nativeOwners[name]=id
 end
 for layoutID in pairs(provider.layoutIDs or {}) do
  assert(not layoutOwners[layoutID] or layoutOwners[layoutID]==id,"Duplicate layout provider")
  layoutOwners[layoutID]=id
 end
 self.providers[id]=row;self.order[#self.order+1]=id;return row
end
function R:SetState(row,state,why)
 state=statuses[state] and state or "RECOVERY";why=reason(why or "NONE")
 if state=="RECOVERY" then row.failed=true;row.failureReason=why end
 if row.state==state and row.reason==why then return end
 row.state=state;row.reason=why;row.revision=row.revision+1
end
function R:StopProvider(row,why)
 row.lifecycleRevision=(row.lifecycleRevision or 0)+1
 if not row.started and not row.pending then self:SetState(row,"STOPPED",why);return true end
 local current,callback,object=providerDispatch(self,row,"Suspend",true)
 local waiting=S:InCombat() and "COMBAT_LOCKDOWN" or self:NativeEditing() and "NATIVE_EDIT" or nil
 if not current() then self:DiscardProviderCallback();return false,"PROVIDER_DISPATCH_SUPERSEDED" end
 if row.pending and not waiting and (row.releaseAttempts or 0)>0 and not row.releaseWake then
  local now=S:Now()
  if not current() then self:DiscardProviderCallback();return false,"PROVIDER_DISPATCH_SUPERSEDED" end
  if not row.transitionRetry or not row.releaseRetryAt or now<row.releaseRetryAt then return false end
  row.releaseWake=true
 end
 if not waiting and (row.releaseAttempts or 0)>=3 then
  row.pending=true;row.releaseBlocked=true;self:SetState(row,"RECOVERY","RESTORE_RETRY_REQUIRED");return false
 end
 if waiting and row.waitPhase==waiting then
  row.pending=true;self:SetState(row,"DEFERRED",waiting);return false
 end
 row.waitPhase=waiting
 if not waiting then row.releaseAttempts=(row.releaseAttempts or 0)+1;row.releaseWake=nil end
 local previous=self.activeProvider;self.activeProvider=row.id
 local ok,done,blocked=pcall(callback,object,why)
 self.activeProvider=previous
 if not current() then self:DiscardProviderCallback();return false,"PROVIDER_DISPATCH_SUPERSEDED" end
 if ok and done==true then
  row.started=false;row.pending=nil;row.nativeBlockPending=nil;row.releaseAttempts=0;row.releaseBlocked=nil;row.waitPhase=nil;row.releaseRetryAt=nil;row.transitionRetry=nil
  self:SetState(row,"STOPPED",why);return true
 end
 row.pending=true;row.releaseDetail=ok and reason(blocked) or "SUSPEND_FAILED"
 if not waiting and row.transitionRetry and (row.releaseAttempts or 0)<3 then
  row.releaseRetryAt=S:Now()+(row.releaseAttempts==1 and 1 or 3)
 end
 self:Health(row,waiting=="COMBAT_LOCKDOWN" and "DEFERRED_COMBAT" or "DEFERRED_HANDOFF",row.releaseDetail)
 if not current() then self:DiscardProviderCallback();return false,"PROVIDER_DISPATCH_SUPERSEDED" end
 self:SetState(row,(row.releaseAttempts or 0)>=3 and "RECOVERY" or "DEFERRED",waiting or (row.releaseAttempts or 0)>=3 and "RESTORE_RETRY_REQUIRED" or row.releaseDetail)
 return false
end
function R:RetireFault(row,why)
 local rows,object=self.providers,row.object
 row.faults=row.faults+1
 local _,detail=self:StopProvider(row,why)
 if detail=="PROVIDER_DISPATCH_SUPERSEDED" or M.Rework~=self or self.providers~=rows
  or rows[row.id]~=row or row.object~=object then return false end
 self:SetState(row,"RECOVERY",why)
 return true
end
function R:ResetReleaseBudget(providerID)
 for _,id in ipairs(self.order) do if not providerID or id==providerID then
  local row=self.providers[id];row.releaseAttempts=0;row.releaseBlocked=nil;row.waitPhase=nil;row.releaseWake=true
 end end
 if self.store and self.store.cvars then for _,row in pairs(self.store.cvars) do
  if not providerID or row.owner==providerID then row.restoreAttempts=nil end
 end end
 for owner in pairs(self.pendingCVarRetryAt or {}) do
  if not providerID or owner==providerID then self.pendingCVarRetryAt[owner]=nil end
 end
end
function R:Stop(why)
 local complete=true
 for i=#self.order,1,-1 do complete=self:StopProvider(self.providers[self.order[i]],why or "SAFE_MODE") and complete end
 local cvars=self:RestoreCVars()
 if not cvars then
  self.pendingCVarOwners=self.pendingCVarOwners or {}
  for _,receipt in pairs(self.store and self.store.cvars or {}) do
   if type(receipt.owner)=="string" then self.pendingCVarOwners[receipt.owner]=true end
  end
 else self.pendingCVarOwners=nil;self.pendingCVarRetryAt=nil
 end
 complete=cvars and complete
 self.pendingStop=not complete or nil
 return complete,complete and "COMPLETE" or "REWORK_RESTORE_PENDING"
end
-- A world/editor handoff retires the old providers together, but recovery is
-- per provider. One deferred inverse must never stop already-recovered siblings.
-- The journal and bounded retry budget remain authoritative for that owner.
function R:WakeTransition(why)
 for _,id in ipairs(self.order) do
  local row=self.providers[id]
  if row.pending then
   row.releaseAttempts=0;row.releaseBlocked=nil;row.waitPhase=nil
   row.releaseWake=true;row.releaseRetryAt=nil;row.transitionRetry=true
  end
 end
 for _,receipt in pairs(self.store and self.store.cvars or {}) do
  if self.pendingCVarOwners and self.pendingCVarOwners[receipt.owner] then
   receipt.restoreAttempts=nil
   if self.pendingCVarRetryAt then self.pendingCVarRetryAt[receipt.owner]=nil end
  end
 end
 self:RequestConfigure(nil,why)
end
function R:ContinueHandoff()
 local complete=true
 for _,id in ipairs(self.order) do
  local row=self.providers[id]
  if row.pending then
   local terminal,why=row.failed or row.state=="RECOVERY",row.failureReason or row.reason
   if self:StopProvider(row,why) then
    if terminal then self:SetState(row,"RECOVERY",why)
    else self:RequestConfigure(id,"HANDOFF_COMPLETE") end
   else complete=false end
  end
 end
 for owner in pairs(self.pendingCVarOwners or {}) do
  local now=S:Now();local due=self.pendingCVarRetryAt and self.pendingCVarRetryAt[owner]
  if not due or now>=due then
   if self:RestoreCVars(owner) then
    self.pendingCVarOwners[owner]=nil
    if self.pendingCVarRetryAt then self.pendingCVarRetryAt[owner]=nil end
    if self.providers[owner] then self:RequestConfigure(owner,"HANDOFF_COMPLETE") end
   else
    -- Several independent configure callbacks can drain handback in the same
    -- scheduler pass. They share one retry deadline, never three writes in
    -- that frame before the native CVar source has had time to settle.
    self.pendingCVarRetryAt=self.pendingCVarRetryAt or {};self.pendingCVarRetryAt[owner]=now+1
    complete=false
   end
  else complete=false end
 end
 self.pendingStop=not complete or nil
 return complete
end
function R:PrepareOwnedRootCleanup(module)
 -- Core tracks passive cards for generic cleanup. Their native-body leases
 -- must be restored before that generic pass is allowed to hide the cards.
 -- Keep this gate local to the affected module; other cleanup can proceed.
 local id=module=="UnitFrames" and "units" or module=="PartyRaid" and "groups"
 local row=id and self.providers[id]
 if row and row.object.nativeBacked then
  if row.object.suspendPending then row.pending=true end
  if (row.started or row.pending) and not self:StopProvider(row,"OWNED_ROOT_CLEANUP") then
   return false,"NATIVE_BODY_HANDOFF_PENDING"
  end
 end
 return true
end
function R:ReleaseBaseline(providerID)
 if S:InCombat() then return false end
 for name,id in pairs(nativeOwners) do
  if (not providerID or providerID==id) and self:Selected(id) then
   local context=M.ContextualNative and M.ContextualNative.rows[name]
   local registered=self.providers[id]
   local owner=context and context.ownedOwner
   local ownContext=context and context.ownedContract==true and context.name==name and context.frame==_G[name]
    and registered and registered.started and context.module==registered.module and owner and owner.active==true
    and (owner==registered.object or id=="main" and registered.object==self.MainAction and owner==self.ActionFamilies)
   -- These gates belong to the very provider being reconfigured. Its property
   -- journals must release before its explicit ReleaseOwned handback; generic
   -- fallback restoration would otherwise strand a healthy owner in recovery.
   if context and not ownContext then M.ContextualNative:Restore(name) end
   if M.ManagedNative and M.ManagedNative.rows[name] then M.ManagedNative:Restore(name) end
   local a=M.ContextualNative and M.ContextualNative.rows[name]
   local b=M.ManagedNative and M.ManagedNative.rows[name]
   if a and (not ownContext or a~=context) and (a.pending or a.active) or b and (b.active or b.restorePending or b.parentAttempt) then return false end
  end
 end
 if (not providerID or providerID=="minimap") and self:Selected("minimap") then
  if M.NavigationStyle and M.NavigationStyle:Restore("Minimap")~=true then return false end
  if M.NativeLayout and M.NativeLayout:Restore("Minimap")~=true then return false end
  if M.Native then M.Native:Restore("Minimap") end
 end
 return true
end
function R:Configure(providerID)
 if self.configuring then return false,"REENTRY" end
 self.configuring=true
 local configured,done,detail=pcall(function()
 if not M.state.initialized or not M.profile then return false,"NOT_INITIALIZED" end
 if M.state.safe or not M.state.world or not M.profile.enabled or self.rolledBack or M.Client.allowed~=true then return self:Stop("INACTIVE") end
 if self.lifecycleBlocked then return false,"LIFECYCLE_PAUSED" end
 if not self:Qualified() then return self:Stop("INACTIVE") end
 local editor=self:NativeEditState()
 if editor=="UNKNOWN" then self:RequestConfigure(providerID,"NATIVE_EDIT_UNKNOWN");return false,"NATIVE_EDIT_UNKNOWN" end
 if editor=="OPEN" then local ok=self:Stop("NATIVE_EDIT");self.editing=true;return ok,"NATIVE_EDIT" end
 if S:InCombat() then self:RequestConfigure(providerID,"COMBAT_LOCKDOWN");return false,"COMBAT_LOCKDOWN" end
 if self.pendingStop then self:ContinueHandoff() end
 if M.Native:Conflict() then self:Stop("CONFLICT_NATIVE_OWNER");return false,"CONFLICT_NATIVE_OWNER" end
 self.editing=nil;self.pendingConfigure=nil;self.serial=self.serial+1;self.live=true
 local profile,state,generation=M.profile,M.state,M.state.settingsGeneration or 0
 for _,id in ipairs(self.order) do if not providerID or id==providerID then
  if M.Rework~=self then return false,"PROVIDER_REGISTRY_CHANGED" end
  local row=self.providers[id]
  self.pendingProviders[id]=nil;row.configurePending=nil;row.viewportResumePending=nil
  if not self:Selected(id) or not M.state.world then
   local native=M.NativeWindowPolicy and M.NativeWindowPolicy:ProviderNative(id)
   local stopped=self:StopProvider(row,native and "NATIVE_BY_DESIGN" or "NOT_SELECTED")
   if native and stopped then self:Health(row,"READY","NATIVE_BY_DESIGN") end
  elseif self.pendingCVarOwners and self.pendingCVarOwners[id] then
   self:Health(row,"DEFERRED_HANDOFF","CVAR_RESTORE_PENDING")
   self:RequestConfigure(id,"CVAR_RESTORE_PENDING")
  elseif row.pending then
   local terminal,why=row.failed or row.state=="RECOVERY",row.failureReason or row.reason
   if self:StopProvider(row,why) then
    if terminal then self:SetState(row,"RECOVERY",why) else self:RequestConfigure(id,"HANDOFF_COMPLETE") end
   end
  elseif row.failed or row.state=="RECOVERY" then self:SetState(row,"RECOVERY",row.failureReason or "RECOVERY_REQUIRED")
  elseif not rawequal(profile,M.profile) or M.state~=state or (M.state.settingsGeneration or 0)~=generation
   or M.state.safe or S:InCombat() then self:RequestConfigure(id,"CONFIGURATION_DEFERRED")
  else
   local preparedCurrent=providerDispatch(self,row,"Configure")
   local prepareOK,prepared=pcall(self.ReleaseBaseline,self,id)
   if prepareOK and prepared==true and row.prepare then prepareOK,prepared=pcall(row.prepare) end
   if not preparedCurrent() then
    self:DiscardProviderCallback()
    if M.Rework==self and self.providers[id]==row
     and (M.profile~=profile or M.state~=state or (M.state.settingsGeneration or 0)~=generation)
     and not M.state.safe and M.state.world then
     self:RequestConfigure(id,"CONFIGURATION_CHANGED")
    end
   elseif not prepareOK or prepared~=true then
    self:DeferConfiguration(id,"BASELINE_RESTORE_PENDING")
   else
    row.lifecycleRevision=(row.lifecycleRevision or 0)+1
    self:SetState(row,"PREPARING","CONTROL_SETUP");row.started=true
    local current,callback,object=providerDispatch(self,row,"Configure")
    local previous=self.activeProvider;self.activeProvider=id
    local ok,value,detail=phase("Rework."..id..".Configure",callback,object,profile)
    self.activeProvider=previous
    if not current() then
     self:DiscardProviderCallback()
     if M.Rework==self and self.providers[id]==row and row.object==object and row.started and not row.failed
      and (M.profile~=profile or M.state~=state or (M.state.settingsGeneration or 0)~=generation)
      and not M.state.safe and M.state.world then self:RequestConfigure(id,"CONFIGURATION_CHANGED") end
    elseif row.nativeBlocked then
     -- A synchronous native rejection is not a successful Configure, even if
     -- the widget API returned normally after emitting its blocked event.
     self:Health(row,"FAULT","NATIVE_ACTION_BLOCKED")
     if current() then self:SetState(row,"RECOVERY","NATIVE_ACTION_BLOCKED") else self:DiscardProviderCallback() end
    else
    local kind,why,surface=self:ResultKind(value,detail,row.object)
    if not ok then kind,why="FAULT","INITIALIZE_FAILED" end
    self:Health(row,kind,why,surface,kind=="FAULT" and row.object.failureEvidence or nil)
    if not current() then self:DiscardProviderCallback()
    elseif kind=="FAULT" or kind=="CONFLICT" then
     local retired=self:RetireFault(row,why)
     if retired and not row.notified then M:Print(row.module.." needs attention. Open Help to retry this display or copy its report.");row.notified=true end
    else
     row.profile=profile;row.settingsGeneration=M.state.settingsGeneration or 0
     if kind=="DEFERRED_COMBAT" then row.configurePending=true end
     -- Waiting content and a local partial row are still a live provider. Its
     -- passive hooks can wake the affected root without stopping siblings.
     self:SetState(row,"ACTIVE",why)
    end
    end
   end
  end
 end end
 return true
 end)
 -- Finalize even when a shared observation outside the provider's own error
 -- boundary fails. Retain bounded planning work instead of a permanent busy
 -- latch. This does not reacquire a native owner or erase a failed inverse.
 self.configuring=nil
 if not configured then
  self.configurePlanningAttempts=math.min(3,(self.configurePlanningAttempts or 0)+1)
  self:RecordLifecycleFailure("CONFIGURATION_PLANNING",S:Now())
  if self.configurePlanningAttempts>=3 then self.lifecycleBlocked=true;self.lifecycleAttempts=3 end
  if M.Rework==self and not M.state.safe and M.state.world then
   pcall(self.RequestConfigure,self,providerID,"CONFIGURATION_PLANNING_FAILED")
  end
  return false,"CONFIGURATION_PLANNING_FAILED"
 end
 if done==true then self.configurePlanningAttempts=0 end
 return done,detail
end
function R:Retry(providerID)
 -- A recovery button may be opened on an unsupported client. It must not
 -- invoke provider initialization or erase evidence before admission checks.
 local observed,qualified=pcall(self.Qualified,self)
 if not observed then self:RecordLifecycleFailure("RECOVERY_ADMISSION",S:Now());return false,"LIFECYCLE_OBSERVATION_UNAVAILABLE" end
 if qualified~=true then return false,"CLIENT_UNQUALIFIED" end
 if not self.storageReady or self.rolledBack then return false,"STORAGE_UNAVAILABLE" end
 if providerID and not self.providers[providerID] then return false,"UNKNOWN_PROVIDER" end
 if S:InCombat() then return false,"COMBAT_LOCKDOWN" end
 if self:NativeEditState()~="CLOSED" then return false,"NATIVE_EDIT_UNKNOWN" end
 -- A shared observation failure pauses planning without destroying healthy
 -- ownership. An admitted recovery can resume that planner independently of
 -- individual native-provider cleanup/retry budgets.
 self.lifecycleBlocked=nil;self.lifecycleAttempts=0;self.configurePlanningAttempts=0;self.nextTick=nil
 if self.CombatLeases and self.CombatLeases.ResetAssetProofs then self.CombatLeases:ResetAssetProofs() end
 if (not providerID or providerID=="auras" or providerID=="units" or providerID=="groups" or providerID=="nameplates")
  and M.ManagedAuraRails and type(M.ManagedAuraRails.RetryLoad)=="function" then
  -- One explicit recovery may retry a previously unavailable native addon;
  -- ordinary unit/view creation shares ManagedAuraRails' failed-load cache.
  M.ManagedAuraRails:RetryLoad()
 end
 self:ResetReleaseBudget(providerID)
 local retry={};local complete,firstFailure=true,nil
 for _,id in ipairs(self.order) do
  local row=self.providers[id]
  if providerID==id or not providerID and (row.failed or row.state=="RECOVERY" or row.pending
   or row.configureBlocked or row.readiness=="FAULT" or row.readiness=="CONFLICT" or row.readiness=="PARTIAL") then
   retry[id]=true
  end
 end
 for _,id in ipairs(self.order) do if retry[id] then
  local row=self.providers[id];row.notified=nil
  -- Complete each local stop/retry/queue before touching the next display.
  -- A blocked handback must not strand other selected displays after a global
  -- "stop everything first" pass. Healthy siblings are never selected here.
  local ready=true
  if (row.started or row.pending) and not self:StopProvider(row,"RECOVER") then
   ready=false;complete=false;firstFailure=firstFailure or "REWORK_RESTORE_PENDING"
  end
  if ready and type(row.object.Retry)=="function" then
   local current,callback,object=providerDispatch(self,row,"Retry")
   local ok,result,detail=pcall(callback,object)
   if not current() then
    self:DiscardProviderCallback();ready=false;complete=false;firstFailure=firstFailure or "PROVIDER_DISPATCH_SUPERSEDED"
   elseif not ok or result==false then
    local why=ok and detail~=nil and reason(detail) or "PROVIDER_RETRY_FAILED"
    if why=="PROVIDER_UNAVAILABLE" and detail~="PROVIDER_UNAVAILABLE" then why="PROVIDER_RETRY_FAILED" end
    self:Health(row,"FAULT",why)
    if current() then
     self:SetState(row,"RECOVERY",why);firstFailure=firstFailure or "PROVIDER_RETRY_FAILED"
    else self:DiscardProviderCallback();firstFailure=firstFailure or "PROVIDER_DISPATCH_SUPERSEDED" end
    ready=false;complete=false
   end
  end
  if ready then
   row.failed=nil;row.failureReason=nil;row.configureAttempts=0;row.configureBlocked=nil
   row.nativeBlocked=nil;row.nativeBlockPending=nil
   if row.state=="RECOVERY" then self:SetState(row,"STANDBY","RECOVER") end
   self:RequestConfigure(id,"EXPLICIT_RETRY")
  end
 end end
 return complete,firstFailure
end
function R:ReconcileProviderState(row)
 -- nil is a valid no-work return, but not proof of continued ownership.
 -- Waiting/partial providers intentionally retain their distinct contracts.
 if not row or row.state~="ACTIVE" or not row.started or row.pending or row.failed
  or row.readiness~="READY" or row.object.active~=false then return false end
 if self:Health(row,"FAULT","PROVIDER_STOPPED")==false then return false end
 self:RetireFault(row,"PROVIDER_STOPPED")
 return true
end
function R:RunProviderTick(id,now)
 local row=self.providers[id]
 if not row or row.state~="ACTIVE" or not row.started or not self:Selected(id) or self:NativeEditState()~="CLOSED" or M.state.safe then return end
 local current,callback,object=providerDispatch(self,row,"Tick")
 now=S:Number(now) and now or S:Now()
 -- A queued request can outlive the work that caused it (for example, a
 -- native hook settled by a direct event). Recheck before entering its writer.
 if not self:NeedsProviderTick(row,now) then row.suppressedTicks=(row.suppressedTicks or 0)+1;return end
 if not current() then self:DiscardProviderCallback();return end
 row.viewportResumePending=nil
 row.runtimeTicks=(row.runtimeTicks or 0)+1
 local previous=self.activeProvider;self.activeProvider=id
 local good,value,detail=phase("Rework."..id..".Tick",callback,object,now)
 self.activeProvider=previous
 if not current() then self:DiscardProviderCallback();return end
 if row.nativeBlocked then return end
 row.nextRuntimeTick=(S:Number(now) and now or S:Now())+(tickIntervals[id] or .50)
 if good and value==nil then
  if self:ReconcileProviderState(row) then return end
  row.idleTicks=(row.idleTicks or 0)+1;return
 end
 row.workTicks=(row.workTicks or 0)+1
 local kind,why,surface=self:ResultKind(value,detail,row.object)
 if not good then kind,why="FAULT","TICK_FAILED" end
 self:Health(row,kind,why,surface)
 if not current() then self:DiscardProviderCallback();return end
 if kind=="FAULT" or kind=="CONFLICT" then
  self:RetireFault(row,why)
 elseif kind=="DEFERRED_COMBAT" then row.configurePending=true;self:SetState(row,"ACTIVE",why)
 elseif not self:ReconcileProviderState(row) and row.state=="ACTIVE" and row.started and not row.pending and not row.failed then
  -- Health and the runtime reason must describe the same completed work.
  -- A startup wait is not a permanent warning after its queue has settled.
  self:SetState(row,"ACTIVE",why)
 end
end
function R:Tick(now)
 if self.tickBusy or now<(self.nextTick or 0) then return end
 self.nextTick=now+.20;self.tickBusy=true
 local settled=false
 local ok=pcall(function()
  -- Existing handback does not need a new acquisition qualification. Read
  -- these owned stop requests first, even if the shared observer is broken.
  self.lifecyclePhase="SESSION_CLEANUP"
  if M.state.safe or not M.state.world or not M.profile or not M.profile.enabled or self.rolledBack
   or not self.storageReady or M.Client.allowed~=true then
   if self.pendingStop or self.live then self:Stop("INACTIVE") end;self.live=nil;return
  end
  self.lifecyclePhase="EDITOR_OBSERVATION"
  local editor=self:NativeEditState();self.editorObservation=editor
  if editor=="UNKNOWN" then return end
  if editor=="OPEN" then
   if not self.editing or self.pendingStop then self:Stop("NATIVE_EDIT") end
   self.editing=true;return
  end
  if self.editing then
   self.editing=nil
   self:WakeTransition("NATIVE_EDIT_CLOSED")
  end
  local combat=S:InCombat()
  self.lifecyclePhase="PENDING_RELEASE"
  if not combat then
   if self.pendingStop then self:ContinueHandoff() end
   for _,id in ipairs(self.order) do
    local row=self.providers[id]
    if row.pending and not row.releaseBlocked and (row.releaseWake or (row.releaseAttempts or 0)==0
     or row.transitionRetry and row.releaseRetryAt and now>=row.releaseRetryAt) then
     local terminal,why=row.failed or row.state=="RECOVERY",row.failureReason or row.reason
     if self:StopProvider(row,why) then
      if terminal then self:SetState(row,"RECOVERY",why) else self:RequestConfigure(id,"HANDOFF_COMPLETE") end
     end
    end
   end
  end
  -- Three failed shared observations pause new planning. Continue observing
  -- genuine native editor edges and draining retained cleanup above; neither
  -- operation clears this pause or spends an acquisition retry budget.
  if self.lifecycleBlocked then return end
  self.lifecyclePhase="ADMISSION"
  if not self:Qualified() then
   if self.pendingStop or self.live then self:Stop("INACTIVE") end;self.live=nil;return
  end
  if self.pendingConfigure then self.pendingConfigure=nil;self:RequestConfigure(nil,"EXPLICIT_CONFIGURATION") end
  self.live=true
  self.lifecyclePhase="PROVIDER_PLANNING"
  for _,id in ipairs(self.order) do
   local row=self.providers[id];local providerID=id
   if row.started and not self:Selected(id) then self:StopProvider(row,"NOT_SELECTED")
   elseif self.pendingProviders[id] and not combat then
    if M.RuntimeScheduler then
     M.RuntimeScheduler:Request("Rework.Configure."..id,row.configureCallback,{combat="defer",priority=2,owner="Rework."..id,guard=row.configureGuard})
    else self:Configure(id) end
   elseif self:ReconcileProviderState(row) then
    -- Local retirement is reported and recoverable even when the provider's
    -- demand probe now returns false and no Tick would otherwise be queued.
   elseif row.state=="ACTIVE" and self:Selected(id) and row.object.Tick and self:NeedsProviderTick(row,now,combat) then
    if M.RuntimeScheduler then
     M.RuntimeScheduler:Request("Rework.Tick."..id,row.tickCallback,{combat="allow",priority=3,owner="Rework."..id,guard=row.tickGuard})
    else self:RunProviderTick(id,now) end
   end
  end
  settled=true
 end)
 self.tickBusy=nil
 if not ok then
  -- Do not interpret an observer/planner exception as permission to restore
  -- every unrelated display. Provider writers have their own local failure
  -- and handback paths. Retain those receipts and bound shared retries.
  self:RecordLifecycleFailure(self.lifecyclePhase,now)
 elseif settled then
  self.lastError=nil;self.lifecycleBlocked=nil;self.lifecycleAttempts=0
 end
 self.lifecyclePhase=nil
end
function R:OnEvent(event,...)
 -- Core records this synchronous incident before any ordinary observers run.
 -- It must not replace the originating event breadcrumb or enter provider
 -- callbacks recursively while the rejected native operation is unwinding.
 if event=="ADDON_ACTION_BLOCKED" or event=="ADDON_ACTION_FORBIDDEN" then return end
 if S:Text(event) and event:match("^[A-Z_]+$") and #event<64 then self.lastEvent=event end
 if event=="PLAYER_LEAVING_WORLD" then
  if M.RuntimeScheduler then M.RuntimeScheduler:CancelPrefix("Rework.") end
  self.pendingProviders={};self.pendingConfigure=nil;self.live=nil;self.worldTransition=true;self:Stop("WORLD_LEFT");return
 end
 if event=="PLAYER_ENTERING_WORLD" then
  if self.worldTransition then self.worldTransition=nil;self:WakeTransition("WORLD_ENTERED")
  elseif not self.live then self:RequestConfigure(nil,"WORLD_ENTERED") end
 end
 if event=="PLAYER_REGEN_ENABLED" then
  for _,id in ipairs(self.order) do local row=self.providers[id]
   if row.configurePending then self:RequestConfigure(id,"DEFERRED_COMBAT_ENDED") end
   -- Cleanup retries resume on this legal edge, not a blanket profile reapply.
   if row.pending then row.waitPhase=nil;row.releaseWake=true end
  end
 end
 -- World/cleanup wakes above remain available during a planning pause. A
 -- failed shared observation on a normal event must not escape to Core's
 -- global EVENT_FAILED handback or repeatedly probe after the bounded pause.
 if self.lifecycleBlocked then return end
 local observed,qualified=pcall(self.Qualified,self)
 if not observed then self:RecordLifecycleFailure("EVENT_ADMISSION",S:Now());return end
 if qualified~=true then return end
 for _,id in ipairs(self.order) do
  local row=self.providers[id]
  local applicable=not row.object.events or row.object.events[event]
  -- A pending native-backed handback can leave our passive card intentionally
  -- visible. Keep its essential data current until its region ledger restores.
  -- Core already covers combat cleanup; this branch covers legal-time debt.
  if applicable and row.pending and row.object.nativeBacked and row.object.suspendPending and not S:InCombat()
   and type(row.object.MaintainSecure)=="function" then
   local ok=pcall(row.object.MaintainSecure,row.object,event,...)
   if not ok then self:Health(row,"PARTIAL","ESSENTIAL_DISPLAY_PENDING") end
  end
  if applicable and row.started and row.object.active==false and row.readinessReason~="VIEWPORT_PENDING"
   and (row.readiness=="WAITING" or row.readiness=="DEFERRED_HANDOFF" or row.readiness=="DEFERRED_COMBAT")
   and (event=="ADDON_LOADED" or event=="PLAYER_REGEN_ENABLED" or event=="PLAYER_ENTERING_WORLD") then
   row.configureAttempts=0;row.configureBlocked=nil;self:RequestConfigure(id,"NATIVE_LIFECYCLE_WAKE")
  end
  local selected=false
  if row.state=="ACTIVE" and row.started and not M.state.safe and self:NativeEditState()=="CLOSED" then
   local known,chosen=pcall(self.Selected,self,id)
   if not known then self:RecordLifecycleFailure("EVENT_SELECTION",S:Now());return end
   selected=chosen==true
  end
  if selected and row.object.OnEvent and (not row.object.events or row.object.events[event]) then
   local current,callback,object=providerDispatch(self,row,"OnEvent")
   local previous=self.activeProvider;self.activeProvider=id
   local ok,value,detail=pcall(callback,object,event,...)
   self.activeProvider=previous
   if not current() then self:DiscardProviderCallback()
   elseif row.nativeBlocked then
    self:Health(row,"FAULT","NATIVE_ACTION_BLOCKED")
    if current() then self:SetState(row,"RECOVERY","NATIVE_ACTION_BLOCKED") else self:DiscardProviderCallback() end
   elseif not ok then
    self:Health(row,"FAULT","EVENT_FAILED")
    if current() then self:RetireFault(row,"EVENT_FAILED") else self:DiscardProviderCallback() end
   else
    -- Structural events can finish an ownership handoff before the next
    -- scheduled paint. Consume only an explicit result, never infer readiness
    -- from ordinary nil/boolean event returns or from a diagnostic read.
    if type(value)=="table" and resultKinds[value.kind] then
     local kind,why,surface=self:ResultKind(value,detail,row.object)
     self:Health(row,kind,why,surface)
     if not current() then self:DiscardProviderCallback()
     elseif kind=="FAULT" or kind=="CONFLICT" then
      self:RetireFault(row,why)
     elseif row.state=="ACTIVE" and row.started and not row.pending and not row.failed then
      if kind=="DEFERRED_COMBAT" then row.configurePending=true end
      self:SetState(row,"ACTIVE",why)
     end
    end
    if row.state=="ACTIVE" and not self:ReconcileProviderState(row) then
     row.nextRuntimeTick=0
     if M.RuntimeScheduler and self:NeedsProviderTick(row,S:Now()) then
      M.RuntimeScheduler:Request("Rework.Tick."..id,row.tickCallback,{combat="allow",priority=2,owner="Rework."..id,guard=row.tickGuard})
     end
    end
   end
  end
 end
end
local operations={SetPoint=true,ClearAllPoints=true,SetAllPoints=true,SetAttribute=true,SetParent=true,SetScale=true,SetSize=true,SetWidth=true,SetHeight=true,SetShown=true,Hide=true,Show=true,EnableMouse=true,
 RegisterStateDriver=true,UnregisterStateDriver=true,RegisterUnitWatch=true,UnregisterUnitWatch=true,SetBinding=true,SetBindingClick=true,SetOverrideBinding=true,
 SetOverrideBindingClick=true,ClearOverrideBindings=true,UseAction=true,CastSpellByName=true,TargetUnit=true,SetProtected=true,SetActionUIButton=true}
local function blockLocations()
 -- Capture only whitelisted addon source paths and line numbers. Do not copy
 -- stack arguments, arbitrary addon names, chat text, units, or locals. The
 -- last event is a breadcrumb, not evidence of the actual blocked caller.
 local stack,state=S:Public(debugstack,"string",2,32,0)
 if state~="KNOWN" or #stack>32768 then return "SOURCE_LOCATIONS_UNAVAILABLE" end
 local result,seen={},{}
 for line in stack:gmatch("[^\r\n]+") do
  local path,number=line:gsub("\\","/"):match('Interface/AddOns/([%w_/%-]+%.lua)["%]]*:(%d+)')
  if path and #path<=160 and #number<=7 then
   local addon=path:match("^([^/]+)/")
   if addon=="MirageUI" or addon=="MirageUIOptions" or addon=="MirageUICursor" or addon and addon:match("^Blizzard_[%w_]+$") then
    local location=path..":"..number
    if not seen[location] then result[#result+1]=location;seen[location]=true end
    if #result>=16 then break end
   end
  end
 end
 return #result>0 and table.concat(result,";") or "SOURCE_LOCATIONS_UNAVAILABLE"
end
local function retainedBlockLocations(value)
 if not S:Text(value) or #value>3000 then return "NOT_RECORDED" end
 if value=="SOURCE_LOCATIONS_UNAVAILABLE" then return value end
 local count=0
 for part in value:gmatch("[^;]+") do
  local addon,path,number=part:match("^([%w_]+)/([%w_/%-]+%.lua):(%d+)$")
  if not addon or #path>160 or #number>7 or not (addon=="MirageUI" or addon=="MirageUIOptions" or addon=="MirageUICursor" or addon:match("^Blizzard_[%w_]+$")) then return "NOT_RECORDED" end
  count=count+1;if count>16 then return "NOT_RECORDED" end
 end
 return count>0 and value or "NOT_RECORDED"
end
local blockSourceProviders={
 ["MirageUI/Rework/ActionBar.lua"]="main",["MirageUI/Rework/ActionFamilies.lua"]="main",["MirageUI/Rework/ActionInterface.lua"]="main",
 ["MirageUI/Rework/UnitFrames.lua"]="units",["MirageUI/Rework/UnitGroups.lua"]="groups",["MirageUI/Rework/Minimap.lua"]="minimap",
 ["MirageUI/Rework/Nameplates.lua"]="nameplates",["MirageUI/Rework/CombatCasts.lua"]="casts",
}
local function blockProvider(self,locations)
 local provider=self.activeProvider
 if provider and self.providers[provider] then return provider,"PROVIDER_CALLBACK" end
 if M.RuntimeScheduler and S:Text(M.RuntimeScheduler.phase) then
  provider=M.RuntimeScheduler.phase:match("^Rework%.Tick%.([%w_%-]+)$") or M.RuntimeScheduler.phase:match("^Rework%.Configure%.([%w_%-]+)$")
  if provider and self.providers[provider] then return provider,"SCHEDULED_PROVIDER_CALLBACK" end
 end
 local module=M.activeGuardOwner
 if module then for id,owner in pairs(modules) do
  if owner==module and self.providers[id] and (self.providers[id].started or self.providers[id].pending) then return id,"MODULE_CALLBACK" end
 end end
 local actionBar,actionButton=false,false
 for part in locations:gmatch("[^;]+") do
  local path=part:match("^(.+%.lua):%d+$")
  provider=path and blockSourceProviders[path]
  if provider and self.providers[provider] and (self.providers[provider].started or self.providers[provider].pending) then return provider,"ADDON_SOURCE_LOCATION" end
  actionBar=actionBar or path=="Blizzard_ActionBar/Shared/ActionBar.lua"
  actionButton=actionButton or path=="Blizzard_ActionBar/Shared/ActionButton.lua"
 end
 -- The P17 evidence reaches both of these native callbacks. This attributes
 -- the affected display, not the earlier tainting write: native container
 -- visibility runs after UpdateAction on ACTIONBAR_SLOT_CHANGED. Do not infer
 -- a provider from the last event, a lone generic SetShown, or arbitrary text.
 local main=self.providers.main
 if actionBar and actionButton and main and (main.started or main.pending) then return "main","NATIVE_ACTION_VISIBILITY_STACK" end
 return nil,"UNATTRIBUTED"
end
function R:RecordNativeBlock(event,addon,operation)
 local api="UNCLASSIFIED"
 if S:Text(operation) and #operation<=256 then
  local token=operation:match("([%w_]+)%(%s*%)$") or operation:match("([%w_]+)$")
  if operations[token] then api=token end
 end
 local source=addon=="MirageUIOptions" and "OPTIONS" or addon=="MirageUICursor" and "CURSOR" or "CORE"
 local locations=blockLocations()
 local provider,attribution=blockProvider(self,locations)
 local module=M.activeGuardOwner
 if not (module and M.modules and M.modules[module]) then module=nil end
 local entry={event=event=="ADDON_ACTION_FORBIDDEN" and "FORBIDDEN" or "BLOCKED",source=source,operation=api,provider=provider or "UNKNOWN",
  context=self.lastEvent or "NONE",combat=S:InCombat() and true or false,nativeEdit=self:NativeEditing() and true or false,
  contextEvidence="LAST_OBSERVED_EVENT",locations=locations,attribution=attribution,module=module,
  build=M.BuildInfo and M.BuildInfo.id or "UNKNOWN",
  version=M.version or "UNKNOWN",observedAt=S:Now()}
 if not self.firstNativeBlock then self.firstNativeBlock=entry;if self.store then self.store.firstNativeBlock=entry end end
 self.lastNativeBlock=entry
 self.nativeBlocksThisSession=math.min(2147483647,(self.nativeBlocksThisSession or 0)+1)
 if self.store then self.store.lastNativeBlock=entry end
 return entry
end
function R:NativeBlockSummary()
 -- Saved incident history is not a failure in this session. Read only the
 -- journal; opening /check or exporting cannot invoke a native operation.
 local count=self.nativeBlocksThisSession or (self.lastNativeBlock and 1 or 0)
 local current=self.lastNativeBlock
 local historical=not current and self.store and self.store.lastNativeBlock
 local history=type(historical)=="table" and "PRESENT_SEPARATE_FROM_CURRENT_SESSION" or "NONE"
 return "current_session="..(current and "OBSERVED" or "NONE_RECORDED").."; count="..count.."; historical="..history
  .."; native_taint_qualification=NOT_RUN"
end
function R:HandleNativeBlock(entry)
 if type(entry)~="table" then return false end
 local id=entry.provider
 local row=id and self.providers[id]
 if row and (row.started or row.pending or row.nativeBlocked) then
  row.nativeBlockCount=math.min(2147483647,(row.nativeBlockCount or 0)+1)
  row.lastNativeBlock=entry
  if not row.nativeBlocked then
   row.nativeBlocked=true;row.firstNativeBlock=entry
   row.nativeBlockPending=row.started or row.pending or nil
   row.faults=row.faults+1
   -- The normal out-of-combat release queue owns the inverse. Marking this
   -- row pending cannot issue a protected setter from the nested event, and
   -- repeated rejections cannot reset its release budget or stop siblings.
   row.pending=row.nativeBlockPending
   self.pendingProviders[id]=nil;row.configurePending=nil
   self:Health(row,"FAULT","NATIVE_ACTION_BLOCKED");self:SetState(row,"RECOVERY","NATIVE_ACTION_BLOCKED")
   if M.Incidents then M.Incidents:Record("NATIVE_BLOCK",row.module,entry.operation or "UNCLASSIFIED","PROVIDER_ISOLATED") end
  end
  entry.disposition="PROVIDER_ISOLATED_RELEASE_DEFERRED"
 end
 local module=entry.module or entry.source=="CURSOR" and "Cursor" or entry.source=="OPTIONS" and "Options"
 local implementation=module and M.modules and M.modules[module]
 if implementation then
  if not implementation.nativeBlocked then
   implementation.nativeBlocked=true;implementation.quarantined=true;implementation.status="FAULTED"
   M.cleanupModules=M.cleanupModules or {};M.cleanupModules[module]=true
   if M.Fault then M:Fault(module,"NATIVE_ACTION_BLOCKED") end
  end
  entry.disposition=entry.disposition or "MODULE_ISOLATED_RELEASE_DEFERRED"
 end
 if not entry.disposition then
  self.unattributedNativeBlocks=math.min(2147483647,(self.unattributedNativeBlocks or 0)+1)
  entry.disposition="RECORDED_UNATTRIBUTED"
  -- A rejection proves that this operation was refused. Without a retained
  -- owner it does not prove that every custom display has failed. Preserve the
  -- first source stack for diagnosis and let independent providers continue.
 end
 return true
end
local cvarNames={nameplateShowEnemies=true,nameplateShowFriends=true,nameplateShowFriendlyPlayers=true,nameplateShowOnlyNameForFriendlyPlayerUnits=true,nameplateShowAll=true,nameplateGlobalScale=true,nameplateMinScale=true,nameplateMaxScale=true,nameplateMaxDistance=true,
 nameplateSelectedScale=true,nameplateMotion=true,nameplateOccludedAlphaMult=true,nameplateShowEnemyMinions=true,nameplateShowEnemyPets=true,nameplateShowFriendlyPets=true,nameplateShowFriendlyPlayerMinions=true,nameplateShowFriendlyNPCs=true,nameplateShowFriendlyNpcs=true,nameplateOtherTopInset=true,nameplateOtherBottomInset=true,
 floatingCombatTextCombatDamage_v2=true,UnitNameFriendlyPlayerName=true,UnitNamePlayerGuild=true,nameplateCheckDistanceForTarget=true,UnitNameNPC=true,UnitNameFriendlyMinionName=true,showTargetOfTarget=true,damageMeterEnabled=true}
function R:IsJournalCVar(key) return cvarNames[key]==true end
local function cvarGet(key)
 return S:Public(C_CVar and C_CVar.GetCVar or GetCVar,"string",key)
end
local function cvarWritable(key)
 if not C_CVar or type(C_CVar.GetCVarInfo)~="function" then return true end
 local ok,_,_,_,_,locked,secure,readonly=pcall(C_CVar.GetCVarInfo,key)
 return ok and S:Readable(locked) and S:Readable(secure) and S:Readable(readonly)
  and locked==false and secure==false and readonly==false
end
function R:WriteCVar(owner,key,value,explicit)
 if not cvarNames[key] or type(owner)~="string" or #owner>48 then return false,"CVAR_NOT_QUALIFIED" end
 if not self:Qualified() or not self.storageReady or M.state.safe then return false,"NOT_QUALIFIED" end
 if S:InCombat() or self:NativeEditing() then return false,"CVAR_DEFERRED" end
 if not S:Readable(value) or (type(value)~="number" and type(value)~="string") then return false,"INVALID_CVAR_VALUE" end
 value=tostring(value)
 local current,state=cvarGet(key)
 if state~="KNOWN" then return false,"CVAR_UNAVAILABLE" end
 local journal=self.store.cvars;local row=journal[key]
 if explicit==true and row and row.owner==owner and row.conflict then journal[key]=nil;row=nil end
 if row and (row.owner~=owner or row.conflict) then return false,"CVAR_EXTERNAL_CHANGE" end
 if row and row.written and current~=row.written and current~=row.attempt then row.conflict=true;row.status="EXTERNAL_CHANGE";return false,"CVAR_EXTERNAL_CHANGE" end
 if current==value then
  -- A locked CVar already at the requested value needs no mutation. Retain
  -- its snapshot so later external changes are still detected and preserved.
  if not row then row={owner=owner,original=current};journal[key]=row end
  row.written=value;row.attempt=nil;row.restoreAttempts=nil;row.status="OWNED";return true,"CVAR_ALREADY_SATISFIED"
 end
 if not cvarWritable(key) then return false,"CVAR_NOT_WRITABLE" end
 if not row then row={owner=owner,original=current,status="PREPARED"};journal[key]=row end
 local set=C_CVar and C_CVar.SetCVar or SetCVar
 if type(set)~="function" then return false,"CVAR_UNAVAILABLE" end
 row.attempt=value;row.writeInProgress=true;row.observedAttempt=nil
 local ok=pcall(set,key,value)
 local after,known=cvarGet(key)
 row.writeInProgress=nil;row.observedAttempt=nil
 -- A public callback may observe our value followed by a newer external
 -- value before the setter returns. Its conflict outranks final readback,
 -- including an external roundtrip back to the same numeric preference.
 if row.conflict then row.status="EXTERNAL_CHANGE";return false,"CVAR_EXTERNAL_CHANGE" end
 if ok and known=="KNOWN" and after==value then row.written=value;row.attempt=nil;row.restoreAttempts=nil;row.status="OWNED";return true end
 row.status="WRITE_UNCONFIRMED";return false,"CVAR_WRITE_UNCONFIRMED"
end
function R:RestoreCVars(owner,onlyKey)
 if not self.store or not self.store.cvars then return true end
 if next(self.store.cvars)==nil then return true end
 local matched,observed=self:ObserveTarget()
 if observed~="KNOWN" then return false,"RESTORE_CLIENT_UNAVAILABLE" end
 if not matched then return false,"RESTORE_CLIENT_UNQUALIFIED" end
 if S:InCombat() then return false,"COMBAT_LOCKDOWN" end
 if self:NativeEditing() then return false,"CVAR_DEFERRED" end
 local complete=true
 for key,row in pairs(self.store.cvars) do
  if (not owner or row.owner==owner) and (not onlyKey or onlyKey==key) and cvarNames[key] then
   if row.restoreAttempts~=nil and (not S:Number(row.restoreAttempts) or row.restoreAttempts<0 or row.restoreAttempts>3 or row.restoreAttempts%1~=0) then
    complete=false;row.status="INVALID_JOURNAL"
   elseif (row.restoreAttempts or 0)>=3 then complete=false;row.status="RESTORE_RETRY_REQUIRED"
   else
   local current,state=cvarGet(key);local expected=row.written or row.attempt
   local ours=current==row.written or current==row.attempt
   if state~="KNOWN" then complete=false;row.restoreAttempts=(row.restoreAttempts or 0)+1;row.status="RESTORE_PENDING"
   elseif row.conflict then row.status="EXTERNAL_PRESERVED"
   -- An unchanged original after an unconfirmed first write is a no-op. Once
   -- our write was confirmed, a return to the original can be a later user
   -- choice; retain that conflict so reacquisition cannot seed over it.
   elseif current==row.original and (not row.written or ours) then self.store.cvars[key]=nil
   elseif expected and not ours then row.status="EXTERNAL_PRESERVED";row.conflict=true
   elseif expected then
    local set=C_CVar and C_CVar.SetCVar or SetCVar
    local ok=cvarWritable(key) and type(set)=="function" and pcall(set,key,row.original)
    local after,known=cvarGet(key)
    if ok and known=="KNOWN" and after==row.original then self.store.cvars[key]=nil
    else complete=false;row.restoreAttempts=(row.restoreAttempts or 0)+1;row.status="RESTORE_PENDING" end
   else self.store.cvars[key]=nil end
   end
  end
 end
 return complete,complete and "COMPLETE" or "CVAR_RESTORE_PENDING"
end
-- The world-damage switch is public and nonsecure in the reviewed client.
-- Its runtime capability, current value, journal and route authority are
-- checked around every write. Ordinary nameplate/layout CVars still use the
-- out-of-combat-only WriteCVar path above. This narrow transaction lets a
-- complete custom route recover during the same fight after native fallback.
function R:AcquireWorldDamage(validate)
 local key="floatingCombatTextCombatDamage_v2"
 if type(validate)~="function" then return false,"ROUTE_VALIDATOR_UNAVAILABLE" end
 local store=self.store
 local journal=S:Field(store,"cvars")
 local api=C_CVar
 local info=S:Field(api,"GetCVarInfo");local get=S:Field(api,"GetCVar");local set=S:Field(api,"SetCVar")
 if not S:Readable(store) or type(store)~="table" or not S:Readable(journal) or type(journal)~="table"
  or not S:Readable(api) or type(api)~="table" or type(info)~="function" or type(get)~="function" or type(set)~="function" then
  return false,"CVAR_API_UNAVAILABLE"
 end
 local row,state=S:FieldAccess(journal,key)
 if state~="KNOWN" and state~="ABSENT" then return false,"CVAR_OWNERSHIP_UNAVAILABLE" end
 if row and (type(row)~="table" or S:Field(row,"owner")~="nameplates") then return false,"CVAR_EXTERNAL_CHANGE" end
 local function authority()
  if self~=R or M.Rework~=R or self.store~=store or S:Field(store,"cvars")~=journal
   or not self.storageReady or M.state.safe or not self:Qualified() or self:NativeEditState()~="CLOSED"
   or C_CVar~=api or S:Field(api,"GetCVarInfo")~=info or S:Field(api,"GetCVar")~=get or S:Field(api,"SetCVar")~=set
   or S:Field(journal,key)~=row then return false end
  local ok,valid=pcall(validate)
  return ok and valid==true
 end
 local function observe()
  if not authority() then return nil end
  local okay,value,default,account,character,locked,secure,readonly=pcall(info,key)
  local public,actual=pcall(get,key)
  if not okay or not public or not S:Text(value) or (value~="0" and value~="1")
   or not S:Text(actual) or actual~=value or not S:Text(default) or (default~="0" and default~="1") then return nil end
  for _,v in ipairs({{account},{character},{locked},{secure},{readonly}}) do
   if not S:Readable(v[1]) or type(v[1])~="boolean" then return nil end
  end
  if not authority() then return nil end
  return actual,not locked and not secure and not readonly
 end
 local value,writable=observe()
 if value==nil then return false,"CVAR_STATE_UNAVAILABLE" end
 if row then
  local original=S:Field(row,"original")
  local written,attempt=S:Field(row,"written"),S:Field(row,"attempt")
  local conflict,known=S:FieldAccess(row,"conflict")
  if not S:Text(original) or (original~="0" and original~="1")
   or written~=nil and written~="0" or attempt~=nil and attempt~="0"
   or known~="ABSENT" and (known~="KNOWN" or type(conflict)~="boolean") then return false,"INVALID_JOURNAL" end
  if conflict or written and value~=written and value~=attempt then
   row.conflict=true;row.status="EXTERNAL_CHANGE";return false,"CVAR_EXTERNAL_CHANGE"
  end
 end
 if not writable then return false,"CVAR_NOT_WRITABLE" end
 if not authority() then return false,"ROUTE_CONTEXT_CHANGED" end
 if value=="0" then
  if not row then row={owner="nameplates",original=value};journal[key]=row end
  row.written="0";row.attempt=nil;row.restoreAttempts=nil;row.status="OWNED";return true,"CVAR_ALREADY_SATISFIED"
 end
 local again,stillWritable=observe()
 if again~=value or not stillWritable or not authority() then return false,"CVAR_STATE_CHANGED" end
 -- Do not create recovery debt for a transaction rejected before its first
 -- write. Persist the original immediately before making that write.
 if not row then row={owner="nameplates",original=value,status="PREPARED"};journal[key]=row end
 row.attempt="0"
 local okay,success=pcall(set,key,"0")
 -- A synchronous callback may revoke the route. Keep its recovery receipt
 -- even then; only the same journal may record or reverse this transaction.
 local same=self==M.Rework and self.store==store and S:Field(store,"cvars")==journal and S:Field(journal,key)==row
 if not same then return false,"CVAR_OWNERSHIP_SUPERSEDED" end
 local public,after=pcall(get,key)
 if public and S:Text(after) and after=="0" then row.written="0";row.attempt=nil end
 if okay and S:Readable(success) and success==true and public and S:Text(after) and after=="0" and authority() then
  row.restoreAttempts=nil;row.status="OWNED";return true,"CVAR_WRITE_CONFIRMED"
 end
 row.status="WRITE_UNCONFIRMED"
 return false,"CVAR_WRITE_UNCONFIRMED"
end
-- Emergency handback of one public presentation switch. 70888 CVar exports
-- explicitly require public/nonsecure/non-read-only CVars; they impose no
-- combat-only prohibition. This does not broaden ordinary CVar acquisition or
-- general restoration, and cannot write any value except our journaled original.
function R:RestoreWorldDamage()
 local key="floatingCombatTextCombatDamage_v2"
 if self~=R or M.Rework~=R or not self:TargetMatched() then return false,"RESTORE_CLIENT_UNQUALIFIED" end
 local store=self.store
 if not S:Readable(store) then return false,"RESTORE_OWNER_UNAVAILABLE" end
 if store==nil then return true,"NO_OWNERSHIP" end
 if type(store)~="table" then return false,"RESTORE_OWNER_UNAVAILABLE" end
 local journal,journalState=S:FieldAccess(store,"cvars")
 if journalState=="ABSENT" then return true,"NO_OWNERSHIP" end
 if journalState~="KNOWN" or type(journal)~="table" then return false,"RESTORE_OWNER_UNAVAILABLE" end
 local row,rowState=S:FieldAccess(journal,key)
 if rowState=="ABSENT" then return true,"NO_OWNERSHIP" end
 if rowState~="KNOWN" or type(row)~="table" or S:Field(row,"owner")~="nameplates" then return false,"RESTORE_OWNER_UNAVAILABLE" end
 local original,written=S:Field(row,"original"),S:Field(row,"written")
 local attempt,attemptState=S:FieldAccess(row,"attempt")
 local conflict,conflictState=S:FieldAccess(row,"conflict")
 if not S:Text(original) or (original~="0" and original~="1") or written~=nil and (not S:Text(written) or written~="0")
  or attemptState~="ABSENT" and (attemptState~="KNOWN" or attempt~="0")
  or conflictState~="ABSENT" and (conflictState~="KNOWN" or type(conflict)~="boolean") then return false,"INVALID_JOURNAL" end
 local api=C_CVar
 local info=S:Field(api,"GetCVarInfo");local get=S:Field(api,"GetCVar");local set=S:Field(api,"SetCVar")
 if not S:Readable(api) or type(api)~="table" or not S:Readable(info) or type(info)~="function"
  or not S:Readable(get) or type(get)~="function" or not S:Readable(set) or type(set)~="function" then return false,"CVAR_API_UNAVAILABLE" end
 local function current()
  local a,as=S:FieldAccess(row,"attempt");local c,cs=S:FieldAccess(row,"conflict")
  return self==M.Rework and S:Readable(self.store) and self.store==store and S:Field(store,"cvars")==journal and S:Field(journal,key)==row
   and S:Field(row,"owner")=="nameplates" and S:Field(row,"original")==original and S:Field(row,"written")==written
   and as==attemptState and a==attempt and cs==conflictState and c==conflict
   and S:Readable(C_CVar) and C_CVar==api and S:Field(api,"GetCVarInfo")==info and S:Field(api,"GetCVar")==get and S:Field(api,"SetCVar")==set and self:TargetMatched()
 end
 local function observed()
  if not current() then return nil end
  local okay,value,default,account,character,locked,secure,readonly=pcall(info,key)
  local public,actual=pcall(get,key)
  if not okay or not public or not S:Text(value) or not S:Text(actual) or actual~=value or not current() then return nil end
  if not S:Readable(locked) or type(locked)~="boolean" or not S:Readable(secure) or type(secure)~="boolean"
   or not S:Readable(readonly) or type(readonly)~="boolean" then return nil end
  return actual,not locked and not secure and not readonly
 end
 local value,writable=observed()
 if not current() then return false,"CVAR_OWNERSHIP_SUPERSEDED" end
 if value==nil then row.status="RESTORE_PENDING";return false,"CVAR_STATE_UNAVAILABLE" end
 if conflict or written and value~=written or not written and value~=attempt and value~=original then
  -- A newer native/user writer owns this value. Keep the conflict receipt so
  -- automatic acquisition cannot immediately seed over the user's choice.
  row.conflict=true;row.status="EXTERNAL_PRESERVED";return true,"EXTERNAL_PRESERVED"
 end
 if value==original then journal[key]=nil;return true,"COMPLETE" end
 if not writable then row.status="RESTORE_PENDING";return false,"CVAR_NOT_WRITABLE" end
 local again,stillWritable=observed()
 if again~=(written or attempt) or not stillWritable or not current() then return false,"CVAR_STATE_CHANGED" end
 local okay,success=pcall(set,key,original)
 if not current() then return false,"CVAR_OWNERSHIP_SUPERSEDED" end
 local after=observed()
 if okay and S:Readable(success) and success==true and after==original and current() then
  journal[key]=nil;return true,"COMPLETE"
 end
 row.status="RESTORE_PENDING";return false,"CVAR_RESTORE_PENDING"
end
function R:Report()
 local lines={"MIRAGE_REWORK=3","milestone=M06","target="..(M.BuildInfo and M.BuildInfo.target or "Forever:1.60.1:70959:16001"),
  "reviewed_builds=70862,70888,70938,70959,71037","checkpoint_origin=Forever:1.60.1:70862:16001","native=NOT_RUN",
  "storage="..(self.storageReady and "READY" or "UNAVAILABLE"),"migration="..reason(self.migrationStatus or "NOT_STARTED"),"scope=all_actions,primary_units,party_raid,nameplates,minimap,combat_displays,maps,chat,tooltips,objectives,inventory,task_windows,character_progression,social_system,secondary_windows"}
 lines[#lines+1]="lifecycle="..(self.lifecycleBlocked and "PAUSED" or self.lastError and "RETRYING" or "READY")
  .."; attempts="..(self.lifecycleAttempts or 0).."/3; last_failure_phase="..reason(self.lastLifecyclePhase or "NONE")
  .."; editor_observation="..(self.editorObservationFailed and "UNKNOWN" or reason(self.editorObservation or "NOT_OBSERVED"))
  .."; editor_observer_failures="..(self.editorObservationFailures or 0)
  .."; configure_observation_attempts="..(self.configurePlanningAttempts or 0).."/3"
  .."; superseded_callbacks="..(self.supersededCallbacks or 0)
  .."; health_observer_failures="..(self.healthObserverFailures or 0)
  .."; last_health_observer="..reason(self.lastHealthObserver or "NONE")
 if self.CombatLeases and self.CombatLeases.AssetReport then lines[#lines+1]="texture_asset_contracts="..self.CombatLeases:AssetReport() end
 for _,id in ipairs(self.order) do
  local row=self.providers[id]
  local observed,selected=pcall(self.Selected,self,id)
  local enabled=observed and type(selected)=="boolean" and tostring(selected) or "UNKNOWN"
  lines[#lines+1]=id.."="..row.state..":"..row.reason..":faults="..row.faults
  lines[#lines+1]=id.."_readiness="..(row.readiness or "WAITING")..":"..(row.readinessReason or "NOT_STARTED").."; enabled="..enabled.."; native=NOT_RUN"
  lines[#lines+1]=id.."_runtime_ticks="..(row.runtimeTicks or 0).."; work="..(row.workTicks or 0).."; idle="..(row.idleTicks or 0).."; fallback_interval="..tostring(tickIntervals[id] or .50)
   .."; settled_before_dispatch="..(row.suppressedTicks or 0).."; demand="..(type(row.object.NeedsRuntimeTick)=="function" and "PROVIDER" or "LEGACY")
  lines[#lines+1]=id.."_layout_dispatch="..reason(row.layoutDispatch or "NOT_RUN").."; calls="..(row.layoutCalls or 0)
   .."; failures="..(row.layoutFailures or 0).."; skipped="..(row.layoutSkips or 0).."; surface="..(row.layoutSurface or "NONE")
  local counts={};local failures={}
  for key,state in pairs(row.object.surfaceStates or {}) do
   counts[state.kind]=(counts[state.kind] or 0)+1
   if state.kind=="PARTIAL" or state.kind=="DEFERRED_HANDOFF" or state.kind=="CONFLICT" or state.kind=="FAULT" then
    failures[#failures+1]={key=key,kind=state.kind,reason=state.reason}
   end
  end
  local totals={};for _,kind in ipairs({"READY","EMPTY","WAITING","DEFERRED_COMBAT","DEFERRED_HANDOFF","PARTIAL","CONFLICT","FAULT"}) do totals[#totals+1]=kind..":"..(counts[kind] or 0) end
  lines[#lines+1]=id.."_surface_health="..table.concat(totals,",")
  table.sort(failures,function(a,b) return a.key<b.key end)
  for i=1,math.min(12,#failures) do local failure=failures[i];lines[#lines+1]=id.."_surface="..failure.key..":"..failure.kind..":"..failure.reason end
  if #failures>12 then lines[#lines+1]=id.."_additional_surface_failures="..(#failures-12) end
  if row.object.status then lines[#lines+1]=id.."_detail="..reason(row.object.status) end
  if row.pending then lines[#lines+1]=id.."_release="..(row.releaseAttempts or 0).."/3:"..reason(row.releaseDetail or row.reason) end
  if type(row.object.Status)=="function" then
   local ok,detail=pcall(row.object.Status,row.object)
   if ok and S:Text(detail) then
    -- The fixed action families now retain their original refusal reasons.
    -- Keep that bounded evidence instead of silently dropping the whole line
    -- when a useful detailed report exceeds the old 2048-character threshold.
    local limit=id=="main" and 8192 or 4096
    lines[#lines+1]=id.."_coverage="..(#detail<=limit and detail or detail:sub(1,limit).."; REPORT_TRUNCATED")
   end
  end
  if self.CombatLeases and type(self.CombatLeases.Diagnostics)=="function" then
   local receiptOwners={};local seen={}
   local function add(owner,key)
    if not owner or seen[owner] then return end;seen[owner]=true
    local d=owner.leaseDiagnostics or {}
    if owner.releasePending or d.first then receiptOwners[#receiptOwners+1]={owner=owner,key=key} end
   end
   for _,owner in pairs(row.object.nodeOwners or {}) do add(owner,owner.rootName or "Window") end
   for _,owner in pairs(row.object.surfaceOwners or {}) do add(owner,owner.surfaceKey or "Tooltip") end
   for key,view in pairs(row.object.nativeCards or {}) do add(view.chromeOwner,key) end
   table.sort(receiptOwners,function(a,b) return a.key<b.key end)
   for i=1,math.min(8,#receiptOwners) do
    local entry=receiptOwners[i];local ok,detail=pcall(self.CombatLeases.Diagnostics,self.CombatLeases,entry.owner)
    if ok and S:Text(detail) and #detail<1024 then lines[#lines+1]=id.."_surface_leases="..entry.key..":"..detail end
   end
   local ok,detail=pcall(self.CombatLeases.Diagnostics,self.CombatLeases,row.object)
   if ok and S:Text(detail) and #detail<1024 then lines[#lines+1]=id.."_leases="..detail end
  end
 end
 if self.store and self.store.cvars then for key,row in pairs(self.store.cvars) do lines[#lines+1]="cvar_"..key.."="..reason(row.status) end end
 lines[#lines+1]="native_block_current="..self:NativeBlockSummary()
 lines[#lines+1]="native_block_unattributed="..tostring(self.unattributedNativeBlocks or 0).."; report_failures="..tostring(M.state and M.state.nativeBlockReportFailures or 0).."; policy=PER_DISPLAY_DEFERRED_RELEASE"
 local first=self.firstNativeBlock
 if first then
  lines[#lines+1]="native_block_first=provider:"..(self.providers[first.provider] and first.provider or "UNKNOWN").."/operation:"..(operations[first.operation] and first.operation or "UNCLASSIFIED").."/attribution:"..reason(first.attribution).."/observed_at:"..(S:Number(first.observedAt) and tostring(first.observedAt) or "UNKNOWN")
  lines[#lines+1]="native_block_first_source_locations="..retainedBlockLocations(first.locations)
 end
 for _,id in ipairs(self.order) do
  local row=self.providers[id]
  if row.nativeBlockCount then
   lines[#lines+1]="native_block_provider_"..id.."=count:"..row.nativeBlockCount.."/isolated:"..tostring(row.nativeBlocked==true).."/release_pending:"..tostring(row.nativeBlockPending==true)
  end
 end
 local block=self.lastNativeBlock or (self.store and self.store.lastNativeBlock)
 if type(block)=="table" then
  local build=S:Text(block.build) and #block.build<=100 and block.build:match("^[%w_.%-]+$") and block.build or "UNKNOWN"
  local observed=S:Number(block.observedAt) and tostring(block.observedAt) or "UNKNOWN"
  lines[#lines+1]="native_block_scope="..(self.lastNativeBlock==block and "CURRENT_SESSION" or "PERSISTED_RECORD").."; build="..build.."; observed_at="..observed
  lines[#lines+1]="native_block_event="..reason(block.event).."; source="..reason(block.source).."; operation="..(operations[block.operation] and block.operation or "UNCLASSIFIED").."; provider="..(self.providers[block.provider] and block.provider or "UNKNOWN")
  lines[#lines+1]="native_block_context="..reason(block.context).."; combat="..tostring(block.combat==true).."; native_edit="..tostring(block.nativeEdit==true)
  lines[#lines+1]="native_block_context_evidence=LAST_OBSERVED_EVENT_NOT_CALLER_PROOF"
  lines[#lines+1]="native_block_attribution="..reason(block.attribution).."; disposition="..reason(block.disposition).."; originating_taint_write=NOT_PROVEN"
  lines[#lines+1]="native_block_source_locations="..retainedBlockLocations(block.locations)
 end
 return table.concat(lines,"\n")
end
