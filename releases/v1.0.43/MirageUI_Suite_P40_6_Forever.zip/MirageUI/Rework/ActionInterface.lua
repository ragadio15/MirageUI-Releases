local _,M=...
-- beta52: a bottom-docked, compact action composition with one visibility
-- owner. Native control geometry is prepared outside combat; packing owned
-- hosts, mouseover and reserve access execute fixed secure snippets. Native action slots, page size (12), bindings and special input
-- remain unchanged. The standard composition shows ten cells in each bar.
local R,S=M.Rework,M.Safety
local A,F=R.MainAction,R.ActionFamilies
local I={id="ActionBars.interface",contextRecipient="COMBAT",width=468,height=252,maxHeight=450,reserveWidth=468,reserveHeight=254,taskFrames={},active=false}
M.ActionInterface=I
local function cfg(p) return (p or M.profile).modules.ActionBars end
local function num(v,d,lo,hi) return S:Number(v) and math.max(lo,math.min(hi,v)) or d end
local function read(o,k,kind,...)
 if o and type(o[k])=="function" then return S:Public(o[k],kind,o,...) end
end
-- x/y are centres in a single bottom-origin canvas. Related bars never acquire
-- separate scales or independently follow a movement/combat context decision.
I.specs={
 ["ActionBars.bar1"]={0,32,452,48,40,4,10},
 ["ActionBars.bar2"]={0,81,421,44,36,5,10},
 ["ActionBars.bar3"]={0,126,390,40,32,6,10},
 -- Drawer centres are relative to its own bottom. Native assignments and
 -- twelve-slot page identities remain intact, including the former columns.
 ["ActionBars.bar4"]={0,174,431,36,30,5,12},
 ["ActionBars.bar5"]={0,136,431,36,30,5,12},
 ["ActionBars.bar6"]={0,98,431,36,30,5,12},
 ["ActionBars.bar7"]={0,60,431,36,30,5,12},
 ["ActionBars.bar8"]={0,22,431,36,30,5,12},
 ["NativeControls.PetActionBar"]={0,166,312,34},
 ["NativeControls.StanceBar"]={0,203,312,34},
 ["NativeControls.MultiCastActionBarFrame"]={0,240,220,34},
 ["NativeControls.PossessActionBar"]={0,165,88,34},
 ["NativeControls.OverrideActionBar"]={0,86,452,112},
 ["NativeControls.MainMenuBarVehicleLeaveButton"]={0,165,38,34},
}
local function drawer(id) return id and id:match("^ActionBars%.bar[45678]$")~=nil end
-- Each host keeps its native ancestry/own Show state. Packing changes only
-- Mirage's hosts and passive backgrounds; it never calls a native frame's
-- SetSize/SetPoint/Hide. IsShown (not inherited IsVisible) describes applicable
-- companions even while the shared Mouseover parent is quiet.
I.packProgram=[[
 local reserveWidth=self:GetAttribute("mui-reserve-width") or 468
 local editing=self:GetAttribute("mui-editing") or self:GetAttribute("mui-cursor")
 for i=1,(self:GetAttribute("mui-task-count") or 0) do
  local f=self:GetFrameRef("mui-task"..i)
  if f and f:IsShown() then editing=true end
 end
 local grid=false
 for i=1,8 do
  local bar=self:GetFrameRef("mui-bar"..i)
  if bar then for j=1,12 do
   local b=bar:GetFrameRef("slot"..j)
   local native=b and b:GetFrameRef("mui-grid-native")
   local mask=native and tonumber(native:GetAttribute("showgrid"))
   if mask and mask>=2 then grid=true end
  end end
 end
 editing=editing or grid
 self:SetAttribute("mui-native-grid",grid)
 self:SetAttribute("mui-layout-editing",editing and true or false)
 local y,width,rows,topWidth=8,144,0,144
 for i=1,3 do
  local bar=self:GetFrameRef("mui-bar"..i)
  if bar then
   local present=bar:IsShown() and (editing or bar:GetAttribute("mui-row-content")~=false or bar:GetAttribute("mui-content-unknown"))
   bar:SetAttribute("mui-main-visible",present and true or false)
   local bg=bar:GetFrameRef("mui-row-background")
   if bg then if present then bg:Show() else bg:Hide() end end
   if present then
    local w=bar:GetAttribute("mui-pack-width") or 452
    local h=bar:GetAttribute("mui-pack-height") or 48
    bar:ClearAllPoints();bar:SetPoint("BOTTOM",self,"BOTTOM",0,y)
    bar:SetAttribute("mui-pack-y",y+h/2)
    if w>width then width=w end
    topWidth=w
    y=y+h;rows=rows+1
   end
  end
 end
 local mode=self:GetAttribute("state-muiinterface") or "ordinary"
 for i=1,6 do
  local host=self:GetFrameRef("mui-companion"..i)
  local native=self:GetFrameRef("mui-native-companion"..i)
  if host then
   local present=host:GetAttribute("mui-pack-ready") and native and native:IsShown()
    and native:GetParent()==self:GetFrameRef("mui-native-companion-parent"..i) and host:GetParent()==self
    and host:GetAttribute("mui-pack-applicable")~=false
    and (i<=3 or mode=="special")
   local bg=host:GetFrameRef("mui-row-background")
   if bg then if present then bg:Show() else bg:Hide() end end
   if present then
    local w=host:GetAttribute("mui-pack-width") or 312
    local h=host:GetAttribute("mui-pack-height") or 34
    host:ClearAllPoints();host:SetPoint("BOTTOM",self,"BOTTOM",0,y)
    host:SetAttribute("mui-pack-y",y+h/2)
    if w>width then width=w end
    topWidth=w
    y=y+h;rows=rows+1
   end
  end
 end
 local more=self:GetFrameRef("mui-more")
 local headerY=y
 -- The toggle follows the last row actually packed, including a current pet
 -- or stance row. The hover envelope keeps the widest row independently.
 if more then
  more:SetWidth(math.max(144,topWidth));more:SetHeight(22);more:ClearAllPoints();more:SetPoint("BOTTOM",self,"BOTTOM",0,headerY)
  local chip=self:GetFrameRef("mui-more-chip")
  if chip then chip:SetWidth(math.min(184,math.max(144,topWidth)-24)) end
 end
 self:SetAttribute("mui-more-width",topWidth)
 local height=headerY+28
 width=width+16
 -- The expanded tray and main body share one outer width and a one-unit
 -- seam. The sensor follows the painted main body, including its margins.
 if self:GetAttribute("mui-reserve-open")==true and width<reserveWidth then width=reserveWidth end
 self:SetAttribute("mui-packed-width",width);self:SetAttribute("mui-packed-height",height)
 self:SetAttribute("mui-packed-rows",rows);self:SetAttribute("mui-header-bottom",headerY)
 local bg=self:GetFrameRef("mui-background")
 if bg then bg:SetWidth(width);bg:SetHeight(height) end
 local sensors=self:GetFrameRef("mui-sensors")
 if sensors then sensors:SetWidth(width);sensors:SetHeight(height) end
 -- Native companions may appear in combat after a manual top-edge placement.
 -- Clamp only the owned origin against the predeclared stable viewport. The
 -- requested bottom remains immutable here, so disappearance restores it.
 -- "$parent" is an explicitly supported restricted SetPoint relative id; it
 -- does not require manufacturing a protected handle for native UIParent.
 local requested=self:GetAttribute("mui-origin-requested")
 local floor=self:GetAttribute("mui-origin-floor")
 local ceiling=self:GetAttribute("mui-origin-ceiling")
 local origin
 if requested and floor and ceiling then
  origin=math.max(floor,math.min(ceiling-height,requested))
 end
 local reserve=self:GetFrameRef("mui-reserve")
 if reserve then
  -- All original destinations reappear while editing. A confirmed empty row
  -- consumes no height during ordinary inspection. Unknown content is kept.
  local ry,reserveRows=8,0
  for i=8,4,-1 do
   local bar=self:GetFrameRef("mui-bar"..i)
   if bar then
    local present=bar:IsShown() and (editing or bar:GetAttribute("mui-row-content")~=false or bar:GetAttribute("mui-content-unknown"))
    bar:SetAttribute("mui-main-visible",present and true or false)
    local rb=bar:GetFrameRef("mui-row-background")
    if rb then if present then rb:Show() else rb:Hide() end end
    if present then
     bar:ClearAllPoints();bar:SetPoint("BOTTOM",reserve,"BOTTOM",0,ry)
     bar:SetAttribute("mui-pack-y",ry+18)
     ry=ry+36;reserveRows=reserveRows+1
    end
   end
  end
  local overflow=false
  for i=1,3 do
   local bar=self:GetFrameRef("mui-bar"..i)
   if bar and bar:IsShown() and (editing or bar:GetAttribute("mui-overflow-content")~=false or bar:GetAttribute("mui-content-unknown")) then overflow=true end
  end
  local overflowPanel=self:GetFrameRef("mui-overflow")
  if overflowPanel then
   if overflow then overflowPanel:ClearAllPoints();overflowPanel:SetPoint("BOTTOM",reserve,"BOTTOM",0,ry);overflowPanel:Show()
   else overflowPanel:Hide() end
  end
  if overflow then
   for i=1,3 do
    local bar=self:GetFrameRef("mui-bar"..i)
    if bar then for j=11,12 do
     local b=bar:GetFrameRef("slot"..j)
     if b then b:ClearAllPoints();b:SetPoint("BOTTOMLEFT",overflowPanel,"BOTTOMLEFT",8+((i-1)*2+j-11)*35,4) end
    end end
   end
   ry=ry+38;reserveRows=reserveRows+1
  end
  local rh=ry+22
  reserve:SetWidth(reserveWidth);reserve:SetHeight(rh)
  self:SetAttribute("mui-reserve-height",rh);self:SetAttribute("mui-reserve-rows",reserveRows)
  local reserveFloor=self:GetAttribute("mui-reserve-floor")
  local minimum=origin and reserveFloor and reserveFloor-origin or 0
  local available=origin and ceiling and ceiling-origin or 1000
  local maximum=available-rh
  -- A shared border replaces the old six-unit dead zone. Pointer movement
  -- through the join always remains in at least one native hover rectangle.
  local above,below=height-1,1-rh
  local bottom=above
  if above>maximum then
   if below>=minimum then bottom=below
   elseif origin and floor and ceiling and reserveFloor and self:GetAttribute("mui-reserve-open")==true then
    -- Neither side fits at a manually chosen midpoint. Move the joined
    -- composition by the smaller distance; never cover its main buttons.
    -- The authored origin remains unchanged and is restored on collapse.
    local upper=ceiling-height-rh+1
    local lower=reserveFloor+rh-1
    if upper>=floor and (lower>ceiling-height or math.abs(origin-upper)<=math.abs(origin-lower)) then
     origin=upper;bottom=above
    elseif lower<=ceiling-height then origin=lower;bottom=below
    else bottom=math.max(minimum,math.min(maximum,above)) end
   else bottom=math.max(minimum,math.min(maximum,above)) end
  end
  self:SetAttribute("mui-reserve-bottom",bottom)
  reserve:ClearAllPoints();reserve:SetPoint("BOTTOM",self,"BOTTOM",0,bottom)
 end
 if origin then
  local x=self:GetAttribute("mui-origin-x") or 0
  self:ClearAllPoints();self:SetPoint("CENTER","$parent","CENTER",x,origin+self:GetHeight()/2)
  if sensors then sensors:ClearAllPoints();sensors:SetPoint("BOTTOM","$parent","CENTER",x,origin) end
  self:SetAttribute("mui-origin-applied",origin)
 end
]]
I.syncProgram=[[
 local editing=self:GetAttribute("mui-layout-editing")
 -- Preparation reveals the main section and exposes empty destinations inside
 -- an already-open tray. Only the More actions button chooses tray expansion.
 local open=self:GetAttribute("mui-reserve-open")==true
 local reserve=self:GetFrameRef("mui-reserve")
 if reserve then if open then reserve:Show() else reserve:Hide() end end
 for i=1,8 do
  local bar=self:GetFrameRef("mui-bar"..i)
  if bar then
   bar:SetAttribute("mui-reserve-open",open and true or false)
   for j=1,12 do
    local b=bar:GetFrameRef("slot"..j)
    if b then b:SetAttribute("mui-grid-editor",editing and true or false);b:RunAttribute("mui-grid") end
   end
  end
 end
]]
-- Secure snippets retain the input boundary. Once native input is admitted,
-- the prepared engine animation supplies the common contextual fade. A combat
-- conceal must still retire the protected buttons immediately.
I.revealProgram=[[
 self:SetAttribute("mui-fade-wanted",true)
 self:SetAlpha(1);self:Show()
 if self:GetAttribute("mui-fade-ready") then self:CallMethod("MirageActionFade",true) end
]]
I.concealProgram=[[
 self:SetAttribute("mui-fade-wanted",false)
 if self:GetAttribute("mui-fade-ready") and self:GetAttribute("state-muicombat")~="combat" then
  self:CallMethod("MirageActionFade",false)
 else self:Hide() end
]]
-- SecureHoverDriver is an enter-then-leave tracker, not an elapsed timer.
-- A never-entered off-screen rectangle cannot expire. Reveal directly from
-- the fixed secure hover route; use native auto-hide only for its supported
-- on-screen leave behavior. No ordinary protected mutation/timer is needed.
I.visibilityProgram=[[
 self:RunAttribute("mui-pack")
 local mode=self:GetAttribute("state-muiinterface") or "ordinary"
 local sensors=self:GetFrameRef("mui-sensors")
 local active=self:GetAttribute("mui-active")
 local more=self:GetFrameRef("mui-more")
 local force=self:GetAttribute("mui-force") or self:GetAttribute("mui-editing") or self:GetAttribute("mui-cursor") or self:GetAttribute("mui-native-grid")
 local contextual=self:GetAttribute("mui-experience")==1
 local demand=false
 if contextual then
  if self:GetAttribute("state-muicombat")=="combat" then demand=self:GetAttribute("mui-context-combat")
  else demand=self:GetAttribute("mui-context") end
  demand=demand or self:GetAttribute("mui-force") or mode=="special"
 end
 for i=1,(self:GetAttribute("mui-task-count") or 0) do
  local f=self:GetFrameRef("mui-task"..i)
  if f and f:IsShown() then force=true end
 end
 local flyout=self:GetFrameRef("mui-flyout")
 if flyout and flyout:IsShown() then force=true end
 self:RunAttribute("mui-reserve-sync")
 if not active then
  self:SetAttribute("mui-hover-ready",false)
  self:UnregisterAutoHide();sensors:Hide()
  local reserve=self:GetFrameRef("mui-reserve");if reserve then reserve:Hide() end
  if more then more:Hide() end
  if self:GetAttribute("mui-fade-ready") then self:CallMethod("MirageActionStopFade") end
  self:SetAlpha(1)
  if self:GetAttribute("mui-recovery-access") then self:Show() else self:Hide() end
 elseif mode=="blocked" or self:GetAttribute("mui-tracker-workspace") then
  self:SetAttribute("mui-hover-ready",false)
  self:UnregisterAutoHide();self:Hide();sensors:Hide()
 elseif demand or force then
  self:SetAttribute("mui-hover-ready",false)
  if more then more:Show() end
  self:UnregisterAutoHide();self:RunAttribute("mui-reveal");sensors:Hide()
 else
  if more then more:Show() end
  sensors:Show()
  local reserve=self:GetFrameRef("mui-reserve")
  local over=sensors:IsUnderMouse() or reserve and reserve:IsShown() and reserve:IsUnderMouse()
  if over then
   self:SetAttribute("mui-hover-ready",true)
   self:RunAttribute("mui-reveal");self:UnregisterAutoHide();self:RegisterAutoHide(.35)
   self:AddToAutoHide(sensors)
   if reserve and reserve:IsShown() then self:AddToAutoHide(reserve) end
  else
   self:UnregisterAutoHide();self:RunAttribute("mui-conceal")
   self:SetAttribute("mui-hover-ready",false)
  end
 end
]]
I.nativeProgram=[[
 local active=self:GetAttribute("mui-active")
 local shown=self:IsShown() and self:GetAttribute("mui-fade-wanted")~=false
  and not self:GetAttribute("mui-tracker-workspace") and self:GetAttribute("state-muiinterface")~="blocked"
 for i=1,6 do
  local gate=self:GetFrameRef("mui-native-companion-gate"..i)
  if gate then
   gate:SetAttribute("mui-native-request",not active or shown)
   gate:RunAttribute("mui-native-present")
  end
 end
]]
I.visibilityProgram=I.visibilityProgram.."\n self:RunAttribute(\"mui-native-companions\")"
I.enterProgram=[[
 -- Native action buttons can take motion focus from the passive hotspot.
 -- Their wrappers retain the same local exit route without repacking the
 -- whole section or restarting the native hover driver on every cell entry.
 if control:GetAttribute("mui-active") and (not control:IsShown() or control:GetAttribute("mui-fade-wanted")==false) then control:RunAttribute("mui-interface") end
]]
I.leaveProgram=[[
 local sensors=control:GetFrameRef("mui-sensors")
 local reserve=control:GetFrameRef("mui-reserve")
 if not sensors or not sensors:IsUnderMouse() and not (reserve and reserve:IsShown() and reserve:IsUnderMouse()) then
  -- An enter/leave between native driver updates has never armed its leave
  -- countdown. Reconcile this observed exit now; preparation/flyouts retain
  -- their normal secure access, while a quiet section cannot stick open.
  control:RunAttribute("mui-interface")
 end
]]
I.reserveProgram=[[
 local hub=self:GetFrameRef("mui-interface")
 if hub:GetAttribute("mui-keybind-workspace") then return end
 hub:SetAttribute("mui-reserve-open",not hub:GetAttribute("mui-reserve-open"))
 -- Refresh the native auto-hide members too: an open drawer participates in
 -- inspection, while its closed/offscreen rectangle cannot retain a hover.
 hub:RunAttribute("mui-interface")
]]
I.combatProgram=[[
 if newstate=="combat" then
  self:SetAttribute("mui-tracker-workspace",false)
  -- Customize and manual inspection end on combat entry; carried-action
  -- editing cannot continue. Retire the exact inspection token so a later
  -- ordinary refresh cannot silently revive it after combat has ended.
  -- Task windows are checked live through their secure frame references.
  self:SetAttribute("mui-editing",false)
  self:SetAttribute("mui-cursor",false)
  self:SetAttribute("mui-force",false)
  if self:GetAttribute("mui-keybind-workspace") then
   self:SetAttribute("mui-keybind-workspace",false)
   local scale=self:GetAttribute("mui-keybind-prior-scale")
   if scale then
    self:SetScale(scale)
    local sensors=self:GetFrameRef("mui-sensors");if sensors then sensors:SetScale(scale) end
    self:SetAttribute("mui-origin-x",self:GetAttribute("mui-keybind-prior-mui-origin-x"))
    self:SetAttribute("mui-origin-requested",self:GetAttribute("mui-keybind-prior-mui-origin-requested"))
    self:SetAttribute("mui-origin-floor",self:GetAttribute("mui-keybind-prior-mui-origin-floor"))
    self:SetAttribute("mui-origin-ceiling",self:GetAttribute("mui-keybind-prior-mui-origin-ceiling"))
    self:SetAttribute("mui-reserve-floor",self:GetAttribute("mui-keybind-prior-mui-reserve-floor"))
    self:SetAttribute("mui-reserve-open",self:GetAttribute("mui-keybind-prior-open"))
   end
   for i=1,8 do
    local bar=self:GetFrameRef("mui-bar"..i)
    if bar then
     for j=1,12 do
      local b=bar:GetFrameRef("slot"..j)
      if b then b:SetAttribute("mui-keybind-editing",false) end
     end
     bar:RunAttribute("mui-bindings")
    end
   end
  end
  self:SetAttribute("mui-reveal-retired",self:GetAttribute("mui-reveal-token"))
 end
 self:RunAttribute("mui-interface")
]]
-- The tracker uses a quiet workspace, separate from keybind grid expansion.
-- Its combat state driver clears this gate before ordinary Lua can run again.
function I:SetTrackerWorkspace(active)
 if S:InCombat() then return false,"COMBAT_LOCKDOWN" end
 if not self.frame and not self:Create() then return false,"ACTION_INTERFACE_UNAVAILABLE" end
 local previous=read(self.frame,"GetAttribute","boolean","mui-tracker-workspace")==true
 local okay,result=pcall(function()
  self.frame:SetAttribute("mui-tracker-workspace",active==true)
  self.signature=nil
  return self:DispatchProgram()
 end)
 if okay and result==true then return true end
 -- A failed refresh may follow a successful attribute write. Return this
 -- one owned request before reporting failure; combat's secure driver already
 -- clears it if combat began synchronously during the attempt.
 if not S:InCombat() and read(self.frame,"GetAttribute","boolean","mui-tracker-workspace")== (active==true) then
  pcall(self.frame.SetAttribute,self.frame,"mui-tracker-workspace",previous)
  pcall(self.DispatchProgram,self)
 end
 return false,"TRACKER_VISIBILITY_UNCONFIRMED"
end
function I:Requested(p)
 return R:Selected("main",p or M.profile) and not (M.state and M.state.safe)
end
function I:OwnsHoverAt(x,y)
 -- Read-only arbitration for overlapping passive inspection rectangles. The
 -- secure action controller remains the sole writer of action visibility.
 -- A closed tray and the unused canonical envelope never claim the pointer.
 local groups=M.PresentationGroups
 if not S:Number(x) or not S:Number(y) or not self.controlsReady or not self.active or not A.active or not self:Requested()
  or not M.state.world or M.state.cinematic or not groups or type(groups.Contains)~="function"
  or read(self.frame,"GetAttribute","boolean","mui-active")~=true
  or read(self.frame,"GetAttribute","string","state-muiinterface")=="blocked" then return false end
 if read(self.sensors,"IsVisible","boolean")==true and groups:Contains(self.sensors,x,y) then return true end
 if read(self.frame,"IsVisible","boolean")~=true then return false end
 if groups:Contains(self.background or self.frame,x,y) then return true end
 return read(self.frame,"GetAttribute","boolean","mui-reserve-open")==true
  and read(self.reserve,"IsVisible","boolean")==true and groups:Contains(self.reserve,x,y) or false
end
-- Use the published native conversion once. UIParent units and physical
-- pixels are separate; neither UI scale nor an old editor envelope is a pixel
-- readability target. Missing optional pixel metadata retains logical fitting.
function I:PixelGeometry(w,h,uiScale)
 local managed=M.Managed
 local row=managed and managed.viewportStable or self.viewport
 if row and S:Number(row.width) and S:Number(row.height) and S:Number(row.scale)
  and math.abs(row.width-w)<.01 and math.abs(row.height-h)<.01 and S:Number(uiScale) and math.abs(row.scale-uiScale)<.00001
  and S:Number(row.physicalWidth) and row.physicalWidth>0 and S:Number(row.physicalHeight) and row.physicalHeight>0 then
  return row.physicalWidth,row.physicalHeight,768/row.physicalHeight
 end
 if not (managed and managed.Viewport) and type(GetPhysicalScreenSize)=="function" and S:Number(uiScale) and uiScale>0 then
  local ok,pw,ph=pcall(GetPhysicalScreenSize)
  if ok and S:Number(pw) and S:Number(ph) and pw>0 and ph>0 and pw<=131072 and ph<=131072 then return pw,ph,768/ph end
 end
end
function I:ParentFor(id)
 if not self.controlsReady then return nil end
 if drawer(id) then return self.reserve end
 if self.specs[id] then return self.frame end
end
function I:Metrics(p)
 p=p or M.profile
 -- A display-change callback may observe a minimized/window-transition size.
 -- All geometry in one transaction consumes the same settled viewport; an
 -- event never turns the hub's observed/effective scale into authored input.
 local w,h,uiScale
 if M.Managed and M.Managed.Viewport then w,h,uiScale=M.Managed:Viewport() end
 if not w then
  local last=self.viewport
  if last then w,h,uiScale=last.width,last.height,last.scale
  elseif not (M.Managed and M.Managed.Viewport) then
   w=read(UIParent,"GetWidth","number");h=read(UIParent,"GetHeight","number");uiScale=read(UIParent,"GetEffectiveScale","number")
  end
 end
 w=num(w,1920,320,20000);h=num(h,1080,240,20000)
 local fit=math.min(w/1920,h/1080)
 local pw,ph,pixelToUI=self:PixelGeometry(w,h,uiScale)
 local target
 if pixelToUI then
  -- 40px at1080p, ~46px at1440p, ~33px at720p. Larger displays gain
  -- readable controls without making their footprint grow as fast as area.
  target=math.max(32,math.min(64,40*math.sqrt(math.min(pw/1920,ph/1080))))
  fit=target/40*pixelToUI/uiScale
 end
 local c=cfg(p);local authored=p.layouts and p.layouts[self.id]
 local percent=num(c.interfaceScale,100,65,160)
 local scale=fit*percent/100
 local authoredWidth=authored and num(authored.width,self.width,240,1200) or self.width
 local authoredScale=authored and num(authored.scale,1,.6,1.6) or 1
 -- An editor resize is uniform; width is the authoritative group dimension.
 scale=scale*authoredWidth/self.width*authoredScale
 local requested=scale
 scale=math.min(scale,(w-16)/math.max(self.width,self.reserveWidth),(h-16)/(self.maxHeight+self.reserveHeight+6))
 local x=authored and num(authored.x,0,-.49,.49) or 0
 local y=authored and num(authored.y,0,-.49,.49) or -.5+(self.height/2+12)*scale/h
 local docked=c.interfaceDocked~=false
 local requestedY=y
 -- Eight physical pixels from the bottom; resizing grows the section upward.
 -- The invisible canonical editor canvas retains its 468x252 aspect contract.
 local inset=pixelToUI and 8*pixelToUI/uiScale or 8
 local hx=(self.width*scale/2+8)/w
 x=math.max(-.5+hx,math.min(.5-hx,x))
 if docked then x=0;y=-.5+(self.height*scale/2+inset)/h;requestedY=y
 else
  local visible=self:PackedHeight()
  local low=-.5+(self.height*scale/2+8)/h
  local high=.5-((visible-self.height/2)*scale+8)/h
  y=math.max(low,math.min(high,y))
 end
 local sizing={mode=pixelToUI and "PHYSICAL_RESPONSIVE" or "LOGICAL_FIT",physicalWidth=pw,physicalHeight=ph,
  pixelToUI=pixelToUI,uiScale=uiScale,target=target,authoredWidth=authoredWidth,authoredScale=authoredScale,
  percent=percent,scale=scale,docked=docked,inset=inset,positionY=requestedY,limited=scale<requested,mainPixels=pixelToUI and 40*scale*uiScale/pixelToUI or nil}
 if M.state.keybindWorkspace then
  -- Temporary workspace geometry never enters the saved layout. Leave side
  -- columns for the native spellbook and inventory/macro sources.
  local footer=M.KeybindWorkspace and M.KeybindWorkspace.panel
  local footerHeight=footer and (read(footer,"GetHeight","number") or 152)*(read(footer,"GetScale","number") or 1) or 152
  local compoundHeight=self:PackedHeight()+self.reserveHeight-1
  local low,high=footerHeight+32,h-20
  scale=math.min(math.max(scale*1.65,fit*1.35),w*.40/self.width,(high-low)/compoundHeight)
  scale=math.max(.25,scale);x=0
  -- Centre the complete expanded composition in the free middle column.
  -- The main bar's canonical origin is not its painted visual centre.
  y=(-h/2+low+(high-low-compoundHeight*scale)/2+self.height*scale/2)/h
  sizing.mode="KEYBIND_WORKSPACE";sizing.scale=scale;sizing.docked=false;sizing.positionY=y
 end
 return {x=x,y=y,width=self.width,height=self.height,scale=scale},w,h,sizing
end
function I:PackedHeight()
 return num(read(self.frame,"GetAttribute","number","mui-packed-height"),168,36,self.maxHeight)
end
function I:PackedWidth()
 return num(read(self.frame,"GetAttribute","number","mui-packed-width"),self.width,160,self.width)
end
function I:AuthoredLayout(p)
 p=p or M.profile
 local effective=self:Metrics(p)
 local saved=p.layouts and p.layouts[self.id] or {}
 local width=num(saved.width,self.width,240,1200)
 return {x=effective.x,y=effective.y,width=width,height=width*self.height/self.width,scale=num(saved.scale,1,.6,1.6)}
end
function I:Resolve(id,p)
 local l,w,h,sizing=self:Metrics(p)
 local reserveOffset,originShift=self:ReserveBottom(l,h,sizing)
 if id==self.id then
  local height=self:PackedHeight()
  return {x=l.x,y=l.y+(height-self.height)*l.scale/(2*h)+originShift*l.scale/h,width=self:PackedWidth(),height=height,scale=l.scale}
 end
 local spec=self.specs[id]
 if not spec then return nil end
 local extra=drawer(id) and reserveOffset or originShift
 local row=id==A.layoutID and A or F.families[id]
 local centre=row and read(row.frame,"GetAttribute","number","mui-pack-y") or spec[2]
 local rowWidth=row and read(row.frame,"GetAttribute","number","mui-pack-width") or spec[3]
 return {x=l.x+spec[1]*l.scale/w,y=l.y+(centre+extra-self.height/2)*l.scale/h,
  width=rowWidth or spec[3],height=spec[4],scale=l.scale}
end
function I:ReserveBottom(l,h,sizing)
 local bottom=l.y*h-self.height*l.scale/2
 local minimum=(-h/2+8-bottom)/l.scale
 local reserveHeight=num(read(self.frame,"GetAttribute","number","mui-reserve-height"),self.reserveHeight,30,self.reserveHeight)
 local maximum=(h/2-8-bottom)/l.scale-reserveHeight
 local above,below=self:PackedHeight()-1,1-reserveHeight
 if above<=maximum then return above,0 end
 if below>=minimum then return below,0 end
 if read(self.frame,"GetAttribute","boolean","mui-reserve-open")==true then
  -- Mirror the secure compound fit for read-only layout/occlusion consumers.
  -- Return the reserve offset from the authored main origin, plus the
  -- temporary main-origin shift separately. Neither value edits a profile.
  if not sizing then local _,_,_,currentSizing=self:Metrics();sizing=currentSizing end
  local origin=bottom/l.scale
  local floor=(-h/2+(sizing and sizing.docked and sizing.inset or 8))/l.scale
  local ceiling=(h/2-8)/l.scale
  local upper=maximum-above
  local lower=minimum-below
  local upperFits=origin+upper>=floor
  local lowerFits=origin+lower<=ceiling-self:PackedHeight()
  if upperFits and (not lowerFits or math.abs(upper)<=math.abs(lower)) then return above+upper,upper end
  if lowerFits then return below+lower,lower end
 end
 -- A collapsed tray is outside hover ownership. Its prospective rectangle
 -- may be clamped until explicit expansion fits the two visible sections.
 return math.max(minimum,math.min(maximum,above)),0
end
local function panel(f,alpha,border)
 local t=f:CreateTexture(nil,"BACKGROUND");t:SetAllPoints();t:SetColorTexture(.025,.032,.038,alpha or .72)
 f.miragePanelFill=t;f.miragePanelEdges={}
 if border==false then return end
 for _,side in ipairs({"TOP","BOTTOM","LEFT","RIGHT"}) do
  -- Match the minimap's one-unit gold frame exactly.
  local e=f:CreateTexture(nil,"BORDER");e:SetColorTexture(.91,.55,.18,.9)
  if side=="TOP" or side=="BOTTOM" then
   e:SetPoint(side.."LEFT",f,side.."LEFT",0,0);e:SetPoint(side.."RIGHT",f,side.."RIGHT",0,0);e:SetHeight(1)
  else e:SetPoint("TOP"..side,f,"TOP"..side,0,0);e:SetPoint("BOTTOM"..side,f,"BOTTOM"..side,0,0);e:SetWidth(1) end
  f.miragePanelEdges[#f.miragePanelEdges+1]=e
 end
end
-- One quiet outline frames the complete composition. Rows retain a soft
-- backing but no separate gold boxes. Every region is passive and follows
-- the secure packing frames, including pet/form changes during combat.
local function chromeStroke(f,layer,r,g,b,a)
 local t=f:CreateTexture(nil,layer or "BORDER")
 t:SetColorTexture(r or .64,g or .43,b or .22,a or .72)
 I.chromeStrokes=I.chromeStrokes or {};I.chromeStrokes[#I.chromeStrokes+1]=t
 return t
end
local function outline(f,alpha)
 local cut=7
 f.miragePanelEdges={};f.miragePanelCorners={}
 for _,side in ipairs({"TOP","BOTTOM","LEFT","RIGHT"}) do
  local t=chromeStroke(f,"BORDER",.79,.55,.27,alpha or .64)
  if side=="TOP" or side=="BOTTOM" then
   t:SetPoint(side.."LEFT",f,side.."LEFT",cut,0);t:SetPoint(side.."RIGHT",f,side.."RIGHT",-cut,0);t:SetHeight(1);t.mirageStrokeAxis="height"
  else
   t:SetPoint("TOP"..side,f,"TOP"..side,0,-cut);t:SetPoint("BOTTOM"..side,f,"BOTTOM"..side,0,cut);t:SetWidth(1);t.mirageStrokeAxis="width"
  end
  f.miragePanelEdges[#f.miragePanelEdges+1]=t
 end
 for _,corner in ipairs({{"TOPLEFT",1,-1,1},{"TOPRIGHT",-1,-1,-1},{"BOTTOMLEFT",1,1,-1},{"BOTTOMRIGHT",-1,1,1}}) do
  local t=chromeStroke(f,"BORDER",.91,.64,.30,alpha or .72)
  t:SetPoint("CENTER",f,corner[1],corner[2]*cut/2,corner[3]*cut/2)
  t:SetSize(cut*math.sqrt(2),1);t.mirageStrokeAxis="height"
  if type(t.SetRotation)=="function" then t:SetRotation(corner[4]*math.pi/4) end
  f.miragePanelCorners[#f.miragePanelCorners+1]=t
 end
end
function I:UpdateChrome(sizing)
 local scale=sizing and sizing.scale or 1
 local pixel=sizing and sizing.pixelToUI and sizing.uiScale and sizing.uiScale>0 and scale>0
  and sizing.pixelToUI/(sizing.uiScale*scale) or 1
 -- A small authored group can require more than three local units for one
 -- physical pixel. Keep the conversion exact at every admitted group scale.
 if not S:Number(pixel) or pixel<=0 then pixel=1 end
 if self.chromePixel==pixel then return end
 self.chromePixel=pixel
 for _,stroke in ipairs(self.chromeStrokes or {}) do
  if stroke.mirageStrokeAxis=="width" then stroke:SetWidth(pixel)
  else stroke:SetHeight(pixel) end
 end
 self.contourSignature=nil
end
local contourRows={"ActionBars.bar1","ActionBars.bar2","ActionBars.bar3","NativeControls.PetActionBar","NativeControls.StanceBar",
 "NativeControls.MultiCastActionBarFrame","NativeControls.PossessActionBar","NativeControls.OverrideActionBar","NativeControls.MainMenuBarVehicleLeaveButton"}
function I:UpdateContour()
 if not self.contour or not self.frame then return end
 -- The input envelope stays rectangular. Only passive paint follows the
 -- observed secure packing; it cannot move, hide or resize a native control.
 -- Keep only scalar geometry from the last sample. Native visibility and
 -- packing are still read on every pass, but unchanged 10 Hz samples need no
 -- row tables, sorting, signature strings or texture writes.
 local observed=self.contourObserved
 if not observed then observed={};self.contourObserved=observed end
 local changed=self.contourSignature==nil
 for index=1,9 do
  local width,height,y
  -- GetFrameRef belongs to the restricted HANDLE API, not ordinary Lua.
  -- These existing provider references identify the paint being observed;
  -- the secure program continues to control live packing and input.
  local row=index==1 and A or F.families[contourRows[index]]
  local f,bg=row and row.frame,row and row.interfaceBackground
  if f and read(f,"GetParent")==self.frame then
   if bg and read(bg,"GetParent")==f and read(bg,"IsShown","boolean")==true then
    width=read(f,"GetAttribute","number","mui-pack-width")
    height=read(f,"GetAttribute","number","mui-pack-height")
    y=read(f,"GetAttribute","number","mui-pack-y")
    if not S:Number(width) or not S:Number(height) or not S:Number(y) then width,height,y=nil,nil,nil end
   end
  end
  local row=observed[index]
  if not row then row={};observed[index]=row end
  if row[1]~=width or row[2]~=height or row[3]~=y then changed=true;row[1],row[2],row[3]=width,height,y end
 end
 local header=read(self.frame,"GetAttribute","number","mui-header-bottom") or 8
 local topWidth=read(self.frame,"GetAttribute","number","mui-more-width") or 144
 local pixel=self.chromePixel or 1
 if not changed and observed.header==header and observed.topWidth==topWidth and observed.pixel==pixel then return end
 observed.header,observed.topWidth,observed.pixel=header,topWidth,pixel
 local rows,signature={},{}
 for index=1,9 do
  local row=observed[index];local width,height,y=row[1],row[2],row[3]
  if width then
   rows[#rows+1]={half=width/2+8,bottom=y-height/2,top=y+height/2}
   signature[#signature+1]=width..":"..height..":"..y
  end
 end
 local key=table.concat(signature,"/")..":"..header..":"..topWidth..":"..pixel
 if key==self.contourSignature then return end
 self.contourSignature=key;self.contourSegments={}
 local points={}
 if #rows>0 then
  table.sort(rows,function(a,b) return a.bottom<b.bottom end)
  local first=rows[1]
  points={{-first.half+6,2},{-first.half,8}}
  for i=1,#rows-1 do
   local a,b=rows[i],rows[i+1]
   local seam=(a.top+b.bottom)/2
   points[#points+1]={-a.half,seam-5}
   points[#points+1]={-b.half,seam+5}
  end
  points[#points+1]={-rows[#rows].half,header+5}
  points[#points+1]={-topWidth/2+2,header+11}
 else points={{-70,2},{-78,8},{-70,header+11}} end
 local n=0
 local function segment(x1,y1,x2,y2)
  n=n+1;local t=self.contour[n];if not t then return end
  local dx,dy=x2-x1,y2-y1;local length=math.sqrt(dx*dx+dy*dy)
  if length<.05 then t:Hide();return end
  t:ClearAllPoints();t:SetPoint("CENTER",I.contourFrame,"BOTTOM",(x1+x2)/2,(y1+y2)/2)
  t:SetSize(length,I.chromePixel or 1)
  if t.SetRotation then
   local angle=dx==0 and (dy>=0 and math.pi/2 or -math.pi/2) or math.atan(dy/dx)
   if dx<0 then angle=angle+math.pi end
   t:SetRotation(angle)
  end
  t:Show();I.contourSegments[#I.contourSegments+1]={x1,y1,x2,y2}
 end
 for i=1,#points-1 do local a,b=points[i],points[i+1];segment(a[1],a[2],b[1],b[2]);segment(-a[1],a[2],-b[1],b[2]) end
 segment(points[1][1],2,-points[1][1],2)
 for i=n+1,#self.contour do self.contour[i]:Hide() end
end
function I:CreateContour(hub)
 local f=CreateFrame("Frame",nil,hub);f:SetAllPoints(hub);f:EnableMouse(false)
 self.contourFrame=f;self.contour={}
 for i=1,48 do
  local t=chromeStroke(f,"BORDER",.79,.55,.27,.64);t.mirageStrokeAxis="height";t:Hide();self.contour[i]=t
 end
 -- Secure packing can change during combat. Paint at most ten times a
 -- second, and only rewrite segments after the packed geometry changes.
 local elapsed=0
 f:SetScript("OnUpdate",function(_,dt) elapsed=elapsed+dt;if elapsed>=.1 then elapsed=0;I:UpdateContour() end end)
end
function I:CreateMoreChrome(more,hub)
 -- The full top row remains the established secure click/hover target; the
 -- visible control is a compact tab with a small chevron and fine side rails.
 panel(more,0,false)
 local chip=CreateFrame("Frame",nil,more,"SecureHandlerBaseTemplate")
 self.moreChip=chip;chip:EnableMouse(false);chip:SetSize(184,18);chip:SetPoint("CENTER",more,"CENTER",0,0)
 panel(chip,.84,false);chip.miragePanelFill:ClearAllPoints();chip.miragePanelFill:SetPoint("TOPLEFT",4,-1);chip.miragePanelFill:SetPoint("BOTTOMRIGHT",-4,1)
 outline(chip,.78);hub:SetFrameRef("mui-more-chip",chip)
 for _,side in ipairs({"LEFT","RIGHT"}) do
  local rail=chromeStroke(more,"BORDER",.78,.54,.26,.62);rail:SetHeight(1);rail.mirageStrokeAxis="height"
  if side=="LEFT" then rail:SetPoint("LEFT",more,"LEFT",2,0);rail:SetPoint("RIGHT",chip,"LEFT",-6,0)
  else rail:SetPoint("LEFT",chip,"RIGHT",6,0);rail:SetPoint("RIGHT",more,"RIGHT",-2,0) end
 end
 self.moreLabel=chip:CreateFontString(nil,"OVERLAY");self.moreLabel:SetFont(STANDARD_TEXT_FONT,11,"")
 self.moreLabel:SetPoint("LEFT",chip,"LEFT",9,0);self.moreLabel:SetPoint("RIGHT",chip,"RIGHT",-22,0);self.moreLabel:SetJustifyH("CENTER")
 self.moreLabel:SetText("More actions")
 if self.moreLabel.SetTextColor then self.moreLabel:SetTextColor(.95,.80,.53,1) end
 self.moreChevrons={}
 for i,angle in ipairs({math.pi/4,-math.pi/4}) do
  local t=chromeStroke(chip,"ARTWORK",.95,.75,.40,.95);t:SetSize(6,1);t.mirageStrokeAxis="height"
  t:SetPoint("CENTER",chip,"RIGHT",i==1 and -15 or -11,1)
  if type(t.SetRotation)=="function" then t:SetRotation(angle) end
  self.moreChevrons[#self.moreChevrons+1]=t
 end
end
function I:CanCleanupRoots()
 -- Native action ancestry remains original in P21. A pending paint/input
 -- receipt still depends on our secure controller and must finish first.
 if A.lease then return false,"NATIVE_RELEASE_PENDING" end
 for _,row in pairs(F.families) do
  if row.interfacePresentation or row.ordinary and row.lease then return false,"NATIVE_RELEASE_PENDING"
  elseif row.lease then
   -- Pure cosmetic debt can retire independently once native anchors no
   -- longer reference this composition. Keep uncertain geometry journals.
   if row.lease.pointWritten or row.lease.pointAttempt or row.lease.pointUnobserved then return false,"NATIVE_RELEASE_PENDING" end
   local native=row.native or _G[row.name]
   local parent,state=read(native,"GetParent")
   if state~="KNOWN" or parent==row.frame then return false,"NATIVE_RELEASE_PENDING" end
  end
 end
 return true
end
local cleanupRoots=I.CanCleanupRoots
I.cleanupGuard=function()
 if not rawequal(M.ActionInterface,I) or not rawequal(M.Rework,R) or not rawequal(R.MainAction,A)
  or not rawequal(R.ActionFamilies,F) or not rawequal(I.CanCleanupRoots,cleanupRoots) then return false,"OWNERSHIP_CHANGED" end
 return cleanupRoots(I)
end
function I:ObserveHoverInput(frame)
 if S:InCombat() or not S:Frame(frame,false) or not self.frame then return false end
 self.hoverInputs=self.hoverInputs or setmetatable({},{__mode="k"})
 local hooks=self.hoverInputs[frame] or {};self.hoverInputs[frame]=hooks
 if hooks.OnEnter and hooks.OnLeave then return true end
 for script,program in pairs({OnEnter=self.enterProgram,OnLeave=self.leaveProgram}) do
  if not hooks[script] then
   local ok=pcall(SecureHandlerWrapScript,frame,script,self.frame,program)
   if not ok then self.hoverHookFailures=math.min(999,(self.hoverHookFailures or 0)+1);return false end
   hooks[script]=true
  end
 end
 return true
end
function I:PrepareFade()
 local effects,hub=M.Effects,self.frame
 if S:InCombat() or not hub or not effects or type(effects.PrepareProtected)~="function" then return false end
 local profile=M.profile
 local duration=type(effects.ContextDuration)=="function" and effects:ContextDuration() or nil
 if self.fadeProfile==profile and self.fadeReady and self.fadeDuration==duration then return true end
 local function current()
  return M.ActionInterface==I and I.frame==hub and M.profile==profile and I.controlsReady and not M.state.safe
 end
 local prepared=effects:PrepareProtected(self,hub,current)
 if not current() then return false end
 self.fadeReady=prepared==true;self.fadeProfile=profile;self.fadeDuration=duration
 hub:SetAttribute("mui-fade-ready",self.fadeReady)
 if not prepared then return false end
 hub.MirageActionFade=function(_,shown)
  if not current() then return end
  local accepted=effects:TransitionProtected(I,hub,shown)
  if not accepted and not S:InCombat() and current() then hub:SetAlpha(shown and 1 or 0);hub:SetShown(shown) end
 end
 hub.MirageActionStopFade=function() effects:StopProtected(I,hub) end
 hub.MirageActionHidden=function() effects:StopProtected(I,hub,0) end
 return true
end
function I:Create()
 -- Named secure widgets cannot be destroyed after a partial construction.
 -- Retain native controls rather than treating one allocated root as proof
 -- that its clock, wrappers and secure input references are ready.
 if self.frame then return self.controlsReady==true end
 if S:InCombat() then return false end
 local hub=CreateFrame("Frame","MirageActionInterface",UIParent,"SecureHandlerStateTemplate")
 self.frame=hub;hub:Hide();hub:EnableMouse(false)
 assert(S:InitializeSecureHandler(hub),"ACTION_INTERFACE_HANDLER_UNAVAILABLE")
 local background=CreateFrame("Frame",nil,hub,"SecureHandlerBaseTemplate")
 self.background=background;background:EnableMouse(false);background:SetPoint("BOTTOM",hub,"BOTTOM",0,0)
 background:SetFrameLevel(hub:GetFrameLevel());panel(background,0,false);hub:SetFrameRef("mui-background",background)
 self:CreateContour(hub)
 local sensors=CreateFrame("Frame","MirageActionInterfaceSensors",UIParent,"SecureHandlerStateTemplate")
 self.sensors=sensors;sensors:Hide();sensors:EnableMouse(false)
 assert(S:InitializeSecureHandler(sensors),"ACTION_SENSOR_HANDLER_UNAVAILABLE")
 hub:SetFrameRef("mui-sensors",sensors)
 local reserve=CreateFrame("Frame","MirageActionReserve",hub,"SecureHandlerStateTemplate")
 self.reserve=reserve;reserve:Hide();reserve:SetSize(self.reserveWidth,self.reserveHeight)
 reserve:SetFrameLevel(hub:GetFrameLevel()+10)
 reserve:SetPoint("BOTTOM",hub,"BOTTOM",0,self.height-1);panel(reserve,.16,false);outline(reserve,.58)
 reserve.miragePanelFill:ClearAllPoints();reserve.miragePanelFill:SetPoint("TOPLEFT",7,-7);reserve.miragePanelFill:SetPoint("BOTTOMRIGHT",-7,7)
 hub:SetFrameRef("mui-reserve",reserve)
 local overflow=CreateFrame("Frame",nil,reserve,"SecureHandlerBaseTemplate")
 self.overflow=overflow;overflow:EnableMouse(false);overflow:SetSize(221,38);overflow:SetFrameLevel(reserve:GetFrameLevel()+1)
 panel(overflow,.24,false);hub:SetFrameRef("mui-overflow",overflow)
 local title=reserve:CreateFontString(nil,"OVERLAY");title:SetFont(STANDARD_TEXT_FONT,11,"")
 title:SetPoint("TOPLEFT",8,-7);title:SetText("MORE ACTIONS")
 hub:SetAttribute("mui-pack",self.packProgram)
 hub:SetAttribute("mui-reserve-sync",self.syncProgram)
 hub:SetAttribute("mui-interface",self.visibilityProgram)
 hub:SetAttribute("mui-native-companions",self.nativeProgram)
 hub:SetAttribute("mui-reveal",self.revealProgram)
 hub:SetAttribute("mui-conceal",self.concealProgram)
 hub:SetAttribute("_onstate-muipack",[[ self:RunAttribute("mui-pack") ]])
 hub:SetAttribute("_onstate-muiinterface",[[ self:RunAttribute("mui-interface") ]])
 hub:SetAttribute("_onstate-muirefresh",[[ self:RunAttribute("mui-interface") ]])
 hub:SetAttribute("_onstate-muicombat",self.combatProgram)
 hub:SetAttribute("mui-active",false);hub:SetAttribute("mui-experience",2)
 hub:SetAttribute("mui-reserve-width",self.reserveWidth)
 hub:SetAttribute("mui-reserve-open",false);hub:SetAttribute("mui-task-count",0)
 SecureHandlerWrapScript(hub,"OnHide",hub,[[
  self:SetAttribute("mui-hover-ready",false);self:SetAttribute("mui-fade-wanted",false)
  self:RunAttribute("mui-native-companions")
  if self:GetAttribute("mui-fade-ready") then self:CallMethod("MirageActionHidden") end
 ]])
 local more=CreateFrame("Button","MirageActionReserveToggle",hub,"SecureHandlerClickTemplate")
 self.more=more;more:SetSize(452,22);more:SetPoint("BOTTOM",hub,"BOTTOM",0,224)
 hub:SetFrameRef("mui-more",more)
 assert(S:InitializeSecureHandler(more),"ACTION_RESERVE_HANDLER_UNAVAILABLE")
 more:RegisterForClicks("AnyUp");more:SetFrameRef("mui-interface",hub)
 more:SetAttribute("_onclick",self.reserveProgram)
 self:CreateMoreChrome(more,hub)
 more:SetScript("OnEnter",function(f)
  for _,edge in ipairs(self.moreChip.miragePanelEdges) do edge:SetColorTexture(.98,.72,.35,1) end
  if GameTooltip then
   GameTooltip:SetOwner(f,"ANCHOR_TOP");GameTooltip:SetText("More actions")
   GameTooltip:AddLine("Click to expand or collapse extra actions. Opening bags, the spellbook or other preparation windows reveals the main section and keeps this tray in its chosen state.",.82,.84,.85,true)
   GameTooltip:AddLine("Keeps slots 11–12 and action bars 4–8 available, including your former vertical bars. Existing actions and shortcuts are unchanged.",.82,.84,.85,true)
   GameTooltip:Show()
  end
 end)
 more:SetScript("OnLeave",function(f)
  for _,edge in ipairs(self.moreChip.miragePanelEdges) do edge:SetColorTexture(.79,.55,.27,.78) end
  if GameTooltip and type(GameTooltip.IsOwned)=="function" and GameTooltip:IsOwned(f) then GameTooltip:Hide() end
 end)
 assert(self:ObserveHoverInput(more),"ACTION_MORE_HOVER_UNAVAILABLE")
 self.hotspots={}
 do
  -- One contiguous rectangle keeps the pet/banner area and every packed row
  -- in the same local inspection region while native controls retain input.
  local sensor=CreateFrame("Frame",nil,sensors,"SecureHandlerEnterLeaveTemplate")
  assert(S:InitializeSecureHandler(sensor),"ACTION_HOVER_HANDLER_UNAVAILABLE")
  sensor:EnableMouse(true)
  if sensor.SetPropagateMouseClicks then sensor:SetPropagateMouseClicks(true) end
  sensor:SetAllPoints(sensors)
  assert(self:ObserveHoverInput(sensor),"ACTION_SENSOR_HOVER_UNAVAILABLE")
  self.hotspots[#self.hotspots+1]=sensor
 end
 self.surface={id=self.id,label="Action bar interface",module="ActionBars",frame=hub,security="SECURE_PREDECLARED",
  hoverFrame=background,occlusionFrame=background,editable=true,minWidth=240,minHeight=129,groups={combat=true},layout={x=0,y=-.36,width=self.width,height=self.height,scale=1},reworkProvider=A}
 M.CVE:Register(self.surface);F.layouts[self.id]=true
 for _,root in ipairs({hub,reserve,sensors}) do M:TrackRoot("ActionBars",root,false,self.cleanupGuard) end
 RegisterStateDriver(hub,"muiinterface","[petbattle] blocked; [vehicleui] special; [overridebar] special; [possessbar] special; [shapeshift] special; ordinary")
 RegisterStateDriver(hub,"muicombat","[combat] combat; clear")
 self.controlsReady=true
 return true
end
function I:DispatchProgram(packOnly)
 if not self.frame then return false end
 if S:InCombat() then self.pending=true;return false end
 -- RunAttribute belongs to restricted handles, not ordinary frame objects.
 -- The native state handler synchronously enters our predeclared snippet.
 -- Use distinct bounded tokens so repeated requests still dispatch; keep a
 -- geometry-only pass separate from the visibility/input reconciliation.
 local key=packOnly and "packRevision" or "revision"
 self[key]=math.floor(num(self[key],0,0,2147483647))%2147483647+1
 self.frame:SetAttribute(packOnly and "state-muipack" or "state-muirefresh",tostring(self[key]))
 return true
end
function I:Layout(p)
 if S:InCombat() or not self.frame then return false end
 if M.Managed and M.Managed.Viewport then
  local w,h,scale=M.Managed:Viewport()
  if not w then self.viewportPending=true;return false,"VIEWPORT_PENDING" end
  self.viewport={width=w,height=h,scale=scale};self.viewportPending=nil
 end
 local l,w,h,sizing=self:Metrics(p)
 self:UpdateChrome(sizing)
 local prior=self.layout
 local geometryCurrent=read(self.frame,"GetParent")==UIParent and read(self.sensors,"GetParent")==UIParent
  and read(self.frame,"GetScale","number")==l.scale and read(self.sensors,"GetScale","number")==l.scale
  and read(self.frame,"GetWidth","number")==l.width and read(self.frame,"GetHeight","number")==l.height
 if prior and prior.x==l.x and prior.y==l.y and prior.width==l.width and prior.height==l.height
  and prior.scale==l.scale and self.layoutWidth==w and self.layoutHeight==h
  and self.layoutPositionY==sizing.positionY and self.layoutDocked==sizing.docked and geometryCurrent then
  self.sizing=sizing;return true
 end
 for _,f in ipairs({self.frame,self.sensors}) do
  if read(f,"GetParent")~=UIParent then f:SetParent(UIParent) end
  f:SetScale(l.scale);f:ClearAllPoints()
 end
 self.frame:SetSize(l.width,l.height)
 self.frame:SetPoint("CENTER",UIParent,"CENTER",l.x*w/l.scale,l.y*h/l.scale)
 -- The mouse sensor shares the actual compact bottom edge, independently of
 -- the hidden parent. It never leaves an invisible old pet/form band active.
 self.sensors:SetPoint("BOTTOM",UIParent,"CENTER",l.x*w/l.scale,l.y*h/l.scale-self.height/2)
 self.sensors:SetFrameLevel(math.max(0,self.frame:GetFrameLevel()-1))
 self.frame:SetAttribute("mui-origin-x",l.x*w/l.scale)
 self.frame:SetAttribute("mui-origin-requested",sizing.positionY*h/l.scale-self.height/2)
 self.frame:SetAttribute("mui-origin-floor",(-h/2+(sizing.docked and sizing.inset or 8))/l.scale)
 self.frame:SetAttribute("mui-origin-ceiling",(h/2-8)/l.scale)
 self.frame:SetAttribute("mui-reserve-floor",(-h/2+8)/l.scale)
 if not self:DispatchProgram(true) then return false,"COMBAT_LOCKDOWN" end
 self.layout=l;self.layoutWidth=w;self.layoutHeight=h;self.layoutPositionY=sizing.positionY;self.layoutDocked=sizing.docked
 self.sizing=sizing;return true
end
function I:RowBackground(row)
 if row.interfaceBackground then return row.interfaceBackground end
 local bg=CreateFrame("Frame",nil,row.frame,"SecureHandlerBaseTemplate")
 bg:EnableMouse(false);bg:SetFrameLevel(row.frame:GetFrameLevel());bg:SetAllPoints(row.frame);panel(bg,.24,false)
 row.interfaceBackground=bg;row.frame:SetFrameRef("mui-row-background",bg)
 return bg
end
function I:Adopt(row)
 if S:InCombat() or not self.frame or not row.frame then return false end
 local index=row.index or 1
 row.frame:SetParent(index>=4 and self.reserve or self.frame)
 row.frame:SetFrameLevel((index>=4 and self.reserve or self.frame):GetFrameLevel()+1)
 self:RowBackground(row)
 self.frame:SetFrameRef("mui-bar"..index,row.frame)
 for _,button in ipairs(row.buttons or {}) do
  if not self:ObserveHoverInput(button) then return false end
 end
 row.frame:SetAttribute("mui-reserve-open",false)
 row.frame:SetFrameRef("mui-interface",self.frame)
 if not row.interfacePackHooked then
  for _,event in ipairs({"OnShow","OnHide"}) do
   SecureHandlerWrapScript(row.frame,event,self.frame,[[ return "mui-pack",true ]],[[ control:RunAttribute("mui-interface") ]])
  end
  row.interfacePackHooked=true
 end
 return true
end
function I:Place(surface,p)
 if S:InCombat() then surface.layoutPending=true;return false end
 local ready,why=self:Layout(p)
 if not ready then surface.layoutPending=true;return false,why end
 if surface.id==self.id then surface.layoutPending=nil;return true end
 local spec=self.specs[surface.id]
 if not spec then return false end
 local width=spec[3]
 local row=F.families[surface.id]
 if row and row.name=="StanceBar" then
  local count=row.formCount and row.formCount>0 and row.formCount or 10
  width=count*26+(count-1)*4+16
 end
 local f=surface.frame;f:SetScale(1);f:SetSize(width,spec[4]);f:ClearAllPoints()
 f:SetAttribute("mui-pack-width",width);f:SetAttribute("mui-pack-height",spec[4])
 if drawer(surface.id) then f:SetPoint("CENTER",self.reserve,"BOTTOM",spec[1],spec[2])
 else f:SetPoint("CENTER",self.frame,"BOTTOM",spec[1],spec[2]) end
 surface.layoutPending=nil
 if surface.OnLayout then surface.OnLayout(surface,{x=spec[1],y=spec[2],width=width,height=spec[4],scale=1}) end
 if not self:DispatchProgram() then surface.layoutPending=true;return false,"COMBAT_LOCKDOWN" end
 return true
end
function I:Arrange(row)
 if S:InCombat() then row.pendingConfigure=true;return false,"COMBAT_LOCKDOWN" end
 local spec=self.specs[row.layoutID];if not spec then return false end
 local c=cfg();local index=row.index or 1;local count=index<=3 and 10 or 12
 local size,gap,columns=spec[5],spec[6],spec[7]
 local rows=math.ceil(count/columns)
 local usedW=columns*size+(columns-1)*gap;local usedH=rows*size+(rows-1)*gap
 local left=(spec[3]-usedW)/2;local top=-(spec[4]-usedH)/2
 row.frame:SetAlpha(num(c.alpha,1,.2,1))
 for slot,b in ipairs(row.buttons) do
  local reserved=index>=4 or slot>10
  b:SetAttribute("mui-fixed-slot",index<=3 and slot<=10)
  b:SetAttribute("mui-reserve-slot",reserved)
  b:SetAttribute("mui-overflow-slot",index<=3 and slot>10)
  b:SetAttribute("mui-visible-slot",true)
  b:ClearAllPoints();b:SetScale(1);b:SetSize(reserved and 30 or size,reserved and 30 or size)
  b:SetFrameLevel(reserved and self.reserve:GetFrameLevel()+4 or row.frame:GetFrameLevel()+1)
  if index<=3 and slot>10 then
   local n=(index-1)*2+(slot-11)
   b:SetPoint("TOPLEFT",self.reserve,"TOPLEFT",(self.reserveWidth-205)/2+n*35,-27)
  else b:SetPoint("TOPLEFT",row.frame,"TOPLEFT",left+((slot-1)%columns)*(size+gap),top-math.floor((slot-1)/columns)*(size+gap)) end
  A:ArrangeKeyLabels(b,c,M.state.keybindWorkspace);b.macro:SetWidth((reserved and 30 or size)-4)
  b.hotkey:SetShown(c.showHotkeys~=false);b.macro:SetShown(c.hideMacroText~=true);b.count:Show()
  b:SetAttribute("mui-editable",c.allowRearrange==true)
  b:SetAttribute("flyoutDirection",columns==1 and (spec[1]>0 and "LEFT" or "RIGHT") or "UP")
 end
 row.layout={width=spec[3],height=spec[4],scale=1,columns=columns,rows=rows,buttonSize=size,gap=gap,count=count}
 row.gridDirty=true
 if row.active then row:RefreshGrid(true) end
 return true
end
local companionOrder={PetActionBar=1,StanceBar=2,MultiCastActionBarFrame=3,PossessActionBar=4,OverrideActionBar=5,MainMenuBarVehicleLeaveButton=6}
function I:SpecialReady(row)
 local index=companionOrder[row.name]
 if not index or S:InCombat() or not self.frame or not row.native or not row.active then return end
 if row.native~=_G[row.name] then row.frame:SetAttribute("mui-pack-ready",false);self:DispatchProgram();return end
 for _,button in ipairs(row.controls or {}) do self:ObserveHoverInput(button) end
 self:RowBackground(row)
 self.frame:SetFrameRef("mui-companion"..index,row.frame)
 self.frame:SetFrameRef("mui-native-companion"..index,row.native)
 self.frame:SetFrameRef("mui-native-companion-parent"..index,row.interfaceParent)
 self.frame:SetFrameRef("mui-native-companion-gate"..index,row.interfacePresentation.gate)
 row.frame:SetFrameRef("mui-interface",self.frame)
 row.frame:SetAttribute("mui-pack-ready",true)
 row.frame:SetAttribute("mui-pack-applicable",row.name~="StanceBar" or row.formCount~=0)
 if row.interfacePackNative~=row.native then
  for _,event in ipairs({"OnShow","OnHide"}) do
   local post='local host=control:GetFrameRef("mui-companion'..index..'")\n'..[[
    if self:IsShown() and host and host:GetFrameRef("mui-interface")==control then host:SetAttribute("mui-pack-applicable",true) end
    control:RunAttribute("mui-interface")
   ]]
   SecureHandlerWrapScript(row.native,event,self.frame,[[ return "mui-pack",true ]],post)
  end
  row.interfacePackNative=row.native
 end
 self:DispatchProgram()
end
function I:ObserveContent()
 if S:InCombat() then self.badgeDirty=true;return end
 local filled=0
 for i=1,8 do
  local row=i==1 and A or F.families["ActionBars.bar"..i]
  if row and row.frame then
   local content,overflow=false,false
   for j=1,12 do
    local button=row.buttons[j]
    local slot=button and read(button,"GetAttribute","number","action")
    local has,state
    if slot then has,state=S:Public(C_ActionBar and C_ActionBar.HasAction or HasAction,"boolean",slot) end
    local occupied=state~="KNOWN" or has~=false
    if i<=3 and j>10 then overflow=overflow or occupied
    else content=content or occupied end
    if (i>=4 or j>10) and has==true then filled=filled+1 end
   end
   row.frame:SetAttribute("mui-row-content",content)
   row.frame:SetAttribute("mui-overflow-content",overflow)
   row.frame:SetAttribute("mui-content-unknown",false)
  end
 end
 if filled~=self.reserveCount then self.moreLabel:SetText(filled>0 and "More actions ("..filled..")" or "More actions");self.reserveCount=filled end
 self.badgeDirty=nil
end
function I:RepairLayout()
 if S:InCombat() or not A.active then return false end
 if not self:Layout(M.profile) then return false end
 -- An unchanged viewport still may have caused a native layout pass. Reassert
 -- owned child geometry once for that event, without changing action custody,
 -- paging, bindings or authored dimensions. Special-native leases reconcile
 -- their own geometry on the following family tick.
 if A.surface then self:Place(A.surface,M.profile) end
 for _,row in pairs(F.families) do
  if row.active and not row.pending and row.surface and self.specs[row.surface.id] then self:Place(row.surface,M.profile) end
 end
 return true
end
local taskNames={"CharacterFrame","SpellBookFrame","PlayerSpellsFrame","PlayerTalentFrame","TalentFrame","ProfessionsFrame","TradeSkillFrame","CraftFrame","ContainerFrameCombinedBags"}
for i=1,13 do taskNames[#taskNames+1]="ContainerFrame"..i end
function I:DiscoverTasks()
 if S:InCombat() or not self.frame then return end
 self.taskSeen=self.taskSeen or setmetatable({},{__mode="k"})
 local candidates={}
 for _,name in ipairs(taskNames) do local f=_G[name];if S:Frame(f,false) then candidates[#candidates+1]=f end end
 local inventory=R.Inventory and R.Inventory.surface and R.Inventory.surface.frame
 if S:Frame(inventory,false) then candidates[#candidates+1]=inventory end
 for _,f in ipairs(candidates) do if not self.taskSeen[f] and #self.taskFrames<32 then
  self.taskSeen[f]=true;self.taskFrames[#self.taskFrames+1]=f
  self.frame:SetFrameRef("mui-task"..#self.taskFrames,f)
  for _,script in ipairs({"OnShow","OnHide"}) do
   local ok=pcall(SecureHandlerWrapScript,f,script,self.frame,[[ return "mui-task",true ]],[[ control:RunAttribute("mui-interface") ]])
   if not ok then self.taskHookFailures=(self.taskHookFailures or 0)+1 end
  end
 end end
 self.frame:SetAttribute("mui-task-count",#self.taskFrames)
 local flyout=_G.SpellFlyout
 if S:Frame(flyout,false) and self.flyoutHook~=flyout then
  self.frame:SetFrameRef("mui-flyout",flyout)
  for _,script in ipairs({"OnShow","OnHide"}) do
   pcall(SecureHandlerWrapScript,flyout,script,self.frame,[[ return "mui-task",true ]],[[ control:RunAttribute("mui-interface") ]])
  end
  self.flyoutHook=flyout
 end
end
function I:TaskOpen()
 for _,f in ipairs(self.taskFrames) do if read(f,"IsShown","boolean")==true then return true end end
 return false
end
function I:CursorOpen()
 local kind=type(GetCursorInfo)=="function" and S:Public(GetCursorInfo,"string")
 return kind=="spell" or kind=="item" or kind=="macro" or kind=="flyout" or kind=="action"
end
function I:EditingOpen() return M.state.edit==true or M.state.keybindWorkspace==true or self:TaskOpen() or self:CursorOpen() or read(self.frame,"GetAttribute","boolean","mui-native-grid")==true end
function I:ContextDemand(now)
 local groups=M.PresentationGroups
 local snapshot=M.Store and M.Store:Snapshot() or {}
 local demanded,why
 if groups and groups.ActionDemand then demanded,why=groups:ActionDemand(snapshot,now,M.profile) end
 if demanded~=nil then self.contextDemand=demanded==true end
 -- Unavailable ordinary observations do not authorize a fresh concealment.
 -- The fixed secure combat branch honors the same authored Combat preference
 -- used by the native unit/cooldown gates, sampled before combat begins.
 local preference=M.ElementRules and M.ElementRules:Preference(self.id,"Combat",M.profile)
 local combat=cfg().visibility~="Manual" and preference~="HIDE"
 self.contextReason=why or "CONTEXT_UNAVAILABLE"
 return self.contextDemand~=false,combat
end
function I:RecoveryNeeded()
 -- Native companions retain their native parent; an artwork inverse cannot
 -- trap their controls below a stopped or auto-hidden Mirage ancestor.
 return false
end
function I:RefreshContext()
 return self:Refresh(false,true)
end
function I:Refresh(force,contextCycle)
 if not self.frame or S:InCombat() then self.pending=true;return end
 local now=S:Now();if not force and not contextCycle and now<(self.next or 0) then return end;self.next=now+.2
 self:PrepareFade()
 if self.profile~=M.profile then
  self.profile=M.profile;self.signature=nil;self.badgeDirty=true
  self.frame:SetAttribute("mui-reserve-open",false)
 end
 if self.discoveryDirty or force then self:DiscoverTasks();self.discoveryDirty=nil end
 local contentChanged=force or self.badgeDirty or self.reserveCount==nil
 if contentChanged then self:ObserveContent() end
 local experience=cfg().actionExperience==1 and 1 or 2
 local context,combatContext=self:ContextDemand(now)
 local editing=M.state.edit==true or M.state.keybindWorkspace==true
 local cursor=self:CursorOpen()==true
 local task=self:TaskOpen()==true
 local recovery=self:RecoveryNeeded()
 local revealToken=S:Number(M.state.revealUntil) and M.state.revealUntil or 0
 local retired=read(self.frame,"GetAttribute","number","mui-reveal-retired")
 local reveal=revealToken>now and revealToken~=retired
 local active=A.active==true and self:Requested()
 local signature=table.concat({tostring(active),experience,tostring(editing),tostring(cursor),tostring(task),tostring(reveal),revealToken,tostring(recovery),tostring(context),tostring(combatContext),tostring(cfg().interfaceDocked~=false)},":")
 if force or contentChanged or signature~=self.signature then
  self.frame:SetAttribute("mui-active",active);self.frame:SetAttribute("mui-experience",experience)
  self.frame:SetAttribute("mui-context",context);self.frame:SetAttribute("mui-context-combat",combatContext)
  self.frame:SetAttribute("mui-editing",editing);self.frame:SetAttribute("mui-cursor",cursor);self.frame:SetAttribute("mui-force",reveal)
  self.frame:SetAttribute("mui-reveal-token",revealToken)
  self.frame:SetAttribute("mui-recovery-access",recovery)
  self:DispatchProgram()
  self.signature=signature
 end
 self.active=active;self.pending=nil
end
function I:Stop()
 if not self.frame then return true end
 if S:InCombat() then self.pending=true;return false end
 local recovery=self:RecoveryNeeded()
 self.frame:SetAttribute("mui-active",false);self.frame:SetAttribute("mui-recovery-access",recovery)
 -- A new activation starts collapsed. Ordinary hover, task, layout and combat
 -- changes never change the player's current click choice.
 self.frame:SetAttribute("mui-reserve-open",false)
 -- UnregisterAutoHide belongs to the restricted frame API. Re-run our fixed
 -- inactive snippet to cancel a previous mouseover timer before holding any
 -- native recovery ancestor open; a raw Show alone would leave that timer live.
 self:DispatchProgram()
 self.active=false;self.signature=nil
 return true
end
local build,arrange,configure,tick,onEvent,suspend,bounds,status=A.Build,A.Arrange,A.Configure,A.Tick,A.OnEvent,A.Suspend,A.Bounds,A.Status
local runtimeDemand=A.NeedsRuntimeTick
local createOrdinary,createSpecial,specialContext,release,specialFamily=F.CreateOrdinary,F.CreateSpecial,F.SpecialContext,F.Release,F.Special
function A:Build()
 -- The final ancestry exists before base construction enrolls root custody.
 -- Cleanup must observe the same legitimate parent that TrackRoot captured.
 if not I:Create() then return false,"ACTION_INTERFACE_UNAVAILABLE" end
 local ok,why=build(self);if not ok then return ok,why end
 if not I:Adopt(self) then return false,"ACTION_INTERFACE_PARENT_UNAVAILABLE" end
 return true
end
function F:CreateOrdinary(def)
 if not I:Create() then return nil,"ACTION_INTERFACE_UNAVAILABLE" end
 local row,why=createOrdinary(self,def)
 if row then I:Adopt(row) end
 return row,why
end
function F:CreateSpecial(def)
 if I.specs["NativeControls."..def[1]] and not I:Create() then return nil,"ACTION_INTERFACE_UNAVAILABLE" end
 local row,why=createSpecial(self,def)
 return row,why
end
function F:Special(row)
 local ok,why=specialFamily(self,row)
 if ok then I:SpecialReady(row) end
 return ok,why
end
function A:Arrange(l) if I.specs[self.layoutID] then return I:Arrange(self) end;return arrange(self,l) end
function A:ResolveLayout(surface,p)
 return I:Resolve(surface.id,p) or M.Layout:Get(surface,p)
end
function A:ApplyLayout(surface)
 if I.specs[surface.id] or surface.id==I.id then return I:Place(surface,M.profile) end
 -- Native-managed encounter actions retain their own geometry.
 return false
end
function A:VisibilityDriver()
 if self==A then return "[petbattle] hide; [vehicleui] hide; [overridebar] hide; show" end
 return "[petbattle] hide; [vehicleui] hide; [overridebar] hide; [possessbar] hide; [shapeshift] hide; show"
end
-- Pack native companions against Mirage hosts without giving the hub
-- ownership of their native Show/Hide lifetime. Their secure paint/input gate
-- follows the hub while their native scripts retain their original ancestry.
local companions={PetActionBar=true,StanceBar=true,PossessActionBar=true,MultiCastActionBarFrame=true,
 OverrideActionBar=true,MainMenuBarVehicleLeaveButton=true}
function F:SpecialContext(row)
 if not companions[row.name] then return specialContext(self,row) end
 if S:InCombat() then return false end
 local native=_G[row.name]
 if not S:Frame(native,false) then return false end
 if not row.interfacePresentation then
  local retained=M.ContextualNative and M.ContextualNative.rows[row.name]
  if retained and retained.ownedOwner==self and not M.ContextualNative:ReleaseOwned(self,row.name) then return false end
  row.frame:SetParent(I.frame)
  local lease,why=R.NativeActionPresentation:Acquire(native)
  if not lease then row.contextStatus=why;return false end
  row.interfacePresentation=lease;row.interfaceParent=lease.parent
  if why then row.contextStatus=why;return false end
 end
 if not R.NativeActionPresentation:Current(row.interfacePresentation) then row.status="NATIVE_ACTION_PRESENTATION_CHANGED";return false end
 row.contextRequested=nil;row.contextReady=true;row.contextStatus="SHARED_ACTION_PRESENTATION"
 return true
end
function F:Release(row,keepContext)
 if row.frame and not S:InCombat() then row.frame:SetAttribute("mui-pack-ready",false) end
 local handback=R.NativeActionPresentation:Release(row.interfacePresentation)
 if handback then row.interfacePresentation=nil;row.interfaceParent=nil end
 local ok,why=release(self,row,keepContext)
 if I.frame and not S:InCombat() then I:DispatchProgram() end
 if not handback then row.pending=true;row.status="FAMILY_RESTORE_PENDING";return false,"NATIVE_PRESENTATION_RESTORE_PENDING" end
 return ok,why
end
function A:Configure(p)
 if S:InCombat() then return configure(self,p) end
 if not I:Create() then return false,"ACTION_INTERFACE_UNAVAILABLE" end
 local laid,reason=I:Layout(p or M.profile)
 if not laid then self.pendingConfigure=true;return false,reason end
 local ok,why=configure(self,p)
 I:Refresh(true);return ok,why
end
function A:Tick(now)
 if self.active~=true and self.pendingConfigure and I.viewportPending and M.Managed and M.Managed.Viewport then
  if S:InCombat() or not M.Managed:Viewport() then return R:Result("WAITING","VIEWPORT_PENDING") end
 end
 if I.layoutDirty and not S:InCombat() and I:RepairLayout() then I.layoutDirty=nil end
 local ok,why=tick(self,now)
 I:Refresh();return ok,why
end
function A:NeedsRuntimeTick(now,combat)
 if self.active~=true and self.pendingConfigure and I.viewportPending and M.Managed and M.Managed.Viewport then
  if combat==nil then combat=S:InCombat() end
  return not combat and M.Managed:Viewport()~=nil
 end
 if runtimeDemand then return runtimeDemand(self,now,combat) end
end
function A:OnEvent(event,...)
 if event=="ACTIONBAR_SLOT_CHANGED" or event=="ACTIONBAR_PAGE_CHANGED" or event=="UPDATE_BONUS_ACTIONBAR"
  or event=="UPDATE_SHAPESHIFT_FORM" or event=="UPDATE_POSSESS_BAR" or event=="PLAYER_ENTERING_WORLD" then I.badgeDirty=true end
 if event=="ADDON_LOADED" or event=="PLAYER_ENTERING_WORLD" then I.discoveryDirty=true end
 if event=="DISPLAY_SIZE_CHANGED" or event=="UI_SCALE_CHANGED" then
  -- Viewport changes need geometry only. The shared settled-viewport owner
  -- refreshes every surface; never retire/reacquire action custody for alt-tab.
  I.layoutDirty=true
 end
 return onEvent(self,event,...)
end
function A:Suspend(why)
 local ok,reason=suspend(self,why)
 -- Main controls quiesce before every cosmetic inverse necessarily succeeds.
 -- Apply the recovery floor even when the aggregate family result is pending.
 if not self.active and not S:InCombat() then I:Stop() end
 return ok,reason
end
function A:Bounds(id)
 if id==I.id then
  if not I.frame then return nil,"NOT_CREATED" end
  return {frame=I.background or I.frame,layoutID=I.id,provider="B52_COMPACT_ACTION_INTERFACE",width=I:PackedWidth(),height=I:PackedHeight(),
   scale=read(I.frame,"GetScale","number"),active=I.active==true}
 end
 return bounds(self,id)
end
local function sizeNumber(value)
 return S:Number(value) and math.abs(value)<131072 and string.format("%.3f",value) or "UNAVAILABLE"
end
function I:SizingStatus()
 local v=self.sizing
 if not v then return ";action_size=NOT_APPLIED" end
 local first=A.buttons and A.buttons[1]
 local size=read(first,"GetWidth","number")
 local effective=read(first,"GetEffectiveScale","number")
 local actual=S:Number(size) and S:Number(effective) and v.pixelToUI and size*effective/v.pixelToUI or nil
 return ";action_size="..v.mode..";action_physical_screen="..sizeNumber(v.physicalWidth).."x"..sizeNumber(v.physicalHeight)..
  ";action_ui_scale="..sizeNumber(v.uiScale)..";action_pixel_to_ui="..sizeNumber(v.pixelToUI)..
  ";action_authored_width="..sizeNumber(v.authoredWidth)..";action_authored_scale="..sizeNumber(v.authoredScale)..
  ";action_size_percent="..sizeNumber(v.percent)..";action_resolved_scale="..sizeNumber(v.scale)..
  ";action_expected_main_px="..sizeNumber(v.mainPixels)..";action_main_button_px="..sizeNumber(actual)..
  ";action_docked="..tostring(v.docked)..";action_visible_height="..sizeNumber(self:PackedHeight())..
  ";action_packed_rows="..sizeNumber(read(self.frame,"GetAttribute","number","mui-packed-rows"))..
  ";action_button_width="..sizeNumber(size)..";action_button_effective_scale="..sizeNumber(effective)..";action_fit_limited="..tostring(v.limited==true)
end
function I:HoverStatus()
 local function state(frame)
  local visible,known=read(frame,"IsVisible","boolean")
  return known=="KNOWN" and (visible and "VISIBLE" or "HIDDEN") or "UNAVAILABLE"
 end
 return ";action_hover_sensor="..state(self.sensors)..";action_hover_section="..state(self.frame)..
  ";action_hover_hook_failures="..tostring(self.hoverHookFailures or 0)
end
function A:Status()
 return status(self)..";interface=COMPACT_3X10;interface_visibility="..(cfg().actionExperience==1 and "SHARED_COMBAT_CONTEXT" or "MOUSEOVER_IMMEDIATE_SECURE")..
  ";reserve_slots_preserved=66;reserve_populated="..tostring(I.reserveCount or 0)..";task_hook_failures="..tostring(I.taskHookFailures or 0)..
  ";hover_minimum=0;hover_acquisition=IMMEDIATE_SECURE;hover_clock=NONE"..
  ";interface_fade="..(I.fadeReady and "COMMON_CONTEXT_DURATION" or "IMMEDIATE_FALLBACK")..";combat_conceal=IMMEDIATE_SECURE"..
  ";action_viewport="..(I.viewportPending and "WAITING_STABLE" or "STABLE_SHARED_SAMPLE")..
  ";action_context="..(I.contextReason or "NOT_RUN")..";companion_context=SHARED_INTERFACE;native_totem_actions=CONDITIONAL_NATIVE_FAMILY"..I:SizingStatus()..I:HoverStatus()
end
A.events.DISPLAY_SIZE_CHANGED=true;A.events.UI_SCALE_CHANGED=true
F.layouts[I.id]=true
