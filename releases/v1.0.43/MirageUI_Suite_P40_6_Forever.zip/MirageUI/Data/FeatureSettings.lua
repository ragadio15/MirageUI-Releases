local _, M = ...
local HUD=M.VisualTokens.geometry.hud
-- Additive, bounded module settings. No migration changes the player's active layout.
M.FeatureSettings={
    Notifications={loot=true,money=true,profession=true,status=true,duration={4,2,8},maxRows={3,1,4},textSize={14,10,22},reducedMotion=false,combatText=true,combatTextSize={20,12,32}},
    UnderCharacterHUD={schemaVersion={1,1,1},health=true,resource=true,cast=true,policy={2,1,4},layoutRevision={1,0,1},rowPitch={14,10,32},layoutOrder={1,1,2},castWidthExtra={0,0,32},healthFillOpacity={100,0,100},resourceFillOpacity={100,0,100},castFillOpacity={100,0,100},showPercent=false,percentTextSize={15,8,24},percentTextOpacity={100,0,100},x={HUD.x,-500,500},y={HUD.y,-500,-60},width={HUD.width,160,300},hudScale={100,75,150},healthHeight={HUD.health,6,16},resourceHeight={HUD.resource,4,16},castHeight={HUD.cast,4,24},gap={HUD.gap,0,6},opacity={100,40,100},backdrop={0,0,35},trackOpacity={76,20,100},
        healthColor={1,1,3},resourceColor={1,1,3},castColor={1,1,3},healthR={0,0,255},healthG={251,0,255},healthB={170,0,255},resourceR={0,0,255},resourceG={200,0,255},resourceB={254,0,255},castR={255,0,255},castG={186,0,255},castB={43,0,255}},
    PvP={automaticLens=false,contacts=false,manualNotes=false,contactRows={5,1,8},lens={2,1,5},badge=false},
    TacticalSignals={marker1={0,0,6},marker2={0,0,6},marker3={0,0,6},marker4={0,0,6},marker5={2,0,6},marker6={0,0,6},marker7={0,0,6},marker8={1,0,6},legend=false},
    Preparations={},
    Minimap={hideWhenQuiet=true,moveNative=false,square=true,squareSize={220,180,360}},
    Chat={hideWhenQuiet=true,moveNative=false,messageCue=true,cueSay=false,cueYell=false,cueGuild=false,cueEmote=false,cueChannels=false},
    DataBars={showFPS=true,showCurrency=false,currencyID={0,0,2147483647},showCoordinates=true,showTravel=false},
    Nameplates={cards=false,cardAuras=true,cardCast=true,cardPercent=true,nameBacking=false,cardLimit={80,16,80},cardWidth={M.VisualTokens.geometry.nameplate.width,180,360},cardScale={100,60,160},cardOffsetY={0,-80,80},cardIconSize={20,16,36},cardAuraCount={6,1,6},extended=false,showPercent=true,showLevel=true,subtle=true,panelOpacity={12,0,100},compact=false,flatBars=true,healthHeight={12,8,28},castHeight={8,5,20},nameSize={12,9,18}},
    Tooltips={presentationRevision={0,0,1},fixedAnchor=false,cursorAnchor=false,cursorOffset={100,0,200},avoidMeters=true,tooltipScale={100,70,160}},
    Bags={browser=false,columns={8,4,12},iconSize={36,24,52},shellPadding={8,0,16}},
    DamageMeters={contextualNative=false,summary=false,rows={8,3,15},meterType={0,0,1},sessionType={0,0,2},
        metersEnabled=true,meterMode={0,0,10},metersSession={1,0,1},meterRows={8,3,15},meterClassColors=true,
        meterShowRate=true,meterShowPercent=true,meterPinPlayer=true,meterReplaceNative=true,meterFirstName=true},
    QuestTracker={matchMinimap=true,hideWhenQuiet=true,moveNative=false,compactPanel=false,questLimit={4,1,8},objectiveLines={3,1,4},showObjectives=true,worldQuests=false},
    UnitFrames={contextualNative=false,referenceLayout=false,nativeAuras=false,panelOpacity={12,0,100},showPercent=true,nameBacking=false,showBuffs=false,debuffAccent=false,showCast=false,showAuras=false,auraSlots={4,2,8},showNames=true,showPower=true,showStatus=true,showRoles=false,showReady=false,classColors=false},
    PartyRaid={nativeAuras=false,nativeGroups=false,groupTitles=false,panelOpacity={10,0,100},compactRaid=true,showPercent=true,nameBacking=false,showBuffs=false,debuffAccent=false,showCast=false,showAuras=false,auraSlots={2,2,8},showNames=true,showPower=true,showStatus=true,showRoles=true,showReady=true,classColors=false,
        raidColumns={5,2,8},cellWidth={128,90,220},cellHeight={50,32,90},cellGap={6,0,16}},
    ActionBars={actionExperience={2,1,2},interfaceScale={100,65,160},interfaceDocked=true,utilityContext=false,columns={12,1,12},buttonCount={12,1,12},vertical=false,gap={4,0,12},showHotkeys=true,centerHotkeys=false,autoSizeHotkeys=false,hotkeySize={16,10,24},hideMacroText=false,showTooltips=true,contextual=false,allowRearrange=true,secondaryHover=false},
    ResourceBars={classResource=false,classSegments=false,empoweredStages=false,runes=false,totems=false},
    Cooldowns={centralGroup=false,tracker=false,columns={6,1,12},iconSize={50,24,80},gap={3,0,12},showNames=false,showNumbers=true,ignoreGCD=false,
        rowEnabled=true,rowSecondary=false,rowCustom=false,rowVisibility={3,1,3},rowFollowHUD=true,rowScale={100,65,160},rowOpacity={100,20,100},rowMaxIcons={0,0,160},
        rowBorder={1,0,3},rowZoom={8,0,20},durationSize={12,8,24},chargeSize={11,8,24},rowShowCharges=true,rowTooltips=false,rowShowInactive=true},
    Auras={nativeScale={100,80,180},preparation=false,privateAuras=false,privateCount={2,1,4},privateSize={32,20,56},playerPanel=false,limit={12,4,20},columns={12,4,20},iconSize={28,20,48},showNumbers=false},
}
-- M04: an explicit primary-presentation choice never changes optional panels.
-- Zero retains the effective legacy choice; named/inactive profiles normalize
-- only when the existing validated profile publisher makes them active.
for _,id in ipairs({"ActionBars","UnitFrames","PartyRaid","Minimap","Nameplates","Auras","Cooldowns","DamageMeters","Chat","Tooltips","QuestTracker","Bags","BlizzardSkin"}) do
 M.FeatureSettings[id]=M.FeatureSettings[id] or {}
 M.FeatureSettings[id].primaryPresentation={0,0,2}
end
-- The long-standing player-aura size option permits 180%. An authored shared
-- rectangle must be able to retain that same scale when it is first moved.
function M:LayoutScaleMaximum(id)
 return (id=="Auras.BuffFrame" or id=="Auras.DebuffFrame") and 1.8 or 1.6
end
for group=1,8 do
 M.FeatureSettings.PartyRaid["group"..group.."Growth"]={1,1,4}
 M.FeatureSettings.PartyRaid["group"..group.."Gap"]={-1,-1,32}
end
-- -1/0 sentinel choices retain the player's native settings until explicitly
-- authored. Enemy visibility keeps M01's seed; all writes use reversible custody.
local plates=M.FeatureSettings.Nameplates
plates.enemyVisibility={2,0,2};plates.friendlyVisibility={1,0,2}
plates.friendlyNPCVisibility={1,0,2};plates.enemyPetVisibility={2,0,2};plates.friendlyPetVisibility={1,0,2}
plates.globalScale={0,0,200};plates.minimumScale={0,0,200};plates.maximumScale={0,0,200}
plates.selectedScale={0,0,200};plates.maximumDistance={0,0,60};plates.stacking={0,0,2};plates.occludedOpacity={-1,-1,100}
plates.customFriendlyPlayers=false;plates.customFriendlyNPCs=false;plates.customPets=true;plates.customNeutral=true
-- Only the currently selected friendly may use an available native anchor.
-- Missing beta57 values adopt this default; an explicit later opt-out survives.
plates.selectedFriendlyPlate=true
plates.plateDistanceRevision={0,0,1}
-- Preserve existing native name preferences unless the user explicitly asks
-- Blizzard's own world renderer to show all NPC names, including civilians.
plates.nativeNPCNames={0,0,1}
function M:ModuleOptionKeys(id)
    local keys={"enabled","visibility","alpha","scale","style","showXP","showZone","showMoney","showClock"}
    local extra={};for key in pairs(self.FeatureSettings[id] or {}) do extra[#extra+1]=key end
    table.sort(extra);for _,key in ipairs(extra) do keys[#keys+1]=key end
    return keys
end
