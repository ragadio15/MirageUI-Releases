local M=MirageUI
if not M then return end
M.Options={page="Home",pool={},setters={},draft=nil,setup=false,step=1}
local O=M.Options;local U=M.UI
local friendly={CANDIDATE="Ready for in-game testing",NATIVE_PRESENTATION="Native controls retained",NATIVE_CONTENT_PRESERVED="Native information retained",WAITING_FOR_NATIVE_SURFACE="Open the native window to attach styling",CONFLICT_NATIVE_OWNER="Another UI suite owns this surface",SAFE_MODE="Suspended in safe mode",DISABLED="Disabled",NATIVE_METER_NOT_LOADED="Enable the game's damage meter first",UNAVAILABLE_NATIVE_API="Not available in this client",OWNED_BASELINE_INTEGRATED="Cursor Companion integrated",STANDALONE_CURSOR_OWNS_INPUT="Standalone Cursor Companion is active"}
function O:ShellBuild(key,...) return U[key](U,...) end
function O:ShellFrame(...) return CreateFrame(...) end
function O:ShellCall(object,key,...) return object[key](object,...) end
function O:Notice(text) self:ShellCall(self.notice,"SetText",text or "") end
function O:ResumeRuntime()
    local frame,draft,profile=self.frame,self.draft,M.profile
    local ok,why=M:Recover()
    -- Recovery changes runtime state, not an owned unsaved appearance draft.
    if self.frame==frame and self.draft==draft and M.profile==profile and draft then
        self:Render();self:Notice(why or M.Diagnostics:ActivationMessage())
    end
    return ok
end
function O:StopRuntime()
    local frame,draft,profile=self.frame,self.draft,M.profile
    M:SafeMode("USER_SETTINGS")
    if self.frame==frame and self.draft==draft and M.profile==profile and draft then
        self:Render();self:Notice(M.Diagnostics:ActivationMessage())
    end
end
function O:Clear()
    if self.ShellBoundary then self:ShellBoundary() end
    U:CloseChoices();if self.ShellBoundary then self:ShellBoundary() end
    for _,widget in pairs(self.pool) do self:ShellCall(widget,"Hide") end
    self.contentHeight=0
end
function O:Place(widget,x,y)
    if self.ShellBoundary then self:ShellBoundary() end
    self:ShellCall(widget,"ClearAllPoints");self:ShellCall(widget,"SetPoint","TOPLEFT",x,y);self:ShellCall(widget,"Show")
    self.contentHeight=math.max(self.contentHeight,-y+(widget.GetHeight and self:ShellCall(widget,"GetHeight") or 30)+20)
end
function O:Text(key,text,x,y,width,size)
    if self.ShellBoundary then self:ShellBoundary() end
    local k="text:"..key;local f=self.pool[k]
    if not f then f=self:ShellBuild("Text",self.content,"",0,0,size or 12,width);self.pool[k]=f end
    self:ShellCall(f,"SetText",text);if width then self:ShellCall(f,"SetWidth",width) end;self:Place(f,x,y);return f
end
function O:Button(key,text,x,y,width,callback)
    if self.ShellBoundary then self:ShellBoundary() end
    local k="button:"..key;local b=self.pool[k]
    if not b then b=self:ShellBuild("Button",self.content,text,x,y,width,nil);self.pool[k]=b end
    self:ShellCall(b,"SetText",text);self:ShellCall(b,"SetWidth",width);self:ShellCall(b.label,"SetWidth",width-16)
    local draft,profile,page,setup,advanced,token=self.draft,M.profile,self.page,self.setup,self.advanced,self.shellRenderToken
    self:ShellCall(b,"SetScript","OnClick",function(...)
        if self.draft~=draft or M.profile~=profile or self.page~=page or self.setup~=setup or self.advanced~=advanced or self.shellRenderToken~=token then return false end
        if callback then return callback(...) end
    end)
    self:Place(b,x,y);return b
end
function O:Edit(key,text,x,y,width,commit)
    if self.ShellBoundary then self:ShellBoundary() end
    local k="edit:"..key;local e=self.pool[k]
    if not e then e=self:ShellBuild("Edit",self.content,x,y,width,"",nil);self.pool[k]=e end
    self:ShellCall(e,"SetWidth",width);self:ShellCall(e,"SetText",text or "");e.shellCommittedText=text or "";e.commit=commit
    local ownerDraft,ownerProfile,ownerFrame,ownerPage,ownerToken=self.draft,M.profile,self.frame,self.page,self.shellRenderToken
    self:ShellCall(e,"SetScript","OnEnterPressed",function(b)
        local work=self.shellWork
        local function current() return self.draft==ownerDraft and M.profile==ownerProfile and self.frame==ownerFrame and self.page==ownerPage and self.shellRenderToken==ownerToken and self.shellWork==work and b.commit==commit end
        if not current() then return false end
        local ok,value=pcall(b.GetText,b)
        if not ok or not M.Safety:Readable(value) or type(value)~="string" or not current() then return false end
        if not commit then return false end
        local accepted,result=pcall(commit,value);if not accepted or result~=true or not current() then return false end
        b.shellCommittedText=value;b:ClearFocus();return current()
    end)
    self:Place(e,x,y);return e
end
function O:Slider(key,label,x,y,width,value,lo,hi,step,setter)
    if self.ShellBoundary then self:ShellBoundary() end
    local k="slider:"..key
    local f=self.pool[k]
    local function unavailable()
        if self.notice then self:Notice("This numeric control needs more horizontal space.") end
        return nil,"SLIDER_SPACE_UNAVAILABLE"
    end
    if not f then
        f=self:ShellBuild("Slider",self.content,label,x,y,width,value,lo,hi,step,function(v) if self.setters[key] then self.setters[key](v) end end)
        if not f then return unavailable() end
        self.pool[k]=f
    end
    -- Refusal must not replace a pooled pending buffer or its draft setter.
    if f.Relayout and f:Relayout(width)==false then return unavailable() end
    if self.ShellBoundary then self:ShellBoundary() end
    self.setters[key]=setter
    f.setValue(value,self.ShellCurrent and function() return self:ShellCurrent() end or nil);if self.ShellBoundary then self:ShellBoundary() end;self:Place(f,x,y);return f
end

function O:Choice(key,label,values,current,x,y,width,fn)
    return self:Button(key,label,x,y,width,function(b) U:Choose(b,values,current,function(v) fn(v);self:Render() end) end)
end
function O:Check(key,label,value,x,y,fn)
    return self:Button(key,(value and "[x] " or "[ ] ")..label,x,y,self.cw,function() fn(not value);self:Render() end)
end
function O:FlushEdits()
    for key,e in pairs(self.pool) do
        if e:IsShown() then
            if key:sub(1,5)=="edit:" and e.commit then
                local draft,profile,frame,page,work,commit=self.draft,M.profile,self.frame,self.page,self.shellWork,e.commit
                local getter,value=pcall(e.GetText,e)
                local function current() return self.draft==draft and M.profile==profile and self.frame==frame and self.page==page and self.shellWork==work and e.commit==commit end
                if not getter or not M.Safety:Readable(value) or type(value)~="string" or not current() then return false,"Settings owner changed." end
                local accepted,result=pcall(commit,value)
                if not accepted or result~=true then return false,"Finish or cancel the invalid field." end
                if not current() then return false,"Settings owner changed." end
                e.shellCommittedText=value
            elseif key:sub(1,7)=="slider:" and e.Commit then
                local ok,reason=e:Commit();if not ok then return false,reason end
            end
        end
    end
    return true
end
function O:Create()
    if self.frame then return end
    local plan=self.shellConstructionPlan
    local f=self.shellConstructedRoot or self:ShellBuild("Panel","MirageUISettings","MIRAGEUI",plan and plan.width or 1020,plan and plan.height or 720)
    self.shellConstructedRoot=f
    if self.ShellBoundary then self:ShellBoundary();self.shellWork.frame=f end;self.frame=f;if self.ShellRoot then self:ShellRoot(f) end
    local width,height=f:GetWidth(),f:GetHeight();if self.ShellBoundary then self:ShellBoundary() end
    self.previewEnabled=plan and plan.preview==true or not plan and width>=930;self.cw=plan and plan.bodyWidth or (self.previewEnabled and width-445 or width-245)
    self.notice=self:ShellBuild("Text",f,"",216,-height+74,11,width-240)
    local subtitle=self:ShellBuild("Text",f,"The world first. The interface when it matters.",22,-48,12,width-60);U:SetTextRole(subtitle,"muted");self.subtitle=subtitle
    self.navScroll=M.UI:Scroll(f);self.navScroll:SetPoint("TOPLEFT",18,-105);self.navScroll:SetPoint("BOTTOMLEFT",18,88);self.navScroll:SetWidth(175)
    self.nav=self:ShellFrame("Frame",nil,self.navScroll);self.nav:SetSize(154,1100);self.navScroll:SetScrollChild(self.nav)
    self.navButtons={}
    local pages={{id="Home",name="Overview"},{id="Behavior",name="What appears when"},{id="Integration",name="Display ownership"},{id="Accessibility",name="Input and accessibility"},{id="Profiles",name="Profiles"},{id="Validation",name="Validation worksheet"},{id="Support",name="Help and recovery"}}
    for _,entry in ipairs(M.Catalog) do if not entry.system and entry.id~="DataBars" then pages[#pages+1]={id=entry.id,name=entry.name} end end
    self.pages=pages
    for i,p in ipairs(pages) do
        local b=self:ShellBuild("Button",self.nav,M.Icons and M.Icons:Label(M.Icons:ForModule(p.id),p.name,16) or p.name,0,-(i-1)*32,154,function() if self.ShellTransition then return self:ShellTransition(false,self.advanced,p.id) end;self:FlushEdits();self.setup=false;self.page=p.id;self:Render() end)
        if self.ShellBoundary then self:ShellBoundary() end;self.navButtons[p.id]=b
    end
    self.nav:SetHeight(#pages*32)
    self.scroll=M.UI:Scroll(f);self.scroll:SetPoint("TOPLEFT",215,-108);self.scroll:SetPoint("BOTTOMLEFT",215,100);self.scroll:SetWidth(self.cw+15)
    self.content=self:ShellFrame("Frame",nil,self.scroll);self.content:SetSize(self.cw,750);self.scroll:SetScrollChild(self.content)
    self.search=self:ShellBuild("Edit",f,215,-70,self.cw,"",function(text) self:Search(text) end)
    self.search:SetScript("OnTextChanged",function(box,user) if user then self:Search(box:GetText()) end end)
    local fw=plan and plan.footer[1].rect.width or math.min(126,math.floor((width-235-32)/5))
    self.apply=self:ShellBuild("Button",f,"Apply",215,-height+44,fw,function() self:Apply() end)
    self.cancel=self:ShellBuild("Button",f,"Cancel",215+(fw+8),-height+44,fw,function() self:Cancel() end)
    self.undo=self:ShellBuild("Button",f,"Undo",215+2*(fw+8),-height+44,fw,function()
        return self:Undo()
    end)
    self.unlock=self:ShellBuild("Button",f,"Unlock",215+3*(fw+8),-height+44,fw,function() M.Editor:Open() end)
    self.safeButton=self:ShellBuild("Button",f,"Safe mode",215+4*(fw+8),-height+44,fw,function() self:StopRuntime() end)
    self.frame.closeButton:SetScript("OnClick",function() self:Cancel() end)
    self.frame:SetScript("OnHide",function() if self.importFrame then self.importFrame:Hide() end;if M.VisualPreview and M.VisualPreview.frame then M.VisualPreview.frame:Hide() end;if M.SourceLibrary and M.SourceLibrary.frame then M.SourceLibrary.frame:Hide() end;U:CloseChoices();if M.BindingEditor then M.BindingEditor:Close() end;if self.CloseCursorEditors then self:CloseCursorEditors() end end)
    if self.previewEnabled then self:CreatePreview(width,height) end
end
local searchWords={Integration="primary display ownership duplicate HUD PRD native settings compatibility mirrors motion",
    Home="preset text font contrast onboarding setup",Behavior="visible visibility context idle fade rules",
    Profiles="import export shared character backup saved",Support="recover safe diagnostics help",
    Cursor="rings halo trail rotation spin mouse pointer shortcut radial",
    QuestTracker="quest quests objective objectives watched watch collapse progress",
    UnitFrames="unit health power class name status offline dead ghost ready role healing healer click casting clickcast",
    PartyRaid="party raid group grid columns health power class name status offline dead ghost ready role healing healer click casting clickcast",
    ActionBars="action button buttons rows columns gap hotkeys macro names text labels hide shortcut shortcuts keys keyboard mouse binding bindings drag rearrange tooltips centre center autosize auto-size fit text",
    UnderCharacterHUD="under character player hud health resource casting screen center placement zoom bars",
    ResourceBars="resource secondary class power casts casting global cooldown gcd",
    Cooldowns="cooldown spell spells track tracking charge recharge timer",
    Nameplates="nameplate nameplates name health cast height compact",Tooltips="tooltip tooltips anchor anchored position",Bags="bag bags inventory search item bank browser",DamageMeters="damage healing meter meters session summary",
    Auras="auras buffs debuffs effects icons",
}
function O:Search(text)
    text=(text or ""):lower()
    local n=0
    for _,p in ipairs(self.pages) do
        local b=self.navButtons[p.id]
        local haystack=p.name:lower().." "..p.id:lower().." "..(searchWords[p.id] or "")
        local match=true;for word in text:gmatch("%S+") do if not haystack:find(word,1,true) then match=false;break end end
        if match then
            self:ShellCall(b,"ClearAllPoints");self:ShellCall(b,"SetPoint","TOPLEFT",0,-n*32);b.mirageNavY=-n*32;self:ShellCall(b,"Show");n=n+1
        else self:ShellCall(b,"Hide") end
    end
    self:ShellCall(self.nav,"SetHeight",math.max(30,n*32))
end
function O:Open()
    if M.Safety:InCombat() then return end
    self:Create();if self.importFrame then self.importFrame:Hide() end;self.draft=M:Copy(M.profile);self.setup=false;self.frame:Show();self:Render()
end
function O:Setup()
    if M.Safety:InCombat() then return end
    self:Create();if self.importFrame then self.importFrame:Hide() end;self.draft=M:Copy(M.profile);self.setup=true;self.step=1;self.frame:Show();self:Render()
end
function O:Apply()
    if M.Safety:InCombat() then return end
    self:FlushEdits()
    if self.setup and self.step<6 then self.step=self.step+1;self:Render();return end
    if self.setup then self.draft.onboarding=true;self.draft.onboardingDismissed=false end
    local ok,why=M.Profiles:Commit(self.draft)
    if ok then self.draft=M:Copy(M.profile);self.setup=false;self:Render();self:Notice("Saved.")
    else self:Notice(why) end
end
function O:Cancel()
    if self.setup and not M.Safety:InCombat() and not M.Profiles.readOnly then
        local p=M:Copy(M.profile);p.onboardingDismissed=true;M.Profiles:Commit(p)
    end
    self.draft=nil;self.frame:Hide();U:CloseChoices()
end
function O:Render()
    if self.importFrame and self.importFrame:IsShown() and self.importOwner~=self.draft then self.importFrame:Hide() end
    if not self.draft then return end
    if (self.page~="Cursor" or self.setup) and self.CloseCursorEditors then self:CloseCursorEditors() end
    local renderKey=self.setup and ("setup:"..self.step) or self.page
    local previousScroll=self.lastRenderKey==renderKey and self.scroll:GetVerticalScroll() or 0
    self.lastRenderKey=renderKey
    self:Clear();self:Notice("")
    if self.setup then self:RenderSetup()
    elseif self.page=="Home" then self:RenderHome()
    elseif self.page=="Validation" then self:RenderValidation()
    elseif self.page=="Accessibility" then self:RenderAccessibility()
    elseif self.page=="Behavior" then self:RenderBehavior()
    elseif self.page=="Integration" then self:RenderIntegration()
    elseif self.page=="Profiles" then self:RenderProfiles()
    elseif self.page=="Support" then self:RenderSupport()
    else self:RenderModule(self.page) end
    self.content:SetHeight(math.max(480,self.contentHeight))
    self.scroll:SetVerticalScroll(math.min(previousScroll,math.max(0,self.content:GetHeight()-self.scroll:GetHeight())))
    self.apply:SetText(self.setup and (self.step==7 and "Finish" or "Next") or "Apply")
    self.cancel:SetText(self.setup and "Skip setup" or "Cancel")
    self.undo:SetShown(not self.setup)
    for id,b in pairs(self.navButtons) do b.selected=id==self.page;b:SetBackdropBorderColor(unpack(id==self.page and M.Theme.accent or M.Theme.edge)) end
    self:UpdatePreview()
end
function O:RenderHome()
    local activation=M.Diagnostics:ActivationState()
    self:Text("head",activation.setupBlocked and activation.title or "A calmer interface",0,0,self.cw,20)
    self:Text("intro",activation.message,0,-38,self.cw,12)
    self:Choice("preset","Starting view: "..self.draft.preset,M.PresetNames,self.draft.preset,0,-105,self.cw,function(v) self.draft=M.Profiles:Preset(v,self.draft) end)
    self:Check("enabled","Enable MirageUI presentation",self.draft.enabled,0,-145,function(v) self.draft.enabled=v end)
    self:Button("setup","Run first-time setup",0,-185,self.cw,function() self:Setup() end)
    self:Button("reveal","Reveal optional panels for 10 seconds",0,-225,self.cw,function() M.CVE:Reveal(10) end)
    self:Slider("textScale","Text size",0,-275,self.cw,self.draft.textScale,.8,1.5,.05,function(v) self.draft.textScale=v end)
    self:Check("contrast","Higher-contrast interface",self.draft.contrast,0,-345,function(v) self.draft.contrast=v end)
    self:Text("client","Client: "..M.Client.family.." "..M.Client.patch.." / "..M.Client.build.."\n"..activation.help,0,-392,self.cw,11)
    if activation.canRecover then self:Button("recover","Resume MirageUI",0,-465,self.cw,function() self:ResumeRuntime() end):SetEnabled(true) end
end
function O:RenderModule(id)
    local entry=M.CatalogByID[id];local cfg=self.draft.modules[id]
    if not entry or not cfg or id=="DataBars" then self:Text("none","Choose a module in the sidebar.",0,0,self.cw);return end
    local mod=M.modules[id]
    self:Text("head",entry.name,0,0,self.cw,20)
    self:Text("note",entry.note or "",0,-39,self.cw,12)
    local enabledText=entry.kind=="native" and "Let MirageUI manage this display" or "Enable this display"
    self:Check("moduleEnabled",enabledText,cfg.enabled,0,-105,function(v) cfg.enabled=v end)
    self:Text("status","Status: "..(friendly[mod and mod.status] or (mod and mod.status or "Not loaded")),0,-145,self.cw,11)
    if self.RenderSpecialModule and self:RenderSpecialModule(id,cfg) then return end
    if entry.kind=="secure" then
        self:Text("secureNote","These are optional additional secure controls. Blizzard's original action, unit and group frames are not removed. Visibility is managed by fixed native unit/state drivers, not by ordinary contextual hide rules.\n\nConfigure them outside combat. Changes to protected controls are deferred until combat ends.",0,-185,self.cw,12)
        self:Button("layout","Move or resize in Unlock Mode",0,-312,self.cw,function() M.Editor:Open() end)
        self:Button("why","Why is this visible?",0,-354,self.cw,function() U:CopyWindow(entry.name.." — presentation",M.Diagnostics:Why(id)) end)
        return
    end
    self:Choice("visibility","Visibility: "..cfg.visibility,{"Contextual","Always","Manual"},cfg.visibility,0,-185,self.cw,function(v) cfg.visibility=v end)
    self:Slider("alpha","Visual emphasis",0,-236,self.cw,cfg.alpha,.2,1,.05,function(v) cfg.alpha=v end)
    if entry.kind=="native" then
        self:Check("skin","Original MirageUI accents",cfg.style,0,-304,function(v) cfg.style=v end)
        self:Text("native","On: MirageUI controls this display’s appearance and when it is shown. Off: the game’s original display is left in place. Spell actions, quest tracking and click behavior stay unchanged.",0,-350,self.cw,12)
    else
        self:Button("layout","Move or resize in Unlock Mode",0,-304,self.cw,function() M.Editor:Open() end)
    end
    local y=-425
    if id=="DamageMeters" then
        self:Button("meter","How to enable the native meter",0,y,self.cw,function() M.modules.DamageMeters:OpenSettings() end);y=y-40
    end
    self:Button("why","Why is this visible?",0,y,self.cw,function() U:CopyWindow(entry.name.." — presentation",M.Diagnostics:Why(id)) end)
end
function O:RenderBehavior()
    self:Text("head","What appears when",0,0,self.cw,20)
    self:Text("rulesInfo","Safety comes first, then your pins and active tasks, then context. Missing or restricted data never becomes a false verdict. Rules below apply only to eligible surfaces; native and secure controls retain their own safety rules.",0,-40,self.cw,12)
    self:Slider("idle","Stillness before quiet (seconds)",0,-125,self.cw,self.draft.idle,0,15,.5,function(v) self.draft.idle=v end)
    self:Slider("hold","Navigation hold (seconds)",0,-190,self.cw,self.draft.movementHold,0,5,.25,function(v) self.draft.movementHold=v end)
    self:Slider("combatHold","Combat recovery (seconds)",0,-255,self.cw,self.draft.combatHold,0,8,.5,function(v) self.draft.combatHold=v end)
    self:Slider("fade","Fade time (seconds)",0,-320,self.cw,self.draft.fade,0,.4,.05,function(v) self.draft.fade=v end)
    self:Text("custom","Personal rule",0,-395,self.cw,16)
    local moduleValues={};for _,e in ipairs(M.Catalog) do if not e.system and e.kind~="secure" and e.id~="Cursor" and e.id~="DataBars" then moduleValues[#moduleValues+1]={value=e.id,label=e.name} end end
    self.ruleModule=self.ruleModule~="DataBars" and self.ruleModule or "Minimap";self.ruleState=self.ruleState or "VISIBLE"
    self.ruleTerms=self.ruleTerms or {{signal="PLAYER_MOVING",value=true}};self.ruleJoin=self.ruleJoin or "all"
    self:Choice("ruleModule","Module: "..self.ruleModule,moduleValues,self.ruleModule,0,-430,self.cw,function(v) self.ruleModule=v end)
    self:Choice("ruleJoin",self.ruleJoin=="all" and "Match every condition" or "Match any condition",{{value="all",label="Match every condition"},{value="any",label="Match any condition"}},self.ruleJoin,0,-470,self.cw,function(v) self.ruleJoin=v end)
    local values={{value="PLAYER_MOVING",label="Moving"},{value="PLAYER_IN_COMBAT",label="In combat"},{value="TARGET_EXISTS",label="Target selected"},{value="MAP_OPEN",label="World map open"},{value="CHATTING",label="Typing in chat"},{value="BAGS_OPEN",label="Bags open"},{value="IN_DUNGEON",label="Inside a dungeon"},{value="PLAYER_MOUNTED",label="Mounted"},{value="PLAYER_HAS_PET",label="Pet present"}}
    local y=-510
    for i,term in ipairs(self.ruleTerms) do
        self:Choice("ruleSignal"..i,M.UserSignalLabels[term.signal] or term.signal,values,term.signal,0,y,self.cw-112,function(v) term.signal=v end)
        self:Button("ruleTruth"..i,term.value and "Yes" or "No",self.cw-104,y,60,function() term.value=not term.value;self:Render() end)
        if #self.ruleTerms>1 then self:Button("removeTerm"..i,"-",self.cw-36,y,36,function() table.remove(self.ruleTerms,i);self:Render() end) end
        y=y-36
    end
    if #self.ruleTerms<4 then self:Button("newTerm","Add condition",0,y,self.cw,function() self.ruleTerms[#self.ruleTerms+1]={signal="PLAYER_IN_COMBAT",value=false};self:Render() end);y=y-40 end
    self:Choice("ruleState","Presentation: "..self.ruleState,{{value="VISIBLE",label="Visible"},{value="AMBIENT",label="Quiet"},{value="HIDDEN",label="Hidden (optional visuals only)"}},self.ruleState,0,y,self.cw,function(v) self.ruleState=v end);y=y-40
    self:Button("addRule","Add this rule",0,y,self.cw,function()
        if #self.draft.rules>=24 then self:Notice("Up to 24 personal rules are supported.");return end
        local args={};for _,term in ipairs(self.ruleTerms) do args[#args+1]={op="eq",signal=term.signal,value=term.value} end
        self.draft.rules[#self.draft.rules+1]={module=self.ruleModule,state=self.ruleState,enabled=true,when={op=self.ruleJoin,args=args},dwell=0}
        self:Render()
    end);y=y-45
    for i,r in ipairs(self.draft.rules) do
        self:Button("userRule"..i,r.module..": "..M.Predicate:Describe(r.when).." → "..r.state.."   [Remove]",0,y,self.cw,function() table.remove(self.draft.rules,i);self:Render() end);y=y-36
    end
    self:Button("catalogue","Inspect built-in rule decisions",0,y-10,self.cw,function() U:CopyWindow("Current presentation decisions",M.Diagnostics:Why()) end)
end
function O:RenderProfiles()
    self:Text("head","Profiles and recovery",0,0,self.cw,20)
    self:Text("profileInfo","Settings are isolated by client. Copy a shared profile for this character, keep named snapshots locally, or preview a data-only import. Copied profiles include saved reference text; review before sharing. Shortcuts remain controlled by WoW's binding system.",0,-40,self.cw,12)
    self:Button("account","Use shared settings",0,-125,self.cw,function() M.Profiles:UseCharacter(false);self.draft=M:Copy(M.profile);self:Render() end)
    self:Button("character","Use character settings (create if needed)",0,-165,self.cw,function() M.Profiles:UseCharacter(true);self.draft=M:Copy(M.profile);self:Render() end)
    self:Edit("profileName",self.profileName or "My layout",0,-220,self.cw,function(v) self.profileName=v;return true end)
    self:Button("saveProfile","Save current applied layout",0,-258,self.cw,function() self:FlushEdits();local ok,why=M.Profiles:SaveNamed(self.profileName or "My layout");self:Notice(ok and "Saved locally." or why) end)
    local names={};if M.Profiles.account then for name in pairs(M.Profiles.account.named) do names[#names+1]=name end;table.sort(names) end
    self:Choice("loadProfile","Load a saved layout",names,nil,0,-298,self.cw,function(name) local ok,why=M.Profiles:LoadNamed(name);self.draft=M:Copy(M.profile);self:Notice(ok and "Layout applied." or why) end)
    self:Button("exportProfile","Copy applied profile",0,-350,self.cw,function() local text,why=M.Profiles:Export();if not text then self:Notice(why);return end;U:CopyWindow("Profile includes saved reference text — review before sharing",text) end)
    self:Button("importProfile","Paste a profile for preview",0,-390,self.cw,function() self:ImportWindow() end)
    self:Button("rescue","Rescue off-screen layout",0,-442,self.cw,function() M.Layout:Rescue();self.draft=M:Copy(M.profile);self:Notice("Layout returned to screen anchors and constrained to visible bounds.") end)
    self:Button("reset","Reset draft to safe defaults",0,-482,self.cw,function() self.draft=M.Profiles:Defaults();self.draft.onboarding=M.profile.onboarding;self:Render();self:Notice("Defaults are a draft until Apply.") end)
end
-- Request ownership is separate from the admitted dialog token. A shared native
-- writer cannot roll back a late write, so nested same-dialog opens are refused
-- until that writer returns (including when it throws).
local function importPure(self,t,retired,rendered)
    if t.opening and not retired then
        local D=t.navigation
        if D.CurrentShown~=t.currentShown or D.OwnedShow~=t.ownedShow or D.OwnedWrite~=t.ownedWrite then return false end
        local ok,current=pcall(t.currentShown,D,t.shownReceipt)
        if not ok or current~=true then return false end
    end
    local request=t.request or t
    local owned=request.token and self.importRequest==request or (not request.token and self.importAttempt==request and self.importRequest==request.prior and self.importToken==request.priorToken and self.importOwner==request.priorOwner)
    return M.Options==self and owned and (retired or not request.retired) and
        self.frame==t.frame and self.draft==t.draft and M.profile==t.profile and (t.live or rendered or self.shellWork==t.work) and
        self.setup==t.setup and self.advanced==t.advanced and self.page==t.page and
        (not t.panel or (self.importFrame==t.panel and self.importBox==t.box)) and
        (M.state.safe==true)==t.safe and (M.state.cinematic==true)==t.cinematic and M.state.world==t.world and
        M.Client==t.client and M.adapter==t.adapter and M.Client.build==t.build and M.adapter.sourceCommit==t.source and
        M.Safety==t.safety and M.DialogNavigation==t.navigation and
        (t.live or t.handing or (t.navigation.top==t.top and t.navigation.shownGeneration==t.shown))
end
local function importCall(self,t,object,method,writer,...)
    if not importPure(self,t) then return false end
    local previous=self.importWriter
    if writer then self.importWriter=true end
    local good,value
    if writer and t.opening then
        -- The shared lifecycle writer also refuses other-dialog admission while
        -- a native focus/text setter may still perform its old write.
        local called,accepted,result=pcall(t.ownedWrite,t.navigation,t.shownReceipt,object,method,...)
        good,value=called and accepted==true,result
    else
        local ok,fn=pcall(function() return object[method] end)
        if ok and type(fn)=="function" and importPure(self,t) then good,value=pcall(fn,object,...) end
    end
    if writer then self.importWriter=previous end
    return good==true and importPure(self,t),value
end

local function importShown(self,t,frame)
    local ok,value=importCall(self,t,frame,"IsShown",false)
    if not ok then return false end
    local good,public=pcall(t.safety.Readable,t.safety,value)
    return good and public==true and type(value)=="boolean" and value and importPure(self,t)
end
local function importEligible(self,t)
    if not importPure(self,t) or M.state.safe or M.state.cinematic then return false end
    local ok,combat=pcall(t.safety.InCombat,t.safety)
    if not ok or combat~=false or not importPure(self,t) or M.state.safe or M.state.cinematic or not importShown(self,t,t.frame) then return false end
    ok,combat=pcall(t.safety.InCombat,t.safety)
    return ok and combat==false and importPure(self,t) and not M.state.safe and not M.state.cinematic
end
local function importRetire(self,t)
    if self.importRequest~=t then return end
    t.retired=true;self.importToken=nil;self.importOwner=nil
    t.draft=nil;t.profile=nil;t.work=nil;t.frame=nil;t.panel=nil;t.box=nil
    local box=self.importBox
    local draft,profile,frame,work=self.draft,M.profile,self.frame,self.shellWork
    local function current() return self.importRequest==t and self.importToken==nil and self.importBox==box and
        self.draft==draft and M.profile==profile and self.frame==frame and self.shellWork==work end
    -- Independent best efforts: a failing focus release does not skip text
    -- erasure. No text/history is retained to restore a partially failed write.
    for _,method in ipairs({"ClearFocus","SetText"}) do
        if not current() then return end
        local previous=self.importWriter;self.importWriter=true
        pcall(function() if method=="SetText" then box:SetText("") else box:ClearFocus() end end)
        self.importWriter=previous
    end
end
local function importAbort(self,t)
    if not t.token then
        t.retired=true;t.draft=nil;t.profile=nil;t.work=nil;t.frame=nil;t.panel=nil;t.box=nil;t.prior=nil;t.priorToken=nil;t.priorOwner=nil
        return false
    end
    if self.importRequest~=t then return false end
    if self.frame~=t.frame or self.draft~=t.draft or M.profile~=t.profile or self.shellWork~=t.work then
        t.retired=true;self.importToken=nil;self.importOwner=nil
        t.draft=nil;t.profile=nil;t.work=nil;t.frame=nil;t.panel=nil;t.box=nil
        return false
    end
    local frame,box,owner,draft,profile,work=self.importFrame,self.importBox,self.frame,self.draft,M.profile,self.shellWork
    importRetire(self,t)
    if self.importRequest==t and self.importToken==nil and self.importFrame==frame and self.importBox==box and
        self.frame==owner and self.draft==draft and M.profile==profile and self.shellWork==work and frame then
        local previous=self.importWriter;self.importWriter=true
        pcall(function() frame:Hide() end)
        self.importWriter=previous
    end
    return false
end
function O:ImportWindow()
    if self.importWriter or self.importBuilding or self.importQuarantined then return false end
    local S,D=M.Safety,M.DialogNavigation
    -- A denied preadmission probe does not replace the existing private session.
    -- Never restore saved ownership after a callback: simply refuse if it moved.
    local prior,owner,draft,profile,work=self.importRequest,self.frame,self.draft,M.profile,self.shellWork
    local top,shown=D.top,D.shownGeneration
    local function preflightCurrent()
        return M.Options==self and self.importRequest==prior and self.frame==owner and self.draft==draft and
            M.profile==profile and self.shellWork==work and M.Safety==S and M.DialogNavigation==D and D.top==top and D.shownGeneration==shown and not M.state.safe and not M.state.cinematic
    end
    if not owner or not draft or not preflightCurrent() then return false end
    local probed,combat=pcall(S.InCombat,S)
    if not probed or combat~=false or not preflightCurrent() then return false end
    local observed,visible=pcall(function() return owner:IsShown() end)
    if not observed or not preflightCurrent() then return false end
    local readable,public=pcall(S.Readable,S,visible)
    if not readable or public~=true or visible~=true or not preflightCurrent() then return false end
    probed,combat=pcall(S.InCombat,S)
    if not probed or combat~=false or not preflightCurrent() then return false end
    local t={frame=self.frame,draft=self.draft,profile=M.profile,work=self.shellWork,setup=self.setup,advanced=self.advanced,page=self.page,safety=S,navigation=D,safe=M.state.safe==true,cinematic=M.state.cinematic==true,world=M.state.world,client=M.Client,adapter=M.adapter,build=M.Client.build,source=M.adapter.sourceCommit,top=D.top,shown=D.shownGeneration,prior=prior,priorToken=self.importToken,priorOwner=self.importOwner}
    self.importAttempt=t
    if not t.frame or not t.draft or not importEligible(self,t) then return importAbort(self,t) end
    if not self.importFrame then
        self.importBuilding=true
        local f
        local ok=pcall(function()
            local function call(object,method,...)
                local good,value=importCall(self,t,object,method,false,...)
                if not good then error("Import construction retired",0) end
                return value
            end
            f=U:Panel("MirageUIImportWindow","Preview a profile import",640,400)
            if not importPure(self,t) then error("Import construction retired",0) end
            self.importFrame=f
            local scroll=M.UI:Scroll(f)
            if not importPure(self,t) then error("Import construction retired",0) end
            call(scroll,"SetPoint","TOPLEFT",20,-92);call(scroll,"SetPoint","BOTTOMRIGHT",-40,65)
            local e=CreateFrame("EditBox",nil,scroll)
            if not importPure(self,t) then error("Import construction retired",0) end
            self.importBox=e
            call(e,"SetMultiLine",true);call(e,"SetAutoFocus",false);call(e,"SetMaxLetters",32768);call(e,"SetFont",STANDARD_TEXT_FONT,12,"")
            local width=call(f,"GetWidth");call(e,"SetSize",width-70,1400);call(scroll,"SetScrollChild",e)
            self.importNavigation=U:Button(f,"Controller navigation / Tab leaves text",20,-54,width-40,nil)
            if not importPure(self,t) then error("Import construction retired",0) end
            self.importPreview=U:Button(f,"Preview import",20,-350,200,nil)
            if not importPure(self,t) then error("Import construction retired",0) end
            call(self.importPreview,"ClearAllPoints");call(self.importPreview,"SetPoint","BOTTOMLEFT",20,22)
            self.importNotice=U:Text(f,"",230,-350,11,width-255)
            if not importPure(self,t) then error("Import construction retired",0) end
            call(self.importNotice,"ClearAllPoints");call(self.importNotice,"SetPoint","BOTTOMLEFT",230,20)
            call(f,"SetScript","OnHide",function() local active=self.importRequest;if active then importRetire(self,active) end end)
            D:Attach(f,{allowed=function() return self:ImportAlive() end,closeOnSuspend=true,
                hideCleanupAllowed=function() return self.importToken==nil end,
                entries=function() return {
                    {frame=e,key="importText",kind="edit",identity=self.importToken},
                    {frame=self.importPreview,key="preview",kind="button",identity=self.importToken},
                    {frame=self.importNavigation,key="navigation",kind="button",identity=self.importToken},
                    {frame=f.closeButton,key="close",kind="button",identity=self.importToken}}
                end})
            if not importPure(self,t) then error("Import construction retired",0) end
        end)
        self.importBuilding=nil
        if not ok then
            self.importQuarantined=true;t.retired=true;self.importToken=nil;self.importOwner=nil
            if f then pcall(f.Hide,f) end
            return false
        end
    end
    local f,e=self.importFrame,self.importBox;t.panel=f;t.box=e
    if U and type(U.CloseChoices)=="function" and not importCall(self,t,U,"CloseChoices",false) then return importAbort(self,t) end
    if M.AccessibleInput and type(M.AccessibleInput.Stop)=="function" and not importCall(self,t,M.AccessibleInput,"Stop",false) then return importAbort(self,t) end
    if M.OptionsNavigation and type(M.OptionsNavigation.Stop)=="function" and not importCall(self,t,M.OptionsNavigation,"Stop",false) then return importAbort(self,t) end
    if not importEligible(self,t) then return importAbort(self,t) end
    -- Successful admission supersedes the prior logical request without touching
    -- its shared field. Stale saved handlers must not retain old draft owners.
    local previous=t.prior
    if previous then
        previous.retired=true;previous.draft=nil;previous.profile=nil;previous.work=nil;previous.frame=nil;previous.panel=nil;previous.box=nil
    end
    local token={};t.token=token;self.importRequest=t;t.prior=nil;t.priorToken=nil;t.priorOwner=nil;self.importToken=token;self.importOwner=t.draft
    local function alive() return self:ImportAlive(token) end
    local function action(fn)
        return function(...)
            local work=self.shellWork
            if not alive() or self.shellWork~=work then return false end
            local op={};for key,value in pairs(t) do op[key]=value end
            op.request=t;op.live=false;op.work=work
            local function current() return importPure(self,op) and alive() and importPure(self,op) end
            return fn(op,current,...)
        end
    end
    local close=action(function(t,alive) if alive() then importCall(self,t,f,"Hide",true) end end)
    local navigate=action(function(t,alive)
        if not alive() then return false end
        local ok,focus=pcall(GetCurrentKeyBoardFocus)
        if not ok or not alive() then return false end
        local readable,public=pcall(S.Readable,S,focus)
        if not readable or public~=true or not alive() or (focus~=nil and focus~=e) then return false end
        if focus==e and not importCall(self,t,e,"ClearFocus",true) then return false end
        if not alive() then return false end
        return importCall(self,t,D,"Start",false,f,true)
    end)
    local preview=action(function(t,alive)
        if not alive() then return end
        local profiles=M.Profiles;local parser=profiles.Import
        local ok,text=importCall(self,t,e,"GetText",false)
        if not ok or not alive() or M.Profiles~=profiles or profiles.Import~=parser then return end
        local readable,public=pcall(S.Readable,S,text)
        if not readable or public~=true or type(text)~="string" or not alive() or M.Profiles~=profiles or profiles.Import~=parser then return end
        local parsed,p,why=pcall(parser,profiles,text)
        text=nil
        if not parsed or not alive() or M.Profiles~=profiles or profiles.Import~=parser then return end
        if p then
            -- Establish an exact existing shell request before staging. A mere
            -- Render boolean cannot identify its work if a wrapper opens a newer
            -- same-draft session after the original render returns.
            local shell=M.OptionsShell
            local bound,capture,run,pure,render=pcall(function() return shell.Capture,shell.Run,shell.Pure,self.Render end)
            if not bound or type(capture)~="function" or type(run)~="function" or type(pure)~="function" or type(render)~="function" or not alive() then return end
            local captured,receipt=pcall(capture,shell)
            local function receiptCurrent()
                if not captured or type(receipt)~="table" or M.OptionsShell~=shell or shell.Capture~=capture or shell.Run~=run or shell.Pure~=pure or self.shellWork~=receipt then return false end
                local ok,current=pcall(pure,shell,receipt)
                return ok and current==true and M.OptionsShell==shell and shell.Capture==capture and shell.Run==run and shell.Pure==pure and self.shellWork==receipt
            end
            if not receiptCurrent() or not importPure(self,t,false,true) then return end
            t.work=receipt
            self.draft=p;t.draft=p;t.request.draft=p;self.importOwner=p;receipt.draft=p
            local bound,hide=pcall(function() return f.Hide end)
            if not bound or type(hide)~="function" or not importPure(self,t) then return end
            local previous=self.importWriter;self.importWriter=true
            local hidden=pcall(hide,f)
            self.importWriter=previous
            if not hidden or not importPure(self,t,true) or self.importToken~=nil then return end
            if self.Render~=render or not importPure(self,t,true) or not receiptCurrent() then return end
            local rendered,result=pcall(render,self,receipt)
            if not rendered or result~=true or not receiptCurrent() or not importPure(self,t,true) or self.importToken~=nil or self.Render~=render then return end
            self:Notice("Import is a replacement draft, not a merge. Apply replaces saved reference text. Review, then Apply or Cancel.")
        else
            if not importCall(self,t,self.importNotice,"SetText",true,why or "Import unavailable.") or not alive() then return end
            self:Notice(why)
        end
    end)
    local tab=action(function(t,alive)
        local ok,focus=pcall(GetCurrentKeyBoardFocus)
        if not ok or not alive() then return false end
        local readable,public=pcall(S.Readable,S,focus)
        if not readable or public~=true or not alive() or focus~=e then return false end
        if not importCall(self,t,e,"ClearFocus",true) or not alive() then return false end
        local started,result=importCall(self,t,D,"Start",false,f,false)
        if not started or result~=true or not alive() then return false end
        if not importCall(self,t,D,"Highlight",false,{frame=e,key="importText",kind="edit",identity=token}) or not alive() then return false end
        local shifted,shift=pcall(IsShiftKeyDown)
        if not shifted or not alive() then return false end
        local readableShift,publicShift=pcall(S.Readable,S,shift)
        if not readableShift or publicShift~=true or type(shift)~="boolean" or not alive() then return false end
        return importCall(self,t,D,"Move",false,shift and -1 or 1)
    end)
    for _,entry in ipairs({{e,"OnEscapePressed",close},{e,"OnTabPressed",tab},{f.closeButton,"OnClick",close},{self.importNavigation,"OnClick",navigate},{self.importPreview,"OnClick",preview}}) do
        if not importCall(self,t,entry[1],"SetScript",false,entry[2],entry[3]) then return importAbort(self,t) end
    end
    if not importCall(self,t,self.importNotice,"SetText",true,"") or not importCall(self,t,e,"SetText",true,"") then return importAbort(self,t) end
    t.handing=true
    local bound,shown,currentShown,ownedShow,ownedWrite=pcall(function() return D.Shown,D.CurrentShown,D.OwnedShow,D.OwnedWrite end)
    if not bound or type(shown)~="function" or type(currentShown)~="function" or type(ownedShow)~="function" or type(ownedWrite)~="function" or not importPure(self,t) then return importAbort(self,t) end
    local called,accepted,receipt=pcall(shown,D,f)
    if not called or accepted~=true or not importPure(self,t) or D.Shown~=shown or D.CurrentShown~=currentShown or D.OwnedShow~=ownedShow or D.OwnedWrite~=ownedWrite then return importAbort(self,t) end
    t.shownReceipt=receipt;t.currentShown=currentShown;t.ownedShow=ownedShow;t.ownedWrite=ownedWrite;t.opening=true
    if not importPure(self,t) then return importAbort(self,t) end
    called,accepted=pcall(ownedShow,D,f,receipt)
    if not called or accepted~=true or not importPure(self,t) or not alive() then return importAbort(self,t) end
    if not importCall(self,t,e,"SetFocus",true) or not alive() then return importAbort(self,t) end
    t.opening=nil;t.live=true
    return true
end
function O:ImportAlive(token)
    local t=self.importRequest
    if not t or not importPure(self,t) or self.importToken==nil or self.importToken~=t.token or (token and token~=t.token) or self.importOwner~=t.draft then return false end
    if not importEligible(self,t) or not importShown(self,t,self.importFrame) then return false end
    local ok,combat=pcall(t.safety.InCombat,t.safety)
    return ok and combat==false and importPure(self,t) and M.DialogNavigation.top==self.importFrame and self.importToken==t.token and self.importOwner==self.draft
end

function O:RenderSupport()
    local activation=M.Diagnostics:ActivationState()
    self:Text("head","Help and recovery",0,0,self.cw,20)
    self:Text("help",activation.message.."\n\n"..activation.help.."\n\nSource review and user testing do not grant formal native qualification.",0,-40,self.cw,12)
    self:Button("export","Copy sanitized support information",0,-180,self.cw,function() U:CopyWindow("MirageUI support information",M.Diagnostics:Export()) end)
    self:Button("profile","Measure context processing",0,-220,self.cw,function() M.profiling=not M.profiling;self:Notice(M.profiling and "Measurement on. Export after a consistent test scene." or "Measurement off.") end)
    self:Button("recover","Resume MirageUI",0,-260,self.cw,function() self:ResumeRuntime() end):SetEnabled(activation.canRecover)
    self:Text("boundaries","Coexistence: MirageUI does not disable ElvUI, EllesmereUI or standalone Cursor Companion. Native integrations pause when another suite owns them. Cursor Companion, Sanctuary and WealthCraft are independent suite addons.\n\nNo chat text, names, unit IDs, health values or raw native errors are included in support exports.",0,-310,self.cw,12)
end
function O:RenderSetup()
    local headings={"Choose your starting view","Choose your modules","Keep essential controls accessible","Choose a layout","Standalone suite addons","Ready for a first beta session"}
    self:Text("head",headings[self.step],0,0,self.cw,20)
    self:Text("step","Step "..self.step.." of 6. Nothing is applied until Finish.",0,-37,self.cw,12)
    if self.step==1 then
        self:Text("welcome","MirageUI keeps the world prominent and presents optional information when it is useful. Begin with a gentle view, or keep everything informed while learning the system.",0,-80,self.cw,12)
        self:Choice("setupPreset",self.draft.preset,M.PresetNames,self.draft.preset,0,-160,self.cw,function(v) self.draft=M.Profiles:Preset(v,self.draft) end)
    elseif self.step==2 then
        local y=-82
        for _,e in ipairs(M.Catalog) do if not e.system and e.id~="DataBars" then
            self:Check("setup"..e.id,e.name,self.draft.modules[e.id].enabled,0,y,function(v) self.draft.modules[e.id].enabled=v end);y=y-35
        end end
    elseif self.step==3 then
        self:Text("safety","Combat essentials and mandatory Blizzard prompts remain available. Extra MirageUI unit, group and action bars are optional; they do not remove the native originals.\n\nThe context engine never turns secret or missing information into a combat decision. New client builds start conservatively.\n\nUse /mirage safe at any point. Protected controls are cleaned up only when combat allows it.",0,-85,self.cw,13)
    elseif self.step==4 then
        self:Button("layoutBalanced","Balanced layout",0,-85,self.cw,function() self.draft.layouts={};self:Notice("Default centered layout selected.") end)
        self:Button("layoutCompact","Compact combat cluster",0,-128,self.cw,function()
            self.draft.layouts["ResourceBars.player"]={x=0,y=-.17,width=250,height=78,scale=.9}
            self.draft.layouts["UnitFrames.player"]={x=-.16,y=-.20,width=215,height=50,scale=.9}
            self.draft.layouts["UnitFrames.target"]={x=.16,y=-.20,width=215,height=50,scale=.9}
            self:Notice("Compact draft selected. You can refine it in Unlock Mode after setup.")
        end)
        self:Text("layoutInfo","Unlock Mode provides drag, resize, grid snapping, anchors, match-width/height, Undo and screen-edge rescue for registered editable surfaces.",0,-185,self.cw,12)
    elseif self.step==5 then
        self:Text("suiteInfo","Cursor Companion, Sanctuary and WealthCraft are standalone suite addons. Enable them independently in the AddOns list. Use /cc, /sanctuary and /wealthcraft for their own settings.",0,-85,self.cw,12)
    else
        local count=0;for _,v in pairs(self.draft.modules) do if v.enabled then count=count+1 end end
        self:Text("summary","Starting view: "..self.draft.preset.."\nModules selected: "..count.."\nClient: "..M.Client.family.."\n\nFinish saves your choices. This wizard will not reopen automatically. The MirageUI button and /mirage remain available for changes.\n\nNative verification is reserved for your completed-beta test session, not implied by completing setup.",0,-85,self.cw,13)
    end
    if self.step>1 then self:Button("back","Back",0,-math.max(390,self.contentHeight+12),100,function() self:FlushEdits();self.step=self.step-1;self:Render() end) end
end
