local M=MirageUI
if not M or not M.Options then return end
local O=M.Options
local titles={"Choose your starting view","Choose your modules","Check compatibility and controls","Choose a layout","Standalone suite addons","Under-Character HUD","Review and finish"}
local labels={"Starting view","Modules","Safety check","Layout","Suite addons","HUD","Finish"}
local recipes={
 Exploration={Minimap=true,Chat=true,Tooltips=true,QuestTracker=true,Nameplates=true,DataBars=true},
 Combat={Minimap=true,Chat=true,Tooltips=true,QuestTracker=true,Nameplates=true,DataBars=true,UnitFrames=true,ResourceBars=true,Auras=true,Cooldowns=true},
 Group={Minimap=true,Chat=true,Tooltips=true,QuestTracker=true,Nameplates=true,DataBars=true,UnitFrames=true,ResourceBars=true,Auras=true,Cooldowns=true,PartyRaid=true},
}
function O:SetupRecipe(name)
    if not self.draft or not recipes[name] then return false end
    if self.ShellPending and self:ShellPending() then return false end
    self:FlushEdits()
    for _,entry in ipairs(M.Catalog) do
        if not entry.system then self.draft.modules[entry.id].enabled=recipes[name][entry.id]==true end
    end
    self:Render();self:Notice("Module selection staged. Nothing changes in the game until Finish.")
    return true
end
function O:Setup()
    if M.Safety:InCombat() then M:Print("Open setup after combat.");return false end
    self:Create()
    self.pendingCursorImport=nil;self.draft=M:Copy(M.profile);self.setup=true;self.step=1
    self.frame:Show();self:Render();return true
end
function O:Apply()
    if not self.draft then return false end
    if M.Safety:InCombat() then self:Notice("Save after combat. No settings were changed.");return false end
    local edits,editReason=self:FlushEdits()
    if edits==false then self:Notice(editReason);return false end
    if self.setup and self.step<7 then self.step=self.step+1;self:Render();return true end
    local proposal=M:Copy(self.draft)
    if self.setup then
        proposal.onboarding=true;proposal.onboardingDismissed=false
        local summary,report=M.Readiness:Summary(proposal)
        if not report.canFinish then self:Notice("Resolve the safety-check items before saving. "..summary);return false end
    end
    local ok,reason=M.Profiles:Commit(proposal)
    if not ok then self:Notice(reason or "Settings could not be saved.");return false end
    local wasSetup=self.setup
    self.pendingCursorImport=nil;self.draft=M:Copy(M.profile);self.setup=false;self.page=wasSetup and "Home" or self.page
    self:Render()
    self:Notice(wasSetup and "Setup saved. Use /mirage to change settings, /mirage edit to arrange frames, or /mirage safe to stop effects." or "Saved.")
    return true
end
function O:Cancel()
    -- Dismissal is the only persisted setup action; draft settings and imports are discarded.
    if self.setup and not M.Safety:InCombat() and not M.Profiles.readOnly then
        local p=M:Copy(M.profile);p.onboardingDismissed=true;M.Profiles:Commit(p)
    end
    self.pendingCursorImport=nil;self.draft=nil;self.setup=false
    self.frame:Hide();M.UI:CloseChoices()
end
function O:FitWindow()
    if not self.frame or M.Safety:InCombat() then return end
    local sw,sh=UIParent:GetWidth(),UIParent:GetHeight()
    if not M.Safety:Number(sw) or not M.Safety:Number(sh) or sw<420 or sh<350 then return end
    local width,height=math.min(1020,sw-30),math.min(720,sh-30)
    self.frame:SetSize(width,height)
    self.previewEnabled=width>=930 and height>=640
    self.cw=self.previewEnabled and width-445 or width-245
    self.content:SetWidth(self.cw);self.scroll:SetWidth(self.cw+15);self.search:SetWidth(self.cw)
    self.notice:ClearAllPoints();self.notice:SetPoint("TOPLEFT",216,-height+74);self.notice:SetWidth(width-240)
    local fw=math.min(126,math.floor((width-235-32)/5))
    for i,button in ipairs({self.apply,self.cancel,self.undo,self.unlock,self.safeButton}) do
        button:ClearAllPoints();button:SetPoint("TOPLEFT",215+(i-1)*(fw+8),-height+44);button:SetWidth(fw);button.label:SetWidth(fw-16)
    end
    self.frame.closeButton:ClearAllPoints();self.frame.closeButton:SetPoint("TOPLEFT",width-42,-12)
    if self.previewEnabled and not self.preview then self:CreatePreview(width,height) end
    if self.preview then
        self.preview:SetShown(self.previewEnabled);self.previewButton:SetShown(self.previewEnabled)
        self.preview:SetHeight(height-214)
        self.previewButton:ClearAllPoints();self.previewButton:SetPoint("TOPLEFT",width-225,-height+93)
    end
end
local oldCreate=O.Create
function O:Create()
    oldCreate(self);if self.ShellBoundary then self:ShellBoundary() end
    self:FitWindow()
    if self.setupChrome then return end
    self.setupChrome=self:ShellFrame("Frame",nil,self.frame);self.setupChrome:SetPoint("TOPLEFT",18,-106);self.setupChrome:SetSize(180,310)
    self.setupStepLabels={}
    for i,text in ipairs(labels) do self.setupStepLabels[i]=self:ShellBuild("Text",self.setupChrome,i.."  "..text,0,-(i-1)*38,12,175) end
    local oldHide=self.frame:GetScript("OnHide")
    self.frame:SetScript("OnHide",function(...)
        self.pendingCursorImport=nil
        if oldHide then oldHide(...) end
    end)
end
local oldRender=O.Render
function O:Render()
    self:FitWindow()
    oldRender(self);if self.ShellBoundary then self:ShellBoundary() end
    if not self.frame or not self.setupChrome then return end
    self.setupChrome:SetShown(self.setup==true)
    self.navScroll:SetShown(not self.setup);self.search:SetShown(not self.setup)
    if self.unlock then self.unlock:SetShown(not self.setup) end
    for i,text in ipairs(self.setupStepLabels) do
        M.UI:SetTextRole(text,i==self.step and "accent" or "muted")
    end
    if self.apply then
        if self.setup and self.step==7 then self.apply:SetEnabled(M.Readiness:Inspect(self.draft).canFinish) else self.apply:Enable() end
    end
end
function O:RenderSetup()
    self:Text("setupTitle",titles[self.step],0,0,self.cw,20)
    self:Text("setupProgress","Step "..self.step.." of 7. Review now; save with Finish.",0,-38,self.cw,12)
    local y=-88
    if self.step==1 then
        self:Text("welcome","Start with your current preferences, or choose a visibility preset. Native combat controls remain available. This wizard does not replace keybindings or reset your layout.",0,y,self.cw,12);y=y-92
        local views={{value="Immersive",label="World-first — quiet exploration"},{value="Balanced",label="Balanced — gentle emphasis"},{value="Always Informed",label="Always informed — steady visibility"},{value="Accessibility",label="Accessible — steady, high contrast"}}
        self:Choice("setupPreset","Starting view: "..self.draft.preset,views,self.draft.preset,0,y,self.cw,function(v) self.draft=M.Profiles:Preset(v,self.draft) end);y=y-60
        self:Slider("setupText","Text size",0,y,self.cw,self.draft.textScale,.85,1.3,.05,function(v) self.draft.textScale=v end);y=y-72
        self:Check("setupContrast","High-contrast controls",self.draft.contrast,0,y,function(v) self.draft.contrast=v end);y=y-48
        self:Text("setupBacking","Character names keep their official class colors. Setup and the preview are not native validation results.",0,y,self.cw,11)
    elseif self.step==2 then
        self:Text("moduleGuide","Keep your existing choices, use a starting selection, or choose individual modules. You can change every choice later.",0,y,self.cw,12);y=y-66
        local width=(self.cw-16)/3
        for i,item in ipairs({{"Exploration","Exploration"},{"Combat","Combat"},{"Group","Group play"}}) do
            local key=item[1];self:Button("recipe"..key,item[2],(i-1)*(width+8),y,width,function() self:SetupRecipe(key) end)
        end
        y=y-48
        for _,e in ipairs(M.Catalog) do
            if not e.system then local id=e.id
                self:Check("setup"..id,e.name,self.draft.modules[id].enabled,0,y,function(v) self.draft.modules[id].enabled=v end);y=y-36
            end
        end
    elseif self.step==3 then
        local summary=M.Readiness:Summary(self.draft)
        self:Text("setupCheck",summary,0,y,self.cw,12);y=y-250
        self:Text("safety","Blizzard's original action, group, vehicle and special controls remain available. MirageUI never changes another addon's files or settings. Overlapping UI owners suspend the affected modules rather than compete.\n\nUse /mirage safe to stop optional presentation. Protected cleanup waits until it is legal. Review the native test card after installing this candidate.",0,y,self.cw,12);y=y-178
        self:Button("preflightRefresh","Refresh safety check",0,y,self.cw,function() self:Render() end);y=y-54
        self:RenderIntegrationControls(y,true)
    elseif self.step==4 then
        self:Text("layoutGuide","Your current positions are retained. These optional buttons stage a new layout; they do not move live controls until Finish.",0,y,self.cw,12);y=y-72
        self:Button("layoutBalanced","Use the default layout",0,y,self.cw,function() self.draft.layouts={};self:Notice("Default layout staged. Finish saves it.") end);y=y-42
        self:Button("layoutCompact","Use a compact combat cluster",0,y,self.cw,function()
            self.draft.layouts["ResourceBars.player"]={x=0,y=-.17,width=250,height=78,scale=.9}
            self.draft.layouts["UnitFrames.player"]={x=-.16,y=-.20,width=300,height=55,scale=.9}
            self.draft.layouts["UnitFrames.target"]={x=.16,y=-.20,width=300,height=55,scale=.9}
            self:Notice("Compact cluster staged. Existing unrelated positions are retained.")
        end);y=y-48
        for _,count in ipairs({10,20,40}) do local n=count
            self:Button("layoutRaid"..n,"Stage compact Raid "..n,0,y,self.cw,function() self:StageGroupLayout("compact",n) end);y=y-38
        end
        self:Text("layoutInfo","After setup, Unlock Mode offers dragging, resizing, snapping, matching dimensions and screen-edge rescue. No protected layout changes are made during combat.",0,y-12,self.cw,12)
    elseif self.step==5 then
        self:Text("suiteModules","Cursor Companion, Sanctuary and WealthCraft install as independent addons. Enable each one in the AddOns list. Their settings, saved profiles and shortcuts stay separate.\n\nUse /cc, /sanctuary and /wealthcraft to configure them.",0,y,self.cw,12)
    elseif self.step==6 then
        y=self:RenderHUDControls(self.draft.modules.UnderCharacterHUD,y,true)
    else
        local text,report=M.Readiness:Summary(self.draft)
        local names={};for _,e in ipairs(M.Catalog) do if not e.system and self.draft.modules[e.id].enabled then names[#names+1]=e.name end end
        self:Text("summary","Starting view: "..self.draft.preset.."\n"..text.."\n\nSelected: "..table.concat(names,", ").."\n\n".."Presentation ownership: "..M.Presentation:Report(self.draft).."\n\nFinish saves this profile. This wizard will not reopen automatically. Use /mirage setup to run it again. Native testing and validation are still required.",0,y,self.cw,12)
    end
    if self.step>1 then self:Button("back","Back",0,-math.max(420,self.contentHeight+16),110,function() if self.ShellTransition then return self:ShellTransition(true,false,self.page,false,self.step-1) end;self:FlushEdits();self.step=self.step-1;self:Render() end) end
end
-- These entry points describe source/install checks, never grant native approval.
local support=O.RenderSupport
function O:RenderSupport()
    support(self)
    self:Button("installCheck","Installation and compatibility check",0,-(self.contentHeight+16),self.cw,function() M.UI:CopyWindow("MirageUI installation check",M.Readiness:Export()) end)
end
