local M=MirageUI
if not M or not M.Options then return end
local O,U=M.Options,M.UI
local presetNames={"Compact","Standard","Accessible","Reference central HUD"}
local presets={
    -- Rounded UI-unit translation, deliberately staged rather than a migration.
    -- Empty-track backing is distinct from the rectangle behind the whole stack.
    ["Reference central HUD"]={policy=2,layoutOrder=2,layoutRevision=1,rowPitch=24,x=1,y=-236,width=214,castWidthExtra=6,hudScale=100,healthHeight=16,resourceHeight=14,castHeight=20,gap=0,opacity=100,backdrop=0,trackOpacity=75,healthFillOpacity=15,resourceFillOpacity=15,castFillOpacity=100},
    Compact={width=180,hudScale=100,healthHeight=7,resourceHeight=5,castHeight=5,gap=2},
    Standard={width=205,hudScale=100,healthHeight=10,resourceHeight=7,castHeight=7,gap=3},
    Accessible={width=260,hudScale=125,healthHeight=14,resourceHeight=10,castHeight=10,gap=4,opacity=100,trackOpacity=90},
}
M.HUDPresets=presets
local geometryFields={x=true,y=true,width=true,hudScale=true,healthHeight=true,resourceHeight=true,castHeight=true,gap=true,rowPitch=true,layoutRevision=true,layoutOrder=true,castWidthExtra=true}
function O:SetHUDValue(cfg,key,value)
    -- Manual geometry must survive the next resize. This changes only the
    -- settings draft; opening, canceling, or editing appearance keeps auto-fit.
    if geometryFields[key] and cfg[key]~=value and self.draft and self.draft.managed then self.draft.autoLayout=false end
    cfg[key]=value
end
function O:StageHUDReference()
    local draft=self.draft;local cfg=draft and draft.modules.UnderCharacterHUD
    if not cfg then return false end
    local ok,why=self:FlushEdits()
    if ok==false then self:Notice(why);return false end
    if self.draft~=draft or draft.modules.UnderCharacterHUD~=cfg then return false end
    for key,value in pairs(presets["Reference central HUD"]) do self:SetHUDValue(cfg,key,value) end
    -- Explicit preset adoption is manual geometry. Later automatic fit must be
    -- another deliberate action; no startup or profile-load path calls this.
    if draft.managed then draft.autoLayout=false end
    self:Render();return true
end
function O:StageCooldownRefit(enabled)
    local draft=self.draft;if not draft then return false end
    local ok,why=self:FlushEdits();if ok==false then self:Notice(why);return false end
    if self.draft~=draft then return false end
    local proposal,reason=M.Managed:BuildCooldownRefit(draft,enabled)
    if self.draft~=draft then return false end
    if not proposal then self:Notice(reason);return false end
    self.draft=proposal;self.pendingFit=true;self:Render()
    self:Notice("Refit staged only. Apply rechecks the viewport; Cancel preserves current settings. Native viewer fitting remains conditional.")
    return true
end
function O:HUDSample(cfg,y)
    if not self.hudSample then
        local frame=CreateFrame("Frame",nil,self.content);frame:SetSize(self.cw,210);M.Safety:Passive(frame)
        self.hudSample={frame=frame,view=M.HUDView:Create(frame)}
        self.hudSample.caption=U:Text(frame,"HUD preview · sample values",0,-4,12,self.cw)
        self.pool["custom:hudSample"]=frame
    end
    local sample=self.hudSample
    sample.frame:SetWidth(self.cw);sample.caption:SetWidth(self.cw)
    sample.view.root:ClearAllPoints();sample.view.root:SetPoint("TOPLEFT",sample.frame,"TOPLEFT",8,-36)
    local fit=math.min(1,(self.cw-16)/(M.HUDView:Geometry(cfg)*cfg.hudScale/100))
    sample.view.root:SetScale(fit)
    M.HUDView:Sample(sample.view,cfg,true,self.draft and self.draft.textScale)
    sample.caption:SetText(fit<1 and "HUD preview · DEMO, fitted to this panel" or "HUD preview · sample values")
    self:Place(sample.frame,0,y)
    -- Equal lane pitch plus the spell footer can reach 156 scaled UI units.
    -- Reserve caption and the complete stack without covering later controls.
    return y-220
end
function O:RefreshHUDSample()
    local cfg=self.draft and self.draft.modules.UnderCharacterHUD
    if cfg and self.hudSample and self.hudSample.frame:IsShown() then
        local fit=math.min(1,(self.cw-16)/(M.HUDView:Geometry(cfg)*cfg.hudScale/100))
        self.hudSample.view.root:SetScale(fit)
        M.HUDView:Sample(self.hudSample.view,cfg,true,self.draft and self.draft.textScale)
        self.hudSample.caption:SetText(fit<1 and "HUD preview · DEMO, fitted to this panel" or "HUD preview · sample values")
        if self.pool["text:hudPercentStatus"] then self.pool["text:hudPercentStatus"]:SetText("Preview label fit: health "..M.HUDPercent:Status(self.hudSample.view,"health").."; resource "..M.HUDPercent:Status(self.hudSample.view,"resource")) end
    end
end
function O:RenderHUDControls(cfg,y,wizard)
    y=y or -143
    self:Text("hudIntent","Three player bars at a fixed screen location below center. Camera zoom never moves or resizes this display; camera tilt can move the character independently.",0,y,self.cw,12);y=y-84
    y=self:HUDSample(cfg,y)
    self:Check("hudEnable","Enable Under-Character HUD",cfg.enabled,0,y,function(v) cfg.enabled=v end);y=y-40
    for _,row in ipairs({{"health","Health"},{"resource","Primary resource"},{"cast","Cast / channel — only while active"}}) do
        local key=row[1];self:Check("hud"..key,row[2],cfg[key],0,y,function(v) cfg[key]=v end);y=y-38
    end
    local choices={{value=1,label="Always show health and resource"},{value=2,label="Combat; cast row while casting"}}
    local policy=cfg.policy==1 and 1 or 2
    self:Choice("hudPolicy","When to show: "..choices[policy].label,choices,policy,0,y,self.cw,function(v) cfg.policy=v end);y=y-42
    self:Text("hudPolicyFallback","Outside combat, an active cast reveals only its cast row and brief result. A stale target does not hold the player HUD open. If the custom cast cannot take ownership, the native cast bar remains available.",0,y,self.cw,11);y=y-78
    self:Choice("hudPreset","Choose a size preset",presetNames,nil,0,y,self.cw,function(v)
        if v=="Reference central HUD" then self:StageHUDReference();return end
        for k,value in pairs(presets[v]) do self:SetHUDValue(cfg,k,value) end
    end);y=y-44
    local function slider(key,label,lo,hi)
        self:Slider("hud_"..key,label,0,y,self.cw,cfg[key],lo,hi,1,function(v) self:SetHUDValue(cfg,key,v);self:RefreshHUDSample() end);y=y-65
    end
    slider("x","Horizontal offset (UI units)",-500,500);slider("y","Vertical offset (UI units)",-500,-60)
    self:Button("hudPlace","Place HUD — drag, nudge and lock",0,y,self.cw,function()
        local ok,why=self:FlushEdits();if ok==false then self:Notice(why);return end;M.HUDEditor:Open(self)
    end);y=y-40
    self:Button("hudCenter","Reset position to center / −185",0,y,self.cw,function() self:SetHUDValue(cfg,"x",0);self:SetHUDValue(cfg,"y",-185);self:Render() end);y=y-46
    slider("width","Width",160,300);slider("hudScale","HUD size (%)",75,150)
    slider("healthHeight","Health bar height",6,16);slider("resourceHeight","Resource bar height",4,16);slider("castHeight","Cast bar height",4,24)
    local orders={{value=1,label="Health / resource / cast"},{value=2,label="Cast / health / resource"}}
    self:Choice("hudOrder","Row order: "..orders[cfg.layoutOrder].label,orders,cfg.layoutOrder,0,y,self.cw,function(v) self:SetHUDValue(cfg,"layoutOrder",v) end);y=y-42
    if self.draft and self.draft.managed then
        self:Button("hudCentralCooldownRefit","Stage central cooldown refit",0,y,self.cw,function() self:StageCooldownRefit(true) end);y=y-42
        self:Button("hudStandardCooldownRefit","Stage standard refit (ungroup cooldowns)",0,y,self.cw,function() self:StageCooldownRefit(false) end);y=y-42
        self:Text("hudCooldownRefitScope","Explicit refit moves the planned layout: main and utility cooldown envelopes stay below the reserved HUD as one group. Existing icon content, native visibility and fonts are unchanged. Native fit can decline; optional panels/artwork are not covered. Manual edits suspend grouping; manual reload leaves native positions authoritative.",0,y,self.cw,11);y=y-142
        local selected=self.draft.modules.Cooldowns.centralGroup
        self:Text("hudCooldownRefitState","Draft cooldown layout: "..(selected and (self.draft.autoLayout and "CENTRAL REFIT SELECTED" or "SUSPENDED_MANUAL") or "STANDARD").." · last native submission: "..(M.ManagedNative.status.CentralCooldowns or "NOT_RUN"),0,y,self.cw,11);y=y-64
    end
    slider("castWidthExtra","Extra cast width (UI units)",0,32)
    slider("rowPitch","Row spacing (grows to fit taller bars)",10,32);slider("opacity","Whole HUD opacity (%)",40,100);slider("trackOpacity","Row backing opacity (%)",20,100)
    slider("healthFillOpacity","Health fill opacity (%)",0,100);slider("resourceFillOpacity","Resource fill opacity (%)",0,100);slider("castFillOpacity","Cast fill opacity (%)",0,100)
    self:Text("hudLayerScope","Fill opacity does not fade row backing. Whole HUD opacity intentionally multiplies both. Native-owned cast styling stays native; its size is a maximum fit envelope. Optional percentage text has its own opacity and selected size; labels that do not fit are omitted, never shrunk.",0,y,self.cw,11);y=y-94
    self:Check("hudPercent","Show health / resource percentages when supported and fitted",cfg.showPercent,0,y,function(v) cfg.showPercent=v;self:RefreshHUDSample() end);y=y-42
    slider("percentTextSize","Percentage text size (before text / HUD scale)",8,24)
    slider("percentTextOpacity","Percentage text opacity (%)",0,100)
    self:Text("hudPercentScope","Off by default. Saved row sizes and selected text size are never changed to fit labels. At large text scales labels may not fit even the maximum row height. The 15-point reference text may not fit its 14-unit resource row. Unsupported text stays absent; native bars remain available.",0,y,self.cw,11);y=y-110
    local status=self.hudSample and self.hudSample.view
    self:Text("hudPercentStatus","Preview label fit: health "..M.HUDPercent:Status(status,"health").."; resource "..M.HUDPercent:Status(status,"resource"),0,y,self.cw,11);y=y-62
    for _,key in ipairs({"health","resource","cast"}) do
        local choices={{value=1,label=key=="resource" and "Native resource color" or "MirageUI theme"},{value=2,label="Player class color"},{value=3,label="Custom RGB"}}
        self:Choice("hudColor"..key,key.." color: "..choices[cfg[key.."Color"]].label,choices,cfg[key.."Color"],0,y,self.cw,function(v) cfg[key.."Color"]=v end);y=y-42
        if cfg[key.."Color"]==3 then for _,channel in ipairs({"R","G","B"}) do slider(key..channel,key.." "..channel,0,255) end end
    end
    self:Text("hudCompatibility",M.HUDData:Overlap().."\n\nGameplay bars are click-through and locked. Health and resource keep their positions when casting starts or stops. The spell name and cast state appear below the cast row. Pet battles and vehicle control use native controls. Secondary class resources remain in their own display; unsupported empowered-stage detail stays native.",0,y,self.cw,11);y=y-190
    self:Button("hudWhy","Why is the live HUD visible or hidden?",0,y,self.cw,function() U:CopyWindow("HUD visibility",M.Diagnostics:Why("UnderCharacterHUD")) end);y=y-42
    self:Button("hudOwnership","Review primary display / native duplicates",0,y,self.cw,function() self:FlushEdits();self.setup=false;self.page="Integration";self:Render() end);y=y-42
    self:Button("hudReset","Restore only HUD defaults",0,y,self.cw,function()
        local defaults=M.Profiles:Defaults().modules.UnderCharacterHUD
        for key,value in pairs(defaults) do self:SetHUDValue(cfg,key,value) end
        self.draft.modules.UnderCharacterHUD=defaults;self:Render()
    end);y=y-42
    if not wizard then
        self:Button("hudWizard","Open HUD setup step",0,y,self.cw,function() self:Setup();self.step=6;self:Render() end);y=y-42
    end
    return y
end
local oldSpecial=O.RenderSpecialModule
function O:RenderSpecialModule(id,cfg)
    if id=="UnderCharacterHUD" then self:RenderHUDControls(cfg,-143,false);return true end
    return oldSpecial(self,id,cfg)
end
-- Placement edits a private copy, then stages it back into the owner's draft.
-- It never moves the live HUD, changes CVars, or captures input during gameplay.
M.HUDEditor={}
local E=M.HUDEditor
function E:Alive()
    return self.owner and self.owner.draft==self.draft and self.owner.draft.modules.UnderCharacterHUD==self.target and self.owner.frame and self.owner.frame:IsShown() and not M.Safety:InCombat() and not M.state.safe and not M.state.cinematic
end
function E:CanInput()
    return self:Alive() and self.window and self.window:IsShown() and not M.state.safe and
        M.DialogNavigation.top==self.window and not M.Safety:Typing()
end
function E:LayoutWindow()
    local scale=M.profile.textScale or 1;local width=math.max(560,math.ceil(560*scale));local button=math.ceil(28*scale)
    local positionY=55+math.ceil(34*scale)+14;local controlsY=positionY+math.ceil(36*scale)+12
    local nudgeY=controlsY+button+12;local footerY=nudgeY+button+12;local height=footerY+button+20
    local function place(f,x,y,w)
        f:ClearAllPoints();f:SetPoint("TOPLEFT",x,-y);f:SetWidth(w)
        if f.label then f:SetHeight(button);f.label:SetWidth(w-16) end
    end
    self.window:SetSize(width,height);self.window.heading:SetWidth(width-80)
    place(self.window.closeButton,width-42,12,28);self.window.closeButton:SetHeight(28)
    place(self.hint,20,55,width-40);place(self.position,20,positionY,width-40)
    local third=(width-56)/3
    place(self.center,20,controlsY,third);place(self.lock,28+third,controlsY,third);place(self.navStart,36+2*third,controlsY,third)
    local quarter=(width-64)/4
    for i,b in ipairs(self.nudges) do place(b,20+(i-1)*(quarter+8),nudgeY,quarter) end
    place(self.stage,20,footerY,(width-48)/2);place(self.cancel,28+(width-48)/2,footerY,(width-48)/2)
    local sw,ws=M.Safety:Public(UIParent.GetWidth,"number",UIParent);local sh,hs=M.Safety:Public(UIParent.GetHeight,"number",UIParent)
    if ws~="KNOWN" or hs~="KNOWN" or sw<=30 or sh<=30 then return false end
    self.window:SetScale(math.min(1,(sw-30)/width,(sh-30)/height));return true
end
function E:Place()
    if not self.cfg then return end
    local c=self.cfg
    self.handle:ClearAllPoints();self.handle:SetPoint("CENTER",UIParent,"CENTER",c.x,c.y)
    local w,h=M.HUDView:Geometry(c);self.handle:SetSize(w*c.hudScale/100,math.max(24,h*c.hudScale/100))
    M.HUDView:Sample(self.sample,c,true,self.draft and self.draft.textScale)
    local width,height=UIParent:GetWidth(),UIParent:GetHeight()
    local guide=""
    if M.Safety:Number(width) and M.Safety:Number(height) and width>0 and height>0 then
        guide=string.format("  |  %.1f%% across / %.1f%% down",50+100*c.x/width,50-100*c.y/height)
    end
    self.position:SetText("X "..c.x.."   Y "..c.y..guide.."\n"..(self.locked and "Locked" or "Drag or use arrow keys; Shift = 10"))
end
function E:Nudge(dx,dy)
    if not self:CanInput() or self.locked then return false end
    self.cfg.x=math.max(-500,math.min(500,self.cfg.x+dx));self.cfg.y=math.max(-500,math.min(-60,self.cfg.y+dy));self:Place();return true
end
function E:Close()
    self.drag=nil;self.owner=nil;self.draft=nil;self.target=nil;self.cfg=nil;self.handlePressed={}
    if M.DialogNavigation.active==self.window then M.DialogNavigation:Stop() end
    if self.handle then self.handle:SetScript("OnUpdate",nil);self.handle:EnableKeyboard(false);self.handle:Hide() end
    if self.window then self.window:Hide() end
end
function E:Create()
    if self.window then return end
    local f=U:Panel("MirageUIHUDPlacement","HUD placement · DEMO",560,235);self.window=f
    f:ClearAllPoints();f:SetPoint("TOP",UIParent,"TOP",0,-60)
    self.hint=U:Text(f,"Sample only. Stage, then Apply in settings.\nF6: keyboard focus. Controller: D-pad / A / B.",20,-55,12,520)
    self.position=U:Text(f,"",20,-105,12,520)
    self.center=U:Button(f,"Center",20,-139,110,function() if self.cfg and self:CanInput() then self.cfg.x=0;self.cfg.y=-185;self:Place() end end)
    self.lock=U:Button(f,"Lock / unlock",140,-139,150,function() if not self:CanInput() then return end;self.locked=not self.locked;self:Place() end)
    self.navStart=U:Button(f,"Controller",300,-139,180,function() M.DialogNavigation:Start(f,true) end)
    self.nudges={}
    for i,row in ipairs({{"Left",-1,0},{"Right",1,0},{"Up",0,1},{"Down",0,-1}}) do
        self.nudges[i]=U:Button(f,row[1],20+(i-1)*130,-180,120,function()
            local step=M.Safety:Public(IsShiftKeyDown,"boolean") and 10 or 1
            self:Nudge(row[2]*step,row[3]*step)
        end)
    end
    self.stage=U:Button(f,"Stage position",20,-225,180,function()
        if not self:Alive() then self:Close();return end
        if not self:CanInput() then return end
        local o=self.owner;local c=o.draft.modules.UnderCharacterHUD
        o:SetHUDValue(c,"x",self.cfg.x);o:SetHUDValue(c,"y",self.cfg.y)
        self:Close();o:Render();o:Notice("HUD position staged. Apply or Finish saves it; Cancel discards it.")
    end)
    self.cancel=U:Button(f,"Cancel placement",210,-225,180,function() self:Close() end)
    local h=CreateFrame("Frame",nil,UIParent,"BackdropTemplate");self.handle=h
    U:Backdrop(h,true);h:SetFrameStrata("DIALOG");h:EnableMouse(true);h:RegisterForDrag("LeftButton")
    self.sample=M.HUDView:Create(h);self.sample.root:SetPoint("CENTER",h,"CENTER",0,0)
    h:SetScript("OnDragStart",function()
        if not self:CanInput() or self.locked then return end
        local x,y=GetCursorPosition();local scale=UIParent:GetEffectiveScale()
        if not M.Safety:Number(x) or not M.Safety:Number(y) or not M.Safety:Number(scale) or scale<=0 then return end
        self.drag={x=x/scale,y=y/scale,startX=self.cfg.x,startY=self.cfg.y}
        h:SetScript("OnUpdate",function()
            if not self:Alive() then self:Close();return end
            if not self:CanInput() then self.drag=nil;h:SetScript("OnUpdate",nil);return end
            local x,y=GetCursorPosition();local scale=UIParent:GetEffectiveScale()
            if M.Safety:Number(x) and M.Safety:Number(y) and M.Safety:Number(scale) and scale>0 then
                self.cfg.x=math.max(-500,math.min(500,math.floor(self.drag.startX+x/scale-self.drag.x+.5)))
                self.cfg.y=math.max(-500,math.min(-60,math.floor(self.drag.startY+y/scale-self.drag.y+.5)))
                self:Place()
            end
        end)
    end)
    h:SetScript("OnDragStop",function() self.drag=nil;h:SetScript("OnUpdate",nil) end)
    h:SetScript("OnKeyDown",function(_,key)
        if not self:Alive() then self:Close();return end
        local delta={UP={0,1},DOWN={0,-1},LEFT={-1,0},RIGHT={1,0}}
        local navigation=M.DialogNavigation.active==f
        local handled=self:CanInput() and ((key=="ESCAPE" and not navigation) or (delta[key]~=nil and not self.locked))
        if not M.Safety:InCombat() and h.SetPropagateKeyboardInput then h:SetPropagateKeyboardInput(not handled) end
        if not handled then return end
        if key=="ESCAPE" then self:Close()
        else local step=M.Safety:Public(IsShiftKeyDown,"boolean") and 10 or 1;self:Nudge(delta[key][1]*step,delta[key][2]*step) end
        self.handlePressed=self.handlePressed or {};self.handlePressed[key]=true
    end)
    h:SetScript("OnKeyUp",function(_,key)
        local consumed=self.handlePressed and self.handlePressed[key]
        if self.handlePressed then self.handlePressed[key]=nil end
        if not M.Safety:InCombat() and h.SetPropagateKeyboardInput then h:SetPropagateKeyboardInput(not consumed) end
    end)
    f.closeButton:SetScript("OnClick",function() self:Close() end)
    f:SetScript("OnHide",function() if self.owner then self:Close() end end)
    f:SetScript("OnUpdate",function() if self.owner and not self:Alive() then self:Close() end end)
    M.DialogNavigation:Attach(f,{closeOnSuspend=true,allowed=function() return self:Alive() end,close=function() self:Close() end,entries=function()
        local entries={}
        for _,row in ipairs({{self.navStart,"navigation"},{self.center,"center"},{self.lock,"lock"}}) do entries[#entries+1]={frame=row[1],key=row[2],kind="button",identity=self.cfg} end
        for i,b in ipairs(self.nudges) do entries[#entries+1]={frame=b,key="nudge:"..i,kind="button",identity=self.cfg} end
        for _,row in ipairs({{self.stage,"stage"},{self.cancel,"cancel"},{f.closeButton,"close"}}) do entries[#entries+1]={frame=row[1],key=row[2],kind="button",identity=self.cfg} end
        return entries
    end})
    h:Hide()
end
function E:Open(owner)
    if M.Safety:InCombat() or M.state.safe or M.state.cinematic or not owner.draft or not owner.frame or not owner.frame:IsShown() then return false end
    self:Create()
    if not self:LayoutWindow() then self:Close();return false end
    if self.owner~=owner or not self:Alive() then
        self:Close();self.owner=owner;self.draft=owner.draft;self.target=owner.draft.modules.UnderCharacterHUD;self.cfg=M:Copy(self.target);self.locked=false
    end
    M.DialogNavigation:Shown(self.window);self.window:Show();self.handle:Show();self.handle:EnableKeyboard(true)
    if self.handle.SetPropagateKeyboardInput then self.handle:SetPropagateKeyboardInput(true) end
    self:Place();return true
end
local oldCreate=O.Create
function O:Create()
    oldCreate(self)
    if not self.hudCloseHook then
        self.hudCloseHook=true;local close=self.frame:GetScript("OnHide")
        self.frame:SetScript("OnHide",function(...) E:Close();if close then close(...) end end)
    end
end
