local M=MirageUI
if not M or not M.WorkspaceModel then return end
local U,S,W=M.UI,M.Safety,M.WorkspaceModel
local A={page="Customize",forms={},cursorPage="Home"}
M.Workspace=A
-- Small reusable form builder: cached controls are refreshed, not accumulated on
-- every keypress or drag. Only authored settings enter these controls.
local Form={};Form.__index=Form
M.WorkspaceForm=Form
local controlArt="Interface\\AddOns\\MirageUIOptions\\Media\\Controls\\"
local displayArt={
 ActionBars="ActionBars",UnitFrames="UnitFrames",PartyRaid="PartyRaid",Nameplates="Nameplates",Auras="Auras",
 Cooldowns="Cooldowns",DamageMeters="DamageMeters",ResourceBars="ResourceBars",UnderCharacterHUD="UnderCharacterHUD",
 Minimap="Minimap",QuestTracker="QuestTracker",DataBars="DataBars",Chat="Chat",Notifications="Notifications",
 Tooltips="Tooltips",Bags="Bags",Preparations="Preparations",PvP="PvP",TacticalSignals="TacticalSignals",
 ["section.appearance"]="Appearance",["section.startup"]="Startup",back="Home",
 ["companion.MirageIntel_Map"]="Map",["companion.MirageIntel_Navigate"]="Navigate",["companion.MirageIntel_Gather"]="Gather"}
local function displayIcon(key,module)
 return controlArt..(displayArt[key] or displayArt[module] or "Displays")..".tga"
end
local function alignButton(button,path)
 local label=button.label
 if not button.controlIcon then button.controlIcon=button:CreateTexture(nil,"ARTWORK") end
 local icon=button.controlIcon
 icon:Show();icon:SetTexture(path);icon:SetSize(22,22);icon:SetPoint("LEFT",9,0)
 label:ClearAllPoints();label:SetPoint("LEFT",38,0);label:SetPoint("RIGHT",-8,0)
 label:SetJustifyH("LEFT");label:SetJustifyV("MIDDLE")
end
function Form:New(parent,width)
 return setmetatable({parent=parent,width=width or 580,cache={},used={},y=0},self)
end
function Form:Begin() self.y=0;self.indent=0;self.used={} end
function Form:Place(key,kind,make,height)
 local item=self.cache[key]
 if not item then item={kind=kind};item.frame=make(item);self.cache[key]=item end
 self.used[key]=true;item.frame:ClearAllPoints();item.frame:SetPoint("TOPLEFT",self.indent or 0,-self.y);item.frame:Show()
 self.y=self.y+(height or item.frame:GetHeight())+10
 return item
end
function Form:Text(key,text,height,accent,icon)
 local it=self:Place(key,"text",function() return U:Text(self.parent,"",0,0,13,self.width) end,height or 42)
 local minimum=height or 42
 it.frame:SetWidth(self.width-(self.indent or 0));it.frame:SetHeight(0);it.frame:SetText(M.Icons and icon and M.Icons:Label(icon,text,20) or text)
 local measured=it.frame.GetStringHeight and it.frame:GetStringHeight() or minimum
 if type(measured)~="number" or measured~=measured then measured=minimum end
 local actual=math.max(minimum,math.min(1600,measured+4));it.frame:SetHeight(actual);self.y=self.y+actual-minimum
 U:SetTextRole(it.frame,key=="title" and "heading" or (accent or key=="version" or key=="intro") and "secondary" or "text");return it.frame
end
function Form:Button(key,label,callback,icon)
 local it=self:Place(key,"button",function(item) return U:Button(self.parent,"",0,0,self.width,function()
  if W.draft then local ok,why=W:Current();if not ok then A:Notice(why);return end end
  if not A:FlushInputs() then return end
  if item.callback then item.callback() end
 end) end,28)
 icon=icon or M.Icons and M.Icons:ForModule(key)
 it.callback=callback
 if self.compact then
  it.frame:SetWidth(self.width)
  alignButton(it.frame,displayIcon(key,A.selectedModule))
  it.frame:SetText(label)
 else
  if it.frame.controlIcon then
   it.frame.controlIcon:Hide();it.frame:SetWidth(self.width)
   it.frame.label:ClearAllPoints();it.frame.label:SetPoint("LEFT",8,0);it.frame.label:SetPoint("RIGHT",-8,0)
   it.frame.label:SetJustifyH("CENTER")
  end
  it.frame:SetText(M.Icons and icon and M.Icons:Label(icon,label,18) or label)
 end
 if self.helpActions then
  local font=it.frame.label
  local measured=font.GetUnboundedStringWidth and font:GetUnboundedStringWidth() or font.GetStringWidth and font:GetStringWidth()
  it.frame:SetWidth(math.min(math.floor(self.width*.75),320,math.max(100,math.ceil(measured or #label*8)+28)))
 elseif not self.compact then
  it.frame:SetWidth(self.width)
 end
 local height=it.frame.label.GetStringHeight and it.frame.label:GetStringHeight() or 12
 if type(height)~="number" or height~=height then height=12 end
 height=math.max(28,math.min(160,height+16));it.frame:SetHeight(height);self.y=self.y+height-28
 return it.frame
end
-- P39-A.1: losslessly cropped 2048x512 user-supplied banner artwork.
-- Preserve the framed image's aspect ratio; center at 80% of the previous banner size
-- to show all three choices together even on the small-screen workspace.
-- Illumination is only updated during an active hover fade.
local bannerMedia="Interface\\AddOns\\MirageUIOptions\\Media\\SettingsBanners\\"
local bannerAspect=512/2048
function Form:Banner(key,file,callback,label)
 local width=math.floor(self.width*.88*.8+.5)
 local height=math.floor(width*bannerAspect+.5)
 local top=self.y
 local item=self:Place(key,"banner",function(item)
  local b=CreateFrame("Button",nil,self.parent)
  b:SetSize(width,height)
  b:EnableMouse(true)
  b:RegisterForClicks("LeftButtonUp")
  b.mirageActionLabel=label
  local path=bannerMedia..file
  local art=b:CreateTexture(nil,"ARTWORK")
  art:SetAllPoints(b);art:SetTexture(path)
  art:SetTexCoord(0,1,0,1)
  local illuminate=b:CreateTexture(nil,"OVERLAY")
  illuminate:SetAllPoints(b);illuminate:SetTexture(path)
  illuminate:SetTexCoord(0,1,0,1)
  illuminate:SetBlendMode("ADD");illuminate:SetVertexColor(1,.9,.72,1)
  illuminate:SetAlpha(0)
  local line=b:CreateTexture(nil,"OVERLAY",nil,2)
  line:SetPoint("TOPLEFT",b,"TOPLEFT",8,0)
  line:SetPoint("TOPRIGHT",b,"TOPRIGHT",-8,0)
  line:SetHeight(2);line:SetColorTexture(unpack(M.Theme.accent))
  item.art,item.illuminate=art,illuminate
  local function fade(button,elapsed)
   local goal=button.mirageHovered and .085 or 0
   local current=button.mirageGlow or 0
   local dt=type(elapsed)=="number" and math.max(0,math.min(.1,elapsed)) or 0
   current=current+(goal-current)*math.min(1,dt*13)
   if math.abs(goal-current)<.003 then current=goal end
   button.mirageGlow=current;illuminate:SetAlpha(current)
   if current==goal then button:SetScript("OnUpdate",nil) end
  end
  b:SetScript("OnEnter",function(button)
   button.mirageHovered=true;button:SetScript("OnUpdate",fade)
  end)
  b:SetScript("OnLeave",function(button)
   button.mirageHovered=false;button:SetScript("OnUpdate",fade)
  end)
  b:SetScript("OnHide",function(button)
   button.mirageHovered=false;button.mirageGlow=0
   illuminate:SetAlpha(0);button:SetScript("OnUpdate",nil)
  end)
  b:SetScript("OnClick",function(_,mouseButton)
   if mouseButton~="LeftButton" or A.page~="Customize" or not A.frame or not A.frame:IsShown() then return end
   if W.draft then local ok,why=W:Current();if not ok then A:Notice(why);return end end
   if not A:FlushInputs() then return end
   if item.callback then item.callback() end
  end)
  return b
 end,height)
 item.callback=callback
 item.frame:SetSize(width,height)
 item.frame:ClearAllPoints()
 item.frame:SetPoint("TOPLEFT",self.parent,"TOPLEFT",math.floor((self.width-width)/2+.5),-top)
 return item.frame
end
local function optionLabel(form,label)
 if not form.compact then return label end
 return "|T"..displayIcon(nil,A.selectedModule)..":20:20|t "..label
end
function Form:Edit(key,label,value,callback,maxLetters)
 self:Text(key.."label",optionLabel(self,label),22)
 local it=self:Place(key,"edit",function(item)
  local edit=U:Edit(self.parent,0,0,self.width,"",nil)
  item.lastText=""
  function edit:Pending() return self:GetText()~=item.lastText end
  function edit:CaptureInput() return {text=self:GetText(),last=item.lastText} end
  function edit:RestoreInput(state) self:SetText(state.text);item.lastText=state.last end
  function edit:Validate() return true end
  function edit:Commit()
   if not self:Pending() then return true end
   local text=self:GetText();local ok,why=true,nil
   if item.callback then ok,why=item.callback(text) end
   if ok==false then return false,why end
   item.lastText=text;return true
  end
  edit:SetScript("OnEnterPressed",function(frame) local ok,why=A:FlushInputs();if ok then frame:ClearFocus() else A:Notice(why) end end)
  edit:SetScript("OnEscapePressed",function(frame) frame:SetText(item.lastText);frame:ClearFocus() end)
  return edit
 end,28)
 it.callback=callback;it.frame:SetMaxLetters(maxLetters or 160)
 if not it.frame:Pending() then it.lastText=value or "";it.frame:SetText(it.lastText) end
 return it.frame
end
function Form:Slider(key,label,value,lo,hi,step,callback)
 local it=self:Place(key,"slider",function(item)
  return U:Slider(self.parent,label,0,0,self.width,value,lo,hi,step,function(v) if item.callback then item.callback(v) end end)
 end,55)
 it.callback=callback;it.frame.label:SetText(optionLabel(self,label));it.frame.slider:SetMinMaxValues(lo,hi)
 if not it.frame:Pending() then it.frame.setValue(value) end
 return it.frame
end
function Form:Choice(key,label,value,values,labels,callback)
 return self:Button(key,label..": "..tostring(labels and labels[value] or value),function(button)
  local anchor=self.cache[key].frame
  local choices={};for _,v in ipairs(values) do choices[#choices+1]={value=v,label=labels and labels[v] or tostring(v)} end
  U:Choose(anchor,choices,value,callback)
 end)
end
function Form:Toggle(key,label,value,callback,immediate)
 local it=self:Place(key,"toggle",function(item)
  local button=U:Button(self.parent,"",0,0,self.width,function()
   if not item.immediate then
    if W.draft then local ok,why=W:Current();if not ok then A:Notice(why);return end end
    if not A:FlushInputs() then return end
   end
   if item.callback then item.callback(not item.value) end
  end)
  button.label:ClearAllPoints();button.label:SetPoint("LEFT",38,0);button.label:SetPoint("RIGHT",-10,0);button.label:SetJustifyH("LEFT")
  local box=CreateFrame("Frame",nil,button,"BackdropTemplate");box:SetSize(18,18);box:SetPoint("LEFT",10,0);U:Backdrop(box,true)
  local mark=box:CreateTexture(nil,"ARTWORK");mark:SetAllPoints();mark:SetTexture("Interface\\Buttons\\UI-CheckBox-Check");mark:SetVertexColor(1,.78,.18,1)
  item.mark=mark;return button
 end,30)
 it.value=value==true;it.callback=callback;it.immediate=immediate;it.frame:SetText(label);it.mark:SetShown(it.value)
 if self.compact then
  it.frame:SetWidth(self.width)
  local icon=displayIcon(key,A.selectedModule)
  alignButton(it.frame,icon)
  it.mark:GetParent():ClearAllPoints();it.mark:GetParent():SetPoint("RIGHT",-8,0)
  it.frame.label:ClearAllPoints();it.frame.label:SetPoint("LEFT",38,0);it.frame.label:SetPoint("RIGHT",-34,0)
 end
 local measured=it.frame.label.GetStringHeight and it.frame.label:GetStringHeight() or 14
 if type(measured)~="number" or measured~=measured then measured=14 end
 local height=math.max(30,math.min(160,measured+16));it.frame:SetHeight(height);self.y=self.y+height-30
 return it.frame
end
function A:Disclosure(form,key,label)
 self.disclosures=self.disclosures or {}
 local button=form:Button("section."..key,(self.disclosures[key] and "−  " or "+  ")..label,function()
  self.disclosures[key]=not self.disclosures[key];self:Render()
  if M.ElementMap and M.ElementMap:IsOpen() then M.ElementMap:Render() end
 end)
 button.mirageLabelRole="secondary";U:PaintButton(button)
 return self.disclosures[key]==true
end
function Form:Finish()
 for k,item in pairs(self.cache) do if not self.used[k] then item.frame:Hide() end end
 self.parent:SetHeight(math.max(40,self.y+12))
end
function Form:Inputs()
 local inputs,keys={},{}
 for key in pairs(self.used) do keys[#keys+1]=key end;table.sort(keys)
 for _,key in ipairs(keys) do
  local item=self.cache[key]
  if item.frame.Pending then inputs[#inputs+1]=item.frame end
  if item.spells and item.spells.Pending and item.spells.frame:IsShown() then inputs[#inputs+1]=item.spells end
  local rows={};for name in pairs(item.rows or {}) do rows[#rows+1]=name end;table.sort(rows)
  for _,name in ipairs(rows) do local row=item.rows[name];if row.Pending and row:IsShown() then inputs[#inputs+1]=row end end
 end
 return inputs
end
function A:InputControls()
 local inputs={}
 local function append(form) if form then for _,input in ipairs(form:Inputs()) do inputs[#inputs+1]=input end end end
 if self.frame and (self.frame:IsShown() or self.nativePaused) then append(self.form) end
 local e=M.ElementMap
 if e and (e:IsOpen() or e.nativePaused) then append(e.inspectorForm) end
 return inputs
end
function A:HasPendingInput()
 for _,input in ipairs(self:InputControls()) do if input:Pending() then return true end end
 return false
end
function A:FlushInputs()
 if self.flushing then return true end
 if not W.draft then return true end
 local editing,message=M.Elements:EditingAllowed();if not editing then self:Notice(message);return false,message end
 local current,why=W:Current();if not current then self:Notice(why);return false,why end
 local inputs={}
 for _,input in ipairs(self:InputControls()) do if input:Pending() then inputs[#inputs+1]=input end end
 if #inputs==0 then return true end
 if S:InCombat() then why="Finish editing after combat. Your typed values are retained.";self:Notice(why);return false,why end
 -- Validate every pending field before staging any of them.
 for _,input in ipairs(inputs) do
  local ok,reason=input:Validate()
  if not ok then self:Notice(reason);return false,reason end
 end
 local before=M:Copy(W.draft);local history=M:Copy(W.history)
 local inputStates={}
 for _,input in ipairs(inputs) do if input.CaptureInput then inputStates[input]=input:CaptureInput() end end
 local cursorBefore=self.cursorOwner and M:Copy(self.cursorOwner.draft)
 self.flushing=true;self.inputFailure=nil
 local good,reason=true,nil
 for _,input in ipairs(inputs) do
  local called,ok,message=pcall(input.Commit,input)
  if not called or ok==false or self.inputFailure then
   good=false;reason=self.inputFailure or message or "This field could not be staged. Previous preferences are retained.";break
  end
 end
 self.flushing=false;self.inputFailure=nil
 if not good then
  W.draft=before;W.history=history;W:Changed()
  if self.cursorOwner then self.cursorOwner.source=W.draft;self.cursorOwner.draft=cursorBefore end
  -- A later rejected field must not consume the earlier fields' typed values.
  -- Restore their committed markers as well as the detached preference draft.
  for input,state in pairs(inputStates) do input:RestoreInput(state) end
  self:Notice(reason);return false,reason
 end
 -- A single flush is one logical edit, regardless of the number of fields.
 W.history=history;W:Remember(before);self:RefreshFooter();return true
end
function A:Undo()
 local ok,why=self:FlushInputs();if not ok then return false,why end
 ok,why=W:Undo()
 if ok then self:Render();if M.ElementMap and M.ElementMap:IsOpen() then M.ElementMap:Render() end end
 self:Changed(ok and "Previous draft change restored." or why);return ok,why
end
local function title(key)
 local names={enabled="Enabled",style="Use MirageUI styling",visibility="Visibility",alpha="Opacity",scale="Display scale",hideWhenQuiet="Hide when quiet",moveNative="Use the shared layout position",square="Square minimap",squareSize="Minimap size",matchMinimap="Match quest width to minimap",nativeScale="Buff and debuff size (%)",contextualNative="Contextual game controls",utilityContext="Context visibility for supported utility controls",contextual="Contextual action bars",reducedMotion="Reduce notification motion",combatText="Style native scrolling combat text",combatTextSize="Combat text size",loot="Item loot receipts",money="Money received receipts",profession="Profession skill increases",maxRows="Maximum notifications",textSize="Notification text size",duration="Notification duration (seconds)",healthPair="Health and resources",policy="When HUD appears",hudScale="HUD scale (%)",nativeGroups="Sort raid members by subgroup",nativeAuras="Use game aura containers",cards="MirageUI nameplate cards",showPercent="Show percentages",playerPanel="Player aura panel",totems="Totems and temporary summons",summary="Show damage summary",privateAuras="Private aura anchors",browser="Inventory browser",ignoreGCD="Exclude the global cooldown",allowRearrange="Allow moving ordinary actions",showNumbers="Show duration numbers",showBuffs="Show buffs",showAuras="Show auras",showCast="Show cast bar",nameBacking="Subtle name background",spells="Tracked spells"}
 return names[key] or (key:gsub("(%l)(%u)","%1 %2"):gsub("^%l",string.upper))
end
A.SettingLabel=title
function A:Notice(text) if self.message then self.message:SetText(text or "") end;if M.ElementMap then M.ElementMap:Notice(text) end end
function A:Changed(text)
 self:RefreshFooter();self:Notice(text or "Draft changed. Apply to save; Cancel keeps your previous settings.")
 if M.ElementMap and M.ElementMap:IsOpen() then M.ElementMap:RefreshBoxes() end
end
function A:Change(fn,rerender)
 local ok,why=W:Change(fn);if not ok and self.flushing then self.inputFailure=why end;self:Changed(not ok and why or nil)
 if ok and rerender then self:Render() end
 return ok,why
end
function A:SetModuleOption(id,key,value,rerender)
 local supported,reason=M.Elements:SettingSupported(id,key,W.draft)
 if not supported then self:Notice(reason);return false,reason end
 return self:Change(function(p) p.modules[id][key]=value end,rerender)
end
-- Native Edit Mode owns its own unsaved work. Pause only our windows and
-- unfinished gestures; retain detached preferences and typed input for reopen.
function A:PauseForNativeEditor(message)
 local map=M.ElementMap
 local mainShown=self.frame and self.frame:IsShown()
 local mapShown=map and map:IsOpen()
 if not mainShown and not mapShown then return false end
 if mainShown then self.nativePaused=true end
 if mapShown then
  map.nativePaused=true
  if map.drag then map:CancelDrag() end
  map:HidePreserve()
 end
 self.nativeModal=self.modal and self.modal:IsShown() or self.nativeModal
 self.nativeConfirm=self.confirm and self.confirm:IsShown() or self.nativeConfirm
 self:HidePreserve()
 self:Notice(message);M:Print(message)
 return true
end
function A:Create()
 if self.frame then return end
 local f=CreateFrame("Frame","MirageUIWorkspace",UIParent,"BackdropTemplate");self.frame=f
 f:SetSize(850,680);f:SetPoint("CENTER");f:SetFrameStrata("DIALOG");U:Backdrop(f)
 f:SetClampedToScreen(true);f:EnableMouse(true);f:SetMovable(true)
 local mark=f:CreateTexture(nil,"ARTWORK");mark:SetTexture("Interface\\AddOns\\MirageUI\\Media\\Mark.tga");mark:SetSize(32,32);mark:SetPoint("TOPLEFT",20,-18)
 local heading=U:Text(f,"MirageUI",64,-25,14,660);U:SetTextRole(heading,"heading")
 mark:ClearAllPoints();mark:SetPoint("RIGHT",heading,"LEFT",-10,0)
 self.dragFrame=CreateFrame("Frame",nil,f);self.dragFrame:SetPoint("TOPLEFT",0,0);self.dragFrame:SetSize(730,84)
 self.dragFrame:EnableMouse(true);self.dragFrame:RegisterForDrag("LeftButton")
 self.dragFrame:SetScript("OnDragStart",function()
  local control,known=S:Public(IsControlKeyDown,"boolean")
  if known=="KNOWN" and control and not S:InCombat() then f:StartMoving() end
 end)
 self.dragFrame:SetScript("OnDragStop",function() f:StopMovingOrSizing() end)
 self.close=U:Button(f,"Close",748,-23,78,function() self:RequestClose() end)
 self.nav={}
 for i,row in ipairs({{"Customize","Home"},{"Modules","Displays"},{"Profiles","Profiles"},{"Help","Help"}}) do
  local page,label=row[1],row[2]
  self.nav[page]=U:Button(f,label,20,-110-(i-1)*42,132,function()
   if not self:FlushInputs() then return end
   self.page=page;self.selectedModule=nil;self:Render()
  end)
  alignButton(self.nav[page],controlArt..label..".tga")
 end
 self.scroll=M.UI:Scroll(f)
 self.scroll:SetPoint("TOPLEFT",176,-106);self.scroll:SetSize(625,456)
 self.body=CreateFrame("Frame",nil,self.scroll);self.body:SetSize(606,400);self.scroll:SetScrollChild(self.body)
 self.form=Form:New(self.body,600)
 self.message=U:Text(f,"",178,-574,12,640);self.message:SetHeight(38)
 self.apply=U:Button(f,"Apply",178,-626,110,function() self:Apply() end)
 self.undo=U:Button(f,"Undo",300,-626,100,function() self:Undo() end)
 self.cancel=U:Button(f,"Cancel",412,-626,110,function() self:DiscardAndClose() end)
 self.draftLabel=U:Text(f,"",550,-634,12,260)
 f:SetScript("OnHide",function() f:StopMovingOrSizing();M.state.forceEvaluate=true end)
 f:SetScript("OnShow",function() M.state.forceEvaluate=true end)
 f:SetScript("OnUpdate",function(_,elapsed)
  self.editCheck=(self.editCheck or 0)+elapsed;if self.editCheck<.1 then return end;self.editCheck=0
  local allowed,message=M.Elements:EditingAllowed();if not allowed then self:PauseForNativeEditor(message) end
 end)
 f:Hide()
 -- Escape requests a close instead of allowing UISpecialFrames to discard data.
 f:EnableKeyboard(true);if f.SetPropagateKeyboardInput then f:SetPropagateKeyboardInput(true) end
 f:SetScript("OnKeyDown",function(_,key)
  if key=="ESCAPE" then
   if f.SetPropagateKeyboardInput then f:SetPropagateKeyboardInput(false) end
   if M.SuiteLauncher and M.SuiteLauncher.CloseTransient and M.SuiteLauncher:CloseTransient("ESCAPE") then return end
   self:RequestClose()
  elseif f.SetPropagateKeyboardInput then f:SetPropagateKeyboardInput(true) end
 end)
end
function A:Fit()
 local w,h=UIParent:GetWidth(),UIParent:GetHeight()
 self.frame:SetScale(math.max(.5,math.min(1,(w-32)/850,(h-32)/680)))
end
function A:Open(page,module)
 if S:InCombat() then M:Print("Open customization after combat. Your draft is retained.");return false end
 local allowed,message=M.Elements:EditingAllowed();if not allowed then self:PauseForNativeEditor(message);M:Print(message);return false end
 if W.draft and not self:FlushInputs() then return false end
 local ok,why=W:Begin();if not ok then M:Print(why);return false end
 self:Create();self:Fit();self.page=page or self.page;self.selectedModule=module
 if self.page=="Suite" then self.page="Help";self.suiteExpanded=true end
 if M.ElementMap and M.ElementMap:IsOpen() then M.ElementMap:HidePreserve() end
 if M.PlayerSettings.frame then M.PlayerSettings.frame:Hide() end
 if M.Options.frame then M.Options.frame:Hide() end
 self.nativePaused=nil;if M.ElementMap then M.ElementMap.nativePaused=nil end
 self.frame:Show();self:Render()
 if self.nativeModal and self.modal then self.modal:Show() end
 if self.nativeConfirm and self.confirm then self.confirm:Show() end
 self.nativeModal=nil;self.nativeConfirm=nil
 M.Signals:Observe();M.state.forceEvaluate=true;return true
end
function A:CloseTransient()
 if M.UI.CloseChoices then M.UI:CloseChoices() end
end
function A:HidePreserve()
 self:CancelNativeHandoff()
 self:CloseTransient();if self.frame then self.frame:Hide() end
 if self.modal then self.modal:Hide() end
 if self.confirm then self.confirm:Hide() end
end
function A:DiscardAndClose()
 self.nativePaused=nil;self.nativeModal=nil;self.nativeConfirm=nil;if M.ElementMap then M.ElementMap.nativePaused=nil end
 self:HidePreserve();if M.ElementMap then M.ElementMap:HidePreserve() end
 W:Discard()
 for _,form in ipairs({self.form,M.ElementMap and M.ElementMap.inspectorForm}) do
  if form then for _,item in pairs(form.cache) do
   if item.kind=="slider" and item.frame.Pending and item.frame:Pending() then item.frame.setValue(item.frame.slider:GetValue()) end
   if item.kind=="edit" then item.frame:SetText(item.lastText or "") end
   for _,row in pairs(item.rows or {}) do if row.workspaceInput then row.entry:SetText(row.workspaceLastText or "") end end
  end end
 end
 if self.cursorOwner then self.cursorOwner.source=nil;self.cursorOwner.draft=nil;self.cursorOwner.bindingDraft=nil;self.cursorOwner.bindingConfirm=false;self.cursorOwner.notesBindingDraft=nil;self.cursorOwner.notesBindingConfirm=false;self.cursorOwner.fishingBindingDraft=nil;self.cursorOwner.fishingBindingConfirm=false end;self.pendingName=nil;M.state.forceEvaluate=true
end
function A:Confirm(message,yes,no,allowDiscard)
 if not self.confirm then
  local f=CreateFrame("Frame","MirageUIWorkspaceConfirm",UIParent,"BackdropTemplate");self.confirm=f
  f:SetSize(500,190);f:SetPoint("CENTER");f:SetFrameStrata("FULLSCREEN_DIALOG");U:Backdrop(f);f:EnableMouse(true)
  self.confirmText=U:Text(f,"",20,-20,14,460);self.confirmText:SetHeight(90)
  self.confirmYes=U:Button(f,"Discard",20,-134,210,function() local fn=self.confirmAccept
   if not self.confirmDiscard and (S:InCombat() or not W:Current()) then self:Notice("The profile or game state changed; reopen the action.");f:Hide();return end
   f:Hide();if fn then fn() end
  end)
  self.confirmNo=U:Button(f,"Keep editing",250,-134,210,function() local fn=self.confirmDecline;f:Hide();if fn then fn() end end)
  f:Hide()
 end
 self.confirmText:SetText(message);self.confirmYes:SetText("Discard");self.confirmNo:SetText("Keep editing");self.confirmAccept=yes;self.confirmDecline=no;self.confirmDiscard=allowDiscard==true
 self.confirm:Show()
end
-- Native property delegation is an explicit draft transaction. Opening another
-- editor is never queued for combat end, and never imports or saves its layout.
function A:NativeEditorAvailable(id)
 if not M.Elements:IsNativeGeometry(id,W.draft or M.profile) then return false,"This display uses its Mirage layout controls." end
 if S:InCombat() then return false,"Open Blizzard Edit HUD after combat. Your Mirage draft is retained." end
 local state=M.Elements:NativeEditorState()
 if state=="UNKNOWN" then return false,"Blizzard Edit HUD is not currently readable. Your Mirage draft is retained; try the button again when it is available." end
 if state=="OPEN" then return false,"Finish the open Blizzard Edit HUD with its Save or Cancel controls first." end
 local c=M.Client
 if not c or type(c.IsRuntimeClient)~="function" or not c:IsRuntimeClient() or not S:Frame(_G.EditModeManagerFrame,false) or type(_G.ShowUIPanel)~="function" then
  return false,"Blizzard Edit HUD cannot be opened through a qualified game control on this client. Your Mirage draft is retained."
 end
 if W.draft then local ok,why=W:Current();if not ok then return false,why end end
 return true
end
function A:CancelNativeHandoff()
 self.nativeHandoffPending=nil
 if self.nativeHandoff then self.nativeHandoff:Hide() end
 return true
end
function A:CreateNativeHandoff()
 if self.nativeHandoff then return end
 local f=CreateFrame("Frame","MirageUIWorkspaceNativeHandoff",UIParent,"BackdropTemplate");self.nativeHandoff=f
 f:SetSize(650,210);f:SetPoint("CENTER");f:SetFrameStrata("FULLSCREEN_DIALOG");U:Backdrop(f)
 f:EnableMouse(true);f:SetClampedToScreen(true)
 U:Text(f,"Position and size in Blizzard Edit HUD",20,-20,17,610)
 self.nativeHandoffText=U:Text(f,"Save the Mirage draft before continuing, discard it, or cancel to keep editing. Blizzard Edit HUD uses its own Save and Cancel controls.",20,-57,13,610)
 self.nativeHandoffText:SetHeight(82)
 U:Button(f,"Save and continue",20,-158,198,function() self:ResolveNativeHandoff("SAVE") end)
 U:Button(f,"Discard and continue",226,-158,198,function() self:ResolveNativeHandoff("DISCARD") end)
 U:Button(f,"Cancel",432,-158,198,function() self:CancelNativeHandoff() end)
 f:EnableKeyboard(true);if f.SetPropagateKeyboardInput then f:SetPropagateKeyboardInput(true) end
 f:SetScript("OnKeyDown",function(_,key)
  if key=="ESCAPE" then if f.SetPropagateKeyboardInput then f:SetPropagateKeyboardInput(false) end;self:CancelNativeHandoff()
  elseif f.SetPropagateKeyboardInput then f:SetPropagateKeyboardInput(true) end
 end)
 f:Hide()
end
function A:RequestNativeEditor(id)
 local allowed,why=self:NativeEditorAvailable(id)
 if not allowed then self:Notice(why);return false,why end
 if M.ElementMap and M.ElementMap.drag then M.ElementMap:StopDrag() end
 local flushed,reason=self:FlushInputs();if not flushed then return false,reason end
 self.nativeHandoffPending={id=id,draft=W.draft,profile=M.profile,
  mapOpen=M.ElementMap and M.ElementMap:IsOpen(),mainOpen=self.frame and self.frame:IsShown()}
 if W.dirty then
  self:CreateNativeHandoff();self.nativeHandoff:Show();return true,"DRAFT_CHOICE_REQUIRED"
 end
 return self:ResolveNativeHandoff("CONTINUE")
end
function A:ResolveNativeHandoff(choice)
 if choice=="CANCEL" then return self:CancelNativeHandoff() end
 local pending=self.nativeHandoffPending
 if not pending or choice~="SAVE" and choice~="DISCARD" and choice~="CONTINUE" then return false end
 local allowed,why=self:NativeEditorAvailable(pending.id)
 if not allowed or pending.draft~=W.draft or pending.profile~=M.profile then
  why=why or "Your Mirage draft changed. Select the native Edit HUD action again."
  self:CancelNativeHandoff();self:Notice(why);return false,why
 end
 if choice=="CONTINUE" and (W.dirty or self:HasPendingInput()) then
  self:CreateNativeHandoff();self.nativeHandoff:Show();return false,"DRAFT_CHOICE_REQUIRED"
 end
 if choice=="SAVE" then
  local saved,message=self:Apply();if not saved then self:Notice(message);return false,message end
 end
 -- Recheck after callbacks from Apply. A stale/profile-changed/locked request
 -- stays local; there is no saved callback which could open the game panel later.
 allowed,why=self:NativeEditorAvailable(pending.id)
 if not allowed then self:CancelNativeHandoff();self:Notice(why);return false,why end
 self:CancelNativeHandoff();self:HidePreserve()
 if M.ElementMap then M.ElementMap:HidePreserve() end
 local opened=pcall(_G.ShowUIPanel,_G.EditModeManagerFrame)
 local state=M.Elements:NativeEditorState()
 if opened and state=="OPEN" then
  -- Discard only after an actual opening. A failed/opaque opener retains the
  -- detached draft, including typed values already staged by the flush above.
  self:DiscardAndClose();self.nativeHandoffOpened=true
  self:Notice("Blizzard Edit HUD owns position and size. Use its Save or Cancel controls, then reopen MirageUI.")
  return true
 end
 why="Blizzard Edit HUD did not confirm an open panel. Your Mirage draft is retained; use the action again when it is available."
 if state=="CLOSED" then
  if pending.mapOpen and M.ElementMap then M.ElementMap:Open()
  elseif pending.mainOpen then self:Open(self.page,self.selectedModule) end
 else self.nativePaused=pending.mainOpen or nil;if M.ElementMap then M.ElementMap.nativePaused=pending.mapOpen or nil end end
 self:Notice(why);return false,why
end
function A:RequestClose()
 if self.nativeHandoff and self.nativeHandoff:IsShown() then self:CancelNativeHandoff();return end
 if self.modal and self.modal:IsShown() then self.modal:Hide();return end
 if self.confirm and self.confirm:IsShown() then self.confirm:Hide();return end
 self:CloseTransient()
 if W.dirty or self:HasPendingInput() then self:Confirm("There are unapplied changes. Discard them and close, or keep editing?",function() self:DiscardAndClose() end,nil,true)
 else self:DiscardAndClose() end
end
function A:RefreshFooter()
 if self.draftLabel then self.draftLabel:SetText(W.dirty and "Unapplied draft" or "Saved preferences") end
 for _,button in ipairs({self.apply,self.undo,self.cancel}) do if button then button:SetShown(self.page~="Setup") end end
end
function A:Apply()
 local allowed,message=M.Elements:EditingAllowed();if not allowed then self:PauseForNativeEditor(message);self:Notice(message);return false,message end
 if M.ElementMap and M.ElementMap.drag then M.ElementMap:StopDrag() end
 local flushed,reason=self:FlushInputs();if not flushed then return false,reason end
 if self.cursorOwner and self.cursorOwner.draft and self.cursorOwner.source==W.draft then self.cursorOwner:Preview() end
 if self.cursorOwner and self.cursorOwner.bindingDraft then self:Notice("Apply or cancel the explicit shortcut assignment in Cursor controls first.");return false end
 if self.cursorOwner and self.cursorOwner.notesBindingDraft then self:Notice("Apply or cancel the explicit Navigation shortcut first.");return false end
 if self.cursorOwner and self.cursorOwner.fishingBindingDraft then self:Notice("Apply or cancel the explicit Fishing shortcut first.");return false end
 local ok,why=W:Apply()
 self:Notice(why);if ok then if self.cursorOwner then self.cursorOwner.source=nil;self.cursorOwner.draft=nil end;self:Render();if M.ElementMap and M.ElementMap:IsOpen() then M.ElementMap:Render() end end
 self:RefreshFooter();return ok,why
end
function A:TextDialog(titleText,text,actionLabel,action)
 if S:InCombat() then return false end
 if not self.modal then
  local f=CreateFrame("Frame","MirageUIWorkspaceText",UIParent,"BackdropTemplate");self.modal=f
  f:SetSize(690,480);f:SetPoint("CENTER");f:SetFrameStrata("FULLSCREEN_DIALOG");U:Backdrop(f);f:EnableMouse(true)
  self.modalTitle=U:Text(f,"",20,-20,18,610);U:SetTextRole(self.modalTitle,"heading")
  self.modalHint=U:Text(f,"",20,-54,12,640);self.modalHint:SetHeight(42)
  local sc=M.UI:Scroll(f);sc:SetPoint("TOPLEFT",20,-102);sc:SetSize(630,300)
  local e=CreateFrame("EditBox",nil,sc);self.modalEdit=e;e:SetMultiLine(true);e:SetAutoFocus(false);e:SetMaxLetters(96000)
  e:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",12,"");e:SetWidth(614);e:SetHeight(310);sc:SetScrollChild(e)
  e:SetScript("OnTextChanged",function() if e.GetNumLetters then e:SetHeight(math.max(310,math.min(32000,e:GetNumLetters()/60*16+64))) end end)
  e:SetScript("OnEscapePressed",function() e:ClearFocus();f:Hide() end)
  self.modalAction=U:Button(f,"",20,-428,300,function() if self.modalCallback then self.modalCallback(e:GetText()) end end)
  U:Button(f,"Close",350,-428,300,function() f:Hide() end)
  f:SetScript("OnHide",function()
   e:ClearFocus()
   if self.nativePaused or M.ElementMap and M.ElementMap.nativePaused then return end
   e:SetText("");self.modalCallback=nil
  end);f:Hide()
 end
 self.modalTitle:SetText(titleText);self.modalHint:SetText(action and "Paste data, then validate into the draft. Nothing is applied until Apply." or "Select and copy the text. Review support reports before sharing.")
 self.modalCallback=action;self.modalAction:SetText(actionLabel or "Select all");self.modalEdit:SetText(text or "")
 if not action then self.modalCallback=function() self.modalEdit:SetFocus();self.modalEdit:HighlightText() end end
 self.modal:Show();self.modalEdit:SetFocus();self.modalEdit:HighlightText();return true
end
local function libraryNames()
 local result={};for name in pairs(M.Profiles.account.named or {}) do if type(name)=="string" then result[#result+1]=name end end;table.sort(result);return result
end
function A:Profiles(form)
 form:Text("title","Profiles",28,true)
 form:Text("intro","Save display choices, layouts and context visibility. Companion addons keep their own settings.",56)
 self.profileName=self.profileName or "My MirageUI"
 local nameInput=form:Edit("name","Profile name (1–32 characters)",self.profileName,function(v) self.profileName=v end,32)
 local function currentName() return nameInput:GetText() end
 form:Button("create","Create from current saved preferences",function()
  local name=currentName();if M.Profiles.account.named[name] then self:Notice("That name already exists. Use Save over selected, or choose a new name.");return end
  if W.dirty then self:Notice("Apply or cancel the draft before saving a named profile.");return end
  local ok,why=M.Profiles:SaveNamed(name);self.selectedProfile=ok and name or self.selectedProfile;self:Render();self:Notice(ok and "Named profile created." or why)
 end)
 local names=libraryNames();if #names>0 and not M.Profiles.account.named[self.selectedProfile or ""] then self.selectedProfile=names[1] end
 if #names>0 then
  form:Choice("library","Saved profile",self.selectedProfile,names,nil,function(v) self.selectedProfile=v;self:Render() end)
  form:Button("load","Load selected into the draft",function()
   local p=M.Profiles.account.named[self.selectedProfile];local valid,why=M.Profiles:Validate(p)
   local ok=not why and W:Replace(valid);self:Render();self:Notice(ok and "Profile loaded into the draft. Apply to activate it." or why or "The profile could not be staged.")
  end)
  form:Button("save","Save current preferences over selected",function()
   if W.dirty then self:Notice("Apply or cancel the draft before updating a saved profile.");return end
   local selected=self.selectedProfile
   self:Confirm("Replace this named profile with the current saved interface settings?",function()
    local ok,why=M.Profiles:SaveNamed(selected);self:Notice(ok and "Named profile updated." or why)
   end);self.confirmYes:SetText("Replace profile");self.confirmNo:SetText("Keep profile")
  end)
  form:Button("copy","Copy selected to the new name",function()
   local ok,why=M.Profiles:CopyNamed(self.selectedProfile,currentName());if ok then self.selectedProfile=currentName() end;self:Render();self:Notice(ok and "Profile copied." or why)
  end)
  form:Button("delete","Delete selected saved profile",function()
   local selected=self.selectedProfile
   self:Confirm("Delete only this named library entry? The active preferences and other profiles will be kept.",function()
    local ok,why=M.Profiles:DeleteNamed(selected);self.selectedProfile=nil;self:Render();self:Notice(ok and "Named profile removed. Active settings retained." or why)
   end);self.confirmYes:SetText("Delete entry");self.confirmNo:SetText("Keep entry")
  end)
 end
 form:Button("export","Export interface profile",function()
  if W.dirty then self:Notice("Apply or cancel before exporting; exports describe saved settings.");return end
  local text,why=M.Profiles:Export();if text then self:TextDialog("Export interface profile",text) else self:Notice(why) end
 end)
 form:Button("import","Import interface profile",function()
  self:TextDialog("Import preferences","","Validate and stage",function(text)
   local p,why=M.Profiles:Import(text)
   if not p then self.modalHint:SetText(why or "Profile data was rejected.");return end
   local ok,reason=W:Replace(p)
   if ok then self.modal:Hide();if self.cursorOwner then self.cursorOwner.source=nil;self.cursorOwner.draft=nil end;self:Render();self:Changed("Import validated into the draft. Review it, then Apply or Cancel.") else self.modalHint:SetText(reason) end
  end)
 end)
 form:Button("scope",M.Profiles.character.useCharacter and "Use account preferences" or "Use this character’s preferences",function()
  if W.dirty then self:Notice("Apply or cancel this draft before changing profile scope.");return end
  local ok,why=M.Profiles:UseCharacter(not M.Profiles.character.useCharacter)
  if ok then W:Discard();W:Begin();if self.cursorOwner then self.cursorOwner.source=nil;self.cursorOwner.draft=nil end;self:Render() end;self:Notice(ok and "Profile scope changed; existing preferences are retained." or why)
 end)
 form:Text("scopehelp","Profiles exclude key assignments, companion settings and account startup preferences. Create, replace and delete actions save immediately; loaded or imported settings wait for Apply.",58)
end
function A:ModuleStatus(id,profile)
 profile=profile or M.profile
 if M.NativeWindowPolicy and M.NativeWindowPolicy:ModuleNative(id) then
  for _,row in pairs(M.Rework and M.Rework.providers or {}) do
   if row.module==id and row.pending then
    return "Native by design. A previous Mirage receipt still needs restoration; use Help to complete that handback."
   end
  end
  return "Native by design. The game owns these windows and tooltips. Earlier Mirage appearance and placement preferences remain saved but inactive."
 end
 local cfg=profile.modules[id];local mod=M.modules[id]
 local selected,active,pending=0,0,0
 local r=M.Rework
 if r then for _,key in ipairs(r.order) do
  local row=r.providers[key]
  if row.module==id and r:Selected(key,profile) then
   selected=selected+1
   if row.state=="ACTIVE" and not row.pending then active=active+1
   elseif row.failed or row.pending or row.state=="RECOVERY" then pending=pending+1 end
  end
 end end
 if not cfg or not cfg.enabled and selected==0 then return "Module off. Saved preferences are retained; game controls remain available." end
 if not M.Client.allowed then return "Selected. Waiting for a compatible client and setup." end
 if M.state.safe or not M.profile.enabled then return "Selected. MirageUI is paused; open Help to resume your saved choices." end
 if pending>0 then return "Some displays need attention. Open Help to retry or copy the support report." end
 if selected>0 then
  return active==selected and "Mirage presentation is active. Content and context determine when each display appears."
   or "Mirage presentation is selected. Apply the draft, then open the relevant window or display."
 end
 if mod and (mod.quarantined or mod.initializationFailed or mod.maintenanceFailed) then return "Needs attention. Open Help for recovery." end
 return M:IsModuleActive(id) and "Module features are enabled. Each display keeps its own content and visibility choices." or "Selected. Waiting for the display provider."
end

function A:Modules(form)
 local names={UnderCharacterHUD="Character bars",DamageMeters="Meters",QuestTracker="Quest objectives"}
 form:Text("title",self.selectedModule and (names[self.selectedModule] or (M.CatalogByID[self.selectedModule] or {}).name or self.selectedModule) or "Displays",28,true,M.Icons and M.Icons:ForModule(self.selectedModule))
 if self.selectedModule then
  form:Button("back","Back to displays",function() self.selectedModule=nil;self:Render() end)
  if M.CatalogByID[self.selectedModule] then self:ModuleControls(form,self.selectedModule) end
  return
 end
 self:VisibilityControls(form)
 if self:Disclosure(form,"startup","Startup") then
  self:StartupControls(form)
 end
 if self:Disclosure(form,"appearance","Appearance and accessibility") then
  form:Slider("text","Settings text scale (%)",W.draft.textScale*100,80,150,5,function(v) self:Change(function(p) p.textScale=v/100 end) end)
  if W.draft.contrast~=nil then form:Toggle("contrast","Higher contrast",W.draft.contrast,function(v) self:Change(function(p) p.contrast=v end,true) end) end
  if M.StartupAnimation then
   form:Text("startupAccessibilityScope","Startup accessibility · saved immediately for this account",30,true)
   form:Toggle("startupReduceMotion","Reduce motion",M.StartupAnimation:GetPreference("reduceMotion"),function(v) self:SetStartupPreference("reduceMotion",v) end,true)
   form:Text("startupAccessibilityHelp","Uses a quiet fade for the startup presentation. This account preference is separate from Apply, Undo and Cancel.",48)
  end
 end
 local groups={
  {name="Combat",ids={"ActionBars","UnderCharacterHUD","UnitFrames","PartyRaid","Nameplates","Auras","Cooldowns","DamageMeters","ResourceBars"}},
  {name="Exploration",ids={"Minimap","QuestTracker","DataBars"},addons={{"MirageIntel_Map","Maps"},{"MirageIntel_Navigate","Wayfinder"},{"MirageIntel_Gather","Gathering"}}},
  {name="Communication",ids={"Chat","Notifications"}},
  {name="Interface and tools",ids={"Tooltips","Bags","Preparations","PvP","TacticalSignals"}}}
 for _,group in ipairs(groups) do
  form:Text("group."..group.name,group.name,26,true)
  for _,id in ipairs(group.ids) do
   local row=M.CatalogByID[id];local cfg=W.draft.modules[id]
   if row and cfg then
    local selected=cfg.enabled
    if M.Rework then for _,key in ipairs(M.Rework.order) do local provider=M.Rework.providers[key];if provider.module==id and M.Rework:Selected(key,W.draft) then selected=true;break end end end
    local state=cfg.primaryPresentation==2 and "Game controls" or selected and ((M.state.safe or not M.profile.enabled) and "Paused" or "On") or "Off"
    if id=="DamageMeters" and (cfg.enabled==false or cfg.metersEnabled==false) then state="Off" end
    form:Button(id,(names[id] or row.name or id).."  ·  "..state,function() self.selectedModule=id;self:Render() end)
   end
  end
  for _,entry in ipairs(group.addons or {}) do
   local addon,label=entry[1],entry[2]
   form:Button("companion."..addon,label..(S:Loaded(addon) and " settings" or " · not loaded"),function() self:OpenCompanion(addon) end,M.Icons and M.Icons:ForAddon(addon))
  end
 end
end
function A:OpenCompanion(addon)
 if not M.SuiteLauncher then self:Notice("Companion settings are unavailable in this installation.");return false end
 local ok,why=M.SuiteLauncher:OpenAddon(addon)
 if ok then self:HidePreserve() else self:Notice(why or "Companion settings could not open.") end
 return ok,why
end
function A:SetStartupPreference(key,value)
 if not M.StartupAnimation then return false end
 local ok,why=M.StartupAnimation:SetPreference(key,value==true)
 self:Render();self:Notice(ok==false and (why or "This startup preference could not be saved.") or "Saved immediately for this account.")
 return ok~=false
end
function A:StartupControls(form)
 if not M.StartupAnimation then form:Text("startupUnavailable","Startup presentation is unavailable in this installation.",42);return end
 form:Text("startupScope","Saved immediately for this account",26,true)
 form:Toggle("startupEnabled","Startup animation",M.StartupAnimation:GetPreference("enabled"),function(v) self:SetStartupPreference("enabled",v) end,true)
 form:Text("startupHelp","A seven-second mirage entrance covers startup. Esc skips it. Combat and game prompts take priority.",58)
 form:Button("startupPreview","Preview startup animation",function() local ok,why=M.StartupAnimation:Preview();if ok==false then self:Notice(why) end end)
 form:Text("startupSaveHelp","This preference is separate from Apply, Undo and Cancel, and is not included in interface profiles.",44)
end
function A:CooldownControls(form,cfg)
 local draft,profile=W.draft,M.profile
 local function set(key,value,rerender)
  if W.draft~=draft or M.profile~=profile or draft.modules.Cooldowns~=cfg or not W:Current() then return false end
  return self:SetModuleOption("Cooldowns",key,value,rerender)
 end
 form:Text("cooldownOverview","Track spells and items. Inactive effects keep their saved slots.",38)
 form:Button("cooldownManager","Open Cooldown Manager",function()
  local ok,why
  if M.CooldownEditor then ok,why=M.CooldownEditor:Enter() end
  if not ok then self:Notice(why or "The Cooldown Manager is unavailable.") end
 end)
 form:Toggle("cooldownRowEnabled","Show tracking display",cfg.rowEnabled,function(v) set("rowEnabled",v,true) end)
 form:Toggle("cooldownSecondaryEnabled","Enable secondary bar",cfg.rowSecondary,function(v) set("rowSecondary",v,true) end)
 form:Choice("cooldownRowVisibility","Visibility",cfg.rowVisibility,{1,2,3},{"Always","In combat","In combat or with a target"},function(v) set("rowVisibility",v,true) end)
 form:Toggle("cooldownFollowHUD","Follow character bars",cfg.rowFollowHUD and not draft.layouts["Cooldowns.row"],function(v)
  if W.draft~=draft or M.profile~=profile or draft.modules.Cooldowns~=cfg then return end
  self:Change(function(p) p.modules.Cooldowns.rowFollowHUD=v;if v then p.layouts["Cooldowns.row"]=nil end end,true)
 end)
 for _,field in ipairs({{"iconSize","Icon size (pixels)",24,80,1},{"gap","Icon spacing (pixels)",0,12,1},{"rowScale","Scale (%)",65,160,5},{"rowOpacity","Opacity (%)",20,100,5}}) do
  local key=field[1];form:Slider("cooldown"..key,field[2],cfg[key],field[3],field[4],field[5],function(v) set(key,v) end)
 end
 for _,field in ipairs({{"showNumbers","Show durations"},{"rowShowCharges","Show charges and stacks"},{"rowShowInactive","Show inactive effects"},{"rowTooltips","Show tooltips"}}) do
  local key=field[1];form:Toggle("cooldown"..key,field[2],cfg[key],function(v) set(key,v,true) end)
 end
 form:Button("cooldownMap","Position and size",function() M.ElementMap:Open("Cooldowns.row") end)
 if self:Disclosure(form,"Cooldowns.advanced","Advanced") then
  form:Choice("cooldownLimitMode","Icon limit",cfg.rowMaxIcons==0 and 0 or 1,{0,1},{[0]="Unlimited",[1]="Custom"},function(v) set("rowMaxIcons",v==0 and 0 or cfg.rowMaxIcons>0 and cfg.rowMaxIcons or 12,true) end)
  if cfg.rowMaxIcons~=0 then form:Slider("cooldownrowMaxIcons","Maximum icons",cfg.rowMaxIcons,1,160,1,function(v) set("rowMaxIcons",v) end) end
  for _,field in ipairs({{"rowBorder","Border width (pixels)",0,3},{"rowZoom","Icon crop (%)",0,20},{"durationSize","Duration text size (points)",8,24},{"chargeSize","Charge and stack text size (points)",8,24}}) do
   local key=field[1];form:Slider("cooldown"..key,field[2],cfg[key],field[3],field[4],1,function(v) set(key,v) end)
  end
  form:Toggle("cooldownignoreGCD","Exclude global cooldown",cfg.ignoreGCD,function(v) set("ignoreGCD",v,true) end)
  self:PresentationControls(form,"Cooldowns",cfg)
 end
end
function A:RestoreSidebarWidth()
 return self:Change(function(profile)
  local stored=profile.layouts["Minimap.nativePosition"]
  local plan=not stored and M.SidebarLayout and M.SidebarLayout:Plan(profile)
  local layout=M:Copy(stored or plan and plan.map or {scale=1})
  layout.width=225;layout.height=225
  profile.layouts["Minimap.nativePosition"]=layout
 end,true)
end
-- Public controls are an allow-list, independent of the persistence schema.
-- Storage revisions, renderer receipts and recovery-only values never become
-- widgets merely because a new field was added to FeatureSettings.
local public={}
M.PublicSettingDescriptors=public
local function describe(module,key,label,section,kind,values,labels,units)
 local definition=M.FeatureSettings and M.FeatureSettings[module] and M.FeatureSettings[module][key]
 local row={key=key,label=label,section=section or "Appearance",kind=kind or (type(definition)=="boolean" and "toggle" or "number"),
  owner=module,effect=label,renderer="selected",persistence="interface profile",apply="draft",units=units,
  values=values,labels=labels,default=type(definition)=="table" and definition[1] or definition,
  minimum=type(definition)=="table" and definition[2] or nil,maximum=type(definition)=="table" and definition[3] or nil,
  availability=function(profile) return M.Elements:SettingSupported(module,key,profile) end}
 public[module]=public[module] or {};public[module][#public[module]+1]=row
 return row
end
local function switches(module,section,rows)
 for _,row in ipairs(rows) do describe(module,row[1],row[2],section,"toggle") end
end
local function numbers(module,section,rows)
 for _,row in ipairs(rows) do describe(module,row[1],row[2],section,"number",nil,nil,row[3]) end
end
for _,module in ipairs({"UnitFrames","PartyRaid"}) do
 switches(module,"Appearance",{{"showNames","Show names"},{"showPercent","Show percentages"},{"showPower","Show resources"},{"showStatus","Show status"},{"showRoles","Show roles"},{"showReady","Show ready checks"},{"nameBacking","Shade name backgrounds"}})
 numbers(module,"Appearance",{{"panelOpacity","Panel opacity (%)","percent"}})
 switches(module,"Advanced",{{"classColors","Use class colors"},{"showCast","Show cast bars"},{"showAuras","Show auras"},{"showBuffs","Show buffs"},{"debuffAccent","Highlight debuffs"},{"nativeAuras","Use game aura containers"}})
 numbers(module,"Advanced",{{"auraSlots","Aura slots"}})
end
switches("UnitFrames","Advanced",{{"referenceLayout","Use the reference unit layout"}})
switches("PartyRaid","Advanced",{{"nativeGroups","Sort by subgroup"},{"groupTitles","Show subgroup titles"},{"compactRaid","Use compact raid frames"}})
numbers("PartyRaid","Advanced",{{"raidColumns","Raid columns"},{"cellWidth","Member width (pixels)","pixels"},{"cellHeight","Member height (pixels)","pixels"},{"cellGap","Member spacing (pixels)","pixels"}})
for i=1,8 do
 describe("PartyRaid","group"..i.."Growth","Subgroup "..i.." direction","Advanced","choice",{1,2,3,4},{"Down","Up","Right","Left"})
 describe("PartyRaid","group"..i.."Gap","Subgroup "..i.." spacing (-1 uses member spacing)","Advanced","number",nil,nil,"pixels")
end
switches("Nameplates","Appearance",{{"cardAuras","Show auras"},{"cardCast","Show casts"},{"cardPercent","Show percentages"},{"showLevel","Show levels"},{"nameBacking","Shade name backgrounds"},{"selectedFriendlyPlate","Show a plate for my friendly target"}})
numbers("Nameplates","Appearance",{{"cardWidth","Width (pixels)","pixels"},{"cardScale","Scale (%)","percent"},{"nameSize","Name text size (points)","points"},{"panelOpacity","Panel opacity (%)","percent"}})
numbers("Nameplates","Advanced",{{"cardOffsetY","Vertical offset (pixels)","pixels"},{"cardIconSize","Aura icon size (pixels)","pixels"},{"cardLimit","Maximum displayed plates"},{"globalScale","Game plate scale (%; 0 keeps current)","percent"},{"minimumScale","Minimum scale (%; 0 keeps current)","percent"},{"maximumScale","Maximum scale (%; 0 keeps current)","percent"},{"selectedScale","Target scale (%; 0 keeps current)","percent"},{"maximumDistance","Plate distance (yards; 0 keeps current)","yards"},{"occludedOpacity","Occluded opacity (%; -1 keeps current)","percent"}})
for _,row in ipairs({{"enemyVisibility","Enemy plates"},{"enemyPetVisibility","Enemy pets and minions"}}) do describe("Nameplates",row[1],row[2],"Advanced","choice",{0,1,2},{[0]="Keep current",[1]="Hide",[2]="Show"}) end
describe("Nameplates","stacking","Plate arrangement","Advanced","choice",{0,1,2},{[0]="Keep current",[1]="Overlap",[2]="Stack"})
describe("Nameplates","nativeNPCNames","Game NPC names","Advanced","choice",{0,1},{[0]="Keep current",[1]="Show all"})
switches("Nameplates","Advanced",{{"customPets","Use Mirage plates for pets"},{"customNeutral","Use Mirage plates for neutral units"}})
switches("Chat","Appearance",{{"messageCue","Show a new message cue"}})
switches("Chat","Advanced",{{"cueSay","Include nearby speech"},{"cueYell","Include yells"},{"cueGuild","Include guild chat"},{"cueEmote","Include emotes"},{"cueChannels","Include public channels"}})
switches("DataBars","Appearance",{{"showXP","Show experience"},{"showZone","Show zone"},{"showMoney","Show money"},{"showClock","Show clock"},{"showFPS","Show frame rate"},{"showCoordinates","Show coordinates"},{"showTravel","Show travel information"},{"showCurrency","Show a currency"}})
numbers("DataBars","Advanced",{{"currencyID","Currency ID"}})
switches("Notifications","Appearance",{{"loot","Item loot"},{"money","Money received"},{"profession","Profession skill increases"},{"status","Level and reputation changes"},{"reducedMotion","Reduce notification motion"}})
numbers("Notifications","Appearance",{{"duration","Display duration (seconds)","seconds"},{"maxRows","Maximum notifications"},{"textSize","Text size (points)","points"}})
switches("Notifications","Advanced",{{"combatText","Style scrolling combat text"}})
numbers("Notifications","Advanced",{{"combatTextSize","Combat text size (points)","points"}})
switches("ResourceBars","Appearance",{{"classResource","Show class resource"},{"classSegments","Show resource segments"},{"runes","Show runes"},{"totems","Show totems and temporary summons"}})
numbers("Auras","Appearance",{{"nativeScale","Buff and debuff scale (%)","percent"}})
switches("Auras","Advanced",{{"playerPanel","Show a separate player aura panel"},{"preparation","Show aura reminders"},{"privateAuras","Show private aura anchors"},{"showNumbers","Show duration numbers"}})
numbers("Auras","Advanced",{{"privateCount","Private aura anchors"},{"privateSize","Private aura size (pixels)","pixels"},{"limit","Maximum panel auras"},{"columns","Panel columns"},{"iconSize","Panel icon size (pixels)","pixels"}})
switches("QuestTracker","Advanced",{{"compactPanel","Show a separate compact objectives panel"},{"showObjectives","Include objective details"},{"worldQuests","Include world quests"}})
numbers("QuestTracker","Advanced",{{"questLimit","Compact panel quest limit"},{"objectiveLines","Lines per compact objective"}})
numbers("Bags","Appearance",{{"shellPadding","Window padding (pixels)","pixels"}})
switches("PvP","Appearance",{{"automaticLens","Choose emphasis from group and instance context"},{"contacts","Show observed contacts"},{"manualNotes","Show manual notes"},{"badge","Show the current emphasis"}})
describe("PvP","lens","Manual emphasis","Appearance","choice",{1,2,3,4,5},{"Duel","Roaming","Skirmish","Warband","Battleground"})
numbers("PvP","Advanced",{{"contactRows","Contact rows"}})
switches("TacticalSignals","Appearance",{{"legend","Show marker conventions"}})
for i,name in ipairs({"Star","Circle","Diamond","Triangle","Moon","Square","Cross","Skull"}) do
 describe("TacticalSignals","marker"..i,name,"Appearance","choice",{0,1,2,3,4,5,6},{[0]="Unassigned","Primary damage","Crowd control","Danger","Aid requested","Rally","Avoid"})
end
function A:PublicControls(form,id,section)
 local cfg=W.draft.modules[id]
 for _,row in ipairs(public[id] or {}) do
  local key=row.key;local value=cfg[key]
  local visible=row.section==section and value~=nil and row.availability(W.draft)
  if id=="QuestTracker" and key~="compactPanel" and cfg.compactPanel~=true then visible=false end
  if id=="DataBars" and key=="currencyID" and cfg.showCurrency~=true then visible=false end
  if id=="Auras" and (key=="limit" or key=="columns" or key=="iconSize" or key=="showNumbers") and cfg.playerPanel~=true then visible=false end
  if id=="Auras" and (key=="privateCount" or key=="privateSize") and cfg.privateAuras~=true then visible=false end
  if visible then
   if row.kind=="toggle" then
    form:Toggle(id..key,row.label,value,function(v) self:SetModuleOption(id,key,v,true) end)
   elseif row.kind=="choice" then
    form:Choice(id..key,row.label,value,row.values,row.labels,function(v) self:SetModuleOption(id,key,v,true) end)
   elseif row.minimum and row.maximum and type(value)=="number" then
    form:Slider(id..key,row.label,value,row.minimum,row.maximum,1,function(v) self:SetModuleOption(id,key,v) end)
   end
  end
 end
end
function A:PresentationControls(form,id,cfg)
 if cfg.primaryPresentation~=nil then
  form:Choice(id.."primary","Display source",cfg.primaryPresentation,{0,1,2},{[0]="Current profile choice",[1]="MirageUI",[2]="Game controls"},function(v) self:SetModuleOption(id,"primaryPresentation",v,true) end)
  form:Text(id.."sourceHelp","Game controls can be used while troubleshooting this display.",36)
 end
end
function A:SourceControls(form)
 for _,fact in ipairs({"health","resource","cast","gcd"}) do
  local values,labels={},{}
  for _,entry in ipairs(M.Presentation:Options(fact)) do values[#values+1]=entry.value;labels[entry.value]=entry.label end
  local name=({health="Health",resource="Resource",cast="Cast",gcd="Global cooldown"})[fact]
  form:Choice("owner"..fact,name.." display",W.draft.presentation[fact],values,labels,function(v) self:Change(function(p) p.presentation[fact]=v end,true) end)
  form:Toggle("mirror"..fact,"Allow duplicate "..name:lower().." displays",W.draft.presentation[fact.."Mirror"],function(v) self:Change(function(p) p.presentation[fact.."Mirror"]=v end,true) end)
 end
end
function A:HUDControls(form,cfg)
 for _,row in ipairs({{"health","Show health"},{"resource","Show primary resource"},{"cast","Show casts and channels"}}) do
  local key=row[1];form:Toggle("hud."..key,row[2],cfg[key],function(v) self:SetModuleOption("UnderCharacterHUD",key,v,true) end)
 end
 -- Legacy policies 2, 3 and 4 already share the current contextual policy.
 -- Display its name without normalising the saved value just by opening.
 form:Choice("hud.policy","Visibility",cfg.policy==1 and 1 or 2,{1,2},{"Always show health and resource","Contextual health and resource"},function(v) self:SetModuleOption("UnderCharacterHUD","policy",v,true) end)
 form:Text("hud.castHelp","Cast and channel rows appear while active. Context, hover and temporary reveal still apply.",46)
 form:Choice("hud.order","Row order",cfg.layoutOrder,{1,2},{"Health / resource / cast","Cast / health / resource"},function(v) self:SetModuleOption("UnderCharacterHUD","layoutOrder",v,true) end)
 form:Toggle("hud.percent","Show health and resource percentages",cfg.showPercent,function(v) self:SetModuleOption("UnderCharacterHUD","showPercent",v,true) end)
 for _,part in ipairs({"health","resource","cast"}) do
  local name=({health="Health",resource="Resource",cast="Cast"})[part]
  form:Choice("hud."..part.."Color",name.." color",cfg[part.."Color"],{1,2,3},{part=="resource" and "Resource color" or "MirageUI theme","Class","Custom"},function(v) self:SetModuleOption("UnderCharacterHUD",part.."Color",v,true) end)
  if cfg[part.."Color"]==3 then
   for _,channel in ipairs({{"R","Red"},{"G","Green"},{"B","Blue"}}) do
    local key=part..channel[1];form:Slider("hud."..key,name.." · "..channel[2].." (0–255)",cfg[key],0,255,1,function(v) self:SetModuleOption("UnderCharacterHUD",key,v) end)
   end
  end
 end
 form:Button("hud.layout","Position and size",function() M.ElementMap:Open("UnderCharacterHUD") end)
 if self:Disclosure(form,"hud.advanced","Advanced") then
  for _,row in ipairs({{"rowPitch","Row spacing (pixels)"},{"healthHeight","Health height (pixels)"},{"resourceHeight","Resource height (pixels)"},{"castHeight","Cast height (pixels)"},{"castWidthExtra","Extra cast width (pixels)"},{"opacity","Display opacity (%)"},{"trackOpacity","Track opacity (%)"},{"healthFillOpacity","Health fill opacity (%)"},{"resourceFillOpacity","Resource fill opacity (%)"},{"castFillOpacity","Cast fill opacity (%)"},{"percentTextSize","Percentage text size (points)"},{"percentTextOpacity","Percentage text opacity (%)"}}) do
   local key=row[1];local def=M.FeatureSettings.UnderCharacterHUD[key]
   if not key:match("^percent") or cfg.showPercent then form:Slider("hud."..key,row[2],cfg[key],def[2],def[3],1,function(v) self:SetModuleOption("UnderCharacterHUD",key,v) end) end
  end
  if self:Disclosure(form,"hud.sources","Display sources") then self:SourceControls(form) end
 end
end
function A:ModuleControls(form,id)
 local cfg=W.draft.modules[id];if not cfg then return end
 if M.NativeWindowPolicy and M.NativeWindowPolicy:ModuleNative(id) then
  form:Text(id.."nativePolicy","This window uses the game's controls and appearance.",42);return
 end
 local optional={Auras=true,QuestTracker=true,Preparations=true,ResourceBars=true,PvP=true,TacticalSignals=true}
 if cfg.primaryPresentation==nil or optional[id] or id=="Tooltips" then
  form:Toggle(id.."enabled",id=="Tooltips" and "Enable tooltip features" or cfg.primaryPresentation~=nil and "Enable optional features" or "Show this display",cfg.enabled,function(v) self:Change(function(p) p.modules[id].enabled=v end,true) end)
 end
 if id=="UnderCharacterHUD" then self:HUDControls(form,cfg);return end
 if id=="ActionBars" and M.Rework and M.Rework:Selected("main",W.draft) then
  form:Choice("actionExperience","Reveal action bars",cfg.actionExperience or 2,{1,2},{"With combat displays","On hover"},function(v) self:SetModuleOption(id,"actionExperience",v,true) end)
  form:Slider("actionInterfaceScale","Scale (%)",cfg.interfaceScale or 100,65,160,5,function(v) self:SetModuleOption(id,"interfaceScale",v,true) end)
  form:Slider("actionInterfaceAlpha","Opacity (%)",(cfg.alpha or 1)*100,20,100,5,function(v) self:SetModuleOption(id,"alpha",v/100) end)
  for _,row in ipairs({{"interfaceDocked","Anchor to the bottom of the screen"},{"showTooltips","Show tooltips"},{"allowRearrange","Allow arranging actions"}}) do local key=row[1];form:Toggle("action"..key,row[2],cfg[key],function(v) self:SetModuleOption(id,key,v,true) end) end
  if self:Disclosure(form,"action.labels","Labels") then
   form:Toggle("actionShowHotkeys","Show keybind labels",cfg.showHotkeys,function(v) self:SetModuleOption(id,"showHotkeys",v,true) end)
   if cfg.showHotkeys then
    form:Toggle("actionCenterHotkeys","Center keybind labels",cfg.centerHotkeys,function(v) self:SetModuleOption(id,"centerHotkeys",v,true) end)
    if cfg.centerHotkeys then
     form:Toggle("actionAutoSizeHotkeys","Fit keybind text to each slot",cfg.autoSizeHotkeys,function(v) self:SetModuleOption(id,"autoSizeHotkeys",v,true) end)
     if not cfg.autoSizeHotkeys then form:Slider("actionHotkeySize","Keybind text size (points)",cfg.hotkeySize or 16,10,24,1,function(v) self:SetModuleOption(id,"hotkeySize",v) end) end
    end
   end
   form:Toggle("actionHideMacroText","Hide macro names",cfg.hideMacroText,function(v) self:SetModuleOption(id,"hideMacroText",v,true) end)
  end
  form:Button("actionBindings","Edit keybinds",function() if M.BindingEditor then M.BindingEditor:Open() end end)
  form:Button("actionInterfaceMap","Position and size",function() M.ElementMap:Open("ActionBars.interface") end)
  if self:Disclosure(form,"action.help","How action bars work") then
   form:Text("actionHelp","Hover reveals your action bars. Click More actions for additional slots. Hold the game's pickup modifier (usually Shift) to rearrange actions outside combat.",70)
   form:Text("actionDockHelp","Rows grow upward from the bottom anchor. Moving the interface releases that anchor; resizing keeps it attached.",52)
  end
  if self:Disclosure(form,"ActionBars.advanced","Advanced") then self:PresentationControls(form,id,cfg) end
  return
 end
 if id=="Tooltips" then
  form:Text("tooltipIntro","Tooltip appearance and position. Insight has separate information and text-size preferences.",46)
  form:Toggle("mirageTooltipStyle","Mirage tooltip appearance",cfg.style,function(v) self:SetModuleOption(id,"style",v,true) end)
  local mode=cfg.cursorAnchor and 3 or cfg.fixedAnchor and 2 or 1
  form:Choice("mirageTooltipPlacement","World tooltip position",mode,{1,2,3},{"Default","Fixed screen position","Beside the cursor"},function(v) self:Change(function(p) p.modules.Tooltips.fixedAnchor=v==2;p.modules.Tooltips.cursorAnchor=v==3 end,true) end)
  form:Slider("mirageTooltipSize","Whole tooltip scale (%)",cfg.tooltipScale or 100,70,160,5,function(v) self:SetModuleOption(id,"tooltipScale",v) end)
  if mode==3 then form:Slider("mirageTooltipCursorOffset","Cursor offset (pixels)",cfg.cursorOffset or 100,0,200,1,function(v) self:SetModuleOption(id,"cursorOffset",v) end) end
  form:Button("mirageTooltipMap","Position and scale",function() M.ElementMap:Open("Tooltips.anchor") end)
  form:Button("mirageInsightSettings","Insight information and text size",function() self:OpenCompanion("MirageIntel_Insight") end)
  if self:Disclosure(form,"Tooltips.advanced","Advanced") then
   if mode==1 then form:Toggle("mirageTooltipAvoidMeters","Keep tooltips clear of Meters",cfg.avoidMeters~=false,function(v) self:SetModuleOption(id,"avoidMeters",v,true) end) end
   self:PresentationControls(form,id,cfg)
   form:Text("tooltipAnchors","Item comparisons and control-specific tooltips keep their own anchors. Position and scale changes apply outside combat.",56)
  end
  return
 end
 if id=="Cooldowns" then self:CooldownControls(form,cfg);return end
 if id=="DamageMeters" then
  form:Toggle("metersEnabled","Show Meters",cfg.enabled~=false and cfg.metersEnabled~=false,function(v)
   self:Change(function(p) local meters=p.modules.DamageMeters;meters.enabled=v;meters.metersEnabled=v;if v and meters.primaryPresentation==2 then meters.primaryPresentation=1 end end,true)
  end)
  form:Text("metersIntro","Fight tracking is automatic. Choose a measure or report in Meters; select a player for ability details.",48)
  for _,row in ipairs({{"meterFirstName","Show first character name"},{"meterClassColors","Use class colors"},{"meterPinPlayer","Keep my row visible"}}) do local key=row[1];form:Toggle("meters"..key,row[2],cfg[key]~=false,function(v) self:SetModuleOption(id,key,v,true) end) end
  form:Slider("metersRows","Visible rows",cfg.meterRows or 8,3,15,1,function(v) self:SetModuleOption(id,"meterRows",v,true) end)
  form:Choice("metersVisibility","Visibility",cfg.visibility,{"Contextual","Always","Manual"},{Contextual="Follow context",Always="Always when available",Manual="Temporary reveal only"},function(v) self:SetModuleOption(id,"visibility",v,true) end)
  form:Button("metersOpen","Open Meters",function() if M.Rework and M.Rework.CombatMeters then M.Rework.CombatMeters:Open() end end)
  form:Button("metersMap","Position and size",function() M.ElementMap:Open("DamageMeters.mirage") end)
  if self:Disclosure(form,"DamageMeters.advanced","Advanced") then
   form:Slider("metersAlpha","Opacity (%)",(cfg.alpha or 1)*100,20,100,5,function(v) self:SetModuleOption(id,"alpha",v/100) end)
   form:Toggle("metersReplaceNative","Replace the game meter window",cfg.meterReplaceNative~=false,function(v) self:SetModuleOption(id,"meterReplaceNative",v,true) end)
   self:PresentationControls(form,id,cfg)
  end
  return
 end
 local visibility=M.Elements:SettingSupported(id,"visibility",W.draft)
 if visibility then form:Choice(id.."visibility","Visibility",cfg.visibility,{"Contextual","Always","Manual"},{Contextual="Follow context",Always="Always when available",Manual="Temporary reveal only"},function(v) self:SetModuleOption(id,"visibility",v,true) end) end
 self:PublicControls(form,id,"Appearance")
 if id=="PartyRaid" then
  form:Button("raidWholeLayout","Position and size · Raid",function() M.ElementMap:Open("PartyRaid.raidFrame") end)
  form:Button("partyWholeLayout","Position and size · Party",function() M.ElementMap:Open("PartyRaid.partyFrame") end)
 else form:Button(id.."map","Customize display",function() M.ElementMap:Open(id) end) end
 if id=="Minimap" then form:Button("restoreSidebarWidth","Restore sidebar width",function() self:RestoreSidebarWidth() end) end
 if self:Disclosure(form,id..".advanced","Advanced") then
  self:PresentationControls(form,id,cfg)
  self:PublicControls(form,id,"Advanced")
  for _,row in ipairs({{"alpha","Opacity (%)",20,100,5,100},{"scale","Scale (%)",60,160,5,100}}) do
   local key=row[1]
   if cfg[key]~=nil and M.Elements:SettingSupported(id,key,W.draft) then form:Slider(id..key,row[2],cfg[key]*row[6],row[3],row[4],row[5],function(v) self:SetModuleOption(id,key,v/row[6]) end) end
  end
  local nativeID=id=="UnitFrames" and "UnitFrames.player" or id=="PartyRaid" and "PartyRaid.raidFrame"
  if nativeID and M.Elements:IsNativeGeometry(nativeID,W.draft) then form:Button(id.."nativeEditHUD","Open Blizzard Edit HUD",function() self:RequestNativeEditor(nativeID) end) end
  local listField=id=="Auras" and cfg.preparation and "reminders" or id=="Preparations" and "supplyIDs"
  if listField then
   local ids={};for _,v in ipairs(cfg[listField] or {}) do ids[#ids+1]=tostring(v) end
   form:Edit(id.."ids",listField=="reminders" and "Reminder spell IDs (up to 8)" or "Supply item IDs (up to 8)",table.concat(ids," "),function(text)
    local values,seen={},{}
    for token in text:gmatch("%S+") do local n=tonumber(token);if not n or n%1~=0 or n<1 or n>2147483647 or #values>=8 or seen[n] then return false,"Enter up to eight distinct positive IDs, separated by spaces." end;values[#values+1]=n;seen[n]=true end
    return self:Change(function(p) p.modules[id][listField]=values end)
   end)
  end
 end
end
function A:Suite(form)
 form:Text("suiteIntro","Open companion settings here. Each companion can run independently and saves its own settings. Use the game's AddOns list to enable or disable addons.",100)
 form:Button("addonMenu","Open AddOns menu",function()
  if M.SuiteLauncher then M.SuiteLauncher:Open(self.frame) else self:Notice("The AddOns menu is unavailable in this build.") end
 end,"addons-launcher")
 local entries={
  {"CursorCompanion","Cursor Companion","/cc config", "cursor-companion"},
  {"MirageUISanctuary","Sanctuary","/sanctuary settings", "sanctuary"},
  {"Wealthcraft","WealthCraft","/wealthcraft settings", "wealthcraft"},
  {"MirageIntel_Map","Maps","/mmap", "utility-map"},
  {"MirageIntel_Navigate","Wayfinder","/mnav", "utility-navigate"},
  {"MirageIntel_Gather","Gather Mate","/mgather", "utility-gather"},
  {"MirageIntel_Insight","Insight","/minsight", "utility-insight"}}
 for _,row in ipairs(entries) do
  local addonName,label,command,glyph=row[1],row[2],row[3],row[4]
  local descriptor=_G.MirageUIAddonSettings and _G.MirageUIAddonSettings[addonName]
  if descriptor and type(descriptor.title)=="string" then label=descriptor.title end
  local loaded=S:Loaded(addonName)
  form:Button(addonName,"Open "..label.." settings",function()
   if not M.SuiteLauncher then self:Notice("The AddOns menu is unavailable in this build.");return end
   local ok,why=M.SuiteLauncher:OpenAddon(addonName)
   if ok and addonName~="MirageUIOptions" then self:HidePreserve() elseif not ok then self:Notice(why or "Settings could not open.") end
  end,glyph)
  form:Text(addonName.."shortcut",loaded and command or "Addon is not loaded.  "..command,24)
 end
 local retired=S:Loaded("MirageUICursor")
 local getMetadata=_G.C_AddOns and _G.C_AddOns.GetAddOnMetadata or _G.GetAddOnMetadata
 if not retired and type(getMetadata)=="function" then local ok,value=pcall(getMetadata,"MirageUICursor","Title");retired=ok and (not S.Readable or S:Readable(value)) and type(value)=="string" and value~="" end
 if retired then form:Text("legacy","The retired MirageUICursor addon is installed. Remove that folder when updating; Cursor Companion is its replacement.",62) end
end
function A:VisibilityControls(form)
 form:Text("visibilityHeading","Contextual visibility",28,true,"visibility")
 form:Slider("idle","Hide after inactivity (seconds)",W.draft.idle,0,15,.5,function(v) self:Change(function(p) p.idle=v end) end)
 form:Slider("fade","Fade duration (seconds)",W.draft.fade,0,.4,.05,function(v) self:Change(function(p) p.fade=v end) end)
end
function A:Customize(form)
 -- One uncluttered destination per banner. Other suite settings remain
 -- available from Displays, Profiles and Help in the persistent navigation.
 form.y=8
 form:Banner("landing.customize","01_Customize_UI.tga",function()
  if M.state.safe or M.state.safeCleanupPending then self.page="Help";self:Render();self:Notice("MirageUI is paused. Resume saved displays from Help before customizing.");return end
  if M.ElementMap then M.ElementMap:Open()
  else self:Notice("Customize UI is not available on this client.") end
 end,"Customize UI")
 form.y=form.y+12
 form:Banner("landing.keybinds","02_Configure_Keybinds.tga",function()
  local workspace=M.KeybindWorkspace
  if not workspace or type(workspace.Enter)~="function" then self:Notice("Configure Keybinds is unavailable.");return end
  local ok,why=workspace:Enter()
  if not ok then self:Notice(why or "Configure Keybinds could not open.") end
 end,"Configure Keybinds")
 form.y=form.y+12
 form:Banner("landing.cooldowns","03_Configure_Cooldowns.tga",function()
  local editor=M.CooldownEditor
  if not editor or type(editor.Enter)~="function" then self:Notice("Configure Cooldowns is unavailable.");return end
  local ok,why=editor:Enter()
  if not ok then self:Notice(why or "Configure Cooldowns could not open.") end
 end,"Configure Cooldowns")
end
function A:Setup()
 if W.draft and (W.dirty or self:HasPendingInput()) then self:Notice("Apply or cancel your draft before changing your setup.");return false end
 return self:Open("Setup")
end
function A:SetupChoice(yes)
 if not self:FlushInputs() or W.dirty then self:Notice("Apply or cancel your draft before changing your setup.");return false end
 local current,why=W:Current();if not current then self:Notice(why);return false end
 W:Discard()
 local ok,message=M.Experience:Choose(yes)
 W:Begin();self.page=ok and "Customize" or "Setup";self.selectedModule=nil;self:Render();self:Notice(message)
 return ok,message
end
function A:SetupPage(form)
 form:Text("title","Set up MirageUI",30,true)
 form:Text("intro","Keep the world in view. Navigation appears while traveling; combat and interaction reveal the displays you need.",64)
 if M.Experience:PreviousChoice() then
  form:Button("resumeChoices","Enable MirageUI",function()
   if not self:FlushInputs() or W.dirty then self:Notice("Apply or cancel the current draft first.");return end
   local ok,why=M.Experience:ResumeChoices();W:Discard();W:Begin();self.page=ok and "Customize" or "Setup";self:Render();self:Notice(why)
  end)
 end
 form:Button("setupYes","Apply recommended layout",function() self:SetupChoice(true) end)
 form:Button("setupNo","Keep my current interface",function()
  if not M.Experience:PreviousChoice() then self:SetupChoice(false);return end
  if not self:FlushInputs() or W.dirty then self:Notice("Apply or cancel the current draft first.");return end
  local ok,why=M.Experience:KeepChoices()
  if ok then self.page="Customize";self:Render() end
  self:Notice(why)
 end)
 form:Text("choiceHelp","These actions save your setup choice immediately. You can return to setup from Help.",46)
end
function A:HelpActions(form)
 local width=math.floor(math.min(160,(form.width-20)/3))
 form:Place("helpActions","actions",function()
  local row=CreateFrame("Frame",nil,form.parent)
  row:SetSize(form.width,94)
  local actions={
   {"Report","View report",function() self:TextDialog("MirageUI backend report",M.Diagnostics:Export()) end},
   {"Wizard","Run setup",function() self:Setup() end},
   {"Addons","Browse addons",function() self.suiteExpanded=not self.suiteExpanded;self:Render() end}}
  for index,action in ipairs(actions) do
   local callback=action[3]
   local button=U:Button(row,action[2],(index-1)*(width+10),0,width,function()
    if W.draft then local ok,why=W:Current();if not ok then self:Notice(why);return end end
    if self:FlushInputs() then callback() end
   end)
   button:SetHeight(94)
   local icon=button:CreateTexture(nil,"ARTWORK")
   icon:SetTexture(controlArt..action[1]..".tga");icon:SetPoint("TOP",0,-7);icon:SetSize(54,54)
   button.label:ClearAllPoints();button.label:SetPoint("BOTTOMLEFT",3,8);button.label:SetPoint("BOTTOMRIGHT",-3,8)
   button.label:SetJustifyH("CENTER")
  end
  return row
 end,94)
end
-- The label and its expand mark share a hit target, without button chrome.
function A:HelpDisclosure(form,key,label)
 self.disclosures=self.disclosures or {}
 local expanded=self.disclosures[key]==true
 local item=form:Place("section."..key,"disclosure",function()
  local header=CreateFrame("Button",nil,form.parent)
  header:RegisterForClicks("LeftButtonUp")
  header.label=U:Text(header,label,0,0,14)
  header.label:ClearAllPoints();header.label:SetPoint("LEFT",18,0)
  header.label:SetJustifyV("MIDDLE")
  U:SetTextRole(header.label,"secondary")
  local bar=header:CreateTexture(nil,"ARTWORK")
  bar:SetSize(9,1);bar:SetPoint("LEFT",2,0);bar:SetColorTexture(unpack(M.Theme.secondary))
  local stem=header:CreateTexture(nil,"ARTWORK")
  stem:SetSize(1,9);stem:SetPoint("CENTER",bar);stem:SetColorTexture(unpack(M.Theme.secondary))
  header.expandMark=stem
  header:SetScript("OnEnter",function() U:SetTextRole(header.label,"heading") end)
  header:SetScript("OnLeave",function() U:SetTextRole(header.label,"secondary") end)
  header:SetScript("OnClick",function()
   if W.draft then local ok,why=W:Current();if not ok then self:Notice(why);return end end
   if not self:FlushInputs() then return end
   self.disclosures[key]=not self.disclosures[key];self:Render()
  end)
  return header
 end,28)
 local header=item.frame
 local w=header.label.GetStringWidth and header.label:GetStringWidth() or #label*9
 header:SetSize(math.min(form.width,w+32),28)
 header.expandMark:SetShown(not expanded)
 header.mirageActionLabel=(expanded and "Collapse " or "Expand ")..label
 return expanded
end
-- Group related compact actions when both labels fit at the current text scale.
function Form:PairActions(first,second)
 local a,b=self.cache[first].frame,self.cache[second].frame
 local gap=10
 if (self.indent or 0)+a:GetWidth()+gap+b:GetWidth()>self.width then return end
 b:ClearAllPoints();b:SetPoint("TOPLEFT",a,"TOPRIGHT",gap,0)
 self.y=self.y-math.min(a:GetHeight(),b:GetHeight())-10
end
function A:Help(form)
 form:Text("title","Help",30,true,"compatibility")
 local c=M.Client;local state=M.Diagnostics:ActivationState()
 form:Text("version","MirageUI "..tostring(M.version or M.BuildInfo and M.BuildInfo.version or "").."  ·  Game "..tostring(c.patch or "unknown"),32)
 form:Text("status",state.title,30)
 self:HelpActions(form)
 if self.suiteExpanded then self:Suite(form) end
 if self:HelpDisclosure(form,"help.troubleshooting","Troubleshooting") then
  form.indent=18
  form:Button("recover",M.profile.enabled~=true and "Enable MirageUI" or M.state.safe and "Resume MirageUI" or "Retry displays",function()
   if W.dirty then self:Notice("Apply or cancel the draft before recovery.");return end
   local ok,why
   if M.profile.enabled~=true then ok,why=M.Experience:ResumeChoices() else ok,why=M:Recover() end
   W:Discard();W:Begin();self:Render();self:Notice(why or (ok and "Recovery requested." or "Recovery could not finish."))
  end)
  form:Button("reveal","Show displays for 10s",function() M.CVE:Reveal(10);self:Notice("Temporary reveal requested.") end)
  form:PairActions("recover","reveal")
  if M.Rework then
   local retryable={PARTIAL=true,DEFERRED_HANDOFF=true,CONFLICT=true,FAULT=true};local affected={}
   for id,provider in pairs(M.Rework.providers or {}) do
    local native=M.NativeWindowPolicy and M.NativeWindowPolicy:ProviderNative(id)
    if provider.pending or not native and (retryable[provider.readiness] or provider.failed) then affected[#affected+1]=id end
   end
   table.sort(affected)
   for _,providerID in ipairs(affected) do
    local id=providerID;local provider=M.Rework.providers[id]
    form:Button("retry."..id,"Retry "..(provider.label or (M.CatalogByID[provider.module] or {}).name or "display"),function()
     local ok,why=M.Rework:Retry(id);self:Render();self:Notice(why or (ok and "Display retry requested." or "This display cannot be retried yet."))
    end)
   end
  end
  form:Text("pauseHelp","Pause MirageUI to restore the game controls. Your settings are saved.",28)
  form:Button("safe","Pause MirageUI",function()
   if W.dirty then self:Notice("Apply or cancel the draft before pausing MirageUI.");return end
   self:HidePreserve();if M.ElementMap then M.ElementMap:HidePreserve() end
   local ok=M:SafeMode("USER_REQUEST");W:Discard();self:Open("Help");self:Notice(ok and "MirageUI is paused. Saved preferences are retained." or "Some controls still need recovery. Prepare a support report.")
  end)
  if M.Profiler then
   form:Text("captureHelp","Record performance while you play. Open the capture to copy it for support.",44)
   form:Button("captureToggle",M.Profiler.running and "Stop capture" or "Start capture",function()
    local ok,why;if M.Profiler.running then ok,why=M.Profiler:Stop() else ok,why=M.Profiler:Start("ROUTE") end
    self:Render();self:Notice(why or (ok and "Capture updated." or "Capture could not start."))
   end)
   form:Button("captureCopy","View capture",function() self:TextDialog("MirageUI performance capture",M.Profiler:Export().."\n\n"..M.Diagnostics:Export()) end)
   form:PairActions("captureToggle","captureCopy")
  end
  form.indent=0
 end
 if self:HelpDisclosure(form,"help.technical","Technical details") then
  form.indent=18
  local a=M.adapter or {}
  form:Text("client","Client: "..tostring(c.patch).." / "..tostring(c.build).." / "..tostring(c.interface).."\nPackage: "..tostring(M.BuildInfo and M.BuildInfo.target or "unknown").."\nSource: "..tostring(a.sourceCommit or "unavailable"),80)
  form:Text("nativeWindows","Task windows, character panels, progression, maps and system windows use the game controls.",54)
  if M.Rework then
   form:Button("mapping","View saved preferences",function() self:TextDialog("Preserved preferences",M.Rework:PreferenceReport()) end)
   form:Button("coverage","View display status",function() self:TextDialog("Display coverage",M.Rework:Report()) end)
   form:PairActions("mapping","coverage")
  end
  form.indent=0
 end
end
function A:Render()
 if not W.draft or not self.form then return end
 local form=self.form;form.helpActions=self.page=="Help" or self.page=="Suite";form.compact=self.page=="Modules";form.width=form.compact and 390 or 600;form:Begin()
 if self.page=="Profiles" then self:Profiles(form)
 elseif self.page=="Modules" then self:Modules(form)
 elseif self.page=="Suite" then self.page="Help";self.suiteExpanded=true;self:Help(form)
 elseif self.page=="Help" then self:Help(form)
 elseif self.page=="Setup" then self:SetupPage(form)
 else self.page="Customize";self:Customize(form) end
 form:Finish();self:RefreshFooter()
 local route=self.page..":"..tostring(self.selectedModule or "")
 if self.scrollRoute~=route then self.scroll:SetVerticalScroll(0);self.scrollRoute=route
 else
  local maximum=math.max(0,self.body:GetHeight()-self.scroll:GetHeight())
  if self.scroll:GetVerticalScroll()>maximum then self.scroll:SetVerticalScroll(maximum) end
 end
 for key,button in pairs(self.nav) do button.selected=key==self.page;U:PaintButton(button) end
end
-- Preserve the original Yes/No transaction and explanatory body within the same
-- shell. Existing legacy code remains available for compatibility, not entry.
local P=M.PlayerSettings;local oldClose=P.Close
function P:Open(page)
 if page=="welcome" then return A:Setup() end
 return A:Open(page=="profiles" and "Profiles" or page=="help" and "Help" or page=="cursor" and "Suite" or (page=="displays" or page=="context") and "Modules" or "Customize")
end
function P:Render(page) return self:Open(page) end
function P:Close() oldClose(self);A:HidePreserve() end
function M.Options:Open() return A:Open("Customize") end
function M.Options:LegacyOpen() return A:Open("Modules") end
function M.Options:Setup() return P:Open("welcome") end
