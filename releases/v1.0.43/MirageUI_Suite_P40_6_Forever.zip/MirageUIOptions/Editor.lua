local M=MirageUI
if not M then return end
M.Editor={ghosts={},selected=nil,active=false,history={}}
local E,U=M.Editor,M.UI
local controlOrder={"x","y","width","height","scale"}
local filterLabels={main="Main displays",groups="Party & raid",other="Other displays",all="All displays"}
local mainIDs={['UnitFrames.player']=true,['UnitFrames.target']=true,['UnitFrames.focus']=true,['UnitFrames.pet']=true,
 ['UnderCharacterHUD.player']=true,['ResourceBars.player']=true,
 ['ActionBars.bar1']=true,['ActionBars.bar2']=true,['ActionBars.bar3']=true,
 ['Auras.player']=true,['Cooldowns.tracked']=true,['QuestTracker.compact']=true}
local friendly={['UnitFrames.player']='Player',['UnitFrames.target']='Target',['UnitFrames.focus']='Focus',['UnitFrames.pet']='Pet',
 ['UnderCharacterHUD.player']='Under-character bars',['ResourceBars.player']='Resources',
 ['Auras.player']='Player auras',['Cooldowns.tracked']='Tracked cooldowns',['QuestTracker.compact']='Objectives',['Tooltips.anchor']='Tooltip position'}
local function label(id)
 local s=M.surfaces[id];if s and s.label then return s.label end
 if friendly[id] then return friendly[id] end
 local raid=id:match('^PartyRaid%.raid(%d+)$');if raid then return 'Raid member '..raid end
 local group=id:match('^PartyRaid%.group(%d+)$');if group then return 'Raid group '..group end
 local party=id:match('^PartyRaid%.party(%d+)$');if party then return 'Party member '..party end
 return id
end
function E:InFilter(id)
 local s=M.surfaces[id];if not s then return false end
 if M.NativeWindowPolicy and M.NativeWindowPolicy:ModuleNative(s.module) then return false end
 local f=self.filter or 'main'
 if f=='all' then return true end
 if f=='groups' then return s.module=='PartyRaid' end
 local main=mainIDs[id] or s.module=='Minimap' or s.module=='Chat'
 return f=='main' and main==true or f=='other' and s.module~='PartyRaid' and not main
end
function E:SetFilter(value)
 if not filterLabels[value] or not self:CanEdit() or not self:FlushEdits() then return false end
 self.filter=value
 if not self.selected or not self:InFilter(self.selected) then
  self.selected=nil;for _,id in ipairs(self.ids or {}) do if self:InFilter(id) then self.selected=id;break end end
 end
 self:Refresh();return true
end
function E:CanEdit()
    return self.active and self.draft and self.frame and self.frame:IsVisible() and
        M.DialogNavigation.top==self.frame and not M.Safety:InCombat() and not M.state.safe and not M.state.cinematic
end
function E:FlushEdits()
    if not self:CanEdit() then return false end
    if not self.selected or not self.controls then return true end
    local pending=false
    -- Validate every pending value before any callback can change this draft.
    -- A rejected field must not partly save its siblings or switch the owner.
    for _,key in ipairs(controlOrder) do
        local control=self.controls[key]
        local ok,why=control:Validate()
        if not ok then self.name:SetText(why);control.edit:SetFocus();return false,why end
        pending=pending or control:Pending()
    end
    if pending then
        self:Record()
        self.flushing=true
        for _,key in ipairs(controlOrder) do self.controls[key]:Commit() end
        self.flushing=false
        M.Layout:Clamp(self:Layout(self.selected));self:PlaceGhost(self.selected)
        self:RefreshControls()
    end
    return true
end
function E:Adjust(key,delta)
    if not self:CanEdit() or not self.selected or (delta~=1 and delta~=-1) then return false end
    if not self:FlushEdits() then return false end
    local control=self.controls[key];local slider=control and control.slider
    if not slider then return false end
    local value,vs=M.Safety:Public(slider.GetValue,"number",slider)
    local step,ss=M.Safety:Public(slider.GetValueStep,"number",slider)
    local ok,lo,hi=pcall(slider.GetMinMaxValues,slider)
    if vs~="KNOWN" or ss~="KNOWN" or step<=0 or not ok or not M.Safety:Number(lo) or not M.Safety:Number(hi) or hi<lo then return false end
    local nextValue=math.max(lo,math.min(hi,value+delta*step))
    if not M.Safety:Number(nextValue) then return false end
    if nextValue==value then return true end
    local previous=M:Copy(self.draft.layouts);local changed=pcall(slider.SetValue,slider,nextValue)
    if not changed then self.draft.layouts=previous;pcall(self.Refresh,self);self.refreshing=false;self.name:SetText("Number could not be adjusted. Reopen the editor if its display is stale.");return false end
    self.history[#self.history+1]=previous;if #self.history>20 then table.remove(self.history,1) end
    self:RefreshControls();return true
end
function E:FitPanel()
    local w,ws=M.Safety:Public(UIParent.GetWidth,"number",UIParent)
    local h,hs=M.Safety:Public(UIParent.GetHeight,"number",UIParent)
    if ws~="KNOWN" or hs~="KNOWN" or w<=30 or h<=30 then return false end
    self.frame:SetSize(490,600);self.frame:SetScale(math.min(1,(w-30)/490,(h-30)/600));return true
end
local function point()
    -- Read both coordinates together, without using secret or malformed operands.
    local ok,a,b=pcall(GetCursorPosition)
    if not ok or not M.Safety:Number(a) or not M.Safety:Number(b) then return nil end
    local scale=UIParent:GetEffectiveScale()
    if not M.Safety:Number(scale) or scale<=0 then return nil end
    return a/scale,b/scale
end
function E:Record()
    self.history[#self.history+1]=M:Copy(self.draft.layouts)
    if #self.history>20 then table.remove(self.history,1) end
end
function E:Undo()
    if not self:CanEdit() then return false end
    -- Undo/Reset/Cancel deliberately discard pending text; they must remain a
    -- way out of an invalid entry rather than requiring it to be committed.
    for _,key in ipairs(controlOrder) do
        if self.controls[key]:Pending() then self:RefreshControls();return true end
    end
    if #self.history==0 then return false end
    self.draft.layouts=table.remove(self.history);self:Refresh();return true
end
function E:Reset()
    if not self:CanEdit() then return false end
    self:Record();self.draft.layouts={};self:Refresh();return true
end
function E:Layout(id)
    local s=M.surfaces[id]
    if not s then return nil end
    local l=self.draft.layouts[id]
    if not l then l=M.Layout:Get(s,self.draft);self.draft.layouts[id]=l end
    l.width=math.max(s.minWidth or 24,l.width);l.height=math.max(s.minHeight or 16,l.height)
    return l
end
function E:WorldPosition(id,seen)
    seen=seen or {};if seen[id] then return 0,0 end;seen[id]=true
    local l=self:Layout(id);if not l then return 0,0 end
    local x,y=l.x,l.y
    if l.anchorTo and M.surfaces[l.anchorTo] then local ax,ay=self:WorldPosition(l.anchorTo,seen);x=x+ax;y=y+ay end
    return x,y
end
function E:PlaceGhost(id)
    local g=self.ghosts[id];local l=self:Layout(id);if not g or not l then return end
    local x,y=self:WorldPosition(id)
    local sx,sy=UIParent:GetWidth(),UIParent:GetHeight()
    g:ClearAllPoints();g:SetPoint("CENTER",UIParent,"CENTER",x*sx,y*sy);g:SetSize(l.width*(l.scale or 1),l.height*(l.scale or 1))
    g:SetBackdropBorderColor(unpack(self.selected==id and M.Theme.accent or M.Theme.edge))
    if g.label then g.label:SetWidth(math.max(16,l.width*(l.scale or 1)-34));g.label:SetText(M.Icons and M.Icons:Label(M.Icons:ForElement({id=id,module=(M.surfaces[id] or {}).module}),label(id),14) or label(id)) end
end
function E:Select(id)
    if not self:CanEdit() then return false end
    local found=false;for _,candidate in ipairs(self.ids or {}) do if candidate==id then found=true;break end end
    if not found or not self:FlushEdits() then return false end
    for _,control in pairs(self.controls) do control.edit:ClearFocus() end
    if not self:InFilter(id) then self.filter="all" end
    self.selected=id;self:Refresh()
    for key in pairs(self.ghosts) do if self.ghosts[key]:IsShown() then self:PlaceGhost(key) end end
    return true
end
function E:DragStart(id,resize)
    if not self.active or M.Safety:InCombat() then return end
    local x,y=point();if not x then return end
    if not self:Select(id) then return end
    self:Record()
    local l=self:Layout(id);local gx,gy=self:WorldPosition(id)
    -- Drag is an explicit reanchor to the screen; no protected native frame is touched.
    if not resize then l.anchorTo=nil;l.x=gx;l.y=gy end
    self.drag={id=id,x=x,y=y,layout=M:Copy(l),resize=resize}
end
function E:UpdateDrag()
    local d=self.drag;if not d then return end
    if M.Safety:InCombat() then self:Close();return end
    local x,y=point();if not x then return end
    local l=self:Layout(d.id);local scale=l.scale or 1
    if d.resize then
        l.width=math.max(24,math.min(1200,d.layout.width+(x-d.x)/scale))
        l.height=math.max(16,math.min(800,d.layout.height-(y-d.y)/scale))
    else
        l.x=d.layout.x+(x-d.x)/UIParent:GetWidth();l.y=d.layout.y+(y-d.y)/UIParent:GetHeight()
        l.x,l.y=M.Layout:Snap(d.id,l.x,l.y,l.width*scale,l.height*scale,self.draft)
    end
    l.width=math.max(M.surfaces[d.id].minWidth or 24,l.width);l.height=math.max(M.surfaces[d.id].minHeight or 16,l.height)
    M.Layout:Clamp(l);self:PlaceGhost(d.id)
end
function E:DragStop() self.drag=nil;self:RefreshControls() end
function E:CreateGhost(id,surface)
    local g=self.ghosts[id]
    if g then return g end
    g=CreateFrame("Frame",nil,UIParent,"BackdropTemplate");self.ghosts[id]=g
    g:SetFrameStrata("DIALOG");g:SetFrameLevel(5);U:Backdrop(g,true);g:SetBackdropColor(.060,.060,.065,.58)
    g:EnableMouse(true);g:RegisterForDrag("LeftButton");g:SetClampedToScreen(true)
    g.label=U:Text(g,M.Icons and M.Icons:Label(M.Icons:ForElement({id=id,module=surface.module}),label(id),14) or label(id),7,-7,11,180)
    g:SetScript("OnMouseDown",function(_,button) if button=="LeftButton" then self:Select(id) end end)
    g:SetScript("OnDragStart",function() self:DragStart(id,false) end)
    g:SetScript("OnDragStop",function() self:DragStop() end)
    local handle=U:Button(g,"+",0,0,22,nil);handle:ClearAllPoints();handle:SetPoint("BOTTOMRIGHT",-2,2);handle:SetHeight(22)
    handle:RegisterForDrag("LeftButton");handle:SetScript("OnDragStart",function() self:DragStart(id,true) end);handle:SetScript("OnDragStop",function() self:DragStop() end)
    g:Hide();return g
end
function E:Create()
    if self.frame then return end
    local f=U:Panel("MirageUILayoutEditor",M.Icons and M.Icons:Label("layout","Unlock Mode",22) or "Unlock Mode",490,600);self.frame=f
    f:ClearAllPoints();f:SetPoint("LEFT",UIParent,"LEFT",20,0);f:SetFrameStrata("FULLSCREEN_DIALOG")
    self.name=U:Text(f,"Choose an outline to edit.",20,-60,13,450)
    f.closeButton:ClearAllPoints();f.closeButton:SetPoint("TOPRIGHT",-14,-12)
    f.heading:SetWidth(270)
    self.navStart=U:Button(f,"Controller",310,-12,130,function()
        if not self:FlushEdits() then return end
        for _,control in pairs(self.controls) do control.edit:ClearFocus() end
        M.DialogNavigation:Start(f,true)
    end)
    U:Text(f,"Preview only. Apply saves; combat discards. F6 keyboard.\nController: D-pad moves; left/right adjusts a focused number.",20,-92,11,450)
    self.filterButton=U:Button(f,"Main displays",330,-145,140,function(b)
        if not self:FlushEdits() then return end
        U:Choose(b,{{value="main",label="Main displays"},{value="groups",label="Party & raid"},
            {value="other",label="Other displays"},{value="all",label="All displays"}},self.filter or "main",function(v) self:SetFilter(v) end)
    end)
    self.selector=U:Button(f,"Select an element",20,-145,300,function(b)
        if not self:FlushEdits() then return end
        local v={};for _,id in ipairs(self.ids) do if self:InFilter(id) then v[#v+1]={value=id,label=label(id)} end end
        U:Choose(b,v,self.selected,function(id) self:Select(id) end)
    end)
    self.controls={}
    local specs={{"x","Horizontal offset",-.48,.48,.005},{"y","Vertical offset",-.48,.48,.005},{"width","Width",24,1200,1},{"height","Height",16,800,1},{"scale","Scale",.6,1.6,.05}}
    for i,spec in ipairs(specs) do
        local key=spec[1]
        self.controls[key]=U:Slider(f,spec[2],20,-185-(i-1)*58,450,key=="width" and 220 or key=="height" and 50 or key=="scale" and 1 or 0,spec[3],spec[4],spec[5],function(v)
            if self.refreshing or not self:CanEdit() or not self.selected then return end
            local l=self:Layout(self.selected);l[key]=v
            if not self.flushing then M.Layout:Clamp(l);self:PlaceGhost(self.selected) end
        end)
        self.controls[key].edit:SetScript("OnEnterPressed",function(box)
            if self:FlushEdits() then box:ClearFocus() end
        end)
    end
    self.anchor=U:Button(f,"Anchor / match",20,-487,140,function(b)
        if not self:FlushEdits() then return end
        local v={{value="SCREEN",label="Anchor to the screen"}}
        for _,id in ipairs(self.ids or {}) do if id~=self.selected then v[#v+1]={value=id,label=id} end end
        U:Choose(b,v,nil,function(id) self:AnchorTo(id) end)
    end)
    self.matchWidth=U:Button(f,"Match width",170,-487,140,function() self:Match("width") end)
    self.matchHeight=U:Button(f,"Match height",320,-487,150,function() self:Match("height") end)
    self.apply=U:Button(f,"Apply",20,-545,102,function() self:Apply() end)
    self.cancel=U:Button(f,"Cancel",132,-545,102,function() self:Close() end)
    self.undo=U:Button(f,"Undo",244,-545,102,function() self:Undo() end)
    self.reset=U:Button(f,"Reset layout",356,-545,114,function() self:Reset() end)
    f.closeButton:SetScript("OnClick",function() self:Close() end)
    f:SetScript("OnHide",function() if self.active then self:Close() end end)
    f:SetScript("OnUpdate",function() self:UpdateDrag() end)
    -- Original alignment grid: finite preallocated lines, no fullscreen input catcher.
    self.grid=CreateFrame("Frame",nil,UIParent);self.grid:SetAllPoints();self.grid:SetFrameStrata("DIALOG");M.Safety:Passive(self.grid)
    self.gridLines={}
    for i=1,40 do
        local t=self.grid:CreateTexture(nil,"BACKGROUND");t:SetColorTexture(.40,.70,.72,.065);self.gridLines[i]=t
    end
    self.grid:Hide()
    M.DialogNavigation:Attach(f,{closeOnSuspend=true,allowed=function() return self:CanEdit() end,close=function() self:Close() end,entries=function()
        local rows={{frame=self.navStart,key="navigation",kind="button"},{frame=self.selector,key="selector",kind="button",identity=self.draft},
            {frame=self.filterButton,key="filter",kind="button",identity=self.draft}}
        local selectedLayout=self.draft and self.selected and self.draft.layouts[self.selected]
        for _,key in ipairs(controlOrder) do
            rows[#rows+1]={frame=self.controls[key].edit,key="number:"..key,kind="edit",identity=selectedLayout,
                commit=function() return self:FlushEdits() end,adjust=function(delta) return self:Adjust(key,delta) end}
        end
        for _,key in ipairs({"anchor","matchWidth","matchHeight","apply","cancel","undo","reset"}) do
            rows[#rows+1]={frame=self[key],key=key,kind="button",identity=self.draft}
        end
        rows[#rows+1]={frame=f.closeButton,key="close",kind="button"};return rows
    end})
    f:RegisterEvent("UI_SCALE_CHANGED");f:RegisterEvent("DISPLAY_SIZE_CHANGED")
    f:SetScript("OnEvent",function() if self.active and not M.Safety:InCombat() and not self:FitPanel() then self:Close() end end)
end
function E:AnchorTo(target)
    if not self:CanEdit() or not self.selected then return false end
    local found=target=="SCREEN";for _,candidate in ipairs(self.ids or {}) do if candidate==target then found=true;break end end
    if not found or not self:FlushEdits() then return false end
    local l=self:Layout(self.selected)
    local x,y=self:WorldPosition(self.selected)
    if target=="SCREEN" then self:Record();l.anchorTo=nil;l.x=x;l.y=y
    else
        local seen={[self.selected]=true};local a=target
        while a do if seen[a] then self.name:SetText("That anchor would create a loop.");return end;seen[a]=true;local al=self:Layout(a);a=al and al.anchorTo end
        self:Record();local tx,ty=self:WorldPosition(target);l.anchorTo=target;l.x=x-tx;l.y=y-ty;self.reference=target
    end
    self:Refresh()
end
function E:Match(dimension)
    if not self:CanEdit() or (dimension~="width" and dimension~="height") or not self:FlushEdits() then return false end
    if not self.selected or not self.reference or not M.surfaces[self.reference] then self.name:SetText("Choose another element using Anchor / match first.");return end
    self:Record();local l,ref=self:Layout(self.selected),self:Layout(self.reference)
    l[dimension]=ref[dimension]*(ref.scale or 1)/(l.scale or 1);self:Refresh()
end
function E:RefreshControls()
    if self.filterButton then self.filterButton:SetText(filterLabels[self.filter or "main"]) end
    if not self.selected then
        self.name:SetText("No enabled displays in this group. Choose another group.")
        self.selector:SetText("Choose a display group");return
    end
    local l=self:Layout(self.selected);self.name:SetText(label(self.selected))
    self.refreshing=true;for key,control in pairs(self.controls) do control.setValue(l[key] or 0) end;self.refreshing=false
    self.selector:SetText(label(self.selected));self.anchor:SetText(l.anchorTo and "Anchor: "..label(l.anchorTo) or "Anchor / match")
    M.DialogNavigation:Refresh(self.frame)
end
function E:Refresh()
    for id,g in pairs(self.ghosts) do if self.active and M.surfaces[id] and M.surfaces[id].editable and M:ModuleConfig(M.surfaces[id].module).enabled and self:InFilter(id) then self:PlaceGhost(id);g:Show() else g:Hide() end end
    self:RefreshControls()
end
function E:Open()
    if M.Safety:InCombat() or M.state.safe or M.state.cinematic then M:Print("Unlock Mode is unavailable while presentation is suspended.");return false end
    if M.Profiles.readOnly then M:Print("Unknown saved-data schema: editing is unavailable.");return end
    self:Create()
    if not self:FitPanel() then self:Close();return false end
    if self.active then U:CloseChoices();M.DialogNavigation:Shown(self.frame);self.frame:Show();return true end
    self.active=true;M.state.edit=true;self.history={};self.reference=nil;self.draft=M:Copy(M.profile);self.ids={}
    for id,s in pairs(M.surfaces) do
        local cfg=M:ModuleConfig(s.module)
        if s.editable and cfg and cfg.enabled and not (M.NativeWindowPolicy and M.NativeWindowPolicy:ModuleNative(s.module)) then self.ids[#self.ids+1]=id;self:CreateGhost(id,s) end
    end
    table.sort(self.ids)
    self.filter="main";self.selected=nil
    for _,id in ipairs(self.ids) do if self:InFilter(id) then self.selected=self.selected or id end end
    if M.surfaces["UnitFrames.player"] and self.ghosts["UnitFrames.player"] then self.selected="UnitFrames.player" end
    if not self.selected then self.filter="all";self.selected=self.ids[1] end
    if M.Options.frame then M.Options.frame:Hide() end
    self.frame:Show();self.grid:Show()
    local w,h=UIParent:GetWidth(),UIParent:GetHeight()
    for i,t in ipairs(self.gridLines) do
        t:ClearAllPoints()
        if i<=20 then t:SetSize(1,h);t:SetPoint("LEFT",self.grid,"LEFT",w*i/21,0)
        else t:SetSize(w,1);t:SetPoint("BOTTOM",self.grid,"BOTTOM",0,h*(i-20)/21) end
    end
    self:Refresh()
    if not self.selected then self.name:SetText("Enable a custom visual module to create editable outlines.") end
end
function E:Apply()
    if not self:CanEdit() or not self:FlushEdits() then return false end
    local p=M:Copy(M.profile);p.layouts=M:Copy(self.draft.layouts)
    if p.managed then p.autoLayout=false end
    local ok,why=M.Profiles:Commit(p)
    if ok then self:Close();M.Options:Open() else self.name:SetText(why) end
    return ok,why
end
function E:Close()
    self.active=false;M.state.edit=false;self.drag=nil;self.draft=nil;self.reference=nil
    for _,control in pairs(self.controls or {}) do control.edit:ClearFocus() end
    for _,g in pairs(self.ghosts) do g:Hide() end
    if self.grid then self.grid:Hide() end
    if self.frame then self.frame:Hide() end
    U:CloseChoices()
end
