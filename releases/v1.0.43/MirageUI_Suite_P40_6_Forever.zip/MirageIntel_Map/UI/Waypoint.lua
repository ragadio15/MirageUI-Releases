local _,M=...
-- The map card edits one Wayfinder focus. Coordinates are always percentages
-- on the browsed map, never on a stale player map or an old canvas selection.
M.Waypoint={status="NOT_CREATED"}
local W=M.Waypoint
local white="Interface\\Buttons\\WHITE8x8"
local messages={INVALID_COORDINATE="Enter X and Y between 0 and 100.",
    WAYPOINT_SELECTION_CHANGED="The destination changed. Review it and try again.",
    MAP_CONTEXT_CHANGED="The map changed. Enter coordinates on this map.",
    NAVIGATION_NOT_READY="Wayfinder is not ready yet.",
    MIRAGENAVIGATE_NOT_INSTALLED="Enable Wayfinder to use coordinates.",
    WAYPOINT_PRIORITIZED="Waypoint set · selected for navigation.",
    WAYPOINT_SAVED_PAUSED="Waypoint saved · resume Wayfinder to navigate.",
    WAYPOINT_SAVED_OFF="Waypoint saved · enable Wayfinder to navigate.",
    WAYPOINT_SAVED_DEAD="Waypoint saved · navigation resumes after resurrection.",
    WAYPOINT_SAVED_SUSPENDED="Waypoint saved · navigation resumes when available.",
    WAYPOINT_CLEARED="Waypoint cleared.",
    NO_COORDINATE_WAYPOINT="No coordinate waypoint is selected."}
function W:Parse(value)
    if not M:Readable(value) or type(value)~="string" or #value>16 then return nil end
    value=value:match("^%s*(.-)%s*$"):gsub("%%$","")
    -- A comma decimal is accepted for localized input; exponent/hex notation,
    -- separators, control codes and non-finite values are not coordinates.
    value=value:gsub(",",".")
    if not value:match("^%d*%.?%d+$") then return nil end
    local number=tonumber(value)
    if not M:Number(number) or number<0 or number>100 then return nil end
    return number
end
function W:Provider()
    local api=M.Integration:Navigate()
    return api and api.coordinateWaypointVersion==1 and type(api.GetCoordinateWaypoint)=="function" and
        type(api.SetCoordinateWaypoint)=="function" and type(api.ClearCoordinateWaypoint)=="function" and api or nil
end
local selectionFields={"present","pinRevision","epoch"}
local presentationFields={"mode","suspended","readOnly","lastResult"}
local function sameSelection(a,b)
    if not a or not b then return a==b end
    for _,key in ipairs(selectionFields) do if a[key]~=b[key] then return false end end
    local x,y=a.pin,b.pin
    if not x or not y then return x==y end
    return x.mapID==y.mapID and x.x==y.x and x.y==y.y
end
function W:ReadState()
    local api=self:Provider();local snapshot,read=M:Call(api and api.GetCoordinateWaypoint)
    return api,read and type(snapshot)=="table" and snapshot or nil
end
function W:MessageExpired()
    if not self.message then return false end
    local now=M:Now()
    return self.messageUntil and now>=self.messageUntil or self.messageAt and now<self.messageAt
end
function W:NeedsUpdate(mapID)
    local scope=self.scope;local frame=M.MapQuery:Frame();local scroll=frame and frame.ScrollContainer
    if not self.frame or not scope or scope.mapID~=mapID or scope.frame~=frame or scope.scroll~=scroll or
        not scroll or scope.canvas~=scroll.Child or scope.account~=M.Storage.account or scope.character~=M.Storage.character or
        self.uiDirty or self:MessageExpired() then return true end
    local api,snapshot=self:ReadState()
    local old=self.shownWaypoint
    if api~=self.shownProvider or not sameSelection(snapshot,old) then return true end
    if snapshot and old then
        for _,key in ipairs(presentationFields) do if snapshot[key]~=old[key] then return true end end
    end
    return false
end
function W:ContextCurrent(scope)
    if not scope or not M.state.clientAllowed or M.Storage.readOnly or M:Combat() or not M.MapQuery:Shown() then return false end
    local frame=M.MapQuery:Frame();local mapID=M.MapQuery:CurrentMap()
    return self.scope==scope and frame==scope.frame and frame and frame.ScrollContainer==scope.scroll and
        scope.scroll.Child==scope.canvas and mapID==scope.mapID and
        M.Storage.account==scope.account and M.Storage.character==scope.character
end
function W:Message(code,error)
    self.status=code;self.message=messages[code] or M:UserMessage(code);self.messageError=error==true
    self.messageAt=M:Now();self.messageUntil=self.messageAt+6;self.uiDirty=true
    if self.feedback then
        self.feedback:SetText(self.message)
        local c=error and M.colors.accent or M.colors.muted;self.feedback:SetTextColor(c[1],c[2],c[3])
    end
end
function W:Submit()
    local scope=self.scope
    if not self:ContextCurrent(scope) then self:Message("MAP_CONTEXT_CHANGED",true);return false,"MAP_CONTEXT_CHANGED" end
    local x,y=self:Parse(self.x:GetText()),self:Parse(self.y:GetText())
    if not x or not y then self:Message("INVALID_COORDINATE",true);return false,"INVALID_COORDINATE" end
    local api=self:Provider()
    if not api then self:Message("MIRAGENAVIGATE_NOT_INSTALLED",true);return false,"MIRAGENAVIGATE_NOT_INSTALLED" end
    local snapshot,read=M:Call(api.GetCoordinateWaypoint)
    local zone=M.MapQuery:Name(scope.mapID) or "Waypoint"
    if not read or type(snapshot)~="table" then self:Message("NAVIGATION_NOT_READY",true);return false,"NAVIGATION_NOT_READY" end
    if not self:ContextCurrent(scope) or self:Provider()~=api then self:Message("MAP_CONTEXT_CHANGED",true);return false,"MAP_CONTEXT_CHANGED" end
    local ok,called,why=M:Call(api.SetCoordinateWaypoint,scope.mapID,x,y,{userInitiated=true,
        expectedRevision=snapshot.pinRevision,expectedEpoch=snapshot.epoch,
        label=string.format("%s · %.2f, %.2f",zone,x,y)})
    local accepted=called and ok==true
    self:Message(why or "NAVIGATION_NOT_READY",not accepted)
    if accepted then self.dirty=false;self.x:ClearFocus();self.y:ClearFocus() end
    return accepted,why
end
function W:Clear()
    local scope=self.scope;local shown=self.shownWaypoint;local api=self:Provider()
    if not self:ContextCurrent(scope) or api~=self.shownProvider or api~=self:Provider() then self:Message("MAP_CONTEXT_CHANGED",true);return false end
    if not shown or not shown.present or not shown.pin then self:Message("NO_COORDINATE_WAYPOINT",true);return false end
    local pin=shown.pin
    local ok,called,why=M:Call(api.ClearCoordinateWaypoint,{userInitiated=true,pinRevision=shown.pinRevision,epoch=shown.epoch,
        mapID=pin.mapID,x=pin.x,y=pin.y})
    local accepted=called and ok==true
    self:Message(why or "NAVIGATION_NOT_READY",not accepted)
    if accepted then self.dirty=false;self.writing=true;self.x:SetText("");self.y:SetText("");self.writing=nil end
    return accepted,why
end
local function label(parent,text,color)
    local region=parent:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    region:SetText(text);region:SetJustifyH("LEFT");region:SetJustifyV("TOP");region:SetWordWrap(true)
    region:SetTextColor(color[1],color[2],color[3])
    local chrome=M.core and M.core.Chrome
    if chrome and chrome.Font then chrome.Font(region,"small") end
    return region
end
function W:Create(card)
    if self.frame then return end
    self.frame=CreateFrame("Frame",nil,card);local f=self.frame;f:SetWidth(336);f:SetHeight(100)
    local divider=f:CreateTexture(nil,"ARTWORK");divider:SetTexture(white);divider:SetVertexColor(.26,.26,.26,.65)
    divider:SetPoint("TOPLEFT",f,"TOPLEFT",12,0);divider:SetPoint("TOPRIGHT",f,"TOPRIGHT",-12,0);divider:SetHeight(1)
    self.title=label(f,"Wayfinder",M.colors.secondary);self.title:SetPoint("TOPLEFT",f,"TOPLEFT",12,-10)
    self.xLabel=label(f,"X",M.colors.text);self.yLabel=label(f,"Y",M.colors.text)
    local function input()
        local edit=CreateFrame("EditBox",nil,f,"BackdropTemplate")
        edit:SetHeight(27);edit:SetAutoFocus(false);edit:SetMaxLetters(16);edit:SetFontObject("GameFontHighlightSmall")
        edit:SetBackdrop({bgFile=white,edgeFile=white,edgeSize=1});edit:SetBackdropColor(.035,.035,.038,.98)
        edit:SetBackdropBorderColor(.26,.26,.26,1)
        if edit.SetTextInsets then edit:SetTextInsets(7,7,0,0) end
        if edit.SetJustifyH then edit:SetJustifyH("CENTER") end
        local chrome=M.core and M.core.Chrome;if chrome and chrome.Font then chrome.Font(edit,"small") end
        edit:SetScript("OnTextChanged",function()
            if not W.writing then
                W.dirty=true;W.uiDirty=true;W.message=nil;W.messageError=nil;W.messageUntil=nil;W.messageAt=nil
            end
        end)
        edit:SetScript("OnEscapePressed",function(self)self:ClearFocus()end)
        edit:SetScript("OnEnterPressed",function()W:Submit()end)
        return edit
    end
    self.x,self.y=input(),input()
    self.x:SetScript("OnTabPressed",function(self)self:ClearFocus();W.y:SetFocus();W.y:HighlightText()end)
    self.y:SetScript("OnTabPressed",function(self)self:ClearFocus();W.x:SetFocus();W.x:HighlightText()end)
    local function button(text,width,handler)
        local chrome=M.core and M.core.Chrome
        if chrome and chrome.Button then return chrome.Button(f,text,0,0,width,27,handler) end
        local b=CreateFrame("Button",nil,f,"BackdropTemplate");b:SetSize(width,27)
        b:SetBackdrop({bgFile=white,edgeFile=white,edgeSize=1});b:SetBackdropColor(.06,.06,.065,.97);b:SetBackdropBorderColor(.26,.26,.26,1)
        local t=label(b,text,M.colors.text);t:SetAllPoints(b);t:SetJustifyH("CENTER");t:SetJustifyV("MIDDLE");b:SetFontString(t)
        b:SetScript("OnClick",handler);return b
    end
    self.go=button("Navigate",88,function()W:Submit()end)
    self.clear=button("Clear",60,function()W:Clear()end);self.clear:SetHeight(23)
    self.feedback=label(f,"Coordinates · 0–100",M.colors.muted)
    f:SetScript("OnHide",function()
        W.x:ClearFocus();W.y:ClearFocus();W.scope=nil;W.message=nil;W.messageUntil=nil;W.messageAt=nil;W.status="HIDDEN"
    end)
end
function W:Update(mapID,y,canvas)
    if not self.frame then self:Create(canvas.legendBack) end
    local frame=M.MapQuery:Frame();local scroll=frame and frame.ScrollContainer
    if not scroll then self.frame:Hide();return 0 end
    local old=self.scope
    local changed=not old or old.mapID~=mapID or old.frame~=frame or old.scroll~=scroll or old.canvas~=scroll.Child or
        old.account~=M.Storage.account or old.character~=M.Storage.character
    local api,snapshot=self:ReadState()
    local selectionChanged=api~=self.shownProvider or not sameSelection(snapshot,self.shownWaypoint)
    if changed then
        self.scope={mapID=mapID,frame=frame,scroll=scroll,canvas=scroll.Child,account=M.Storage.account,character=M.Storage.character}
        self.dirty=false;self.message=nil;self.messageError=nil;self.messageUntil=nil;self.messageAt=nil
        self.x:ClearFocus();self.y:ClearFocus()
    end
    -- External selections and arrival can change the saved focus without a map
    -- change. Follow those only while clean; an unsubmitted draft belongs to the
    -- player and survives until confirmation or a change of map/profile.
    if changed or selectionChanged and not self.dirty then
        self.writing=true
        local pin=snapshot and snapshot.pin
        self.x:SetText(pin and pin.mapID==mapID and string.format("%.2f",pin.x*100) or "")
        self.y:SetText(pin and pin.mapID==mapID and string.format("%.2f",pin.y*100) or "");self.writing=nil
    end
    self.shownWaypoint,self.shownProvider=snapshot,api
    self.go:SetEnabled(api~=nil and snapshot~=nil and snapshot.readOnly~=true)
    self.clear:SetEnabled(snapshot~=nil and snapshot.present==true and snapshot.readOnly~=true)
    if self:MessageExpired() or snapshot and snapshot.lastResult=="REACHED" and not self.messageError then
        self.message=nil;self.messageError=nil;self.messageUntil=nil;self.messageAt=nil
    end
    local message=self.message
    if not message then
        if not api then message=messages.MIRAGENAVIGATE_NOT_INSTALLED
        elseif not snapshot then message=messages.NAVIGATION_NOT_READY
        elseif snapshot and snapshot.present and snapshot.pin then
            local p=snapshot.pin
            message=snapshot.mode=="Pause" and messages.WAYPOINT_SAVED_PAUSED or snapshot.mode=="Off" and messages.WAYPOINT_SAVED_OFF or
                snapshot.suspended=="PLAYER_DEAD" and messages.WAYPOINT_SAVED_DEAD or
                string.format("Waypoint · %.2f, %.2f",p.x*100,p.y*100)
            if p.mapID~=mapID then message=message.." · "..(M.MapQuery:Name(p.mapID) or "another map") end
        elseif snapshot and snapshot.lastResult=="REACHED" then message="Waypoint reached."
        else message="Coordinates on this map · 0–100" end
    end
    self.feedback:SetText(message)
    local color=self.messageError and M.colors.accent or M.colors.muted;self.feedback:SetTextColor(color[1],color[2],color[3])
    local width=canvas.legendBack:GetWidth();local field=math.max(48,(width-170)/2)
    local f=self.frame;f:ClearAllPoints();f:SetPoint("TOPLEFT",canvas.legendBack,"TOPLEFT",0,-y);f:SetWidth(width)
    self.clear:ClearAllPoints();self.clear:SetPoint("TOPRIGHT",f,"TOPRIGHT",-14,-5)
    self.xLabel:ClearAllPoints();self.xLabel:SetPoint("TOPLEFT",f,"TOPLEFT",12,-42)
    self.x:ClearAllPoints();self.x:SetPoint("TOPLEFT",f,"TOPLEFT",30,-34);self.x:SetWidth(field)
    self.yLabel:ClearAllPoints();self.yLabel:SetPoint("TOPLEFT",f,"TOPLEFT",40+field,-42)
    self.y:ClearAllPoints();self.y:SetPoint("TOPLEFT",f,"TOPLEFT",58+field,-34);self.y:SetWidth(field)
    self.go:ClearAllPoints();self.go:SetPoint("TOPRIGHT",f,"TOPRIGHT",-14,-34)
    self.feedback:ClearAllPoints();self.feedback:SetPoint("TOPLEFT",f,"TOPLEFT",12,-70);self.feedback:SetWidth(width-26)
    local height,ok=M:Call(self.feedback.GetStringHeight,self.feedback)
    local total=70+(ok and M:Number(height) and math.max(14,height) or 28)+12
    f:SetHeight(total);f:Show();self.status=self.message and self.status or "READY";self.uiDirty=nil
    return total
end
