-- Recommended player levels, not an admission test or a travel-safety promise.
local _,M=...
M.ZoneGuide={}
local Z=M.ZoneGuide
-- Eight pilot fallbacks selected from ForeverPlusPlus Data/ZoneInfo.lua (MIT),
-- copyright (c) 2026 Cameron Weaver. These are Classic reference values, not
-- Forever server requirements. See ThirdParty/FPP-LICENSE.txt.
local pilotReference={
    [1411]={1,10},[1412]={1,10},[1420]={1,10},[1424]={20,30},
    [1426]={1,10},[1429]={1,10},[1434]={30,45},[1438]={1,10},
}
local revision="0ae2c5006b28a640c3a3c17914d3d4543717ce5d"
local function resourceBuild()
    local patch,ok,build,_,interface=M:Call(GetBuildInfo)
    return ok and patch=="1.60.1" and (tostring(build)=="70959" or tostring(build)=="71037") and interface==16001
end
local function itemName(itemID)
    local name,read=M:Call(type(C_Item)=="table" and C_Item.GetItemNameByID,itemID)
    local localized=read and M:Text(name,100)
    return localized and name or (M.ZoneReferenceItemNames and M.ZoneReferenceItemNames[itemID]) or ("Item #"..itemID),
        localized and "NATIVE_CACHED_NAME" or "REFERENCE_FALLBACK"
end
local function resourceBase()
    local reference=M.ResourceReference
    if type(reference)~="table" then return nil end
    return {source=reference.source,sourceVersion=reference.sourceVersion,sourceURL=reference.sourceURL,
        qualification=reference.qualification,license=reference.license,locations="NOT_PROVIDED",
        dropRates="NOT_PROVIDED",currentEligibility="NOT_ESTABLISHED",nativeVerification="NOT_RUN"}
end
local function resource(itemID)
    if not M:Integer(itemID) or itemID>2147483647 then return nil,"ITEM_ID_UNAVAILABLE" end
    local catalog=M.ResourceReference
    local row=type(catalog)=="table" and type(catalog.items)=="table" and catalog.items[itemID]
    if type(row)~="table" then return nil,"RESOURCE_REFERENCE_UNAVAILABLE" end
    if not M:Integer(row.skillLineID) or not M:Integer(row.minSkill) or not M:Integer(row.maxSkill) or
        row.minSkill>row.maxSkill or row.maxSkill>350 or
        (row.category~="herb" and row.category~="ore" and row.category~="stone") or
        type(row.variants)~="table" or #row.variants>16 then return nil,"RESOURCE_REFERENCE_INVALID" end
    local info=resourceBase()
    info.itemID=itemID;info.name,info.nameSource=itemName(itemID)
    info.category=row.category;info.skillLineID=row.skillLineID;info.minSkill=row.minSkill;info.maxSkill=row.maxSkill
    info.skillMeaning=row.category=="stone" and "LOWEST_YIELDING_VEIN_REFERENCE" or "GATHERING_NODE_REQUIREMENT_REFERENCE"
    info.nodeVariants={}
    for _,variant in ipairs(row.variants)do
        if type(variant)~="table" or not M:Text(variant.name,100) or not M:Integer(variant.skill) or
            variant.skill<row.minSkill or variant.skill>row.maxSkill or
            (variant.sharedBaseName~=nil and not M:Text(variant.sharedBaseName,100)) then
            return nil,"RESOURCE_REFERENCE_INVALID"
        end
        info.nodeVariants[#info.nodeVariants+1]={name=variant.name,nameSource="REFERENCE_ENGLISH",skill=variant.skill,
            sharedBaseName=variant.sharedBaseName}
    end
    return info,"REFERENCE_ONLY"
end
local function range(lo,hi)
    return M:Integer(lo) and M:Integer(hi) and lo<=hi and hi<=1000
end
local function relevance(info)
    local level,read=M:Call(UnitLevel,"player")
    info.skillEligibility="NOT_ASSESSED"
    info.skillNote="Player-level guidance does not establish gathering or fishing skill requirements."
    if not read or not M:Integer(level) or level>1000 then
        info.levelRelevance="PLAYER_LEVEL_UNAVAILABLE";info.relevanceLabel="Your level unavailable"
        return info
    end
    info.playerLevel=level
    if level<info.recommendedMin then
        info.levelRelevance="BELOW_RECOMMENDED";info.levelDelta=level-info.recommendedMin
        info.relevanceLabel=string.format("you %d · below range",level)
    elseif level>info.recommendedMax then
        info.levelRelevance="ABOVE_RECOMMENDED";info.levelDelta=level-info.recommendedMax
        info.relevanceLabel=string.format("you %d · above range",level)
    else
        info.levelRelevance="WITHIN_RECOMMENDED";info.levelDelta=0
        info.relevanceLabel=string.format("you %d · within range",level)
    end
    return info
end
function Z:Get(mapID)
    if not M:Integer(mapID) then return nil,"MAP_ID_UNAVAILABLE" end
    local patch,ok,build,_,interface=M:Call(GetBuildInfo)
    local lo,read,hi=M:Call(type(C_Map)=="table" and C_Map.GetMapLevels,mapID)
    local base={mapID=mapID,name=M.MapQuery and M.MapQuery:Name(mapID),entryRequirement="NOT_PROVIDED",
        build=ok and tostring(build) or "unknown",note="Recommended player levels; not an entry requirement."}
    if read and range(lo,hi) then
        base.recommendedMin=lo;base.recommendedMax=hi;base.source="Native C_Map.GetMapLevels"
        base.sourceVersion=(ok and M:Text(patch,80) or "Unknown client").." / "..base.build;base.confidence="NATIVE_REPORTED"
        return relevance(base),"NATIVE_LEVEL_RANGE"
    end
    -- Historical tables remain separately qualified; a readable native level
    -- API does not establish that another client's static zone IDs agree.
    if not resourceBuild() then return nil,"ZONE_GUIDE_BUILD_UNQUALIFIED" end
    local full=M.ZoneReference and M.ZoneReference[mapID]
    local fallback=full and full.minLevel and {full.minLevel,full.maxLevel} or pilotReference[mapID]
    if not fallback then return nil,"ZONE_LEVELS_UNAVAILABLE" end
    base.recommendedMin=fallback[1];base.recommendedMax=fallback[2]
    base.source="Classic reference via ForeverPlusPlus";base.sourceVersion=revision
    base.confidence=full and full.qualification or "CLASSIC_REFERENCE_UNVERIFIED_FOREVER"
    base.source=base.confidence=="FOREVER_ZONE_REFERENCE_UNVERIFIED" and "ForeverPlusPlus zone reference" or base.source
    base.note="Reference guidance; current Forever levels are unverified. Not an entry requirement."
    return relevance(base),"CLASSIC_REFERENCE"
end
function Z:Summary(mapID)
    local info,why=self:Get(mapID)
    if not info then return "Explore this zone",why end
    local label=string.format("Suggested levels %d–%d",info.recommendedMin,info.recommendedMax)
    if info.playerLevel then label=label.." · "..info.relevanceLabel end
    return label,info.confidence
end
-- Regional reference lists are deliberately separate from WorldRecords. A zone
-- material list cannot establish a node position, current spawn or drop chance.
function Z:GetResources(mapID)
    if not M:Integer(mapID) then return nil,"MAP_ID_UNAVAILABLE" end
    local patch,ok,build,_,interface=M:Call(GetBuildInfo)
    if not ok or patch~="1.60.1" or (tostring(build)~="70959" and tostring(build)~="71037") or interface~=16001 then
        return nil,"ZONE_GUIDE_BUILD_UNQUALIFIED"
    end
    local row=M.ZoneReference and M.ZoneReference[mapID]
    if not row then return nil,"REGIONAL_REFERENCE_UNAVAILABLE" end
    local result={mapID=mapID,source="ForeverPlusPlus regional reference",sourceVersion=revision,
        qualification=row.qualification,license="MIT",locations="NOT_PROVIDED",dropRates="NOT_PROVIDED",
        currentEligibility="NOT_ESTABLISHED",herbs={},ores={},nativeVerification="NOT_RUN"}
    if M:Integer(row.fishingSkill) then result.fishingSkill=row.fishingSkill end
    if M:Integer(row.coastalFishingSkill) then result.coastalFishingSkill=row.coastalFishingSkill end
    for _,kind in ipairs({"herbs","ores"}) do
        for index,id in ipairs(row[kind] or {}) do
            if index>32 then break end
            if M:Integer(id) and id<=2147483647 then
                local detail=resource(id)
                if not detail then
                    local name,nameSource=itemName(id)
                    detail={itemID=id,name=name,nameSource=nameSource}
                end
                result[kind][#result[kind]+1]=detail
            end
        end
    end
    return result,"REFERENCE_ONLY"
end
-- These APIs describe regional possibilities and reference requirements. They
-- intentionally never create WorldRecords, destinations, skills or discoveries.
function Z:GetResource(itemID)
    if not resourceBuild() then return nil,"ZONE_GUIDE_BUILD_UNQUALIFIED" end
    return resource(itemID)
end
function Z:GetResourceCatalog()
    if not resourceBuild() then return nil,"ZONE_GUIDE_BUILD_UNQUALIFIED" end
    local catalog=M.ResourceReference
    if type(catalog)~="table" or type(catalog.items)~="table" then return nil,"RESOURCE_REFERENCE_UNAVAILABLE" end
    local info=resourceBase();info.items={};info.fishingPools={};info.professionTools={}
    local ids={}
    for id in pairs(catalog.items)do
        if #ids>=128 then return nil,"RESOURCE_REFERENCE_LIMIT" end
        if not M:Integer(id) or id>2147483647 then return nil,"RESOURCE_REFERENCE_INVALID" end
        ids[#ids+1]=id
    end
    table.sort(ids)
    for _,id in ipairs(ids)do
        local row,why=resource(id)
        if not row then return nil,why end
        info.items[#info.items+1]=row
    end
    for index,name in ipairs(catalog.fishingPools or {})do
        if index>32 then return nil,"RESOURCE_REFERENCE_LIMIT" end
        if not M:Text(name,100) then return nil,"RESOURCE_REFERENCE_INVALID" end
        info.fishingPools[#info.fishingPools+1]=name
    end
    info.fishingPoolNames="REFERENCE_ENGLISH";info.fishingPoolRegions="NOT_PROVIDED"
    local tools={}
    for id,line in pairs(catalog.professionTools or {})do
        if #tools>=16 then return nil,"RESOURCE_REFERENCE_LIMIT" end
        if not M:Integer(id) or id>2147483647 or not M:Integer(line) then return nil,"RESOURCE_REFERENCE_INVALID" end
        tools[#tools+1]=id
    end
    table.sort(tools)
    for _,id in ipairs(tools)do
        local name,nameSource=itemName(id)
        info.professionTools[#info.professionTools+1]={itemID=id,name=name,nameSource=nameSource,
            skillLineID=catalog.professionTools[id],qualification=info.qualification,owned="NOT_ASSESSED"}
    end
    info.count=#info.items
    return info,"REFERENCE_ONLY"
end
function Z:FindResourceRegions(itemID)
    if not resourceBuild() then return nil,"ZONE_GUIDE_BUILD_UNQUALIFIED" end
    local info,why=resource(itemID)
    if not info then return nil,why end
    info.regions={};info.count=0;info.omitted=0
    info.regionSource="ForeverPlusPlus regional reference"
    info.regionSourceURL="https://github.com/xIGBClutchIx/ForeverPlusPlus/blob/"..revision.."/ForeverPlusPlus/Data/ZoneInfo.lua"
    local ids={}
    for mapID in pairs(M.ZoneReference or {})do
        if #ids>=128 then return nil,"REGIONAL_REFERENCE_LIMIT" end
        if M:Integer(mapID) then ids[#ids+1]=mapID end
    end
    table.sort(ids)
    for _,mapID in ipairs(ids)do
        local row=M.ZoneReference[mapID];local found=false
        if type(row)=="table" then
            for _,kind in ipairs({"herbs","ores"})do
                for index,id in ipairs(row[kind] or {})do
                    if index>32 then break end
                    if id==itemID then found=true;break end
                end
                if found then break end
            end
            if found then
                if #info.regions>=64 then info.omitted=info.omitted+1
                else
                    local name,ok=M:Call(M.MapQuery and M.MapQuery.Name,M.MapQuery,mapID)
                    local region={mapID=mapID,name=ok and M:Text(name,100) or ("Map #"..mapID),
                        qualification=row.qualification,locations="NOT_PROVIDED",availability="UNKNOWN"}
                    if range(row.minLevel,row.maxLevel) then region.minLevel=row.minLevel;region.maxLevel=row.maxLevel end
                    info.regions[#info.regions+1]=region
                end
            end
        end
    end
    info.count=#info.regions
    return info,"REFERENCE_ONLY"
end
function Z:ResourceSummary(mapID)
    local info=self:GetResources(mapID)
    if not info then return {} end
    local rows={}
    if info.fishingSkill then
        local text="Fishing skill guide: "..info.fishingSkill
        if info.coastalFishingSkill then text=text.." inland / "..info.coastalFishingSkill.." coast" end
        rows[#rows+1]=text
    end
    local function names(list)
        local t={};for _,r in ipairs(list) do
            local name=r.name
            if r.minSkill then name=name.." ("..r.minSkill..(r.maxSkill>r.minSkill and ("–"..r.maxSkill) or "")..")" end
            t[#t+1]=name
        end
        return table.concat(t,", ")
    end
    if #info.herbs>0 then rows[#rows+1]="Herbs: "..names(info.herbs) end
    if #info.ores>0 then rows[#rows+1]="Ore: "..names(info.ores) end
    return rows
end
