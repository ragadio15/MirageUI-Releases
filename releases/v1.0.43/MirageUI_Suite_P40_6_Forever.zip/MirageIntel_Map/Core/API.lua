local _,M=...
M.API={}
local A=M.API
local function copy(t)
    if M.core and type(M.core.Copy)=="function" then return M.core.Copy(t) end
    return nil
end
function A:Create(label,kind,location,details)
    if type(location)~="table" or not M:Readable(location) then return false,"LOCATION_REQUIRED" end
    return M.Storage:Add(location.mapID,location.x,location.y,label,kind,details)
end
function A:PinHere(label,kind)
    local p,why=M.MapQuery:Player()
    if not p then return false,why end
    return self:Create(label or "My location",kind or "note",p)
end
function A:PinCursor(label,kind)
    local p,why=M.MapQuery:LastCursor()
    if not p then return false,why end
    return self:Create(label or "Map note",kind or "note",p)
end
function A:PinCoordinates(xPercent,yPercent,label,kind)
    local mapID,reason=M.MapQuery:BrowseMap()
    if not mapID then return false,reason end
    if not M:Number(xPercent) or not M:Number(yPercent) or xPercent<0 or xPercent>100 or
        yPercent<0 or yPercent>100 then return false,"COORDINATES_OUT_OF_RANGE" end
    return self:Create(label or "Map note",kind or "note",{mapID=mapID,x=xPercent/100,y=yPercent/100})
end
function A:Select(id)
    local account=M.Storage.account
    local rec=not M.Storage.readOnly and type(account)=="table" and M:Integer(id) and account.notes[id]
    if not rec then return false,"NOTE_NOT_FOUND" end
    return M.Integration:GoToNote(rec)
end
function A:RouteNavigate()
    local character=M.Storage.character
    local r=not M.Storage.readOnly and type(character)=="table" and character.route
    if not r or r.cursor==0 then return false,"NO_ACTIVE_ROUTE_STEP" end
    local note=M.Storage.account.notes[r.order[r.cursor]]
    return M.Integration:GoToNote(note)
end
function A:Install()
    local public={apiVersion=1,version=M.version,targetBuild=M.state.clientBuild or "unknown",nativeVerification="NOT_RUN"}
    function public.GetLayerPreferences()
        local account=M.Storage.account
        local settings=not M.Storage.readOnly and type(account)=="table" and account.settings
        return copy({readOnly=M.Storage.readOnly==true,clientAllowed=M.state.clientAllowed==true,
            settings=type(settings)=="table" and {showResourcePins=settings.showResourcePins,
                mapPolicy=settings.mapPolicy} or nil})
    end
    function public.GetSupportStatus()
        local canvas=M.Canvas or {}
        return copy({status=canvas.status,clientAllowed=M.state.clientAllowed==true,
            errors=M.state.errors or 0,lastError=M.state.lastError,
            mapPins=canvas.visible or 0,gatherPins=canvas.sharedVisible or 0,
            routeSegments=canvas.routeLineCount or 0,zoneCard=canvas.zoneCardStatus or "NOT_CREATED",
            nativeIconSize=canvas.nativeIconSize or 32,pinClickStatus=canvas.lastClickStatus or "NOT_CLICKED",
            pinClicks=canvas.clicks or 0,pinInput="STABLE_GLYPH_IDENTITY",
            windowLifetime=M.Panel and M.Panel.mapOwner and "WORLD_MAP_COMPANION" or "INDEPENDENT",
            coordinateWaypoint=M.Waypoint and M.Waypoint.status or "NOT_CREATED"})
    end
    function public.GetStatus()
        local account=M.Storage.account
        return copy({version=M.version,state=M.state,storage=M.Storage.reason,
            settings=not M.Storage.readOnly and type(account)=="table" and account.settings or nil,
            noteCount=M.state.noteCount,route=M.Storage:RouteSnapshot(),
            mapAvailable=M.MapQuery:Shown(),conflicts=M.Integration:Conflicts(),
            places=M.RecordQuery and M.RecordQuery:GetStatus() or nil,
            catalog=M.Catalog and M.Catalog:GetStatus() or nil,
            exploration=M.Exploration and M.Exploration:GetStatus() or nil,
            explorationRenderer=M.ExplorationUI and M.ExplorationUI:GetStatus() or nil,
            coverage=M.Coverage and M.Coverage:Get(M.MapQuery:BrowseMap()) or nil,
            interface=M.Panel and M.Panel.GetStatus and M.Panel:GetStatus() or nil,
            sharedLayers={status=M.Canvas.sharedStatus,revision=M.Canvas.sharedRevision,
                stack=M.Canvas.layerStack,
                representedRecords=M.Canvas.representedRecords or 0,clusters=M.Canvas.clusters or 0,
                diagnosticRowsCapped=(M.Canvas.representedRecords or 0)>80,
                visible=M.Canvas.sharedVisible or 0,truncated=M.Canvas.sharedTruncated==true,
                records=M.Canvas.renderedRecords or {},navigationRevision=M.Integration.navigationRevision,
                routeRevision=M.Integration.navigationSnapshot and M.Integration.navigationSnapshot.routeRevision,
                nextLegID=M.Canvas.routeNextLegID,routePrecision=M.Canvas.routePrecision,routeLineCount=M.Canvas.routeLineCount or 0}})
    end
    function public.GetNotes(filters,limit,offset)
        local data,total=M.Storage:List(filters,limit,offset)
        return copy(data),total
    end
    function public.GetRoute() return copy(M.Storage:RouteSnapshot()) end
    function public.AddNote(label,kind,location,details) return A:Create(label,kind,location,details) end
    function public.PinHere(label,kind) return A:PinHere(label,kind) end
    function public.PinCursor(label,kind) return A:PinCursor(label,kind) end
    function public.PinCoordinates(x,y,label,kind) return A:PinCoordinates(x,y,label,kind) end
    function public.SelectNote(id) return A:Select(id) end
    function public.SelectUtilityRecord(id)
        local service=M.Integration:Service("WorldRecords")
        local record
        if service and type(service.Get)=="function" then record=M:Call(service.Get,id) end
        return M.Integration:SelectRecord(record)
    end
    function public.NavigateSelectedRecord() return M.Integration:NavigateRecord(M.state.utilitySelection) end
    function public.ShowUtilityRecord(expected,options)
        local explicit,read=M:Call(function()
            return M:Readable(options) and type(options)=="table" and M:Readable(options.userInitiated) and options.userInitiated==true
        end)
        if not read or explicit~=true then return false,"EXPLICIT_ACTION_REQUIRED" end
        if not M.state.clientAllowed or M.Storage.readOnly or M:Combat() then return false,"CLIENT_OR_COMBAT_UNAVAILABLE" end
        if not M.Integration:ValidRecord(expected) then return false,"INVALID_RECORD" end
        expected=copy(expected)
        if not M.Integration:ValidRecord(expected) then return false,"INVALID_RECORD" end
        local storage,account,character,integration=M.Storage,M.Storage.account,M.Storage.character,M.Integration
        local service=M.Integration:Service("WorldRecords")
        local function ready()
            return MirageMapAPI==public and M.API==A and M.Storage==storage and storage.account==account and
                storage.character==character and M.Integration==integration and M.state.clientAllowed and
                not storage.readOnly and not M:Combat()
        end
        local function resolve()
            if not ready() then return nil,"MAP_CONTEXT_CHANGED" end
            local current=integration:Service("WorldRecords")
            if current~=service or not service or type(service.Get)~="function" or not ready() then return nil,"LOCATION_PROVIDER_CHANGED" end
            local record,called=M:Call(service.Get,expected.id)
            if not ready() then return nil,"MAP_CONTEXT_CHANGED" end
            if not called or not integration:ValidRecord(record) or record.hidden then return nil,"LOCATION_NO_LONGER_AVAILABLE" end
            if record.revision~=expected.revision or record.sourceRevision~=expected.sourceRevision or
                record.owner~=expected.owner or record.mapID~=expected.mapID or record.x~=expected.x or record.y~=expected.y then
                return nil,"LOCATION_CHANGED_REFRESH_AND_SELECT_AGAIN"
            end
            return record
        end
        local record,why=resolve();if not record then return false,why end
        local opened,why=M.MapQuery:OpenMap()
        if not opened then return false,why end
        record,why=resolve();if not record then return false,why end
        local selected,reason=M.MapQuery:GoToMap(record.mapID)
        if not selected then return false,reason end
        record,why=resolve();if not record then return false,why end
        -- Inspection chooses a map and a record; it never chooses a navigation mode.
        local inspected,status=M.Integration:SelectRecord(record,"map")
        if not ready() then return false,"MAP_CONTEXT_CHANGED" end
        return inspected,inspected and "LOCATION_SHOWN_ON_MAP" or status
    end
    function public.GetPlaces(mapID,limit,offset)
        if not M.RecordQuery or not M.state.clientAllowed then return {},{status="UNAVAILABLE"} end
        if M.Storage.readOnly then return {},{status="STORAGE_READ_ONLY"} end
        if not M:Integer(mapID) then return {},{status="INVALID_MAP"} end
        if M.Catalog and not M:Combat() then M.Catalog:Refresh(mapID) end
        local rows=M.RecordQuery:List(mapID);local output={}
        limit=M:Integer(limit) and math.min(64,limit) or 64
        offset=M:Number(offset) and math.max(0,math.floor(offset)) or 0
        for i=offset+1,math.min(#rows,offset+limit) do output[#output+1]=copy(rows[i]) end
        return output,copy(M.RecordQuery:GetStatus())
    end
    function public.SearchPlaces(search,material)
        if not M.RecordQuery then return false,"UNAVAILABLE" end
        local ok,why=M.RecordQuery:SetSearch(search,material)
        if ok and M.Panel then
            local panel=M.Panel
            panel.searches=panel.searches or {};panel.searches.Places=M.RecordQuery.search
            panel.searchError=nil;panel.offset=0;panel.clusterMembers=nil
            panel.syncingSearch=true
            if panel.page=="Places" and panel.search then panel.search:SetText(M.RecordQuery.search) end
            if panel.material then panel.material:SetText(M.RecordQuery.material) end
            panel.syncingSearch=false
            panel:Update()
        end
        return ok,why
    end
    function public.GetZoneGuide(mapID)
        return M.ZoneGuide and copy(M.ZoneGuide:Get(mapID)) or nil
    end
    function public.GetCoverage(mapID) return M.Coverage and copy(M.Coverage:Get(mapID)) or nil end
    function public.GetZoneResources(mapID) return M.ZoneGuide and copy(M.ZoneGuide:GetResources(mapID)) or nil end
    -- Reference-only lookups never produce a destination or change gathering mode.
    function public.GetResourceReference(itemID)
        return M.ZoneGuide and M.ZoneGuide.GetResource and copy(M.ZoneGuide:GetResource(itemID)) or nil
    end
    function public.FindResourceRegions(itemID)
        return M.ZoneGuide and M.ZoneGuide.FindResourceRegions and copy(M.ZoneGuide:FindResourceRegions(itemID)) or nil
    end
    function public.GetResourceCatalog()
        return M.ZoneGuide and M.ZoneGuide.GetResourceCatalog and copy(M.ZoneGuide:GetResourceCatalog()) or nil
    end
    function public.OpenResourceReference(itemID,options)
        local explicit,read=M:Call(function()
            return M:Readable(options) and type(options)=="table" and M:Readable(options.userInitiated) and options.userInitiated==true
        end)
        if not read or explicit~=true then return false,"EXPLICIT_ACTION_REQUIRED" end
        if not M:Integer(itemID) then return false,"INVALID_ITEM" end
        local storage,panel,guide=M.Storage,M.Panel,M.ZoneGuide
        local account,character=storage and storage.account,storage and storage.character
        local function ready()
            if M.API~=A or MirageMapAPI~=public then return false,"MAP_PROVIDER_CHANGED" end
            if M.Storage~=storage or M.Panel~=panel or M.ZoneGuide~=guide or not storage or
                storage.account~=account or storage.character~=character then return false,"MAP_CONTEXT_CHANGED" end
            if not M.state.initialized or not M.state.clientAllowed or storage.readOnly or type(account)~="table" or type(character)~="table" then
                return false,"CLIENT_OR_STORAGE_UNAVAILABLE"
            end
            if M:Combat() then return false,"OPEN_AFTER_COMBAT" end
            return true
        end
        local allowed,why=ready();if not allowed then return false,why end
        if not panel or type(panel.Open)~="function" or not panel.UpdateResources or not guide or type(guide.GetResource)~="function" then
            return false,"RESOURCE_GUIDE_UNAVAILABLE"
        end
        local reference,valid=M:Call(guide.GetResource,guide,itemID)
        if not valid or type(reference)~="table" or reference.itemID~=itemID then return false,"RESOURCE_REFERENCE_UNAVAILABLE" end
        allowed,why=ready();if not allowed then return false,why end
        local opened,called,reason=M:Call(panel.Open,panel)
        if not called or opened~=true then return false,reason or "RESOURCE_GUIDE_OPEN_FAILED" end
        allowed,why=ready();if not allowed then return false,why end
        panel.page="Coverage";panel.referenceMode="regions";panel.referenceItem=itemID
        panel.referenceRegion=nil;panel.offset=0
        panel:Update()
        allowed,why=ready();if not allowed then return false,why end
        if not panel.frame or not panel.frame:IsShown() or panel.page~="Coverage" or panel.referenceMode~="regions" or panel.referenceItem~=itemID then
            return false,"RESOURCE_SELECTION_CHANGED"
        end
        return true,"RESOURCE_REFERENCE_OPENED"
    end
    function public.InspectRecord(id)
        local service=M.Integration:Service("WorldRecords")
        local record=service and M:Call(service.Get,id)
        if M.Inspector then return M.Inspector:Open(record) end
        return false,"INSPECTOR_UNAVAILABLE"
    end
    function public.DeleteNote(id,confirmed) return M.Storage:Delete(id,confirmed) end
    function public.UpdateNote(id,label,kind,details) return M.Storage:Edit(id,label,kind,details) end
    function public.HideNote(id,hidden) return M.Storage:Hide(id,hidden) end
    function public.AddRouteStep(id) return M.Storage:RouteAdd(id) end
    function public.NextRouteStep() return M.Storage:RouteNext() end
    function public.SelectRouteStep(index) return M.Storage:RouteSelect(index) end
    function public.RemoveRouteStep(index) return M.Storage:RouteRemove(index) end
    function public.MoveRouteStep(from,to) return M.Storage:RouteMove(from,to) end
    function public.ResetRoute() return M.Storage:RouteReset() end
    function public.ClearRoute() return M.Storage:RouteClear() end
    function public.NavigateRouteStep() return A:RouteNavigate() end
    function public.SetPreference(key,value) return M.Storage:SetSetting(key,value) end
    function public.GetCoordinates() return copy({player=M.MapQuery:Player(),cursor=M.MapQuery:Cursor()}) end
    function public.ExportText(limit,offset) return M.Storage:Export(limit,offset) end
    function public.Open() return M.Panel:Open() end
    MirageMapAPI=public
    if M.core and type(M.core.RegisterService)=="function" then
        local ok=M.core.RegisterService("MapAddon","MirageIntel_Map",1,public)
        if not ok then M:Fault("MAP_SERVICE_REGISTRATION_FAILED") end
    end
end
