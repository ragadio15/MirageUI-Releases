-- Optional public settings entry. This file also works without MirageUI installed.
-- Register a closure; never create a window, load another addon or change saved settings here.
local addonName,A=...
local function outOfCombat()
    if type(InCombatLockdown)~="function" then return false end
    local ok,locked=pcall(InCombatLockdown)
    if not ok then return false end
    if type(issecretvalue)=="function" then
        local known,secret=pcall(issecretvalue,locked)
        if not known or secret then return false end
    end
    return locked==false or locked==nil
end
local function closeSettings()
    if not outOfCombat() then return false end
    if A.Inspector then A.Inspector.returnToPanel=false end
    for _,name in ipairs({"Inspector","Panel"}) do
        local panel=A[name]
        if type(panel)=="table" then
            for _,key in ipairs({"frame","editPanel","exportPanel","modal","confirm"}) do
                local frame=panel[key]
                if frame and type(frame.Hide)=="function" then pcall(frame.Hide,frame) end
            end
        end
    end
    return true
end
local function openSettings()
    if not outOfCombat() then return false,"Open settings after combat." end
    if not (A.state and A.state.initialized) then return false,"This addon has not finished loading." end
    local panel=A.Panel
    if type(panel)~="table" or type(panel.Open)~="function" then return false,"Settings are unavailable." end
    panel.page="Settings"
    local called,result,reason=pcall(panel.Open,panel)
    if not called then return false,"The settings window could not open." end
    if result==false then return false,reason or "Settings are unavailable." end
    local frame=panel.frame
    if not frame or type(frame.IsShown)~="function" then return false,"The settings window is unavailable." end
    local observed,shown=pcall(frame.IsShown,frame)
    if not observed or shown~=true then return false,"The settings window did not open." end
    return true
end
if _G.MirageUIAddonSettings==nil then _G.MirageUIAddonSettings={} end
if type(_G.MirageUIAddonSettings)=="table" then
    _G.MirageUIAddonSettings[addonName]={title="Maps",icon="Interface\\AddOns\\MirageIntel_Map\\Media\\Badge.tga",order=50,
        open=openSettings,close=closeSettings,combatSafe=false,version="1.11.4"}
end
