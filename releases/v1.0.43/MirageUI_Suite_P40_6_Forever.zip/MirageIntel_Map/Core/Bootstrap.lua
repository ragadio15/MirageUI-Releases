-- MirageMap. Read-only, independent world-map companion for WoW Forever.
-- Never replaces/reparents WorldMapFrame or the MirageUI minimap.
local addonName, M = ...
M.addonName=addonName
M.version="1.11.4"
M.apiVersion=1
M.target={patch="1.60.1",build="71037",interface=16001}
M.core=MirageIntelCoreAPI
M.state={initialized=false,status="STARTING",errors=0,events=0,overlay="NOT_ATTACHED",
  clientAllowed=false,nativeVerification="NOT_RUN",selection=nil}
M.maxNotes=350
M.maxPins=80
-- Local fallback copies published beta.43 options palette values; no private MirageUI reads.
M.colors={panel={.060,.060,.065,.97},edge={.26,.26,.26,1},
 accent={.91,.55,.18,1},secondary={.96,.79,.36,1},
 text={.90,.89,.87,1},muted={.63,.62,.60,1}}
function M:Readable(value)
    if value==nil then return true end
    if type(issecretvalue)=="function" then
        local ok,secret=pcall(issecretvalue,value)
        if not ok or secret then return false end
    end
    if type(canaccessvalue)=="function" then
        local ok,permitted=pcall(canaccessvalue,value)
        if not ok or not permitted then return false end
    end
    return true
end
function M:Number(value) return self:Readable(value) and type(value)=="number" and
    value==value and value>-math.huge and value<math.huge end
function M:Integer(value) return self:Number(value) and value>=1 and value%1==0 end
function M:Text(value,max)
    max=max or 96
    return self:Readable(value) and type(value)=="string" and #value>=1 and #value<=max and
        not value:find("[%c|]") and value or nil
end
function M:Call(fn,...)
    if not self:Readable(fn) or type(fn)~="function" then return nil,false end
    local ok,a,b,c,d,e=pcall(fn,...)
    if not ok or not self:Readable(a) or not self:Readable(b) or not self:Readable(c)
        or not self:Readable(d) or not self:Readable(e) then return nil,false end
    return a,true,b,c,d,e
end
function M:Combat()
    local combat,ok=self:Call(InCombatLockdown)
    -- A successful nil is the legacy WoW unlocked result, not an API failure.
    return not ok or (combat~=nil and combat~=false)
end
function M:Now()
    local v,ok=self:Call(GetTime)
    return ok and self:Number(v) and v or 0
end
function M:When()
    local v,ok=self:Call(time)
    return ok and self:Number(v) and v>0 and math.floor(v) or 0
end
function M:Fault(reason)
    self.state.errors=self.state.errors+1
    self.state.lastError=type(reason)=="string" and reason or "UNKNOWN"
end
function M:Print(message)
    if DEFAULT_CHAT_FRAME and type(DEFAULT_CHAT_FRAME.AddMessage)=="function" then
        DEFAULT_CHAT_FRAME:AddMessage("|cffe8b77dMap+ Ultra:|r "..tostring(message))
    end
end
function M:UserMessage(reason)
    local messages={LOCATION_UPDATED_SELECT_NAVIGATE_AGAIN="This place has changed. Review it and choose Navigate again.",
        LOCATION_NO_LONGER_AVAILABLE="This place is no longer available.",LOCATION_HIDDEN="This place is hidden.",
        SELECT_PLACE_FIRST="Select a place first.",SELECT_NOTE_FIRST="Select a note first.",
        MIRAGENAVIGATE_NOT_INSTALLED="Install Wayfinder to navigate.",NAVIGATE_NOT_INSTALLED="Install Wayfinder to navigate.",
        GATHER_NOT_INSTALLED="Install Gather Mate to see recorded gathering spots.",
        MAP_STORAGE_READ_ONLY="Saved map data is unavailable.",INVALID_COORDINATE="Enter coordinates between 0 and 100."}
    if messages[reason] then return messages[reason] end
    if type(reason)=="string" then
        if reason:find("COMBAT",1,true) then return "Try again after combat." end
        if not reason:match("^[A-Z][A-Z_0-9]+$") then return reason end
    end
    return "This action is unavailable right now."
end
function M:Allowed()
    local core=self.core
    if type(core)~="table" or core.apiVersion~=1 or type(core.GetCapabilities)~="function" then
        return false,"UTILITY_CORE_MISSING"
    end
    local info,ok=self:Call(core.GetCapabilities)
    local client=ok and type(info)=="table" and info.client or nil
    if type(client)~="table" or client.allowed~=true then
        return false,"UTILITY_RUNTIME_UNAVAILABLE"
    end
    if type(core.Map)~="table" or type(core.Map.Valid)~="function" or
       type(core.Map.Player)~="function" then return false,"CORE_MAP_CONTRACT_MISSING" end
    self.state.clientBuild=client.build
    return true,client.sourceMatched==false and "UNREVIEWED_CLIENT_API_GUARDED" or "SOURCE_CANDIDATE_NATIVE_NOT_RUN"
end
function M:Initialize()
    if self.state.initialized then return end
    self.state.clientAllowed,self.state.reason=self:Allowed()
    self.map=self.core and self.core.Map
    self.Storage:Initialize()
    self.state.status=not self.state.clientAllowed and "UNSUPPORTED_CLIENT" or
        self.Storage.readOnly and "STORAGE_READ_ONLY" or "READY_NATIVE_UNTESTED"
    self.state.initialized=true
    self.Commands:Install()
    self.Integration:Initialize()
    if self.Catalog then self.Catalog:Initialize() end
    if self.Exploration then self.Exploration:Initialize() end
    self.API:Install()
    if self.core and type(self.core.RegisterModule)=="function" then
        self.core.RegisterModule("MirageIntel_Map",1,{notes=true,coordinates=true,
            waypointQueue=true,zoneBrowser=true,nativeMapOverlay=true,
            gatherReuse=true,navigateReuse=true,standalone=true,independentLayers=true,
            serviceSearch=true,materialSearch=true,clusterList=true,recordInspector=true})
    end
    if not pcall(self.Canvas.Attach,self.Canvas) then self:Fault("MAP_ATTACH_FAILED");self.Canvas:HideAll() end
end
