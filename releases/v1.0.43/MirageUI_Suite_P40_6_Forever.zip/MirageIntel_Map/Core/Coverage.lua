local _,M=...
-- Coverage is descriptive. It cannot promote reference data, unlock a route,
-- turn an empty API response into a complete catalog, or qualify native pixels.
M.Coverage={schemaVersion=1,packRevision="P8-0ae2c500-71037"}
local V=M.Coverage
local function count(rows,predicate)
    local n=0
    for _,r in pairs(type(rows)=="table" and rows or {}) do
        if type(r)=="table" and M:Readable(r) and (not predicate or predicate(r)) then n=n+1 end
    end
    return n
end
local function copy(value)
    if M.core and type(M.core.Copy)=="function" then return M.core.Copy(value) end
    local out={};for k,v in pairs(value or {}) do out[k]=type(v)=="table" and copy(v) or v end;return out
end
local function service(name)
    return M.Integration and M.Integration:Service(name)
end
function V:Get(mapID)
    if mapID~=nil and not M:Integer(mapID) then return nil,"INVALID_MAP" end
    local catalog=M.Catalog
    local a=catalog and not catalog.readOnly and type(catalog.account)=="table" and catalog.account
    local b=catalog and not catalog.readOnly and type(catalog.character)=="table" and catalog.character
    local function here(row)return mapID==nil or row.mapID==mapID end
    local travel=count(M.PilotTravelSeeds,here)
    local regions=M.ZoneReference or {}
    local region=mapID and regions[mapID]
    local levelCount=mapID and (region and region.minLevel and 1 or 0) or count(regions,function(r)return r.minLevel~=nil end)
    local materialCount=mapID and ((region and #(region.herbs or {}) or 0)+(region and #(region.ores or {}) or 0)) or count(regions,function(r)return r.herbs~=nil or r.ores~=nil end)
    local fishingCount=mapID and (region and region.fishingSkill and 1 or 0) or count(regions,function(r)return r.fishingSkill~=nil end)
    local published=catalog and catalog.mapID==mapID and not catalog.withdrawn and catalog.publishedCounts or {}
    local report={schemaVersion=1,packRevision=self.packRevision,mapID=mapID,
        targetBuild=M.state.clientBuild or "unknown",nativeVerification="NOT_RUN",
        catalogStatus=catalog and catalog.status or "UNAVAILABLE",categories={},
        license="MIT",referenceCommit="0ae2c5006b28a640c3a3c17914d3d4543717ce5d"}
    local function add(id,label,state,n,scope,source,qualification)
        report.categories[#report.categories+1]={id=id,label=label,state=state,count=n,
            scope=scope,source=source,qualification=qualification}
    end
    add("travel","Travel references",travel>0 and "REFERENCE_AVAILABLE" or "NO_REFERENCE",travel,
        mapID and "Selected map" or "All supplied maps","ForeverPlusPlus MIT travel facts","Historical positions; access and 71037 alignment unverified")
    add("levels","Zone level guidance",levelCount>0 and "REFERENCE_AVAILABLE" or "NATIVE_WHEN_READABLE",levelCount,
        mapID and "Selected map" or "All supplied maps","Native map levels take priority over reference","Recommended levels, not an entry condition")
    add("regional_resources","Regional materials",materialCount>0 and "REFERENCE_AVAILABLE" or "NO_REFERENCE",materialCount,
        mapID and "Material IDs for selected zone" or "Maps with resource references","ForeverPlusPlus MIT Classic reference","No node coordinates, spawn state or drop rates")
    add("regional_fishing","Fishing skill guidance",fishingCount>0 and "REFERENCE_AVAILABLE" or "NO_REFERENCE",fishingCount,
        mapID and "Selected map" or "All supplied maps","ForeverPlusPlus MIT Classic reference","Current Forever fishing eligibility unverified")
    local terrain=M.ExplorationData and M.ExplorationData.maps or {}
    local terrainCount=mapID and (terrain[mapID] and 1 or 0) or count(terrain)
    add("terrain","Unexplored terrain references",terrainCount>0 and "IDENTITY_CHECK_REQUIRED" or "NO_REFERENCE",terrainCount,
        mapID and "Selected outdoor map" or "Catalogued outdoor maps","ForeverPlusPlus MIT / native 70959 art tables",
        "Preview requires matching native art and geometry; 71037 observed-overlay conflicts refuse rendering")
    local references=M.ServiceReference or {}
    local referenceCounts={spirit=0,dungeon=0,raid=0}
    for id,list in pairs(references) do if mapID==nil or mapID==id then
        for _,row in ipairs(list) do
            if referenceCounts[row.sourceCategory] then referenceCounts[row.sourceCategory]=referenceCounts[row.sourceCategory]+1 end
        end
    end end
    for _,entry in ipairs({{"spirit","Spirit-healer references"},{"dungeon","Dungeon / access-area references"},{"raid","Raid / access-area references"}}) do
        local n=referenceCounts[entry[1]]
        add("reference_"..entry[1],entry[2],n>0 and "REFERENCE_AVAILABLE" or "NO_REFERENCE",n,
            mapID and "Selected map" or "All supplied maps","ForeverPlusPlus MIT place reference",
            "Historical locations; current access and services unknown. Native matching points take priority")
    end
    local materialDetails=0
    if M.ZoneGuide and M.ZoneGuide.GetResourceCatalog then
        local resources=M.ZoneGuide:GetResourceCatalog()
        if resources then
            local hereItems={}
            for _,kind in ipairs({"herbs","ores"}) do for _,id in ipairs(region and region[kind] or {}) do hereItems[id]=true end end
            for _,item in ipairs(resources.items or {}) do if mapID==nil or hereItems[item.itemID] then materialDetails=materialDetails+1 end end
        end
    end
    add("resource_skills","Gathering skill / node references",materialDetails>0 and "REFERENCE_AVAILABLE" or "NO_REFERENCE",materialDetails,
        mapID and "Materials in the selected region reference" or "All supplied material references","ForeverPlusPlus MIT profession reference",
        "Skill and node variants are historical references; current requirements and live spawns unverified")
    add("merchants","Visited vendors / repair",a and "PERSONAL_OBSERVATIONS" or "NOT_INITIALIZED",
        count(a and a.services,function(r)return here(r) and r.serviceRoles and (r.serviceRoles:find("goods",1,true) or r.serviceRoles:find("repair",1,true)) end),
        "Visited NPC interaction positions","Native merchant interaction","Approximate history; current offerings unknown")
    add("vendor_items","Vendor item associations",a and "PERSONAL_OBSERVATIONS" or "NOT_INITIALIZED",
        count(a and a.services,function(r)return here(r) and r.soldItemIDs and #r.soldItemIDs>0 end),
        "Vendors with up to 32 observed item IDs each","Read-only visible merchant list","Historical visible list; stock / prices / exhaustive catalog not established")
    add("trainers","Visited trainers",a and "PERSONAL_OBSERVATIONS" or "NOT_INITIALIZED",
        count(a and a.services,function(r)return here(r) and r.serviceRoles and r.serviceRoles:find("trainer",1,true) end),
        "Visited NPC interaction positions","Native trainer interaction","Current learnable offerings unknown")
    add("accepted_quests","Accepted quest locations","NATIVE_WHEN_READABLE",published.NATIVE_ACCEPTED_QUEST or 0,
        "Published locations on selected map","Current native quest log / map","Native next waypoint can represent an intermediate objective")
    add("quest_offers","Quest offer history",b and "PERSONAL_OBSERVATIONS" or "NOT_INITIALIZED",count(b and b.offers,here),
        "Previously visited quest givers","Native available-quest interaction","Eligibility requires a current NPC check; no complete quest database")
    add("flight_access","Observed flight access",b and "PERSONAL_OBSERVATIONS" or "NOT_INITIALIZED",count(b and b.flights),
        "Character-wide taxi-map observations","Native flight-master map","Reachability belongs to the observation; no automatic booking")
    add("native_pois","Native POIs / entrances","NATIVE_WHEN_READABLE",published.NATIVE_MAP_API or 0,
        "Published locations on selected map","Native POI and encounter-journal maps","Only readable native points; eligibility unknown")
    local gather=service("Gather")
    local info,ok=M:Call(gather and gather.GetStatus)
    if not ok or type(info)~="table" or not M:Readable(info) then info=nil end
    add("gather_sites","Gathering / fishing observations",info and "PERSONAL_AND_IMPORTED_RECORDS" or "PROVIDER_UNAVAILABLE",
        info and M:Number(info.recordCount) and info.recordCount or 0,"Account-wide personal observations",
        "Gather Mate collector / explicitly imported packs","Historical sites, not live spawns or guaranteed catches")
    report.globalNodeDatabase="NOT_BUNDLED"
    report.completeQuestDatabase="NOT_BUNDLED"
    report.globalVendorTrainerDatabase="NOT_BUNDLED"
    return copy(report),"COVERAGE_REPORTED"
end
function V:Rows(mapID)
    local info,why=self:Get(mapID)
    if not info then return {{label="Coverage unavailable",detail=why}} end
    local rows={}
    for _,r in ipairs(info.categories) do
        rows[#rows+1]={id=r.id,label=r.label..": "..r.count,
            detail=r.scope.." · "..r.qualification,state=r.state,source=r.source}
    end
    return rows
end
