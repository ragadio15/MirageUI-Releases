local _,M=...
M.Integration={owners={}}
local I=M.Integration
local competing={"Leatrix_Maps","Mapster","OpenMap","MapTab","Veilmap","MapForever",
    "PatchToolsMaps","BVAddonSuite_Map","WorldMapPlus"}
function I:IsLoaded(name)
    local func=(type(C_AddOns)=="table" and C_AddOns.IsAddOnLoaded) or IsAddOnLoaded
    local value,ok=M:Call(func,name)
    return ok and value==true
end
function I:Conflicts()
    local found={}
    for _,name in ipairs(competing) do if self:IsLoaded(name) then found[#found+1]=name end end
    return found
end
function I:AllowMapOverlay()
    if not M.state.clientAllowed then return false,"UNSUPPORTED_CLIENT" end
    local account=M.Storage.account
    local p=type(account)=="table" and account.settings
    if M.Storage.readOnly or type(p)~="table" then return false,"PREFERENCES_UNAVAILABLE" end
    if p.mapPolicy=="off" then return false,"OVERLAY_DISABLED" end
    -- Other map addons may own fog, zoom or textures without owning our data
    -- layers. Only the optional native canvas attachment is capability-gated.
    -- No native map scripts, textures, parenting or navigation are replaced.
    return true,"INDEPENDENT_MAP_LAYERS"
end
function I:Service(name)
    if not M.core or type(M.core.GetService)~="function" then return nil end
    local value,ok=M:Call(M.core.GetService,name,1)
    return ok and type(value)=="table" and value or nil
end
function I:ValidRecord(record)
    return M:Readable(record) and type(record)=="table" and M:Text(record.id,128) and
        M:Text(record.label,160) and M:Text(record.kind,40) and M.map and
        M.map:Valid(record.mapID,record.x,record.y)
end
function I:NoteRecord(note)
    if not note or not M.Storage:ValidNote(note) then return nil end
    return {id="mapnote:"..note.id,recordID=note.id,owner="MirageIntel_Map",kind="note",layer="notes",category=note.kind,
        label=note.label,mapID=note.mapID,x=note.x,y=note.y,source="PERSONAL_NOTE",confidence="MANUAL",
        revision=M.Storage.account.revision,sourceRevision=M.Storage.account.revision,
        observedAt=note.updatedAt,precision="PLAYER_SELECTED_POSITION",details=note.details,purpose="PERSONAL_NOTE"}
end
function I:Navigate()
    local a=MirageNavigateAPI
    return type(a)=="table" and a.apiVersion==1 and type(a.RequestDestination)=="function" and a or nil
end
function I:Gather()
    local a=MirageGatherAPI
    return type(a)=="table" and a.apiVersion==1 and type(a.GetGatherLocations)=="function" and a or nil
end
function I:GoToNote(note)
    if not M.state.clientAllowed then return false,"UNSUPPORTED_FOREVER_BUILD" end
    if not M.Storage or M.Storage.readOnly then return false,"MAP_STORAGE_READ_ONLY" end
    if not note or not M.Storage:ValidNote(note) then return false,"INVALID_DESTINATION" end
    if M:Combat() then return false,"COMBAT_NAVIGATION_UNAVAILABLE" end
    local a=self:Navigate()
    if not a then return false,"MIRAGENAVIGATE_NOT_INSTALLED" end
    local accepted,called,reason=M:Call(a.RequestDestination,"manual",{mapID=note.mapID,x=note.x,y=note.y,
        label=note.label,recordID="mapnote:"..note.id,sourceRevision=M.Storage.account.revision,
        purpose="PERSONAL_NOTE"},{userInitiated=true})
    if not called then return false,"NAVIGATION_PROVIDER_UNAVAILABLE" end
    local ok=accepted==true
    if ok and type(a.Refresh)=="function" then M:Call(a.Refresh) end
    if M.Canvas then M.Canvas:Dirty() end
    return ok,reason
end
function I:CurrentDestination()
    self.navigationSnapshot=nil;self.navigationRevision=nil;self.navigationMode=nil
    local a=self:Navigate()
    if not a or not M.map or type(M.map.Valid)~="function" or type(a.GetDestination)~="function" then return nil end
    local data,ok
    if type(a.GetNavigationSnapshot)=="function" then
        local session,called=M:Call(a.GetNavigationSnapshot)
        if not called or type(session)~="table" or session.schemaVersion~=2 then return nil end
        self.navigationRevision=session.revision
        self.navigationMode=session.mode
        self.navigationSnapshot=session
        if session.mode=="Pause" or session.mode=="Off" then return nil end
        data,ok=session.destination,true
    else data,ok=M:Call(a.GetDestination) end
    if not ok or type(data)~="table" or not M:Readable(data) or
        not M:Text(data.label,160) or not M.map:Valid(data.mapID,data.x,data.y) then return nil end
    local records=self:Service("WorldRecords")
    local id=M:Text(data.recordID,128) or M:Text(data.siteID,128)
    local record
    if records and type(records.Get)=="function" and id then
        local value,called=M:Call(records.Get,id)
        if called and self:ValidRecord(value) and value.mapID==data.mapID and
            (value.floorID or value.mapID)==(data.floorID or data.mapID) and
            value.x==data.x and value.y==data.y then record=value end
    end
    -- Preserve the published record's revision. Navigation's session revision
    -- is separate, so every renderer can identify the same source observation.
    record=record or {id=id or M:Text(data.id,128) or ("destination:"..data.mapID..":"..data.x..":"..data.y),
        mapID=data.mapID,x=data.x,y=data.y,label=data.label,source=data.source or "UNKNOWN",
        kind=data.kind or "destination",category=data.category,floorID=data.floorID,confidence=data.confidence or "USER_SELECTED",
        revision=data.revision,sourceRevision=data.sourceRevision,precision=data.precision,
        observedAt=data.observedAt,siteID=data.siteID,questID=data.questID,stage=data.stage}
    record.navigationRevision=self.navigationRevision or data.revision
    record.positionPrecision=record.precision
    record.precision=data.precision or record.precision
    record.nextLegID=self.navigationSnapshot and self.navigationSnapshot.nextLeg and self.navigationSnapshot.nextLeg.id
    record.routeRevision=self.navigationSnapshot and self.navigationSnapshot.routeRevision or record.navigationRevision
    record.routeCostBasis=self.navigationSnapshot and self.navigationSnapshot.route and self.navigationSnapshot.route.costBasis
    record.purpose=data.purpose or (self.navigationMode=="Gather" and "GATHER" or
        self.navigationMode=="Quest" and "QUEST" or "MANUAL")
    record.destination=true
    record.status=data.status
    return record
end
-- Destination pins retain the exact goal. Guidance consumes the authority's
-- published next leg and target, including an intentional nil direction for
-- a transport action whose trajectory is not supplied by its source.
function I:GuidanceFor(destination)
    if not destination then return nil,nil end
    local session=self.navigationSnapshot
    if session then
        if session.revision~=destination.navigationRevision then return nil,nil end
        if session.nextLeg or session.route then return session.nextLeg,session.directionTarget end
    end
    return {id="direct:"..destination.id,precision="DIRECT_BEARING",geometry="DIRECT_BEARING",mode="BEARING"},destination
end
function I:FlightPreview(record)
    local graph=self:Service("TravelGraph")
    if not graph or type(graph.GetRoute)~="function" or not record then return nil,"FLIGHT_GRAPH_UNAVAILABLE" end
    local player=M.map and M.map:Player()
    if not player then return nil,"PLAYER_POSITION_UNAVAILABLE" end
    local result,ok,why=M:Call(graph.GetRoute,{start=player,destination=record,context={modes={FLIGHT=true}}})
    return ok and type(result)=="table" and result or nil,why or "FLIGHT_MASTER_OBSERVATION_REQUIRED"
end
function I:GatherPreferences()
    local gather=self:Gather()
    if not gather or type(gather.GetStatus)~="function" then return nil,"GATHER_UNAVAILABLE" end
    local status,ok=M:Call(gather.GetStatus)
    local p=ok and type(status)=="table" and status.preferences
    if type(p)~="table" or type(p.showMapPins)~="boolean" then return nil,"GATHER_PREFERENCES_UNAVAILABLE" end
    return p,"AVAILABLE"
end
function I:GatherRecords(mapID,limit)
    local prefs,why=self:GatherPreferences()
    if not prefs then return {},{status=why,revision=0} end
    if not prefs.showMapPins then return {},{status="GATHER_LAYER_DISABLED",revision=0} end
    local records=self:Service("WorldRecords")
    if not records or type(records.Query)~="function" then return {},{status="WORLD_RECORDS_UNAVAILABLE",revision=0} end
    local size=M:Integer(limit) and math.min(limit,64) or 64
    if M:Integer(prefs.maxPins) then size=math.min(size,prefs.maxPins) end
    local request={mapID=mapID,owner="MirageIntel_Gather",kind="gather",visibility="world",limit=size}
    if M:Text(prefs.category,40) and prefs.category~="all" then request.category=prefs.category end
    local result,called=M:Call(records.Query,request)
    if not called or type(result)~="table" or type(result.records)~="table" then
        return {},{status="WORLD_RECORD_QUERY_UNAVAILABLE",revision=0}
    end
    local rows={}
    for i,record in ipairs(result.records) do
        if i>64 then break end
        if self:ValidRecord(record) and record.mapID==mapID and record.owner=="MirageIntel_Gather" and
            record.kind=="gather" and record.hidden~=true and record.showWorld~=false then rows[#rows+1]=record end
    end
    return rows,{status=result.status,revision=result.revision,nextCursor=result.nextCursor}
end
function I:ClaimGatherLayer()
    local layers=self:Service("MapLayers")
    if not layers or type(layers.Acquire)~="function" then return false,"LAYER_SERVICE_UNAVAILABLE" end
    local acquired,ok,why=M:Call(layers.Acquire,"world:gather","MirageIntel_Map",20,3)
    return ok and acquired==true,why
end
function I:ReleaseGatherLayer()
    local layers=self:Service("MapLayers")
    if layers and type(layers.Release)=="function" then M:Call(layers.Release,"world:gather","MirageIntel_Map") end
end
function I:ClaimLayer(layer)
    if layer=="resources" then return self:ClaimGatherLayer() end
    local service=self:Service("MapLayers")
    if not service or type(service.Acquire)~="function" then return false end
    local result,ok=M:Call(service.Acquire,"world:"..layer,"MirageIntel_Map",20,3)
    return ok and result==true
end
function I:ReleaseLayer(layer)
    if layer=="resources" then return self:ReleaseGatherLayer() end
    local service=self:Service("MapLayers")
    if service and type(service.Release)=="function" then M:Call(service.Release,"world:"..layer,"MirageIntel_Map") end
end
function I:RouteOverlay()
    local now=M:Now()
    local nav=self:Navigate();local session=self.navigationSnapshot
    local revision=session and session.revision
    local epoch=self.navigationEpoch or 0
    if self.overlayCacheTime==now and self.overlayCache and self.overlayCacheProvider==nav and
        self.overlayCacheRevision==revision and self.overlayCacheEpoch==epoch then return self.overlayCache end
    local data
    if nav and type(nav.GetRouteOverlay)=="function" then
        local result,ok=M:Call(nav.GetRouteOverlay)
        if ok and type(result)=="table" then data=result end
    end
    if self:Navigate()~=nav or (self.navigationEpoch or 0)~=epoch or self.navigationSnapshot~=session then
        self.overlayCache=nil;self.overlayCacheTime=nil
        return {stops={},showMap=false,showMinimap=false,status="NAVIGATION_AUTHORITY_CHANGED"}
    end
    if data and session and data.revision~=session.revision then
        -- A provider can publish a new destination while another callback is
        -- reading the previous snapshot. Do not join their separate routes.
        self.overlayCache=nil;self.overlayCacheTime=nil
        return {revision=data.revision,mode=data.mode,stops={},showMap=false,showMinimap=false,status="NAVIGATION_REVISION_CHANGED"}
    end
    if not data and session then
        data={revision=session.revision,mode=session.mode,stops=session.itinerary and session.itinerary.stops or {},
            activeID=session.destination and session.destination.id}
    end
    data=data or {stops={}}
    if data.mode=="Off" or data.mode=="Pause" then data={revision=data.revision,mode=data.mode,stops={},showMap=false} end
    local result={revision=data.revision,mode=data.mode,activeID=data.activeID,showMap=data.showMap~=false,showMinimap=data.showMinimap~=false,stops={}}
    for i,row in ipairs(type(data.stops)=="table" and data.stops or {}) do
        if i>24 then break end
        if type(row)=="table" and M:Readable(row) and M.map:Valid(row.mapID,row.x,row.y) and M:Text(row.label,160) then
            local copy=M.core.Copy(row)
            copy.id=M:Text(copy.recordID,128) or M:Text(copy.siteID,128) or M:Text(copy.id,128) or ("route:"..i)
            result.stops[#result.stops+1]=copy
        end
    end
    self.overlayCacheTime=now;self.overlayCache=result;self.overlayCacheProvider=nav;self.overlayCacheRevision=revision;self.overlayCacheEpoch=epoch
    return result
end
function I:RouteStops(mapID)
    local rows={};local cfg=M.Storage.account and M.Storage.account.settings
    if not cfg or cfg.showRouteStops==false then return rows end
    local overlay=self:RouteOverlay()
    if overlay.showMap==false then return rows end
    if #overlay.stops>0 then
        for i,stop in ipairs(overlay.stops) do
            if stop.mapID==mapID then
                local record=M.core.Copy(stop)
                record.suggestedStop=i;record.layer="routes";record.purpose="ROUTE_STOP"
                rows[#rows+1]=record
            end
        end
        return rows
    end
    if not M.Storage.RouteSnapshot then return rows end
    local snapshot=M.Storage:RouteSnapshot()
    for _,note in ipairs(snapshot.rows or {}) do
        if note.mapID==mapID and not M.Storage.character.hidden[note.id] then
            local record=self:NoteRecord(M.Storage.account.notes[note.id])
            if record then record.suggestedStop=note.index;record.layer="routes";record.purpose="SUGGESTED_MANUAL_STOP";rows[#rows+1]=record end
        end
    end
    return rows
end
function I:SelectRecord(record,origin)
    if not self:ValidRecord(record) then return false,"INVALID_RECORD" end
    if M:Combat() then return false,"COMBAT_NAVIGATION_UNAVAILABLE" end
    M.state.utilitySelection=M.core.Copy(record)
    if M.Inspector then return M.Inspector:Open(record,origin) end
    M.Panel.page="Places";M.Panel.offset=0
    return M.Panel:Open(origin)
end
function I:NavigateRecord(record)
    if not M.state.clientAllowed or M:Combat() then return false,"CLIENT_OR_COMBAT_UNAVAILABLE" end
    if M.Storage and M.Storage.readOnly then return false,"MAP_STORAGE_READ_ONLY" end
    if not self:ValidRecord(record) then return false,"SELECT_PLACE_FIRST" end
    -- Itinerary stops carry lightweight identities. Restore the current site
    -- record before dispatch so a gathering stop keeps its observation lifecycle.
    if record.kind=="gather" and not record.owner then
        local records=self:Service("WorldRecords")
        local current,ok
        local id=M:Text(record.siteID,128) or M:Text(record.id,128)
        if records and type(records.Get)=="function" and id then current,ok=M:Call(records.Get,id) end
        if not ok or not self:ValidRecord(current) or current.kind~="gather" or current.owner~="MirageIntel_Gather" then
            return false,"LOCATION_NO_LONGER_AVAILABLE"
        end
        if current.hidden==true then return false,"LOCATION_HIDDEN" end
        if current.mapID~=record.mapID or current.x~=record.x or current.y~=record.y then
            M.state.utilitySelection=current
            return false,"LOCATION_UPDATED_SELECT_NAVIGATE_AGAIN"
        end
        record=current
    end
    -- Re-resolve a shared record at the click boundary. Removed or changed
    -- observations cannot silently send the player to an outdated position.
    if record.owner and record.owner~="MirageIntel_Map" then
        local records=self:Service("WorldRecords")
        local current,ok
        if records and type(records.Get)=="function" then current,ok=M:Call(records.Get,record.id) end
        if not ok or not self:ValidRecord(current) then return false,"LOCATION_NO_LONGER_AVAILABLE" end
        if current.hidden==true then return false,"LOCATION_HIDDEN" end
        if current.revision~=record.revision or current.sourceRevision~=record.sourceRevision then
            M.state.utilitySelection=current
            return false,"LOCATION_UPDATED_SELECT_NAVIGATE_AGAIN"
        end
        record=current
    elseif record.owner=="MirageIntel_Map" and type(record.recordID)=="number" then
        if not M.Storage then return false,"MAP_STORAGE_READ_ONLY" end
        local note=M.Storage.account.notes and M.Storage.account.notes[record.recordID]
        if not note then return false,"LOCATION_NO_LONGER_AVAILABLE" end
        if M.Storage.character.hidden[record.recordID] then return false,"LOCATION_HIDDEN" end
        local current=self:NoteRecord(note)
        if current.sourceRevision~=record.sourceRevision then M.state.utilitySelection=current;return false,"LOCATION_UPDATED_SELECT_NAVIGATE_AGAIN" end
        record=current
    end
    local nav=self:Navigate()
    if not nav then return false,"MIRAGENAVIGATE_NOT_INSTALLED" end
    if record.kind=="quest" and M:Integer(record.questID) and
        (record.availability=="ACCEPTED" or record.suggestedStop or record.purpose=="ROUTE_STOP" or record.destination or not record.owner) then
        if type(nav.PinQuest)~="function" then return false,"QUEST_NAVIGATION_UNAVAILABLE" end
        -- Keep the quest ID and stage under the navigation authority. A static
        -- coordinate pin cannot follow objective progress, turn-in or removal.
        local accepted,called,why=M:Call(nav.PinQuest,record.questID)
        if not called then return false,"NAVIGATION_PROVIDER_UNAVAILABLE" end
        if accepted==true and type(nav.Refresh)=="function" then M:Call(nav.Refresh) end
        if M.Canvas then M.Canvas:Dirty() end
        return accepted==true,why
    end
    local gather=record.kind=="gather" and record.owner=="MirageIntel_Gather"
    local accepted,ok,why=M:Call(nav.RequestDestination,gather and "gather" or "manual",{mapID=record.mapID,x=record.x,y=record.y,
        label=record.label,recordID=record.id,siteID=record.siteID,sourceRevision=record.sourceRevision,
        name=record.name or record.label,category=record.category,requireRecord=gather,
        taxiNodeID=record.taxiNodeID or record.nodeID,nodeID=record.nodeID,floorID=record.floorID,
        purpose=record.kind=="gather" and "HISTORICAL_SITE" or "MANUAL"},{userInitiated=true})
    if not ok then return false,"NAVIGATION_PROVIDER_UNAVAILABLE" end
    if accepted==true and type(nav.Refresh)=="function" then M:Call(nav.Refresh) end
    if M.Canvas then M.Canvas:Dirty() end
    return accepted==true,why
end
function I:ShowRecord(owner,record,context)
    if not self:ValidRecord(record) then return false end
    local insight=MirageInsightAPI
    if type(insight)=="table" and type(insight.ShowUtilityRecord)=="function" then
        local shown,ok=M:Call(insight.ShowUtilityRecord,owner,record,context)
        if ok and shown==true then return true end
    end
    -- Optional Insight disabled or absent: retain a small native utility card.
    if not GameTooltip then return false end
    GameTooltip:SetOwner(owner,"ANCHOR_RIGHT")
    GameTooltip:AddLine(record.label,.96,.79,.36,true)
    GameTooltip:AddLine(string.format("%s  ·  %.1f, %.1f",M:Text(record.category,40) or record.kind,record.x*100,record.y*100),.90,.89,.87,true)
    if record.kind=="gather" then GameTooltip:AddLine("Recorded gathering spot",.63,.62,.60,true) end
    if record.destination then GameTooltip:AddLine("Current destination",.96,.79,.36,true) end
    if context and M:Text(context.hint,140) then GameTooltip:AddLine(context.hint,.63,.62,.60,true) end
    GameTooltip:Show()
    return true
end
function I:HideRecord(owner)
    local insight=MirageInsightAPI
    if type(insight)=="table" and type(insight.HideUtilityRecord)=="function" then M:Call(insight.HideUtilityRecord,owner) end
    if GameTooltip and type(GameTooltip.IsOwned)=="function" and GameTooltip:IsOwned(owner) then GameTooltip:Hide() end
end
function I:Initialize()
    if M.core and type(M.core.Subscribe)=="function" then
        M.core.Subscribe("NAV_DESTINATION_CHANGED","MirageIntel_Map",function()
            I.navigationEpoch=(I.navigationEpoch or 0)+1;I.overlayCache=nil;I.overlayCacheTime=nil
            if M.Canvas then M.Canvas:Dirty() end
        end)
        M.core.Subscribe("NAV_SESSION_CHANGED","MirageIntel_Map",function()
            I.navigationEpoch=(I.navigationEpoch or 0)+1
            I.overlayCache=nil;I.overlayCacheTime=nil
            if M.Canvas then M.Canvas:Dirty() end
            if M.Panel then M.Panel:Update() end
        end)
        M.core.Subscribe("TRAVEL_GRAPH_CHANGED","MirageIntel_Map",function()
            if M.Canvas then M.Canvas:Dirty() end
            if M.Inspector and M.Inspector.frame and M.Inspector.frame:IsShown() then M.Inspector:Refresh() end
        end)
        M.core.Subscribe("WORLD_RECORDS_CHANGED","MirageIntel_Map",function()
            if M.RecordQuery then M.RecordQuery:Invalidate() end
            if M.Canvas then M.Canvas:Dirty() end
            if M.Panel then M.Panel:Update() end
        end)
        M.core.Subscribe("MAP_LAYER_CHANGED","MirageIntel_Map",function(event)
            if type(event)=="table" and type(event.key)=="string" and event.key:sub(1,6)=="world:" and event.owner~="MirageIntel_Map" then
                if M.Canvas then M.Canvas:Dirty() end
            end
        end)
        M.core.Subscribe("GATHER_OBSERVATION_SAVED","MirageIntel_Map",function()
            if M.Panel then M.Panel:Update() end
        end)
    end
end
