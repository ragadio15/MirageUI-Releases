local _,M=...
-- Map-local native facts and attributed history. This provider never selects a
-- quest, changes the native map's POI map, accepts a quest or initiates travel.
-- Flight-map coordinates belong to the flight map, never to an arbitrary zone.
M.Catalog={owner="MirageIntel_MapCatalog",generation=0,revision=0,invalidated=true,
    status="NOT_INITIALIZED",sourceStates={},maxObserved=512,maxRows=1024}
local P=M.Catalog
local nativeURL="https://github.com/Gethe/wow-ui-source/tree/734f065329cff4992835b01a84f210a297db91b6"
local seedURL="https://github.com/xIGBClutchIx/ForeverPlusPlus/blob/0ae2c5006b28a640c3a3c17914d3d4543717ce5d/ForeverPlusPlus/Data/PointsOfInterest.lua"
local function field(row,key)
    if not M:Readable(row) or (type(row)~="table" and type(row)~="userdata") then return nil end
    local ok,v=pcall(function()return row[key]end)
    if not ok or not M:Readable(v) then return nil end
    return v
end
local function service(name) return M.Integration and M.Integration:Service(name) end
local function copy(row) return M.core and M.core.Copy(row) end
local function boolean(api,...)
    local v,ok=M:Call(api,...)
    if not ok or type(v)~="boolean" then return nil,false end
    return v,true
end
local function list(api,...)
    local v,ok=M:Call(api,...)
    return ok and type(v)=="table" and v or {},ok and type(v)=="table"
end
local function position(row)
    local x,y=M.map:XY(field(row,"position"))
    return x,y
end
local function rowsize(rows)
    local n=0;for _ in pairs(type(rows)=="table" and rows or {}) do n=n+1 end;return n
end
local function safeRecord(r)
    if type(r)~="table" or not M:Readable(r) then return false end
    local fields=0
    for k,v in pairs(r) do
        fields=fields+1
        if fields>64 or type(k)~="string" or #k>48 or not M:Readable(v) then return false end
        local t=type(v)
        if t=="string" then if #v>400 or v:find("[%c|]") then return false end
        elseif t=="number" then if not M:Number(v) then return false end
        elseif t=="table" and k=="soldItemIDs" then
            local n,seen=0,{}
            if #v>32 then return false end
            for index,id in pairs(v) do
                n=n+1
                if not M:Integer(index) or index>#v or not M:Integer(id) or id>2147483647 or seen[id] then return false end
                seen[id]=true
            end
            if n~=#v then return false end
        elseif t~="boolean" then return false end
    end
    return M:Text(r.id,128) and r.id:match("^[%w_:%-%.]+$") and
        M:Text(r.label,160) and M:Text(r.kind,32) and M.map:Valid(r.mapID,r.x,r.y) and
        (r.observedAt==nil or (M:Number(r.observedAt) and r.observedAt>=0))
end
function P:Initialize()
    if self.initialized then return end
    self.initialized=true
    if not M.state.clientAllowed or M.Storage.readOnly then self.status="CLIENT_OR_STORAGE_UNAVAILABLE";return end
    local a,b=M.Storage.account,M.Storage.character
    if a.catalog==nil then a.catalog={schemaVersion=1,revision=0,services={}} end
    if b.catalog==nil then b.catalog={schemaVersion=1,revision=0,offers={},flights={}} end
    self.account,self.character=a.catalog,b.catalog
    if type(self.account)~="table" or type(self.character)~="table" or self.account.schemaVersion~=1 or self.character.schemaVersion~=1 or
        type(self.account.services)~="table" or type(self.character.offers)~="table" or type(self.character.flights)~="table" or
        not M:Number(self.account.revision) or self.account.revision<0 or self.account.revision%1~=0 or
        not M:Number(self.character.revision) or self.character.revision<0 or self.character.revision%1~=0 then
        self.readOnly=true;self.status="CATALOG_SCHEMA_PRESERVED";return
    end
    for _,bucket in ipairs({self.account.services,self.character.offers,self.character.flights}) do
        local n=0
        for id,r in pairs(bucket) do
            n=n+1
            if n>self.maxObserved or not safeRecord(r) or r.id~=id then
                self.readOnly=true;self.status="CATALOG_HISTORY_PRESERVED";return
            end
        end
    end
    self.status="READY_NATIVE_UNTESTED"
    if next(self.account.services) or next(self.character.offers) or next(self.character.flights) then
        -- Restored history must become an item source after login as well as
        -- after a fresh interaction; opening the world map is not required.
        self.observationRevision=1;self.observationsDirty=true;self.observationsDirtyAt=M:Now()
        self.observationPublication="RESTORED_HISTORY_PENDING"
        for _,bucket in ipairs({self.account.services,self.character.offers,self.character.flights}) do
            local _,row=next(bucket)
            if row then self.lastObservationMapID=row.mapID;break end
        end
    end
    if M.core and type(M.core.RegisterService)=="function" then
        M.core.RegisterService("MapCatalog","MirageIntel_Map",1,{
            GetStatus=function()return P:GetStatus()end,
            Refresh=function(mapID)P:Invalidate();return P:Refresh(mapID,true)end})
    end
end
function P:GetStatus()
    return {status=self.status,mapID=self.mapID,generation=self.generation,revision=self.revision,
        rows=self.count or 0,omitted=self.omitted or 0,pilotSeeds=#(M.PilotTravelSeeds or {}),
        referenceServices=M.ServiceReferenceInfo and M.ServiceReferenceInfo.records or 0,
        referenceMaps=M.ServiceReferenceInfo and M.ServiceReferenceInfo.maps or 0,
        observedServices=type(self.account)=="table" and rowsize(self.account.services) or 0,
        observedOffers=type(self.character)=="table" and rowsize(self.character.offers) or 0,
        observedFlights=type(self.character)=="table" and rowsize(self.character.flights) or 0,
        sources=copy(self.sourceStates),coverage="NATIVE_FACTS_LOCAL_OBSERVATIONS_AND_ATTRIBUTED_REFERENCE",
        merchantObservation=self.merchantStatus or "NOT_OBSERVED",merchantGeneration=self.merchantGeneration or 0,
        gossipObservation=self.gossipStatus or "NOT_OBSERVED",gossipGeneration=self.gossipGeneration or 0,
        observationsDirty=self.observationsDirty==true,observationRevision=self.observationRevision or 0,
        publishedObservationRevision=self.publishedObservationRevision or 0,
        observationPublication=self.observationPublication or "NOT_REQUESTED",
        coordinates="NATIVE_MAP_OR_APPROXIMATE_INTERACTION_POSITION",nativeVerification="NOT_RUN"}
end
function P:Diagnostics()
    local d=service("Diagnostics");if d and type(d.Set)=="function" then d.Set(self.owner,self:GetStatus()) end
end
function P:Invalidate()
    self.invalidated=true
    if not self.observationsDirty and not self.readOnly and self.account and self.character and
       (next(self.account.services) or next(self.character.offers) or next(self.character.flights)) then
        -- The provider is shared with live quest facts. Their immediate
        -- withdrawal must also schedule the historical item index to return,
        -- even when no map consumer is visible to request a fresh snapshot.
        self.observationsDirty=true;self.observationsDirtyAt=M:Now()
        self.observationPublication="CATALOG_REVALIDATION_PENDING"
    end
    local records,tasks=service("WorldRecords"),service("Tasks")
    if self.token then
        if records then records.CancelSnapshot(self.owner,self.token) end
        if tasks then tasks.Cancel(self.owner) end
        self.token=nil;self.generation=self.generation+1
    end
    -- Changed quest/NPC evidence is withdrawn immediately, even with the map
    -- closed. A published AVAILABLE row cannot outlive its native observation.
    if records and self.initialized and not self.readOnly and (not self.withdrawn or self.committingToken) then
        records.SetOwnerState(self.owner,"UNAVAILABLE","CATALOG_REVALIDATING")
        self.withdrawn=true
    end
    if M.Canvas then M.Canvas:Dirty() end
end
function P:Base(id,mapID,x,y,label,kind,category,source)
    if not M.map:Valid(mapID,x,y) or not M:Text(label,160) then return nil end
    return {id=id,mapID=mapID,x=x,y=y,label=label,kind=kind,category=category,
        layer=kind=="quest" and "quests" or kind=="poi" and "pois" or "services",
        source=source or "NATIVE_MAP_API",sourceLabel="Native client map data",sourceURL=nativeURL,
        confidence="NATIVE_READBACK",precision="NATIVE_MAP_POINT",clientBuild=M.state.clientBuild or "unknown",
        coverage="READABLE_NATIVE_DATA",availability="UNKNOWN",availabilityReason="Not established",
        showWorld=true,showMinimap=false,nativeVerification="NOT_RUN"}
end
function P:Add(stage,r)
    if not r or not safeRecord(r) then return end
    if stage.seen[r.id] then return end
    if #stage.rows>=self.maxRows then stage.omitted=stage.omitted+1;return end
    stage.seen[r.id]=true;stage.rows[#stage.rows+1]=r
end
function P:NativePOIs(stage,mapID)
    local api=C_AreaPoiInfo
    if not stage.poiIDs then
        local ids,ok=list(api and api.GetAreaPOIForMap,mapID)
        stage.poiIDs=ids;stage.poiCursor=1
        self.sourceStates.poi=ok and "READABLE" or "UNAVAILABLE"
        if #ids>256 then stage.omitted=stage.omitted+(#ids-256) end
    end
    local ids=stage.poiIDs
    for i=stage.poiCursor,math.min(#ids,256,stage.poiCursor+31) do
        local id=ids[i]
        if M:Integer(id) then
            local row,read=M:Call(api and api.GetAreaPOIInfo,mapID,id)
            if read and type(row)=="table" then
                local x,y=position(row)
                local r=self:Base("nativepoi:"..mapID..":"..id,mapID,x,y,field(row,"name"),"poi","landmark")
                if r then
                    r.details=M:Text(field(row,"description"),300);r.atlas=M:Text(field(row,"atlasName"),96)
                    r.areaPoiID=id;r.availabilityReason="Native POI; service eligibility is not implied"
                    self:Add(stage,r)
                end
            end
        end
    end
    stage.poiCursor=stage.poiCursor+32
    if stage.poiCursor<=math.min(#ids,256) then return true end
    local entrances,known=list(C_EncounterJournal and C_EncounterJournal.GetDungeonEntrancesForMap,mapID)
    self.sourceStates.entrances=known and "READABLE" or "UNAVAILABLE"
    for i,row in ipairs(entrances) do
        if i>64 then stage.omitted=stage.omitted+1;break end
        local x,y=position(row);local id=field(row,"journalInstanceID")
        if M:Integer(id) then
            local r=self:Base("entrance:"..mapID..":"..id,mapID,x,y,field(row,"name"),"poi","entrance")
            if r then r.details="Entrance location. Entry and group requirements are not established.";self:Add(stage,r) end
        end
    end
    return false
end
function P:NativeQuests(stage,mapID)
    local log=C_QuestLog
    local q=stage.quests
    if not q then
        local rows,ok=list(log and log.GetQuestsOnMap,mapID)
        self.sourceStates.quests=ok and "READABLE" or "UNAVAILABLE"
        local n,known=M:Call(log and log.GetNumQuestLogEntries)
        if known and M:Number(n) and n>=0 then self.sourceStates.quests="READABLE"
        else n=0 end
        q={rows=rows,mapCursor=1,logCursor=1,logCount=math.min(128,math.floor(n)),
            ids={},seen={},native={},cursor=1}
        stage.quests=q
    end
    local ids,seen,native=q.ids,q.seen,q.native
    local function add(id)
        if M:Integer(id) and not seen[id] and #ids<128 then seen[id]=true;ids[#ids+1]=id end
    end
    if q.mapCursor<=math.min(128,#q.rows) then
        for i=q.mapCursor,math.min(128,#q.rows,q.mapCursor+31) do
            local row=q.rows[i];local id=field(row,"questID");add(id)
            if M:Integer(id) and field(row,"mapID")==mapID and M.map:Valid(mapID,field(row,"x"),field(row,"y")) then
                native[id]={x=field(row,"x"),y=field(row,"y"),isQuestStart=field(row,"isQuestStart")==true,isDaily=field(row,"isDaily")}
            end
        end
        q.mapCursor=q.mapCursor+32;return true
    end
    if q.logCursor<=q.logCount then
        for i=q.logCursor,math.min(q.logCount,q.logCursor+31) do
            local row,read=M:Call(log.GetInfo,i)
            if read and field(row,"isHeader")~=true then add(field(row,"questID")) end
        end
        q.logCursor=q.logCursor+32;return true
    end
    for i=q.cursor,math.min(#ids,q.cursor+15) do
        local id=ids[i]
        -- Accepted waypoints and native quest-start markers remain distinct;
        -- unknown eligibility never becomes an automatic recommendation.
        local accepted=boolean(log and log.IsOnQuest,id)
        local failed=boolean(log and log.IsFailed,id)
        if accepted==true and failed~=true then
            local x,read,y=M:Call(log and log.GetNextWaypointForMap,id,mapID)
            if not read or not M.map:Valid(mapID,x,y) then
                local mid,good,a,b=M:Call(log and log.GetNextWaypoint,id)
                if good and mid==mapID then x,y=a,b else x,y=nil,nil end
            end
            if not M.map:Valid(mapID,x,y) and native[id] then x,y=native[id].x,native[id].y end
            local name=M:Call(log and log.GetTitleForQuestID,id)
            local r=self:Base("mapquest:"..mapID..":"..id,mapID,x,y,M:Text(name,160) or ("Quest #"..id),"quest","objective")
            if r then
                local complete,knownComplete=boolean(log and log.IsComplete,id)
                r.questID=id;r.availability="ACCEPTED";r.availabilityReason="Present in your current native quest log"
                r.stage=knownComplete and (complete and "TURN_IN_WAYPOINT" or "OBJECTIVE_WAYPOINT") or "WAYPOINT_STAGE_UNKNOWN"
                r.category=complete and "turn-in" or "objective"
                r.details="Native next waypoint; may be an intermediate objective or entrance."
                r.source="NATIVE_ACCEPTED_QUEST";r.sourceLabel="Current accepted quest log"
                self:Add(stage,r)
            end
        elseif accepted~=true and native[id] and native[id].isQuestStart then
            local name=M:Call(log and log.GetTitleForQuestID,id)
            local r=self:Base("mapquestoffer:"..mapID..":"..id,mapID,native[id].x,native[id].y,
                M:Text(name,160) or ("Quest #"..id),"quest","available","NATIVE_QUEST_START")
            if r then
                r.questID=id;r.stage="OFFER_MARKER";r.autoRecommend=false;r.repeatability=native[id].isDaily==true and "DAILY" or "UNKNOWN"
                r.sourceLabel="Native quest-start marker";r.availability="UNKNOWN"
                r.availabilityReason="Client map marker; current prerequisite eligibility needs an NPC check"
                r.details="Inspect this quest-giver to confirm availability. No automatic acceptance recommendation."
                self:Add(stage,r)
            end
        end
    end
    q.cursor=q.cursor+16
    return q.cursor<=#ids
end
-- Rectangles are read-only, and only used for outdoor zone/city maps. A
-- missing or degenerate rectangle does not authorize a guessed projection.
function P:Reproject(r,mapID)
    if r.mapID==mapID then return copy(r) end
    if r.kind~="flight" then return nil end
    local target=M:Call(C_Map and C_Map.GetMapInfo,mapID)
    local mt=field(target,"mapType")
    if mt~=3 then return nil end
    local left,ok,right,top,bottom=M:Call(C_Map and C_Map.GetMapRectOnMap,mapID,r.mapID)
    if not ok or not M:Number(left) or not M:Number(right) or not M:Number(top) or not M:Number(bottom) or
        right-left<=.00001 or bottom-top<=.00001 then return nil end
    local x,y=(r.x-left)/(right-left),(r.y-top)/(bottom-top)
    if not M.map:Valid(mapID,x,y) then return nil end
    local value=copy(r);value.id=r.id..":"..mapID;value.originalMapID=r.mapID;value.mapID=mapID;value.x=x;value.y=y
    value.precision="NATIVE_TAXI_MAP_RECT_TRANSFORM";return value
end
function P:Historical(stage,mapID)
    if not self.account or not self.character or self.readOnly then return false end
    local h=stage.history or {bucket=1};stage.history=h
    local buckets={self.account.services,self.character.offers,self.character.flights}
    for _=1,32 do
        local bucket=buckets[h.bucket];if not bucket then return false end
        local key,r=next(bucket,h.key)
        if not key then h.bucket=h.bucket+1;h.key=nil
        else
            h.key=key
            if h.bucket==3 then
                local projected=self:Reproject(r,mapID);if projected then self:Add(stage,projected) end
            elseif r.mapID==mapID then
                local value=copy(r)
                value.availability="UNKNOWN"
                if h.bucket==1 then value.availabilityReason="Previously visited; current offerings and stock unknown"
                else
                    local accepted=boolean(C_QuestLog and C_QuestLog.IsOnQuest,r.questID)
                    local completed,known=boolean(C_QuestLog and C_QuestLog.IsQuestFlaggedCompleted,r.questID)
                    value.availabilityReason="Previously offered; prerequisites and repeatability need a fresh NPC interaction"
                    if accepted then value.availability="ACCEPTED";value.availabilityReason="Already in your quest log"
                    elseif self.liveOffers and self.liveOffers[r.id] and self:GossipCurrent(self.gossipStage) then
                        value.availability="AVAILABLE";value.availabilityReason="Offered by the NPC currently open"
                    elseif known and completed and r.repeatability=="NONREPEATABLE_OBSERVED" then value.availability="UNAVAILABLE";value.availabilityReason="Previously completed; explicitly observed as nonrepeatable" end
                    value.autoRecommend=false
                end
                self:Add(stage,value)
            end
        end
    end
    return h.bucket<=3
end
local function referenceClientAligned()
    local patch,ok,build,date,interface=M:Call(GetBuildInfo)
    -- These attributed tables use Forever map IDs. They can remain labelled
    -- historical/unknown on later Forever builds, but another game's matching
    -- numeric map ID is not evidence of the same place or service.
    return ok and interface==16001
end
function P:Seeds(stage,mapID)
    if not referenceClientAligned() then return end
    for _,seed in ipairs(M.PilotTravelSeeds or {}) do if seed.mapID==mapID then
        local r=self:Base(seed.id,mapID,seed.x,seed.y,seed.label,seed.category=="flight" and "flight" or "service",seed.category,"FOREVER_PILOT_CATALOG")
        if r then
            r.sourceLabel="Forever travel reference (source checks through 70888)";r.sourceURL=seedURL;r.license="MIT"
            r.packID="FPP-travel-0ae2c500-P6";r.coverage="HISTORICAL_TRAVEL_REFERENCE";r.confidence="CATALOG_CANDIDATE"
            r.precision="CATALOG_APPROXIMATE";r.faction=seed.faction;r.serviceRoles=seed.category
            r.destinationMapID=seed.destinationMapID;r.availability="UNKNOWN";r.learned="UNKNOWN"
            r.sourceQualification=seed.sourceQualification or "HISTORICAL_CLIENT_TABLE_REFERENCE"
            r.via=seed.via;r.viaMapID=seed.viaMapID
            r.availabilityReason="Travel location; learned access and current route availability not established"
            r.details=r.sourceQualification=="CATALOG_UNTESTED_REFERENCE" and
                "Guide reference; upstream does not claim in-game coordinate verification. Current access is unknown." or
                "Historical source table checks through 70888; current positions and access need native observation."
            local duplicate=false
            -- A native observation at the same site takes presentation priority.
            -- Records remain separate; a visual dedupe never changes learned state.
            for _,native in ipairs(stage.rows) do
                if native.kind==r.kind and native.category==r.category and native.mapID==mapID and native.source=="NATIVE_TAXI_OBSERVATION" and
                    math.abs(native.x-r.x)<.006 and math.abs(native.y-r.y)<.006 then duplicate=true;break end
            end
            if not duplicate then self:Add(stage,r) end
        end
    end end
end
-- Optional P8 references are current-map only and never acquire live availability.
-- A narrow identity-and-position match gives native facts presentation priority;
-- proximity alone must not suppress a different entrance or neighboring service.
local function referenceName(value)
    return type(value)=="string" and value:lower():gsub("%s+"," "):gsub("^%s+",""):gsub("%s+$","") or nil
end
function P:ServiceReferences(stage,mapID)
    if not referenceClientAligned() then return false end
    local rows=M.ServiceReference and M.ServiceReference[mapID]
    if type(rows)~="table" then return false end
    local cursor=stage.referenceCursor or 1
    if cursor==1 and #rows>64 then stage.omitted=stage.omitted+(#rows-64) end
    for index=cursor,math.min(#rows,64,cursor+7) do
        local seed=rows[index]
        if type(seed)=="table" and (seed.kind=="service" or seed.kind=="poi") then
            local r=self:Base(seed.id,mapID,seed.x,seed.y,seed.label,seed.kind,seed.category,"FOREVER_SERVICE_REFERENCE")
            if r then
                r.sourceLabel="Historical service / entrance reference";r.sourceURL=seedURL;r.license="MIT"
                r.packID="FPP-services-0ae2c500-P8";r.coverage="HISTORICAL_SERVICE_REFERENCE"
                r.confidence="CATALOG_CANDIDATE";r.precision="CATALOG_APPROXIMATE"
                r.sourceQualification=seed.sourceQualification or "HISTORICAL_GUIDE_REFERENCE"
                r.sourceCategory=seed.sourceCategory;r.instanceKey=seed.instanceKey;r.instanceID=seed.instanceID
                r.groupNames=seed.groupNames
                r.serviceRoles=seed.serviceRoles;r.details=seed.details
                r.availability="UNKNOWN";r.availabilityReason="Historical reference; current location, access and requirements unconfirmed"
                r.autoRecommend=false
                local duplicate=false
                local name=referenceName(r.label)
                for _,native in ipairs(stage.rows) do
                    if native.mapID==mapID and native.source=="NATIVE_MAP_API" and referenceName(native.label)==name and
                        math.abs(native.x-r.x)<.003 and math.abs(native.y-r.y)<.003 then duplicate=true;break end
                end
                if not duplicate then self:Add(stage,r) end
            end
        end
    end
    stage.referenceCursor=cursor+8
    return stage.referenceCursor<=math.min(#rows,64)
end
-- Personal vendor/trainer records are useful to Insight after leaving a zone.
-- Publish their unchanged coordinates in the same provider, after current-map
-- facts. Map queries still select by map ID; item queries may search all maps.
function P:HistoricalServicesElsewhere(stage,mapID)
    stage.otherServices=stage.otherServices or {}
    local progress=stage.otherServices
    for _=1,32 do
        local key,r=next(self.account.services,progress.key)
        if not key then return false end
        progress.key=key
        if r.mapID~=mapID then
            local value=copy(r)
            value.availability="UNKNOWN"
            value.availabilityReason="Previously visited; current offerings and stock unknown"
            self:Add(stage,value)
        end
    end
    return true
end
function P:Refresh(mapID)
    if not self.initialized then self:Initialize() end
    if not M.state.clientAllowed or M.Storage.readOnly or self.readOnly or not M:Integer(mapID) then return false,self.status end
    if M:Combat() then self.invalidated=true;return false,"CATALOG_WAITING_FOR_COMBAT" end
    local now=M:Now()
    if self.mapID==mapID and not self.invalidated and self.lastAt and now>=self.lastAt and now-self.lastAt<30 then return true,self.status end
    local records,tasks=service("WorldRecords"),service("Tasks")
    if not records or not tasks then self.status="SHARED_SERVICES_UNAVAILABLE";return false,self.status end
    if self.token then records.CancelSnapshot(self.owner,self.token) end
    tasks.Cancel(self.owner)
    self.generation=self.generation+1;local generation=self.generation
    local observationRevision=self.observationRevision or 0
    self.mapID=mapID;self.lastAt=now;self.invalidated=false;self.status="SYNC_PENDING"
    local stage={rows={},seen={},omitted=0};local phase=1;local cursor=1
    local token,why=records.BeginSnapshot(self.owner,tostring(generation));if not token then self.invalidated=true;self.status=why;return false,why end
    self.token=token
    local queued,queueReason=tasks.Queue(self.owner,function()
        if generation~=P.generation then return false end
        if M:Combat() then records.CancelSnapshot(P.owner,token);P.token=nil;P.invalidated=true;P.status="CATALOG_WAITING_FOR_COMBAT";return false end
        -- Provider families run on separate frames; no global native state is
        -- altered to fetch facts. The final public snapshot is atomic.
        if phase==1 then if not P:NativePOIs(stage,mapID) then phase=2 end;return true end
        if phase==2 then if not P:NativeQuests(stage,mapID) then phase=3 end;return true end
        if phase==3 then if not P:Historical(stage,mapID) then P:Seeds(stage,mapID);phase=4 end;return true end
        -- Optional expansion records have last priority. They must not evict
        -- P7's cross-map vendor item history from a saturated shared snapshot.
        if phase==4 then if not P:HistoricalServicesElsewhere(stage,mapID) then phase=5 end;return true end
        if phase==5 then if not P:ServiceReferences(stage,mapID) then phase=6 end;return true end
        local batch={}
        for i=cursor,math.min(#stage.rows,cursor+31) do batch[#batch+1]=stage.rows[i] end
        if #batch>0 then
            local good,error=records.PutBatch(P.owner,token,batch)
            if not good then records.CancelSnapshot(P.owner,token);P.token=nil;P.invalidated=true;P.status=error;P:Diagnostics();return false end
            cursor=cursor+#batch;if cursor<=#stage.rows then return true end
        end
        P.committingToken=token
        local good,error=records.CommitSnapshot(P.owner,token)
        if P.committingToken==token then P.committingToken=nil end
        if P.token==token then P.token=nil end
        if generation~=P.generation then return false end
        if good then P.withdrawn=false;P.count=#stage.rows;P.omitted=stage.omitted;P.revision=P.revision+1
            P.publishedCounts={}
            for _,r in ipairs(stage.rows) do
                local key=r.source or "UNSPECIFIED";P.publishedCounts[key]=(P.publishedCounts[key] or 0)+1
            end
            P.publishedObservationRevision=observationRevision
            if observationRevision==(P.observationRevision or 0) then
                P.observationsDirty=false;P.observationsDirtyAt=nil;P.observationPublication="PUBLISHED"
            end
        else P.invalidated=true end
        P.status=good and (#stage.rows>0 and "READY" or "READY_EMPTY") or error
        P:Diagnostics();return false
    end,generation)
    if not queued then
        records.CancelSnapshot(self.owner,token);self.token=nil;self.invalidated=true
        self.status=queueReason or "CATALOG_QUEUE_REJECTED";self:Diagnostics()
        return false,self.status
    end
    return true,"SYNC_PENDING"
end
function P:TickObservations()
    local gossip=self.gossipStage
    if gossip and not self:GossipCurrent(gossip) and self.gossipStage==gossip then
        -- Native close events are normally sufficient, but a hidden/replaced
        -- window must not keep an AVAILABLE offer published indefinitely.
        self:CancelGossip("INTERACTION_CHANGED");self:Invalidate()
    end
    if not self.observationsDirty then return false,"OBSERVATIONS_CURRENT" end
    if not M.state.clientAllowed or M.Storage.readOnly or self.readOnly or not self.account then
        return false,"OBSERVATIONS_UNAVAILABLE"
    end
    if M:Combat() then self.observationPublication="WAITING_FOR_COMBAT";return false,self.observationPublication end
    if self.merchantStage then self.observationPublication="WAITING_FOR_MERCHANT_OBSERVATION";return false,self.observationPublication end
    if self.token then return false,"CATALOG_SYNC_PENDING" end
    local now=M:Now()
    if self.observationsDirtyAt and now>=self.observationsDirtyAt and now-self.observationsDirtyAt<.25 then
        return false,"OBSERVATIONS_COALESCING"
    end
    -- Keep an existing map consumer's context. On first use a service visit can
    -- publish without opening any map UI. No frame or native map is selected.
    local mapID=self.mapID
    if not M:Integer(mapID) then
        local player=M.map:Player();mapID=player and player.mapID or self.lastObservationMapID
    end
    if not M:Integer(mapID) then self.observationPublication="WAITING_FOR_MAP_CONTEXT";return false,self.observationPublication end
    local ok,why=self:Refresh(mapID)
    self.observationPublication=ok and "SYNC_PENDING" or why
    return ok,why
end
-- Quest-giver reads can trigger close/replacement callbacks just like merchant
-- reads. Keep live availability scoped to the exact interaction; historical
-- records remain intact when its window closes or the client becomes unreadable.
function P:CancelGossip(reason)
    self.gossipGeneration=(self.gossipGeneration or 0)+1
    self.gossipStage=nil;self.liveOffers=nil;self.gossipStatus=reason or "CANCELLED"
end
function P:GossipCurrent(stage)
    if not stage or self.gossipStage~=stage or stage.generation~=self.gossipGeneration or
        not M.state.clientAllowed or M.Storage.readOnly or self.readOnly or M:Combat() or
        self.character~=stage.character or self.character.offers~=stage.offers then return false end
    local guid,ok=M:Call(UnitGUID,"npc")
    if not ok or guid~=stage.guid then return false end
    if stage.frame then
        if GossipFrame~=stage.frame then return false end
        local shown,visible=M:Call(stage.frame.IsShown,stage.frame)
        if not visible or shown~=true then return false end
    end
    return self.gossipStage==stage and stage.generation==self.gossipGeneration and
        M.state.clientAllowed and not M.Storage.readOnly and not self.readOnly and not M:Combat() and
        self.character==stage.character and self.character.offers==stage.offers
end
function P:Store(bucket,r,scope)
    if self.readOnly or not safeRecord(r) then return false end
    if not bucket[r.id] and rowsize(bucket)>=self.maxObserved then
        local oldestID,oldest
        for id,row in pairs(bucket) do if not oldest or (row.observedAt or 0)<oldest then oldestID=id;oldest=row.observedAt or 0 end end
        if oldestID then bucket[oldestID]=nil end
    end
    bucket[r.id]=r
    local db=scope=="character" and self.character or self.account
    db.revision=db.revision+1
    self.observationRevision=(self.observationRevision or 0)+1
    self.observationsDirty=true;self.observationsDirtyAt=M:Now();self.lastObservationMapID=r.mapID
    self.observationPublication="OBSERVATIONS_DIRTY"
    self:Invalidate();return true
end
function P:Interaction(category)
    local player=M.map:Player();if not player then return nil end
    local name=M:Call(UnitName,"npc");local guid=M:Call(UnitGUID,"npc")
    if not M:Text(name,100) or not M:Text(guid,128) then return nil end
    local npcID=guid:match("^Creature%-%d+%-%d+%-%d+%-%d+%-(%d+)%-")
    if not npcID then return nil end
    -- A player interaction position is approximate and not the NPC's center.
    local id="serviceobs:"..player.mapID..":"..npcID..":"..math.floor(player.x*500)..":"..math.floor(player.y*500)
    local r=self:Base(id,player.mapID,player.x,player.y,name,"service",category,"LOCAL_SERVICE_OBSERVATION")
    if not r then return nil end
    r.sourceLabel="Your NPC interaction";r.sourceURL=nativeURL;r.confidence="OBSERVED_SERVICE"
    r.precision="APPROXIMATE_PLAYER_INTERACTION_POSITION";r.observedAt=M:When();r.npcID=tonumber(npcID)
    r.serviceRoles=category;r.availabilityReason="Previously visited; current offerings unknown"
    r.details="Location is where you interacted, not a measured NPC position."
    local faction=M:Call(UnitFactionGroup,"player")
    if faction=="Alliance" or faction=="Horde" then r.observedByFaction=faction end
    return r
end
-- Merchant items are observation-only base-item associations. They supply
-- Insight's recorded source index; they never quote price or imply live stock.
-- Read and verify bounded slices from the same open NPC interaction. A close,
-- update, identity replacement or combat transition cancels the staged result.
local merchantOwner="MirageIntel_MapMerchantObservation"
local function merchantLink(index)
    local link,ok=M:Call(GetMerchantItemLink,index)
    if not ok or type(link)~="string" or not M:Readable(link) or #link>4096 then return nil end
    if not link:find("|Hitem:",1,true) and not link:match("^item:") then return nil end
    return link
end
local function merchantItemID(link)
    if not link then return nil end
    local id,ok=M:Call(C_Item and C_Item.GetItemIDForItemInfo,link)
    if not ok or not M:Integer(id) then
        id=tonumber(link:match("|Hitem:(%d+)") or link:match("^item:(%d+)"))
    end
    return M:Integer(id) and id<=2147483647 and id or nil
end
function P:CancelMerchant(reason)
    self.merchantGeneration=(self.merchantGeneration or 0)+1
    self.merchantStage=nil;self.merchantStatus=reason or "CANCELLED"
    local tasks=service("Tasks");if tasks then tasks.Cancel(merchantOwner) end
end
function P:MerchantCurrent(stage)
    if not stage or self.merchantStage~=stage or stage.generation~=self.merchantGeneration or
       self.merchantActive~=true or self.merchantGUID~=stage.guid or not M.state.clientAllowed or M.Storage.readOnly or self.readOnly or M:Combat() then return false end
    if self.account~=stage.account or self.account.services~=stage.services then return false end
    local guid,ok=M:Call(UnitGUID,"npc")
    if not ok or guid~=stage.guid then return false end
    local count,read=M:Call(GetMerchantNumItems)
    if not read or count~=stage.count then return false end
    if stage.frame then
        if MerchantFrame~=stage.frame then return false end
        local shown,visible=M:Call(stage.frame.IsShown,stage.frame)
        if not visible or shown~=true then return false end
    end
    return self.merchantStage==stage and stage.generation==self.merchantGeneration
end
function P:ObserveMerchant(record)
    self:CancelMerchant("PREPARING_OBSERVATION")
    if not record or not self.merchantActive or self.readOnly or M.Storage.readOnly or not self.account or M:Combat() then return false end
    local generation=self.merchantGeneration
    local tasks=service("Tasks")
    local count,ok=M:Call(GetMerchantNumItems)
    local guid,known=M:Call(UnitGUID,"npc")
    if self.merchantGeneration~=generation or not self.merchantActive then return false end
    local npcID=known and M:Text(guid,128) and tonumber(guid:match("^Creature%-%d+%-%d+%-%d+%-%d+%-(%d+)%-"))
    if not tasks or not ok or not M:Number(count) or count<0 or count%1~=0 or count>4096 or
       not npcID or npcID~=record.npcID or guid~=self.merchantGUID then self.merchantStatus="ITEM_LIST_UNAVAILABLE";return false end
    local stage={generation=generation,guid=guid,count=count,limit=math.min(count,256),
        cursor=1,verify=1,links={},ids={},seen={},missing=0,record=copy(record),
        account=self.account,services=self.account.services}
    if MerchantFrame and type(MerchantFrame.IsShown)=="function" then stage.frame=MerchantFrame end
    self.merchantStage=stage
    if not self:MerchantCurrent(stage) then
        if self.merchantStage==stage then self:CancelMerchant("INTERACTION_CHANGED") end
        return false
    end
    self.merchantStatus="OBSERVATION_PENDING"
    local queued=tasks.Queue(merchantOwner,function()
        local function abort(reason)
            -- A native getter can synchronously trigger a replacement event.
            -- An obsolete slice must never cancel the newer observation.
            if P.merchantStage==stage then P:CancelMerchant(reason) end
            return false
        end
        if not P:MerchantCurrent(stage) then
            return abort("INTERACTION_CHANGED")
        end
        local cursor=stage.cursor<=stage.limit and "cursor" or "verify"
        local start=M:Call(debugprofilestop)
        for _=1,8 do
            local index=stage[cursor]
            if index>stage.limit then break end
            local link=merchantLink(index)
            if cursor=="cursor" then
                local id=merchantItemID(link)
                if merchantLink(index)~=link then return abort("ITEM_LIST_CHANGED") end
                stage.links[index]=link or false
                if id and not stage.seen[id] then stage.seen[id]=true;stage.ids[#stage.ids+1]=id
                elseif not id then stage.missing=stage.missing+1 end
            elseif (link or false)~=stage.links[index] then
                return abort("ITEM_LIST_CHANGED")
            end
            if not P:MerchantCurrent(stage) then
                return abort("INTERACTION_CHANGED")
            end
            stage[cursor]=index+1
            local elapsed=M:Call(debugprofilestop)
            if M:Number(start) and M:Number(elapsed) and elapsed-start>=.5 then break end
        end
        if stage.cursor<=stage.limit or stage.verify<=stage.limit then return true end
        if not P:MerchantCurrent(stage) then return abort("INTERACTION_CHANGED") end
        -- A temporarily unreadable list never erases an earlier observation.
        if #stage.ids==0 then P.merchantStage=nil;P.merchantStatus="NO_READABLE_ITEM_ASSOCIATIONS";return false end
        table.sort(stage.ids)
        local r=copy(stage.record)
        r.soldItemIDs={}
        for i=1,math.min(32,#stage.ids) do r.soldItemIDs[i]=stage.ids[i] end
        r.observedCatalogCount=stage.count;r.itemAssociationsObservedAt=M:When()
        r.itemAssociationCoverage=(stage.count>256 or #stage.ids>32 or stage.missing>0) and "PARTIAL_VISIBLE_ITEMS" or "VISIBLE_ITEMS_OBSERVED"
        r.itemAssociationsOmitted=math.max(0,#stage.ids-32)+math.max(0,stage.count-stage.limit)+stage.missing
        r.stock="CURRENT_STOCK_UNKNOWN"
        r.details="Visited vendor; item associations are a historical visible-list observation. Current stock and prices are unknown."
        if not P:MerchantCurrent(stage) then return abort("INTERACTION_CHANGED") end
        P.merchantStage=nil
        if P:Store(P.account.services,r) then
            P.merchantStatus="ITEM_ASSOCIATIONS_RECORDED";P.sourceStates.merchantItems="HISTORICAL_VISIBLE_LIST_OBSERVATION"
        else P.merchantStatus="OBSERVATION_STORAGE_REJECTED" end
        return false
    end,stage.generation)
    if not queued and self.merchantStage==stage then self.merchantStage=nil;self.merchantStatus="OBSERVATION_QUEUE_UNAVAILABLE" end
    return queued==true
end
function P:Observe(event)
    if not self.initialized then self:Initialize() end
    local gossipGeneration
    if event=="GOSSIP_SHOW" then
        self:CancelGossip("PREPARING_OBSERVATION");gossipGeneration=self.gossipGeneration
        self:Invalidate()
    elseif event=="GOSSIP_CLOSED" or event=="QUEST_FINISHED" or event=="PLAYER_REGEN_DISABLED" or
        event=="PLAYER_ENTERING_WORLD" or event=="ZONE_CHANGED_NEW_AREA" or event=="MERCHANT_SHOW" or
        event=="TRAINER_SHOW" or event=="BANKFRAME_OPENED" or event=="TAXIMAP_OPENED" then
        local hadGossip=self.gossipStage or self.liveOffers
        self:CancelGossip(event)
        if hadGossip then self:Invalidate() end
    end
    local openingGeneration
    if event=="MERCHANT_SHOW" then
        self.merchantActive=false;self:CancelMerchant("NEW_MERCHANT_INTERACTION")
        openingGeneration=self.merchantGeneration
        local guid=M:Call(UnitGUID,"npc")
        if self.merchantGeneration~=openingGeneration then return end
        self.merchantGUID=guid;self.merchantRecord=nil
    elseif event=="MERCHANT_CLOSED" or event=="PLAYER_REGEN_DISABLED" or event=="PLAYER_ENTERING_WORLD" or
           event=="TRAINER_SHOW" or event=="BANKFRAME_OPENED" or event=="GOSSIP_SHOW" then
        self.merchantActive=false;self.merchantGUID=nil;self.merchantRecord=nil;self:CancelMerchant(event)
    elseif event=="MERCHANT_UPDATE" then
        if self.merchantActive then
            local r=self.merchantRecord
            local generation=self.merchantGeneration
            local guid,read=M:Call(UnitGUID,"npc")
            if generation~=self.merchantGeneration then return end
            if r and read and guid==self.merchantGUID then
                local old=self.account and self.account.services[r.id]
                if old then r=copy(old) end
                self:ObserveMerchant(r)
            else self.merchantActive=false;self:CancelMerchant("INTERACTION_UNAVAILABLE") end
        end
        return
    end
    if event=="GOSSIP_CLOSED" or event=="QUEST_FINISHED" then self:Invalidate();return end
    if not M.state.clientAllowed or M.Storage.readOnly or self.readOnly or not self.account then return end
    if M:Combat() then self:Invalidate();return end
    if event=="MERCHANT_SHOW" or event=="TRAINER_SHOW" or event=="BANKFRAME_OPENED" then
        local category=event=="MERCHANT_SHOW" and "goods" or event=="TRAINER_SHOW" and "trainer" or "bank"
        local r=self:Interaction(category)
        if openingGeneration and openingGeneration~=self.merchantGeneration then return end
        if r then
            if event=="MERCHANT_SHOW" then
                local repairs=boolean(C_MerchantFrame and C_MerchantFrame.CanMerchantRepair or CanMerchantRepair)
                if repairs then r.category="repair";r.serviceRoles="goods,repair" end
                r.stock="NOT_OBSERVED"
            elseif event=="TRAINER_SHOW" then
                r.availabilityReason="Trainer visited; current learnable offerings unknown"
                local _,_,_,classID=M:Call(UnitClass,"player")
                if M:Integer(classID) then r.observedByClassID=classID end
            end
            -- Multiple roles from the same observation share one record.
            local old=self.account.services[r.id]
            if old and M:Text(old.serviceRoles,160) then
                local combined,known={},{}
                for role in (old.serviceRoles..","..r.serviceRoles):gmatch("[^,]+") do
                    if not known[role] then combined[#combined+1]=role;known[role]=true end
                end
                r.serviceRoles=table.concat(combined,",")
            end
            if old and old.soldItemIDs then
                r.soldItemIDs=copy(old.soldItemIDs);r.itemAssociationCoverage=old.itemAssociationCoverage
                r.itemAssociationsObservedAt=old.itemAssociationsObservedAt;r.itemAssociationsOmitted=old.itemAssociationsOmitted
                r.observedCatalogCount=old.observedCatalogCount
            end
            if openingGeneration and openingGeneration~=self.merchantGeneration then return end
            self:Store(self.account.services,r)
            if event=="MERCHANT_SHOW" and openingGeneration==self.merchantGeneration then
                self.merchantRecord=copy(r);self.merchantActive=true;self:ObserveMerchant(r)
            end
        end
    elseif event=="GOSSIP_SHOW" then
        if gossipGeneration~=self.gossipGeneration then return end
        local guid,known=M:Call(UnitGUID,"npc")
        if gossipGeneration~=self.gossipGeneration then return end
        if not known or not M:Text(guid,128) then self.gossipStatus="INTERACTION_UNAVAILABLE";return end
        local stage={generation=gossipGeneration,guid=guid,character=self.character,offers=self.character.offers}
        if GossipFrame and type(GossipFrame.IsShown)=="function" then stage.frame=GossipFrame end
        self.gossipStage=stage
        local location=self:Interaction("quest-giver")
        local npcID=tonumber(guid:match("^Creature%-%d+%-%d+%-%d+%-%d+%-(%d+)%-"))
        local function current()
            if self:GossipCurrent(stage) then return true end
            if self.gossipStage==stage then self:CancelGossip("INTERACTION_CHANGED") end
            return false
        end
        if not location or location.npcID~=npcID then
            if self.gossipStage==stage then self:CancelGossip("INTERACTION_UNAVAILABLE") end
            return
        end
        if current() then
            local rows,read=list(C_GossipInfo and C_GossipInfo.GetAvailableQuests)
            if not current() then return end
            self.sourceStates.availableQuests=read and "INTERACTION_OBSERVED" or "UNAVAILABLE"
            self.gossipStatus=read and "OFFERS_OBSERVED" or "OFFER_LIST_UNAVAILABLE"
            self.liveOffers={}
            for i,row in ipairs(rows) do
                if i>64 then break end
                local id=field(row,"questID");local title=field(row,"title")
                if M:Integer(id) and M:Text(title,160) then
                    local r=self:Base("questoffer:"..location.mapID..":"..location.npcID..":"..id,
                        location.mapID,location.x,location.y,title,"quest","available","LOCAL_QUEST_OFFER")
                    if not r or not current() then return end
                    r.questID=id;r.npcID=location.npcID;r.sourceLabel="Your quest-giver interaction"
                    r.precision=location.precision;r.observedAt=M:When();r.confidence="OFFER_OBSERVED"
                    r.stage="OFFER";r.autoRecommend=false;r.prerequisites="UNKNOWN"
                    local repeatable=field(row,"repeatable")
                    r.repeatability=repeatable==true and "REPEATABLE" or repeatable==false and "NONREPEATABLE_OBSERVED" or "UNKNOWN"
                    local level=field(row,"questLevel");if M:Integer(level) then r.questLevel=level end
                    r.details="Observed offer. Availability is rechecked only during a fresh NPC interaction."
                    if not current() then return end
                    self:Store(self.character.offers,r,"character")
                    if not current() then return end
                    self.liveOffers[r.id]=true
                end
            end
        end
    elseif event=="TAXIMAP_OPENED" then
        local mapID,read=M:Call(GetTaxiMapID)
        local rows,ok=list(C_TaxiMap and C_TaxiMap.GetAllTaxiNodes,mapID)
        self.sourceStates.flights=read and ok and "FLIGHT_MASTER_OBSERVED" or "UNAVAILABLE"
        if not read or not M:Integer(mapID) then return end
        local states=Enum and Enum.FlightPathState
        for i,row in ipairs(rows) do
            if i>256 then break end
            local id=field(row,"nodeID");local x,y=position(row)
            if M:Integer(id) and field(row,"isMapLayerTransition")~=true then
                local r=self:Base("taxiobs:"..id..":"..mapID,mapID,x,y,field(row,"name"),"flight","flight","NATIVE_TAXI_OBSERVATION")
                if r then
                    local state=field(row,"state");r.sourceLabel="Your flight-master map"
                    r.observedAt=M:When();r.nodeID=id;r.learned="UNKNOWN";r.reachable="UNKNOWN"
                    r.serviceRoles="flight";r.precision="NATIVE_TAXI_MAP_POINT"
                    if states and (state==states.Current or state==states.Reachable) then
                        r.learned="OBSERVED_KNOWN";r.availability="KNOWN"
                        r.reachable=state==states.Current and "CURRENT_AT_OBSERVATION" or "REACHABLE_AT_OBSERVATION"
                        r.availabilityReason="Seen usable at a flight master; connectivity may change"
                    else r.availabilityReason="Unreachable at this master does not prove undiscovered" end
                    self:Store(self.character.flights,r,"character")
                end
            end
        end
    else self:Invalidate() end
end
