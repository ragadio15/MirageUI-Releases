local _,M=...
local frame=CreateFrame("Frame")
M.eventFrame=frame
local function attach()
    local ok=pcall(M.Canvas.Attach,M.Canvas)
    if not ok then M:Fault("MAP_ATTACH_FAILED");M.Canvas:HideAll() end
end
local eventNames={"ADDON_LOADED","PLAYER_ENTERING_WORLD","PLAYER_REGEN_ENABLED",
    "PLAYER_REGEN_DISABLED","ZONE_CHANGED_NEW_AREA","USER_WAYPOINT_UPDATED","UI_SCALE_CHANGED","DISPLAY_SIZE_CHANGED",
    "MERCHANT_SHOW","MERCHANT_UPDATE","MERCHANT_CLOSED","TRAINER_SHOW","BANKFRAME_OPENED","GOSSIP_SHOW","GOSSIP_CLOSED","QUEST_FINISHED",
    "TAXIMAP_OPENED","QUEST_LOG_UPDATE","QUEST_POI_UPDATE","AREA_POIS_UPDATED","TAXI_NODE_STATUS_CHANGED",
    "PLAYER_LEVEL_UP","SKILL_LINES_CHANGED","MAP_EXPLORATION_UPDATED"}
for _,event in ipairs(eventNames) do pcall(frame.RegisterEvent,frame,event) end
frame:SetScript("OnEvent",function(_,event,addon)
    if event=="ADDON_LOADED" then
        if addon==M.addonName then
            local ok=pcall(M.Initialize,M)
            if not ok then M:Fault("MAP_INITIALIZATION_FAILED");M.state.status="INITIALIZATION_FAILED" end
        elseif M.state.initialized then
            M.Canvas:Dirty()
            if addon=="Blizzard_WorldMap" or addon=="Blizzard_WorldMapFrame" then attach() end
        end
        return
    end
    if not M.state.initialized then return end
    M.state.events=M.state.events+1
    if M.Catalog then M.Catalog:Observe(event) end
    if event=="ZONE_CHANGED_NEW_AREA" or event=="PLAYER_ENTERING_WORLD" or event=="PLAYER_LEVEL_UP" or event=="SKILL_LINES_CHANGED" then
        if M.Catalog then M.Catalog:Invalidate() end
        if M.RecordQuery then M.RecordQuery:Invalidate() end
    end
    if event=="PLAYER_REGEN_DISABLED" then
        M.Canvas:HideAll()
        if M.Panel and M.Panel.choiceMenu then M.Panel.choiceMenu:Hide() end
        if M.Explorer and M.Panel then M.Explorer:CancelDistance(M.Panel) end
        return
    end
    if event=="PLAYER_REGEN_ENABLED" then attach() end
    if (event=="UI_SCALE_CHANGED" or event=="DISPLAY_SIZE_CHANGED" or event=="PLAYER_REGEN_ENABLED") and not M:Combat() then M.Panel:Fit() end
    M.Canvas:Dirty()
    if M.Panel then M.Panel.dirty=true end
end)
frame:SetScript("OnUpdate",function(_,dt)
    if M.state.initialized then M.Canvas:Tick(dt) end
end)
