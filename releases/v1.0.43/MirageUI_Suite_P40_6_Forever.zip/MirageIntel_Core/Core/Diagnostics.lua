local _,C=...
local states={}
local function owner(v) return C.Text(v) and #v>0 and #v<=64 and v:match("^[%w_%-]+$") end
local D={apiVersion=1}
function D.Set(id,value)
    if not owner(id) or not C.Readable(value) or type(value)~="table" then return false,"BAD_DIAGNOSTIC" end
    local result,valid=C.Sanitize(value)
    if not valid then return false,"BAD_DIAGNOSTIC" end
    if not states[id] then
        local count=0;for _ in pairs(states) do count=count+1 end
        if count>=32 then return false,"OWNER_LIMIT" end
    end
    states[id]={observedAt=C:Now(),state=result};return true
end
function D.Get(id)
    if id~=nil then return owner(id) and C.Copy(states[id]) or nil end
    return C.Copy(states)
end
-- A small, cached support view for the suite's ordinary export. It deliberately
-- does not call Probe, refresh a provider, enumerate history or copy identities.
local supportFields={"status","version","initialized","clientAllowed","errors","lastError",
    "mode","registered","hookStrategy","hookFailures","activeContexts","captures","captureAttempts","prepared","surfacePasses",
    "lastCaptureReason","lastRenderReason","lastPresentationReason",
    "scanCount","scanPending","recipeCount","professionCount","automatic",
    "navigationRevision","destinationPresent","destinationKind","kind","selectionTier","renderer","routeStopCount","guidanceStatus","guidanceSamples",
    "running","managed","source","reason","revision","guidance",
    "mapPins","gatherPins","routeSegments","zoneCard","iconSize","nativeIconSize","pins","route","shape","radius","historyStatus",
    "historyQueries","paintPasses","idlePaints","publication","published","frameReady",
    "queued","active","capacity","continued","queueFull","ownerLimit","peakQueued","failed"}
local function supportScalar(value)
    if not C.Readable(value) then return nil end
    if type(value)=="boolean" then return value end
    if C.Number(value) and math.abs(value)<=1e12 then return value end
    if C.Text(value) and #value<=80 and value:match("^[%w_%.%-]+$") then return value end
    return nil
end
local function supportRow(value)
    local result={}
    if not C.Readable(value) or type(value)~="table" then return {status="UNAVAILABLE"} end
    for _,key in ipairs(supportFields) do
        local ok,v=pcall(function()return value[key]end)
        if ok then result[key]=supportScalar(v) end
    end
    return result
end
function D.GetSupportSummary()
    local out={release=C.Release and C.Release.id or "UNKNOWN",core=supportRow({version=C.version,
        initialized=C.state.initialized,status=C.state.status,clientAllowed=C.Client and C.Client.allowed,
        errors=C.state.errors,lastError=C.state.lastError})}
    -- Queue pressure belongs in the same bounded support export as the
    -- consumers it serves. This reads counters only, without native probing
    -- or retaining callback/owner identities.
    local scheduler=C.Scheduler
    if scheduler and type(scheduler.Status)=="function" then
        local ok,queue=pcall(scheduler.Status,scheduler)
        if ok and type(queue)=="table" then
            local metrics=type(queue.metrics)=="table" and queue.metrics or {}
            out.tasks=supportRow({queued=queue.queued,active=queue.active,capacity=queue.capacity,running=queue.running,
                continued=metrics.continued,queueFull=metrics.queueFull,ownerLimit=metrics.ownerLimit,
                peakQueued=metrics.peakQueued,failed=metrics.failed})
        else out.tasks={status="STATUS_UNAVAILABLE"} end
    else out.tasks={status="NOT_INITIALIZED"} end
    local mini=C.MinimapPins or {}
    out.minimap=supportRow({status=mini.status or "NOT_INITIALIZED",pins=mini.visibleSites or 0,
        route=mini.routeShown==true,routeSegments=mini.routeLineCount or 0,shape=mini.shape,radius=mini.radius,
        historyStatus=mini.historyStatus,historyQueries=mini.historyQueries or 0,
        paintPasses=mini.paintPasses or 0,idlePaints=mini.idlePaints or 0,scanPending=mini.scanPending==true,
        frameReady=mini.frame~=nil})
    for _,entry in ipairs({{"map","MapAddon"},{"insight","Insight"},{"navigation","Navigate"}}) do
        local api=C.Services:Get(entry[2],1)
        if not api then out[entry[1]]={status="NOT_LOADED"}
        elseif type(api.GetSupportStatus)~="function" then out[entry[1]]={status="STATUS_UNAVAILABLE"}
        else
            local ok,data=pcall(api.GetSupportStatus)
            out[entry[1]]=ok and supportRow(data) or {status="STATUS_UNAVAILABLE"}
        end
    end
    local gather=states.MirageIntel_Gather
    out.gather=gather and supportRow(gather.state) or {status=C.Services:Get("Gather",1) and "STARTING" or "NOT_LOADED"}
    local cursor=_G.MirageUICursorNavBridge
    if C.Readable(cursor) and type(cursor)=="table" and type(cursor.GetSupportStatus)=="function" then
        local ok,value=pcall(cursor.GetSupportStatus)
        out.cursor=ok and supportRow(value) or {status="STATUS_UNAVAILABLE"}
    else out.cursor={status="NOT_LOADED"} end
    return out
end
function C.Public.GetUtilitySupport() return D.GetSupportSummary() end
local function method(t,name) return type(t)=="table" and type(t[name])=="function" end
function D.Probe()
    local geometry
    if C.Client.allowed then
        local value,ok=C.Call(C.Map.Player,C.Map)
        geometry=ok and C.Copy(value) or nil
    end
    local radius,radiusOK=C.Call(type(C_Minimap)=="table" and C_Minimap.GetViewRadius)
    local release=C.Release and C.Release.id
    if not C.Text(release) or release=="" then release="UNKNOWN" end
    return {schemaVersion=1,release=release,client=C.Copy(C.Client),
        sourceCandidate=C.Client.sourceMatched==true,nativeAcceptance="NOT_RUN",performanceAcceptance="NOT_RUN",
        storage=C.Storage:Diagnostics(),playerGeometry=geometry,
        api={minimapRadius=radiusOK and C.Number(radius) and radius>0 and radius or "UNAVAILABLE",
            questWaypoint=method(C_QuestLog,"GetNextWaypoint"),
            questWaypointForMap=method(C_QuestLog,"GetNextWaypointForMap"),
            questCompletion=method(C_QuestLog,"IsComplete"),
            skillLine=method(C_SkillInfo,"GetSkillLineInfoByID"),
            tooltipData=method(C_TooltipInfo,"GetItemByID")},
        runtime=C.Copy(C.state),tasks=C.Scheduler:Status(),components=D.Get(),
        modules=C.Public.GetModules(),services=C.Commands and C.Commands:ModuleStatus(),
        performance=C.Performance and C.Performance:GetStatus()}
end
C.Diagnostics=D
C.Services:Register("Diagnostics","MirageIntel_Core",1,D)
local T={apiVersion=1}
function T.Queue(id,callback,generation)
    if not C.Client.allowed then return false,"UNSUPPORTED_CLIENT" end
    return C.Scheduler:Queue(id,callback,generation)
end
function T.Cancel(id) return C.Scheduler:Cancel(id) end
function T.GetStatus() return C.Scheduler:Status() end
C.Services:Register("Tasks","MirageIntel_Core",1,T)
