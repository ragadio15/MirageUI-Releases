local _,C=...
-- Payload digest covers sorted relative paths and their SHA-256, excluding this receipt.
C.Release={phase="P40_6_NATIVE_WORLD_NAMES",id="P40.6-71091-1.0.43-rc.12",
    qualification="RUNTIME_API_GUARDED",nativeAcceptance="NOT_RUN",
    payloadSHA256="077e39796e3f117e1c865b5932eec963c15dbe79d08034cc279c1dc3f80cea52"}
