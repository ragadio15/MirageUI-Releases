local _,CC=...
CC.Migrations={}
function CC.Migrations:Legacy(legacy)
 local p=CC:Copy(CC.Defaults)
 if type(legacy)~="table" then return p end
 for _,k in ipairs({"enabled","offsetX","offsetY","idleHideSeconds","hideOnMouseDown"}) do
  if type(legacy[k])==type(p[k]) then p[k]=legacy[k] end
 end
 local r=p.rings.outer
 for _,k in ipairs({"size","opacity","theme","glow"}) do if type(legacy[k])==type(r[k]) then r[k]=legacy[k] end end
 if legacy.shape=="Ring" or legacy.shape=="Segments" then r.style=legacy.shape end
 if type(legacy.theme)=="string" and CC.Themes[legacy.theme] then
  local rgb=CC.Themes[legacy.theme];r.r,r.g,r.b=rgb[1],rgb[2],rgb[3];r.colorMode="Manual"
 end
 return p
end
function CC.Migrations:Prepare(v1,c1,flavor)
 -- Pure preparation. Existing v1 tables are never mutated, even on malformed input.
 local a,c={schema=2,flavors={},evidence={}},{schema=2,useCharacter=false,flavor=flavor}
 local old=type(v1)=="table" and v1.schema==1 and type(v1.flavors)=="table" and v1.flavors[flavor]
 a.flavors[flavor]={profile=self:Legacy(type(old)=="table" and old.profile),migration=old and "V1_COPIED" or "DEFAULTS"}
 if type(c1)=="table" and c1.schema==1 and c1.flavor==flavor and c1.useCharacter==true then
  c.useCharacter=true; c.profile=self:Legacy(c1.profile)
 end
 return a,c
end

-- Converts obsolete theme choices to explicit color values and seeds the spell list.
-- This works on a copy: legacy roots and unknown future schemas are never rewritten here.
function CC.Migrations:Usability(input)
 if type(input)~="table" then return input end
 local p=CC:Copy(input)
 -- v2.6.9 used one pointer scale for both dimensions. Preserve its apparent
 -- size when introducing independent width/height sliders in v2.6.9.
 if type(p.compass)=="table" then
  local c=p.compass
  local old=c.pointerScale
  if type(old)=="number" and CC.Safety:IsNumber(old) and old>=1 and old<=1.6 then
   if c.pointerWidth==nil then c.pointerWidth=old end
   if c.pointerHeight==nil then c.pointerHeight=old end
  end
  c.pointerScale=nil
 end
 local function color(r)
  if type(r)~="table" then return end
  if r.colorMode=="Theme" then
   local rgb=CC.Themes[r.theme] or CC.Themes.Neutral
   r.r,r.g,r.b=rgb[1],rgb[2],rgb[3];r.colorMode="Manual"
  end
 end
 if type(p.rings)=="table" then color(p.rings.outer);color(p.rings.inner);color(p.rings.outer2) end
 -- The v2.6.3 compass used the ordinary Outer Ring 2 display and forced
 -- its enabled state. Migrate it to the standalone compass without touching
 -- outer/inner functions, spell choices, rotation or visual preferences.
 if type(p.rings)=="table" and type(p.rings.outer2)=="table" then
  local old=p.rings.outer2
  if old.questCompass==true and (type(p.compass)~="table" or p.compass._legacyImport==true) then
   local compass=CC:Copy(CC.Defaults.compass)
   for _,key in ipairs({"style","size","stroke","opacity","colorMode","r","g","b","glow"}) do
    if type(old[key])==type(compass[key]) then compass[key]=old[key] end
   end
   compass.enabled=true;p.compass=compass;old.enabled=false
   if CC.QuestCompassStyleSet[old.style] then old.style="Ring" end
  end
  old.questCompass=nil
 end
 if type(p.compass)=="table" then p.compass._legacyImport=nil end
 color(p.motion)
 if type(p.info)=="table" and type(p.info.tracked)~="table" then
  local rows,seen={},{}
  local function add(v)
   if type(v)=="string" then v=v:match("^%s*(.-)%s*$")
    if v~="" and not seen[v] and #rows<8 then rows[#rows+1]=v;seen[v]=true end
   end
  end
  add(p.info.reference)
  if type(p.info.probes)=="string" then for v in p.info.probes:gmatch("[^,]+") do add(v) end end
  p.info.tracked=#rows>0 and rows or {""}
 end
 -- v2.7.1 adds independently selected enemy-menu options and four formerly
 -- mandatory general shortcuts. Mirror legacy shared preferences on first
 -- upgrade; do not overwrite any explicit v2.7.1 selection.
 if type(p.palette)=="table" then
  local v=p.palette
  local enemy={enemyFocus="focus",enemyInspect="inspect",enemyPing="ping",enemyMark="mark"}
  for newKey,legacyKey in pairs(enemy) do
   if v[newKey]==nil and type(v[legacyKey])=="boolean" then v[newKey]=v[legacyKey] end
  end
 end
 -- Drop retired standalone HUD and aura-orb fields on the copied profile only.
 -- Native Health and Resource ring role choices remain untouched.
 p.bars=nil;p.crescents=nil;p.orbs=nil
 -- UX04 removes classification roles, all cursor annotations and the global
 -- motion override. Preserve the effective still appearance of old reduced profiles.
 if type(p.motion)=="table" then
  if p.motion.reduced==true then
   p.motion.enabled=false
   if type(p.rings)=="table" then
    for _,key in ipairs({"outer","inner","outer2"}) do
     if type(p.rings[key])=="table" then p.rings[key].speed=0 end
    end
   end
  end
  p.motion.reduced=nil
 end
 if type(p.rings)=="table" then
  for _,key in ipairs({"outer","inner","outer2"}) do
   if type(p.rings[key])=="table" and p.rings[key].role=="Classification" then
    p.rings[key].role="Decorative"
   end
  end
 end
 if type(p.info)=="table" then
  for _,key in ipairs({"label","labelX","labelY","labelSize","showUnknown",
    "informationIdle","classificationAccent","levelGap","levelThreshold"}) do p.info[key]=nil end
 end
 if CC.MenuModel then CC.MenuModel:Migrate(p) end
 return p
end
