-- Shared, dependency-free compatibility notice. Identical copies in each
-- independent suite root join one broker; optional addons never create a stack
-- of duplicate dialogs. Source review is diagnostic, not runtime permission.
local addonName,namespace=...
local broker=_G.MirageSuiteCompatibility
if type(broker)~="table" or broker.protocol~=18 then
 broker={protocol=18,members={},seen={},pending=false,world=false,events={},failures={},attempts=0}
 _G.MirageSuiteCompatibility=broker
 local B=broker
 local addons={"MirageUI","MirageUIOptions","CursorCompanion","MirageUISanctuary","Wealthcraft",
  "MirageIntel_Core","MirageIntel_Map","MirageIntel_Navigate","MirageIntel_Gather","MirageIntel_Insight"}
 local reviewed={['70862']=true,['70888']=true,['70938']=true,['70959']=true,['71037']=true}
 local function readable(v)
  if type(issecretvalue)=="function" then local ok,x=pcall(issecretvalue,v);if not ok or x~=false then return false end end
  if type(canaccessvalue)=="function" then local ok,x=pcall(canaccessvalue,v);if not ok or x~=true then return false end end
  return true
 end
 local function text(v,limit)
  return readable(v) and type(v)=="string" and #v<=(limit or 512) and v or nil
 end
 local function value(v)
  if not readable(v) then return "RESTRICTED" end
  if type(v)=="boolean" then return v and "true" or "false" end
  if type(v)=="number" and v==v and v<math.huge and v>-math.huge then return tostring(v) end
  if text(v,256) then return v:gsub("[\r\n|]"," ") end
  return "UNKNOWN"
 end
 local function call(fn,...)
  if type(fn)~="function" then return nil,false end
  local ok,a,b,c,d=pcall(fn,...)
  if not ok or not readable(a) or not readable(b) or not readable(c) or not readable(d) then return nil,false end
  return a,true,b,c,d
 end
 local function combat()
  local locked,ok=call(InCombatLockdown)
  return not ok or locked~=false
 end
 local function number(fn,object,fallback)
  local n,ok=call(fn,object)
  return ok and type(n)=="number" and n==n and n>0 and n<100000 and n or fallback
 end
 local APIs={"CreateFrame","GetBuildInfo","issecretvalue","canaccessvalue","InCombatLockdown","RegisterStateDriver","RegisterUnitWatch","hooksecurefunc",
  "UnitCastingDuration","UnitChannelDuration","UnitHealthPercent","UnitPowerPercent","UnitHealth","UnitPower","GetCursorPosition",
  "C_Spell.GetSpellCooldown","C_Spell.GetSpellCooldownDuration","C_Spell.GetSpellInfo","C_ActionBar.GetActionCooldown",
  "C_UnitAuras.GetAuraDataByIndex","C_NamePlate.GetNamePlates","C_NamePlate.GetNamePlateForUnit",
  "C_Map.GetBestMapForUnit","C_Map.GetPlayerMapPosition","C_Map.GetWorldPosFromMapPos","C_Map.GetUserWaypoint","C_Map.SetUserWaypoint",
  "C_SuperTrack.GetSuperTrackedQuestID","C_QuestLog.GetNextWaypoint","C_Minimap.GetTrackingFilter","C_Minimap.SetTracking",
  "C_TooltipInfo.GetItemByID","C_Item.GetItemInfo","C_Container.GetContainerItemInfo","C_TradeSkillUI.GetAllRecipeIDs",
  "C_AuctionHouse.ReplicateItems","C_AuctionHouse.GetReplicateItemInfo","C_AuctionHouse.SendSearchQuery","C_AuctionHouse.GetItemSearchResultInfo",
  "C_CVar.GetCVarInfo","C_CVar.GetCVar","C_CVar.SetCVar","C_CooldownViewer.GetCooldownViewerCategorySet","C_DamageMeter.GetCombatSessionFromType"}
 local function hasAPI(name)
  local object=_G
  for part in name:gmatch('[^.]+') do
   if not readable(object) or type(object)~="table" then return false end
   local ok,v=pcall(function() return object[part] end)
   if not ok or not readable(v) then return false end
   object=v
  end
  return type(object)=="function"
 end
 function B:Observe()
  local patch,ok,build,_,interface=call(GetBuildInfo)
  patch=text(patch,80) or "unknown";build=text(build,40) or "unknown"
  interface=readable(interface) and type(interface)=="number" and interface==interface and interface>=0 and interface<10000000 and interface or 0
  local key=patch..":"..build..":"..interface
  if self.key~=key then
   if self.open then self:Close(false) end
   self.attempts=0;self.key=key
  end
  self.patch,self.build,self.interface=patch,build,interface
  self.reviewed=ok and patch=="1.60.1" and interface==16001 and reviewed[build]==true or false
  -- A targeted runtime-only candidate remains UNREVIEWED in every report.
  -- It uses a quiet advisory rather than a repeated blocking load dialog.
  self.runtimeCandidate=ok and patch=="1.60.1" and interface==16001 and build=="71091" or false
  self.pending=not self.reviewed and not self.runtimeCandidate and not self.seen[key] or false
  return self.pending
 end
 function B:Summary()
  return "suite_compatibility=CAPABILITY_GUARDED; observed_client="..value(self.key)..
   "; source="..(self.reviewed and "REVIEWED" or "UNREVIEWED")..
   "; notice="..(self.open and "OPEN" or self.pending and "QUEUED" or self.runtimeCandidate and "QUIET_API_GUARDED" or "SETTLED").."; native_acceptance=NOT_RUN"
 end
 function B:Report(details)
  self:Observe()
  local lines={"MIRAGEUI P20 COMPATIBILITY REPORT","Client: "..self.patch.." / build "..self.build.." / interface "..self.interface,
   "Source review: "..(self.reviewed and "MATCHED" or "UNREVIEWED"),
   "Runtime policy: available APIs and feature-local recovery; no version/build veto.",
   "Native rendering, input, taint and gameplay performance: NOT_RUN by this report.",
   "",self:Summary(),"","Installed components:"}
  local metadata=C_AddOns and C_AddOns.GetAddOnMetadata or GetAddOnMetadata
  for _,name in ipairs(addons) do
   local version,ok=call(metadata,name,"Version")
   local member=self.members[name]
   local loaded,loadKnown=call(C_AddOns and C_AddOns.IsAddOnLoaded or IsAddOnLoaded,name)
   local isLoaded=member~=nil or loadKnown and loaded==true
   if member or ok and text(version,80) then
    local n=member and member.namespace
    local state=n and (n.state or n.runtime)
    local client=n and (n.Client or n.ClientIdentity)
    local allowed
    if client and type(client.allowed)=="boolean" then allowed=client.allowed
    elseif state then allowed=state.clientAllowed end
    lines[#lines+1]=name.." | version="..(text(version,80) or value(n and n.version))..
     " | loaded="..(isLoaded and "true" or "false").." | status="..value(state and (state.status or state.reason or state.startupStage))..
     " | allowed="..value(allowed)
   end
  end
  lines[#lines+1]="";lines[#lines+1]="API availability (presence only; each feature validates results):"
  for _,name in ipairs(APIs) do lines[#lines+1]=name.."="..(hasAPI(name) and "PRESENT" or "MISSING") end
  lines[#lines+1]="";lines[#lines+1]="Notice event registration:"
  local events={};for name in pairs(self.events) do events[#events+1]=name end;table.sort(events)
  for _,name in ipairs(events) do lines[#lines+1]=name.."="..self.events[name] end
  if details then
   local function append(name,object,method)
    if not object or type(object[method])~="function" then return end
    local report,ok=call(object[method],object)
    lines[#lines+1]="";lines[#lines+1]="--- "..name.." ---"
    if ok and text(report,240000) then lines[#lines+1]=report
    else lines[#lines+1]="Detailed component report unavailable; other component reports continue." end
   end
   local core=self.members.MirageUI;core=core and core.namespace
   append("MirageUI support",core and core.Diagnostics,"Export")
   local cursor=self.members.CursorCompanion;cursor=cursor and cursor.namespace
   append("Cursor Companion support",cursor and cursor.Diagnostics,"Report")
   -- The notice contains public capability/state summaries. Wealthcraft's raw
   -- startup trace is deliberately left in its explicit /wc startup workflow.
   local wealth=self.members.Wealthcraft;wealth=wealth and wealth.namespace
   if wealth then
    local compat=wealth.Compat;local b=compat and compat.build
    lines[#lines+1]="Wealthcraft: client="..value(b and b.status).."; runtime="..value(b and b.runtimeAllowed)..
     "; startup="..value(wealth.runtime and wealth.runtime.startupStage)
   end
   local utility=self.members.MirageIntel_Core;utility=utility and utility.namespace
   if utility then
    lines[#lines+1]="Utility Core: status="..value(utility.state and utility.state.status).."; last_failure="..value(utility.state and utility.state.lastError)
    for _,id in ipairs({"MirageIntel_Map","MirageIntel_Navigate","MirageIntel_Gather","MirageIntel_Insight"}) do
     local row=utility.Modules and utility.Modules.records and utility.Modules.records[id]
     lines[#lines+1]=id..": registered="..value(row~=nil)
    end
   end
  end
  return table.concat(lines,"\n")
 end
 function B:Close(dismiss)
  if dismiss and self.displayedKey then self.seen[self.displayedKey]=true end
  self.pending=not self.reviewed and not self.runtimeCandidate and self.key~=nil and not self.seen[self.key] or false
  if self.panel then
   if self.panel.edit and self.panel.edit.ClearFocus then pcall(self.panel.edit.ClearFocus,self.panel.edit) end
   pcall(self.panel.Hide,self.panel)
  end
  self.open=false
 end
 local function finite(v,minimum,maximum)
  return readable(v) and type(v)=="number" and v==v and v>=minimum and v<=maximum
 end
 function B:SizeReport(f,reset)
  if combat() or not f or not f.edit or not f.scroll or f.sizingReport then return end
  f.sizingReport=true
  local edit,scroll=f.edit,f.scroll
  local _,fontOK,fontHeight=call(edit.GetFont,edit)
  fontHeight=fontOK and finite(fontHeight,1,1000) and fontHeight or 12
  local spacing,spacingOK=call(edit.GetSpacing,edit)
  spacing=spacingOK and finite(spacing,0,1000) and spacing or 0
  local lines,linesOK=call(edit.GetNumLines,edit)
  if not linesOK or not finite(lines,1,1000000) then
   -- Keep the complete report copyable even if a future client lacks native
   -- line measurement. Conservative wrapping only affects the scroll extent.
   local contents,known=call(edit.GetText,edit)
   contents=known and text(contents,1000000) or f.reportText or ""
   local columns=math.max(1,math.floor(number(edit.GetWidth,edit,600)/fontHeight))
   lines=0
   for line in (contents.."\n"):gmatch("(.-)\n") do lines=lines+math.max(1,math.ceil(#line/columns)) end
  end
  local viewport=number(scroll.GetHeight,scroll,f.reportViewport or 300)
  local height=math.max(viewport,lines*fontHeight+math.max(0,lines-1)*spacing+12)
  if finite(height,1,100000000) then pcall(edit.SetHeight,edit,height) end
  if type(scroll.UpdateScrollChildRect)=="function" then pcall(scroll.UpdateScrollChildRect,scroll) end
  if reset then
   if type(edit.SetCursorPosition)=="function" then pcall(edit.SetCursorPosition,edit,0) end
   if type(scroll.SetVerticalScroll)=="function" then pcall(scroll.SetVerticalScroll,scroll,0) end
  end
  f.sizingReport=nil
 end
 function B:SetReport(f,report)
  if combat() then return false end
  f.reportText=report;f.edit:SetText(report);self:SizeReport(f,true);f.edit:ClearFocus()
  return true
 end
 function B:ReportCursor(f,y,height)
  if combat() or not f or f.sizingReport or not finite(y,-100000000,100000000) or not finite(height,0,1000) then return end
  local scroll=f.scroll
  local offset,known=call(scroll.GetVerticalScroll,scroll)
  if not known or not finite(offset,0,100000000) then return end
  local viewport=number(scroll.GetHeight,scroll,f.reportViewport or 300)
  local top=math.max(0,-y);local desired=offset
  if top<offset then desired=top elseif top+height>offset+viewport then desired=top+height-viewport end
  local maximum,rangeKnown=call(scroll.GetVerticalScrollRange,scroll)
  if rangeKnown and finite(maximum,0,100000000) then desired=math.min(desired,maximum) end
  if desired~=offset and type(scroll.SetVerticalScroll)=="function" then pcall(scroll.SetVerticalScroll,scroll,math.max(0,desired)) end
 end
 function B:CreatePanel()
  if self.panel then return self.panel end
  if combat() or type(CreateFrame)~="function" or not UIParent then return nil end
  local f=CreateFrame("Frame",nil,UIParent)
  self.constructing=f;f:Hide();f:SetPoint("CENTER");f:SetFrameStrata("DIALOG");f:SetClampedToScreen(true);f:EnableMouse(true)
  local screenW=number(UIParent.GetWidth,UIParent,1024);local screenH=number(UIParent.GetHeight,UIParent,768)
  local width=math.max(320,math.min(760,screenW-32));local height=math.max(280,math.min(590,screenH-48))
  f:SetSize(width,height)
  local bg=f:CreateTexture(nil,"BACKGROUND");bg:SetAllPoints();bg:SetColorTexture(.025,.035,.04,.98)
  local edge=f:CreateTexture(nil,"BORDER");edge:SetPoint("TOPLEFT");edge:SetPoint("TOPRIGHT");edge:SetHeight(2);edge:SetColorTexture(1,.60,.12,1)
  local title=f:CreateFontString(nil,"OVERLAY","GameFontNormalLarge");title:SetPoint("TOPLEFT",18,-18);title:SetText("MirageUI compatibility notice")
  local note=f:CreateFontString(nil,"OVERLAY","GameFontHighlight");note:SetPoint("TOPLEFT",18,-48);note:SetWidth(width-36);note:SetJustifyH("LEFT")
  note:SetText("This client has not been reviewed for this release. Available features continue running. Copy the report when convenient and share it with your test results.")
  local scroll=CreateFrame("ScrollFrame",nil,f,"UIPanelScrollFrameTemplate");scroll:SetPoint("TOPLEFT",18,-104);scroll:SetPoint("BOTTOMRIGHT",-38,78)
  local edit=CreateFrame("EditBox",nil,scroll);edit:SetMultiLine(true);edit:SetAutoFocus(false);edit:SetFontObject("ChatFontNormal");edit:SetWidth(width-64);edit:SetHeight(300);edit:SetMaxLetters(0)
  edit:SetScript("OnEscapePressed",function() B:Close(true) end);scroll:SetScrollChild(edit);f.edit=edit;f.note=note;f.scroll=scroll;f.reportViewport=height-182
  edit:SetScript("OnTextChanged",function() B:SizeReport(f,false) end)
  edit:SetScript("OnCursorChanged",function(_,_,y,_,h) B:ReportCursor(f,y,h) end)
  local function button(label,index,callback)
   local b=CreateFrame("Button",nil,f,"UIPanelButtonTemplate");b:SetSize((width-48)/3,26);b:SetPoint("BOTTOMLEFT",18+(index-1)*(width-30)/3,36);b:SetText(label);b:SetScript("OnClick",callback);return b
  end
  f.copy=button("Select report",1,function()
   if combat() then B:Close(false);B.pending=true;return end
   edit:SetFocus();edit:HighlightText()
  end)
  f.refresh=button("Refresh report",2,function() if not combat() then B:SetReport(f,B:Report(true)) end end)
  f.close=button("Continue",3,function() B:Close(true) end)
  local hint=f:CreateFontString(nil,"OVERLAY","GameFontDisableSmall");hint:SetPoint("BOTTOMLEFT",18,14);hint:SetText("Ctrl+A / Ctrl+C to copy. Reopen with /miragecompat.")
  self.panel=f;self.constructing=nil
  return f
 end
 function B:Open(manual)
  self:Observe()
  if combat() or not self.world or self.cinematic then self.manualPending=manual or self.manualPending;return false,"DEFERRED" end
  if not manual and not self.pending then return false,"NOT_NEEDED" end
  if self.open then return true end
  if not self:InitializeEvents() then return false,"NOTICE_EVENTS_UNAVAILABLE" end
  if self.attempts>=3 and not manual then return false,"NOTICE_UI_UNAVAILABLE" end
  self.attempts=math.min(3,self.attempts+1)
  local ok,result=pcall(function()
   local f=self:CreatePanel();if not f then return false end
   if combat() or not self.world or self.cinematic then return false end
   f.note:SetText(self.reviewed and "This client matches the reviewed source. Available features still use runtime API checks. Copy this report to review a display issue." or
    "This client has not been reviewed for this release. Available features continue running. Copy the report when convenient and share it with your test results.")
   if not self:SetReport(f,self:Report(true)) then return false end
   if combat() or not self.world or self.cinematic then return false end
   f:Show();self.open=true;self.displayedKey=self.key;self.attempts=0;self.manualPending=nil;return true
  end)
  if not ok or not result then
   self.open=false;self.failures.ui="NOTICE_UI_UNAVAILABLE"
   if self.constructing then pcall(self.constructing.Hide,self.constructing);self.constructing=nil end
   if self.panel then pcall(self.panel.Hide,self.panel) end
   return false,"NOTICE_UI_UNAVAILABLE"
  end
  return true
 end
 function B:Schedule()
  if self.scheduled or not self.world then return end
  self.scheduled=true
  local function ready()
   self.scheduled=false
   if self.pending or self.manualPending then self:Open(self.manualPending==true) end
  end
  if C_Timer and type(C_Timer.After)=="function" then
   local ok=pcall(C_Timer.After,2,ready);if not ok then self.scheduled=false;ready() end
  else ready() end
 end
 function B:Event(event,name)
  if event=="ADDON_LOADED" then
   if type(SlashCmdList)=="table" then
    SLASH_MIRAGECOMPAT1="/miragecompat";SlashCmdList.MIRAGECOMPAT=function() self:Open(true) end
   end
   self:Observe();if self.world then self:Schedule() end
  elseif event=="PLAYER_ENTERING_WORLD" then self.world=true;self:Observe();self:Schedule()
  elseif event=="PLAYER_REGEN_ENABLED" then self:Observe();self:Schedule()
  elseif event=="PLAYER_REGEN_DISABLED" then
   if self.open then self:Close(false);self.pending=not self.reviewed and not self.runtimeCandidate end
  elseif event=="PLAYER_LEAVING_WORLD" then self.world=false;self:Close(false)
  elseif event=="CINEMATIC_START" or event=="PLAY_MOVIE" then self.cinematic=true;self:Close(false)
  elseif event=="CINEMATIC_STOP" or event=="STOP_MOVIE" then self.cinematic=false;self:Schedule() end
 end
 function B:InitializeEvents()
  if self.eventReady then return true end
  local frame=self.eventFrame
  if not frame then
   if type(CreateFrame)~="function" then return false end
   local ok,created=pcall(CreateFrame,"Frame")
   if not ok or not created then self.failures.event="NOTICE_EVENT_FRAME_UNAVAILABLE";return false end
   frame=created;self.eventFrame=frame
  end
  for _,event in ipairs({"ADDON_LOADED","PLAYER_ENTERING_WORLD","PLAYER_LEAVING_WORLD","PLAYER_REGEN_ENABLED","PLAYER_REGEN_DISABLED","CINEMATIC_START","CINEMATIC_STOP","PLAY_MOVIE","STOP_MOVIE"}) do
   if self.events[event]~="REGISTERED" then
    local registered,result=pcall(frame.RegisterEvent,frame,event)
    if registered and result~=false and type(frame.IsEventRegistered)=="function" then
     local present,known=call(frame.IsEventRegistered,frame,event);registered=known and present==true
    end
    self.events[event]=registered and result~=false and "REGISTERED" or "UNAVAILABLE"
   end
  end
  local installed,result=pcall(frame.SetScript,frame,"OnEvent",function(_,event,name)
   local worked=pcall(B.Event,B,event,name)
   if not worked then B.failures.event="NOTICE_EVENT_FAILED" end
  end)
  self.eventReady=installed and result~=false and self.events.PLAYER_REGEN_DISABLED=="REGISTERED"
   and self.events.PLAYER_REGEN_ENABLED=="REGISTERED" and self.events.PLAYER_ENTERING_WORLD=="REGISTERED"
   and self.events.PLAYER_LEAVING_WORLD=="REGISTERED" or false
  return self.eventReady
 end

end
broker.members[addonName]={namespace=namespace}
broker:InitializeEvents()
if broker.world then broker:Observe();broker:Schedule() end
