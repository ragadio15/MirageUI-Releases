local _,CC=...
CC.PresetNames={"Minimal","Range + Cast","Range + GCD","Timing","Vitals + GCD","Accessible","Developer Curated"}
function CC:Preset(name)
 local p=self:Copy(self.Defaults)
 if name=="Developer Curated" then
  -- Reconstructed from the supplied 2026-11-01 settings screenshots.
  -- Keybinds are controlled by WoW and are deliberately not overwritten.
  p.enabled=true;p.launcher.show=false;p.advanced.contrast=false
  local inn=p.rings.inner
  inn.enabled=true;inn.style="Ticks";inn.role="GCD";inn.size=50
  inn.stroke=2;inn.opacity=.25;inn.colorMode="Class";inn.glow=true
  inn.speed=5;inn.direction="Clockwise"
  local out=p.rings.outer
  out.enabled=true;out.style="Compass";out.role="Health";out.size=100
  out.stroke=2;out.opacity=.25;out.colorMode="Class";out.glow=false
  out.speed=5;out.direction="Clockwise"
  p.rings.outer2.enabled=false
  local comp=p.compass
  comp.enabled=true;comp.style="QuestAster";comp.size=114;comp.stroke=1
  comp.pointerWidth=1.5;comp.pointerHeight=.5;comp.opacity=.5
  comp.colorMode="Class";comp.glow=false
  p.questNotes.enabled=true;p.questNotes.limit=5
  p.questNotes.width=382;p.questNotes.height=296
  local alerts=p.alerts
  alerts.enabled=true;alerts.combatStart=true;alerts.combatEnd=true
  alerts.style="Nova";alerts.colorMode="Contextual";alerts.size=160
  alerts.duration=.75;alerts.opacity=.78
  alerts.eventColors.combatStart={r=1,g=82/255,b=45/255}
  alerts.eventColors.combatEnd={r=92/255,g=212/255,b=153/255}
  local tr=p.motion
  tr.enabled=true;tr.kind="Needles";tr.colorMode="Class"
  tr.length=240;tr.lifetime=.2;tr.width=10;tr.opacity=.25
  tr.density=8;tr.quality="Balanced"
  p.info.tracked={"Corruption","Shadow Bolt","Agony"}
  p.info.reference="Corruption";p.info.source="mouseover";p.info.brackets=true
  local menu=p.palette
  menu.enabled=true;menu.settings=false;menu.experimental=true
  menu.offsetX=28;menu.offsetY=-20;menu.closeMode="Click and Escape"
  menu.radius=120;menu.confirmDuel=true;menu.actionIcons=true;menu.actionScale=1
  menu.signalStyle="Tactical";menu.signalIcons=true;menu.signalScale=1.25
  menu.signalFeedback=true
  p.hideOnMouseDown=true;p.hideOverWindows=true;p.idleHideSeconds=5
  p.offsetX=0;p.offsetY=0
  return p
 end
 if name=="Range + Cast" or name=="Range + GCD" then
  p.rings.outer.role="Spell range";p.rings.inner.enabled=true
  p.rings.inner.role=name=="Range + Cast" and "Cast / channel" or "GCD"
 elseif name=="Timing" then p.rings.outer.role="Cast / channel";p.rings.inner.enabled=true;p.rings.inner.role="GCD"
 elseif name=="Vitals + GCD" then
  p.rings.inner.enabled=true;p.rings.inner.role="Health";p.rings.outer.role="Resource";p.rings.outer2.enabled=true;p.rings.outer2.role="GCD"
 elseif name=="Accessible" then p.rings.outer.style="Circle";p.rings.outer.stroke=3;p.rings.outer.colorMode="Neutral";p.motion.enabled=false;p.rings.outer.speed=0;p.rings.inner.speed=0;p.advanced.contrast=true end
 return p
end
