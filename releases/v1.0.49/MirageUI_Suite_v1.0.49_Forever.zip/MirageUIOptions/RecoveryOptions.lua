-- Recovered-beta additions use the suite's ordinary draft / Apply / Cancel contract.
local M=MirageUI
if not M then return end
local O=M.Options
local oldSpecial=O.RenderSpecialModule
function O:RenderExplorationOptions(id,cfg,y)
    y=y or -185
    y=self:FeatureVisibility(cfg,y)
    if id=="Chat" then
        self:Check("chatMessageCue","Reveal chat for qualifying incoming messages",cfg.messageCue,0,y,function(v) cfg.messageCue=v end);y=y-46
        self:Text("chatCueHelp","Whispers, party/raid and instance messages, raid warnings, and system messages can reveal their receiving chat window. Each new qualifying message renews an eight-second display. The optional categories below are off by default; the switch above controls all message cues.",0,y,self.cw,11);y=y-132
        for _,row in ipairs({{"cueSay","Also reveal for Say"},{"cueYell","Also reveal for Yell"},
            {"cueGuild","Also reveal for Guild / Officer"},{"cueEmote","Also reveal for emotes"},
            {"cueChannels","Also reveal for channels (General, Trade, custom)"}}) do
            local key,label=row[1],row[2]
            self:Check("chat_"..key,label,cfg[key],0,y,function(v) cfg[key]=v end);y=y-42
        end
        self:Text("chatCategoryHelp","Channels is one category, including General, Trade and custom channels already accepted by that chat window. These choices do not change native chat filters or select a different chat tab.",0,y,self.cw,11);y=y-92
    end
    self:Check("quietHide","Hide eligible native panels when quiet",cfg.hideWhenQuiet,0,y,function(v) cfg.hideWhenQuiet=v end);y=y-46
    self:Text("quietExplain","Eligible panels hide when their local activity ends. Use your normal window keybindings or chat entry; /mirage reveal temporarily shows eligible displays. Visible controls stay available while you use them. Protected or unavailable surfaces retain native access.",0,y,self.cw,11);y=y-116
    self:Check("moveNative","Place the eligible native panel with Unlock Mode",cfg.moveNative,0,y,function(v) cfg.moveNative=v end);y=y-46
    self:Button("nativePlace","Open Unlock Mode",0,y,self.cw,function() M.Editor:Open() end);y=y-44
    self:Text("nativePlaceHint","Apply first to create a positioning anchor. Moving its outline changes a draft only; Apply saves it. This moves the native panel without resizing its content. Changing another UI owner's position takes precedence. Disable this option to release MirageUI's position lease.",0,y,self.cw,11)
end
function O:RenderPreparationOptions(cfg)
    local y=-(self.contentHeight or 500)-24
    self:Text("prepHeading","Preparation checklist",0,y,self.cw,16);y=y-42
    self:Check("prepEnabled","Show selected buff checks outside combat",cfg.preparation,0,y,function(v) cfg.preparation=v end);y=y-44
    self:Text("prepExplain","Choose up to eight exact buff spell IDs. Present means that exact ID was observed. Not observed is used only after a complete readable scan. Similar ranks or replacement spells are not assumed equivalent. No reminder is generated during combat.",0,y,self.cw,11);y=y-116
    for i,id in ipairs(cfg.reminders) do
        local meta=M.PreparationSnapshot:Describe(id)
        self:Text("prepRow"..i,(meta and meta.name or "Spell").." · "..id,0,y,self.cw-46,11)
        self:Button("prepRemove"..i,"−",self.cw-34,y+6,34,function() table.remove(cfg.reminders,i);self:Render() end);y=y-38
    end
    if #cfg.reminders<8 then
        local box=self:Edit("prepAdd",self.prepEntry or "",0,y,self.cw-100,function(text) self.prepEntry=text;return true end)
        self:Button("prepAddButton","Add buff",self.cw-92,y,92,function()
            local text=box:GetText();local id=tonumber(text)
            if not id and C_Spell and type(C_Spell.GetSpellInfo)=="function" then
                local ok,info=pcall(C_Spell.GetSpellInfo,text);if ok then local v=M.Safety:Field(info,"spellID");if M.Safety:Number(v) then id=v end end
            end
            local meta=id and M.PreparationSnapshot:Describe(id)
            if not meta then self:Notice("Enter a recognized buff name or its exact spell ID.");return end
            for _,v in ipairs(cfg.reminders) do if v==id then self:Notice("That exact spell ID is already listed.");return end end
            cfg.reminders[#cfg.reminders+1]=id;self.prepEntry="";self:Render()
        end);y=y-50
    end
    self:Text("privateHeading","Native private-aura display",0,y,self.cw,16);y=y-42
    self:Check("privateEnabled","Allow the game to display private auras here",cfg.privateAuras,0,y,function(v) cfg.privateAuras=v end);y=y-48
    self:Slider("privateCount","Private-aura slots",0,y,self.cw,cfg.privateCount,1,4,1,function(v) cfg.privateCount=v end);y=y-68
    self:Slider("privateSize","Private-aura icon size",0,y,self.cw,cfg.privateSize,20,56,1,function(v) cfg.privateSize=v end);y=y-68
    self:Text("privateInfo","Player only. The game supplies the icons and timing; MirageUI does not read names, duration, presence or contents. This anchor is not faded by contextual aura rules. It can be arranged outside combat in Unlock Mode. An empty anchor is not proof that no private effect exists.",0,y,self.cw,11)
end
function O:RenderSpecialModule(id,cfg)
    if id=="Minimap" or id=="Chat" then self:RenderExplorationOptions(id,cfg);return true end
    local handled=oldSpecial(self,id,cfg)
    if id=="Auras" then self:RenderPreparationOptions(cfg)
    elseif id=="ResourceBars" then
        local y=-(self.contentHeight or 450)-28
        self:Check("runeDisplay","Show individual rune timers when available",cfg.runes,0,y,function(v) cfg.runes=v end)
        self:Text("runeInfo","Six fixed native rune slots for death knights. Unknown values are blanked. The order is never optimized, and a cleared timer is not a recommendation to cast. Blizzard's class display stays available.",0,y-46,self.cw,11)
    elseif id=="QuestTracker" then self:RenderExplorationOptions(id,cfg,-(self.contentHeight or 600)-24) end
    return handled
end

local oldSupport=O.RenderSupport
function O:RenderSupport()
    oldSupport(self)
    local y=-(self.contentHeight or 500)-28
    self:Text("measureHead","Local performance capture",0,y,self.cw,16);y=y-40
    self:Text("measureHelp","Optional native-attributed timing across the three MirageUI packages. It measures your chosen scene without changing your settings. Stop after the same scene and duration for comparable runs. Results use the latest 8,192 valid frame samples; no names, combat logs or chat are captured.",0,y,self.cw,11);y=y-120
    self:Button("measureStart","Start a QUIET-scene capture",0,y,self.cw,function() local ok,why=M.Profiler:Start("QUIET");self:Notice(why) end);y=y-40
    self:Button("measureStop","Stop and view performance",0,y,self.cw,function() M.Profiler:Stop();M.UI:CopyWindow("MirageUI performance",M.Profiler:Export()) end);y=y-50
    if M.Client.family=="Forever" then
        self:Text("foreverHead","Forever source candidate",0,y,self.cw,16);y=y-42
        self:Text("foreverHelp","This enables only the exact pinned build with restricted-value checks available. APIs are still checked by each feature. It does not certify combat, input, Camping, Legacy or cross-client parity. Your Midnight profile remains separate. An updated or unidentified client is never forced through.",0,y,self.cw,11);y=y-124
        self:Button("foreverOpt",M.Client.experimental and "Disable Forever candidate" or "Enable exact-build Forever candidate",0,y,self.cw,function() local ok,why=M.Client:SetCandidate(not M.Client.experimental);self:Notice(why) end)
    end
end

-- Client support is read on explicit request, not continuously polled by options.
local previousSupport=O.RenderSupport
function O:RenderSupport()
    previousSupport(self)
    local y=-(self.contentHeight or 500)-28
    self:Button("clientMatrix","Inspect this client's available providers",0,y,self.cw,function()
        M.Capabilities:Probe();M.UI:CopyWindow("MirageUI client support",M.ClientUI:Report())
    end);y=y-42
    self:Button("clientSpellbook","Open the native spellbook",0,y,self.cw,function() local ok,msg=M.ClientUI:Open("spellbook");self:Notice(msg) end);y=y-42
    self:Button("clientTalents","Open native talents",0,y,self.cw,function() local ok,msg=M.ClientUI:Open("talents");self:Notice(msg) end)
end

local beforeTotems=O.RenderSpecialModule
function O:RenderSpecialModule(id,cfg)
    local handled=beforeTotems(self,id,cfg)
    if id=="ResourceBars" then
        local y=-(self.contentHeight or 500)-28
        self:Check("totemDisplay","Show native totem / temporary-summon timers",cfg.totems,0,y,function(v) cfg.totems=v end)
        self:Text("totemInfo","Fixed slots in native order, using native duration objects. Unavailable icons stay blank; private slot contents are not interpreted. These tiles cannot target or dismiss a summon. The game's own controls remain available.",0,y-46,self.cw,11)
    end
    return handled
end
