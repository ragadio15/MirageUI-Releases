local M=MirageUI
if not M or not M.Options then return end
local U,S=M.UI,M.Safety
local P={page="home",panels={},controls={}}
M.PlayerSettings=P
local O=M.Options
O.LegacyOpen=O.Open;O.LegacySetup=O.Setup
local pages={{"home","Your experience"},{"displays","Displays & layout"},{"context","When things appear"},{"cursor","Suite addons"},{"profiles","Profiles & preferences"},{"help","Help & recovery"}}
local function shown(f) return f and f:IsShown() end
function P:Notice(text)
 if self.notice then self.notice:SetText(text or "") end
end
function P:Close()
 if self.frame then self.frame:Hide() end
 if M.Signals then M.Signals:Observe() end
 M.state.forceEvaluate=true
end
function P:Create()
 if self.frame then return end
 local f=CreateFrame("Frame","MirageUIPlayerSettings",UIParent,"BackdropTemplate");self.frame=f
 f:SetSize(900,620);f:SetPoint("CENTER");f:SetFrameStrata("DIALOG");U:Backdrop(f)
 f:SetClampedToScreen(true);f:EnableMouse(true);f:SetMovable(true);f:RegisterForDrag("LeftButton")
 f:SetScript("OnDragStart",function() if not S:InCombat() then f:StartMoving() end end)
 f:SetScript("OnDragStop",function() f:StopMovingOrSizing() end)
 local title=U:Text(f,"MIRAGEUI",24,-22,22,500);U:SetTextRole(title,"accent")
 U:Text(f,"Your world first. The right information when it matters.",24,-54,13,760)
 self.closeButton=U:Button(f,"Close",796,-22,80,function() self:Close() end)
 for index,row in ipairs(pages) do
  local id,label=row[1],row[2]
  self.controls[id]=U:Button(f,label,20,-104-(index-1)*42,194,function() self:Render(id) end)
 end
 self.revealButton=U:Button(f,"Show displays",20,-392,194,function() M.CVE:Reveal(10);self:Notice("Optional displays are revealed for 10 seconds. Native safety limits still apply.") end)
 self.moveButton=U:Button(f,"Move displays",20,-434,194,function() self:Close();if M.Editor then M.Editor:Open() end end)
 self.shortcuts=U:Text(f,"Settings: /mirage\nStop presentation: /mirage safe",24,-491,12,190)
 self.notice=U:Text(f,"",238,-548,13,630)
 self.notice:SetHeight(58)
 self.body=CreateFrame("Frame",nil,f);self.body:SetPoint("TOPLEFT",238,-104);self.body:SetSize(638,422)
 f:SetScript("OnShow",function() M.state.forceEvaluate=true end)
 f:SetScript("OnHide",function() M.state.forceEvaluate=true;if M.Experience then M.Experience:ClosePreview() end end)
 if UISpecialFrames then table.insert(UISpecialFrames,"MirageUIPlayerSettings") end
 f:Hide()
end
function P:Open(page)
 if S:InCombat() then M:Print("Open settings after combat. Your gameplay controls are unchanged.");return false end
 -- Never silently discard an old advanced draft.
 if O.draft and O.frame and O.frame:IsShown() then M:Print("Apply or cancel the open detailed settings before opening the player settings.");return false end
 self:Create()
 local w=S:Public(UIParent.GetWidth,"number",UIParent);local h=S:Public(UIParent.GetHeight,"number",UIParent)
 if w and h then self.frame:SetScale(math.max(.25,math.min(1,(w-24)/900,(h-24)/620))) end
 self.frame:Show();self:Render(page or "home")
 M.Signals:Observe();M.CVE:Tick(true)
 return true
end
function P:Run(fn)
 if S:InCombat() then self:Notice("Finish combat before changing settings.");return false end
 local ok,a,b=pcall(fn)
 if not ok then M:Fault("Options","PLAYER_SETTINGS_FAILED");self:Notice("This change could not be completed. Copy the support report from Help.");return false end
 local panel=self.panels[self.page];if panel and panel.Refresh then panel.Refresh() end
 self:Notice(b or (a and "Saved." or "Nothing changed."))
 return a,b
end
function P:Commit(mutator)
 return self:Run(function()
  if M.Profiles.readOnly then return false,"Your current settings are read-only and have been preserved." end
  local p=M:Copy(M.profile);mutator(p)
  return M.Profiles:Commit(p,nil,"PROFILE_COMMIT")
 end)
end
local function heading(panel,text,y) local f=U:Text(panel,text,0,y or 0,20,620);U:SetTextRole(f,"heading");return f end
local function paragraph(panel,text,y,height)
 local f=U:Text(panel,text,0,y,14,622);f:SetHeight(height or 66);return f
end
function P:Button(panel,text,x,y,width,fn)
 return U:Button(panel,text,x,y,width,function() self:Run(fn) end)
end
function P:Toggle(panel,label,id,x,y,width)
 local b
 b=U:Button(panel,"",x,y,width or 302,function()
  self:Commit(function(p) p.modules[id].enabled=not p.modules[id].enabled end)
  b:SetText((M.profile.modules[id].enabled and "On  |  " or "Off  |  ")..label)
 end)
 b:SetText((M.profile.modules[id].enabled and "On  |  " or "Off  |  ")..label)
 return b
end
function P:Render(page)
 self.page=page
 local welcome=page=="welcome"
 self.frame:SetSize(welcome and 700 or 900,620)
 for _,button in pairs(self.controls) do button:SetShown(not welcome) end
 for _,control in ipairs({self.closeButton,self.revealButton,self.moveButton,self.shortcuts}) do control:SetShown(not welcome) end
 self.body:ClearAllPoints();self.body:SetPoint("TOPLEFT",welcome and 24 or 238,-104)
 self.notice:ClearAllPoints();self.notice:SetPoint("TOPLEFT",welcome and 24 or 238,-548)
 local width=S:Public(UIParent.GetWidth,"number",UIParent);local height=S:Public(UIParent.GetHeight,"number",UIParent)
 if width and height then self.frame:SetScale(math.max(.25,math.min(1,(width-24)/(welcome and 700 or 900),(height-24)/620))) end
 for _,panel in pairs(self.panels) do panel:Hide() end
 for key,b in pairs(self.controls) do b.selected=key==page;U:PaintButton(b) end
 local panel=self.panels[page]
 if not panel then panel=CreateFrame("Frame",nil,self.body);panel:SetAllPoints();self.panels[page]=panel end
 -- Rebuild bounded content only when first opening a page. Dynamic labels get
 -- their own Refresh hook; no per-frame font creation or accumulating pools.
 if not panel.built then
  panel.built=true
  if page=="welcome" then
   heading(panel,"The intended MirageUI experience")
   paragraph(panel,"MirageUI keeps the world in view. Your displays are prepared together, appear when useful, and recede between activities. Moving reveals navigation; combat and your interactions bring the relevant information back.",-46,104)
   paragraph(panel,"MirageUI displays and standalone suite addons keep their own settings. Original game controls remain available when a replacement cannot safely take over.",-157,76)
   paragraph(panel,"Would you like to opt in to the intended MirageUI experience?",-246,58)
   self:Button(panel,"Yes",0,-320,190,function()
    local ok,why=M.Experience:Choose(true)
    if ok then self:Render("home") end
    return ok,why
   end)
   self:Button(panel,"No",206,-320,190,function()
    local ok,why=M.Experience:Choose(false)
    if ok then self:Render("home") end
    return ok,why
   end)
   paragraph(panel,"Yes applies the complete preset. No leaves your game interface in place. You can change this choice in Settings.",-367,52)
  elseif page=="home" then
   panel.title=heading(panel,"")
   panel.message=paragraph(panel,"",-47,85)
   self:Button(panel,"Use the intended experience",0,-148,302,function() self:Render("welcome");return true,"Your preferences change only when you choose Yes." end)
   panel.resume=self:Button(panel,"Resume presentation",320,-148,302,function()
    if not M.profile.enabled then return M.Experience:ResumeChoices() end
    return M:Recover()
   end)
   self:Button(panel,"Pause presentation",0,-191,302,function() local ok=M:SafeMode("USER_REQUEST");return ok,ok and "Optional presentation is stopped. Your preferences are retained." or "Presentation is stopped; some display cleanup remains pending. Open Help." end)
   self:Button(panel,"Preview player / target / focus",320,-191,302,function() return self:PreviewFrames() end)
   paragraph(panel,"Explore, quest and fight as usual. Displays appear when useful and recede between activities. Adjust their appearance and placement without losing your saved preferences.",-252,84)
   paragraph(panel,"Enable my current choices keeps your custom settings. Use the intended experience to start again from the coordinated preset.",-350,70)
   panel.Refresh=function() local state=M.Diagnostics:ActivationState();panel.title:SetText(state.title);panel.message:SetText(state.message);panel.resume:SetText(M.profile.enabled and "Resume presentation" or "Enable my current choices") end
  elseif page=="displays" or page=="more" then
   heading(panel,page=="displays" and "Choose your displays" or "Additional displays")
   paragraph(panel,"Changes save when clicked. Context decides when enabled displays appear; enabling a display does not force unavailable information or duplicate its primary source.",-42,70)
   local list=page=="displays" and {{"Player, target & focus","UnitFrames"},{"Under-character bars","UnderCharacterHUD"},{"Nameplates","Nameplates"},{"Action bars","ActionBars"},{"Minimap","Minimap"},{"Chat","Chat"},{"Objectives","QuestTracker"},{"Tooltips","Tooltips"}}
    or {{"Party & raid","PartyRaid"},{"Resources & summons","ResourceBars"},{"Auras","Auras"},{"Cooldowns","Cooldowns"},{"Bags","Bags"},{"Damage summaries","DamageMeters"},{"Preparation tools","Preparations"},{"Tactical signals","TacticalSignals"},{"PvP tools","PvP"},{"Native window styling","BlizzardSkin"}}
   panel.toggles={}
   for i,row in ipairs(list) do
    local id,label=row[2],row[1];local b=self:Toggle(panel,label,id,((i-1)%2)*320,-124-math.floor((i-1)/2)*42,302)
    panel.toggles[#panel.toggles+1]={button=b,id=id,label=label}
   end
   self:Button(panel,page=="displays" and "Additional displays" or "Main displays",0,-350,302,function() self:Render(page=="displays" and "more" or "displays");return true end)
   self:Button(panel,"Preview frame designs",320,-350,302,function() return self:PreviewFrames() end)
   self:Button(panel,"Minimap, quests & buffs",0,-390,302,function() self:Render("navigation");return true end)
   self:Button(panel,"Preview the whole layout",320,-390,302,function() return M.LayoutPreview:Open() end)
   panel.Refresh=function() for _,t in ipairs(panel.toggles) do t.button:SetText((M.profile.modules[t.id].enabled and "On  |  " or "Off  |  ")..t.label) end end
  elseif page=="navigation" then
   heading(panel,"Minimap, quests & buffs")
   paragraph(panel,"MirageUI reshapes the game’s map and scales its buff icons. Quest tracking, map clicks and buff tooltips still use the original game controls.",-44,80)
   panel.square=U:Button(panel,"",0,-140,622,function() self:Commit(function(p) p.modules.Minimap.square=not p.modules.Minimap.square end) end)
   panel.column=U:Button(panel,"",0,-184,622,function() self:Commit(function(p) p.modules.QuestTracker.matchMinimap=not p.modules.QuestTracker.matchMinimap end) end)
   self:Button(panel,"Map: 220 pixels",0,-232,196,function() return self:Commit(function(p) p.modules.Minimap.squareSize=220 end) end)
   self:Button(panel,"Map: 260 pixels",210,-232,196,function() return self:Commit(function(p) p.modules.Minimap.squareSize=260 end) end)
   self:Button(panel,"Map: 300 pixels",420,-232,196,function() return self:Commit(function(p) p.modules.Minimap.squareSize=300 end) end)
   self:Button(panel,"Buff size: Original",0,-280,196,function() return self:Commit(function(p) p.modules.Auras.nativeScale=100 end) end)
   self:Button(panel,"Buff size: Larger",210,-280,196,function() return self:Commit(function(p) p.modules.Auras.nativeScale=140 end) end)
   self:Button(panel,"Buff size: Largest",420,-280,196,function() return self:Commit(function(p) p.modules.Auras.nativeScale=160 end) end)
   self:Button(panel,"Preview the whole layout",0,-340,302,function() return M.LayoutPreview:Open() end)
   self:Button(panel,"Back to displays",320,-340,302,function() self:Render("displays");return true end)
   panel.result=paragraph(panel,"",-386,44)
   panel.Refresh=function()
    local state=M.NavigationStyle and M.NavigationStyle.status or {}
    local map=state.Minimap=="SQUARE_NATIVE_MAP" and "Square" or state.Minimap=="GAME_DEFAULT" and "Game default" or "Not confirmed"
    local quests=state.QuestTracker=="MATCHED_MINIMAP_COLUMN" and "Matched" or state.QuestTracker=="GAME_DEFAULT" and "Game default" or "Not confirmed"
    local buffs=state.Auras=="ENLARGED_NATIVE_BUFFS" and "Larger" or state.Auras=="GAME_DEFAULT" and "Game default" or "Not confirmed"
    panel.result:SetText("Current appearance — Map: "..map..". Quests: "..quests..". Buffs: "..buffs..".")
    panel.square:SetText("Square minimap: "..(M.profile.modules.Minimap.square and "On" or "Off"))
    panel.column:SetText("Match quest-list width to minimap: "..(M.profile.modules.QuestTracker.matchMinimap and "On" or "Off"))
   end
  elseif page=="context" then
   heading(panel,"Quiet when you do not need it")
   paragraph(panel,"The intended preset fades eligible displays away after five quiet seconds. Movement reveals the minimap. Combat, interaction, editing and manual reveal take priority.",-44,85)
   panel.quiet=U:Button(panel,"",0,-148,622,function()
    self:Commit(function(p) p.preset=p.preset=="Immersive" and "Balanced" or "Immersive" end)
   end)
   panel.minimap=U:Button(panel,"",0,-192,622,function()
    self:Commit(function(p) local c=p.modules.Minimap;c.visibility=c.visibility=="Always" and "Contextual" or "Always" end)
   end)
   self:Button(panel,"Idle delay: 3 seconds",0,-242,196,function() return self:Commit(function(p) p.idle=3 end) end)
   self:Button(panel,"Idle delay: 5 seconds",210,-242,196,function() return self:Commit(function(p) p.idle=5 end) end)
   self:Button(panel,"Idle delay: 8 seconds",420,-242,196,function() return self:Commit(function(p) p.idle=8 end) end)
   self:Button(panel,"Reveal displays for 10 seconds",0,-294,622,function() M.CVE:Reveal(10);return true,"Reveal is temporary; your normal context rules resume afterward." end)
   paragraph(panel,"Combat, a selected target or focus brings combat controls back. Use Show displays for bags, menus and other controls whenever you need them. Special gameplay controls remain available.",-350,70)
   panel.Refresh=function()
    panel.quiet:SetText(M.profile.preset=="Immersive" and "Quiet between activities: On" or "Quiet between activities: Off")
    panel.minimap:SetText(M.profile.modules.Minimap.visibility=="Always" and "Minimap: Always visible" or "Minimap: Contextual (movement, combat or interaction)")
   end
  elseif page=="cursor" then
   heading(panel,"Standalone suite addons")
   paragraph(panel,"Cursor Companion, Sanctuary and WealthCraft keep their own settings and shortcuts. Enable them independently from the AddOns list.\n\nUse /cc, /sanctuary and /wealthcraft to open their settings.",-45,180)
  elseif page=="profiles" then
   heading(panel,"Keep your preferences")
   paragraph(panel,"Existing settings are preserved until you deliberately change them. Yes stores one previous-suite backup. Standalone addons keep their own profile import and export tools.",-44,88)
   self:Button(panel,"Export suite preferences",0,-150,302,function() local code,why=M.Profiles:Export();if code then M.UI:CopyWindow("Suite preferences — review before sharing",code) end;return code~=nil,why end)
   self:Button(panel,"Restore previous suite setup",320,-150,302,function() return M.Managed:RestorePrevious() end)
   panel.scope=U:Button(panel,"",320,-194,302,function() self:Run(function() return M.Profiles:UseCharacter(not M.Profiles.character.useCharacter) end) end)
   self:Button(panel,"Choose the intended preset again",0,-249,622,function() self:Render("welcome");return true,"This changes preferences only after Yes." end)
   paragraph(panel,"To restore an external backup, close the game first. Do not erase WTF or SavedVariables as a troubleshooting step; they contain the preferences we are trying to preserve.",-322,94)
   panel.Refresh=function() panel.scope:SetText(M.Profiles.character.useCharacter and "Profile scope: This character" or "Profile scope: Account") end
  elseif page=="help" then
   heading(panel,"A clear way back")
   panel.message=paragraph(panel,"",-44,100)
   self:Button(panel,"Copy support report",0,-166,302,function() M.UI:CopyWindow("MirageUI support report",M.Diagnostics:Export());return true,"Review the text before sharing it with screenshots." end)
   self:Button(panel,"Pause and restore native access",320,-166,302,function() local ok=M:SafeMode("USER_REQUEST");return ok,ok and "Cleanup completed. Native controls remain available." or "Cleanup remains pending. Copy the report before trying again." end)
   self:Button(panel,"Resume once",0,-210,302,function() return M:Recover() end)
   self:Button(panel,"Detailed settings",320,-210,302,function() self:Close();O:LegacyOpen();return true end)
   self:Button(panel,"Preview frame designs",0,-254,302,function() return self:PreviewFrames() end)
   self:Button(panel,"Copy current frame status",320,-254,302,function() M.UI:CopyWindow("Frame availability",M.UnitTypography:Report());return true end)
   paragraph(panel,"If setup or recovery fails, copy the support report immediately and stop repeating the action. When input is inaccessible, exit to character selection and disable the three MirageUI addons.",-321,91)
   panel.Refresh=function() local a=M.Diagnostics:ActivationState();panel.message:SetText(a.message.."\n\n"..a.help) end
  end
 end
 panel:Show();if panel.Refresh then panel.Refresh() end
 self:Notice("")
end
function P:PreviewFrames()
 if S:InCombat() then return false,"Preview frames outside combat." end
 if M.state.safe or M.state.safeCleanupPending then return false,"Resume successfully before previewing optional displays." end
 local e=M.Experience
 if not e.preview then
  local f=CreateFrame("Frame","MirageUIFrameDesignPreview",UIParent,"BackdropTemplate");e.preview=f;f.samples={}
  f:SetSize(790,355);f:SetPoint("CENTER");f:SetFrameStrata("FULLSCREEN_DIALOG");U:Backdrop(f)
  f:SetBackdropColor(.018,.022,.026,.98)
  f:SetClampedToScreen(true);f:EnableMouse(true)
  local t=U:Text(f,"FRAME DESIGN PREVIEW  |  DEMO",20,-20,19,700);U:SetTextRole(t,"accent")
  U:Text(f,"Authored sample values, not live units. Existing frame dimensions are preserved.",20,-57,13,750)
  for i,row in ipairs({{"Player","player"},{"Target","target"},{"Focus","focus"}}) do
   local x=20+(i-1)*253
   local label=U:Text(f,row[1],x,-108,15,230);U:SetTextRole(label,"heading")
   local child=CreateFrame("Frame",nil,f);child:SetSize(row[2]=="focus" and 220 or 240,55);child:SetPoint("TOPLEFT",x,-147)
   S:Passive(child)
   local v=M.Display:DecorateUnit(child,row[2],row[1],"UnitFrames",true)
   f.samples[#f.samples+1]=v
   -- DecorateUnit starts at its normal live width. Restore this sample's own
   -- bounds before anchoring its level/name; otherwise the level spills into
   -- the next column. No live unit or saved layout is resized here.
   child:SetSize(row[2]=="focus" and 220 or 240,55)
   M.Display:SizeUnit(v,row[2]=="focus" and 220 or 240,55)
   v.name:SetText(row[1].." demo");v.name:SetTextColor(.65,.50,.85,1)
   v.level:SetText("60");v.separator:SetText("|");v.detail:SetText("Sample only")
   v.health:SetMinMaxValues(0,100);v.health:SetValue(72);v.health:SetStatusBarColor(unpack(M.Visual.health))
   v.power:SetMinMaxValues(0,100);v.power:SetValue(58);v.power:SetStatusBarColor(unpack(M.Visual.mana))
   v.healthPercent:SetText("");v.powerPercent:SetText("");child:Show()
  end
  U:Text(f,"For actual target/focus frames, select the matching unit. A native frame remains when the secure replacement is not admitted; use Help > Copy current frame status.",20,-237,13,750):SetHeight(52)
  U:Button(f,"Close preview",20,-307,170,function() e:ClosePreview() end)
  if UISpecialFrames then table.insert(UISpecialFrames,"MirageUIFrameDesignPreview") end
 end
 local width=S:Public(UIParent.GetWidth,"number",UIParent);local height=S:Public(UIParent.GetHeight,"number",UIParent)
 if width and height then e.preview:SetScale(math.max(.25,math.min(1,(width-24)/790,(height-24)/355))) end
 for _,sample in ipairs(e.preview.samples or {}) do sample.frame:Show() end
 e.preview:Show();M.state.forceEvaluate=true
 return true,"Preview is labeled DEMO and closes when combat begins or presentation stops."
end
function O:Open() return P:Open("home") end
function O:Setup() return P:Open("welcome") end
