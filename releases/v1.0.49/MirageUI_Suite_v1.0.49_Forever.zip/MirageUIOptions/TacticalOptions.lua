local M=MirageUI
if not M or not M.Options then return end
local O=M.Options
local previous=O.RenderSpecialModule
function O:RenderSpecialModule(id,cfg)
 if id=="PvP" then
  local choices={};for i,name in ipairs(M.CombatLenses.names) do choices[#choices+1]={value=i,label=name.." (manual fallback)"} end
  local y=-185
  self:Choice("pvpLens","Combat lens: "..M.CombatLenses.names[cfg.lens],choices,cfg.lens,0,y,self.cw,function(v) cfg.lens=v end);y=y-46
  self:Check("pvpAuto","Use public group / instance context",cfg.automaticLens,0,y,function(v) cfg.automaticLens=v end);y=y-42
  self:Check("pvpBadge","Show a small lens label during combat",cfg.badge,0,y,function(v) cfg.badge=v end);y=y-42
  self:Check("pvpContacts","Show currently observed player contacts",cfg.contacts,0,y,function(v) cfg.contacts=v end);y=y-42
  self:Slider("pvpRows","Maximum observed contact rows",0,y,self.cw,cfg.contactRows,1,8,1,function(v) cfg.contactRows=v end);y=y-68
  self:Check("pvpManual","Allow explicit manual estimate notes",cfg.manualNotes,0,y,function(v) cfg.manualNotes=v end);y=y-42
  self:Text("pvpManualGuide","Optional manual input for the current attackable player target:\n/mirage note cooldown 30\n/mirage note cc 18\n/mirage note clear\nThese are user-entered timers, not observed casts, cooldowns or DR. Expiry displays UNKNOWN, never READY. No predictions or ability durations are supplied by the add-on.",0,y,self.cw,11);y=y-150
  self:Button("pvpForget","Forget current manual notes",0,y,self.cw,function() M.ObservedContacts:ForgetNotes();self:Notice("Manual notes cleared.") end);y=y-46
  self:Text("pvpScope","Current visible nameplates and target/focus/mouseover aliases only. Identity changes and lost observations discard the record. No unseen-enemy discovery, complete-opponent count, automatic targeting, saved identity history, combat-log reconstruction or battleground objective system. All contact data stays in this session and is excluded from profile/support exports.",0,y,self.cw,11);y=y-140
  self:Text("pvpEvidence","Duel is manual. Unavailable group/instance context retains the current lens, not a claim that context is still active. Automatic transition stabilization and native validation remain pending. Cooldown/DR prediction requires qualifying evidence and is unavailable. Preparation remains separate.",0,y,self.cw,11)
  return true
 elseif id=="TacticalSignals" then
  self:Text("pingHelp","Use a separate native ping shortcut in combat. The cursor's middle-mouse menu remains out of combat and keeps its existing binding. Apply this module before assigning keys; every occupied shortcut requires review.",0,-185,self.cw,12)
  local y=-300
  for _,row in ipairs(M.modules.TacticalSignals.commands) do
   self:Button("pingKey"..row.id,row.label,0,y,self.cw,function() M.BindingEditor:OpenForService(M.TacticalKeys,row.id,"Native ping shortcut") end);y=y-40
  end
  self:Text("markerConventions","Local marker meanings",0,y-8,self.cw,14);y=y-42
  local meanings={};for i=0,6 do meanings[#meanings+1]={value=i,label=M.modules.TacticalSignals.meanings[i]} end
  for i,name in ipairs(M.modules.TacticalSignals.markers) do
   local key="marker"..i
   self:Choice("meaning"..i,name..": "..M.modules.TacticalSignals.meanings[cfg[key]],meanings,cfg[key],0,y,self.cw,function(v) cfg[key]=v end);y=y-40
  end
  self:Button("copyConventions","Copy these conventions",0,y,self.cw,function() M.UI:CopyWindow("Tactical conventions",M.modules.TacticalSignals:ConventionText(self.draft)) end);y=y-46
  self:Check("pingLegend","Show the conventions card outside combat",cfg.legend,0,y,function(v) cfg.legend=v end);y=y-48
  self:Text("pingBoundary","These buttons edit native shortcuts; they do not send pings or apply markers. Native RAIDTARGET shortcuts act on the game target, not a saved mouseover. The out-of-combat cursor menu retains its separate mouseover identity checks. Native permissions, anti-spam rules and target/location behavior still apply. No key is assigned automatically. Saved game bindings remain assigned even if this presentation module is disabled.",0,y,self.cw,11)
  return true
 elseif id=="Preparations" then
  self:Text("prepSeparate","Manual, Supplies, Gear/details, Saved sets, Talents/entries. Forever durability; associated spell / temporary enchant. Legacy: source-pinned applied Forever. Camping stays manual.",0,-185,self.cw,12)
  self:Text("prepIDsHelp","Optional carried-stock snapshots: enter up to 8 item IDs separated by commas. No default essentials, minimum quantities or readiness verdict. Apply before opening. Selected IDs are profile preferences; observed counts are never saved or exported.",0,-290,self.cw,11)
  local supplyEdit=self:Edit("prepSupplyIDs",table.concat(cfg.supplyIDs,", "),0,-390,self.cw,function(text)
   if #text>192 then cfg.supplyIDs={text};return true end
   local ids={};local valid=text:match("^%s*$")~=nil
   if not valid then
    valid=text:match("^%s*%d+[%d%s,]*$")~=nil and not text:match(",%s*,") and not text:match(",%s*$")
    if valid then
     for token in text:gmatch("[^,]+") do
      if #ids>=8 or not token:match("^%s*%d+%s*$") then valid=false;break end
      ids[#ids+1]=tonumber(token)
     end
    end
   end
   -- Invalid text stays invalid draft data; Apply must reject, never silently
   -- commit the prior list or repair a malformed user's selection.
   cfg.supplyIDs=valid and ids or {text};return true
  end)
  -- One extra character makes even a native-truncated oversized paste invalid,
  -- never a silently shortened valid selection. Parsing remains bounded at 192.
  supplyEdit:SetMaxLetters(193)
  self:Button("prepOpen","Open applied Preparations",0,-438,self.cw,function() local _,why=M.modules.Preparations:Open();if why then self:Notice(why) end end)
  self:Button("prepBuffs","Configure exact-ID buff checks",0,-482,self.cw,function() self.page="Auras";self:Render() end)
  local ownerDraft,ownerProfile=self.draft,M.profile
  local function references(kind)
   if self.draft~=ownerDraft or M.profile~=ownerProfile or self.page~="Preparations" or self.setup then return end
   if M.ReferenceEditor then M.ReferenceEditor:Open(kind) end
  end
  self:Button("prepBuildReferences","Manage build references",0,-620,self.cw,function() references("builds") end)
  self:Button("prepStrategies","Manage manual strategies",0,-664,self.cw,function() references("strategies") end)
  self:Text("prepCharter","Supplies cover carried bags; Gear: own-equipment snapshot. Snapshots never saved or sent. Sets/details are read-only. Talents: config/staged only; entry node ranks. Not current state, usability or readiness. Native acceptance NOT_RUN.",0,-536,self.cw,11)
  return true
 end
 return previous(self,id,cfg)
end
