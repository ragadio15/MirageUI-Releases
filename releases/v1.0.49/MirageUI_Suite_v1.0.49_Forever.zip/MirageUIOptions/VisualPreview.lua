local M=MirageUI
if not M or not M.Options then return end
-- Real shared components, synthetic values only. Never reads or substitutes live units.
local V={views={},mode=10}
M.VisualPreview=V
local classes={"MAGE","WARLOCK","PALADIN","PRIEST","WARRIOR","ROGUE","DRUID","HUNTER","SHAMAN","MONK","DEATHKNIGHT","DEMONHUNTER","EVOKER"}
local function classColor(class)
 if C_ClassColor and C_ClassColor.GetClassColor then
  local ok,c=pcall(C_ClassColor.GetClassColor,class)
  if ok then
   local r,g,b=M.Safety:Field(c,"r"),M.Safety:Field(c,"g"),M.Safety:Field(c,"b")
   if M.Safety:Number(r) and M.Safety:Number(g) and M.Safety:Number(b) then return r,g,b end
  end
 end
 local c=M.Safety:Field(RAID_CLASS_COLORS,class)
 if c then local r,g,b=M.Safety:Field(c,"r"),M.Safety:Field(c,"g"),M.Safety:Field(c,"b");if M.Safety:Number(r) and M.Safety:Number(g) and M.Safety:Number(b) then return r,g,b end end
 return unpack(M.Visual.neutral)
end
function V:Alive()
 return self.frame and self.frame:IsVisible() and M.DialogNavigation.top==self.frame and not M.Safety:InCombat() and not M.state.safe and not M.state.cinematic
end
function V:Render(count)
 if M.Safety:InCombat() then return end
 self.mode=count or self.mode
 for _,v in ipairs(self.views) do v.frame:Hide() end
 local n=self.mode;local columns=n==40 and 4 or 2
 local w,h=n==40 and 125 or 150,n==40 and 32 or 34
 for i=1,n do
  local v=self.views[i]
  if not v then v=M.Display:CreateUnit(nil,"raid"..i,"",self.frame,"PartyRaid",true);self.views[i]=v end
  local group=math.floor((i-1)/5);local col=group%columns;local groupRow=math.floor(group/columns)
  local x=30+col*(w+18);local y=-190-groupRow*(5*(h+6)+18)-((i-1)%5)*(h+6)
  v.previewCompact=true
  v.frame:ClearAllPoints();v.frame:SetPoint("TOPLEFT",x,y);v.frame:SetSize(w,h)
  M.Display:SizeUnit(v,w,h)
  v.name:SetText("");v.level:SetText("");v.separator:SetText("");v.detail:SetText("")
  v.health:SetMinMaxValues(0,100);v.health:SetValue(i%5==0 and 75 or 100)
  v.power:SetMinMaxValues(0,100);v.power:SetValue(i%4==0 and 65 or 100)
  v.healthPercent:SetText("");v.powerPercent:SetText("");v.frame:Show()
 end
 local sample=self.sample
 if not sample then sample=M.Display:CreateUnit(nil,"DEMO","",self.frame,"UnitFrames",true);self.sample=sample end
 sample.frame:ClearAllPoints();sample.frame:SetPoint("TOPLEFT",30,-98);sample.frame:SetSize(300,55);M.Display:SizeUnit(sample,300,55)
 local class=classes[self.classIndex or 1]
 sample.name:SetText("Sample "..class:sub(1,1)..class:sub(2):lower());sample.name:SetTextColor(classColor(class));M.Visual:PlainName(sample.name,12)
 sample.level:SetText("70");sample.separator:SetText("|");sample.detail:SetText("")
 sample.health:SetMinMaxValues(0,100);sample.health:SetValue(100);sample.power:SetMinMaxValues(0,100);sample.power:SetValue(100)
 sample.frame:Show();M.Visual:Accent(sample,self.category)
 self.note:SetText("DEMO ONLY · Raid "..n.."\nSynthetic values, not in-game validation. Full health fills the track; compact raid cells omit names and percentages.")
 M.DialogNavigation:Refresh(self.frame)
end
function V:Open()
 if M.Safety:InCombat() or M.state.safe or M.state.cinematic then return false end
 if not self.frame then
  local f=M.UI:Panel("MirageVisualPreview","Subtle Minimal · DEMO",680,720);self.frame=f;M:TrackRoot("UnitFrames",f)
  f:SetSize(680,720)
  f.closeButton:ClearAllPoints();f.closeButton:SetPoint("TOPRIGHT",-14,-12)
  self.note=M.UI:Text(f,"",24,-49,11,630)
  self.navStart=M.UI:Button(f,"Controller / F6",460,-12,160,function() M.DialogNavigation:Start(f,true) end);f.heading:SetWidth(420)
  self.countButtons={}
  for i,count in ipairs({10,20,40}) do self.countButtons[i]=M.UI:Button(f,"Raid "..count,30+(i-1)*108,-670,100,function() if self:Alive() then self:Render(count) end end) end
  self.nextClass=M.UI:Button(f,"Next class",360,-104,130,function() if not self:Alive() then return end;self.classIndex=(self.classIndex or 1)%#classes+1;self:Render() end)
  self.border=M.UI:Button(f,"Debuff border",360,-143,130,function()
   if not self:Alive() then return end
   local labels={false,"Magic","Curse","Poison","Disease","Bleed"};self.categoryIndex=(self.categoryIndex or 1)%#labels+1;self.category=labels[self.categoryIndex];self:Render()
  end)
  M.UI:Text(f,"Border examples are synthetic categories,\nnot automatic dispel recommendations.",30,-619,10,610)
  M.DialogNavigation:Attach(f,{closeOnSuspend=true,allowed=function() return self:Alive() end,entries=function()
   local rows={{frame=self.navStart,key="navigation",kind="button"},{frame=self.nextClass,key="class",kind="button"},{frame=self.border,key="border",kind="button"}}
   for i,b in ipairs(self.countButtons) do rows[#rows+1]={frame=b,key="count:"..i,kind="button"} end
   rows[#rows+1]={frame=f.closeButton,key="close",kind="button"};return rows
  end})
 end
 local sw,sh=M.Safety:Public(UIParent.GetWidth,"number",UIParent),M.Safety:Public(UIParent.GetHeight,"number",UIParent)
 if M.Safety:Number(sw) and M.Safety:Number(sh) and sw>30 and sh>30 then self.frame:SetScale(math.min(1,(sw-30)/680,(sh-30)/720)) end
 M.UI:CloseChoices();M.DialogNavigation:Shown(self.frame);self.frame:Show();self:Render();return true
end
local O=M.Options
local units,plates=O.RenderUnitOptions,O.RenderNameplateOptions
function O:RenderUnitOptions(id,cfg)
 units(self,id,cfg)
 self:Button("visualDemo",M.Icons and M.Icons:Label(M.Icons:ForModule(id),"Preview the shared frame design (DEMO)",18) or "Preview the shared frame design (DEMO)",0,-(self.contentHeight or 800)-16,self.cw,function() V:Open() end)
end
function O:RenderNameplateOptions(cfg)
 plates(self,cfg)
 self:Button("visualDemo",M.Icons and M.Icons:Label("nameplates","Preview the shared frame design (DEMO)",18) or "Preview the shared frame design (DEMO)",0,-(self.contentHeight or 800)-16,self.cw,function() V:Open() end)
end
