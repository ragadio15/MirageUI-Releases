local M=MirageUI
if not M or not M.Options then return end
local O,U,P=M.Options,M.UI,M.Presentation
local titles={health="Player health",resource="Primary resource",cast="Player cast / channel",gcd="Global Cooldown (GCD)"}
function O:RenderIntegrationControls(y,compact)
 self.draft.presentation=P:Normalize(self.draft.presentation)
 local cfg=self.draft.presentation
 self:Text('ownershipTitle','One fact, one primary display',0,y,self.cw,16);y=y-38
 self:Text('ownershipInfo','Keep current displays preserves your existing setup. A primary choice suppresses duplicate passive Mirage visuals only; unavailable primaries retain backups. Native frames and secure player buttons remain available. Nothing changes until Apply / Finish.',0,y,self.cw,12);y=y-112
 self.primaryBundle=self.primaryBundle or 'Keep'
 local choices=P:Options('health')
 self:Choice('primaryBundle','Primary bundle: '..P.labels[self.primaryBundle],choices,self.primaryBundle,0,y,self.cw,function(v) self.primaryBundle=v end);y=y-38
 self:Button('stagePrimary','Stage this health / resource / cast owner',0,y,self.cw,function()
  local ok,why=self:FlushEdits();if ok==false then self:Notice(why);return end
  ok,why=P:StagePrimary(self.draft,self.primaryBundle);self:Render();self:Notice(why)
 end);y=y-48
 for _,fact in ipairs({'health','resource','cast','gcd'}) do local key=fact
  self:Choice('owner_'..key,titles[key]..': '..P.labels[cfg[key]],P:Options(key),cfg[key],0,y,self.cw,function(v) cfg[key]=v end);y=y-36
  self:Check('mirror_'..key,'Allow extra Mirage '..titles[key]:lower()..' displays',cfg[key..'Mirror'],0,y,function(v) cfg[key..'Mirror']=v end);y=y-42
 end
 self:Button('accessibleBundle','Stage Accessible presentation',0,y,self.cw,function()
  self.draft.textScale=1.2;self.draft.contrast=true;self.draft.fade=0
  local h=self.draft.modules.UnderCharacterHUD
  if h.enabled then h.width=240;h.healthHeight=14;h.resourceHeight=10;h.castHeight=10 end
  self:Render();self:Notice('Accessible sizes and contrast staged. No module was enabled and no native setting or binding was changed.')
 end);y=y-52
 self:Text('nativeTitle','Native settings review',0,y,self.cw,16);y=y-38
 for _,row in ipairs(M.IntegrationReview:Inspect(self.draft)) do
  self:Text('native_'..row.id,row.state..' — '..row.text,0,y,self.cw,12)
  -- Conservative measured row sizing; no live combat or private text involved.
  local height=math.max(76,math.ceil(#row.text/math.max(24,math.floor(self.cw/(8.5*(self.draft.textScale or 1)))))*22+24)
  y=y-height
 end
 self:Button('copyNative','Copy this integration review',0,y,self.cw,function() U:CopyWindow('Display and native-settings review',M.IntegrationReview:Report(self.draft)) end);y=y-46
 self:Text('bindingsBoundary','Profile Apply / Undo changes Mirage preferences only. Native keyboard shortcuts use their own explicit review and restoration controls. Native markers act on the selected target; the out-of-combat cursor menu captures the unit under your pointer.',0,y,self.cw,12)
 return y-100
end
function O:RenderIntegration()
 self:RenderIntegrationControls(0,false)
end
local oldSupport=O.RenderSupport
function O:RenderSupport()
 oldSupport(self)
 local y=-(self.contentHeight+20)
 self:Button('whyAll12','Why are my displays visible?',0,y,self.cw,function() U:CopyWindow('Visibility explanations',M.Diagnostics:Why()) end);y=y-42
 self:Button('contextRehearsal12','Rehearse contextual behavior (DEMO)',0,y,self.cw,function() U:CopyWindow('DEMO — not live game information',M.FirstTranche:Rehearsal()) end)
end
