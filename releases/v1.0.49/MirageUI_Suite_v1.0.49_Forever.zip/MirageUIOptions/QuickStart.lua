local M=MirageUI
if not M or not M.Options then return end
local O,U=M.Options,M.UI
-- The previous full editor is retained behind More settings. First use is one
-- explicit consent, not seven pages of configuration and engineering prose.
local oldCreate,oldRender,oldApply,oldCancel,oldOpen=O.Create,O.Render,O.Apply,O.Cancel,O.Open
local oldHome,oldAccessibility,oldFit=O.RenderHome,O.RenderAccessibility,O.FitWindow
local oldModule,oldSupport,oldSearch=O.RenderModule,O.RenderSupport,O.Search
local simplePages={Home=true,UnderCharacterHUD=true,Nameplates=true,Accessibility=true,Support=true}
local simpleLabels={Home="Overview and layout",UnderCharacterHUD="Player bars",Cursor="Cursor",Nameplates="Names and health bars",Accessibility="Text and comfort",Support="Help and restore"}
function O:FitWindow()
    if self.advanced and not self.setup then return oldFit(self) end
    if not self.frame or M.Safety:InCombat() then return end
    local sw,sh=UIParent:GetWidth(),UIParent:GetHeight()
    local width=math.min(self.setup and 760 or 980,sw-30)
    local height=math.min(self.setup and 540 or 680,sh-30)
    self.frame:SetSize(width,height)
    self.previewEnabled=false
    if self.preview then self.preview:Hide() end;if self.previewButton then self.previewButton:Hide() end
    local left=self.setup and 36 or 215
    self.cw=width-left-38
    self.scroll:ClearAllPoints();self.scroll:SetPoint("TOPLEFT",left,-110);self.scroll:SetPoint("BOTTOMLEFT",left,94);self.scroll:SetWidth(self.cw+15)
    self.content:SetWidth(self.cw)
    self.search:ClearAllPoints();self.search:SetPoint("TOPLEFT",215,-70);self.search:SetWidth(math.max(200,width-255))
    self.notice:ClearAllPoints();self.notice:SetPoint("TOPLEFT",left,-height+80);self.notice:SetWidth(self.cw)
    local buttons={self.apply,self.cancel,self.undo,self.unlock,self.safeButton}
    local bw=math.floor((self.cw-32)/5)
    for i,b in ipairs(buttons) do
        b:ClearAllPoints();b:SetPoint("TOPLEFT",left+(i-1)*(bw+8),-height+44);b:SetWidth(bw);b.label:SetWidth(bw-16)
    end
    if self.setup then
        self.apply:ClearAllPoints();self.apply:SetPoint("TOPLEFT",left,-height+44);self.apply:SetWidth(math.min(320,self.cw-160));self.apply.label:SetWidth(self.apply:GetWidth()-16)
        self.cancel:ClearAllPoints();self.cancel:SetPoint("TOPLEFT",left+self.apply:GetWidth()+14,-height+44);self.cancel:SetWidth(126);self.cancel.label:SetWidth(110)
    end
    self.frame.closeButton:ClearAllPoints();self.frame.closeButton:SetPoint("TOPLEFT",width-42,-12)
end
function O:Create()
    oldCreate(self);if self.ShellBoundary then self:ShellBoundary() end
    if not self.moreButton then
        self.moreButton=self:ShellBuild("Button",self.frame,"More settings",18,-70,154,function()
            if self.ShellTransition then return self:ShellTransition(false,not self.advanced,"Home",true) end
            self:FlushEdits();self.advanced=not self.advanced;self.page="Home";self.search:SetText("");self:Render()
        end)
        local hide=self.frame:GetScript("OnHide")
        self.frame:SetScript("OnHide",function(...)
            self.confirmRestore=nil
            -- A combat/native Hide interrupts setup, but is not user consent or
            -- a persisted opt-out. Hidden drafts cannot later accept setup.
            if self.setup then
                self.pendingCursorImport=nil;self.pendingFit=nil;self.draft=nil;self.setup=false
                self.shellWork={};self.shellSession=nil;self.shellViewport=nil
            end
            if hide then return hide(...) end
        end)
        local key=self.frame:GetScript("OnKeyDown")
        self.frame:SetScript("OnKeyDown",function(frame,button)
            -- Ordinary Escape is explicit dismissal even with F6 navigation off.
            -- Automatic combat Hide above remains only an interruption.
            if button=="ESCAPE" and self.setup and not M.Safety:InCombat() and not M.Safety:Typing()
                and not (M.OptionsNavigation and M.OptionsNavigation:Busy()) then
                self:Cancel()
                -- OnHide releases keyboard navigation, so consume this one
                -- handled Escape only after that cleanup has run.
                if self.frame==frame and not self.draft and not self.setup and not M.Safety:InCombat() then frame:SetPropagateKeyboardInput(false) end
                return
            end
            if key then return key(frame,button) end
        end)
    end
    self:FitWindow()
end
function O:Search(text)
    oldSearch(self,text);if self.ShellBoundary then self:ShellBoundary() end
    if text and text~="" then for _,p in ipairs(self.pages) do self:ShellCall(self.navButtons[p.id],"SetText",p.name) end end
    if self.advanced or (text and text~="") then return end
    local n=0
    for _,p in ipairs(self.pages) do
        local b=self.navButtons[p.id]
        if not simplePages[p.id] then self:ShellCall(b,"Hide")
        elseif self:ShellCall(b,"IsShown") then
            self:ShellCall(b,"ClearAllPoints");self:ShellCall(b,"SetPoint","TOPLEFT",0,-n*44);b.mirageNavY=-n*44;self:ShellCall(b,"SetText",simpleLabels[p.id] or p.name);n=n+1
        end
    end
    self:ShellCall(self.nav,"SetHeight",math.max(44,n*44))
end
function O:Open()
    if M.Safety:InCombat() then return end
    self.pendingFit=nil;self.confirmRestore=nil
    self.advanced=false;self.page="Home"
    oldOpen(self)
end
function O:Setup()
    if M.Safety:InCombat() then M:Print("Set up MirageUI after combat.");return false end
    self:Create();self.pendingCursorImport=nil;self.pendingFit=nil;self.confirmRestore=nil;self.draft=M:Copy(M.profile)
    self.setup=true;self.step=1;self.advanced=false;self.frame:Show();self:Render();return true
end
function O:RenderSetup()
    local activation=M.Diagnostics:ActivationState()
    if activation.setupBlocked then
        self:Text("quickTitle",activation.title,0,0,self.cw,21)
        self:Text("quickSummary",activation.message,0,-48,self.cw,14)
        self:Text("quickChanges",M.Diagnostics:BuildSummary(),0,-108,self.cw,13)
        self:Text("quickConsent",activation.help,0,-210,self.cw,12)
        if activation.canRecover then self:Button("quickResume","Resume MirageUI",0,-288,self.cw,function() self:ResumeRuntime() end) end
        local _,why=M.Managed:Preflight()
        self.apply:SetEnabled(false);self:Notice(why);return
    end
    self:Text("quickTitle","Your world. One coordinated interface.",0,0,self.cw,21)
    self:Text("quickSummary","MirageUI will enable its supported features, arrange them for your screen, and show information when it matters.",0,-48,self.cw,14)
    self:Text("quickChanges","Automatic spacing and scale\nFewer duplicate Blizzard displays\nQuiet nameplates with 90% transparent backgrounds",0,-108,self.cw,13)
    self:Text("quickConsent","Setup adjusts MirageUI and the supported Blizzard displays. Your action keys and special game controls stay intact. A copy of your previous MirageUI setup is saved for recovery.",0,-192,self.cw,12)
    self:Text("quickLater","No presets to choose. Fine-tune the appearance later in Settings.",0,-258,self.cw,12)
    local ok,why=M.Managed:Preflight()
    if ok then local r=M.Readiness:Inspect(self.draft);ok=r.canFinish;for _,issue in ipairs(r.issues) do if issue.blocking then why=issue.text;break end end end
    self.apply:SetEnabled(ok)
    if not ok then self:Notice(why) end
end
function O:Apply()
    local draft,frame,profile=self.draft,self.frame,M.profile
    if not draft or not frame then return false end
    local shown,status=M.Safety:Public(frame.IsShown,"boolean",frame)
    if status~="KNOWN" or shown~=true or self.draft~=draft or self.frame~=frame or M.profile~=profile then return false end
    local session=self.shellSession
    if self.setup and (not session or session.draft~=self.draft or session.profile~=M.profile or session.frame~=self.frame) then return false end
    if self.setup then
        self.apply:Disable()
        local ok,why=M.Managed:Accept()
        if not ok then
            if self.frame==frame and self.draft==draft and M.profile==profile and self.setup then
                -- Recompute the state and preflight after a failed transaction.
                -- A Core stop must not leave the old ready screen or live Accept.
                self:Render();self:Notice(why or M.Diagnostics:ActivationMessage())
            end
            return false
        end
        self.pendingCursorImport=nil;self.setup=false;self.draft=M:Copy(M.profile);self.page="Home";self:Render();self:Notice(why);return true
    end
    if self.pendingFit and self.draft then
        local ok,why=self:FlushEdits();if ok==false then self:Notice(why);return false end
        -- A resize may have happened since Fit was staged. Project again into
        -- the draft, never into the live profile, before the final transaction.
        -- Flushing a later manual numeric edit may itself turn auto-fit off.
        if self.draft.autoLayout then
            local p,reason=M.Managed:BuildRefit(self.draft)
            if not p then self:Notice(reason);return false end
            self.draft=p
            -- A failed settings Apply retains this prepared Fit draft for
            -- correction; it remains the same footer session, not a new wizard.
            if session and self.shellSession==session and session.profile==M.profile then session.draft=p end
        end
    end
    local applied=oldApply(self)
    if applied then self.pendingFit=nil
    elseif self.frame==frame and self.draft==draft and M.profile==profile and M.Diagnostics:ActivationState().setupBlocked then
        self:Render();self:Notice(M.Diagnostics:ActivationMessage())
    end
    return applied
end
function O:Cancel(setupDismissal)
    self.pendingFit=nil;self.confirmRestore=nil
    if self.setup then
        local draft,frame,work=self.draft,self.frame,self.shellWork
        local remembered,why=M.Managed:Dismiss(setupDismissal)
        if self.draft~=draft or self.frame~=frame or self.shellWork~=work or not self.setup then return false end
        self.pendingCursorImport=nil;self.draft=nil;self.setup=false;self.frame:Hide();U:CloseChoices()
        if not remembered then M:Print(why) end
        return remembered
    end
    return oldCancel(self)
end
function O:RenderHome()
    if self.advanced then return oldHome(self) end
    local activation=M.Diagnostics:ActivationState()
    if activation.setupBlocked then
        self:Text("homeTitle",activation.title,0,0,self.cw,20)
        self:Text("homeDescription",activation.message,0,-45,self.cw,13)
        self:Text("homeBuild",M.Diagnostics:BuildSummary(),0,-112,self.cw,12)
        self:Text("homeHint",activation.help,0,-218,self.cw,12)
        if activation.canRecover then self:Button("homeResume","Resume MirageUI",0,-292,self.cw,function() self:ResumeRuntime() end) end
        return
    end
    self:Text("homeTitle",activation.code=="DISABLED" and activation.title or M.profile.managed and "MirageUI is in charge of the view" or "Welcome to MirageUI",0,0,self.cw,20)
    self:Text("homeDescription",activation.code=="DISABLED" and activation.message or M.profile.managed and "Your interface is arranged automatically. It quiets down between activities and returns information when you need it." or "Set up the complete experience in one step. No preset or module selection is required.",0,-45,self.cw,13)
    local y=-112
    self:Button("automaticSetup",M.profile.managed and "Run automatic setup again" or "Set up MirageUI",0,y,self.cw,function() self:Setup() end);y=y-48
    self:Button("fitScreen","Fit the layout to my screen",0,y,self.cw,function()
        local ok,why=self:FlushEdits();if ok==false then self:Notice(why);return end
        local p,reason=M.Managed:BuildRefit(self.draft)
        if not p then self:Notice(reason);return end
        self.draft=p;self.pendingFit=true;self:Render()
        self:Notice("Layout fitted in your draft. Apply saves it; Close discards it.")
    end);y=y-48
    self:Button("arrange","Move individual elements",0,y,self.cw,function() M.Editor:Open() end);y=y-48
    self:Button("reveal","Show the interface briefly",0,y,self.cw,function() M.CVE:Reveal(12);M.ManagedNative:Tick() end);y=y-56
    self:Text("homeHint","Right-click the MirageUI button to reveal the interface. /mirage safe restores native access; Help and restore can undo setup.",0,y,self.cw,12)
end
local function advanced(self,page)
    if self.ShellTransition then return self:ShellTransition(false,true,page) end
    self:FlushEdits();self.advanced=true;self.page=page;self:Render()
end
function O:RenderModule(id)
    if self.advanced or (self.search and self.search:GetText()~="") then return oldModule(self,id) end
    local c=self.draft.modules[id]
    if id=="Nameplates" then
        self:Text("namesTitle","Names and health bars",0,0,self.cw,20)
        self:Text("namesIntro","A light backdrop lets the world show through. Names and health bars stay readable.",0,-42,self.cw,12)
        self:Slider("simplePlateTransparency","Background transparency (%)",0,-105,self.cw,100-c.panelOpacity,0,100,5,function(v) c.panelOpacity=100-v end)
        self:Slider("simplePlateSize","Nameplate size (%)",0,-185,self.cw,c.cardScale,60,160,5,function(v) self:SetNameplateScale(c,v) end)
        self:Slider("simplePlateText","Name text size",0,-265,self.cw,c.nameSize,9,18,1,function(v) c.nameSize=v end)
        self:Button("detailsNames","More nameplate settings",0,-350,self.cw,function() advanced(self,id) end)
    elseif id=="UnderCharacterHUD" then
        self:Text("hudTitle","Player bars",0,0,self.cw,20)
        self:Text("hudIntro","Your health and resource sit below the center of the screen. Their position does not follow camera zoom.",0,-42,self.cw,12)
        self:Slider("simpleHUDWidth","Width",0,-108,self.cw,c.width,160,300,5,function(v) self:SetHUDValue(c,"width",v) end)
        self:Slider("simpleHUDPosition","Position below screen center",0,-188,self.cw,-c.y,60,360,5,function(v) self:SetHUDValue(c,"y",-v) end)
        self:Button("placeHUD","Move the player bars",0,-274,self.cw,function() if M.HUDEditor then M.HUDEditor:Open(self) end end)
        self:Button("detailsHUD","More player-bar settings",0,-322,self.cw,function() advanced(self,id) end)
        self:Button("referenceHUD","Stage reference central HUD",0,-370,self.cw,function() self:StageHUDReference() end)
        self:Text("referenceHUDNote","Stages combat or target, cast above health and power, and separate fill and backing opacity. Apply saves; Close discards. Enabled rows, display owners and percentage choices are preserved. Percentages require support and room to fit.",0,-412,self.cw,11)
    else return oldModule(self,id) end
end
function O:RenderAccessibility()
    if self.advanced then return oldAccessibility(self) end
    local p=self.draft
    self:Text("comfortTitle","Text and comfort",0,0,self.cw,20)
    self:Slider("comfortText","Settings text size",0,-65,self.cw,p.textScale,.85,1.5,.05,function(v) p.textScale=v end)
    self:Check("comfortContrast","Stronger contrast in settings",p.contrast,0,-150,function(v) p.contrast=v end)
    self:Text("comfortHint","Timing and essential information remain available. Apply saves these changes.",0,-296,self.cw,12)
    self:Button("comfortAdvanced","Keyboard, controller and spoken labels",0,-350,self.cw,function() advanced(self,"Accessibility") end)
end
function O:RenderSupport()
    if self.advanced then return oldSupport(self) end
    local activation=M.Diagnostics:ActivationState()
    self:Text("helpTitle","Help and restore",0,0,self.cw,20)
    self:Text("helpIntro",activation.message,0,-45,self.cw,12)
    self:Button("simpleSafe","Stop MirageUI and restore native displays",0,-110,self.cw,function() self:StopRuntime() end)
    self:Button("simpleResume","Resume MirageUI",0,-158,self.cw,function() self:ResumeRuntime() end):SetEnabled(activation.canRecover)
    self:Button("restoreBeforeSetup","Restore my pre-setup MirageUI settings",0,-206,self.cw,function()
        if not self.confirmRestore then self.confirmRestore=true;self:Notice("Click again to restore your previous setup.");return end
        self.confirmRestore=nil;local ok,why=M.Managed:RestorePrevious();self.draft=M:Copy(M.profile);self:Render();self:Notice(why)
    end)
    self:Button("copyManaged","Copy a support report",0,-254,self.cw,function() U:CopyWindow("MirageUI support",M.Managed:Report().."\n"..M.Readiness:Export()) end)
    self:Button("technicalHelp","More help and diagnostics",0,-320,self.cw,function() advanced(self,"Support") end)
end
function O:Render()
    if self.setup or self.advanced or self.page~="Support" then self.confirmRestore=nil end
    oldRender(self);if self.ShellBoundary then self:ShellBoundary() end
    if not self.frame then return end
    if self.setupChrome then self.setupChrome:Hide() end
    self.navScroll:SetShown(not self.setup);self.search:SetShown(not self.setup)
    if self.moreButton then self.moreButton:SetShown(not self.setup);self.moreButton:SetText(self.advanced and "Simple settings" or "More settings") end
    if not self.advanced or self.setup then if self.preview then self.preview:Hide() end;if self.previewButton then self.previewButton:Hide() end end
    if self.setup then
        self.apply:SetText("Set up MirageUI");self.cancel:SetText("Not now")
        self.undo:Hide();self.unlock:Hide();self.safeButton:Hide()
        local ok=M.Managed:Preflight();if ok then ok=M.Readiness:Inspect(self.draft).canFinish end;self.apply:SetEnabled(ok)
    else
        self.cancel:SetText("Close");self.unlock:SetText("Move UI")
        if self.advanced then
            for _,p in ipairs(self.pages) do self.navButtons[p.id]:SetText(p.name) end
        end
        self:Search(self.search:GetText())
    end
end
