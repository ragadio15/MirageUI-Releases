local M=MirageUI
if not M or not M.Workspace then return end
local U,S,W,A=M.UI,M.Safety,M.WorkspaceModel,M.Workspace
local E={boxes={},searchRows={},showGrid=false,snap=true,query="",advanced=false,searchShown=false,filters={unavailable=false,references=false}}
M.ElementMap=E
local function color() return M.Elements.contextColors[W.context or "All"] end
local function textColor(font,c) font:SetTextColor(c[1],c[2],c[3],1) end
local function fit(frame,w,h)
 frame:SetScale(math.max(.45,math.min(1,(UIParent:GetWidth()-40)/w,(UIParent:GetHeight()-40)/h)))
end
function E:IsOpen() return self.frame and self.frame:IsShown() or false end
function E:Notice(text) if self.message then self.message:SetText(text or "") end end
function E:SetPanel(panel,shown,immediate)
 if not panel then return end
 panel.mirageWanted=shown==true
 if immediate then panel:SetScript("OnUpdate",nil);panel:SetAlpha(1);panel:SetShown(shown);return end
 local start=panel:IsShown() and panel:GetAlpha() or 0
 if shown then panel:Show() end
 local elapsed=0;local target=shown and 1 or 0
 panel:SetScript("OnUpdate",function(frame,delta)
  elapsed=math.min(.14,elapsed+delta);local progress=elapsed/.14
  frame:SetAlpha(start+(target-start)*progress)
  if progress>=1 then frame:SetScript("OnUpdate",nil);if not frame.mirageWanted then frame:Hide() end;frame:SetAlpha(1) end
 end)
end
-- Selecting an element only changes the selection. Panel visibility belongs to
-- explicit hub/close controls, and hiding controls first retains pending input.
function E:TogglePanel(which)
 local panel=which=="advanced" and self.inspector or which=="search" and self.searchPanel or self.contextPanel
 if not panel or not A:FlushInputs() then return false end
 local shown=not panel.mirageWanted
 if which=="advanced" then self.advanced=shown elseif which=="search" then self.searchShown=shown end
 self:SetPanel(panel,shown)
 return true
end
function E:PlaceHub()
 if not self.panelRoot then return end
 local scale=self.panelRoot:GetScale() or 1
 local width,height=UIParent:GetWidth(),UIParent:GetHeight()
 if not S:Number(scale) or scale<=0 or not S:Number(width) or not S:Number(height) then return end
 local maxX=math.max(0,width/2-560*scale-8)
 local maxY=math.max(0,height/2-380*scale-8)
 self.hubX=math.max(-maxX,math.min(maxX,self.hubX or 0))
 self.hubY=math.max(-maxY,math.min(maxY,self.hubY or 0))
 self.panelRoot:ClearAllPoints();self.panelRoot:SetPoint("CENTER",UIParent,"CENTER",self.hubX/scale,self.hubY/scale)
end
function E:StartHubDrag()
 if S:InCombat() or not M.Elements:EditingAllowed() or not A:FlushInputs() then return false end
 if self.drag then self:StopDrag() end
 local x,y=GetCursorPosition();local scale=UIParent:GetEffectiveScale()
 if not S:Number(x) or not S:Number(y) or not S:Number(scale) or scale<=0 then return false end
 self.hubDrag={x=x/scale,y=y/scale,scale=scale,width=UIParent:GetWidth(),height=UIParent:GetHeight(),beforeX=self.hubX or 0,beforeY=self.hubY or 0}
 return true
end
function E:UpdateHubDrag()
 local d=self.hubDrag;if not d then return end
 local x,y=GetCursorPosition();local scale=UIParent:GetEffectiveScale()
 if S:InCombat() or not M.Elements:EditingAllowed() or scale~=d.scale or UIParent:GetWidth()~=d.width or UIParent:GetHeight()~=d.height then
  self:StopHubDrag(true);return
 end
 if not S:Number(x) or not S:Number(y) then return end
 self.hubX=d.beforeX+x/scale-d.x;self.hubY=d.beforeY+y/scale-d.y;self:PlaceHub()
end
function E:StopHubDrag(cancel)
 local d=self.hubDrag;if not d then return end
 if cancel then self.hubX,self.hubY=d.beforeX,d.beforeY else self:UpdateHubDrag();if self.hubDrag~=d then return end end
 self.hubDrag=nil;self:PlaceHub()
end
-- The footer is independent of the central hub. Use screen-normalized
-- coordinates so its last position stays reachable after a display change.
function E:PlaceToolbar()
 if not self.toolbar then return end
 local width,height=UIParent:GetWidth(),UIParent:GetHeight()
 local scale=self.panelRoot:GetScale() or 1
 if not S:Number(width) or not S:Number(height) or width<=0 or height<=0 or not S:Number(scale) or scale<=0 then return end
 self.toolbar:SetScale(scale)
 local halfW,halfH=460*scale,44*scale
 local maxX=math.max(0,width/2-halfW-8);local maxY=math.max(0,height/2-halfH-8)
 local x=math.max(-maxX,math.min(maxX,(self.toolbarX or 0)*width))
 local y=math.max(-maxY,math.min(maxY,(self.toolbarY or -.30)*height))
 self.toolbarX,self.toolbarY=x/width,y/height
 self.toolbar:ClearAllPoints();self.toolbar:SetPoint("CENTER",UIParent,"CENTER",x/scale,y/scale)
end
function E:StartToolbarDrag()
 if S:InCombat() or not M.Elements:EditingAllowed() or not A:FlushInputs() then return false end
 if self.drag then self:StopDrag() end
 self:StopHubDrag()
 local x,y=GetCursorPosition();local scale=UIParent:GetEffectiveScale()
 if not S:Number(x) or not S:Number(y) or not S:Number(scale) or scale<=0 then return false end
 self:PlaceToolbar()
 self.toolbarDrag={x=x/scale,y=y/scale,scale=scale,width=UIParent:GetWidth(),height=UIParent:GetHeight(),beforeX=self.toolbarX,beforeY=self.toolbarY}
 return true
end
function E:UpdateToolbarDrag()
 local d=self.toolbarDrag;if not d then return end
 local x,y=GetCursorPosition();local scale=UIParent:GetEffectiveScale()
 if S:InCombat() or not M.Elements:EditingAllowed() or scale~=d.scale or UIParent:GetWidth()~=d.width or UIParent:GetHeight()~=d.height then
  self:StopToolbarDrag(true);return
 end
 if not S:Number(x) or not S:Number(y) then return end
 self.toolbarX=d.beforeX+(x/scale-d.x)/d.width;self.toolbarY=d.beforeY+(y/scale-d.y)/d.height
 self:PlaceToolbar()
end
function E:StopToolbarDrag(cancel)
 local d=self.toolbarDrag;if not d then return end
 if cancel then self.toolbarX,self.toolbarY=d.beforeX,d.beforeY
 else self:UpdateToolbarDrag();if self.toolbarDrag~=d then return end end
 self.toolbarDrag=nil;self:PlaceToolbar()
end
function E:Create()
 if self.frame then return end
 local f=CreateFrame("Frame","MirageUIElementMap",UIParent);self.frame=f;f:SetAllPoints(UIParent);f:SetFrameStrata("DIALOG");f:SetFrameLevel(20)
 self.gridFrame=CreateFrame("Frame",nil,f);self.gridFrame:SetAllPoints(f);self.gridFrame:SetFrameLevel(21);self.gridLines={}
 self.panelRoot=CreateFrame("Frame",nil,f);self.panelRoot:SetSize(1000,650);self.panelRoot:SetPoint("CENTER");self.panelRoot:SetFrameLevel(80)
 local hub=U:Button(self.panelRoot,"",0,0,76,function(_,button)
  if self.hubGesture then self.hubGesture=nil;return end
  if IsControlKeyDown and IsControlKeyDown() then return end
  if IsShiftKeyDown and IsShiftKeyDown() then self:TogglePanel("context")
  elseif button=="RightButton" then self:TogglePanel("search")
  else self:TogglePanel("advanced") end
 end);self.hub=hub;hub:ClearAllPoints();hub:SetPoint("CENTER");hub:SetSize(76,76);hub:RegisterForClicks("LeftButtonUp","RightButtonUp")
 hub:SetScript("OnMouseDown",function(_,button)
  self.hubGesture=nil
  if button=="LeftButton" and IsControlKeyDown and IsControlKeyDown() then self.hubGesture=true;self:StartHubDrag() end
 end)
 hub:SetScript("OnMouseUp",function(_,button) if button=="LeftButton" then self:StopHubDrag() end end)
 local icon=hub:CreateTexture(nil,"ARTWORK");icon:SetAllPoints();icon:SetTexture("Interface\\AddOns\\MirageUI\\Media\\Mark.tga");self.hubIcon=icon
 hub:SetScript("OnEnter",function()
  if GameTooltip then GameTooltip:SetOwner(hub,"ANCHOR_TOP");GameTooltip:SetText("MirageUI Customize");GameTooltip:AddLine("Left-click: Display settings (left)\nRight-click: Search (right)\nShift-click: Context (above)\nCtrl + left-drag: move hub and menus\nEscape: close or keep your draft",1,1,1);GameTooltip:Show() end
 end)
 hub:SetScript("OnLeave",function() if GameTooltip then GameTooltip:Hide() end end)
 local c=CreateFrame("Frame",nil,self.panelRoot,"BackdropTemplate");self.contextPanel=c;c:SetSize(520,76);c:SetPoint("BOTTOM",hub,"TOP",0,250);U:Backdrop(c);c:EnableMouse(true);c.mirageWanted=true
 self.contextTitle=U:Text(c,M.Icons and M.Icons:Label("visibility","Preview visibility",16) or "Preview visibility",14,-10,12,492)
 self.contextButtons={}
 for i,id in ipairs({"All","Idle","Moving","Combat"}) do
  self.contextButtons[id]=U:Button(c,id,12+(i-1)*126,-35,118,function() self:SetContext(id) end)
 end
 local left=CreateFrame("Frame",nil,self.panelRoot,"BackdropTemplate");self.inspector=left;left:SetSize(450,566);left:SetPoint("RIGHT",hub,"LEFT",-22,0);U:Backdrop(left);left:EnableMouse(true)
 self.inspectorTitle=U:Text(left,M.Icons and M.Icons:Label("mirageui-options","Display settings",20) or "Display settings",16,-15,18,370);U:SetTextRole(self.inspectorTitle,"accent")
 self.closeAdvanced=U:Button(left,"X",412,-10,26,function() self:TogglePanel("advanced") end)
 self.inspectorScroll=M.UI:Scroll(left);self.inspectorScroll:SetPoint("TOPLEFT",16,-50);self.inspectorScroll:SetSize(413,498)
 self.inspectorBody=CreateFrame("Frame",nil,self.inspectorScroll);self.inspectorBody:SetSize(410,500);self.inspectorScroll:SetScrollChild(self.inspectorBody)
 self.inspectorForm=M.WorkspaceForm:New(self.inspectorBody,405)
 local right=CreateFrame("Frame",nil,self.panelRoot,"BackdropTemplate");self.searchPanel=right;right:SetSize(340,566);right:SetPoint("LEFT",hub,"RIGHT",22,0);U:Backdrop(right);right:EnableMouse(true)
 U:SetTextRole(U:Text(right,"Search",16,-15,18,266),"accent")
 self.closeSearch=U:Button(right,"X",302,-10,26,function() self:TogglePanel("search") end)
 self.search=U:Edit(right,16,-49,306,"",nil,80)
 self.search:SetScript("OnTextChanged",function(box,user)
  if user then self.query=box:GetText();self.searchScroll:SetVerticalScroll(0);self:RenderSearch() end
 end)
 self.search:SetScript("OnEscapePressed",function(box) box:ClearFocus() end)
 local filters=CreateFrame("Frame",nil,right);filters:SetPoint("TOPLEFT",16,-88);filters:SetSize(306,80)
 self.filterForm=M.WorkspaceForm:New(filters,306)
 self.searchHelp=U:Text(right,"",16,-172,12,306);self.searchHelp:SetHeight(34)
 self.searchScroll=M.UI:Scroll(right);self.searchScroll:SetPoint("TOPLEFT",16,-214);self.searchScroll:SetSize(306,332)
 self.searchBody=CreateFrame("Frame",nil,self.searchScroll);self.searchBody:SetSize(284,420);self.searchScroll:SetScrollChild(self.searchBody)
 self.selectedLabel=U:Text(self.panelRoot,"Select a display or search.",0,0,12,250);self.selectedLabel:ClearAllPoints();self.selectedLabel:SetPoint("TOP",hub,"BOTTOM",0,-16);self.selectedLabel:SetJustifyH("CENTER");self.selectedLabel:SetHeight(72)
 local bottom=CreateFrame("Frame",nil,f,"BackdropTemplate");self.toolbar=bottom;bottom:SetSize(920,88);bottom:SetFrameLevel(90);U:Backdrop(bottom);bottom:EnableMouse(true)
 bottom:RegisterForDrag("LeftButton");bottom:SetScript("OnDragStart",function() self:StartToolbarDrag() end);bottom:SetScript("OnDragStop",function() self:StopToolbarDrag() end)
 local grip=bottom:CreateTexture(nil,"ARTWORK");grip:SetColorTexture(.83,.65,.35,.6);grip:SetSize(56,2);grip:SetPoint("TOP",0,-6)
 bottom:SetScript("OnEnter",function() if GameTooltip then GameTooltip:SetOwner(bottom,"ANCHOR_TOP");GameTooltip:SetText("Customize controls");GameTooltip:AddLine("Drag the bar background to move it.",1,1,1);GameTooltip:Show() end end)
 bottom:SetScript("OnLeave",function() if GameTooltip then GameTooltip:Hide() end end)
 self.apply=U:Button(bottom,"Apply",12,-20,100,function() if A:Apply() then self:Render() end end)
 self.undo=U:Button(bottom,"Undo",122,-20,90,function() A:Undo() end)
 self.cancel=U:Button(bottom,"Cancel",222,-20,100,function() A:DiscardAndClose() end)
 self.gridToggle=U:Button(bottom,"Grid: Off",332,-20,120,function() self.showGrid=not self.showGrid;self:RefreshGrid() end)
 self.snapToggle=U:Button(bottom,"Snap: On",462,-20,120,function() self.snap=not self.snap;self.snapToggle:SetText(self.snap and "Snap: On" or "Snap: Off") end)
 self.gridSize=U:Button(bottom,"Grid spacing",592,-20,150,function(button)
  U:Choose(button,{4,8,16,24,32},W.draft.grid,function(v) A:Change(function(p) p.grid=v end);self:RefreshGrid() end)
 end)
 self.back=U:Button(bottom,"Back to settings",754,-20,154,function() A:Open("Customize") end)
 self.message=U:Text(bottom,"",14,-58,12,892);self.message:SetHeight(24)
 f:EnableKeyboard(true);if f.SetPropagateKeyboardInput then f:SetPropagateKeyboardInput(true) end
 f:SetScript("OnKeyDown",function(_,key)
  if key=="ESCAPE" then
   if f.SetPropagateKeyboardInput then f:SetPropagateKeyboardInput(false) end
   if M.SuiteLauncher and M.SuiteLauncher.CloseTransient and M.SuiteLauncher:CloseTransient("ESCAPE") then return end
   if M.UI.choices and M.UI.choices:IsShown() then M.UI:CloseChoices() else A:RequestClose() end
  elseif f.SetPropagateKeyboardInput then f:SetPropagateKeyboardInput(true) end
 end)
 f:SetScript("OnUpdate",function(_,elapsed)
  self.elapsed=(self.elapsed or 0)+elapsed;if self.elapsed<1/30 then return end;self.elapsed=0
  local allowed,message=M.Elements:EditingAllowed()
  if not allowed then A:PauseForNativeEditor(message);return end
  if self.drag then self:UpdateDrag() end
  if self.hubDrag then self:UpdateHubDrag() end
  if self.toolbarDrag then self:UpdateToolbarDrag() end
  -- A single texture breathes only while customization is visible.
  local alpha=.82+.14*math.sin(S:Now()*2);self.hubIcon:SetAlpha(alpha)
 end)
 f:RegisterEvent("PLAYER_REGEN_DISABLED");f:RegisterEvent("DISPLAY_SIZE_CHANGED");f:RegisterEvent("UI_SCALE_CHANGED")
 f:SetScript("OnEvent",function(_,event)
  if event=="PLAYER_REGEN_DISABLED" then self:PauseForCombat()
  elseif self:IsOpen() then self:StopToolbarDrag(true);self:StopHubDrag(true);fit(self.panelRoot,1120,760);self:PlaceHub();self:PlaceToolbar();self:RefreshGrid();self:RefreshBoxes() end
 end)
 f:SetScript("OnHide",function() self:StopToolbarDrag(true);self:StopHubDrag(true);M.state.edit=false;M.state.forceEvaluate=true end)
 f:Hide()
end
function E:Open(query)
 if S:InCombat() then M:Print("Customization pauses during combat. Your draft is retained.");return false end
 local allowed,message=M.Elements:EditingAllowed();if not allowed then A:PauseForNativeEditor(message);M:Print(message);return false end
 if W.draft and not A:FlushInputs() then return false end
 local ok,why=W:Begin();if not ok then M:Print(why);return false end
 self:Create();A:HidePreserve();fit(self.panelRoot,1120,760);self:PlaceHub();self:PlaceToolbar()
 self.query=query or self.query;self.search:SetText(self.query or "")
 self.nativePaused=nil;A.nativePaused=nil
 self.frame:Show();M.state.edit=true;M.state.forceEvaluate=true;self:Render()
 M.Signals:Observe();return true
end
function E:HidePreserve()
 if self.toolbarDrag then self:StopToolbarDrag(true) end
 if self.hubDrag then self:StopHubDrag(true) end
 if self.drag then self:StopDrag() end
 A:CloseTransient();if self.frame then self.frame:Hide() end
 M.state.edit=false;M.state.forceEvaluate=true
end
function E:PauseForCombat()
 if not self:IsOpen() then return end
 if self.drag then
  local d=self.drag;self.drag=nil
  -- Only an unfinished gesture is cancelled. Prior edits remain in the draft.
  if d.before and W.draft==d.draft then W.draft=d.before;W:Changed() end
 end
 self:HidePreserve();A:HidePreserve();M:Print("Customization paused for combat. Your draft is retained; open /mirage afterward.")
end
function E:SetContext(context)
 if not A:FlushInputs() then return end
 if not W:SetContext(context) then return end
 self:Render();self:Notice("Preview: "..context..". Shared positions stay unchanged; only visibility is contextual.")
end
function E:ToggleFilter(key)
 if key~="unavailable" and key~="references" then return false end
 if not A:FlushInputs() then return false end
 self.filters[key]=not self.filters[key]
 self.searchScroll:SetVerticalScroll(0);self:RefreshBoxes();self:RenderSearch()
 self:Notice("Catalogue filter changed. Saved module choices, context visibility and layouts are unchanged.")
 return true
end
function E:Select(id)
 if not A:FlushInputs() then return false end
 local row=M.Elements:Get(id,W.draft);if not row then return end
 W.selected=id;self.selectedLabel:SetText(row.name.."\n"..row.module)
 self:RefreshBoxes();self:RenderSearch();self:RenderInspector();self.inspectorScroll:SetVerticalScroll(0)
 return true
end
function E:Box(row)
 local box=self.boxes[row.id];if box then return box end
 box=CreateFrame("Frame",nil,self.frame,"BackdropTemplate");self.boxes[row.id]=box;box:SetFrameLevel(24);U:Backdrop(box);box:EnableMouse(true)
 box.title=U:Text(box,row.name,6,-5,11,160);box.title:SetHeight(30)
 box.kind=U:Text(box,"",6,-31,10,160);box.kind:SetHeight(26)
 -- Controls sit outside the measured rectangle, so their affordances cannot
 -- be mistaken for part of the runtime display's geometry.
 box.handle=U:Button(box,"Size",0,0,48,function() end);box.handle:ClearAllPoints();box.handle:SetPoint("TOPRIGHT",box,"BOTTOMRIGHT",0,0);box.handle:SetSize(48,22)
 box.move=U:Button(box,"Move",0,0,54,function() end);box.move:ClearAllPoints();box.move:SetPoint("BOTTOMLEFT",box,"TOPLEFT",0,0);box.move:SetSize(54,22)
 box.nativeEdit=U:Button(box,"Position and size in Blizzard Edit HUD",0,0,286,function() A:RequestNativeEditor(row.id) end)
 box.nativeEdit:ClearAllPoints();box.nativeEdit:SetPoint("BOTTOMRIGHT",box,"TOPRIGHT",0,0);box.nativeEdit:SetSize(286,26)
 box:SetScript("OnMouseDown",function(_,button) if button=="LeftButton" then self:Select(row.id) end end)
 box:SetScript("OnMouseUp",function() self:StopDrag() end)
 box.handle:SetScript("OnMouseDown",function(_,button) if button=="LeftButton" and self:Select(row.id)~=false then self:StartDrag(row.id,true) end end)
 box.handle:SetScript("OnMouseUp",function() self:StopDrag() end)
 box.move:SetScript("OnMouseDown",function(_,button) if button=="LeftButton" and self:Select(row.id)~=false then self:StartDrag(row.id,false) end end)
 box.move:SetScript("OnMouseUp",function() self:StopDrag() end)
 return box
end
function E:EditLayout(row,profile)
 if W.GroupBounds then
  local bounds=W:GroupBounds(row,profile)
  if bounds then return bounds end
 end
 return (M.Elements.EditLayout or M.Elements.Layout)(M.Elements,row,profile)
end
function E:BoxLayout(row,profile)
 local owner=M.Rework and M.Rework:ProviderForLayout(row.id,profile)
 if row.kind=="group" and owner and owner.id=="groups" and M.Elements.BoxLayout then
  return M.Elements:BoxLayout(row,profile)
 end
 if W.GroupBounds then
  local bounds=W:GroupBounds(row,profile)
  if bounds then
   return bounds,"Fixed roster slots "..((tonumber(row.id:match("(%d+)$"))-1)*5+1).."–"..(tonumber(row.id:match("(%d+)$"))*5).."; subgroup sorting is off."
  end
 end
 if M.Elements.BoxLayout then return M.Elements:BoxLayout(row,profile) end
 return M.Elements:Layout(row,profile)
end
function E:RefreshBoxes()
 if not W.draft or not self.frame then return end
 local c=color();local seen={};local count=0
 self.optionalBoxes=self.optionalBoxes or {}
 for _,box in ipairs(self.optionalBoxes) do box:Hide() end
 for _,row in ipairs(M.Elements:List(nil,W.draft)) do
  local selected=W.selected==row.id;local included,state=M.Elements:OnCanvas(row,W.context,W.draft,self.filters,selected)
  local visible=M.Elements:Visible(row,W.context,W.draft)
  -- The forty member entries remain in Search and Display settings. Whole
  -- party/raid controls and observed subgroup references occupy the map.
  if included then
   local box=self:Box(row);local l,note
   l,note=self:BoxLayout(row,W.draft)
   local enabled=not state or state.enabled~=false
   box:ClearAllPoints();box:SetPoint("CENTER",UIParent,"CENTER",l.x*UIParent:GetWidth(),l.y*UIParent:GetHeight())
   box:SetSize(l.width*l.scale,l.height*l.scale);box:SetAlpha(visible and enabled and (selected and .95 or .85) or .25)
   box:SetBackdropColor(.02,.025,.035,selected and .72 or .16);box:SetBackdropBorderColor(c[1],c[2],c[3],selected and 1 or .38)
   local glyph=M.Icons and M.Icons:ForElement(row)
   local title=glyph and l.width*l.scale>=100 and l.height*l.scale>=30 and M.Icons:Label(glyph,row.name,16) or row.name
   box.title:SetText(title..(l.height*l.scale>=30 and ("\n"..state.label) or ""));box.title:SetWidth(math.max(24,l.width*l.scale-12));textColor(box.title,selected and c or {.85,.84,.80})
   box.kind:SetWidth(math.max(24,l.width*l.scale-12));box.kind:SetShown(selected and l.height*l.scale>74)
   box.kind:SetText(not visible and "Hidden in this preview" or note or "Shared draft geometry")
   box.handle:SetShown(selected and row.editable and row.resizable~=false and row.id~="Tooltips.anchor");box.move:SetShown(selected and row.editable and row.movable~=false)
   box.nativeEdit:SetShown(selected and state.provider.nativeEdit==true)
   box.title:ClearAllPoints();box.title:SetPoint("TOPLEFT",6,-5)
   box.title:SetHeight(math.max(10,math.min(34,l.height*l.scale-8)))
   box:Show();seen[row.id]=true;count=count+1
   if selected and M.Elements.OptionalBounds then
    for i,part in ipairs(M.Elements:OptionalBounds(row,W.draft)) do
     local footprint=self.optionalBoxes[i]
     if not footprint then
      footprint=CreateFrame("Frame",nil,self.frame,"BackdropTemplate");U:Backdrop(footprint)
      footprint:SetFrameLevel(23);footprint:EnableMouse(false)
      footprint.label=U:Text(footprint,"",3,0,9,180)
      footprint.label:ClearAllPoints();footprint.label:SetPoint("BOTTOMLEFT",footprint,"TOPLEFT",3,1)
      self.optionalBoxes[i]=footprint
     end
     footprint:ClearAllPoints();footprint:SetPoint("CENTER",UIParent,"CENTER",part.x*UIParent:GetWidth(),part.y*UIParent:GetHeight())
     footprint:SetSize(part.width*part.scale,part.height*part.scale)
     footprint:SetBackdropColor(.02,.025,.035,.06);footprint:SetBackdropBorderColor(c[1],c[2],c[3],.42)
     footprint.label:SetText(part.label.." · optional footprint");footprint.label:SetWidth(math.max(80,part.width*part.scale))
     footprint:Show()
    end
   end
  end
 end
 for id,box in pairs(self.boxes) do if not seen[id] then box:Hide() end end
 self.visibleCount=count
end
function E:RenderSearch()
 if not W.draft or not self.searchBody then return end
 local rows={};local catalogue=M.Elements:List(self.query or "",W.draft)
 for _,row in ipairs(catalogue) do if M.Elements:InCatalogue(row,W.draft,self.filters,W.selected==row.id) then rows[#rows+1]=row end end
 self.results=rows
 for _,b in ipairs(self.searchRows) do b:Hide() end
 for i,row in ipairs(rows) do
  local button=self.searchRows[i]
  if not button then button=U:Button(self.searchBody,"",0,-(i-1)*42,282,nil);button:SetHeight(38);self.searchRows[i]=button end
  button:ClearAllPoints();button:SetPoint("TOPLEFT",0,-(i-1)*42)
  local visible=M.Elements:Visible(row,W.context,W.draft);local cfg=W.draft.modules[row.module]
  local state=M.Elements.State and M.Elements:State(row,W.draft)
  local status=state and state.label
  if status and not visible then status=status.."; hidden in "..W.context.." preview" end
  local member=row.id:match("^PartyRaid%.raid%d+$") and "  [member settings]" or ""
  local title=M.Icons and M.Icons:Label(M.Icons:ForElement(row),row.name,16) or row.name
  button:SetText(title..member..(status and "  ["..status.."]" or (not cfg or not cfg.enabled) and "  [module off]" or not visible and "  [hidden]" or ""))
  button.selected=row.id==W.selected;U:PaintButton(button)
  button:SetScript("OnClick",function() self:Select(row.id) end);button:Show()
 end
 self.filterForm:Begin()
 self.filterUnavailable=self.filterForm:Toggle("unavailable","Include unavailable displays",self.filters.unavailable,function() self:ToggleFilter("unavailable") end)
 self.filterReferences=self.filterForm:Toggle("references","Include other features",self.filters.references,function() self:ToggleFilter("references") end)
 self.filterForm:Finish()
 local searchTop=88+self.filterForm.y+42
 self.searchHelp:ClearAllPoints();self.searchHelp:SetPoint("TOPLEFT",self.searchPanel,"TOPLEFT",16,-(searchTop-38))
 self.searchScroll:ClearAllPoints();self.searchScroll:SetPoint("TOPLEFT",self.searchPanel,"TOPLEFT",16,-searchTop);self.searchScroll:SetHeight(math.max(150,546-searchTop))
 self.searchBody:SetHeight(math.max(40,#rows*42));self.searchHelp:SetText(#rows.." of "..#catalogue.." results · editor filters only")
end
local fitMessages={
 COMBAT_LOCKDOWN="Fit controls resume after combat. Your draft is retained.",
 FIT_DISABLED="This frame is disabled. Its existing layout is retained.",
 FIT_DRAFT_CHANGED="Text options or width changed since the last measurement. Apply those changes before requesting a measured height.",
 FIT_STALE="The frame or its measurement changed. Apply or reopen settings to obtain a current height proposal.",
 WIDTH_UNFIT="Extra height cannot repair this width refusal. Adjust the width or visible text, then Apply to recheck the frame.",
 HEIGHT_ALREADY_SUFFICIENT="The draft already has enough height for this measured text layout.",
 HEIGHT_LIMIT="The measured height exceeds the supported layout range. Adjust the width or visible text before trying again.",
}
function E:FitRequiredHeight(id)
 if S:InCombat() then A:Notice(fitMessages.COMBAT_LOCKDOWN);return false,"COMBAT_LOCKDOWN" end
 local current,why=W:Current();if not current then A:Notice(why);return false,why end
 if W.selected~=id then A:Notice("The selected frame changed. Select it again before fitting its height.");return false,"SELECTION_CHANGED" end
 if not A:FlushInputs() then return false,"PENDING_INPUT" end
 local row=M.Elements:Get(id,W.draft);local typography=M.UnitTypography
 if not row or row.module~="UnitFrames" or not row.editable or not typography or type(typography.FitProposal)~="function" then return false,"FIT_UNAVAILABLE" end
 -- A rendered suggestion is never an authorization token. Resolve a fresh
 -- proposal after pending input and profile/selection checks at click time.
 local proposal,reason=typography:FitProposal(id,W.draft,self:EditLayout(row,W.draft))
 if not proposal or proposal.reason~="HEIGHT_UNFIT" or type(proposal.layout)~="table" or not S:Number(proposal.requiredHeight) then
  A:Notice(fitMessages[reason] or "A current measured height proposal is unavailable. Your draft is retained.");return false,reason or "FIT_UNAVAILABLE"
 end
 local ok,message=W:SetLayout(id,proposal.layout)
 if not ok then A:Notice(message);return false,message end
 self:Render();A:Changed("Required height staged. Undo can restore it; Apply rechecks the frame before native replacement.")
 return true
end
function E:RenderInspector()
 if not W.draft or not self.inspectorForm then return end
 local f=self.inspectorForm;f:Begin();local row=W.selected and M.Elements:Get(W.selected,W.draft)
 if not row then
  f:Text("intro","Select any box or search result.",32,true)
  f:Text("help","Use Search to include unavailable displays or other features. The preview changes visibility only.",56)
  f:Text("help2","Select a display. Drag Move or Size to arrange it. Ctrl + left-drag moves the MirageUI hub. Apply saves; Cancel keeps your current layout.",72)
 else
  f:Text("selected",row.name,30,true,M.Icons and M.Icons:ForElement(row))
  local state=M.Elements.State and M.Elements:State(row,W.draft)
  f:Text("identity",state.label,28)
  local technical=A:Disclosure(f,"element.technical."..row.id,"Technical details")
  if technical then
   f:Text("provider",row.module.." · "..state.provider.name.." · "..state.visibility:lower(),42)
   if state.note then f:Text("availability",state.note,52) end
   if state.provider.capabilityNote and state.provider.capabilityNote~=state.note then f:Text("capabilities",state.provider.capabilityNote,52) end
  end
  if state.provider.nativeEdit then
   f:Button("nativeEditHUD","Position and size in Blizzard Edit HUD",function() A:RequestNativeEditor(row.id) end)
  end
  if state.provider.customizeTarget and state.provider.customizeTarget~=row.id then
   local target=state.provider.customizeTarget
   f:Button("wholeGroupLayout",target=="PartyRaid.raidFrame" and "Move or resize Raid frames" or "Move or resize the Party frame",function() self:Select(target) end)
  end
  if row.id:match("^PartyRaid%.raid%d+$") then
   local rework=M.Rework and M.Rework:ProviderForLayout(row.id,W.draft)
   f:Text("memberSettings",rework and rework.object.nativeBacked and "Individual member settings remain available here. Select Raid frames to move or uniformly resize the whole native raid control. The game retains subgroup arrangement."
    or "Individual member settings remain available here. Move and resize the raid subgroup boxes on the map.",86)
  end
  local geometryNote
  local unused;if not state.reference then unused,geometryNote=self:BoxLayout(row,W.draft) end
  if technical and geometryNote then f:Text("geometryNote",geometryNote,52) end
  if row.module=="UnitFrames" and row.editable and M.UnitTypography and type(M.UnitTypography.FitProposal)=="function" then
   local proposal,reason=M.UnitTypography:FitProposal(row.id,W.draft,self:EditLayout(row,W.draft))
   if proposal and proposal.reason=="HEIGHT_UNFIT" and S:Number(proposal.requiredHeight) then
    f:Text("fitHeightDetail",string.format("Measured minimum: %.1f layout units at this width and text size. Fit changes the draft only; Apply rechecks native admission.",proposal.requiredHeight),82)
    f:Button("fitHeight","Fit required height",function() self:FitRequiredHeight(row.id) end)
   elseif reason=="WIDTH_UNFIT" then f:Text("fitWidthDetail",fitMessages.WIDTH_UNFIT,82) end
  end
  if row.contextSupported==false then f:Text("contextLimited","Visibility follows the game for this display.",36)
  elseif W.context~="All" then
   local v=M.ElementRules:Preference(row.id,W.context,W.draft) or "AUTO"
   f:Text("context","For "..W.context..": "..(v=="AUTO" and "Follow MirageUI rules" or v=="SHOW" and "Show when available" or "Hide unless access takes priority"),46)
   f:Button("hide","Hide for chosen context",function() local ok,why=W:SetVisibility(row.id,"HIDE");self:Render();A:Changed(ok and "Hide preference staged. Search can recover this element." or why) end)
   f:Button("show","Show for chosen context",function() local ok,why=W:SetVisibility(row.id,"SHOW");self:Render();A:Changed(ok and "Show preference staged. A disabled module stays disabled." or why) end)
   f:Button("auto","Follow MirageUI rules",function() W:SetVisibility(row.id,"AUTO");self:Render();A:Changed() end)
  else f:Text("choose","Choose Idle, Moving or Combat above to edit visibility.",42) end
  if row.editable then
   local l=self:EditLayout(row,W.draft)
   local function change(key,value)
    local nextLayout=self:EditLayout(row,W.draft)
    -- A position control becomes a screen anchor. Retain the current absolute
    -- center for its other axis before discarding a relative anchor.
    if nextLayout.anchorTo and (key=="x" or key=="y") then
     local shown=self:BoxLayout(row,W.draft);nextLayout.x,nextLayout.y=shown.x,shown.y;nextLayout.anchorTo=nil
    end
    nextLayout[key]=value
    if row.sidebar=="MAP" and key=="width" then nextLayout.height=value end
    local ok,why=W:SetLayout(row.id,nextLayout);self:RefreshBoxes();A:Changed(not ok and why or nil)
   end
   if row.movable~=false then
    f:Slider("x","Position X (% of screen)",l.x*100,-48,48,.1,function(v) change("x",v/100) end)
    f:Slider("y","Position Y (% of screen)",l.y*100,-48,48,.1,function(v) change("y",v/100) end)
   end
   if row.resizable~=false and row.id~="Tooltips.anchor" then
    if row.resizeWidth~=false then f:Slider("width",row.sidebar=="MAP" and "Sidebar width (pixels)" or row.kind=="hud" and "Bar width (pixels)" or "Width (pixels)",l.width,row.minWidth or row.surface and row.surface.minWidth or 24,row.maxWidth or 1200,1,function(v) change("width",v) end) end
    if row.kind~="hud" and row.resizeHeight~=false then
     local authored=W.draft.layouts[row.id]
     local height=row.sidebar=="OBJECTIVES" and authored and authored.height or l.height
     f:Slider("height",row.sidebar=="OBJECTIVES" and "Objective height (pixels)" or "Height (pixels)",height,row.minHeight or row.surface and row.surface.minHeight or 16,800,1,function(v) change("height",v) end)
    end
   end
   if row.scalable~=false then
    local authored=W.draft.layouts[row.id]
    local scale=row.sidebar=="MAP" and ((authored and authored.scale) or (row.layout and row.layout.scale) or 1) or l.scale
    f:Slider("scale","Scale",scale,row.minScale or .6,M.LayoutScaleMaximum and M:LayoutScaleMaximum(row.id) or 1.6,.05,function(v) change("scale",v) end)
   end
   if row.resizable==false or row.id=="Tooltips.anchor" then f:Text("dynamicSize","Content determines this display’s width and height.",36) end
   if row.kind=="hud" then f:Text("computedSize","Height follows the enabled character bars.",32) end
   if technical then f:Text("geography",row.sidebar and state.provider.capabilityNote or "Position and size are shared across contexts.",48) end
  else
   f:Text("representative",state.reference and "Use this feature’s settings below." or state.provider.nativeEdit and "Position and size are managed in Blizzard Edit HUD." or "Position and size are unavailable for this display.",42)
  end
  if technical and (row.surface and row.surface.floor or row.kind=="native" or row.kind=="world") then
   f:Text("nativefloor","Context choices are preferences. Essential combat access and game-managed visibility take priority. A sample box does not certify a native replacement.",80)
  end
  A:ModuleControls(f,row.module)
 end
 f:Finish()
 local route=tostring(W.selected or "")
 if self.inspectorRoute~=route then self.inspectorScroll:SetVerticalScroll(0);self.inspectorRoute=route
 else
  local maximum=math.max(0,self.inspectorBody:GetHeight()-self.inspectorScroll:GetHeight())
  if self.inspectorScroll:GetVerticalScroll()>maximum then self.inspectorScroll:SetVerticalScroll(maximum) end
 end
end
function E:StartDrag(id,resize)
 local row=M.Elements:Get(id,W.draft)
 if not row or not row.editable or not resize and row.movable==false or (resize and (row.resizable==false or row.id=="Tooltips.anchor")) or S:InCombat() or not M.Elements:EditingAllowed() or not W:Current() then return false end
 if not A:FlushInputs() then return false end
 if self.drag then self:StopDrag() end
 local x,y=GetCursorPosition();local scale=UIParent:GetEffectiveScale()
 local width,height=UIParent:GetWidth(),UIParent:GetHeight()
 if not S:Number(x) or not S:Number(y) or not S:Number(scale) or scale<=0 or not S:Number(width) or width<=0 or not S:Number(height) or height<=0 then return false end
 local layout=self:EditLayout(row,W.draft)
 local resizeScale,resizeHeightScale
 if row.provider and row.provider.geometry=="actionInterface" then
  local shown=self:BoxLayout(row,W.draft)
  resizeScale=shown.width*shown.scale/layout.width
  -- The compact action footprint can be shorter than its canonical authored
  -- canvas. Each handle axis converts through its displayed dimension before
  -- the single proportional factor is chosen below.
  resizeHeightScale=shown.height*shown.scale/layout.height
 end
 if not resize and layout.anchorTo then
  local shown=self:BoxLayout(row,W.draft);layout.x,layout.y=shown.x,shown.y
 end
 self.drag={id=id,resize=resize,x=x/scale,y=y/scale,scale=scale,width=width,height=height,
  layout=layout,resizeScale=resizeScale,resizeHeightScale=resizeHeightScale,before=M:Copy(W.draft),draft=W.draft,moved=false}
 return true
end
function E:CancelDrag()
 local d=self.drag;self.drag=nil
 if d and W.draft==d.draft then W.draft=d.before;W:Changed() end
end
function E:UpdateDrag()
 local d=self.drag;if not d then return end
 if S:InCombat() then self:PauseForCombat();return end
 local allowed,message=M.Elements:EditingAllowed();if not allowed then A:PauseForNativeEditor(message);return end
 if W.draft~=d.draft or not W:Current() then self:CancelDrag();return end
 local x,y=GetCursorPosition();local scale=UIParent:GetEffectiveScale()
 if not S:Number(x) or not S:Number(y) or not S:Number(scale) or scale<=0 then return end
 if scale~=d.scale or UIParent:GetWidth()~=d.width or UIParent:GetHeight()~=d.height then
  self:CancelDrag();self:Notice("Screen size changed; the unfinished drag was cancelled.");return
 end
 local dx,dy=x/scale-d.x,y/scale-d.y
 -- A selection click is not a layout edit and must not disable auto-layout.
 if dx==0 and dy==0 and not d.moved then return end
 if dx==0 and dy==0 then
  W.draft=M:Copy(d.before);d.draft=W.draft;d.moved=false;W:Changed();self:RefreshBoxes();return
 end
 local l=M:Copy(d.layout);local row=M.Elements:Get(d.id,W.draft)
 if d.resize and ((row.sidebar=="MAP" and dx==0) or (row.sidebar=="OBJECTIVES" and dy==0)) then
  if d.moved then W.draft=M:Copy(d.before);d.draft=W.draft;d.moved=false;W:Changed();self:RefreshBoxes() end
  return
 end
 if not d.resize then l.anchorTo=nil end
 if d.resize then
  local minW=row.minWidth or row.surface and row.surface.minWidth or 24;local maxW=row.maxWidth or 1200;local minH=row.minHeight or row.surface and row.surface.minHeight or 16
  local pixelsPerUnit=d.resizeScale or l.scale
  if row.resizeWidth~=false then l.width=math.max(minW,math.min(maxW,d.layout.width+dx/pixelsPerUnit)) end
  if row.kind~="hud" and row.resizeHeight~=false then l.height=math.max(minH,math.min(800,d.layout.height-dy/(d.resizeHeightScale or pixelsPerUnit))) end
  if self.snap and (row.kind~="hud" or dx~=0) then
   local g=W.draft.grid
   if row.resizeWidth~=false then l.width=math.max(minW,math.min(maxW,math.floor(l.width/g+.5)*g)) end
   if row.kind~="hud" and row.resizeHeight~=false then l.height=math.max(minH,math.floor(l.height/g+.5)*g) end
  end
  if row.sidebar=="MAP" then l.height=l.width end
  if row.id=="ActionBars.interface" then
   local dw,dh=math.abs(l.width/d.layout.width-1),math.abs(l.height/d.layout.height-1)
   local factor=dw>=dh and l.width/d.layout.width or l.height/d.layout.height
   l.width=math.max(minW,math.min(maxW,d.layout.width*factor));l.height=l.width*d.layout.height/d.layout.width
  end
 else
  l.x=l.x+dx/d.width;l.y=l.y+dy/d.height
  if self.snap then l.x,l.y=M.Layout:Snap(d.id,l.x,l.y,l.width,l.height,W.draft,d.resizeScale or l.scale) end
 end
 -- Snapping back to the starting geometry is also a no-op.
 if l.x==d.layout.x and l.y==d.layout.y and l.width==d.layout.width and l.height==d.layout.height and l.scale==d.layout.scale then
  W.draft=M:Copy(d.before);d.draft=W.draft;d.moved=false;W:Changed();self:RefreshBoxes();return
 end
 local ok=W:SetLayout(d.id,l,false,d.before)
 if not ok then self:CancelDrag();return end
 d.moved=true;self:RefreshBoxes()
end
function E:StopDrag()
 local d=self.drag;if not d then return end
 self:UpdateDrag()
 if self.drag~=d then return end
 self.drag=nil
 if W.draft==d.draft and W:Current() then W:Remember(d.before) end
 self:RenderInspector();A:Changed()
end
function E:RefreshGrid()
 if not self.gridFrame then return end
 self.gridToggle:SetText(self.showGrid and "Grid: On" or "Grid: Off")
 for _,line in ipairs(self.gridLines) do line:Hide() end
 for _,axis in pairs(self.gridAxes or {}) do axis:Hide() end
 if not self.showGrid or not W.draft then return end
 local width,height=UIParent:GetWidth(),UIParent:GetHeight();local step=W.draft.grid or 8
 -- Keep the visual grid bounded on very large displays, preserving snap units.
 local spacing=step*math.max(1,math.ceil((width+height)/step/384));local n=0
 local function line(x,y,w,h)
  n=n+1;local texture=E.gridLines[n];if not texture then texture=E.gridFrame:CreateTexture(nil,"BACKGROUND");E.gridLines[n]=texture end
  texture:ClearAllPoints();texture:SetPoint("TOPLEFT",x,y);texture:SetSize(w,h);texture:SetColorTexture(.9,.7,.35,.12);texture:Show()
 end
 for x=0,width,spacing do line(x,0,1,height) end
 for y=0,height,spacing do line(0,-y,width,1) end
 self.gridAxes=self.gridAxes or {}
 for _,axis in ipairs({"x","y"}) do
  local texture=self.gridAxes[axis]
  if not texture then texture=self.gridFrame:CreateTexture(nil,"ARTWORK");self.gridAxes[axis]=texture end
  texture:ClearAllPoints();texture:SetPoint("CENTER",self.gridFrame,"CENTER",0,0)
  texture:SetSize(axis=="x" and width or 3,axis=="x" and 3 or height)
  texture:SetColorTexture(.96,.73,.32,.72);texture:Show()
 end
end
function E:Render()
 if not W.draft or not self.frame then return end
 self:RefreshBoxes();self:RenderSearch();self:RenderInspector();self:RefreshGrid()
 local c=color();self.hub:SetBackdropBorderColor(c[1],c[2],c[3],1)
 for id,button in pairs(self.contextButtons) do button.selected=id==W.context;U:PaintButton(button) end
 self:SetPanel(self.inspector,self.advanced,true);self:SetPanel(self.searchPanel,self.searchShown,true)
 self:Notice(W.dirty and "Unapplied changes · Apply saves; Cancel keeps your current layout." or "Select a display to edit its position, size or visibility.")
end
-- Existing commands now use the unified element map, not a second editor.
if M.Editor then
 function M.Editor:Open() return E:Open() end
 function M.Editor:Close() if E:IsOpen() then if S:InCombat() then E:PauseForCombat() else E:HidePreserve() end end;M.state.edit=false end
end
if M.LayoutPreview then function M.LayoutPreview:Open() W:SetContext("All");return E:Open() end end

-- Historical command names are compatibility aliases, not alternate settings UIs.
if M.PlayerSettings then
 function M.PlayerSettings:PreviewFrames() return E:Open("UnitFrames") end
end
if M.Options then
 function M.Options:ShellOpenPage(page)
  if page=="Profiles" then return A:Open("Profiles") end
  if page=="Integration" then
   A.disclosures=A.disclosures or {};A.disclosures["hud.advanced"]=true;A.disclosures["hud.sources"]=true
   return A:Open("Modules","UnderCharacterHUD")
  end
  if page=="Recovery" or page=="Validation" then return A:Open("Help") end
  if M.modules[page] then return A:Open("Modules",page) end
  return A:Open("Customize")
 end
end
