local M=MirageUI
if not M or not M.Options then return end
local O=M.Options
-- The common picker feeds exact spell IDs to both cooldown and cursor drafts.
-- It never edits saved profiles or auto-selects another learned rank.
function O:PickLearnedSpell(button,query,callback)
 local request={};self.spellPickerRequest=request
 local ownerDraft,profile,frame,ownerPage=self.draft,M.profile,self.frame,self.page
 local setup,advanced,step,renderToken=self.setup,self.advanced,self.step,self.shellRenderToken
 local provider,safety,shell=M.SpellBook,M.Safety,M.OptionsShell
 local function current(afterRender)
  if self.draft~=ownerDraft or self.page~=ownerPage then return false end
  return M.Options==self and self.spellPickerRequest==request and ownerDraft~=nil
   and M.profile==profile and self.frame==frame and frame~=nil
   and self.setup==setup and self.advanced==advanced and self.step==step
   and (afterRender or self.shellRenderToken==renderToken) and M.SpellBook==provider and M.Safety==safety and M.OptionsShell==shell
 end
 local function active(afterRender)
  if not current(afterRender) or safety:InCombat() or not current(afterRender) then return false end
  local shown,state=safety:Public(frame.IsShown,"boolean",frame)
  return state=="KNOWN" and shown==true and current(afterRender)
 end
 if not shell or type(shell.Capture)~="function" or type(shell.Pure)~="function" or not active() then return end
 local snapshot=provider:Read(query or "")
 -- Native observations may dismiss this dialog or install a successor draft.
 -- The old request must not open choices, select an ID, or narrate that successor.
 if not active() then return end
 if #snapshot.rows==0 then
  self:Notice(snapshot.state=="PUBLIC_SPELLBOOK" and "No learned active spells match. Try another name or enter an exact spell ID." or "The spellbook list is unavailable. Enter an exact learned spell ID instead.")
  return
 end
 local choices,byID={},{}
 for _,row in ipairs(snapshot.rows) do choices[#choices+1]={value=row.id,label=row.label};byID[row.id]=row end
 local selected=false
 M.UI:Choose(button,choices,nil,function(id)
  if selected then return end
  -- Consume before any callback-capable validation, including visibility probes.
  selected=true
  if not active() then return end
  local row=byID[id]
  local same=row and M.SpellBook:StillSame(row)
  if not active() then return end
  if not same then self:Notice("The spellbook changed. Open the list again.");return end
  local message=callback(id,row)
  if not active() then return end
  local receipt=shell:Capture()
  if not active() or not shell:Pure(receipt) or not current() then return end
  local rendered=self:Render(receipt)
  -- Our ordinary render renews its render token. Keep the other captured
  -- identities for feedback; do not adopt a newer picker or another dialog.
  if rendered~=false and type(message)=="string" and active(true) and shell:Pure(receipt) and current(true) then self:Notice(message) end
 end)
 if not active() then return end
 self:Notice(snapshot.state=="REFINE_SEARCH" and "Showing the first 48 matches. Type a more specific name to narrow the list."
  or snapshot.state=="PARTIAL_UNAVAILABLE" and "Some spellbook entries are unavailable. Only entries reported as learned are listed."
  or "Choose the exact ability or rank. Existing selections are never upgraded automatically.")
end
