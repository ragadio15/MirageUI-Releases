local M=MirageUI
if not M or not M.Options then return end
local O,U,S,D=M.Options,M.UI,M.Safety,M.DialogNavigation
local E={};M.ReferenceEditor=E
local function focus()
 if type(GetCurrentKeyBoardFocus)~="function" then return false end
 local ok,value=pcall(GetCurrentKeyBoardFocus)
 if not ok or not S:Readable(value) then return false end
 return true,value
end
local titles={builds="Build references",strategies="Manual strategies"}
local function same(a,b)
 if type(a)~=type(b) then return false end
 if type(a)~="table" then return a==b end
 if getmetatable(a) or getmetatable(b) then return false end
 for k,v in next,a do if not same(v,rawget(b,k)) then return false end end
 for k in next,b do if rawget(a,k)==nil then return false end end
 return true
end
function E:Pure(a)
 local ok,value=pcall(function() return a and not a.invalidated and self.session==a and M.Options==O and O.draft==a.draft and O.frame==a.parent and O.page=="Preparations" and not O.setup and a.draft.preparationReferences==a.subtree and same(a.subtree,a.original) and (not a.subtree or a.subtree[a.kind]==a.collection) and (not a.selected or a.subtree[a.kind][a.index]==a.selected) and M.profile==a.profile and M.Client==a.client and M.Client.key==a.key and M.Client.family==a.family and M.Client.build==a.build and M.Client.interface==a.interface and M.Client.patch==a.patch and M.Client.sourceMatched==a.sourceMatched and M.Client.experimental==a.experimental and M.adapter==a.adapter and M.adapter.sourceCommit==a.source and M.adapter.family==a.adapterFamily and M.adapter.patch==a.adapterPatch and M.adapter.build==a.adapterBuild and M.adapter.interface==a.adapterInterface and M.Policy.contextEpoch==a.context and M.Policy.capabilityEpoch==a.capability and M.Policy.scopeEpoch==a.scope and not M.Profiles.readOnly and not M.state.safe and not M.state.cinematic and M.state.world and M.profile.textScale==a.scale end)
 return ok and value==true
end
function E:Current(a,foreground)
 if not self:Pure(a) then return false end
 if a.checking then a.invalidated=true;return false end
 a.checking=true
 local ok,result=pcall(function()
 local parentShown=a.parent:IsShown();local shown=self.frame:IsShown()
 if not self:Pure(a) or not parentShown or (foreground and (not shown or D.top~=self.frame)) then return false end
 local current=M.References:Validate(a.subtree)
 if not current or not self:Pure(a) or not same(current,a.baseline) then return false end
 -- Identity, not an ID recycled by delete/recreate, owns the selected record.
 if a.selected and (not a.subtree or a.subtree[a.kind][a.index]~=a.selected) then return false end
 local combat=S:InCombat()
 return not combat and self:Pure(a) and (not foreground or D.top==self.frame)
 end)
 a.checking=false
 return ok and result==true
end
function E:OwnInput(a)
 if not self:Current(a,true) then return false end
 local ok,focused=focus()
 if not ok or not self:Current(a,true) then return false end
 if not focused then return true end
 return focused==self.nameEdit or focused==self.bodyEdit or focused==self.sourceEdit
end
function E:Scrub(a)
 if not a then return end
 a.private=nil;a.record=nil;a.pages=nil;a.baseline=nil;a.original=nil
 a.selected=nil;a.collection=nil;a.subtree=nil;a.draft=nil;a.profile=nil
end
function E:Close(token)
 if token and self.session~=token then return false end
 local a=self.session;if not a then return false end
 self.session=nil
 -- Retired handler closures carry only an inert owner token, not a private history.
 self:Scrub(a)
 if self.frame then self.frame:Hide() end
 return true
end
function E:Dimensions()
 local w,ws=S:Public(UIParent.GetWidth,"number",UIParent);local h,hs=S:Public(UIParent.GetHeight,"number",UIParent)
 local scale=M.profile.textScale or 1;local row=math.ceil(28*scale);local label=math.ceil(18*scale)
 local height=150+8*row+6*label
 if ws~="KNOWN" or hs~="KNOWN" or w<360 or h<height+30 then return nil end
 return math.min(620,w-30),height,row,label
end
function E:Bind(a)
 local function action(button,fn) button:SetScript("OnClick",function() if self:Current(a,true) then fn(a) end end) end
 action(self.nav,function(token) if self:OwnInput(token) then
   for _,box in ipairs({self.nameEdit,self.sourceEdit,self.bodyEdit}) do box:ClearFocus();if not self:Current(token,true) then return end end
   D:Start(self.frame,true)
  end end)
 action(self.choose,function(token)
  if token.mode~="list" or not self:OwnInput(token) then return end
  local entries={};for i,row in ipairs(token.baseline[token.kind]) do entries[i]={value=i,label=row.name} end
  if #entries==0 then self.notice:SetText("No saved records in this settings draft.");return end
  U:Choose(self.choose,entries,token.index,function(index) if self:Current(token,true) then self:Select(token,index) end end)
 end)
 action(self.new,function(token) self:Edit(token,true) end)
 action(self.edit,function(token) self:Edit(token,false) end)
 action(self.delete,function(token) self:Delete(token,false) end)
 action(self.confirmDelete,function(token) self:Delete(token,true) end)
 action(self.save,function(token) self:Save(token) end)
 action(self.back,function(token) self:Reset(token) end)
 action(self.up,function(token) self:Scroll(token,-1) end)
 action(self.down,function(token) self:Scroll(token,1) end)
 self.cancel:SetScript("OnClick",function() self:Close(a) end)
 self.frame.closeButton:SetScript("OnClick",function() self:Close(a) end)
 for _,box in ipairs({self.nameEdit,self.bodyEdit,self.sourceEdit}) do
  box:SetScript("OnEscapePressed",function() self:Close(a) end)
 end
 self.nameEdit:SetScript("OnEnterPressed",function(box) if self:Current(a,true) and self:OwnInput(a) then box:ClearFocus() end end)
 self.sourceEdit:SetScript("OnEnterPressed",function(box) if self:Current(a,true) and self:OwnInput(a) then box:ClearFocus() end end)
 for _,pair in ipairs({{self.nameEdit,"name"},{self.sourceEdit,"source"},{self.bodyEdit,"body"}}) do
  local box,key=pair[1],pair[2]
  box:SetScript("OnTabPressed",function() if self:Current(a,true) and a.mode=="edit" then D:FieldTab(self.frame,box,key) end end)
 end
 self.bodyEdit:SetScript("OnEnterPressed",nil) -- native multiline insertion, never Save
end
function E:Transition(a,changes)
 if not self:Current(a,true) then return false end
 local nextToken={};for k,v in pairs(a) do nextToken[k]=v end
 for k,v in pairs(changes) do nextToken[k]=v end
 self.session=nextToken;self:Scrub(a)
 return self:Paint(nextToken)
end
function E:Reset(a)
 if not self:Current(a,true) or not self:OwnInput(a) then return false end
 return self:Transition(a,{mode="list",private=false})
end
function E:Select(a,index)
 if not self:Current(a,true) or a.mode~="list" then return false end
 local row=a.baseline[a.kind][index];local original=a.subtree and a.subtree[a.kind][index]
 if not row or not original then return false end
 return self:Transition(a,{index=index,selected=original,record=M:Copy(row),viewPage=1})
end
function E:Edit(a,isNew)
 if not self:Current(a,true) or not self:OwnInput(a) or a.mode~="list" then return false end
 local record
 if isNew then
  if #a.baseline[a.kind]>=8 then self.notice:SetText("At most eight records per kind.");return false end
  local origin,why=M.References:CreatedClient();if not origin or not self:Current(a,true) then return false end
  local used={};for _,r in ipairs(a.baseline[a.kind]) do used[r.id]=true end
  local id=1;while used[id] do id=id+1 end
  record={id=id,name="",text="",source="",createdClient=origin}
 else
  if not a.selected or not a.record then return false end;record=M:Copy(a.record)
 end
 local selected,index,shownRecord=false,false,false
 if not isNew then selected,index,shownRecord=a.selected,a.index,a.record end
 return self:Transition(a,{mode="edit",private=record,record=shownRecord,selected=selected,index=index})
end
function E:Delete(a,confirm)
 if not self:Current(a,true) or not self:OwnInput(a) or not a.selected then return false end
 if not confirm then if a.mode~="list" then return false end;return self:Transition(a,{mode="delete"}) end
 if a.mode~="delete" then return false end
 local candidate=M:Copy(a.baseline);table.remove(candidate[a.kind],a.index)
 return self:Stage(a,candidate)
end
function E:Stage(a,candidate)
 if not self:Current(a,true) then return false end
 local clean,why=M.References:Validate(candidate)
 if not self:Current(a,true) then return false end
 if not clean then self.notice:SetText(why or "Invalid reference data.");return false end
 local draftBefore=M:Copy(a.draft);local draft=M:Copy(draftBefore);draft.preparationReferences=clean
 local ok,reason=M.Profiles:CheckTransaction(draft)
 if not self:Current(a,true) or not self:OwnInput(a) or not self:Current(a,true) then return false end
 if not same(a.draft,draftBefore) then return false end
 if not ok then self.notice:SetText(reason or "Settings draft is invalid.");return false end
 -- One exact draft assignment; no profile commit or callback between final check/write.
 a.draft.preparationReferences=clean
 local ownerDraft,ownerProfile=a.draft,a.profile
 self:Close(a)
 if not self.session and O.draft==ownerDraft and M.profile==ownerProfile then O:Notice("References staged in settings. Apply saves; Cancel discards.") end
 return true
end
function E:Save(a)
 if not self:Current(a,true) or a.mode~="edit" or not self:OwnInput(a) then return false end
 local values={}
 for _,spec in ipairs({{"name",self.nameEdit},{"text",self.bodyEdit},{"source",self.sourceEdit}}) do
  local value,status=S:Public(spec[2].GetText,"string",spec[2]);if status~="KNOWN" or not self:Current(a,true) then return false end
  values[spec[1]]=value
 end
 if not self:Current(a,true) then return false end
 local record=M:Copy(a.private);record.name=values.name;record.text=values.text;record.source=values.source
 local candidate=M:Copy(a.baseline)
 if a.selected then candidate[a.kind][a.index]=record else candidate[a.kind][#candidate[a.kind]+1]=record end
 return self:Stage(a,candidate)
end
function E:Scroll(a,delta)
 if not self:Current(a,true) or not self:OwnInput(a) then return false end
 if a.mode~="edit" then
  a.viewPage=math.max(1,math.min(#a.pages,(a.viewPage or 1)+delta))
  self.viewer:SetText(a.pages[a.viewPage] or "")
  return self:Current(a,true)
 end
 local pos=S:Public(self.scroll.GetVerticalScroll,"number",self.scroll);local height=S:Public(self.scroll.GetHeight,"number",self.scroll);local childHeight=S:Public(self.bodyEdit.GetHeight,"number",self.bodyEdit)
 if not S:Number(pos) or not S:Number(height) or not S:Number(childHeight) or not self:Current(a,true) then return false end
 self.scroll:SetVerticalScroll(math.max(0,math.min(childHeight-height,pos+delta*math.max(24,height-24))))
 return self:Current(a,true)
end
function E:Create()
 if self.frame then return end
 local f=U:Panel("MirageReferenceEditor","Reference settings",620,600);self.frame=f
 self.nav=U:Button(f,"Controller / F6",18,-54,300,nil)
 self.choose=U:Button(f,"Select a record",18,-96,300,nil)
 self.new=U:Button(f,"New",18,-136,140,nil);self.edit=U:Button(f,"Edit",170,-136,140,nil);self.delete=U:Button(f,"Delete",322,-136,140,nil)
 self.nameLabel=U:Text(f,"Name",18,-180,11,300);self.nameEdit=U:Edit(f,18,-200,300,"")
 self.sourceLabel=U:Text(f,"Source (unverified)",18,-236,11,300);self.sourceEdit=U:Edit(f,18,-256,300,"")
 self.nameEdit.mirageManualFont=true;self.sourceEdit.mirageManualFont=true -- Paint owns these session fonts.
 self.bodyLabel=U:Text(f,"Full reference text",18,-292,11,300)
 self.viewer=U:Text(f,"",18,-180,12,300)
 self.scroll=M.UI:Scroll(f)
 self.bodyEdit=CreateFrame("EditBox",nil,self.scroll,"BackdropTemplate");U:Backdrop(self.bodyEdit,true);self.bodyEdit:SetMultiLine(true);self.bodyEdit:SetAutoFocus(false);self.bodyEdit:SetTextInsets(6,6,4,4);self.scroll:SetScrollChild(self.bodyEdit)
 self.nameEdit:SetMaxLetters(49);self.sourceEdit:SetMaxLetters(97);self.bodyEdit:SetMaxLetters(1025)
 self.up=U:Button(f,"Text up",18,-400,140,nil);self.down=U:Button(f,"Text down",170,-400,140,nil)
 self.notice=U:Text(f,"",18,-440,11,300)
 self.save=U:Button(f,"Save to draft",18,-480,300,nil)
 self.confirmDelete=U:Button(f,"Confirm delete",18,-480,300,nil)
 self.back=U:Button(f,"Discard",18,-520,140,nil);self.cancel=U:Button(f,"Close",170,-520,140,nil)
 f:SetScript("OnHide",function()
  local opening=self.opening;local retired=self.session;self.session=nil;self:Scrub(retired)
  for _,box in ipairs({self.nameEdit,self.sourceEdit,self.bodyEdit}) do
   if self.session or self.opening~=opening then break end
   -- Cleanup is best-effort per operation: a failed focus callback must not
   -- retain another field's private text or prevent dialog navigation cleanup.
   -- Recheck ownership even when a callback opens a successor and then throws.
   pcall(box.ClearFocus,box)
   if self.session or self.opening~=opening then break end
   pcall(box.SetText,box,"")
  end
 end)
 f:SetScript("OnUpdate",function() local a=self.session;if a and (not self:Current(a,true) or not self:Dimensions()) then self:Close(a) end end)
 D:Attach(f,{closeOnSuspend=true,hideCleanupAllowed=function() return self.session==nil end,allowed=function() return self:Current(self.session,true) end,onSuperseded=function() self:Close(self.session) end,close=function() self:Close(self.session) end,entries=function()
  local a=self.session;local rows={}
  for _,pair in ipairs({{self.nav,"navigation"},{self.choose,"select"},{self.new,"new"},{self.edit,"edit"},{self.delete,"delete"},{self.up,"textUp"},{self.down,"textDown"},{self.save,"save"},{self.confirmDelete,"confirmDelete"},{self.back,"back"},{self.cancel,"cancel"},{f.closeButton,"close"}}) do rows[#rows+1]={frame=pair[1],key=pair[2],kind="button",identity=a} end
  for _,pair in ipairs(a and a.mode=="edit" and {{self.nameEdit,"name"},{self.sourceEdit,"source"},{self.bodyEdit,"body"}} or {}) do rows[#rows+1]={frame=pair[1],key=pair[2],kind="edit",identity=a,commit=function() return self:Current(a,true) end} end
  return rows
 end})
end
function E:Paint(a)
 local stale={}
 local function call(object,method,...)
  if not self:Pure(a) then error(stale) end
  local result=object[method](object,...)
  if not self:Pure(a) then error(stale) end
  return result
 end
 local ok,result=pcall(function()
 if self.session~=a then return false end
 local w,h,row,label=self:Dimensions();if not self:Pure(a) then return false end;if not w then self:Close(a);return false end
 local editing=a.mode=="edit";local formStart=54+row+8
 call(self.frame,"SetSize",w,h);call(self.frame.heading,"SetText",titles[a.kind]);call(self.frame.heading,"SetWidth",w-80);call(self.frame.heading,"SetFont",STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",16*a.scale,"")
 local inner=w-36;local function place(widget,y,width,height,x) call(widget,"ClearAllPoints");call(widget,"SetPoint","TOPLEFT",x or 18,-y);call(widget,"SetSize",width or inner,height or row) end
 local y=54;place(self.nav,y);y=y+row+8;place(self.choose,y);y=y+row+8
 local third=math.floor((inner-16)/3);place(self.new,y,third,row);place(self.edit,y,third,row,26+third);place(self.delete,y,third,row,34+2*third);y=y+row+8
 if editing then y=formStart end
 local viewY=y
 place(self.nameLabel,y,inner,label);y=y+label;place(self.nameEdit,y);y=y+row+8
 place(self.sourceLabel,y,inner,label);y=y+label;place(self.sourceEdit,y);y=y+row+8
 place(self.bodyLabel,y,inner,label);y=y+label;place(self.scroll,y,inner-22,row*2);call(self.bodyEdit,"SetWidth",inner-24);call(self.bodyEdit,"SetHeight",1026*math.ceil(24*a.scale));y=y+row*2+8
 if not editing then y=viewY+3*label+4*row+24 end
 local half=math.floor((inner-8)/2);place(self.up,y,half);place(self.down,y,half,row,26+half);y=y+row+8
 place(self.notice,y,inner,label*3);y=y+label*3+8
 place(self.save,y);place(self.confirmDelete,y);y=y+row+8;place(self.back,y,half);place(self.cancel,y,half,row,26+half)
 -- Use full layout height, with viewport refusal rather than overlapping footer.
 if y+row+18>h then call(self.frame,"SetHeight",y+row+18);local viewport=S:Public(UIParent.GetHeight,"number",UIParent);if not viewport or y+row+48>viewport then self:Close(a);return false end end
 for _,widget in ipairs({self.nav,self.choose,self.new,self.edit,self.delete,self.up,self.down,self.save,self.confirmDelete,self.back,self.cancel}) do
  if widget.label then call(widget.label,"SetFont",STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",11*a.scale,"") end
 end
 for _,widget in ipairs({self.nameLabel,self.sourceLabel,self.bodyLabel,self.notice}) do call(widget,"SetFont",STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",11*a.scale,"") end
 for _,widget in ipairs({self.nav,self.choose,self.new,self.edit,self.delete,self.up,self.down,self.save,self.confirmDelete,self.back,self.cancel}) do
  call(widget.label,"SetWidth",widget:GetWidth()-16)
 end
 call(self.up,"SetText",editing and "Text up" or "Prev page");call(self.down,"SetText",editing and "Text down" or "Next page")
 local record=editing and a.private or a.record
 for _,widget in ipairs({self.nameLabel,self.nameEdit,self.sourceLabel,self.sourceEdit,self.bodyLabel,self.scroll}) do call(widget,"SetShown",editing) end
 call(self.viewer,"SetShown",not editing)
 place(self.viewer,viewY,inner,3*label+4*row+16)
 call(self.viewer,"SetFont",STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",12*a.scale,"")
 if not editing then
  local text="No record selected."
  if record then
   local c=record.createdClient
   local stale=c.family~=a.family or c.build~=a.build or c.interface~=a.interface
   text=(stale and "Different client/build; unverified.\n" or "Not validated against your current talents or activity.\n").."Name: "..record.name.."\nSource: "..record.source.."\nUnverified client: "..record.createdClient.family.." / "..record.createdClient.build.." / "..record.createdClient.interface.."\n"..record.text end
  a.pages=M.ReferenceView:Pages(text,16,math.max(1,math.floor((3*label+4*row+16)/(18*a.scale))))
  a.viewPage=math.max(1,math.min(#a.pages,a.viewPage or 1));call(self.viewer,"SetText",a.pages[a.viewPage])
 end
 call(self.choose,"SetShown",a.mode=="list");call(self.new,"SetShown",a.mode=="list");call(self.edit,"SetShown",a.mode=="list" and not not a.selected);call(self.delete,"SetShown",a.mode=="list" and not not a.selected)
 call(self.save,"SetShown",editing);call(self.confirmDelete,"SetShown",a.mode=="delete");call(self.back,"SetShown",a.mode~="list")
 call(self.choose,"SetText",a.record and "Change selection" or "Select a record")
 for _,box in ipairs({self.nameEdit,self.sourceEdit,self.bodyEdit}) do call(box,"SetFont",STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",12*a.scale,"");call(box,"EnableMouse",editing);call(box,"EnableKeyboard",editing) end
 call(self.nameEdit,"SetText",record and record.name or "");call(self.sourceEdit,"SetText",record and record.source or "");call(self.bodyEdit,"SetText",record and record.text or "");call(self.scroll,"SetVerticalScroll",0)
 call(self.notice,"SetText",a.mode=="delete" and "Delete record?\nDraft only.\nApply saves." or editing and "Private edits.\nSave stages.\nApply saves." or "User-authored.\nUnverified.\nApply saves.")
 if not self:Pure(a) then return false end;self:Bind(a);D:Refresh(self.frame);return self:Pure(a)end)
 if not ok then self:Close(a);return false end
 return result
end

function E:Open(kind)
 local request={};self.opening=request
 local draft,profile,parent=O.draft,M.profile,O.frame
 local client,adapter=M.Client,M.adapter
 local context,capability,scope=M.Policy.contextEpoch,M.Policy.capabilityEpoch,M.Policy.scopeEpoch
 local key,family,build,interface,source=client.key,client.family,client.build,client.interface,adapter.sourceCommit
 local patch,sourceMatched,experimental=client.patch,client.sourceMatched,client.experimental
 local adapterFamily,adapterPatch,adapterBuild,adapterInterface=adapter.family,adapter.patch,adapter.build,adapter.interface
 local function owner()
  return self.opening==request and O.draft==draft and draft and M.profile==profile and O.frame==parent and parent and O.page=="Preparations" and not O.setup and M.Client==client and M.adapter==adapter and client.key==key and client.family==family and client.build==build and client.interface==interface and client.patch==patch and client.sourceMatched==sourceMatched and client.experimental==experimental and adapter.sourceCommit==source and adapter.family==adapterFamily and adapter.patch==adapterPatch and adapter.build==adapterBuild and adapter.interface==adapterInterface and M.Policy.contextEpoch==context and M.Policy.capabilityEpoch==capability and M.Policy.scopeEpoch==scope and not M.Profiles.readOnly and not M.state.safe and not M.state.cinematic and M.state.world
 end
 if not titles[kind] or not owner() or not S:Public(parent.IsShown,"boolean",parent) or not owner() or S:InCombat() or not owner() or (D.top and D.top~=parent and D.top~=self.frame) then return false end
 local focusOK,focused=focus();if not focusOK or focused or not owner() then return false end
 local flushed,why=O:FlushEdits();if not owner() then return false end
 if flushed==false then O:Notice(why);return false end
 local subtree=draft.preparationReferences;local baseline,reason=M.References:Validate(subtree)
 if not owner() or draft.preparationReferences~=subtree then return false end
 if not baseline then O:Notice(reason or "Reference data unavailable.");return false end
 local w=self:Dimensions();if not owner() then return false end
 if not w then O:Notice("More screen space is needed for reference settings.");return false end
 self:Close(self.session);if not owner() then return false end
 self:Create();if not owner() then return false end
 local a={kind=kind,mode="list",draft=draft,profile=profile,parent=parent,subtree=subtree,original=M:Copy(subtree),collection=subtree and subtree[kind],baseline=baseline,client=client,key=key,family=family,build=build,interface=interface,patch=patch,sourceMatched=sourceMatched,experimental=experimental,adapter=adapter,source=source,adapterFamily=adapterFamily,adapterPatch=adapterPatch,adapterBuild=adapterBuild,adapterInterface=adapterInterface,context=context,capability=capability,scope=scope,scale=profile.textScale}
 self.session=a
 U:CloseChoices();if not self:Pure(a) then return false end
 if M.OptionsNavigation then M.OptionsNavigation:Stop() end;if not self:Pure(a) then return false end
 if M.AccessibleInput then M.AccessibleInput:Stop() end
 if not self:Pure(a) or not self:Paint(a) then self:Close(a);return false end
 D:Shown(self.frame);if not self:Pure(a) then return false end
 self.frame:Show();return self:Current(a,true)
end
local render=O.Render
function O:Render() local result=render(self);local a=E.session;if a and not E:Current(a,false) then E:Close(a) end;return result end
local create=O.Create
function O:Create() create(self);if self.frame and not self.referenceHideHook then self.referenceHideHook=true;self.frame:HookScript("OnHide",function() E:Close(E.session) end) end end
