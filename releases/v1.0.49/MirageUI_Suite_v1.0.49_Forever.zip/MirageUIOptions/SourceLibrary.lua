local M=MirageUI
if not M or not M.Options then return end
local L={group="Conditions",page=1,query="",matches={},rows={}}
M.SourceLibrary=L
local groups={"Conditions","Scenarios","PvP","Excluded","Quality"}
function L:Alive()
 return self.frame and self.frame:IsVisible() and M.DialogNavigation.top==self.frame and not M.Safety:InCombat() and not M.state.safe and not M.state.cinematic
end
function L:Render()
 local data=M.SourceLibraryData[self.group] or {};local query=self.query:lower();self.matches={}
 for _,r in ipairs(data) do
  local text=(r.id.." "..r.title.." "..r.detail):lower();local match=true
  for word in query:gmatch("%S+") do if not text:find(word,1,true) then match=false;break end end
  if match then self.matches[#self.matches+1]=r end
 end
 local pages=math.max(1,math.ceil(#self.matches/5));self.page=math.max(1,math.min(pages,self.page))
 for i,v in ipairs(self.rows) do
  local r=self.matches[(self.page-1)*5+i]
  v.id:SetText(r and r.id or "");v.title:SetText(r and r.title or "");v.detail:SetText(r and r.detail or "");v.status:SetText(r and r.status or "")
 end
 self.note:SetText(self.group.." · "..#self.matches.." matching records · page "..self.page.." / "..pages)
 M.DialogNavigation:Refresh(self.frame)
end
function L:Open()
 if M.Safety:InCombat() or M.state.safe or M.state.cinematic then return false end
 if not self.frame then
  local f=M.UI:Panel("MirageSourceLibrary","Source library · read-only",940,770);self.frame=f
  f:SetSize(940,770)
  f.closeButton:ClearAllPoints();f.closeButton:SetPoint("TOPRIGHT",-14,-12)
  self.navStart=M.UI:Button(f,"Controller / F6",740,-12,150,function() self.search:ClearFocus();M.DialogNavigation:Start(f,true) end)
  f.heading:SetWidth(700);self.groupButtons={}
  for i,g in ipairs(groups) do self.groupButtons[i]=M.UI:Button(f,g,22+(i-1)*176,-58,165,function() if not self:Alive() then return end;self.group=g;self.page=1;self:Render() end) end
  M.UI:Text(f,"Search source text or ID",22,-104,11,200)
  self.search=M.UI:Edit(f,225,-99,675,"",function(text) if not self:Alive() then return end;self.query=text;self.page=1;self:Render() end)
  self.search:SetScript("OnTextChanged",function(box,user) if user and self:Alive() then self.query=box:GetText();self.page=1;self:Render() end end)
  for i=1,5 do
   local y=-142-(i-1)*100
   self.rows[i]={id=M.UI:Text(f,"",22,y,12,85),title=M.UI:Text(f,"",115,y,12,780),detail=M.UI:Text(f,"",115,y-32,11,780),status=M.UI:Text(f,"",115,y-74,10,780)}
  end
  self.note=M.UI:Text(f,"",22,-656,11,680)
  self.previous=M.UI:Button(f,"Previous",698,-650,96,function() if not self:Alive() then return end;self.page=self.page-1;self:Render() end)
  self.next=M.UI:Button(f,"Next",804,-650,96,function() if not self:Alive() then return end;self.page=self.page+1;self:Render() end)
  M.UI:Text(f,"Source status is not implementation acceptance. No record can be activated here. The 491 CVE proposals are unbound; existing factory policies are separately tracked engineering candidates. No native PASS is implied.",22,-697,11,870)
  f:HookScript("OnHide",function() self.search:ClearFocus() end)
  M.DialogNavigation:Attach(f,{closeOnSuspend=true,allowed=function() return self:Alive() end,entries=function()
   local rows={{frame=self.navStart,key="navigation",kind="button"},{frame=self.search,key="search",kind="edit"}}
   for i,b in ipairs(self.groupButtons) do rows[#rows+1]={frame=b,key="group:"..i,kind="button"} end
   rows[#rows+1]={frame=self.previous,key="previous",kind="button"};rows[#rows+1]={frame=self.next,key="next",kind="button"};rows[#rows+1]={frame=f.closeButton,key="close",kind="button"};return rows
  end})
 end
 local sw,sh=M.Safety:Public(UIParent.GetWidth,"number",UIParent),M.Safety:Public(UIParent.GetHeight,"number",UIParent)
 if M.Safety:Number(sw) and M.Safety:Number(sh) and sw>30 and sh>30 then self.frame:SetScale(math.min(1,(sw-30)/940,(sh-30)/770)) end
 M.UI:CloseChoices();M.DialogNavigation:Shown(self.frame);self.frame:Show();self:Render();return true
end
local O=M.Options;local old=O.RenderSupport
function O:RenderSupport()
 old(self)
 self:Button("sourceLibrary","Browse requirements and test catalogue",0,-(self.contentHeight or 900)-16,self.cw,function() L:Open() end)
end
