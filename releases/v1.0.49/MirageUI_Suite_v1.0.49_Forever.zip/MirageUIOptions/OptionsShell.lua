local M=MirageUI
if not M or not M.Options then return end
local O,S=M.Options,M.Safety
local H={};M.OptionsShell=H
local retired={}
local create,render,search,cancel
local rootMethods={"SetSize","SetWidth","SetHeight","SetPoint","ClearAllPoints","GetWidth","GetHeight","IsShown","Show","Hide","HookScript","GetScript","SetScript","EnableKeyboard","SetPropagateKeyboardInput"}
local function mode(setup,advanced) return setup and "setup" or advanced and "advanced" or "simple" end
function H:Capture()
 local t={frame=O.frame,draft=O.draft,profile=M.profile};O.shellWork=t
 if t.frame then
  t.rootMethods={}
  for _,key in ipairs(rootMethods) do
   local fn=t.frame[key]
   if O.shellWork~=t or M.Options~=O or O.frame~=t.frame or O.draft~=t.draft or M.profile~=t.profile then t.retired=true;return t end
   t.rootMethods[key]=fn
  end
 end
 local c,a=M.Client,M.adapter
 local values={owner=O,draft=O.draft,frame=O.frame,profile=M.profile,scale=M.profile.textScale,setup=O.setup,advanced=O.advanced,page=O.page,step=O.step,
  client=c,adapter=a,key=c.key,family=c.family,patch=c.patch,build=c.build,interface=c.interface,matched=c.sourceMatched,experimental=c.experimental,
  source=a.sourceCommit,af=a.family,ap=a.patch,ab=a.build,ai=a.interface,safe=M.state.safe,cinematic=M.state.cinematic,world=M.state.world,
  context=M.Policy.contextEpoch,capability=M.Policy.capabilityEpoch,scope=M.Policy.scopeEpoch,
  parent=UIParent,widthFn=UIParent.GetWidth,heightFn=UIParent.GetHeight,combat=InCombatLockdown,safety=M.Safety,inCombat=S.InCombat,readable=S.Readable,
  metrics=M.OptionsShellMetrics,planFn=M.OptionsShellMetrics.Plan,font=STANDARD_TEXT_FONT,
  ui=M.UI,factory=CreateFrame,uiText=M.UI.Text,uiButton=M.UI.Button,uiEdit=M.UI.Edit,uiPanel=M.UI.Panel,uiSlider=M.UI.Slider}
 if O.shellWork~=t then t.retired=true;return t end
 for key,value in pairs(values) do t[key]=value end
 return t
end
function H:Pure(t)
 if not t or t.retired or O.shellWork~=t then return false end
 local ok,value=pcall(function()
  local c,a=M.Client,M.adapter
  if t and t.rootMethods then for _,key in ipairs(rootMethods) do if t.frame[key]~=t.rootMethods[key] or O.shellWork~=t then return false end end end
  return t and O.shellWork==t and M.Options==O and O.draft==t.draft and O.frame==t.frame and M.profile==t.profile and M.profile.textScale==t.scale and
   O.setup==t.setup and O.advanced==t.advanced and O.page==t.page and O.step==t.step and c==t.client and a==t.adapter and
   c.key==t.key and c.family==t.family and c.patch==t.patch and c.build==t.build and c.interface==t.interface and c.sourceMatched==t.matched and c.experimental==t.experimental and
   a.sourceCommit==t.source and a.family==t.af and a.patch==t.ap and a.build==t.ab and a.interface==t.ai and M.state.safe==t.safe and M.state.cinematic==t.cinematic and M.state.world==t.world and
   M.Policy.contextEpoch==t.context and M.Policy.capabilityEpoch==t.capability and M.Policy.scopeEpoch==t.scope and
   UIParent==t.parent and UIParent.GetWidth==t.widthFn and UIParent.GetHeight==t.heightFn and InCombatLockdown==t.combat and M.Safety==t.safety and S.InCombat==t.inCombat and S.Readable==t.readable and
   M.OptionsShellMetrics==t.metrics and t.metrics.Plan==t.planFn and STANDARD_TEXT_FONT==t.font and M.UI==t.ui and CreateFrame==t.factory and t.ui.Text==t.uiText and t.ui.Button==t.uiButton and t.ui.Edit==t.uiEdit and t.ui.Panel==t.uiPanel and t.ui.Slider==t.uiSlider
 end)
 return ok and value==true
end
function H:Viewport(t)
 if not self:Pure(t) then return nil end
 local w,ws=S:Public(t.widthFn,"number",t.parent);if not self:Pure(t) then return nil end
 local h,hs=S:Public(t.heightFn,"number",t.parent);if not self:Pure(t) then return nil end
 if ws~="KNOWN" or hs~="KNOWN" or w<=0 or h<=0 or w>16384 or h>16384 then return nil end
 local combat=S:InCombat();if combat or not self:Pure(t) then return nil end
 return w,h
end
function H:Current(t)
 local w,h=self:Viewport(t)
 return w and (not t.width or w==t.width and h==t.height) and self:Pure(t) or false
end
function H:Run(t,fn)
 local previous=self.active;self.active=t
 local ok,result=pcall(fn)
 self.active=previous
 return ok and result or false
end
function O:ShellRoot(frame)
 local t=H.active
 if t then
  t.rootMethods={}
  for _,key in ipairs(rootMethods) do
   local fn=frame[key]
   if O.shellWork~=t or O.frame~=frame or M.profile~=t.profile then error(retired,0) end
   t.rootMethods[key]=fn
  end
  if not H:Pure(t) then error(retired,0) end
 end
end
function O:ShellCurrent() return not H.active or H:Current(H.active) end
function O:ShellBoundary()
 local t=H.active
 if t and not H:Current(t) then error(retired,0) end
end
-- Local geometry policy: the actual mutation target must report unprotected.
-- Ancestors are visibility/security context, not mutation targets. Never infer
-- target protection from a protected ancestor or require native plain tables.
function H:PublicTarget(t,target,mutation)
 local function public(value)
  local ok,known=pcall(t.readable,S,value)
  return ok and known==true and self:Pure(t)
 end
 local function bind(object,key)
  if not public(object) then return nil end
  local ok,fn=pcall(function() return object[key] end)
  if not ok or not public(fn) or type(fn)~="function" then return nil end
  return {object=object,key=key,fn=fn}
 end
 local function invoke(bound)
  if not bound or not self:Pure(t) then return false end
  local ok,value=pcall(bound.fn,bound.object)
  if not ok or not public(value) then return false end
  local readable,fn=pcall(function() return bound.object[bound.key] end)
  if not readable or not public(fn) or fn~=bound.fn or not self:Pure(t) then return false end
  return true,value
 end
 local node,seen=target,{}
 for depth=1,32 do
  if not public(node) or (type(node)~="table" and type(node)~="userdata") or seen[node] then return false end
  seen[node]=true
  local forbidden,parent=bind(node,"IsForbidden"),bind(node,"GetParent")
  local protection=mutation and depth==1 and bind(node,"IsProtected") or nil
  if not forbidden or not parent or mutation and depth==1 and not protection then return false end
  local ok,value=invoke(forbidden);if not ok or type(value)~="boolean" or value~=false then return false end
  if protection then ok,value=invoke(protection);if not ok or type(value)~="boolean" or value~=false then return false end end
  ok,node=invoke(parent);if not ok then return false end
  if node==nil then return self:Pure(t) end
 end
 return false
end
function H:Call(t,object,key,...)
 if not self:Pure(t) then error(retired,0) end
 local fn=object==t.frame and t.rootMethods and t.rootMethods[key] or object[key]
 if not self:Current(t) or object[key]~=fn then error(retired,0) end
 local mutation=key:sub(1,3)=="Set" or key=="ClearAllPoints" or key=="Show" or key=="Hide" or key=="HookScript" or key:sub(1,6)=="Enable" or key=="Disable"
 local region=mutation or object==t.frame or key=="IsShown" or key=="GetWidth" or key=="GetHeight" or key=="GetText" or key=="Pending"
 if region and (not self:PublicTarget(t,object,mutation) or not self:Current(t) or object[key]~=fn) then error(retired,0) end
 local value=fn(object,...)
 if key=="IsShown" or key=="Pending" then
  -- Successful nil is unknown, not hidden/resolved; private/nonboolean results cannot
  -- authorize opening or bypass an unresolved pending field.
  if not S:Readable(value) or type(value)~="boolean" or not self:Current(t) then error(retired,0) end
 end
 if object[key]~=fn or not self:Current(t) then error(retired,0) end
 return value
end
function O:ShellCall(object,key,...)
 if H.active then return H:Call(H.active,object,key,...) end
 return object[key](object,...)
end
function H:Track(object,key)
 if not self.constructing or not object then return end
 if key=="Panel" then O.shellConstructedRoot=object
 else self.created[#self.created+1]=object;self.allocations=(self.allocations or 0)+1 end
end
function O:ShellBuild(key,...)
 local t=H.active
 if t and not H:Current(t) then error(retired,0) end
 if H.constructing and (H.allocations or 0)>=512 then error(retired,0) end
 local object=M.UI[key](M.UI,...);H:Track(object,key)
 if t and not H:Current(t) then
  if not H.constructing and object then
   local adopted=false;for _,widget in pairs(O.pool) do if widget==object then adopted=true;break end end
   if not adopted and object.Hide then pcall(object.Hide,object) end
  end
  error(retired,0)
 end
 return object
end
function O:ShellFrame(...)
 local t=H.active
 if t and not H:Current(t) then error(retired,0) end
 if H.constructing and (H.allocations or 0)>=512 then error(retired,0) end
 local object=CreateFrame(...);H:Track(object)
 if t and not H:Current(t) then error(retired,0) end
 return object
end
function H:Construct(t,p)
 if O.frame then create(O);O:ShellBoundary();return true end
 if self.quarantined then return false end
 local snapshot={};for k,v in pairs(O) do snapshot[k]=v end
 O.shellConstructionPlan=p;self.constructing=true;self.created={}
 local ok,problem=pcall(create,O)
 if ok and self:Current(t) then self.constructing=nil;self.created=nil;return true end
 local root=O.shellConstructedRoot
 -- No successor can adopt a half-built named root. Retain it only after all
 -- returned owned controls have been retired; otherwise refuse until reload.
 O.frame=nil
 local clean=root~=nil and (ok or problem==retired)
 for _,object in ipairs(self.created) do
  if object.Hide then local good=pcall(object.Hide,object);clean=clean and good end
  if object.Disable then local good=pcall(object.Disable,object);clean=clean and good end
  if object.SetScript then pcall(object.SetScript,object,"OnClick",nil) end
  if object.IsShown then local good,shown=pcall(object.IsShown,object);local safe,hidden=pcall(function() return S:Readable(shown) and type(shown)=="boolean" and shown==false end);clean=clean and good and safe and hidden end
 end
 if root then local good=pcall(root.Hide,root);local seen,shown=pcall(root.IsShown,root);local safe,hidden=pcall(function() return S:Readable(shown) and type(shown)=="boolean" and shown==false end);clean=clean and good and seen and safe and hidden end
 local work=O.shellWork
 for k in pairs(O) do if snapshot[k]==nil then O[k]=nil end end
 for k,v in pairs(snapshot) do O[k]=v end
 O.shellWork=work;O.shellConstructedRoot=root;O.frame=nil
 self.quarantined=not clean;self.constructing=nil;self.created=nil
 return false
end
function H:Refuse(t,reason)
 if not self:Pure(t) or O.shellRefusal==reason then return false end
 O.shellRefusal=reason
 -- Plain bounded static channel survives absence of a created settings frame.
 M:Print(reason or "Settings shell is unavailable at this size.")
 return false
end
function H:Plan(t,requested,fixed)
 local w,h=self:Viewport(t);if not w then return nil,"Settings shell geometry is unavailable." end
 t.width,t.height=w,h
 local p,why,required=t.metrics:Plan(requested,w,h,fixed,function() return self:Pure(t) end)
 if not self:Current(t) then return nil end
 if not p then
  local reason="Settings shell cannot fit this window; existing edits are unchanged."
  if required and S:Number(required.width) and S:Number(required.height) then reason="Settings shell needs "..math.ceil(required.width).." x "..math.ceil(required.height).." UI units; existing edits are unchanged." end
  return nil,reason
 end
 local session=O.shellSession
 if fixed and session and session.mode==requested then
  if session.preview and not p.preview then return nil,"Settings shell cannot fit its admitted preview; existing edits are unchanged." end
  if not session.preview and p.preview then p.preview=false;p.regions.preview=nil;p.regions.previewButton=nil end
 end
 return p
end
function H:Pending(t)
 for key,widget in pairs(O.pool) do
  local shown=self:Call(t,widget,"IsShown")
  if shown then
   if key:sub(1,7)=="slider:" and widget.Pending then
    if self:Call(t,widget,"Pending") then return true end
   elseif key:sub(1,5)=="edit:" then
    local text=self:Call(t,widget,"GetText")
    if not S:Readable(text) or not self:Current(t) or text~=widget.shellCommittedText then return true end
   end
  end
 end
 if O.importToken and O.importOwner==O.draft then return true end
 for _,editor in ipairs({M.ReferenceEditor,M.CursorColorDialog}) do
  local session=editor and editor.session
  if session and session.draft==O.draft and session.profile==M.profile then return true end
 end
 return false
end
function O:ShellPending()
 local t=H:Capture()
 local checked=false
 local pending=H:Run(t,function() local value=H:Pending(t);checked=true;return value end)
 return not checked or pending
end
function H:Apply(t,p)
 local function call(object,key,...) return self:Call(t,object,key,...) end
 local function rect(object,r)
  if not object or not r then return end
  if not S:Number(r.width) or not S:Number(r.height) or r.width<=0 or r.height<=0 then error(retired,0) end
  call(object,"ClearAllPoints");call(object,"SetPoint","TOPLEFT",r.x,-r.y);call(object,"SetSize",r.width,r.height)
 end
 call(O.frame,"SetSize",p.width,p.height)
 rect(O.frame.heading,p.regions.title);rect(O.subtitle,p.regions.subtitle);rect(O.frame.closeButton,p.regions.close)
 local font=STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"
 call(O.frame.heading,"SetFont",font,18*t.scale,"");call(O.subtitle,"SetFont",font,12*t.scale,"");call(O.notice,"SetFont",font,11*t.scale,"")
 call(O.search,"SetFont",font,12*t.scale,"")
 call(O.subtitle,"SetWordWrap",true);call(O.notice,"SetWordWrap",true)
 rect(O.scroll,p.regions.scroll)
 -- Only the existing body container width is admitted; no pooled child relayout.
 call(O.content,"SetWidth",p.bodyWidth);O.cw=p.bodyWidth
 rect(O.notice,p.regions.notice);rect(O.search,p.regions.search);rect(O.moreButton,p.regions.modeSwitch);rect(O.navScroll,p.regions.nav)
 if p.regions.nav then
  local width=p.navContentWidth or p.regions.nav.width-22
  call(O.nav,"SetWidth",width)
  local n=0
  for _,page in ipairs(O.pages) do
   local button=O.navButtons[page.id]
   call(button.label,"SetFont",font,12*t.scale,"");call(button,"SetWidth",width);call(button,"SetHeight",p.navRowHeight);call(button.label,"SetWidth",width-16)
   if call(button,"IsShown") then call(button,"ClearAllPoints");call(button,"SetPoint","TOPLEFT",0,-n*p.navRowHeight);button.mirageNavY=-n*p.navRowHeight;n=n+1 end
  end
  call(O.nav,"SetHeight",math.max(p.navRowHeight,n*p.navRowHeight))
 end
 for _,item in ipairs(p.footer) do
  local button=item.key=="safe" and O.safeButton or O[item.key]
  rect(button,item.rect);call(button.label,"SetFont",font,12*t.scale,"");call(button.label,"SetWidth",item.rect.width-16)
 end
 for _,button in ipairs({O.frame.closeButton,O.moreButton}) do if button then call(button.label,"SetFont",font,12*t.scale,"");call(button.label,"SetWidth",call(button,"GetWidth")-16) end end
 O.previewEnabled=p.preview==true
 if p.preview then
  rect(O.preview,p.regions.preview);rect(O.previewButton,p.regions.previewButton)
  if O.previewTitle and p.regions.preview then call(O.previewTitle,"SetWidth",p.regions.preview.width-24);call(O.previewTitle,"SetFont",font,12*t.scale,"") end
  if O.previewButton and p.regions.previewButton then call(O.previewButton.label,"SetWidth",p.regions.previewButton.width-16);call(O.previewButton.label,"SetFont",font,12*t.scale,"") end
 end
 if not self:Current(t) then return false end
 O.shellPlan=p;local session={draft=O.draft,profile=M.profile,scale=M.profile.textScale,frame=O.frame,mode=mode(O.setup,O.advanced),bodyWidth=p.bodyWidth,preview=p.preview==true,page=O.page,step=O.step,sourceOwner=t};O.shellSession=session
 local dismissal=O.setup and M.Managed:DismissalToken(M.profile) or nil
 if not self:Current(t) or O.shellSession~=session then return false end
 session.setupDismissal=dismissal
 self:Bind(t)
 O.shellRefusal=nil
 return true
end
function H:Bind(t)
 local session=O.shellSession
 local function displayed()
  return O.shellSession==session and O.draft==session.draft and O.frame==session.frame and mode(O.setup,O.advanced)==session.mode and O.page==session.page and O.step==session.step
 end
 local function live()
  return displayed() and M.profile==session.profile and M.profile.textScale==session.scale
 end
 for _,page in ipairs(O.pages) do
  self:Call(t,O.navButtons[page.id],"SetScript","OnClick",function()
   if not live() then return false end
   return O:ShellTransition(false,O.advanced,page.id)
  end)
 end
 if O.moreButton then self:Call(t,O.moreButton,"SetScript","OnClick",function()
  if not live() then return false end
  return O:ShellTransition(false,not O.advanced,"Home",true)
 end) end
 -- Footer callbacks also belong to the admitted session. A queued old click
 -- must not accept or dismiss a replacement wizard or settings draft.
 for _,entry in ipairs({{O.apply,"Apply"},{O.cancel,"Cancel"},{O.frame.closeButton,"Cancel"},{O.undo,"Undo"}}) do
  local button,method=entry[1],entry[2]
  local owned=method=="Cancel" and displayed or live
  self:Call(t,button,"SetScript","OnClick",function()
   if not owned() then return false end
   local shown,status=S:Public(O.frame.IsShown,"boolean",O.frame)
   if status~="KNOWN" or shown~=true or not owned() then return false end
   return O[method](O)
  end)
 end
end
function H:SessionCurrent(session)
 if not session then return false end
 local ok,value=pcall(function()
 local t=session.sourceOwner;local c,a=M.Client,M.adapter
 return t and session.profile==M.profile and session.scale==M.profile.textScale and session.frame==O.frame and session.draft==O.draft and
  c==t.client and a==t.adapter and c.key==t.key and c.family==t.family and c.patch==t.patch and c.build==t.build and c.interface==t.interface and c.sourceMatched==t.matched and c.experimental==t.experimental and
  a.sourceCommit==t.source and a.family==t.af and a.patch==t.ap and a.build==t.ab and a.interface==t.ai end)
 return ok and value==true
end
function H:Fixed(requested)
 local s=O.shellSession
 if s and s.frame==O.frame and s.profile==M.profile and s.scale==M.profile.textScale and s.mode==requested then return s.bodyWidth end
end
create,render,search,cancel=O.Create,O.Render,O.Search,O.Cancel
function O:FitWindow()
 if H.active then return true end
 return self:ShellReflow()
end
function O:ShellReflow()
 if not self.frame or not self.draft then return false end
 local session=self.shellSession
 if session and (not H:SessionCurrent(session) or session.mode~=mode(self.setup,self.advanced)) then return false end
 local t=H:Capture()
 return H:Run(t,function()
  if not H:Call(t,self.frame,"IsShown") then return false end
  local p,why=H:Plan(t,mode(self.setup,self.advanced),H:Fixed(mode(self.setup,self.advanced)))
  if not p then return H:Refuse(t,why) end
  return H:Apply(t,p)
 end)
end
function O:Create()
 if H.constructing then self.shellWork={};return false end
 if H.active then return create(self) end
 local t=H:Capture()
 return H:Run(t,function()
  local p,why=H:Plan(t,mode(self.setup,self.advanced))
  if not p then return H:Refuse(t,why) end
  if not H:Construct(t,p) then return false end;self:ShellBoundary()
  return H:Apply(t,p)
 end)
end
function O:Render(receipt)
 if receipt~=nil then
  -- Explicit caller-owned rendering must not capture/adopt another request.
  if type(receipt)~="table" or (H.active and H.active~=receipt) then return false end
  local ok,current=pcall(H.Pure,H,receipt)
  if not ok or current~=true or (H.active and H.active~=receipt) then return false end
 end
 if not self.draft then return false end
 local t=receipt or H.active or H:Capture()
 return H:Run(t,function()
  self:ShellBoundary()
  local requested=mode(self.setup,self.advanced)
  local p,why=H:Plan(t,requested,H:Fixed(requested))
  if not p then return H:Refuse(t,why) end
  if not t.fresh and H:Pending(t) then return H:Refuse(t,"Finish or cancel pending fields before changing this page.") end
  self.cw=p.bodyWidth;H:Call(t,self.content,"SetWidth",p.bodyWidth)
  self.previewEnabled=p.preview==true
  if p.preview and not self.preview then H:Call(t,self,"CreatePreview",p.width,p.height) end
  self.shellRenderToken={}
  render(self);self:ShellBoundary()
  for _,button in ipairs({self.undo,self.unlock,self.safeButton}) do H:Call(t,button,"SetShown",not self.setup) end
  if p.preview and self.previewButton then H:Call(t,self.previewButton,"Show") end
  return H:Apply(t,p)
 end)
end
function O:Search(text)
 local t=H.active or H:Capture()
 return H:Run(t,function()
  local p,why=H:Plan(t,mode(self.setup,self.advanced),H:Fixed(mode(self.setup,self.advanced)))
  if not p then return H:Refuse(t,why) end
  search(self,text);self:ShellBoundary()
  return H:Apply(t,p)
 end)
end
function O:ShellTransition(setup,advanced,page,clearSearch,step)
 if not self.frame or not self.draft then return false end
 local t=H:Capture()
 return H:Run(t,function()
  if not H:Call(t,self.frame,"IsShown") then return false end
  local candidate=mode(setup,advanced)
  local p,why=H:Plan(t,candidate,H:Fixed(candidate))
  if not p then return H:Refuse(t,why) end
  if H:Pending(t) then return H:Refuse(t,"Finish or cancel pending fields before changing this page.") end
  self.setup=setup;self.advanced=advanced;self.page=page or self.page;self.step=step or self.step
  t.setup,t.advanced,t.page,t.step=self.setup,self.advanced,self.page,self.step
  self.shellSession=nil
  if clearSearch then H:Call(t,self.search,"SetText","") end
  return self:Render()
 end)
end
function H:Open(setup,t)
 t=t or self:Capture()
 if self.constructing then return false end
 return self:Run(t,function()
  if O.frame and self:Call(t,O.frame,"IsShown") and O.draft then
   -- Explicit repeated Open never clears buffers, changes page, or captures input.
   local session=O.shellSession
   if not self:SessionCurrent(session) then return self:Refuse(t,"Settings owner changed; close this draft before reopening.") end
   if not setup or O.setup then return true end
   if self:Pending(t) then return self:Refuse(t,"Finish or cancel pending fields before opening setup.") end
  end
  local requested=setup and "setup" or "simple"
  local p,why=self:Plan(t,requested)
  if not p then return self:Refuse(t,why) end
  if O.draft and self:Pending(t) then return self:Refuse(t,"Finish or cancel pending fields before opening setup.") end
  if not self:Construct(t,p) then return false end
  O:ShellBoundary()
  local draft=M:Copy(M.profile);O:ShellBoundary()
  O.draft=draft;t.draft=draft;O.setup=setup;t.setup=setup;O.advanced=false;t.advanced=false;O.page="Home";t.page="Home";O.step=1;t.step=1
  O.pendingFit=nil;O.pendingCursorImport=nil;O.confirmRestore=nil;O.shellSession=nil;t.fresh=true
  if not O:Render() then return false end;t.fresh=nil
  self:Call(t,O.frame,"Show")
  if M.profile.gamepadNavigation and M.AccessibleInput then
   local input=M.AccessibleInput
   if self:Call(t,input,"Allowed") then self:Call(t,input,"Start") end
  end
  if not O.shellResizeHook then
   O.shellResizeHook=true
   O.frame:HookScript("OnUpdate",function(_,elapsed)
    H.elapsed=(H.elapsed or 0)+(elapsed or 0)
    if H.elapsed>=.25 then H.elapsed=0
     local poll=H:Capture();local w,h=H:Viewport(poll)
     if w and H:Pure(poll) then
      local last=O.shellViewport
      if not last or last[1]~=w or last[2]~=h then O.shellViewport={w,h};O:ShellReflow() end
     end
    end
   end)
   if not self:Current(t) then return false end
  end
  return true
 end)
end
function O:ShellOpenPage(page,advanced)
 local t=H:Capture()
 if not H:Open(false,t) or not H:Current(t) then return false end
 if advanced==nil then advanced=self.advanced end
 return self:ShellTransition(false,advanced,page)
end
function O:Open() return H:Open(false) end
function O:Setup() return H:Open(true) end
-- Undo restores the previous applied profile; a refusal is not Cancel.
-- Keep a caller-owned shell receipt across service, copy and render callbacks.
function O:Undo()
 if self.undoRequest or self.setup or not H:SessionCurrent(self.shellSession) then return false end
 local session=self.shellSession
 local request={};self.undoRequest=request
 local ok,result=pcall(function()
  local t=H:Capture()
  local profiles,undo,copy=M.Profiles,M.Profiles.Undo,M.Copy
  local function owned()
   return self.undoRequest==request and self.shellSession==session and M.Profiles==profiles and profiles.Undo==undo and M.Copy==copy and H:Current(t)
  end
  if not owned() then return false end
  local shown,status=S:Public(t.frame.IsShown,"boolean",t.frame)
  if status~="KNOWN" or shown~=true or not owned() then return false end
  local called,accepted,why=pcall(undo,profiles)
  if called and accepted==true then
   -- The successful service intentionally changes the profile, but never
   -- grants this continuation ownership of a replacement editor session.
   t.profile=M.profile;t.scale=M.profile.textScale;t.context=M.Policy.contextEpoch
  end
  if not owned() then return false end
  if not called or accepted~=true then
   self:Notice(called and why or "Undo could not be completed. Your draft was preserved.")
   return false
  end
  local draft=copy(M,t.profile)
  if not owned() or type(draft)~="table" or draft==t.profile then return false end
  self.pendingFit=nil;self.pendingCursorImport=nil;self.confirmRestore=nil
  self.draft=draft;t.draft=draft;t.fresh=true
  -- Explicit successful Undo discards pending edits, unlike a page transition.
  if not self:Render(t) or not H:Current(t) or self.undoRequest~=request then return false end
  self:Notice("Previous applied settings restored.")
  return true
 end)
 if self.undoRequest==request then self.undoRequest=nil end
 return ok and result==true
end
function O:Cancel()
 if H.constructing then self.shellWork={};return false end
 local session=self.shellSession
 local setupDismissal=self.setup and session and session.mode=="setup" and session.draft==self.draft and session.frame==self.frame and session.setupDismissal or nil
 self.shellWork={};self.shellSession=nil;self.shellViewport=nil
 return cancel(self,setupDismissal)
end
