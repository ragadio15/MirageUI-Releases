local M=MirageUI
if not M or not M.Options then return end
local O,U,S=M.Options,M.UI,M.Safety
-- Explicit, settings-local navigation. No binding writes or gameplay key capture.
M.OptionsNavigation={enabled=false,index=0}
local A=M.OptionsNavigation
local function shown(f) return f and f.IsShown and f:IsShown() and (not f.IsEnabled or f:IsEnabled()) end
function A:Busy()
 return S:InCombat() or not O.frame or not O.frame:IsShown() or not O.draft or
  (O.importFrame and O.importFrame:IsShown()) or
  (M.modules.Preparations and M.modules.Preparations.frame and M.modules.Preparations.frame:IsShown()) or
  (M.modules.Bags and M.modules.Bags.browserFrame and M.modules.Bags.browserFrame:IsShown()) or
  (M.BindingEditor and M.BindingEditor.frame and M.BindingEditor.frame:IsShown()) or
  (M.HUDEditor and M.HUDEditor.owner) or (M.Editor and M.Editor.frame and M.Editor.frame:IsShown()) or
  (U.copy and U.copy:IsShown()) or (M.SourceLibrary and M.SourceLibrary.frame and M.SourceLibrary.frame:IsShown()) or
  (M.VisualPreview and M.VisualPreview.frame and M.VisualPreview.frame:IsShown()) or
  (M.SpellPicker and M.SpellPicker.frame and M.SpellPicker.frame:IsShown())
end
function A:Popup()
 if U.choices and U.choices:IsShown() then return U.choices,U.choices.rows,U.choices.scroll,function() U:CloseChoices() end end
end
function A:Entries()
 local entries={}
 local function add(f,kind,y,scroll,label,key)
  if shown(f) then entries[#entries+1]={frame=f,kind=kind,y=y,scroll=scroll,label=label,key=key} end
 end
 local popup,rows,scroll=self:Popup()
 if popup then for i,b in ipairs(rows) do add(b,'button',-(i-1)*30,scroll,nil,'choice:'..i) end;return entries end
 add(O.search,'edit',nil,nil,'Find a setting','search')
 if not O.setup then for _,p in ipairs(O.pages) do local b=O.navButtons[p.id];add(b,'button',b.mirageNavY or 0,O.navScroll,p.name,'nav:'..p.id) end end
 local content={}
 for key,f in pairs(O.pool) do
  local kind=key:match('^(%w+):');local target=kind=='slider' and f.edit or f
  if shown(f) and (kind=='button' or kind=='edit' or kind=='slider') then
   content[#content+1]={frame=target,kind=kind=='button' and 'button' or 'edit',y=f.mirageNavY or 0,x=f.mirageNavX or 0,scroll=O.scroll,key=key}
  end
 end
 table.sort(content,function(a,b) if a.y~=b.y then return a.y>b.y elseif a.x~=b.x then return a.x<b.x end;return a.key<b.key end)
 for _,entry in ipairs(content) do entries[#entries+1]=entry end
 for i,f in ipairs({O.apply,O.cancel,O.undo,O.unlock,O.safeButton,O.frame.closeButton}) do add(f,'button',nil,nil,nil,'footer:'..i) end
 return entries
end
function A:RestoreFocus(frame,key)
 for i,entry in ipairs(self:Entries()) do
  if (key and entry.key==key) or (not key and entry.frame==frame) then self.index=i;self:Highlight(entry);return true end
 end
 return false
end
function A:Highlight(entry)
 if not self.outline then
  self.outline=CreateFrame('Frame',nil,O.frame,'BackdropTemplate');S:Passive(self.outline)
  self.outline:SetBackdrop({edgeFile='Interface\\Buttons\\WHITE8X8',edgeSize=2})
 end
 self.outline:Hide();self.current=entry
 if not entry then return end
 self.outline:SetParent(entry.frame);self.outline:ClearAllPoints();self.outline:SetPoint('TOPLEFT',entry.frame,'TOPLEFT',-2,2);self.outline:SetPoint('BOTTOMRIGHT',entry.frame,'BOTTOMRIGHT',2,-2)
 self.outline:SetBackdropBorderColor(.96,.79,.36,1);self.outline:Show()
 if entry.scroll and entry.y then
  local top=-entry.y;local pos=entry.scroll:GetVerticalScroll();local h=entry.scroll:GetHeight()
  if S:Number(h) and h>0 then
   if top<pos then entry.scroll:SetVerticalScroll(math.max(0,top)) elseif top+32>pos+h then entry.scroll:SetVerticalScroll(math.max(0,top+32-h)) end
  end
 end
end
function A:Stop()
 self.enabled=false;self.index=0;self.current=nil;self.returnFocus=nil;if self.outline then self.outline:Hide() end
 if not S:InCombat() and O.frame and O.frame.SetPropagateKeyboardInput then O.frame:SetPropagateKeyboardInput(true) end
end
function A:Move(delta)
 if self:Busy() then self:Stop();return false end
 local entries=self:Entries();if #entries==0 then return false end
 self.index=((self.index-1+delta)%#entries)+1;self:Highlight(entries[self.index]);return true
end
function A:Start()
 if self:Busy() then return false end
 self.enabled=true;self.index=0;self:Move(1)
 O:Notice('Keyboard: Tab / Shift-Tab moves; Enter selects; Escape closes; F6 returns keys to the game. Text fields use normal typing.')
 return true
end
function A:Activate()
 if self:Busy() or not self.enabled then return false end
 local entry=self.current;if not entry or not shown(entry.frame) then return false end
 -- Recheck that the target still belongs to the current settings/choice list.
 local found=false;for _,row in ipairs(self:Entries()) do if row.frame==entry.frame then found=true;break end end
 if not found then return false end
 if entry.kind=='edit' then entry.frame:SetFocus();if entry.frame.HighlightText then entry.frame:HighlightText() end;return true end
 local click=entry.frame:GetScript('OnClick')
 if click then
  local wasPopup=self:Popup()~=nil
  if not wasPopup then self.returnFocus={frame=entry.frame,key=entry.key} end
  click(entry.frame,'LeftButton')
  if self:Popup() then self.index=0;self:Move(1)
  elseif wasPopup and self.returnFocus then self:RestoreFocus(self.returnFocus.frame,self.returnFocus.key);self.returnFocus=nil
  else self.returnFocus=nil end
  return true
 end
 return false
end
function A:Key(key)
 if self:Busy() then self:Stop();return false end
 if S:Typing() then return false end
 if key=='F6' then if self.enabled then self:Stop() else self:Start() end;return true end
 if not self.enabled then return false end
 if key=='TAB' then return self:Move(S:Public(IsShiftKeyDown,'boolean') and -1 or 1) end
 if key=='ENTER' or key=='SPACE' then return self:Activate() end
 if key=='ESCAPE' then
  local popup,_,_,close=self:Popup()
  if popup then close();local target=self.returnFocus;self.returnFocus=nil;if not target or not self:RestoreFocus(target.frame,target.key) then self.index=0;self:Move(1) end
  else O:Cancel();self:Stop() end
  return true
 end
 return false
end
local oldPlace=O.Place
function O:Place(widget,x,y) widget.mirageNavX=x;widget.mirageNavY=y;return oldPlace(self,widget,x,y) end
local oldRender=O.Render
function O:Render()
 local previous=A.current;local previousPage=self.lastRenderKey
 if A.outline then self:ShellCall(A.outline,"Hide") end;A.current=nil;A.index=0
 oldRender(self);if self.ShellBoundary then self:ShellBoundary() end
 for _,entry in ipairs(self:ShellCall(A,"Entries")) do if entry.kind=='edit' then
  local box=entry.frame
  self:ShellCall(box,'SetScript','OnTabPressed',function(b)
   if A:Busy() then return end
   local ok,why=O:FlushEdits();if ok==false then O:Notice(why);return end
   if entry.validate then entry.validate() end
   b:ClearFocus();A.enabled=true
   local entries=A:Entries();for i,row in ipairs(entries) do if row.frame==b then A.index=i;break end end
   A:Move(S:Public(IsShiftKeyDown,'boolean') and -1 or 1)
  end)
 end end
 if A.enabled and not A:Busy() then
  local returnTo=A.returnFocus or (previousPage==self.lastRenderKey and previous)
  if not returnTo or not self:ShellCall(A,"RestoreFocus",returnTo.frame,returnTo.key) then self:ShellCall(A,"Move",1) end
 end
end
local oldCreate=O.Create
function O:Create()
 oldCreate(self);if self.ShellBoundary then self:ShellBoundary() end
 if self.keyboardNavigationHooked then return end;self.keyboardNavigationHooked=true
 self:ShellCall(self.frame,"EnableKeyboard",true);self:ShellCall(self.frame,"SetPropagateKeyboardInput",true)
 self:ShellCall(self.frame,'SetScript','OnKeyDown',function(f,key)
  local handled=A:Key(key)
  if not S:InCombat() then f:SetPropagateKeyboardInput(not handled) end
 end)
 self:ShellCall(self.frame,'SetScript','OnKeyUp',function(f) if not S:InCombat() then f:SetPropagateKeyboardInput(true) end end)
 local hide=self:ShellCall(self.frame,'GetScript','OnHide');self:ShellCall(self.frame,'SetScript','OnHide',function(...) A:Stop();if hide then hide(...) end end)
end
local oldHome=O.RenderHome
function O:RenderHome()
 oldHome(self)
 self:Button('keyboardHelp','Keyboard navigation (F6)',0,-510,self.cw,function() A:Start() end)
 self:Button('accessPreset','Stage larger text and high contrast',0,-552,self.cw,function()
  self.draft.textScale=1.2;self.draft.contrast=true;self.draft.fade=0
  self:Render();self:Notice('Larger text, higher contrast and immediate transitions staged. Apply saves; Cancel discards. Cursor motion preferences are unchanged.')
 end)
end
