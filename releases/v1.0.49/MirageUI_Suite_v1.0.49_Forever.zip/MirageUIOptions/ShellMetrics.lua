local M=MirageUI
if not M then return end
-- Static owned chrome only. Native hidden-probe/font-fit acceptance is NOT_RUN.
local Q={generation=0,cacheCount=0};M.OptionsShellMetrics=Q
local cache,order,cacheCount,cacheNext,cacheOwner={},{},0,1,nil
local ownedFrame,ownedFont
local modes={simple=true,advanced=true,setup=true}
local catalogNames={Core="MirageUI Core",Context="Contextual visibility",Options="Settings",EditMode="Unlock Mode",Cursor="Cursor",Minimap="Minimap",Chat="Chat",Tooltips="Tooltips",QuestTracker="Objectives",UnitFrames="Unit frames",Nameplates="Nameplates",ActionBars="Action bars",UnderCharacterHUD="Under-Character HUD",ResourceBars="Resources and casts",Auras="Auras",Cooldowns="Cooldowns",PartyRaid="Party and raid",BlizzardSkin="Blizzard windows",Bags="Bags and bank",DataBars="Travel and progress",DamageMeters="Damage meter",PvP="PvP combat lenses",TacticalSignals="Tactical signals",Preparations="Preparations",Forever="Forever compatibility"}
local systemIDs={Core=true,Context=true,Options=true,EditMode=true,Forever=true}
local pages={"Overview","What appears when","Display ownership","Input and accessibility","Profiles","Validation worksheet","Help and recovery"}
local simple={"Overview and layout","Player bars","Cursor","Names and health bars","Text and comfort","Help and restore"}
local footerEditor={{"apply","Apply"},{"cancel","Close"},{"undo","Undo"},{"unlock","Move UI"},{"safe","Safe mode"}}
local footerSetup={{"apply","Set up MirageUI"},{"cancel","Not now"}}
local function finite(v) return type(v)=="number" and v==v and v~=math.huge and v~=-math.huge end
local function positive(v) return finite(v) and v>0 and v<=16384 end
local function plain(t) return type(t)=="table" and getmetatable(t)==nil end
local function source()
 local c=M.Client;local runtime=c and c.RuntimeAvailable
 if type(runtime)~="function" then return false end
 local ok,value=pcall(runtime,c)
 return ok and value==true and M.Client==c and c.RuntimeAvailable==runtime or false
end
function Q:SourceAllowed() return source() end
local function sameFields(t,values)
 if not plain(t) then return false end
 for k,v in pairs(values) do if rawget(t,k)~=v then return false end end
 return true
end
local function read(self,mode,request)
 local S,client,adapter,profile,catalog,parent=M.Safety,M.Client,M.adapter,M.profile,M.Catalog,UIParent
 local readable,frameCheck,fieldAccess,combat=S.Readable,S.Frame,S.FieldAccess,S.InCombat
 local secret,access,tableAccess,combatNative=issecretvalue,canaccessvalue,canaccesstable,InCombatLockdown
 local create,fontGlobal=CreateFrame,STANDARD_TEXT_FONT
 local readMethod,planMethod,solveMethod=self.Read,self.Plan,self.Solve
 local generation=self.generation;local scale=profile and profile.textScale
 local clientValues={key=client.key,family=client.family,patch=client.patch,build=client.build,interface=client.interface,sourceMatched=client.sourceMatched,RuntimeAvailable=client.RuntimeAvailable}
 local adapterValues={family=adapter.family,patch=adapter.patch,build=adapter.build,interface=adapter.interface,sourceCommit=adapter.sourceCommit}
 local policy=M.Policy;local context,capability,scope=policy.contextEpoch,policy.capabilityEpoch,policy.scopeEpoch
 local bindings={};local retired=false;local catalogueSeal={};local runtimeReady=false
 local function bindingSeal()
  local ok,value=pcall(function()
   for _,binding in ipairs(bindings) do
    for _,part in ipairs(binding.route) do
     if rawget(part.object,binding.key)~=part.slot or getmetatable(part.object)~=part.meta or (part.indexKnown and rawget(part.meta,"__index")~=part.index) then return false end
    end
   end
   return true
  end)
  return ok and value==true
 end
 local function owner()
  if retired then return false end
  local ok,value=pcall(function()
   if M.Policy~=policy or policy.contextEpoch~=context or policy.capabilityEpoch~=capability or policy.scopeEpoch~=scope or self.probeFrame~=ownedFrame or self.probeFont~=ownedFont or M.OptionsShellMetrics~=self or self.generation~=generation or self.Read~=readMethod or self.Plan~=planMethod or self.Solve~=solveMethod or M.Safety~=S or S.Readable~=readable or S.Frame~=frameCheck or S.FieldAccess~=fieldAccess or S.InCombat~=combat or issecretvalue~=secret or canaccessvalue~=access or canaccesstable~=tableAccess or InCombatLockdown~=combatNative or CreateFrame~=create or STANDARD_TEXT_FONT~=fontGlobal or UIParent~=parent or M.Client~=client or M.adapter~=adapter or M.profile~=profile or profile.textScale~=scale or M.Catalog~=catalog or not sameFields(client,clientValues) or not sameFields(adapter,adapterValues) or not runtimeReady then return false end
   local keys=0;for key in pairs(catalog) do keys=keys+1;if keys>25 or type(key)~="number" or key%1~=0 or key<1 or key>25 then return false end end
   for i,row in ipairs(catalogueSeal) do if rawget(catalog,i)~=row.record or rawget(row.record,"id")~=row.id or rawget(row.record,"name")~=row.name or rawget(row.record,"system")~=row.system then return false end end
   return true
  end)
  if not ok or value~=true then retired=true end
  return not retired
 end
 local function checkRequest()
  if not owner() then return false end
  local ok,value=pcall(request)
  if not owner() or not ok or type(value)~="boolean" or value~=true then retired=true;return false end
  return true
 end
 local function qualify(value)
  if not checkRequest() then return false end
  local ok,value=pcall(readable,S,value)
  return checkRequest() and ok and value==true
 end
 -- Public engine lookup is supported independently of its table/userdata resolver
 -- representation. Measurements and method checks are sequential, not atomic.
 local function lookup(object,key)
  if not qualify(object) then return nil,false end
  local ok,value=pcall(function() return object[key] end)
  if not checkRequest() or not ok or not qualify(value) then return nil,false end
  return value,true
 end
 local function live()
  if not checkRequest() then return false end
  for _,binding in ipairs(bindings) do
   if not binding.complete then
    local value,ok=lookup(binding.object,binding.key)
    if not ok or value~=binding.fn then return false end
   end
  end
  local ok,locked=pcall(combat,S)
  if not checkRequest() or not ok or locked~=false then return false end
  return owner() and bindingSeal()
 end
 local function bind(object,key)
  if not live() then return nil end
  local value,ok=lookup(object,key)
  if not ok or type(value)~="function" then return nil end
  -- Naturally exposed raw table slots can be pinned without invoking a resolver.
  -- Opaque/function/userdata resolvers remain admissible after public lookup;
  -- their internal state is not claimed to have an atomic pure seal.
  local route,node,seen,complete={},object,{},false
  for _=1,8 do
   if type(node)~="table" or seen[node] then break end;seen[node]=true
   local slot=rawget(node,key);local meta=getmetatable(node)
   if not qualify(slot) or not qualify(meta) then break end
   local indexKnown=type(meta)=="table";local index=indexKnown and rawget(meta,"__index") or nil
   if not qualify(index) then break end
   route[#route+1]={object=node,slot=slot,meta=meta,index=index,indexKnown=indexKnown}
   if slot~=nil then complete=slot==value;break end
   if type(index)~="table" then break end;node=index
  end
  if not live() then return nil end
  local entry={object=object,key=key,fn=value,route=route,complete=complete};bindings[#bindings+1]=entry
  if not live() then return nil end
  return entry
 end
 local function ready(binding)
  if not binding or not live() then return false end
  local value,ok=lookup(binding.object,binding.key)
  return ok and value==binding.fn and owner() and bindingSeal()
 end
 local function invoke(binding,...)
  if not ready(binding) then return nil,false end
  local ok,value=pcall(binding.fn,binding.object,...)
  if not live() or not ok then return nil,false end
  return value,true
 end
 local function frameOK(object,mutationTarget)
  local node,seen=object,{}
  for depth=1,32 do
   if not qualify(node) then return false end
   if node==nil then return depth>1 and live() end
   if (type(node)~="table" and type(node)~="userdata") or seen[node] then return false end
   seen[node]=true
   local forbidden=bind(node,"IsForbidden");local value,ok=invoke(forbidden)
   if not ok or not qualify(value) or value~=false then return false end
   -- Context ancestors are never mutated. Protection is required only on the
   -- actual owned target, not an unsupported all-ancestors-unprotected policy.
   if depth==1 and mutationTarget then
    local protected=bind(node,"IsProtected");value,ok=invoke(protected)
    if not ok or not qualify(value) or value~=false then return false end
   end
   local getParent=bind(node,"GetParent");value,ok=invoke(getParent)
   if not ok or not qualify(value) then return false end
   node=value
  end
  return node==nil and live()
 end
 -- Probe once, then preserve pure owner seals during measurement/dispatch.
 -- A paused profile may still open settings to resume or inspect diagnostics.
 runtimeReady=source()
 if not runtimeReady then return nil,"RUNTIME_UNAVAILABLE" end
 if type(request)~="function" or not qualify(mode) or not modes[mode] or not qualify(scale) or not finite(scale) or scale<.8 or scale>1.5 then return nil,"INPUT_UNAVAILABLE" end
 if not qualify(fontGlobal) then return nil,"FONT_UNAVAILABLE" end
 local font=fontGlobal or "Fonts\\FRIZQT__.TTF"
 if type(font)~="string" or #font==0 or #font>256 or font:find("[%c]") then return nil,"FONT_UNAVAILABLE" end
 if not live() or not frameOK(parent,false) then return nil,"PARENT_UNAVAILABLE" end
 -- Admit source-defined catalogue literals only, never a widget GetText or draft.
 if not qualify(catalog) or not plain(catalog) then return nil,"CATALOGUE_UNAVAILABLE" end
 local seen={};local count=0
 for key,row in pairs(catalog) do
  count=count+1;if count>25 or not finite(key) or key%1~=0 or key<1 or key>25 or not qualify(row) or not plain(row) then return nil,"CATALOGUE_UNAVAILABLE" end
  local id,name,system=rawget(row,"id"),rawget(row,"name"),rawget(row,"system")
  if not qualify(id) or not qualify(name) or not qualify(system) or type(id)~="string" or name~=catalogNames[id] or seen[id] or (system==true)~=(systemIDs[id]==true) then return nil,"CATALOGUE_UNAVAILABLE" end
  seen[id]=true;catalogueSeal[key]={record=row,id=id,name=name,system=system}
 end
 if count~=25 then return nil,"CATALOGUE_UNAVAILABLE" end
 local specs={{id="title",text="MIRAGEUI",base=18},{id="subtitle",text="The world first. The interface when it matters.",base=12},{id="close",text="x",base=12},{id="notice",text="MIRAGEUI",base=11}}
 local footer=mode=="setup" and footerSetup or footerEditor
 for _,row in ipairs(footer) do specs[#specs+1]={id=row[1],text=row[2],base=12} end
 if mode=="advanced" then specs[#specs+1]={id="previewTitle",text="MIRAGEUI PREVIEW",base=12};specs[#specs+1]={id="previewButton",text="Preview another scene",base=12} end
 local nav={}
 if mode~="setup" then
  specs[#specs+1]={id="modeSwitch",text=mode=="advanced" and "Simple settings" or "More settings",base=12}
  local function add(text) local id="nav"..(#nav+1);nav[#nav+1]=id;specs[#specs+1]={id=id,text=text,base=12} end
  -- Include every search-visible item even when simple navigation is filtered.
  for _,text in ipairs(simple) do add(text) end
  for _,text in ipairs(pages) do add(text) end
  for i=1,25 do local row=catalogueSeal[i];if not row.system then add(row.name) end end
 end
 if #specs>128 then return nil,"CATALOGUE_UNAVAILABLE" end
 if not self.frameAttempted then
  if not live() then return nil,"REQUEST_RETIRED" end
  self.frameAttempted=true
  local ok,value=pcall(create,"Frame",nil,parent);ownedFrame=ok and value or nil;self.probeFrame=ownedFrame
  if not live() or not ok then return nil,"PROBE_UNAVAILABLE" end
 end
 local frame=self.probeFrame
 if not frameOK(frame,true) then return nil,"PROBE_UNAVAILABLE" end
 local hide,mouse,keyboard,make=bind(frame,"Hide"),bind(frame,"EnableMouse"),bind(frame,"EnableKeyboard"),bind(frame,"CreateFontString")
 local _,ok=invoke(hide);if not ok then return nil,"PROBE_UNAVAILABLE" end
 _,ok=invoke(mouse,false);if not ok then return nil,"PROBE_UNAVAILABLE" end
 _,ok=invoke(keyboard,false);if not ok then return nil,"PROBE_UNAVAILABLE" end
 if not self.fontAttempted then
  if not ready(make) then return nil,"REQUEST_RETIRED" end
  self.fontAttempted=true;local good,value=pcall(make.fn,make.object,nil,"OVERLAY");ownedFont=good and value or nil;self.probeFont=ownedFont
  if not live() or not good then return nil,"PROBE_UNAVAILABLE" end
 end
 local probe=self.probeFont
 if not frameOK(probe,true) then return nil,"PROBE_UNAVAILABLE" end
 local fontHide=bind(probe,"Hide");local setFont=bind(probe,"SetFont");local wrap=bind(probe,"SetWordWrap");local setWidth=bind(probe,"SetWidth");local text=bind(probe,"SetText");local width=bind(probe,"GetStringWidth");local height=bind(probe,"GetStringHeight")
 if not fontHide or not setFont or not wrap or not setWidth or not text or not width or not height then return nil,"METRICS_UNAVAILABLE" end
 _,ok=invoke(fontHide);if not ok then return nil,"PROBE_UNAVAILABLE" end
 -- Cache ownership never includes private profile/draft objects.
 local signature=cacheOwner
 local compatible=signature and signature.client==client and signature.adapter==adapter and signature.font==probe and signature.parent==parent and signature.source==adapter.sourceCommit and #signature.bindings==#bindings
 if compatible then for i,binding in ipairs(bindings) do local old=signature.bindings[i];if old.object~=binding.object or old.key~=binding.key or old.fn~=binding.fn then compatible=false;break end end end
 if not compatible then cache={};order={};cacheCount=0;cacheNext=1;self.cacheCount=0;cacheOwner={client=client,adapter=adapter,font=probe,parent=parent,source=adapter.sourceCommit,bindings=bindings} end
 local result={mode=mode,font=font,scale=scale,flags="",labels={},nav=nav,footer={}}
 for _,row in ipairs(footer) do result.footer[#result.footer+1]=row[1] end
 for _,spec in ipairs(specs) do
  if not live() then return nil,"REQUEST_RETIRED" end
  local size=spec.base*scale;local key=font.."\0"..string.format("%.17g",size).."\0\0"..spec.text;local cached=cache[key]
  if not cached then
   local success,good=invoke(setFont,font,size,"")
   if not good or not qualify(success) or success~=true then return nil,"FONT_UNAVAILABLE" end
   local _,good=invoke(wrap,false);if not good then return nil,"METRICS_UNAVAILABLE" end
   _,good=invoke(setWidth,0);if not good then return nil,"METRICS_UNAVAILABLE" end
   _,good=invoke(text,spec.text);if not good then return nil,"METRICS_UNAVAILABLE" end
   local w,goodW=invoke(width);if not goodW or not qualify(w) or not positive(w) then return nil,"METRICS_UNAVAILABLE" end
   local h,goodH=invoke(height);if not goodH or not qualify(h) or not positive(h) then return nil,"METRICS_UNAVAILABLE" end
   if not live() then return nil,"REQUEST_RETIRED" end
   cached={width=w,height=h}
   if cacheCount==128 then local old=order[cacheNext];cache[old]=nil else cacheCount=cacheCount+1 end;self.cacheCount=cacheCount
   order[cacheNext]=key;cacheNext=cacheNext%128+1;cache[key]=cached
  end
  if not qualify(cached.width) or not qualify(cached.height) or not positive(cached.width) or not positive(cached.height) then return nil,"METRICS_UNAVAILABLE" end
  result.labels[spec.id]={width=cached.width,height=cached.height,text=spec.text,size=size}
 end
 if not live() then return nil,"REQUEST_RETIRED" end
 return result,nil,function() return owner() and bindingSeal() end
end
function Q:Read(mode,current)
 self.generation=self.generation+1
 if self.reading then return nil,"REQUEST_RETIRED" end
 self.reading=true
 local ok,value,reason,seal=pcall(read,self,mode,current)
 self.reading=nil
 if not ok then return nil,"METRICS_UNAVAILABLE" end
 return value,reason,seal
end
local function solve(width,height,mode,metrics,bodyWidth)
 if not positive(width) or not positive(height) or not modes[mode] or not plain(metrics) or rawget(metrics,"mode")~=mode or not plain(rawget(metrics,"labels")) or not plain(rawget(metrics,"footer")) or not plain(rawget(metrics,"nav")) then return nil,"INVALID_METRICS" end
 local scale=rawget(metrics,"scale");if not finite(scale) or scale<.8 or scale>1.5 then return nil,"INVALID_METRICS" end
 local labels=rawget(metrics,"labels")
 local function metric(id)
  local r=rawget(labels,id);if not plain(r) or not positive(rawget(r,"width")) or not positive(rawget(r,"height")) then error("Invalid shell metric",0) end
  return rawget(r,"width"),rawget(r,"height")
 end
 local titleW,titleH=metric("title");local subW,subH=metric("subtitle");local closeW,closeH=metric("close");local _,noticeLine=metric("notice")
 closeW=math.max(28,closeW+16);closeH=math.max(28,closeH+14)
 local actionSpecs=mode=="setup" and footerSetup or footerEditor
 local actionWidths={};local footerWidth=0;local buttonHeight=28;local widestAction=0
 for i,row in ipairs(actionSpecs) do
  if rawget(metrics.footer,i)~=row[1] then return nil,"INVALID_METRICS" end
  local w,h=metric(row[1]);w=w+16;buttonHeight=math.max(buttonHeight,h+14);actionWidths[i]=w;footerWidth=footerWidth+w+(i>1 and 8 or 0);widestAction=math.max(widestAction,w)
 end
 if rawget(metrics.footer,#actionSpecs+1)~=nil then return nil,"INVALID_METRICS" end
 local navContentWidth,navRowHeight=0,buttonHeight+4
 if mode~="setup" then
  local sw,sh=metric("modeSwitch");navContentWidth=sw+16;buttonHeight=math.max(buttonHeight,sh+14)
  local count=0;for i,id in ipairs(metrics.nav) do count=count+1;if count>64 or type(id)~="string" then return nil,"INVALID_METRICS" end;local w,h=metric(id);navContentWidth=math.max(navContentWidth,w+16);navRowHeight=math.max(navRowHeight,h+18) end
  if count==0 then return nil,"INVALID_METRICS" end
 end
 local navWidth=mode=="setup" and 0 or navContentWidth+22
 local left=mode=="setup" and 36 or 18+navWidth+12
 local reserve=16+49*math.max(1,scale)
 local primitiveMinimum=math.max(reserve+13+64,160+widestAction+8)
 local minimumBody=math.max(primitiveMinimum,footerWidth)
 if bodyWidth~=nil and (not positive(bodyWidth) or bodyWidth<minimumBody) then return nil,"BODY_WIDTH_UNAVAILABLE" end
 local bodyMinimum=bodyWidth or minimumBody
 local requiredWidth=math.max(left+bodyMinimum+40,titleW+closeW+48,subW+36)
 local availableWidth=width-30;local cap=mode=="setup" and 760 or mode=="simple" and 980 or 1020
 local panelWidth=math.max(requiredWidth,math.min(cap,availableWidth))
 local body=bodyWidth or panelWidth-left-40
 local preview,previewWidth,previewButtonHeight=false,nil,nil
 if mode=="advanced" and height-30>=640 then
  local tw=metric("previewTitle");local bw,bh=metric("previewButton")
  previewWidth=math.max(205,tw+24,bw+16);previewButtonHeight=math.max(28,bh+14)
  if bodyWidth then
   local needed=left+body+40+previewWidth+12
   if needed<=availableWidth then panelWidth=math.max(panelWidth,needed);preview=true end
  else
   local candidate=panelWidth-left-40-previewWidth-12
   if candidate>=minimumBody then body=candidate;preview=true end
  end
 end
 local titleBottom=math.max(18+titleH,12+closeH)
 local subY=titleBottom+8;local subLines=1
 local controlY=subY+subH*subLines+12
 local searchHeight=math.max(28,buttonHeight-6)
 local bodyY=mode=="setup" and controlY or controlY+math.max(searchHeight,buttonHeight)+8
 local noticeH=noticeLine*2
 local requiredHeight=bodyY+128+12+noticeH+8+buttonHeight+18
 local required={width=math.ceil(requiredWidth+30),height=math.ceil(requiredHeight+30)}
 if panelWidth>availableWidth or requiredHeight>height-30 then return nil,"VIEWPORT_TOO_SMALL",required end
 local capHeight=mode=="setup" and 540 or mode=="simple" and 680 or 720
 local panelHeight=math.max(requiredHeight,math.min(capHeight,height-30))
 local footerY=panelHeight-18-buttonHeight;local noticeY=footerY-8-noticeH;local scrollHeight=noticeY-12-bodyY
 local function rect(x,y,w,h) if not finite(x) or not finite(y) or x<0 or y<0 or not positive(w) or not positive(h) or x+w>panelWidth+.000001 or y+h>panelHeight+.000001 then error("Uncontained shell",0) end;return {x=x,y=y,width=w,height=h} end
 local regions={title=rect(22,18,panelWidth-22-closeW-26,titleH),subtitle=rect(18,subY,panelWidth-36,subH*subLines),close=rect(panelWidth-18-closeW,12,closeW,closeH),scroll=rect(left,bodyY,body+22,scrollHeight),content=rect(left,bodyY,body,scrollHeight),notice=rect(left,noticeY,body,noticeH)}
 if mode~="setup" then regions.nav=rect(18,bodyY,navWidth,scrollHeight);regions.modeSwitch=rect(18,controlY,navContentWidth,buttonHeight);regions.search=rect(left,controlY,body,searchHeight) end
 if preview and scrollHeight>=360 and previewButtonHeight<=panelHeight-18-bodyY then
  local x=left+body+34
  regions.preview=rect(x,bodyY,previewWidth,scrollHeight)
  regions.previewButton=rect(x,panelHeight-18-previewButtonHeight,previewWidth,previewButtonHeight)
 else preview=false end
 local footer={};local x=left
 for i,row in ipairs(actionSpecs) do footer[i]={key=row[1],rect=rect(x,footerY,actionWidths[i],buttonHeight)};x=x+actionWidths[i]+8 end
 return {mode=mode,width=panelWidth,height=panelHeight,bodyWidth=body,required=required,regions=regions,footer=footer,navContentWidth=navContentWidth,navRowHeight=navRowHeight,buttonHeight=buttonHeight,noticeLines=2,subtitleLines=subLines,preview=preview,primitiveMinimum=primitiveMinimum}
end
function Q:Solve(width,height,mode,metrics,bodyWidth)
 local ok,plan,reason,required=pcall(solve,width,height,mode,metrics,bodyWidth)
 if not ok then return nil,"INVALID_METRICS" end
 return plan,reason,required
end
function Q:Plan(mode,width,height,bodyWidth,current)
 local readMethod,solveMethod=self.Read,self.Solve
 local safety,readable=M.Safety,M.Safety.Readable
 local metrics,reason,seal=readMethod(self,mode,current);if not metrics then return nil,reason end
 if not seal() then return nil,"REQUEST_RETIRED" end
 for _,value in ipairs({mode,width,height}) do
  local ok,public=pcall(readable,safety,value)
  if not seal() then return nil,"REQUEST_RETIRED" end
  if not ok or public~=true then return nil,"INPUT_UNAVAILABLE" end
 end
 do local ok,public=pcall(readable,safety,bodyWidth);if not seal() then return nil,"REQUEST_RETIRED" end;if not ok or public~=true then return nil,"INPUT_UNAVAILABLE" end end
 local plan,why,required=solveMethod(self,width,height,mode,metrics,bodyWidth)
 local ok,valid=pcall(current);if not ok or valid~=true or not seal() then return nil,"REQUEST_RETIRED" end
 return plan,why,required
end
