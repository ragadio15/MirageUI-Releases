local M=MirageUI
if not M or not M.Options then return end
local O,U=M.Options,M.UI
function O:RenderValidation()
 local E=M.NativeEvidence
 self:Text("validationHeading","Your in-game validation worksheet",0,0,self.cw,16)
 self:Text("validationScope","Record your observations against the master plan and HUD tests. This is a session-only worksheet, not an automated test or permission grant. Export before reload. A version, build or settings change makes the worksheet stale; it cannot approve source rules.",0,-45,self.cw,12)
 self:Button("validationBegin","Begin a worksheet for the current settings",0,-160,self.cw,function() local _,why=E:Begin();self:Notice(why) end)
 self:Button("validationExport","Copy the current worksheet",0,-202,self.cw,function() U:CopyWindow("User-reported validation",E:Export()) end)
 self:Button("validationClear",self.validationClearPending and "Confirm clearing these session results" or "Clear the session worksheet",0,-244,self.cw,function()
  if not self.validationClearPending then self.validationClearPending=true;self:Notice("Export first to keep your observations. Select Confirm clearing to discard this session.")
  else self.validationClearPending=false;local _,why=E:Clear();self:Notice(why) end
 end)
 self.validationID=self.validationID or M.AcceptanceTests[1].id
 local choices={};local current
 for _,row in ipairs(M.AcceptanceTests) do choices[#choices+1]={value=row.id,label=row.id.." — "..(row.shortLabel or row.label)};if row.id==self.validationID then current=row end end
 self:Choice("validationTest",self.validationID.." — "..(current and (current.shortLabel or current.label) or "Select test"),choices,self.validationID,0,-298,self.cw,function(v) self.validationID=v end)
 self:Text("validationCriterion",current and (current.criterion or "Use the corresponding K test in the packaged validation card. Record only what you actually observed on this client.") or "",0,-342,self.cw,11)
 local y=-440
 for _,result in ipairs({"PASS","PARTIAL","FAIL","BLOCKED","NOT_RUN","NA"}) do
  local status=result
  self:Button("validation"..status,"Record "..status,0,y,self.cw,function() local _,why=E:Record(self.validationID,status);self:Notice(why) end);y=y-38
 end
 self:Text("validationMemory","Optional performance and memory capture does not pass any test automatically. Compare identical scenes. Native memory net change is not an allocation rate, garbage-collection trace, or proof of a leak.",0,y-10,self.cw,11);y=y-105
 self:Button("memoryCapture","Start QUIET capture with memory samples",0,y,self.cw,function() local _,why=M.Profiler:Start("QUIET",true);self:Notice(why) end);y=y-40
 self:Button("memoryStop","Stop and copy performance / memory",0,y,self.cw,function() M.Profiler:Stop();U:CopyWindow("Local performance",M.Profiler:Export()) end)
end
