local M=MirageUI
if not M or not M.Options then return end
local U,S,O=M.UI,M.Safety,M.Options
-- This editor owns only passive preview widgets and a detached preferences
-- transaction. It never acquires native cooldown children or action bindings.
local E={limit=160,searchLimit=96,historyLimit=20}
M.CooldownEditor=E
local auraModes={Aura=true,Debuff=true,TargetAura=true,TargetDebuff=true,ItemAura=true}
local modeLabels={Cooldown="Cooldown",Recharge="Charges",Aura="Buff / proc",Debuff="Debuff",TargetAura="Buff / proc",TargetDebuff="Debuff",Item="Item cooldown",ItemAura="Item buff"}
local highlightLabels={None="None",Accent="Gold border",Glow="Soft glow"}
local tableModes={Cooldown="Cooldown",Recharge="Charges",Aura="Buff / proc",Debuff="Debuff",TargetAura="Buff / proc",TargetDebuff="Debuff",Item="Item CD",ItemAura="Item buff"}
local function integer(v,lo,hi) return S:Number(v) and v%1==0 and v>=lo and v<=hi end
local function provider() return M.Rework and M.Rework.CooldownRow end
local function equal(a,b,depth)
 if type(a)~=type(b) then return false end
 if type(a)~="table" then return a==b end
 if (depth or 0)>24 then return false end
 for k,v in pairs(a) do if not equal(v,b[k],(depth or 0)+1) then return false end end
 for k in pairs(b) do if a[k]==nil then return false end end
 return true
end
local function identity(entry) return entry.mode..":"..entry.id..(entry.mode=="ItemAura" and ":"..entry.auraID or "") end
local function isItem(entry) return entry.mode=="Item" or entry.mode=="ItemAura" end
local function searchText(value)
 return S:Text(value) and value:match("^%s*(.-)%s*$"):sub(1,120) or ""
end
local function copyRecords(records)
 local out={};for i,row in ipairs(records or {}) do out[i]={token=row.token,entry=M:Copy(row.entry)} end;return out
end
local function lookup(records,token)
 for i,row in ipairs(records or {}) do if row.token==token then return i,row end end
end
local function groupByID(groups,id)
 for i,group in ipairs(groups or {}) do if group.id==id then return group,i end end
end
local function display(entry) return entry and entry.bar=="Secondary" and "Secondary" or "Primary" end
local trackerFields={"spells","rowCustom","rowSecondary","groups"}
local function copyTracker(to,from)
 for _,key in ipairs(trackerFields) do to[key]=M:Copy(from[key]) end
end
local function selectedButton(button,yes)
 button.selected=yes==true
 if U.PaintButton then U:PaintButton(button) end
end
function E:Current(session)
 if not self.session or (session and self.session~=session) or not self.model then return false,"The tracker session changed." end
 local request=self.session;local model=self.model;local profiles=M.Profiles
 if M.profile~=model.base or profiles~=model.profileOwner or profiles.account~=model.account or profiles.character~=model.character
  or (model.character and model.character.useCharacter)~=model.scope or (model.savedOwner and model.savedOwner.profile)~=model.savedProfile then
  return false,"The active profile changed. Reopen the tracker before editing."
 end
 if S:InCombat() then return false,"Tracker editing resumes after combat." end
 if self.session~=request or self.model~=model then return false,"The tracker session changed." end
 if self.suspended then return false,"Reopen Configure Tracker to continue your draft." end
 return true
end
function E:Notice(text)
 self.message=text or ""
 if self.notice then self.notice:SetText(self.message) end
end
function E:RefreshUndo()
 if self.undo then self.undo:SetEnabled(self.fieldDraft~=nil or self.pendingGroupEdit~=nil or #(self.history or {})>0) end
end
function E:RefreshContext()
 M.state.forceEvaluate=true
 if M.KeybindWorkspace and M.KeybindWorkspace.RefreshContext then M.KeybindWorkspace:RefreshContext() end
 if provider() and provider().RefreshVisibility then provider():RefreshVisibility() end
end
function E:Snapshot()
 local c=self.model.draft.modules.Cooldowns
 return {records=copyRecords(self.records),selection=self.selection,custom=c.rowCustom,spells=M:Copy(c.spells),secondary=c.rowSecondary==true,groups=M:Copy(c.groups or {})}
end
function E:Mutate(fn)
 local session,model=self.session,self.model;local ok,why=self:Current(session)
 if not ok then self:Notice(why);return false,why end
 if self.busy then return false,"A tracker change is already in progress." end
 local operation={};self.busy=operation
 local function release() if self.busy==operation then self.busy=nil end end
 local before=self:Snapshot();local records=copyRecords(self.records);local settings=M:Copy(self.model.draft.modules.Cooldowns)
 settings.groups=settings.groups or {}
 local accepted,message=pcall(fn,records,settings)
 if not accepted or message==false then release();return false,"That change could not be staged." end
 if not self:Current(session) or self.model~=model then release();return false,"The tracker session changed." end
 local changed,reason=model:Change(function(p)
  p.modules.Cooldowns.spells={};p.modules.Cooldowns.rowCustom=true
  p.modules.Cooldowns.groups=M:Copy(settings.groups);p.modules.Cooldowns.rowSecondary=settings.rowSecondary==true
  for i,row in ipairs(records) do p.modules.Cooldowns.spells[i]=M:Copy(row.entry) end
  return M.Profiles:CheckTransaction(p)
 end,false)
 if not self:Current(session) or self.model~=model then release();return false,"The tracker session changed." end
 if not changed then release();self:Notice(reason);return false,reason end
 self.records=records
 if not equal(before.spells,self.model.draft.modules.Cooldowns.spells) or before.custom~=true
  or before.secondary~=self.model.draft.modules.Cooldowns.rowSecondary or not equal(before.groups,self.model.draft.modules.Cooldowns.groups) then
  self.history[#self.history+1]=before;if #self.history>self.historyLimit then table.remove(self.history,1) end
 end
 release();self:Notice("Changes are staged. Save applies your tracker; Cancel keeps your saved tracker.")
 self:Render()
 if not self:Current(session) or self.model~=model or self.records~=records then return false,"The tracker session changed." end
 return true
end
function E:Undo()
 local session=self.session;local ok,why=self:Current(session)
 if not ok then self:Notice(why);return false end
 if self:RememberGroupFields() or self.pendingGroupEdit then
  self.pendingGroupEdit=nil;self:CloseGroups(false)
  self:Notice("Unapplied group edits cleared.");self:Render();return true
 end
 if self.fieldDraft then self:ClearFieldDraft();self:Notice("Unapplied field edits cleared.");self:Render();return true end
 local prior=self.history[#self.history];if not prior then return false end
 ok,why=self.model:Change(function(p)
  p.modules.Cooldowns.spells=M:Copy(prior.spells);p.modules.Cooldowns.rowCustom=prior.custom
  p.modules.Cooldowns.rowSecondary=prior.secondary==true;p.modules.Cooldowns.groups=M:Copy(prior.groups or {})
  return M.Profiles:CheckTransaction(p)
 end,false)
 if not ok or not self:Current(session) then self:Notice(why);return false end
 self:ClearFieldDraft();table.remove(self.history);self.records=copyRecords(prior.records);self:SetSelection(prior.selection)
 if self.CloseGroups then self:CloseGroups(false) end
 self:Notice("Previous tracker change restored.");self:Render();return true
end
function E:Select(token)
 if not self:Current() or not lookup(self.records,token) then return false end
 if not self:SetSelection(token) then return false end;self:Render();return true
end
function E:SetSelection(token)
 if self.selection~=token then
  if self.fieldDraft and not self:FlushEntryEdits() then return false end
  local session=self.session
  self.auraDraft=nil
  if self.slotBox then self.slotBox:ClearFocus() end
  if self.auraBox then self.auraBox:ClearFocus() end
  if not self:Current(session) then return false end
 end
 self.selection=token
 local _,row=lookup(self.records,token);if row then self.addBar=display(row.entry) end
 return true
end
function E:ClearFieldDraft()
 self.fieldDraft=nil;self.auraDraft=nil
 if self.slotBox then self.slotBox:ClearFocus() end
 if self.auraBox then self.auraBox:ClearFocus() end
end
function E:StageField(kind,text)
 if self.fieldUpdating or not self:Current() or not S:Text(text) then return false end
 local index,row=lookup(self.records,self.selection);if not row then return false end
 if kind~="slot" and (kind~="aura" or not isItem(row.entry)) then return false end
 local draft=self.fieldDraft
 if not draft or draft.token~=row.token then draft={session=self.session,token=row.token} end
 local saved=kind=="slot" and tostring(index) or row.entry.auraID and tostring(row.entry.auraID) or nil
 draft[kind]=text~=saved and text or nil
 self.fieldDraft=(draft.slot~=nil or draft.aura~=nil) and draft or nil
 self:RefreshUndo()
 return true
end
function E:FlushEntryEdits()
 local draft=self.fieldDraft;if not draft then return true end
 if self.fieldFlushActive then return false end
 local session=self.session;local ok,why=self:Current(session)
 if not ok then self:Notice(why);return false end
 local records=self.records;local index,row=lookup(records,draft.token)
 if draft.session~=session or not row or self.selection~=draft.token then self:Notice("Select the original slot to finish its field edits.");return false end
 local destination=index;local entry=M:Copy(row.entry)
 if draft.slot~=nil then
  destination=tonumber(draft.slot)
  if not integer(destination,1,#records) then self:Notice("Choose a slot between 1 and "..#records.." before continuing.");return false end
 end
 if draft.aura~=nil then
  if not isItem(entry) then self:Notice("This slot no longer tracks an item. Undo its field edit before continuing.");return false end
  self.fieldFlushActive=draft
  local queried,resolved=pcall(O.ResolveCooldownSelection,O,tostring(entry.id),"ItemAura",draft.aura)
  if self.fieldFlushActive==draft then self.fieldFlushActive=nil end
  if not self:Current(session) or self.records~=records or self.fieldDraft~=draft or self.selection~=draft.token then return false end
  if not queried or type(resolved)~="table" then self:Notice("Buff information is unavailable. Keep the field edit and try again.");return false end
  if not resolved.ready then self:Notice(resolved.reason);return false end
  entry.mode="ItemAura";entry.auraID=resolved.auraID
  for i,other in ipairs(records) do
   if i~=index and identity(other.entry)==identity(entry) then self:Notice("That item and buff are already tracked. Choose another buff or undo this field edit.");return false end
  end
 end
 -- Validate both fields before staging either. Save and a new selection cannot
 -- silently skip a focused field, and invalid edits remain available to fix.
 self.fieldDraft=nil;self.auraDraft=nil
 if destination~=index or not equal(entry,row.entry) then
  ok,why=self:Mutate(function(nextRecords)
   nextRecords[index].entry=entry
   if destination~=index then local moved=table.remove(nextRecords,index);table.insert(nextRecords,destination,moved) end
  end)
  if not ok then
   if self:Current(session) and not self.fieldDraft then self.fieldDraft=draft end
   self:Notice(why);return false
  end
 end
 if not self:Current(session) then return false end
 self:ClearFieldDraft();self:Render();return true
end
function E:Move(token,destination)
 if self.fieldDraft and not self:FlushEntryEdits() then return false end
 local index=lookup(self.records,token)
 if not index or not integer(destination,1,#self.records) or index==destination then return false end
 local ok=self:Mutate(function(records) local row=table.remove(records,index);table.insert(records,destination,row) end)
 if ok then self:SetSelection(token);self:Render() end
 return ok
end
function E:Remove(token)
 local index=lookup(self.records,token);if not index then return false end
 if self.fieldDraft and self.fieldDraft.token==token then self:ClearFieldDraft()
 elseif self.fieldDraft and not self:FlushEntryEdits() then return false end
 index=lookup(self.records,token);if not index then return false end
 local ok=self:Mutate(function(records) table.remove(records,index) end)
 if ok then local row=self.records[math.min(index,#self.records)];self:SetSelection(row and row.token);self:Render() end
 return ok
end
function E:ChangeEntry(token,mode,highlight,auraID)
 local index,row=lookup(self.records,token);if not row then return false end
 local nextEntry=M:Copy(row.entry)
 if mode then nextEntry.mode=mode;nextEntry.auraID=mode=="ItemAura" and (auraID or nextEntry.auraID) or nil end
 if highlight then nextEntry.highlight=highlight~="None" and highlight or nil end
 if auraID then nextEntry.auraID=auraID end
 if nextEntry.mode=="ItemAura" and not integer(nextEntry.auraID,1,2147483647) then self:Notice("Choose the item's buff spell first.");return false end
 for i,other in ipairs(self.records) do
  if i~=index and identity(other.entry)==identity(nextEntry) then self:Notice("That source and timer are already tracked. Choose a different timer type.");return false end
 end
 return self:Mutate(function(records) records[index].entry=nextEntry end)
end
function E:ChangeType(kind)
 if self.fieldDraft and not self:FlushEntryEdits() then return false end
 local _,row=lookup(self.records,self.selection);if not row then return false end
 local entry,session,records=row.entry,self.session,self.records
 local target=entry.mode=="TargetAura" or entry.mode=="TargetDebuff"
 local mode=kind=="Buff" and (target and "TargetAura" or "Aura") or kind=="Debuff" and (target and "TargetDebuff" or "Debuff") or kind
 local auraID
 if mode=="ItemAura" then
  local result=O:ResolveCooldownSelection(tostring(entry.id),"ItemAura",entry.auraID)
  if not self:Current(session) or self.selection~=row.token or self.records~=records then return false end
  if not result.ready then self:Notice(result.reason);return false end
  auraID=result.auraID
 end
 return self:ChangeEntry(row.token,mode,nil,auraID)
end
function E:ChangeObservation(unit)
 if self.fieldDraft and not self:FlushEntryEdits() then return false end
 local _,row=lookup(self.records,self.selection);if not row then return false end
 local mode=row.entry.mode
 if mode~="Aura" and mode~="TargetAura" and mode~="Debuff" and mode~="TargetDebuff" then return false end
 local harmful=mode=="Debuff" or mode=="TargetDebuff"
 return self:ChangeEntry(row.token,unit=="target" and (harmful and "TargetDebuff" or "TargetAura") or (harmful and "Debuff" or "Aura"))
end
function E:ChangeAura(text)
 local _,row=lookup(self.records,self.selection);if not row or not isItem(row.entry) then return false end
 if not self:StageField("aura",text) then return false end
 return self:FlushEntryEdits()
end
function E:DefaultEntry(candidate)
 if candidate.kind=="Item" then return {id=candidate.id,mode="Item"} end
 local id=candidate.id
 local active=O:ResolveCooldownSelection(tostring(id),"Cooldown")
 if not active.ready then return {id=id,mode="Aura"} end
 local charges=S:Public(C_Spell and C_Spell.GetSpellCharges,"table",id)
 local maximum=S:Field(charges,"maxCharges")
 if integer(maximum,2,100) then return {id=id,mode="Recharge"} end
 local native=candidate.native
 if native and native.hasAura==true then
  if native.selfAura==true then return {id=id,mode="Aura"} end
  local harmful=S:Public(C_Spell and C_Spell.IsSpellHarmful,"boolean",id)
  if harmful==true then return {id=id,mode="TargetDebuff"} end
 end
 return {id=id,mode="Cooldown"}
end
function E:Add(candidate)
 local session=self.session
 if not self:Current(session) or type(candidate)~="table" or not integer(candidate.id,1,2147483647) then return false end
 if candidate.generation~=self.searchGeneration or candidate.query~=self.query then return false end
 local found=false;for _,value in ipairs(self.results or {}) do if value==candidate then found=true;break end end
 if not found then return false end
 if self.fieldDraft and not self:FlushEntryEdits() then return false end
 if #self.records>=self.limit then self:Notice("The tracking list can contain up to 160 slots.");return false end
 local resolved=O:ResolveCooldownSelection(tostring(candidate.id),candidate.kind=="Item" and "Item" or "Aura")
 if not self:Current(session) or candidate.generation~=self.searchGeneration or candidate.query~=self.query then return false end
 if not resolved.ready then self:Notice(resolved.reason);self.searchPending=true;return false end
 local entry=self:DefaultEntry(candidate)
 -- An existing secondary selection may remain in the table while that row is
 -- disabled. New additions must not silently undo the checkbox preference.
 if self.addBar=="Secondary" and self.model.draft.modules.Cooldowns.rowSecondary==true then entry.bar="Secondary" end
 if not self:Current(session) or candidate.generation~=self.searchGeneration then return false end
 local token={}
 for _,row in ipairs(self.records) do if identity(row.entry)==identity(entry) then
  self:SetSelection(row.token);self:Notice("Already tracked. Select another timer type in Tracking List to track this source twice.");self:Render();return false
 end end
 local ok=self:Mutate(function(records,settings)
  if entry.bar=="Secondary" then settings.rowSecondary=true end
  records[#records+1]={token=token,entry=entry}
 end)
 if ok then self:SetSelection(token);self:Notice((resolved.name or "Entry").." added at the right end of the tracker.");self:Render() end
 return ok
end
function E:SetSecondary(enabled)
 if not self:Current() or type(enabled)~="boolean" or not self:FlushEntryEdits() then return false end
 return self:Mutate(function(_,settings) settings.rowSecondary=enabled end)
end
function E:ChangeDisplay(token,bar,destination)
 if not self:Current() or (bar~="Primary" and bar~="Secondary") or not self:FlushEntryEdits() then return false end
 local _,row=lookup(self.records,token);if not row then return false end
 if destination~=nil and not integer(destination,1,#self.records) then return false end
 local ok=self:Mutate(function(records,settings)
  local index,item=lookup(records,token);if not item then return false end
  item.entry.bar=bar=="Secondary" and "Secondary" or nil
  local group=groupByID(settings.groups,item.entry.group)
  if group and group.bar~=bar then item.entry.group=nil end
  if bar=="Secondary" then settings.rowSecondary=true end
  if destination and index~=destination then table.remove(records,index);table.insert(records,destination,item) end
 end)
 if ok then self.addBar=bar;self:SetSelection(token);self:Render() end
 return ok
end
function E:AssignGroup(token,id)
 if not self:Current() or not self:FlushEntryEdits() then return false end
 local _,row=lookup(self.records,token);if not row then return false end
 if id~=nil then
  local group=groupByID(self.model.draft.modules.Cooldowns.groups,id)
  if not group then self:Notice("That group is no longer available.");return false end
  if group.bar and group.bar~=display(row.entry) then self:Notice("This group belongs to the "..group.bar.." display. Manage Groups can move it and unassign its current slots.");return false end
 end
 return self:Mutate(function(records,settings)
  local _,item=lookup(records,token);if not item then return false end
  local group=groupByID(settings.groups,id)
  if id and (not group or group.bar and group.bar~=display(item.entry)) then return false end
  if group then group.bar=display(item.entry) end
  item.entry.group=id
 end)
end
function E:NewGroup()
 if not self:Current() or not self:FlushEntryEdits() then return false end
 if not self:FlushGroupEdits() then return false end
 local groups=self.model.draft.modules.Cooldowns.groups or {}
 if #groups>=64 then self:Notice("The tracker supports up to 64 groups.");return false end
 local serial=self.groupSerial or 0
 for _,group in ipairs(groups) do serial=math.max(serial,group.id) end
 serial=serial+1
 if serial>999999 then self:Notice("No unused group identities remain in this editor session.");return false end
 self.groupSerial=serial
 local ok=self:Mutate(function(_,settings)
  settings.groups[#settings.groups+1]={id=serial,name=string.format("%03d",serial),r=1,g=.6,b=0,alpha=1}
 end)
 if ok then self.groupSelection=serial;self:OpenGroups(serial) end
 return ok,serial
end
function E:UpdateGroup(id,changes)
 if not self:Current() or type(changes)~="table" or not self:FlushEntryEdits() then return false end
 local existing=groupByID(self.model.draft.modules.Cooldowns.groups,id)
 if not existing then self:Notice("That group is no longer available.");return false end
 local group=M:Copy(existing)
 for key,value in pairs(changes) do
  if not ({name=true,r=true,g=true,b=true,alpha=true,bar=true})[key] then return false end
  if key=="bar" and value=="Unassigned" then group.bar=nil else group[key]=value end
 end
 if S:Text(group.name) then group.name=group.name:match("^%s*(.-)%s*$") end
 local candidate=M:Copy(self.model.draft);local _,position=groupByID(candidate.modules.Cooldowns.groups,id)
 candidate.modules.Cooldowns.groups[position]=group
 if group.bar~=existing.bar then for _,entry in ipairs(candidate.modules.Cooldowns.spells) do if entry.group==id then entry.group=nil end end end
 local valid,why=M.Profiles:CheckTransaction(candidate)
 if not valid then self:Notice(why);if self.groupNotice then self.groupNotice:SetText(why) end;return false end
 return self:Mutate(function(records,settings)
  local current,index=groupByID(settings.groups,id);if not current then return false end
  if current.bar~=group.bar then for _,record in ipairs(records) do if record.entry.group==id then record.entry.group=nil end end end
  settings.groups[index]=M:Copy(group)
 end)
end
function E:DeleteGroup(id)
 if not self:Current() or not groupByID(self.model.draft.modules.Cooldowns.groups,id) then return false end
 local ok=self:Mutate(function(records,settings)
  local _,index=groupByID(settings.groups,id);if not index then return false end
  table.remove(settings.groups,index)
  for _,record in ipairs(records) do if record.entry.group==id then record.entry.group=nil end end
 end)
 if ok then self.groupSelection=nil;self.pendingGroupEdit=nil;self:OpenGroups() end
 return ok
end
-- Search is bounded to the learned spellbook, native tracker metadata, selected
-- sources, carried/equipped items and exact public name/ID lookups. No ID-space
-- scan, fabricated catalogue or parsing of private gameplay data is performed.
function E:Search(query)
 local session=self.session;if not self:Current(session) then return false end
 query=searchText(query)
 local previous=self.query==query and self.results and self.results[self.searchSelection or 0]
 local previousOffset=self.query==query and self.searchOffset or 0
 -- An explicit search (including Clear) supersedes deferred typing. Metadata
 -- callbacks during this search may queue a later refresh of this same intent.
 self.pendingQuery=nil;self.searchPending=nil;self.searchDelay=nil
 self.query=query;self.searchGeneration=(self.searchGeneration or 0)+1
 local generation=self.searchGeneration
 self.results={};self.searchSelection=nil;self.searchOffset=previousOffset;self.searchHint=nil;self.searchLoading=nil;self.searchUnavailable=nil
 self.searchDemand={Spell={},Item={}}
 if self.searchBox and searchText(self.searchBox:GetText())~=query then
  self.updating=true;self.searchBox:SetText(query);self.updating=nil
 end
 if query=="" then self:RenderSearch();return true end
 local lower=query:lower();local results,seen,probed={},{},{}
 local numeric=tonumber(query:match("^%d+$") or query:match("spell:(%d+)") or query:match("item:(%d+)"))
 local exactID=integer(numeric,1,2147483647)
 local exactKind=query:find("item:",1,true) and "Item" or query:find("spell:",1,true) and "Spell" or nil
 local catalogue={};local source=provider()
 if source and source.ReadNativeCatalogue then
  local ok,values=pcall(source.ReadNativeCatalogue,source)
  if ok and S:Readable(values) and type(values)=="table" then catalogue=values end
 end
 local function current() return self:Current(session) and self.searchGeneration==generation and self.query==query end
 local function add(id,kind,native,rank,exact)
  if not current() or not integer(id,1,2147483647) or exactID and (id~=numeric or exactKind and kind~=exactKind) then return end
  local key=kind..":"..id
  if seen[key] then if native then seen[key].native=native end;if rank then seen[key].rank=rank end;return end
  -- Duplicate bag stacks and sources that did not match the query used to
  -- repeat static metadata reads for every slot. Probe each source once.
  if probed[key] then return end;probed[key]=true
  self.searchDemand[kind][id]=true
  local meta=O:ResolveCooldownSelection(tostring(id),kind=="Item" and "Item" or "Aura")
  if not current() then return end
  if not meta.ready or not S:Text(meta.name) or not (S:Number(meta.icon) or S:Text(meta.icon)) then
   if kind=="Item" and meta.status=="Item data loading" then
    if self:MetadataFailed(kind,id) then self.searchUnavailable=true else self.searchLoading=true end
   end
   return
  end
  if not exact and not meta.name:lower():find(lower,1,true) and tostring(id)~=query then return end
  if #results>=self.searchLimit then self.searchHint="Refine the search to see more matches.";return end
  local result={id=id,kind=kind,name=meta.name,icon=meta.icon,rank=rank,native=native,generation=generation,query=query}
  seen[key]=result;results[#results+1]=result
 end
 if exactID then
  if not query:find("item:",1,true) then add(numeric,"Spell",nil,nil,true) end
  if not query:find("spell:",1,true) then add(numeric,"Item",nil,nil,true) end
  if current() then
   local spell=S:Public(C_Spell and C_Spell.GetSpellInfo,"table",numeric)
   if exactKind~="Item" and not spell and source and source.RequestSpellMetadata then
    self.searchDemand.Spell[numeric]=true;source:RequestSpellMetadata(numeric)
    if current() then
     if self:MetadataFailed("Spell",numeric) then self.searchUnavailable=true else self.searchLoading=true end
    end
   end
  end
 else
  local direct=O:ResolveCooldownSelection(query,"Aura")
  if current() and direct.ready then add(direct.id,"Spell",nil,nil,true) end
  local itemID=S:Public(C_Item and C_Item.GetItemIDForItemInfo,"number",query)
  if current() and integer(itemID,1,2147483647) then add(itemID,"Item",nil,nil,true) end
 end
 if not current() then return false end
 if not exactID and M.SpellBook and M.SpellBook.Read then
  local read=M.SpellBook:Read(query)
  if current() and type(read)=="table" and type(read.rows)=="table" then
   if read.state=="REFINE_SEARCH" then self.searchHint="Refine the search to see more matches." end
   for _,row in ipairs(read.rows) do add(row.id,"Spell",nil,row.subName) end
  end
 end
 for _,native in pairs(catalogue) do
  local id=S:Field(native,"spellID");if integer(id,1,2147483647) then add(id,"Spell",native) end
 end
 for _,row in ipairs(self.records) do add(row.entry.id,isItem(row.entry) and "Item" or "Spell") end
 if not exactID then
 local scanned=0
 for bag=0,math.min(5,tonumber(NUM_BAG_SLOTS) or 4) do
  local slots=S:Public(C_Container and C_Container.GetContainerNumSlots,"number",bag)
  if integer(slots,0,200) then for slot=1,slots do
   scanned=scanned+1;if scanned>800 or not current() then break end
   local id=S:Public(C_Container and C_Container.GetContainerItemID,"number",bag,slot)
   if integer(id,1,2147483647) then add(id,"Item") end
  end end
 end
 for slot=1,19 do
  if not current() then return false end
  local id=S:Public(GetInventoryItemID,"number","player",slot)
  if integer(id,1,2147483647) then add(id,"Item") end
 end
 end
 if not current() or not self.model:Current() then return false end
 table.sort(results,function(a,b)
  local exactA=a.name:lower()==lower or tostring(a.id)==query;local exactB=b.name:lower()==lower or tostring(b.id)==query
  if exactA~=exactB then return exactA end
  if a.name:lower()~=b.name:lower() then return a.name:lower()<b.name:lower() end
  if a.kind~=b.kind then return a.kind<b.kind end
  return a.id<b.id
 end)
 self.results=results;self.catalogue=catalogue
 if previous then
  for i,row in ipairs(results) do if row.id==previous.id and row.kind==previous.kind then self.searchSelection=i;break end end
 end
 self:RenderSearch();return true
end
function E:QueueSearch(text)
 if not self.session or self.suspended then return end
 text=searchText(text)
 if text=="" then return self:Search("") end
 self.pendingQuery=text;self.searchPending=true;self.searchDelay=.12
 self.searchGeneration=(self.searchGeneration or 0)+1
 self:RenderSearch()
end
function E:RefreshSearch()
 if not self.session or self.suspended then return end
 -- Content events must never replace newer text or continuously restart its
 -- debounce. A burst coalesces into one refresh of the latest query.
 if self.searchPending then return end
 if self.query and self.query~="" then
  self.searchPending=true;self.searchDelay=.12
  self.searchGeneration=(self.searchGeneration or 0)+1
 end
end
function E:MetadataRelevant(kind,id)
 if not integer(id,1,2147483647) then return false end
 local demand=self.searchDemand and self.searchDemand[kind]
 if demand and demand[id] then return true end
 for _,row in ipairs(self.records or {}) do
  local entry=row.entry
  if kind=="Item" and isItem(entry) and entry.id==id
   or kind=="Spell" and (not isItem(entry) and entry.id==id or entry.mode=="ItemAura" and entry.auraID==id) then return true end
 end
 return false
end
function E:MetadataFailed(kind,id)
 local outcomes=self.metadataOutcomes and self.metadataOutcomes[kind]
 if outcomes and outcomes[id]==false then return true end
 local source=provider()
 local profile=source and source[kind=="Item" and "itemLoadProfile" or "spellLoadProfile"]
 local loads=source and source[kind=="Item" and "itemLoads" or "spellLoads"]
 local state=profile==M.profile and loads and loads[id]
 return state=="FAILED" or state=="UNSUPPORTED" or state=="REQUEST_REJECTED"
end
function E:Save()
 local session,model=self.session,self.model;local ok,why=self:Current(session)
 if not ok then self:Notice(why);return false end
 local function current() return self.model==model and self:Current(session) and self.model==model end
 if self.busy then return false end
 if not self:FlushGroupEdits() or not current() then return false end
 if not self:FlushEntryEdits() or not current() then return false end
 -- Even an intentionally empty list is an authored custom list, and cannot
 -- silently restore the native automatic assignments on the next login.
 if not model.draft.modules.Cooldowns.rowCustom then
  if not self:Mutate(function() end) or not current() then return false end
 end
 local outer=M.WorkspaceModel
 local retained=outer.draft and outer:Current() and {session=outer.session,draft=outer.draft,history=outer.history} or nil
 if not current() then return false end
 local saved,reason=model:Apply()
 if self.session~=session or self.model~=model then return false end
 if not saved then self:Notice(reason);return false end
 -- Preserve a main-settings draft while rebasing its ownership and history.
 -- Only tracker assignments are replaced; pending size/visibility/profile
 -- preferences are neither applied by this editor nor silently discarded.
 if retained and outer.session==retained.session and outer.draft==retained.draft then
  local fresh=setmetatable({draft=false,baseSnapshot=false,session=false,editOperation=false},{__index=outer});fresh:Begin()
  local function rebase(p)
   local value=M:Copy(p)
   copyTracker(value.modules.Cooldowns,M.profile.modules.Cooldowns)
   return value
  end
  local draft=rebase(retained.draft);local history={}
  for _,old in ipairs(retained.history or {}) do history[#history+1]=rebase(old) end
  for _,key in ipairs({"base","baseSnapshot","profileOwner","account","character","scope","savedOwner","savedProfile","savedSnapshot"}) do outer[key]=fresh[key] end
  outer.draft=draft;outer.history=history;outer:Changed()
 end
 self:Close(false);return true
end
function E:Close(keepDraft,reason)
 if not self.session then return true end
 self.suspended=keepDraft==true;M.state.trackerWorkspace=false
 if keepDraft and self.pendingQuery then self.query=self.pendingQuery;self.results={};self.searchSelection=nil end
 self.pendingQuery=nil;self.searchPending=nil;self.drag=nil;self.suppressClick=nil;self.busy=nil;self.fieldFlushActive=nil
 if self.searchBox then self.searchBox:ClearFocus() end
 if self.slotBox then self.slotBox:ClearFocus() end
 if self.auraBox then self.auraBox:ClearFocus() end
 if self.menu then self.menu:Hide() end
 if self.CloseGroups then self:CloseGroups(keepDraft==true) end
 if self.root then self.closing=true;self.root:EnableKeyboard(false);self.root:Hide();self.closing=nil end
 local interface=M.ActionInterface
 if interface and interface.SetTrackerWorkspace then
  if not S:InCombat() then
   local ok=interface:SetTrackerWorkspace(false);self.restorePending=not ok
  else self.restorePending=true end
 end
 if M.KeybindWorkspace and M.KeybindWorkspace.CursorCapture then M.KeybindWorkspace:CursorCapture(false) end
 if not keepDraft then self.fieldDraft=nil;self.auraDraft=nil;self.session=nil;self.model=nil;self.records=nil;self.history=nil;self.selection=nil;self.suspended=nil end
 if reason then self:Notice(reason) end
 self:RefreshContext();return true
end
local function enter(self)
 if S:InCombat() then return false,"Configure Tracker is available after combat." end
 if M.state.keybindWorkspace then return false,"Finish configuring keybinds before opening the tracker." end
 local allowed,why=M.Elements:EditingAllowed();if not allowed then return false,why end
 if self.session and not self.suspended then self.root:Show();return true end
 if self.session then
  local current,changed=self.model:Current()
  if not current then self:Close(false);return false,changed end
  self.suspended=nil
 else
  local model=setmetatable({},{__index=M.WorkspaceModel})
  -- Instance-owned fields prevent an already open main settings draft from
  -- being inherited through the method prototype.
  model.draft=false;model.baseSnapshot=false;model.session=false;model.editOperation=false
  local ok,message=model:Begin();if not ok then return false,message end
  self.session={};self.model=model;self.records={};self.history={};self.selection=nil;self.fieldDraft=nil;self.auraDraft=nil
  local cfg=model.draft.modules.Cooldowns
  local outer=M.WorkspaceModel
  if outer.draft and outer:Current() then
   copyTracker(cfg,outer.draft.modules.Cooldowns)
  end
  local entries=cfg.spells
  if #entries==0 and cfg.rowCustom~=true then entries=O:NativeCooldownAssignments() or {} end
  for _,entry in ipairs(entries) do self.records[#self.records+1]={token={},entry=M:Copy(entry)} end
  self.selection=self.records[1] and self.records[1].token
  self.addBar="Primary";self.secondaryPreviewOffset=0;self.groupSerial=0
  for _,g in ipairs(cfg.groups or {}) do self.groupSerial=math.max(self.groupSerial,g.id) end
  self.query="";self.results={};self.searchDemand=nil;self.metadataOutcomes={Spell={},Item={}};self.searchLoading=nil;self.searchUnavailable=nil;self.searchHint=nil;self.searchGeneration=0;self.searchOffset=0;self.listOffset=0;self.previewOffset=0
 end
 local session=self.session
 local built,errorText=pcall(self.Create,self)
 if not built then
  self:Close(false);if self.root then self.root:UnregisterAllEvents() end
  self.root=nil;self.menu=nil
  return false,"The tracker interface could not open: "..tostring(errorText)
 end
 local current,stale=self:Current(session);if not current then return false,stale end
 self.updating=true;self.searchBox:SetText(self.query or "");self.updating=nil
 local interface=M.ActionInterface
 if interface and interface.active and interface.SetTrackerWorkspace then
  local ok,message=interface:SetTrackerWorkspace(true)
  if not ok then self:Close(true,message);return false,message end
 end
 local function admitted()
  local ok,why=self:Current(session)
  if not ok and self.session==session then self:Close(true,why) end
  return ok,why
 end
 local ok,why=admitted();if not ok then return false,why end
 M.state.trackerWorkspace=true
 if M.KeybindWorkspace and M.KeybindWorkspace.CloseSettings then M.KeybindWorkspace:CloseSettings() end
 ok,why=admitted();if not ok then return false,why end
 if type(CloseAllWindows)=="function" then pcall(CloseAllWindows) end
 ok,why=admitted();if not ok then return false,why end
 if M.KeybindWorkspace and M.KeybindWorkspace.CursorCapture then M.KeybindWorkspace:CursorCapture(true) end
 ok,why=admitted();if not ok then return false,why end
 self.root:EnableKeyboard(true);self.root:SetPropagateKeyboardInput(true);self.root:Show()
 if not self:Layout() then self:Close(true);return false,"The screen layout is unavailable. Reopen the tracker once the display is ready." end
 ok,why=admitted();if not ok then return false,why end
 self:Render();self:Notice("Search and add to either display. Drag icons to reorder or move between displays.")
 self:RefreshSearch()
 ok,why=admitted();if not ok then return false,why end
 self:RefreshContext();return admitted()
end
function E:Enter()
 if self.entering then return false,"The tracker is already opening." end
 local operation={};self.entering=operation
 local ok,accepted,why=pcall(enter,self)
 if self.entering==operation then self.entering=nil end
 if not ok then
  self.lastError=tostring(accepted)
  if self.session then self:Close(true) end
  return false,"The tracker could not open. Your saved tracker was retained."
 end
 return accepted,why
end
local function box(parent)
 local frame=CreateFrame("Frame",nil,parent,"BackdropTemplate");U:Backdrop(frame,true);return frame
end
local function label(parent,text,x,y,size,width,role)
 local font=U:Text(parent,text,x,y,size,width);if role and U.SetTextRole then U:SetTextRole(font,role) end;return font
end
local function place(frame,x,y,width,height)
 frame:ClearAllPoints();frame:SetPoint("TOPLEFT",x,y);frame:SetSize(width,height)
 if frame.label then frame.label:SetWidth(math.max(1,width-16)) end
end
-- Rows use one readable line. On a narrow screen the ID moves into the
-- selected-slot summary, leaving room for the name and every tracking choice.
function E:TrackingColumns(width)
 local compact=width<700
 local columns={};local x=8;local gap=8
 local function add(key,title,size)
  columns[#columns+1]={key=key,title=title,x=x,width=size};x=x+size+gap
 end
 local slot=compact and 26 or 30;local id=compact and 0 or 62
 local timer=compact and 78 or 94;local unit=compact and 48 or 58;local effect=compact and 58 or 64;local grouping=compact and 90 or 108
 local name=width-16-slot-id-timer-unit-effect-grouping-gap*(compact and 5 or 6)
 add("slot","Slot",slot);add("name","Spell / item",name)
 if not compact then add("id","ID",id) end
 add("timer","Tracking",timer);add("unit","Observe",unit);add("effect","Effect",effect);add("group","Grouping",grouping)
 return columns,compact
end
local function tableCell(cell,parent,column,y,size)
 cell:ClearAllPoints();cell:SetPoint("LEFT",parent,"LEFT",column.x,y or 0)
 cell:SetSize(math.max(1,column.width),size or 18);cell:SetJustifyV("MIDDLE");cell:SetWordWrap(false)
end
function E:PaintPreviewAppearance(tile)
 local source=provider();local highlighted=false
 if source and source.PaintAppearance then highlighted=source:PaintAppearance(tile)
 else
  local active=not auraModes[tile.meta.mode] or tile.auraActive==true
  highlighted=tile.displayReady and active and (tile.meta.highlight=="Accent" or tile.meta.highlight=="Glow")
  tile.glow:SetShown(highlighted and tile.meta.highlight=="Glow" or false)
 end
 local selected=tile.token==self.selection
 selectedButton(tile.frame,selected)
 if highlighted and not selected then
  local color=(M.Theme and M.Theme.secondary) or {.96,.79,.36,1}
  tile.frame:SetBackdropBorderColor(unpack(color))
 end
end
function E:ShowMenu(anchor,choices,callback)
 if not self:Current() then return end
 if self.menu and self.menu:IsShown() and self.menu.owner and self.menu.owner.anchor==anchor then self.menu:Hide();return end
 if not self.menu then
  self.menu=box(self.root);self.menu:SetFrameStrata("FULLSCREEN_DIALOG");self.menu.buttons={}
  self.menu:SetScript("OnHide",function(menu) menu.owner=nil end)
  if self.menu.SetClampedToScreen then self.menu:SetClampedToScreen(true) end
 end
 local menu=self.menu;menu:ClearAllPoints();menu:SetPoint("TOPLEFT",anchor,"BOTTOMLEFT",0,-3)
 local owner={session=self.session,selection=self.selection,anchor=anchor};menu.owner=owner;menu.offset=0
 menu:SetFrameLevel(self.root:GetFrameLevel()+100);menu:EnableMouseWheel(true);menu:EnableMouse(true)
 local function render()
  if menu.owner~=owner or not self:Current(owner.session) then return end
  local visible=math.min(9,#choices);local paged=#choices>visible
  menu.offset=math.max(0,math.min(menu.offset,math.max(0,#choices-visible)))
  menu:SetSize(math.max(220,anchor:GetWidth()),visible*30+8+(paged and 32 or 0))
  for i=1,visible do
   local choice=choices[menu.offset+i];local b=menu.buttons[i]
   if not b then b=U:Button(menu,"",4,0,212);menu.buttons[i]=b end
   place(b,4,-4-(i-1)*30,menu:GetWidth()-8,28);b:SetText(choice.label)
   b:SetScript("OnClick",function()
    if menu.owner~=owner then return end
    local eligible=menu.owner==owner and self:Current(owner.session) and self.selection==owner.selection
    if menu.owner~=owner then return end
    menu:Hide()
    if eligible and self:Current(owner.session) and self.selection==owner.selection then callback(choice.value) end
   end);b:Show()
  end
  for i=visible+1,#menu.buttons do menu.buttons[i]:Hide() end
  if not menu.previous then
   menu.previous=U:Button(menu,"Previous",0,0,90);menu.next=U:Button(menu,"Next",0,0,90)
  end
  menu.previous:SetShown(paged);menu.next:SetShown(paged)
  if paged then
   place(menu.previous,4,-4-visible*30,(menu:GetWidth()-12)/2,28)
   place(menu.next,8+(menu:GetWidth()-12)/2,-4-visible*30,(menu:GetWidth()-12)/2,28)
   menu.previous:SetEnabled(menu.offset>0);menu.next:SetEnabled(menu.offset+visible<#choices)
   menu.previous:SetScript("OnClick",function() menu.offset=menu.offset-visible;render() end)
   menu.next:SetScript("OnClick",function() menu.offset=menu.offset+visible;render() end)
  end
 end
 menu:SetScript("OnMouseWheel",function(_,delta) menu.offset=menu.offset-delta*3;render() end)
 render();menu:Show()
end
function E:MenuOutsideClick()
 local menu=self.menu;local owner=menu and menu.owner
 if not owner or not menu:IsShown() then return end
 if not self:Current(owner.session) then if menu.owner==owner then menu:Hide() end;return end
 local function over(frame)
  return frame and (S:Public(MouseIsOver,"boolean",frame)==true or S:Public(frame.IsMouseOver,"boolean",frame)==true)
 end
 if not over(menu) and not over(owner.anchor) and menu.owner==owner then menu:Hide() end
end
function E:RememberGroupFields()
 if not self.groupShade or not self.groupShade:IsShown() or not self.groupSelection or not self.groupOriginal then return false end
 local original=self.groupOriginal
 if original.id~=self.groupSelection or original.session~=self.session then return false end
 local draft={id=self.groupSelection,name=self.groupName:GetText(),color=self.groupColor:GetText(),opacity=self.groupOpacity:GetText(),bar=self.groupBarDraft,changed={}}
 for _,key in ipairs({"name","color","opacity","bar"}) do if draft[key]~=original[key] then draft.changed[key]=true end end
 self.pendingGroupEdit=next(draft.changed) and draft or nil
 return self.pendingGroupEdit~=nil
end
function E:CloseGroups(keepPending)
 if keepPending~=false then self:RememberGroupFields() else self.pendingGroupEdit=nil end
 if self.groupName then self.groupName:ClearFocus();self.groupColor:ClearFocus();self.groupOpacity:ClearFocus() end
 if self.groupShade then self.groupShade:Hide() end
 if self.menu then self.menu:Hide() end
 self.groupSession=nil
 self:RefreshUndo()
end
function E:FlushGroupEdits()
 local session,model=self.session,self.model
 if not self:Current(session) then return false end
 self:RememberGroupFields()
 local pending=self.pendingGroupEdit
 if not pending then return true end
 if not groupByID(self.model.draft.modules.Cooldowns.groups,pending.id) then
  self.pendingGroupEdit=nil;return true
 end
 if not self.groupShade or not self.groupShade:IsShown() or self.groupSelection~=pending.id then
  if not self:OpenGroups(pending.id) then return false end
 end
 if not self:Current(session) or self.model~=model then return false end
 return self:ApplyGroupFields()
end
function E:GroupFieldsChanged()
 if not self:Current() or not self.groupShade or not self.groupShade:IsShown() then return end
 local group=groupByID(self.model.draft.modules.Cooldowns.groups,self.groupSelection)
 if not group then return end
 self:RememberGroupFields();self:RefreshUndo()
 local color=self.groupColor:GetText():match("^#?(%x%x%x%x%x%x)$")
 local opacity=tonumber(self.groupOpacity:GetText())
 local valid=color and S:Number(opacity) and opacity>=0 and opacity<=100
 if valid then self.groupSwatch:SetColorTexture(tonumber(color:sub(1,2),16)/255,tonumber(color:sub(3,4),16)/255,tonumber(color:sub(5,6),16)/255,opacity/100) end
 local count=0;for _,row in ipairs(self.records) do if row.entry.group==group.id then count=count+1 end end
 local bar=self.groupBarDraft~="Unassigned" and self.groupBarDraft or nil
 self.groupBarButton:SetText(bar and bar.." Display" or "Automatic on first assignment")
 self.groupApply:SetText(bar~=group.bar and count>0 and ("Move & unassign "..count) or "Apply group")
 self.groupNotice:SetText(not valid and "Use a six-digit hex color and an opacity from 0 to 100."
  or bar~=group.bar and count>0 and ("Changing this display will unassign all "..count.." slots in this group. Their spells and positions remain unchanged.")
  or group.bar and (count.." assigned slots · Locked to "..group.bar..". Changing display unassigns its slots.")
  or "This group locks to the display of its first assigned spell or item.")
end
function E:ApplyGroupFields()
 if not self:Current(self.groupSession) or not self.groupShade or not self.groupShade:IsShown() then return false end
 local session,model=self.session,self.model
 local id=self.groupSelection;local group=groupByID(self.model.draft.modules.Cooldowns.groups,id);if not group then return false end
 local color=self.groupColor:GetText():match("^#?(%x%x%x%x%x%x)$");local opacity=tonumber(self.groupOpacity:GetText())
 if not color or not S:Number(opacity) or opacity<0 or opacity>100 then self:GroupFieldsChanged();return false end
 if not self:RememberGroupFields() then return true end
 local sameColor=self.groupColor:GetText()==self.groupDisplayColor
 local sameOpacity=self.groupOpacity:GetText()==self.groupDisplayOpacity
 local ok=self:UpdateGroup(id,{name=self.groupName:GetText(),r=sameColor and group.r or tonumber(color:sub(1,2),16)/255,
  g=sameColor and group.g or tonumber(color:sub(3,4),16)/255,b=sameColor and group.b or tonumber(color:sub(5,6),16)/255,
  alpha=sameOpacity and group.alpha or opacity/100,bar=self.groupBarDraft})
 if not self:Current(session) or self.model~=model then return false end
 if ok then
  self.pendingGroupEdit=nil
  if not self:OpenGroups(id) or not self:Current(session) or self.model~=model or self.groupSelection~=id then return false end
  self.groupNotice:SetText("Group changes are staged. Save & Close applies the tracker.")
 end
 return ok
end
function E:OpenGroups(id)
 if not self:Current() or not self:FlushEntryEdits() then return false end
 if id and self.groupSelection and id~=self.groupSelection and self.groupShade and self.groupShade:IsShown() then
  if not self:FlushGroupEdits() then return false end
 end
 local session=self.session
 for _,edit in ipairs({self.searchBox,self.slotBox,self.auraBox}) do if edit then edit:ClearFocus() end end
 if not self:Current(session) then return false end
 if self.menu then self.menu:Hide() end
 if not self.groupShade then
  local shade=CreateFrame("Button",nil,self.root);shade:SetAllPoints(self.root);shade:SetFrameLevel(self.root:GetFrameLevel()+60);shade:EnableMouse(true)
  shade.fill=shade:CreateTexture(nil,"BACKGROUND");shade.fill:SetAllPoints(shade);shade.fill:SetColorTexture(0,0,0,.68)
  shade:SetScript("OnClick",function() self:CloseGroups() end);self.groupShade=shade
  local panel=box(shade);self.groupWindow=panel;panel:SetPoint("CENTER",shade,"CENTER",0,0);panel:SetSize(580,424);panel:SetFrameLevel(shade:GetFrameLevel()+2);panel:EnableMouse(true)
  label(panel,"Manage Groups",20,-18,20,440,"heading")
  local close=U:Button(panel,"×",530,-14,30,function() self:CloseGroups() end);close:SetSize(30,30)
  self.groupPicker=U:Button(panel,"Choose a group",20,-58,390,function(button)
   local choices={};for _,g in ipairs(self.model.draft.modules.Cooldowns.groups or {}) do choices[#choices+1]={value=g.id,label=g.name.." · "..(g.bar or "Unassigned")} end
   if #choices>0 then self:ShowMenu(button,choices,function(value) self:OpenGroups(value) end) end
  end)
  self.groupNew=U:Button(panel,"New Group",422,-58,138,function() self:NewGroup() end)
  label(panel,"Name",20,-111,12,112,"text")
  self.groupName=U:Edit(panel,140,-102,420,"",function() self:ApplyGroupFields() end);self.groupName:SetMaxLetters(40)
  label(panel,"Color",20,-155,12,112,"text")
  self.groupColor=U:Edit(panel,140,-146,140,"",function() self:ApplyGroupFields() end);self.groupColor:SetMaxLetters(7)
  self.groupSwatch=panel:CreateTexture(nil,"ARTWORK");self.groupSwatch:SetPoint("TOPLEFT",294,-146);self.groupSwatch:SetSize(48,28)
  local palette={{1,.6,0},{1,.84,.2},{.25,.75,1},{.55,.35,1},{.25,.85,.55},{1,.35,.4}}
  for i,rgb in ipairs(palette) do
   local button=U:Button(panel,"",352+(i-1)*35,-146,30,function()
    self.groupColor:SetText(string.format("#%02X%02X%02X",math.floor(rgb[1]*255+.5),math.floor(rgb[2]*255+.5),math.floor(rgb[3]*255+.5)));self:GroupFieldsChanged()
   end)
   button:SetSize(30,28);button.swatch=button:CreateTexture(nil,"ARTWORK");button.swatch:SetPoint("TOPLEFT",5,-5);button.swatch:SetPoint("BOTTOMRIGHT",-5,5);button.swatch:SetColorTexture(rgb[1],rgb[2],rgb[3],1)
  end
  label(panel,"Opacity",20,-199,12,112,"text")
  self.groupOpacity=U:Edit(panel,140,-190,86,"",function() self:ApplyGroupFields() end);self.groupOpacity:SetMaxLetters(6)
  label(panel,"%   0 = invisible · 100 = opaque",240,-199,11,320,"muted")
  label(panel,"Display",20,-243,12,112,"text")
  self.groupBarButton=U:Button(panel,"Automatic on first assignment",140,-234,420,function(button)
   self:ShowMenu(button,{{value="Unassigned",label="Automatic on first assignment"},{value="Primary",label="Primary Display"},{value="Secondary",label="Secondary Display"}},function(value) self.groupBarDraft=value;self:GroupFieldsChanged() end)
  end)
  self.groupNotice=label(panel,"",20,-282,12,540,"muted")
  self.groupDelete=U:Button(panel,"Delete group",20,-374,126,function() if self:Current(self.groupSession) then self:DeleteGroup(self.groupSelection) end end)
  self.groupApply=U:Button(panel,"Apply group",262,-374,180,function() self:ApplyGroupFields() end)
  self.groupDone=U:Button(panel,"Done",450,-374,110,function()
   if self:FlushGroupEdits() then self:CloseGroups(false) end
  end)
  for _,edit in ipairs({self.groupName,self.groupColor,self.groupOpacity}) do edit:SetScript("OnTextChanged",function() if not self.groupUpdating then self:GroupFieldsChanged() end end) end
 end
 local groups=self.model.draft.modules.Cooldowns.groups or {}
 local group=groupByID(groups,id or self.groupSelection) or groups[1]
 self.groupSelection=group and group.id;self.groupSession=self.session;self.groupShade:Show()
 self.groupPicker:SetText(group and (group.name.." · "..(group.bar or "Unassigned")) or "No groups yet")
 self.groupNew:SetEnabled(#groups<64)
 for _,control in ipairs({self.groupName,self.groupColor,self.groupOpacity,self.groupBarButton,self.groupApply,self.groupDelete}) do
  if control.SetEnabled then control:SetEnabled(group~=nil) end
 end
 self.groupUpdating=true
 local pending=group and self.pendingGroupEdit and self.pendingGroupEdit.id==group.id and self.pendingGroupEdit
 self.groupDisplayColor=group and string.format("#%02X%02X%02X",math.floor(group.r*255+.5),math.floor(group.g*255+.5),math.floor(group.b*255+.5)) or "#FF9900"
 self.groupDisplayOpacity=group and string.format("%.2f",group.alpha*100):gsub("%.?0+$","") or "100"
 self.groupOriginal={session=self.session,id=group and group.id,name=group and group.name or "",color=self.groupDisplayColor,opacity=self.groupDisplayOpacity,bar=group and group.bar or "Unassigned"}
 local function value(key)
  return pending and pending.changed and pending.changed[key] and pending[key] or self.groupOriginal[key]
 end
 self.groupName:SetText(value("name"));self.groupColor:SetText(value("color"));self.groupOpacity:SetText(value("opacity"));self.groupBarDraft=value("bar")
 self.groupUpdating=nil
 if group then self:GroupFieldsChanged() else self.groupNotice:SetText("Create a group, then assign spells or items with the Grouping control in Tracking List.") end
 return true
end
function E:Metadata(entry)
 local pass=self.metadataPass
 local current=pass and pass.session==self.session and pass.records==self.records
 if current and pass.values[entry] then return pass.values[entry] end
 local function resolved(meta)
  if current and self.metadataPass==pass and self.session==pass.session and self.records==pass.records then pass.values[entry]=meta end
  return meta
 end
 local source=provider()
 if source and source.Metadata then
  local ok,meta=pcall(source.Metadata,source,entry,self.catalogue or {})
  if ok and type(meta)=="table" and S:Readable(meta) then return resolved(meta) end
 end
 local info=O:ResolveCooldownSelection(tostring(entry.id),entry.mode,entry.auraID)
 return resolved({id=entry.id,spellID=entry.auraID or entry.id,itemID=isItem(entry) and entry.id or nil,mode=entry.mode,
  name=info.name or ((isItem(entry) and "Item " or "Spell ")..entry.id),icon=info.icon,ready=info.ready,
  auraName=info.auraName,status=info.status,highlight=entry.highlight})
end
function E:Create()
 if self.root then return end
 self.groupShade=nil;self.groupWindow=nil;self.groupSession=nil
 local root=CreateFrame("Frame","MirageUICooldownEditor",UIParent,"BackdropTemplate")
 self.root=root;root:Hide();root:SetFrameStrata("DIALOG");root:SetFrameLevel(180)
 U:Backdrop(root,true);root:EnableMouse(true)
 self.mark=root:CreateTexture(nil,"ARTWORK");self.mark:SetTexture("Interface\\AddOns\\MirageUI\\Media\\Mark.tga");self.mark:SetSize(32,32);self.mark:SetPoint("TOPLEFT",16,-14)
 self.heading=label(root,"Cooldown Manager",60,-21,20,300,"heading")
 self.headerRule=root:CreateTexture(nil,"BORDER");self.headerRule:SetColorTexture(unpack((M.Theme and M.Theme.edge) or {.26,.26,.26,1}));self.headerRule:SetSize(1,1)
 self.headerRule:SetPoint("TOPLEFT",16,-58);self.headerRule:SetPoint("TOPRIGHT",-16,-58)
 self.primaryHeading=label(root,"Tracking Display",18,-72,14,170,"heading")
 self.tray=box(root);self.preview=CreateFrame("Frame",nil,self.tray);self.preview:SetClipsChildren(true)
 self.preview:EnableMouseWheel(true);self.preview:SetScript("OnMouseWheel",function(_,delta)
  if not self:Current() then return end
  local rows=self:BarRecords("Primary")
  self.previewOffset=math.max(0,math.min(math.max(0,#rows-self.previewVisible),self.previewOffset-delta*3));self:RenderPreview()
 end)
 self.barHint=label(self.tray,"",12,-76,10,600,"muted");self.barHint:Hide()
 self.barPrevious=U:Button(self.tray,"<",0,0,28,function() self.previewOffset=math.max(0,self.previewOffset-self.previewVisible);self:RenderPreview() end)
 self.barNext=U:Button(self.tray,">",0,0,28,function() local rows=self:BarRecords("Primary");self.previewOffset=math.min(math.max(0,#rows-self.previewVisible),self.previewOffset+self.previewVisible);self:RenderPreview() end)
 self.emptyBar=label(self.preview,"Your tracker starts here. Search below to add the first slot.",8,-20,13,700,"muted")
 self.dropMarker=self.preview:CreateTexture(nil,"OVERLAY");self.dropMarker:SetColorTexture(unpack((M.Theme and M.Theme.secondary) or {.96,.79,.36,1}));self.dropMarker:SetSize(2,54);self.dropMarker:Hide()
 self.secondaryToggle=CreateFrame("CheckButton",nil,root,"BackdropTemplate");U:Backdrop(self.secondaryToggle,true);self.secondaryToggle:SetSize(22,22)
 self.secondaryToggle.mark=self.secondaryToggle:CreateTexture(nil,"ARTWORK");self.secondaryToggle.mark:SetTexture("Interface\\Buttons\\UI-CheckBox-Check");self.secondaryToggle.mark:SetAllPoints(self.secondaryToggle)
 self.secondaryToggle.caption=label(self.secondaryToggle,"Enable secondary bar",32,-4,12,205,"text")
 self.secondaryToggle:SetScript("OnClick",function()
  if not self:Current() then return end
  self:SetSecondary(not self.model.draft.modules.Cooldowns.rowSecondary)
  if not self:Current() then return end
  local enabled=self.model.draft.modules.Cooldowns.rowSecondary==true
  if self.secondaryToggle.SetChecked then self.secondaryToggle:SetChecked(enabled) end
  self.secondaryToggle.mark:SetShown(enabled)
 end)
 -- One tray mirrors the live primary/secondary stack. The secondary host is
 -- transparent and exists only to page its row independently.
 self.secondaryTray=CreateFrame("Frame",nil,self.tray);self.secondaryPreview=CreateFrame("Frame",nil,self.secondaryTray);self.secondaryPreview:SetClipsChildren(true)
 self.secondaryPreview:EnableMouseWheel(true);self.secondaryPreview:SetScript("OnMouseWheel",function(_,delta)
  if not self:Current() then return end
  local rows=self:BarRecords("Secondary");self.secondaryPreviewOffset=math.max(0,math.min(math.max(0,#rows-self.secondaryPreviewVisible),self.secondaryPreviewOffset-delta*3));self:RenderPreview()
 end)
 self.secondaryPrevious=U:Button(self.secondaryTray,"<",0,0,28,function() self.secondaryPreviewOffset=math.max(0,self.secondaryPreviewOffset-self.secondaryPreviewVisible);self:RenderPreview() end)
 self.secondaryNext=U:Button(self.secondaryTray,">",0,0,28,function()
  local rows=self:BarRecords("Secondary");self.secondaryPreviewOffset=math.min(math.max(0,#rows-self.secondaryPreviewVisible),self.secondaryPreviewOffset+self.secondaryPreviewVisible);self:RenderPreview()
 end)
 self.secondaryEmpty=box(self.secondaryPreview);self.secondaryEmpty:SetSize(48.6,48.6);self.secondaryEmpty:SetPoint("TOP",self.secondaryPreview,"TOP",0,-8)
 self.secondaryEmpty.plus=label(self.secondaryEmpty,"+",0,-13,18,48.6,"muted");self.secondaryEmpty.plus:SetJustifyH("CENTER")
 self.secondaryEmpty:EnableMouse(true);self.secondaryEmpty:SetScript("OnMouseDown",function() if self:Current() then self.addBar="Secondary";self:RenderSearch();self.searchBox:SetFocus() end end)
 self.secondaryDropMarker=self.secondaryPreview:CreateTexture(nil,"OVERLAY");self.secondaryDropMarker:SetColorTexture(unpack((M.Theme and M.Theme.secondary) or {.96,.79,.36,1}));self.secondaryDropMarker:SetSize(2,50);self.secondaryDropMarker:Hide()
 self.body=CreateFrame("Frame",nil,root);self.searchPanel=box(self.body);self.trackingPanel=box(self.body)
 self.searchHeading=label(self.searchPanel,"Find a spell or item",12,-12,15,300,"heading")
 self.searchBox=U:Edit(self.searchPanel,12,-40,300,"",function() local item=self.results and self.results[self.searchSelection or 1];if item then self:Add(item) end end)
 self.searchBox:SetMaxLetters(120);self.searchBox:SetScript("OnTextChanged",function(edit,userInput) if not self.updating then self:QueueSearch(edit:GetText()) end end)
 self.searchBox:SetScript("OnKeyDown",function(_,key)
  if self.pendingQuery~=nil and self.pendingQuery~=self.query then return end
  if key=="DOWN" or key=="UP" then
   local count=#(self.results or {});if count>0 then
    self.searchSelection=math.max(1,math.min(count,(self.searchSelection or (key=="DOWN" and 0 or 2))+(key=="DOWN" and 1 or -1)))
    self.searchOffset=math.max(0,math.min(self.searchOffset,self.searchSelection-1))
    if self.searchSelection>self.searchOffset+self.searchVisible then self.searchOffset=self.searchSelection-self.searchVisible end
    self:RenderSearch()
   end
  end
 end)
 self.searchBox:SetScript("OnEscapePressed",function(edit) edit:ClearFocus() end)
 self.clearSearch=U:Button(self.searchPanel,"Clear",0,-40,58,function()
  self.updating=true;self.searchBox:SetText("");self.updating=nil;self:Search("");self.searchBox:SetFocus()
 end)
 self.searchSummary=label(self.searchPanel,"",12,-78,11,300,"muted")
 self.searchEmpty=label(self.searchPanel,"Type a name or ID to search.\n\nResults include your spellbook, tracked effects and carried or equipped items. An exact ID can find a buff or item outside those lists.",12,-126,13,300,"muted")
 self.searchRows={};self.trackRows={};self.barTiles={}
 for i=1,14 do
  local row=U:Button(self.searchPanel,"",12,-106,300);row:SetHeight(42)
  row.icon=row:CreateTexture(nil,"ARTWORK");row.icon:SetSize(30,30);row.icon:SetPoint("LEFT",row,"LEFT",7,0)
  row.label:ClearAllPoints();row.label:SetPoint("TOPLEFT",row,"TOPLEFT",45,-6);row.label:SetJustifyH("LEFT");row.label:SetWordWrap(false)
  row.detail=label(row,"",45,-24,10,190,"muted");row.detail:SetWordWrap(false)
  row.select=U:Button(row,"Select",0,-7,62,function()
   local candidate=row.candidate;if candidate then self:Add(candidate) end
  end);row.select:Hide()
  row:SetScript("OnClick",function()
   if self:Current() and row.generation==self.searchGeneration and row.candidate then self.searchSelection=row.resultIndex;self:RenderSearch() end
  end)
  self.searchRows[i]=row
  local track=U:Button(self.trackingPanel,"",12,-44,400);track:SetHeight(42)
  track.icon=track:CreateTexture(nil,"ARTWORK");track.icon:SetSize(24,24);track.icon:SetTexCoord(.08,.92,.08,.92)
  track.label:SetJustifyH("LEFT");track.label:SetWordWrap(false)
  track.cells={name=track.label}
  for _,key in ipairs({"slot","id","timer","unit","effect","group"}) do track.cells[key]=label(track,"",0,0,11,60,key=="slot" and "secondary" or "muted") end
  track:SetScript("OnClick",function() if track.token then self:Select(track.token) end end)
  self.trackRows[i]=track
 end
 self.searchPrevious=U:Button(self.searchPanel,"Previous",12,0,90,function() self.searchOffset=math.max(0,self.searchOffset-self.searchVisible);self:RenderSearch() end)
 self.searchNext=U:Button(self.searchPanel,"Next",0,0,90,function() self.searchOffset=math.min(math.max(0,#self.results-self.searchVisible),self.searchOffset+self.searchVisible);self:RenderSearch() end)
 self.searchPage=label(self.searchPanel,"",110,0,11,140,"muted");self.searchPage:SetJustifyH("CENTER")
 self.trackingHeading=label(self.trackingPanel,"Tracking List",12,-12,15,330,"heading")
 self.tableHeader=CreateFrame("Frame",nil,self.trackingPanel);self.tableHeader.cells={}
 for _,key in ipairs({"slot","name","id","timer","unit","effect","group"}) do self.tableHeader.cells[key]=label(self.tableHeader,"",0,0,11,60,"secondary") end
 self.tableRule=self.tableHeader:CreateTexture(nil,"BACKGROUND");self.tableRule:SetHeight(1);self.tableRule:SetPoint("BOTTOMLEFT");self.tableRule:SetPoint("BOTTOMRIGHT")
 self.tableRule:SetColorTexture(unpack((M.Theme and M.Theme.edge) or {.26,.26,.26,1}))
 self.trackPrevious=U:Button(self.trackingPanel,"<",0,-8,26,function() self.listOffset=math.max(0,self.listOffset-self.trackVisible);self:RenderTracking() end)
 self.trackNext=U:Button(self.trackingPanel,">",0,-8,26,function() self.listOffset=math.min(math.max(0,#self.records-self.trackVisible),self.listOffset+self.trackVisible);self:RenderTracking() end)
 self.manageGroups=U:Button(self.trackingPanel,"Manage Groups",0,-8,130,function() self:OpenGroups() end)
 self.trackEmpty=label(self.trackingPanel,"Select a search result, then choose Select to add it here.",16,-84,13,400,"muted")
 self.details=CreateFrame("Frame",nil,self.trackingPanel)
 self.detailRule=self.details:CreateTexture(nil,"BACKGROUND");self.detailRule:SetColorTexture(unpack((M.Theme and M.Theme.edge) or {.26,.26,.26,1}));self.detailRule:SetHeight(1);self.detailRule:SetPoint("TOPLEFT");self.detailRule:SetPoint("TOPRIGHT")
 self.detailName=label(self.details,"Select a slot to edit its tracking.",0,-12,12,380,"heading");self.detailName:SetWordWrap(false)
 self.typeButton=U:Button(self.details,"Timer",0,-38,210,function(button)
  local _,row=lookup(self.records,self.selection);if not row then return end
  local choices=isItem(row.entry) and {{value="Item",label="Item cooldown"},{value="ItemAura",label="Item buff duration"}}
   or {{value="Cooldown",label="Ability cooldown"},{value="Recharge",label="Charge recharge"},{value="Buff",label="Buff / proc"},{value="Debuff",label="Debuff"}}
  self:ShowMenu(button,choices,function(value) self:ChangeType(value) end)
 end)
 self.observeButton=U:Button(self.details,"Observe: Self",222,-38,160,function(button)
  self:ShowMenu(button,{{value="player",label="Self"},{value="target",label="Current target"}},function(value) self:ChangeObservation(value) end)
 end)
 self.highlightButton=U:Button(self.details,"Highlight: None",0,-76,210,function(button)
  self:ShowMenu(button,{{value="None",label="None"},{value="Accent",label="Gold border"},{value="Glow",label="Soft glow"}},function(value) self:ChangeEntry(self.selection,nil,value) end)
 end)
 self.displayButton=U:Button(self.details,"Display: Primary",0,-114,210,function(button)
  self:ShowMenu(button,{{value="Primary",label="Primary Display"},{value="Secondary",label="Secondary Display"}},function(value) self:ChangeDisplay(self.selection,value) end)
 end)
 self.groupButton=U:Button(self.details,"Grouping: Unassigned",222,-114,160,function(button)
  local choices={{value=false,label="Unassigned"}}
  for _,group in ipairs(self.model.draft.modules.Cooldowns.groups or {}) do
   choices[#choices+1]={value=group.id,label=group.name..(group.bar and " · "..group.bar or "")}
  end
  self:ShowMenu(button,choices,function(value) self:AssignGroup(self.selection,value or nil) end)
 end)
 self.slotLabel=label(self.details,"Slot",222,-83,11,30,"muted")
 self.slotBox=U:Edit(self.details,254,-76,44,"",function(text)
  if self:StageField("slot",text) then self:FlushEntryEdits() end
 end);self.slotBox:SetMaxLetters(3)
 self.slotBox:SetScript("OnTextChanged",function(edit) self:StageField("slot",edit:GetText()) end)
 self.earlier=U:Button(self.details,"<",304,-76,30,function() local index=lookup(self.records,self.selection);if index then self:Move(self.selection,index-1) end end)
 self.later=U:Button(self.details,">",340,-76,30,function() local index=lookup(self.records,self.selection);if index then self:Move(self.selection,index+1) end end)
 self.auraLabel=label(self.details,"Buff spell name or ID",0,-115,11,250,"muted")
 self.auraBox=U:Edit(self.details,0,-135,290,"",function(text) self:ChangeAura(text) end)
 self.auraBox:SetScript("OnTextChanged",function(edit) self:StageField("aura",edit:GetText()) end)
 self.auraApply=U:Button(self.details,"Use buff",300,-135,82,function() self:ChangeAura(self.auraBox:GetText()) end)
 self.detailHint=label(self.details,"",0,-115,11,300,"muted")
 self.remove=U:Button(self.details,"Remove",0,-174,90,function() self:Remove(self.selection) end)
 self.footer=CreateFrame("Frame",nil,root)
 self.notice=label(self.footer,"",0,-3,11,600,"muted")
 self.undo=U:Button(root,"Undo",0,0,84,function() self:Undo() end)
 self.cancel=U:Button(root,"Cancel",0,0,90,function() self:Close(false) end)
 self.save=U:Button(root,"Save & Close",0,0,132,function() self:Save() end)
 self.save.selected=true;U:PaintButton(self.save)
 self.secondaryBarTiles={}
 for i=1,40 do
  local isSecondary=i>20;local host=isSecondary and self.secondaryPreview or self.preview
  local button=U:Button(host,"",0,0,56)
  button.label:Hide();button:RegisterForDrag("LeftButton")
  local icon=button:CreateTexture(nil,"ARTWORK");icon:SetPoint("TOPLEFT",2,-2);icon:SetPoint("BOTTOMRIGHT",-2,2)
  icon:SetTexCoord(.08,.92,.08,.92)
  local timer=CreateFrame("Cooldown",nil,button,"CooldownFrameTemplate");timer:SetAllPoints(icon)
  if timer.SetDrawEdge then timer:SetDrawEdge(false) end
  if timer.SetHideCountdownNumbers then timer:SetHideCountdownNumbers(false) end
  if timer.EnableMouse then timer:EnableMouse(false) end
  local overlay=CreateFrame("Frame",nil,button);overlay:SetAllPoints(button);overlay:SetFrameLevel(timer:GetFrameLevel()+1)
  local count=label(overlay,"",0,0,11,52);count:ClearAllPoints();count:SetPoint("BOTTOMRIGHT",-3,3);count:SetJustifyH("RIGHT")
  local number=label(overlay,"",2,-2,10,48,"text")
  local glow=overlay:CreateTexture(nil,"ARTWORK");glow:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
  if glow.SetBlendMode then glow:SetBlendMode("ADD") end
  local highlight=(M.Theme and M.Theme.secondary) or {.96,.79,.36,1}
  glow:SetVertexColor(highlight[1],highlight[2],highlight[3],.65);glow:SetPoint("TOPLEFT",button,"TOPLEFT",-6,6);glow:SetPoint("BOTTOMRIGHT",button,"BOTTOMRIGHT",6,-6);glow:Hide()
  local tile={frame=button,icon=icon,timer=timer,count=count,number=number,countFrame=overlay,glow=glow,bar=isSecondary and "Secondary" or "Primary"}
  tile.groupTop=overlay:CreateTexture(nil,"OVERLAY");tile.groupBottom=overlay:CreateTexture(nil,"OVERLAY");tile.groupTop:Hide();tile.groupBottom:Hide()
  button:SetScript("OnMouseDown",function() self.suppressClick=nil end)
  button:SetScript("OnClick",function()
   if self.suppressClick==button then self.suppressClick=nil;return end
   if tile.token then self:Select(tile.token) end
  end)
  button:SetScript("OnDragStart",function()
   if self:Current() and tile.token and self:SetSelection(tile.token) then self.drag={session=self.session,token=tile.token};self.suppressClick=button;self:RenderTracking() end
  end)
  button:SetScript("OnDragStop",function()
   local drag=self.drag;self.drag=nil;self.dropMarker:Hide();self.secondaryDropMarker:Hide()
   if drag and self:Current(drag.session) then
    local destination,_,bar=self:DropIndex();if destination then
     local _,record=lookup(self.records,drag.token)
     if record and display(record.entry)~=bar then self:ChangeDisplay(drag.token,bar,destination) else self:Move(drag.token,destination) end
    end
   end
  end)
  self.barTiles[i]=tile
  if isSecondary then self.secondaryBarTiles[#self.secondaryBarTiles+1]=tile end
 end
 root:SetScript("OnKeyDown",function(frame,key)
  if not self.session or self.suspended then return end
  frame:SetPropagateKeyboardInput(true)
  if key=="ESCAPE" then
   frame:SetPropagateKeyboardInput(false)
   if self.menu and self.menu:IsShown() then self.menu:Hide()
   elseif self.groupShade and self.groupShade:IsShown() then self:CloseGroups()
   else self:Close(true,"Tracker draft retained. Reopen Configure Tracker to continue.") end
  elseif not (self.groupShade and self.groupShade:IsShown()) and not self.searchBox:HasFocus() and not self.slotBox:HasFocus() and not self.auraBox:HasFocus() and S:Public(IsControlKeyDown,"boolean")==true then
   local index=lookup(self.records,self.selection)
   if key=="Z" then frame:SetPropagateKeyboardInput(false);self:Undo()
   elseif index and (key=="LEFT" or key=="RIGHT") then frame:SetPropagateKeyboardInput(false);self:Move(self.selection,index+(key=="LEFT" and -1 or 1)) end
  end
 end)
 root:SetScript("OnKeyUp",function(frame) frame:SetPropagateKeyboardInput(true) end)
 root:SetScript("OnHide",function() if self.session and not self.closing then self:Close(true) end end)
 root:SetScript("OnUpdate",function(_,elapsed) self:OnUpdate(elapsed) end)
 root:SetScript("OnEvent",function(_,event,unit,success)
  if event=="GLOBAL_MOUSE_DOWN" then self:MenuOutsideClick();return
  elseif event=="PLAYER_REGEN_DISABLED" or event=="PLAYER_LEAVING_WORLD" then
   if self.session then self:Close(true,"Tracker draft retained. Reopen Configure Tracker after combat or travel.") end
  elseif event=="PLAYER_REGEN_ENABLED" then
   if self.restorePending and M.ActionInterface and M.ActionInterface.SetTrackerWorkspace then self.restorePending=not M.ActionInterface:SetTrackerWorkspace(false) end
   if self.session then self:RefreshContext() end
  elseif event=="DISPLAY_SIZE_CHANGED" or event=="UI_SCALE_CHANGED" then
   if self.session and not self.suspended then self:Layout();self:Render() end
  elseif self.session and not self.suspended then
   if event=="UNIT_AURA" then
    if unit=="player" or unit=="target" then self.paintElapsed=.2 end
   elseif event=="PLAYER_TARGET_CHANGED" then self.paintElapsed=.2
   elseif event=="SPELL_DATA_LOAD_RESULT" or event=="ITEM_DATA_LOAD_RESULT" then
    local kind=event=="SPELL_DATA_LOAD_RESULT" and "Spell" or "Item"
    if self:MetadataRelevant(kind,unit) and S:Readable(success) and type(success)=="boolean" then
     self.metadataOutcomes[kind][unit]=success
     self:RefreshSearch();self.paintElapsed=.2;self.metadataDirty=true
    end
   else self:RefreshSearch();self.paintElapsed=.2;self.metadataDirty=true end
  end
 end)
 for _,event in ipairs({"PLAYER_REGEN_DISABLED","PLAYER_REGEN_ENABLED","PLAYER_LEAVING_WORLD","DISPLAY_SIZE_CHANGED","UI_SCALE_CHANGED","SPELL_DATA_LOAD_RESULT","ITEM_DATA_LOAD_RESULT","SPELLS_CHANGED","BAG_UPDATE_DELAYED","PLAYER_EQUIPMENT_CHANGED","COOLDOWN_VIEWER_DATA_LOADED","COOLDOWN_VIEWER_TABLE_HOTFIXED","COOLDOWN_VIEWER_SPELL_OVERRIDE_UPDATED","PLAYER_TARGET_CHANGED","UNIT_AURA"}) do root:RegisterEvent(event) end
 self.mouseEventAvailable=pcall(root.RegisterEvent,root,"GLOBAL_MOUSE_DOWN")
end
function E:Layout()
 local width,height=UIParent:GetWidth(),UIParent:GetHeight()
 if not S:Number(width) or not S:Number(height) or width<=0 or height<=0 then return false end
 -- One bounded window; a stable minimum canvas scales uniformly on smaller
 -- displays so table cells, controls and preview padding cannot collide.
 local scale=math.min(1,width/1040,height/800)
 local w,h=math.min(1280,width/scale-24),math.min(840,height/scale-24)
 self.root:ClearAllPoints();self.root:SetPoint("CENTER",UIParent,"CENTER",0,0);self.root:SetScale(scale);self.root:SetSize(w,h)
 self.heading:SetWidth(math.max(180,w-430));place(self.undo,w-342,-16,84,30);place(self.cancel,w-250,-16,90,30);place(self.save,w-152,-16,136,30)
 local enabled=self.model and self.model.draft.modules.Cooldowns.rowSecondary==true
 self.layoutSecondary=enabled
 self.secondaryToggle:ClearAllPoints();self.secondaryToggle:SetPoint("TOPLEFT",self.root,"TOPLEFT",190,-68)
 if self.secondaryToggle.SetChecked then self.secondaryToggle:SetChecked(enabled) end
 self.secondaryToggle.mark:SetShown(enabled)
 local trayWidth=w-36
 local tileSize,pitch=54,60
 local source=provider()
 local metrics=source and source.DisplayMetrics and source:DisplayMetrics(tileSize,pitch-tileSize)
  or {secondarySize=48.6,secondaryGap=5.4,sectionGap=16}
 self.previewMetrics=metrics
 local previewHeight=tileSize+16
 local secondaryTop=8+previewHeight+metrics.sectionGap-16
 local secondaryHeight=metrics.secondarySize+16
 local trayHeight=math.ceil(enabled and secondaryTop+secondaryHeight+8 or 8+previewHeight+8)
 place(self.tray,18,-96,trayWidth,trayHeight)
 self.previewVisible=math.max(1,math.min(20,math.floor((trayWidth-88)/pitch)))
 local previewWidth=self.previewVisible*pitch-6
 self.previewCapacityWidth=previewWidth
 self.preview:SetSize(previewWidth,previewHeight);self.preview:ClearAllPoints();self.preview:SetPoint("TOP",self.tray,"TOP",0,-8)
 local primaryArrowY=-(16+(tileSize-28)/2)
 place(self.barPrevious,10,primaryArrowY,26,28);place(self.barNext,trayWidth-36,primaryArrowY,26,28)
 self.barHint:SetWidth(trayWidth-24);self.barHint:SetJustifyH("CENTER");self.emptyBar:SetWidth(previewWidth-16)
 self.secondaryTray:SetShown(enabled);place(self.secondaryTray,0,-secondaryTop,trayWidth,secondaryHeight)
 self.secondaryPreviewVisible=math.max(1,math.min(20,math.floor((trayWidth-88)/54)))
 self.secondaryPreviewCapacityWidth=self.secondaryPreviewVisible*54-5.4
 self.secondaryPreview:SetSize(self.secondaryPreviewCapacityWidth,secondaryHeight);self.secondaryPreview:ClearAllPoints();self.secondaryPreview:SetPoint("TOP",self.secondaryTray,"TOP",0,0)
 local secondaryArrowY=-(8+(metrics.secondarySize-28)/2)
 place(self.secondaryPrevious,10,secondaryArrowY,26,28);place(self.secondaryNext,trayWidth-36,secondaryArrowY,26,28)
 for i,tile in ipairs(self.barTiles) do
  local secondary=i>20;local index=secondary and i-20 or i
  local size=secondary and 48.6 or tileSize;local spacing=secondary and 54 or pitch
  place(tile.frame,(index-1)*spacing,-8,size,size)
 end
 local bodyWidth=w-32;local bodyTop=96+trayHeight+16;local bodyHeight=h-bodyTop-34
 self.body:SetSize(bodyWidth,bodyHeight);self.body:ClearAllPoints();self.body:SetPoint("TOPLEFT",self.root,"TOPLEFT",16,-bodyTop)
 local left=math.max(280,math.floor((bodyWidth-14)*.28));local right=bodyWidth-14-left
 place(self.searchPanel,0,0,left,bodyHeight);place(self.trackingPanel,left+14,0,right,bodyHeight)
 self.leftWidth,self.rightWidth=left,right
 self.searchHeading:SetWidth(left-24);place(self.searchBox,12,-40,left-90,30);place(self.clearSearch,left-70,-40,58,30)
 self.searchSummary:SetWidth(left-24);self.searchEmpty:SetWidth(left-24)
 self.searchVisible=math.max(3,math.min(14,math.floor((bodyHeight-150)/44)))
 self.trackPitch=34;self.trackTop=70
 self.trackVisible=math.max(2,math.min(12,math.floor((bodyHeight-self.trackTop-248)/self.trackPitch)))
 self.searchPrevious:ClearAllPoints();self.searchPrevious:SetPoint("BOTTOMLEFT",self.searchPanel,"BOTTOMLEFT",12,10)
 self.searchNext:ClearAllPoints();self.searchNext:SetPoint("BOTTOMRIGHT",self.searchPanel,"BOTTOMRIGHT",-12,10)
 self.searchPage:ClearAllPoints();self.searchPage:SetPoint("BOTTOM",self.searchPanel,"BOTTOM",0,18);self.searchPage:SetWidth(math.max(60,left-220))
 self.trackingHeading:SetWidth(right-242);place(self.manageGroups,right-224,-8,140,28);place(self.trackPrevious,right-74,-8,26,28);place(self.trackNext,right-42,-8,26,28)
 place(self.tableHeader,12,-40,right-24,24)
 self.trackingColumns,self.trackingCompact=self:TrackingColumns(right-24)
 for _,cell in pairs(self.tableHeader.cells) do cell:Hide() end
 for _,column in ipairs(self.trackingColumns) do
  local cell=self.tableHeader.cells[column.key];tableCell(cell,self.tableHeader,column,2,18);cell:SetText(column.title);cell:Show()
 end
 self.trackEmpty:SetWidth(right-32)
 place(self.details,12,-(self.trackTop+self.trackVisible*self.trackPitch+6),right-24,242)
 local dw=right-24;local fieldWidth=math.floor((dw-10)*.52);local second=dw-fieldWidth-10
 self.detailName:SetWidth(dw)
 place(self.typeButton,0,-38,fieldWidth,28);place(self.observeButton,fieldWidth+10,-38,second,28)
 place(self.highlightButton,0,-76,fieldWidth,28)
 self.slotLabel:ClearAllPoints();self.slotLabel:SetPoint("TOPLEFT",self.details,"TOPLEFT",fieldWidth+10,-84)
 place(self.slotBox,fieldWidth+39,-76,math.max(30,second-99),28)
 place(self.earlier,dw-60,-76,28,28);place(self.later,dw-28,-76,28,28)
 place(self.displayButton,0,-114,fieldWidth,28);place(self.groupButton,fieldWidth+10,-114,second,28)
 self.auraLabel:ClearAllPoints();self.auraLabel:SetPoint("TOPLEFT",0,-151)
 self.detailHint:ClearAllPoints();self.detailHint:SetPoint("TOPLEFT",0,-151);self.detailHint:SetWidth(dw)
 place(self.auraBox,0,-171,dw-92,28);place(self.auraApply,dw-84,-171,84,28);place(self.remove,dw-90,-208,90,28)
 self.footer:SetSize(bodyWidth,24);self.footer:ClearAllPoints();self.footer:SetPoint("BOTTOMLEFT",self.root,"BOTTOMLEFT",16,4)
 self.notice:SetWidth(bodyWidth)
 return true
end
function E:RenderSearch()
 if not self.root or not self.session then return end
 local pending=self.pendingQuery~=nil and self.pendingQuery~=self.query
 local total=pending and 0 or #(self.results or {});local query=self.pendingQuery or self.query or ""
 self.searchOffset=math.max(0,math.min(self.searchOffset or 0,math.max(0,total-self.searchVisible)))
 self.searchSummary:SetText(query=="" and "Search by name or ID" or pending and "Searching…" or total>0 and (total..(total==1 and " match" or " matches")..(self.searchHint and " · Refine to see more" or "")) or self.searchLoading and "Waiting for spell or item information…" or self.searchUnavailable and "Information is unavailable" or "No matches found")
 self.searchEmpty:SetText(query=="" and "Type a name or ID to search.\n\nResults include your spellbook, tracked effects and carried or equipped items. An exact ID can find a buff or item outside those lists." or pending and "Results will appear here as you type." or self.searchLoading and "Requested information will appear automatically when available. You can keep searching while it loads." or self.searchUnavailable and "The game could not load information for this source. Check the ID or try another name." or "Try another name or an exact spell or item ID.\n\nUse spell:ID or item:ID to narrow an exact lookup.")
 self.searchEmpty:SetShown(total==0)
 for i,row in ipairs(self.searchRows) do
  local index=self.searchOffset+i;local candidate=not pending and i<=self.searchVisible and self.results[index]
  row.candidate=candidate;row.resultIndex=index;row.generation=self.searchGeneration
  if candidate then
   place(row,12,-106-(i-1)*44,self.leftWidth-24,42)
   row.icon:SetTexture(candidate.icon);row.label:SetText(candidate.name)
   row.detail:SetText(candidate.kind.." · #"..candidate.id..(candidate.rank and candidate.rank~="" and " · "..candidate.rank or ""))
   local selected=self.searchSelection==index
   row.label:SetWidth(self.leftWidth-24-56-(selected and 74 or 0));row.detail:SetWidth(self.leftWidth-24-56-(selected and 74 or 0))
   row.select:ClearAllPoints();row.select:SetPoint("RIGHT",row,"RIGHT",-7,0);row.select:SetShown(selected)
   selectedButton(row,selected);row:Show()
  else row:Hide() end
 end
 self.searchPrevious:SetEnabled(self.searchOffset>0);self.searchNext:SetEnabled(self.searchOffset+self.searchVisible<total)
 self.searchPage:SetText(total>0 and ((self.searchOffset+1).."–"..math.min(total,self.searchOffset+self.searchVisible).." / "..total) or "")
end
function E:RenderTracking()
 if not self.session or not self.details then return end
 local session,records,selection,render=self.session,self.records,self.selection,{}
 self.trackingRender=render
 local function current() return self:Current(session) and self.records==records and self.selection==selection and self.trackingRender==render end
 local count=#self.records;local index,selected=lookup(self.records,self.selection)
 if self.renderSelection~=self.selection then
  if index then
   if index<=self.listOffset then self.listOffset=index-1 elseif index>self.listOffset+self.trackVisible then self.listOffset=index-self.trackVisible end
  end
 end
 self.listOffset=math.max(0,math.min(self.listOffset or 0,math.max(0,count-self.trackVisible)))
 self.trackingHeading:SetText("Tracking List · "..count..(count==1 and " slot" or " slots"));self.trackEmpty:SetShown(count==0)
 for i,row in ipairs(self.trackRows) do
  local slot=self.listOffset+i;local item=i<=self.trackVisible and self.records[slot]
  row.token=item and item.token
  if item then
   local meta=self:Metadata(item.entry);local target=item.entry.mode=="TargetAura" or item.entry.mode=="TargetDebuff"
   if not current() then return end
   place(row,12,-self.trackTop-(i-1)*self.trackPitch,self.rightWidth-24,self.trackPitch-2)
   local group=groupByID(self.model.draft.modules.Cooldowns.groups,item.entry.group)
   local values={slot=(item.entry.bar=="Secondary" and "S" or "")..tostring(slot),name=meta.name or "Loading…",id=tostring(item.entry.id),
    timer=tableModes[item.entry.mode] or item.entry.mode,unit=target and "Target" or "Self",
    effect=item.entry.highlight=="Glow" and "Glow" or item.entry.highlight=="Accent" and "Border" or "None",group=group and group.name or "Unassigned"}
   for _,cell in pairs(row.cells) do cell:Hide() end
   for _,column in ipairs(self.trackingColumns) do
    local cell=row.cells[column.key];tableCell(cell,row,column)
    if column.key=="name" then
     row.icon:ClearAllPoints();row.icon:SetPoint("LEFT",row,"LEFT",column.x,0)
     cell:ClearAllPoints();cell:SetPoint("LEFT",row,"LEFT",column.x+32,0);cell:SetWidth(math.max(1,column.width-32))
    end
    cell:SetText(values[column.key]);cell:Show()
   end
   row.icon:SetTexture(meta.icon or 134400)
   selectedButton(row,item.token==self.selection);row:Show()
  else row:Hide() end
 end
 self.trackPrevious:SetEnabled(self.listOffset>0);self.trackNext:SetEnabled(self.listOffset+self.trackVisible<count)
 self.details:SetShown(selected~=nil)
 if selected then
  local entry=selected.entry;local meta=self:Metadata(entry)
  if not current() then return end
  local aura=auraModes[entry.mode] and entry.mode~="ItemAura"
  local target=entry.mode=="TargetAura" or entry.mode=="TargetDebuff"
  self.detailName:SetText("Slot "..index.." · "..display(entry).." · "..(meta.name or "Loading…").." · ID "..entry.id)
  self.typeButton:SetText("Timer: "..(modeLabels[entry.mode] or entry.mode));self.observeButton:SetText("Observe: "..(target and "Target" or "Self"));self.observeButton:SetEnabled(aura==true)
  self.highlightButton:SetText("Highlight: "..(highlightLabels[entry.highlight or "None"] or "None"))
  local group=groupByID(self.model.draft.modules.Cooldowns.groups,entry.group)
  self.displayButton:SetText("Display: "..display(entry));self.groupButton:SetText("Grouping: "..(group and group.name or "Unassigned"))
  local draft=self.fieldDraft and self.fieldDraft.token==selected.token and self.fieldDraft
  local previousUpdating=self.fieldUpdating;self.fieldUpdating=true
  if not self.slotBox:HasFocus() then self.slotBox:SetText(draft and draft.slot or tostring(index)) end
  self.earlier:SetEnabled(index>1);self.later:SetEnabled(index<count)
  local item=isItem(entry)
  self.auraLabel:SetShown(item);self.auraBox:SetShown(item);self.auraApply:SetShown(item);self.detailHint:SetShown(not item)
  if item then
   if not self.auraBox:HasFocus() then self.auraBox:SetText(draft and draft.aura or (entry.auraID and tostring(entry.auraID)) or "") end
  else
   self.detailHint:SetText(aura and "Inactive effects stay grey in their saved slots. Active effects regain their color and chosen highlight. Change this in the bar's display settings." or "Timers follow your ability or charges. Choose Buff / proc or Debuff to observe an effect on Self or Target.")
  end
  self.fieldUpdating=previousUpdating
 end
end
function E:BarRecords(bar)
 local rows={}
 for index,record in ipairs(self.records or {}) do if display(record.entry)==bar then rows[#rows+1]={record=record,index=index} end end
 return rows
end
function E:RenderPreview()
 if not self.session or not self.preview then return end
 local session,records,selection,render=self.session,self.records,self.selection,{}
 self.previewRender=render
 local function current() return self:Current(session) and self.records==records and self.selection==selection and self.previewRender==render end
 local source=provider();local settings=self.model.draft.modules.Cooldowns
 for _,bar in ipairs({"Primary","Secondary"}) do
  local secondary=bar=="Secondary";local rows=self:BarRecords(bar)
  local offsetKey=secondary and "secondaryPreviewOffset" or "previewOffset"
  local visible=secondary and self.secondaryPreviewVisible or self.previewVisible
  local offset=self[offsetKey] or 0
  if self.renderSelection~=self.selection then
   for index,row in ipairs(rows) do if row.record.token==self.selection then
    if index<=offset then offset=index-1 elseif index>offset+visible then offset=index-visible end;break
   end end
  end
  offset=math.max(0,math.min(offset,math.max(0,#rows-visible)));self[offsetKey]=offset
  local enabled=not secondary or settings.rowSecondary==true
  local preview=secondary and self.secondaryPreview or self.preview
  local rendered=math.min(#rows,visible)
  local previewWidth=rendered>0 and (rendered*(secondary and 54 or 60)-(secondary and 5.4 or 6))
   or secondary and 48.6 or self.previewCapacityWidth
  preview:SetWidth(previewWidth)
  if secondary then self.secondaryEmpty:SetShown(enabled and #rows==0) else self.emptyBar:SetShown(#rows==0) end
  for i=1,20 do
   local tile=self.barTiles[(secondary and 20 or 0)+i]
   local slot=offset+i;local item=enabled and i<=visible and rows[slot];local record=item and item.record
   tile.token=record and record.token
   if record then
    local meta=self:Metadata(record.entry);if not current() then return end
    tile.meta=meta;tile.meta.highlight=record.entry.highlight;tile.meta.bar=record.entry.bar;tile.meta.group=record.entry.group
    tile.icon:SetTexture(meta.icon or 134400);tile.icon:SetDesaturated(false);tile.number:SetText(tostring(item.index))
    tile.auraActive=nil;tile.displayReady=false;tile.timer:Clear();tile.count:SetText("");tile.frame:Show();self:PaintPreviewAppearance(tile)
    local previous=i>1 and rows[slot-1] and rows[slot-1].record.entry
    local following=i<visible and rows[slot+1] and rows[slot+1].record.entry
    if source and source.AccentPlan and source.PaintGroupAccents then
     local plan=source:AccentPlan(record.entry,settings.groups,previous,following,secondary and 48.6 or 54,secondary and 5.4 or 6)
     source:PaintGroupAccents(tile,plan)
    else tile.groupTop:Hide();tile.groupBottom:Hide() end
   else tile.frame:Hide();tile.timer:Clear();tile.glow:Hide();tile.groupTop:Hide();tile.groupBottom:Hide();tile.meta=nil end
  end
  local previous=secondary and self.secondaryPrevious or self.barPrevious
  local following=secondary and self.secondaryNext or self.barNext
  previous:SetEnabled(offset>0);following:SetEnabled(offset+visible<#rows)
 end
 self.barHint:SetText("Live previews · Drag slots within or between displays · Ctrl + Left / Right changes order")
 self.paintElapsed=.2
end
function E:Render()
 if not self.session or not self.root or self.suspended then return end
 local session=self.session
 if self.menu then self.menu:Hide() end
 if self.layoutSecondary~=(self.model.draft.modules.Cooldowns.rowSecondary==true) then self:Layout() end
 -- The list, selected summary and preview need the same static source facts.
 -- Cache only inside this render, so metadata events and the next render still
 -- resolve fresh information. Nested renders cannot publish into this pass.
 local pass={session=session,records=self.records,values={}};self.metadataPass=pass
 self:RenderSearch();self:RenderTracking()
 if not self:Current(session) or self.metadataPass~=pass or self.records~=pass.records then if self.metadataPass==pass then self.metadataPass=nil end;return end
 self:RenderPreview()
 if self.metadataPass~=pass then return end
 self.metadataPass=nil
 if not self:Current(session) or self.records~=pass.records then return end
 self.renderSelection=self.selection;self:RefreshUndo()
end
function E:DropIndex()
 if not self.preview or not self.records then return nil end
 local cursorX,cursorY=GetCursorPosition()
 if not S:Number(cursorX) or not S:Number(cursorY) then return nil end
 for _,bar in ipairs({"Primary","Secondary"}) do
  local secondary=bar=="Secondary";local preview=secondary and self.secondaryPreview or self.preview
  if not secondary or self.model.draft.modules.Cooldowns.rowSecondary==true then
   local scale=preview:GetEffectiveScale();local left,bottom=preview:GetLeft(),preview:GetBottom()
   local width,height=preview:GetWidth(),preview:GetHeight()
   if S:Number(scale) and scale>0 and S:Number(left) and S:Number(bottom) then
    local x,y=cursorX/scale-left,cursorY/scale-bottom
    if x>=0 and x<=width and y>=0 and y<=height then
     local rows=self:BarRecords(bar);local offset=secondary and self.secondaryPreviewOffset or self.previewOffset
     local position=math.max(1,math.min(math.max(1,#rows),offset+math.floor(x/(secondary and 54 or 60))+1))
     local destination=rows[position] and rows[position].index or math.max(1,#self.records)
     return destination,x,bar,position
    end
   end
  end
 end
end
function E:OnUpdate(elapsed)
 if not self.session or self.suspended then return end
 local session=self.session
 if S:InCombat() then self:Close(true,"Tracker draft retained after combat began.");return end
 if not self.mouseEventAvailable and self.menu and self.menu:IsShown() then
  local down=S:Public(IsMouseButtonDown,"boolean")
  if down==true and self.menuMouseDown~=true then self:MenuOutsideClick() end
  self.menuMouseDown=down
 end
 self.ownershipElapsed=(self.ownershipElapsed or 0)+elapsed
 if not self:Current() or self.ownershipElapsed>=.5 and not self.model:Current() then self:Close(true,"Saved settings changed. Reopen the tracker to start a fresh draft.");return end
 if self.ownershipElapsed>=.5 then self.ownershipElapsed=0 end
 if self.searchPending then
  self.searchDelay=(self.searchDelay or 0)-elapsed
  if self.searchDelay<=0 then
   local query=self.pendingQuery or self.query or "";self.pendingQuery=nil;self.searchPending=nil;self:Search(query)
  end
 end
 if not self:Current(session) then return end
 if self.metadataDirty then self.metadataDirty=nil;self:Render() end
 if not self:Current(session) then return end
 self.paintElapsed=(self.paintElapsed or 0)+elapsed
 if self.paintElapsed>=.2 then
  self.paintElapsed=0;local source=provider()
  for _,tile in ipairs(self.barTiles) do
   if not self:Current(session) then return end
   if tile.token and tile.meta then
    local records,token,meta=self.records,tile.token,tile.meta
    local ok,ready=false,false
    if source and source.PaintFallback then ok,ready=pcall(source.PaintFallback,source,tile) end
    if not self:Current(session) then return end
    if self.records~=records or tile.token~=token or tile.meta~=meta then self:Render();return end
    tile.displayReady=ok and ready==true
    if not ok or not ready then tile.timer:Clear();tile.count:SetText("?");tile.icon:SetDesaturated(true)
    elseif tile.auraActive==false then tile.icon:SetDesaturated(true) end
    self:PaintPreviewAppearance(tile)
   end
  end
 end
 if self.drag then
  local index,x,bar,position=self:DropIndex()
  self.dropMarker:Hide();self.secondaryDropMarker:Hide()
  if index then
   local secondary=bar=="Secondary";local preview=secondary and self.secondaryPreview or self.preview
   local marker=secondary and self.secondaryDropMarker or self.dropMarker
   local key=secondary and "secondaryPreviewOffset" or "previewOffset";local offset=self[key] or 0
   local count=#self:BarRecords(bar);local visible=secondary and self.secondaryPreviewVisible or self.previewVisible
   marker:ClearAllPoints();marker:SetPoint("TOPLEFT",preview,"TOPLEFT",(position-offset-1)*(secondary and 54 or 60)-3,-8);marker:Show()
   self.drag.elapsed=(self.drag.elapsed or 0)+elapsed
   if self.drag.elapsed>.18 then
    self.drag.elapsed=0
    if x<12 and offset>0 then self[key]=offset-1;self:RenderPreview()
    elseif x>preview:GetWidth()-12 and offset+visible<count then self[key]=offset+1;self:RenderPreview() end
   end
  end
 end
end
