local M=MirageUI
if not M or not M.Options then return end
local O,U=M.Options,M.UI
function O:SetNameplateScale(cfg,value)
    if cfg.cardScale~=value and self.draft and self.draft.managed then self.draft.autoLayout=false end
    cfg.cardScale=value
end
function O:StageGroupLayout(kind,count)
    local supported,message=M.Elements:SettingSupported("PartyRaid","cellWidth",self.draft or M.profile)
    if not supported then self:Notice(message);return false,message end
    local ok,why=self:FlushEdits()
    if ok==false then self:Notice(why);return false end
    local staged,reason
    if kind=="compact" then staged,reason=M.GroupLayout:CompactPreset(self.draft,count)
    else staged,reason=M.GroupLayout:Arrange(self.draft,kind) end
    self:Notice(reason);return staged
end
O.cooldownModes={"Cooldown","Recharge","Aura","Debuff","TargetAura","TargetDebuff","Item","ItemAura"}
O.cooldownModeLabels={Cooldown="Ability cooldown",Recharge="Charge recharge",Aura="Player buff / proc",Debuff="Player debuff",
    TargetAura="Target buff",TargetDebuff="Target debuff",Item="Item cooldown",ItemAura="Item buff duration"}
function O:CooldownEntryMatches(entry,id,mode,auraID)
    return entry.id==id and entry.mode==mode and (mode~="ItemAura" or entry.auraID==auraID)
end
function O:CooldownEntryModes(mode)
    if mode=="Item" or mode=="ItemAura" then return {"Item","ItemAura"} end
    return {"Cooldown","Recharge","Aura","Debuff","TargetAura","TargetDebuff"}
end
local function labelForSpell(row)
    local result=O:ResolveCooldownSelection(tostring(row.id),row.mode,row.auraID)
    return (result.name or ("Spell "..row.id)),result
end
function O:ResolveCooldownSelection(query,mode,auraQuery)
    if mode=="Item" or mode=="ItemAura" then
        local S=M.Safety
        local id=tonumber(query) or S:Public(C_Item and C_Item.GetItemIDForItemInfo,"number",query)
        if not S:Number(id) or id<1 or id>2147483647 or id%1~=0 then
            return {ready=false,status="Choose an item",reason="Enter an item ID, item link or a cached item name."}
        end
        local name=S:Public(C_Item and C_Item.GetItemNameByID,"string",id)
        local icon=S:Public(C_Item and C_Item.GetItemIconByID,"number",id)
        if not name or not icon then
            local row=M.Rework and M.Rework.CooldownRow
            if row and row.RequestItemMetadata then row:RequestItemMetadata(id)
            elseif C_Item and type(C_Item.RequestLoadItemDataByID)=="function" then pcall(C_Item.RequestLoadItemDataByID,id) end
            return {id=id,ready=false,status="Item data loading",reason="Item information is not cached yet. Try adding it again after the game loads the item."}
        end
        local result={id=id,name=name,icon=icon,ready=true,status="Ready",reason="The item's cooldown will share the tracked row."}
        if mode=="ItemAura" then
            if auraQuery==nil or tostring(auraQuery):match("^%s*$") then
                local fn=C_Item and C_Item.GetItemSpell
                if type(fn)=="function" then
                    local ok,_,spellID=pcall(fn,id)
                    if ok and S:Number(spellID) and spellID>0 and spellID<=2147483647 and spellID%1==0 then auraQuery=tostring(spellID) end
                end
            end
            local aura=self:ResolveCooldownSelection(tostring(auraQuery or ""),"Aura")
            if not aura.ready then
                result.ready=false;result.status="Choose the buff";result.reason="Enter the spell name or ID of the buff granted by this item. The use spell and resulting buff may differ."
            else
                result.auraID=aura.id;result.auraName=aura.name
                result.reason="Track "..aura.name.." while it is present on you. Change the buff ID if the item's use effect grants a different aura."
            end
        end
        return result
    end
    local result=M.Spells:Resolve(query)
    -- A proc/buff need not be a learned castable ability. Resolve still checks
    -- public static spell metadata; no aura state is read by this editor.
    if (mode=="Aura" or mode=="Debuff" or mode=="TargetDebuff" or mode=="TargetAura") and M.Safety:Number(result.id) and result.id>=1 and result.id<=2147483647
        and M.Safety:Text(result.name) then
        result.ready=true;result.status="Ready";result.reason="Public spell metadata is available for aura tracking."
    end
    return result
end
function O:NativeCooldownAssignments()
    if M.Safety:InCombat() then return nil,"Choose tracked spells after combat." end
    local row=M.Rework and M.Rework.CooldownRow
    if not row or type(row.NativeAssignments)~="function" then return nil,"The cooldown manager is not available yet." end
    local ok,source=pcall(row.NativeAssignments,row)
    if not ok or not M.Safety:Readable(source) or type(source)~="table" or #source>160 then return nil,"Native tracking assignments are unavailable." end
    local values,seen={},{}
    for _,entry in ipairs(source) do
        local id=M.Safety:Field(entry,"id")
        if not M.Safety:Number(id) or id%1~=0 or id<1 or id>2147483647 then return nil,"Native tracking assignments are unavailable." end
        if not seen[id] then values[#values+1]={id=id,mode="Cooldown"};seen[id]=true end
    end
    return values
end
function O:OpenNativeCooldownSettings()
    if M.Safety:InCombat() then return false,"Open cooldown settings after combat." end
    local frame=CooldownViewerSettings
    if not M.Safety:Frame(frame,false) or type(frame.Show)~="function" then return false,"The game's cooldown settings are not available yet." end
    local ok,result=pcall(frame.Show,frame)
    local shown,state=M.Safety:Public(frame.IsShown,"boolean",frame)
    if not ok or result==false or state~="KNOWN" or shown~=true then return false,"The game's cooldown settings could not be opened." end
    return true,"Native cooldown settings are open."
end
function O:FeatureVisibility(cfg,y)
    self:Choice("featureVisibility","Visibility: "..cfg.visibility,{"Contextual","Always","Manual"},cfg.visibility,0,y,self.cw,function(v) cfg.visibility=v end)
    self:Slider("featureOpacity","Visual emphasis",0,y-48,self.cw,cfg.alpha,.2,1,.05,function(v) cfg.alpha=v end)
    return y-120
end
function O:RenderCooldownOptions(cfg)
    local draft,profile=self.draft,M.profile
    local function current() return self.draft==draft and M.profile==profile and draft and draft~=profile and draft.modules.Cooldowns==cfg end
    local function set(key,value) if current() then cfg[key]=value end end
    self:Check("ownedCooldowns","Show the tracked cooldown row",cfg.rowEnabled,0,-185,function(v) set("rowEnabled",v) end)
    self:Choice("cooldownVisibility","When the row appears",{{value=1,label="Always"},{value=2,label="In combat"},{value=3,label="In combat or with a target"}},cfg.rowVisibility,0,-227,self.cw,function(v) set("rowVisibility",v) end)
    self:Check("cooldownFollowHUD","Follow directly below the character HUD",cfg.rowFollowHUD,0,-270,function(v)
        if current() then cfg.rowFollowHUD=v;if v then draft.layouts["Cooldowns.row"]=nil end end
    end)
    local y=-318
    self:Text("cooldownTrackerHint","Choose spells and items, change tracking conditions and arrange slots in Customize UI > Cooldown Manager > Configure Tracker.",0,y,self.cw,12);y=y-76
    for _,row in ipairs({{"ignoreGCD","Exclude the Global Cooldown from ability timers"},{"showNumbers","Show countdown numbers"},{"rowShowCharges","Show charge or stack counts"},{"rowTooltips","Show tooltips on hover"}}) do
        local key,label=row[1],row[2]
        self:Check("cooldown"..key,label,cfg[key],0,y,function(v) set(key,v) end);y=y-44
    end
    for _,row in ipairs({{"iconSize","Icon size (pixels)",24,80},{"gap","Space between icons",0,12},{"rowScale","Row size (%)",65,160},{"rowOpacity","Opacity (%)",20,100},{"rowMaxIcons","Maximum icons (0 shows all)",0,160},{"rowBorder","Solid border (pixels)",0,3},{"rowZoom","Icon crop (%)",0,20},{"durationSize","Duration text size",8,24},{"chargeSize","Charge and stack text size",8,24}}) do
        local key,label,lo,hi=row[1],row[2],row[3],row[4]
        self:Slider("cooldown"..key,label,0,y,self.cw,cfg[key],lo,hi,1,function(v) set(key,v) end);y=y-68
    end
    self:Button("cooldownLayout","Move or resize the cooldown row",0,y,self.cw,function() M.ElementMap:Open("Cooldowns.row") end);y=y-42
    self:Text("cooldownHint","Apply before moving the row. Following the HUD clears a previously moved row position.",0,y,self.cw,11)
end
function O:RenderAuraOptions(cfg)
    self:Check("auraNativeStyle","Accent the game's aura frames",cfg.style,0,-185,function(v) cfg.style=v end)
    self:Check("auraOwn","Show an additional player-aura panel",cfg.playerPanel,0,-225,function(v) cfg.playerPanel=v end)
    local y=self:FeatureVisibility(cfg,-268)
    self:Text("auraInfo","Two rows of groups: your buffs and your debuffs, in the order supplied by the game. Restricted or unavailable entries are omitted. Blizzard's original auras remain the complete fallback; this panel never cancels effects.",0,y,self.cw,12);y=y-90
    self:Slider("auraLimit","Maximum icons in each group",0,y,self.cw,cfg.limit,4,20,1,function(v) cfg.limit=v end);y=y-68
    self:Slider("auraColumns","Icons per row",0,y,self.cw,cfg.columns,4,20,1,function(v) cfg.columns=v end);y=y-68
    self:Slider("auraSize","Icon size",0,y,self.cw,cfg.iconSize,20,48,1,function(v) cfg.iconSize=v end);y=y-68
    self:Check("auraNumbers","Show native countdown numbers",cfg.showNumbers,0,y,function(v) cfg.showNumbers=v end);y=y-44
    self:Button("auraLayout","Move the applied panel in Unlock Mode",0,y,self.cw,function() M.Editor:Open() end);y=y-48
    self:Text("auraLimitHint","This is a bounded display, not a reminder or debuff-priority engine. It does not sort by hidden durations, identify secret effects, or change the native aura filters.",0,y,self.cw,11)
end
function O:RenderActionOptions(cfg)
    if M.Rework and M.Rework:Selected("main",self.draft) then
        local y=-185
        self:Choice("actionExperience","Action interface: "..(cfg.actionExperience==1 and "Combat data context" or "Mouseover"),{"Combat data context","Mouseover"},cfg.actionExperience==1 and "Combat data context" or "Mouseover",0,y,self.cw,function(v) cfg.actionExperience=v=="Mouseover" and 2 or 1 end);y=y-56
        self:Slider("actionInterfaceScale","Overall size %",0,y,self.cw,cfg.interfaceScale or 100,65,160,5,function(v) cfg.interfaceScale=v end);y=y-68
        self:Check("actionDocked","Anchor to the bottom of the screen",cfg.interfaceDocked~=false,0,y,function(v) cfg.interfaceDocked=v end);y=y-42
        self:Check("actionKeys","Show shortcut labels",cfg.showHotkeys,0,y,function(v) cfg.showHotkeys=v end);y=y-42
        self:Check("actionCenterKeys","Centre keybind text on action slots",cfg.centerHotkeys==true,0,y,function(v) cfg.centerHotkeys=v;self:Render() end);y=y-42
        if cfg.centerHotkeys then
            self:Check("actionAutoKeySize","Auto-size keybind text to fit each slot",cfg.autoSizeHotkeys==true,0,y,function(v) cfg.autoSizeHotkeys=v;self:Render() end);y=y-42
            if not cfg.autoSizeHotkeys then self:Slider("actionKeySize","Centred keybind text size",0,y,self.cw,cfg.hotkeySize or 16,10,24,1,function(v) cfg.hotkeySize=v end);y=y-68 end
        end
        self:Check("actionMacroText","Hide macro text",cfg.hideMacroText==true,0,y,function(v) cfg.hideMacroText=v end);y=y-42
        self:Check("actionTips","Show action tooltips",cfg.showTooltips,0,y,function(v) cfg.showTooltips=v end);y=y-42
        self:Check("actionMove","Allow arranging actions",cfg.allowRearrange,0,y,function(v) cfg.allowRearrange=v end);y=y-48
        self:Text("actionFixedLayout","Horizontal action rows pack upward from the screen's bottom edge. A fine, beveled frame surrounds the section; inactive pet, stance and totem controls leave no gap. The compact More actions tab follows the top visible row and preserves slots 11–12 and bars 4–8. Empty rows appear while arranging actions.",0,y,self.cw,12);y=y-120
        self:Text("actionTaskReveal","Bags, spellbook, professions, talents and character windows reveal the controls. Hold the pickup modifier (usually Shift) when moving an existing action; drop a carried spell, item or macro outside combat.",0,y,self.cw,11);y=y-110
        self:Button("actionBindingEditor","Edit action shortcuts",0,y,self.cw,function() self:FlushEdits();M.BindingEditor:Open() end);y=y-45
        self:Button("actionLayout","Move or resize the action interface",0,y,self.cw,function() M.ElementMap:Open("ActionBars.interface") end)
        return
    end
    if self.draft.managed then
        self:Text("actionInfo","Managed mode uses the native action bars, not MirageUI's optional three supplemental bars. Native action slots and special vehicle, override and possession controls remain native.",0,-185,self.cw,12)
        self:Text("actionManagedPolicy","By default, managed bars use a fixed native visibility policy: combat or a target reveals them. The optional experiment below changes only four standard secondary bars. Supplemental labels, tooltips, dragging and geometry settings remain separate.",0,-290,self.cw,12)
        self:Check("actionSecondaryHover","Experimental secondary-bar hover",cfg.secondaryHover,0,-405,function(v) cfg.secondaryHover=v end)
        self:Text("actionSecondaryHoverScope","Off by default, source-qualified Standard client only, out of combat. The two bottom and two side secondary bars share hover. Main, extra and special-action access is not hidden by this option; combat keeps native access. Hover cleanly, then click after the controls are visible. Held or uncertain input defers transitions. Native input validation is NOT_RUN; this is not full action-bar hover.",0,-450,self.cw,11)
        self:Button("actionBindingEditor","Edit action shortcuts",0,-605,self.cw,function() self:FlushEdits();M.BindingEditor:Open() end)
        self:Text("actionBindingHint","Shortcut changes have their own confirmation and session-only restore history. Layout Apply/Cancel/Undo does not save or undo native key assignments. Other shortcuts remain intact.",0,-650,self.cw,11)
        self:Text("actionManagedRecovery","Help and restore provides native recovery and pre-setup configuration restore. This option is staged until Apply; Cancel leaves the applied policy unchanged. Shortcut confirmation is separate. Supplemental Unlock controls do not edit native bar layout.",0,-750,self.cw,11)
        return
    end
    self:Text("actionInfo","These three bars supplement Blizzard's controls. Their buttons use native secure actions and the existing action slots. Shortcuts use the matching native action commands; special vehicle/possession controls remain native.",0,-185,self.cw,12)
    local y=-278
    self:Check("actionContext","Show only in combat or with a target",cfg.contextual,0,y,function(v) cfg.contextual=v end);y=y-42
    self:Check("actionKeys","Show existing shortcut labels",cfg.showHotkeys,0,y,function(v) cfg.showHotkeys=v end);y=y-42
    self:Check("actionTips","Show action tooltips",cfg.showTooltips,0,y,function(v) cfg.showTooltips=v end);y=y-42
    self:Check("actionMove","Allow modifier + drag to rearrange actions",cfg.allowRearrange,0,y,function(v) cfg.allowRearrange=v end);y=y-42
    self:Text("actionMoveHint","After Apply, hold your action pickup modifier (normally Shift) while dragging or dropping a spell, item or macro. Changes affect the shared native action slots immediately, outside combat. No action is discarded from the cursor.",0,y,self.cw,11);y=y-100
    self:Button("actionBindingEditor","Edit action shortcuts",0,y,self.cw,function() self:FlushEdits();M.BindingEditor:Open() end);y=y-42
    self:Text("actionBindingHint","Shortcut changes have their own confirmation and session-only restore history. Layout Apply/Cancel/Undo does not save or undo native key assignments. Other shortcuts remain intact.",0,y,self.cw,11);y=y-86
    self:Slider("actionColumns","Buttons per row",0,y,self.cw,cfg.columns,1,12,1,function(v) cfg.columns=v end);y=y-68
    self:Slider("actionGap","Space between buttons",0,y,self.cw,cfg.gap,0,12,1,function(v) cfg.gap=v end);y=y-68
    self:Button("actionLayout","Move or resize bars in Unlock Mode",0,y,self.cw,function() M.Editor:Open() end);y=y-45
    self:Text("actionSafety","Contextual bar visibility is prepared outside combat and handled by a fixed native state driver. It has no decorative fade or post-combat delay. The bars yield to native vehicle, override and possession controls. Apply before arranging multi-row bars to avoid overlap.",0,y,self.cw,11)
end
function O:RenderResourceOptions(cfg)
    local y=self:FeatureVisibility(cfg,-185)
    self:Check("secondaryPower","Show the supported class-resource bar",cfg.classResource,0,y,function(v) cfg.classResource=v end);y=y-44
    self:Check("secondarySegments","Use separate segments for a known 1–10 point resource",cfg.classSegments,0,y,function(v) cfg.classSegments=v end);y=y-44
    self:Text("secondarySegmentsInfo","Segments need a supported resource with a known maximum of 1–10 whole points. Otherwise the extra display stays hidden. Clear the segment option to request a continuous bar. Form or capacity changes wait for safe reconfiguration.",0,y,self.cw,11);y=y-82
    self:Check("empowerStages","Show native empowered-cast stage slots",cfg.empoweredStages,0,y,function(v) cfg.empoweredStages=v end);y=y-44
    self:Text("empowerHint","Separate from the Under-Character HUD. Equal-width stage slots and a Hold slot use native duration objects; the addon never recommends a release time. Unsupported providers leave the native cast display available.",0,y,self.cw,11);y=y-100
    self:Text("resourceTypes","Optional secondary bar: Combo points, Holy Power, Chi, Soul Shards, Arcane Charges or Essence, depending on the character and available native power type. Choose a continuous bar or fixed native-fill segments. This does not add class-mechanic predictions.",0,y,self.cw,12);y=y-90
    self:Button("resourceLayout","Arrange resources and casts in Unlock Mode",0,y,self.cw,function() M.Editor:Open() end);y=y-44
    self:Text("resourceSafety","Player health, power and timing use native display widgets. No secret resource value drives a rule or threshold alert. Cast cancellation clears the timing track; empowered-stage slots are optional and retain native fallback.",0,y,self.cw,11)
end
function O:RenderQuestOptions(cfg)
    self:Check("questNativeStyle","Accent the game's objective tracker",cfg.style,0,-185,function(v) cfg.style=v end)
    self:Check("questCompact","Show a compact watched-quest panel",cfg.compactPanel,0,-225,function(v) cfg.compactPanel=v end)
    local y=self:FeatureVisibility(cfg,-270)
    self:Text("questDescription","Shows quests you already track, in the game's order. Click a title to collapse its details outside combat. Quest items, rewards and tracking choices remain in the native quest log.",0,y,self.cw,12);y=y-90
    self:Slider("questLimit","Maximum displayed quests",0,y,self.cw,cfg.questLimit,1,8,1,function(v) cfg.questLimit=v end);y=y-68
    self:Slider("objectiveLines","Objective lines per quest",0,y,self.cw,cfg.objectiveLines,1,4,1,function(v) cfg.objectiveLines=v end);y=y-68
    self:Check("questDetails","Show objective details",cfg.showObjectives,0,y,function(v) cfg.showObjectives=v end);y=y-42
    self:Check("questWorld","Include tracked world quests when available",cfg.worldQuests,0,y,function(v) cfg.worldQuests=v end);y=y-48
    self:Button("questLayout","Move or resize the panel in Unlock Mode",0,y,self.cw,function() M.Editor:Open() end);y=y-45
    self:Text("questHint","In Contextual mode the compact panel appears while traveling with tracked quests, after quest updates, or when revealed. It stays visible while you read its controls. More content than fits is left in the native quest log, never drawn outside the panel. No distance, route or turn-in proximity is guessed.",0,y,self.cw,11)
end
function O:RenderUnitOptions(id,cfg)
    self:Text("unitDescription","Additional unit controls keep their native target and menu clicks. Names, roles and status use only readable game information. Health and power remain native display values, not triggers for alerts.",0,-185,self.cw,12)
    local y=-278
    self:Slider("unitPanelOpacity","Subtle Minimal panel opacity",0,y,self.cw,cfg.panelOpacity,0,100,1,function(v) cfg.panelOpacity=v end);y=y-68
    self:Text("nameContract","Complete character names use one official class color, without outlines or shadows. Unknown classes use a neutral color. Health stays mint; resource colors follow the game.",0,y,self.cw,11);y=y-100
    self:Check("unitPercent","Show supported native health / power percentages",cfg.showPercent,0,y,function(v) cfg.showPercent=v end);y=y-42
    self:Check("unitNameBacking","Neutral backing behind names (optional)",cfg.nameBacking,0,y,function(v) cfg.nameBacking=v end);y=y-42
    if id=="PartyRaid" then
        self:Check("nativeGroups","Use native raid subgroup assignment",cfg.nativeGroups,0,y,function(v) cfg.nativeGroups=v end);y=y-42
        self:Check("groupTitles","Show subgroup headings",cfg.groupTitles,0,y,function(v) cfg.groupTitles=v end);y=y-42
        self:Text("nativeGroupHelp","Native subgroup headers keep members in their actual raid group, including roster changes in combat. Enable outside combat. Unsupported header paths retain the fixed-roster fallback. Compact presets reserve space for all eight groups.",0,y,self.cw,11);y=y-100
        self:Check("compactRaid","Compact raid cells (no names or percentages)",cfg.compactRaid,0,y,function(v) cfg.compactRaid=v end);y=y-42
        for _,count in ipairs({10,20,40}) do
            self:Button("compactRaid"..count,"Stage Raid "..count,0,y,self.cw,function() self:StageGroupLayout("compact",count) end);y=y-40
        end
    end
    for _,row in ipairs({{"showNames","Show names"},{"showPower","Show the power bar"},{"showStatus","Show offline, dead and ghost status"},{"showRoles","Show assigned roles"},{"showReady","Show ready-check responses"}}) do
        local key,label=row[1],row[2]
        self:Check("unit_"..key,label,cfg[key],0,y,function(v) cfg[key]=v end);y=y-42
    end
    self:Check("unitCast","Show a cast / channel track",cfg.showCast,0,y,function(v) cfg.showCast=v end);y=y-42
    self:Check("unitNativeAuras","Use native-managed aura rails",cfg.nativeAuras,0,y,function(v) cfg.nativeAuras=v end);y=y-42
    self:Check("unitAuras","Show debuff icons",cfg.showAuras,0,y,function(v) cfg.showAuras=v end);y=y-42
    self:Check("unitBuffs","Show helpful aura icons without numbers",cfg.showBuffs,0,y,function(v) cfg.showBuffs=v end);y=y-42
    self:Check("unitAccent","Highlight one public debuff category (candidate)",cfg.debuffAccent,0,y,function(v) cfg.debuffAccent=v end);y=y-42
    self:Slider("unitAuraSlots","Maximum debuff icons",0,y,self.cw,cfg.auraSlots,2,8,1,function(v) cfg.auraSlots=v end);y=y-68
    self:Text("unitExtraHint","Native aura mode lets the game display supported icons and timers without MirageUI inspecting their contents; its perimeter stays neutral. The public-data mode omits restricted entries and highlights only one unambiguous category. Bleed is never guessed. Cast progress is native; secure layouts reserve space for it before combat. Keep room around the frame.",0,y,self.cw,11);y=y-105
    if id=="PartyRaid" then
        self:Text("nativeGroupHelp","Native subgroup headers keep members in their actual raid group, including roster changes in combat. Enable outside combat. Unsupported header paths retain the fixed-roster fallback. Compact presets reserve space for all eight groups.",0,y,self.cw,11);y=y-100
        self:Text("groupGrid","Group arrangement",0,y-8,self.cw,16);y=y-48
        self:Slider("groupColumns","Raid columns",0,y,self.cw,cfg.raidColumns,2,8,1,function(v) cfg.raidColumns=v end);y=y-68
        self:Slider("groupWidth","Frame width",0,y,self.cw,cfg.cellWidth,90,220,1,function(v) cfg.cellWidth=v end);y=y-68
        self:Slider("groupHeight","Frame height",0,y,self.cw,cfg.cellHeight,32,90,1,function(v) cfg.cellHeight=v end);y=y-68
        self:Slider("groupGap","Space between frames",0,y,self.cw,cfg.cellGap,0,16,1,function(v) cfg.cellGap=v end);y=y-68
        self:Button("arrangeParty","Stage a party column",0,y,self.cw,function()
            self:StageGroupLayout("party")
        end);y=y-40
        self:Button("arrangeRaid","Stage a raid grid",0,y,self.cw,function()
            self:StageGroupLayout("raid")
        end);y=y-44
        self:Text("groupGridHint","Arrangement is deliberate: these buttons stage positions in this draft; Apply saves them. Cancel discards them. The grid preserves unit-slot order, fits as one block, and refuses an oversized arrangement instead of overlapping frames. It does not sort players by role or health.",0,y,self.cw,11);y=y-105
    end
    self:Button("unitLayout","Move or resize frames in Unlock Mode",0,y,self.cw,function() M.Editor:Open() end);y=y-42
    self:Button("unitClickCasting","Open the game's click-casting settings",0,y,self.cw,function()
        local ok,message=M.ClickCasting:Open();self:Notice(message)
    end);y=y-44
    self:Text("unitClickInfo",M.ClickCasting:Describe(),0,y,self.cw,11);y=y-95
    self:Text("unitBoundary","Blizzard's original unit/group controls stay available. Native click-casting bindings are managed by the game, not copied into MirageUI profiles. The secure unit-button handler is not replaced. Roles are not inferred from class; unknown status is omitted. No smart healing, dispel priority or combat layout rearrangement is added.",0,y,self.cw,11)
end
function O:RenderNameplateOptions(cfg)
    local y=-143
    self:Check("plateCards","Use independent Mirage nameplate cards",cfg.cards,0,y,function(v) cfg.cards=v end);y=y-46
    self:Text("plateCardExplain","Blizzard draws overhead names and guild tags at the distance allowed by the game. Attackable units keep their plates. Selecting a friendly unit requests its plate. Plate distance and debuffs are independent of overhead names. Apply outside combat.",0,y,self.cw,11);y=y-140
    if cfg.cards then
        self:Check("cardAuras","Show debuffs and important short buffs",cfg.cardAuras,0,y,function(v) cfg.cardAuras=v end);y=y-42
        self:Check("cardCast","Show cast / channel row",cfg.cardCast,0,y,function(v) cfg.cardCast=v end);y=y-42
        self:Check("cardPercent","Show native percentage labels",cfg.cardPercent,0,y,function(v) cfg.cardPercent=v end);y=y-42
        self:Check("cardNameBacking","Add neutral backing behind names",cfg.nameBacking,0,y,function(v) cfg.nameBacking=v end);y=y-42
        self:Slider("cardWidth","Card width",0,y,self.cw,cfg.cardWidth,180,360,1,function(v) cfg.cardWidth=v end);y=y-68
        self:Slider("cardScale","Card scale (%)",0,y,self.cw,cfg.cardScale,60,160,1,function(v) self:SetNameplateScale(cfg,v) end);y=y-68
        self:Slider("cardOffset","Vertical offset",0,y,self.cw,cfg.cardOffsetY,-80,80,1,function(v) cfg.cardOffsetY=v end);y=y-68
        self:Slider("cardIcons","Aura icon size",0,y,self.cw,cfg.cardIconSize,16,36,1,function(v) cfg.cardIconSize=v end);y=y-68
        self:Text("cardAuraCount","Debuffs fit six to eight per row and wrap upward, up to 40 per plate. Important short offensive and defensive buffs appear to its right.",0,y,self.cw,11);y=y-68
        self:Slider("cardLimit","Maximum simultaneous Mirage cards",0,y,self.cw,cfg.cardLimit,16,80,1,function(v) cfg.cardLimit=v end);y=y-68
        self:Text("cardLimitHint","Beyond this limit, native plates stay visible. Debuffs receive countdown labels. Raid markers, native crowd-control cues and special widgets remain available. Native hit regions stay under the game's control; visible distance remains limited by the client.",0,y,self.cw,11);y=y-110
    else
        self:Check("plateSubtle","Use the shared Subtle Minimal surface",cfg.subtle,0,y,function(v) cfg.subtle=v end);y=y-42
        self:Check("plateAccent","Accent eligible nameplates",cfg.style,0,y,function(v) cfg.style=v end);y=y-42
        self:Check("plateCompact","Use compact native nameplate styling",cfg.compact,0,y,function(v) cfg.compact=v end);y=y-42
        self:Check("plateDetails","Show native-backed level, resource and percentages",cfg.extended,0,y,function(v) cfg.extended=v end);y=y-42
        self:Check("plateDetailPercent","Show supported nameplate percentages",cfg.showPercent,0,y,function(v) cfg.showPercent=v end);y=y-42
        self:Check("plateDetailLevel","Show nameplate level",cfg.showLevel,0,y,function(v) cfg.showLevel=v end);y=y-42
        self:Check("plateFlat","Use flat health and cast textures",cfg.flatBars,0,y,function(v) cfg.flatBars=v end);y=y-46
        self:Slider("plateHealth","Health bar height",0,y,self.cw,cfg.healthHeight,8,28,1,function(v) cfg.healthHeight=v end);y=y-68
        self:Slider("plateCast","Cast bar height",0,y,self.cw,cfg.castHeight,5,20,1,function(v) cfg.castHeight=v end);y=y-68
    end
    self:Slider("platePanelOpacity","Panel opacity",0,y,self.cw,cfg.panelOpacity,0,100,1,function(v) cfg.panelOpacity=v end);y=y-68
    self:Slider("plateName","Name text size",0,y,self.cw,cfg.nameSize,9,18,1,function(v) cfg.nameSize=v end);y=y-68
    self:Text("plateBoundary","Mirage card names use plain, unoutlined letters. The card name size does not change Blizzard world-name text. Native targeting remains available. Disabling restores only properties still owned by MirageUI; another owner's changes are kept.",0,y,self.cw,11)
end
function O:RenderTooltipOptions(cfg)
    self:Check("tipAccent","Use Mirage tooltip appearance",cfg.style,0,-185,function(v) cfg.style=v end)
    self:Check("tipAnchor","Use a fixed world-tooltip location",cfg.fixedAnchor,0,-227,function(v) cfg.fixedAnchor=v;if v then cfg.cursorAnchor=false end end)
    self:Check("tipCursor","Use cursor-right placement outside combat",cfg.cursorAnchor,0,-269,function(v) cfg.cursorAnchor=v;if v then cfg.fixedAnchor=false end end)
    self:Slider("tipCursorOffset","Cursor-right offset (UI units)",0,-315,self.cw,cfg.cursorOffset,0,200,1,function(v) cfg.cursorOffset=v end)
    self:Check("tipAvoidMeters","Keep default tooltips clear of Meters",cfg.avoidMeters~=false,0,-389,function(v) cfg.avoidMeters=v end)
    self:Slider("tipScale","Tooltip size (%)",0,-439,self.cw,cfg.tooltipScale or 100,70,160,5,function(v) cfg.tooltipScale=v end)
    self:Button("tipLayout","Move or size Tooltips in Customize UI",0,-519,self.cw,function() M.ElementMap:Open("Tooltips.anchor") end)
    self:Text("tipBoundary","Moving the anchor selects a fixed world-tooltip position. Placement and size apply outside combat. Native content, item comparisons, links and control-specific anchors remain available. Insight detail settings remain in Insight.",0,-569,self.cw,11)
end
function O:RenderBagOptions(cfg)
    self:Check("bagStyle","Accent native bags and bank",cfg.style,0,-185,function(v) cfg.style=v end)
    self:Check("bagBrowser","Enable the inventory browser",cfg.browser,0,-227,function(v) cfg.browser=v end)
    self:Text("bagDescription","A searchable, paginated view of carried items and accessible character/account bank tabs. Search by public item name or exact item ID; use bag order or name order. It does not move, sell, equip, use or destroy items. Native bags and bank remain available.",0,-275,self.cw,12)
    local y=-380
    self:Slider("bagColumns","Icons per row",0,y,self.cw,cfg.columns,4,12,1,function(v) cfg.columns=v end);y=y-68
    self:Slider("bagIconSize","Icon size",0,y,self.cw,cfg.iconSize,24,52,1,function(v) cfg.iconSize=v end);y=y-68
    self:Button("bagOpen","Open the applied inventory browser",0,y,self.cw,function() local ok,msg=M.modules.Bags:OpenBrowser();self:Notice(msg) end);y=y-42
    self:Button("bagNative","Open native bags",0,y,self.cw,function() M.modules.Bags:OpenNativeBags() end);y=y-44
    self:Text("bagHint","Apply before opening the browser. /mirage bags is another way to open it. It closes in combat and keeps no inventory history. A missing item cache is shown as an item ID until the game supplies a name. Choose a bank source inside the browser while the native bank is open. Closing the bank immediately clears its snapshot; unsupported bank types remain with the native UI.",0,y,self.cw,11)
end
function O:RenderMeterOptions(cfg)
    local y=-185
    for _,row in ipairs({{"metersEnabled","Show Meters"},{"meterFirstName","Show first character name"},{"meterClassColors","Use class colors"},{"meterPinPlayer","Keep my row visible"},{"meterReplaceNative","Replace game meter window"}}) do
        local key,label=row[1],row[2]
        self:Check(key,label,cfg[key]~=false,0,y,function(v) cfg[key]=v end);y=y-44
    end
    self:Slider("meterRows","Visible rows",0,y,self.cw,cfg.meterRows or 8,3,15,1,function(v) cfg.meterRows=v end);y=y-70
    self:Button("meterOpen","Open Meters",0,y,self.cw,function() if M.Rework and M.Rework.CombatMeters then M.Rework.CombatMeters:Open() end end);y=y-42
    self:Button("meterLayout","Move or resize Meters",0,y,self.cw,function() M.ElementMap:Open("DamageMeters.mirage") end);y=y-46
    self:Text("meterHint","Choose a measure or fight from the meter header. Select a player to inspect their abilities. Collection and fight transitions are managed automatically.",0,y,self.cw,11)
end
function O:RenderSpecialModule(id,cfg)
    if id=="Nameplates" then self:RenderNameplateOptions(cfg)
    elseif id=="Tooltips" then self:RenderTooltipOptions(cfg)
    elseif id=="Bags" then self:RenderBagOptions(cfg)
    elseif id=="DamageMeters" then self:RenderMeterOptions(cfg)
    elseif id=="Cooldowns" then self:RenderCooldownOptions(cfg)
    elseif id=="Auras" then self:RenderAuraOptions(cfg)
    elseif id=="ActionBars" then self:RenderActionOptions(cfg)
    elseif id=="ResourceBars" then self:RenderResourceOptions(cfg)
    elseif id=="QuestTracker" then self:RenderQuestOptions(cfg)
    elseif id=="UnitFrames" or id=="PartyRaid" then self:RenderUnitOptions(id,cfg)
    else return false end
    return true
end
