local M=MirageUI
if not M or not M.Options then return end
local O,U=M.Options,M.UI
-- Authored samples only. Both preview entry points use the same renderer and
-- current draft; no live unit/quest/aura state is inspected or modified.
local L={scenes={"Idle","Moving","Combat","Interaction"}}
M.LayoutPreview=L
local function text(parent,caption,x,y,w,size)
 local t=U:Text(parent,caption,x,y,size or 10,w);return t
end
local function card(parent,w,h,label,glyph)
 local f=U:Card(parent,w,h);f.caption=text(f,M.Icons and glyph and M.Icons:Label(glyph,label,14) or label,4,-4,w-8,10);return f
end
local function sampleUnit(parent,label)
 local f=card(parent,100,38,label,"unit-frames")
 f.health=U:Bar(f,4,-18,92,6,0,.98,.67);f.health:SetMinMaxValues(0,1);f.health:SetValue(.74)
 f.power=U:Bar(f,4,-28,92,4,0,.78,1);f.power:SetMinMaxValues(0,1);f.power:SetValue(.60)
 return f
end
function L:Create(parent,width,height,profile)
 local f=CreateFrame("Frame",nil,parent,"BackdropTemplate");f:SetSize(width,height);U:Backdrop(f,true);M.Safety:Passive(f)
 local v={frame=f,scene=1,profile=profile,parts={},time=0};local p=v.parts
 v.title=text(f,M.Icons and M.Icons:Label("mirageui-options","LAYOUT PREVIEW",18) or "LAYOUT PREVIEW",12,-12,width-24,12);U:SetTextRole(v.title,"accent")
 v.caption=text(f,"Sample data · Idle",12,-34,width-24,10)
 v.canvas=CreateFrame("Frame",nil,f,"BackdropTemplate");U:Backdrop(v.canvas,true);M.Safety:Passive(v.canvas)
 v.canvas:SetPoint("TOPLEFT",10,-58);v.canvas:SetPoint("BOTTOMRIGHT",-10,86)
 p.map=card(v.canvas,60,60,"Map","minimap");p.quests=card(v.canvas,60,68,"Quests","objectives")
 p.questLines=text(p.quests,"Sample quest\n  2 / 4 items\nExplore the area",4,-22,52,9)
 p.player=sampleUnit(v.canvas,"Player");p.target=sampleUnit(v.canvas,"Target");p.pet=card(v.canvas,70,19,"Pet")
 p.cast=U:Bar(v.canvas,0,0,150,8,1,.73,.17);p.cast:SetMinMaxValues(0,1);p.cast:SetValue(.6)
 p.actions={};for i=1,6 do
  p.actions[i]=card(v.canvas,20,20,tostring(i));p.actions[i]:SetBackdropBorderColor(1,.58,.16,.7)
 end
 p.buffs={};for i=1,3 do
  p.buffs[i]=card(v.canvas,16,16,"+");p.buffs[i]:SetBackdropBorderColor(.28,.7,.75,.7)
 end
 p.chat=card(v.canvas,100,42,"Chat","chat")
 p.progress=U:Bar(v.canvas,0,0,60,4,.1,.65,.83);p.progress:SetMinMaxValues(0,1);p.progress:SetValue(.6)
 p.menu=card(v.canvas,72,20,"Menu / bags")
 p.cursor=v.canvas:CreateTexture(nil,"OVERLAY");p.cursor:SetTexture("Interface\\AddOns\\MirageUI\\Media\\Mark.tga");p.cursor:SetSize(16,16)
 v.note=text(f,"",12,-height+74,width-24,10);v.note:SetHeight(64)
 function v:Layout()
  local w,h=self.frame:GetWidth(),self.frame:GetHeight();local cw,ch=w-20,math.max(180,h-144)
  self.title:SetWidth(w-24);self.caption:SetWidth(w-24);self.note:SetWidth(w-24)
  self.note:ClearAllPoints();self.note:SetPoint("BOTTOMLEFT",12,10)
  local mapWidth=math.min(cw*.30,106);local unitWidth=math.min(150,(cw-20)/2)
  local function at(obj,point,x,y,sw,sh)
   obj:ClearAllPoints();obj:SetPoint(point,self.canvas,point,x,y)
   if sw then obj:SetSize(sw,sh) end
  end
  at(p.map,"TOPRIGHT",-6,-6,mapWidth,mapWidth)
  at(p.progress,"TOPRIGHT",-6,-mapWidth-12,mapWidth,4)
  at(p.quests,"TOPRIGHT",-6,-mapWidth-22,mapWidth,math.min(85,ch*.28))
  p.map.caption:SetWidth(mapWidth-8);p.quests.caption:SetWidth(mapWidth-8);p.questLines:SetWidth(mapWidth-8)
  at(p.player,"BOTTOMLEFT",4,106,unitWidth,38);at(p.target,"BOTTOMRIGHT",-4,106,unitWidth,38)
  for _,unit in ipairs({p.player,p.target}) do unit.caption:SetWidth(unitWidth-8);unit.health:SetWidth(unitWidth-8);unit.power:SetWidth(unitWidth-8) end
  at(p.pet,"BOTTOMLEFT",4,78,math.min(70,unitWidth),19)
  at(p.cast,"BOTTOM",0,60,math.min(cw-16,220),8)
  local size=math.min(28,(cw-30)/6)
  for i,button in ipairs(p.actions) do at(button,"BOTTOMLEFT",(cw-6*(size+3)+3)/2+(i-1)*(size+3),18,size,size) end
  local auraSize=math.min(24,cw*.085)
  for i,button in ipairs(p.buffs) do at(button,"TOPLEFT",4+(i-1)*(auraSize+3),-8,auraSize,auraSize) end
  at(p.chat,"BOTTOMLEFT",4,75,math.min(110,cw*.48),42)
  at(p.menu,"BOTTOMLEFT",4,18,math.min(90,cw*.48),20)
  at(p.cursor,"CENTER",-cw*.12,8)
 end
 function v:Refresh()
  self:Layout()
  local profile=self.profile() or M.profile;local scene=L.scenes[self.scene]
  self.caption:SetText("Sample data · "..scene)
  local function visible(module,wanted)
   local cfg=profile.modules[module]
   if not profile.enabled or not cfg or not cfg.enabled then return false end
   if cfg.visibility=="Always" then return true end
   if cfg.visibility=="Manual" then return scene=="Interaction" end
   if profile.preset=="Always Informed" or profile.preset=="Accessibility" then return true end
   return wanted
  end
  local combat=scene=="Combat";local moving=scene=="Moving";local task=scene=="Interaction"
  p.map:SetShown(visible("Minimap",moving or combat or task))
  p.quests:SetShown(visible("QuestTracker",moving or task))
  p.map.caption:SetText(M.Icons and M.Icons:Label("minimap",profile.modules.Minimap.square and "Square map" or "Map",14) or (profile.modules.Minimap.square and "Square map" or "Map"))
  p.player:SetShown(visible("UnitFrames",combat));p.target:SetShown(visible("UnitFrames",combat));p.pet:SetShown(visible("UnitFrames",combat))
  p.cast:SetShown(visible("UnderCharacterHUD",combat));p.chat:SetShown(visible("Chat",task))
  p.progress:SetShown(visible("Minimap",moving or combat or task))
  p.menu:SetShown(visible("ActionBars",task))
  for _,b in ipairs(p.actions) do b:SetShown(visible("ActionBars",combat)) end
  for _,b in ipairs(p.buffs) do b:SetShown(visible("Auras",combat or task)) end
  p.cursor:SetShown(visible("Cursor",scene~="Idle"))
  local descriptions={Idle="No target or interaction: displays recede. Move the mouse to wake the cursor.",Moving="A square map and aligned quest column support travel. Combat controls stay quiet.",Combat="Combat, a target, or focus reveals combat controls. The game still owns spells and unit clicks.",Interaction="Open panels, reveal and editing keep controls accessible until you finish."}
  self.note:SetText(descriptions[scene].."\nSample layout, not live gameplay.")
 end
 function v:Next() self.scene=self.scene%#L.scenes+1;self:Refresh() end
 f:SetScript("OnUpdate",function(_,dt)
  if L.window and L.window:IsShown() and (M.state.safe or M.Safety:InCombat()) then L.window:Hide() end
  if not M.Safety:Number(dt) then return end
  v.time=(v.time+math.min(dt,.1))%2
  if L.scenes[v.scene]=="Combat" then p.cast:SetValue(v.time/2) end
 end)
 v:Refresh();return v
end
function O:CreatePreview(width,height)
 self.layoutPreview=L:Create(self.frame,205,height-214,function() return self.draft or M.profile end)
 self.preview=self.layoutPreview.frame;self.preview:SetPoint("TOPRIGHT",-20,-108)
 self.previewTitle=self.layoutPreview.title;self.previewCaption=self.layoutPreview.caption;self.previewExplanation=self.layoutPreview.note
 local p=self.layoutPreview.parts
 self.previewMap=p.map;self.previewTarget=p.target;self.previewCast=p.cast;self.previewChat=p.chat;self.previewAction=p.actions;self.previewCursor=p.cursor
 self.previewScene=1
 self.previewButton=U:Button(self.frame,"Next preview scene",width-225,-height+93,205,function()
  self.previewScene=(self.previewScene or 1)%#L.scenes+1;self:UpdatePreview()
 end)
end
function O:UpdatePreview()
 if not self.layoutPreview then return end
 self.layoutPreview.scene=self.previewScene or 1;self.layoutPreview:Refresh()
end
function L:Open()
 if M.Safety:InCombat() then return false,"Open the layout preview outside combat." end
 if not self.window then
  local f=U:Panel("MirageLayoutPreview","MirageUI layout preview",880,660);self.window=f;self.frame=f
  self.view=self:Create(f,832,545,function() return M.profile end);self.view.frame:SetPoint("TOPLEFT",24,-58)
  self.next=U:Button(f,"Next scene",24,-616,180,function() self.view:Next() end)
  f:SetFrameStrata("FULLSCREEN_DIALOG");f:SetClampedToScreen(true)
  M:TrackRoot("Options",f,true)
  if UISpecialFrames then table.insert(UISpecialFrames,"MirageLayoutPreview") end
 end
 local w=M.Safety:Public(UIParent.GetWidth,"number",UIParent) or 1024
 local h=M.Safety:Public(UIParent.GetHeight,"number",UIParent) or 768
 self.window:SetScale(math.min(1,(w-24)/880,(h-24)/660))
 self.view:Refresh();self.window:Show();return true,"The preview uses sample data and your current preferences."
end
