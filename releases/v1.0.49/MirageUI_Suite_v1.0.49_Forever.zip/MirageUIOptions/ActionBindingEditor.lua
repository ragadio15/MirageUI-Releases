local M=MirageUI
if not M or not M.Options then return end
local U,K,S=M.UI,M.ActionKeys,M.Safety
local B={bar=1,slot=1}
M.BindingEditor=B
function B:KeysService() return self.service or K end
function B:SelectedCommand() return self.customCommand or K:Command(self.bar,self.slot) end
local barNames={"Main bar","Second bar","Third bar","Right bar","Left bar","Action bar 6","Action bar 7","Action bar 8"}
function B:Alive()
    local session,service,owner=self.session,self:KeysService(),self.owner
    if not session or not self.frame or not self.frame:IsVisible() or M.DialogNavigation.top~=self.frame then return false end
    if not service:Allowed() or (owner and owner.ownerCurrent and not owner.ownerCurrent(session)) then return false end
    return self.session==session and self:KeysService()==service and self.owner==owner
end
function B:Busy() return self.arm or self.listening or self.releaseKey end
function B:Passive()
    if self.frame and not S:InCombat() then
        self.frame:EnableKeyboard(true);self.frame:SetPropagateKeyboardInput(true)
    end
end
function B:Close()
    if self.closing then return end
    self.closing=true
    local session,owner,service=self.session,self.owner,self:KeysService()
    self.arm=nil;self.listening=false;self.releaseKey=nil;self.releaseObserved=nil;self.captureSubject=nil;self.ignoredKeys=nil;self.pendingMouse=nil;self.session=nil;self.owner=nil
    service:Cancel();U:CloseChoices()
    if M.DialogNavigation.active==self.frame then M.DialogNavigation:Stop() end
    if self.frame then self.frame:EnableKeyboard(false);self.frame:EnableMouseWheel(false);self.frame:Hide() end
    self.closing=nil
    if session and owner and owner.onClosed then owner.onClosed(session) end
end
function B:Notice(message)
    if self.notice then self.notice:SetText(message or "") end
end
function B:Refresh()
    if not self.frame then return end
    local refreshSession,refreshService=self.session,self:KeysService()
    local command=self:SelectedCommand()
    self.barButton:SetText(self.customCommand and self:KeysService():ActionLabel(self.customCommand) or barNames[self.bar])
    local busy=self:Busy()~=nil and self:Busy()~=false
    self.barButton:SetEnabled(not self.customCommand and not busy);self.slotButton:SetEnabled(not busy);self.slotButton:SetShown(not self.customCommand)
    self.slotButton:SetText("Button "..self.slot)
    local keys,why=refreshService:Keys(command)
    if self.session~=refreshSession or self:KeysService()~=refreshService then return end
    self.assigned=keys or {}
    local labels={};for _,key in ipairs(self.assigned) do labels[#labels+1]=self:KeysService():Label(key) end
    self.current:SetText("Current shortcuts: "..(#labels>0 and table.concat(labels,", ") or why or "None"))
    self.remove:SetEnabled(#self.assigned>0 and not busy);self.capture:SetEnabled(not busy);self.navStart:SetEnabled(not busy)
    local plan=self:KeysService().plan
    self.save:SetShown(plan~=nil);self.save:SetEnabled(not busy)
    self.restore:SetEnabled(#self:KeysService().history>0 and not busy)
    if plan then
        local action=plan.after=="" and "Remove" or "Assign"
        self.review:SetText(action.." "..self:KeysService():Label(plan.key).."\nFrom: "..self:KeysService():ActionLabel(plan.before).."\nTo: "..self:KeysService():ActionLabel(plan.after))
        self.save:SetText(plan.after=="" and "Confirm removal" or plan.before~="" and "Replace assignment" or "Save shortcut")
    else self.review:SetText(self.arm and "Release the activation button before capture begins. Escape or controller B cancels." or self.listening and "Press a key, or use the mouse capture area below.\nEscape cancels capture; normal left/right clicks are not assignable." or "Capture a shortcut to review it before saving. F6 starts navigation; no shortcut is assigned automatically.") end
    local session,service,plan=self.session,self:KeysService(),self:KeysService().plan
    local selection=self.selection
    for _,action in ipairs(self.actions or {}) do
        action.frame:SetScript("OnClick",function(...)
            if not self:Alive() or self.session~=session or self:KeysService()~=service then return end
            if not action.allowBusy and (self:Busy() or self.selection~=selection) then return end
            action.callback(...)
        end)
    end
    self.save:SetScript("OnClick",function()
        if not self:Alive() or self:Busy() or self.session~=session or self:KeysService()~=service or service.plan~=plan or not plan then return end
        local ok,message=service:Commit(true);if self.session~=session or self:KeysService()~=service then return end;self:Refresh();self:Notice(message)
    end)
    local last=service.history[#service.history]
    self.restore:SetScript("OnClick",function()
        if not self:Alive() or self:Busy() or self.session~=session or self:KeysService()~=service or service.history[#service.history]~=last or not last then return end
        local ok,message=service:Restore();if self.session~=session or self:KeysService()~=service then return end;self:Refresh();self:Notice(message)
    end)
    M.DialogNavigation:Refresh(self.frame)
end
function B:Select(bar,slot)
    local session=self.session
    if not self:Alive() or self:Busy() or self.session~=session then return false end
    local newBar,newSlot=bar or self.bar,slot or self.slot
    if not K:Command(newBar,newSlot) then return false end
    self:KeysService():Cancel();self.bar=newBar;self.slot=newSlot;self.selection={}
    self:Passive();self:Notice("");self:Refresh();return true
end
function B:TypingHandoff()
    self.arm=nil;self.listening=false;self.releaseKey=nil;self.releaseObserved=nil;self.captureSubject=nil;self.ignoredKeys=nil;self.pendingMouse=nil
    self:KeysService():Cancel()
    if M.DialogNavigation.active==self.frame then M.DialogNavigation:Stop() end
    self:Passive();self:Refresh();self:Notice("Text entry owns input. Capture cancelled; leave text entry before starting again.")
end
function B:BeginCapture()
    local subject=self.captureSubject
    if not subject then return false end
    if not self:Alive() or subject.session~=self.session or subject.service~=self:KeysService() or subject.command~=self:SelectedCommand() then
        if self.session==subject.session then self:Close() end;return false
    end
    if S:Typing() then if self.session==subject.session then self:TypingHandoff() end;return false end
    if self.session~=subject.session or self.captureSubject~=subject or self:KeysService()~=subject.service or self:SelectedCommand()~=subject.command then return false end
    self.ignoredKeys={};for key in pairs(M.DialogNavigation.pressed[self.frame] or {}) do self.ignoredKeys[key]=true end
    self.arm=nil
    if M.DialogNavigation.active==self.frame then M.DialogNavigation:Stop() end
    self.listening=true;self.frame:EnableKeyboard(true);self.frame:SetPropagateKeyboardInput(false)
    self:Notice("Capture is active. Escape cancels; no shortcut changes until explicit Save.");self:Refresh();return true
end
function B:StartCapture()
    local session,service,command=self.session,self:KeysService(),self:SelectedCommand()
    if not self:Alive() or self:Busy() or self.session~=session then return false end
    if S:Typing() then if self.session==session then self:Notice("Leave text entry before capturing a shortcut.") end;return false end
    if self.session~=session or self:KeysService()~=service or self:SelectedCommand()~=command then return false end
    service:Cancel();U:CloseChoices()
    if self.session~=session or self:KeysService()~=service or self:SelectedCommand()~=command then return false end
    self.captureSubject={session=session,service=service,command=command}
    local dispatch=M.DialogNavigation.dispatch
    if dispatch and dispatch.panel==self.frame and M.DialogNavigation.active==self.frame then
        self.arm={key=dispatch.key,controller=dispatch.controller}
        self:Notice("Release the activation button. Escape or controller B cancels.");M.DialogNavigation:Highlight(nil);self:Refresh();return true
    end
    return self:BeginCapture()
end
-- Capture belongs to one exact session/command, including across native getters.
function B:CaptureCurrent(subject)
    if not subject or not self.listening or self.captureSubject~=subject then return false end
    if not self:Alive() then
        if self.session==subject.session then self:Close() end
        return false
    end
    if S:Typing() then
        if self.session==subject.session then self:TypingHandoff() end
        return false
    end
    return self.session==subject.session and self:KeysService()==subject.service and self:SelectedCommand()==subject.command and self.captureSubject==subject and self.listening
end
function B:AcceptInput(subject,key,reason,release)
    if not self:CaptureCurrent(subject) then return false end
    if reason~="CANCEL" and (not key or not subject.service:KeyValid(key)) then return false end
    if not self:CaptureCurrent(subject) then return false end
    self.pendingMouse=nil;self.listening=false;self.releaseKey=release
    if not self.releaseKey then self:Passive() end
    if reason=="CANCEL" then
        subject.service:Cancel();self:Refresh();self:Notice("Capture cancelled. No shortcut changed. F6 restarts navigation.");return true
    end
    local ok,message=subject.service:Prepare(subject.command,key,false)
    if self.session~=subject.session or self:KeysService()~=subject.service then return false end
    self:Refresh();self:Notice(message);return true
end
function B:Input(value,fromKeyboard)
    local subject=self.captureSubject
    if not self:CaptureCurrent(subject) then return false end
    local key,reason=subject.service:Capture(value)
    return self:AcceptInput(subject,key,reason,fromKeyboard and value or nil)
end
local function MouseToken(button)
    if not S:Text(button) then return end
    if button=="MiddleButton" then return "BUTTON3" end
    local number=tonumber(button:match("^Button(%d+)$"))
    if number and number>=3 and number<=31 then return "BUTTON"..number end
end
function B:MouseDown(button,session)
    if self.session~=session then return false end
    local subject=self.captureSubject
    self.pendingMouse=nil
    if not self:CaptureCurrent(subject) then return false end
    local token=MouseToken(button);if not token then return false end
    local key=subject.service:Capture(token)
    if not key or not self:CaptureCurrent(subject) then return false end
    self.pendingMouse={button=button,key=key,subject=subject};return true
end
function B:MouseUp(button,session)
    if self.session~=session then return false end
    local pending=self.pendingMouse;self.pendingMouse=nil
    if not pending or pending.button~=button then return false end
    return self:AcceptInput(pending.subject,pending.key)
end
function B:BindMouse()
    local session=self.session
    self.mouse:SetScript("OnMouseDown",function(_,button) return self:MouseDown(button,session) end)
    self.mouse:SetScript("OnMouseUp",function(_,button) return self:MouseUp(button,session) end)
    self.mouse:SetScript("OnMouseWheel",function(_,delta)
        if self.session==session and S:Number(delta) and delta~=0 then self:Input(delta>0 and "MOUSEWHEELUP" or "MOUSEWHEELDOWN") end
    end)
end
function B:InputDown(key,controller)
    local session=self.session
    if not self:Alive() or self.session~=session then return nil end
    if self:Busy() and S:Typing() then if self.session==session then self:TypingHandoff() end;return false end
    if self.session~=session then return false end
    if self.arm then
        if key=="ESCAPE" or (controller and key=="PAD2") then
            self.arm.cancel=true
            if not self.arm.cancelKey then self.arm.cancelKey=key;self.arm.cancelController=controller end
        end
        return true
    end
    if self.releaseKey then return true end
    if self.listening then
        if self.ignoredKeys and self.ignoredKeys[key] then return true end
        -- Navigation never grants a gamepad-binding provider. Only the existing
        -- keyboard capture and explicit mouse area enter the binding service.
        if not controller then self:Input(key,true) end
        return true
    end
end
function B:InputUp(key,controller)
    if self.arm then
        if self.arm.key==key and self.arm.controller==controller then self.arm.released=true end
        if self.arm.cancelKey==key and self.arm.cancelController==controller then self.arm.cancelReleased=true end
        return true
    end
    if self.releaseKey then if not controller and self.releaseKey==key then self.releaseObserved=true end;return true end
    if self.listening then if self.ignoredKeys then self.ignoredKeys[key]=nil end;return true end
end
function B:Create()
    if self.frame then return end
    local width,height=570,560
    local f=U:Panel("MirageUIActionBindingEditor","Action shortcuts",width,height);self.frame=f
    f:SetFrameStrata("FULLSCREEN_DIALOG")
    local scale=math.min(1,(UIParent:GetWidth()-30)/width,(UIParent:GetHeight()-30)/height)
    f:SetSize(width,height);f:SetScale(math.max(.2,scale))
    f.heading:SetWidth(345)
    self.navStart=U:Button(f,"Controller / F6",365,-12,155,function()
        if self:Alive() and not self:Busy() then M.DialogNavigation:Start(f,true) end
    end)
    self.description=U:Text(f,"These shortcuts control the matching native action buttons too. They are saved separately from MirageUI layouts. Nothing is assigned automatically.",20,-55,12,530)
    self.barButton=U:Button(f,"",20,-120,250,function(button)
        if not self:Alive() or self:Busy() then return end
        local session=self.session
        local choices={};for i,name in ipairs(barNames) do choices[#choices+1]={value=i,label=name} end
        U:Choose(button,choices,self.bar,function(value) if self.session==session then self:Select(value,nil) end end)
    end)
    self.slotButton=U:Button(f,"",282,-120,268,function(button)
        if not self:Alive() or self:Busy() then return end
        local session=self.session
        local choices={};for i=1,12 do choices[#choices+1]={value=i,label="Button "..i} end
        U:Choose(button,choices,self.slot,function(value) if self.session==session then self:Select(nil,value) end end)
    end)
    self.current=U:Text(f,"",20,-162,12,530);self.current:SetHeight(50)
    self.capture=U:Button(f,"Capture shortcut",20,-215,250,function() self:StartCapture() end)
    self.remove=U:Button(f,"Remove one shortcut",282,-215,268,function(button)
        if not self:Select() then return end
        local session,service,command,selection=self.session,self:KeysService(),self:SelectedCommand(),self.selection
        local keys,why=service:Keys(command);if not keys or #keys==0 then self:Notice(why or "No shortcut to remove.");return end
        local choices={};for _,key in ipairs(keys) do choices[#choices+1]={value=key,label=self:KeysService():Label(key)} end
        U:Choose(button,choices,nil,function(key)
            if not self:Alive() or self:Busy() or self.session~=session or self:KeysService()~=service or self:SelectedCommand()~=command or self.selection~=selection then return end
            local ok,message=service:Prepare(command,key,true);if self.session~=session or self:KeysService()~=service then return end;self:Refresh();self:Notice(message)
        end)
    end)
    local mouse=CreateFrame("Frame",nil,f,"BackdropTemplate");self.mouse=mouse
    mouse:SetPoint("TOPLEFT",20,-257);mouse:SetSize(530,45);U:Backdrop(mouse,true);mouse:EnableMouse(true);mouse:EnableMouseWheel(true)
    U:Text(mouse,"Mouse capture area — middle/side button or wheel",8,-14,11,514)
    self.review=U:Text(f,"",20,-317,12,530);self.review:SetHeight(67)
    self.save=U:Button(f,"Save shortcut",20,-397,250,nil)
    self.restore=U:Button(f,"Restore last shortcut change",282,-397,268,nil)
    self.notice=U:Text(f,"",20,-438,11,530);self.notice:SetHeight(52)
    self.cancel=U:Button(f,"Cancel / close",20,-512,250,function() self:Close() end)
    U:Text(f,"Restore history lasts until reload or logout.",282,-516,10,268)
    f.closeButton:SetScript("OnClick",function() self:Close() end)
    f:SetScript("OnHide",function() self:Close() end)
    self.actions={}
    for _,key in ipairs({"navStart","barButton","slotButton","capture","remove","cancel"}) do
        self.actions[#self.actions+1]={frame=self[key],callback=self[key]:GetScript("OnClick"),allowBusy=key=="cancel"}
    end
    self.actions[#self.actions+1]={frame=f.closeButton,callback=f.closeButton:GetScript("OnClick"),allowBusy=true}
    M.DialogNavigation:Attach(f,{closeOnSuspend=true,allowed=function() return self:Alive() end,
        onSuperseded=function() self:Close() end,inputDown=function(key,pad) return self:InputDown(key,pad) end,
        inputUp=function(key,pad) return self:InputUp(key,pad) end,entries=function()
            if self:Busy() then return {} end
            local rows={}
            for _,key in ipairs({"navStart","barButton","slotButton","capture","remove"}) do rows[#rows+1]={frame=self[key],key=key,kind="button",identity=(key=="capture" or key=="remove") and self.selection or self.session} end
            local service=self:KeysService()
            rows[#rows+1]={frame=self.save,key="save",kind="button",identity=service.plan}
            rows[#rows+1]={frame=self.restore,key="restore",kind="button",identity=service.history[#service.history]}
            rows[#rows+1]={frame=self.cancel,key="cancel",kind="button",identity=self.session};rows[#rows+1]={frame=f.closeButton,key="close",kind="button",identity=self.session};return rows
        end})
    local elapsed=0
    f:SetScript("OnUpdate",function(_,dt)
        if not f:IsShown() or not S:Number(dt) then return end
        local session=self.session
        if not self:Alive() then if self.session==session then self:Close() end;return end
        if self:Busy() and S:Typing() then if self.session==session then self:TypingHandoff() end;return end
        if self.session~=session then return end
        if self.arm and self.arm.released and (not self.arm.cancel or self.arm.cancelReleased) then
            if self.arm.cancel then
                self.arm=nil;self.captureSubject=nil;M.DialogNavigation:Stop();self:Passive();self:Refresh();self:Notice("Capture cancelled before listening. F6 restarts navigation.")
            else self:BeginCapture() end
        elseif self.releaseObserved then
            self.releaseObserved=nil;self.releaseKey=nil;self.captureSubject=nil;self:Passive();self:Refresh()
        end
        elapsed=elapsed+dt;if elapsed<.1 then return end;elapsed=0
        if not self:KeysService():Allowed() and self.session==session then self:Close() end
    end)
end
function B:OpenForService(service,command,title,owner)
    if self.closing then return false end
    local attempt={};self.openAttempt=attempt
    self:Close();if self.openAttempt~=attempt then return false end
    self.service=service;self.customCommand=command
    local allowed,why=service:Allowed();if self.openAttempt~=attempt then return false end
    if not allowed then M.Options:Notice(why);self.service=nil;self.customCommand=nil;return false end
    self:Create();if self.openAttempt~=attempt then return false end
    local session={};self.session=session;self.owner=owner;self:BindMouse()
    if owner and owner.onOpened then owner.onOpened(session) end
    if self.session~=session then return false end
    self.frame:Show()
    if self.session~=session or not self:Alive() then if self.session==session then self:Close() end;return false end
    self:Passive();self:Select();if self.session~=session then return false end;self.frame.heading:SetText(title or "Native shortcut")
    self.description:SetText(owner and owner.description or "A native game shortcut, separate from the cursor menu. Existing assignments require confirmation. No ping is sent by editing a shortcut.")
    self:Refresh();return self.session==session
end
function B:Open()
    if self.closing then return false end
    local attempt={};self.openAttempt=attempt
    self:Close();if self.openAttempt~=attempt then return false end
    self.service=nil;self.customCommand=nil
    local allowed,why=self:KeysService():Allowed();if self.openAttempt~=attempt then return false end
    if not allowed then M.Options:Notice(why);return false end
    self:Create();if self.openAttempt~=attempt then return false end
    local session={};self.session=session;self:BindMouse();self.frame:Show()
    if self.session~=session or not self:Alive() then if self.session==session then self:Close() end;return false end
    self:Passive();self:Select();if self.session~=session then return false end;self.frame.heading:SetText("Action shortcuts");self.description:SetText("These shortcuts also control native action buttons. They are saved separately from MirageUI layouts. Nothing is assigned automatically.");self:Refresh();return self.session==session
end
