local M=MirageUI
if not M or not M.OptionsNavigation then return end
local O,A,S,U=M.Options,M.OptionsNavigation,M.Safety,M.UI
M.AccessibleInput={status="IDLE",pressed={}}
local I=M.AccessibleInput
local staticPages={Home="Overview",Behavior="What appears when",Integration="Display ownership",Accessibility="Input and accessibility",Profiles="Profiles",Support="Help and recovery"}
local function available(f) return f and f.IsShown and f:IsShown() end
function I:Allowed()
 return not M.state.safe and not S:InCombat() and not M.state.cinematic and not A:Busy() and not S:Typing()
end
function I:Stop()
 self.active=false;self.pressed={};self.lastSpoken=nil
 self.cleanupPending=S:InCombat() and O.frame~=nil or false
 if O.frame and not S:InCombat() then
  if type(O.frame.EnableGamePadButton)=="function" then pcall(O.frame.EnableGamePadButton,O.frame,false) end
  if O.frame.SetPropagateKeyboardInput then O.frame:SetPropagateKeyboardInput(true) end
 end
end
function I:Start()
 if not self:Allowed() then return false,"Open settings outside combat and leave text entry first." end
 if not O.frame or type(O.frame.EnableGamePadButton)~="function" then return false,"Controller input is unavailable in this client." end
 local ok=pcall(O.frame.EnableGamePadButton,O.frame,true)
 if not ok then self.status="CONTROLLER_UNAVAILABLE";return false,"Controller input could not be enabled." end
 self.active=true;self.cleanupPending=false;A:Start()
 O:Notice("Controller: D-pad up/down moves, left/right adjusts numeric sliders, A selects, B backs out. Text entry uses your native keyboard. No gameplay shortcuts are changed.")
 return true
end
function I:Label(entry)
 if not entry then return "MirageUI settings" end
 -- Setup reuses the settings footer, but its actions have distinct consent.
 -- Resolve only authored labels; never read the live control or edit text.
 if O.setup then
  if entry.key=="footer:1" then return "Set up MirageUI" end
  if entry.key=="footer:2" then return "Not now" end
 end
 local label=M.AccessibleLabels[entry.key or ""]
 if label then return label end
 local module=entry.key and entry.key:match("^nav:(%w+)$")
 if module then return staticPages[module] or (M.CatalogByID[module] and M.CatalogByID[module].name) or "Settings page" end
 local choice=entry.key and tonumber(entry.key:match("^choice:(%d+)$"))
 if choice then return "Option "..choice end
 if entry.key and entry.key:match("^spell:") then return "Tracked spell input" end
 if entry.key and entry.key:match("^removeSpell:") then return "Remove tracked spell" end
 return entry.kind=="edit" and "Editable setting" or "Settings control"
end
function I:Speak(entry,explicit)
 if not self:Allowed() or not A.enabled then return false end
 local p=M.profile
 if not p.spokenLabels and not explicit then return false end
 if not C_VoiceChat or type(C_VoiceChat.SpeakText)~="function" or type(C_VoiceChat.GetTtsVoices)~="function" then self.speechStatus="NATIVE_SPEECH_UNAVAILABLE";return false end
 local label=self:Label(entry)
 if not explicit and self.lastSpoken==label then return false end
 local ok,voices=pcall(C_VoiceChat.GetTtsVoices)
 if not ok or not S:Readable(voices) or type(voices)~="table" then self.speechStatus="NO_NATIVE_VOICE";return false end
 local voice
 for i=1,64 do
  local row,status=S:Field(voices,i);if status~="KNOWN" then break end
  local id,why=S:Field(row,"voiceID")
  if why=="KNOWN" and S:Number(id) and id>=0 and id%1==0 then voice=id;break end
 end
 if not voice then self.speechStatus="NO_NATIVE_VOICE";return false end
 -- Only compile-time owned labels. No dynamic edit text, chat, names, GUIDs,
 -- resource numbers, aura data, or error payloads are passed to speech.
 local spoken=pcall(C_VoiceChat.SpeakText,voice,label,p.speechRate,p.speechVolume,false)
 self.speechStatus=spoken and "NATIVE_SPEECH_REQUESTED" or "NATIVE_SPEECH_UNAVAILABLE"
 if spoken then self.lastSpoken=label end
 return spoken
end
function I:Adjust(delta)
 local entry=A.current
 if not entry or not entry.key or not entry.key:match("^slider:") then return false end
 local f=O.pool[entry.key];local slider=f and f.slider
 if not slider or not available(f) then return false end
 local value,why=S:Public(slider.GetValue,"number",slider)
 local step,stepStatus=S:Public(slider.GetValueStep,"number",slider)
 if why~="KNOWN" or stepStatus~="KNOWN" or step<=0 then return false end
 local bounds,lo,hi=pcall(slider.GetMinMaxValues,slider)
 if not bounds or not S:Number(lo) or not S:Number(hi) or hi<lo then return false end
 local nextValue=math.max(lo,math.min(hi,value+delta*step))
 local ok=pcall(slider.SetValue,slider,nextValue)
 if ok then self:Speak(entry,true) end
 return ok
end
function I:Button(key)
 if not self.active or not self:Allowed() or not S:Text(key) then return false end
 local handled=false
 if key=="PADDUP" then handled=A:Move(-1)
 elseif key=="PADDDOWN" then handled=A:Move(1)
 elseif key=="PADDLEFT" then handled=self:Adjust(-1)
 elseif key=="PADDRIGHT" then handled=self:Adjust(1)
 elseif key=="PAD1" then handled=A:Activate()
 elseif key=="PAD2" then handled=A:Key("ESCAPE")
 elseif key=="PAD3" then handled=self:Speak(A.current,true)
 elseif key=="PADBACK" then self:Stop();A:Stop();handled=true end
 if handled then self.pressed[key]=true end
 return handled
end
local oldHighlight=A.Highlight
function A:Highlight(entry) oldHighlight(self,entry);I:Speak(entry,false) end
local oldCreate=O.Create
function O:Create()
 oldCreate(self);if self.ShellBoundary then self:ShellBoundary() end
 if self.accessibleInputHooked then return end;self.accessibleInputHooked=true
 if type(self.frame.EnableGamePadButton)=="function" then
  self:ShellCall(self.frame,"SetScript","OnGamePadButtonDown",function(f,key)
   local handled=I:Button(key)
   if not S:InCombat() and f.SetPropagateKeyboardInput then f:SetPropagateKeyboardInput(not handled) end
  end)
  self:ShellCall(self.frame,"SetScript","OnGamePadButtonUp",function(f,key)
   local consumed=S:Text(key) and I.pressed[key];if consumed then I.pressed[key]=nil end
   if not S:InCombat() and f.SetPropagateKeyboardInput then f:SetPropagateKeyboardInput(not consumed) end
  end)
 end
 local hide=self:ShellCall(self.frame,"GetScript","OnHide")
 self:ShellCall(self.frame,"SetScript","OnHide",function(...) I:Stop();if hide then hide(...) end end)
end
local oldRender=O.Render
function O:Render()
 oldRender(self);if self.ShellBoundary then self:ShellBoundary() end
 if not self.draft or not self.frame or not self:ShellCall(self.frame,"IsShown") then return end
 if I.active and not self:ShellCall(I,"Allowed") then self:ShellCall(I,"Stop") end
end
local oldOpen=O.Open
function O:Open(...)
 local result=oldOpen(self,...)
 if M.profile.gamepadNavigation and I:Allowed() then I:Start() end
 return result
end
function O:RenderAccessibility()
 local p=self.draft
 self:Text("accessHeading","Input and accessibility",0,0,self.cw,16)
 self:Text("accessScope","Settings-local navigation and native speech. Gameplay bindings, native screen narration and chat speech remain under your control. Text-entry values and game data are never narrated by MirageUI.",0,-42,self.cw,12)
 self:Check("padNavigation","Remember controller navigation for settings",p.gamepadNavigation,0,-130,function(v) p.gamepadNavigation=v end)
 self:Button("padStart","Start controller navigation for this session",0,-174,self.cw,function() local ok,why=I:Start();if not ok then self:Notice(why) end end)
 self:Check("speakLabels","Speak static setting labels while navigating",p.spokenLabels,0,-220,function(v) p.spokenLabels=v end)
 self:Slider("speechRate","Speech rate",0,-270,self.cw,p.speechRate,-10,10,1,function(v) p.speechRate=v end)
 self:Slider("speechVolume","Speech volume",0,-340,self.cw,p.speechVolume,0,100,5,function(v) p.speechVolume=v end)
 self:Button("speakSample","Speak the focused control (uses saved speech settings)",0,-410,self.cw,function() if not A.enabled then A:Start() end;I:Speak(A.current,true) end)
 self:Text("accessKeys","Keyboard: F6 starts focus navigation; Tab and Shift-Tab move; Enter selects. Controller: D-pad moves or changes slider values; A selects; B backs out; X reads; Back returns control. Apply saves the checkboxes. Native input and speech still require client validation.",0,-458,self.cw,11)
end
