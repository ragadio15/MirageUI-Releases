local _, S = ...
local D={dirty=true,bagCounts={},items={},consumables={},recipes={},stats={},values={},professions={},pending=0}
S.Data=D
local function num(v) return S:Number(v) end
local function txt(v) return S:String(v) end
local function itemID(link) return type(link)=="string" and tonumber(link:match("item:(%d+)")) or nil end
function D:Init()
    local c=S.characterDB
    if c.recipeBuild~=S.client.build or type(c.recipes)~="table" then c.recipes={} end
    c.recipeBuild=S.client.build; self.recipes=c.recipes
end
function D:RefreshStats()
    self.stats,self.values=S.Compat:Stats()
    self.professions=S.Compat:Professions()
end
function D:RefreshBags()
    self.bagCounts,self.items,self.pending=S.Compat:Bags()
    self.consumables={}
    for _,row in pairs(self.items) do
        if row.class==0 or row.itemType=="Consumable" then
            -- Inventory candidates, never advertised as universally rest-safe.
            row.details=S.Compat:TooltipLines("item",row.id)
            local spell
            if C_Spell and C_Spell.GetSpellInfo and row.spellID then spell=S:Call("GetSpellInfo",C_Spell.GetSpellInfo,row.spellID) end
            row.castMS=type(spell)=="table" and num(spell.castTime) or nil
            self.consumables[#self.consumables+1]=row
        end
    end
    table.sort(self.consumables,function(a,b)return a.name<b.name end)
    self.dirty=false; self.craftCache=nil
end
-- Item details are extracted from Blizzard tooltip data, never invented. Use the
-- native tooltip on hover for all conditions and effect text that cannot fit.
function D:ItemDescription(row)
    local lines={}
    local seen={}
    local function add(line)
        if type(line)~="string" or line=="" or line==row.name or seen[line] then return end
        seen[line]=true
        lines[#lines+1]=line
    end
    for _,line in ipairs(row.details or {}) do
        local lower=line:lower()
        if lower:find("use:",1,true) or lower:find("restores",1,true) or
           lower:find("increases",1,true) or lower:find("well fed",1,true) or
           lower:find("requires",1,true) or lower:find("duration",1,true) or
           lower:find("eat",1,true) or lower:find("drink",1,true) then
            add(line)
        end
        if #lines>=3 then break end
    end
    if #lines==0 and row.spellName then add("Use: "..row.spellName) end
    if #lines==0 then add(row.pending and "Item details are loading" or "Hover for the item's native description") end
    return table.concat(lines,"\n")
end
function D:IsUseCandidate(row)
    -- Consumable classification does not imply it actually has an on-use action.
    -- Prefer Blizzard's GetItemSpell or an explicit native tooltip Use line.
    if not row or row.pending or type(row.id)~="number" or not row.count or row.count<1 then return false end
    if not (row.class==0 or row.itemType=="Consumable") then return false end
    if row.spellID or row.spellName then return true end
    for _,line in ipairs(row.details or {}) do
        if type(line)=="string" and line:lower():find("use:",1,true) then return true end
    end
    return false
end
function D:IsDirectCraftCandidate(r)
    if not r or r.unknown or r.disabled or r.supportsQualities or r.requiresStation then return false end
    if type(r.reagents)~="table" or #r.reagents==0 then return false end
    for _,slot in ipairs(r.reagents) do
        if type(slot.options)~="table" or #slot.options~=1 then return false end
    end
    return true
end
function D:CaptureRecipes()
    local captured=0
    if C_TradeSkillUI and type(C_TradeSkillUI.GetRecipeInfo)=="function" and type(C_TradeSkillUI.GetRecipeSchematic)=="function" then
        if S:Call("IsTradeSkillLinked",C_TradeSkillUI.IsTradeSkillLinked)==true or
           S:Call("IsTradeSkillGuild",C_TradeSkillUI.IsTradeSkillGuild)==true then return 0 end
        local ids,seen={},{}
        local function addID(id)
            if num(id) and id>0 and not seen[id] then seen[id]=true;ids[#ids+1]=id end
        end
        -- Prefer Blizzard's known spell list for each profession on clients
        -- exposing it. Other clients populate recipes from the native window.
        if type(C_TradeSkillUI.GetProfessionSpells)=="function" then
            for _,prof in ipairs(self.professions or S.Compat:Professions()) do
                local line=prof.skillLineID
                if num(line) then
                    local spells=S:Call("GetProfessionSpells",C_TradeSkillUI.GetProfessionSpells,line,line)
                    if type(spells)=="table" then
                        for _,id in ipairs(spells) do addID(id) end
                    end
                end
            end
        end
        local visible=S:Call("GetAllRecipeIDs",C_TradeSkillUI.GetAllRecipeIDs)
        if type(visible)=="table" then for _,id in ipairs(visible) do addID(id) end end
        if #ids>0 then
            for _,id in ipairs(ids) do
                if num(id) then
                    local info=S:Call("GetRecipeInfo",C_TradeSkillUI.GetRecipeInfo,id)
                    if type(info)=="table" and (info.learned==true or
                        (info.learned==nil and S:Call("IsRecipeProfessionLearned",C_TradeSkillUI.IsRecipeProfessionLearned,id)==true)) then
                        local sch=S:Call("GetRecipeSchematic",C_TradeSkillUI.GetRecipeSchematic,id,false)
                        if type(sch)=="table" then
                            local recipe={id=id,name=txt(info.name) or txt(sch.name) or ("Recipe "..id),source="modern",reagents={},unknown=false,
                                icon=info.icon or info.iconID or info.recipeIcon,
                                profession=txt(info.professionName) or txt(info.skillLineName),
                                disabled=info.isDisabled==true or info.isRecraft==true,
                                supportsQualities=info.supportsQualities==true or sch.supportsQualities==true,
                                requiresStation=info.requiresCraftingStation==true or sch.requiresCraftingStation==true}
                            for _,slot in ipairs(type(sch.reagentSlotSchematics)=="table" and sch.reagentSlotSchematics or {}) do
                                local basic=Enum and Enum.CraftingReagentType and Enum.CraftingReagentType.Basic or 0
                                if slot.required==true or slot.reagentType==basic then
                                    local options={}
                                    for _,r in ipairs(type(slot.reagents)=="table" and slot.reagents or {}) do
                                        if num(r.itemID) then options[#options+1]=r.itemID end
                                    end
                                    local qty=num(slot.quantityRequired)
                                    if #options>0 and qty and qty>0 then
                                        recipe.reagents[#recipe.reagents+1]={options=options,quantity=qty}
                                    else recipe.unknown=true end
                                end
                            end
                            -- Reagent-less schematics are not treated as free/infinite crafts.
                            if #recipe.reagents==0 or recipe.disabled then recipe.unknown=true end
                            self.recipes["m"..id]=recipe; captured=captured+1
                        end
                    end
                end
            end
        end
    end
    if type(GetNumTradeSkills)=="function" and type(GetTradeSkillInfo)=="function" then
        local count=num(S:Call("GetNumTradeSkills",GetNumTradeSkills)) or 0
        local skillName=txt(S:Call("GetTradeSkillLine",GetTradeSkillLine)) or "Profession"
        for i=1,math.min(count,3000) do
            local name,kind=S:Call("GetTradeSkillInfo",GetTradeSkillInfo,i)
            if txt(name) and kind~="header" and kind~="subheader" then
                local link=S:Call("GetTradeSkillRecipeLink",GetTradeSkillRecipeLink,i)
                local recipe={name=name,source="legacy",index=i,profession=skillName,reagents={},unknown=false,link=txt(link)}
                local total=num(S:Call("GetTradeSkillNumReagents",GetTradeSkillNumReagents,i)) or 0
                for j=1,total do
                    local _,_,required=S:Call("GetTradeSkillReagentInfo",GetTradeSkillReagentInfo,i,j)
                    local id=itemID(S:Call("GetTradeSkillReagentItemLink",GetTradeSkillReagentItemLink,i,j))
                    if id and num(required) and required>0 then recipe.reagents[#recipe.reagents+1]={options={id},quantity=required}
                    else recipe.unknown=true end
                end
                if total==0 then recipe.unknown=true end
                self.recipes["l:"..skillName..":"..name]=recipe; captured=captured+1
            end
        end
    end
    if captured>0 then self.lastCapture=S:Now(); self.craftCache=nil end
    return captured
end
-- No bank, reagent-bank, warband, auction-house, or vendor stock is counted.
-- Conservative allocation, including overlapping alternative reagent slots.
local function arraySize(value)
    if type(value)~="table" then return nil end
    local n=#value
    if n==0 then return nil end
    local count=0
    for key in pairs(value) do
        if not num(key) or key%1~=0 or key<1 or key>n then return nil end
        count=count+1
    end
    if count~=n then return nil end
    return n
end
local function positiveInteger(value)
    return num(value) and value>0 and value%1==0
end
function D:CraftCount(recipe)
    if type(recipe)~="table" or recipe.unknown or not arraySize(recipe.reagents) then return nil end
    -- Cached recipes can outlive a profession-window session. Reject incomplete
    -- or malformed slots rather than advertising free crafts or raising during
    -- a scene refresh. Read only bag items used by this recipe.
    local counts,required={},{}
    local simple=true
    for _,slot in ipairs(recipe.reagents) do
        if type(slot)~="table" or not positiveInteger(slot.quantity) then return nil end
        local options=arraySize(slot.options)
        if not options then return nil end
        if options~=1 then simple=false end
        for _,id in ipairs(slot.options) do
            if not positiveInteger(id) then return nil end
            if counts[id]==nil then
                local count=self.bagCounts[id]
                if count==nil then count=0 end
                if not num(count) or count<0 or count%1~=0 then return nil end
                counts[id]=count
            end
        end
        if options==1 then
            local id=slot.options[1]
            required[id]=(required[id] or 0)+slot.quantity
            if not num(required[id]) then return nil end
        end
    end
    -- Most classic recipes have one accepted item per slot. Aggregate repeated
    -- item IDs before dividing, so shared ingredients are never counted twice.
    -- This replaces thousands of simulated crafts with one pass over slots.
    if simple then
        local made=9999
        for id,quantity in pairs(required) do made=math.min(made,math.floor(counts[id]/quantity)) end
        return made
    end
    local made=0
    for attempt=1,9999 do
        local spent={}; local complete=true
        for _,slot in ipairs(recipe.reagents) do
            local need=slot.quantity
            for _,id in ipairs(slot.options) do
                local amount=math.min(need,math.max(0,(counts[id] or 0)-(spent[id] or 0)))
                spent[id]=(spent[id] or 0)+amount; need=need-amount
                if need<=0 then break end
            end
            if need>0 then complete=false; break end
        end
        if not complete then break end
        for id,used in pairs(spent) do counts[id]=counts[id]-used end
        made=made+1
    end
    return made
end
function D:Craftable()
    if self.craftCache then return self.craftCache[1],self.craftCache[2],self.craftCache[3] end
    local out,known,unknown={},0,0
    for key,r in pairs(self.recipes) do
        known=known+1
        local n=self:CraftCount(r)
        if not n then unknown=unknown+1
        elseif n>0 then out[#out+1]={key=key,recipe=r,count=n} end
    end
    table.sort(out,function(a,b)return a.recipe.name<b.recipe.name end)
    self.craftCache={out,known,unknown}
    return out,known,unknown
end
function D:CraftOne(key)
    if S:InCombat() then return false,"Unavailable in combat." end
    local r=self.recipes[key]
    if not r then return false,"Recipe is no longer cached." end
    self:RefreshBags()
    if (self:CraftCount(r) or 0)<1 then return false,"Required materials are no longer in your bags." end
    if not self:IsDirectCraftCandidate(r) then return false,"This recipe needs optional reagents, a station, quality selection or the native profession window." end
    if r.source=="modern" and C_TradeSkillUI and type(C_TradeSkillUI.CraftRecipe)=="function" then
        local info=S:Call("GetRecipeInfo",C_TradeSkillUI.GetRecipeInfo,r.id)
        if not info or info.learned~=true then return false,"Open this profession once to refresh the learned recipe." end
        if info.isDisabled==true or info.isRecraft==true then return false,"This recipe must be handled in the native profession window." end
        if r.supportsQualities then return false,"Choose crafting quality in the native profession window." end
        if r.requiresStation then return false,"This recipe needs its crafting station; use the native profession window." end
        -- Quality/alternative reagent allocation needs the native profession editor.
        for _,slot in ipairs(r.reagents) do if #slot.options~=1 then return false,"Choose reagent quality in the native profession window." end end
        local reagents={}
        for _,slot in ipairs(r.reagents) do reagents[#reagents+1]={itemID=slot.options[1],quantity=slot.quantity} end
        local ok,success=S:Guard("CraftRecipe",C_TradeSkillUI.CraftRecipe,r.id,1)
        if not ok or success==false then return false,"Crafting was rejected; use the native profession window if tools, a station or protected casting are required." end
        return true,"Craft request sent. The game's crafting result and rest aura are authoritative."
    elseif r.source=="legacy" and type(DoTradeSkill)=="function" then
        local name=S:Call("GetTradeSkillInfo",GetTradeSkillInfo,r.index)
        local profession=S:Call("GetTradeSkillLine",GetTradeSkillLine)
        if name~=r.name or profession~=r.profession then return false,"Open the matching profession first; cached indices cannot be used safely." end
        local ok,success=S:Guard("DoTradeSkill",DoTradeSkill,r.index,1)
        if not ok or success==false then return false,"Crafting was rejected by the client. Check tools, station and native profession UI." end
        return true,"Craft request sent. The game validates the result."
    end
    return false,"Use the native profession window for this recipe."
end
function D:Refresh()
    S:Guard("Stats provider",self.RefreshStats,self)
    if self.dirty then S:Guard("Inventory provider",self.RefreshBags,self) end
end
