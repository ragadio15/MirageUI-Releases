local _, S = ...
-- P10: User-supplied, final, unmodified 48kHz stereo Ogg/Vorbis masters.
-- Game sound handles cannot provide sample-perfect gapless looping. A brief
-- native crossfade hides UI-tick jitter without editing or recompressing files.
local A={status="Stopped",active=false,loopOverlap=.09,fadeOutMs=90}; S.Audio=A
A.tracks={
    idle={file="Stillwater.ogg",duration=96.0,label="Stillwater Reverie v4.3"},
    campfire={file="Vanguard.ogg",duration=80.0,label="Vanguard Ascendant final"},
    demo={file="Vanguard.ogg",duration=80.0,label="Vanguard Ascendant final"},
}
local CVARS={"Sound_EnableMusic","Sound_EnableAmbience"}
local function get(k) return S:String(S:Call("GetCVar",C_CVar and C_CVar.GetCVar or GetCVar,k)) end
local function set(k,v) return S:Guard("SetCVar "..k,C_CVar and C_CVar.SetCVar or SetCVar,k,v) end
function A:GetTrack(mode)
    return self.tracks[mode or S.mode or "idle"] or self.tracks.idle
end
function A:Recover()
    local lease=S.db.audioLease
    if type(lease)~="table" then self.recoveryState="CLEAR"; return end
    -- Do not overwrite a player/addon change made while Sanctuary was active.
    -- An unavailable read is not an external change, and a successful call
    -- alone does not establish that the setting was restored. Keep that
    -- original receipt until a readable postcondition settles ownership.
    -- Recovery is event-driven: at most one write per setting in this call.
    local unresolved={}
    for _,k in ipairs(CVARS) do
        local r=lease[k]
        if type(r)=="table" and type(r.previous)=="string" and type(r.written)=="string" then
            local current=get(k)
            if current==nil then
                unresolved[k]=r
            elseif current==r.written and current~=r.previous then
                set(k,r.previous)
                local after=get(k)
                if after==nil or after==r.written then unresolved[k]=r end
                -- A different readable value belongs to the player/another
                -- addon; release our receipt rather than forcing a retry.
            end
        end
    end
    S.db.audioLease=next(unresolved) and unresolved or nil
    self.recoveryState=S.db.audioLease and "RESTORE_PENDING" or "CLEAR"
end
function A:StopTrack(handle,fadeOutMs)
    handle=handle or self.handle
    if handle and type(StopSound)=="function" then
        S:Call("StopSound",StopSound,handle,fadeOutMs or 150)
    end
    if not handle or handle==self.handle then
        self.handle=nil; self.ends=nil; self.loopAt=nil
        self.currentKey=nil; self.status="Stopped"
    end
end
function A:Play(force)
    if not self.active or not S.db.music then self:StopTrack(); return end
    local key=S.mode or "idle"
    local track=self:GetTrack(key)
    if not force and self.handle and self.currentKey==key and self.loopAt and S:Now()<self.loopAt then
        return
    end
    local previous=self.handle
    local played,handle=S:Call("PlaySoundFile",PlaySoundFile,S.media..track.file,"Master")
    if played and handle then
        self.handle=handle
        self.currentKey=key
        self.ends=S:Now()+track.duration
        self.loopAt=self.ends-self.loopOverlap
        self.status="Playing: "..track.label
        if previous and previous~=handle then self:StopTrack(previous,self.fadeOutMs) end
    else
        -- Retain the previous handle, if any, instead of stopping valid audio.
        -- Avoid retrying the missing asset on every frame.
        self.status="Audio unavailable: "..track.label
        self.loopAt=nil
    end
end
function A:Enter()
    if self.active then
        local key=S.mode or "idle"
        -- Do not momentarily restore Blizzard audio when switching Sanctuary
        -- scenes, and do not restart a track if the same scene is reopened.
        if self.handle and self.currentKey and self:GetTrack(self.currentKey).file==self:GetTrack(key).file then
            self.currentKey=key
        elseif self.currentKey~=key or (S.db.music and not self.handle) then
            self:Play(true)
        end
        return
    end
    self:Recover()
    S.db.audioLease=S.db.audioLease or {}
    for _,k in ipairs(CVARS) do
        local previous=get(k)
        if previous and previous~="0" and not S.db.audioLease[k] then
            S.db.audioLease[k]={previous=previous,written="0"}
            set(k,"0")
            local after=get(k)
            if after and after~="0" then S.db.audioLease[k]=nil end
        end
    end
    if not next(S.db.audioLease) then S.db.audioLease=nil end
    self.active=true
    self:Play(true)
end
function A:Exit()
    self:StopTrack(); self.active=false; self:Recover(); self.currentKey=nil
end
function A:Tick()
    if self.active and S.db.music and self.loopAt and S:Now()>=self.loopAt then
        self:Play(true)
    end
end
