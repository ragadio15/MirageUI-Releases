local _, S = ...
local V={clock=0,petals={},smoke={},embers={},ribbons={},modelState="Not loaded"}; S.Scene=V
local function tex(parent,file,layer)
    local t=parent:CreateTexture(nil,layer or "ARTWORK"); t:SetTexture(S.media..file); return t
end
local function visibility(frame,b) if b then frame:Show() else frame:Hide() end end
local FLAME_SEQUENCE={}
do
    for i=0,31 do FLAME_SEQUENCE[#FLAME_SEQUENCE+1]=i end
    for i=30,1,-1 do FLAME_SEQUENCE[#FLAME_SEQUENCE+1]=i end
end
local function BuildBackgroundTiles(root, prefix)
    local tiles={}
    for row=1,2 do
        for col=1,4 do
            local index=(row-1)*4+col
            local t=root:CreateTexture(nil,"BACKGROUND",nil,1)
            t:SetTexture(S.media..string.format("%s_%02d.tga",prefix,index))
            tiles[index]=t
        end
    end
    return tiles
end
local function sprite(t,index)
    local page=math.floor(index/16)+1; local slot=index%16
    if t.sanctuaryPage~=page then
        t:SetTexture(S.media..string.format("CampFlame_%02d.tga",page)); t.sanctuaryPage=page
    end
    local x,y=slot%4,math.floor(slot/4)
    local inset=.5/2048
    t:SetTexCoord(x/4+inset,(x+1)/4-inset,y/4+inset,(y+1)/4-inset)
end

function V:Create(root,canvas)
    self.root,self.canvas=root,canvas
    self.idleTiles=BuildBackgroundTiles(root, "Idle")
    self.campTiles=BuildBackgroundTiles(root, "Camp")
    self.backgroundGeometry={width=0,height=0,left=0,top=0,tileWidth=0,tileHeight=0}

    self.vignette=root:CreateTexture(nil,"BORDER")
    self.vignette:SetAllPoints(root)
    self.vignette:SetColorTexture(0.02,0.015,0.03,0.12)
    self.tint=root:CreateTexture(nil,"ARTWORK")
    self.tint:SetAllPoints(root)
    self.tint:SetColorTexture(0.07,0.04,0.10,0.05)
    self.topFade=root:CreateTexture(nil,"OVERLAY")
    self.topFade:SetPoint("TOPLEFT",root,"TOPLEFT",0,0)
    self.topFade:SetPoint("TOPRIGHT",root,"TOPRIGHT",0,0)
    self.topFade:SetHeight(220)
    self.topFade:SetColorTexture(0.02,0.015,0.03,0.10)
    self.bottomFade=root:CreateTexture(nil,"OVERLAY")
    self.bottomFade:SetPoint("BOTTOMLEFT",root,"BOTTOMLEFT",0,0)
    self.bottomFade:SetPoint("BOTTOMRIGHT",root,"BOTTOMRIGHT",0,0)
    self.bottomFade:SetHeight(180)
    self.bottomFade:SetColorTexture(0.02,0.015,0.03,0.08)

    -- Position lives in the same unscaled canvas space as the character.
    -- Scaling the animated fire must not also pull its X/Y offsets inward.
    self.fireAnchor=CreateFrame("Frame",nil,canvas)
    self.fireAnchor:SetSize(1,1)
    self.fireAnchor:EnableMouse(false)
    self.fire=CreateFrame("Frame",nil,self.fireAnchor)
    -- The complete effect, including glow and drifting smoke, has an explicit
    -- paint envelope. Keep particles inside it so a resized scene cannot paint
    -- through the character viewport or the Prepare controls.
    self.fire:SetSize(400,620)
    if self.fire.SetClipsChildren then self.fire:SetClipsChildren(true) end
    self.fire:SetFrameLevel(canvas:GetFrameLevel()+2)
    self.fire:EnableMouse(false)
    self.shadow=tex(canvas,"Shadow.tga","ARTWORK")
    self.glow=tex(self.fire,"Glow.tga","BACKGROUND")
    self.glow:SetPoint("CENTER",self.fire,"BOTTOM",0,54)
    self.glow:SetSize(400,150)
    self.glow:SetVertexColor(1,.56,.18,.58)
    self.fireArt=tex(self.fire,"CampfireFixed.tga","BORDER")
    self.fireArt:SetPoint("BOTTOM",self.fire,"BOTTOM",0,0)
    self.fireArt:SetSize(330,330)
    self.flameA=tex(self.fire,"CampFlame_01.tga","ARTWORK")
    self.flameB=tex(self.fire,"CampFlame_01.tga","ARTWORK")
    for _,f in ipairs({self.flameA,self.flameB}) do
        f:SetSize(330,330); f:SetPoint("BOTTOM",self.fire,"BOTTOM",0,0)
        if f.SetBlendMode then f:SetBlendMode("ADD") end
    end
    for i=1,5 do
        local t=tex(self.fire,"SmokeRibbon.tga","OVERLAY")
        t:SetVertexColor(.82,.86,.92,.24)
        self.ribbons[i]={texture=t,phase=(i-1)/5,duration=5.8+i*.31,drift=math.sin(i*1.7)*16,twist=(i%2==0 and 1 or -1)}
    end
    for i=1,4 do
        local t=tex(self.fire,"Smoke.tga","OVERLAY")
        t:SetVertexColor(.74,.78,.84,.18)
        self.smoke[i]={texture=t,phase=(i-1)/4,duration=4.8+i*.29,drift=math.sin(i*2.1)*20}
    end
    for i=1,12 do
        local t=tex(self.fire,"Glow.tga","OVERLAY")
        t:SetVertexColor(1,.60,.18,1)
        if t.SetBlendMode then t:SetBlendMode("ADD") end
        self.embers[i]={texture=t,phase=(i-1)/12,duration=2.0+i*.13,drift=math.sin(i*5.1)*26}
    end

    -- Three distant, independent flocks, animated entirely in the UI sky.
    -- This frame is below the 3D character, Prepare panel, and toolbar.
    self.birdLayer=CreateFrame("Frame",nil,root)
    self.birdLayer:SetFrameLevel(root:GetFrameLevel()+1)
    self.birdLayer:EnableMouse(false)
    self.birds={}
    self.flocks={
        {duration=25.0,phase=.16,sky=.70,count=6,alpha=.80,size=29},
        {duration=32.0,phase=.49,sky=.77,count=5,alpha=.66,size=24},
        {duration=29.0,phase=.74,sky=.67,count=5,alpha=.53,size=21},
    }
    for flockIndex,flock in ipairs(self.flocks) do
        for slot=1,flock.count do
            local t=tex(self.birdLayer,"BirdFlight.tga","ARTWORK")
            t:SetTexCoord(0,.5,0,.5)
            t:SetVertexColor(.78,.83,.94,1)
            self.birds[#self.birds+1]={texture=t,flock=flockIndex,slot=slot,
                wingFrame=-1,alpha=flock.alpha*(.89+(slot%3)*.055)}
        end
    end

    self.petalLayer=CreateFrame("Frame",nil,root)
    self.petalLayer:SetFrameLevel(root:GetFrameLevel()+1)
    self.petalLayer:EnableMouse(false)
    self.petals={}
    for i=1,18 do
        local t=tex(self.petalLayer,"Petal.tga","ARTWORK")
        self.petals[i]={texture=t,phase=i*.37,duration=9.0+(i%5)*1.3,size=20+(i%4)*6,drift=38+((i*17)%30),sway=14+((i*13)%18),spin=(i%2==0 and 1 or -1)*(.10+(i%3)*.05)}
    end

    local ok,model=pcall(CreateFrame,"DressUpModel",nil,canvas)
    if not ok then ok,model=pcall(CreateFrame,"PlayerModel",nil,canvas) end
    if ok then
        self.model=model
        model:SetFrameLevel(canvas:GetFrameLevel()+3)
        model:EnableMouse(false)
        model:Hide()
        S:Call("Keep model",model.SetKeepModelOnHide,model,true)
        S:Guard("Model loaded script",model.SetScript,model,"OnModelLoaded",function()
            -- SetUnit may complete after the first camera/pose submission.
            -- Start the sequence once for this completed native model load.
            S:Guard("Pose",V.ApplyPose,V,true)
        end)
    end
end

function V:SetBackground(mode)
    local showIdle=(mode=="idle")
    for _,t in ipairs(self.idleTiles or {}) do if showIdle then t:Show() else t:Hide() end end
    for _,t in ipairs(self.campTiles or {}) do if showIdle then t:Hide() else t:Show() end end
    if showIdle then
        self.tint:SetColorTexture(0.08,0.04,0.11,0.05)
        self.vignette:SetColorTexture(0.02,0.015,0.03,0.10)
        self.topFade:SetColorTexture(0.02,0.015,0.03,0.08)
        self.bottomFade:SetColorTexture(0.02,0.015,0.03,0.05)
    else
        self.tint:SetColorTexture(0.04,0.025,0.08,0.14)
        self.vignette:SetColorTexture(0.02,0.015,0.03,0.17)
        self.topFade:SetColorTexture(0.02,0.015,0.03,0.12)
        self.bottomFade:SetColorTexture(0.02,0.015,0.03,0.11)
    end
end

function V:Crop()
    local w,h=self.root:GetWidth(),self.root:GetHeight()
    if type(w)~="number" or type(h)~="number" or w<=0 or h<=0 then return end
    local artworkAspect=2.0
    local fitWidth=math.max(w,h*artworkAspect)
    local fitHeight=fitWidth/artworkAspect
    local left=(w-fitWidth)/2
    local top=(fitHeight-h)/2
    local tileW,tileH=fitWidth/4,fitHeight/2
    self.backgroundGeometry={width=fitWidth,height=fitHeight,left=left,top=top,tileWidth=tileW,tileHeight=tileH,screenW=w,screenH=h}
    for _,tiles in ipairs({self.idleTiles,self.campTiles}) do
        for index,t in ipairs(tiles) do
            local col=(index-1)%4
            local row=math.floor((index-1)/4)
            t:ClearAllPoints()
            t:SetSize(tileW+0.35,tileH+0.35)
            t:SetPoint("TOPLEFT",self.root,"TOPLEFT",left+col*tileW,top-row*tileH)
        end
    end
end

function V:BackgroundReport()
    local g=self.backgroundGeometry or {}
    return string.format("TILED_4x2 | mode=%s | 8 expected tiles | canvas=%s x %s | coverage=%.1f x %.1f | offset=%.1f,%.1f",
        tostring(S.mode),tostring(g.screenW or "?"),tostring(g.screenH or "?"),g.width or 0,g.height or 0,g.left or 0,g.top or 0)
end

function V:Layout(w,h)
    local camp=S.mode~="idle"
    local prefix=camp and "camp" or "idle"
    local portrait=S.UI and S.UI.profile=="portrait"
    -- Position and scale the character and fire as one composition. Previously
    -- AFK reserved a large empty model viewport, while Prepare positioned the
    -- fire independently inside that viewport. Both errors were conspicuous
    -- on the Surface's 3:2 canvas. A shared fitting factor retains the model's
    -- aspect ratio and a small, deterministic gap at every screen size.
    local left=portrait and 12 or 24
    local boundary=camp and ((S.UI and S.UI.scenicRight) or w*.64) or w*.49
    if portrait then boundary=camp and w*.48 or w-12 end
    boundary=math.max(left+120,math.min(w-12,boundary))
    local gap=portrait and 22 or S:Clamp(w*.024,28,36)
    local modelScale=S:Clamp(S.db[prefix.."Scale"] or 1,.6,1.6)
    local baseW,baseH,baseFire=camp and 620 or 520,camp and 680 or 590,camp and 1 or .82
    local floor=camp and 34 or 30
    local top=h-110
    local offsetFactor=1
    if portrait and camp then
        baseW,baseH,baseFire=245,166,.30
        floor=h-246;top=h-80;offsetFactor=.16
    elseif portrait then
        baseW,baseH,baseFire=350,470,.52
        floor=26;top=h-90;offsetFactor=.2
    end
    baseW,baseH=baseW*modelScale,baseH*modelScale
    local fit=math.min(1,(boundary-left-gap)/(baseW+400*baseFire),(top-floor)/math.max(baseH,620*baseFire))
    fit=math.max(.05,fit)
    local viewportW,viewportH=baseW*fit,baseH*fit
    local fireScale=baseFire*fit
    local pairWidth=viewportW+gap+400*fireScale
    local pairHeight=math.max(viewportH,620*fireScale)
    local x=S:Clamp(left+(S.db[prefix.."OffsetX"] or 0)*offsetFactor,left,math.max(left,boundary-pairWidth))
    local y=S:Clamp(floor+(S.db[prefix.."OffsetY"] or 0)*offsetFactor,portrait and camp and floor or 12,math.max(floor,top-pairHeight))
    local fireCenter=x+viewportW+gap+200*fireScale
    local fireY=y
    local separation=gap+35*fireScale -- rock/flame art is 330 inside the 400-wide effect envelope
    self.modelGeometry={width=viewportW,height=viewportH,x=x,y=y,boundary=boundary}
    -- Uniform fitting already shrinks the scene. Applying 620 / viewportW as
    -- well would shrink the character twice and make the fire look far away.
    self.cameraPadding=1+(1-fit)*.12
    if self.model then
        self.model:ClearAllPoints();self.model:SetSize(viewportW,viewportH)
        self.model:SetPoint("BOTTOMLEFT",self.canvas,"BOTTOMLEFT",x,y)
    end
    self.shadow:ClearAllPoints()
    self.shadow:SetSize((portrait and 120 or (camp and 240 or 220))*fit,(portrait and 26 or 48)*fit)
    self.shadow:SetPoint("CENTER",self.canvas,"BOTTOMLEFT",x+viewportW*.5,y+(portrait and 16 or 70)*fit)
    self.fireGeometry={x=fireCenter,y=fireY,width=330*fireScale,height=350*fireScale,
        scale=fireScale,separation=separation,effectWidth=400*fireScale,effectHeight=620*fireScale,effectGap=gap,
        pairWidth=pairWidth,fit=fit,layout=camp and "SEPARATE_PREPARE_VIEWPORTS" or "SEPARATE_IDLE_VIEWPORTS"}
    self.fireAnchor:ClearAllPoints()
    self.fireAnchor:SetPoint("BOTTOM",self.canvas,"BOTTOMLEFT",fireCenter,fireY)
    self.fire:ClearAllPoints()
    self.fire:SetPoint("BOTTOM",self.fireAnchor,"BOTTOM",0,0)
    self.fire:SetScale(fireScale)

    self.birdLayer:ClearAllPoints();self.birdLayer:SetPoint("CENTER",self.root,"CENTER")
    self.birdLayer:SetScale(self.root:GetHeight()/h);self.birdLayer:SetSize(w,h)
    self.petalLayer:ClearAllPoints();self.petalLayer:SetPoint("CENTER",self.root,"CENTER")
    self.petalLayer:SetScale(self.root:GetHeight()/h);self.petalLayer:SetSize(w,h)
    self.birdScenicWidth=portrait and w or math.max(280,boundary)
    for _,bird in ipairs(self.birds) do
        local flock=self.flocks[bird.flock]
        local size=flock.size*(.92+(bird.slot%3)*.06)*(portrait and .65 or 1)
        bird.texture:SetSize(size*1.5,size)
    end
    self:Crop()
end
function V:ModelReport()
    local g=self.modelGeometry or {}
    local f=self.fireGeometry or {}
    return string.format("viewport=%.0fx%.0f | camera=%.2f | scene=%s | fire_gap=%s | lighting=%s | animation=%s | native rendering; client quality settings unchanged",
        g.width or 0,g.height or 0,self.effectiveCamera or 0,f.layout or "PENDING",
        f.separation and string.format("%.1f",f.separation) or "PREPARE",self.lightingState or "native",self.animationState or "NOT_STARTED")
end

function V:ApplyLighting()
    local m=self.model
    if not m or type(m.SetLight)~="function" or type(CreateVector3D)~="function" or type(CreateColor)~="function" then
        self.lightingState="native (optional lighting API unavailable)"; return
    end
    if not self.lightCaptured then
        self.nativeLightEnabled,self.nativeLight=S:Call("Original model light",m.GetLight,m)
        self.lightCaptured=true
    end
    if not S.db.modelLight then
        if self.nativeLight then S:Call("Restore model light",m.SetLight,m,self.nativeLightEnabled,self.nativeLight) end
        self.lightingState="native"; return
    end
    if type(self.nativeLight)~="table" or type(self.nativeLightEnabled)~="boolean" then
        self.lightingState="native (restorable light state unavailable)"; return
    end
    local camp=S.mode~="idle"
    local light={omnidirectional=false,point=CreateVector3D(-.4,-.7,-1),ambientIntensity=.68,ambientColor=CreateColor(.84,.87,.94),diffuseIntensity=.74,diffuseColor=CreateColor(1,camp and .83 or .91,camp and .69 or .82)}
    local ok=S:Guard("Model lighting",m.SetLight,m,true,light)
    self.lightingState=ok and "soft ambient + warm key" or "native fallback"
end

function V:StopModelAnimation(reason)
    self.modelAnimation=nil;self.animationState=reason or "STOPPED"
    local m=self.model
    if m and type(m.SetScript)=="function" then S:Guard("Stop model loop",m.SetScript,m,"OnAnimFinished",nil) end
end

function V:PlayModelAnimation(id,force)
    local m=self.model
    if not m or not S.mode or not S.db.model or not m:IsShown() or type(m.SetAnimation)~="function" then return false end
    local previous=self.modelAnimation
    if not force and previous and previous.model==m and previous.id==id and previous.mode==S.mode then return true end
    -- CharacterModelBase:SetAnimation selects a sequence, not a loop flag.
    -- Blizzard's TalkingHead model repeats it from OnAnimFinished. Use the
    -- same native completion signal, queued into the scene tick to prevent
    -- recursive callbacks. No guessed duration, frame seeking or pose swap.
    local animation={model=m,id=id,mode=S.mode,completed=0}
    self.modelAnimation=animation
    local hooked=S:Guard("Model animation completion",m.SetScript,m,"OnAnimFinished",function()
        if self.modelAnimation==animation and S.mode==animation.mode and S.db.model and m:IsShown() then animation.pending=true end
    end)
    if type(m.SetPaused)=="function" then S:Guard("Resume model animation",m.SetPaused,m,false) end
    local ok,result=S:Guard("SetAnimation",m.SetAnimation,m,id,0)
    if self.modelAnimation~=animation then return false end
    if not ok or result==false then
        self:StopModelAnimation("NATIVE_SEQUENCE_REJECTED");return false
    end
    self.poseID=id
    self.animationState=hooked and "NATIVE_COMPLETION_LOOP_READY" or "NATIVE_SEQUENCE_ONLY"
    return true
end

function V:TickModelAnimation()
    local animation=self.modelAnimation
    if not animation or not animation.pending then return end
    animation.pending=nil
    local m=animation.model
    if m~=self.model or not S.db.model or not S.mode or S.mode~=animation.mode or not m:IsShown() then return end
    local ok,result=S:Guard("Repeat model animation",m.SetAnimation,m,animation.id,0)
    if self.modelAnimation~=animation then return end
    if not ok or result==false then self:StopModelAnimation("NATIVE_SEQUENCE_REJECTED");return end
    animation.completed=animation.completed+1
    self.animationState="NATIVE_COMPLETION_OBSERVED"
end

function V:ApplyPose(force)
    local m=self.model
    if not m or not S.db.model or not S.mode then return end
    local camp=S.mode~="idle"
    local prefix=camp and "camp" or "idle"
    local pose=S.db[prefix.."Pose"]
    -- AnimationData SitGround is 97; 96/98 are its down/up transitions.
    -- Preserve the actual seated idle rather than freezing a transition frame.
    local ids={sit=97,stand=0,combat=26,sleep=100}
    local id=ids[pose] or 0
    if type(m.HasAnimation)=="function" then
        local supported=S:Call("HasAnimation",m.HasAnimation,m,id)
        if supported==false then id=0; self.modelState="Requested pose unavailable; native stand fallback" end
    end
    if type(m.SetSheathed)=="function" then S:Call("SetSheathed",m.SetSheathed,m,not camp) end
    S:Call("SetPortraitZoom",m.SetPortraitZoom,m,0)
    self.effectiveCamera=S:Clamp(S.db[prefix.."Camera"]*(self.cameraPadding or 1),.5,3.5)
    S:Call("SetViewInsets",m.SetViewInsets,m,0,0,0,0)
    S:Call("SetCamDistanceScale",m.SetCamDistanceScale,m,self.effectiveCamera)
    S:Call("SetFacing",m.SetFacing or m.SetRotation,m,S.db[prefix.."Facing"])
    self:PlayModelAnimation(id,force)
    self:ApplyLighting()
end

function V:RefreshModel()
    local m=self.model
    if not m then self.modelState="Native player-model widget unavailable"; return end
    self:StopModelAnimation("MODEL_REFRESH")
    if not S.db.model then m:Hide(); self.shadow:Hide(); self.modelState="Disabled"; return end
    m:Show(); self.shadow:Show()
    local ok,result=S:Guard("SetUnit",m.SetUnit,m,"player")
    if not ok or result==false then m:Hide(); self.shadow:Hide(); self.modelState="SetUnit unavailable; landscape remains usable"; return end
    S:Call("Dress",m.Dress,m)
    S:Call("SetPosition",m.SetPosition,m,0,0,0)
    self.modelState="Native player model requested; pose "..tostring(self.poseID or 0)
    self:ApplyPose()
    self.retryTimes={S:Now()+.15,S:Now()+.5,S:Now()+1.2}
end

function V:UpdateFireVisibility()
    visibility(self.fire,S.db.fire)
end
function V:UpdateAmbienceVisibility()
    visibility(self.birdLayer,S.db.birds and S.mode~="idle")
    visibility(self.petalLayer,S.db.petals and S.mode=="idle")
end
-- Retain the earlier method name for optional external integrations.
function V:UpdateRayVisibility() self:UpdateAmbienceVisibility() end
function V:Enter()
    self.clock=0; self.enterAt=S:Now()
    self:SetBackground(S.mode)
    self:UpdateFireVisibility(); self:UpdateAmbienceVisibility(); self:Crop(); self:RefreshModel()
end
function V:Exit()
    self:StopModelAnimation("SCENE_CLOSED")
    if self.model then self.model:Hide() end
    self.retryTimes=nil
end

function V:Tick(dt)
    self.clock=self.clock+dt
    if self.retryTimes and #self.retryTimes>0 and S:Now()>=self.retryTimes[1] then table.remove(self.retryTimes,1); self:ApplyPose() end
    self:TickModelAnimation()
    local t=self.clock
    if self.fire:IsShown() then
        local cycle=#FLAME_SEQUENCE
        local position=(t*13.2)%cycle; local base=math.floor(position)+1; local nextIndex=base%cycle+1; local mix=position-math.floor(position)
        sprite(self.flameA,FLAME_SEQUENCE[base]); sprite(self.flameB,FLAME_SEQUENCE[nextIndex])
        self.flameA:SetAlpha(1-mix); self.flameB:SetAlpha(mix)
        self.glow:SetAlpha(.48+.05*math.sin(t*2.8)+.02*math.sin(t*6.1))
        local ribbonCount=S.db.quality=="low" and 3 or 5
        for i,p in ipairs(self.ribbons) do
            if i<=ribbonCount then
                p.texture:Show()
                local age=(t/p.duration+p.phase)%1
                local size=150+age*170
                p.texture:SetSize(size*0.85,size*1.6)
                p.texture:ClearAllPoints()
                p.texture:SetPoint("CENTER",self.fire,"BOTTOM",p.drift*math.sin(age*6.283+p.phase*4)+p.twist*age*18,168+age*188)
                p.texture:SetRotation((age*1.4+p.phase*2.4)*p.twist*.75)
                p.texture:SetAlpha((math.sin(math.pi*age)^2)*.24)
            else p.texture:Hide() end
        end
        local smokeCount=S.db.quality=="low" and 2 or 4
        for i,p in ipairs(self.smoke) do
            if i<=smokeCount then
                p.texture:Show()
                local age=(t/p.duration+p.phase)%1; local size=72+age*100
                p.texture:SetSize(size,size*1.5); p.texture:ClearAllPoints()
                p.texture:SetPoint("CENTER",self.fire,"BOTTOM",p.drift*age+14*math.sin(age*4.5+t*.17),188+age*150)
                p.texture:SetAlpha(math.sin(math.pi*age)^2*.11)
            else p.texture:Hide() end
        end
        local emberCount=S.db.quality=="low" and 6 or 12
        for i,p in ipairs(self.embers) do
            if i<=emberCount then
                p.texture:Show()
                local age=(t/p.duration+p.phase)%1; local size=2.5+3*math.sin(math.pi*age)
                p.texture:SetSize(size,size*1.6); p.texture:ClearAllPoints()
                p.texture:SetPoint("CENTER",self.fire,"BOTTOM",p.drift*(.25+age)+math.sin(age*7+p.phase*10)*9,90+age*235)
                p.texture:SetAlpha(math.sin(math.pi*age)*.82)
            else p.texture:Hide() end
        end
    end
    if S.db.birds and S.mode~="idle" then
        local limit=S.db.quality=="low" and 9 or #self.birds
        local scenicWidth=self.birdScenicWidth or 1100
        local h=self.canvas and self.canvas:GetHeight() or 900
        local sequence={0,1,2,1}
        for i,bird in ipairs(self.birds) do
            if i<=limit then
                local flock=self.flocks[bird.flock]
                local age=(t/flock.duration+flock.phase)%1
                local slot=bird.slot-1
                local distance=slot==0 and 0 or (slot%2==0 and -1 or 1)*math.ceil(slot/2)
                local x=scenicWidth*(-.06+1.07*age)+slot*5
                local y=h*flock.sky+distance*9+math.sin(t*.41+slot*.73+bird.flock)*3.5
                bird.texture:ClearAllPoints()
                bird.texture:SetPoint("CENTER",self.birdLayer,"BOTTOMLEFT",x,y)
                local flightFade=math.sin(math.pi*age)
                local shimmer=.85+.15*math.sin(t*.49+slot*.41)
                bird.texture:SetAlpha(math.max(0,flightFade)^.64*bird.alpha*shimmer)
                local wing=sequence[math.floor((t*2.35+slot*.21+bird.flock*.35)%4)+1]
                if wing~=bird.wingFrame then
                    local col=wing%2; local row=math.floor(wing/2)
                    bird.texture:SetTexCoord(col*.5,(col+1)*.5,row*.5,(row+1)*.5)
                    bird.wingFrame=wing
                end
                bird.texture:Show()
            else bird.texture:Hide() end
        end
    end
    if S.db.petals and S.mode=="idle" then
        local limit=S.db.quality=="low" and 10 or 18
        local w,h=(self.canvas and self.canvas:GetWidth() or 1600),(self.canvas and self.canvas:GetHeight() or 900)
        for i,p in ipairs(self.petals) do
            if i<=limit then
                p.texture:Show()
                local age=(t/p.duration+p.phase)%1
                local x=(w*.18 + (i%6)*w*.12 + math.sin(age*6.283+p.phase*5)*p.sway + age*w*.18) % (w*0.82)
                local y=h - age*(h+120) + math.sin(age*9+p.phase*7)*18
                local size=p.size*(.9+.35*math.sin(age*6.283+p.phase))
                p.texture:SetSize(size,size)
                p.texture:ClearAllPoints()
                p.texture:SetPoint("CENTER",self.petalLayer,"BOTTOMLEFT",x+20,y)
                p.texture:SetRotation(age*6.283*p.spin)
                p.texture:SetAlpha((.20+.55*math.sin(math.pi*age)^2) * (.75+.25*math.sin(t*0.9+p.phase)))
            else p.texture:Hide() end
        end
    end
end
