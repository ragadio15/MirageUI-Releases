local addonName,S=...
local events=CreateFrame("Frame")
function S:Open(mode,reason)
    if not self.ready or self:InCombat() or self:Dead() or self.worldTransition then return false end
    mode=mode or "idle"
    if mode~="idle" and mode~="campfire" and mode~="demo" then return false end
    if mode=="demo" and self.Camping.welcome then mode="campfire"; reason="live-rest-over-demo" end
    -- Start each fresh preparation visit at a concise, integrated status view.
    if mode~="idle" and (not self.mode or self.mode=="idle") then
        self.UI.tab="status"; self.UI.offset=0
    end
    self.mode,self.reason=mode,reason or "manual"; self.completionUntil=nil
    if mode=="demo" then self.demoEnd=self:Now()+60 end
    local fast=(mode=="campfire" and (reason=="rest-intent" or reason=="aura"))
    self.fastEntry=fast
    local ok=self:Guard("Open scene",function()
        self.UI.root:Show()
        -- Present the scene before inventory/profession enumeration; fast
        -- entry defers those expensive reads until the next visible frame.
        self.UI:SetMode(); self.Scene:Enter(); self.UI:Layout(); self.Audio:Enter()
        if fast then
            self.deferredPrepare=true
        else
            self.Data:Refresh()
            if mode~="idle" then
                self:Guard("Auto profession scan",self.Data.CaptureRecipes,self.Data)
                self.UI:RefreshPanel()
            end
        end
    end)
    self.fastEntry=nil
    if not ok then self.deferredPrepare=nil; self:Close("open-failure"); self:Print("Sanctuary could not open safely. Use /sanctuary diagnose."); return false end
    self:WakePump(); return true
end
function S:Hidden()
    -- Release logical scene state even when an optional cleanup fails.
    -- Dismiss keeps the already observed rest session, but stops auto-reopen.
    local hadScene=self.mode~=nil
    self.mode=nil; self.reason=nil; self.completionUntil=nil
    self.deferredPrepare=nil; self.demoEnd=nil; self.fastEntry=nil
    if self.UI then self:Guard("Hide leave prompt",self.UI.HideLeavePrompt,self.UI) end
    self:Guard("Audio exit",self.Audio.Exit,self.Audio)
    self:Guard("Model exit",self.Scene.Exit,self.Scene)
    if hadScene then self:Guard("Dismiss camp",self.Camping.Dismiss,self.Camping) end
end
function S:Close(reason)
    if not self.ready then return end
    self.lastClose=reason or "manual"
    if self.mode=="idle" and self:AFK() then self.afkDismissed=true end
    if self.UI.root and self.UI.root:IsShown() then self.UI.root:Hide()
    else self:Hidden() end
end
function S:IsShown() return self.UI.root and self.UI.root:IsShown() or false end
function S:Report()
    local C=self.Camping; local _,known,unknown=self.Data:Craftable()
    local lines={"MirageUI | Sanctuary "..self.version,"Client "..self.client.version.." / "..self.client.build.." / interface "..self.client.interface,
        "Mode: "..tostring(self.mode).." | reason: "..tostring(self.reason),
        "Nearby aura (1283391): "..tostring(C.nearby).." | Violet Flames (1328375): "..tostring(C.violet).." | Flames: "..tostring(C.flames),
        "Fire ready (aura; never sufficient alone to open): "..tostring(C.fireReady).." | posture: "..tostring(C.lastPosture),
        "Auto AFK: "..tostring(self.db.automatic).." | Auto camping: "..tostring(self.db.automaticCampfire),
        "Fast rest trigger: "..tostring(C.hookStatus or "unavailable").." | preliminary: "..tostring(C.pending and C.pending.source or "none").." | fire-ready: "..tostring(C.fireReady),
        "Model: "..self.Scene.modelState.." | animation: "..tostring(self.Scene.poseID),
        "Framing: "..self.Scene:ModelReport(),
        "Layout: "..tostring(self.UI.profile).." / "..math.floor((self.UI.w or 0)+.5).."x"..math.floor((self.UI.h or 0)+.5).." logical / scale "..string.format("%.3f",self.UI.canvasScale or 1),
        "Exit confirmation: "..tostring(self.UI.leavePrompt and self.UI.leavePrompt:IsShown()).." | completed rest remains open",
        "Background: "..self.Scene:BackgroundReport().." | expected assets: Idle_01..08.tga / Camp_01..08.tga",
        "Audio: "..self.Audio.status.." | scene: "..tostring(self.Audio.currentKey).." | lease active: "..tostring(self.db.audioLease~=nil).." | restoration: "..tostring(self.Audio.recoveryState or "CLEAR"),
        "Consumables: "..#self.Data.consumables.." | pending item data: "..self.Data.pending,
        "Cached learned recipes: "..known.." | unresolved: "..unknown,
        "Auras: "..tostring(C_UnitAuras and type(C_UnitAuras.GetAuraDataByIndex) or type(UnitAura)),
        "Items: "..tostring(C_Item and type(C_Item.GetItemInfo) or type(GetItemInfo)),
        "Craft API: "..tostring(C_TradeSkillUI and type(C_TradeSkillUI.GetRecipeSchematic) or type(GetNumTradeSkills)),
        "Active camp effects: "..#C:ActiveEffects(),
        "Nearby object enumeration: no verified provider; no speculative predictions", "", "PLAYER HELPFUL AURAS:"}
    for _,a in ipairs(C.auras) do lines[#lines+1]=string.format("%s | id=%s | instance=%s | duration=%s | remaining=%s",a.name,tostring(a.id),tostring(a.instance),tostring(a.duration),a.expires and string.format("%.2f",a.expires-self:Now()) or "unknown") end
    lines[#lines+1]=""; lines[#lines+1]="PROVIDER / RUNTIME FAULTS:"
    local count=0
    for label,v in pairs(self.faults) do count=count+1; lines[#lines+1]=label.." ("..v.count.."): "..v.message end
    if count==0 then lines[#lines+1]="None recorded this session." end
    lines[#lines+1]=""; lines[#lines+1]="No in-game test is implied by this report. No object proximity or reward is inferred from an item in a bag."
    return table.concat(lines,"\n")
end
function S:WakePump()
    if events:GetScript("OnUpdate") then return end
    local auraAccum,postureAccum=0,0
    events:SetScript("OnUpdate",function(_,elapsed)
        postureAccum=postureAccum+elapsed
        if postureAccum>=0.10 then
            postureAccum=postureAccum%0.10
            if S.db.automaticCampfire and S.Camping.fireReady and not S.Camping.welcome and not S.Camping.pending then
                S:Guard("Fast posture observation",S.Camping.WatchPosture,S.Camping)
            end
        end
        auraAccum=auraAccum+elapsed
        if auraAccum<.40 then return end
        auraAccum=auraAccum%.40
        if S.Camping.fireReady or S.Camping.session or S.Camping.pending or S.mode or S.settleUntil then
            S:Guard("Camp aura observation",S.Camping.Observe,S.Camping)
        end
        if not S.Camping.fireReady and not S.Camping.session and not S.Camping.pending and not S.mode and not S.settleUntil then
            events:SetScript("OnUpdate",nil)
        end
    end)
end
function S:Command(input)
    local verb,rest=(input or ""):match("^%s*(%S*)%s*(.-)%s*$"); verb=verb:lower(); rest=rest:lower()
    if verb=="settings" or verb=="config" then
        local opened,reason=self.Settings:Open()
        if not opened then self:Print(reason) end
    elseif verb=="" or verb=="open" or verb=="on" then
        if not self:Open("idle","manual") then self:Print("Open Sanctuary outside combat, after loading, while alive.") end
    elseif verb=="rest" or verb=="campfire" or verb=="prepare" then
        self.Camping:Observe(); self:Open("campfire","manual")
    elseif verb=="demo" then self:Open("demo","manual")
    elseif verb=="off" or verb=="close" or verb=="exit" then self:Close("user")
    elseif verb=="status" then
        self:Print(self.version.." | "..(self.mode or "closed").." | "..self.Scene.modelState)
        self:Print("Campfire Nearby: "..tostring(self.Camping.nearby).."; Violet Flames: "..tostring(self.Camping.violet).."; Flames: "..tostring(self.Camping.flames).."; timed rest: "..tostring(self.Camping.welcome~=nil))
        self:Print("Background: "..self.Scene:BackgroundReport())
        self:Print("Layout: "..tostring(self.UI.profile).." / "..math.floor((self.UI.w or 0)+.5).." x "..math.floor((self.UI.h or 0)+.5))
    elseif verb=="layout" then
        self:Print("Layout: "..tostring(self.UI.profile).." | logical "..math.floor((self.UI.w or 0)+.5).." x "..math.floor((self.UI.h or 0)+.5).." | display "..math.floor((self.UI.root:GetWidth() or 0)+.5).." x "..math.floor((self.UI.root:GetHeight() or 0)+.5))
    elseif verb=="art" or verb=="background" then
        self:Print("Scene art: "..self.Scene:BackgroundReport())
        self:Print("If scenery is black after a *complete game restart*, use /sanctuary diagnose and attach a screenshot.")
    elseif verb=="diagnose" or verb=="report" then self.Camping:Observe(); self.UI:Diagnostics(self:Report())
    elseif verb=="refresh" then
        self.Data.dirty=true; self.Data:CaptureRecipes(); self.Data:Refresh(); self.Camping:Observe()
        if self.mode then self.UI:RefreshPanel(); self.Scene:RefreshModel() end
        self:Print("Refreshed available native data.")
    elseif verb=="next" then self.UI:NextQuote()
    elseif verb=="quote" then
        local n=tonumber(rest)
        if n and n==math.floor(n) and n>=1 and n<=#self.Quotes then self.UI:NextQuote(n)
        else self:Print("/sanctuary quote 1-"..#self.Quotes.." selects a reading; no numbers are displayed.") end
    elseif verb=="tab" then
        if rest=="consumables" then rest="items" end
        if rest=="overview" or rest=="bonuses" then rest="status" end
        if rest=="crafting" then rest="craft" end
        if self.UI.tabs[rest] then self.UI.tab=rest; self.UI.offset=0; self.UI:RefreshPanel() end
    elseif verb=="fit" then
        local prefix=self.mode and self.mode~="idle" and "camp" or "idle"
        for _,key in ipairs({"Scale","OffsetX","OffsetY","Facing","Camera"}) do
            self.db[prefix..key]=self.defaults[prefix..key]
        end
        if self.mode then self.UI:Layout(); self.Scene:ApplyPose() end
        self:Print("Reset "..prefix.." model framing; weapon-safe viewport retained.")
    elseif verb=="auto" or verb=="campauto" or verb=="music" or verb=="petals" or verb=="birds" or verb=="rays" or verb=="lighting" or verb=="model" or verb=="fire" then
        local key=verb=="auto" and "automatic" or (verb=="campauto" and "automaticCampfire" or (verb=="rays" and "birds" or (verb=="lighting" and "modelLight" or verb)))
        if rest~="on" and rest~="off" then self:Print("/sanctuary "..verb.." on|off"); return end
        self.db[key]=rest=="on"
        if key=="birds" then self.db.rays=self.db.birds end -- compatibility alias
        self.UI:Labels()
        if self.mode then
            if key=="music" then self.Audio:Play()
            elseif key=="model" then self.Scene:RefreshModel()
            elseif key=="birds" or key=="petals" then self.Scene:UpdateAmbienceVisibility()
            elseif key=="modelLight" then self.Scene:ApplyLighting()
            elseif key=="fire" then self.Scene:UpdateFireVisibility() end
        end
        if key=="automaticCampfire" then self.Camping:Observe() end
    elseif verb=="quality" then
        if rest=="normal" or rest=="low" then self.db.quality=rest; self:Print("Effects quality: "..rest) end
    elseif verb=="pose" or verb=="scale" or verb=="x" or verb=="y" or verb=="facing" or verb=="camera" then
        local prefix=self.mode and self.mode~="idle" and "camp" or "idle"
        if verb=="pose" then
            if rest=="sit" or rest=="stand" or rest=="combat" or rest=="sleep" then self.db[prefix.."Pose"]=rest end
        else
            local n=tonumber(rest)
            if not self:Number(n) then self:Print("A numeric value is required."); return end
            if verb=="scale" then self.db[prefix.."Scale"]=self:Clamp(n,.55,1.65)
            elseif verb=="x" then self.db[prefix.."OffsetX"]=self:Clamp(n,-650,650)
            elseif verb=="y" then self.db[prefix.."OffsetY"]=self:Clamp(n,-350,350)
            elseif verb=="camera" then self.db[prefix.."Camera"]=self:Clamp(n,.5,2.5)
            else self.db[prefix.."Facing"]=(n*math.pi/180)%(math.pi*2) end
        end
        if self.mode then self.UI:Layout(); self.Scene:ApplyPose() end
    elseif verb=="audioreset" then self.Audio:Exit(); self:Print("Released Sanctuary's sound settings and stopped its track.")
    else
        self:Print("/sanctuary • idle | rest • live aura / waiting preview | demo • clearly labelled 60-sec visual test")
        self:Print("settings | off | status | art | diagnose | refresh | tab status|items|craft (overview/bonuses aliases) | next | quote <index>")
        self:Print("auto|campauto|music|petals|birds|lighting|model|fire on|off • quality low|normal • fit")
        self:Print("pose sit|stand|combat|sleep • scale <.55-1.65> • x|y <pixels> • facing <degrees> • camera <.5-2.5>")
    end
end
function S:OnEvent(event,a,b)
    if event=="ADDON_LOADED" then
        if a~=addonName then return end
        SLASH_MIRAGESANCTUARY1="/sanctuary"; SLASH_MIRAGESANCTUARY2="/muisanctuary"
        SlashCmdList.MIRAGESANCTUARY=function(input)
            if S.storageIssue then S:Print(S.storageIssue);return end
            S:Guard("Slash command",S.Command,S,input)
        end
        if not self:InitDB() then self:Print(self.storageIssue);return end
        self.Audio:Recover(); self.Data:Init(); self.UI:Create(); self.ready=true
        self.worldTransition=true
        for _,e in ipairs({"PLAYER_ENTERING_WORLD","PLAYER_LEAVING_WORLD","PLAYER_LOGOUT","PLAYER_REGEN_DISABLED","PLAYER_REGEN_ENABLED","PLAYER_DEAD",
            "UNIT_AURA","CHAT_MSG_TEXT_EMOTE","PLAYER_FLAGS_CHANGED","PLAYER_STARTED_MOVING","PLAYER_EQUIPMENT_CHANGED","UNIT_MODEL_CHANGED",
            "BAG_UPDATE_DELAYED","GET_ITEM_INFO_RECEIVED","UI_ERROR_MESSAGE","SKILL_LINES_CHANGED","TRADE_SKILL_SHOW","TRADE_SKILL_LIST_UPDATE",
            "TRADE_SKILL_UPDATE","NEW_RECIPE_LEARNED","UNIT_STATS","UNIT_MAXHEALTH","READY_CHECK","LFG_PROPOSAL_SHOW"}) do
            self:Guard("Register "..e,events.RegisterEvent,events,e)
        end
        -- Optional local emote posthook: catches /sit even when Blizzard does
        -- not emit a visible text-emote message. No player action is sent.
        self.Camping.hookStatus="text-emote fallback"
        if type(hooksecurefunc)=="function" and type(DoEmote)=="function" then
            local ok=self:Guard("DoEmote posthook",hooksecurefunc,"DoEmote",function(token)
                local raw=S:String(token)
                local action=raw and raw:upper()
                if action=="SIT" or action=="SLEEP" then
                    S:Guard("Fast rest intent",S.Camping.SignalRestIntent,S.Camping,"DoEmote:"..action)
                end
            end)
            if ok then self.Camping.hookStatus="DoEmote hook + text-emote fallback" end
        end
        -- Some Forever /sit and /sleep paths dispatch via SlashCmdList
        -- without calling DoEmote. Posthook the native handlers only when
        -- present; never replace them or issue a sitting action ourselves.
        local slashHooks={}
        if type(hooksecurefunc)=="function" and type(SlashCmdList)=="table" then
            for _,token in ipairs({"SIT","SLEEP","KNEEL","LAYDOWN"}) do
                if type(SlashCmdList[token])=="function" then
                    local key=token
                    local ok=self:Guard("Slash "..key.." posthook",hooksecurefunc,SlashCmdList,key,function()
                        S:Guard("Fast slash rest intent",S.Camping.SignalRestIntent,S.Camping,"SlashCmdList:"..key)
                    end)
                    if ok then slashHooks[#slashHooks+1]=key end
                end
            end
        end
        self.Camping.hookStatus=(self.Camping.hookStatus or "text-emote fallback")..
            " | slash="..(#slashHooks>0 and table.concat(slashHooks,",") or "unavailable")..
            " | posture="..(type(UnitStandState)=="function" and "available" or "unavailable")
        events:UnregisterEvent("ADDON_LOADED")
    elseif not self.ready then return
    elseif event=="PLAYER_ENTERING_WORLD" then
        self.worldTransition=false; self:BindCharacterData(); self.Data:Init(); self.Data.dirty=true; self.Camping:Reset(); self:Close("world-entered")
        -- Observe a genuine ongoing rest after load; never assume AFK on login.
        self.Camping:Observe(); self:WakePump()
    elseif event=="PLAYER_LEAVING_WORLD" or event=="PLAYER_LOGOUT" then
        self.worldTransition=true; self:Close("world-transition"); self.Camping:Reset()
    elseif event=="PLAYER_REGEN_ENABLED" then
        -- A prior cleanup can be temporarily unreadable. Retry only at this
        -- lifecycle boundary; never poll or restore an active scene's lease.
        if not self.Audio.active then self.Audio:Recover() end
    elseif event=="PLAYER_REGEN_DISABLED" or event=="PLAYER_DEAD" or event=="READY_CHECK" or event=="LFG_PROPOSAL_SHOW" then self:Close(event)
    elseif event=="PLAYER_STARTED_MOVING" then self:Close("movement")
    elseif event=="UNIT_AURA" and a=="player" then
        self.Camping:Observe(); self:WakePump()
    elseif event=="CHAT_MSG_TEXT_EMOTE" then
        local message=self:String(a)
        local sender=self:String(b)
        local unit=self:String(self:Call("UnitName",UnitName,"player"))
        local short=sender and sender:match("^[^-]+")
        local own=unit and short and short==unit
        if own and message then
            local lower=message:lower()
            if lower:find("sit down",1,true) or lower:find("fall asleep",1,true) or
               lower:find("lie down",1,true) or lower:find("kneel down",1,true) then
                self.Camping:SignalRestIntent("CHAT_MSG_TEXT_EMOTE")
            end
        end
    elseif event=="PLAYER_FLAGS_CHANGED" and (a=="player" or a==nil) then
        if self:AFK() then
            if self.db.automatic and not self.afkDismissed and not self.mode and not self.Camping.welcome then self:Open("idle","autoAFK") end
        else self.afkDismissed=nil; if self.reason=="autoAFK" then self:Close("afk-ended") end end
    elseif event=="PLAYER_EQUIPMENT_CHANGED" or (event=="UNIT_MODEL_CHANGED" and a=="player") then
        if self.mode then self.Scene:RefreshModel(); self.Data:RefreshStats() end
    elseif event=="UI_ERROR_MESSAGE" and self.mode and self.mode~="idle" then
        self.UI.actionNotice=self:String(b) or self:String(a) or "The game rejected the action."
        self.UI.noticeUntil=self:Now()+5
    elseif event=="BAG_UPDATE_DELAYED" or event=="GET_ITEM_INFO_RECEIVED" then self.Data.dirty=true
    elseif event=="TRADE_SKILL_SHOW" or event=="TRADE_SKILL_LIST_UPDATE" or event=="TRADE_SKILL_UPDATE" or event=="NEW_RECIPE_LEARNED" then
        self.Data:CaptureRecipes(); self.Data.dirty=true
    elseif event=="SKILL_LINES_CHANGED" then self.Data:RefreshStats()
    elseif (event=="UNIT_STATS" or event=="UNIT_MAXHEALTH") and a=="player" and self.mode then self.Data:RefreshStats() end
end
events:RegisterEvent("ADDON_LOADED")
events:SetScript("OnEvent",function(_,event,...)
    local ok=S:Guard("Event "..event,S.OnEvent,S,event,...)
    if not ok and (event=="PLAYER_LOGOUT" or event=="PLAYER_REGEN_DISABLED") then S.Audio:Exit() end
end)
S.events=events
-- Backward-compatible integration facade: dot calls retained from P02/P03.
local methodOpen=S.Open
S.Open=function(a,b,c)
    if a==S then return methodOpen(a,b,c) end
    return methodOpen(S,a or "idle",b or "external")
end
S.OpenCampfire=function()return methodOpen(S,"campfire","external")end
S.Version=S.version

local methodClose,methodShown=S.Close,S.IsShown
S.Close=function(a,b) if a==S then return methodClose(S,b) end; return methodClose(S,a) end
S.IsShown=function() return methodShown(S) end
S.Mode=function()return S.mode end
