local _, S = ...
local C = {requested={}}; S.Compat = C
local function number(v) return S:Number(v) end
local function text(v) return S:String(v) end
function C:Auras()
    if S:InCombat() or (C_Secrets and S:Call("ShouldAurasBeSecret",C_Secrets.ShouldAurasBeSecret)==true) then
        return nil,"RESTRICTED"
    end
    local out,seen={},{}
    -- A failed provider is not an empty aura list. Preserve the last observed
    -- rest and show unavailable timing until a complete snapshot can be read.
    local failed=false
    local function read(label,fn,...)
        if type(fn)~="function" then failed=true;return nil end
        local ok,a,b,c,d,e,f,g,h,i,j=pcall(fn,...)
        if not ok then S:Fault(label,a);failed=true;return nil end
        if S:Secret(a) then failed=true;return nil end
        return a,b,c,d,e,f,g,h,i,j
    end
    local function add(a,index)
        if type(a)~="table" or S:Secret(a) then return end
        local name,id=text(a.name),number(a.spellId or a.spellID)
        if not name and not id then return end
        if id and seen[id] then return end
        local points={}
        if type(a.points)=="table" and not S:Secret(a.points) then
            for i=1,8 do points[i]=number(a.points[i]) end
        end
        local row={name=name or "Restricted aura",id=id,duration=number(a.duration),
            expires=number(a.expirationTime),instance=number(a.auraInstanceID),icon=a.icon,
            index=index,stacks=number(a.applications) or 0,points=points}
        out[#out+1]=row; if id then seen[id]=true end
    end
    for index=1,80 do
        local a
        if C_UnitAuras and type(C_UnitAuras.GetAuraDataByIndex)=="function" then
            a=read("C_UnitAuras.GetAuraDataByIndex",C_UnitAuras.GetAuraDataByIndex,"player",index,"HELPFUL")
        elseif type(UnitAura)=="function" then
            local name,icon,count,dispel,duration,expires,source,steal,personal,id=read("UnitAura",UnitAura,"player",index,"HELPFUL")
            if name then a={name=name,icon=icon,applications=count,duration=duration,expirationTime=expires,spellId=id,sourceUnit=source} end
        elseif type(UnitBuff)=="function" then
            local name,icon,count,dispel,duration,expires,source,steal,personal,id=read("UnitBuff",UnitBuff,"player",index)
            if name then a={name=name,icon=icon,duration=duration,expirationTime=expires,spellId=id} end
        else
            return nil,"UNAVAILABLE"
        end
        if failed then return nil,"UNAVAILABLE" end
        if not a then break end
        add(a,index)
    end
    -- Individual camp effects can be hidden from the visible buff-index list.
    if C_UnitAuras and type(C_UnitAuras.GetPlayerAuraBySpellID)=="function" then
        local ids={1283391,1328375,1229741,1229739,1289723}
        for id in pairs(S.CampEffects or {}) do ids[#ids+1]=id end
        for id in pairs(S.db.welcomeIDs) do if tonumber(id) then ids[#ids+1]=tonumber(id) end end
        for _,id in ipairs(ids) do
            if not seen[id] then
                add(read("GetPlayerAuraBySpellID",C_UnitAuras.GetPlayerAuraBySpellID,id),nil)
                if failed then return nil,"UNAVAILABLE" end
            end
        end
    end
    return out
end
function C:TooltipLines(kind, a, b)
    local data
    if C_TooltipInfo then
        if kind=="aura" then data=S:Call("GetUnitBuff",C_TooltipInfo.GetUnitBuff,"player",a,"HELPFUL")
        elseif kind=="item" then data=S:Call("GetItemByID",C_TooltipInfo.GetItemByID,a)
        elseif kind=="bag" then data=S:Call("GetBagItem",C_TooltipInfo.GetBagItem,a,b) end
    end
    local lines={}
    if type(data)=="table" and type(data.lines)=="table" then
        for _,line in ipairs(data.lines) do
            if text(line.leftText) then lines[#lines+1]=line.leftText:gsub("|c%x%x%x%x%x%x%x%x",""):gsub("|r","") end
            if text(line.rightText) then lines[#lines+1]=line.rightText:gsub("|c%x%x%x%x%x%x%x%x",""):gsub("|r","") end
        end
    end
    return lines
end
function C:Item(id)
    local fn = C_Item and C_Item.GetItemInfo or GetItemInfo
    local name,link,quality,level,req,itemType,subtype,stack,equip,icon,sell,class,subclass=S:Call("GetItemInfo",fn,id)
    if not name then
        if C_Item and C_Item.RequestLoadItemDataByID and (not self.requested[id] or S:Now()-self.requested[id]>30) then
            self.requested[id]=S:Now(); S:Call("RequestLoadItemDataByID",C_Item.RequestLoadItemDataByID,id)
        end
        local instant=C_Item and C_Item.GetItemInfoInstant or GetItemInfoInstant
        local _,iType,iSub,iEquip,iIcon,iClass,iSubclass=S:Call("GetItemInfoInstant",instant,id)
        class,subclass,icon,itemType,subtype=iClass,iSubclass,iIcon,iType,iSub
    end
    local spellName,spellID=S:Call("GetItemSpell",C_Item and C_Item.GetItemSpell or GetItemSpell,id)
    return {id=id,name=text(name) or ("Item "..id.." (loading)"),link=text(link),class=number(class),
        subclass=number(subclass),icon=icon,spellID=number(spellID),spellName=text(spellName),
        subtype=text(subtype),pending=not text(name),itemType=text(itemType)}
end
function C:Bags()
    local counts, items, pending = {}, {}, 0
    local n=number(NUM_BAG_SLOTS) or 4
    n=math.min(math.max(n,4),10)
    local bagIDs={}; for bag=0,n do bagIDs[#bagIDs+1]=bag end
    local reagent=Enum and Enum.BagIndex and number(Enum.BagIndex.ReagentBag)
    if reagent and reagent>n and reagent<12 then bagIDs[#bagIDs+1]=reagent end
    for _,bag in ipairs(bagIDs) do
        local slots=number(S:Call("GetContainerNumSlots",C_Container and C_Container.GetContainerNumSlots or GetContainerNumSlots,bag)) or 0
        for slot=1,math.min(slots,100) do
            local id,count,link
            if C_Container and C_Container.GetContainerItemInfo then
                local info=S:Call("GetContainerItemInfo",C_Container.GetContainerItemInfo,bag,slot)
                if type(info)=="table" then id,count,link=number(info.itemID),number(info.stackCount),text(info.hyperlink) end
            else
                id=number(S:Call("GetContainerItemID",GetContainerItemID,bag,slot))
                local _,qty,_,_,_,_,lnk=S:Call("GetContainerItemInfo",GetContainerItemInfo,bag,slot)
                count,link=number(qty),text(lnk)
            end
            if id and id>0 and count and count>0 then
                counts[id]=(counts[id] or 0)+count
                if not items[id] then
                    local row=self:Item(id); row.bag,row.slot=bag,slot; row.link=row.link or link
                    items[id]=row
                    if row.pending then pending=pending+1 end
                end
            end
        end
    end
    for id,row in pairs(items) do row.count=counts[id] end
    return counts,items,pending
end
function C:Stats()
    local rows={}; local values={}
    local function add(key,label,val,fmt)
        local n=number(val)
        rows[#rows+1]={key=key,label=label,value=n,format=fmt or "%d"}
        values[key]=n
    end
    add("health","Maximum health",S:Call("UnitHealthMax",UnitHealthMax,"player"))
    for i,label in ipairs({"Strength","Agility","Stamina","Intellect","Spirit"}) do
        local base,effective=S:Call("UnitStat",UnitStat,"player",i)
        add("stat"..i,label,effective or base)
    end
    local base,pos,neg=S:Call("UnitAttackPower",UnitAttackPower,"player")
    local ap=number(base) and number(base)+(number(pos) or 0)+(number(neg) or 0) or nil
    add("attack","Attack power",ap)
    local _,armor=S:Call("UnitArmor",UnitArmor,"player"); add("armor","Armor",armor)
    add("crit","Melee critical chance",S:Call("GetCritChance",GetCritChance),"%.1f%%")
    local spellPower
    for school=2,7 do
        local n=number(S:Call("GetSpellBonusDamage",GetSpellBonusDamage,school))
        if n then spellPower=math.max(spellPower or n,n) end
    end
    add("spell","Spell bonus (highest school)",spellPower)
    add("haste","Haste",S:Call("GetHaste",GetHaste),"%.1f%%")
    return rows,values
end
function C:Professions()
    local result={}; local seen={}
    if type(GetProfessions)=="function" and type(GetProfessionInfo)=="function" then
        -- Explicit numeric traversal handles holes between primary/secondary professions.
        local a,b,c,d,e,f=S:Call("GetProfessions",GetProfessions)
        local indexes={[1]=a,[2]=b,[3]=c,[4]=d,[5]=e,[6]=f}
        for i=1,6 do
            local index=number(indexes[i])
            if index and not seen[index] then
                seen[index]=true
                local name,icon,rank,max,_,_,skillLineID=S:Call("GetProfessionInfo",GetProfessionInfo,index)
                if text(name) then result[#result+1]={name=name,rank=number(rank),maximum=number(max),icon=icon,skillLineID=number(skillLineID)} end
            end
        end
    end
    -- Classic / Forever clients may expose the skill-line APIs instead.
    if #result==0 and type(GetNumSkillLines)=="function" and type(GetSkillLineInfo)=="function" then
        local count=number(S:Call("GetNumSkillLines",GetNumSkillLines)) or 0
        local section=""
        for i=1,math.min(count,300) do
            local name,header,expanded,rank,temp,mod,max=S:Call("GetSkillLineInfo",GetSkillLineInfo,i)
            if header then section=text(name) or ""
            elseif text(name) and (section==TRADE_SKILLS or section==SECONDARY_SKILLS or section=="Professions" or section=="Secondary Skills" or section=="Tradeskills") then
                result[#result+1]={name=name,rank=number(rank),maximum=number(max)}
            end
        end
    end
    table.sort(result,function(a,b)return a.name<b.name end)
    return result
end
