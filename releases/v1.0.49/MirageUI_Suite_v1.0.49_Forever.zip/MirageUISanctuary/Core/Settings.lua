local _,S=...
-- Configuration is separate from the full-screen scene. Opening settings does
-- not enter rest, start a demonstration, scan professions or use an item.
S.Settings={tab="behavior",framingMode="idle"}
local U=S.Settings
local unpackColor=unpack or table.unpack
local colors={background={.035,.035,.038,.98},panel={.060,.060,.065,.97},edge={.26,.26,.26,1},text={.90,.89,.87,1},
    muted={.63,.62,.60,1},gold={.96,.79,.36,1},accent={.91,.55,.18,1},
    fill={.060,.060,.065,.97},hover={.15,.12,.08,.98},active={.15,.12,.08,.98}}
local rows={
    {key="automatic",command="auto",label="Open when AFK",tab="behavior",help="Open the quiet scene when the client marks you away."},
    {key="automaticCampfire",command="campauto",label="Open during campfire rest",tab="behavior",help="Open when supported campfire rest begins."},
    {key="music",command="music",label="Scene music",tab="atmosphere",help="Play the scene soundtrack; restore your sound settings on exit."},
    {key="petals",command="petals",label="Drifting petals",tab="atmosphere",help="Show the quiet scene's drifting petals."},
    {key="birds",command="birds",label="Distant birds",tab="atmosphere",help="Show the campfire scene's distant birds."},
    {key="modelLight",command="lighting",label="Character lighting",tab="atmosphere",help="Light the character preview within Sanctuary."},
    {key="model",command="model",label="Character preview",tab="atmosphere",help="Include your character in the scene composition."},
    {key="fire",command="fire",label="Campfire effect",tab="atmosphere",help="Show the campfire's cosmetic flame effect."},
}
local framing={
    {key="Pose",label="Pose",help="Change only the displayed character model."},
    {key="Scale",label="Character scale",help="Size within the scene's existing viewport.",step=.05,min=.55,max=1.65,percent=true},
    {key="Camera",label="Camera distance",help="Model framing only; your game camera stays as it is.",step=.05,min=.5,max=2.5,percent=true},
    {key="Facing",label="Facing",help="Turn the displayed model in 15-degree steps.",step=15,min=0,max=360,degrees=true},
    {key="OffsetX",label="Horizontal position",help="Move the model left or right within its viewport.",step=20,min=-650,max=650},
    {key="OffsetY",label="Vertical position",help="Move the model lower or higher within its viewport.",step=20,min=-350,max=350},
}
local tabs={{"behavior","Behavior"},{"atmosphere","Atmosphere"},{"framing","Framing"}}
local function text(parent,value,size,x,y,width,role)
    local f=parent:CreateFontString(nil,"OVERLAY")
    f:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",size,"")
    f:SetTextColor(unpackColor(colors[role or "text"]))
    f:SetJustifyH("LEFT");f:SetJustifyV("MIDDLE")
    f:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y);f:SetSize(width,24);f:SetText(value)
    return f
end
local function paint(b)
    b.fill:SetColorTexture(unpackColor(b.active and colors.active or b.hovered and colors.hover or colors.fill))
    b.label:SetTextColor(unpackColor(colors.text))
    for _,edge in ipairs(b.edges)do edge:SetColorTexture(unpackColor((b.active or b.hovered) and colors.accent or colors.edge))end
    if b.active or b.hovered then b.stripe:Show()else b.stripe:Hide()end
    b.gloss:SetVertexColor(.96,.79,.36,b.hovered and .58 or b.active and .45 or .22)
end
local function button(parent,value,x,y,width,callback)
    local b=CreateFrame("Button",nil,parent)
    b:SetSize(width,30);b:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
    b.fill=b:CreateTexture(nil,"BACKGROUND");b.fill:SetAllPoints(b)
    b.edges={}
    for _,side in ipairs({"TOP","BOTTOM","LEFT","RIGHT"})do
        local edge=b:CreateTexture(nil,"BORDER")
        if side=="TOP" or side=="BOTTOM"then edge:SetPoint(side.."LEFT",b,side.."LEFT");edge:SetPoint(side.."RIGHT",b,side.."RIGHT");edge:SetHeight(1)
        else edge:SetPoint("TOP"..side,b,"TOP"..side);edge:SetPoint("BOTTOM"..side,b,"BOTTOM"..side);edge:SetWidth(1)end
        b.edges[#b.edges+1]=edge
    end
    b.gloss=b:CreateTexture(nil,"BORDER");b.gloss:SetAllPoints(b);b.gloss:SetTexture(S.media.."ButtonGloss.tga")
    b.stripe=b:CreateTexture(nil,"OVERLAY");b.stripe:SetColorTexture(unpackColor(colors.accent));b.stripe:SetPoint("TOPLEFT",b,"TOPLEFT",1,-3);b.stripe:SetPoint("BOTTOMLEFT",b,"BOTTOMLEFT",1,3);b.stripe:SetWidth(2)
    b.label=text(b,value,12,6,-3,width-12);b.label:SetJustifyH("CENTER")
    b:SetScript("OnEnter",function(self)self.hovered=true;paint(self)end)
    b:SetScript("OnLeave",function(self)self.hovered=false;paint(self)end)
    b:SetScript("OnHide",function(self)self.hovered=false;paint(self)end)
    b:SetScript("OnClick",function()if not S:InCombat() then callback()end end)
    paint(b);return b
end
local function active(b,value)b.active=value==true;paint(b)end
local function show(frame,value)if value then frame:Show()else frame:Hide()end end
function U:Ready()
    return S.ready and type(S.db)=="table" and self.contextDB==S.db and not S:InCombat() and
        not S.worldTransition
end
function U:Fit()
    if not self.frame or not UIParent then return false end
    local w=S:Number(S:Call("Settings width",UIParent.GetWidth,UIParent))
    local h=S:Number(S:Call("Settings height",UIParent.GetHeight,UIParent))
    if not w or not h or w<180 or h<180 then return false end
    self.frame:SetScale(math.min(1,(w-24)/640,(h-24)/640))
    return true
end
function U:Notice(value)
    self.notice=value or ""
    if self.note then self.note:SetText(self.notice~="" and self.notice or "Changes save immediately. Preview opens only when you choose it.")end
end
function U:SelectTab(tab)
    if tab~="behavior" and tab~="atmosphere" and tab~="framing" then return false end
    self.tab=tab;self:Notice("");self:Refresh();return true
end
function U:Refresh()
    if not self.frame or not S.db then return end
    local count=0
    for i,row in ipairs(rows) do
        local cell=self.cells[i];local visible=row.tab==self.tab
        if visible then
            count=count+1;cell:ClearAllPoints();cell:SetPoint("TOPLEFT",self.frame,"TOPLEFT",20,-151-(count-1)*55)
        end
        show(cell,visible)
        local b=self.toggles[i]
        b.label:SetText(S.db[row.key] and "On" or "Off");active(b,S.db[row.key])
    end
    for key,b in pairs(self.tabs)do active(b,key==self.tab)end
    show(self.qualityRow,self.tab=="atmosphere")
    self.quality.label:SetText(S.db.quality=="low" and "Low" or "Normal")
    show(self.behaviorNote,self.tab=="behavior")
    show(self.previewQuiet,self.tab=="behavior");show(self.previewRest,self.tab=="behavior")
    show(self.framingPanel,self.tab=="framing")
    self.subtitle:SetText(({behavior="Choose when Sanctuary opens",atmosphere="Keep the scene as quiet or detailed as you prefer",framing="Compose each character preview independently"})[self.tab])
    if self.tab=="framing" then
        local mode=self.framingMode
        active(self.idleMode,mode=="idle");active(self.campMode,mode=="camp")
        for i,spec in ipairs(framing)do
            local value=S.db[mode..spec.key]
            local fallback=S.defaults and S.defaults[mode..spec.key]
            local label
            if spec.key=="Pose" then label=tostring(value or fallback or "sit")
            else
                value=S:Number(value) or S:Number(fallback) or 0
                if spec.degrees then label=string.format("%.0f°",(value*180/math.pi)%360)
                elseif spec.percent then label=string.format("%.0f%%",value*100)
                else label=string.format("%+.0f",value)end
            end
            self.framingRows[i].value:SetText(label)
        end
    end
end
function U:SetToggle(index)
    local row=rows[index]
    if not row or not self:Ready() then return false end
    S:Command(row.command.." "..(S.db[row.key] and "off" or "on"))
    self:Notice(row.label.." "..(S.db[row.key] and "enabled." or "disabled."));self:Refresh();return true
end
local function snapshot(mode)
    local result={}
    for _,spec in ipairs(framing)do result[spec.key]=S.db[mode..spec.key]end
    return result
end
local function same(mode,values)
    for _,spec in ipairs(framing)do if S.db[mode..spec.key]~=values[spec.key]then return false end end
    return true
end
function U:ApplyFraming(mode,values)
    if not self:Ready() or (mode~="idle" and mode~="camp") or type(values)~="table" then return false end
    local db=S.db
    local before=snapshot(mode)
    local valid={}
    local poses=mode=="idle" and {sit=true,stand=true,sleep=true} or {combat=true,sit=true,stand=true}
    for _,spec in ipairs(framing)do
        local value=values[spec.key]
        if spec.key=="Pose" then if not poses[value]then return false end
        elseif not S:Number(value) then return false
        elseif spec.degrees then value=value%(math.pi*2)
        else value=math.max(spec.min,math.min(spec.max,value))end
        valid[spec.key]=value
    end
    if not self:Ready() or S.db~=db or not same(mode,before) then return false end
    for _,spec in ipairs(framing)do S.db[mode..spec.key]=valid[spec.key]end
    self.undoFraming={db=S.db,mode=mode,before=before,after=valid}
    -- Settings normally close a scene. If another explicit action opened one,
    -- refresh only the matching displayed model, never the player's pose.
    if S.mode and (S.mode=="idle" and "idle" or "camp")==mode then
        if S.UI and type(S.UI.Layout)=="function" then S:Guard("Settings framing layout",S.UI.Layout,S.UI)end
        if S.Scene and type(S.Scene.ApplyPose)=="function" then S:Guard("Settings framing pose",S.Scene.ApplyPose,S.Scene)end
    end
    self:Notice("Saved "..(mode=="idle" and "quiet" or "campfire").." scene framing.");self:Refresh();return true
end
function U:Adjust(index,direction)
    if not self:Ready() or (direction~=1 and direction~=-1) then return false end
    local spec=framing[index];if not spec then return false end
    local mode=self.framingMode;local values=snapshot(mode)
    if spec.key=="Pose" then
        local options=mode=="idle" and {"sit","stand","sleep"} or {"combat","sit","stand"}
        local at=1;for i,value in ipairs(options)do if value==values.Pose then at=i end end
        values.Pose=options[(at-1+direction)%#options+1]
    else
        local value=S:Number(values[spec.key]);if not value then return false end
        values[spec.key]=spec.degrees and (value+direction*spec.step*math.pi/180) or (value+direction*spec.step)
    end
    return self:ApplyFraming(mode,values)
end
function U:ResetFraming()
    if not self:Ready() or type(S.defaults)~="table" then return false end
    local values={};for _,spec in ipairs(framing)do values[spec.key]=S.defaults[self.framingMode..spec.key]end
    return self:ApplyFraming(self.framingMode,values)
end
function U:UndoFraming()
    local undo=self.undoFraming
    if not self:Ready() or not undo or undo.db~=S.db or not same(undo.mode,undo.after) then
        self:Notice("No unchanged framing edit is available to undo.");return false
    end
    local ok=self:ApplyFraming(undo.mode,undo.before)
    if ok then self.undoFraming=nil;self:Notice("Restored the framing before your last edit.")end
    return ok
end
function U:Preview(mode)
    if not self:Ready() or (mode~="idle" and mode~="demo") then return false end
    local opened=S:Open(mode,"settings-preview")
    if opened==true then self.frame:Hide();return true end
    self:Notice("The scene can open after loading, while alive and outside combat.");return false
end
function U:Create()
    if self.frame or not UIParent or S:InCombat() then return end
    local f=CreateFrame("Frame","MirageUISanctuarySettings",UIParent,"BackdropTemplate")
    f:SetSize(640,640);f:SetPoint("CENTER",UIParent,"CENTER",0,0)
    f:SetFrameStrata("DIALOG");f:SetClampedToScreen(true);f:EnableMouse(true);f:SetMovable(true)
    f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8x8",edgeFile="Interface\\Buttons\\WHITE8x8",edgeSize=1})
    f:SetBackdropColor(unpackColor(colors.background));f:SetBackdropBorderColor(unpackColor(colors.edge))
    local shine=f:CreateTexture(nil,"BACKGROUND");shine:SetAllPoints(f);shine:SetTexture(S.media.."PanelShine.tga");shine:SetVertexColor(.82,.53,.29,.17)
    local glass=f:CreateTexture(nil,"BACKGROUND");glass:SetAllPoints(f);glass:SetTexture(S.media.."OptionsPanelGlass.tga");glass:SetVertexColor(.72,.53,.33,.23)
    local rule=f:CreateTexture(nil,"BORDER");rule:SetColorTexture(.91,.55,.18,.70)
    rule:SetPoint("TOPLEFT",f,"TOPLEFT",1,-1);rule:SetPoint("TOPRIGHT",f,"TOPRIGHT",-1,-1);rule:SetHeight(2)
    local mark=f:CreateTexture(nil,"ARTWORK");mark:SetTexture(S.media.."SanctuaryBadge.tga")
    mark:SetSize(32,32);mark:SetPoint("TOPLEFT",f,"TOPLEFT",20,-14)
    local title=text(f,"Sanctuary",14,60,-16,440)
    title:ClearAllPoints();title:SetPoint("LEFT",mark,"RIGHT",8,0)
    self.title,self.mark=title,mark
    local drag=CreateFrame("Frame",nil,f);drag:SetPoint("TOPLEFT",f,"TOPLEFT",0,0);drag:SetSize(520,52)
    drag:EnableMouse(true);drag:RegisterForDrag("LeftButton")
    drag:SetScript("OnDragStart",function()if not S:InCombat()then f:StartMoving()end end)
    drag:SetScript("OnDragStop",function()f:StopMovingOrSizing()end)
    button(f,"Close",542,-16,78,function()f:Hide()end)
    self.subtitle=text(f,"",14,20,-59,600,"muted")
    self.tabs={}
    for i,tab in ipairs(tabs)do
        self.tabs[tab[1]]=button(f,tab[2],20+(i-1)*202,-98,194,function()U:SelectTab(tab[1])end)
    end
    self.toggles={};self.cells={}
    for i,row in ipairs(rows)do
        local cell=CreateFrame("Frame",nil,f);cell:SetSize(600,52);self.cells[i]=cell
        text(cell,row.label,15,0,0,470)
        local hint=text(cell,row.help,12,0,-25,476,"muted");hint:SetHeight(26);hint:SetWordWrap(true)
        self.toggles[i]=button(cell,"",500,-7,100,function()U:SetToggle(i)end)
    end
    self.qualityRow=CreateFrame("Frame",nil,f);self.qualityRow:SetSize(600,52);self.qualityRow:SetPoint("TOPLEFT",f,"TOPLEFT",20,-489)
    text(self.qualityRow,"Effects quality",15,0,0,470)
    text(self.qualityRow,"Low reduces the existing particle detail.",12,0,-25,476,"muted")
    self.quality=button(self.qualityRow,"",500,-7,100,function()
        if U:Ready() then S:Command("quality "..(S.db.quality=="low" and "normal" or "low"));U:Refresh()end
    end)
    self.behaviorNote=text(f,"Away and campfire settings work independently.\n\nClosing a scene dismisses the current away or rest session. Combat and loading close the scene.",14,20,-282,600,"muted")
    self.behaviorNote:SetHeight(188);self.behaviorNote:SetWordWrap(true)
    self.previewQuiet=button(f,"Preview quiet scene",20,-486,292,function()U:Preview("idle")end)
    self.previewRest=button(f,"Preview campfire",322,-486,298,function()U:Preview("demo")end)
    local p=CreateFrame("Frame",nil,f);self.framingPanel=p;p:SetSize(600,400);p:SetPoint("TOPLEFT",f,"TOPLEFT",20,-145)
    self.idleMode=button(p,"Quiet scene",0,0,292,function()U.framingMode="idle";U:Refresh()end)
    self.campMode=button(p,"Campfire scene",302,0,298,function()U.framingMode="camp";U:Refresh()end)
    self.framingRows={}
    for i,spec in ipairs(framing)do
        local y=-45-(i-1)*46
        text(p,spec.label,14,0,y,365)
        local help=text(p,spec.help,12,0,y-22,365,"muted");help:SetHeight(22)
        local row={};self.framingRows[i]=row
        row.minus=button(p,"−",378,y-3,38,function()U:Adjust(i,-1)end)
        row.value=text(p,"",14,426,y,114,"gold");row.value:SetJustifyH("CENTER")
        row.plus=button(p,"+",562,y-3,38,function()U:Adjust(i,1)end)
    end
    self.resetFraming=button(p,"Restore framing",0,-332,190,function()U:ResetFraming()end)
    self.undo=button(p,"Undo framing edit",202,-332,190,function()U:UndoFraming()end)
    self.previewFraming=button(p,"Preview this scene",404,-332,196,function()U:Preview(U.framingMode=="idle" and "idle" or "demo")end)
    self.note=text(f,"",12,20,-563,600,"muted");self.note:SetHeight(55);self.note:SetWordWrap(true)
    for _,event in ipairs({"PLAYER_REGEN_DISABLED","PLAYER_LEAVING_WORLD","UI_SCALE_CHANGED","DISPLAY_SIZE_CHANGED"})do pcall(f.RegisterEvent,f,event)end
    f:SetScript("OnEvent",function(_,event)
        if event=="PLAYER_REGEN_DISABLED" or event=="PLAYER_LEAVING_WORLD" then f:Hide()
        elseif f:IsShown() and not S:InCombat() and not U:Fit() then f:Hide()end
    end)
    if type(UISpecialFrames)=="table" then
        local found=false;for _,name in ipairs(UISpecialFrames)do if name=="MirageUISanctuarySettings" then found=true end end
        if not found then UISpecialFrames[#UISpecialFrames+1]="MirageUISanctuarySettings"end
    end
    f:Hide();self.frame=f
end
function U:Open()
    if not S.ready or not S.db then return false,"Sanctuary has not finished loading."end
    if S.worldTransition then return false,"Open Sanctuary settings after the loading screen."end
    if S:InCombat()then return false,"Open Sanctuary settings after combat."end
    self:Create()
    if not self.frame or not self:Fit()then return false,"Not enough room to open Sanctuary settings."end
    if S:IsShown()then S:Close("settings")end
    self.contextDB=S.db
    self:Notice("");self:Refresh();self.frame:Show();return true
end
