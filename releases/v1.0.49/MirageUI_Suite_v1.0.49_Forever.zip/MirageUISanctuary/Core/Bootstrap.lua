local addonName, S = ...
S.name, S.version = addonName, "0.4.18"
S.media = "Interface\\AddOns\\" .. addonName .. "\\Media\\"
S.faults, S.audit = {}, {}
S.defaults = {
    automatic = false, automaticCampfire = true, music = true, petals = true, birds = true, rays = true, modelLight = true,
    model = true, fire = true, idlePose = "sit", campPose = "combat",
    idleScale = 1, campScale = 1, idleOffsetX = 0, idleOffsetY = 0,
    campOffsetX = 0, campOffsetY = 0, idleFacing = 0.35, campFacing = 0.52,
    idleCamera = 1.15, campCamera = 1.22, quality = "normal", welcomeIDs = {},
}
function S:Print(text)
    if DEFAULT_CHAT_FRAME and DEFAULT_CHAT_FRAME.AddMessage then
        DEFAULT_CHAT_FRAME:AddMessage("|cffefc9a4Sanctuary:|r " .. tostring(text))
    end
end
function S:Secret(v)
    if type(issecretvalue) == "function" then local ok, b = pcall(issecretvalue, v); return ok and b end
    return false
end
function S:Number(v)
    if self:Secret(v) then return nil end
    if type(v) == "number" and v == v and v > -math.huge and v < math.huge then return v end
end
function S:String(v)
    if not self:Secret(v) and type(v) == "string" then return v end
end
function S:Clamp(v, lo, hi) return math.max(lo, math.min(hi, v)) end
function S:Fault(label, err)
    local message = self:String(err) or "Unavailable / restricted value"
    self.faults[label] = { message = message:sub(1, 240), count = ((self.faults[label] or {}).count or 0) + 1 }
end
function S:Call(label, fn, ...)
    if type(fn) ~= "function" then return nil end
    local ok,a,b,c,d,e,f,g,h,i,j,k,l,m,n,o = pcall(fn, ...)
    if not ok then self:Fault(label,a); return nil end
    return a,b,c,d,e,f,g,h,i,j,k,l,m,n,o
end
function S:Guard(label, fn, ...)
    local ok, result = pcall(fn, ...)
    if not ok then self:Fault(label, result) end
    return ok, result
end
function S:Now() return self:Number(self:Call("GetTime", GetTime)) or 0 end
function S:InCombat()
    return self:Call("InCombatLockdown", InCombatLockdown) == true or
        self:Call("UnitAffectingCombat", UnitAffectingCombat, "player") == true
end
function S:AFK() return self:Call("UnitIsAFK", UnitIsAFK, "player") == true end
function S:Dead() return self:Call("UnitIsDeadOrGhost", UnitIsDeadOrGhost, "player") == true end
function S:InitDB()
    if MirageUISanctuaryDB == nil then MirageUISanctuaryDB = {} end
    local db = MirageUISanctuaryDB
    if type(db)~="table" or (db.schema~=nil and
        (not self:Number(db.schema) or db.schema<0 or db.schema~=math.floor(db.schema) or db.schema>10)) or
        (db.characters~=nil and type(db.characters)~="table") then
        self.storageIssue="Sanctuary paused because its saved data uses an unsupported format."
        return false,self.storageIssue
    end
    -- Keep preferences and the P02/P03 tuning; never discard unrelated keys.
    if not db.schema then
        db.idleScale = db.idleScale or db.scale
        db.idleOffsetX = db.idleOffsetX or db.offsetX
        db.idleOffsetY = db.idleOffsetY or db.offsetY
        db.idleFacing = db.idleFacing or db.facing
        db.idlePose = db.idlePose or db.pose
    end
    for k,v in pairs(self.defaults) do
        if type(db[k]) ~= type(v) then db[k] = type(v)=="table" and {} or v end
    end
    for _,mode in ipairs({"idle","camp"}) do
        for key, bounds in pairs({Scale={0.55,1.65}, OffsetX={-650,650}, OffsetY={-350,350}, Facing={-6.29,6.29}, Camera={0.5,2.5}}) do
            local name = mode .. key
            db[name] = self:Clamp(self:Number(db[name]) or self.defaults[name], bounds[1], bounds[2])
        end
    end
    if (self:Number(db.schema) or 0) < 6 then
        if db.campScale == 1 then db.campScale = self.defaults.campScale end
        if db.campOffsetX == 0 then db.campOffsetX = self.defaults.campOffsetX end
        if db.campOffsetY == 0 then db.campOffsetY = self.defaults.campOffsetY end
        if db.campFacing == 0.48 then db.campFacing = self.defaults.campFacing end
        if db.campCamera == 1.15 then db.campCamera = self.defaults.campCamera end
    end
    if db.quality ~= "low" then db.quality = "normal" end
    if db.idlePose ~= "sit" and db.idlePose ~= "stand" and db.idlePose ~= "sleep" then db.idlePose="sit" end
    if db.campPose ~= "combat" and db.campPose ~= "sit" and db.campPose ~= "stand" then db.campPose="combat" end
    if (self:Number(db.schema) or 0) < 7 then
        -- Only untouched P07 stock framing is migrated. User tuning survives.
        if db.campScale==0.92 then db.campScale=1 end
        if db.campOffsetX==28 then db.campOffsetX=0 end
        if db.campCamera==1.28 then db.campCamera=1.22 end
        db.rays=db.petals -- P07 stored its rays preference in this legacy field.
    end
    if (self:Number(db.schema) or 0) < 8 then
        if db.fire == nil then db.fire = true end
    end
    -- P10 used a shared ray/petal toggle. On migration preserve its value
    -- separately for the new distant-birds campfire effect.
    if (self:Number(db.schema) or 0) < 9 then
        db.birds=db.rays == true
        db.petals=db.petals ~= false
    end
    db.schema = 10
    self.db = db
    local version, build, _, interface = self:Call("GetBuildInfo", GetBuildInfo)
    self.client = {version=self:String(version) or "unknown", build=self:String(build) or tostring(self:Number(build) or 0), interface=self:Number(interface) or 0}
    db.characters=db.characters or {}
    self:BindCharacterData()
    return true
end
_G.MirageUISanctuary = S

function S:BindCharacterData()
    local name=self:String(self:Call("UnitName",UnitName,"player"))
    local realm=self:String(self:Call("GetRealmName",GetRealmName))
    local key=name and name~="" and realm and realm~="" and (realm..":"..name) or nil
    if not key or (self.db.characters[key]~=nil and type(self.db.characters[key])~="table") then
        self.characterKey=nil
        self.temporaryCharacter=self.temporaryCharacter or {}
        self.characterDB=self.temporaryCharacter
        return
    end
    self.db.characters[key]=self.db.characters[key] or {}
    self.characterKey=key
    self.characterDB=self.db.characters[key]
    self.temporaryCharacter=nil
end
