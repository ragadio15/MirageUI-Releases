local _, S = ...
local C={nearby=false,auras={},welcome=nil,session=nil,suppressed=nil,result=nil}; S.Camping=C
-- Player-supplied live screenshot, Forever build 70938: Campfire Nearby = 1283391.
C.nearbyID=1283391
-- Violet Flames (Pouch of Violet Dust) player-facing aura is 1328375.
-- 'Flames' is a named-aura fallback observed on some client variants; it
-- is accepted only when the *player* changes to a rest posture or emotes.
-- Neither flame aura alone opens the scene as the player walks past.
C.violetID=1328375
local restStates={[1]=true,[2]=true,[3]=true,[4]=true,[5]=true,[6]=true,[8]=true}
function C:IsFireSignal(a)
    if not a then return false end
    if a.id==self.nearbyID or a.id==self.violetID then return true end
    local name=a.name
    return name=="Campfire Nearby" or name=="Violet Flames" or name=="Flames"
end
function C:RestPosture()
    if type(UnitStandState)~="function" then return nil end
    return S:Number(S:Call("UnitStandState",UnitStandState,"player"))
end
-- Only the *transition* into a resting stance is actionable. Sampling the
-- initial state after aura acquisition prevents spurious activation when a
-- player walks into camp range already seated.
function C:WatchPosture(baselineOnly)
    if not self.fireReady or not S.db or not S.db.automaticCampfire then return false end
    local state=self:RestPosture()
    if not state then return false end
    local previous=self.lastPosture
    self.lastPosture=state
    if baselineOnly or previous==nil or previous==state or not restStates[state] then return false end
    return self:SignalRestIntent("UnitStandState:"..tostring(state))
end
-- Forever 1.60.1 has two documented spell records for Welcoming Campfire.
-- The current player aura's instance + expiration remains authoritative;
-- proximity alone (1283391) is never considered an active rest.
C.welcomeSpellIDs={[1229739]=true,[1289723]=true}
local function key(a) return tostring(a.instance or a.id or a.name)..":"..tostring(a.expires or "untimed") end
function C:IsWelcome(a)
    if a.id and C.welcomeSpellIDs[a.id] then return true end
    if a.name=="Welcoming Campfire" then
        if a.id then S.db.welcomeIDs[tostring(a.id)]=true end
        return true
    end
    return a.id and S.db.welcomeIDs[tostring(a.id)]==true
end
-- Fast visual entry is independent of server rest timing. Do not infer a
-- 60-second countdown from an emote: the Welcoming Campfire aura remains the
-- sole countdown source. A short pending window prevents stale previews.
function C:SignalRestIntent(source)
    if not S.ready or not S.db or not S.db.automaticCampfire or S:InCombat() or S:Dead() or S.worldTransition then return false end
    local now=S:Now()
    if self.pendingDismissedUntil and now<self.pendingDismissedUntil then return false end
    -- Normal campfire and violet fire are independent signals. The freshest
    -- UNIT_AURA observation is normally already cached; only refresh when
    -- no recognized flame aura is known yet (e.g. slash fired first).
    if not self.fireReady then self:Observe() end
    if self.welcome or not self.fireReady or S.mode=="campfire" or S.mode=="demo" then return false end
    if self.pending and now-self.pending.at<1.0 then return false end
    self.result=nil -- never display a previous session's Complete during a new rest intent
    S.settleUntil=nil
    self.pending={at=now,expires=now+14,source=source or "emote"}
    if not S:Open("campfire","rest-intent") then self.pending=nil; return false end
    S:WakePump()
    return true
end
function C:Observe()
    local auras,why=S.Compat:Auras()
    if not auras then self.restricted=why; return end
    self.restricted=nil
    local nearby,violet,flames,welcome,benefits=false,false,false,nil,nil
    for _,a in ipairs(auras) do
        if a.id==self.nearbyID or a.name=="Campfire Nearby" then nearby=true end
        if a.id==self.violetID or a.name=="Violet Flames" then violet=true end
        if a.name=="Flames" then flames=true end
        if self:IsWelcome(a) then welcome=a end
        if a.id==1229741 or a.name=="Camp Benefits" then benefits=a end
    end
    local wasReady=self.fireReady
    self.auras,self.nearby,self.violet,self.flames,self.benefits=auras,nearby,violet,flames,benefits
    self.fireReady=nearby or violet or flames
    if self.fireReady and not wasReady then self:WatchPosture(true) end
    if not self.fireReady then self.lastPosture=nil end
    if welcome and welcome.expires and welcome.expires<=S:Now() then welcome=nil end
    local prior=self.session
    if welcome then
        self.pending=nil -- authoritative server timer supersedes the preliminary scene
        local k=key(welcome)
        -- An early manual dismissal must remain dismissed for the entire
        -- subsequent server session, not just the short emote debounce.
        if self.pendingDismissedUntil and S:Now()<self.pendingDismissedUntil then
            self.suppressed=k
        end
        if not prior or prior.key~=k then
            local _,values=S.Compat:Stats()
            local oldAuras={}; for _,a in ipairs(auras) do if a.id then oldAuras[a.id]=a.expires or true end end
            self.session={key=k,started=S:Now(),before=values,beforeAuras=oldAuras,
                duration=welcome.duration and welcome.duration>0 and welcome.duration or nil,
                expires=welcome.expires,late=welcome.duration and welcome.expires and (welcome.expires-S:Now()<welcome.duration-2) or false}
            self.result=nil
        else
            prior.expires=welcome.expires; prior.duration=welcome.duration and welcome.duration>0 and welcome.duration or prior.duration
        end
        self.welcome=welcome
        if S.db.automaticCampfire and self.suppressed~=k and
           (not self.pendingDismissedUntil or S:Now()>=self.pendingDismissedUntil) and
           not S:InCombat() and not S:Dead() and not S.worldTransition then
            if S.mode~="campfire" then S:Open("campfire","aura") end
        end
    else
        self.welcome=nil
        if prior then
            local _,after=S.Compat:Stats()
            local elapsed=prior.expires and S:Now()>=prior.expires
            local added={}
            for _,a in ipairs(auras) do
                if a.id and a.id~=self.nearbyID and not self:IsWelcome(a) and
                    prior.beforeAuras[a.id]~=(a.expires or true) then added[#added+1]=a.name end
            end
            self.result={before=prior.before,after=after,added=added,
                beforeAuras=prior.beforeAuras, status=elapsed and "Rest timer ended; observed changes below" or "Rest interrupted / aura removed",
                at=S:Now(),late=prior.late,expires=prior.expires,duration=prior.duration,finished=elapsed==true}
            self.session=nil; self.suppressed=nil
            S.settleUntil=elapsed and (S:Now()+10) or nil
            if S.mode=="campfire" then
                if elapsed then
                    if S.UI then S.UI:RefreshPanel() end
                else S:Close("rest-ended") end
            end
        end
    end
    -- If the campfire server never starts a rest, do not linger in a
    -- preliminary (non-timed) screen or claim a reward.
    if not welcome and self.pending and (not self.fireReady or S:Now()>=self.pending.expires) then
        self.pending=nil
        if S.mode=="campfire" and S.reason=="rest-intent" then
            S:Close("rest-aura-not-confirmed")
        end
    end
    if S.settleUntil and self.result then
        local _,after=S.Compat:Stats(); self.result.after=after
        local added={}
        for _,a in ipairs(auras) do
            if a.id and a.id~=self.nearbyID and not self:IsWelcome(a) and
                self.result.beforeAuras[a.id]~=(a.expires or true) then added[#added+1]=a.name end
        end
        self.result.added=added
        if S:Now()>=S.settleUntil then S.settleUntil=nil end
    end
    if S.mode=="campfire" and S.UI then S.UI:UpdateTimer() end
end
function C:Remaining()
    -- A completed session is historical, not invalidated by later restrictions.
    if S.mode=="campfire" and not self.session and self.result and self.result.finished then
        return 0,self.result.duration or 60,"ENDED"
    end
    if self.restricted then return nil,nil,"RESTRICTED" end
    if self.welcome and self.session and self.session.expires then
        return math.max(0,self.session.expires-S:Now()),self.session.duration,"AURA"
    end
    if self.welcome then return nil,nil,"UNTIMED_AURA" end
    if S.mode=="campfire" and self.pending then return nil,nil,"PENDING" end
    if S.mode=="demo" then
        local remaining=math.max(0,(S.demoEnd or S:Now())-S:Now())
        return remaining,60,remaining==0 and "DEMO_ENDED" or "DEMO"
    end
    return nil,nil,"PREVIEW"
end
function C:Dismiss()
    if self.session then self.suppressed=self.session.key end
    if self.pending then self.pendingDismissedUntil=S:Now()+18 end
    self.pending=nil
end
function C:Reset()
    self.welcome=nil; self.session=nil; self.nearby=false; self.suppressed=nil; self.auras={}
    self.violet=false; self.flames=false; self.fireReady=false; self.lastPosture=nil
    self.result=nil; self.restricted=nil; self.benefits=nil
    self.pending=nil; self.pendingDismissedUntil=nil
    S.settleUntil=nil; S.completionUntil=nil
end
function C:Evidence()
    local rows={}
    for _,a in ipairs(self.auras) do
        if self:IsFireSignal(a) or self:IsWelcome(a) or a.id==1229741 or a.name=="Camp Benefits" then
            rows[#rows+1]={name=a.name,id=a.id,lines=a.index and S.Compat:TooltipLines("aura",a.index) or {}}
        end
    end
    return rows
end

function C:ActiveEffects()
    local rows={}
    for _,a in ipairs(self.auras) do
        local def=a.id and S.CampEffects[a.id]
        if def then
            local lines={}
            for i,label in ipairs(def.labels) do
                local n=a.points and S:Number(a.points[i])
                lines[#lines+1]=label..": "..(n and string.format("%g%s",n,def.percent and "%" or "") or "value not exposed")
            end
            if #lines==0 then lines[1]="Native tent / rested-experience aura is active. No XP amount is inferred." end
            rows[#rows+1]={id=a.id,name=def.name,detail=table.concat(lines,"\n"),
                remaining=a.expires and a.expires>0 and math.max(0,a.expires-S:Now()) or nil}
        end
    end
    table.sort(rows,function(a,b)return a.name<b.name end)
    return rows
end

function C:ObservedRewardCount()
    local result=self.result
    if not result or not result.finished then return 0 end
    local count=0
    for _,a in ipairs(self.auras) do
        if a.id and (S.CampEffects[a.id] or a.id==1229741) and
           result.beforeAuras[a.id]~=(a.expires or true) then count=count+1 end
    end
    return count
end
