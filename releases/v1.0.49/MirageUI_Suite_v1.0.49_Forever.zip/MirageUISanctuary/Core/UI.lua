local _, S = ...
local U={rows={},tab="status",quoteIndex=1,quoteAt=0,quoteDuration=28,offset=0}; S.UI=U
local TAB_ORDER={"status","items","craft"}
local function canonicalTab(key)
    if key=="overview" or key=="bonuses" then return "status" end
    if key=="crafting" then return "craft" end
    if key=="status" or key=="items" or key=="craft" then return key end
    return "status"
end
-- MirageUI/Data/VisualTokens.lua options colors, mirrored locally for a
-- standalone Sanctuary. The cinematic world/lighting has its own palette.
local cream={.90,.89,.87,1}
local muted={.63,.62,.60,1}
local scenicMuted={.83,.78,.77,1} -- contrast over moving art, not a UI chrome token
local gold={.96,.79,.36,1}
local accent={.91,.55,.18,1}
local charcoal={.035,.035,.038,.98}
local panel={.060,.060,.065,.97}
local edge={.26,.26,.26,1}
local hover={.15,.12,.08,.98}
local function text(parent,size,color,align)
    local f=parent:CreateFontString(nil,"OVERLAY")
    f:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",size,"")
    f:SetTextColor(unpack(color or cream)); f:SetJustifyH(align or "LEFT"); f:SetJustifyV("TOP")
    f:SetShadowColor(.035,.02,.045,.9); f:SetShadowOffset(1,-1)
    if f.SetWordWrap then f:SetWordWrap(true) end
    return f
end
local function solid(parent,color,layer)
    local t=parent:CreateTexture(nil,layer or "BACKGROUND"); t:SetColorTexture(unpack(color)); return t
end
local function paintButton(b)
    local selected=b.selected
    b.bg:SetColorTexture(unpack((selected or b.hovered) and hover or panel))
    if selected or b.hovered then
        b.line:SetColorTexture(accent[1],accent[2],accent[3],selected and 1 or .56)
    else
        b.line:SetColorTexture(edge[1],edge[2],edge[3],.64)
    end
    b.label:SetTextColor(unpack(cream))
end
local function button(parent,label,width,handler)
    local b=CreateFrame("Button",nil,parent); b:SetSize(width,30); b:EnableMouse(true)
    b.bg=solid(b,panel); b.bg:SetAllPoints(b)
    b.line=solid(b,edge,"ARTWORK"); b.line:SetHeight(1); b.line:SetPoint("BOTTOMLEFT",b,"BOTTOMLEFT",0,0); b.line:SetPoint("BOTTOMRIGHT",b,"BOTTOMRIGHT",0,0)
    b.label=text(b,12,cream,"CENTER"); b.label:SetPoint("CENTER",b,"CENTER",0,1); b.label:SetSize(width-8,17); b.label:SetText(label); paintButton(b)
    b:SetScript("OnClick",function()
        if label~="EXIT" and label~="LEAVE" and label~="STAY" then U:HideLeavePrompt() end
        local ok=S:Guard("Button "..label,handler)
        if not ok then S:Print("An action failed; /sanctuary diagnose contains details.") end
    end)
    b:SetScript("OnEnter",function() b.hovered=true; paintButton(b) end)
    b:SetScript("OnLeave",function() b.hovered=false; paintButton(b) end)
    b:SetScript("OnHide",function() b.hovered=false; paintButton(b) end)
    return b
end
local function shown(frame,b) if b then frame:Show() else frame:Hide() end end
function U:Create()
    local root=CreateFrame("Frame","MirageUISanctuaryFrame",UIParent)
    self.root=root; root:SetAllPoints(UIParent); root:SetFrameStrata("FULLSCREEN_DIALOG"); root:SetFrameLevel(100); root:Hide()
    local black=solid(root,{.025,.02,.035,1}); black:SetAllPoints(root)
    root:EnableMouse(true)
    root:SetScript("OnMouseUp",function(_,mouseButton)
        if mouseButton==nil or mouseButton=="LeftButton" then U:BackdropClick() end
    end)
    local canvas=CreateFrame("Frame",nil,root); self.canvas=canvas; canvas:SetPoint("CENTER",root,"CENTER"); canvas:SetFrameLevel(102); canvas:EnableMouse(false)
    S.Scene:Create(root,canvas)
    self.header=text(canvas,13,scenicMuted,"CENTER"); self.header:SetText("M I R A G E U I")
    self.title=text(canvas,42,cream,"CENTER"); self.title:SetText("Sanctuary")
    self.titleMark=canvas:CreateTexture(nil,"ARTWORK")
    self.titleMark:SetTexture(S.media.."SanctuaryBadge.tga")
    self.subtitle=text(canvas,14,scenicMuted,"CENTER")
    self.quote=text(canvas,25,cream,"CENTER"); self.author=text(canvas,12,scenicMuted,"CENTER")
    self.footer=text(canvas,12,scenicMuted,"LEFT"); self.hint=text(canvas,12,scenicMuted,"RIGHT")
    self.hint:SetText("Click the landscape or press Escape to return")
    self.modelHint=text(canvas,12,scenicMuted,"CENTER")
    self.controls={}
    local c=self.controls
    c.exit=button(canvas,"EXIT",64,function()U:RequestLeave()end)
    c.camp=button(canvas,"REST AUTO",110,function()S.db.automaticCampfire=not S.db.automaticCampfire; U:Labels(); S.Camping:Observe()end)
    c.auto=button(canvas,"AFK",88,function()S.db.automatic=not S.db.automatic; U:Labels()end)
    c.petals=button(canvas,"AMBIENCE",110,function()
        local key=S.mode=="idle" and "petals" or "birds"
        S.db[key]=not S.db[key]
        if key=="birds" then S.db.rays=S.db.birds end -- legacy saved-variable compatibility
        S.Scene:UpdateAmbienceVisibility(); U:Labels()
    end)
    c.music=button(canvas,"MUSIC",103,function()S.db.music=not S.db.music; S.Audio:Play(); U:Labels()end)
    c.next=button(canvas,"NEXT",72,function()U:NextQuote()end)
    for _,b in pairs(c) do b:SetFrameLevel(112) end
    self:CreatePanel()
    self:CreateLeavePrompt()
    root:SetScript("OnSizeChanged",function()S:Guard("Layout",U.Layout,U)end)
    root:SetScript("OnHide",function()S:Hidden()end)
    root:SetScript("OnUpdate",function(_,elapsed)
        local ok=S:Guard("Scene update",U.Tick,U,elapsed)
        if not ok then S:Close("render-failure"); S:Print("Sanctuary closed safely after a rendering error. Use /sanctuary diagnose.") end
    end)
    if type(UISpecialFrames)=="table" then UISpecialFrames[#UISpecialFrames+1]="MirageUISanctuaryFrame" end
    self:Layout(); self:Labels()
end
function U:CreatePanel()
    local p=CreateFrame("Frame",nil,self.canvas); self.panel=p; p:SetFrameLevel(120); p:EnableMouse(true)
    p:SetScript("OnMouseDown",function() U:HideLeavePrompt() end)
    p:SetScript("OnMouseUp",function() end)
    if p.SetPropagateMouseClicks then p:SetPropagateMouseClicks(false) end
    -- Translucent premium glass material preserves the new forest scene without
    -- sacrificing the readability of item lists and timing data.
    self.panelGlass=p:CreateTexture(nil,"BACKGROUND")
    self.panelGlass:SetTexture(S.media.."PanelGlass.tga")
    self.panelGlass:SetAllPoints(p)
    self.panelGlass:SetVertexColor(.91,.91,.92,1)
    local headerShade=solid(p,{.035,.035,.038,.26},"BORDER")
    headerShade:SetPoint("TOPLEFT",p,"TOPLEFT",12,-12)
    headerShade:SetPoint("TOPRIGHT",p,"TOPRIGHT",-12,-12)
    headerShade:SetHeight(120)
    -- P16: borderless charcoal glass; no gold perimeter stroke.
    self.panelIcon=p:CreateTexture(nil,"ARTWORK")
    self.panelIcon:SetTexture(S.media.."SanctuaryBadge.tga")
    self.panelIcon:SetSize(28,28)
    self.panelTitle=text(p,28,cream); self.panelTitle:SetText("Prepare")
    self.panelMode=text(p,11,gold); self.panelMode:SetText("CAMPFIRE REST")
    self.timer=text(p,29,gold,"RIGHT")
    self.timerCaption=text(p,11,muted,"RIGHT")
    self.panelNote=text(p,11,muted)
    self.progress=CreateFrame("StatusBar",nil,p)
    self.progress:SetStatusBarTexture("Interface\\Buttons\\WHITE8X8")
    self.progress:SetStatusBarColor(unpack(accent))
    self.progress:SetMinMaxValues(0,1); self.progress:SetValue(0)
    local barbg=solid(self.progress,edge); barbg:SetAllPoints(self.progress)
    local hairline=solid(p,{.26,.26,.26,.55},"ARTWORK")
    hairline:SetHeight(1); hairline:SetPoint("TOPLEFT",p,"TOPLEFT",20,-134); hairline:SetPoint("TOPRIGHT",p,"TOPRIGHT",-20,-134)
    self.metrics={}
    for i,key in ipairs({"buffs","items","crafts"}) do
        local cell=CreateFrame("Frame",nil,p)
        cell:EnableMouse(false)
        cell.label=text(cell,10,muted,"CENTER")
        cell.label:SetText((({buffs="CAMP BENEFITS",items="USABLE ITEMS",crafts="MATERIAL SETS"})[key]))
        cell.value=text(cell,16,cream,"CENTER")
        self.metrics[key]=cell
        if i<3 then
            local divider=solid(p,{.26,.26,.26,.55},"ARTWORK")
            divider:SetWidth(1); divider:SetHeight(42)
            cell.divider=divider
        end
    end
    self.tabs={}; self.tabOrder=TAB_ORDER
    local labels={status="Status",items="Items",craft="Craft"}
    for _,key in ipairs(TAB_ORDER) do
        self.tabs[key]=button(p,labels[key],112,function()U.tab=key; U.offset=0; U:RefreshPanel()end)
    end
    -- Backward-compatible programmatic selectors and /sanctuary tab aliases.
    self.tabs.overview=self.tabs.status
    self.tabs.bonuses=self.tabs.status
    self.tabs.crafting=self.tabs.craft
    self.viewHint=text(p,11,muted)
    self.scroll=CreateFrame("ScrollFrame",nil,p); self.scroll:EnableMouseWheel(true)
    self.content=CreateFrame("Frame",nil,self.scroll); self.content:SetHeight(1); self.scroll:SetScrollChild(self.content)
    self.scroll:SetScript("OnMouseWheel",function(_,delta)U:HideLeavePrompt(); U:Scroll(-delta*72)end)
    self.scrollTrack=solid(p,{.26,.26,.26,.55}); self.scrollThumb=solid(p,{.91,.55,.18,.75},"ARTWORK")
    self.up=button(p,"UP",43,function()U:Scroll(-200)end); self.down=button(p,"DOWN",59,function()U:Scroll(200)end)
    self.panelFooter=text(p,11,muted)
    p:Hide()
end
function U:CreateLeavePrompt()
    local f=CreateFrame("Frame",nil,self.canvas); self.leavePrompt=f; f:SetFrameLevel(132); f:EnableMouse(true); f:Hide()
    local bg=solid(f,charcoal,"BACKGROUND"); bg:SetAllPoints(f)
    local accent=solid(f,{.91,.55,.18,.62},"ARTWORK"); accent:SetHeight(1); accent:SetPoint("TOPLEFT",f,"TOPLEFT",0,0); accent:SetPoint("TOPRIGHT",f,"TOPRIGHT",0,0)
    local accent2=solid(f,{.26,.26,.26,.75},"ARTWORK"); accent2:SetHeight(1); accent2:SetPoint("BOTTOMLEFT",f,"BOTTOMLEFT",0,0); accent2:SetPoint("BOTTOMRIGHT",f,"BOTTOMRIGHT",0,0)
    f.title=text(f,20,cream); f.title:SetText("Leave Sanctuary?")
    f.body=text(f,12,muted); f.body:SetText("Press Escape, click outside once more, or choose Leave to return to gameplay.")
    f.stay=button(f,"STAY",78,function() U:HideLeavePrompt() end)
    f.leave=button(f,"LEAVE",84,function() S:Close("user-confirm") end)
    f:SetScript("OnMouseDown",function() end)
end
function U:ShowLeavePrompt()
    if not self.leavePrompt then return end
    local complete=S.Camping and S.Camping.result and S.Camping.result.finished
    self.leavePrompt.title:SetText("Leave Sanctuary?")
    if complete then
        self.leavePrompt.body:SetText("Rest is complete. Press Escape, click outside once more, or choose Leave to return to gameplay.")
    else
        self.leavePrompt.body:SetText("Sanctuary is still open for campfire preparation. Press Escape, click outside once more, or choose Leave to close it now.")
    end
    self.leavePrompt:Show()
end
function U:HideLeavePrompt()
    if self.leavePrompt then self.leavePrompt:Hide() end
end
function U:RequestLeave()
    if not S.mode then return end
    if S.mode=="idle" then S:Close("user"); return end
    self:ShowLeavePrompt()
end
function U:BackdropClick()
    if not S.mode then return end
    if S.mode=="idle" then S:Close("user"); return end
    if self.leavePrompt and self.leavePrompt:IsShown() then S:Close("user-confirm"); return end
    self:ShowLeavePrompt()
end


function U:Labels()
    local c=self.controls
    if not c then return end
    c.music.label:SetText(S.db.music and "MUSIC ON" or "MUSIC OFF")
    local idle=(S.mode=="idle")
    local ambienceKey=idle and "petals" or "birds"
    c.petals.label:SetText((idle and "PETALS " or "BIRDS ")..(S.db[ambienceKey] and "ON" or "OFF"))
    c.auto.label:SetText(S.db.automatic and "AFK ON" or "AFK OFF")
    c.camp.label:SetText(S.db.automaticCampfire and "REST AUTO" or "REST MANUAL")
end
-- The scene remains at a stable logical height on each device class. WoW uses
-- UI units, not Windows physical pixels; the aspect ratio is the reliable cue.
-- The compact profile is deliberately wider in UI space for Surface Pro 3:2.
function U:Layout()
    if not self.canvas then return end
    local physicalW,physicalH=self.root:GetWidth(),self.root:GetHeight()
    if not physicalW or not physicalH or physicalW<240 or physicalH<300 then return end
    local aspect=physicalW/physicalH
    local profile=aspect<1.15 and "portrait" or (aspect<2.02 and "compact" or "wide")
    local logicalH=profile=="wide" and 900 or 840
    local canvasScale=physicalH/logicalH
    self.canvas:SetScale(canvasScale)
    local w,h=physicalW/canvasScale,logicalH
    self.canvas:SetSize(w,h)
    self.w,self.h,self.profile,self.canvasScale=w,h,profile,canvasScale

    local camp=S.mode and S.mode~="idle"
    local stacked=profile=="portrait"
    local isCompact=profile~="wide"
    local panelW, panelHeight, panelTop, panelRight
    if stacked then
        panelW=w-24
        panelTop=-(camp and 250 or 250)
        panelHeight=h-265
        panelRight=-12
    elseif isCompact then
        panelW=S:Clamp(w*.48,500,680)
        panelHeight=math.min(690,h-155)
        panelTop=-123
        panelRight=-18
    else
        panelW=math.min(780,math.max(420,w*.335))
        panelHeight=650
        panelTop=-170
        panelRight=-24
    end
    self.panelTop=math.abs(panelTop)
    self.panelProfile=profile
    self.scenicRight=stacked and w or (w-panelW+panelRight-22)
    self.panelGeometry={left=w+panelRight-panelW,top=h+panelTop,width=panelW,height=panelHeight}

    local leftSpace=w-panelW+panelRight-22
    local center=camp and (stacked and w*.76 or leftSpace*.51) or (stacked and w*.52 or w*.54)
    local titleW
    if stacked then titleW=camp and math.min(260,w*.43) or math.min(w-24,540)
    else titleW=camp and math.max(240,math.min(540,leftSpace-8)) or math.min(540,w-24) end
    local titleSize=profile=="wide" and 42 or (stacked and 30 or 38)
    local font=STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"
    self.title:SetFont(font,titleSize,"")
    self.header:SetFont(font,stacked and 11 or 13,"")
    self.subtitle:SetFont(font,isCompact and 15 or 14,"")
    self.header:ClearAllPoints()
    self.header:SetSize(math.min(400,titleW),22)
    self.header:SetPoint("TOP",self.canvas,"TOPLEFT",center,stacked and -86 or (isCompact and -72 or -90))
    self.title:ClearAllPoints()
    -- Title and badge share one vertically centered line. The old title was
    -- top-aligned in a 58-unit box, leaving the small badge below its text.
    self.title:SetJustifyV("MIDDLE")
    self.title:SetSize(titleW,math.ceil(titleSize*1.24))
    self.title:SetPoint("TOP",self.canvas,"TOPLEFT",center,stacked and -109 or (isCompact and -102 or -120))
    local markSize=titleSize+2
    local paintedTitleW=math.min(titleW, self.title:GetStringWidth())
    local markRight=center-paintedTitleW/2-8
    self.titleMark:SetSize(markSize,markSize)
    self.titleMark:ClearAllPoints()
    self.titleMark:SetPoint("RIGHT",self.title,"CENTER",-paintedTitleW/2-8,0)
    shown(self.titleMark,markRight-markSize>=4)
    self.subtitle:ClearAllPoints()
    self.subtitle:SetSize(stacked and titleW or (camp and titleW or math.min(640,w-36)),stacked and 48 or 38)
    self.subtitle:SetPoint("TOP",self.canvas,"TOPLEFT",center,stacked and -155 or (isCompact and -160 or -179))
    self.footer:ClearAllPoints()
    self.footer:SetSize(w*.46,22)
    self.footer:SetPoint("BOTTOMLEFT",self.canvas,"BOTTOMLEFT",stacked and 12 or 24,stacked and 8 or 20)
    self.hint:ClearAllPoints()
    self.hint:SetSize(w*.49,26)
    self.hint:SetPoint("BOTTOMRIGHT",self.canvas,"BOTTOMRIGHT",stacked and -12 or -24,stacked and 8 or 20)
    if stacked then
        self.hint:SetText(camp and "Esc / tap twice to leave" or "Tap scene / Esc to leave")
    else
        self.hint:SetText(camp and "Press Escape or click outside the Prepare window twice to return" or "Click the landscape or press Escape to return")
    end
    self.modelHint:ClearAllPoints()
    self.modelHint:SetSize(math.min(340,w*.58),44)
    self.modelHint:SetPoint("BOTTOMLEFT",self.canvas,"BOTTOMLEFT",stacked and 10 or 45,stacked and h-240 or 76)

    -- Controls remain functional and visible, wrapped to two touch-sized rows
    -- when the screen is taller than it is wide. No feature is hidden.
    local visible={"exit","camp","auto","petals","music"}
    if not camp then visible[#visible+1]="next" end
    for _,key in ipairs({"exit","camp","auto","petals","music","next"}) do
        shown(self.controls[key],key~="next" or not camp)
    end
    if stacked then
        local desired={exit=60,camp=103,auto=85,petals=103,music=92,next=69}
        local rows={{"exit","camp","auto"},{"petals","music"}}
        if not camp then rows[2][#rows[2]+1]="next" end
        for rowNo,keys in ipairs(rows) do
            local sum=0
            for _,key in ipairs(keys) do sum=sum+desired[key] end
            local gap=6
            local fit=math.min(1,(w-28-(#keys-1)*gap)/sum)
            local total=sum*fit+(#keys-1)*gap
            local x=(w-total)/2
            for _,key in ipairs(keys) do
                local b=self.controls[key]
                local bw=desired[key]*fit
                b:SetSize(bw,34)
                b.label:SetSize(bw-6,20)
                b.label:SetFont(font,12,"")
                b:ClearAllPoints(); b:SetPoint("TOPLEFT",self.canvas,"TOPLEFT",x,-10-(rowNo-1)*40)
                x=x+bw+gap
            end
        end
    else
        local x=isCompact and -16 or -24
        for _,key in ipairs(visible) do
            local b=self.controls[key]
            local widths=isCompact and {exit=66,camp=112,auto=87,petals=110,music=103,next=72} or
                {exit=64,camp=110,auto=88,petals=110,music=103,next=72}
            local bw=widths[key]
            b:SetSize(bw,isCompact and 34 or 30)
            b.label:SetSize(bw-8,isCompact and 20 or 17)
            b.label:SetFont(font,isCompact and 13 or 12,"")
            b:ClearAllPoints();b:SetPoint("TOPRIGHT",self.canvas,"TOPRIGHT",x,isCompact and -12 or -20)
            x=x-bw-(isCompact and 7 or 8)
        end
    end

    self.panel:SetSize(panelW,panelHeight)
    self.panel:ClearAllPoints()
    self.panel:SetPoint("TOPRIGHT",self.canvas,"TOPRIGHT",panelRight,panelTop)
    self.panelIcon:ClearAllPoints();self.panelIcon:SetPoint("TOPLEFT",self.panel,"TOPLEFT",18,-20)
    -- Reserve a disjoint timer column: localized names and longer state
    -- descriptions cannot paint over the preparation title or status.
    local timerW=math.min(208,math.floor((panelW-48)*.45))
    local labelW=panelW-48-timerW
    self.panelTitle:ClearAllPoints();self.panelTitle:SetPoint("TOPLEFT",self.panel,"TOPLEFT",55,-15)
    self.panelTitle:SetSize(labelW-35,40)
    self.panelTitle:SetFont(font,isCompact and 27 or 28,"")
    self.panelMode:ClearAllPoints();self.panelMode:SetPoint("TOPLEFT",self.panel,"TOPLEFT",20,-58)
    self.panelMode:SetSize(labelW,30)
    self.panelMode:SetFont(font,isCompact and 12 or 11,"")
    self.timer:ClearAllPoints();self.timer:SetPoint("TOPRIGHT",self.panel,"TOPRIGHT",-18,-17)
    self.timer:SetSize(timerW,36)
    self.timer:SetFont(font,panelW<390 and 25 or 29,"")
    self.timerCaption:ClearAllPoints();self.timerCaption:SetPoint("TOPRIGHT",self.panel,"TOPRIGHT",-20,-59)
    self.timerCaption:SetSize(timerW,30)
    self.timerCaption:SetFont(font,11,"")
    self.progress:ClearAllPoints();self.progress:SetPoint("TOPLEFT",self.panel,"TOPLEFT",20,-92)
    self.progress:SetSize(panelW-40,5)
    self.panelNote:ClearAllPoints();self.panelNote:SetPoint("TOPLEFT",self.panel,"TOPLEFT",20,-104)
    self.panelNote:SetSize(panelW-40,30)
    self.panelNote:SetFont(font,isCompact and 12 or 11,"")
    local metricW=(panelW-40)/3
    for i,key in ipairs({"buffs","items","crafts"}) do
        local cell=self.metrics[key]
        cell:ClearAllPoints();cell:SetPoint("TOPLEFT",self.panel,"TOPLEFT",20+(i-1)*metricW,-142)
        cell:SetSize(metricW,42)
        cell.value:ClearAllPoints();cell.value:SetPoint("TOP",cell,"TOP",0,-1)
        cell.value:SetSize(metricW-8,23)
        cell.value:SetFont(font,isCompact and 17 or 16,"")
        cell.label:ClearAllPoints();cell.label:SetPoint("TOP",cell,"TOP",0,-25)
        cell.label:SetSize(metricW-8,15)
        cell.label:SetFont(font,isCompact and 11 or 10,"")
        if cell.divider then
            cell.divider:ClearAllPoints();cell.divider:SetPoint("RIGHT",cell,"RIGHT",0,0)
        end
    end
    local tabW=(panelW-50)/3
    for i,key in ipairs(TAB_ORDER) do
        local b=self.tabs[key]
        b:ClearAllPoints();b:SetSize(tabW,isCompact and 38 or 32)
        b.label:SetSize(tabW-8,isCompact and 23 or 17)
        b.label:SetFont(font,isCompact and 14 or 12,"")
        b:SetPoint("TOPLEFT",self.panel,"TOPLEFT",20+(i-1)*(tabW+5),-194)
    end
    self.viewHint:ClearAllPoints();self.viewHint:SetPoint("TOPLEFT",self.panel,"TOPLEFT",20,-239)
    self.viewHint:SetSize(panelW-40,18)
    self.viewHint:SetFont(font,isCompact and 12 or 11,"")
    local scrollTop=260
    local scrollHeight=panelHeight-313
    self.scroll:ClearAllPoints();self.scroll:SetPoint("TOPLEFT",self.panel,"TOPLEFT",20,-scrollTop)
    self.scroll:SetSize(panelW-49,scrollHeight)
    self.content:SetWidth(panelW-49)
    self.scrollTrack:ClearAllPoints();self.scrollTrack:SetSize(3,scrollHeight)
    self.scrollTrack:SetPoint("TOPRIGHT",self.panel,"TOPRIGHT",-12,-scrollTop)
    self.up:ClearAllPoints();self.up:SetPoint("BOTTOMRIGHT",self.panel,"BOTTOMRIGHT",-86,14)
    self.down:ClearAllPoints();self.down:SetPoint("BOTTOMRIGHT",self.panel,"BOTTOMRIGHT",-20,14)
    self.up:SetHeight(isCompact and 31 or 30)
    self.down:SetHeight(isCompact and 31 or 30)
    self.panelFooter:ClearAllPoints();self.panelFooter:SetPoint("BOTTOMLEFT",self.panel,"BOTTOMLEFT",20,20)
    self.panelFooter:SetSize(panelW-185,18)
    self.panelFooter:SetFont(font,isCompact and 11 or 11,"")
    if self.leavePrompt then
        local dialogW=math.min(440,w-32)
        self.leavePrompt:SetSize(dialogW,174)
        self.leavePrompt:ClearAllPoints()
        local dx=stacked and w*.5 or math.max(dialogW*.5+24,leftSpace*.5)
        self.leavePrompt:SetPoint("CENTER",self.canvas,"BOTTOMLEFT",dx,stacked and h*.52 or h*.49)
        self.leavePrompt.title:ClearAllPoints();self.leavePrompt.title:SetPoint("TOPLEFT",self.leavePrompt,"TOPLEFT",22,-20)
        self.leavePrompt.title:SetSize(dialogW-44,28)
        self.leavePrompt.body:ClearAllPoints();self.leavePrompt.body:SetPoint("TOPLEFT",self.leavePrompt,"TOPLEFT",22,-57)
        self.leavePrompt.body:SetSize(dialogW-44,60)
        self.leavePrompt.stay:ClearAllPoints();self.leavePrompt.stay:SetPoint("BOTTOMRIGHT",self.leavePrompt,"BOTTOMRIGHT",-108,14)
        self.leavePrompt.leave:ClearAllPoints();self.leavePrompt.leave:SetPoint("BOTTOMRIGHT",self.leavePrompt,"BOTTOMRIGHT",-18,14)
    end
    local prior=S.Scene.modelGeometry
    local oldW,oldH=prior and prior.width,prior and prior.height
    S.Scene:Layout(w,h)
    local current=S.Scene.modelGeometry
    -- Resizing the model frame does not change the model's camera. Refresh the
    -- camera only on real viewport changes, so rotated Surface displays do not
    -- crop a weapon while a rest timer stays active.
    if S.mode and S.Scene.model and S.Scene.model:IsShown() and current and
        (not oldW or math.abs(oldW-current.width)>0.5 or math.abs(oldH-current.height)>0.5) then
        S.Scene:ApplyPose()
    end
    self:QuoteLayout()
    if self.panel:IsShown() and not S.fastEntry then self:RefreshPanel() end
end
function U:Scroll(delta)
    local max=math.max(0,self.content:GetHeight()-self.scroll:GetHeight())
    self.offset=S:Clamp((self.offset or 0)+delta,0,max)
    self.scroll:SetVerticalScroll(self.offset)
    local track=self.scroll:GetHeight(); local size=math.max(24,track*track/math.max(track,self.content:GetHeight()))
    self.scrollThumb:ClearAllPoints(); self.scrollThumb:SetSize(3,size)
    self.scrollThumb:SetPoint("TOPRIGHT",self.panel,"TOPRIGHT",-12,-260-(max>0 and (track-size)*self.offset/max or 0))
end
-- Forever's InsecureActionButtonTemplate contains Blizzard's native OnClick
-- item dispatcher and runs only on a real user click OUTSIDE combat.
-- P12 used AnyUp without useOnKeyDown=false. If the player has the game's
-- action-on-key-down option enabled, the secure item dispatcher ignores the
-- release event. Both mouse events are registered, but only Up may execute.
-- Do not replace the template's OnClick or call UseContainerItem from addon Lua.
-- These buttons are INSECURE (the template's intended out-of-combat variant):
-- do not turn the entire Sanctuary overlay into a protected ancestor.
local function makeUseButton(row)
    if S:InCombat() then return nil end
    local ok,btn=pcall(CreateFrame,"Button",nil,row,"InsecureActionButtonTemplate")
    if not ok or not btn or type(btn.SetAttribute)~="function" then return nil end
    btn:SetSize(80,29); btn:EnableMouse(true)
    if btn.SetFrameLevel then btn:SetFrameLevel(row:GetFrameLevel()+8) end
    if btn.SetPropagateMouseClicks then btn:SetPropagateMouseClicks(false) end
    if btn.RegisterForClicks then btn:RegisterForClicks("AnyUp","AnyDown") end
    -- Explicitly disable key-down activation independent of ActionButtonUseKeyDown.
    -- The inherited XML handler receives (button,down) and will execute only
    -- for the real LeftButton release; it must not depend on a client CVar.
    local timingOK=S:Guard("Item button action timing",btn.SetAttribute,btn,"useOnKeyDown",false)
    if not timingOK then return nil end
    local bg=solid(btn,panel); bg:SetAllPoints(btn)
    local edge=solid(btn,{.91,.55,.18,.65},"ARTWORK")
    edge:SetPoint("BOTTOMLEFT",btn,"BOTTOMLEFT",0,0); edge:SetPoint("BOTTOMRIGHT",btn,"BOTTOMRIGHT",0,0); edge:SetHeight(1)
    local label=text(btn,12,gold,"CENTER");label:SetAllPoints(btn);label:SetText("USE")
    btn:SetScript("OnEnter",function() bg:SetColorTexture(unpack(hover)) end)
    btn:SetScript("OnLeave",function() bg:SetColorTexture(unpack(panel)) end)
    -- The template's native OnClick is essential; do not override it.
    return btn
end

local function bindUseItem(btn,item)
    if not btn or not item or S:InCombat() then return false end
    local bag,slot=S:Number(item.bag),S:Number(item.slot)
    -- Bind the exact CURRENT bag and slot instead of a generic item:ID.
    -- The bag iterator already obtains this location from Blizzard's bag API.
    -- This preserves identical item IDs with several stacks and gives
    -- SecureCmdItemParse the supported "bag slot" argument form.
    if not (bag and slot and bag>=0 and bag<=11 and slot>=1 and slot<=100 and
        bag==math.floor(bag) and slot==math.floor(slot)) then return false end
    local location=string.format("%d %d",bag,slot)
    local ok1=S:Guard("Use item left-click type",btn.SetAttribute,btn,"type1","item")
    local ok2=S:Guard("Use item bag-slot",btn.SetAttribute,btn,"item1",location)
    local ok3=S:Guard("Use item generic type",btn.SetAttribute,btn,"type","item")
    local ok4=S:Guard("Use item generic bag-slot",btn.SetAttribute,btn,"item",location)
    return ok1 and ok2 and ok3 and ok4
end
local function clearUseItem(btn)
    if not btn or S:InCombat() then return end
    for _,key in ipairs({"type1","item1","type","item"}) do
        S:Call("Clear item action "..key,btn.SetAttribute,btn,key,nil)
    end
end
local function hideItemTooltip(row)
    local tooltip=GameTooltip
    if not tooltip then return end
    local owned
    if type(tooltip.IsOwned)=="function" then
        owned=S:Call("Tooltip ownership",tooltip.IsOwned,tooltip,row)==true
    elseif type(tooltip.GetOwner)=="function" then
        owned=S:Call("Tooltip owner",tooltip.GetOwner,tooltip)==row
    end
    if owned then S:Call("Tooltip hide",tooltip.Hide,tooltip) end
end
function U:Add(title,detail,value,style,meta)
    self.rowCount=self.rowCount+1
    local r=self.rows[self.rowCount]
    if not r then
        r=CreateFrame("Frame",nil,self.content);self.rows[self.rowCount]=r
        r.stripe=solid(r,{.13,.09,.15,.12},"BACKGROUND");r.stripe:SetAllPoints(r)
        r.title=text(r,14,cream);r.detail=text(r,12,muted);r.value=text(r,14,gold,"RIGHT")
        r.icon=r:CreateTexture(nil,"ARTWORK");r.icon:SetSize(38,38)
        r.rule=solid(r,{.84,.66,.52,.15});r.rule:SetHeight(1)
        r.rule:SetPoint("BOTTOMLEFT",r,"BOTTOMLEFT",0,0);r.rule:SetPoint("BOTTOMRIGHT",r,"BOTTOMRIGHT",0,0)
        r.action=button(r,"Craft 1",74,function()
            if r.meta and r.meta.craftKey then
                local _,msg=S.Data:CraftOne(r.meta.craftKey)
                S:Print(msg); U.actionNotice=msg; U.noticeUntil=S:Now()+5; S.Data.dirty=true
            end
        end)
        r.useButton=makeUseButton(r)
        r:EnableMouse(true)
        r:SetScript("OnMouseDown",function()U:HideLeavePrompt()end)
        r:SetScript("OnMouseUp",function()end)
        r:SetScript("OnEnter",function()
            local entry=r.meta and r.meta.item
            if entry and GameTooltip then
                S:Call("Tooltip owner",GameTooltip.SetOwner,GameTooltip,r,"ANCHOR_LEFT")
                if entry.link then S:Call("Tooltip item link",GameTooltip.SetHyperlink,GameTooltip,entry.link)
                else S:Call("Tooltip item",GameTooltip.SetItemByID,GameTooltip,entry.id) end
                S:Call("Tooltip show",GameTooltip.Show,GameTooltip)
            end
        end)
        r:SetScript("OnLeave",hideItemTooltip)
        r:SetScript("OnHide",hideItemTooltip)
    end
    if not r.useButton and not S:InCombat() then r.useButton=makeUseButton(r) end
    -- Recycled rows must retire their prior tooltip before displaying a new item.
    local oldItem=r.meta and r.meta.item
    local newItem=meta and meta.item
    if oldItem and (not newItem or oldItem.id~=newItem.id or oldItem.link~=newItem.link) then
        hideItemTooltip(r)
    end
    r.meta=meta
    r.stripe:SetColorTexture(.06,.06,.065,self.rowCount%2==0 and .30 or 0)
    local width=self.content:GetWidth()
    local narrow=self.profile=="portrait" or width<470
    local compact=self.profile~="wide"
    local craft=meta and meta.craftKey
    local item=meta and meta.item
    local recipe=meta and meta.recipe
    local hasIcon=not not (item or recipe)
    local actionable=item and S.Data:IsUseCandidate(item)
    r:ClearAllPoints();r:SetPoint("TOPLEFT",self.content,"TOPLEFT",0,-self.cursor);r:SetWidth(width)
    r.icon:ClearAllPoints()
    if hasIcon then
        r.icon:SetTexture((item and item.icon) or (recipe and recipe.icon) or "Interface\\Icons\\INV_Misc_QuestionMark")
        r.icon:SetPoint("TOPLEFT",r,"TOPLEFT",3,-3)
        r.icon:Show()
    else r.icon:Hide() end
    local indent=hasIcon and 49 or 0
    local valueW=math.min(98,width*.26)
    local rightPad=value and valueW+8 or 0
    r.title:ClearAllPoints();r.title:SetPoint("TOPLEFT",r,"TOPLEFT",indent,0)
    r.title:SetWidth(math.max(1,width-indent-rightPad-6))
    r.title:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",style=="heading" and (compact and 13 or 12) or (style=="compact" and (compact and 14 or 13) or (compact and 15 or 14)),"")
    r.title:SetTextColor(unpack(style=="heading" and gold or (style=="muted" and muted or cream)));r.title:SetText(title or "")
    r.title:SetHeight(0)
    local titleH=math.max(18,r.title:GetStringHeight() or 18);r.title:SetHeight(titleH+2)
    r.value:ClearAllPoints();r.value:SetPoint("TOPRIGHT",r,"TOPRIGHT",-2,0);r.value:SetSize(valueW,0);r.value:SetText(value or "")
    local valueH=(value and value~="") and math.max(18,r.value:GetStringHeight() or 18) or 0
    r.value:SetHeight(valueH+2)
    r.detail:ClearAllPoints();r.detail:SetPoint("TOPLEFT",r,"TOPLEFT",indent,-titleH-4)
    r.detail:SetWidth(math.max(100,width-indent-((craft or actionable) and (narrow and 4 or 92) or 2)))
    r.detail:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",compact and 13 or 12,"")
    r.detail:SetHeight(0);r.detail:SetText(detail or "")
    local detailH=detail and detail~="" and math.max(16,r.detail:GetStringHeight() or 16) or 0
    r.detail:SetHeight(detailH+2)
    local height=titleH+detailH+(detailH>0 and 15 or 10)
    if style=="compact" then height=math.max(height,compact and 31 or 26) end
    if style=="heading" then height=math.max(height,compact and 34 or 30) end
    height=math.max(height,valueH+8)
    if hasIcon then height=math.max(height,58) end
    if craft or actionable then height=math.max(height,narrow and 94 or 72) end
    if narrow and (craft or actionable) then height=math.max(height,titleH+detailH+51) end
    r:SetHeight(height);self.cursor=self.cursor+height+7;r:Show()
    r.action:ClearAllPoints()
    r.action:SetSize(compact and 92 or 74,compact and 35 or 30)
    if narrow then r.action:SetPoint("BOTTOMRIGHT",r,"BOTTOMRIGHT",-4,6)
    else r.action:SetPoint("TOPRIGHT",r,"TOPRIGHT",-2,-29) end
    shown(r.action,craft and true or false)
    if r.useButton then
        r.useButton:ClearAllPoints()
        r.useButton:SetSize(compact and 92 or 80,compact and 35 or 29)
        if narrow then r.useButton:SetPoint("BOTTOMRIGHT",r,"BOTTOMRIGHT",-4,6)
        else r.useButton:SetPoint("TOPRIGHT",r,"TOPRIGHT",-2,-29) end
        if actionable and not S:InCombat() then
            local bound=bindUseItem(r.useButton,item)
            if not bound then clearUseItem(r.useButton) end
            shown(r.useButton,bound)
        else
            -- Explicitly disarm pooled controls so tab changes and bag moves
            -- cannot leave an old USE action attached to a reused row.
            clearUseItem(r.useButton)
            r.useButton:Hide()
        end
    end
end
function U:RefreshMetrics()
    if not self.metrics or not S.Data or not S.Camping then return end
    local active=S.Camping:ActiveEffects()
    local count=0
    for _,item in ipairs(S.Data.consumables or {}) do
        if S.Data:IsUseCandidate(item) then count=count+1 end
    end
    local available=S.Data:Craftable()
    self.metrics.buffs.value:SetText(tostring(#active).." active")
    self.metrics.items.value:SetText(tostring(count).." usable")
    self.metrics.crafts.value:SetText(tostring(#available)..(#available==1 and " set" or " sets"))
end
function U:RefreshPanel()
    if not self.panel then return end
    self.tab=canonicalTab(self.tab)
    self.rowCount,self.cursor=0,0
    for _,row in ipairs(self.rows) do row:Hide() end
    for _,key in ipairs(TAB_ORDER) do
        local b=self.tabs[key]
        b.selected=(key==self.tab)
        paintButton(b)
    end
    self:RefreshMetrics()
    local D=S.Data
    local active=S.Camping:ActiveEffects()
    local available,known,unknown=D:Craftable()
    if self.tab=="status" then
        self.viewHint:SetText("Live character • verified campfire effects")
    elseif self.tab=="items" then
        self.viewHint:SetText("From your bags • click USE to activate")
    else
        self.viewHint:SetText("Known recipes • materials carried in bags")
    end
    local ok=S:Guard("Prepare render "..self.tab,function()
        if U.tab=="status" then
            U:Add("CAMPFIRE BENEFITS",nil,nil,"heading")
            if #active==0 then
                if S.Camping.restricted then
                    U:Add("Effects unavailable","The game is restricting buff data. No rewards are inferred.")
                else
                    U:Add("No benefits confirmed yet","Current effects will appear here when the game grants them.")
                end
            else
                for _,effect in ipairs(active) do
                    U:Add(effect.name,effect.detail,effect.remaining and string.format("%d min left",math.ceil(effect.remaining/60)) or "Active")
                end
            end
            local result=S.Camping.result
            if result and result.finished then
                U:Add("AFTER REST",nil,nil,"heading")
                local changes=0
                for _,r in ipairs(D.stats) do
                    local before=result.before and result.before[r.key]
                    local after=result.after and result.after[r.key]
                    if S:Number(before) and S:Number(after) then
                        local delta=after-before
                        if math.abs(delta)>.001 then
                            changes=changes+1
                            U:Add(r.label,string.format(r.format,before).." → "..string.format(r.format,after),string.format("%+.1f",delta))
                        end
                    end
                end
                if changes==0 then U:Add("No measured stat change","This does not establish whether every possible camp benefit was awarded.")
                else U:Add("Measurement note","Changes may also reflect gear, consumables or other active effects.",nil,"muted") end
            end
            U:Add("CHARACTER",nil,nil,"heading")
            local priority={health=true,stat3=true,stat4=true,stat5=true,attack=true,armor=true,crit=true,spell=true}
            local remainder={}
            for _,r in ipairs(D.stats) do
                if priority[r.key] then
                    U:Add(r.label,nil,r.value and string.format(r.format,r.value) or "—","compact")
                else
                    if r.value then remainder[#remainder+1]=r.label.." "..string.format(r.format,r.value) end
                end
            end
            if #remainder>0 then U:Add("Other statistics",table.concat(remainder," • "),nil,"muted") end
            U:Add("PROFESSIONS",nil,nil,"heading")
            if #D.professions==0 then
                U:Add("No profession data","Open your Skills or Professions window to refresh.")
            else
                for _,prof in ipairs(D.professions) do
                    U:Add(prof.name,nil,prof.rank and tostring(prof.rank).." / "..tostring(prof.maximum or "?") or "—","compact")
                end
            end
        elseif U.tab=="items" then
            local usable,other={},{}
            for _,item in ipairs(D.consumables) do
                if D:IsUseCandidate(item) then usable[#usable+1]=item else other[#other+1]=item end
            end
            U:Add("READY TO USE",nil,nil,"heading")
            if #usable==0 then U:Add("No usable consumables found","The client has not identified an on-use effect in your carried items.") end
            for _,r in ipairs(usable) do
                local details="ID "..r.id.." • "..D:ItemDescription(r)
                if r.castMS and r.castMS>0 then details=details..string.format("\n%.1f sec use/cast",r.castMS/1000) end
                U:Add(r.name,details,"×"..(r.count or 0),nil,{item=r})
            end
            if D.pending>0 then U:Add("Loading item details",D.pending.." item records pending from Blizzard.") end
            if #other>0 then
                U:Add("OTHER CONSUMABLES",nil,nil,"heading")
                for _,r in ipairs(other) do
                    U:Add(r.name,"ID "..r.id.." • "..D:ItemDescription(r),"×"..(r.count or 0),nil,{item=r})
                end
            end
        elseif U.tab=="craft" then
            U:Add("MATERIALS AVAILABLE",nil,nil,"heading")
            if known==0 then
                U:Add("No learned recipes cached","Open a profession once to make its recipes available to Sanctuary.")
            elseif #available==0 then
                U:Add("Nothing craftable from bags","Your cached recipes lack the required carried materials.")
            end
            if unknown>0 then U:Add("Recipe details incomplete",unknown.." recipes need a native profession refresh.") end
            local direct,requires={},{}
            for _,entry in ipairs(available) do
                if D:IsDirectCraftCandidate(entry.recipe) then direct[#direct+1]=entry
                else requires[#requires+1]=entry end
            end
            local function addRecipe(entry)
                local r=entry.recipe
                local parts={}
                for _,slot in ipairs(r.reagents) do
                    local names={}
                    for _,id in ipairs(slot.options) do names[#names+1]=(D.items[id] and D.items[id].name) or ("item "..id) end
                    parts[#parts+1]=tostring(slot.quantity).." × "..table.concat(names," / ")
                end
                local description="ID "..tostring(r.id or "legacy")..(r.profession and (" • "..r.profession) or "")
                if #parts>0 then description=description.."\n"..table.concat(parts,", ") end
                local safe=D:IsDirectCraftCandidate(r)
                U:Add(r.name,description,"×"..entry.count,nil,{craftKey=safe and entry.key or nil,recipe=r})
            end
            for _,entry in ipairs(direct) do addRecipe(entry) end
            if #requires>0 then
                U:Add("NATIVE WINDOW REQUIRED",nil,nil,"heading")
                for _,entry in ipairs(requires) do addRecipe(entry) end
            end
        end
    end)
    if not ok then self:Add("This view is temporarily unavailable","The rest timer remains active. Use /sanctuary diagnose for details.") end
    self.content:SetHeight(math.max(self.cursor,1))
    self:Scroll(0)
    self.panelFooter:SetText((self.tab=="items" and "Item use may interrupt rest • hover for details") or
        (self.tab=="craft" and "Crafting is subject to game rules") or "Live values • no assumed rewards")
end
function U:QuoteLayout()
    if not self.quote or not self.w then return end
    local entry=(S.Quotes or {})[self.quoteIndex]
    if not entry then return end
    local lines=1; for _ in entry.text:gmatch("\n") do lines=lines+1 end
    local portrait=self.profile=="portrait"
    local compact=self.profile~="wide"
    local size=lines>=8 and 22 or (lines>=5 and 24 or 27)
    if portrait then size=lines>=8 and 18 or (lines>=5 and 20 or 24) end
    local width=portrait and math.max(260,self.w-42) or math.min(self.w*(compact and .67 or .56),900)
    local face=STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"
    self.quote:SetFont(face,size,"")
    self.quote:SetWidth(width);self.quote:SetHeight(0)
    self.quote:SetText("“"..entry.text.."”")
    local height=self.quote:GetStringHeight()
    local maxH=portrait and self.h*.40 or math.min(370,self.h*.44)
    while height>maxH and size>15 do
        size=size-1;self.quote:SetFont(face,size,"");height=self.quote:GetStringHeight()
    end
    self.quote:SetHeight(height+4)
    self.quote:ClearAllPoints()
    local qx=portrait and self.w*.50 or self.w*.59
    local qy=portrait and (lines>5 and self.h*.65 or self.h*.70) or
        (self.profile=="wide" and (lines>5 and 480 or 554) or (lines>5 and self.h*.53 or self.h*.60))
    self.quote:SetPoint("CENTER",self.canvas,"BOTTOMLEFT",qx,qy)
    self.author:ClearAllPoints();self.author:SetSize(width,34)
    self.author:SetPoint("TOP",self.quote,"BOTTOM",0,-12)
    self.author:SetText(entry.author~="" and ("— "..entry.author) or "")
    self.author:SetFont(face,portrait and 12 or 12,"")
end
function U:NextQuote(index)
    local total=#(S.Quotes or {}); if total==0 then return end
    self.quoteIndex=index or ((self.quoteIndex or 0)%total+1)
    self.quoteIndex=S:Clamp(self.quoteIndex,1,total)
    local entry=S.Quotes[self.quoteIndex]
    self.quoteAt=S:Now(); self.quoteDuration=S:Clamp(24+#entry.text/16,28,62)
    self:QuoteLayout(); self.quote:SetAlpha(0); self.author:SetAlpha(0)
end
function U:SetMode()
    local idle=S.mode=="idle"
    self:HideLeavePrompt()
    shown(self.quote,idle); shown(self.author,idle); shown(self.panel,not idle)
    self.subtitle:SetText(idle and "A quiet place between journeys" or "The fire is warm. Prepare for what comes next.")
    self.footer:SetText(idle and "YOUR JOURNEY CONTINUES" or (S.mode=="demo" and "CAMPFIRE DEMO • NO GAME REST IN PROGRESS" or "CAMPFIRE SANCTUARY"))
    self.hint:SetText(idle and "Click the landscape or press Escape to return" or "Press Escape or click outside the Prepare window twice to return")
    self:Labels(); self:Layout(); self:NextQuote(self.quoteIndex)
    if not idle then
        if not S.fastEntry then self:RefreshPanel() end
        self:UpdateTimer()
        if S.fastEntry then
            -- Never show counts from a previous character/session during fast entry.
            for _,key in ipairs({"buffs","items","crafts"}) do self.metrics[key].value:SetText("—") end
        end
    end
end
-- These are Sanctuary-owned regions. Avoid re-submitting unchanged text at
-- the 20/30 Hz scene cadence, while preserving a smoothly advancing progress
-- bar and immediate rest-state/notice changes. Read the current value so a
-- separate owned renderer cannot leave an out-of-date cached text receipt.
local function displayText(region,value)
    if region:GetText()~=value then region:SetText(value) end
end
function U:UpdateTimer()
    if not self.timer then return end
    local remaining,total,source=S.Camping:Remaining()
    if self.previousRestSource~=source then
        self.previousRestSource=source
        self:RefreshMetrics()
    end
    local timer,progress,mode,caption,note
    if source=="ENDED" or source=="DEMO_ENDED" then
        timer="Complete"; progress=1
    elseif remaining then
        local n=math.ceil(remaining)
        timer=string.format("%02d:%02d",math.floor(n/60),n%60)
        progress=total and total>0 and S:Clamp(1-remaining/total,0,1) or 0
    else timer="— : —"; progress=0 end
    if source=="AURA" then
        mode="REST IN PROGRESS"
        caption=total and string.format("LIVE AURA • %.0f SEC REST",total) or "LIVE AURA • DURATION UNKNOWN"
        note="Your rest timer follows the game."
    elseif source=="PENDING" then
        mode="STARTING REST"; caption="AWAITING GAME REST AURA"
        note=S.Camping.violet and "Violet Flames detected. Waiting for the game timer." or
            "Waiting for the game to confirm the rest timer."
    elseif source=="DEMO" then
        mode="VISUAL PREVIEW"; caption="DEMO TIMER"; note="Preview only. No game rewards are granted."
    elseif source=="ENDED" then
        mode="REST COMPLETE"
        local observed=S.Camping:ObservedRewardCount()
        caption=observed>0 and "CAMP EFFECTS OBSERVED" or "REVIEW CAMP EFFECTS"
        note="Rest complete. Review benefits or click outside for exit confirmation."
    elseif source=="DEMO_ENDED" then
        mode="NO GAME REWARDS"; caption="DEMO TIMER"
        note="The preview stays open. Escape exits; a landscape click asks for confirmation."
    elseif source=="RESTRICTED" then
        mode="REST DATA UNAVAILABLE"; caption="CLIENT DATA RESTRICTED"
        note="Aura values are not currently readable. No countdown or reward is inferred."
    elseif source=="UNTIMED_AURA" then
        mode="REST DETECTED"; caption="TIMING UNAVAILABLE"
        note="The aura is visible, but this client did not expose readable timing."
    else
        mode="PREPARATION"; caption="PREVIEW"
        note="Sit or sleep near a campfire to start the actual game countdown."
    end
    if self.actionNotice and self.noticeUntil and S:Now()<self.noticeUntil then note=self.actionNotice end
    displayText(self.timer,timer);displayText(self.panelMode,mode)
    displayText(self.timerCaption,caption);displayText(self.panelNote,note)
    if self.progress:GetValue()~=progress then self.progress:SetValue(progress) end
end
function U:Tick(elapsed)
    self.accum=(self.accum or 0)+elapsed
    local interval=S.db.quality=="low" and 1/20 or 1/30
    if self.accum<interval then return end
    local dt=self.accum; self.accum=0
    S.Scene:Tick(math.min(dt,.2)); S.Audio:Tick()
    if S.deferredPrepare and S.mode~="idle" then
        S.deferredPrepare=nil
        S:Guard("Deferred Prepare data",function()
            S.Data:Refresh()
            S.Data:CaptureRecipes()
            self:RefreshPanel()
        end)
    end
    if S.mode=="idle" then
        local age=S:Now()-self.quoteAt
        if age>=self.quoteDuration then self:NextQuote(); age=0 end
        local alpha=math.min(1,age/2.5,(self.quoteDuration-age)/3.5)
        self.quote:SetAlpha(math.max(0,alpha)); self.author:SetAlpha(math.max(0,alpha*.85))
    else self:UpdateTimer() end
    if (self.nextStats or 0)<=S:Now() then
        self.nextStats=S:Now()+2
        if S.mode~="idle" then
            local inventoryDirty=S.Data.dirty
            S.Data:Refresh()
            -- Inventory and recipe tables are not redrawn every second unless
            -- underlying bag/recipe data changes. Overview/Bonuses need fresh
            -- measured stats; this still refreshes at most once per 2s.
            if inventoryDirty or canonicalTab(self.tab)=="status" then self:RefreshPanel() end
        end
        self.modelHint:SetText(S.db.model and (S.Scene.modelState:find("unavailable") and S.Scene.modelState or "") or "")
    end
end
function U:Diagnostics(value)
    if not self.diagnostic then
        local f=CreateFrame("Frame","MirageUISanctuaryDiagnostics",UIParent); self.diagnostic=f
        f:SetSize(740,520); f:SetPoint("CENTER",UIParent,"CENTER"); f:SetFrameStrata("TOOLTIP"); f:EnableMouse(true)
        local bg=solid(f,{.06,.055,.08,.98}); bg:SetAllPoints(f)
        local title=text(f,20,cream); title:SetPoint("TOPLEFT",f,"TOPLEFT",22,-18); title:SetText("Sanctuary • diagnostic report")
        local hint=text(f,12,muted); hint:SetPoint("TOPLEFT",f,"TOPLEFT",22,-49); hint:SetText("Click the report, then Ctrl+A and Ctrl+C to copy it.")
        local scroll=CreateFrame("ScrollFrame",nil,f,"UIPanelScrollFrameTemplate"); scroll:SetPoint("TOPLEFT",f,"TOPLEFT",22,-78); scroll:SetSize(670,385)
        local edit=CreateFrame("EditBox",nil,scroll); edit:SetMultiLine(true); edit:SetFontObject(ChatFontNormal or GameFontNormal); edit:SetWidth(660); edit:SetAutoFocus(false); edit:EnableMouse(true)
        edit:SetScript("OnEscapePressed",function()f:Hide()end); scroll:SetScrollChild(edit); f.edit=edit
        local close=button(f,"CLOSE",80,function()f:Hide()end); close:SetPoint("BOTTOMRIGHT",f,"BOTTOMRIGHT",-22,14)
        if type(UISpecialFrames)=="table" then UISpecialFrames[#UISpecialFrames+1]="MirageUISanctuaryDiagnostics" end
    end
    self.diagnostic.edit:SetText(value); self.diagnostic:Show(); self.diagnostic.edit:HighlightText()
end
