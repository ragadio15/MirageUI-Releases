-- Sanctuary P02: user-supplied quote collection; credits reproduced as provided.
-- Attribution and historical accuracy are unverified. No quote numbers display in the UI.
-- The final supplied fragment has no attribution.
local _, namespace = ...
namespace.Quotes = {
    { text = "Everything that begins also ends. Make peace with that and all will be well.", author = "The Buddha" },
    { text = "To be enlightened is to be intimate with all things", author = "Zen Master Dogen" },
    { text = "The resting place for the mind is the heart", author = "Buddhist Monk" },
    { text = "No one who truly loves themselves would harm another for they would be harming themselves", author = "The Buddha" },
    { text = "The only truth you find at the top of the mountain is the truth you brought with you", author = "Zen Saying" },
    { text = "To abandon what is harmful,\nTo adopt what is wholesome,\nTo purify the heart and mind.\nThis is the teaching of the Buddha.", author = "The Buddha" },
    { text = "We accept the graceful falling of mountain cherry blossoms,\nBut it is much harder for us\nTo fall away from our own\nAttachment to the world", author = "Zen Wisdom" },
    { text = "Know all things like this\nA mirage, a cloud, a castle.\nNothing appears as it is", author = "The Buddha" },
    { text = "Your worst enemy cannot harm you\nAs much as your own thoughts,\nunguarded.\nBut once mastered,\nNo one can help you as much", author = "The Dhammapada" },
    { text = "All that we are is the result\nof what we have thought.\nIt is founded on our thoughts,\nIt is made up of our thoughts", author = "The Dhammapada" },
    { text = "Zen mind is not Zen mind,\nThat is,\nif you are attached to Zen mind,\nThen you have a problem,\nAnd your way is very narrow.\nThrowing away Zen mind\nis correct Zen mind.\nOnly keeping the question,\nWhat is the best way of helping other people?", author = "Seung Sahn" },
    { text = "If we speak of what is real,or grain of sand is real.\nEverything is illusory\nlike the moon reflected in water.\nNeither real or unreal\nis the infinite void", author = "Zen Poem, Vietnamese Buddhist Monk" },
    { text = "Refraining from all evil,\nNot clinging to birth and death,\nWorking with deep compassion\nfor all sentient beings,\nrespecting those over you\nand pitying those below you,\nwithout any detesting or desiring,\nworrying or lamentation —\nThis is called Buddha.\nDo not Search beyond it", author = "Zen Master Dogen" },
    { text = "When I let go of what I am, I become what I might be", author = "Lao Tzu" },
    { text = "We sat together, the forest and I, merging into silence. Until only the forest remained", author = "Li Po" },
    { text = "We reflect on paradox:\nwater wears away rock.\nSpirit overcomes force.\nThe weak will undo the mighty.\nMay we learn yo see things backwards,\ninside out, and upside down", author = "Lao Tzu" },
    { text = "Seeing through to essential nature\nis the window of enlightenment", author = "Hakuun Yasutani Roshi" },
    { text = "One who does not grasp hold\nof anything is not agitated.\nOne who is not agitated is close to freedom", author = "The Buddha" },
    { text = "Stop talking and thinking, then\nthere is nowhere you cannot go.\nReturning to the Source,\nyou gain the meaning, chasing forms you\nlose wholeness.\nA moment’s true insight transcends all", author = "Sosan" },
    { text = "The quieter you become\nThe more you are able to hear", author = "Zen Saying" },
    { text = "We are not in chaos\nwe are the chaos", author = "MZ" },
    { text = "Form is empty of a separate self,\nbut it is full of everything else\nin the cosmos.\nThe same is true with feelings, perceptions, mental formations, and consciousness", author = "Thich Nhat Hahn" },
    { text = "Do not mistake understanding for realization, and do not mistaken realization for liberation", author = "Tibetan Saying" },
    { text = "Elements of the Self,\ncome and go like clouds\nwithout purpose.", author = "Zen Saying" },
    { text = "All conditioned things are impermanent.\nWork out your own salvation\nwith diligence", author = "The Buddha’s last words" },
    { text = "Even a speck of dust", author = "" },
}
