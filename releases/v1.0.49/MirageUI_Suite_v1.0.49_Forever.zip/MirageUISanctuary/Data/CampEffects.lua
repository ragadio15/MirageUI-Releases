local _, S=...
-- Factual spell/effect identifiers for Forever 1.60.1.70938.
-- Cross-reference: cjber/tweaks-forever Data/CampBenefits.lua, blob
-- 45209a95209c2dc741878e2dbfde605cbb87e08f (generated from build 70938 DB2).
-- Original independent presentation below. NO database base magnitudes are used:
-- every displayed magnitude must come from the player's live aura.points.
S.CampEffects={
 [1229451]={name="Camp Tent",labels={}},
 [1230587]={name="Mana Well",labels={"Mana per 5 sec"}},
 [1230172]={name="Sharpening Wheel",labels={"Strength"}},
 [1230653]={name="Enchanted Lute",labels={"Armor","All attributes","All resistances"}},
 [1230124]={name="First Aid Kit",labels={"Stamina"}},
 [1230098]={name="Fish Bowl",labels={"All attributes"},percent=true},
 [1229513]={name="Incense Candle",labels={"Intellect"}},
 [1230164]={name="Lodestone",labels={"Melee attack power"}},
 [1229519]={name="Camp Chair",labels={"Critical chance"},percent=true},
 [1229718]={name="Faction Banner",labels={"Spirit"}},
}
