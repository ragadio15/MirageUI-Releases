local _,CC=...
-- F3: measure only our readable UI text. Never inspect protected gameplay text.
CC.TextLayout={}
local L=CC.TextLayout
local function number(v) return CC.Safety:IsNumber(v) end
function L:Read(object,method,...)
 local fn=object and object[method]
 if type(fn)~="function" then return nil end
 return CC.Safety:Value(fn,object,...)
end
function L:Width(text)
 local w=self:Read(text,"GetUnboundedStringWidth") or self:Read(text,"GetStringWidth")
 return number(w) and math.max(0,w) or 0
end
function L:Text(text,width,minimum)
 if not text then return minimum or 0 end
 width=number(width) and math.max(8,width) or 200
 text:SetWidth(width)
 if text.SetWordWrap then text:SetWordWrap(true) end
 if text.SetNonSpaceWrap then text:SetNonSpaceWrap(true) end
 if text.SetMaxLines then text:SetMaxLines(0) end
 if text.SetJustifyV then text:SetJustifyV("TOP") end
 -- Zero removes an explicit height constraint, allowing native measurement of
 -- ALL wrapped lines. There is no maximum line count or final-height cap.
 text:SetHeight(0)
 local h=self:Read(text,"GetStringHeight")
 if not number(h) or h<=0 then
  local value=self:Read(text,"GetText")
  if CC.Safety:IsText(value) and value~="" then
   local fontHeight=12
   if type(text.GetFont)=="function" then
    local ok,_,size=pcall(text.GetFont,text)
    if ok and number(size) and size>0 then fontHeight=size end
   end
   -- Conservative fallback only when the renderer cannot measure. Respect
   -- explicit newlines; over-allocation is preferable to losing instructions.
   local columns=math.max(1,math.floor(width/fontHeight));local lines=0
   for line in (value.."\n"):gmatch("(.-)\n") do lines=lines+math.max(1,math.ceil(#line/columns)) end
   h=lines*(fontHeight+3)
  else h=0 end
 end
 h=math.max(minimum or 0,math.ceil(h)+3)
 text:SetHeight(h)
 return h
end
function L:FixedText(text,width,height)
 if text.SetTextScale then text:SetTextScale(1) end
 if text.SetWordWrap then text:SetWordWrap(false) end
 text:SetWidth(width);text:SetHeight(0)
 local w=self:Width(text);local h=self:Read(text,"GetStringHeight")
 if number(h) and h>0 and text.SetTextScale then
  -- Keep a small gutter for native font-height/pixel rounding.
  text:SetTextScale(math.min(1,math.max(1,width-2)/math.max(1,w),math.max(1,height-2)/h))
 end
 text:SetHeight(height)
end
function L:Button(b)
 if b.ccSizing or not b.ccLabel then return end
 b.ccSizing=true
 if b.ccFixedHeight then
  b:SetHeight(b.ccFixedHeight)
  self:FixedText(b.ccLabel,math.max(8,b:GetWidth()-12),math.max(8,b.ccFixedHeight-8))
  b.ccSizing=false;return
 end
 local height=self:Text(b.ccLabel,math.max(8,b:GetWidth()-12),0)
 b:SetHeight(math.max(b.ccMinHeight or 25,height+8))
 b.ccSizing=false
end
function L:WindowSize(w,h,minW,minH)
 local availableW=math.max(100,UIParent:GetWidth()-24)
 local availableH=math.max(100,UIParent:GetHeight()-24)
 return math.min(w,math.max(minW or w,availableW)),math.min(h,math.max(minH or h,availableH))
end
function L:FitWindow(f)
 if not f or not f.SetScale then return end
 local scale=math.min(1,math.max(100,UIParent:GetWidth()-24)/math.max(1,f:GetWidth()),
  math.max(100,UIParent:GetHeight()-24)/math.max(1,f:GetHeight()))
 f:SetScale(scale)
end
function L:EditBox(edit,scroll)
 -- A font string measures the same text/font/width as the multiline input.
 -- The actual EditBox remains the editable, selectable scroll child.
 if not edit.ccMeasure then
  edit.ccMeasure=edit:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
  edit.ccMeasure:Hide()
  edit:HookScript("OnTextChanged",function() L:EditBox(edit,scroll) end)
  edit:HookScript("OnCursorChanged",function(_,_,y,_,height)
   if not number(y) then return end
   local top=math.abs(y);local visible=scroll:GetHeight();local current=scroll:GetVerticalScroll()
   if top<current then scroll:SetVerticalScroll(top)
   elseif top+(height or 16)>current+visible then scroll:SetVerticalScroll(math.max(0,top+(height or 16)-visible)) end
  end)
 end
 local font=self:Read(edit,"GetFontObject")
 if font then edit.ccMeasure:SetFontObject(font) end
 edit.ccMeasure:SetText(edit:GetText() or "")
 local height=self:Text(edit.ccMeasure,math.max(8,edit:GetWidth()-16),0)+16
 edit:SetHeight(math.max(scroll:GetHeight(),height))
 if scroll.UpdateScrollChildRect then scroll:UpdateScrollChildRect() end
end
function L:ViewportChanged()
 if CC.QuestRoutePanel then CC.QuestRoutePanel:Close() end
 if CC.NavigationLabel then CC.NavigationLabel.textKey=nil;CC.NavigationLabel:Hide() end
 CC.Controls:CloseChoices()
 for _,f in ipairs({CC.Settings.frame or false,CC.Wizard.frame or false,
    CC.ProfilePanel.dialog or false,CC.Settings.exportFrame or false,
    CC.Settings.historyFrame or false,CC.Bindings.capture or false}) do
  if f then self:FitWindow(f) end
 end
 if CC.QuestNotes and CC.QuestNotes.shown then CC.QuestNotes:Close() end
 if CC.Minimap then CC.Minimap:Refresh() end
end
