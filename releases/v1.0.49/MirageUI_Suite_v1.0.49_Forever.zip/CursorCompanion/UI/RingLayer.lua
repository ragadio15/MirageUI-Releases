local _,CC=...
CC.RingLayer={}
local media="Interface\\AddOns\\CursorCompanion\\Media\\"
local neutral={0.92,0.94,0.98}
local function isVital(role) return role=="Health" or role=="Resource" end
-- The 512px source art contains strokes narrower than a screen pixel at
-- ordinary ring sizes. Use prefiltered mip levels during rotation.
local function setArtwork(region,texture,spinning)
 if region.ccArtwork==texture and region.ccFiltered==spinning then return end
 region.ccArtwork,region.ccFiltered=texture,spinning
 if spinning then
  local ok,accepted=pcall(region.SetTexture,region,media.."Spin\\"..texture..".blp","CLAMP","CLAMP","TRILINEAR")
  if ok and accepted~=false then return end
 end
 region:SetTexture(media..texture..".tga")
end
function CC.RingLayer:Create(parent)
 local root=CreateFrame("Frame",nil,parent);root:SetPoint("CENTER",parent,"CENTER");root:SetSize(48,48)
 CC.OverlaySafety:MakePassive(root)
 local L={root=root,angle=0,pivot=type(CreateVector2)=="function" and CreateVector2(0.5,0.5) or nil}
 for _,name in ipairs({"glow","outline","art","progress"}) do
  local layer=name=="glow" and "BACKGROUND" or name=="outline" and "BORDER" or name=="progress" and "OVERLAY" or "ARTWORK"
  local t=root:CreateTexture(nil,layer)
  t:SetPoint("CENTER",root,"CENTER");t:SetSize(48,48);L[name]=t
  if name~="progress" then
   if t.SetSnapToPixelGrid then t:SetSnapToPixelGrid(false) end
   if t.SetTexelSnappingBias then t:SetTexelSnappingBias(0) end
  end
 end
 L.pointer=root:CreateTexture(nil,"OVERLAY")
 L.pointer:SetPoint("CENTER",root,"CENTER");L.pointer:SetSize(48,48)
 L.pointer:SetBlendMode("ADD");L.pointer:Hide()
 L.compassUnavailable=root:CreateTexture(nil,"OVERLAY")
 L.compassUnavailable:SetPoint("CENTER",root,"CENTER")
 L.compassUnavailable:SetTexture(media.."QuestUnavailable.tga")
 L.compassUnavailable:SetVertexColor(.57,.64,.69,.75)
 L.compassUnavailable:Hide()
 L.arrival=root:CreateTexture(nil,"OVERLAY");L.arrival:SetTexture(media.."TrailDot.tga")
 L.arrival:SetSize(10,10);L.arrival:SetVertexColor(.96,.79,.36,1);L.arrival:Hide()
 L.glow:SetBlendMode("ADD")
 for _,name in ipairs({"cast","channel","gcd"}) do
  local c=CreateFrame("Cooldown",nil,root);L[name]=c;c:SetAllPoints(root);CC.OverlaySafety:MakePassive(c)
  c:SetSwipeTexture(media.."Annulus.tga",1,1,1,1)
  c:SetDrawEdge(false);c:SetDrawBling(false);c:SetHideCountdownNumbers(true)
  c:SetDrawSwipe(true);c:SetReverse(true);c:SetRotation(0);c:Hide()
 end
 return L
end
function CC.RingLayer:Apply(L,r)
 local spinning=r.enabled and not r.questCompass and r.speed>0
 if not spinning then L.angle=0 end
 L.velocity=spinning and math.rad(r.speed)*(r.direction=="Clockwise" and -1 or 1) or 0
 L.options=r;L.displayHeading=nil;L.headingKey=nil;L.arrival:Hide();L.root:SetSize(r.size,r.size);L.root:SetAlpha(r.opacity)
 local gcdRole=r.role=="GCD" and not r.questCompass
 local texture=r.style=="Ring" and "HaloRing" or r.style=="Segments" and "HaloSegments" or r.style..tostring(r.stroke)
 for _,name in ipairs({"art","glow","outline","progress"}) do
  local t=L[name];t:ClearAllPoints();t:SetPoint("CENTER",L.root,"CENTER");t:SetSize(r.size,r.size)
  t:SetRotation(name=="progress" and 0 or L.angle,L.pivot)
 end
 setArtwork(L.art,texture,spinning)
 setArtwork(L.glow,"HaloGlow",spinning)
 setArtwork(L.outline,"HaloOutline",spinning)
 -- Function progress has its own rim. It never replaces, dims or rotates
 -- the configured artwork, including when a provider has no current data.
 L.progress:SetTexture(media.."ProgressRim"..r.stroke..".tga")
 L.pointer:ClearAllPoints();L.pointer:SetPoint("CENTER",L.root,"CENTER");-- The pointer glyph is centered within its own texture. Scale the GLYPH, not
 -- the whole compass-sized canvas: changing pointerWidth/pointerHeight must never move it.
 local width=r.pointerWidth or 1
 local height=r.pointerHeight or 1
 L.pointer:SetSize(math.max(12,r.size*.17)*width,math.max(16,r.size*.23)*height)
 L.compassUnavailable:ClearAllPoints();L.compassUnavailable:SetPoint("CENTER",L.root,"CENTER");L.compassUnavailable:SetSize(r.size,r.size)
 local pointerByStyle={QuestNeedle="Needle",QuestRose="Rose",QuestWayfinder="Wayfinder",QuestSundial="Sundial",QuestHorizon="Horizon",QuestAster="Aster",QuestEclipse="Eclipse",QuestVector="Vector",QuestBeacon="Beacon"}
 local variant=pointerByStyle[r.style] or "Needle"
 L.pointer:SetTexture(media.."QuestArrow"..variant..".tga")
 L.pointer:SetRotation(0,L.pivot);L.pointer:Hide();L.compassUnavailable:Hide()
 -- A native 12.1 radial texture consumes opaque unit percent without Lua arithmetic.
 -- On older client flavors it is left empty rather than fabricating combat information.
 if type(L.progress.SetRadialProgressBarPercent)=="function" then
  pcall(L.progress.SetRadialProgressBarPercent,L.progress,0)
 end
 L.progress:SetShown(r.enabled and not r.questCompass and isVital(r.role) and CC.Capabilities.vitals and type(L.progress.SetRadialProgressBarPercent)=="function")
 -- The ring is also a persistent aesthetic. Only the native timed sweep
 -- clears when a GCD ends; it must not remove the user's chosen shape.
 -- Keep the near-black classic outline out of the GCD composition so it
 -- cannot become an unintended dark track on bright terrain.
 L.art:SetShown(r.enabled)
 L.glow:SetShown(r.enabled and r.glow)
 L.outline:SetShown(r.enabled and not gcdRole and (r.style=="Ring" or r.style=="Segments"))
 L.root:SetShown(r.enabled)
 for _,name in ipairs({"cast","channel","gcd"}) do
  L[name]:Clear();L[name]:SetSwipeTexture(media.."ProgressRim"..r.stroke..".tga",1,1,1,1)
  L[name]:SetShown(r.enabled and not r.questCompass and ((r.role=="Cast / channel" and name~="gcd") or (r.role=="GCD" and name=="gcd")))
 end
 L.cast:SetSwipeColor(.2,.8,1,1);L.channel:SetSwipeColor(.8,.5,1,1)
 local a,b,c=self:Tint(r,nil,false)
 L.art:SetVertexColor(a,b,c,1);L.progress:SetVertexColor(a,b,c,1)
 L.glow:SetVertexColor(a,b,c,.45)
 L.gcd:SetSwipeColor(a,b,c,1)
end
function CC.RingLayer:Tint(r,s,contrast)
 -- Range is a live signal; the chosen tint is its resting appearance.
 -- Resolve a readable verdict before any preset can return a fixed color.
 -- Unknown / absent range falls through to the same saved tint as resting.
 if r.role=="Spell range" then
  if s and s.range=="IN" then return contrast and .2 or .25,contrast and .8 or 1,contrast and 1 or .4
  elseif s and s.range=="OUT" then return 1,contrast and .55 or .3,.25 end
 end
 local brand=CC.MUIColorPresets and CC.MUIColorPresets[r.colorMode]
 if brand then return brand.r,brand.g,brand.b end
 local a,b,d=neutral[1],neutral[2],neutral[3]
 if r.colorMode=="Manual" then a,b,d=r.r,r.g,r.b
 elseif r.colorMode=="Class" then
  if not self.classChecked then
   self.classChecked=true
   local tag=CC.Safety:Value(UnitClassBase,"player")
   if type(tag)=="string" and C_ClassColor and type(C_ClassColor.GetClassColor)=="function" then
    local color=CC.Safety:Value(C_ClassColor.GetClassColor,tag)
    local cr,cg,cb=CC.Safety:Field(color,"r"),CC.Safety:Field(color,"g"),CC.Safety:Field(color,"b")
    if CC.Safety:IsNumber(cr) and CC.Safety:IsNumber(cg) and CC.Safety:IsNumber(cb) then self.classTint={cr,cg,cb} end
   end
  end
  if self.classTint then a,b,d=self.classTint[1],self.classTint[2],self.classTint[3] end
 end
 if r.role=="Health" and r.colorMode=="Neutral" then return .04,.94,.48 end
 if r.role=="Resource" and r.colorMode=="Neutral" then return .13,.65,1 end
 if r.role=="Relationship" then
  if s and s.relationship=="FRIENDLY" then return .35,.9,.5
  elseif s and s.relationship=="HOSTILE" then return 1,.35,.3
  elseif s and s.relationship=="NEUTRAL" then return 1,.8,.3 end
  return .55,.58,.62
 end
 return a,b,d
end
function CC.RingLayer:Update(L,r,s,dt,idle,contrast,questState)
 if not r.enabled then L.pointer:Hide();L.arrival:Hide();L.displayHeading=nil;L.compassUnavailable:Hide();L.root:Hide();return end
 -- Navigation is a passive display in combat too. Providers expose a bearing
 -- only after validating fresh readable positions and facing; an unavailable
 -- provider never replays its last angle.
 L.root:Show()
 if r.questCompass then
  -- The selected Quest or Beacon provider owns this independent outer layer.
  -- A stale bearing is never replayed when facing or waypoint becomes unreadable.
  local usable=questState and questState.status=="GUIDING" and CC.Safety:IsNumber(questState.angle)
  local a,b,c=self:Tint({colorMode=r.colorMode,role="Decorative",r=r.r,g=r.g,b=r.b},s,contrast)
  if questState and questState.kind=="Beacon" and CC.NativePings then
   local color=CC.NativePings:Color(questState.transmissionType,questState.previewProfile)
   if color then a,b,c=color.r,color.g,color.b end
  end
  L.arrival:SetVertexColor(a,b,c,1)
  L.art:SetVertexColor(a,b,c,1)
  L.glow:SetVertexColor(a,b,c,.42)
  L.outline:Hide();L.progress:Hide()
  for _,name in ipairs({"cast","channel","gcd"}) do L[name]:Hide() end
  L.art:SetRotation(0,L.pivot);L.glow:SetRotation(0,L.pivot)
  L.art:Show();L.glow:SetShown(r.glow)
  L.pointer:SetShown(usable==true)
  L.compassUnavailable:Hide() -- Unknown heading: no misleading question-mark marker
  local arrived=questState and questState.status=="NEAR_DESTINATION" and r.arrivalCue==true
  L.arrival:SetShown(arrived==true)
  if arrived then L.arrival:ClearAllPoints();L.arrival:SetPoint("CENTER",L.root,"CENTER",0,r.size*.40) end
  if usable then
   local key=questState.key or questState.questID
   local heading=CC.QuestNavigation:SmoothAngle(L.displayHeading,questState.angle,dt,
    not r.smoothHeading or L.headingKey~=key)
   L.displayHeading=heading;L.headingKey=key
   local radius=r.size*.40 -- positive heading is left (counterclockwise)
   L.pointer:ClearAllPoints()
   L.pointer:SetPoint("CENTER",L.root,"CENTER",-math.sin(heading)*radius,math.cos(heading)*radius)
   L.pointer:SetRotation(heading,L.pivot)
   local alpha=1
   if r.arrivalCue and CC.Safety:IsNumber(questState.distance) then
    alpha=math.max(.3,math.min(1,(questState.distance-(r.arrivalRadius or 8))/12))
   end
   L.pointer:SetVertexColor(a,b,c,alpha)
  else L.displayHeading=nil;L.headingKey=nil end
  return
 end
 L.pointer:Hide();L.arrival:Hide();L.displayHeading=nil;L.compassUnavailable:Hide()
 local a,b,c=self:Tint(r,s,contrast)
 if r.role=="GCD" then
  -- The native Cooldown owns progress and stops drawing when its timer ends.
  -- Artwork remains independent. Do not inspect opaque duration objects or
  -- manufacture an idle progress track. Both layers inherit saved opacity
  -- once from root, including in the preview.
  L.gcd:SetSwipeColor(a,b,c,1)
 end
 local vital=isVital(r.role) and CC.Capabilities.vitals and type(L.progress.SetRadialProgressBarPercent)=="function"
 local showProgress=vital
 if L.runtimeSlot and vital and CC.profile and CC.profile.rings[L.runtimeSlot]==r then
  local kind=r.role=="Health" and "health" or "resource"
  showProgress=CC.Vitals and CC.Vitals.valid[kind]==true and CC.Vitals.radialFaults[L.runtimeSlot]~=true
 end
 L.art:SetVertexColor(a,b,c,1)
 L.progress:SetVertexColor(a,b,c,1)
 L.progress:SetShown(showProgress)
 L.glow:SetVertexColor(a,b,c,.45)
 L.art:Show();L.outline:SetShown(r.role~="GCD" and (r.style=="Ring" or r.style=="Segments"))
 L.glow:SetShown(r.glow)
 -- Progress stays stationary so its angular origin never drifts. Every role
 -- can spin its configured artwork independently of that functional layer.
 if not idle and L.velocity~=0 then
  L.angle=(L.angle+L.velocity*dt)%(2*math.pi)
  L.art:SetRotation(L.angle,L.pivot)
  if r.glow then L.glow:SetRotation(L.angle,L.pivot) end
  if L.outline:IsShown() then L.outline:SetRotation(L.angle,L.pivot) end
 end
end
