local _,CC=...
CC.TrackedSpells={views={}}
local T=CC.TrackedSpells;local S=CC.Safety
function T:Validate(input)
 local result={input=input or "",status="Invalid",id=nil,name=nil,rangeEligible=false}
 if type(input)~="string" then return result end
 input=input:match("^%s*(.-)%s*$");result.input=input
 if input=="" then result.status="";return result end
 local key=input:match("spell:(%d+)") or input
 if key:match("^%d+$") then key=tonumber(key) end
 local info=S:Value(C_Spell and C_Spell.GetSpellInfo,key)
 if not info then
  -- Loading is temporary, never a false Not Learned or Ready result.
  if type(key)=="number" and C_Spell and C_Spell.RequestLoadSpellData then
   self.requested=self.requested or {}
   if not self.requested[key] then self.requested[key]=true;pcall(C_Spell.RequestLoadSpellData,key) end
  end
  return result
 end
 local id,name=S:Field(info,"spellID"),S:Field(info,"name")
 if not S:IsNumber(id) or id<1 or id%1~=0 or not S:IsText(name) then return result end
 result.id=id;result.name=name
 local known=S:BoolCall(C_SpellBook and C_SpellBook.IsSpellKnown,id)
 if known==false then result.status="Not Learned";return result end
 if known~=true then return result end
 result.status="Ready"
 -- Being known is not the same as being a suitable harmful ranged spell.
 local lo,hi=S:Field(info,"minRange"),S:Field(info,"maxRange")
 local current=S:Value(C_Spell and C_Spell.GetOverrideSpell,id)
 result.rangeEligible=S:IsNumber(lo) and S:IsNumber(hi) and lo>=0 and hi>0 and hi>=lo and hi<=200
  and S:BoolCall(C_Spell and C_Spell.IsSpellHarmful,id)==true
  and S:BoolCall(C_Spell and C_Spell.IsSpellPassive,id)==false
  and S:BoolCall(C_Spell and C_Spell.SpellHasRange,id)==true and current==id
 result.min=lo;result.max=hi
 return result
end
function T:Sync(info)
 -- Rows never choose an optimal/reference spell automatically. Preserve explicit selection.
 local ready,probes={},{}
 for _,input in ipairs(info.tracked or {}) do
  local v=self:Validate(input)
  if v.status=="Ready" and v.id then ready[tostring(v.id)]=v
   if v.rangeEligible and v.min==0 and v.max>5 then probes[#probes+1]=tostring(v.id) end
  end
 end
 if info.reference~="" then
  local v=self:Validate(info.reference)
  if not v.id or not ready[tostring(v.id)] or not v.rangeEligible then info.reference="" end
 end
 info.probes=table.concat(probes,",")
 return ready
end
function T:Create(parent,owner)
 local C=CC.Controls
 local view={owner=owner,rows={},results={}}
 local f=CreateFrame("Frame",nil,parent);view.frame=f;f:SetSize(410,160)
 C:Text(f,"Tracked Spell",0,0,"GameFontNormalSmall");C:Text(f,"Spell ID",226,0,"GameFontNormalSmall");C:Text(f,"Status",296,0,"GameFontNormalSmall")
 for i=1,8 do
  local row=CreateFrame("Frame",nil,f);row:SetSize(410,32);row:SetPoint("TOPLEFT",0,-24-(i-1)*34)
  local edit=CreateFrame("EditBox",nil,row,"BackdropTemplate");CC.Skin:Input(edit);edit:SetSize(208,24);edit:SetPoint("TOPLEFT",4,0);edit:SetAutoFocus(false);edit:SetMaxLetters(200)
  row.input=edit;row.id=C:Text(row,"",226,-5,"GameFontHighlightSmall");row.id:SetWidth(65)
  row.status=C:Text(row,"",296,-5,"GameFontHighlightSmall");row.status:SetWidth(85)
  row.remove=C:Button(row,"-",386,0,22,function()
   if not owner.draft or CC.Safety:InCombat() then return end
   table.remove(owner.draft.info.tracked,i);if #owner.draft.info.tracked==0 then owner.draft.info.tracked={""} end
   self:Sync(owner.draft.info);view:Refresh();owner:Notice("Changes not saved yet.");owner:Preview()
  end)
  C:Tip(row.remove,"Remove this spell.")
  edit:SetScript("OnTextChanged",function(b,user)
   if not user or view.refreshing or not owner.draft or CC.Safety:InCombat() then return end
   owner.draft.info.tracked[i]=b:GetText();view.due=(GetTime and GetTime() or 0)+.35
   -- Immediately clear old ID/readiness while editing; never add an unchecked row.
   row.id:SetText("");row.status:SetText("");view.add:Hide();owner:Notice("Changes not saved yet.")
  end)
  edit:SetScript("OnEnterPressed",function(b) view:ValidateRows();b:ClearFocus() end)
  edit:SetScript("OnEditFocusLost",function() if not view.refreshing then view:ValidateRows() end end)
  edit:SetScript("OnEscapePressed",function(b) b:ClearFocus() end)
  edit:SetScript("OnTabPressed",function(b)
   view:ValidateRows();b:ClearFocus();local nextRow=view.rows[i+1];if nextRow and nextRow:IsShown() then nextRow.input:SetFocus() end
  end)
  view.rows[i]=row
 end
 view.add=C:Button(f,"Add Spell",0,-65,120,function()
  if not owner.draft or CC.Safety:InCombat() or not view:CanAdd() then return end
  local rows=owner.draft.info.tracked;rows[#rows+1]="";view:Refresh();view.rows[#rows].input:SetFocus()
 end)
 view.rangeLabel=C:Text(f,"Use for range",0,-102,"GameFontNormalSmall")
 view.range=C:Button(f,"Choose a spell",142,-97,260,function(button)
  local values,labels={},{}
  for _,v in ipairs(view.results) do
   if v.status=="Ready" and v.rangeEligible then local id=tostring(v.id);values[#values+1]=id;labels[id]=v.name end
  end
  if #values==0 then owner:Notice("Add a learned ranged attack to use for range.");return end
  C:Choose(button,values,labels,owner.draft.info.reference,function(v) owner.draft.info.reference=v;view:Refresh();owner:Preview();owner:Notice("Changes not saved yet.") end)
 end)
 C:Tip(view.range,"Choose one learned ranged attack. Its range colors do not mean that the spell is ready to cast.")
 function view:CanAdd()
  local rows=self.owner.draft and self.owner.draft.info.tracked
  if not rows or #rows>=8 then return false end
  for i=1,#rows do if not self.results[i] or self.results[i].status~="Ready" then return false end end
  return #rows>0
 end
 function view:ValidateRows()
  self.due=nil;if not self.owner.draft or CC.Safety:InCombat() then return end
  self.results={};local ids={}
  for i,input in ipairs(self.owner.draft.info.tracked) do
   local v=T:Validate(input)
   if v.id and ids[v.id] then v.status="Invalid";v.duplicate=true else if v.id then ids[v.id]=true end end
   self.results[i]=v
   self.rows[i].id:SetText(v.id and tostring(v.id) or "")
   self.rows[i].status:SetText(v.status)
   self.rows[i].status:SetTextColor(v.status=="Ready" and .4 or 1,v.status=="Ready" and .9 or .65,.45)
  end
  T:Sync(self.owner.draft.info)
  self:Layout();self.owner:Preview()
 end
 function view:Layout()
  local n=#self.owner.draft.info.tracked;local used=24
  for i=1,n do
   local row=self.rows[i]
   local h=math.max(32,CC.TextLayout:Text(row.status,85,16)+10,CC.TextLayout:Text(row.id,65,16)+10)
   row:ClearAllPoints();row:SetPoint("TOPLEFT",0,-used);row:SetHeight(h)
   used=used+h+2
  end
  local y=-used
  self.add:ClearAllPoints();self.add:SetPoint("TOPLEFT",0,y);self.add:SetShown(self:CanAdd())
  local ry=y-36;self.rangeLabel:ClearAllPoints();self.rangeLabel:SetPoint("TOPLEFT",0,ry-5)
  self.range:ClearAllPoints();self.range:SetPoint("TOPLEFT",142,ry)
  local selected=self.owner.draft.info.reference;local v=T:Validate(selected)
  self.range:SetText(v.status=="Ready" and v.name or "Choose a spell")
  self.frame:SetHeight(-ry+math.max(40,self.range:GetHeight()+12));if self.owner.LayoutSpells then self.owner:LayoutSpells(self.frame:GetHeight()) end
 end
 function view:Refresh()
  if not self.owner.draft then return end
  self.refreshing=true
  for i,row in ipairs(self.rows) do
   local input=self.owner.draft.info.tracked[i];row:SetShown(input~=nil)
   if input~=nil then row.input:SetText(input) end
  end
  self.refreshing=false;self:ValidateRows()
 end
 f:SetScript("OnUpdate",function() if view.due and GetTime()>=view.due then view:ValidateRows() end end)
 self.views[#self.views+1]=view;return view
end
function T:RefreshVisible()
 for _,v in ipairs(self.views) do if v.frame:IsShown() and v.owner.draft then v:ValidateRows() end end
end
