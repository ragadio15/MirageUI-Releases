local _,CC=...
-- The Fishing Assistant HUD is intentionally cosmetic. Its timer reads public
-- channel timing, and it never casts, equips, clicks, or changes secure actions.
-- MirageUI beta 61 options colors, packaged locally through CC.Skin.
-- The fishing overlay does not require MirageUI itself to be installed.
CC.FishingStatus={serial=0,elapsed=0}
local H=CC.FishingStatus
local K=CC.Skin
local accent=K.accent
local secondary=K.secondary
local textColor=K.text
local muted=K.muted
local media="Interface\\AddOns\\CursorCompanion\\Media\\"
local states={
 CASTING="LINE CAST",CAST_CHECK="CASTING LINE",RECASTING="RECASTING",READY="READY",
 EQUIPPING="EQUIPPING POLE",SWAPPING="EQUIPMENT CHANGE",RESTORING="RESTORING WEAPONS",
 RESTORE_READY="RESTORE READY",RESTORE_WAIT="RESTORE PAUSED",RESTORED="WEAPONS RESTORED",
 LOOT="CATCH COLLECTED",NO_ACCESS="FISHING UNAVAILABLE",NO_POLE="NO POLE AVAILABLE",
 BAGS_FULL="BAGS FULL",RECAST_UNCONFIRMED="RECAST NOT CONFIRMED",
}
local function failColor(phase)
 return phase=="NO_ACCESS" or phase=="NO_POLE" or phase=="BAGS_FULL" or phase=="RECAST_UNCONFIRMED"
  or phase=="EQUIP_FAILED" or phase=="SWAP_UNAVAILABLE" or phase=="RESTRICTED"
  or phase=="UNAVAILABLE" or phase=="UNLEARNED" or phase=="EQUIPMENT_UNAVAILABLE"
end
local function shade(texture,c,alpha) texture:SetColorTexture(c[1],c[2],c[3],alpha or 1) end
local function public(frame,method,kind)
 local S=CC.Safety
 if not S then return end
 local fn=S:Field(frame,method)
 if type(fn)~="function" then return end
 local ok,value=pcall(fn,frame)
 if not ok or not S:IsReadable(value) then return end
 if kind=="number" then if S:IsNumber(value) then return value end
 elseif type(value)==kind then return value end
end
local function measured(frame,parentScale)
 if not frame or public(frame,"IsVisible","boolean")~=true then return end
 local scale=public(frame,"GetEffectiveScale","number")
 local left,right=public(frame,"GetLeft","number"),public(frame,"GetRight","number")
 local bottom,top=public(frame,"GetBottom","number"),public(frame,"GetTop","number")
 if not scale or scale<=0 or not left or not right or not bottom or not top or right<=left or top<=bottom then return end
 local ratio=scale/parentScale
 return {left=left*ratio,right=right*ratio,bottom=bottom*ratio,top=top*ratio}
end
local function merge(a,b)
 if not b then return a end
 if not a then return b end
 a.left=math.min(a.left,b.left);a.right=math.max(a.right,b.right)
 a.bottom=math.min(a.bottom,b.bottom);a.top=math.max(a.top,b.top)
 return a
end
function H:ReleaseHUD()
 local hud=self.borrowedHUD
 self.borrowedHUD=nil
 if hud then
  local setter=CC.Safety:Field(hud,"SetFishingPresentation")
  if type(setter)=="function" then pcall(setter,hud,self.frame,false) end
 end
end
function H:BorrowCastLane()
 local S=CC.Safety
 local hud=S:Field(S:Field(_G,"MirageUI"),"UnderCharacterHUD")
 if hud~=self.borrowedHUD then self:ReleaseHUD() end
 local reader=S:Field(hud,"GetFishingAnchor")
 local setter=S:Field(hud,"SetFishingPresentation")
 if type(reader)~="function" or type(setter)~="function" or not self.frame or not self.frame:IsShown() then self:ReleaseHUD();return end
 local ok,value=pcall(reader,hud)
 if ok and S:IsReadable(value) and type(value)=="table" and S:Field(value,"space")=="UIParent" then
  local left,right,bottom,top=S:Field(value,"left"),S:Field(value,"right"),S:Field(value,"bottom"),S:Field(value,"top")
  if S:IsNumber(left) and S:IsNumber(right) and S:IsNumber(bottom) and S:IsNumber(top) and right>left and top>bottom then
   local accepted,result=pcall(setter,hud,self.frame,true)
   if accepted and result==true then
    self.borrowedHUD=hud
    return {left=left,right=right,bottom=bottom,top=top}
   end
  end
 end
 self:ReleaseHUD()
end
function H:CastBounds(parentScale)
 local result,S={},CC.Safety
 local m=S:Field(_G,"MirageUI")
 local hud=S:Field(m,"UnderCharacterHUD")
 local reader=S:Field(hud,"GetDisplayBounds")
 if type(reader)=="function" then
  local ok,value=pcall(reader,hud)
  if ok and S:IsReadable(value) and type(value)=="table" and S:Field(value,"space")=="UIParent" then
   local left,right,bottom,top=S:Field(value,"left"),S:Field(value,"right"),S:Field(value,"bottom"),S:Field(value,"top")
   if S:IsNumber(left) and S:IsNumber(right) and S:IsNumber(bottom) and S:IsNumber(top) and right>left and top>bottom then
    result[#result+1]={left=left,right=right,bottom=bottom,top=top,source="MIRAGE_HUD"}
   end
  end
 end
 -- Standalone installs, native fallback and a disabled core HUD still receive
 -- collision avoidance. Read actual public geometry; never move/hide a cast.
 local previous
 for _,name in ipairs({"PlayerCastingBarFrame","CastingBarFrame"}) do
  local frame=S:Field(_G,name)
  if frame and frame~=previous then
   previous=frame
   local bounds=measured(frame,parentScale)
   if bounds then
    for _,key in ipairs({"Text","Time","SpellName"}) do bounds=merge(bounds,measured(S:Field(frame,key),parentScale)) end
    bounds.source="NATIVE_CAST";result[#result+1]=bounds
   end
  end
 end
 return result
end
function H:Layout()
 local f=self.frame
 if not f then return end
 local w,h=public(UIParent,"GetWidth","number"),public(UIParent,"GetHeight","number")
 local scale=public(UIParent,"GetEffectiveScale","number")
 if not w or not h or not scale or w<120 or h<100 or scale<=0 then self.layoutState="VIEWPORT_PENDING";return end
 local width,height=math.min(360,w-32),56
 local halfW,halfH=width/2,height/2
 local minX,maxX=16+halfW,w-16-halfW
 local minY,maxY=16+halfH,h-16-halfH
 local preferredX,preferredY=w/2,math.max(minY,math.min(maxY,h/2-150))
 local lane=self:BorrowCastLane()
 if lane then
  preferredX=math.max(minX,math.min(maxX,(lane.left+lane.right)/2))
  preferredY=math.max(minY,math.min(maxY,(lane.bottom+lane.top)/2))
 end
 local obstacles=self:CastBounds(scale)
 local gap=12
 local function clear(x,y)
  for _,b in ipairs(obstacles) do
   if x+halfW>b.left-gap and x-halfW<b.right+gap and y+halfH>b.bottom-gap and y-halfH<b.top+gap then return false end
  end
  return true
 end
 local x,y=preferredX,preferredY
 local state=lane and "MIRAGE_CAST_LANE" or "PREFERRED_POSITION"
 if not clear(x,y) then
  -- Search the finite boundaries of the observed rectangles. Prefer a
  -- vertical move above the cast; side placement handles a manually moved
  -- HUD near the screen edge without allowing a second collision.
  local xs,ys={preferredX,minX,maxX},{preferredY,minY,maxY}
  for _,b in ipairs(obstacles) do
   xs[#xs+1]=b.left-halfW-gap;xs[#xs+1]=b.right+halfW+gap
   ys[#ys+1]=b.top+halfH+gap;ys[#ys+1]=b.bottom-halfH-gap
  end
  local best
  for _,cx in ipairs(xs) do for _,cy in ipairs(ys) do
   if cx>=minX and cx<=maxX and cy>=minY and cy<=maxY and clear(cx,cy) then
    local score=math.abs(cx-preferredX)*1.8+math.abs(cy-preferredY)+(cy<preferredY and 16 or 0)
    if not best or score<best then best=score;x,y=cx,cy end
   end
  end end
  state=best and "CAST_CLEARANCE" or "NO_FREE_VIEWPORT_SPACE"
 end
 if self.layoutWidth~=width then
  f:SetSize(width,height)
  self.title:SetWidth(math.max(1,width-122));self.label:SetWidth(math.max(1,width-70))
  self.progressWidth=width-24;self.progressTrack:SetWidth(self.progressWidth)
  self.layoutWidth=width
 end
 if self.layoutX~=x or self.layoutY~=y or self.viewportW~=w or self.viewportH~=h then
  f:ClearAllPoints();f:SetPoint("CENTER",UIParent,"BOTTOMLEFT",x,y)
  self.layoutX,self.layoutY,self.viewportW,self.viewportH=x,y,w,h
 end
 self.layoutState=state
 self.layoutBounds={left=x-halfW,right=x+halfW,bottom=y-halfH,top=y+halfH,space="UIParent"}
end
function H:ClearTimer()
 if self.timer then self.timer:SetText("") end
 if self.progressTrack then self.progressTrack:Hide() end
 if self.progressFill then self.progressFill:SetWidth(0) end
end
function H:CreateRestorePrompt(button)
 -- SecureActionButtonTemplate remains independent of this display and keeps
 -- its existing native PreClick/PostClick and protected equipment behavior.
 button:SetSize(298,48)
 button:SetPoint("CENTER",UIParent,"CENTER",0,-224)
 button:SetFrameStrata("DIALOG");button:EnableMouse(true)
 local background=button:CreateTexture(nil,"BACKGROUND")
 background:SetAllPoints();background:SetColorTexture(K.background[1],K.background[2],K.background[3],K.background[4]*.8)
 local rule=button:CreateTexture(nil,"BORDER")
 rule:SetPoint("TOPLEFT",button,"TOPLEFT",0,0);rule:SetPoint("BOTTOMLEFT",button,"BOTTOMLEFT",0,0)
 rule:SetWidth(3);shade(rule,accent)
 local label=button:CreateFontString(nil,"OVERLAY","GameFontNormal")
 label:SetPoint("TOPLEFT",button,"TOPLEFT",14,-8);label:SetText("Restore weapons")
 label:SetTextColor(textColor[1],textColor[2],textColor[3])
 local hint=button:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
 hint:SetPoint("TOPLEFT",button,"TOPLEFT",14,-27)
 hint:SetText("Left-click to restore  |  Right-click to dismiss")
 hint:SetTextColor(muted[1],muted[2],muted[3])
 button.restoreLabel=label
end
function H:UpdateTimer(elapsed)
 self.elapsed=(self.elapsed or 0)+(type(elapsed)=="number" and elapsed or 0)
 if self.elapsed<.10 then return end
 self.elapsed=0
 if not self.frame or not self.frame:IsShown() then return end
 if not self:CanPresent() then self:Hide();return end
 self:Layout()
 if self.phase~="CASTING" then self:ClearTimer();return end
 local F=CC.Fishing
 if not F or not F.channel or type(UnitChannelInfo)~="function" then self:ClearTimer();return end
 local ok,_,_,_,startMS,endMS=pcall(UnitChannelInfo,"player")
 local S=CC.Safety
 if not ok or not S or not S:IsNumber(startMS) or not S:IsNumber(endMS) or endMS<=startMS then
  self:ClearTimer();return
 end
 local current
 if type(GetTime)=="function" then local good,v=pcall(GetTime);if good and S:IsNumber(v) then current=v end end
 if not current then self:ClearTimer();return end
 local duration=(endMS-startMS)/1000
 local progress=math.max(0,math.min(1,(current-startMS/1000)/duration))
 self.progressFill:SetWidth(self.progressWidth*progress)
 self.timer:SetText(string.format("%.1fs",math.max(0,endMS/1000-current)))
 self.progressTrack:Show()
end
function H:Create()
 if self.frame then return end
 local f=CreateFrame("Frame",nil,CC.VisualLifecycle:OverlayParent(),"BackdropTemplate");self.frame=f
 f:SetSize(360,56);f:SetPoint("CENTER",UIParent,"CENTER",0,-150)
 f:SetFrameStrata("MEDIUM");f:EnableMouse(false)
 K:Panel(f,true)
 local bg=K.background
 f:SetBackdropColor(bg[1],bg[2],bg[3],bg[4]*.8)
 local left=f:CreateTexture(nil,"BORDER");self.rule=left
 left:SetPoint("TOPLEFT",f,"TOPLEFT",0,-1);left:SetPoint("BOTTOMLEFT",f,"BOTTOMLEFT",0,1)
 left:SetWidth(3);shade(left,accent)
 local icon=f:CreateTexture(nil,"ARTWORK");self.icon=icon
 icon:SetSize(38,38);icon:SetPoint("LEFT",f,"LEFT",12,2)
 icon:SetTexture(media.."FishingHook.tga")
 local eyebrow=f:CreateFontString(nil,"OVERLAY","GameFontNormal")
 eyebrow:SetPoint("TOPLEFT",f,"TOPLEFT",58,-9)
 eyebrow:SetWidth(230);eyebrow:SetJustifyH("LEFT")
 eyebrow:SetText("Fishing Assistant")
 eyebrow:SetTextColor(secondary[1],secondary[2],secondary[3]);self.title=eyebrow
 local stage=f:CreateFontString(nil,"OVERLAY","GameFontNormal")
 stage:SetPoint("TOPLEFT",f,"TOPLEFT",58,-28)
 stage:SetWidth(286);stage:SetJustifyH("LEFT")
 stage:SetTextColor(textColor[1],textColor[2],textColor[3]);self.label=stage
 local timer=f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
 timer:SetPoint("TOPRIGHT",f,"TOPRIGHT",-12,-11)
 timer:SetTextColor(secondary[1],secondary[2],secondary[3]);self.timer=timer
 local track=CreateFrame("Frame",nil,f);self.progressTrack=track
 self.progressWidth=336
 track:SetSize(self.progressWidth,2);track:SetPoint("BOTTOMLEFT",f,"BOTTOMLEFT",12,3)
 local rail=track:CreateTexture(nil,"BACKGROUND");rail:SetAllPoints();rail:SetColorTexture(K.edge[1],K.edge[2],K.edge[3],.62)
 local fill=track:CreateTexture(nil,"ARTWORK");self.progressFill=fill
 fill:SetPoint("TOPLEFT",track,"TOPLEFT",0,0);fill:SetHeight(2);fill:SetWidth(0)
 shade(fill,accent)
 track:Hide()
 f:SetScript("OnUpdate",function(_,dt) H:UpdateTimer(dt) end)
 f:SetScript("OnHide",function() H:ReleaseHUD();H:ClearTimer() end)
 f:Hide()
end
function H:Hide()
 self.serial=self.serial+1
 self.phase=nil
 if self.frame then self.frame:Hide();self:ClearTimer() end
 self:ReleaseHUD()
end
function H:CanPresent()
 local state=CC.state
 local S=CC.Safety
 local coreState=S:Field(S:Field(_G,"MirageUI"),"state")
 return not CC.VisualLifecycle.startupHidden and (not state or (state.inWorld~=false and state.cinematic~=true)) and S:Field(coreState,"keybindWorkspace")~=true
end
function H:ResumeChannel()
 -- Event listeners can observe world entry in either order. Re-present only
 -- a current verified fishing channel after the core commits visibility; do
 -- not replay transient notices or issue another cast/equipment operation.
 if not self:CanPresent() then self:Hide();return end
 local F=CC.Fishing
 if F and F.channel and F.phase=="CASTING" and F:ChannelInfo()==true then self:Set("",true) end
end
function H:Set(message,persistent)
 local p=CC.profile and CC.profile.fishing
 if not p or not p.showStatus or not self:CanPresent() then self:Hide();return end
 self:Create()
 self.serial=self.serial+1
 local token=self.serial
 local phase=CC.Fishing and CC.Fishing.phase or "READY"
 local r=states[phase]
 if phase=="RESTORE_READY" and CC.Fishing and type(CC.Fishing.RestoreEntry)=="function" then
  local _,slot=CC.Fishing:RestoreEntry()
  if slot then r=slot==17 and "PRESS SHORTCUT · OFF-HAND" or slot==18 and "PRESS SHORTCUT · RANGED" or "PRESS SHORTCUT · MAIN HAND" end
 end
 self.phase=phase
 self.label:SetText(r or (phase or "FISHING"):gsub("_"," "))
 local c=failColor(phase) and secondary or accent
 shade(self.rule,c)
 self:ClearTimer()
 self.frame:Show()
 self:Layout()
 -- Cast providers may process the same channel-start event after this addon.
 -- Recheck their committed geometry on the next frame, then use the existing
 -- visible-only 100 ms heartbeat for moves, scale changes and fallback swaps.
 if C_Timer and type(C_Timer.After)=="function" then
  C_Timer.After(0,function() if self.serial==token and self.frame and self.frame:IsShown() then self:Layout() end end)
 end
 -- Read-only channel progress; never drives a cast, recast, or interaction.
 if phase=="CASTING" then self:UpdateTimer(.11) end
 if not persistent and C_Timer and type(C_Timer.After)=="function" then
  C_Timer.After(6,function() if self.serial==token then self:Hide() end end)
 end
end
