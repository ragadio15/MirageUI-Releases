local _,CC=...
CC.Controls={}
local C=CC.Controls
function C:Angle(y,x)
 if math.atan2 then return math.atan2(y,x) end
 if x>0 then return math.atan(y/x) end
 if x<0 then return math.atan(y/x)+(y>=0 and math.pi or -math.pi) end
 return y>0 and math.pi/2 or y<0 and -math.pi/2 or 0
end
function C:Text(parent,text,x,y,size)
 local f=parent:CreateFontString(nil,"OVERLAY",size or "GameFontNormal")
 f:SetPoint("TOPLEFT",x,y);f:SetText(text);f:SetJustifyH("LEFT")
 if parent:GetWidth()>0 then f:SetWidth(math.max(8,parent:GetWidth()-x-10)) end
 if f.SetWordWrap then f:SetWordWrap(true) end
 if f.SetNonSpaceWrap then f:SetNonSpaceWrap(true) end
 if f.SetJustifyV then f:SetJustifyV("TOP") end
 CC.Skin:Text(f);return f
end
function C:Button(parent,label,x,y,w,fn)
 local b=CreateFrame("Button",nil,parent,"BackdropTemplate")
 b:SetSize(w or 130,25);b:SetPoint("TOPLEFT",x,y);if parent.ccFixedButtons then b.ccFixedHeight=25 end;CC.Skin:Button(b);b:SetText(label);b:SetScript("OnClick",fn);return b
end
function C:Tip(frame,text)
 if not text or text=="" then return end
 frame:HookScript("OnEnter",function(b)
  if GameTooltip then GameTooltip:SetOwner(b,"ANCHOR_RIGHT");GameTooltip:SetText(text,1,1,1,1,true);GameTooltip:Show() end
 end)
 frame:HookScript("OnLeave",function() if GameTooltip then GameTooltip:Hide() end end)
end
function C:Get(p,path)
 if path=="outside.mode" then
  if p.compass and p.compass.enabled then return p.compass.mode=="Beacon" and "Beacon" or "Quest Compass" end
  if p.rings and p.rings.outer2 and p.rings.outer2.enabled then return "Outer Ring 2" end
  return "None"
 end
 local t=p;for key in path:gmatch("[^.]+") do if type(t)~="table" then return nil end;t=t[key] end;return t
end
function C:Set(p,path,v)
 if path=="outside.mode" then
  p.compass.enabled=v=="Quest Compass" or v=="Beacon"
  if v=="Quest Compass" then p.compass.mode="Quest" elseif v=="Beacon" then p.compass.mode="Beacon" end
  p.rings.outer2.enabled=v=="Outer Ring 2"
  return
 end
 local parts={};for k in path:gmatch("[^.]+") do parts[#parts+1]=k end
 local t=p;for i=1,#parts-1 do t=t[parts[i]] end;t[parts[#parts]]=v
end
function C:Backdrop(f) CC.Skin:Panel(f) end
function C:CloseChoices()
 if self.choices then
  if self.choices.UnregisterEvent then self.choices:UnregisterEvent("GLOBAL_MOUSE_DOWN") end
  self.choices:Hide()
 end
end
function C:IsChoiceMouseInside()
 local f=self.choices
 if not f or not f:IsShown() then return false end
 -- IsMouseOver handles the menu and its actual child hit regions. No
 -- full-screen interception layer is used, so the outside click still acts.
 if type(f.IsMouseOver)=="function" then
  local ok,inside=pcall(f.IsMouseOver,f)
  if ok then return inside==true end
 end
 -- Frame-focus fallback for Midnight 11.0+, when a child has focus.
 if type(GetMouseFoci)=="function" then
  local ok,regions=pcall(GetMouseFoci)
  if ok and type(regions)=="table" then
   for _,region in ipairs(regions) do
    local node=region
    for _=1,16 do
     if node==f then return true end
     if not node or type(node.GetParent)~="function" then break end
     local parentOK,parent=pcall(node.GetParent,node)
     if not parentOK or parent==node then break end
     node=parent
    end
   end
  end
 end
 return false
end
function C:Choose(anchor,values,labels,current,fn,icons)
 self:CloseChoices()
 if not self.choices then
  self.choices=CreateFrame("Frame","CursorCompanionChoices",UIParent,"BackdropTemplate")
  self.choices:SetFrameStrata("TOOLTIP");self.choices:EnableMouse(true);self.choices:SetClampedToScreen(true)
  self:Backdrop(self.choices);self.choiceButtons={};tinsert(UISpecialFrames,"CursorCompanionChoices")
  self.choiceScroll=CC.Skin:Scroll(self.choices)
  self.choiceScroll:SetPoint("TOPLEFT",4,-4);self.choiceScroll:SetPoint("BOTTOMRIGHT",-18,4)
  self.choiceContent=CreateFrame("Frame",nil,self.choiceScroll);self.choiceScroll:SetScrollChild(self.choiceContent)
  self.choices:SetScript("OnHide",function(frame)
   if frame.UnregisterEvent then frame:UnregisterEvent("GLOBAL_MOUSE_DOWN") end
  end)
  self.choices:SetScript("OnEvent",function(_,event)
   if event=="GLOBAL_MOUSE_DOWN" and not C:IsChoiceMouseInside() then C:CloseChoices() end
  end)
 end
 local f=self.choices;f:ClearAllPoints();f:SetPoint("TOPLEFT",anchor,"BOTTOMLEFT",0,-2)
 local width=math.min(360,math.max(230,anchor:GetWidth()+22),math.max(100,UIParent:GetWidth()-24))
 local inner=width-22;local y=0
 for _,button in ipairs(self.choiceButtons) do button:Hide() end
 for i,v in ipairs(values) do
  local button=self.choiceButtons[i]
  if not button then button=self:Button(self.choiceContent,"",0,0,inner,function() end);self.choiceButtons[i]=button end
  if icons and icons[v] then
   if not button.ccChoiceIcon then button.ccChoiceIcon=button:CreateTexture(nil,"OVERLAY");button.ccChoiceIcon:SetSize(20,20);button.ccChoiceIcon:SetPoint("LEFT",6,0) end
   button.ccChoiceIcon:SetTexture(icons[v]);button.ccChoiceIcon:Show()
  elseif button.ccChoiceIcon then button.ccChoiceIcon:Hide() end
  button:SetWidth(inner);local fs=button:GetFontString()
  if fs then fs:ClearAllPoints();fs:SetPoint("LEFT",icons and icons[v] and 32 or 6,0);fs:SetPoint("RIGHT",-6,0);fs:SetJustifyH(icons and icons[v] and "LEFT" or "CENTER") end
  button:SetText((v==current and "* " or "")..tostring((labels and labels[v]) or v))
  button:ClearAllPoints();button:SetPoint("TOPLEFT",0,-y)
  button:SetScript("OnClick",function() C:CloseChoices();fn(v) end);button:Show()
  y=y+button:GetHeight()+2
 end
 local height=math.min(math.max(35,y+8),math.max(80,UIParent:GetHeight()-32))
 f:SetSize(width,height);self.choiceContent:SetSize(inner,math.max(1,y))
 self.choiceScroll:SetWidth(inner);self.choiceScroll:SetHeight(height-8)
 self.choiceScroll:SetVerticalScroll(0)
 f:Show()
 if self.choiceScroll.UpdateScrollChildRect then self.choiceScroll:UpdateScrollChildRect() end
 pcall(f.RegisterEvent,f,"GLOBAL_MOUSE_DOWN")
end
function C:Create(parent,d,owner)
 owner=owner or CC.Settings
 local row=CreateFrame("Frame",nil,parent);row:SetSize(410,44);row.desc=d
 row.label=self:Text(row,d.label,0,-6,"GameFontNormalSmall");row.label:SetWidth(177)
 local function change(v)
  if row.refreshing or CC.Safety:InCombat() or not owner.draft then return end
  self:Set(owner.draft,d.path,v)
  if d.path=="outside.mode" then
   -- A single explicit choice replaces two potentially confusing checkboxes.
  elseif d.path=="compass.enabled" and v==true then
   owner.draft.rings.outer2.enabled=false
  elseif d.path=="rings.outer2.enabled" and v==true then
   owner.draft.compass.enabled=false
  end
  -- The compass can never silently disable normal Outer/Inner ring roles.
  if owner.draft.compass.enabled then
   local co=owner.draft.compass
   local largest,widest=0,co.stroke
   for _,key in ipairs({"inner","outer"}) do
    local other=owner.draft.rings[key]
    if other.enabled then largest=math.max(largest,other.size);widest=math.max(widest,other.stroke) end
   end
   co.size=math.min(176,math.max(co.size,largest+math.max(14,2*(3+widest)+2)))
  end
  owner:Preview();owner:Notice("Changes not saved yet.")
 end
 if d.kind=="bool" then
  row.control=CreateFrame("CheckButton",nil,row,"BackdropTemplate");row.control:SetPoint("TOPLEFT",183,0);CC.Skin:Check(row.control)
  row.control:SetScript("OnClick",function(b)
   change(b:GetChecked()==true)
   if (d.path=="outside.mode" or d.path=="questNotes.enabled" or d.path=="compass.enabled" or d.path=="rings.outer2.enabled" or d.path=="palette.experimental" or d.path=="utility.enabled" or d.path=="fishing.enabled"
       or d.path=="rings.inner.enabled" or d.path=="rings.outer.enabled"
       or (d.kind=="bool" and d.path:match("^alerts%.")~=nil))
       and owner.Render then owner:Render(true) end
  end)
 elseif d.kind=="number" then
  local slider=CreateFrame("Slider",nil,row);row.control=slider
  slider:SetPoint("TOPLEFT",183,-5);slider:SetSize(140,16);CC.Skin:Slider(slider);slider:SetMinMaxValues(d.min,d.max);slider:SetValueStep(d.step or 1)
  if slider.SetObeyStepOnDrag then slider:SetObeyStepOnDrag(true) end
  if slider.Low then slider.Low:SetText("") end;if slider.High then slider.High:SetText("") end;if slider.Text then slider.Text:SetText("") end
  local e=CreateFrame("EditBox",nil,row,"BackdropTemplate");row.entry=e;CC.Skin:Input(e);e:SetSize(64,22);e:SetPoint("TOPLEFT",337,0);e:SetAutoFocus(false);e:SetMaxLetters(12)
  slider:SetScript("OnValueChanged",function(_,v)
   if row.refreshing then return end
   local step=d.step or 1;v=math.floor(v/step+0.5)*step;e:SetText(string.format("%.3g",v));change(v)
  end)
  e:SetScript("OnEnterPressed",function(box)
   local v=tonumber(box:GetText())
   if not CC.Safety:IsNumber(v) or v<d.min or v>d.max then owner:Notice("Enter a number from "..d.min.." to "..d.max..".");return end
   change(v);row.refreshing=true;slider:SetValue(v);row.refreshing=false;box:ClearFocus()
  end)
  e:SetScript("OnEscapePressed",function(b) b:ClearFocus();row:Refresh() end)
 elseif d.kind=="spell" then
  -- A deliberate commit on Enter avoids persisting partial spell IDs.
  local e=CreateFrame("EditBox",nil,row,"BackdropTemplate");row.control=e;row.entry=e
  CC.Skin:Input(e);e:SetSize(218,22);e:SetPoint("TOPLEFT",183,0)
  e:SetAutoFocus(false);e:SetMaxLetters(8)
  e:SetScript("OnEnterPressed",function(box)
   local raw=box:GetText() or ""
   local v=tonumber(raw)
   if not v or v<0 or v>99999999 or v%1~=0 or not CC.Safety:IsNumber(v) then
    owner:Notice("Enter a numeric spell ID (0 to clear).");return
   end
   change(v);box:ClearFocus();row:Refresh()
  end)
  e:SetScript("OnEscapePressed",function(box) box:ClearFocus();row:Refresh() end)
 elseif d.kind=="choice" then
  local isRangeRole=d.path=="rings.inner.role" or d.path=="rings.outer.role" or d.path=="rings.outer2.role"
  row.control=self:Button(row,"",183,0,isRangeRole and 180 or 218,function(button)
   local choices=d.values
   self:Choose(button,choices,d.labels,self:Get(owner.draft,d.path),function(v) change(v);row:Refresh();if owner.Render then owner:Render(true) end end)
  end)
  if isRangeRole then
   row.rangeShortcut=self:Button(row,"",369,0,32,function()
    if owner.OpenSpellRange then owner:OpenSpellRange() end
   end)
   local gear=row.rangeShortcut:CreateTexture(nil,"ARTWORK")
   gear:SetTexture("Interface\\AddOns\\CursorCompanion\\Media\\ActionSettings.tga")
   gear:SetPoint("CENTER",row.rangeShortcut,"CENTER",0,0);gear:SetSize(18,18)
   self:Tip(row.rangeShortcut,"Open Spell range to select the ability checked by this ring.")
  end
 elseif d.kind=="color" then
  if d.eventColor or d.signalColor then
   row.swatchBorder=CreateFrame("Frame",nil,row,"BackdropTemplate")
   row.swatchBorder:SetSize(29,25);row.swatchBorder:SetPoint("TOPLEFT",181,1)
   CC.Skin:Panel(row.swatchBorder,true)
   row.swatch=row.swatchBorder:CreateTexture(nil,"ARTWORK")
   row.swatch:SetPoint("TOPLEFT",row.swatchBorder,"TOPLEFT",3,-3)
   row.swatch:SetPoint("BOTTOMRIGHT",row.swatchBorder,"BOTTOMRIGHT",-3,3)
   row.swatch:SetTexture("Interface\\Buttons\\WHITE8X8")
  end
  row.control=self:Button(row,"Choose color",(d.eventColor or d.signalColor) and 215 or 183,0,(d.eventColor or d.signalColor) and 186 or 218,function()
   local r=self:Get(owner.draft,d.path)
   CC.ColorPicker:Open(r.r,r.g,r.b,function(a,b,c)
    if owner.draft then
     local t=self:Get(owner.draft,d.path);t.r,t.g,t.b=a,b,c
     local kind=d.path:match("^beacon%.colors%.([%a]+)$");if kind then owner.beaconPreviewType=kind end
     row:Refresh();owner:Preview()
     if d.eventColor and CC.Preview then CC.Preview:TryAlert(d.eventCondition) end
     owner:Notice("Changes not saved yet.")
    end
   end)
  end)
 else
  local e=CreateFrame("EditBox",nil,row,"BackdropTemplate");row.control=e;CC.Skin:Input(e);e:SetSize(218,22);e:SetPoint("TOPLEFT",183,0);e:SetAutoFocus(false);e:SetMaxLetters(200)
  e:SetScript("OnTextChanged",function(b,user) if user then change(b:GetText()) end end)
  e:SetScript("OnEnterPressed",function(b) change(b:GetText());b:ClearFocus() end)
  e:SetScript("OnEscapePressed",function(b) b:ClearFocus() end)
 end
 self:Tip(row.control,d.help)
 if row.entry and owner.FocusNext then row.entry:SetScript("OnTabPressed",function(b) owner:FocusNext(b) end) end
 function row:Refresh()
  if not owner.draft then return end
  self.refreshing=true;local v=C:Get(owner.draft,d.path)
  if d.kind=="bool" then self.control:SetChecked(v)
  elseif d.kind=="number" then self.control:SetValue(v);self.entry:SetText(string.format("%.3g",v))
  elseif d.kind=="color" then
   self.control:SetText("Choose color")
   if self.swatch and v then self.swatch:SetVertexColor(v.r,v.g,v.b,1) end
  else self.control:SetText((d.labels and d.labels[v]) or tostring(v or "")) end
  if self.rangeShortcut then
   self.rangeShortcut:SetShown(v=="Spell range")
  end
  local locked=d.compassLock and owner.draft.compass and owner.draft.compass.enabled==true
  if self.control.SetEnabled then self.control:SetEnabled(not locked) end
  if self.entry and self.entry.SetEnabled then self.entry:SetEnabled(not locked) end
  if self.label.SetTextColor then self.label:SetTextColor(locked and 0.48 or 0.90,locked and 0.48 or 0.89,locked and 0.48 or 0.87) end
  local labelHeight=CC.TextLayout:Text(self.label,177,18)
  local controlHeight=self.control:GetHeight()
  self:SetHeight(math.max(44,labelHeight+16,controlHeight+12,self.entry and self.entry:GetHeight()+12 or 0))
  self.refreshing=false
 end
 return row
end
