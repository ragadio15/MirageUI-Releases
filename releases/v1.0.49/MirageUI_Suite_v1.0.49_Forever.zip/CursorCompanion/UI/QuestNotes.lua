local _,CC=...
-- Read-only objective panel. Only special quest items get a Blizzard secure
-- item button, configured out of combat and activated by a direct user click.
CC.QuestNotes={shown=false,rows={},showAll=false,dirty=false,refreshDelay=0,lastDataStatus="NOT_OPENED",lastEntryCount=0}
local N=CC.QuestNotes
local media="Interface\\AddOns\\CursorCompanion\\Media\\"
function N:Icon(parent,art,x,tip,fn)
 local b=CreateFrame("Button",nil,parent,"BackdropTemplate")
 b:SetSize(28,28);b:SetPoint("TOPRIGHT",parent,"TOPRIGHT",-x,-13);CC.Skin:Button(b,true);b:SetText("")
 local icon=b:CreateTexture(nil,"ARTWORK")
 icon:SetPoint("CENTER",b,"CENTER");icon:SetSize(20,20)
 icon:SetTexture(media..art..".tga");icon:SetVertexColor(.96,.79,.36,.96)
 if type(icon.SetSnapToPixelGrid)=="function" then pcall(icon.SetSnapToPixelGrid,icon,true) end
 CC.Controls:Tip(b,tip);b:SetScript("OnClick",fn)
 return b
end
function N:CreateRow(i)
 if self.rows[i] then return self.rows[i] end
 local C=CC.Controls
 local row=CreateFrame("Frame",nil,self.content,"BackdropTemplate")
 CC.Skin:Panel(row,true);row:SetBackdropColor(.068,.063,.071,.83)
 -- A consistent metadata band precedes the quest title at every window width.
 -- GameFontNormal is bold and the orange is the official primary accent.
 local name=C:Text(row,"",11,-39,"GameFontNormal")
 name:SetWidth(320);name:SetTextColor(.91,.55,.18)
 local distance=CreateFrame("Frame",nil,row,"BackdropTemplate")
 distance:SetSize(91,24);distance:SetPoint("TOPLEFT",row,"TOPLEFT",10,-6)
 CC.Skin:Panel(distance,true);distance:SetBackdropColor(.035,.04,.045,.95)
 local distanceText=C:Text(distance,"",7,-5,"GameFontHighlightSmall")
 distanceText:SetTextColor(.96,.79,.36)
 -- Quest Notes closes on combat entry. A protected SecureActionButtonTemplate
 -- would also protect its ancestor row/panel and make that Hide() illegal in
 -- combat. The insecure action template still performs a direct user-initiated
 -- quest-item click out of combat but does not protect the Notes panel.
 local item=CreateFrame("Button",nil,row,"InsecureActionButtonTemplate,BackdropTemplate")
 item:SetSize(27,27);item:SetPoint("TOPLEFT",row,"TOPLEFT",111,-4)
 if type(item.RegisterForClicks)=="function" then item:RegisterForClicks("LeftButtonUp") end
 CC.Skin:Panel(item,true);item:SetBackdropColor(.06,.07,.08,.95)
 local itemIcon=item:CreateTexture(nil,"ARTWORK")
 itemIcon:SetAllPoints(item);itemIcon:SetTexture(media.."ActionQuestlog.tga")
 itemIcon:SetVertexColor(1,1,1,.9)
 item:SetScript("OnEnter",function(button)
  if self.shown and button.ccItemLink and GameTooltip and type(GameTooltip.SetHyperlink)=="function" then
   GameTooltip:SetOwner(button,"ANCHOR_RIGHT");GameTooltip:SetHyperlink(button.ccItemLink);GameTooltip:Show()
  end
 end)
 item:SetScript("OnLeave",function() if GameTooltip then GameTooltip:Hide() end end)
 -- The action template owns the click. No automatic quest-item use is issued.
 local pin=CreateFrame("Button",nil,row,"BackdropTemplate")
 pin:SetSize(25,25);pin:SetPoint("TOPRIGHT",row,"TOPRIGHT",-8,-5);CC.Skin:Button(pin,true);pin:SetText("")
 local pinArt=pin:CreateTexture(nil,"ARTWORK");pinArt:SetAllPoints(pin)
 pinArt:SetTexture(media.."ActionFocus.tga")
 CC.Controls:Tip(pin,"Pin this quest for the compass. Click again to return to automatic guidance. A pin does not change Blizzard tracking.")
 pin:SetScript("OnClick",function()
  if CC.Safety:InCombat() or not pin.questID then return end
  local nav=CC.QuestNavigation
  local id=nav:PinnedID()==pin.questID and 0 or pin.questID
  local ok,why=nav:SetPin(id)
  if ok then CC.QuestCompass:Invalidate("PIN_CHANGED");self:Refresh() else CC:Print(why) end
 end)
 local detail=C:Text(row,"",12,-66,"GameFontHighlightSmall");detail:SetWidth(320)
 local o={frame=row,name=name,distance=distanceText,distanceFrame=distance,itemButton=item,itemIcon=itemIcon,detail=detail,pinButton=pin,pinArt=pinArt,objectives={}}
 self.rows[i]=o;return o
end
function N:Create()
 local C=CC.Controls
 if self.frame then return end
 local f=CreateFrame("Frame","CursorCompanionQuestNotes",UIParent,"BackdropTemplate")
 self.frame=f;f:SetSize(382,296);f:SetFrameStrata("DIALOG");f:SetClampedToScreen(true);f:EnableMouse(true)
 CC.Skin:Panel(f,true);f:SetBackdropColor(.052,.047,.054,.96);f:SetBackdropBorderColor(.027,.024,.030,.98)
 self.title=C:Text(f,"QUEST NOTES",18,-20,"GameFontNormal");self.title:SetTextColor(.91,.55,.18)
 self.refresh=self:Icon(f,"NoteRefresh",115,"Refresh quest data and recheck a waiting turn-in location",function() CC.QuestNavigation:Refresh();self:Refresh() end)
 self.questLog=self:Icon(f,"NoteQuestLog",81,"Open Blizzard's Quest Log",function()
  if CC.Safety:InCombat() then return end
  if type(ToggleQuestLog)=="function" then pcall(ToggleQuestLog)
  elseif type(ToggleWorldMap)=="function" then pcall(ToggleWorldMap) end
  self:Close()
 end)
 self.all=self:Icon(f,"NoteList",47,"Show all readable quests / nearest quests",function()
  self.showAll=not self.showAll;self:Refresh();self.scroll:SetVerticalScroll(0)
 end)
 self.route=self:Icon(f,"ActionQuestlog",149,"Review experimental route suggestions",function()
  self:Close();CC.QuestRoutePanel:Open()
 end);self.route:Hide()
 self.close=CC.Skin:Close(f,function() self:Close() end)
 self.scroll=CC.Skin:Scroll(f)
 self.scroll:SetPoint("TOPLEFT",16,-57);self.scroll:SetPoint("BOTTOMRIGHT",f,"BOTTOMRIGHT",-32,16)
 self.content=CreateFrame("Frame",nil,self.scroll)
 self.content:SetSize(334,216);self.scroll:SetScrollChild(self.content)
 self.empty=C:Text(self.content,"",12,-15,"GameFontHighlightSmall");self.empty:SetWidth(310)
 f:SetScript("OnHide",function()
  self.shown=false;self.dirty=false;self.refreshDelay=0
  if f.UnregisterEvent then f:UnregisterEvent("GLOBAL_MOUSE_DOWN") end
 end)
 f:SetScript("OnEvent",function(_,event)
  if event=="GLOBAL_MOUSE_DOWN" and f.IsMouseOver then
   local ok,inside=pcall(f.IsMouseOver,f)
   if ok and inside==false then N:Close() end
  end
 end)
 -- Quest log events mark this view dirty; rebuild once after a short delay.
 -- No unbounded per-frame quest/map queries and no auto-reset of the reader's scroll.
 f:SetScript("OnUpdate",function(_,dt)
  if not N.shown then return end
  local elapsed=CC.Safety:IsNumber(dt) and math.min(dt,.25) or 0
  N.visibleElapsed=(N.visibleElapsed or 0)+elapsed
  if not N.dirty and N.visibleElapsed>=1 then N.dirty=true;N.refreshDelay=0 end
  if not N.dirty then return end
  N.refreshDelay=math.max(0,(N.refreshDelay or 0)-(CC.Safety:IsNumber(dt) and math.min(dt,.25) or 0))
  if N.refreshDelay==0 then N.dirty=false;N.visibleElapsed=0;N:Refresh() end
 end)
 tinsert(UISpecialFrames,"CursorCompanionQuestNotes")
 f:Hide()
end
function N:Close()
 self.shown=false;self.dirty=false;self.refreshDelay=0
 if self.frame then self.frame:Hide() end
end
function N:Invalidate()
 if self.shown and not self.dirty and not CC.Safety:InCombat() then
  self.dirty=true;self.refreshDelay=.25
 end
end
-- UI is intentionally compact like the radial quick menu. The scroll child
-- grows to fit complete objectives; viewport dimensions stay user-configured.
function N:WindowSize()
 local pref=CC.profile and CC.profile.questNotes or CC.Defaults.questNotes
 local w=math.max(320,math.min(620,tonumber(pref.width) or 382))
 local h=math.max(220,math.min(560,tonumber(pref.height) or 296))
 if UIParent then
  w=math.min(w,math.max(200,UIParent:GetWidth()-16))
  h=math.min(h,math.max(170,UIParent:GetHeight()-16))
 end
 return w,h
end
function N:Refresh()
 if not self.frame or not self.shown then return end
 if CC.Safety:InCombat() or not (CC.profile.compass.enabled and CC.profile.questNotes.enabled) then self:Close();return end
 local ok,entries,status=pcall(CC.QuestNotesData.Nearby,CC.QuestNotesData,CC.profile.questNotes.limit,self.showAll)
 if not ok or type(entries)~="table" then
  entries={};status="QUEST_API_UNAVAILABLE"
  if not self.apiErrorReported then
   self.apiErrorReported=true;CC.Diagnostics:OptionalFault("QUEST_NOTES_DATA_UNAVAILABLE")
  end
 end
 self.lastDataStatus=status or "NO_READABLE_OBJECTIVES";self.lastEntryCount=#entries
 local width,height=self:WindowSize()
 self.frame:SetSize(width,height)
 local contentWidth=math.max(120,width-48)
 local rowWidth=contentWidth-2
 local y=0
 local routeEnabled=CC.QuestRoute:Enabled()
 self.route:SetShown(routeEnabled)
 local titleHeight=CC.TextLayout:Text(self.title,math.max(80,width-(routeEnabled and 65 or 178)),18)
 local toolbarY=routeEnabled and math.max(45,titleHeight+28) or 13
 for _,entry in ipairs({{self.route,149},{self.refresh,115},{self.questLog,81},{self.all,47}}) do
  entry[1]:ClearAllPoints();entry[1]:SetPoint("TOPRIGHT",self.frame,"TOPRIGHT",-entry[2],-toolbarY)
 end
 local headerHeight=routeEnabled and toolbarY+40 or math.max(57,titleHeight+35)
 self.scroll:SetPoint("TOPLEFT",16,-headerHeight)
 self.empty:SetWidth(contentWidth-22)
 self.empty:SetShown(#entries==0)
 if #entries==0 then
  self.empty:SetText(status=="NO_POSITION" and "Your map position is unavailable. Try another location."
   or status=="QUEST_API_UNAVAILABLE" and "Quest information is temporarily unavailable. Try Refresh outside combat."
   or "No readable quest locations. Track a quest or open the map and refresh.")
 end
 if #entries==0 then y=CC.TextLayout:Text(self.empty,contentWidth-22,20)+30 end
 for i,entry in ipairs(entries) do
  local row=self:CreateRow(i)
  local objectives=entry.objectives or {}
  if #objectives==0 and entry.objective then objectives={{text=entry.objective,complete=false}} end
  row.name:SetText(entry.name)
  local nameHeight=CC.TextLayout:Text(row.name,math.max(70,rowWidth-23),19)
  row.pinButton.questID=entry.questID
  row.pinButton:SetShown(CC.Safety:IsNumber(entry.questID) and entry.questID>0)
  row.pinArt:SetVertexColor(entry.pinned and .91 or .58,entry.pinned and .55 or .62,entry.pinned and .18 or .65,1)
  if entry.guiding then row.frame:SetBackdropBorderColor(.91,.55,.18,.85)
  else row.frame:SetBackdropBorderColor(.22,.23,.25,.8) end
  row.distance:SetText(CC.Safety:IsNumber(entry.approxDistance) and (not entry.locationState or entry.locationState=="LOCATED") and ("~"..math.floor(entry.approxDistance+0.5).." yd") or "No location")
  local distanceWidth=math.max(91,CC.TextLayout:Width(row.distance)+16)
  row.distanceFrame:SetWidth(math.min(math.max(40,rowWidth-90),distanceWidth))
  CC.TextLayout:FixedText(row.distance,row.distanceFrame:GetWidth()-14,16)
  row.itemButton:ClearAllPoints();row.itemButton:SetPoint("TOPLEFT",row.frame,"TOPLEFT",20+row.distanceFrame:GetWidth(),-4)
  row.distanceFrame:Show()
  local objectiveY=42+nameHeight
  for j=1,#objectives do
   local field=row.objectives[j]
   if not field then
    -- Blizzard's GameFontHighlightSmall does not consistently contain the
    -- Unicode checkmark used by F1. Use a real texture rather than a font glyph.
    local label=CC.Controls:Text(row.frame,"",31,-objectiveY,"GameFontHighlightSmall")
    local mark=row.frame:CreateTexture(nil,"OVERLAY")
    field={label=label,mark=mark}
    row.objectives[j]=field
   end
   local objective=objectives[j]
   local label,mark=field.label,field.mark
   label:ClearAllPoints();label:SetPoint("TOPLEFT",row.frame,"TOPLEFT",31,-objectiveY)
   label:SetText(objective.text)
   label:SetTextColor(objective.complete and .64 or .84,objective.complete and .80 or .82,objective.complete and .65 or .80)
   local lineHeight=CC.TextLayout:Text(label,math.max(60,rowWidth-45),19)
   label:Show()
   mark:ClearAllPoints()
   mark:SetPoint("TOPLEFT",row.frame,"TOPLEFT",13,-objectiveY-4)
   if objective.complete then
    mark:SetTexture(media.."Checkmark.tga");mark:SetSize(13,13)
    mark:SetVertexColor(.46,.82,.44,1)
   else
    mark:SetTexture("Interface\\Buttons\\WHITE8X8");mark:SetSize(9,2)
    mark:SetVertexColor(.65,.66,.66,1)
   end
   mark:Show()
   objectiveY=objectiveY+lineHeight
  end
  for j=#objectives+1,#row.objectives do
   local field=row.objectives[j];field.label:Hide();field.mark:Hide()
  end
  local state={}
  if entry.pinned then state[#state+1]="Pinned" elseif entry.guiding then state[#state+1]="Guiding" end
  if entry.stage=="READY_FOR_TURN_IN" then state[#state+1]="Ready for turn-in"
  elseif entry.stage=="FAILED" then state[#state+1]="Quest failed" end
  if entry.locationState and entry.locationState~="LOCATED" then
   state[#state+1]=entry.locationState=="AWAITING_TURN_IN_LOCATION" and "Waiting for updated turn-in location" or "Guidance unavailable"
  elseif entry.guiding then
   state[#state+1]=entry.confidence=="BLIZZARD_WAYPOINT" and "Blizzard waypoint" or "Approximate map area"
  end
  if entry.routeIndex then
   state[#state+1]="Suggested stop "..entry.routeIndex
   if entry.clusterSize and entry.clusterSize>1 then state[#state+1]=entry.clusterSize.." quests in this area" end
  elseif entry.routeDeferred then state[#state+1]="Deferred from experimental route" end
  if #state>0 then
   row.detail:ClearAllPoints();row.detail:SetPoint("TOPLEFT",row.frame,"TOPLEFT",12,-objectiveY-4)
   row.detail:SetText(table.concat(state," / "));row.detail:SetTextColor(.96,.79,.36)
   objectiveY=objectiveY+CC.TextLayout:Text(row.detail,math.max(60,rowWidth-24),16)+7;row.detail:Show()
  else row.detail:SetText("");row.detail:Hide() end
  local item=row.itemButton
  local special=entry.specialItem
  if special and type(item.SetAttribute)=="function" then
   item:SetAttribute("type","item");item:SetAttribute("item",special.link)
   item.ccItemLink=special.link;row.itemIcon:SetTexture(special.icon);item:Show()
  else
   if type(item.SetAttribute)=="function" then item:SetAttribute("type",nil);item:SetAttribute("item",nil) end
   item.ccItemLink=nil;item:Hide()
  end
  local rowHeight=math.max(79,objectiveY+9)
  row.frame:SetSize(rowWidth,rowHeight)
  row.frame:ClearAllPoints();row.frame:SetPoint("TOPLEFT",self.content,"TOPLEFT",0,-y)
  row.frame:Show();y=y+rowHeight+7
 end
 for i=#entries+1,#self.rows do
  local row=self.rows[i];row.frame:Hide()
  if not CC.Safety:InCombat() and type(row.itemButton.SetAttribute)=="function" then
   row.itemButton:SetAttribute("type",nil);row.itemButton:SetAttribute("item",nil)
  end
 end
 self.content:SetSize(contentWidth,math.max(height-headerHeight-20,y+10))
end
function N:Open()
 if CC.profile.compass.mode=="Beacon" then
  CC:Print("Beacon mode is active. Use the Navigation shortcut to transmit; select Quest Compass and Apply to open Quest Notes.")
  return false
 end
 if CC.Safety:InCombat() then CC:Print("Quest Notes is available outside combat.");return false end
 if not CC.profile.enabled or not CC.profile.compass.enabled or not CC.profile.questNotes.enabled then
  CC:Print("Enable Quest Compass and Quest Notes in Outside cursor settings first.");return false
 end
 if GetCurrentKeyBoardFocus and GetCurrentKeyBoardFocus() then return false end
 self:Create();CC.Palette:Close()
 local x,y=CC.CursorPosition:Sample();if not x then return false end
 local width,height=self:WindowSize()
 local w,h=UIParent:GetWidth(),UIParent:GetHeight()
 self.frame:SetSize(width,height)
 local p=CC.profile.palette;local ring=CC.profile.compass.size/2+14
 local right=x+ring+width/2+math.max(0,p.offsetX)
 local left=x-ring-width/2-math.max(0,-p.offsetX)
 local center=right+width/2<w-6 and right or left
 center=math.max(width/2+8,math.min(w-width/2-8,center))
 local cy=math.max(height/2+8,math.min(h-height/2-8,y+p.offsetY))
 self.frame:ClearAllPoints();self.frame:SetPoint("CENTER",UIParent,"BOTTOMLEFT",center,cy)
 self.showAll=false;self.shown=true;self.dirty=false;self.refreshDelay=0;self.frame:Show()
 if self.frame.RegisterEvent then pcall(self.frame.RegisterEvent,self.frame,"GLOBAL_MOUSE_DOWN") end
 self:Refresh();self.scroll:SetVerticalScroll(0);return true
end
function N:Toggle()
 if self.shown then self:Close();return true end
 return self:Open()
end
BINDING_NAME_CURSORCOMPANION_QUESTNOTES="Navigation: Quest Notes / transmit Beacon"
