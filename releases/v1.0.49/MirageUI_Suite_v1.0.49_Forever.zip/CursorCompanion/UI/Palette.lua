local _,CC=...
CC.Palette={shown=false,pages={},art={},dirty=true,compiledKeys={}}
local P=CC.Palette
local media="Interface\\AddOns\\CursorCompanion\\Media\\"
local marks={"Star","Circle","Diamond","Triangle","Moon","Square","Cross","Skull","Clear"}
local pings={{"pingassist","Assist"},{"pingattack","Attack"},{"pingwarning","Warning"},{"pingonmyway","On my way"}}
P.primary={.91,.55,.18};P.secondary={.96,.79,.36}
P.menuStyles={
 Tracker={prefix="Radial",center="RadialCenter",outline="RadialOutline",base={.052,.052,.054,.94},hover={.102,.100,.102,.97},centerTint={.039,.039,.041,.97},trim={.030,.030,.032,.96},trimHover={.071,.070,.072,.98}},
 Aperture={prefix="RadialAperture",center="RadialApertureCenter",outline="RadialApertureOutline",base={.050,.047,.045,.95},hover={.105,.096,.088,.98},centerTint={.038,.036,.035,.98},trim={.105,.061,.030,.88},trimHover={.18,.095,.038,.98}},
 Halo={prefix="RadialHalo",center="RadialHaloCenter",outline="RadialHaloOutline",base={.048,.049,.052,.88},hover={.096,.096,.100,.94},centerTint={.038,.039,.042,.94},trim={.090,.071,.047,.82},trimHover={.18,.11,.045,.96}},
 Facet={prefix="RadialFacet",center="RadialFacetCenter",outline="RadialFacetOutline",base={.055,.051,.049,.94},hover={.108,.098,.091,.98},centerTint={.040,.037,.036,.98},trim={.092,.055,.031,.90},trimHover={.18,.092,.035,.98}},
}
P.trackerSkin=P.menuStyles.Tracker
local function safeCall(fn,...)
 local ok,result=pcall(fn,...)
 if not ok and CC.Diagnostics then CC.Diagnostics:OptionalFault("PALETTE_PRESENTATION_FAULT") end
 return ok,result
end
-- Blizzard executes these snippets in its restricted environment. Every action
-- is prepared out of combat; addon Lua never chooses protected actions in combat.
-- The binding's physical release can target a hostile mouseover before opening.
-- No insecure TargetUnit calls, no /startattack, no synthetic clicks.
P.secureOpenBefore=[[
 if down then return false end
 self:SetAttribute("type",nil);self:SetAttribute("macrotext",nil)
 local menu=self:GetFrameRef("menu")
 if menu:IsShown() then menu:ClearBindings();menu:Hide();return false end
 if not menu:GetAttribute("cc-enabled") then self:CallMethod("Unavailable");return false end
 if menu:GetAttribute("cc-auto-target") then
  self:SetAttribute("type","macro")
  self:SetAttribute("macrotext","/target [@mouseover,harm,nodead]")
 end
 return nil,true
]]
P.secureToggle=[[
 if down then return end
 local menu=self:GetFrameRef("menu")
 if menu:IsShown() then menu:ClearBindings();menu:Hide();return end
 if not menu:GetAttribute("cc-enabled") then self:CallMethod("Unavailable");return end
 local page="main"
 if menu:GetAttribute("state-combat")~="combat" then
  menu:SetAttribute("cc-opening-page","main")
  menu:CallMethod("PrepareOpening")
  page=menu:GetAttribute("cc-opening-page") or "main"
 end
 menu:SetAttribute("cc-page",page)
 menu:ClearAllPoints()
 local screen=menu:GetFrameRef("screen")
 local px,py=screen:GetMousePosition()
 if px and py then
  local w,h=screen:GetWidth(),screen:GetHeight()
  local x,y=px*w,py*h
  local r=menu:GetWidth()/2
  local offset=menu:GetAttribute("cc-offset-x") or 0
  local distance=math.abs(offset)
  local right,left=x+distance,x-distance
  local rightFits,leftFits=right+r<=w-8,left-r>=8
  local useRight=offset>=0
  if rightFits~=leftFits then useRight=rightFits elseif not rightFits then useRight=w-x>=x end
  local cx=useRight and right or left
  local cy=y+(menu:GetAttribute("cc-offset-y") or 0)
  cx=math.max(r+8,math.min(w-r-8,cx));cy=math.max(r+8,math.min(h-r-8,cy))
  menu:SetPoint("CENTER",screen,"BOTTOMLEFT",cx,cy)
 else menu:SetPoint("CENTER","$cursor","CENTER",menu:GetAttribute("cc-offset-x") or 0,menu:GetAttribute("cc-offset-y") or 0) end
 menu:SetBindingClick(true,"ESCAPE",menu:GetName(),"CCClose")
 menu:Show();menu:CallMethod("Paint",page)
]]
P.secureOpenAfter=[[
 self:SetAttribute("type",nil);self:SetAttribute("macrotext",nil)
]]..P.secureToggle
P.secureBeforeClick=[[
 if down then return false end
 self:SetAttribute("cc-selected-page",nil);self:SetAttribute("cc-selected-index",nil)
 self:SetAttribute("type",nil);self:SetAttribute("unit",nil)
 self:SetAttribute("spell",nil);self:SetAttribute("item",nil)
 self:SetAttribute("macro",nil);self:SetAttribute("macrotext",nil)
 self:SetAttribute("marker",nil);self:SetAttribute("action",nil)
 if button=="CCClose" then self:ClearBindings();self:Hide();return false end
 local token=button=="MiddleButton" and "BUTTON3" or button:match("^Button(%d+)$")
 if token then
  if token~="BUTTON3" then token="BUTTON"..token end
  local prefix=""
  if IsAltKeyDown() then prefix=prefix.."ALT-" end
  if IsControlKeyDown() then prefix=prefix.."CTRL-" end
  if IsShiftKeyDown() then prefix=prefix.."SHIFT-" end
  if IsMetaKeyDown and IsMetaKeyDown() then prefix=prefix.."META-" end
  if self:GetAttribute("cc-close-key-"..prefix..token) then self:ClearBindings();self:Hide();return false end
 end
 if button=="RightButton" then
  if self:GetAttribute("cc-close-click") then self:ClearBindings();self:Hide() end
  return false
 end
 if button~="LeftButton" or not self:IsShown() then return false end
 local page=self:GetAttribute("cc-page") or "main"
 local count=self:GetAttribute("cc-count-"..page) or 0
 local x,y=self:GetMousePosition()
 if not x or not y then return false end
 local dx,dy=x-.5,y-.5
 local distance=dx*dx+dy*dy
 if distance>.25 then return false end
 if distance<.02325625 then
  local previous=self:GetAttribute("cc-back-"..page) or "main"
  if page~="main" then self:SetAttribute("cc-page",previous);self:CallMethod("Paint",previous)
  elseif self:GetAttribute("cc-close-click") then self:ClearBindings();self:Hide() end
  return false
 end
 if count<1 then return false end
 local angle
 if dy>0 then angle=math.atan(dx/dy)
 elseif dy<0 then angle=math.atan(dx/dy)+(dx>=0 and math.pi or -math.pi)
 elseif dx>0 then angle=math.pi/2 else angle=-math.pi/2 end
 local index=math.floor(((angle+math.pi/count)%(2*math.pi))/(2*math.pi/count))+1
 local prefix="cc-"..page.."-"..index.."-"
 local destination=self:GetAttribute(prefix.."page")
 if self:GetAttribute(prefix.."nocombat") and self:GetAttribute("state-combat")=="combat" then self:CallMethod("Blocked",page,index,"combat");return false end
 if self:GetAttribute(prefix.."subject") then
  self:SetAttribute(prefix.."enabled",false)
  self:CallMethod("ValidateSubject",page,index)
 end
 if not self:GetAttribute(prefix.."enabled") then self:CallMethod("Blocked",page,index,"unavailable");return false end
 -- Missing explicit Focus/Mouseover units must explain a blocked click rather
 -- than allowing Blizzard's secure action dispatch to discard it silently.
 -- Native Game default actions carry no unit attribute at all.
 local requestedUnit=self:GetAttribute(prefix.."unit")
 if not self:GetAttribute(prefix.."signal") and requestedUnit and requestedUnit~="none" and not UnitExists(requestedUnit) then
  self:CallMethod("Blocked",page,index,"unit");return false
 end
 if destination then
  self:SetAttribute("cc-back-"..destination,page)
  self:SetAttribute("cc-page",destination);self:CallMethod("Paint",destination);return false
 end
 self:SetAttribute("type",self:GetAttribute(prefix.."type"))
 self:SetAttribute("unit",self:GetAttribute(prefix.."unit"))
 self:SetAttribute("spell",self:GetAttribute(prefix.."spell"))
 self:SetAttribute("item",self:GetAttribute(prefix.."item"))
 self:SetAttribute("macro",self:GetAttribute(prefix.."macro"))
 self:SetAttribute("macrotext",self:GetAttribute(prefix.."macrotext"))
 self:SetAttribute("marker",self:GetAttribute(prefix.."marker"))
 self:SetAttribute("action",self:GetAttribute(prefix.."action"))
 local signal=self:GetAttribute(prefix.."signal")
 if signal then
  local unit=self:GetAttribute(prefix.."signal-target") or "none"
  if unit=="none" then
   if self:GetAttribute("state-combat")=="combat" then unit="target"
   else
    self:CallMethod("ValidateSignal",page,index)
    if not self:GetAttribute(prefix.."signal-valid") then self:SetAttribute("type",nil);self:CallMethod("Blocked",page,index,"signal");return false end
    unit=self:GetAttribute(prefix.."signal-unit")
   end
  end
  if not unit or (unit~="cursor" and not UnitExists(unit)) then self:SetAttribute("type",nil);self:CallMethod("Blocked",page,index,"signal");return false end
  self:SetAttribute("cc-executed-unit",unit)
  if signal=="ping" then
   local kind=self:GetAttribute(prefix.."ping-kind") or "contextual"
   self:SetAttribute("type","macro");self:SetAttribute("unit",nil)
   self:SetAttribute("macrotext","/ping [@"..unit..(unit=="cursor" and "" or ",exists").."]"..(kind=="contextual" and "" or " "..kind))
  else
   self:SetAttribute("unit",unit)
  end
 end
 self:SetAttribute("cc-selected-page",page);self:SetAttribute("cc-selected-index",index)
 self:CallMethod("ActionSelected",page,index)
 return nil,true
]]
P.secureAfterClick=[[
 local page=self:GetAttribute("cc-selected-page")
 local index=self:GetAttribute("cc-selected-index")
 self:SetAttribute("type",nil);self:SetAttribute("unit",nil)
 self:SetAttribute("spell",nil);self:SetAttribute("item",nil)
 self:SetAttribute("macro",nil);self:SetAttribute("macrotext",nil)
 self:SetAttribute("marker",nil);self:SetAttribute("action",nil)
 self:CallMethod("DidClick",page,index)
 if self:GetAttribute("cc-close-click") then self:ClearBindings();self:Hide() end
]]
P.secureCombat=[[
 if newstate=="combat" and self:IsShown() then
  self:SetAttribute("type",nil)
  local page=self:GetAttribute("cc-page")
  if page~="main" and page~="custom1" and page~="custom2" and page~="custom3" and page~="custom4" and page~="pings" then
   self:SetAttribute("cc-page","main");self:CallMethod("Paint","main")
  end
 end
 self:CallMethod("CombatChanged",newstate)
]]
function P:Style()
 local name=CC.profile and CC.profile.palette and CC.profile.palette.style or "Tracker"
 return self.menuStyles[name] or self.menuStyles.Tracker,name
end
function P:ClickCloses() return true end
function P:SetCompiled(key,value) self.root:SetAttribute(key,value);self.compiledKeys[key]=true end
function P:CompileEntry(page,index,item)
 local prefix="cc-"..page.."-"..index.."-"
 self:SetCompiled(prefix.."page",item.page);self:SetCompiled(prefix.."enabled",item.ready~=false)
 self:SetCompiled(prefix.."nocombat",item.combat==false);self:SetCompiled(prefix.."subject",item.subject==true)
 self:SetCompiled(prefix.."signal",item.signal and item.kind or nil)
 self:SetCompiled(prefix.."signal-target",item.signalTarget or "none")
 self:SetCompiled(prefix.."ping-kind",item.pingType)
 for _,key in ipairs({"type","unit","spell","item","macro","macrotext","marker","action"}) do self:SetCompiled(prefix..key,item.action and item.action[key] or nil) end
end
function P:PageTitle(page) return CC.MenuModel:Title(CC.profile,page) end
function P:BuildPages() self.pages=CC.MenuModel:Build(CC.profile) end
function P:Rebuild()
 if CC.Safety:InCombat() then self.dirty=true;return false,"Menu changes apply after combat." end
 if self.rebuilding then return false end
 if not self.root then self:Create();return self.root~=nil and not self.unavailable end
 self.rebuilding=true
 local ok,why=pcall(function()
  self:Close();self:BuildPages()
  for key in pairs(self.compiledKeys) do self.root:SetAttribute(key,nil) end;self.compiledKeys={}
  local cfg=CC.profile.palette;self.radius=cfg.radius or 112;self.root:SetSize(self.radius*2,self.radius*2)
  self.root:SetAttribute("cc-enabled",CC.profile.enabled and cfg.enabled and not CC.SavedData.readOnly)
  self.root:SetAttribute("cc-close-click",self:ClickCloses())
  self.root:SetAttribute("cc-auto-target",cfg.autoTargetEnemy~=false)
  local gap=28;for _,ring in pairs(CC.profile.rings) do if ring.enabled then gap=math.max(gap,ring.size/2+8) end end
  local ox=cfg.offsetX or 40
  self.root:SetAttribute("cc-offset-x",(ox<0 and -1 or 1)*(self.radius+math.max(gap,math.abs(ox))))
  self.root:SetAttribute("cc-offset-y",cfg.offsetY or -28)
  for page,items in pairs(self.pages) do
   assert(#items<=9,"Quick menu page exceeds nine sectors")
   self:SetCompiled("cc-count-"..page,#items);self:SetCompiled("cc-back-"..page,"main")
   for index,item in ipairs(items) do self:CompileEntry(page,index,item) end
   self:PrepareArt(page,items)
  end
  self.root:SetAttribute("cc-page","main");self.root:SetAttribute("cc-opening-page","main")
  self.dirty=false;if CC.Utility then CC.Utility.dirty=false end
 end)
 self.rebuilding=false
 if not ok then self.unavailable=true;self.failureReason=tostring(why);pcall(self.root.SetAttribute,self.root,"cc-enabled",false);if CC.Diagnostics then CC.Diagnostics:OptionalFault("PALETTE_BUILD_FAULT") end;return false,why end
 self.unavailable=false;return true
end
function P:PrepareOpening()
 if CC.Safety:InCombat() then return end
 self.snapshot=nil
 if self.dirty then self:Rebuild() end
 if CC.QuestNotes then CC.QuestNotes:Close() end
 self.snapshot=CC.Subject:Capture()
 self.signalSnapshot=self.snapshot.guid and CC:Copy(self.snapshot) or nil
 if not self.signalSnapshot then
  local guid=CC.Subject:GUID("target")
  if guid then self.signalSnapshot={guid=guid,unit="target",created=GetTime()} end
 end
 if not CC.profile.palette.experimental then self.snapshot={context="general",created=GetTime()} end
 self.root:SetAttribute("cc-opening-page",self.snapshot.context=="enemy" and "enemy" or self.snapshot.context=="friendly" and "friendly" or "main")
 for page,items in pairs(self.pages) do for index,item in ipairs(items) do if item.subject then self:ValidateSubject(page,index) end end end
end
function P:ValidateSubject(page,index)
 if CC.Safety:InCombat() then return end
 local item=self.pages[page] and self.pages[page][index];if not item or not item.subject then return end
 local allowed,reason=CC.Actions:Available(item.id,self.snapshot);item.ready=allowed==true;item.reason=reason;item.action=nil
 local unit=self.snapshot and self.snapshot.unit
 if allowed then
  if item.id=="focus" then item.action={type="focus",unit=unit}
  elseif item.id:match("^mark%d+$") then item.action={type="raidtarget",unit=unit,marker=tonumber(item.id:sub(5)),action="set"}
  elseif item.id:match("^ping") then item.action={type="macro",macrotext="/ping [@"..unit..",exists] "..item.id:sub(5)} end
 end
 self:CompileEntry(page,index,item)
end
function P:SignalUnit(item)
 local requested=item.signalTarget or "none"
 if requested~="none" then return requested end
 if CC.Safety:InCombat() then return "target" end
 local snap=self.signalSnapshot
 if snap then
  if GetTime()-(snap.created or 0)>30 then return nil,"The menu target expired. Reopen over the intended unit." end
  local token=CC.Subject:Resolve(snap)
  if token then return token end
  return nil,"The original unit is no longer available. Reopen over the intended unit."
 end
 return "target"
end
function P:SignalAvailable(item)
 local unit,why=self:SignalUnit(item)
 if not unit then return false,why end
 if unit=="cursor" then return item.kind=="ping","Ground placement is only available for pings." end
 local exists=CC.Safety:BoolCall(UnitExists,unit)
 if exists==false then return false,"Select a target or reopen the menu over a unit." end
 -- Unreadable combat data is left to the restricted click's native UnitExists
 -- check. It is never inspected, converted, or used to fabricate an identity.
 if exists==nil and not CC.Safety:InCombat() then return false,"Target data is unavailable." end
 return true
end
function P:ValidateSignal(page,index)
 if CC.Safety:InCombat() then return end
 local item=self.pages[page] and self.pages[page][index];if not item or not item.signal then return end
 local prefix="cc-"..page.."-"..index.."-"
 local unit,why=self:SignalUnit(item);local okay=unit and (unit=="cursor" or CC.Safety:BoolCall(UnitExists,unit)==true)
 self.root:SetAttribute(prefix.."signal-valid",okay==true)
 self.root:SetAttribute(prefix.."signal-unit",okay and unit or nil)
 self.signalReason=why or (not okay and "Select a target or reopen the menu over a unit." or nil)
end
function P:Allowed(item)
 if not item then return false,"Choose an option." end
 if item.kind then return CC.Utility:Status(item) end
 if item.page then return item.ready~=false,item.reason end
 if item.combat==false and CC.Safety:InCombat() then return false,"Available after combat." end
 if item.id:match("^ping") and not item.subject then return CC.Utility and CC.Utility:PingAvailable()==true,"Blizzard's Ping system is unavailable." end
 return CC.Actions:Available(item.id,self.snapshot)
end
function P:Blocked(page,index,reason)
 local item=self.pages[page] and self.pages[page][index];local _,why=self:Allowed(item)
 if reason=="signal" then CC:Print(self.signalReason or "No usable menu target. Select a target and reopen the menu.");return end
 if reason=="unit" then
  local name=item and item.action and item.action.unit or "selected unit"
  CC:Print("Cannot use this action: "..tostring(name).." is unavailable. Select Game default or choose an available unit.")
  return
 end
 CC:Print(reason=="combat" and "This action is available after combat." or why or (item and item.reason) or "This action is unavailable.")
end
function P:DidClick(page,index)
 local item=self.pages[page] and self.pages[page][index];if not item then return end
 self.lastAction=item.id
 if not item.action then CC.Actions:Dispatch(item.dispatchID or item.id,self.snapshot) end
 if item.signal and CC.NativePings and CC.NativePings.FinishMenuSignal then CC.NativePings:FinishMenuSignal(item) end
 if CC.SignalArt:IsSignal(item.signalID or item.id) then local x,y=CC.CursorPosition:Sample();if x then CC.SignalFeedback:Play(item.signalID or item.id,x,y,CC.profile.palette.signalStyle) end end
end
function P:CombatChanged(state) self.hover=nil;if state=="combat" then self.snapshot=nil;self.signalSnapshot=nil end end
function P:Create()
 if self.root or CC.Safety:InCombat() then return end
 if type(SecureHandlerWrapScript)~="function" or type(RegisterStateDriver)~="function" or type(SetOverrideBindingClick)~="function" then self.unavailable=true;self.failureReason="Secure menu APIs are unavailable.";return end
 local ok,why=pcall(function()
  local root=CreateFrame("Button","CursorCompanionPalette",UIParent,"SecureActionButtonTemplate,SecureHandlerStateTemplate")
  self.root=root;root:SetSize(224,224);root:SetFrameStrata("DIALOG");root:SetFrameLevel(20);root:EnableMouse(true);root:SetClampedToScreen(true)
  root:SetAttribute("ping-top-level-pass-through",true)
  -- An explicitly protected, passive reference avoids relying on UIParent's
  -- inherited protection when obtaining a restricted frame handle.
  local screen=CreateFrame("Frame",nil,UIParent,"SecureHandlerBaseTemplate")
  self.screen=screen;screen:SetAllPoints(UIParent);screen:EnableMouse(false)
  if screen.EnableMouseWheel then screen:EnableMouseWheel(false) end
  root:SetFrameRef("screen",screen)
  root:RegisterForClicks("AnyUp","AnyDown");root:SetAttribute("useOnKeyDown",false)
  root.PrepareOpening=function() safeCall(self.PrepareOpening,self) end
  root.Paint=function(_,page) safeCall(self.Paint,self,page) end
  root.ValidateSubject=function(_,page,index) safeCall(self.ValidateSubject,self,page,index) end
  root.ValidateSignal=function(_,page,index) safeCall(self.ValidateSignal,self,page,index) end
  root.Blocked=function(_,page,index,reason) safeCall(self.Blocked,self,page,index,reason) end
  root.DidClick=function(_,page,index) safeCall(self.DidClick,self,page,index) end
  root.ActionSelected=function(_,page,index)
   local item=self.pages[page] and self.pages[page][index];self.lastAction=item and item.id or nil
   CC.state.nativeActionOwner="Palette"
   if item and item.signal and CC.NativePings and CC.NativePings.BeginMenuSignal then
    CC.NativePings:BeginMenuSignal(item,root:GetAttribute("cc-executed-unit"))
   end
  end
  root.CombatChanged=function(_,state) self:CombatChanged(state) end
  SecureHandlerWrapScript(root,"OnClick",root,self.secureBeforeClick,self.secureAfterClick)
  root:SetAttribute("_onstate-combat",self.secureCombat);RegisterStateDriver(root,"combat","[combat] combat; safe")
  root:SetScript("OnHide",function()
   self.shown=false;self.page=nil;self.snapshot=nil;self.signalSnapshot=nil;self.hover=nil;self.pendingClose=nil
   if CC.PaletteTether then CC.PaletteTether:Hide() end;if GameTooltip then GameTooltip:Hide() end
  end)
  SecureHandlerWrapScript(root,"OnHide",root,[[ self:ClearBindings() ]])
  root:SetScript("OnShow",function() self.shown=true;self.openedAt=GetTime();self.closeNotice=false end)
  root:SetScript("OnUpdate",function(_,dt) safeCall(self.Update,self,dt) end)
  root:SetScript("OnLeave",function() if GameTooltip then GameTooltip:Hide() end end)
  self.centerArt=root:CreateTexture(nil,"BORDER");self.centerArt:SetAllPoints(root)
  self.outlineArt=root:CreateTexture(nil,"ARTWORK");self.outlineArt:SetAllPoints(root)
  self.centerText=root:CreateFontString(nil,"OVERLAY","GameFontNormalSmall");self.centerText:SetPoint("CENTER",0,5);self.centerText:SetWidth(96)
  self.centerHint=root:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall");self.centerHint:SetPoint("CENTER",0,-18);self.centerHint:SetWidth(100)
  local toggle=CreateFrame("Button","CursorCompanionPaletteToggle",UIParent,"SecureActionButtonTemplate,SecureHandlerBaseTemplate")
  self.toggle=toggle;toggle:RegisterForClicks("AnyUp","AnyDown");toggle:SetFrameRef("menu",root);toggle:SetAttribute("useOnKeyDown",false)
  SecureHandlerWrapScript(toggle,"OnClick",toggle,self.secureOpenBefore,self.secureOpenAfter)
  toggle.Unavailable=function() CC:Print(self.unavailable and (self.failureReason or "Quick menu is unavailable on this client.") or "Enable Quick menu in Cursor Companion settings.") end
  toggle:Hide();self.bindingOwner=CreateFrame("Frame",nil,UIParent)
  self.listener=CreateFrame("Frame");pcall(self.listener.RegisterEvent,self.listener,"GLOBAL_MOUSE_DOWN")
  self.listener:SetScript("OnEvent",function(_,_,button)
   if self.shown and not CC.Safety:InCombat() and self:ClickCloses() and (button=="LeftButton" or button=="RightButton") then local index=self:PointerIndex();if index==nil then self:Close() end end
  end)
  CC.PaletteTether:Create();root:Hide()
 end)
 if not ok then self.unavailable=true;self.failureReason=tostring(why);if CC.Diagnostics then CC.Diagnostics:OptionalFault("PALETTE_SECURE_SETUP_FAULT") end;return end
 self:Rebuild();self:RefreshBindings()
end
function P:RefreshBindings()
 if CC.Safety:InCombat() then self.bindingsDirty=true;return false end
 if not self.bindingOwner or not self.toggle or type(GetBindingKey)~="function" or type(ClearOverrideBindings)~="function" then return false end
 local a,b=GetBindingKey(CC.Bindings and CC.Bindings.action or "CURSORCOMPANION_PALETTE")
 local signature=(a or "").."|"..(b or "")
 if signature==self.bindingSignature and not self.bindingsDirty then return true end
 ClearOverrideBindings(self.bindingOwner)
 for _,key in ipairs(self.mouseBindingKeys or {}) do self.root:SetAttribute("cc-close-key-"..key,nil) end
 self.mouseBindingKeys={}
 if self.captureSuspended then self.bindingSignature=nil;return true end
 for _,key in ipairs({a or "",b or ""}) do if key~="" then
  SetOverrideBindingClick(self.bindingOwner,true,key,"CursorCompanionPaletteToggle","LeftButton")
  self.root:SetAttribute("cc-close-key-"..key,true);self.mouseBindingKeys[#self.mouseBindingKeys+1]=key
 end end
 self.bindingSignature=signature;self.bindingsDirty=false;return true
end
function P:SetBindingCapture(active)
 self.captureSuspended=active==true;self.bindingsDirty=true
 if CC.Safety:InCombat() then return false end
 return self:RefreshBindings()
end
function P:OnCombatEnded()
 if CC.Safety:InCombat() then return end
 if self.pendingClose then self:Close() end
 if self.dirty and (not self.root or not self.root:IsShown()) then self:Rebuild() end;self:RefreshBindings()
end
function P:Close()
 if not self.root then return true end
 if CC.Safety:InCombat() then
  self.pendingClose=true
  if self.root:IsShown() and not self.closeNotice then CC:Print("Press Escape or the menu shortcut to close the quick menu during combat.");self.closeNotice=true end
  return false
 end
 self.root:Hide();self.shown=false;self.pendingClose=nil;return true
end
function P:Open()
 if CC.Safety:InCombat() then CC:Print("Use your quick-menu shortcut during combat.");return false end
 if not CC.profile.enabled or not CC.profile.palette.enabled then CC:Print("Enable Quick menu in Cursor Companion settings.");return false end
 self:Create();if not self.root or self.unavailable then CC:Print(self.failureReason or "The quick menu is unavailable.");return false end
 self:Close();self.toggle:Execute(self.secureToggle);return self.root:IsShown()
end
function P:Toggle() if self.root and self.root:IsShown() then return self:Close() else return self:Open() end end
function P:At(x,y)
 if not self.centerX or not self.radius then return nil end
 local dx,dy=x-self.centerX,y-self.centerY;local distance=dx*dx+dy*dy
 if distance>self.radius*self.radius then return nil end
 if distance<(self.radius*.305)^2 then return 0 end
 local count=#(self.items or {});if count==0 then return nil end
 local angle=CC.Controls:Angle(dx,dy)%(2*math.pi)
 return math.floor((angle+math.pi/count)%(2*math.pi)/(2*math.pi/count))+1
end
function P:PointerIndex()
 local x,y=CC.CursorPosition:Sample();if not x then return nil end
 return self:At(x,y),x,y
end
function P:PrepareArt(page,items)
 local cfg=CC.profile.palette;local style=self:Style();local group=self.art[page] or {};self.art[page]=group
 for i=1,9 do
  local a=group[i]
  if not a then
   a={};group[i]=a;a.sector=self.root:CreateTexture(nil,"BACKGROUND");a.sector:SetAllPoints(self.root)
   a.label=self.root:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall");a.label:SetJustifyH("CENTER")
   a.icon=self.root:CreateTexture(nil,"OVERLAY");a.plate=self.root:CreateTexture(nil,"ARTWORK");a.plate:SetTexture(media.."SignalPlate.tga");a.plate:SetBlendMode("ADD")
  end
  a.sector:Hide();a.label:Hide();a.icon:Hide();a.plate:Hide()
  local item=items[i]
  if item then
   local count=#items;local angle=(i-1)*2*math.pi/count;local radius=self.radius*(count<=4 and .70 or .68)
   a.sector:SetTexture(media..style.prefix..count.."_"..i..".tga")
   local signal=CC.SignalArt:IsSignal(item.signalID or item.id)
   local icon=item.icon or (signal and CC.SignalArt:Texture(item.signalID or item.id)) or CC.MenuIcons:Texture(item.id) or media.."ActionSettings.tga"
   a.hasIcon=icon~=nil
   local size=math.max(16,math.min(42,math.floor((count>=8 and 26 or 30)*(signal and cfg.signalScale or cfg.actionScale)+.5)))
   a.icon:SetTexture(icon);a.icon:ClearAllPoints();a.icon:SetPoint("CENTER",self.root,"CENTER",math.sin(angle)*radius,math.cos(angle)*radius);a.icon:SetSize(size,size)
   a.plate:ClearAllPoints();a.plate:SetPoint("CENTER",a.icon,"CENTER");a.plate:SetSize(size*1.42,size*1.42)
   a.label:SetText(item.label);a.label:SetWidth(count>=8 and 66 or 86);a.label:ClearAllPoints();a.label:SetPoint("CENTER",self.root,"CENTER",math.sin(angle)*radius,math.cos(angle)*radius)
   CC.TextLayout:Text(a.label,a.label:GetWidth(),14)
  end
 end
end
function P:Paint(page)
 if not self.root or not self.root:IsShown() then return end
 self.page=page;self.items=self.pages[page] or {};self.hover=nil;self.accum=.12
 local style,name=self:Style();self.activeStyleName=name
 self.centerArt:SetTexture(media..style.center..".tga");self.outlineArt:SetTexture(media..style.outline..".tga")
 self.centerArt:SetVertexColor(unpack(style.centerTint));self.outlineArt:SetVertexColor(unpack(style.trim))
 for key,group in pairs(self.art) do for i,a in ipairs(group) do
  local visible=key==page and self.items[i]~=nil
  a.sector:SetShown(visible);a.icon:SetShown(visible and a.hasIcon);a.plate:SetShown(visible and a.hasIcon);a.label:SetShown(visible and not a.hasIcon)
 end end
 self.centerText:SetText(self:PageTitle(page));self.centerHint:SetText(#self.items==0 and "Empty" or page=="main" and "Close" or "Back")
 self.centerText:SetTextColor(.89,.88,.86);self.centerHint:SetTextColor(.70,.69,.67);self:FitCenter();self:Update(0)
end
function P:FitCenter()
 local width=math.max(40,(self.radius or 112)*.50)
 CC.TextLayout:FixedText(self.centerText,width,26);CC.TextLayout:FixedText(self.centerHint,width,16)
end
function P:Update(dt)
 if not self.root or not self.root:IsShown() or not self.items then return end
 self.shown=true
 local x,y=self.root:GetCenter();local scale=self.root:GetEffectiveScale()/UIParent:GetEffectiveScale()
 if not CC.Safety:IsNumber(x) or not CC.Safety:IsNumber(y) then return end
 self.centerX,self.centerY=x*scale,y*scale
 local index,cx,cy=self:PointerIndex();if cx then CC.PaletteTether:Update(self.centerX,self.centerY,self.radius,cx,cy) end
 local changed=index~=self.hover;self.hover=index;self.accum=(self.accum or 0)+(dt or 0)
 if not changed and self.accum<.12 then return end;self.accum=0
 local style=self:Style();local choice=index and index>0 and self.items[index];local allowed,reason=self:Allowed(choice)
 self.centerText:SetText(choice and string.upper(choice.label) or self:PageTitle(self.page))
 self.centerHint:SetText(choice and (allowed and "Select" or "Unavailable") or self.page=="main" and "Close" or "Back")
 self.centerText:SetTextColor(unpack(choice and self.primary or {.89,.88,.86}));self:FitCenter();self.outlineArt:SetVertexColor(unpack(choice and style.trimHover or style.trim))
 local group=self.art[self.page] or {}
 for i,item in ipairs(self.items) do
  local a=group[i];local enabled,why=self:Allowed(item);item.available=enabled==true;item.currentReason=why
  if a then
   a.sector:SetVertexColor(unpack(index==i and style.hover or style.base));local alpha=enabled and 1 or .38
   a.label:SetTextColor(index==i and self.primary[1] or .88,index==i and self.primary[2] or .87,index==i and self.primary[3] or .85,alpha)
   local r,g,b=1,1,1;if CC.SignalArt:IsSignal(item.signalID or item.id) then r,g,b=CC.SignalArt:Tint(item.signalID or item.id,CC.profile.palette.signalStyle) end
   if index==i then r,g,b=self.secondary[1],self.secondary[2],self.secondary[3] end
   a.icon:SetVertexColor(r,g,b,alpha);a.plate:SetVertexColor(r,g,b,alpha*(index==i and .38 or .14))
  end
 end
 if changed and GameTooltip then
  GameTooltip:Hide()
  if choice and not allowed then GameTooltip:SetOwner(self.root,"ANCHOR_BOTTOM");GameTooltip:SetText(reason or choice.reason or "Unavailable",1,1,1,1,true);GameTooltip:Show() end
 end
end
-- Slash/settings entry points remain available out of combat. Gameplay bindings
-- click CursorCompanionPaletteToggle directly through an out-of-combat override.
function CursorCompanion_TogglePalette(keyState)
 if keyState=="down" then return end
 if GetCurrentKeyBoardFocus and GetCurrentKeyBoardFocus() then return end
 if CC.Bindings and CC.Bindings:SuppressInvocation() then return end
 CC.Palette:Toggle()
end
BINDING_HEADER_CURSORCOMPANION="Cursor Companion"
BINDING_NAME_CURSORCOMPANION_PALETTE="Open / close quick menu"
