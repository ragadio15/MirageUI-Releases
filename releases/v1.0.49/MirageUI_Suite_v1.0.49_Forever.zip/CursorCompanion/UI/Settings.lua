local _,CC=...
CC.Settings={page="Home",rows={},descriptors={},notice=""}
local S=CC.Settings;local C=CC.Controls
-- Search is session-only. Every word must match, in any order, across the
-- visible label, explanation, category and human-readable choice names.
function S:SearchWords(value)
 local words={}
 for word in tostring(value or ""):lower():gmatch("%S+") do
  -- The edit box already bounds input to 80 characters. Every entered word
  -- participates; silently dropping a ninth word returns misleading matches.
  words[#words+1]=word
 end
 return words
end
function S:MatchesSearch(d,words)
 local text=(d.page or "").." "..(d.label or "").." "..(d.help or "")
 for _,value in ipairs(d.values or {}) do text=text.." "..tostring(d.labels and d.labels[value] or value) end
 text=text:lower()
 for _,word in ipairs(words) do if not text:find(word,1,true) then return false end end
 return true
end
CC.StyleLabels={Ring="Classic ring",Segments="Classic segments",Circle="Circle",FourDash="Four dashes",EightDash="Eight dashes",Plus="Crosshair",Diagonal="Diagonal crosshair",Corners="Corner brackets",Precision="Precision dual ring",Orbit="Orbital arcs",Ticks="Tactical ticks",Compass="Compass bearings",Constellation="Constellation orbit",Circuit="Circuit arcs",Eclipse="Eclipse arcs",Lattice="Lattice ring",Vector="Vector chevrons",QuestNeedle="Quest needle",QuestRose="Quest rose",QuestWayfinder="Quest wayfinder",QuestSundial="Quest sundial",QuestHorizon="Quest horizon",QuestAster="Quest aster",QuestEclipse="Quest eclipse",QuestVector="Quest vector",QuestBeacon="Quest beacon"}
CC.RoleLabels={Decorative="Appearance only",["Spell range"]="Spell range",Relationship="Friendly or hostile",["Cast / channel"]="Casting time",GCD="Global Cooldown (GCD)",Health="Player health",Resource="Player resource"}
local function add(page,path,label,kind,opts,help)
 local d={page=page,path=path,label=label,kind=kind,help=help or ""}
 for k,v in pairs(opts or {}) do d[k]=v end;S.descriptors[#S.descriptors+1]=d;return d
end
local function number(page,path,label,mi,ma,step,help) return add(page,path,label,"number",{min=mi,max=ma,step=step},help) end
local function choice(page,path,label,values,labels,help) return add(page,path,label,"choice",{values=values,labels=labels},help) end
add("Home","enabled","Show cursor effects","bool",nil,"You can always stop the effects with /cc off.")
add("Home","advanced.contrast","Color-blind friendly colors","bool",nil,"Uses blue and orange for spell range, without adding text near the pointer.")
local outside=choice("Outside cursor","outside.mode","Select outside cursor",{"None","Outer Ring 2","Quest Compass","Beacon"},nil,
 "Choose one outer display. Quest Compass and group Beacon share the navigation ring. Combat guidance needs readable position and facing; other rings stay independent.")
outside.virtual=true
for _,key in ipairs({"inner","outer","outer2"}) do
 local page=key=="outer" and "Outer ring" or key=="inner" and "Inner ring" or "Outside cursor";local p="rings."..key.."."
 if key~="outer2" then add(page,p.."enabled","Show this ring","bool") end
 choice(page,p.."style","Shape",CC.StyleOrder,CC.StyleLabels,
  key=="outer2" and "Choose artwork for your third function ring." or nil)
 choice(page,p.."role","What it shows",CC.RoleOrder,CC.RoleLabels,"Every enabled ring keeps its configured appearance, subject to your general hide preferences. GCD adds a separate circular sweep only during the cooldown. Casting, health and resource add their own progress when current data is available; missing data leaves the artwork visible.")
 number(page,p.."size","Size",key=="outer" and 24 or 20,key=="outer2" and 176 or key=="outer" and 128 or 100,1)
 number(page,p.."stroke","Line thickness",1,3,1,"Changes the function's progress rim and supported artwork. Classic ring and segments keep their original artwork thickness.")
 number(page,p.."opacity","Visibility",.1,1,.05,"Lower values make the ring more transparent.")
 choice(page,p.."colorMode","Ring color",{"Manual","Class","Neutral","[MUI] Orange","[MUI] Gold"},nil,
  "Choose the ring's tint, including the active GCD sweep. Spell range temporarily uses green or red, then returns to this color when no range result is available. Color-blind mode uses blue and orange. Choose a distinct resting color so each state is clear.")
 add(page,"rings."..key,"Manual color","color",{manualPath=p.."colorMode"})
 add(page,p.."glow","Soft glow","bool")
 number(page,p.."speed","Spin speed",0,90,5,"Zero is still. Only the artwork spins around its center; function progress keeps a fixed origin.")
 choice(page,p.."direction","Spin direction",{"Clockwise","Counterclockwise"})
end
-- Independent navigation feature. It owns only the outermost compass layer and
-- NEVER changes the other function rings. The normal Outer Ring 2 and Quest
-- Compass toggles are mutually exclusive and explicitly explained in both UIs.
-- The outside mode selector uses existing persisted mode flags, preserving
-- all legacy v2.5/v2.6 import and migration behavior without a new field.

choice("Outside cursor","compass.style","Compass shape",CC.QuestCompassStyles,CC.StyleLabels,
 "Nine purpose-built navigation dials. They can also be selected as ordinary ring artwork.")
number("Outside cursor","compass.size","Compass diameter",20,176,1,"Automatically remains outside the largest enabled ordinary ring.")
number("Outside cursor","compass.stroke","Compass line thickness",1,3,1)
number("Outside cursor","compass.pointerWidth","Pointer width",.35,2.2,.05,"Change only the directional arrow's width. Its distance from the dial stays fixed.")
number("Outside cursor","compass.pointerHeight","Pointer height",.15,2.2,.05,"Change only the arrow's height; the smaller minimum offers a subtle indicator.")
number("Outside cursor","compass.opacity","Compass visibility",.1,1,.05)
choice("Outside cursor","compass.colorMode","Compass color",{"Manual","Class","Neutral","[MUI] Orange","[MUI] Gold"},nil,
 "MirageUI presets set the overall compass tint. In Beacon mode, Color by transmission type overrides this tint until disabled.")
add("Outside cursor","compass","Manual compass color","color",{manualPath="compass.colorMode"})
add("Outside cursor","compass.glow","Soft compass glow","bool")
choice("Outside cursor","compass.selectionMode","Standalone quest selection",{"Nearest","Focused"},
 {Nearest="Nearest eligible quest",Focused="Pinned, then Blizzard focus, then nearest"},
 "A Quest Notes pin always wins. Focused also follows Blizzard's supertracked quest. Unknown focused locations never redirect you to an unrelated quest.")
add("Outside cursor","compass.stableTarget","Keep a stable automatic target","bool",nil,
 "Switch automatic quests only when the alternative is substantially closer. A pin or changed Blizzard focus takes effect immediately.")
add("Outside cursor","compass.smoothHeading","Smooth compass direction","bool",nil,
 "Smooth small turns; new destinations and large turns respond immediately. Unknown bearings are never replayed.")
add("Outside cursor","compass.arrivalCue","Show a nearby-location cue","bool",nil,
 "Near the approximate marker, replace the pointer with a small gold dot. This does not mean the objective is complete.")
number("Outside cursor","compass.arrivalRadius","Nearby radius (yards)",3,20,1,
 "A proximity cue only. Caves, floors and map areas can make this different from walking distance.")
add("Outside cursor","compass.showLabel","Show destination label","bool",nil,
 "Destination, approximate straight-line distance and navigation state beside the cursor. Combat can use a last known quest location or a received Beacon.")
choice("Outside cursor","compass.labelMode","Destination label",{"Name + distance","Distance only"})
number("Outside cursor","compass.labelWidth","Destination label width",120,320,10,
 "Destination names wrap; labels flip near screen edges and never capture mouse clicks.")
choice("Outside cursor","compass.routeMode","Standalone route planner",{"Off","Suggestions","Follow route"},nil,
 "Used when Wayfinder is off or absent. Suggestions keep your compass unchanged; Follow route guides between known quest locations. /cc route reviews the stops. Distances are straight-line.")
choice("Outside cursor","compass.routePolicy","Route preference",{"Balanced","Short travel","Nearby turn-ins"},nil,
 "Balanced weighs distance, compact quest groups, readable progress and native waypoint confidence. Nearby turn-ins adds a modest turn-in preference; it does not estimate travel time or danger.")
number("Outside cursor","compass.clusterRadius","Maximum cluster span (yards)",20,150,10,
 "Every pair of known quest destinations in a cluster must be within this straight-line span and on the same map/floor. No inferred spawn locations.")
number("Outside cursor","compass.routeRange","Planning radius (yards)",200,10000,100,
 "Only readable destinations on your current map and within this straight-line radius are considered. Other locations are explained in the route panel.")
number("Outside cursor","compass.routeStops","Maximum suggested stops",3,12,1,
 "Bounded local tour, not a globally optimal route. Reaching a marker never advances a quest. Defer temporarily skips a stop; Reset restores deferred stops.")
add("Outside cursor","questNotes.enabled","Enable Quest Notes","bool",nil,"Open nearby readable quest objectives with the shared Navigation shortcut in Quest Compass mode. Out of combat only; Beacon mode transmits instead.")
number("Outside cursor","questNotes.limit","Quest Notes: nearby objectives",3,8,1,"Number of nearby quests shown. A scroll bar appears when the window fills.")
number("Outside cursor","questNotes.width","Quest Notes window width",320,620,10,"Set the compact window width; longer objective text wraps and remains scrollable.")
number("Outside cursor","questNotes.height","Quest Notes window height",220,560,10,"Set the window height. Extra quest entries remain available by scrolling.")
add("Outside cursor","beacon.nativePings","Receive native Blizzard pings","bool",nil,"Readable group pings share Beacon priority. Terrain coordinates are not generally exposed: no guessed locations or sender-position substitutions.")
add("Outside cursor","beacon.typeColors","Color by transmission type","bool",nil,
 "When on, each signal's saved color overrides Compass color. Choose [MUI] Orange or [MUI] Gold in each transmission's color picker. Turn off to use the overall Compass color.")
add("Outside cursor","beacon.trackPingUnits","Follow readable ping targets","bool",nil,"Tracks only an explicitly identified target with readable native coordinates. Loss of target data removes the arrow; the sender's position is never substituted.")
number("Outside cursor","beacon.pingLifetime","Native ping lifetime (seconds)",5,300,5,"Native ping destinations expire unless held. Beacon waypoint expiry remains separate.")
for _,key in ipairs(CC.MenuModel.transmissionOrder) do
 add("Outside cursor","beacon.colors."..key,CC.MenuModel.transmissionLabels[key].." color","color",{signalColor=true})
end
add("Outside cursor","beacon.shareMenuTargets","Share menu target identities","bool",nil,"Quietly shares the target identity of a confirmed menu ping or marker with compatible group members. No continuous coordinate broadcast; never shares a guessed target.")
add("Outside cursor","beacon.receiveMenuTargets","Receive menu target identities","bool",nil,"Accept target signals from compatible group members, using the same Hold, sender filter, lifetime and readable-position rules as native pings.")
add("Outside cursor","beacon.showSender","Beacon: show sender","bool",nil,"Identify whose latest group waypoint you are following.")
add("Outside cursor","beacon.showAge","Beacon: show age","bool",nil,"Show how long ago this destination was published.")
choice("Outside cursor","beacon.acceptFrom","Beacon: accept destinations from",{"Any group member","Leader and assistants"},nil,"Filter incoming destinations. Your own publications are always available locally.")
add("Outside cursor","beacon.autoSync","Beacon: recover after reloading","bool",nil,"Quietly request the group's current waypoint after reloading, joining, or enabling Beacon. The original sender must still be present with a compatible version.")
add("Outside cursor","beacon.showDelivery","Beacon: show receipt confirmations","bool",nil,"The destination label reports how many compatible receivers confirmed your publication. No confirmation does not prove delivery failed.")
number("Outside cursor","beacon.staleAfter","Beacon age warning (seconds)",0,3600,30,"Label an older location as an old snapshot. Zero disables the warning; it never moves or deletes the destination.")
number("Outside cursor","beacon.expiration","Beacon expiry (seconds)",0,3600,30,"Zero keeps the latest Beacon until replaced, cleared or the group ends. Hidden addon messages create no chat lines.")
add("Fishing","fishing.enabled","Enable Fishing Assistant","bool",nil,"The assigned key equips or casts. During a Fishing channel, pressing it cancels that cast and recasts. Right-click the bobber to collect a fish.")
add("Fishing","fishing.autoEquip","Equip a pole when needed","bool",nil,"Use your equipped pole first, or choose a usable pole from carried bags. Equipment may need a separate press before casting.")
add("Fishing","fishing.poleID","Preferred pole item ID","text",nil,"Leave blank for automatic selection. Choose a carried pole below, or enter its item ID.")
add("Fishing","fishing.showStatus","Show fishing status","bool",nil,"Shows the prepared action, access-check state, and when another press is required.")
add("Fishing","fishing.restoreWeapons","Restore previous weapons","bool",nil,"Remember the equipped main hand, off-hand and separate ranged weapon when present. After leaving a confirmed fishing spot, press the shortcut to restore them. A no-water result also prepares restoration. Repeat if another saved slot remains.")
add("Alerts","alerts.enabled","Enable center-out alert effects","bool",nil,"Alerts use supported public events that remain available in combat. No health/resource threshold or enemy-cast comparisons.")
add("Alerts","alerts.combatStart","Entering combat","bool",nil,"Play when combat starts.")
add("Alerts","alerts.combatEnd","Leaving combat","bool",nil,"Play when combat ends.")
add("Alerts","alerts.playerCastStart","Your cast or channel begins","bool",nil,"Uses your player-cast/channel start events.")
add("Alerts","alerts.playerCastInterrupted","Your cast is interrupted","bool",nil,"Uses your spellcast-interrupted event, including during combat.")
add("Alerts","alerts.playerCastFailed","Your spell fails","bool",nil,"Uses your spellcast-failed event; may trigger frequently.")
add("Alerts","alerts.playerDead","Your character dies","bool",nil,"Uses the player-death event; no health-value comparison.")
add("Alerts","alerts.targetChanged","Your target changes","bool",nil,"Uses the target-change event; may also fire when a target is cleared.")
add("Alerts","alerts.encounterStart","Boss encounter begins","bool",nil,"Uses the native encounter-start event when the client provides one.")
add("Alerts","alerts.encounterEnd","Boss encounter ends","bool",nil,"Uses the native encounter-end event when available.")
add("Alerts","alerts.beaconReceived","Beacon Received","bool",nil,"Fires once when a valid remote Beacon or supported group signal is accepted. Duplicates, filtered and held signals do not trigger it.")
add("Alerts","alerts.beaconSent","Beacon Sent","bool",nil,"Fires after the native addon-message API confirms your Beacon publication, not merely when a key is pressed.")
add("Alerts","alerts.beaconUpdated","Beacon Updated","bool",nil,"Fires when an accepted signal replaces the active destination, or correlated target data makes its position usable. Not on acknowledgments or every tracking tick.")
choice("Alerts","alerts.style","Effect style",{"Pulse","Glow","Burst","Sparks","Ripple","Beacon","Heartbeat","Prism","Aperture","Crosswave","Nova"},nil,"Aperture, Crosswave and Nova add three crisp center-out effect families with soft shapes radiating from the cursor.")
choice("Alerts","alerts.colorMode","Effect colors",{"Manual","Contextual","[MUI] Orange","[MUI] Gold"},
 {Manual="Use your chosen color",Contextual="Different color for each event"},
 "The two official MirageUI presets apply a fixed tint to all alerts. Contextual keeps independent colors for each event; its color pickers also offer both presets.")
number("Alerts","alerts.size","Effect diameter",32,240,4)
number("Alerts","alerts.duration","Effect duration (seconds)",.25,2.5,.05)
number("Alerts","alerts.opacity","Effect opacity",.1,1,.05)
add("Alerts","alerts.color","Custom effect color","color",{manualPath="alerts.colorMode"})
-- These are genuine saved RGB values, not merely a fixed color legend.
-- Each row is shown when its corresponding alert is enabled and Contextual
-- ("Different color for each event") has been selected.
for _,event in ipairs(CC.AlertEventOrder) do
 add("Alerts","alerts.eventColors."..event,"Color: "..CC.AlertEventLabels[event],"color",
  {eventCondition=event,eventColor=true},"Choose the unique color for this alert event.")
end
add("Trails","motion.enabled","Show a trail","bool")
choice("Trails","motion.kind","Trail style",{"Ribbon","Dots","Comet","Glints","Mist","Needles","Stardust","Embers","Chevron","Orbitals"},nil,"Needles and Chevron are directional. Embers and Orbitals add crisp compact particles.")
choice("Trails","motion.colorMode","Trail color",{"Manual","Class","Neutral","[MUI] Orange","[MUI] Gold"},nil,
 "Use a fixed official MirageUI tint for any trail style, or retain your existing Manual, Class or Neutral appearance.")
add("Trails","motion","Manual color","color",{manualPath="motion.colorMode"})
number("Trails","motion.length","Trail length",20,240,10)
number("Trails","motion.lifetime","Fade time (seconds)",.05,.6,.05)
number("Trails","motion.width","Trail width",1,16,1,"Controls ribbon thickness and dot size. The preview, live trail and quick-menu connection use the same setting.")
number("Trails","motion.opacity","Trail visibility",.05,.6,.05)
number("Trails","motion.density","Dot spacing",2,24,1,"A smaller gap makes a smoother trail.").advanced=true
choice("Trails","motion.quality","Trail detail",{"Low","Balanced","High"}).advanced=true
choice("Spell range","info.source","Check range for",{"mouseover","target"},{mouseover="Unit under the pointer",target="Selected target"})
add("Spell range","info.brackets","Try an approximate reach range","bool",{advanced=true},"Uses tracked ranged attacks outside combat. This is an estimate of spell reach, not measured distance.")
-- Quick Menu is organized by the context in which options actually appear.
-- Headings are presentation-only; values remain normal persisted preferences.
local function section(label)
 local d=add("Quick menu","__heading."..label,label,"heading")
 d.section=true;return d
end
choice("Signals","palette.signalStyle","Ping and marker palette",{"Chromatic","Tactical","Monochrome","[MUI] Orange","[MUI] Gold"},
 {Chromatic="Original signal colors",Tactical="Subtle tactical colors",Monochrome="Neutral mint-white"},
 "Use [MUI] Orange or [MUI] Gold to tint local ping/marker icons and feedback. This never recolors Blizzard's world-space pings or target markers.")
number("Signals","palette.signalScale","Signal icon scale",.75,1.4,.05)
add("Signals","palette.signalFeedback","Show selection echo","bool",nil,"Local click feedback; it does not guarantee server delivery.")
add("Preferences","hideOnMouseDown","Hide during mouse-button holds","bool")
add("Preferences","hideOverWindows","Hide when hovering over windows","bool",nil,
 "Hide Cursor Companion effects over recognized UI windows, then show them again when the pointer returns to the game world. Windows and Blizzard's cursor stay visible. Some custom addon windows may not be recognized.")
number("Preferences","idleHideSeconds","Hide when still (seconds)",0,15,.5,"Zero keeps the ring visible while the mouse is still.")
-- UX03: idle hiding takes priority for every assigned function.
number("Preferences","offsetX","Ring: left / right",-96,96,1).advanced=true
number("Preferences","offsetY","Ring: up / down",-96,96,1).advanced=true
-- Basic settings show the essential decisions; "More options" reveals all detail.
-- Saved data, defaults, profile export codes and rendering values are unchanged.
local fineTune={
 ["rings.*.stroke"]=true,["rings.*.opacity"]=true,["rings.*.glow"]=true,
 ["rings.*.speed"]=true,["rings.*.direction"]=true,
 ["compass.selectionMode"]=true,["compass.stableTarget"]=true,["compass.smoothHeading"]=true,
 ["compass.routeMode"]=true,["compass.routePolicy"]=true,["compass.clusterRadius"]=true,["compass.routeRange"]=true,["compass.routeStops"]=true,
 ["compass.arrivalRadius"]=true,["compass.labelMode"]=true,["compass.labelWidth"]=true,
 ["compass.stroke"]=true,["questNotes.limit"]=true,["compass.opacity"]=true,["compass.colorMode"]=true,["compass.glow"]=true,
 ["alerts.duration"]=true,["alerts.opacity"]=true,["alerts.size"]=true,
 ["motion.length"]=true,["motion.opacity"]=true,["motion.density"]=true,["motion.quality"]=true,
 ["palette.offsetX"]=true,["palette.offsetY"]=true,["palette.radius"]=true,
 ["palette.confirmDuel"]=true,["palette.actionScale"]=true,
}
for _,d in ipairs(S.descriptors) do
 local key=d.path:gsub("^rings%.[^.]+%.","rings.*.")
 if fineTune[key] then d.advanced=true end
end
function S:Notice(text)
 self.notice=text or ""
 if self.message then
  self.message:SetText(self.notice)
  local h=CC.TextLayout:Text(self.message,self.frame:GetWidth()-180,15)
  self.message:ClearAllPoints();self.message:SetPoint("BOTTOMLEFT",self.frame,"BOTTOMLEFT",160,48)
  if self.scroll then self.scroll:SetPoint("BOTTOMLEFT",158,math.max(86,h+60)) end
 end
end
function S:Preview() if CC.Preview then CC.Preview:Apply() end end
function S:Create()
 if self.frame then return end
 local f=CreateFrame("Frame","CursorCompanionSettings",UIParent,"BackdropTemplate");self.frame=f;f.ccFixedButtons=true
 local width,height=CC.TextLayout:WindowSize(870,660,870,600)
 f:SetSize(width,height);CC.TextLayout:FitWindow(f);f:SetPoint("CENTER");f:SetFrameStrata("DIALOG");f:EnableMouse(true);f:SetMovable(true);f:SetClampedToScreen(true);C:Backdrop(f)
 -- Actual MirageUI emblem, packaged locally so Cursor Companion stays standalone.
 local mirage=f:CreateTexture(nil,"ARTWORK");self.mirageMark=mirage
 mirage:SetSize(32,32);mirage:SetPoint("TOPLEFT",f,"TOPLEFT",15,-9)
 mirage:SetTexture("Interface\\AddOns\\CursorCompanion\\Media\\CrosshairIcon.tga")
 local title=C:Text(f,"Cursor Companion",55,-16)
 title:ClearAllPoints();title:SetPoint("LEFT",mirage,"RIGHT",8,0);title:SetJustifyV("MIDDLE")
 CC.Skin:Text(title);self.brandTitle=title
 local drag=CreateFrame("Frame",nil,f);drag:SetPoint("TOPLEFT");drag:SetSize(width-60,40);drag:EnableMouse(true);drag:RegisterForDrag("LeftButton")
 drag:SetScript("OnDragStart",function() f:StartMoving() end);drag:SetScript("OnDragStop",function() f:StopMovingOrSizing() end)
 local close=CC.Skin:Close(f,function() self:Cancel() end)
 self.message=C:Text(f,"",160,-height+66,"GameFontHighlightSmall");self.message:SetWidth(width-180)
 local search=CreateFrame("EditBox",nil,f,"BackdropTemplate");CC.Skin:Input(search);self.search=search;search:SetSize(234,24);search:SetPoint("TOPLEFT",160,-58);search:SetAutoFocus(false);search:SetMaxLetters(80)
 C:Text(f,"Find a setting",18,-64,"GameFontHighlightSmall")
 search:SetScript("OnTextChanged",function(_,user) if user then self:Render() end end);search:SetScript("OnEscapePressed",function(b) b:ClearFocus() end)
 self.clearSearch=C:Button(f,"Clear",400,-58,44,function()
  C:CloseChoices();search:SetText("");search:ClearFocus();self:Render()
 end)
 self.searchStatus=C:Text(f,"",160,-84,"GameFontHighlightSmall")
 self.searchStatus:SetSize(420,15);self.searchStatus:SetTextColor(.63,.62,.60)
 if self.searchStatus.SetWordWrap then self.searchStatus:SetWordWrap(false) end
 self.nav={};self.groupPages={}
 self.navGroups={
  {label="Appearance",pages={"Home","Inner ring","Outer ring","Trails","Alerts","Spell range"}},
  {label="Navigation",pages={"Outside cursor"}},
  {label="Quick menu",pages={"Quick menu","Signals"}},
  {label="Fishing",pages={"Fishing"}}, {label="Profiles",pages={"Profiles"}},
  {label="Preferences",pages={"Preferences"}}, {label="Help",pages={"Help"}},
 }
 for i,entry in ipairs(self.navGroups) do
  local group=entry
  local b=C:Button(f,group.label,14,-100-(i-1)*36,128,function()
   C:CloseChoices();self.page=self.groupPages[group.label] or group.pages[1];search:SetText("");self:Render()
  end)
  b.group=group;self.nav[i]=b
 end
 self.sectionPicker=C:Button(f,"",158,-100,422,function(owner)
  local group=self.currentGroup
  if not group then return end
  C:Choose(owner,group.pages,{Home="Overview",["Outside cursor"]="Compass and Beacon"},self.page,function(page)
   self.page=page;search:SetText("");self:Render()
  end)
 end)
 self.scroll=CC.Skin:Scroll(f);self.scroll:SetPoint("TOPLEFT",158,-100);self.scroll:SetPoint("BOTTOMLEFT",158,86);self.scroll:SetWidth(422)
 self.child=CreateFrame("Frame",nil,self.scroll);self.child:SetSize(410,500);self.scroll:SetScrollChild(self.child)
 self.advancedButton=C:Button(f,"Advanced",450,-58,130,function() self.showAdvanced=not self.showAdvanced;self.advancedButton:SetText(self.showAdvanced and "Basic" or "Advanced");self:Render() end)
 self.demoButton=C:Button(f,"Refresh preview",width-230,-height+90,210,function() CC.Preview:Refresh() end);if width<820 then self.demoButton:Hide() end
 self.special={}
 self.compassNote=C:Text(self.child,"",0,0,"GameFontHighlightSmall")
 self.compassNote:SetWidth(405);self.compassNote:SetTextColor(.96,.79,.36)
 self.alertNote=C:Text(self.child,"Choose when an alert appears, then preview its look.",0,0,"GameFontHighlightSmall")
 self.alertNote:SetWidth(405);self.alertNote:SetTextColor(.96,.79,.36)
 self.special.alertDemo=C:Button(self.child,"Play alert preview",0,0,194,function()
  if CC.Preview:TryAlert() then self:Notice("Preview only: no gameplay alert or protected action was triggered.")
  else self:Notice("Preview is not available at this screen size.") end
 end)
 self.special.setup=C:Button(self.child,"Run setup",0,0,190,function() CC.Wizard:Open(true) end)
 self.special.preset=C:Button(self.child,"Presets",210,0,190,function(button)
  C:Choose(button,CC.PresetNames,{["Range + GCD"]="Range + Global Cooldown (GCD)",Timing="Cast + Global Cooldown (GCD)"},"",function(name)
   local old=self.draft;self.draft=CC:Preset(name)
   if name~="Developer Curated" then
    self.draft.customMenus=CC:Copy(old.customMenus);self.draft.quickMenus=CC:Copy(old.quickMenus);self.draft.utility=CC:Copy(old.utility);self.draft.fishing=CC:Copy(old.fishing);self.draft.beacon=CC:Copy(old.beacon)
    self.draft.info=CC:Copy(old.info)
    self.draft.palette=CC:Copy(old.palette);self.draft.launcher=CC:Copy(old.launcher)
   end
   self:Render();self:Preview();self:Notice("Preset selected. Apply to save.")
  end)
 end)
 self.special.account=C:Button(self.child,"Use shared settings",0,0,190,function() CC.SavedData:UseCharacter(false);self.draft=CC:Copy(CC.profile);self:Render();self:Preview();self:Notice("Using shared settings. Unapplied changes were not kept.") end)
 self.special.clone=C:Button(self.child,"Copy for this character",210,0,190,function() CC.SavedData:UseCharacter(true);self.draft=CC:Copy(CC.profile);self:Render();self:Preview();self:Notice("This character now has a separate copy.") end)
 self.special.export=C:Button(self.child,"Copy support information",0,0,240,function() self:OpenDiagnostics() end)
 self.special.test=C:Button(self.child,"Check add-on",0,-36,240,function() local ok=CC.Diagnostics:SelfTest();self:Notice(ok and "Basic checks passed. In-game testing is still needed." or "A check failed. Copy support information.") end)
 self.special.profile=C:Button(self.child,"Measure performance",0,-72,240,function() CC.Diagnostics.profiling=not CC.Diagnostics.profiling;self:Notice(CC.Diagnostics.profiling and "Measurement is on. Copy support information after testing." or "Measurement stopped.") end)
 self.special.coexist=C:Button(self.child,"Allow another cursor add-on",0,-108,240,function() CC.state.conflictAcknowledged=true;CC.VisualLifecycle:Reconcile();self:Notice("Allowed for this session. Other add-ons were not changed.") end)
 self.helpText=C:Text(self.child,"",0,-160,"GameFontHighlightSmall");self.helpText:SetWidth(405)
 self.profiles=CC.ProfilePanel;self.profiles:Create(self.child)
 self.spells=CC.TrackedSpells:Create(self.child,self);self.spells.frame:SetPoint("TOPLEFT",0,0)
 self.bindingWidget=CC.Bindings:CreateWidget(self.child,self);self.bindingWidget.frame:SetPoint("TOPLEFT",0,0)
 self.notesBindingWidget=CC.Bindings:CreateNotesWidget(self.child,self);self.notesBindingWidget.frame:SetPoint("TOPLEFT",0,0)
 self.fishingBindingWidget=CC.Bindings:CreateFishingWidget(self.child,self)
 self.quickEditor=CC.QuickMenuEditor:Create(self.child,self)
 self.utilityEditor=self.quickEditor.editor
 self.fishingNote=C:Text(self.child,"",0,0,"GameFontHighlightSmall");self.fishingNote:SetWidth(405)
 self.special.choosePole=C:Button(self.child,"Choose carried pole",0,0,194,function(button)
  CC.Inventory:Refresh(true)
  local values={""};local labels={[""]="Automatic selection"}
  for _,pole in ipairs(CC.Inventory:GetPoles() or {}) do
   local value=tostring(pole.id);values[#values+1]=value;labels[value]=pole.name or ("Item "..value)
  end
  C:Choose(button,values,labels,self.draft.fishing.poleID,function(value)
   self.draft.fishing.poleID=value;self:Render(true);self:Notice("Pole choice not saved yet. Apply to use it.")
  end)
 end)
 self.special.restoreWeapons=C:Button(self.child,"Prepare weapon restore",210,0,194,function()
  local ok,message=CC.Fishing:RequestRestore()
  self:Notice(message or (ok and "Press your fishing shortcut to restore weapons." or "No saved fishing weapons are available."))
 end)
 self.special.syncBeacon=C:Button(self.child,"Recover group Beacon",0,0,210,function()
  local _,message=CC.Beacon:RequestSync();self:Notice(message)
 end)
 self.special.holdBeacon=C:Button(self.child,"Hold / release Beacon",0,0,210,function()
  local _,message=CC.Beacon:SetHeld(not CC.Beacon.held);self:Notice(message)
 end)
 self.special.clearBeacon=C:Button(self.child,"Clear current Beacon",0,0,210,function()
  CC.Beacon:Clear("CLEARED");self:Notice("Current Beacon cleared. Waiting for the next group publication.")
 end)
 self.special.signalHistory=C:Button(self.child,"Recent group signals",0,0,210,function()
  self:OpenSignalHistory()
 end)
 self.openMenu=C:Button(self.child,"Try quick menu",0,-173,160,function()
  if not CC.profile.palette.enabled then self:Notice("Apply Enable quick menu first.");return end
  CC.Palette:Toggle()
 end)
 C:Button(f,"Apply",160,-height+36,88,function() self:Apply() end)
 C:Button(f,"Cancel",256,-height+36,88,function() self:Cancel() end)
 C:Button(f,"Undo",352,-height+36,88,function() local ok,why=CC.SavedData:Undo();self.draft=CC:Copy(CC.profile);self:Render();self:Preview();self:Notice(ok and "Restored your previous saved settings." or why) end)
 self.resetPage=C:Button(f,"Reset this page",448,-height+36,135,function() self:ResetSection() end)
 C:Button(f,"Turn off",width-122,-height+36,100,function() CC.SavedData:EmergencyOff();if self.draft then self.draft.enabled=false end;self:Notice("Cursor effects are off. Use /cc config to reopen settings, even with the minimap hidden.") end)
 -- The status follows the cached live navigation owner only while this page
 -- is open; rendering runs again only when that owner/status actually changes.
 f:SetScript("OnUpdate",function(_,elapsed)
  if not self.draft or self.page~="Outside cursor" then self.ownerElapsed=0;return end
  self.ownerElapsed=(self.ownerElapsed or 0)+(elapsed or 0)
  if self.ownerElapsed<.5 then return end
  self.ownerElapsed=0
  if self.navigationOwnerText~=self:NavigationOwnerText() then self:Render(true) end
 end)
 f:SetScript("OnHide",function() self.draft=nil;C:CloseChoices();CC.ColorPicker:Cancel();CC.Bindings:CancelCapture();CC.ProfilePanel:CloseForCombat() end)
 tinsert(UISpecialFrames,"CursorCompanionSettings");f:Hide();self.width=width
end
function S:NavigationOwnerText()
 local activeMode=CC.Navigation:Mode()
 local wayfinder=CC.Wayfinder
 local managed=wayfinder and wayfinder:IsManaged()
 local snapshot=managed and wayfinder.snapshot
 if activeMode=="None" then return "Navigation is currently off." end
 if not managed then return "Cursor Companion owns navigation." end
 if not snapshot then return "Waiting for Wayfinder to finish loading." end
 if snapshot.mode=="Pause" then return "Wayfinder owns navigation and is paused." end
 return "Wayfinder owns navigation."
end
function S:RefreshStatus()
 if not self.status then return end
 local text=CC.profile.enabled and "Cursor effects on" or "Cursor effects off"
 if CC.state.fault then text="An effect stopped. Open Help for support information."
 elseif CC.state.reason=="CURSOR_ADDON_CONFLICT" then text="Paused because another cursor add-on is enabled. See Help."
 elseif not CC.ClientIdentity.allowed then text="This game version needs a compatibility check." end
 self.status:SetText(text)
end
function S:LayoutSpells(height)
 local changed=self.spellHeight~=height;self.spellHeight=height
 if changed and not self.rendering and self.frame and self.frame:IsShown() then self:Render(true) end
end
function S:Render(keepScroll)
 if not self.draft then return end
 self.rendering=true
 local aliases={Overview="Home",Rings="Inner ring",Information="Spell range",Spells="Spell range",Palette="Quick menu",Visibility="Preferences",Diagnostics="Help",Motion="Trails",["Outer ring 2"]="Outside cursor",["Quest Compass"]="Outside cursor"}
 self.page=aliases[self.page] or (self.page=="Beacon" and "Outside cursor" or self.page)
 for _,row in pairs(self.rows) do row:Hide() end
 for _,button in pairs(self.special) do button:Hide() end
 if self.compassNote then self.compassNote:Hide() end
 if self.alertNote then self.alertNote:Hide() end
 self.spells.frame:Hide();self.profiles.frame:Hide();self.bindingWidget.frame:Hide();self.notesBindingWidget.frame:Hide();self.fishingBindingWidget.frame:Hide();self.utilityEditor.frame:Hide();self.quickEditor.frame:Hide();self.fishingNote:Hide();self.openMenu:Hide();self.helpText:SetText("")
 local y=0;local query=(self.search:GetText() or ""):lower():match("^%s*(.-)%s*$")
 local words=self:SearchWords(query)
 local matches,contextHidden,lastGroup=0,0,nil
 if self.resetPage then self.resetPage:SetEnabled(query=="") end
 if self.clearSearch then self.clearSearch:SetEnabled(query~="") end
 if query=="" then
  if self.page=="Home" then self.special.setup:Show();self.special.preset:Show();y=math.max(50,self.special.setup:GetHeight()+16,self.special.preset:GetHeight()+16)
  elseif self.page=="Outside cursor" then
   self.compassNote:ClearAllPoints();self.compassNote:SetPoint("TOPLEFT",self.child,"TOPLEFT",0,0)
   self.navigationOwnerText=self:NavigationOwnerText()
   self.compassNote:SetText(self.navigationOwnerText.." Select a mode and Apply. Quest Compass opens Quest Notes; Beacon shares a waypoint with your group. Advanced standalone route choices apply when Wayfinder is off or absent.")

   self.compassNote:Show();y=CC.TextLayout:Text(self.compassNote,405,20)+16
  elseif self.page=="Alerts" then
   self.alertNote:ClearAllPoints();self.alertNote:SetPoint("TOPLEFT",self.child,"TOPLEFT",0,0)
   self.alertNote:Show()
   self.special.alertDemo:ClearAllPoints();self.special.alertDemo:SetPoint("TOPLEFT",self.child,"TOPLEFT",0,-CC.TextLayout:Text(self.alertNote,405,20)-12)
   self.special.alertDemo:Show();y=self.alertNote:GetHeight()+12+self.special.alertDemo:GetHeight()+12
  elseif self.page=="Spell range" then self.spells.frame:Show();self.spells:Refresh();y=(self.spellHeight or 150)+12
  elseif self.page=="Quick menu" then
   self.bindingWidget.frame:Show();self.bindingWidget:Refresh();y=self.bindingWidget.frame:GetHeight()+14
   self.quickEditor.frame:ClearAllPoints();self.quickEditor.frame:SetPoint("TOPLEFT",0,-y);self.quickEditor.frame:Show();self.quickEditor:Refresh();y=y+self.quickEditor.frame:GetHeight()+12
  elseif self.page=="Fishing" then
   self.fishingBindingWidget.frame:ClearAllPoints();self.fishingBindingWidget.frame:SetPoint("TOPLEFT",0,0)
   self.fishingBindingWidget:Refresh();self.fishingBindingWidget.frame:Show()
   y=self.fishingBindingWidget.frame:GetHeight()+14
   self.fishingNote:ClearAllPoints();self.fishingNote:SetPoint("TOPLEFT",0,-y)
   self.fishingNote:SetText("Press your shortcut to equip a carried pole, then again to cast. Right-click the bobber at the splash to catch fish. Pressing during a channel restarts the cast. After leaving a confirmed fishing spot, press to restore your weapons; repeat for any remaining saved slot.")
   self.fishingNote:Show();y=y+CC.TextLayout:Text(self.fishingNote,405,50)+18
  elseif self.page=="Profiles" then
   self.profiles.frame:Show();self.profiles:Refresh();y=self.profiles.frame:GetHeight()+12
  elseif self.page=="Preferences" then self.special.account:Show();self.special.clone:Show();y=math.max(50,self.special.account:GetHeight()+16,self.special.clone:GetHeight()+16)
  elseif self.page=="Help" then
   local helpTop=0
   for _,name in ipairs({"export","test","profile","coexist"}) do
    local button=self.special[name];button:ClearAllPoints();button:SetPoint("TOPLEFT",0,-helpTop)
    button:Show();helpTop=helpTop+button:GetHeight()+11
   end
   helpTop=helpTop+16
   self.helpText:ClearAllPoints();self.helpText:SetPoint("TOPLEFT",0,-helpTop)
   self.helpText:SetText("Start here: choose an Appearance section, select what each ring shows, then adjust its shape and color. Advanced reveals fine adjustments. Apply saves your draft; Cancel discards unapplied changes.\n\nNavigation: choose Quest Compass or Beacon. Wayfinder supplies the route while it is enabled; its paused state also pauses guidance. Standalone routing is available under Advanced when Wayfinder is off or absent. A nearby cue means proximity, not quest completion.\n\nQuest Notes: select a crosshair to pin or unpin an objective. Your character's pins do not change Blizzard tracking. The Navigation shortcut opens Quest Notes in Compass mode and shares your position in Beacon mode.\n\nBeacon: compatible group members can share destinations. Sender filters, Hold and expiry control what you follow. Clear removes your local destination. A native ping without readable coordinates shows no directional arrow. Share menu target identities and Receive menu target identities are independent group-sharing preferences.\n\nSpell range: choose a learned spell under Appearance → Spell range. The color shows that spell's reported reach, not a guarantee it will cast.\n\nFishing: equip and cast with your shortcut, then right-click the bobber to catch fish. Leaving a confirmed fishing spot prepares weapon restoration for your next press. Water proximity and bites are not detected automatically. /cc fish shows current status.\n\nQuick menu: assign actions, pings, markers or native windows to your menus, then Apply outside combat. The right-hand preview is for appearance and navigation; it does not perform the action.\n\nProfiles: Create saves this editor's contents. Open applies a named profile immediately. Import stores a new profile without activating it. Export copies a shareable code.\n\nStop effects: /cc off   |   Settings: /cc config   |   Setup: /cc setup\n\nFor an unexpected result, use Copy support information. Measure performance only while investigating an issue.")
   y=helpTop+CC.TextLayout:Text(self.helpText,405,20)
  end
 end
 local mode=C:Get(self.draft,"outside.mode")
 local navigationMode=mode=="Beacon" or mode=="Quest Compass"
 local navigationQuery=query~="" and self:MatchesSearch({label="navigation shortcut key bind beacon transmit quest compass quest notes"},words)
 local showNavigation=navigationMode and ((query=="" and self.page=="Outside cursor") or navigationQuery)
 local questOnly={selectionMode=true,stableTarget=true,routeMode=true,routePolicy=true,clusterRadius=true,routeRange=true,routeStops=true}
 local descriptors=self.descriptors
 if query~="" then
  descriptors={};local originalOrder={}
  for i,d in ipairs(self.descriptors) do descriptors[i]=d;originalOrder[d]=i end
  table.sort(descriptors,function(a,b)
   if a.page~=b.page then return a.page<b.page end
   return originalOrder[a]<originalOrder[b]
  end)
 end
 for _,d in ipairs(descriptors) do
  local outsidePath=d.page=="Outside cursor"
  local modeMatch=(not outsidePath) or d.path=="outside.mode"
   or (mode=="Outer Ring 2" and d.path:match("^rings%.outer2%."))
   or (mode=="Quest Compass" and (d.path:match("^compass%.") or d.path:match("^questNotes%.")))
   or (mode=="Beacon" and ((d.path:match("^compass%.") and not questOnly[d.path:match("^compass%.(.+)$")]) or d.path:match("^beacon%.")))
  local eventMatch=not d.eventCondition or (self.draft.alerts.colorMode=="Contextual" and self.draft.alerts[d.eventCondition]==true)
  local searchMatch=query~="" and d.kind~="heading" and self:MatchesSearch(d,words)
  local manualMatch=not d.manualPath or C:Get(self.draft,d.manualPath)=="Manual"
  if searchMatch and not (modeMatch and eventMatch and manualMatch) then contextHidden=contextHidden+1 end
  local visible=modeMatch and eventMatch and (searchMatch or (query=="" and d.page==self.page) or (d.path=="outside.mode" and showNavigation))
  if visible and (d.path=="outside.mode" or not d.advanced or self.showAdvanced or query~="") and (not d.manualPath or C:Get(self.draft,d.manualPath)=="Manual") then
   if query~="" then
    if lastGroup~=d.page then
     local key="__search."..d.page
     local heading=self.rows[key]
     if not heading then
      heading=C:Text(self.child,d.page,0,0,"GameFontNormal")
      heading:SetTextColor(.96,.79,.36);heading:SetWidth(405);self.rows[key]=heading
     end
     heading:ClearAllPoints();heading:SetPoint("TOPLEFT",0,-y-5);heading:Show()
     y=y+CC.TextLayout:Text(heading,405,18)+12;lastGroup=d.page
    end
    matches=matches+1
   end
   if d.kind=="heading" then
    local heading=self.rows[d.path]
    if not heading then
     heading=C:Text(self.child,d.label,0,0,"GameFontNormal")
     heading:SetTextColor(.91,.55,.18);heading:SetWidth(405)
     if heading.SetFontObject then heading:SetFontObject("GameFontNormalLarge") end
     self.rows[d.path]=heading
    end
    heading:ClearAllPoints();heading:SetPoint("TOPLEFT",0,-y-7);heading:Show();y=y+CC.TextLayout:Text(heading,405,20)+15
   else
    local row=self.rows[d.path];if not row then row=C:Create(self.child,d,self);self.rows[d.path]=row end
    row:ClearAllPoints();row:SetPoint("TOPLEFT",0,-y);row:Refresh();row:Show();y=y+row:GetHeight()
   end
   if d.path=="outside.mode" and showNavigation then
    self.notesBindingWidget.frame:ClearAllPoints()
    self.notesBindingWidget.frame:SetPoint("TOPLEFT",self.child,"TOPLEFT",0,-y-8)
    self.notesBindingWidget:Refresh();self.notesBindingWidget.frame:Show()
    y=y+self.notesBindingWidget.frame:GetHeight()+20
   end
  end
 end
 if self.searchStatus then
  self.searchStatus:SetText(query~="" and (matches.." shown across pages"..
   (contextHidden>0 and (" · "..contextHidden.." need another mode or color") or "")) or "")
 end
 if query~="" and matches==0 then
  self.helpText:ClearAllPoints();self.helpText:SetPoint("TOPLEFT",0,0)
  self.helpText:SetText(contextHidden>0 and "Matching controls depend on another mode or color choice. Open Outside cursor to change its mode, or select Manual color to reveal color controls. Your current choices are kept." or
   "No settings match all of those words. Try a shorter phrase such as 'ring color', 'fishing shortcut' or 'alert'. Clear returns to this page.")
  y=CC.TextLayout:Text(self.helpText,405,70)
 end
 if query=="" and self.page=="Outside cursor" and mode=="Beacon" then
  for _,name in ipairs({"syncBeacon","holdBeacon","clearBeacon","signalHistory"}) do
   local button=self.special[name];button:ClearAllPoints();button:SetPoint("TOPLEFT",0,-y-8);button:Show();y=y+button:GetHeight()+14
  end
 end
 if query=="" and self.page=="Fishing" then
  for i,name in ipairs({"choosePole","restoreWeapons"}) do
   local button=self.special[name];button:ClearAllPoints();button:SetPoint("TOPLEFT",(i-1)*210,-y-8);button:Show()
  end
  y=y+math.max(self.special.choosePole:GetHeight(),self.special.restoreWeapons:GetHeight())+22
 end
 if query=="" and self.page=="Signals" then
   self.openMenu:ClearAllPoints();self.openMenu:SetPoint("TOPLEFT",self.child,"TOPLEFT",0,-y-14)
   self.openMenu:Show();y=y+self.openMenu:GetHeight()+26
  elseif query=="" and self.page=="Quick menu" then
   self.openMenu:ClearAllPoints();self.openMenu:SetPoint("TOPLEFT",self.child,"TOPLEFT",0,-self.bindingWidget.frame:GetHeight()-12)
  end
 self.child:SetHeight(math.max(420,y+12));if not keepScroll then self.scroll:SetVerticalScroll(0) end
 for _,button in ipairs(self.nav) do
  local selected=false
  for _,page in ipairs(button.group.pages) do if page==self.page then selected=true;break end end
  CC.Skin:Select(button,selected)
  if selected then self.currentGroup=button.group;self.groupPages[button.group.label]=self.page end
 end
 local nested=self.currentGroup and #self.currentGroup.pages>1
 self.sectionPicker:SetShown(nested)
 if nested then self.sectionPicker:SetText(self.currentGroup.label.." · "..(self.page=="Home" and "Overview" or self.page)) end
 self.scroll:SetPoint("TOPLEFT",158,nested and -138 or -100)
 self.rendering=false;self:Preview()
end
function S:OpenSpellRange()
 if not self.draft then return end
 CC.Controls:CloseChoices()
 self.page="Spell range"
 self.search:SetText("")
 self:Render()
 self:Notice("Choose the learned spell to check for range, then Apply to save.")
end
function S:Open()
 if CC.Safety:InCombat() then CC:Print("Open settings after combat. /cc off is still available.");return end
 CC.Palette:Close();if CC.QuestNotes then CC.QuestNotes:Close() end
 if CC.Wizard.frame and CC.Wizard.frame:IsShown() then CC.Wizard:Dismiss() end
 self:Create();CC.TextLayout:FitWindow(self.frame);self.draft=CC:Copy(CC.profile);self.bindingDraft=nil;self.bindingConfirm=false;self.notesBindingDraft=nil;self.notesBindingConfirm=false;self.fishingBindingDraft=nil;self.fishingBindingConfirm=false
 self.frame:Show();CC.Preview:Attach(self.frame,function() return self.draft end,self.width>=820);self:Render();self:Preview();self:Notice("Changes preview here. Apply to save.")
end
function S:Apply()
 if not self.draft then return end
 CC.TrackedSpells:Sync(self.draft.info)
 local valid,why=CC.SavedData:Validate(self.draft,true);if not valid then self:Notice(why);return end
 local bound,message=CC.Bindings:CommitAllDrafts(self);if not bound then self:Notice(message);return end
 local ok,errorText=CC.SavedData:Commit(valid)
 if ok then
  if self.fromWizard and CC.SavedData.account then
   CC.SavedData.account.onboarding={completed=true,dismissed=false,version=CC.version}
   self.fromWizard=false
  end
  self.draft=CC:Copy(CC.profile);self:Render(true);self:Preview();self:Notice(self.page=="Outside cursor" and ("Saved. Active mode: "..CC.Navigation:ModeLabel(CC.Navigation:Mode()).." | Navigation: "..CC.Bindings:Label(CC.Bindings:NotesCurrent())) or "Saved.")
 else self:Notice(errorText) end
end
function S:Cancel() self.fromWizard=false;if self.frame then self.frame:Hide() end end
function S:CloseForCombat() if self.historyFrame then self.historyFrame:Hide() end;self:Cancel();if self.exportFrame then self.exportFrame:Hide() end;CC.ProfilePanel:CloseForCombat() end
function S:FocusNext(current)
 local list={};for _,d in ipairs(self.descriptors) do local r=self.rows[d.path];if r and r:IsShown() and r.entry then list[#list+1]=r.entry end end
 for i,b in ipairs(list) do if b==current then current:ClearFocus();list[i%#list+1]:SetFocus();return end end
end
function S:ResetSection()
 if self.search and self.search:GetText():match("%S") then self:Notice("Clear the search before resetting a page.");return false end
 if self.page=="Profiles" then self:Notice("Profiles are managed with their own Save, Load and Delete controls.");return end
 local defaults=CC:FactoryProfile()
 for _,d in ipairs(self.descriptors) do if d.page==self.page and d.kind~="heading" then C:Set(self.draft,d.path,CC:Copy(C:Get(defaults,d.path))) end end
 if self.page=="Outside cursor" then
  self.draft.compass.enabled=defaults.compass.enabled;self.draft.rings.outer2.enabled=defaults.rings.outer2.enabled
 end
 if self.page=="Quick menu" then self.draft.palette=CC:Copy(defaults.palette);self.draft.customMenus=CC:Copy(defaults.customMenus);self.draft.quickMenus=CC:Copy(defaults.quickMenus) end
 if self.page=="Spell range" then self.draft.info.tracked={""};self.draft.info.reference="";self.draft.info.probes="" end
 self:Render();self:Preview();self:Notice("Page reset. Apply to save.")
end
function S:OpenDiagnostics()
 if CC.Safety:InCombat() then CC:Print("Copy support information after combat.");return end
 if not self.exportFrame then
  local f=CreateFrame("Frame","CursorCompanionExport",UIParent,"BackdropTemplate");self.exportFrame=f
  local w,h=CC.TextLayout:WindowSize(640,500,500,400)
  f:SetSize(w,h);f:SetPoint("CENTER");f:SetFrameStrata("FULLSCREEN_DIALOG");f:EnableMouse(true);C:Backdrop(f)
  self.exportTitle=C:Text(f,"Support information - Ctrl+A, Ctrl+C",18,-15)
  local header=30+CC.TextLayout:Text(self.exportTitle,w-64,18)
  local close=CC.Skin:Close(f,function() f:Hide() end)
  local sc=CC.Skin:Scroll(f);self.exportScroll=sc;sc:SetPoint("TOPLEFT",16,-header);sc:SetSize(f:GetWidth()-50,f:GetHeight()-header-25)
  local e=CreateFrame("EditBox",nil,sc);self.exportBox=e;e:SetSize(f:GetWidth()-70,2000);e:SetMultiLine(true);e:SetAutoFocus(false);e:SetFontObject(ChatFontNormal);sc:SetScrollChild(e)
  e:SetScript("OnEscapePressed",function() f:Hide() end);tinsert(UISpecialFrames,"CursorCompanionExport")
 end
 CC.TextLayout:FitWindow(self.exportFrame);self.exportFrame:Show();self.exportBox:SetText(CC.Diagnostics:Report());CC.TextLayout:EditBox(self.exportBox,self.exportScroll);self.exportBox:HighlightText();self.exportBox:SetFocus()
end

function S:OpenSignalHistory()
 if not self.historyFrame then
  local f=CreateFrame("Frame","CursorCompanionSignalHistory",UIParent,"BackdropTemplate");self.historyFrame=f
  f:SetSize(600,460);f:SetPoint("CENTER");f:SetFrameStrata("DIALOG");f:EnableMouse(true);f:SetClampedToScreen(true);CC.Skin:Panel(f)
  CC.Controls:Text(f,"RECENT GROUP SIGNALS",18,-18):SetTextColor(.96,.79,.36)
  CC.Skin:Close(f,function()f:Hide()end)
  local scroll=CC.Skin:Scroll(f);scroll:SetPoint("TOPLEFT",18,-56);scroll:SetSize(548,336)
  local child=CreateFrame("Frame",nil,scroll);child:SetSize(530,336);scroll:SetScrollChild(child)
  local text=CC.Controls:Text(child,"",0,0,"GameFontHighlightSmall");text:SetWidth(522)
  self.historyText=text;self.historyChild=child
  CC.Controls:Button(f,"Refresh",18,-414,120,function()self:OpenSignalHistory()end)
  CC.Controls:Button(f,"Clear history",154,-414,150,function()CC.NativePings:ClearHistory();self:OpenSignalHistory()end)
  tinsert(UISpecialFrames,"CursorCompanionSignalHistory")
 end
 self.historyText:SetText(CC.NativePings:HistoryText());self.historyChild:SetHeight(CC.TextLayout:Text(self.historyText,522,336)+16)
 CC.TextLayout:FitWindow(self.historyFrame);self.historyFrame:Show()
end
