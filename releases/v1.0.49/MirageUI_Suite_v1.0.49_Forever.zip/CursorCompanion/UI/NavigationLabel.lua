local _,CC=...
-- Passive, opt-in destination label. Full text wraps and screen-edge placement
-- is independent of the pointer glyph. No tooltip/click surface is created.
CC.NavigationLabel={}
local L=CC.NavigationLabel
local messages={TARGET_MARK_REMOVED="Target marker cleared",SIGNAL_TARGET_DEAD="Signal target is dead",SIGNAL_TARGET_PHASE="Target is in another phase",PING_LOCATION_UNAVAILABLE="Native ping location unavailable",PING_TARGET_UNAVAILABLE="Ping target position unavailable",PING_EXPIRED="Native ping expired",NO_POSITION="Player position unavailable",NO_FACING="Direction unavailable",
 NO_API="Guidance unavailable",NO_QUEST_DATA="No readable quest locations",
 NO_READABLE_QUEST_LOCATION="Guidance unavailable",NO_LOCATION="Guidance unavailable",
 NO_MAP_TRANSFORM="Map position unavailable",OTHER_WORLD="Destination on another map",
 AWAITING_TURN_IN_LOCATION="Waiting for turn-in location",QUEST_FAILED="Quest failed",
 REFRESHING="Updating guidance",PROVIDER_ERROR="Guidance unavailable",NO_LOCAL_ROUTE="No eligible local route; /cc route",
 SENDER_FILTERED="Beacon excluded by sender filter",CLEARED="Beacon cleared",WORLD_TRANSITION="Changing zones",UNAVAILABLE="Guidance unavailable",
 WAITING_BEACON="Waiting for a group Beacon",NO_GROUP="Join a party or raid",NO_ROSTER="Group roster unavailable",
 SENDER_LEFT="Beacon sender left the group",BEACON_EXPIRED="Beacon expired",OTHER_FLOOR="Beacon on another floor or map",
 QUEST_SCAN_DEFERRED="Quest discovery resumes after combat",GROUP_CHANGED="Waiting for a Beacon from this group"}
function L:Create(parent)
 if self.frame then return end
 local f=CreateFrame("Frame",nil,parent,"BackdropTemplate")
 self.frame=f;f:SetSize(220,38);f:SetClampedToScreen(true)
 CC.OverlaySafety:MakePassive(f);CC.Skin:Panel(f,true)
 f:SetBackdropColor(.025,.03,.035,.62);f:SetBackdropBorderColor(.18,.19,.20,.35)
 self.title=CC.Controls:Text(f,"",8,-6,"GameFontHighlightSmall");self.title:SetTextColor(.91,.55,.18)
 self.detail=CC.Controls:Text(f,"",8,-22,"GameFontHighlightSmall");self.detail:SetTextColor(.96,.79,.36)
 f:Hide()
end
function L:Hide() if self.frame then self.frame:Hide() end end
function L:Update(state,p,x,y,idle)
 if not self.frame then return end
 if not p.enabled or not p.showLabel or idle or CC.Palette.shown then self:Hide();return end
 if not state or state.status=="OFF" or state.status=="RESTRICTED" then self:Hide();return end
 local title=p.labelMode~="Distance only" and CC.Safety:IsText(state.name) and state.name or ""
 local beacon=state.kind=="Beacon"
 local beaconOptions=CC.profile.beacon or {}
 if beacon and p.labelMode~="Distance only" then
  title=state.name or "Beacon"
  if beaconOptions.showSender~=false and CC.Safety:IsText(state.sender) then title=title.." / "..state.sender end
 end
 local detail=messages[state.status]
 if not detail then
  if CC.Safety:IsNumber(state.distance) then detail="~"..math.floor(state.distance+.5).." yd"
  else detail="Guidance unavailable" end
  if state.status=="NEAR_DESTINATION" or state.status=="DESTINATION_REACHED" then detail=detail.." / Nearby marker"
  elseif state.stage=="READY_FOR_TURN_IN" then detail=detail.." / Ready for turn-in"
  elseif state.confidence=="APPROXIMATE_MAP_AREA" then detail=detail.." / Map area" end
 end
 if beacon then
  if state.confidence=="UNIT_SNAPSHOT" then detail=detail.." / Unit snapshot" end
  if CC.Safety:IsText(state.zone) and state.active then detail=detail.." / "..state.zone end
  if state.held then detail=detail.." / Held" end
  if state.stale then detail=detail.." / Old snapshot" end
  if beaconOptions.showDelivery~=false and CC.Beacon then
   local delivery=CC.Beacon:DeliveryText();if delivery then detail=detail.." / "..delivery end
  end
  if beaconOptions.showAge~=false and CC.Safety:IsNumber(state.age) then
   local age=math.floor(state.age)
   detail=detail.." / "..(age<60 and (age.."s ago") or (math.floor(age/60).."m ago"))
  end
 elseif state.combatCached then detail=detail.." / Last known quest location" end
 local selection=state.selection
 if not beacon and selection and selection.routeIndex and CC.profile.compass.routeMode=="Follow route" then
  detail=detail.." / Route stop "..selection.routeIndex
  if selection.clusterSize and selection.clusterSize>1 then detail=detail.." / "..selection.clusterSize.." nearby quests" end
 end
 local sw,sh=UIParent:GetWidth(),UIParent:GetHeight()
 local width=math.max(80,math.min(p.labelWidth or 220,sw-20))
 local key=title.."\n"..detail.."\n"..width..":"..sh
 if key~=self.textKey then
  self.textKey=key;self.frame:SetScale(1)
  local top=6
  self.title:SetText(title);self.title:SetShown(title~="")
  if title~="" then top=top+CC.TextLayout:Text(self.title,width-16,14)+3 end
  self.detail:ClearAllPoints();self.detail:SetPoint("TOPLEFT",self.frame,"TOPLEFT",8,-top)
  self.detail:SetText(detail)
  local h=top+CC.TextLayout:Text(self.detail,width-16,14)+6
  self.frame:SetSize(width,h)
  self.fit=math.min(1,math.max(40,sh-20)/math.max(1,h))
  self.frame:SetScale(self.fit)
 end
 local scale=self.fit or 1
 local w,h=self.frame:GetWidth()*scale,self.frame:GetHeight()*scale
 local radius=p.size/2+12
 local left=x+radius
 if left+w>sw-8 then left=x-radius-w end
 left=math.max(8,math.min(sw-w-8,left))
 local bottom=math.max(8,math.min(sh-h-8,y-h/2))
 self.frame:ClearAllPoints();self.frame:SetPoint("BOTTOMLEFT",UIParent,"BOTTOMLEFT",left/scale,bottom/scale)
 self.bounds={left=left,bottom=bottom,right=left+w,top=bottom+h}
 self.frame:Show()
end
