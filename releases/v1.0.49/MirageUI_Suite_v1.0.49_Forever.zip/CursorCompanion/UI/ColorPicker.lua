local _,CC=...
CC.ColorPicker={}
local P=CC.ColorPicker
-- Pure RGB/HSV helpers; these process only player-selected cosmetic colors.
function P:RGB(h,s,v)
 local k=(h%1)*6;local i=math.floor(k);local f=k-i
 local a,b,c=v*(1-s),v*(1-f*s),v*(1-(1-f)*s)
 if i==0 then return v,c,a elseif i==1 then return b,v,a elseif i==2 then return a,v,c
 elseif i==3 then return a,b,v elseif i==4 then return c,a,v else return v,a,b end
end
function P:HSV(r,g,b)
 local hi,lo=math.max(r,g,b),math.min(r,g,b);local d=hi-lo;local h=0
 if d>0 then
  if hi==r then h=((g-b)/d)%6 elseif hi==g then h=(b-r)/d+2 else h=(r-g)/d+4 end
  h=h/6
 end
 return h,hi==0 and 0 or d/hi,hi
end
function P:Create()
 if self.frame then return end
 local C=CC.Controls
 local f=CreateFrame("Frame","CursorCompanionColorPicker",UIParent,"BackdropTemplate");self.frame=f
 f:SetSize(330,415);f:SetPoint("CENTER");f:SetFrameStrata("FULLSCREEN_DIALOG");f:SetClampedToScreen(true);f:EnableMouse(true);C:Backdrop(f)
 C:Text(f,"Choose a color",18,-16)
 local close=CC.Skin:Close(f,function() self:Cancel() end)
 local wheel=CreateFrame("Button",nil,f);self.wheel=wheel;wheel:SetSize(188,188);wheel:SetPoint("TOPLEFT",22,-50);wheel:EnableMouse(true)
 local art=wheel:CreateTexture(nil,"ARTWORK");art:SetAllPoints(wheel);art:SetTexture("Interface\\AddOns\\CursorCompanion\\Media\\ColorWheel.tga");self.art=art
 local dot=wheel:CreateTexture(nil,"OVERLAY");self.dot=dot;dot:SetSize(10,10);dot:SetTexture("Interface\\AddOns\\CursorCompanion\\Media\\ColorMarker.tga")
 local swatch=f:CreateTexture(nil,"ARTWORK");swatch:SetSize(58,58);swatch:SetPoint("TOPLEFT",240,-70);swatch:SetTexture("Interface\\Buttons\\WHITE8X8");self.swatch=swatch
 self.hex=C:Text(f,"",228,-140,"GameFontHighlightSmall")
 C:Text(f,"Dark",24,-262,"GameFontHighlightSmall");C:Text(f,"Light",273,-262,"GameFontHighlightSmall")
 local slider=CreateFrame("Slider",nil,f);self.slider=slider;slider:SetPoint("TOPLEFT",65,-263);slider:SetSize(200,16);CC.Skin:Slider(slider)
 slider:SetMinMaxValues(0,1);slider:SetValueStep(.01);if slider.SetObeyStepOnDrag then slider:SetObeyStepOnDrag(true) end
 if slider.Low then slider.Low:SetText("") end;if slider.High then slider.High:SetText("") end;if slider.Text then slider.Text:SetText("") end
 slider:SetScript("OnValueChanged",function(_,v) if not self.updating then self.presetChoice=nil;self.v=v;self:Update() end end)
 wheel:SetScript("OnMouseDown",function(_,button) if button=="LeftButton" then self.dragging=true;self:PickAtCursor() end end)
 wheel:SetScript("OnMouseUp",function() self.dragging=false end)
 wheel:SetScript("OnUpdate",function() if self.dragging then if IsMouseButtonDown("LeftButton") then self:PickAtCursor() else self.dragging=false end end end)
 C:Text(f,"MirageUI color presets",22,-293,"GameFontHighlightSmall")
 self.presetButtons={}
 for i,name in ipairs(CC.MUIColorModes) do
  local p=CC.MUIColorPresets[name]
  local x=i==1 and 22 or 173
  local button=C:Button(f,name,x,-317,135,function() self:SelectPreset(name) end)
  local icon=button:CreateTexture(nil,"OVERLAY")
  icon:SetSize(12,12);icon:SetPoint("RIGHT",button,"RIGHT",-5,0)
  icon:SetColorTexture(p.r,p.g,p.b,1)
  self.presetButtons[name]=button
 end
 C:Button(f,"Cancel",22,-364,135,function() self:Cancel() end)
 C:Button(f,"Use color",173,-364,135,function()
  local fn=self.callback;local r,g,b=self:RGB(self.h,self.s,self.v)
  local p=self.presetChoice and CC.MUIColorPresets[self.presetChoice]
  if p then r,g,b=p.r,p.g,p.b end -- preserve exact 8-bit RGB values
  self.callback=nil;f:Hide();if fn then fn(r,g,b) end
 end)
 f:SetScript("OnHide",function() self.dragging=false;self.callback=nil end)
 tinsert(UISpecialFrames,"CursorCompanionColorPicker");f:Hide()
end
function P:Update()
 local r,g,b=self:RGB(self.h,self.s,self.v)
 local p=self.presetChoice and CC.MUIColorPresets[self.presetChoice]
 if p then r,g,b=p.r,p.g,p.b end
 self.swatch:SetVertexColor(r,g,b,1)
 for name,button in pairs(self.presetButtons or {}) do CC.Skin:Select(button,name==self.presetChoice) end
 self.hex:SetText(string.format("#%02X%02X%02X",math.floor(r*255+.5),math.floor(g*255+.5),math.floor(b*255+.5)))
 self.art:SetVertexColor(self.v,self.v,self.v,1)
 self.dot:ClearAllPoints();self.dot:SetPoint("CENTER",self.wheel,"CENTER",math.cos(self.h*2*math.pi)*self.s*94,math.sin(self.h*2*math.pi)*self.s*94)
end
function P:PickAtCursor()
 self.presetChoice=nil
 local x,y=GetCursorPosition();local scale=self.wheel:GetEffectiveScale();local cx,cy=self.wheel:GetCenter()
 if not cx or not cy or not CC.Safety:IsNumber(scale) or scale<=0 then return end
 local dx,dy=x/scale-cx,y/scale-cy
 self.h=(CC.Controls:Angle(dy,dx)/(2*math.pi))%1;self.s=math.min(1,math.sqrt(dx*dx+dy*dy)/94);self:Update()
end
function P:SelectPreset(name)
 local p=CC.MUIColorPresets and CC.MUIColorPresets[name]
 if not p or not self.frame or not self.callback then return false end
 self.presetChoice=name
 self.h,self.s,self.v=self:HSV(p.r,p.g,p.b)
 self.updating=true;self.slider:SetValue(self.v);self.updating=false
 self:Update();return true
end
function P:Open(r,g,b,callback)
 if CC.Safety:InCombat() then return end
 self:Create();self.callback=callback;self.presetChoice=nil
 for name,p in pairs(CC.MUIColorPresets) do
  if math.abs(r-p.r)<.000001 and math.abs(g-p.g)<.000001 and math.abs(b-p.b)<.000001 then
   self.presetChoice=name;break
  end
 end
 self.h,self.s,self.v=self:HSV(r,g,b)
 self.updating=true;self.slider:SetValue(self.v);self.updating=false;self:Update();self.frame:Show()
end
function P:Cancel() if self.frame then self.frame:Hide() end;self.callback=nil end
