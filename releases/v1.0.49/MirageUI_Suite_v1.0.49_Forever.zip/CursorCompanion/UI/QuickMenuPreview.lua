local _,CC=...
-- Deliberately NOT a SecureActionButton and never invokes Palette/Actions.
-- A separate model, page stack and mouse surface prevent cosmetic input from
-- affecting the world, moving/closing the preview, or changing secure bindings.
CC.QuickMenuPreview={page="main",stack={},art={}}
local P=CC.QuickMenuPreview
local media="Interface\\AddOns\\CursorCompanion\\Media\\"
function P:Create(parent)
 if self.frame then return end
 local f=CreateFrame("Button",nil,parent);self.frame=f;f:SetSize(190,190);f:SetPoint("CENTER",parent,"CENTER",0,10);f:EnableMouse(true);f:RegisterForClicks("LeftButtonUp","RightButtonUp")
 self.outline=f:CreateTexture(nil,"ARTWORK");self.outline:SetAllPoints(f)
 self.center=f:CreateTexture(nil,"ARTWORK");self.center:SetAllPoints(f)
 self.title=f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall");self.title:SetPoint("CENTER",0,5);self.title:SetWidth(62);self.title:SetTextColor(.96,.79,.36)
 self.hint=f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall");self.hint:SetPoint("CENTER",0,-15);self.hint:SetWidth(62)
 self.description=CC.Controls:Text(parent,"",8,-12,"GameFontHighlightSmall");self.description:SetWidth(174)
 self.footer=CC.Controls:Text(parent,"",8,-250,"GameFontHighlightSmall");self.footer:SetWidth(174);self.footer:ClearAllPoints();self.footer:SetPoint("BOTTOMLEFT",parent,"BOTTOMLEFT",8,10)
 self.home=CC.Controls:Button(parent,"General",8,-42,82,function() self:Go("main",true) end)
 self.back=CC.Controls:Button(parent,"Back",100,-42,82,function() self:Back() end)
 for i=1,9 do
  local a={};self.art[i]=a;a.sector=f:CreateTexture(nil,"BACKGROUND");a.sector:SetAllPoints(f)
  a.icon=f:CreateTexture(nil,"OVERLAY");a.label=f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall");a.label:SetWidth(54);a.label:SetJustifyH("CENTER")
 end
 f:SetScript("OnClick",function(_,button)
  if button=="RightButton" then self:Back();return end
  local index=self:Index();if index==0 then self:Back();return end
  local item=index and self.items and self.items[index]
  if item and item.page and self.pages[item.page] then self:Go(item.page)
  elseif item then self.footer:SetText(item.label.."\nPreview only - no action performed.") end
 end)
 f:SetScript("OnUpdate",function(_,dt)
  self.elapsed=(self.elapsed or 0)+(dt or 0);if self.elapsed<.05 then return end;self.elapsed=0;self:Hover()
 end)
 self.elapsed=0
end
function P:SetVisible(visible)
 if not self.frame then return end
 for _,node in ipairs({self.frame,self.description,self.footer,self.home,self.back}) do node:SetShown(visible) end
end
function P:Refresh(profile,selectedPage)
 self.profile=profile;self.pages=CC.MenuModel:Build(profile)
 if selectedPage and selectedPage~=self.selectedPage then self.page=selectedPage;self.stack={};self.selectedPage=selectedPage end
 if not self.pages[self.page] then self.page="main" end
 self:Paint()
end
function P:Go(page,reset)
 if not self.pages or not self.pages[page] then return end
 if reset then self.stack={} elseif self.page~=page then
  self.stack[#self.stack+1]=self.page;if #self.stack>12 then table.remove(self.stack,1) end
 end
 self.page=page;self:Paint()
end
function P:Back()
 local previous=table.remove(self.stack)
 self.page=previous or (CC.Settings and CC.Settings.quickEditor and CC.Settings.quickEditor.context) or "main"
 self:Paint()
end
function P:Paint()
 if not self.profile or not self.frame then return end
 self.items=self.pages[self.page] or {};local style=CC.Palette.menuStyles[self.profile.palette.style] or CC.Palette.menuStyles.Tracker
 self.style=style;local count=#self.items
 self.center:SetTexture(media..style.center..".tga");self.center:SetVertexColor(unpack(style.centerTint))
 self.outline:SetTexture(media..style.outline..".tga");self.outline:SetVertexColor(unpack(style.trim))
 self.description:SetText(CC.MenuModel:Title(self.profile,self.page)..(self.profile.palette.enabled and "" or "\nQuick menu disabled"))
 self.footer:SetText(count==0 and "Empty menu\nEnable slots to preview them." or "Click a submenu to explore.\nActions are cosmetic only.")
 for i,a in ipairs(self.art) do
  local item=self.items[i];a.sector:SetShown(item~=nil);a.icon:Hide();a.label:Hide()
  if item then
   local angle=(i-1)*2*math.pi/count;local radius=95*(count<=4 and .70 or .68)
   a.sector:SetTexture(media..style.prefix..count.."_"..i..".tga");a.sector:SetVertexColor(unpack(style.base))
   local icon=item.icon or (CC.SignalArt:IsSignal(item.signalID or item.id) and CC.SignalArt:Texture(item.signalID or item.id)) or CC.MenuIcons:Texture(item.id) or media.."ActionSettings.tga"
   local size=math.max(14,math.min(30,math.floor((count>=8 and 22 or 26)*(CC.SignalArt:IsSignal(item.signalID or item.id) and self.profile.palette.signalScale or self.profile.palette.actionScale)+.5)))
   a.icon:SetTexture(icon);a.icon:SetSize(size,size);a.icon:ClearAllPoints();a.icon:SetPoint("CENTER",self.frame,"CENTER",math.sin(angle)*radius,math.cos(angle)*radius);a.icon:Show()
  end
 end
 self.hover=nil;self:Hover()
end
function P:Index()
 local x,y=GetCursorPosition();local cx,cy=self.frame:GetCenter();local scale=self.frame:GetEffectiveScale()
 if not CC.Safety:IsNumber(x) or not CC.Safety:IsNumber(y) or not cx or not cy or not scale or scale<=0 then return nil end
 local dx,dy=x/scale-cx,y/scale-cy;local radius=self.frame:GetWidth()/2;local d=dx*dx+dy*dy
 if d>radius*radius then return nil end
 if d<(radius*.305)^2 then return 0 end
 local n=#(self.items or {});if n==0 then return nil end
 local angle=CC.Controls:Angle(dx,dy)%(2*math.pi)
 return math.floor((angle+math.pi/n)%(2*math.pi)/(2*math.pi/n))+1
end
function P:Hover()
 if not self.items or not self.style then return end
 local index=self:Index();local item=index and index>0 and self.items[index]
 self.title:SetText(item and item.label or "Preview");CC.TextLayout:FixedText(self.title,62,28)
 self.hint:SetText(item and (item.page and "Open" or "View") or "Back")
 for i,a in ipairs(self.art) do if self.items[i] then
  a.sector:SetVertexColor(unpack(i==index and self.style.hover or self.style.base))
  local enabled=self.items[i].ready~=false;local signal=self.items[i].signalID or self.items[i].id
  local r,g,b=1,1,1;if CC.SignalArt:IsSignal(signal) then r,g,b=CC.SignalArt:Tint(signal,self.profile.palette.signalStyle) end
  if i==index then r,g,b=.96,.79,.36 end
  a.icon:SetVertexColor(r,g,b,enabled and 1 or .38)
 end end
end
