local _,CC=...
CC.MenuIcons={}
local icons={character="Character",bags="Bags",spellbook="Spellbook",talents="Talents",
 professions="Professions",questlog="Questlog",groupfinder="Groupfinder",settings="Settings",
 focus="Focus",invite="Invite",whisper="Whisper",inspect="Inspect",trade="Trade",
 follow="Follow",duel="Duel",["page:marks"]="Marker",["page:pings"]="Ping"}
local root="Interface\\AddOns\\CursorCompanion\\Media\\Action"
function CC.MenuIcons:Texture(id) local name=icons[id];if name then return root..name..".tga" end end
function CC.MenuIcons:Has(id) return icons[id]~=nil end
function CC.MenuIcons:Tint(enabled,selected)
 if not enabled then return .44,.44,.43,.42 end
 if selected then return .96,.79,.36,1 end -- desert-noon yellow, not legacy teal
 return .86,.85,.83,.92
end
