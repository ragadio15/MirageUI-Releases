local _,CC=...
CC.Trails={}
local media="Interface\\AddOns\\CursorCompanion\\Media\\"
local images={Ribbon="TrailLine.tga",Dots="TrailDot.tga",Comet="TrailDot.tga",Glints="TrailGlint.tga",Mist="TrailSoft.tga",Needles="TrailNeedle.tga",Stardust="TrailStardust.tga",Embers="TrailEmber.tga",Chevron="TrailChevron.tga",Orbitals="TrailOrbital.tga"}
function CC.Trails:Create(parent)
 self.root=CreateFrame("Frame",nil,parent);self.root:SetAllPoints(parent);CC.OverlaySafety:MakePassive(self.root)
 self.nodes={};for i=1,64 do
  local t=self.root:CreateTexture(nil,"BACKGROUND");t:SetTexture(media.."TrailDot.tga");t:Hide()
  self.nodes[i]={texture=t,active=false,x=0,y=0,age=0,distance=0}
 end
 self.head=0;self.activeCount=0;self.pivot=type(CreateVector2)=="function" and CreateVector2(0.5,0.5) or nil
end
function CC.Trails:Flush()
 if not self.nodes then return end
 if self.activeCount>0 then
  for _,n in ipairs(self.nodes) do
   if n.active then n.active=false;n.texture:Hide() end
  end
  self.activeCount=0
 end
 self.lastX=nil;self.lastY=nil;self.carry=0
end
function CC.Trails:Apply()
 self:Flush();self.cap=CC.QualityCaps[CC.profile.motion.quality] or 32
 local m=CC.profile.motion;local path=media..(images[m.kind] or images.Dots)
 for _,node in ipairs(self.nodes) do node.texture:SetTexture(path) end
 self.tintConfig={colorMode=m.colorMode,r=m.r,g=m.g,b=m.b,role="Decorative"}
 -- Ring sizes change only when a profile is applied. Cache this once instead
 -- of walking the ring table for every cursor update.
 self.exclusionRadius=0
 for _,ring in pairs(CC.profile.rings) do if ring.enabled then self.exclusionRadius=math.max(self.exclusionRadius,ring.size/2+2) end end
end
function CC.Trails:Add(x,y,length,angle)
 self.head=self.head%self.cap+1
 local n=self.nodes[self.head]
 if not n.active then self.activeCount=self.activeCount+1 end
 n.active=true;n.x=x;n.y=y;n.age=0;n.distance=0;n.length=length;n.angle=angle or 0
 n.texture:ClearAllPoints();n.texture:SetPoint("CENTER",UIParent,"BOTTOMLEFT",x,y)
end
function CC.Trails:Update(x,y,dt)
 local m=CC.profile.motion
 if not m.enabled then self:Flush();return end
 local moved=0;local dx,dy=0,0
 if self.lastX then dx=x-self.lastX;dy=y-self.lastY;moved=math.sqrt(dx*dx+dy*dy) end
 if moved>math.max(300,m.length*2) or dt>0.2 then self:Flush();moved=0;dx=0;dy=0 end
 if moved>0 then
  local step=m.density;local angle=CC.Controls:Angle(dy,dx);local count=math.min(self.cap,math.floor((moved+(self.carry or 0))/step))
  for i=1,count do local f=i/count;self:Add(x-dx*(1-f),y-dy*(1-f),step+1,angle) end
  self.carry=((self.carry or 0)+moved)%step
 end
 self.lastX,self.lastY=x,y
 if self.activeCount==0 then return end
 local cr,cg,cb=CC.RingLayer:Tint(self.tintConfig,nil,false);local radius=self.exclusionRadius or 0
 for i=1,self.cap do
  local n=self.nodes[i]
  if n.active then
   n.age=n.age+dt;n.distance=n.distance+moved
   if n.age>m.lifetime or n.distance>m.length then n.active=false;self.activeCount=self.activeCount-1;n.texture:Hide()
   else
    local fade=1-n.age/m.lifetime;local t=n.texture;t:SetVertexColor(cr,cg,cb,m.opacity*fade)
    if m.kind=="Ribbon" or m.kind=="Needles" or m.kind=="Chevron" then
     if m.kind=="Needles" then t:SetSize(math.max(6,m.width*3.2),math.max(3,m.width*2.3))
     elseif m.kind=="Chevron" then t:SetSize(math.max(8,m.width*4.1),math.max(6,m.width*3.0))
     else t:SetSize(math.max(n.length or 2,m.width),m.width) end
     t:SetRotation(n.angle,self.pivot)
    elseif m.kind=="Embers" then
     local size=m.width*(2.1+1.2*fade);t:SetSize(size,size);t:SetRotation(n.angle,self.pivot)
    else
     local size=m.width*(m.kind=="Comet" and (1+2*fade) or m.kind=="Glints" and 1.55 or m.kind=="Mist" and 2.6 or m.kind=="Stardust" and 2.15 or m.kind=="Orbitals" and 2.55 or 1)
     t:SetSize(size,size);t:SetRotation(0,self.pivot)
    end
    local w,h=t:GetWidth(),t:GetHeight();local extent=math.sqrt(w*w+h*h)/2;local rx,ry=n.x-x,n.y-y
    t:SetShown(rx*rx+ry*ry>(radius+extent)*(radius+extent))
   end
  end
 end
end
