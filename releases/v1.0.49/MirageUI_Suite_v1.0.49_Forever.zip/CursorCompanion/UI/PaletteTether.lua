local _,CC=...
CC.PaletteTether={}
local T=CC.PaletteTether
local media="Interface\\AddOns\\CursorCompanion\\Media\\"
local images={Ribbon="TrailLine.tga",Dots="TrailDot.tga",Comet="TrailDot.tga",Glints="TrailGlint.tga",Mist="TrailSoft.tga",Needles="TrailNeedle.tga",Stardust="TrailStardust.tga",Embers="TrailEmber.tga",Chevron="TrailChevron.tga",Orbitals="TrailOrbital.tga"}
function T:Create()
 if self.root then return end
 self.root=CreateFrame("Frame",nil,CC.VisualLifecycle:OverlayParent());self.root:SetAllPoints(UIParent);self.root:SetFrameStrata("DIALOG");self.root:SetFrameLevel(1)
 CC.OverlaySafety:MakePassive(self.root);self.nodes={}
 for i=1,64 do local t=self.root:CreateTexture(nil,"ARTWORK");t:Hide();self.nodes[i]=t end
 self.fallback={colorMode="Neutral",role="Decorative"};self:Hide()
end
function T:Hide()
 if self.root then self.root:Hide();for _,t in ipairs(self.nodes) do t:Hide() end end
end
function T:Update(cx,cy,radius,x,y)
 self:Create();local p=CC.profile;local m=p.motion
 local dx,dy=x-cx,y-cy;local length=math.sqrt(dx*dx+dy*dy)
 local kind=m.enabled and m.kind or "Ribbon"
 local width=m.width;local opacity=m.enabled and math.max(.18,m.opacity) or .35
 local cr,cg,cb=CC.RingLayer:Tint(m.enabled and m or self.fallback,nil,false)
 local cursorRadius=0;for _,r in pairs(p.rings) do if r.enabled then cursorRadius=math.max(cursorRadius,r.size/2+2) end end
 local first=radius+4;local last=length-cursorRadius-4
 if length<1 or last<=first then self:Hide();return end
 self.root:Show()
 local available=last-first;local spacing=math.max((kind=="Ribbon" or kind=="Needles" or kind=="Chevron") and 6 or 10,m.density or 8,available/64)
 local count=math.min(64,math.max(1,math.floor(available/spacing)))
 local step=available/count;local angle=CC.Controls:Angle(dy,dx)
 for i,t in ipairs(self.nodes) do
  if i<=count then
   local d=first+(i-.5)*step;local fade=.45+.55*i/count
   local size=kind=="Comet" and width*(.7+1.3*i/count) or kind=="Glints" and width*1.55 or kind=="Mist" and width*2.6 or kind=="Stardust" and width*2.15 or kind=="Needles" and width*2.3 or kind=="Orbitals" and width*2.55 or kind=="Embers" and width*1.35 or kind=="Chevron" and width*2.1 or width
   local long=(kind=="Ribbon" or kind=="Needles" or kind=="Chevron") and math.max(1,kind=="Needles" and width*3.2 or kind=="Chevron" and width*3.1 or step+.5) or size
   local extent=math.sqrt(long*long+size*size)/2
   -- Whole-sprite exclusion, not just its center: nothing is drawn behind the circle.
   if d-extent>=radius+2 and length-d-extent>=cursorRadius then
    t:ClearAllPoints();t:SetPoint("CENTER",UIParent,"BOTTOMLEFT",cx+dx*d/length,cy+dy*d/length)
    local path=media..(images[kind] or images.Ribbon)
    if t.ccPath~=path then t:SetTexture(path);t.ccPath=path end
    t:SetSize(long,size)
    t:SetRotation((kind=="Ribbon" or kind=="Needles" or kind=="Chevron") and angle or 0);t:SetVertexColor(cr,cg,cb,opacity*fade);t:Show()
   else t:Hide() end
  else t:Hide() end
 end
end
