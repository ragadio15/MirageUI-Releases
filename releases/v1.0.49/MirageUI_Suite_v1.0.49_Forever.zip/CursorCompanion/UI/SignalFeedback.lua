local _,CC=...
-- Cosmetic tactical signal assets. This module does not issue pings or markers;
-- the protected, user-initiated action path remains exclusively in Palette.
CC.SignalArt={}
local A=CC.SignalArt
local media="Interface\\AddOns\\CursorCompanion\\Media\\"
local assets={
 mark1={"SignalMark1",.98,.84,.26},mark2={"SignalMark2",1,.57,.20},
 mark3={"SignalMark3",.77,.51,.98},mark4={"SignalMark4",.35,.94,.48},
 mark5={"SignalMark5",.81,.88,.96},mark6={"SignalMark6",.32,.65,1},
 mark7={"SignalMark7",1,.32,.35},mark8={"SignalMark8",.95,.96,.94},
 mark0={"SignalMark0",.67,.76,.84},
 pingassist={"SignalPingAssist",.23,.91,.74},pingattack={"SignalPingAttack",1,.32,.34},
 pingwarning={"SignalPingWarning",1,.76,.26},pingonmyway={"SignalPingOnMyWay",.40,.72,1},
}
function A:IsSignal(id) return type(id)=="string" and assets[id]~=nil end
function A:Texture(id)
 local info=assets[id];return info and media..info[1]..".tga" or nil
end
function A:Tint(id,style)
 local info=assets[id];if not info then return .78,.85,.90 end
 local brand=CC.MUIColorPresets and CC.MUIColorPresets[style]
 if brand then return brand.r,brand.g,brand.b end
 if style=="Monochrome" then return .73,.96,.88 end
 local r,g,b=info[2],info[3],info[4]
 if style=="Tactical" then return r*.55+.25,g*.55+.28,b*.55+.30 end
 return r,g,b
end
CC.SignalFeedback={}
local F=CC.SignalFeedback
function F:Create()
 if self.root then return end
 local root=CreateFrame("Frame",nil,CC.VisualLifecycle:OverlayParent())
 root:SetSize(128,128);root:SetFrameStrata("TOOLTIP");root:SetFrameLevel(6)
 CC.OverlaySafety:MakePassive(root)
 local pulse=root:CreateTexture(nil,"ARTWORK");pulse:SetPoint("CENTER",root,"CENTER");pulse:SetTexture(media.."SignalFeedbackRing.tga");pulse:SetBlendMode("ADD")
 local glyph=root:CreateTexture(nil,"OVERLAY");glyph:SetPoint("CENTER",root,"CENTER");glyph:SetSize(26,26)
 local shine=root:CreateTexture(nil,"BACKGROUND");shine:SetPoint("CENTER",root,"CENTER");shine:SetTexture(media.."SignalPlate.tga");shine:SetBlendMode("ADD")
 self.root,self.pulse,self.glyph,self.shine=root,pulse,glyph,shine
 root:SetScript("OnUpdate",function(_,dt)
  if not pcall(self.Tick,self,dt) then
   self:Hide();CC.Diagnostics:OptionalFault("SIGNAL_VISUAL_FAULT")
  end
 end)
 root:Hide()
end
function F:Hide() if self.root then self.root:Hide() end;self.age=nil end
function F:Play(id,x,y,style)
 if CC.VisualLifecycle and CC.VisualLifecycle:WorkspaceActive() then return end
 if not A:IsSignal(id) or CC.Safety:InCombat() or not CC.profile.palette.signalFeedback then return end
 if not CC.Safety:IsNumber(x) or not CC.Safety:IsNumber(y) then return end
 self:Create()
 local w,h=UIParent:GetWidth(),UIParent:GetHeight()
 x=math.max(60,math.min(w-60,x));y=math.max(60,math.min(h-60,y))
 self.root:ClearAllPoints();self.root:SetPoint("CENTER",UIParent,"BOTTOMLEFT",x,y)
 self.glyph:SetTexture(A:Texture(id))
 self.color={A:Tint(id,style)};self.age=0;self.root:Show();self:Tick(0)
end
function F:Tick(dt)
 if not self.age then return end
 if CC.VisualLifecycle and CC.VisualLifecycle:WorkspaceActive() then self:Hide();return end
 if CC.Safety:InCombat() then self:Hide();return end
 self.age=self.age+math.max(0,math.min(dt or 0,.2))
 if self.age>=.52 then self:Hide();return end
 local t=self.age/.52;local a=1-t
 local r,g,b=self.color[1],self.color[2],self.color[3]
 self.pulse:SetSize(40+96*t,40+96*t);self.pulse:SetVertexColor(r,g,b,.62*a)
 self.shine:SetSize(36+52*t,36+52*t);self.shine:SetVertexColor(r,g,b,.25*a)
 self.glyph:SetSize(23+15*t,23+15*t);self.glyph:SetVertexColor(r,g,b,.85*a)
end
