local _,CC=...
CC.Preview={phase=0,scenario="Appearance"}
local P=CC.Preview
local media="Interface\\AddOns\\CursorCompanion\\Media\\"
local trailImages={Ribbon="TrailLine.tga",Dots="TrailDot.tga",Comet="TrailDot.tga",Glints="TrailGlint.tga",Mist="TrailSoft.tga",Needles="TrailNeedle.tga",Stardust="TrailStardust.tga",Embers="TrailEmber.tga",Chevron="TrailChevron.tga",Orbitals="TrailOrbital.tga"}
function P:Create(parent)
 if self.root then return end
 self.root=CreateFrame("Frame",nil,parent,"BackdropTemplate");self.root:SetSize(210,420);CC.OverlaySafety:MakePassive(self.root)
 CC.Skin:Panel(self.root,true);self.root:SetBackdropColor(.025,.035,.043,.95)
 self.caption=CC.Controls:Text(self.root,"Cursor Companion Preview",10,-12,"GameFontHighlightSmall");self.caption:SetWidth(190);self.caption:SetTextColor(unpack(CC.Skin.muted))
 self.canvas=CreateFrame("Frame",nil,self.root);self.canvas:SetPoint("TOPLEFT",8,-40);self.canvas:SetPoint("BOTTOMRIGHT",-8,10)
 if self.canvas.SetClipsChildren then self.canvas:SetClipsChildren(true) end;CC.OverlaySafety:MakePassive(self.canvas)
 self.anchor=CreateFrame("Frame",nil,self.canvas);self.anchor:SetSize(1,1);CC.OverlaySafety:MakePassive(self.anchor)
 self.layers={inner=CC.RingLayer:Create(self.anchor),outer=CC.RingLayer:Create(self.anchor),outer2=CC.RingLayer:Create(self.anchor)}
 self.compassLayer=CC.RingLayer:Create(self.anchor)
 self.alert=CC.AlertEffects:Create(self.anchor)
 self.trail={};for i=1,64 do
  local t=self.canvas:CreateTexture(nil,"BACKGROUND");t:SetTexture(media.."TrailDot.tga");t:Hide();self.trail[i]=t
 end
 self.sample={relationship="FRIENDLY",range="IN"}
 self.root:SetScript("OnUpdate",function(_,dt) self:Tick(dt) end)
end
function P:Attach(parent,provider,show)
 self:Create(parent);self.root:SetParent(parent);self.root:ClearAllPoints();self.root:SetPoint("TOPRIGHT",-20,-108)
 local height=math.max(190,math.min(440,parent:GetHeight()-230))
 self.root:SetSize(210,height);self.canvas:SetSize(194,height-50)
 self.provider=provider;self.captionText=nil;self.root:SetShown(show~=false);self:Refresh()
end
function P:IsQuickMenu()
 return CC.Settings and CC.Settings.frame and self.root and self.root:GetParent()==CC.Settings.frame and CC.Settings.page=="Quick menu"
end
function P:MenuMode(p)
 local active=self:IsQuickMenu()
 self.anchor:SetShown(not active)
 if active then
  for _,t in ipairs(self.trail) do t:Hide() end
  self.caption:SetText("Quick Menu - cosmetic preview");self.caption:SetTextColor(.96,.79,.36)
  self.canvas:SetPoint("TOPLEFT",8,-48);self.canvas:SetSize(self.root:GetWidth()-16,self.root:GetHeight()-58)
  CC.QuickMenuPreview:Create(self.canvas);CC.QuickMenuPreview:SetVisible(true)
 else CC.QuickMenuPreview:SetVisible(false) end
 return active
end
function P:Apply()
 local p=self.provider and self.provider();if not self.root or not p then return end
 if self:MenuMode(p) then
  CC.QuickMenuPreview:Refresh(p,CC.Settings.quickEditor and CC.Settings.quickEditor.previewPage or "main");return
 end
 for k,L in pairs(self.layers) do
  L.previewProgressUnavailable=nil
  CC.RingLayer:Apply(L,p.rings[k])
 end
 CC.RingLayer:Apply(self.compassLayer,p.compass)
 CC.AlertEffects:Clear(self.alert);self.testConfig=nil
 self.timingAge=4;self:Tick(0)
end
function P:AlertExample(cfg)
 if cfg.colorMode=="Contextual" then
  for _,key in ipairs(CC.AlertEventOrder) do if cfg[key] then return key end end
 end
 return "preview"
end
function P:TryAlert(selectedEvent)
 local cfg=self.provider and self.provider().alerts
 if not self.root or not self.root:IsShown() or not cfg then return false end
 self.testConfig=CC:Copy(cfg);self.testConfig.enabled=true
 CC.AlertEffects:Clear(self.alert)
 CC.AlertEffects:Fire(self.alert,selectedEvent or self:AlertExample(cfg),self.testConfig)
 return true
end
function P:Refresh()
 self.phase=0;self.timingAge=4;self.scenario="Appearance"
 if self:IsQuickMenu() and CC.QuickMenuPreview.frame then CC.QuickMenuPreview:Go(CC.Settings.quickEditor.context,true) end
 if self.trail then for _,t in ipairs(self.trail) do t:Hide() end end
 self:Apply()
end
function P:Cycle() self:Refresh() end -- legacy internal callers; no scenario-cycling UI remains.
-- Fit enabled ring and alert geometry to the narrow preview pane.
function P:Bounds(p)
 local left,right,top,bottom=-2,2,2,-2
 for _,r in pairs(p.rings) do
  if r.enabled then
   local half=r.size/2+2
   left=math.min(left,-half);right=math.max(right,half)
   top=math.max(top,half);bottom=math.min(bottom,-half)
  end
 end
 if p.compass.enabled then
  local half=p.compass.size/2+2
  left=math.min(left,-half);right=math.max(right,half)
  top=math.max(top,half);bottom=math.min(bottom,-half)
 end
 if p.alerts.enabled then
  local half=p.alerts.size/2
  left=math.min(left,-half);right=math.max(right,half)
  top=math.max(top,half);bottom=math.min(bottom,-half)
 end
 return left,right,top,bottom
end
function P:Tick(dt)
 local p=self.provider and self.provider();if not p then return end
 if self:IsQuickMenu() then return end
 local ringElapsed=math.max(0,dt or 0)
 dt=math.min(ringElapsed,.1);self.phase=self.phase+dt;self.timingAge=(self.timingAge or 0)+dt
 local m=p.motion;local active=m.enabled
 local radius=0;for _,r in pairs(p.rings) do if r.enabled then radius=math.max(radius,r.size/2+2) end end
 if p.compass.enabled then radius=math.max(radius,p.compass.size/2+2) end
 if self.caption then
  self.caption:SetText(p.compass.enabled and "Compass direction: preview only" or "Cursor Companion Preview")
  if p.compass.enabled then self.caption:SetTextColor(.96,.79,.36) else self.caption:SetTextColor(unpack(CC.Skin.muted)) end
  if self.captionText~=self.caption:GetText() then
   self.captionText=self.caption:GetText()
   local header=math.max(40,CC.TextLayout:Text(self.caption,self.root:GetWidth()-20,15)+24)
   self.canvas:SetPoint("TOPLEFT",8,-header)
   self.canvas:SetSize(self.root:GetWidth()-16,self.root:GetHeight()-header-10)
  end
 end
 local h=self.canvas:GetHeight();local w=self.canvas:GetWidth()
 local left,right,top,bottom=self:Bounds(p)
 local fit=math.min(1,(w-20)/math.max(1,right-left),(h-24)/math.max(1,top-bottom))
 self.anchor:SetScale(fit)
 local low=12-bottom*fit;local high=h-12-top*fit
 -- A straight upward, slowed demonstration. It is not gameplay position/timing evidence.
 local travel=active and ((self.phase%5)/5) or 1
 local head=low+math.max(0,high-low)*travel
 local headX=w/2-(left+right)*fit/2
 self.anchor:ClearAllPoints();self.anchor:SetPoint("CENTER",self.canvas,"BOTTOMLEFT",headX,head)
 self.headX,self.headY=headX,head
 self.previewScale=fit;self.previewBounds={left=left*fit+headX,right=right*fit+headX,top=top*fit+head,bottom=bottom*fit+head}
 local cap=CC.QualityCaps[m.quality] or 32;local spacing=math.max(m.density,m.length/math.max(1,cap))
 local a,b,c=CC.RingLayer:Tint(m,nil,false)
 for i,t in ipairs(self.trail) do
  local distance=i*spacing;local fade=math.max(0,1-distance/m.length)
  local size=m.width*(m.kind=="Comet" and (1+2*fade) or m.kind=="Glints" and 1.55 or m.kind=="Mist" and 2.6 or m.kind=="Stardust" and 2.15 or m.kind=="Needles" and 2.3 or m.kind=="Orbitals" and 2.55 or m.kind=="Embers" and 1.35 or m.kind=="Chevron" and 2.1 or 1)
  local long=m.kind=="Ribbon" and spacing+1 or m.kind=="Needles" and math.max(6,m.width*3.2) or m.kind=="Chevron" and math.max(7,m.width*3.1) or size
  local extent=math.sqrt(long*long+size*size)/2
  local y=head-distance
  local exclusion=math.max(radius*fit,-bottom*fit)
  if active and i<=cap and distance<=m.length and distance>exclusion+extent and y-extent>=0 and y+extent<=h then
   t:ClearAllPoints();t:SetPoint("CENTER",self.canvas,"BOTTOMLEFT",headX,y)
   local path=media..(trailImages[m.kind] or trailImages.Dots)
   if t.ccPath~=path then t:SetTexture(path);t.ccPath=path end
   t:SetSize(long,size);t:SetRotation((m.kind=="Ribbon" or m.kind=="Needles" or m.kind=="Chevron") and math.pi/2 or 0);t:SetVertexColor(a,b,c,m.opacity*fade);t:Show()
  else t:Hide() end
 end
 if not self.testConfig and p.alerts.enabled and not self.alert.active and (self.phase<.12 or self.phase%3.5<dt) then
  CC.AlertEffects:Fire(self.alert,self:AlertExample(p.alerts),p.alerts)
 end
 CC.AlertEffects:Tick(self.alert,self.testConfig or p.alerts,dt,true)
 if self.testConfig and not self.alert.active then self.testConfig=nil end
 local stage=math.floor(self.phase/2)%3
 self.sample.range=stage==0 and "IN" or stage==1 and "OUT" or "UNKNOWN"
 self.sample.relationship=stage==0 and "FRIENDLY" or stage==1 and "HOSTILE" or "NEUTRAL"
 for k,L in pairs(self.layers) do
  local r=p.rings[k]
  CC.RingLayer:Update(L,r,self.sample,ringElapsed,false,p.advanced.contrast,nil)
  if r.role=="Health" or r.role=="Resource" then
   -- Optional native radial support may be absent or decline a sample. Keep
   -- the configured appearance and other preview rings usable in either case.
   if L.previewProgressUnavailable or type(L.progress.SetRadialProgressBarPercent)~="function" or
      not pcall(L.progress.SetRadialProgressBarPercent,L.progress,r.role=="Health" and .84 or .64) then
    L.previewProgressUnavailable=true;L.progress:Hide()
   end
  end
  if self.timingAge>=4 then
   if r.role=="Cast / channel" then L.cast:SetCooldown(GetTime(),4,1)
   -- Demonstrate configured artwork during the idle interval, then add its
   -- separate sweep. The live provider still forwards measured native data.
   elseif r.role=="GCD" then L.gcd:SetCooldown(GetTime(),1.5,1) end
  end
 end
 CC.RingLayer:Update(self.compassLayer,p.compass,self.sample,dt,false,p.advanced.contrast,
  {status="GUIDING",angle=math.sin(self.phase*.55)*1.9,kind=p.compass.mode=="Beacon" and "Beacon" or "Quest",
   transmissionType=CC.Settings and CC.Settings.beaconPreviewType or "beacon",previewProfile=p})
 if self.timingAge>=4 then self.timingAge=0 end
end
