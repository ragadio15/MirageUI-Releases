local _,CC=...
-- Review-only panel with explicit opt-in controls. No secure actions, map pins,
-- third-party hooks, waypoint writes or automated quest interaction.
CC.QuestRoutePanel={shown=false,rows={}}
local P=CC.QuestRoutePanel
function P:Close()
 self.shown=false
 if self.frame then self.frame:Hide() end
end
function P:ChangeMode(mode)
 local ok,why=CC.QuestRoute:SetMode(mode)
 if not ok then CC:Print(why);return end
 self:Open()
end
function P:Create()
 if self.frame then return end
 local C=CC.Controls
 local f=CreateFrame("Frame","CursorCompanionRoutes",UIParent,"BackdropTemplate")
 self.frame=f;f:SetSize(470,450);f:SetPoint("CENTER",UIParent,"CENTER",0,0)
 f:SetFrameStrata("DIALOG");f:SetClampedToScreen(true);f:EnableMouse(true);CC.Skin:Panel(f)
 self.title=C:Text(f,"EXPERIMENTAL ROUTES",16,-17,"GameFontNormal")
 self.title:SetTextColor(.91,.55,.18);CC.TextLayout:Text(self.title,410,20)
 self.close=CC.Skin:Close(f,function()self:Close()end)
 self.suggest=C:Button(f,"Suggestions",16,-48,140,function()self:ChangeMode("Suggestions")end)
 self.follow=C:Button(f,"Follow route",164,-48,140,function()self:ChangeMode("Follow route")end)
 self.off=C:Button(f,"Off",312,-48,140,function()self:ChangeMode("Off")end)
 self.scroll=CC.Skin:Scroll(f)
 self.scroll:SetPoint("TOPLEFT",16,-85);self.scroll:SetPoint("BOTTOMRIGHT",f,"BOTTOMRIGHT",-28,16)
 self.content=CreateFrame("Frame",nil,self.scroll);self.content:SetSize(426,350);self.scroll:SetScrollChild(self.content)
 self.summary=C:Text(self.content,"",0,0,"GameFontHighlightSmall")
 self.reset=C:Button(self.content,"Reset deferred stops",0,-100,206,function()
  CC.QuestRoute:Reset(true);CC.QuestNavigation:Invalidate("ROUTE_RESET");self:Refresh()
 end)
 self.replan=C:Button(self.content,"Replan from here",214,-100,206,function()
  CC.QuestRoute:Reset(false);CC.QuestNavigation:Invalidate("ROUTE_REPLAN");self:Refresh()
 end)
 C:Tip(self.replan,"Re-rank from your position without marking anything complete. Deferred stops stay deferred; your pin and Blizzard focus are retained.")
 C:Tip(self.reset,"Restore destinations deferred this session. Does not change quest progress, your pin, or Blizzard tracking.")
 self.exclusions=C:Text(self.content,"",0,0,"GameFontHighlightSmall")
 f:SetScript("OnHide",function()self.shown=false;self.elapsed=0 end)
 f:SetScript("OnUpdate",function(_,dt)
  if not self.shown then return end
  if CC.Safety:InCombat() or not CC.profile.enabled or not CC.profile.compass.enabled then self:Close();return end
  self.elapsed=(self.elapsed or 0)+(CC.Safety:IsNumber(dt) and math.min(.25,dt) or 0)
  if self.elapsed>=1 then
   self.elapsed=0;local ok=pcall(self.Refresh,self)
   if not ok then self:Close();CC.Diagnostics:OptionalFault("QUEST_ROUTE_PANEL_UNAVAILABLE") end
  end
 end)
 tinsert(UISpecialFrames,"CursorCompanionRoutes");f:Hide()
end
function P:Row(index)
 if self.rows[index] then return self.rows[index] end
 local f=CreateFrame("Frame",nil,self.content,"BackdropTemplate");CC.Skin:Panel(f,true)
 local row={frame=f}
 row.title=CC.Controls:Text(f,"",10,-10,"GameFontNormal");row.title:SetTextColor(.91,.55,.18)
 row.detail=CC.Controls:Text(f,"",10,-35,"GameFontHighlightSmall")
 row.pin=CC.Controls:Button(f,"Pin quest",10,-65,122,function()
  if CC.Safety:InCombat() then return end
  local n=CC.QuestNavigation
  local ok,why=n:SetPin(n:PinnedID()==row.id and 0 or row.id)
  if not ok then CC:Print(why) else self:Refresh() end
 end)
 row.defer=CC.Controls:Button(f,"Defer stop",142,-65,122,function()
  local ok,why=CC.QuestRoute:Defer(row.id);CC:Print(why)
  if ok then self:Refresh() end
 end)
 CC.Controls:Tip(row.pin,"Pin this quest, taking priority over the route. Click again to unpin. Blizzard tracking is unchanged.")
 CC.Controls:Tip(row.defer,"Skip this destination for this session only; not completion. Reset or a changed native quest stage/location restores it. Explicitly focused quests must first be unpinned/unfocused.")
 self.rows[index]=row;return row
end
function P:Refresh()
 if not self.shown or CC.Safety:InCombat() then return end
 local titleHeight=CC.TextLayout:Text(self.title,410,20)
 local buttonY=math.max(48,titleHeight+28)
 local headerBottom=buttonY+math.max(self.suggest:GetHeight(),self.follow:GetHeight(),self.off:GetHeight())+12
 for _,button in ipairs({self.suggest,self.follow,self.off}) do
  local x=button==self.suggest and 16 or button==self.follow and 164 or 312
  button:ClearAllPoints();button:SetPoint("TOPLEFT",self.frame,"TOPLEFT",x,-buttonY)
 end
 self.scroll:SetPoint("TOPLEFT",16,-headerBottom)
 local nav,route=CC.QuestNavigation,CC.QuestRoute
 local ok=pcall(nav.Snapshot,nav)
 if not ok then route:Suspend("UNAVAILABLE") end
 local mode=CC.profile.compass.routeMode or "Off"
 CC.Skin:Select(self.suggest,mode=="Suggestions");CC.Skin:Select(self.follow,mode=="Follow route");CC.Skin:Select(self.off,mode=="Off")
 local lines={"Mode: "..mode.." / "..route.status}
 if mode=="Off" then
  lines[#lines+1]="Choose Suggestions to preview without changing your compass. Follow route is optional."
 else
  lines[#lines+1]=#route.plan.." suggested stops / "..(route.candidateCount or 0).." eligible locations / ~"..math.floor((route.totalDistance or 0)+.5).." yd at last plan"
  lines[#lines+1]="Preference: "..CC.profile.compass.routePolicy.." / cluster span "..CC.profile.compass.clusterRadius.." yd / planning radius "..CC.profile.compass.routeRange.." yd"
  if route.requested then
   lines[#lines+1]=route.focusUnavailable and "Your explicit focus has no eligible local route location. It retains compass priority; suggestions below do not override it."
    or "Your pinned or Blizzard-focused quest takes priority."
  end
  if mode=="Suggestions" then lines[#lines+1]="Preview only: existing compass selection is unchanged."
  else lines[#lines+1]="Guidance retains the current stop until quest data changes, you defer it, or you replan. Arrival alone does not advance it." end
 end
 lines[#lines+1]="Experimental straight-line tour of known quest markers, not terrain pathfinding. One location per quest, not every objective spawn. Same-map checks cannot detect all caves or floors. No travel-time or safety guarantee."
 self.summary:SetText(table.concat(lines,"\n\n"))
 local y=CC.TextLayout:Text(self.summary,420,20)+12
 self.reset:ClearAllPoints();self.reset:SetPoint("TOPLEFT",self.content,"TOPLEFT",0,-y)
 self.replan:ClearAllPoints();self.replan:SetPoint("TOPLEFT",self.content,"TOPLEFT",214,-y)
 y=y+math.max(self.reset:GetHeight(),self.replan:GetHeight())+12
 for i,entry in ipairs(route.plan) do
  local row=self:Row(i);row.id=entry.id
  row.title:SetText(i..". "..entry.name)
  local h=CC.TextLayout:Text(row.title,400,18)+14
  row.detail:ClearAllPoints();row.detail:SetPoint("TOPLEFT",row.frame,"TOPLEFT",10,-h)
  row.detail:SetText("Leg ~"..math.floor(entry.legDistance+.5).." yd / Total ~"..math.floor(entry.totalDistance+.5).." yd\n"..entry.reason)
  h=h+CC.TextLayout:Text(row.detail,400,18)+8
  row.pin:ClearAllPoints();row.pin:SetPoint("TOPLEFT",row.frame,"TOPLEFT",10,-h)
  row.defer:ClearAllPoints();row.defer:SetPoint("TOPLEFT",row.frame,"TOPLEFT",142,-h)
  row.pin:SetText(nav:PinnedID()==entry.id and "Unpin quest" or "Pin quest")
  h=h+math.max(row.pin:GetHeight(),row.defer:GetHeight())+10
  row.frame:SetSize(420,h);row.frame:ClearAllPoints();row.frame:SetPoint("TOPLEFT",self.content,"TOPLEFT",0,-y)
  row.frame:SetBackdropBorderColor(entry.id==(nav.selected and nav.selected.id) and .91 or .26,.35,.18,.9)
  row.frame:Show();y=y+h+8
 end
 for i=#route.plan+1,#self.rows do self.rows[i].frame:Hide() end
 local counts={}
 for _,reason in pairs(route.excluded) do counts[reason]=(counts[reason] or 0)+1 end
 local reasons={};for reason in pairs(counts) do reasons[#reasons+1]=reason end;table.sort(reasons)
 local excluded={}
 for _,reason in ipairs(reasons) do excluded[#excluded+1]=(route.ExclusionLabels[reason] or reason)..": "..counts[reason] end
 if (route.candidateCount or 0)>#route.plan then excluded[#excluded+1]="Eligible locations beyond this tour's stop limit: "..(route.candidateCount-#route.plan) end
 if #route.plan==0 and mode~="Off" then
  table.insert(excluded,1,"No eligible local stops. Track an active quest on this map, or inspect the exclusions below. Existing manual focus remains available.")
 end
 self.exclusions:ClearAllPoints();self.exclusions:SetPoint("TOPLEFT",self.content,"TOPLEFT",0,-y)
 self.exclusions:SetText(table.concat(excluded,"\n"));self.exclusions:SetShown(#excluded>0)
 if #excluded>0 then y=y+CC.TextLayout:Text(self.exclusions,420,18)+10 end
 self.content:SetHeight(math.max(350,y+8))
 if self.scroll.UpdateScrollChildRect then self.scroll:UpdateScrollChildRect() end
 CC.TextLayout:FitWindow(self.frame)
end
function P:Open()
 if CC.Safety:InCombat() then CC:Print("Route review is available outside combat.");return end
 if CC.Wayfinder then
  local managed,opened,reason=CC.Wayfinder:OpenRoute()
  if managed then
   self:Close()
   if not opened then CC:Print(reason or "Wayfinder is still starting.") end
   return
  end
 end
 if not CC.profile.enabled or not CC.profile.compass.enabled then
  CC:Print("Enable Quest Compass under Outside cursor before opening route review. Your ring roles have not been changed.");return
 end
 self:Create();CC.Palette:Close();CC.QuestNotes:Close();self.shown=true;self.elapsed=0
 self.frame:Show();self:Refresh();self.scroll:SetVerticalScroll(0)
end
