local _,CC=...
CC.Wizard={step=1,rows={}}
local W=CC.Wizard;local C=CC.Controls
W.steps={"Inner and outer rings","Outside cursor","Trails","Quick menu","Fishing","Alerts","Review and finish"}
function W:Notice(text)
 if self.notice then
  self.notice:SetText(text or "")
  local h=CC.TextLayout:Text(self.notice,self.frame:GetWidth()-48,16)
  self.notice:ClearAllPoints();self.notice:SetPoint("BOTTOMLEFT",self.frame,"BOTTOMLEFT",24,60)
  self.scroll:SetPoint("BOTTOMLEFT",24,math.max(105,h+76))
 end
end
function W:Preview() CC.Preview:Apply() end
function W:Create()
 if self.frame then return end
 local f=CreateFrame("Frame","CursorCompanionSetup",UIParent,"BackdropTemplate");self.frame=f;f.ccFixedButtons=true
 local width,height=CC.TextLayout:WindowSize(870,660,500,520);self.width=width
 f:SetSize(width,height);CC.TextLayout:FitWindow(f);f:SetPoint("CENTER");f:SetFrameStrata("DIALOG");f:EnableMouse(true);f:SetClampedToScreen(true);C:Backdrop(f)
 local mark=f:CreateTexture(nil,"ARTWORK");mark:SetTexture("Interface\\AddOns\\CursorCompanion\\Media\\CrosshairIcon.tga")
 mark:SetSize(32,32);mark:SetPoint("TOPLEFT",f,"TOPLEFT",20,-12)
 local brand=C:Text(f,"Cursor Companion",60,-18)
 brand:ClearAllPoints();brand:SetPoint("LEFT",mark,"RIGHT",8,0);brand:SetJustifyV("MIDDLE");CC.Skin:Text(brand)
 self.mirageMark,self.brandTitle=mark,brand
 self.title=C:Text(f,"",20,-57);self.progress=C:Text(f,"",20,-84,"GameFontHighlightSmall")
 local close=CC.Skin:Close(f,function() self:Dismiss() end)
 self.scroll=CC.Skin:Scroll(f);self.scroll:SetPoint("TOPLEFT",24,-117);self.scroll:SetWidth(430);self.scroll:SetPoint("BOTTOMLEFT",24,105)
 self.child=CreateFrame("Frame",nil,self.scroll);self.child:SetSize(412,430);self.scroll:SetScrollChild(self.child)
 self.compassNote=C:Text(self.child,"",0,0,"GameFontHighlightSmall")
 self.compassNote:SetWidth(408);self.compassNote:SetTextColor(.96,.79,.36)
 self.alertNote=C:Text(self.child,"Only combat-safe event alerts are offered. Try /cc alerttest in the world.",0,0,"GameFontHighlightSmall")
 self.alertNote:SetWidth(408);self.alertNote:SetTextColor(.96,.79,.36)
 self.testAlert=C:Button(self.child,"Play alert preview",0,-38,190,function()
  if CC.Preview:TryAlert() then self:Notice("Preview only; no gameplay action performed.")
  else self:Notice("Preview is unavailable on this screen size.") end
 end)
 self.summary=C:Text(self.child,"",0,0,"GameFontHighlight");self.summary:SetWidth(408)
 self.spells=CC.TrackedSpells:Create(self.child,self)
 self.bindings=CC.Bindings:CreateWidget(self.child,self);self.bindings.frame:SetPoint("TOPLEFT",0,0)
 self.notesBindingWidget=CC.Bindings:CreateNotesWidget(self.child,self);self.notesBindingWidget.frame:SetPoint("TOPLEFT",0,0)
 self.fishingBindingWidget=CC.Bindings:CreateFishingWidget(self.child,self)
 self.notice=C:Text(f,"",24,-height+85,"GameFontHighlightSmall");self.notice:SetWidth(width-48)
 self.back=C:Button(f,"Back",24,-height+43,100,function() self.step=math.max(1,self.step-1);self:Render() end)
 C:Button(f,"Keep current settings",134,-height+43,190,function() self:Dismiss() end)
 self.next=C:Button(f,"Next",width-135,-height+43,110,function()
  if self.step==#self.steps then self:Finish() else self.step=self.step+1;self:Render() end
 end)
 self.example=C:Button(f,"Refresh preview",width-230,-height+120,210,function() CC.Preview:Refresh() end);if width<700 then self.example:Hide() end
 f:SetScript("OnHide",function() C:CloseChoices();CC.ColorPicker:Cancel();CC.Bindings:CancelCapture() end)
 tinsert(UISpecialFrames,"CursorCompanionSetup");f:Hide()
end
function W:MaybeOpen()
 local a=CC.SavedData.account
 if self.shownThisSession or CC.Safety:InCombat() or CC.SavedData.readOnly or not a or not CC.ClientIdentity.allowed then return end
 -- MirageUI owns suite onboarding. Suppress only this automatic offer while
 -- that core is loaded; the explicit setup command and saved choice stay intact.
 if CC.API:GetAddOnLoaded("MirageUI") then return end
 local o=a.onboarding
 if not o or (not o.completed and not o.dismissed) then self:Open(false) end
end
function W:Open(manual)
 if CC.Safety:InCombat() or CC.SavedData.readOnly then CC:Print("Open setup after combat.");return end
 self:Create();CC.TextLayout:FitWindow(self.frame)
 local previous=CC.Settings.draft and CC:Copy(CC.Settings.draft) or CC:Copy(CC.profile)
 CC.Settings:Cancel();CC.Palette:Close();if CC.QuestNotes then CC.QuestNotes:Close() end;self.draft=previous;self.bindingDraft=nil;self.bindingConfirm=false;self.notesBindingDraft=nil;self.notesBindingConfirm=false;self.fishingBindingDraft=nil;self.fishingBindingConfirm=false;self.step=1;self.shownThisSession=true
 self.frame:Show();CC.Preview:Attach(self.frame,function() return self.draft end,self.width>=700);self:Render()
end
function W:LayoutSpells(height)
 local changed=self.spellHeight~=height;self.spellHeight=height
 if changed and not self.rendering and self.frame and self.frame:IsShown() then self:Render(true) end
end
function W:Render(keepScroll)
 if not self.draft then return end
 self.rendering=true
 for _,row in pairs(self.rows) do row:Hide() end
 self.spells.frame:Hide();self.bindings.frame:Hide();self.notesBindingWidget.frame:Hide();self.fishingBindingWidget.frame:Hide();self.summary:SetText("")
 self.compassNote:Hide();self.alertNote:Hide();self.testAlert:Hide()
 self.title:SetText(self.steps[self.step]);self.progress:SetText("Step "..self.step.." of "..#self.steps..". Changes are saved when you select Finish.")
 local titleHeight=CC.TextLayout:Text(self.title,self.frame:GetWidth()-40,18)
 self.progress:ClearAllPoints();self.progress:SetPoint("TOPLEFT",20,-57-titleHeight-9)
 local progressHeight=CC.TextLayout:Text(self.progress,self.frame:GetWidth()-40,16)
 self.scroll:SetPoint("TOPLEFT",24,-57-titleHeight-9-progressHeight-16)
 self.back:SetEnabled(self.step>1);self.next:SetText(self.step==#self.steps and "Finish" or "Next")
 local paths={}
 if self.step==1 then
  paths={"rings.inner.enabled","rings.inner.role","rings.inner.style",
   "rings.outer.enabled","rings.outer.role","rings.outer.style"}
 elseif self.step==2 then
  local outside=C:Get(self.draft,"outside.mode")
  paths={"outside.mode"}
  if outside=="Outer Ring 2" then
   paths={"outside.mode","rings.outer2.role","rings.outer2.style"}
  elseif outside=="Quest Compass" then
   paths={"outside.mode","compass.style","compass.pointerWidth","compass.pointerHeight","questNotes.enabled"}
   if self.draft.questNotes.enabled then
    paths[#paths+1]="questNotes.width";paths[#paths+1]="questNotes.height"
    paths[#paths+1]="questNotes.limit"
   end
  elseif outside=="Beacon" then
   paths={"outside.mode","compass.style","compass.showLabel","beacon.showSender","beacon.showAge"}
  end
 elseif self.step==3 then paths={"motion.enabled","motion.kind","motion.width","motion.lifetime"}
 elseif self.step==4 then paths={"palette.enabled","palette.style","palette.experimental"}
 elseif self.step==5 then
  paths={"fishing.enabled","fishing.autoEquip","fishing.showStatus","fishing.restoreWeapons"}
 elseif self.step==6 then
  paths={"alerts.enabled","alerts.combatStart","alerts.playerCastStart","alerts.playerCastInterrupted","alerts.playerDead","alerts.style","alerts.colorMode"}
  if self.draft.alerts.colorMode=="Contextual" then
   for _,event in ipairs(CC.AlertEventOrder) do
    if self.draft.alerts[event] then paths[#paths+1]="alerts.eventColors."..event end
   end
  end
 end
 local y=self.step==4 and 170 or 0
 if self.step==1 or self.step==2 then
  self.compassNote:SetText(self.step==1
   and "Configure your Inner ring first, then Outer ring. Both work independently."
   or "Choose a third ring, Quest Compass, or group Beacon. Beacon uses hidden messages. Combat guidance uses fresh readable position and facing.")
  self.compassNote:ClearAllPoints();self.compassNote:SetPoint("TOPLEFT",self.child,"TOPLEFT",0,0)
  self.compassNote:Show();y=CC.TextLayout:Text(self.compassNote,408,20)+16
 elseif self.step==6 then
  self.alertNote:ClearAllPoints();self.alertNote:SetPoint("TOPLEFT",self.child,"TOPLEFT",0,0)
  self.alertNote:Show();self.testAlert:Show()
  local noteHeight=CC.TextLayout:Text(self.alertNote,408,20)
  self.testAlert:ClearAllPoints();self.testAlert:SetPoint("TOPLEFT",0,-noteHeight-12)
  y=noteHeight+12+self.testAlert:GetHeight()+12
 end
 if self.step==4 then self.bindings.frame:Show();self.bindings:Refresh();y=self.bindings.frame:GetHeight()+12 end
 if self.step==5 then self.fishingBindingWidget.frame:Show();self.fishingBindingWidget:Refresh();y=self.fishingBindingWidget.frame:GetHeight()+12 end
 local descriptors=CC.Settings.descriptors
 if self.step==4 then descriptors={
  {path="palette.enabled",label="Enable quick menu",kind="bool"},
  {path="palette.experimental",label="Enable context menus",kind="bool"},
  {path="palette.style",label="Menu design",kind="choice",values={"Tracker","Aperture","Halo","Facet"}},
 } end
 for _,path in ipairs(paths) do
  for _,d in ipairs(descriptors) do
   if d.path==path and (not d.manualPath or C:Get(self.draft,d.manualPath)=="Manual") then
    local ring=path:match("^rings%.([^.]+)%.")
    local shouldShow=not ring or path:match("%.enabled$") or self.draft.rings[ring].enabled
    if shouldShow then
     local row=self.rows[path]
     if not row then
      local copy=CC:Copy(d)
      if ring=="outer2" then copy.label="Outer Ring 2: "..copy.label
      elseif ring=="outer" then copy.label="Outer ring: "..copy.label
      elseif ring=="inner" then copy.label="Inner ring: "..copy.label end
      row=C:Create(self.child,copy,self);self.rows[path]=row
     end
     row:ClearAllPoints();row:SetPoint("TOPLEFT",0,-y);row:Refresh();row:Show();y=y+row:GetHeight()
     if path=="outside.mode" and self.step==2 and self.draft.compass.enabled then
      self.notesBindingWidget.frame:ClearAllPoints();self.notesBindingWidget.frame:SetPoint("TOPLEFT",self.child,"TOPLEFT",0,-y-8)
      self.notesBindingWidget:Refresh();self.notesBindingWidget.frame:Show();y=y+self.notesBindingWidget.frame:GetHeight()+20
     end
    end
   end
  end
 end
 if (self.step==1 or self.step==2) and ((self.draft.rings.outer.enabled and self.draft.rings.outer.role=="Spell range")
     or (self.draft.rings.inner.enabled and self.draft.rings.inner.role=="Spell range")
     or (self.draft.rings.outer2.enabled and self.draft.rings.outer2.role=="Spell range")) then
  self.spells.frame:ClearAllPoints();self.spells.frame:SetPoint("TOPLEFT",0,-y-12)
  self.spells.frame:Show();self.spells:Refresh();y=y+12+(self.spellHeight or 150)
 end
 if self.step==#self.steps then
  local p=self.draft;local outer=CC.StyleLabels[p.rings.outer.style] or p.rings.outer.style
  local inner=p.rings.inner.enabled and (CC.StyleLabels[p.rings.inner.style] or p.rings.inner.style) or "Off"
  local outer2=p.rings.outer2.enabled and (CC.StyleLabels[p.rings.outer2.style] or p.rings.outer2.style) or "Off"
  self.summary:SetText("Inner ring: "..(p.rings.inner.enabled and ((CC.RoleLabels[p.rings.inner.role] or p.rings.inner.role).." / "..inner) or "Off").."\n\nOuter ring: "..(p.rings.outer.enabled and ((CC.RoleLabels[p.rings.outer.role] or p.rings.outer.role).." / "..outer) or "Off").."\n\nOutside cursor: "..(p.rings.outer2.enabled and ((CC.RoleLabels[p.rings.outer2.role] or p.rings.outer2.role).." / "..outer2) or (p.compass.enabled and (p.compass.mode=="Beacon" and "Beacon (hidden group waypoints)" or "Quest Compass") or "None")).."\n\nQuest Notes: "..(p.compass.enabled and p.compass.mode~="Beacon" and p.questNotes.enabled and "On ("..CC.Bindings:Label(self.notesBindingDraft or CC.Bindings:NotesCurrent())..")" or "Off").."\n\nNavigation shortcut: "..CC.Bindings:Label(self.notesBindingDraft or CC.Bindings:NotesCurrent())..(p.compass.enabled and (p.compass.mode=="Beacon" and " (transmit Beacon)" or " (Quest Notes)") or " (inactive)").."\n\nTrails: "..(p.motion.enabled and p.motion.kind or "Off").." (width "..p.motion.width..")".."\n\nQuick menu: "..(p.palette.enabled and "On" or "Off").."\nShortcut: "..CC.Bindings:Label(self.bindingDraft or CC.Bindings:Current()).."\n\nCustom menus: configure up to four six-slot menus in Quick Menu settings.".."\n\nFishing: "..(p.fishing.enabled and "On; water access uses casting results, press during channel to recast; right-click bobber to catch" or "Off").."\n\nAlerts: "..(p.alerts.enabled and p.alerts.style or "Off").."\n\nFinish saves these settings. You can fine-tune everything later in /cc config under More options.")
  y=CC.TextLayout:Text(self.summary,408,20)
 end
 self.child:SetHeight(math.max(410,y+14));if not keepScroll then self.scroll:SetVerticalScroll(0) end
 self:Notice("");self:Preview();self.rendering=false
end
function W:OpenSpellRange()
 if not self.draft then return end
 local savedDraft=CC:Copy(self.draft)
 if self.frame then self.frame:Hide() end
 self.draft=nil
 CC.Settings:Open()
 CC.Settings.draft=savedDraft
 CC.Settings.fromWizard=true
 CC.Settings.page="Spell range"
 CC.Settings:Render()
 CC.Settings:Preview()
 CC.Settings:Notice("Your wizard changes are in this editor. Choose a spell, then Apply to save.")
end
function W:Finish()
 if not self.draft or CC.Safety:InCombat() then return end
 CC.TrackedSpells:Sync(self.draft.info)
 local valid,why=CC.SavedData:Validate(self.draft,true);if not valid then self:Notice(why);return end
 local bound,problem=CC.Bindings:CommitAllDrafts(self);if not bound then self.step=self.fishingBindingDraft and 5 or self.notesBindingDraft and 2 or 4;self:Render();self:Notice(problem);return end
 local ok,errorText=CC.SavedData:Commit(valid);if not ok then self:Notice(errorText);return end
 CC.SavedData.account.onboarding={completed=true,dismissed=false,version=CC.version}
 self.frame:Hide();self.draft=nil;CC:Print("Setup complete. Use the minimap crosshair to change settings.")
end
function W:Dismiss()
 if CC.SavedData.account and not CC.SavedData.readOnly then
  CC.SavedData.account.onboarding.dismissed=true
 end
 if self.frame then self.frame:Hide() end;self.draft=nil
end
function W:CloseForCombat()
 if self.frame then self.frame:Hide() end
 -- No preferences are committed in combat. Run setup from Home to resume explicitly.
end
