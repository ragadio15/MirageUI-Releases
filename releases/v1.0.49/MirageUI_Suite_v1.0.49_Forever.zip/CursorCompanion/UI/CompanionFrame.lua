local _,CC=...
CC.CompanionFrame={}
function CC.CompanionFrame:Create()
 self.frame=CreateFrame("Frame",nil,CC.VisualLifecycle:OverlayParent());self.frame:SetSize(1,1);self.frame:SetFrameStrata("TOOLTIP");CC.OverlaySafety:MakePassive(self.frame)
 self.layers={inner=CC.RingLayer:Create(self.frame),outer=CC.RingLayer:Create(self.frame),outer2=CC.RingLayer:Create(self.frame)}
 for key,layer in pairs(self.layers) do layer.runtimeSlot=key end
 self.compassLayer=CC.RingLayer:Create(self.frame)
 self.compassLayer.runtimeSlot="compass"
 self.alert=CC.AlertEffects:Create(self.frame)
 CC.NavigationLabel:Create(self.frame)
 CC.Trails:Create(CC.VisualLifecycle:OverlayParent());self:ApplyAppearance();self:Hide()
end
function CC.CompanionFrame:ApplyAppearance()
 CC.NavigationLabel.textKey=nil
 for k,L in pairs(self.layers) do CC.RingLayer:Apply(L,CC.profile.rings[k]) end
 CC.RingLayer:Apply(self.compassLayer,CC.profile.compass)
 CC.AlertEffects:Clear(self.alert)
 CC.Trails:Apply()
end
function CC.CompanionFrame:Hide()
 if CC.Wayfinder then CC.Wayfinder:Release() end
 self.frame:Hide();CC.NavigationLabel:Hide();CC.Trails:Flush()
 if self.alert then CC.AlertEffects:Clear(self.alert) end
end
function CC.CompanionFrame:Place(x,y,dt,idle)
 local p=CC.profile;local s=CC.Context:Get()
 local left,bottom=x+p.offsetX,y+p.offsetY
 if self.left~=left or self.bottom~=bottom then
  self.frame:ClearAllPoints();self.frame:SetPoint("CENTER",UIParent,"BOTTOMLEFT",left,bottom)
  self.left,self.bottom=left,bottom
 end
 self.frame:Show()
 CC.AlertEffects:Tick(self.alert,CC.AlertConditions:EffectConfig(),dt,true)
 if CC.AlertConditions.testConfig and not self.alert.active then CC.AlertConditions.testConfig=nil end
 for k,L in pairs(self.layers) do
  -- A stationary cursor must not hide an active GCD: a keyboard spell can
  -- trigger the GCD after the normal idle-hide delay. Keep *only* its GCD
  -- ring visible while Blizzard supplies timing or a recent cast wakes it.
  local wake = p.rings[k].role=="GCD" and CC.Timing:IsGCDVisibilityNeeded()
  if idle and not wake then L.root:Hide()
  else CC.RingLayer:Update(L,p.rings[k],s,dt,false,p.advanced.contrast,nil) end
 end
 local navigation=CC.Navigation and CC.Navigation:Get() or CC.QuestCompass:Get()
 local shared=CC.Wayfinder and CC.Wayfinder:IsManaged()
 local renderAllowed=not shared or CC.Wayfinder:BeginRender(idle)
 if idle or not renderAllowed then self.compassLayer.root:Hide()
 else CC.RingLayer:Update(self.compassLayer,p.compass,s,math.min(dt,0.1),false,p.advanced.contrast,navigation) end
 local labelOK=pcall(CC.NavigationLabel.Update,CC.NavigationLabel,navigation,p.compass,x+p.offsetX,y+p.offsetY,idle or not renderAllowed)
 if not labelOK then
  CC.NavigationLabel:Hide()
  if not CC.NavigationLabel.faultReported then
   CC.NavigationLabel.faultReported=true;CC.Diagnostics:OptionalFault("NAVIGATION_LABEL_ERROR")
  end
 end
 if shared then CC.Wayfinder:FinishRender() end
 if idle or CC.Palette.shown then CC.Trails:Flush() else CC.Trails:Update(x+p.offsetX,y+p.offsetY,dt) end
end
