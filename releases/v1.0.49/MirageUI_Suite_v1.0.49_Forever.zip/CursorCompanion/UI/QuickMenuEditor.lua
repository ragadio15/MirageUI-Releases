local _,CC=...
CC.QuickMenuEditor={}
local Q,C,M=CC.QuickMenuEditor,CC.Controls,CC.MenuModel
function Q:Create(parent,owner)
 local e={owner=owner,context="main",menu=1,rows={},buttons={}}
 e.frame=CreateFrame("Frame",nil,parent);e.frame:SetSize(410,850)
 local function text(label,y)
  local h=C:Text(e.frame,label,0,-y,"GameFontNormalLarge");h:SetTextColor(.91,.55,.18);return h
 end
 e.behavior=text("Menu behavior",0)
 local function row(path,label,kind,extra)
  local d={path=path,label=label,kind=kind,help=""};for k,v in pairs(extra or {}) do d[k]=v end
  local r=C:Create(e.frame,d,owner);e.rows[#e.rows+1]=r;return r
 end
 e.enabled=row("palette.enabled","Enable quick menu","bool")
 e.contextEnabled=row("palette.experimental","Enable context menus","bool")
 e.autoTarget=row("palette.autoTargetEnemy","Target enemy when opening menu","bool",{help="The gameplay shortcut targets a hostile mouseover using a secure hardware action, without starting an attack. Preview and settings buttons never retarget."})
 e.style=row("palette.style","Menu design","choice",{values={"Tracker","Aperture","Halo","Facet"}})
 e.configuration=text("Menu configuration",140)
 e.contextButton=C:Button(e.frame,"General",183,-174,218,function(button)
  local values=owner.draft.palette.experimental and M.contextOrder or {"main"}
  C:Choose(button,values,M.contextLabels,e.context,function(value)
   e.context=value;e.previewPage=value;e:Refresh();owner:Preview()
  end)
 end)
 e.countButton=C:Button(e.frame,"",183,-212,218,function(button)
  C:Choose(button,{1,2,3,4,5,6,7,8,9},nil,owner.draft.quickMenus[e.context].count,function(value)
   owner.draft.quickMenus[e.context].count=value;e.previewPage=e.context;e:Changed(true)
  end)
 end)
 e.slots={}
 for i=1,9 do
  local index=i;local r={}
  r.label=C:Text(e.frame,"Slot "..i,0,0,"GameFontHighlightSmall")
  r.button=C:Button(e.frame,"",183,0,218,function(button)
   local values,labels=M:Options(owner.draft,e.context)
   C:Choose(button,values,labels,owner.draft.quickMenus[e.context]["slot"..index],function(value)
    owner.draft.quickMenus[e.context]["slot"..index]=value;e.previewPage=e.context;e:Changed(true)
   end)
  end)
  e.slots[i]=r
 end
 e.customHeading=text("Custom menus",400)
 for n=1,4 do local index=n
  e.buttons[n]=C:Button(e.frame,"Menu "..n,(n-1)*102,0,96,function()
   e.menu=index;e.previewPage="custom"..index;e:Refresh();owner:Preview()
  end)
 end
 e.customEnabled=CreateFrame("CheckButton",nil,e.frame,"BackdropTemplate");CC.Skin:Check(e.customEnabled);e.customEnabled:SetSize(22,22)
 e.enabledLabel=C:Text(e.frame,"Enable this custom menu",30,0,"GameFontHighlightSmall")
 e.customEnabled:SetScript("OnClick",function(button)
  owner.draft.customMenus["menu"..e.menu].enabled=button:GetChecked()==true;e.previewPage="custom"..e.menu;e:Changed(true)
 end)
 e.nameLabel=C:Text(e.frame,"Custom menu name",0,0,"GameFontHighlightSmall")
 e.name=CreateFrame("EditBox",nil,e.frame,"BackdropTemplate");CC.Skin:Input(e.name)
 e.name:SetSize(218,24);e.name:SetAutoFocus(false);e.name:SetMaxLetters(20)
 e.name:SetScript("OnTextChanged",function(box,user)
  if user and not e.refreshing then
   owner.draft.customMenus["menu"..e.menu].name=box:GetText();e:RefreshSlotNames();e:Changed(false)
  end
 end)
 e.name:SetScript("OnEnterPressed",function(b)b:ClearFocus()end);e.name:SetScript("OnEscapePressed",function(b)b:ClearFocus()end)
 e.iconLabel=C:Text(e.frame,"Custom menu icon",0,0,"GameFontHighlightSmall")
 e.iconButton=C:Button(e.frame,"",217,0,184,function(button)
  local menu=owner.draft.customMenus["menu"..e.menu]
  local icons={};for _,key in ipairs(M.iconOrder) do icons[key]=M:Icon(key) end
  C:Choose(button,M.iconOrder,M.iconLabels,menu.icon,function(key) menu.icon=key;e:Changed(true) end,icons)
 end)
 e.icon=e.frame:CreateTexture(nil,"ARTWORK");e.icon:SetSize(26,26)
 e.editor=CC.Utility:CreateEditor(e.frame,owner);e.editor.menuIndex=1
 e.editor.onSelect=function()e.previewPage="custom"..e.menu;owner:Preview()end
 e.editor.onLayout=function()if not e.refreshing then e:Refresh() end end
 e.note=C:Text(e.frame,"Each menu has six programmable slots for spells, items, macros, pings, native windows or target markers. Add its name to a General, Friendly player or Enemy target slot above. Preview clicks never execute game actions. Apply saves all four menus.",0,0,"GameFontHighlightSmall");e.note:SetWidth(402)
 function e:Changed(layout)
  self.owner:Notice("Changes not saved yet. Apply prepares all four menus for gameplay.")
  if layout then self:Refresh() end
  self.owner:Preview()
 end
 function e:RefreshSlotNames()
  local _,labels=M:Options(self.owner.draft,self.context)
  local cfg=self.owner.draft.quickMenus[self.context]
  for i,r in ipairs(self.slots) do r.button:SetText(labels[cfg["slot"..i]] or "Empty") end
 end
 function e:Refresh()
  if not self.owner.draft or self.refreshing then return end
  self.refreshing=true
  if not self.owner.draft.palette.experimental and self.context~="main" then self.context="main";self.previewPage="main" end
  local y=34
  for _,r in ipairs(self.rows) do r:ClearAllPoints();r:SetPoint("TOPLEFT",0,-y);r:Refresh();r:Show();y=y+r:GetHeight() end
  self.configuration:ClearAllPoints();self.configuration:SetPoint("TOPLEFT",0,-y-12);y=y+48
  -- Labels follow dynamic row heights so localization cannot overlap sections.
  self.contextButton:ClearAllPoints();self.contextButton:SetPoint("TOPLEFT",183,-y)
  if not self.typeLabel then self.typeLabel=C:Text(self.frame,"Menu type",0,0,"GameFontHighlightSmall") end
  self.typeLabel:ClearAllPoints();self.typeLabel:SetPoint("TOPLEFT",0,-y-6)
  self.contextButton:SetText(M.contextLabels[self.context]);y=y+38
  self.countButton:ClearAllPoints();self.countButton:SetPoint("TOPLEFT",183,-y)
  if not self.countLabel then self.countLabel=C:Text(self.frame,"Number of buttons",0,0,"GameFontHighlightSmall") end
  self.countLabel:ClearAllPoints();self.countLabel:SetPoint("TOPLEFT",0,-y-6)
  local cfg=self.owner.draft.quickMenus[self.context];self.countButton:SetText(tostring(cfg.count));y=y+38
  self:RefreshSlotNames()
  for i,r in ipairs(self.slots) do
   r.label:SetShown(i<=cfg.count);r.button:SetShown(i<=cfg.count)
   if i<=cfg.count then
    r.label:ClearAllPoints();r.label:SetPoint("TOPLEFT",0,-y-6);r.button:ClearAllPoints();r.button:SetPoint("TOPLEFT",183,-y)
    y=y+math.max(36,r.button:GetHeight()+10)
   end
  end
  y=y+18;self.customHeading:ClearAllPoints();self.customHeading:SetPoint("TOPLEFT",0,-y);y=y+34
  for i,button in ipairs(self.buttons) do
   button:ClearAllPoints();button:SetPoint("TOPLEFT",(i-1)*102,-y);CC.Skin:Select(button,i==self.menu)
  end
  y=y+42
  local menu=self.owner.draft.customMenus["menu"..self.menu]
  self.customEnabled:ClearAllPoints();self.customEnabled:SetPoint("TOPLEFT",0,-y);self.customEnabled:SetChecked(menu.enabled)
  self.enabledLabel:ClearAllPoints();self.enabledLabel:SetPoint("TOPLEFT",30,-y-5);y=y+38
  self.nameLabel:ClearAllPoints();self.nameLabel:SetPoint("TOPLEFT",0,-y-5);self.name:ClearAllPoints();self.name:SetPoint("TOPLEFT",183,-y)
  if not self.name:HasFocus() then self.name:SetText(menu.name) end;y=y+38
  self.iconLabel:ClearAllPoints();self.iconLabel:SetPoint("TOPLEFT",0,-y-5);self.iconButton:ClearAllPoints();self.iconButton:SetPoint("TOPLEFT",217,-y)
  self.iconButton:SetText(M.iconLabels[menu.icon]);self.icon:ClearAllPoints();self.icon:SetPoint("TOPLEFT",183,-y);self.icon:SetTexture(M:Icon(menu.icon));y=y+46
  self.editor.menuIndex=self.menu;self.editor.frame:ClearAllPoints();self.editor.frame:SetPoint("TOPLEFT",0,-y)
  self.editor.frame:Show();self.editor:Refresh();y=y+self.editor.frame:GetHeight()+18
  self.note:ClearAllPoints();self.note:SetPoint("TOPLEFT",0,-y);y=y+CC.TextLayout:Text(self.note,402,40)+16
  self.frame:SetHeight(y);self.refreshing=false
  if not self.owner.rendering then self.owner:Render(true) end
 end
 return e
end
