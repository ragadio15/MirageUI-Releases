local _,CC=...
local U=CC.Utility
local kindLabels={item="Item",spell="Spell / ability",macro="Custom macro",preset="Cursor Companion preset",ping="Pings",system="System menu",marker="Target marker"}
local targetLabels={none="Game default (recommended)",target="Current target (automatic)",player="Your character",focus="Focus",mouseover="Current mouseover"}
local presetLabels={pings="Pings",eat="Eat",drink="Drink"}
function U:ReadCursorAction()
 if type(GetCursorInfo)~="function" then return nil end
 local ok,kind,id,_,spellID=pcall(GetCursorInfo)
 if not ok or not CC.Safety:IsText(kind) then return nil end
 if kind=="item" and CC.Safety:IsNumber(id) and id>0 then return "item",tostring(id) end
 if kind=="spell" then
  -- The second return is a spellbook slot, never a substitute for a spell ID.
  if CC.Safety:IsNumber(spellID) and spellID>0 then return "spell",tostring(spellID) end
  return nil,nil,"This client did not provide a spell ID for the dragged action. Enter the spell's full name or ID instead."
 end
 if kind=="macro" and CC.Safety:IsNumber(id) and type(GetMacroInfo)=="function" then
  local loaded,name=pcall(GetMacroInfo,id)
  if loaded and CC.Safety:IsText(name) and name~="" then return "macro","macro:"..name end
 end
end
function U:CreateEditor(parent,owner)
 local C=CC.Controls;local editor={owner=owner,selected=1,buttons={},menuIndex=1}
 local frame=CreateFrame("Frame",nil,parent);editor.frame=frame;frame:SetSize(410,485)
 local heading=C:Text(frame,"Menu actions",0,0,"GameFontNormalLarge");heading:SetTextColor(.91,.55,.18)
 local intro=C:Text(frame,"Choose a slot, give it a short label, then assign its action. Apply saves all Custom Menus.",0,-29,"GameFontHighlightSmall");intro:SetWidth(405)
 function editor:Slot()
  local draft=self.owner.draft
  local menu=draft and draft.customMenus and draft.customMenus["menu"..self.menuIndex]
  return menu and menu["slot"..self.selected]
 end
 function editor:Changed()
  if self.refreshing then return end
  self.owner:Notice("Custom Menu changes are not saved yet. Choose Apply when ready.")
  self:Status();if self.onSelect then self.onSelect() end;self.owner:Preview()
 end
 function editor:Status()
  local slot=self:Slot();if not slot then return end
  local _,errorText=U:ValidateSlot(slot,true)
  if errorText then self.status:SetText(errorText);self.status:SetTextColor(1,.54,.35);return end
  if not slot.enabled then self.status:SetText("This slot is disabled. Enable it to show the button in this menu.");self.status:SetTextColor(.7,.69,.67);return end
  local compiled=U:CompileSlot(slot,self.selected)
  local text=compiled.ready and (compiled.itemName or compiled.spellName or compiled.macroName or "Action configured") or compiled.reason or "Unavailable"
  if slot.kind=="macro" and slot.value:sub(1,6)~="macro:" then text=text.."  ("..#slot.value.." / 255 bytes)" end
  self.status:SetText(text);self.status:SetTextColor(compiled.ready and .65 or 1,compiled.ready and .86 or .65,compiled.ready and .66 or .35)
 end
 for i=1,6 do
  local index=i
  editor.buttons[i]=C:Button(frame,"Slot "..i,(i-1)*68,-72,62,function()
   editor.selected=index;editor:Refresh();if editor.onSelect then editor.onSelect() end
  end)
 end
 editor.enabled=CreateFrame("CheckButton",nil,frame,"BackdropTemplate");editor.enabled:SetSize(22,22);editor.enabled:SetPoint("TOPLEFT",0,-112);CC.Skin:Check(editor.enabled)
 C:Text(frame,"Show this slot",30,-115,"GameFontHighlightSmall")
 editor.enabled:SetScript("OnClick",function(button) local slot=editor:Slot();if slot then slot.enabled=button:GetChecked()==true;editor:Changed() end end)
 C:Text(frame,"Label (10 characters)",0,-151,"GameFontHighlightSmall")
 local label=CreateFrame("EditBox",nil,frame,"BackdropTemplate");editor.label=label;CC.Skin:Input(label)
 label:SetSize(218,24);label:SetPoint("TOPLEFT",183,-145);label:SetAutoFocus(false);label:SetMaxLetters(10)
 label:SetScript("OnTextChanged",function(box,user) if user and not editor.refreshing then local slot=editor:Slot();if slot then slot.label=box:GetText();editor:Changed() end end end)
 label:SetScript("OnEnterPressed",function(box) box:ClearFocus() end);label:SetScript("OnEscapePressed",function(box) box:ClearFocus() end)
 C:Text(frame,"Action type",0,-187,"GameFontHighlightSmall")
 editor.kind=C:Button(frame,"",183,-181,218,function(button)
  local slot=editor:Slot();if not slot then return end
  C:Choose(button,{"item","spell","macro","preset","ping","system","marker"},kindLabels,slot.kind,function(kind)
   if slot.kind~=kind then slot.kind=kind;slot.value=kind=="preset" and "pings" or kind=="ping" and "contextual" or kind=="system" and "character" or kind=="marker" and "8" or "";slot.target="none" end
   editor:Changed();editor:Refresh()
  end)
 end)
 editor.valueLabel=C:Text(frame,"Item ID or name",0,-220,"GameFontHighlightSmall")
 local scroll=CC.Skin:Scroll(frame);editor.valueScroll=scroll;scroll:SetPoint("TOPLEFT",0,-244);scroll:SetSize(400,92)
 local value=CreateFrame("EditBox",nil,scroll,"BackdropTemplate");editor.value=value;CC.Skin:Input(value)
 value:SetSize(382,92);value:SetMultiLine(true);value:SetAutoFocus(false);value:SetMaxLetters(512);scroll:SetScrollChild(value)
 if value.SetFontObject then value:SetFontObject(ChatFontNormal or "ChatFontNormal") end
 if value.SetTextInsets then value:SetTextInsets(8,8,7,7) end
 value:SetScript("OnTextChanged",function(box,user) if user and not editor.refreshing then local slot=editor:Slot();if slot then slot.value=box:GetText();editor:Changed() end end end)
 value:SetScript("OnEscapePressed",function(box) box:ClearFocus() end)
 value:SetScript("OnTabPressed",function(box) box:ClearFocus();editor.label:SetFocus() end)
 CC.TextLayout:EditBox(value,scroll)
 editor.preset=C:Button(frame,"Pings",183,-216,218,function(button)
  local slot=editor:Slot();if not slot then return end
  local M=CC.MenuModel
  local values=slot.kind=="ping" and M.pingOrder or slot.kind=="system" and M.systemOrder or slot.kind=="marker" and M.markerOrder or {"pings","eat","drink"}
  local labels=slot.kind=="ping" and M.pingLabels or slot.kind=="system" and M.systemLabels or slot.kind=="marker" and M.markerLabels or presetLabels
  C:Choose(button,values,labels,slot.value,function(preset) slot.value=preset;editor:Changed();editor:Refresh() end)
 end)
 function editor:AcceptCursor()
  local slot=self:Slot();if not slot then return end
  local kind,valueText,reason=U:ReadCursorAction()
  if not valueText then self.owner:Notice(reason or "Drag an item, learned spell, or existing macro onto Use dragged action.");return end
  slot.kind=kind;slot.value=valueText
  if type(ClearCursor)=="function" then ClearCursor() end
  self:Changed();self:Refresh()
 end
 editor.pick=C:Button(frame,"Use dragged action",0,-349,194,function() editor:AcceptCursor() end)
 editor.pick:SetScript("OnReceiveDrag",function() editor:AcceptCursor() end)
 value:SetScript("OnReceiveDrag",function() editor:AcceptCursor() end)
 editor.clear=C:Button(frame,"Clear slot",210,-349,191,function()
  local slot=editor:Slot();if slot then slot.enabled=false;slot.label="";slot.value="";slot.kind="item";slot.target="none";editor:Changed();editor:Refresh() end
 end)
 editor.targetLabel=C:Text(frame,"Use on",0,-390,"GameFontHighlightSmall")
 editor.target=C:Button(frame,"",183,-384,218,function(button)
  local slot=editor:Slot();if not slot then return end
  local signal=slot.kind=="ping" or slot.kind=="marker"
  local labels=CC:Copy(targetLabels);if signal then labels.none="Menu subject / current target";labels.target="Current target";labels.cursor="Ground under cursor" end
  local values=signal and {"none","target","player","focus","mouseover"} or {"none","player","focus","mouseover"}
  if slot.kind=="ping" then values[#values+1]="cursor" end
  C:Choose(button,values,labels,slot.target,function(target) slot.target=target;editor:Changed();editor:Refresh() end)
 end)
 editor.help=C:Text(frame,"",0,-425,"GameFontHighlightSmall");editor.help:SetWidth(402)
 editor.status=C:Text(frame,"",0,-470,"GameFontHighlightSmall");editor.status:SetWidth(402)
 function editor:Refresh()
  local slot=self:Slot();if not slot then return end
  self.refreshing=true
  for i,button in ipairs(self.buttons) do CC.Skin:Select(button,i==self.selected) end
  self.enabled:SetChecked(slot.enabled);self.label:SetText(slot.label or "");self.value:SetText(slot.value or "")
  self.kind:SetText(kindLabels[slot.kind] or "Item");self.target:SetText(targetLabels[slot.target] or "Current target")
  local isPing=slot.kind=="ping"
  local isMarker=slot.kind=="marker";local isSystem=slot.kind=="system";local signal=isPing or isMarker
  local labels=isPing and CC.MenuModel.pingLabels or isMarker and CC.MenuModel.markerLabels or isSystem and CC.MenuModel.systemLabels or presetLabels
  self.preset:SetText(labels[slot.value] or "Choose action")
  if signal and slot.target=="none" then self.target:SetText("Menu subject / current target") elseif slot.target=="cursor" then self.target:SetText("Ground under cursor") end
  local isPreset=slot.kind=="preset" or signal or isSystem;local isMacro=slot.kind=="macro"
  self.preset:SetShown(isPreset);self.valueScroll:SetShown(not isPreset);self.pick:SetShown(not isPreset)
  self.target:SetShown(signal or (not isPreset and not isMacro));self.targetLabel:SetShown(signal or (not isPreset and not isMacro))
  self.valueLabel:SetText(isPing and "Native ping" or isMarker and "Target marker" or isSystem and "System menu" or isPreset and "Preset" or isMacro and "Macro text or macro:ExactName" or slot.kind=="spell" and "Spell ID or full spell name" or "Item ID or full item name")
  self.help:SetText(isPing and "Assist is Blizzard's support ping. By default the signal follows the menu subject/current target, not the menu cursor. Choose Ground under cursor explicitly for terrain pings. Blizzard controls acceptance and cooldowns."
   or isMarker and "Attaches the selected native raid icon to the menu subject/current target. These are unit markers, not ground world markers. Native permissions apply; Clear removes that unit's icon."
   or isSystem and "Opens the selected native window (or Cursor Companion settings) only from a gameplay click. Windows restricted in combat are clearly unavailable; preview clicks remain cosmetic." or isPreset and "Eat and Drink choose the highest usable recognized standard food or water in your bags. Unknown items and food with extra buffs are excluded. Pings opens Blizzard's five ping choices."
   or isMacro and "Paste supported /commands on separate lines, including custom addon commands, or enter macro:ExactName. Your button runs the macro only when clicked. Maximum 255 bytes."
   or "Game default casts like /cast Spell Name: no selected target is required. Explicit Player, Focus and Mouseover overrides need that unit. Existing F8 'Current target' assignments use Game default automatically.")
  self.help:ClearAllPoints();self.help:SetPoint("TOPLEFT",0,-425)
  local helpHeight=CC.TextLayout:Text(self.help,402,36)
  self.status:ClearAllPoints();self.status:SetPoint("TOPLEFT",0,-425-helpHeight-12)
  self:Status();local statusHeight=CC.TextLayout:Text(self.status,402,28)
  self.frame:SetHeight(425+helpHeight+12+statusHeight+12)
  self.refreshing=false
  if self.onLayout then self.onLayout() end
 end
 editor.Render=editor.Refresh
 return editor
end
