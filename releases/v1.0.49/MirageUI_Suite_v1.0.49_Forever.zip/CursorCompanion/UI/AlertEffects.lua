local _,CC=...
CC.AlertEffects={}
local E=CC.AlertEffects
local media="Interface\\AddOns\\CursorCompanion\\Media\\"
local contextColors={
 combatStart={1,.56,.18},combatEnd={.36,.83,.60},playerCastStart={.96,.79,.36},playerCastInterrupted={1,.36,.29},
 playerCastFailed={1,.61,.24},playerDead={1,.20,.20},targetChanged={.55,.77,1},encounterStart={.98,.62,.22},
 encounterEnd={.34,.87,.64},preview={.82,.68,1}}
local function effectTint(condition,cfg)
 local brand=CC.MUIColorPresets and CC.MUIColorPresets[cfg.colorMode]
 if brand then return {r=brand.r,g=brand.g,b=brand.b} end
 if cfg.colorMode=="Contextual" then
  local selected=cfg.eventColors and cfg.eventColors[condition]
  if selected and type(selected.r)=="number" and type(selected.g)=="number" and type(selected.b)=="number" then return {r=selected.r,g=selected.g,b=selected.b} end
  local fallback=contextColors[condition] or contextColors.preview;return {r=fallback[1],g=fallback[2],b=fallback[3]}
 end
 return cfg.color
end
local function texture(n,name) if n.ccImage~=name then n:SetTexture(media..name..".tga");n.ccImage=name end end
function E:Create(parent)
 local root=CreateFrame("Frame",nil,parent);root:SetSize(1,1);root:SetPoint("CENTER",parent,"CENTER");CC.OverlaySafety:MakePassive(root)
 local o={root=root,nodes={},active=false,elapsed=0}
 for i=1,16 do
  local t=root:CreateTexture(nil,"OVERLAY");t:SetPoint("CENTER",root,"CENTER");t:SetTexture(media..(i<=3 and "HaloRing.tga" or "TrailDot.tga"));t:SetBlendMode("ADD");t:Hide();o.nodes[i]=t
 end
 root:Hide();return o
end
function E:Clear(o)
 if not o then return end;o.active=false;o.elapsed=0;o.tint=nil;o.root:Hide();for _,t in ipairs(o.nodes) do t:Hide() end
end
function E:Fire(o,condition,cfg)
 if not o or not cfg.enabled then return end;o.active=true;o.elapsed=0;o.condition=condition;o.tint=effectTint(condition,cfg);o.root:Show()
end
function E:Tick(o,cfg,dt,visible)
 if not o or not o.active then return end
 if not cfg.enabled or not visible then self:Clear(o);return end
 o.elapsed=o.elapsed+math.min(.1,dt);if o.elapsed>=cfg.duration then self:Clear(o);return end
 local t=o.elapsed/cfg.duration;local a=(1-t)*cfg.opacity;local radius=cfg.size;local color=o.tint or cfg.color
 for i,n in ipairs(o.nodes) do
  local use=false;local x,y,w,h,alpha=0,0,0,0,a
  if cfg.style=="Aperture" and i<=8 then
   if i<=6 then
    local angle=(i-1)*math.pi/3+t*math.pi*.75;local distance=radius*(.16+.28*t)
    x,y=math.cos(angle)*distance,math.sin(angle)*distance;w,h=radius*.18,radius*.18
    alpha=a*(.62+.30*math.sin(math.pi*t));texture(n,"AlertChevron");n:SetRotation(angle+math.pi/2);use=true
   else
    local wave=(t+(i-7)*.34)%1;local side=radius*(.42+wave*.88)
    w,h=side,side;alpha=a*(1-wave)*.32;texture(n,"HaloRing");n:SetRotation(0);use=true
   end
  elseif cfg.style=="Crosswave" and i<=6 then
   if i<=4 then
    local angle=(i-1)*math.pi/2;local distance=radius*(.10+.22*t)
    x,y=math.cos(angle)*distance,math.sin(angle)*distance;w=math.max(2,radius*.055);h=radius*(.44-.12*t)
    alpha=a*(.54+.36*math.sin(math.pi*t));texture(n,"AlertRay");n:SetRotation(angle+math.pi/2);use=true
   else
    local wave=(t+(i-5)*.45)%1;local side=radius*(.30+wave*1.10)
    w,h=side,side;alpha=a*(1-wave)*.52;texture(n,"AlertArc");n:SetRotation((i-5)*math.pi);use=true
   end
  elseif cfg.style=="Nova" and i<=13 then
   if i<=12 then
    local angle=(i-1)*math.pi/6;local distance=radius*(.12+.68*t)
    x,y=math.cos(angle)*distance,math.sin(angle)*distance;local side=math.max(3,radius*(.055+.025*(1-t)))
    w,h=side,side;alpha=a*(.52+.42*(1-t));texture(n,"AlertDiamond");n:SetRotation(angle);use=true
   else
    local side=radius*(.52+t*.72);w,h=side,side;alpha=a*.22;texture(n,"HaloGlow");n:SetRotation(0);use=true
   end
  elseif cfg.style=="Heartbeat" and i<=3 then
   local beat=math.max(0,1-math.abs(t-.19)/.16)+.6*math.max(0,1-math.abs(t-.44)/.11);local side=radius*(.43+.25*beat+(i-1)*.13)
   w,h=side,side;alpha=a*(i==3 and .17 or (.42+.42*beat)*(i==1 and 1 or .6));texture(n,i==3 and "HaloGlow" or "HaloRing");n:SetRotation(0);use=true
  elseif cfg.style=="Prism" and i<=14 then
   if i<=8 then
    local angle=(i-1)*math.pi/4;local distance=radius*(.17+.28*t);x,y=math.cos(angle)*distance,math.sin(angle)*distance
    w,h=math.max(2,radius*.043),radius*(.25-.09*t);alpha=a*(.48+.52*math.sin(math.pi*t));texture(n,"AlertRay");n:SetRotation(angle+math.pi/2);use=true
   elseif i<=12 then
    local angle=(i-9)*math.pi/2+math.pi/4;local distance=radius*(.24+.37*t);x,y=math.cos(angle)*distance,math.sin(angle)*distance
    w,h=math.max(2,radius*.056),math.max(2,radius*.056);alpha=a*.85;texture(n,"AlertSpark");n:SetRotation(0);use=true
   else
    local side=radius*(.45+t*.55+(i-13)*.15);w,h=side,side;alpha=a*(1-t)*.27;texture(n,"HaloRing");n:SetRotation(0);use=true
   end
  elseif cfg.style=="Ripple" and i<=3 then
   local wave=(t+(i-1)/3)%1;local side=radius*(.30+wave*1.4);w,h=side,side;alpha=a*(1-wave)*.90;use=true;texture(n,"HaloRing");n:SetRotation(0)
  elseif cfg.style=="Beacon" and i<=9 then
   if i<=3 then
    local wave=(t+(i-1)*.26)%1;w,h=radius*(.32+wave*.92),radius*(.32+wave*.92);alpha=a*(1-wave)*.84;texture(n,"HaloRing");n:SetRotation(0);use=true
   else
    local angle=(i-4)*math.pi/3;local rr=radius*(.22+t*.28);x,y=math.cos(angle)*rr,math.sin(angle)*rr
    w,h=math.max(2,radius*.052),radius*(.21+.12*(1-t));alpha=a*.75;texture(n,"AlertRay");n:SetRotation(angle+math.pi/2);use=true
   end
  elseif cfg.style=="Pulse" and i<=3 then
   local wave=((t+(i-1)/3)%1);local side=radius*(.35+wave*1.3);w,h=side,side;alpha=a*(1-wave);use=true;texture(n,"HaloRing");n:SetRotation(0)
  elseif cfg.style=="Glow" and i<=3 then
   local side=radius*(.8+t*.5);w,h=side,side;alpha=a*(i==1 and .7 or .18);use=true;texture(n,"HaloGlow");n:SetRotation(0)
  elseif cfg.style=="Burst" and i<=12 then
   local angle=(i-1)*math.pi/6;local r=radius*(.2+t*.55);x,y=math.cos(angle)*r,math.sin(angle)*r
   w,h=math.max(2,cfg.size*.07),radius*(.18+.15*(1-t));texture(n,"AlertRay");n:SetRotation(angle+math.pi/2);use=true
  elseif cfg.style=="Sparks" and i<=16 then
   local angle=(i-1)*math.pi/8;local r=radius*(.12+.85*t);x,y=math.cos(angle)*r,math.sin(angle)*r
   w,h=math.max(2,radius*.055),math.max(2,radius*.055);texture(n,"AlertSpark");n:SetRotation(0);use=true
  end
  if use then n:ClearAllPoints();n:SetPoint("CENTER",o.root,"CENTER",x,y);n:SetSize(w,h);n:SetVertexColor(color.r,color.g,color.b,alpha);n:Show() else n:Hide() end
 end
end
