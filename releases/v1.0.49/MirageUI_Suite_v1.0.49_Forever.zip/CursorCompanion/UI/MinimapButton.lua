local _,CC=...
-- P10 uses the MirageUI Addons menu as the single suite launcher. Retain this
-- small adapter for saved profiles and lifecycle callers; it creates no frames
-- and has no periodic work. Imported legacy launcher flags cannot resurrect a
-- second minimap icon. /cc config remains available independently of the map.
CC.Minimap={visibilityReason="SUITE_MENU",blocked=true}
local M=CC.Minimap
local function retire(self)
 if self.controller then self.controller:SetScript("OnUpdate",nil);self.controller:Hide() end
 if self.button then
  self.button:SetScript("OnUpdate",nil)
  self.button:EnableMouse(false)
  self.button:Hide()
 end
 self.angle=nil;self.elapsed=0;self.blocked=true;self.visibilityReason="SUITE_MENU"
end
function M:MapAvailable() return false,"SUITE_MENU" end
function M:StopDrag() retire(self) end
function M:Place() end
function M:Sync() retire(self) end
function M:Refresh() retire(self) end
function M:Create() retire(self) end
