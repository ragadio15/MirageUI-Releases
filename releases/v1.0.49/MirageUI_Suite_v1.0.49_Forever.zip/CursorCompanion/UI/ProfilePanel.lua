local _,CC=...
-- v2.5.1: a permanently anchored, scrollable profile workspace.
-- Named snapshots are saved data, not executable imports or automatic activations.
CC.ProfilePanel={selected=nil,pageIndex=1,pageSize=3}
local U=CC.ProfilePanel
local C=CC.Controls
local function same(a,b)
 if type(a)~=type(b) then return false end
 if type(a)~="table" then return a==b end
 for k,v in pairs(a) do if not same(v,b[k]) then return false end end
 for k in pairs(b) do if a[k]==nil then return false end end
 return true
end
function U:Notify(message)
 if self.status then self.status:SetText(message or "");self:Layout() end
 if CC.Settings and CC.Settings.Notice then CC.Settings:Notice(message or "") end
end
function U:Current()
 -- Capture exactly the values currently displayed in configuration, even if
 -- they have not been applied to gameplay yet. Never mutate the editor draft.
 local source=CC.Settings and CC.Settings.draft or CC.profile
 return CC.SavedData:Validate(source,true)
end
function U:EditorDirty()
 return CC.Settings and CC.Settings.draft and not same(CC.Settings.draft,CC.profile)
end
function U:ClearConfirmation()
 local pending=self.pendingDelete or self.pendingReplace or self.pendingOpen
 self.pendingDelete=nil;self.pendingReplace=nil;self.pendingOpen=nil
 if pending then self:Notify("") end
end
function U:Select(name)
 self.selected=name;self.pendingDelete=nil;self.pendingReplace=nil;self.pendingOpen=nil
 for index,current in ipairs(CC.Profiles:Names()) do
  if name==current then self.pageIndex=math.ceil(index/self.pageSize);break end
 end
 self:Refresh()
end
function U:CreateNew()
 local name,why=CC.Profiles:Name(self.name:GetText())
 if not name then self:Notify(why);return false end
 local snapshot,err=self:Current();if not snapshot then self:Notify(err);return false end
 local ok,message=CC.Profiles:Save(name,snapshot,false)
 if ok then self:Select(name) end
 self:Notify(message)
 return ok
end
function U:SaveSelected()
 local name=self.selected
 if not name then self:Notify("Select an existing profile to update.");return false end
 if self.pendingReplace~=name then
  self.pendingReplace=name;self.pendingOpen=nil;self.pendingDelete=nil
  self:Notify("Click Save selected again to replace '"..name.."' with the current editor settings.")
  return false
 end
 self.pendingReplace=nil
 local snapshot,err=self:Current();if not snapshot then self:Notify(err);return false end
 local ok,message=CC.Profiles:Save(name,snapshot,true)
 self:Refresh();self:Notify(message)
 return ok
end
function U:OpenSelected()
 local name=self.selected
 if not name then self:Notify("Select a saved profile to open.");return false end
 if self:EditorDirty() and self.pendingOpen~=name then
  self.pendingOpen=name;self.pendingReplace=nil;self.pendingDelete=nil
  self:Notify("Unapplied editor changes will be lost. Click Open selected again to continue.")
  return false
 end
 self.pendingOpen=nil
 local ok,why=CC.Profiles:Load(name)
 if ok then
  CC.Settings.draft=CC:Copy(CC.profile)
  CC.Settings:Render(true);CC.Settings:Preview()
  self:Refresh()
 end
 self:Notify(ok and "Opened '"..name.."' and applied it to the active settings." or why)
 return ok
end
function U:CopySelected()
 if not self.selected then self:Notify("Select a saved profile to duplicate.");return false end
 local raw=self.name:GetText()
 local ok,why=CC.Profiles:Copy(self.selected,raw)
 if ok then self:Select(CC.Profiles:Name(raw)) end
 self:Notify(why);return ok
end
function U:DeleteSelected()
 local name=self.selected
 if not name then self:Notify("Select a saved profile to delete.");return false end
 if self.pendingDelete~=name then
  self.pendingDelete=name;self.pendingOpen=nil;self.pendingReplace=nil
  self:Notify("Click Delete selected again to permanently remove '"..name.."'.")
  return false
 end
 local ok,why=CC.Profiles:Remove(name)
 if ok then self.selected=nil;self.pendingDelete=nil;self:Refresh() end
 self:Notify(why);return ok
end
function U:ExportCurrent()
 local snapshot,why=self:Current()
 if not snapshot then self:Notify(why);return end
 local code,err=CC.Profiles:Export(snapshot)
 if not code then self:Notify(err);return end
 self:OpenExchange("export",code)
end
function U:ExportSelected()
 local library=CC.Profiles:Library()
 local profile=library and self.selected and library[self.selected]
 if not profile then self:Notify("Select a saved profile to export.");return end
 local code,why=CC.Profiles:Export(profile)
 if not code then self:Notify(why);return end
 self:OpenExchange("export",code)
end
function U:Create(parent)
 if self.frame then return end
 local f=CreateFrame("Frame",nil,parent);self.frame=f
 -- A second click confirms only the currently visible profile workspace.
 -- Closing, changing pages or rebuilding the editor ends that interaction.
 f:SetScript("OnHide",function() self:ClearConfirmation() end)
 f:SetSize(404,520)
 -- v2.5.0 missed this anchor: the page was created and shown, but never laid out.
 f:SetPoint("TOPLEFT",parent,"TOPLEFT",0,0)
 C:Text(f,"PROFILES",0,-5,"GameFontNormal"):SetTextColor(.91,.55,.18)
 local intro=C:Text(f,"Create, open and share your cursor layouts. Profiles are kept separately from the active configuration.",0,-30,"GameFontHighlightSmall")
 intro:SetWidth(392);self.intro=intro
 self.currentHeading=C:Text(f,"CURRENT SETTINGS",0,-74,"GameFontNormalSmall");self.currentHeading:SetTextColor(.91,.55,.18)
 self.nameLabel=C:Text(f,"Name for a new profile or duplicate",0,-96,"GameFontHighlightSmall")
 local entry=CreateFrame("EditBox",nil,f,"BackdropTemplate");self.name=entry
 CC.Skin:Input(entry);entry:SetSize(392,25);entry:SetPoint("TOPLEFT",0,-117)
 entry:SetAutoFocus(false);entry:SetMaxLetters(32)
 entry:SetScript("OnEscapePressed",function(b) b:ClearFocus() end)
 entry:SetScript("OnEnterPressed",function(b) b:ClearFocus();self:CreateNew() end)
 self.save=C:Button(f,"Create from current",0,-153,190,function() self:CreateNew() end)
 self.replace=C:Button(f,"Save selected",202,-153,190,function() self:SaveSelected() end)
 C:Tip(self.save,"Save the currently visible configuration, including unapplied editor changes, without changing gameplay.")
 C:Tip(self.replace,"Update an existing named profile with the current editor settings. Requires confirmation.")
 self.exchangeHeading=C:Text(f,"IMPORT / EXPORT",0,-197,"GameFontNormalSmall");self.exchangeHeading:SetTextColor(.91,.55,.18)
 self.exportActive=C:Button(f,"Export current",0,-220,123,function() self:ExportCurrent() end)
 self.export=C:Button(f,"Export selected",134,-220,123,function() self:ExportSelected() end)
 self.import=C:Button(f,"Import code",268,-220,124,function() self:OpenExchange("import","") end)
 self.counter=C:Text(f,"SAVED PROFILES",0,-266,"GameFontNormalSmall");self.counter:SetTextColor(.91,.55,.18)
 self.rows={}
 for i=1,self.pageSize do
  self.rows[i]=C:Button(f,"",0,-286-(i-1)*30,392,function()
   if self.rows[i].profileName then self:Select(self.rows[i].profileName) end
  end)
 end
 self.prev=C:Button(f,"Previous",0,-383,110,function() self.pageIndex=math.max(1,self.pageIndex-1);self:Select(nil) end)
 self.pageLabel=C:Text(f,"",158,-389,"GameFontHighlightSmall");self.pageLabel:SetWidth(86)
 self.next=C:Button(f,"Next",283,-383,109,function() self.pageIndex=self.pageIndex+1;self:Select(nil) end)
 self.load=C:Button(f,"Open selected",0,-419,124,function() self:OpenSelected() end)
 self.copy=C:Button(f,"Duplicate as new",134,-419,124,function() self:CopySelected() end)
 self.delete=C:Button(f,"Delete selected",268,-419,124,function() self:DeleteSelected() end)
 local help=C:Text(f,"Create and export use the settings shown in this window. Open applies a saved layout. Import saves a new named profile but never opens it automatically.",0,-457,"GameFontHighlightSmall")
 help:SetWidth(394);self.pageHelp=help
 self.status=C:Text(f,"",0,-505,"GameFontHighlightSmall");self.status:SetWidth(394)
 self:Refresh()
end
function U:Layout()
 if not self.status then return end
 local function place(object,x,y) object:ClearAllPoints();object:SetPoint("TOPLEFT",self.frame,"TOPLEFT",x,-y) end
 local function group(objects,xs,y,gap)
  local height=0
  for i,object in ipairs(objects) do place(object,xs[i],y);height=math.max(height,object:GetHeight()) end
  return y+height+(gap or 12)
 end
 local y=30
 place(self.intro,0,y);y=y+CC.TextLayout:Text(self.intro,392,18)+18
 place(self.currentHeading,0,y);y=y+CC.TextLayout:Text(self.currentHeading,392,16)+8
 place(self.nameLabel,0,y);y=y+CC.TextLayout:Text(self.nameLabel,392,16)+7
 place(self.name,0,y);y=y+self.name:GetHeight()+11
 y=group({self.save,self.replace},{0,202},y,18)
 place(self.exchangeHeading,0,y);y=y+CC.TextLayout:Text(self.exchangeHeading,392,16)+8
 y=group({self.exportActive,self.export,self.import},{0,134,268},y,18)
 place(self.counter,0,y);y=y+CC.TextLayout:Text(self.counter,392,16)+8
 for _,button in ipairs(self.rows) do
  -- Reserve the three slots even on the last page so navigation stays stable.
  place(button,0,y);y=y+button:GetHeight()+5
 end
 y=y+7
 place(self.pageLabel,158,y+4);CC.TextLayout:Text(self.pageLabel,86,16)
 y=group({self.prev,self.next},{0,283},y,11)
 y=group({self.load,self.copy,self.delete},{0,134,268},y,14)
 place(self.pageHelp,0,y);y=y+CC.TextLayout:Text(self.pageHelp,394,18)+12
 place(self.status,0,y);y=y+CC.TextLayout:Text(self.status,394,16)+12
 self.frame:SetHeight(y)
 if CC.Settings.draft and CC.Settings.page=="Profiles" and not CC.Settings.rendering then
  CC.Settings.child:SetHeight(math.max(420,y+24))
 end
end
function U:Refresh()
 if not self.frame then return end
 local names=CC.Profiles:Names();local n=#names
 local index=nil
 for i,name in ipairs(names) do if name==self.selected then index=i;break end end
 if not index then self.selected=nil;self.pendingReplace=nil;self.pendingDelete=nil;self.pendingOpen=nil end
 local pages=math.max(1,math.ceil(n/self.pageSize))
 self.pageIndex=math.max(1,math.min(self.pageIndex,pages))
 self.counter:SetText("SAVED PROFILES  ("..n.." / "..CC.Profiles.maxProfiles..")")
 self.pageLabel:SetText(self.pageIndex.." / "..pages)
 self.prev:SetEnabled(self.pageIndex>1);self.next:SetEnabled(self.pageIndex<pages)
 for i,button in ipairs(self.rows) do
  local name=names[(self.pageIndex-1)*self.pageSize+i]
  button.profileName=name;button:SetShown(name~=nil)
  if name then
   button:SetText(name==self.selected and "SELECTED  |  "..name or name)
   CC.Skin:Select(button,name==self.selected)
  end
 end
 for _,button in ipairs({self.replace,self.load,self.copy,self.delete,self.export}) do
  button:SetEnabled(self.selected~=nil)
 end
 self:Layout()
end
function U:CreateExchange()
 if self.dialog then return end
 local d=CreateFrame("Frame","CursorCompanionProfileExchange",UIParent,"BackdropTemplate");self.dialog=d;d.ccFixedButtons=true
 local w,h=CC.TextLayout:WindowSize(720,490,500,420)
 d:SetSize(w,h);CC.TextLayout:FitWindow(d);d:SetPoint("CENTER");d:SetFrameStrata("FULLSCREEN_DIALOG")
 d:SetClampedToScreen(true);d:EnableMouse(true);C:Backdrop(d)
 self.dialogTitle=C:Text(d,"PROFILE CODE",20,-18)
 CC.Skin:Close(d,function() d:Hide() end)
 self.help=C:Text(d,"",20,-46,"GameFontHighlightSmall");self.help:SetWidth(w-40)
 self.importNameLabel=C:Text(d,"Save imported profile as",20,-86,"GameFontHighlightSmall")
 local name=CreateFrame("EditBox",nil,d,"BackdropTemplate");self.importName=name
 CC.Skin:Input(name);name:SetSize(w-46,26);name:SetPoint("TOPLEFT",20,-106)
 name:SetAutoFocus(false);name:SetMaxLetters(32)
 name:SetScript("OnEscapePressed",function(b) b:ClearFocus() end)
 local scroll=CC.Skin:Scroll(d);self.scroll=scroll
 scroll:SetSize(w-58,h-160)
 local edit=CreateFrame("EditBox",nil,scroll,"BackdropTemplate");self.code=edit
 CC.Skin:Input(edit);edit:SetSize(w-76,1750);edit:SetMultiLine(true)
 edit:SetAutoFocus(false);edit:SetMaxLetters(CC.Profiles.maxCode);scroll:SetScrollChild(edit)
 edit:SetScript("OnEscapePressed",function() d:Hide() end)
 self.submit=C:Button(d,"Save imported profile",20,-h+48,206,function()
  local desired=self.importName:GetText()
  local ok,why=CC.Profiles:Import(self.code:GetText(),desired)
  if ok then
   self:Select(CC.Profiles:Name(desired));d:Hide()
  end
  self:Notify(why)
  if not ok then self.dialogStatus:SetText(why or "Import failed");self:LayoutExchange() end
 end)
 self.copyHint=C:Text(d,"Ctrl+A: select  |  Ctrl+C: copy  |  Ctrl+V: paste",236,-h+43,"GameFontHighlightSmall")
 self.dialogStatus=C:Text(d,"",20,-h+75,"GameFontHighlightSmall");self.dialogStatus:SetWidth(w-40)
 tinsert(UISpecialFrames,"CursorCompanionProfileExchange")
 d:Hide()
end
function U:LayoutExchange()
 local d=self.dialog;local w,h=d:GetWidth(),d:GetHeight()
 local helpHeight=CC.TextLayout:Text(self.help,w-40,20)
 local y=46+helpHeight+12
 if self.exchangeMode=="import" then
  self.importNameLabel:ClearAllPoints();self.importNameLabel:SetPoint("TOPLEFT",20,-y)
  y=y+CC.TextLayout:Text(self.importNameLabel,w-46,16)+6
  self.importName:ClearAllPoints();self.importName:SetPoint("TOPLEFT",20,-y);y=y+38
 end
 local hintX=self.exchangeMode=="import" and 236 or 20
 local hintHeight=CC.TextLayout:Text(self.copyHint,w-hintX-20,16)
 self.copyHint:ClearAllPoints();self.copyHint:SetPoint("BOTTOMLEFT",d,"BOTTOMLEFT",hintX,20)
 local footerHeight=math.max(self.submit:GetHeight(),hintHeight)+24
 local statusHeight=CC.TextLayout:Text(self.dialogStatus,w-40,16)
 self.dialogStatus:ClearAllPoints();self.dialogStatus:SetPoint("BOTTOMLEFT",d,"BOTTOMLEFT",20,footerHeight+6)
 self.scroll:ClearAllPoints();self.scroll:SetPoint("TOPLEFT",20,-y)
 self.scroll:SetSize(w-58,math.max(60,h-y-footerHeight-statusHeight-18))
 CC.TextLayout:EditBox(self.code,self.scroll)
 CC.TextLayout:FitWindow(d)
end
function U:OpenExchange(mode,code)
 if CC.Safety:InCombat() then self:Notify("Open profile exchange outside combat.");return end
 self:ClearConfirmation()
 self:CreateExchange();self.exchangeMode=mode
 self.dialogStatus:SetText("")
 self.dialogTitle:SetText(mode=="import" and "IMPORT PROFILE" or "EXPORT PROFILE")
 self.help:SetText(mode=="import" and
  "Paste a CCP29, CCP28 or CCP25 profile code. Import saves a new profile without activating it. Review its Custom Menu macro actions before selecting Open." or
  "Copy this code to share your layout. A recipient must import it, then explicitly open the saved profile.")
 self.importNameLabel:SetShown(mode=="import");self.importName:SetShown(mode=="import")
 self.importName:SetText(self.name and self.name:GetText() or "")
 self.scroll:ClearAllPoints()
 self.scroll:SetPoint("TOPLEFT",20,mode=="import" and -149 or -91)
 self.scroll:SetSize(self.dialog:GetWidth()-58,self.dialog:GetHeight()-(mode=="import" and 241 or 182))
 self.code:SetText(code or "")
 self.submit:SetShown(mode=="import")
 self:LayoutExchange();self.scroll:SetVerticalScroll(0)
 self.dialog:Show()
 if mode=="import" then
  if self.importName:GetText()=="" then self.importName:SetFocus() else self.code:SetFocus() end
 else self.code:SetFocus();self.code:HighlightText() end
end
function U:CloseForCombat()
 self:ClearConfirmation()
 if self.dialog then self.dialog:Hide() end
end
