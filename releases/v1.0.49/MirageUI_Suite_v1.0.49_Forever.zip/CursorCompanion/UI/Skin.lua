local _,CC=...
-- MirageUI beta 61 palette is the reference, copied as standalone style
-- tokens. The palette here is cosmetic only; player-controlled ring/ping colors
-- and the protected action pipeline are not affected by this file.
-- Source: MirageUI_b61_Forever_70959 / MirageUI/Data/VisualTokens.lua.
CC.Skin={
 source="MirageUI-b61",background={.035,.035,.038,.98},panel={.060,.060,.065,.97},
 edge={.26,.26,.26,1},hover={.15,.12,.08,.98},
 accent={.91,.55,.18},secondary={.96,.79,.36},
 text={.90,.89,.87},muted={.63,.62,.60},
}
local K=CC.Skin
local white="Interface\\Buttons\\WHITE8X8"
local media="Interface\\AddOns\\CursorCompanion\\Media\\"
local function crisp(texture)
 if type(texture.SetSnapToPixelGrid)=="function" then pcall(texture.SetSnapToPixelGrid,texture,true) end
 if type(texture.SetTexelSnappingBias)=="function" then pcall(texture.SetTexelSnappingBias,texture,0) end
end
function K:Panel(f,quiet)
 f:SetBackdrop({bgFile=white,edgeFile=white,edgeSize=1})
 local color=quiet and self.panel or self.background
 f:SetBackdropColor(color[1],color[2],color[3],color[4])
 f:SetBackdropBorderColor(self.edge[1],self.edge[2],self.edge[3],self.edge[4])
 if not quiet and not f.ccPanelShine then
  local shine=f:CreateTexture(nil,"BACKGROUND")
  shine:SetAllPoints(f);shine:SetTexture(media.."PanelShine.tga")
  shine:SetVertexColor(.82,.53,.29,.17);crisp(shine);f.ccPanelShine=shine
  local glass=f:CreateTexture(nil,"BACKGROUND")
  glass:SetAllPoints(f);glass:SetTexture(media.."PanelGlass.tga")
  glass:SetVertexColor(.72,.53,.33,.23);crisp(glass);f.ccPanelGlass=glass
  local line=f:CreateTexture(nil,"BORDER")
  line:SetPoint("TOPLEFT",f,"TOPLEFT",1,-1)
  line:SetPoint("TOPRIGHT",f,"TOPRIGHT",-1,-1)
  line:SetHeight(2);line:SetColorTexture(.91,.55,.18,.70);crisp(line);f.ccPanelLine=line
 end
end
function K:Text(f,muted)
 local c=muted and self.muted or self.text;f:SetTextColor(c[1],c[2],c[3],1)
end
function K:Button(b,compact)
 self:Panel(b,true)
 local gloss=b:CreateTexture(nil,"BORDER");gloss:SetAllPoints(b)
 gloss:SetTexture(media.."ButtonGloss.tga");gloss:SetVertexColor(.84,.68,.43,.23);crisp(gloss);b.ccGloss=gloss
 local accent=b:CreateTexture(nil,"OVERLAY")
 accent:SetColorTexture(.91,.55,.18,1)
 accent:SetPoint("TOPLEFT",b,"TOPLEFT",1,-3)
 accent:SetPoint("BOTTOMLEFT",b,"BOTTOMLEFT",1,3)
 accent:SetWidth(2);accent:Hide();crisp(accent);b.ccAccent=accent
 local label=b:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
 label:SetPoint("CENTER");label:SetWidth((b:GetWidth()>0 and b:GetWidth() or 130)-12)
 self:Text(label);b:SetFontString(label);b.ccLabel=label
 b:SetNormalFontObject("GameFontHighlightSmall");b:SetHighlightFontObject("GameFontHighlightSmall");b:SetDisabledFontObject("GameFontDisableSmall")
 local function color(self)
  local enabled=not self.IsEnabled or self:IsEnabled()
  if not enabled then self:SetBackdropColor(.063,.063,.065,.7);self:SetBackdropBorderColor(.16,.16,.16,.8)
  elseif self.ccSelected then self:SetBackdropColor(unpack(K.hover));self:SetBackdropBorderColor(.91,.55,.18,1)
  elseif self.ccHover then self:SetBackdropColor(unpack(K.hover));self:SetBackdropBorderColor(.91,.55,.18,1)
  else self:SetBackdropColor(unpack(K.panel));self:SetBackdropBorderColor(unpack(K.edge)) end
  if self.ccAccent then self.ccAccent:SetShown(enabled and (self.ccSelected or self.ccHover) or false) end
  if self.ccGloss then self.ccGloss:SetVertexColor(.96,.79,.36,enabled and (self.ccHover and .58 or self.ccSelected and .45 or .22) or .1) end
 end
 b.ccRefreshSkin=color
 b:SetScript("OnEnter",function(self) self.ccHover=true;color(self) end)
 b:SetScript("OnLeave",function(self) self.ccHover=false;color(self) end)
 b:SetScript("OnEnable",color);b:SetScript("OnDisable",color);color(b)
 b.ccMinHeight=math.max(20,b:GetHeight())
 local setText=b.SetText
 b.SetText=function(button,text) setText(button,text);CC.TextLayout:Button(button) end
 b:HookScript("OnSizeChanged",function(button) CC.TextLayout:Button(button) end)
 CC.TextLayout:Button(b)
end
function K:Select(b,selected)
 b.ccSelected=selected;if b.ccRefreshSkin then b.ccRefreshSkin(b) end
end
function K:Input(e)
 self:Panel(e,true);e:SetBackdropColor(.028,.028,.030,.95)
 e:SetFontObject("GameFontHighlightSmall");e:SetTextInsets(7,7,2,2)
end
function K:Check(b)
 self:Panel(b,true);b:SetSize(22,22)
 local mark=b:CreateTexture(nil,"ARTWORK");mark:SetTexture(media.."Checkmark.tga")
 mark:SetVertexColor(.96,.79,.36,1);crisp(mark)
 mark:SetPoint("TOPLEFT",3,-3);mark:SetPoint("BOTTOMRIGHT",-3,3)
 b:SetCheckedTexture(mark)
 local highlight=b:CreateTexture(nil,"HIGHLIGHT");highlight:SetAllPoints();highlight:SetColorTexture(.91,.55,.18,.12)
 b:SetHighlightTexture(highlight)
end
function K:Slider(s,vertical)
 s:SetOrientation(vertical and "VERTICAL" or "HORIZONTAL")
 local track=s:CreateTexture(nil,"BACKGROUND");track:SetColorTexture(.20,.20,.20,1)
 if vertical then track:SetPoint("TOP",0,0);track:SetPoint("BOTTOM",0,0);track:SetWidth(3)
 else track:SetPoint("LEFT",0,0);track:SetPoint("RIGHT",0,0);track:SetHeight(3) end
 local knob=s:CreateTexture(nil,"ARTWORK")
 knob:SetTexture(media.."SliderThumb.tga")
 knob:SetVertexColor(.96,.79,.36,1);crisp(knob)
 knob:SetSize(vertical and 8 or 12,vertical and 25 or 15)
 s:SetThumbTexture(knob);s.ccTrack=track
end
function K:Scroll(parent)
 local sc=CreateFrame("ScrollFrame",nil,parent)
 sc:EnableMouseWheel(true)
 local bar=CreateFrame("Slider",nil,parent);sc.ccBar=bar
 self:Slider(bar,true);bar:SetWidth(8);bar:SetPoint("TOPLEFT",sc,"TOPRIGHT",5,0);bar:SetPoint("BOTTOMLEFT",sc,"BOTTOMRIGHT",5,0)
 bar:SetMinMaxValues(0,0);bar:SetValueStep(1);bar:Hide()
 sc.ccRange=0
 bar:SetScript("OnValueChanged",function(_,v) if not sc.ccSync then sc:SetVerticalScroll(v) end end)
 sc:SetScript("OnScrollRangeChanged",function(_,_,yrange)
  sc.ccRange=math.max(0,yrange or 0);bar:SetMinMaxValues(0,sc.ccRange);bar:SetShown(sc.ccRange>1 and sc:IsShown())
  if sc:GetVerticalScroll()>sc.ccRange then sc:SetVerticalScroll(sc.ccRange) end
 end)
 sc:SetScript("OnVerticalScroll",function(_,v) sc.ccSync=true;bar:SetValue(v);sc.ccSync=false end)
 sc:SetScript("OnMouseWheel",function(_,delta)
  sc:SetVerticalScroll(math.max(0,math.min(sc.ccRange,sc:GetVerticalScroll()-delta*32)))
 end)
 sc:SetScript("OnHide",function() bar:Hide() end)
 sc:SetScript("OnShow",function() bar:SetShown(sc.ccRange>1) end)
 return sc
end
function K:Close(parent,fn)
 local b=CreateFrame("Button",nil,parent,"BackdropTemplate");b:SetSize(24,24);self:Button(b,true)
 b:SetPoint("TOPRIGHT",-10,-10);b:SetText("x");b:SetScript("OnClick",fn);return b
end
