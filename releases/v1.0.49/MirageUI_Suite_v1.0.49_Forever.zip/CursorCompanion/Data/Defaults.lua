local _,CC=...
-- Exact official MirageUI beta 61 colors, kept as named cosmetic presets.
-- These are available to every player-controlled color selector; existing
-- SavedVariables retain their selected modes and RGB values on upgrade.
CC.MUIColorPresets={
 ["[MUI] Orange"]={r=232/255,g=140/255,b=46/255,hex="#E88C2E"},
 ["[MUI] Gold"]={r=245/255,g=201/255,b=92/255,hex="#F5C95C"},
}
CC.MUIColorModes={"[MUI] Orange","[MUI] Gold"}
local function ring(size,enabled)
 return {enabled=enabled,style="Ring",size=size,stroke=1,opacity=0.82,colorMode="Neutral",r=1,g=0.82,b=0.43,glow=true,role="Decorative",speed=0,direction="Clockwise"}
end
CC.Defaults={enabled=true,offsetX=0,offsetY=0,idleHideSeconds=3,hideOnMouseDown=true,hideOverWindows=true,
 rings={outer=ring(48,true),inner=ring(32,false),outer2=ring(72,false)},
 alerts={enabled=false,combatStart=false,combatEnd=false,playerCastStart=false,
   playerCastInterrupted=false,playerCastFailed=false,playerDead=false,
   targetChanged=false,encounterStart=false,encounterEnd=false,beaconReceived=false,beaconSent=false,beaconUpdated=false,
   colorMode="Manual",style="Pulse",size=108,duration=0.75,opacity=0.78,
   color={r=1,g=0.29,b=0.16}},
 motion={enabled=false,kind="Dots",colorMode="Neutral",r=1,g=0.82,b=0.43,length=80,lifetime=0.2,width=3,density=8,opacity=0.25,quality="Balanced"},
 info={tracked={""},reference="",source="mouseover",brackets=false,probes=""},
 launcher={show=false,angle=225},
 palette={enabled=true,autoTargetEnemy=true,style="Tracker",settings=true,character=true,bags=true,spellbook=true,talents=true,
  enemyFocus=true,enemyInspect=true,enemyPing=true,enemyMark=true,experimental=false,closeMode="Click and Escape",radius=112,offsetX=40,offsetY=-28,confirmDuel=true,whisper=true,invite=true,trade=true,follow=true,inspect=true,questlog=true,groupfinder=true,professions=true,duel=true,mark=true,ping=true,focus=true,signalStyle="Chromatic",signalLabels="Contextual",signalIcons=true,signalScale=1.25,signalFeedback=true,actionIcons=true,actionScale=1},
 advanced={contrast=false},}
-- A separate compass display may occupy the third/outermost visual slot,
-- but never shares the ordinary Outer Ring 2's enabled flag, role or effects.
-- All ring roles continue to operate while the compass is enabled.
CC.Defaults.compass={enabled=false,questCompass=true,style="QuestNeedle",size=90,stroke=1,pointerWidth=1,pointerHeight=1,
 opacity=.82,colorMode="Neutral",r=1,g=.82,b=.43,glow=true,role="Decorative",speed=0,direction="Clockwise"}
-- F6 is opt-in: legacy F5 navigation appearance and nearest selection remain
-- the defaults. Pin state lives separately in per-character SavedVariables.
CC.Defaults.compass.selectionMode="Nearest"
CC.Defaults.compass.stableTarget=false
CC.Defaults.compass.smoothHeading=false
CC.Defaults.compass.arrivalCue=false
CC.Defaults.compass.arrivalRadius=8
CC.Defaults.compass.showLabel=false
CC.Defaults.compass.labelMode="Name + distance"
CC.Defaults.compass.labelWidth=220
-- F7 experimental planning is disabled on upgrade. No pin/route is exported.
CC.Defaults.compass.routeMode="Off"
CC.Defaults.compass.routePolicy="Balanced"
CC.Defaults.compass.clusterRadius=60
CC.Defaults.compass.routeRange=2000
CC.Defaults.compass.routeStops=8
CC.Defaults.questNotes={enabled=false,limit=5,width=382,height=296}
-- F8 adds opt-in actions. Existing cursor/navigation appearance is preserved.
CC.Defaults.compass.mode="Quest"
CC.Defaults.utility={enabled=false}
for i=1,6 do
 CC.Defaults.utility["slot"..i]={enabled=i<=3,label=({"Pings","Eat","Drink"})[i] or "",
  kind=i<=3 and "preset" or "item",value=({"pings","eat","drink"})[i] or "",target="none"}
end
CC.Defaults.fishing={enabled=false,autoEquip=true,poleID="",showStatus=true,restoreWeapons=true,accessMode="Cast check"}
CC.Defaults.beacon={showSender=true,showAge=true,expiration=0,acceptFrom="Any group member",autoSync=true,showDelivery=true,staleAfter=120,shareMenuTargets=true,receiveMenuTargets=true}
-- Public event names share one authoritative list for settings, preview and effects.
CC.AlertEventOrder={"combatStart","combatEnd","playerCastStart","playerCastInterrupted","playerCastFailed","playerDead","targetChanged","encounterStart","encounterEnd","beaconReceived","beaconSent","beaconUpdated"}
CC.AlertEventLabels={combatStart="Entering combat",combatEnd="Leaving combat",playerCastStart="Your cast or channel begins",
 playerCastInterrupted="Your cast is interrupted",playerCastFailed="Your spell fails",playerDead="Your character dies",
 targetChanged="Your target changes",encounterStart="Boss encounter begins",encounterEnd="Boss encounter ends",beaconReceived="Beacon Received",beaconSent="Beacon Sent",beaconUpdated="Beacon Updated"}
local colorDefaults={combatStart={1,.56,.18},combatEnd={.36,.83,.60},playerCastStart={.96,.79,.36},
 playerCastInterrupted={1,.36,.29},playerCastFailed={1,.61,.24},playerDead={1,.20,.20},
 targetChanged={.55,.77,1},encounterStart={.98,.62,.22},encounterEnd={.34,.87,.64},beaconReceived={.35,.75,1},beaconSent={.96,.79,.36},beaconUpdated={.65,.50,1}}
CC.Defaults.alerts.eventColors={}
for _,event in ipairs(CC.AlertEventOrder) do
 local rgb=colorDefaults[event]
 CC.Defaults.alerts.eventColors[event]={r=rgb[1],g=rgb[2],b=rgb[3]}
end
CC.StyleOrder={"Ring","Segments","Circle","FourDash","EightDash","Plus","Diagonal","Corners","Precision","Orbit","Ticks","Compass","Constellation","Circuit","Eclipse","Lattice","Vector","QuestNeedle","QuestRose","QuestWayfinder","QuestSundial","QuestHorizon","QuestAster","QuestEclipse","QuestVector","QuestBeacon"}
CC.QuestCompassStyles={"QuestNeedle","QuestRose","QuestWayfinder","QuestSundial","QuestHorizon","QuestAster","QuestEclipse","QuestVector","QuestBeacon"}
CC.QuestCompassStyleSet={QuestNeedle=true,QuestRose=true,QuestWayfinder=true,QuestSundial=true,QuestHorizon=true,QuestAster=true,QuestEclipse=true,QuestVector=true,QuestBeacon=true}
CC.RingOrder={"inner","outer","outer2"}
CC.RoleOrder={"Decorative","Spell range","Relationship","Cast / channel","GCD","Health","Resource"}
CC.QualityCaps={Low=16,Balanced=32,High=64}
CC.Bounds={
 ['beacon.expiration']={0,3600},['beacon.staleAfter']={0,3600},
 offsetX={-96,96},offsetY={-96,96},idleHideSeconds={0,15},
 ['compass.clusterRadius']={20,150},['compass.routeRange']={200,10000},['compass.routeStops']={3,12},
 ['compass.arrivalRadius']={3,20},['compass.labelWidth']={120,320},
 ['compass.size']={20,176},['compass.pointerWidth']={0.35,2.2},['compass.pointerHeight']={0.15,2.2},
 ['questNotes.limit']={3,8},['questNotes.width']={320,620},['questNotes.height']={220,560},['compass.stroke']={1,3},['compass.opacity']={0.1,1},
 ['compass.r']={0,1},['compass.g']={0,1},['compass.b']={0,1},
 ['rings.*.size']={20,176},['rings.*.stroke']={1,3},['rings.*.opacity']={0.1,1},['rings.*.speed']={0,90},
 ['rings.*.r']={0,1},['rings.*.g']={0,1},['rings.*.b']={0,1},
 ['alerts.size']={32,240},['alerts.duration']={0.25,2.5},['alerts.opacity']={0.1,1},
 ['alerts.color.r']={0,1},['alerts.color.g']={0,1},['alerts.color.b']={0,1},
 ['alerts.eventColors.*.r']={0,1},['alerts.eventColors.*.g']={0,1},['alerts.eventColors.*.b']={0,1},
 ['motion.r']={0,1},['motion.g']={0,1},['motion.b']={0,1},['motion.length']={20,240},['motion.lifetime']={0.05,0.6},['motion.width']={1,16},['motion.density']={2,24},['motion.opacity']={0.05,0.6},
 ['palette.actionScale']={0.75,1.4},['palette.signalScale']={0.75,1.4},['palette.radius']={96,144},['palette.offsetX']={-200,200},['palette.offsetY']={-200,200},['launcher.angle']={0,360}}
CC.Enums={['beacon.acceptFrom']={"Any group member","Leader and assistants"},['compass.routeMode']={'Off','Suggestions','Follow route'},['compass.routePolicy']={'Balanced','Short travel','Nearby turn-ins'},['compass.selectionMode']={"Nearest","Focused"},['compass.labelMode']={"Name + distance","Distance only"},['alerts.style']={"Pulse","Glow","Burst","Sparks","Ripple","Beacon","Heartbeat","Prism","Aperture","Crosswave","Nova"},
 ['alerts.colorMode']={"Manual","Contextual","[MUI] Orange","[MUI] Gold"},
 ['rings.*.style']=CC.StyleOrder,['rings.*.role']=CC.RoleOrder,
 ['compass.style']=CC.QuestCompassStyles,['compass.colorMode']={"Manual","Class","Neutral","[MUI] Orange","[MUI] Gold"},
 ['rings.*.colorMode']={"Manual","Class","Neutral","[MUI] Orange","[MUI] Gold"},['rings.*.direction']={"Clockwise","Counterclockwise"},
 ['motion.kind']={"Ribbon","Dots","Comet","Glints","Mist","Needles","Stardust","Embers","Chevron","Orbitals"},['motion.colorMode']={"Manual","Class","Neutral","[MUI] Orange","[MUI] Gold"},['motion.quality']={"Low","Balanced","High"},['info.source']={"mouseover","target"},['palette.style']={"Tracker","Aperture","Halo","Facet"},['palette.closeMode']={"Click and Escape","Escape only"},['palette.signalStyle']={"Chromatic","Tactical","Monochrome","[MUI] Orange","[MUI] Gold"},['palette.signalLabels']={"Contextual","Always"}}
