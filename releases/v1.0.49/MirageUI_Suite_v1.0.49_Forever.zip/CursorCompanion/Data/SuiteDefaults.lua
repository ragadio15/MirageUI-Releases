local _, CC = ...
-- Player-neutral appearance and quick-menu layout. Build a fresh copy for each scope.
function CC:FactoryProfile()
    local p=self:Copy(self.Defaults)
    p.alerts.beaconUpdated=true
    p.alerts.colorMode="Contextual"
    p.alerts.combatEnd=true
    p.alerts.combatStart=true
    p.alerts.enabled=true
    p.alerts.eventColors.beaconUpdated.b=0.36078431372549
    p.alerts.eventColors.beaconUpdated.g=0.78823529411765
    p.alerts.eventColors.beaconUpdated.r=0.96078431372549
    p.alerts.eventColors.combatEnd.g=0.83137254901961
    p.alerts.eventColors.combatEnd.r=0.36078431372549
    p.alerts.eventColors.combatStart.b=0.17647058823529
    p.alerts.eventColors.combatStart.g=0.32156862745098
    p.alerts.size=160
    p.alerts.style="Nova"
    p.compass.arrivalCue=true
    p.compass.colorMode="[MUI] Orange"
    p.compass.enabled=true
    p.compass.glow=false
    p.compass.opacity=0.35
    p.compass.pointerHeight=0.75
    p.compass.pointerWidth=2.2
    p.compass.routeMode="Follow route"
    p.compass.size=100
    p.compass.smoothHeading=true
    p.compass.stableTarget=true
    p.compass.style="QuestHorizon"
    p.fishing.enabled=true
    p.idleHideSeconds=5
    p.info.brackets=true
    p.launcher.angle=143.6211014852
    p.launcher.show=true
    p.motion.colorMode="[MUI] Gold"
    p.motion.enabled=true
    p.motion.kind="Needles"
    p.motion.length=240
    p.motion.width=10
    p.palette.experimental=true
    p.palette.groupfinder=false
    p.palette.offsetX=28
    p.palette.offsetY=-20
    p.palette.questlog=false
    p.palette.radius=120
    p.palette.settings=false
    p.palette.signalStyle="Tactical"
    p.palette.spellbook=false
    p.palette.talents=false
    p.questNotes.enabled=true
    p.rings.inner.colorMode="[MUI] Orange"
    p.rings.inner.enabled=true
    p.rings.inner.glow=false
    p.rings.inner.opacity=0.3
    p.rings.inner.role="GCD"
    p.rings.inner.size=50
    p.rings.inner.speed=5
    p.rings.inner.stroke=2
    p.rings.outer.b=0.36078431372549
    p.rings.outer.colorMode="[MUI] Gold"
    p.rings.outer.g=0.78823529411765
    p.rings.outer.glow=false
    p.rings.outer.opacity=0.3
    p.rings.outer.r=0.96078431372549
    p.rings.outer.role="Relationship"
    p.rings.outer.size=75
    p.rings.outer.speed=5
    p.rings.outer.stroke=2
    p.rings.outer.style="Orbit"
    p.quickMenus.main={count=4, slot1="custom3", slot2="custom2", slot3="bags", slot4="custom1", slot5="none", slot6="none", slot7="none", slot8="none", slot9="none"}
    p.quickMenus.friendly={count=4, slot1="invite", slot2="whisper", slot3="focus", slot4="trade", slot5="inspect", slot6="trade", slot7="follow", slot8="marks", slot9="more"}
    p.quickMenus.enemy={count=3, slot1="pingattack", slot2="mark8", slot3="focus", slot4="inspect", slot5="pings", slot6="marks", slot7="main", slot8="none", slot9="none"}
    p.customMenus.menu1.name="Class"
    p.customMenus.menu1.enabled=true
    p.customMenus.menu1.icon="Tome"
    for index=1,6 do
        p.customMenus.menu1["slot"..index]={enabled=false, kind="spell", label="", value="", target="none"}
    end
    p.customMenus.menu2.name="R&R"
    p.customMenus.menu2.enabled=true
    p.customMenus.menu2.slot1={enabled=true, kind="preset", label="Eat", target="none", value="eat"}
    p.customMenus.menu2.slot2={enabled=true, kind="preset", label="Drink", target="none", value="drink"}
    p.customMenus.menu2.slot3={enabled=true, kind="item", label="Cozy", target="none", value="Cozy Sleeping Bag"}
    p.customMenus.menu2.slot4={enabled=true, kind="item", label="Campfire", target="none", value="Basic Campfire Kit"}
    p.customMenus.menu3.name="Character"
    p.customMenus.menu3.enabled=true
    p.customMenus.menu3.icon="Star"
    p.customMenus.menu3.slot1={enabled=true, kind="system", label="Character", target="none", value="character"}
    p.customMenus.menu3.slot2={enabled=true, kind="system", label="Profession", target="none", value="professions"}
    p.customMenus.menu3.slot3={enabled=true, kind="system", label="Bags", target="none", value="bags"}
    p.customMenus.menu3.slot4={enabled=true, kind="system", label="Spell Book", target="none", value="spellbook"}
    p.utility.enabled=p.customMenus.menu1.enabled
    for index=1,6 do p.utility["slot"..index]=self:Copy(p.customMenus.menu1["slot"..index]) end
    return p
end
