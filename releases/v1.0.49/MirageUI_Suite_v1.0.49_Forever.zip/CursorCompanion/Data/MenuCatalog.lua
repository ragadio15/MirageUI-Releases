local _,CC=...
-- F9 data-only menu model. Shared by the live secure compiler and cosmetic
-- preview; this module NEVER executes an action or writes protected attributes.
CC.MenuModel={maxMenus=4,maxSlots=6,maxButtons=9}
local M=CC.MenuModel
local media="Interface\\AddOns\\CursorCompanion\\Media\\"
M.iconOrder={"Compass","Satchel","Arcane","Blades","Shield","Star","Tome","Potion","Banner"}
M.iconLabels={Compass="Compass",Satchel="Satchel",Arcane="Arcane sigil",Blades="Crossed blades",Shield="Guardian shield",Star="Six-point star",Tome="Enchanted tome",Potion="Alchemist flask",Banner="Rally banner"}
M.contextOrder={"main","friendly","enemy"}
M.contextLabels={main="General",friendly="Friendly player",enemy="Enemy target"}
M.labels={none="Empty",character="Character",bags="Bags",spellbook="Spell Book",talents="Talents",professions="Professions",questlog="Quest Log",groupfinder="Group Finder",settings="Settings",focus="Focus",whisper="Whisper",inspect="Inspect",trade="Trade",follow="Follow",invite="Invite",duel="Duel",marks="Marker",pings="Pings",main="General menu",more="More social actions"}
M.baseActions={main={"character","bags","spellbook","talents","professions","questlog","groupfinder","settings","pings"},friendly={"bags","character","focus","whisper","inspect","trade","follow","invite","duel","marks","pings","main","more"},enemy={"bags","character","focus","inspect","marks","pings","main"}}
M.pingOrder={"contextual","assist","attack","warning","onmyway"}
M.pingLabels={contextual="Contextual (automatic)",assist="Assist / Support",attack="Attack",warning="Warning",onmyway="On My Way"}
-- F10: every context offers native windows and individual unit signals.
M.systemOrder={"character","bags","spellbook","talents","professions","questlog","groupfinder","guild","gamemenu","gameoptions","macros","settings"}
M.systemLabels={character="Character",bags="Bags",spellbook="Spell Book",talents="Talents",professions="Professions",questlog="Quest Log",groupfinder="Group Finder",guild="Guild",gamemenu="Game Menu",gameoptions="Game Options",macros="Macros",settings="Cursor Companion settings"}
M.markerOrder={"8","7","6","5","4","3","2","1","0"}
M.markerLabels={["8"]="Skull",["7"]="Cross / X",["6"]="Square",["5"]="Moon",["4"]="Triangle",["3"]="Diamond",["2"]="Circle",["1"]="Star",["0"]="Clear target marker"}
for _,page in ipairs(M.contextOrder) do
 local values=M.baseActions[page];local seen={}
 for _,id in ipairs(values) do seen[id]=true end
 for _,id in ipairs(M.systemOrder) do if not seen[id] then values[#values+1]=id;seen[id]=true end;M.labels[id]=M.systemLabels[id] end
 for _,kind in ipairs(M.pingOrder) do local id="ping"..kind;values[#values+1]=id;M.labels[id]="Ping: "..M.pingLabels[kind] end
 for _,mark in ipairs(M.markerOrder) do local id="mark"..mark;values[#values+1]=id;M.labels[id]="Marker: "..M.markerLabels[mark] end
end
M.transmissionOrder={"beacon","attack","assist","warning","onmyway","contextual"}
M.transmissionLabels={beacon="Beacon waypoint",attack="Attack ping",assist="Assist ping",warning="Warning ping",onmyway="On My Way ping",contextual="Contextual / other ping"}
local function layout(values)
 local r={count=math.max(1,math.min(9,#values))}
 for i=1,9 do r["slot"..i]=values[i] or "none" end
 return r
end
CC.Defaults.quickMenus={main=layout({"character","bags","spellbook","talents","professions","questlog","groupfinder","settings"}),friendly=layout({"bags","focus","whisper","inspect","trade","follow","marks","more","main"}),enemy=layout({"bags","focus","inspect","pings","marks","main"})}
CC.Defaults.customMenus={}
for n=1,4 do
 local menu={enabled=false,name="Custom "..n,icon=M.iconOrder[n]}
 for i=1,6 do menu["slot"..i]=CC:Copy(CC.Defaults.utility["slot"..i]) end
 CC.Defaults.customMenus["menu"..n]=menu
end
CC.Defaults.beacon.nativePings=true
CC.Defaults.beacon.typeColors=true
CC.Defaults.beacon.pingLifetime=30
CC.Defaults.beacon.trackPingUnits=true
CC.Defaults.beacon.colors={beacon={r=.96,g=.79,b=.36},attack={r=1,g=.28,b=.22},assist={r=.25,g=.90,b=.60},warning={r=1,g=.65,b=.12},onmyway={r=.30,g=.70,b=1},contextual={r=.76,g=.65,b=1}}
CC.Bounds["beacon.pingLifetime"]={5,300}
CC.Bounds["beacon.colors.*.r"]={0,1};CC.Bounds["beacon.colors.*.g"]={0,1};CC.Bounds["beacon.colors.*.b"]={0,1}
function M:Icon(key) return media.."Custom"..(self.iconLabels[key] and key or "Compass")..".tga" end
function M:Title(profile,page)
 local index=tonumber(tostring(page):match("^custom([1-4])$"))
 if index then return profile.customMenus["menu"..index].name end
 return self.contextLabels[page] or ({pings="Pings",unitpings="Pings",marks="Markers",confirm="Duel",more="More"})[page] or "Menu"
end
function M:Options(profile,context)
 local values={"none"};local labels=CC:Copy(self.labels)
 for _,id in ipairs(self.baseActions[context] or self.baseActions.main) do values[#values+1]=id end
 for i=1,4 do local id="custom"..i;local menu=profile.customMenus["menu"..i]
  labels[id]=menu.name..(menu.enabled and "" or " (disabled)")
  -- Keep existing assignments selectable even when disabled; runtime displays
  -- a dim slot instead of shifting every following sector.
  values[#values+1]=id
 end
 return values,labels
end
function M:Allowed(context,id)
 if id=="none" or (type(id)=="string" and id:match("^custom[1-4]$")) then return true end
 for _,v in ipairs(self.baseActions[context] or {}) do if id==v then return true end end
 return false
end
function M:Migrate(p)
 if type(p)~="table" then return p end
 if p.customMenus==nil then
  p.customMenus=CC:Copy(CC.Defaults.customMenus)
  if type(p.utility)=="table" then
   local first=p.customMenus.menu1;first.name="Custom 1";first.enabled=p.utility.enabled==true
   for i=1,6 do if type(p.utility["slot"..i])=="table" then first["slot"..i]=CC:Copy(p.utility["slot"..i]) end end
  end
 end
 if p.quickMenus==nil then
  local cfg=type(p.palette)=="table" and p.palette or CC.Defaults.palette;local menus={main={},friendly={},enemy={}}
  local function add(page,id,flag) if not flag or cfg[flag]~=false then menus[page][#menus[page]+1]=id end end
  for _,id in ipairs({"character","bags","spellbook","talents","professions","questlog","groupfinder","settings"}) do add("main",id,id) end
  if type(p.customMenus)=="table" and type(p.customMenus.menu1)=="table" and p.customMenus.menu1.enabled then add("main","custom1") end
  add("friendly","bags","bags");if type(p.customMenus)=="table" and type(p.customMenus.menu1)=="table" and p.customMenus.menu1.enabled then add("friendly","custom1") end
  for _,id in ipairs({"focus","whisper","inspect","trade","follow"}) do add("friendly",id,id) end
  add("friendly","marks","mark");add("friendly","more")
  add("enemy","bags","bags");if type(p.customMenus)=="table" and type(p.customMenus.menu1)=="table" and p.customMenus.menu1.enabled then add("enemy","custom1") end
  add("enemy","focus","enemyFocus");add("enemy","inspect","enemyInspect");add("enemy","pings","enemyPing");add("enemy","marks","enemyMark");add("enemy","main")
  p.quickMenus={};for _,page in ipairs(self.contextOrder) do p.quickMenus[page]=layout(menus[page]) end
 end
 if type(p.palette)=="table" then p.palette.closeMode="Click and Escape";p.palette.actionIcons=true end
 return p
end
function M:Validate(p,strict)
 for _,page in ipairs(self.contextOrder) do
  local cfg=p.quickMenus[page]
  if cfg.count%1~=0 or cfg.count<1 or cfg.count>9 then
   if strict then return nil,"Number of buttons must be a whole number from 1 to 9." end
   cfg.count=math.floor(math.max(1,math.min(9,cfg.count)))
  end
  for i=1,9 do if not self:Allowed(page,cfg["slot"..i]) then
   if strict then return nil,"Unsupported action in "..self.contextLabels[page].." slot "..i end
   cfg["slot"..i]="none"
  end end
 end
 for n=1,4 do
  local menu=p.customMenus["menu"..n]
  menu.name=menu.name:match("^%s*(.-)%s*$")
  local length=CC.Utility and CC.Utility:LabelLength(menu.name) or #menu.name
  if not length or length<1 or length>20 or menu.name:find("[%c|]") then
   if strict then return nil,"Custom menu "..n.." needs a plain title of 1-20 characters." end
   menu.name="Custom "..n
  end
  if not self.iconLabels[menu.icon] then
   if strict then return nil,"Choose a supported Custom Menu icon." end
   menu.icon=self.iconOrder[n]
  end
  for i=1,6 do if CC.Utility then
   local slot,why=CC.Utility:ValidateSlot(menu["slot"..i],strict)
   if not slot then
    if strict then return nil,menu.name..", slot "..i..": "..tostring(why) end
    slot=CC:Copy(CC.Defaults.customMenus["menu"..n]["slot"..i]);slot.enabled=false
   end
   menu["slot"..i]=slot
  end end
 end
 p.palette.closeMode="Click and Escape";p.palette.actionIcons=true
 return p
end
function M:Build(profile)
 local pages={main={},friendly={},enemy={},more={},pings={},unitpings={},marks={},confirm={}}
 for i=1,4 do pages["custom"..i]={} end
 local function entry(id,context)
  local number=tonumber(id:match("^custom([1-4])$"))
  if number then local m=profile.customMenus["menu"..number]
   return {id="page:"..id,label=m.name,page=id,icon=self:Icon(m.icon),ready=m.enabled,combat=true,reason="Enable this Custom Menu in settings."}
  end
  if id:match("^ping%a+$") then return CC.Utility:SignalRecord("ping",id:sub(5),self.labels[id],id) end
  if id:match("^mark%d+$") then return CC.Utility:SignalRecord("marker",id:sub(5),self.labels[id],id) end
  if id=="none" then return {id="empty",label="Empty",ready=false,combat=true,reason="Choose an action for this slot in Quick Menu settings.",icon=media.."ActionSettings.tga"} end
  if id=="pings" or id=="marks" or id=="main" or id=="more" then
   return {id="page:"..id,label=self.labels[id],page=id,combat=true,icon=media..(id=="pings" and "ActionPing.tga" or id=="marks" and "ActionMarker.tga" or "ActionCharacter.tga")}
  end
  if id=="duel" and profile.palette.confirmDuel then return {id="page:confirm",label="Duel...",page="confirm",combat=false} end
  local subject=context~="main" and (id=="focus" or id=="whisper" or id=="inspect" or id=="trade" or id=="follow" or id=="invite" or id=="duel")
  return {id=id,label=self.labels[id] or id,subject=subject,combat=not subject and (id=="bags" or id=="character" or id=="questlog")}
 end
 for _,page in ipairs(self.contextOrder) do
  local cfg=profile.quickMenus[page]
  for i=1,cfg.count do pages[page][i]=entry(cfg["slot"..i],page) end
 end
 for _,id in ipairs({"invite","duel","main"}) do pages.more[#pages.more+1]=entry(id,"friendly") end
 for _,kind in ipairs(self.pingOrder) do
  pages.pings[#pages.pings+1]=CC.Utility:SignalRecord("ping",kind,self.pingLabels[kind],"ping"..kind)
 end
 pages.unitpings=pages.pings
 local marks={"Star","Circle","Diamond","Triangle","Moon","Square","Cross / X","Skull","Clear"}
 for i,label in ipairs(marks) do local mark=tostring(i==9 and 0 or i)
  pages.marks[i]=CC.Utility:SignalRecord("marker",mark,label,"mark"..mark)
 end
 pages.confirm={{id="duel",label="Confirm",subject=true,combat=false},{id="page:friendly",label="Cancel",page="friendly",combat=true}}
 for n=1,4 do local menu=profile.customMenus["menu"..n]
  if menu.enabled then for i=1,6 do local slot=menu["slot"..i]
   if slot.enabled then
    local item=CC.Utility:CompileSlot(slot,i);item.id="custom"..n.."slot"..i
    pages["custom"..n][#pages["custom"..n]+1]=item
   end
  end end
 end
 return pages
end
