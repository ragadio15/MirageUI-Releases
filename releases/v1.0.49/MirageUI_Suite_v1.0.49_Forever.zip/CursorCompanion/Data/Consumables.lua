local _,CC=...
-- A deliberately conservative catalogue of ordinary regeneration food/drink.
-- IDs are the classic vendor/conjured families retained by Forever. No feast,
-- alcohol, well-fed food, transformation item, or unknown item is inferred from
-- its name. Runtime metadata supplies the actual current required/item level.
-- Source cross-check: LibPeriodicTable 3.1 Basic/Conjured consumable families
-- (https://www.wowace.com/projects/libperiodictable-3-1) and client item metadata.
CC.ConsumableCatalog={revision="F8-standard-1",food={},drink={}}
local function tier(kind,rank,ids)
 for _,id in ipairs(ids) do CC.ConsumableCatalog[kind][id]={tier=rank,kind=kind,standard=true} end
end
-- Ordinary bread, meat, fruit, cheese, mushrooms and fish. Eating/drinking's
-- temporary regeneration aura is allowed; additional stat effects are not.
tier("food",1,{117,2070,4536,4540,4604,787,6290})
tier("food",2,{2287,414,4537,4541,4605,4592,5095,6316,12238})
tier("food",3,{3770,422,4538,4542,4606,4593})
tier("food",4,{3771,1707,4539,4544,4607,4594,8364})
tier("food",5,{4599,3927,4602,4601,4608,6887,8959,13930})
tier("food",6,{8952,8932,8953,8950,8948,8957,13933,13935})
-- Conjured food: Muffin, Bread, Rye, Pumpernickel, Sourdough, Sweet Roll,
-- Cinnamon Roll. Conjured food is ordinary regeneration, not a well-fed buff.
for rank,id in ipairs({5349,1113,1114,1487,8075,8076,22895}) do tier("food",rank,{id}) end
for rank,id in ipairs({159,1179,1205,1708,1645,8766,18300}) do tier("drink",rank,{id}) end
for rank,id in ipairs({5350,2288,2136,3772,8077,8078,8079}) do tier("drink",rank,{id}) end
tier("drink",4,{10841}) -- Goldthorn Tea: mana regeneration only.
tier("drink",5,{19300}) -- Bottled Winterspring Water: mana regeneration only.
