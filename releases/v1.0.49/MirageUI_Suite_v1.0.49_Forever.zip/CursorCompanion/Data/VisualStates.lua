local _, CC = ...
-- These are manual appearance choices, NOT classifications of units or game state.
CC.Themes = {
    Neutral = { 1.00, 0.82, 0.43 },
    Arcane = { 0.67, 0.57, 1.00 },
    Frost = { 0.32, 0.88, 1.00 },
    Contrast = { 1.00, 1.00, 1.00 },
}
CC.ThemeOrder = { "Neutral", "Arcane", "Frost", "Contrast" }
CC.Shapes = { Ring = true, Segments = true }
