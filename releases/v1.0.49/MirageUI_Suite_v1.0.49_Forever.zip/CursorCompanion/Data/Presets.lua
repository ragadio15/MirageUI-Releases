local _,CC=...
CC.PresetNames={"Minimal","Range + Cast","Range + GCD","Timing","Vitals + GCD","Accessible","Developer Curated"}
function CC:Preset(name)
 if name=="Developer Curated" then return self:FactoryProfile() end
 local p=self:Copy(self.Defaults)
 if name=="Range + Cast" or name=="Range + GCD" then
  p.rings.outer.role="Spell range";p.rings.inner.enabled=true
  p.rings.inner.role=name=="Range + Cast" and "Cast / channel" or "GCD"
 elseif name=="Timing" then p.rings.outer.role="Cast / channel";p.rings.inner.enabled=true;p.rings.inner.role="GCD"
 elseif name=="Vitals + GCD" then
  p.rings.inner.enabled=true;p.rings.inner.role="Health";p.rings.outer.role="Resource";p.rings.outer2.enabled=true;p.rings.outer2.role="GCD"
 elseif name=="Accessible" then p.rings.outer.style="Circle";p.rings.outer.stroke=3;p.rings.outer.colorMode="Neutral";p.motion.enabled=false;p.rings.outer.speed=0;p.rings.inner.speed=0;p.advanced.contrast=true end
 return p
end
