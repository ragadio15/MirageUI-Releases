local _,CC=...
CC.Actions={faults={}}
local S=CC.Safety
function CC.Actions:MarkAllowed()
 if S:BoolCall(IsInRaid)==true then
  return S:BoolCall(UnitIsGroupLeader,"player")==true or S:BoolCall(UnitIsGroupAssistant,"player")==true
 end
 return true -- Native group / solo restrictions still apply to a player request.
end
local launchers={character="ToggleCharacter",bags="ToggleAllBags",guild="ToggleGuildFrame",
 questlog="ToggleQuestLog",groupfinder="PVEFrame_ToggleFrame"}
function CC.Actions:Available(id,s)
 if self.faults[id] then return false,"This action stopped after an error. Reload before retrying" end
 -- Opening ordinary bags is a supported combat use case. Keep capability
 -- restrictions on individual windows/interactions instead of the whole menu.
 if S:InCombat() and id~="bags" and id~="character" and id~="questlog" then
  return false,"This action is available after combat"
 end
 if id=="settings" then return true end
 if id=="guild" then return type(ToggleGuildFrame)=="function" or type(ToggleFriendsFrame)=="function","Guild window is unavailable." end
 if id=="gamemenu" then return type(ToggleGameMenu)=="function" or (GameMenuFrame~=nil and type(ShowUIPanel)=="function" and type(HideUIPanel)=="function"),"Game Menu is unavailable." end
 if id=="gameoptions" then return Settings and type(Settings.OpenToCategory)=="function","Game Options are unavailable." end
 if id=="macros" then return type(ShowMacroFrame)=="function" or type(MacroFrame_LoadUI)=="function","Macro UI is unavailable." end
 if id=="professions" then
  return type(ToggleProfessionsBook)=="function" or
    (type(ToggleFrame)=="function" and ProfessionsBookFrame~=nil),"Professions book is unavailable"
 end
 if id=="groupfinder" then return type(PVEFrame_ToggleFrame)=="function" or type(ToggleLFDParentFrame)=="function","Group Finder is unavailable." end
 if launchers[id] then
  return type(_G[launchers[id]])=="function","Native window is unavailable right now"
 end
 if id=="spellbook" then return (PlayerSpellsUtil and type(PlayerSpellsUtil.ToggleSpellBookFrame)=="function") or (type(ToggleSpellBook)=="function" and type(BOOKTYPE_SPELL)=="string"),"Spellbook is unavailable right now" end
 if id=="talents" then return (PlayerSpellsUtil and type(PlayerSpellsUtil.ToggleClassTalentOrSpecFrame)=="function") or type(ToggleTalentFrame)=="function","Talents are unavailable right now" end
 if not CC.Capabilities.actions then return false,"Player actions are not available on this game version" end
 if not CC.profile.palette.experimental then return false,"Turn on Mouseover actions in Quick menu settings" end
 local option=id:match("^mark") and "mark" or id:match("^ping") and "ping" or id
 if s and s.context=="enemy" then
  local enemy={focus="enemyFocus",inspect="enemyInspect",mark="enemyMark",ping="enemyPing"}
  option=enemy[option] or option
 end
 if CC.profile.palette[option]==false then return false,"This action is disabled in Quick menu settings" end
 local needUnit=id=="trade" or id=="duel" or id=="focus" or id=="follow" or
  id=="inspect" or id:match("^mark") or id:match("^ping")
 local valid,why=CC.Subject:Valid(s,needUnit)
 if not valid then return false,why end
 if id:match("^mark") then
  return type(SetRaidTarget)=="function" and self:MarkAllowed(),"Marker permissions or native API unavailable"
 end
 if id:match("^ping") then return C_Ping and S:BoolCall(C_Ping.IsPingSystemEnabled)==true,"Ping system unavailable" end
 if id=="focus" then return type(FocusUnit)=="function","Focus API unavailable" end
 if id=="whisper" then
  return s.player and s.name~=nil and ((ChatFrameUtil and type(ChatFrameUtil.SendTell)=="function") or
    type(ChatFrame_SendTell)=="function"),"Whisper editor unavailable"
 end
 if id=="invite" then
  if s.context~="friendly" or not s.player or not s.assistable then return false,"Only friendly players may be invited" end
  if S:BoolCall(IsInRaid)==true and not self:MarkAllowed() then return false,"Group invite permission required" end
  local count=S:Value(GetNumGroupMembers)
  if type(count)=="number" and ((S:BoolCall(IsInRaid)==true and count>=40) or
    (S:BoolCall(IsInRaid)~=true and count>=5)) then return false,"Group is full" end
  return s.name~=nil and C_PartyInfo and type(C_PartyInfo.InviteUnit)=="function","Invite API unavailable"
 end
 if id=="trade" or id=="follow" then
  if s.context~="friendly" or not s.player or not s.assistable then return false,"Requires a friendly player" end
  local fn=id=="trade" and InitiateTrade or FollowUnit
  if type(fn)~="function" then return false,"Native interaction API unavailable" end
  if type(CheckInteractDistance)=="function" and
    S:BoolCall(CheckInteractDistance,s.unit,id=="trade" and 2 or 4)~=true then
    return false,"Move closer to the player to "..id
  end
  return true
 end
 if id=="inspect" then
  if not s.player then return false,"Only players can be inspected" end
  if type(InspectUnit)~="function" or type(CanInspect)~="function" then return false,"Inspect UI unavailable" end
  if S:BoolCall(CanInspect,s.unit)~=true then return false,"Blizzard does not allow inspecting this player here" end
  if type(CheckInteractDistance)=="function" and S:BoolCall(CheckInteractDistance,s.unit,1)~=true then
   return false,"Move closer to inspect this player"
  end
  return true
 end
 if id=="duel" then
  if s.context~="friendly" or not s.player then return false,"Duel requires a friendly player" end
  return type(StartDuel)=="function","Duel API unavailable"
 end
 return false,"Unsupported action"
end
function CC.Actions:Dispatch(id,s)
 local allowed,why=self:Available(id,s)
 if not allowed then CC:Print(why);return false end
 local ok=pcall(function()
  if id=="settings" then CC.Palette:Close();CC.Settings:Open()
  elseif id=="gamemenu" then
   if type(ToggleGameMenu)=="function" then ToggleGameMenu() elseif GameMenuFrame:IsShown() then HideUIPanel(GameMenuFrame) else ShowUIPanel(GameMenuFrame) end
  elseif id=="gameoptions" then Settings.OpenToCategory(nil)
  elseif id=="macros" then
   if type(ShowMacroFrame)=="function" then ShowMacroFrame() else MacroFrame_LoadUI();if MacroFrame then MacroFrame:Show() end end
  elseif id=="character" then ToggleCharacter("PaperDollFrame")
  elseif id=="bags" then ToggleAllBags()
  elseif id=="guild" then if type(ToggleGuildFrame)=="function" then ToggleGuildFrame() else ToggleFriendsFrame(3) end
  elseif id=="spellbook" then if PlayerSpellsUtil and type(PlayerSpellsUtil.ToggleSpellBookFrame)=="function" then PlayerSpellsUtil.ToggleSpellBookFrame() else ToggleSpellBook(BOOKTYPE_SPELL) end
  elseif id=="talents" then if PlayerSpellsUtil and type(PlayerSpellsUtil.ToggleClassTalentOrSpecFrame)=="function" then PlayerSpellsUtil.ToggleClassTalentOrSpecFrame() else ToggleTalentFrame() end
  elseif id=="professions" then
   if type(ToggleProfessionsBook)=="function" then ToggleProfessionsBook() else ToggleFrame(ProfessionsBookFrame) end
  elseif id=="questlog" then ToggleQuestLog()
  elseif id=="groupfinder" then if type(PVEFrame_ToggleFrame)=="function" then PVEFrame_ToggleFrame() else ToggleLFDParentFrame() end
  elseif id=="whisper" then
   if ChatFrameUtil and ChatFrameUtil.SendTell then ChatFrameUtil.SendTell(s.name) else ChatFrame_SendTell(s.name) end
  elseif id=="invite" then C_PartyInfo.InviteUnit(s.name)
  elseif id=="trade" then InitiateTrade(s.unit)
  elseif id=="follow" then FollowUnit(s.unit)
  elseif id=="inspect" then InspectUnit(s.unit)
  elseif id=="duel" then StartDuel(s.unit,true)
  else error("SECURE_ACTION_REQUIRES_NATIVE_BUTTON") end
 end)
 if not ok then
  self.faults[id]=true;CC.Diagnostics:OptionalFault("ACTION_FAULT")
  CC:Print("Action stopped; native restrictions retained. No retry was queued.")
  return false
 end
 return true -- Attempted by click, NOT proof of server acceptance.
end
