local _,CC=...
-- Ephemeral identity only. Never persist, export, retarget, or create a fake unit token.
CC.Subject={}
local S=CC.Safety
local stable={"target","focus","pet","player","targettarget","focustarget"}
for i=1,40 do stable[#stable+1]="nameplate"..i end
for i=1,4 do stable[#stable+1]="party"..i;stable[#stable+1]="partypet"..i end
for i=1,40 do stable[#stable+1]="raid"..i;stable[#stable+1]="raidpet"..i end
for i=1,8 do stable[#stable+1]="boss"..i end
for i=1,5 do stable[#stable+1]="arena"..i end
function CC.Subject:GUID(unit)
 local v=S:Value(UnitGUID,unit);return type(v)=="string" and v~="" and v or nil
end
function CC.Subject:SafeToken(v)
 -- Returned strings are allowlisted before being embedded in secure macro conditions.
 if not S:IsText(v) then return nil end
 if v=="player" or v=="pet" or v=="target" or v=="focus" or v=="mouseover" or v=="targettarget" or v=="focustarget" then return v end
 for _,prefix in ipairs({"nameplate","party","partypet","raid","raidpet","boss","arena"}) do
  if v:match("^"..prefix.."%d+$") then return v end
 end
end
function CC.Subject:Resolve(s)
 if not s or not s.guid then return nil end
 -- Prefer an existing durable alias over a current mouseover alias.
 if s.unit and s.unit~="mouseover" and self:GUID(s.unit)==s.guid then return s.unit end
 local token=self:SafeToken(S:Value(UnitTokenFromGUID,s.guid))
 if token and token~="mouseover" and self:GUID(token)==s.guid then s.unit=token;return token end
 for _,u in ipairs(stable) do
  if self:GUID(u)==s.guid then s.unit=u;return u end
 end
 -- Useful when still hovering the original unit, but never assumed to survive a move.
 if self:GUID("mouseover")==s.guid then s.unit="mouseover";return "mouseover" end
 s.unit=nil;return nil
end
function CC.Subject:Capture()
 local snap={context="general",created=GetTime()}
 if S:BoolCall(UnitExists,"mouseover")~=true then return snap end
 local guid=self:GUID("mouseover")
 if not guid then snap.reason="Unit information is unavailable";return snap end
 snap.guid=guid
 local isPlayer=S:BoolCall(UnitIsPlayer,"mouseover")
 snap.player=isPlayer==true;snap.attackable=S:BoolCall(UnitCanAttack,"player","mouseover")==true
 snap.assistable=S:BoolCall(UnitCanAssist,"player","mouseover")==true
 -- Hostile players must never inherit friendly-only actions. A neutral
 -- nonplayer retains the general launcher. Never infer friendliness from name.
 if snap.attackable then snap.context="enemy"
 elseif isPlayer==true then snap.context="friendly" end
 if isPlayer==true and type(UnitFullName)=="function" then
  local ok,name,realm=pcall(UnitFullName,"mouseover")
  if ok and S:IsText(name) and name~="" and S:IsReadable(realm) and (realm==nil or type(realm)=="string") then
   snap.name=name..((realm and realm~="") and "-"..realm or "")
  end
 end
 self:Resolve(snap);return snap
end
function CC.Subject:Valid(s,requireUnit)
 if not s or S:InCombat() or GetTime()-s.created>30 then return false,"Menu expired or combat started" end
 if s.context=="general" then return not requireUnit,"No unit under the pointer" end
 if requireUnit then
  local token=self:Resolve(s)
  if not token then return false,"Unit no longer available. Keep its nameplate visible and reopen." end
  if self:GUID(token)~=s.guid then s.unit=nil;return false,"Unit changed. Reopen the menu." end
  return true
 end
 -- Name-addressed social requests use only the original player identity; never a new mouseover.
 if s.name then return true end
 return false,"Player information is unavailable"
end
