local _,CC=...
-- Utility configuration is data. Only Blizzard's secure action template executes
-- an assigned action, and only after a physical click on the prepared menu.
CC.Utility={maxSlots=6,maxLabel=10,maxMacroBytes=255,dirty=true}
local U=CC.Utility
local kinds={item=true,spell=true,macro=true,preset=true,ping=true,system=true,marker=true}
local targets={target=true,player=true,focus=true,mouseover=true,none=true,cursor=true}
local presets={pings=true,eat=true,drink=true}
local function trim(v) return type(v)=="string" and v:match("^%s*(.-)%s*$") or "" end
local function countCharacters(s)
 local count,index=0,1
 while index<=#s do
  local byte=s:byte(index);local length
  if byte<128 then length=1
  elseif byte>=194 and byte<=223 then length=2
  elseif byte>=224 and byte<=239 then length=3
  elseif byte>=240 and byte<=244 then length=4
  else return nil end
  if index+length-1>#s then return nil end
  for j=index+1,index+length-1 do local b=s:byte(j);if b<128 or b>191 then return nil end end
  if length==3 then local b=s:byte(index+1);if (byte==224 and b<160) or (byte==237 and b>159) then return nil end end
  if length==4 then local b=s:byte(index+1);if (byte==240 and b<144) or (byte==244 and b>143) then return nil end end
  count=count+1;index=index+length
 end
 return count
end
function U:LabelLength(value) return type(value)=="string" and countCharacters(value) or nil end
function U:PingAvailable()
 return C_Ping~=nil and CC.Safety:BoolCall(C_Ping.IsPingSystemEnabled)==true
end
function U:ValidateSlot(slot,strict)
 if type(slot)~="table" then return nil,"Choose an action for this Custom Menu slot." end
 local result={enabled=slot.enabled==true,label=trim(slot.label),kind=slot.kind or "item",value=trim(slot.value),target=slot.target or "none"}
 if type(slot.enabled)~="boolean" and slot.enabled~=nil and strict then return nil,"Custom Menu enabled must be a checkbox value." end
 if not kinds[result.kind] then return nil,"Choose Item, Spell, Macro, Preset, Pings, System menu, or Target marker." end
 if not targets[result.target] then return nil,"Choose a supported target for this action." end
 local length=countCharacters(result.label)
 if not length or length>self.maxLabel or result.label:find("[%c|]") then return nil,"Custom Menu labels allow up to 10 characters, without formatting or line breaks." end
 if #result.value>self.maxMacroBytes and result.kind=="macro" then return nil,"Macro text is limited to 255 bytes. Use macro:Name for an existing macro." end
 if #result.value>512 then return nil,"Custom Menu action text is too long." end
 if result.kind~="macro" and result.value:find("[%c]") then return nil,"An item, spell, or preset must fit on one line." end
 if result.kind=="macro" then
  result.value=result.value:gsub("\r\n","\n"):gsub("\r","\n")
  if result.value:find("[%z\1-\8\11\12\14-\31\127]") then return nil,"Macro text contains unsupported control characters." end
  if result.value:sub(1,6)=="macro:" and (trim(result.value:sub(7))=="" or result.value:find("\n")) then return nil,"Enter macro: followed by the exact existing macro name." end
 elseif result.kind=="ping" and result.value~="" and not ({contextual=true,assist=true,attack=true,warning=true,onmyway=true})[result.value] then return nil,"Choose a native ping type."
 elseif result.kind=="preset" and result.value~="" and not presets[result.value] then return nil,"Choose Pings, Eat, or Drink." end
 if result.kind=="system" and result.value~="" and not CC.MenuModel.systemLabels[result.value] then return nil,"Choose a supported system menu." end
 if result.kind=="marker" and result.value~="" and not CC.MenuModel.markerLabels[result.value] then return nil,"Choose a native target marker." end
 if result.target=="cursor" and result.kind~="ping" then return nil,"Ground cursor targeting is only available for pings." end
 if result.enabled and (result.label=="" or result.value=="") then return nil,"Enabled Custom Menu slots need a label and an action." end
 return result
end
local function scalar(fn,...)
 if type(fn)~="function" then return nil end
 local ok,v=pcall(fn,...)
 if ok and CC.Safety:IsReadable(v) then return v end
end
local function itemID(value)
 local id=tonumber(value) or tonumber(value:match("item:(%d+)"))
 if not id and C_Item and type(C_Item.GetItemInfoInstant)=="function" then id=scalar(C_Item.GetItemInfoInstant,value) end
 if not id and CC.Inventory and type(CC.Inventory.items)=="table" then
  local match
  for key,record in pairs(CC.Inventory.items) do
   if type(record.name)=="string" and record.name:lower()==value:lower() then
    if match and match~=key then return nil end
    match=key
   end
  end
  id=match
 end
 if type(id)=="number" and id>0 and id==math.floor(id) then return id end
end
-- An ordinary /cast or /use action must not REQUIRE a selected unit.
-- In Forever's SecureActionButton_OnClick, even a non-targeted spell is
-- discarded before native dispatch when a forced 'target' unit is missing.
-- Treat F8's old default 'target' the same as Game default without rewriting
-- any saved profile. Explicit player/focus/mouseover overrides still work.
local function actionUnit(target)
 if target=="player" or target=="focus" or target=="mouseover" then return target end
 return nil
end
local function spellInfo(value)
 local id=tonumber(value) or tonumber(value:match("spell:(%d+)"))
 local info=C_Spell and scalar(C_Spell.GetSpellInfo,id or value)
 if info and type(info)=="table" then
  local spellID=CC.Safety:Field(info,"spellID") or id
  return spellID,CC.Safety:Field(info,"name"),CC.Safety:Field(info,"iconID")
 end
 return id
end
function U:SignalRecord(kind,value,label,id,target)
 target=target or "none"
 local out={id=id,label=label,kind=kind,combat=true,signal=true,signalTarget=target,ready=true}
 if kind=="ping" then
  out.pingType=value;out.signalID=value~="contextual" and "ping"..value or nil
  local unit=target=="none" and "target" or target
  out.action={type="macro",macrotext="/ping [@"..unit..(unit=="cursor" and "" or ",exists").."]"..(value=="contextual" and "" or " "..value)}
  out.icon=out.signalID and CC.SignalArt and CC.SignalArt:Texture(out.signalID) or "Interface\\AddOns\\CursorCompanion\\Media\\ActionPing.tga"
  out.ready=self:PingAvailable();out.reason=not out.ready and "Blizzard's Ping system is unavailable." or nil
 else
  out.marker=tonumber(value);out.signalID="mark"..value
  out.action={type="raidtarget",unit=target=="none" and "target" or target,marker=out.marker,action=out.marker==0 and "clear" or "set"}
  out.icon=CC.SignalArt and CC.SignalArt:Texture(out.signalID) or "Interface\\TargetingFrame\\UI-RaidTargetingIcon_"..value
 end
 return out
end
function U:CompileSlot(slot,index)
 local clean,why=self:ValidateSlot(slot,true)
 local out={id="utility"..tostring(index or 1),slot=index,label=slot and slot.label or "",ready=false,reason=why,combat=true}
 if not clean then return out end
 out.label=clean.label;out.kind=clean.kind;out.config=clean
 if not clean.enabled then out.reason="This Custom Menu slot is disabled.";return out end
 if clean.kind=="ping" or clean.kind=="marker" then
  local signal=self:SignalRecord(clean.kind,clean.value,clean.label,out.id,clean.target)
  signal.slot=index;signal.config=clean;return signal
 elseif clean.kind=="system" then
  out.dispatchID=clean.value;out.combat=clean.value=="bags" or clean.value=="character" or clean.value=="questlog"
  out.icon=CC.MenuIcons and CC.MenuIcons:Texture(clean.value) or "Interface\\AddOns\\CursorCompanion\\Media\\ActionSettings.tga"
  out.ready=true;out.reason=nil;return out
 elseif clean.kind=="preset" then
  if clean.value=="pings" then
   out.page="pings";out.ready=self:PingAvailable();out.icon="Interface\\AddOns\\CursorCompanion\\Media\\ActionPing.tga"
   out.reason=not out.ready and "Blizzard's Ping system is unavailable." or nil;return out
  end
  local category=clean.value=="eat" and "food" or "drink"
  local record=CC.Inventory and CC.Inventory:BestConsumable(category)
  out.combat=false;out.preset=clean.value
  if not record then out.reason="No usable standard "..category.." in your bags.";return out end
  out.action={type="item",item="item:"..record.id};out.itemID=record.id;out.itemName=record.name
  out.icon=record.icon;out.ready=true;out.reason=nil;return out
 elseif clean.kind=="item" then
  local id=itemID(clean.value)
  if not id then out.reason="Item information is not available. Enter its item ID or drag it from your bags.";return out end
  local record=CC.Inventory and CC.Inventory:GetItem(id)
  out.action={type="item",item="item:"..id,unit=actionUnit(clean.target)};out.itemID=id
  out.icon=record and record.icon or (C_Item and scalar(C_Item.GetItemIconByID,id))
  out.itemName=record and record.name
  out.ready=record~=nil and (record.count or 0)>0 and record.usable~=false
  out.reason=not out.ready and (record and record.usable==false and "This item cannot be used by your character yet." or "This item is not in your bags.") or nil
  return out
 elseif clean.kind=="spell" then
  local id,name,icon=spellInfo(clean.value)
  if not id then out.reason="Spell information is not available. Enter its spell ID or drag it from your spellbook.";return out end
  out.action={type="spell",spell=id,unit=actionUnit(clean.target)};out.spellID=id;out.icon=icon;out.spellName=name
  local known
  if C_SpellBook and C_SpellBook.IsSpellKnown then known=scalar(C_SpellBook.IsSpellKnown,id) end
  if known==nil and type(IsPlayerSpell)=="function" then known=scalar(IsPlayerSpell,id) end
  if known==nil and type(IsSpellKnown)=="function" then known=scalar(IsSpellKnown,id) end
  out.ready=known==true
  out.reason=not out.ready and "This spell is not learned or its availability cannot be verified." or nil
  return out
 elseif clean.kind=="macro" then
  if clean.value:sub(1,6)=="macro:" then
   local name=trim(clean.value:sub(7));local macro=scalar(GetMacroIndexByName,name)
   if type(macro)~="number" or macro<1 then out.reason="The named macro was not found. Use the exact name from WoW's macro window.";return out end
   local actualName,icon
   if type(GetMacroInfo)=="function" then local ok,a,b=pcall(GetMacroInfo,macro);if ok then actualName,icon=a,b end end
   out.action={type="macro",macro=name};out.icon=icon;out.macroName=actualName or name
  else
   out.action={type="macro",macrotext=clean.value}
  end
  out.ready=true;out.reason=nil;return out
 end
 out.reason="Choose a supported Custom Menu action.";return out
end
function U:Status(record)
 if not record then return false,"No action is assigned." end
 if not record.ready then return false,record.reason or "Unavailable" end
 if record.dispatchID and CC.Actions then return CC.Actions:Available(record.dispatchID) end
 if record.signal then
  if record.kind=="marker" and CC.Actions and not CC.Actions:MarkAllowed() then return false,"Raid leader or assistant permission is required to mark this target." end
  if CC.Palette and CC.Palette.SignalAvailable then return CC.Palette:SignalAvailable(record) end
 end
 if not record.combat and CC.Safety:InCombat() then return false,"This action is available after combat." end
 if record.itemID and CC.Inventory then
  local item=CC.Inventory:GetItem(record.itemID)
  if not item or (item.count or 0)==0 then return false,"This item is no longer in your bags." end
 end
 return true
end
function U:MarkDirty(reason)
 self.dirty=true;self.dirtyReason=reason
 if CC.Palette then CC.Palette.dirty=true end
 if not CC.Safety:InCombat() and CC.Palette and CC.Palette.root and not CC.Palette.root:IsShown() then CC.Palette:Rebuild() end
end
function U:Initialize()
 if self.initialized then return end;self.initialized=true
 if CC.Inventory and CC.Inventory.Subscribe then CC.Inventory:Subscribe(self,function() self:MarkDirty("INVENTORY") end) end
 self.eventFrame=CreateFrame("Frame")
 for _,event in ipairs({"SPELLS_CHANGED","UPDATE_MACROS","PLAYER_REGEN_ENABLED"}) do pcall(self.eventFrame.RegisterEvent,self.eventFrame,event) end
 self.eventFrame:SetScript("OnEvent",function(_,event)
  if event=="PLAYER_REGEN_ENABLED" then
   if CC.Palette then CC.Palette:OnCombatEnded() end
  else self:MarkDirty(event) end
 end)
end
