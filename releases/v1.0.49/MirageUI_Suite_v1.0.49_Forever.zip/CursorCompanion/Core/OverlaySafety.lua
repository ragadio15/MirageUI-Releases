local _, CC = ...
CC.OverlaySafety = { frames = {} }
function CC.OverlaySafety:MakePassive(frame)
    frame:EnableMouse(false)
    if frame.EnableMouseWheel then frame:EnableMouseWheel(false) end
    frame:EnableKeyboard(false)
    if frame.EnableGamePadButton then frame:EnableGamePadButton(false) end
    if frame.EnableGamePadStick then frame:EnableGamePadStick(false) end
    self.frames[#self.frames + 1] = frame
end
function CC.OverlaySafety:Check()
    for _, frame in ipairs(self.frames) do
        if frame:IsMouseEnabled() or frame:IsKeyboardEnabled() then return false end
        if frame.IsMouseWheelEnabled and frame:IsMouseWheelEnabled() then return false end
        if frame:GetScript("OnMouseDown") or frame:GetScript("OnMouseUp")
            or frame:GetScript("OnKeyDown") or frame:GetScript("OnKeyUp") then return false end
    end
    return true
end
