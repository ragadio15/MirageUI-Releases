local _,CC=...
-- Bounded declarative profile exchange. Utility macro text is stored data:
-- imports never execute it, and only an intentional secure click runs an action.
-- No load/loadstring, live Beacon coordinates, bindings or identities are exported.
CC.Profiles={maxProfiles=20,maxCode=96000,maxFields=768}
local P=CC.Profiles
local alphabet="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
local function encode64(text)
 local out={}
 for i=1,#text,3 do
  local a,b,c=text:byte(i,i+2)
  local n=a*65536+(b or 0)*256+(c or 0)
  local i1=math.floor(n/262144)%64+1
  local i2=math.floor(n/4096)%64+1
  local i3=math.floor(n/64)%64+1
  local i4=n%64+1
  out[#out+1]=alphabet:sub(i1,i1)..alphabet:sub(i2,i2)..
   (b and alphabet:sub(i3,i3) or "=")..(c and alphabet:sub(i4,i4) or "=")
 end
 return table.concat(out)
end
local mapping={}
for i=1,#alphabet do mapping[alphabet:sub(i,i)]=i-1 end
local function decode64(code)
 if #code==0 or #code%4~=0 or not code:match("^[A-Za-z0-9+/]+=?=?$") then return nil end
 local out={}
 for i=1,#code,4 do
  local a,b,c,d=code:sub(i,i+3):match("(.)(.)(.)(.)")
  if (c=="=" and (d~="=" or i~=#code-3)) or (d=="=" and i~=#code-3) then return nil end
  if not mapping[a] or not mapping[b] or (c~="=" and not mapping[c]) or (d~="=" and not mapping[d]) then return nil end
  local n=mapping[a]*262144+mapping[b]*4096+(mapping[c] or 0)*64+(mapping[d] or 0)
  local x=math.floor(n/65536)%256;local y=math.floor(n/256)%256;local z=n%256
  out[#out+1]=string.char(x)
  if c~="=" then out[#out+1]=string.char(y) end
  if d~="=" then out[#out+1]=string.char(z) end
 end
 return table.concat(out)
end
local function checksum(s)
 local a,b=1,0
 for i=1,#s do a=(a+s:byte(i))%65521;b=(b+a)%65521 end
 return string.format("%04X%04X",b,a)
end
local function encodeValue(v)
 if type(v)=="boolean" then return v and "B1" or "B0" end
 if type(v)=="number" then return "N"..string.format("%.14g",v) end
 local h=v:gsub(".",function(ch) return string.format("%02X",ch:byte()) end)
 return "S"..h
end
local function decodeValue(text,kind)
 local tag=text:sub(1,1);local payload=text:sub(2)
 if kind=="boolean" then if text=="B0" then return false,true elseif text=="B1" then return true,true end
 elseif kind=="number" then
  if tag~="N" or #payload>22 or not payload:match("^[%d%.%+%-eE]+$") then return nil,false end
  local v=tonumber(payload);if CC.Safety:IsNumber(v) then return v,true end
 elseif kind=="string" then
  if tag~="S" or #payload%2~=0 or #payload>1024 or not payload:match("^%x*$") then return nil,false end
  return (payload:gsub("..",function(h) return string.char(tonumber(h,16)) end)),true
 end
 return nil,false
end
local function ordered(t)
 local keys={};for k in pairs(t) do keys[#keys+1]=k end
 table.sort(keys);return keys
end
local function fieldsFrom(p)
 local rows={}
 local function visit(tbl,path)
  for _,key in ipairs(ordered(tbl)) do
   local v=tbl[key];local full=path=="" and key or path.."."..key
   if full=="info.tracked" then
    rows[#rows+1]="info.tracked.count="..encodeValue(#v)
    for i=1,#v do rows[#rows+1]="info.tracked."..i.."="..encodeValue(v[i]) end
   elseif type(v)=="table" then visit(v,full)
   else rows[#rows+1]=full.."="..encodeValue(v) end
  end
 end
 visit(p,"");return rows
end
local function schemaMap()
 local paths={}
 local function visit(t,path)
  for k,v in pairs(t) do
   local full=path=="" and k or path.."."..k
   if full=="info.tracked" then paths["info.tracked.count"]="number"
   elseif type(v)=="table" then visit(v,full)
   else paths[full]=type(v) end
  end
 end
 visit(CC.Defaults,"");return paths
end
local function put(tbl,path,val)
 local branch=tbl;local parts={}
 for p in path:gmatch("[^.]+") do parts[#parts+1]=p end
 for i=1,#parts-1 do branch=branch[parts[i]] end
 branch[parts[#parts]]=val
end
function P:Name(raw)
 if type(raw)~="string" then return nil,"Enter a profile name" end
 local name=raw:match("^%s*(.-)%s*$")
 if #name<1 or #name>32 or not name:match("^[%w][%w _%-]*$") then
  return nil,"Name must be 1-32 characters (letters, digits, spaces, _ or -)"
 end
 return name
end
function P:Library()
 return CC.SavedData.account and CC.SavedData.account.namedProfiles
end
function P:Names()
 local lib=self:Library();local names={}
 if type(lib)=="table" then
  for name,profile in pairs(lib) do if type(name)=="string" and type(profile)=="table" then names[#names+1]=name end end
 end
 table.sort(names);return names
end
function P:Guard()
 if CC.SavedData.readOnly or CC.Safety:InCombat() or not self:Library() then
  return false,"Profiles are unavailable during combat or read-only mode"
 end
 return true
end
function P:Save(raw,profile,overwrite)
 local ok,reason=self:Guard();if not ok then return false,reason end
 local name,why=self:Name(raw);if not name then return false,why end
 local lib=self:Library()
 if lib[name] and not overwrite then return false,"That profile exists. Use a different name or choose Replace."
 elseif not lib[name] and #self:Names()>=self.maxProfiles then return false,"Profile limit reached (20)" end
 local clean,errorText=CC.SavedData:Validate(profile or CC.profile,true)
 if not clean then return false,errorText end
 lib[name]=CC:Copy(clean);return true,"Saved '"..name.."'"
end
function P:Load(name)
 local ok,reason=self:Guard();if not ok then return false,reason end
 local current=self:Library()[name]
 if type(current)~="table" then return false,"Select a saved profile" end
 return CC.SavedData:Commit(CC:Copy(current))
end
function P:Copy(name,destination)
 local current=self:Library() and self:Library()[name]
 if type(current)~="table" then return false,"Select a saved profile to copy" end
 return self:Save(destination,current,false)
end
function P:Remove(name)
 local ok,reason=self:Guard();if not ok then return false,reason end
 if not self:Library()[name] then return false,"Select a saved profile" end
 self:Library()[name]=nil;return true,"Deleted '"..name.."'"
end
function P:Export(profile)
 local clean,why=CC.SavedData:Validate(profile or CC.profile,true)
 if not clean then return nil,why end
 local rows={"format=2","flavor="..CC.adapter.flavor}
 for _,line in ipairs(fieldsFrom(clean)) do rows[#rows+1]=line end
 local data=table.concat(rows,"\n")
 local code="CCP29:"..checksum(data)..":"..encode64(data)
 if #code>self.maxCode then return nil,"Profile exceeds the export size limit" end
 return code
end
function P:Decode(raw)
 if type(raw)~="string" or #raw>self.maxCode+100 then return nil,"Profile code is too long" end
 local code=raw:match("^%s*(.-)%s*$")
 local version,digest,enc=code:match("^CCP(%d+):([0-9A-F]+):([A-Za-z0-9+/=]+)$")
 if (version~="25" and version~="28" and version~="29") or not digest or #digest~=8 or #code>self.maxCode then return nil,"Not a supported Cursor Companion profile code" end
 local data=decode64(enc)
 if not data or #data>64000 or checksum(data)~=digest then return nil,"Profile checksum or encoding is invalid" end
 local rows={};local count=0
 for line in (data.."\n"):gmatch("(.-)\n") do
  count=count+1;if count>self.maxFields then return nil,"Too many profile fields" end
  local name,value=line:match("^([%w%.]+)=(.*)$")
  if not name or rows[name]~=nil then return nil,"Malformed or duplicate profile field" end
  rows[name]=value
 end
 if (version=="25" and rows.format~="1") or ((version=="28" or version=="29") and rows.format~="2") then return nil,"Unsupported profile format" end
 if rows.flavor~=CC.adapter.flavor then return nil,"Profile belongs to another WoW client flavor" end
 rows.format=nil;rows.flavor=nil
 local legacyOptionCode={}
 for _,k in ipairs({"focus","inspect","ping","mark"}) do
  legacyOptionCode[k]=rows["palette."..k]
 end
 local schema=schemaMap();local result=CC:Copy(CC.Defaults)
 local legacyQuest=rows["rings.outer2.questCompass"]
 local oldCode=(rows["compass.enabled"]==nil)
 local priorPointer=rows["compass.pointerScale"]
 if priorPointer~=nil then
  local value,ok=decodeValue(priorPointer,"number")
  if not ok or value<1 or value>1.6 then return nil,"Invalid legacy pointer scale" end
  rows["compass.pointerScale"]=nil
  if rows["compass.pointerWidth"]==nil then rows["compass.pointerWidth"]=encodeValue(value) end
  if rows["compass.pointerHeight"]==nil then rows["compass.pointerHeight"]=encodeValue(value) end
 end
 if legacyQuest~=nil then
  if legacyQuest~="B0" and legacyQuest~="B1" then return nil,"Invalid legacy compass field" end
  rows["rings.outer2.questCompass"]=nil
 end
 for path,kind in pairs(schema) do
  local rawValue=rows[path]
  local f10=(path=="palette.autoTargetEnemy" or path=="beacon.shareMenuTargets" or path=="beacon.receiveMenuTargets"
   or path=="alerts.beaconReceived" or path=="alerts.beaconSent" or path=="alerts.beaconUpdated"
   or path:match("^alerts%.eventColors%.beaconReceived%.") or path:match("^alerts%.eventColors%.beaconSent%.") or path:match("^alerts%.eventColors%.beaconUpdated%."))
  if rawValue==nil and f10 then local d=CC.Defaults;for key in path:gmatch("[^.]+") do d=d[key] end;rawValue=encodeValue(d) end
  if rawValue==nil and version~="29" and (path:match("^customMenus%.") or path:match("^quickMenus%.") or path:match("^beacon%.colors%.") or path=="beacon.nativePings" or path=="beacon.typeColors" or path=="beacon.pingLifetime" or path=="beacon.trackPingUnits") then
   local d=CC.Defaults;for key in path:gmatch("[^.]+") do d=d[key] end
   rawValue=encodeValue(d)
  end
  -- Explicitly grandfather only the four fields introduced by F8.2. Earlier
  -- CCP28 profiles stay valid; unrelated missing fields remain hard errors.
  local f82={['beacon.acceptFrom']=true,['beacon.autoSync']=true,['beacon.showDelivery']=true,['beacon.staleAfter']=true}
  if rawValue==nil and f82[path] then rawValue=encodeValue(CC.Defaults.beacon[path:sub(8)]) end
  -- Only legacy codes may omit the original F8 sections.
  if rawValue==nil and version=="25" and (path:match("^utility%.") or path:match("^fishing%.") or path:match("^beacon%.")) then
   local default=CC.Defaults
   for key in path:gmatch("[^.]+") do default=default[key] end
   rawValue=encodeValue(default)
  end
  -- Prior signed CCP25 exports (v2.5.x/v2.6.0) did not contain newly
  -- introduced optional fields. Populate only explicitly grandfathered
  -- fields; all other missing fields remain strict import errors.
  if version=="25" and rawValue==nil and path:sub(1,8)=="compass." then
   rawValue=encodeValue(CC.Defaults.compass[path:sub(9)])
  end
  local optionalAlert={
   ["alerts.colorMode"]=true,
   ["alerts.combatStart"]=true,["alerts.combatEnd"]=true,["alerts.playerCastStart"]=true,
   ["alerts.playerCastInterrupted"]=true,["alerts.playerCastFailed"]=true,
   ["alerts.playerDead"]=true,["alerts.targetChanged"]=true,
   ["alerts.encounterStart"]=true,["alerts.encounterEnd"]=true,
  }
  if version=="25" and rawValue==nil and path:sub(1,19)=="alerts.eventColors." then
   local event,component=path:match("^alerts%.eventColors%.([^.]+)%.([rgb])$")
   if event and component and CC.Defaults.alerts.eventColors[event] then
    rawValue=encodeValue(CC.Defaults.alerts.eventColors[event][component])
   end
  end
  if version=="25" and rawValue==nil and path:sub(1,11)=="questNotes." then
   rawValue=encodeValue(CC.Defaults.questNotes[path:sub(12)])
  end
  if version=="25" and rawValue==nil and path=="hideOverWindows" then rawValue=encodeValue(CC.Defaults.hideOverWindows) end
  -- Signed profile codes issued before r02 lacked the optional Settings shortcut.
  -- Preserve the historical visible shortcut rather than rejecting their import.
  if version=="25" and rawValue==nil and path=="palette.settings" then rawValue=encodeValue(CC.Defaults.palette.settings) end
  -- v2.7.3 adds a purely visual menu skin; signed older profiles use Tracker.
  if version=="25" and rawValue==nil and path=="palette.style" then rawValue=encodeValue(CC.Defaults.palette.style) end
  local optionalGeneral={character=true,bags=true,spellbook=true,talents=true}
  local optionalEnemy={enemyFocus="focus",enemyInspect="inspect",enemyPing="ping",enemyMark="mark"}
  local paletteKey=path:match("^palette%.([^.]+)$")
  if version=="25" and rawValue==nil and paletteKey and optionalGeneral[paletteKey] then
   rawValue=encodeValue(CC.Defaults.palette[paletteKey])
  end
  if version=="25" and rawValue==nil and paletteKey and optionalEnemy[paletteKey] then
   local prior=legacyOptionCode[optionalEnemy[paletteKey]]
   rawValue=prior or encodeValue(CC.Defaults.palette[paletteKey])
  end
  if version=="25" and rawValue==nil and optionalAlert[path] then
   rawValue=encodeValue(CC.Defaults.alerts[path:sub(8)])
  end
  if rawValue==nil then return nil,"Missing profile field: "..path end
  local value,valid=decodeValue(rawValue,kind)
  if not valid then return nil,"Invalid profile field: "..path end
  if path=="info.tracked.count" then
   if value%1~=0 or value<1 or value>8 then return nil,"Invalid spell list length" end
   result.info.tracked={};for i=1,value do
    local key="info.tracked."..i;local spell,good=decodeValue(rows[key] or "","string")
    if not good or #spell>200 then return nil,"Invalid tracked spell" end
    result.info.tracked[i]=spell;rows[key]=nil
   end
  else put(result,path,value) end
  rows[path]=nil
 end
 -- Older signed profiles contain retired out-of-combat threshold/enemy-cast
 -- fields. Check their type and discard ONLY those known keys; continue to
 -- reject every other unknown field and preserve strict checksum validation.
 local retired={
  ["alerts.playerHealth"]="boolean",["alerts.playerResource"]="boolean",
  ["alerts.targetHealth"]="boolean",["alerts.targetCasting"]="boolean",
  ["alerts.focusCasting"]="boolean",["alerts.repeatEnabled"]="boolean",
  ["alerts.healthThreshold"]="number",["alerts.resourceThreshold"]="number",
  ["alerts.executeThreshold"]="number",["alerts.repeatSeconds"]="number",
  ["alerts.priority"]="string",
 }
 for path,kind in pairs(retired) do
  if rows[path]~=nil then
   local _,ok=decodeValue(rows[path],kind)
   if not ok then return nil,"Invalid retired profile field: "..path end
   rows[path]=nil
  end
 end
 for unknown in pairs(rows) do return nil,"Unexpected profile field: "..unknown end
 if oldCode and legacyQuest=="B1" then
  result.rings.outer2.questCompass=true
  result.compass._legacyImport=true
 end
 if version~="29" and CC.MenuModel then result.customMenus=nil;result.quickMenus=nil end
 local clean,why=CC.SavedData:Validate(result,true)
 if not clean then return nil,why end
 return clean
end
function P:Import(code,name)
 local profile,why=self:Decode(code)
 if not profile then return false,why end
 -- Imported profiles are saved, but never applied automatically.
 return self:Save(name,profile,false)
end
