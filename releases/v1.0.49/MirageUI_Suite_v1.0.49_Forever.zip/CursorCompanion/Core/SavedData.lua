local _,CC=...
CC.SavedData={}
local function listed(v,list) for _,x in ipairs(list) do if v==x then return true end end end
local function walk(input,default,path,strict)
 local out={}
 for k,d in pairs(default) do
  local full=path=="" and k or path.."."..k
  local pattern=full:gsub("rings%.outer%.","rings.*."):gsub("rings%.inner%.","rings.*."):gsub("rings%.outer2%.","rings.*.")
  pattern=pattern:gsub("alerts%.eventColors%.[^.]+%.","alerts.eventColors.*."):gsub("beacon%.colors%.[^.]+%.","beacon.colors.*.")
  local v; if type(input)=="table" then v=input[k] end
  if full=="info.tracked" then
    local rows={}
    if type(v)=="table" then
     if strict and #v>8 then return nil,"You can track up to eight spells." end
     for i=1,math.min(#v,8) do
      if type(v[i])~="string" or #v[i]>200 then
       if strict then return nil,"Enter a spell name or number." end
      else rows[#rows+1]=v[i] end
     end
    end
    if #rows==0 then rows={""} end
    out[k]=rows
   elseif type(d)=="table" then local r,e=walk(v,d,full,strict); if not r then return nil,e end; out[k]=r
  else
   if type(v)~=type(d) or (type(v)=="number" and not CC.Safety:IsNumber(v)) then
    if strict and v~=nil then return nil,"Invalid value: "..full end; v=d
   end
   local b=CC.Bounds[pattern]
   if b and (v<b[1] or v>b[2]) then if strict then return nil,"Out of bounds: "..full end; v=math.max(b[1],math.min(b[2],v)) end
   local e=CC.Enums[pattern]; if e and not listed(v,e) then if strict then return nil,"Unknown option: "..full end; v=d end
   if type(v)=="string" and #v>512 then if strict then return nil,"Text too long: "..full end; v=d end
   out[k]=v
  end
 end
 local r=out.rings
 local compass=out.compass
 if compass then
  compass.questCompass=true;compass.role="Decorative";compass.speed=0
  compass.direction="Clockwise"
  if compass.enabled then
   -- The two third-slot displays are mutually exclusive. The compass has
   -- an independent geometry and role provider; never modify outer/inner.
   if r then r.outer2.enabled=false end
   local largest=0;local widest=1
   if r then for _,k in ipairs({"inner","outer"}) do
    if r[k].enabled then
     largest=math.max(largest,r[k].size)
     widest=math.max(widest,r[k].stroke)
    end
   end end
   local gap=math.max(14,2*(3+math.max(widest,compass.stroke))+2)
   compass.size=math.min(176,math.max(compass.size,largest+gap))
  end
 end
 if r then
  if r.outer.size>128 then if strict then return nil,"Outer ring diameter must be at most 128." end;r.outer.size=128 end
  if r.outer.size<24 then if strict then return nil,"Outer diameter must be at least 24." end; r.outer.size=24 end
  if r.inner.size>100 then if strict then return nil,"Inner diameter must be at most 100." end;r.inner.size=100 end
  for _,x in pairs(r) do x.stroke=math.floor(x.stroke+0.5) end
  -- Only active neighbours must be separated; a disabled ring cannot force a change.
  local pairsToCheck={{"inner","outer"},{"outer","outer2"},{"inner","outer2"}}
  for _,keys in ipairs(pairsToCheck) do
   local small,big=r[keys[1]],r[keys[2]]
   if small.enabled and big.enabled then
    local intermediate=(keys[1]=="inner" and keys[2]=="outer2" and r.outer.enabled)
    if not intermediate and (big.size-small.size)/2 < 3+math.max(big.stroke,small.stroke) then
     if strict then return nil,"Increase "..keys[2].." diameter or reduce "..keys[1].." diameter to leave a visible 3-unit gap." end
     -- Keep the originally enabled outer ring on legacy repairs where possible.
     if keys[2]=="outer2" then big.enabled=false else small.enabled=false end
    end
   end
  end
 end
 return out
end
function CC.SavedData:Validate(p,strict)
 local normalized=CC.Migrations:Usability(p)
 local clean,why=walk(normalized,CC.Defaults,"",strict==true)
 if not clean then return nil,why end
 if clean.compass.mode~="Quest" and clean.compass.mode~="Beacon" then
  if strict then return nil,"Choose Quest Compass or Beacon navigation." end
  clean.compass.mode="Quest"
 end
 if clean.customMenus then
  clean.utility.enabled=clean.customMenus.menu1.enabled
  for i=1,6 do clean.utility["slot"..i]=CC:Copy(clean.customMenus.menu1["slot"..i]) end
 end
 if CC.Utility and CC.Utility.ValidateSlot then
  for i=1,6 do
   local slot,errorText=CC.Utility:ValidateSlot(clean.utility["slot"..i],strict==true)
   if not slot then
    if strict then return nil,"Custom Menu 1 slot "..i..": "..tostring(errorText) end
    slot=CC:Copy(CC.Defaults.utility["slot"..i]);slot.enabled=false
    self.warning="An invalid saved Custom Menu slot was disabled. Review Quick menu settings before enabling it."
   end
   clean.utility["slot"..i]=slot
  end
 end
 if CC.MenuModel then
  local checked,errorText=CC.MenuModel:Validate(clean,strict==true)
  if not checked then return nil,errorText end
  clean.utility.enabled=clean.customMenus.menu1.enabled
  for i=1,6 do clean.utility["slot"..i]=CC:Copy(clean.customMenus.menu1["slot"..i]) end
 end
 local pole=clean.fishing.poleID
 if pole~="" and (not pole:match("^%d+$") or tonumber(pole)<1 or tonumber(pole)>2147483647) then
  if strict then return nil,"Fishing pole: enter an item ID, or leave blank for automatic selection." end
  clean.fishing.poleID=""
 end
 clean.fishing.accessMode="Cast check"
 clean.beacon.expiration=math.floor(clean.beacon.expiration)
 clean.beacon.staleAfter=math.floor(clean.beacon.staleAfter)
 return clean
end
function CC.SavedData:Initialize()
 self.readOnly=false; self.warning=nil
 local flavor=CC.adapter.flavor
 local a,c=CursorCompanionV2DB,CursorCompanionCharacterV2DB
 if (a~=nil and (type(a)~="table" or a.schema~=2 or type(a.flavors)~="table")) or
    (c~=nil and (type(c)~="table" or c.schema~=2)) then
  self.readOnly=true; self.warning="Unknown settings schema preserved; visuals disabled. No downgrade was attempted."
  CC.profile=CC:Copy(CC.Defaults);CC.profile.enabled=false;return
 end
 local preparedA,preparedC
 if not a or not c or type(a.flavors[flavor])~="table" then
  preparedA,preparedC=CC.Migrations:Prepare(CursorCompanionDB,CursorCompanionCharacterDB,flavor)
 end
 -- Prepare complete validated replacements before publishing either new root.
 a=CC:Copy(a or preparedA);c=CC:Copy(c or preparedC)
 if type(a.flavors[flavor])~="table" then a.flavors[flavor]=preparedA.flavors[flavor] end
 local previousRevision=a.flavors[flavor].usabilityRevision or 0
 a.flavors[flavor].profile=self:Validate(a.flavors[flavor].profile)
 -- UX02 explicitly requests an accessible menu by default. One-time beta.1 upgrade only.
 if previousRevision<2 then a.flavors[flavor].profile.palette.enabled=true end
 -- UX04 normalization removes obsolete behavior without re-enabling dismissed setup.
 -- The chosen idle timeout still governs every ring role.
 a.flavors[flavor].usabilityRevision=8
 if type(a.flavors[flavor].onboarding)~="table" then a.flavors[flavor].onboarding={completed=false,dismissed=false} end
 if c.flavor~=flavor then c={schema=2,useCharacter=false,flavor=flavor} end
 c.useCharacter=c.useCharacter==true
 if type(c.profile)=="table" or c.useCharacter then c.profile=self:Validate(c.profile); if previousRevision<2 then c.profile.palette.enabled=true end end
 if type(a.flavors[flavor].namedProfiles)~="table" then a.flavors[flavor].namedProfiles={} end
 if type(a.evidence)~="table" then a.evidence={} end
 CursorCompanionV2DB,CursorCompanionCharacterV2DB=a,c
 self.account=a.flavors[flavor];self.character=c
 CC.profile=c.useCharacter and c.profile or self.account.profile
 self.migration=self.account.migration or "V2_EXISTING"
end
function CC.SavedData:Commit(p)
 if self.readOnly or CC.Safety:InCombat() then return false,"Settings cannot be saved right now. Leave combat first." end
 local v,err=self:Validate(p,true);if not v then return false,err end
 self.undo=CC:Copy(CC.profile)
 if self.character.useCharacter then self.character.profile=v else self.account.profile=v end
 CC.profile=v; CC:ApplyProfile();return true
end
function CC.SavedData:EmergencyOff()
 CC.profile.enabled=false
 if not self.readOnly and self.character then
  if self.character.useCharacter then self.character.profile.enabled=false else self.account.profile.enabled=false end
 end
 CC.Timing:Stop();CC.VisualLifecycle:Stop("DISABLED");CC.Palette:Close()
 if CC.Palette then CC.Palette:Rebuild() end
 if CC.Fishing then CC.Fishing:ApplyProfile() end
 if CC.Bindings then CC.Bindings:RefreshActions() end
end
function CC.SavedData:Undo()
 if not self.undo then return false,"No prior applied settings." end
 return self:Commit(CC:Copy(self.undo))
end
function CC.SavedData:UseCharacter(yes)
 if self.readOnly or CC.Safety:InCombat() then return false end
 if yes then self.character.profile=CC:Copy(CC.profile) end
 self.character.useCharacter=yes==true;self.character.flavor=CC.adapter.flavor
 CC.profile=yes and self.character.profile or self.account.profile;self.undo=nil;CC:ApplyProfile();return true
end
function CC.SavedData:Reset() return self:Commit(CC:FactoryProfile()) end
function CC.SavedData:Set(key,value)
 local p=CC:Copy(CC.profile)
 if key=="theme" then
  local rgb=CC.Themes[value];if not rgb then return false,"Choose a color in Rings." end
  p.rings.outer.r,p.rings.outer.g,p.rings.outer.b=rgb[1],rgb[2],rgb[3];p.rings.outer.colorMode="Manual"
 elseif key=="size" or key=="opacity" or key=="glow" then p.rings.outer[key]=value
 elseif key=="shape" then p.rings.outer.style=value else p[key]=value end
 return self:Commit(p)
end
