local _,CC=...
CC.Evidence={}
local results={PASS=true,PARTIAL=true,FAIL=true,NOT_RUN=true,NA=true}
function CC.Evidence:Key() return CC.version.."|"..CC.ClientIdentity.flavor.."|"..CC.ClientIdentity.build end
function CC.Evidence:Record(test,result)
 if CC.Safety:InCombat() or CC.SavedData.readOnly then return false end
 local n=tonumber((test or ""):match("^T(%d%d)$"))
 if not n or n<1 or n>36 or not results[result] then CC:Print("Use /cc record T01 PASS (PASS/PARTIAL/FAIL/NOT_RUN/NA). User observations only.");return false end
 local db=CursorCompanionV2DB.evidence;local key=self:Key()
 -- Bound to 8 build records; explicit test-case set is finite (36).
 if not db[key] then local count=0;for _ in pairs(db) do count=count+1 end
  if count>=8 then CC:Print("Evidence store full; use external test card for this build.");return false end;db[key]={}
 end
 db[key][test]=result;CC:Print("Recorded user-observed "..test.."="..result.." for this exact build.");return true
end
function CC.Evidence:Get()
 if CC.SavedData.readOnly or not CursorCompanionV2DB then return {} end
 return CursorCompanionV2DB.evidence[self:Key()] or {}
end
