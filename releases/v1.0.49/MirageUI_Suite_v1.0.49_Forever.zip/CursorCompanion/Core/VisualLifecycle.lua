local _,CC=...
CC.VisualLifecycle={}
-- Independent cursor visuals share this passive parent. An effect created
-- during startup inherits suppression, even if its own OnShow fires later.
function CC.VisualLifecycle:OverlayParent()
 if not self.overlayParent then
  local parent=CreateFrame("Frame",nil,UIParent)
  parent:SetAllPoints(UIParent);CC.OverlaySafety:MakePassive(parent)
  local animation=CC.Safety:Field(CC.Safety:Field(_G,"MirageUI"),"StartupAnimation")
  self.startupHidden=self.startupHidden or CC.Safety:Field(animation,"armed")==true or CC.Safety:Field(animation,"active")==true
  parent:SetShown(not self.startupHidden);self.overlayParent=parent
 end
 return self.overlayParent
end
function CC.VisualLifecycle:SetStartupPresentation(active)
 self.startupHidden=active
 if self.overlayParent then self.overlayParent:SetShown(not active) end
 if active then
  if CC.CompanionFrame.frame then CC.CompanionFrame:Hide() end
  if CC.SignalFeedback then CC.SignalFeedback:Hide() end
  if CC.FishingStatus and CC.FishingStatus.frame then CC.FishingStatus:Hide() end
  self.lastX=nil;self.lastY=nil;self.idle=0
 elseif CC.state.initialized and CC.FishingStatus then
  CC.FishingStatus:ResumeChannel()
 end
end
function CC.VisualLifecycle:WorkspaceActive()
 local S=CC.Safety
 local state=S:Field(S:Field(_G,"MirageUI"),"state")
 return self.workspaceCapture==true or S:Field(state,"keybindWorkspace")==true
end
function CC.VisualLifecycle:RefreshWorkspacePresentation()
 if not self:WorkspaceActive() then self.workspaceHidden=nil;return false end
 if not self.workspaceHidden then
  if CC.CompanionFrame and CC.CompanionFrame.frame then CC.CompanionFrame:Hide() end
  if CC.SignalFeedback then CC.SignalFeedback:Hide() end
  if CC.Context then CC.Context:Invalidate() end
  self.lastX=nil;self.lastY=nil;self.idle=0;self.workspaceHidden=true
 end
 CC.state.reason="KEYBIND_WORKSPACE"
 return true
end
function CC.VisualLifecycle:CreateController()
 self.controller=CreateFrame("Frame",nil,UIParent);CC.OverlaySafety:MakePassive(self.controller);self.idle=0
 self.handler=function(_,dt)
  local start=CC.Diagnostics.profiling and debugprofilestop and debugprofilestop()
  local ok=pcall(self.Update,self,dt)
  if not ok then CC.Diagnostics:Fault("UPDATE_FAULT");self:Stop("UPDATE_FAULT") end
  if start then CC.Diagnostics:Measure(debugprofilestop()-start) end
 end
end
function CC.VisualLifecycle:Stop(reason)
 if CC.QuestRoutePanel then CC.QuestRoutePanel:Close() end
 if CC.QuestNotes then CC.QuestNotes:Close();if CC.QuestRoutePanel then CC.QuestRoutePanel:Close() end end
 if self.controller then self.controller:SetScript("OnUpdate",nil) end
 if CC.CompanionFrame.frame then CC.CompanionFrame:Hide() end
 if CC.Context then CC.Context:Stop() end
 if CC.Timing then CC.Timing:Stop() end
 if CC.Vitals then CC.Vitals:Stop() end
 if CC.Navigation then CC.Navigation:Reset("OFF") elseif CC.QuestCompass then CC.QuestCompass:Reset("OFF") end
 if CC.AlertConditions then CC.AlertConditions:Stop() end
 CC.state.running=false;CC.state.reason=reason or "DISABLED";self.lastX=nil;self.lastY=nil;self.idle=0
end
function CC.VisualLifecycle:Reconcile()
 if not CC.profile.enabled then self:Stop("DISABLED");return end
 if CC.SavedData.readOnly then self:Stop("SCHEMA_UNSUPPORTED");return end
 if not CC.ClientIdentity.allowed then self:Stop("UNSUPPORTED_BUILD");return end
 if not CC.Capabilities.ready then self:Stop("MISSING_API");return end
 if not CC.OverlaySafety:Check() then self:Stop("INPUT_SAFETY_FAILED");return end
 if #CC.Diagnostics.conflicts>0 and not CC.state.conflictAcknowledged then self:Stop("CURSOR_ADDON_CONFLICT");return end
 if not CC.state.inWorld or CC.state.cinematic then self:Stop("WORLD_TRANSITION");return end
 if CC.state.fault then self:Stop(CC.state.fault);return end
 if not CC.state.running then
  CC.state.running=true;self.idle=0;self.lastX=nil;self.lastY=nil;self.controller:SetScript("OnUpdate",self.handler)
  CC.Context:Reset();CC.Timing:Start();CC.Vitals:Start();CC.AlertConditions:Start()
 end
end
function CC.VisualLifecycle:Update(dt)
 CC.Diagnostics.updateCount=CC.Diagnostics.updateCount+1
 if not CC.Safety:IsNumber(dt) or dt<0 then self:Stop("TIME_UNKNOWN");return end
 -- Keep provider subscriptions and the single existing heartbeat alive. Once
 -- the editor clears its flag the next frame resumes ordinary visuals, even
 -- if capture is released just before the core clears the workspace flag.
 if self.startupHidden then CC.state.reason="STARTUP_ANIMATION";return end
 if self:RefreshWorkspacePresentation() then return end
 local timingOK=pcall(CC.Timing.Tick,CC.Timing,dt)
 if not timingOK then CC.Timing:Stop();CC.Diagnostics:OptionalFault("TIMING_UPDATE_FAULT") end
 local captured,reason=CC.API:MouseCaptured()
 if captured then
  CC.CompanionFrame:Hide();CC.Context:Invalidate();self.lastX=nil;self.lastY=nil;self.idle=0;CC.state.reason=reason
  if reason=="MOUSELOOK" then CC.Palette:Close() end
  return
 end
 local x,y,problem=CC.CursorPosition:Sample()
 if x==nil then CC.CompanionFrame:Hide();CC.Context:Invalidate();self.lastX=nil;CC.state.reason=problem;return end
 if CC.profile.hideOverWindows and CC.WindowHover and CC.WindowHover:IsHovering() then
  CC.CompanionFrame:Hide();CC.Context:Invalidate()
  self.lastX=nil;self.lastY=nil;self.idle=0
  CC.state.reason="UI_WINDOW_HOVER"
  return
 end
 if dt>0.25 then CC.Trails:Flush();CC.Context:Invalidate() end
 if x~=self.lastX or y~=self.lastY then self.idle=0 else self.idle=self.idle+math.min(dt,1) end
 self.lastX,self.lastY=x,y
 if not CC.Context.quarantined then
  local contextOK=pcall(CC.Context.Tick,CC.Context,math.min(dt,0.25))
  if not contextOK then CC.Context.quarantined=true;CC.Context:Stop();CC.Diagnostics:OptionalFault("CONTEXT_UPDATE_FAULT") end
 end
 local idle=CC.profile.idleHideSeconds>0 and self.idle>=CC.profile.idleHideSeconds
 -- Alerts are attention signals, not decorative ring indicators: an idle
 -- pointer may hide rings, but must not silence an active visual alert.
 CC.AlertConditions:Tick(dt,true)
 if CC.Navigation then
  local ok=pcall(CC.Navigation.Tick,CC.Navigation,dt)
  if not ok then CC.Navigation:Reset("PROVIDER_ERROR");CC.Diagnostics:OptionalFault("NAVIGATION_ERROR") end
 end
 CC.CompanionFrame:Place(x,y,dt,idle);CC.state.reason=idle and "IDLE_HIDDEN" or "VISUAL_ACTIVE"
end
