local _,CC=...
CC.Diagnostics={updateCount=0,sampleCount=0,errorCount=0,conflicts={},lastSelfTest="NOT_RUN",profileSamples={},profileIndex=0,profiling=false,lastFault="NONE"}
-- This collector must be usable before SavedVariables and feature modules are
-- initialized. It observes Blizzard's warning; it never hides or replaces it.
CC.Diagnostics.nativeBlocks={count=0,blocked=0,forbidden=0,history={},notices=0}
local function readableText(value)
 return CC.Safety and CC.Safety:IsText(value)
end
local function apiSymbol(value)
 if not readableText(value) then return "UNAVAILABLE" end
 -- Export an API symbol, not arguments, stack traces, file paths, names or chat.
 -- A dotted/colon-qualified symbol with optional empty parentheses is enough
 -- to identify Frame:RegisterEvent(), SetAttribute(), C_* calls, etc.
 if #value>160 then return "REDACTED" end
 local symbol
 -- The explicit alternatives avoid accepting nonempty argument lists.
 symbol=value:match("^([%a_][%w_%.:]*)%(%)$") or value:match("^([%a_][%w_%.:]*)$")
 if not symbol or #symbol>120 then return "REDACTED" end
 return symbol
end
function CC.Diagnostics:NativeActionBlocked(event,addon,func)
 if event~="ADDON_ACTION_BLOCKED" and event~="ADDON_ACTION_FORBIDDEN" then return false end
 -- Do not attribute another addon's warnings to Cursor Companion.
 if not readableText(addon) or addon~=CC.name then return false end
 local state=CC.state or {}
 local record={event=event,api=apiSymbol(func),
  phase=state.initialized and "RUNTIME" or (state.initializing and "INITIALIZING" or "PRE_INITIALIZE"),
  stage=state.initialized and "RUNTIME" or apiSymbol(state.initializationStage or "NOT_STARTED"),
  combat=CC.Safety:InCombat()}
 local records=self.nativeBlocks
 records.count=math.min(9999,records.count+1)
 local key=event=="ADDON_ACTION_FORBIDDEN" and "forbidden" or "blocked"
 records[key]=math.min(9999,records[key]+1)
 records.first=records.first or record;records.last=record
 records.history[#records.history+1]=record
 while #records.history>8 do table.remove(records.history,1) end
 self.errorCount=math.min(9999,self.errorCount+1)
 self.lastFault=event=="ADDON_ACTION_FORBIDDEN" and "NATIVE_ACTION_FORBIDDEN" or "NATIVE_ACTION_BLOCKED"
 -- Bound notification noise, but count every denial and retain the most recent
 -- eight sanitized records. Never disable Bags, fishing, or the whole addon.
 local signature=event..":"..record.api
 if records.notices<3 and records.lastNotice~=signature then
  records.lastNotice=signature;records.notices=records.notices+1
  CC:Print("Blizzard blocked a Cursor Companion action ("..record.api.."). /cc export records the details; no action was retried.")
 end
 return true
end
function CC.Diagnostics:AppendNativeDiagnostics(fields)
 local blocks=self.nativeBlocks
 local first,last=blocks.first or {},blocks.last or {}
 fields[#fields+1]="native_block_monitor=EARLY_STARTUP_AND_RUNTIME"
 fields[#fields+1]="native_block_count="..blocks.count
 fields[#fields+1]="native_blocked_count="..blocks.blocked
 fields[#fields+1]="native_forbidden_count="..blocks.forbidden
 fields[#fields+1]="native_first_function="..(first.api or "NONE")
 fields[#fields+1]="native_last_function="..(last.api or "NONE")
 fields[#fields+1]="native_last_event="..(last.event or "NONE")
 fields[#fields+1]="native_last_phase="..(last.phase or "NONE")
 fields[#fields+1]="native_last_stage="..(last.stage or "NONE")
 fields[#fields+1]="native_last_combat="..(last.combat==nil and "UNKNOWN" or tostring(last.combat))
 fields[#fields+1]="native_block_history_scope=CURRENT_UI_SESSION_SANITIZED_SYMBOLS_ONLY"
 for i,record in ipairs(blocks.history) do
  fields[#fields+1]="native_block_"..i.."="..record.event.."|"..record.api.."|"..record.phase.."|"..record.stage.."|combat="..tostring(record.combat)
 end
 local native=CC.NativePings
 fields[#fields+1]="native_ping_event_policy="..(native and native.eventPolicy or "NOT_LOADED")
 fields[#fields+1]="native_ping_listener="..(native and native.status or "NOT_LOADED")
 fields[#fields+1]="native_ping_events="..(native and native.RegisteredEvents and native:RegisteredEvents() or "NONE")
end
function CC.Diagnostics:ScanConflicts()
 self.conflicts={}
 for _,name in ipairs({"Glint","GlintCursor","GlintCursorTrail","CursorTrail","SimpleMouseCursor","CursorGlow","CursorRing","UltimateMouseCursor","MouseCursor","CursorMod","CursorCompanionTimingProof","CursorCompanionContextProof"}) do
  if CC.API:GetAddOnLoaded(name) then table.insert(self.conflicts,name) end
 end
end
function CC.Diagnostics:OptionalFault(code)
 self.errorCount=math.min(9999,self.errorCount+1);self.lastFault=code;CC:Print("Feature isolated: "..code..". /cc export after combat.")
end
function CC.Diagnostics:Fault(code) self:OptionalFault(code);CC.state.fault=code end
function CC.Diagnostics:Measure(ms)
 if not CC.Safety:IsNumber(ms) or ms<0 then return end
 self.profileIndex=self.profileIndex%512+1;self.profileSamples[self.profileIndex]=ms
end
function CC.Diagnostics:SelfTest()
 local p=CC.SavedData:Validate(CC.profile,true)
 local ok=p~=nil and CC.OverlaySafety:Check()
 self.lastSelfTest=ok and "STRUCTURAL_PASS_NOT_NATIVE_CERTIFICATION" or "STRUCTURAL_FAIL"
 return ok
end
function CC.Diagnostics:ForeverStatus()
 local c=CC.ClientIdentity
 local a=CC.Capabilities
 local function yes(v) return v and "YES" or "NO" end
 return "Forever "..tostring(c.version).." build "..tostring(c.build).." interface "..tostring(c.interface)
    .." | "..tostring(c.verdict).." | visuals="..yes(a.ready and c.allowed)
    .." health="..yes(a.health).." resource="..yes(a.resource).." cast="..yes(a.castTiming)
    .." gcd="..yes(a.gcdTiming).." range/context="..yes(a.context)
    .." alerts="..yes(a.alerts).." player-actions="..yes(a.actions)
end
function CC.Diagnostics:Report()
 local c=CC.ClientIdentity;local s=CC.Context:Get();local fields={
 "CCDIAG=4","addon="..CC.version,"plan="..CC.planVersion,"flavor="..c.flavor,"patch="..c.version,"build="..c.build,"interface="..tostring(c.interface),
 "compatibility="..c.verdict,"provider_build_policy="..tostring(c.providerBuildStatus),"native_integrated=NOT_CERTIFIED_EXTERNAL_OR_USER_RECORDS","historical_proofs=MIDNIGHT_SCOPED_USER_ACCEPTANCE","native_forever=NOT_RUN_THIS_BUILD","forever_edition="..tostring(CC.edition),"provider_allowed="..tostring(c.providerAllowed),
 "setup_completed="..tostring(CC.SavedData.account and CC.SavedData.account.onboarding and CC.SavedData.account.onboarding.completed==true or false),
 "minimap_button=false;launcher=SUITE_MENU","minimap_visibility="..tostring(CC.Minimap and CC.Minimap.visibilityReason or "NOT_CREATED"),"text_layout=MEASURED_F3","tracked_spell_rows="..tostring(#CC.profile.info.tracked),
 "custom_menus="..tostring(CC.profile.customMenus and ((CC.profile.customMenus.menu1.enabled and 1 or 0)+(CC.profile.customMenus.menu2.enabled and 1 or 0)+(CC.profile.customMenus.menu3.enabled and 1 or 0)+(CC.profile.customMenus.menu4.enabled and 1 or 0)) or 0),
 "fishing_enabled="..tostring(CC.profile.fishing.enabled),
 "fishing_state="..tostring(CC.Fishing:GetStatus().phase),
 "fishing_access="..tostring(CC.Fishing:GetStatus().access),
 "fishing_swap="..tostring(CC.Fishing:GetStatus().swap),
 "fishing_restore_wanted="..tostring(CC.Fishing:GetStatus().restoreWanted),
 "fishing_water_probe=CAST_RESULT_ONLY","fishing_bite_detection=UNAVAILABLE",
 "fishing_channel_press="..tostring(CC.Fishing:GetStatus().channelPress),
 "fishing_recast_requests="..tostring(CC.Fishing:GetStatus().recastRequests),
 "fishing_bound="..tostring(CC.Bindings:FishingCurrent()~=nil),
 "navigation="..CC.Navigation:Summary(),
 "navigation_mode="..CC.Navigation:Mode(),
 "navigation_bound="..tostring(CC.Bindings:NotesCurrent()~=nil),
 "navigation_shortcut="..tostring(CC.Bindings:NotesCurrent() or "UNASSIGNED"),
 "navigation_pending="..tostring(CC.Navigation:PendingShortcutChange() or "NONE"),
 "navigation_last_mode="..tostring(CC.Navigation.lastMode or "NOT_RUN"),
 "navigation_last_action="..tostring(CC.Navigation.lastAction or "NOT_RUN"),
 "navigation_last_result="..tostring(CC.Navigation.lastResult or "NOT_RUN"),
 "beacon="..CC.Beacon:Summary(),"beacon_transport=HIDDEN_ADDON_ONLY",
 "menu_bound="..tostring(CC.Bindings:Current()~=nil),
 "menu_layout=RADIAL","menu_dismiss="..(CC.profile.palette.closeMode=="Escape only" and "ESCAPE_ONLY" or "CLICK_AND_ESCAPE"),
 "subject_policy=OOC_GUID_SNAPSHOT_COMBAT_CURRENT_TARGET",
 "menu_auto_target_enemy="..tostring(CC.profile.palette.autoTargetEnemy~=false),
 "menu_signal_status="..tostring(CC.NativePings.menuStatus or "NOT_USED"),
 "target_signal_send="..tostring(CC.NativePings.targetSendStatus or "NOT_SENT"),
 "target_signal_sent="..tostring(CC.NativePings.targetSent or 0),
 "target_signal_received="..tostring(CC.NativePings.targetReceived or 0),
 "beacon_alert_sent_events="..tostring(CC.Beacon.sentEvents or 0),
 "beacon_alert_received_events="..tostring(CC.Beacon.receivedEvents or 0),
 "beacon_alert_updated_events="..tostring(CC.Beacon.updatedEvents or 0),
 "schema=2","v2_profile_revision="..tostring(CC.profileRevision),"profile_mode="..(CC.SavedData.character and CC.SavedData.character.useCharacter and "character" or "account"),
 "migration="..(CC.SavedData.migration or "READ_ONLY"),"running="..tostring(CC.state.running),"reason="..CC.state.reason,
 "outer_role="..CC.profile.rings.outer.role,"inner_role="..(CC.profile.rings.inner.enabled and CC.profile.rings.inner.role or "DISABLED"),
 "outer2_role="..(CC.profile.rings.outer2.enabled and CC.profile.rings.outer2.role or "DISABLED"),
 "quest_compass_enabled="..tostring(CC.profile.compass.enabled),"quest_compass_status="..(CC.QuestCompass and CC.QuestCompass.status or "NOT_RUN"),
 "quest_compass_source="..(CC.QuestCompass and CC.QuestCompass.source or "NONE"),
 "quest_compass_watched_count="..tostring(CC.QuestCompass and CC.QuestCompass.watchedCount or 0),
 "quest_compass_poi_count="..tostring(CC.QuestCompass and CC.QuestCompass.poiCount or 0),
 "quest_navigation="..CC.QuestNavigation:Summary(),
 "quest_route="..CC.QuestRoute:Summary(),
 "quest_navigation_mode="..CC.profile.compass.selectionMode,
 "quest_navigation_smoothing="..tostring(CC.profile.compass.smoothHeading),
 "quest_navigation_arrival="..tostring(CC.profile.compass.arrivalCue),
 "quest_notes_status="..tostring(CC.QuestNotes and CC.QuestNotes.lastDataStatus or "NOT_RUN"),
 "quest_notes_visible_count="..tostring(CC.QuestNotes and CC.QuestNotes.lastEntryCount or 0),
 "timing_cast_capable="..tostring(CC.Capabilities.castTiming),"timing_gcd_capable="..tostring(CC.Capabilities.gcdTiming),
 "gcd_source="..tostring(CC.Timing.gcdStats and CC.Timing.gcdStats.source or "NOT_RUN"),
 "gcd_reason="..tostring(CC.Timing.gcdStats and CC.Timing.gcdStats.reason or "NOT_RUN"),
 "gcd_active="..tostring(CC.Timing.gcdStats and CC.Timing.gcdStats.active or false),
 "gcd_table_samples="..tostring(CC.Timing.gcdStats and CC.Timing.gcdStats.tableSamples or 0),
 "gcd_duration_samples="..tostring(CC.Timing.gcdStats and CC.Timing.gcdStats.nativeSamples or 0),
 "gcd_cooldown_events="..tostring(CC.Timing.gcdStats and CC.Timing.gcdStats.eventUpdates or 0),
 "gcd_cast_events="..tostring(CC.Timing.gcdStats and CC.Timing.gcdStats.castEvents or 0),
 "gcd_action_scans="..tostring(CC.Timing.gcdStats and CC.Timing.gcdStats.actionScans or 0),
 "gcd_action_candidates="..tostring(CC.Timing.gcdStats and CC.Timing.gcdStats.actionCandidates or 0),
 "gcd_action_samples="..tostring(CC.Timing.gcdStats and CC.Timing.gcdStats.actionSamples or 0),
 "gcd_action_native="..tostring(CC.Timing.gcdStats and CC.Timing.gcdStats.actionNative or 0),
 "gcd_action_slot="..tostring(CC.Timing.gcdStats and CC.Timing.gcdStats.actionSlot or 0),
 "gcd_action_reason="..tostring(CC.Timing.gcdStats and CC.Timing.gcdStats.actionReason or "NOT_RUN"),
 "gcd_render_test="..tostring(CC.Timing.gcdStats and CC.Timing.gcdStats.renderTest or "NOT_RUN"),
 "gcd_idle_wake="..tostring(CC.Timing:IsGCDVisibilityNeeded()),
 "alerts_enabled="..tostring(CC.profile.alerts.enabled),"alerts_capable="..tostring(CC.Capabilities.alerts),
 "alerts_active="..tostring(CC.AlertConditions.active),"alerts_state="..tostring(CC.AlertConditions.status),
 "alerts_triggered="..tostring(CC.AlertConditions.triggers),"alerts_last_condition="..tostring(CC.AlertConditions.lastCondition or "NONE"),
 "alerts_live_tests="..tostring(CC.AlertConditions.liveTests),"alerts_unavailable="..tostring(CC.AlertConditions.unavailable),"vitals_capable="..tostring(CC.Capabilities.vitals),
 "health_capable="..tostring(CC.Capabilities.health),"resource_capable="..tostring(CC.Capabilities.resource),"vitals_active="..tostring(CC.Vitals.active),"vitals_samples="..CC.Vitals.samples,
 "source="..CC.profile.info.source,"reference_id="..tostring(CC.ContextBackend.selected and CC.ContextBackend.selected.id or 0),
 "range="..(s and s.range or "UNKNOWN"),"range_reason="..(s and s.rangeReason or "NO_FRESH_SAMPLE"),
 "context="..(s and s.relationship or "UNKNOWN"),
 "bracket_policy=EXPERIMENTAL_OOC_SPELL_REACH_NOT_WORLD_YARDS","bracket_enabled="..tostring(CC.profile.info.brackets),
 "actions="..(CC.profile.palette.experimental and "EXPERIMENTAL_NATIVE_TEST_REQUIRED" or "UNIT_ACTIONS_DISABLED"),
 "error_count="..self.errorCount,"context_error_count="..CC.ContextBackend.state.errors,"last_fault="..self.lastFault,
 "updates="..self.updateCount,"samples="..self.sampleCount,"self_test="..self.lastSelfTest,"focus=IDLE_FALLBACK_NO_OS_FOCUS_SIGNAL",
 "unavailable_optional_events="..(function()
   local missing={};for event in pairs(CC.eventRegistration and CC.eventRegistration.unavailable or {}) do missing[#missing+1]=event end
   table.sort(missing);return #missing>0 and table.concat(missing,",") or "none_detected"
  end)(),
 "conflicts="..(#self.conflicts>0 and table.concat(self.conflicts,",") or "none_detected"),"privacy=NO_NAMES_GUIDS_CHAT_PATHS_OR_RAW_ERRORS"}
 for _,n in ipairs({"cast","channel","gcd"}) do local l=CC.Timing.lanes[n];fields[#fields+1]=n.."_status="..(l and l.status or "NOT_RUN") end
 local records=CC.Evidence:Get();for i=1,36 do local id=string.format("T%02d",i);if records[id] then fields[#fields+1]="user_"..id.."="..records[id] end end
 if #self.profileSamples>0 then
  local copy={};local total=0;for _,v in ipairs(self.profileSamples) do copy[#copy+1]=v;total=total+v end;table.sort(copy)
  fields[#fields+1]="measured_callback_mean_ms="..string.format("%.4f",total/#copy)
  fields[#fields+1]="measured_callback_p95_ms="..string.format("%.4f",copy[math.max(1,math.ceil(#copy*0.95))])
  fields[#fields+1]="measured_sample_count="..#copy;fields[#fields+1]="measurement_scope=INSTRUMENTED_CALLBACK_ONLY_NOT_TOTAL_ADDON_COST"
 end
 self:AppendNativeDiagnostics(fields)
 return table.concat(fields,"\n")
end
