local _, CC=...
-- Optional display-only heuristic: never hides Blizzard frames, changes mouse
-- focus, or creates secure interactions. A missing/secret mouse-focus API fails
-- open (effects stay visible), rather than interpreting uncertain focus.
CC.WindowHover={}
local W=CC.WindowHover
local known={
 CursorCompanionRoutes=true,CursorCompanionQuestNotes=true,CharacterFrame=true,WorldMapFrame=true,QuestLogFrame=true,SpellBookFrame=true,
 PlayerTalentFrame=true,ProfessionsFrame=true,PVEFrame=true,SettingsPanel=true,
 GameMenuFrame=true,CollectionsJournal=true,EncounterJournal=true,
 AchievementFrame=true,MerchantFrame=true,BankFrame=true,TradeFrame=true,
 MailFrame=true,InspectFrame=true,FriendsFrame=true,CommunitiesFrame=true,
 AuctionHouseFrame=true,GossipFrame=true,QuestFrame=true,TaxiFrame=true,
 ItemTextFrame=true,PlayerChoiceFrame=true,HelpFrame=true,
}
local excluded={WorldFrame=true,UIParent=true,Minimap=true,MinimapCluster=true,
 GameTooltip=true,PlayerFrame=true,TargetFrame=true,FocusFrame=true,
}
local function isWindow(frame)
 if not frame or type(frame.GetName)~="function" then return false end
 local name=frame:GetName()
 if type(name)~="string" or excluded[name] then return false end
 if known[name] then return true end
 if type(UIPanelWindows)=="table" and UIPanelWindows[name] then return true end
 -- Support conventional named third-party configuration windows without
 -- classifying unit frames, action bars, nameplates or the minimap as windows.
 if name:find("NamePlate",1,true) or name:find("ActionButton",1,true)
    or name:find("UnitFrame",1,true) or name:find("RaidFrame",1,true)
    or name:find("PartyFrame",1,true) or name:find("Minimap",1,true) then return false end
 local candidate=name:match("Window$") or name:match("Panel$") or
  name:match("Dialog$") or name:match("Options$") or name:match("Config$") or
  name:match("Settings$")
 if not candidate or type(frame.GetWidth)~="function" or type(frame.GetHeight)~="function" then return false end
 return frame:GetWidth()>=180 and frame:GetHeight()>=130
end
local function findHoveredWindow()
 if type(GetMouseFoci)~="function" then return false end
 local ok,focused=pcall(GetMouseFoci)
 if not ok or type(focused)~="table" then return false end
 local focusCount=math.min(#focused,12)
 for i=1,focusCount do
  local object=focused[i]
  for _=1,18 do
   if object==nil or object==UIParent or object==WorldFrame then break end
   -- Cursor Companion's own navigation/UI remains interactable; only its
   -- floating cursor art is affected by the preference.
   if isWindow(object) then return true end
   if type(object.GetParent)~="function" then break end
   object=object:GetParent()
  end
 end
 return false
end

function W:IsHovering()
 local ok,hovering=pcall(findHoveredWindow)
 return ok and hovering==true
end
