local _,CC=...
CC.Capabilities={}
function CC.Capabilities:Probe()
 self.ready=type(CreateFrame)=="function" and UIParent~=nil and type(GetCursorPosition)=="function" and type(IsMouselooking)=="function" and type(IsMouseButtonDown)=="function" and type(issecretvalue)=="function"
 local permitted=self.ready and CC.ClientIdentity.providerAllowed
 local curves=type(CurveConstants)=="table" and CurveConstants.ZeroToOne~=nil
 self.health=permitted and curves and type(UnitHealthPercent)=="function" or false
 self.resource=permitted and curves and type(UnitPowerPercent)=="function" or false
 self.vitals=self.health or self.resource
 -- An alert's artwork and public event signals do not depend on native vitals,
 -- aura restrictions or protected percentage getters. Check each data-driven
 -- condition separately at use time instead of disabling every alert here.
 self.alerts=permitted and type(GetTime)=="function"
 -- Do not lose GCD because channel timing is absent, or lose cast timing
 -- because a different optional API is absent on an otherwise supported build.
 self.castTiming=permitted and (type(UnitCastingDuration)=="function" or type(UnitChannelDuration)=="function") or false
 self.gcdTiming=permitted and ((C_Spell~=nil and (type(C_Spell.GetSpellCooldown)=="function" or type(C_Spell.GetSpellCooldownDuration)=="function")) or (C_ActionBar~=nil and type(C_ActionBar.GetActionCooldown)=="function" and type(GetActionInfo)=="function" and type(GetSpellBaseCooldown)=="function")) or false
 self.timing=self.castTiming or self.gcdTiming
 self.context=permitted and type(UnitExists)=="function" or false
 self.actions=permitted and type(RegisterStateDriver)=="function" or false
 self.focus="IDLE_FALLBACK_NO_OS_FOCUS_SIGNAL"
end
