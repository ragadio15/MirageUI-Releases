local _,CC=...
local f=CreateFrame("Frame");CC.eventFrame=f
local events={"ADDON_LOADED","PLAYER_LOGIN","PLAYER_ENTERING_WORLD","PLAYER_LEAVING_WORLD","PLAYER_REGEN_DISABLED","PLAYER_REGEN_ENABLED","PLAYER_DEAD","CINEMATIC_START","CINEMATIC_STOP","PLAY_MOVIE","UPDATE_MOUSEOVER_UNIT","PLAYER_TARGET_CHANGED","PLAYER_FOCUS_CHANGED","SPELLS_CHANGED","PLAYER_SPECIALIZATION_CHANGED","UPDATE_SHAPESHIFT_FORM","UI_SCALE_CHANGED","DISPLAY_SIZE_CHANGED","ADDON_ACTION_BLOCKED","ADDON_ACTION_FORBIDDEN","UPDATE_BINDINGS","SPELL_DATA_LOAD_RESULT","QUEST_LOG_UPDATE","QUEST_WATCH_UPDATE","QUEST_ACCEPTED","QUEST_REMOVED","QUEST_TURNED_IN","WAYPOINT_UPDATE","ZONE_CHANGED_INDOORS","QUEST_WATCH_LIST_CHANGED","SUPER_TRACKING_CHANGED","SUPER_TRACKING_PATH_UPDATED","ZONE_CHANGED","ZONE_CHANGED_NEW_AREA","NAVIGATION_DESTINATION_REACHED"}
-- Some Mainline events are deliberately absent on Forever. An unknown event
-- throws during RegisterEvent; failing to guard it would abort ADDON_LOADED and
-- prevent even decorative rings and /cc off from being initialized.
CC.eventRegistration={registered={},unavailable={}}
local function register(event)
 local ok,result=pcall(f.RegisterEvent,f,event)
 local registered=ok and result~=false
 if registered and type(f.IsEventRegistered)=="function" then
  local checked,active=pcall(f.IsEventRegistered,f,event)
  registered=checked and CC.Safety:IsReadable(active) and active==true
 end
 if registered then CC.eventRegistration.registered[event]=true
 else CC.eventRegistration.unavailable[event]=true end
 return registered==true
end
f:SetScript("OnEvent",function(_,e,name,arg2)
 local ok=pcall(function()
  -- These synchronous events can fire INSIDE Initialize(), before the normal
  -- initialized guard is true. Never discard them or infer success from pcall.
  if e=="ADDON_ACTION_BLOCKED" or e=="ADDON_ACTION_FORBIDDEN" then
   CC.Diagnostics:NativeActionBlocked(e,name,arg2)
   return
  end
  if e=="ADDON_LOADED" and name==CC.name then CC:Initialize() end
  if not CC.state.initialized then return end
  if CC.QuestNavigation and (e=="QUEST_ACCEPTED" or e=="QUEST_REMOVED" or e=="QUEST_TURNED_IN"
      or e=="PLAYER_ENTERING_WORLD" or e=="ZONE_CHANGED_NEW_AREA") then
   CC.QuestNavigation:OnEvent(e,name,arg2)
  end
  if e=="PLAYER_LOGIN" or (e=="ADDON_LOADED" and name~=CC.name) then CC.Diagnostics:ScanConflicts();CC.VisualLifecycle:Reconcile()
  elseif e=="PLAYER_ENTERING_WORLD" then CC.state.inWorld=true;CC.state.cinematic=false;CC.VisualLifecycle:Reconcile();CC.Bindings:InitializeDefault();CC.Bindings:InitializeNotesDefault();CC.Bindings:InitializeFishingDefault();CC.Bindings:RefreshActions();CC.Wizard:MaybeOpen();CC.Minimap:Refresh();if CC.FishingStatus then CC.FishingStatus:ResumeChannel() end
  elseif e=="PLAYER_LEAVING_WORLD" then CC.state.inWorld=false;CC.VisualLifecycle:Stop("WORLD_TRANSITION");if CC.FishingStatus then CC.FishingStatus:Hide() end;CC.Palette:Close();CC.QuestNotes:Close();if CC.QuestRoutePanel then CC.QuestRoutePanel:Close() end
  elseif e=="CINEMATIC_START" or e=="PLAY_MOVIE" then CC.state.cinematic=true;CC.VisualLifecycle:Stop("CINEMATIC");if CC.FishingStatus then CC.FishingStatus:Hide() end;CC.Palette:Close();CC.QuestNotes:Close();if CC.QuestRoutePanel then CC.QuestRoutePanel:Close() end
  elseif e=="CINEMATIC_STOP" then CC.state.cinematic=false;CC.VisualLifecycle:Reconcile();if CC.FishingStatus then CC.FishingStatus:ResumeChannel() end
  elseif e=="PLAYER_REGEN_DISABLED" then CC.AlertConditions:QueueEvent("combatStart");CC.Settings:CloseForCombat();CC.Wizard:CloseForCombat();CC.ColorPicker:Cancel();CC.Bindings:CancelCapture();CC.Controls:CloseChoices();CC.QuestNotes:Close();if CC.QuestRoutePanel then CC.QuestRoutePanel:Close() end;CC.Context:Invalidate()
    -- Secure menu actions stay available. Navigation uses only fresh readable
    -- position/facing and an already known destination while combat is active.
    if CC.Navigation then CC.Navigation:Invalidate("COMBAT_CHANGED") end
  elseif e=="PLAYER_REGEN_ENABLED" then CC.AlertConditions:QueueEvent("combatEnd");CC.Context:Reset();CC.Navigation:Invalidate("COMBAT_CHANGED");CC.Bindings:InitializeDefault();CC.Bindings:InitializeNotesDefault();CC.Bindings:InitializeFishingDefault();CC.Bindings:RefreshActions();CC.Wizard:MaybeOpen()
  elseif e=="PLAYER_DEAD" then CC.AlertConditions:QueueEvent("playerDead")
  elseif e=="ENCOUNTER_START" then CC.AlertConditions:QueueEvent("encounterStart")
  elseif e=="ENCOUNTER_END" then CC.AlertConditions:QueueEvent("encounterEnd")
  elseif e=="UNIT_SPELLCAST_START" or e=="UNIT_SPELLCAST_CHANNEL_START"
      or e=="UNIT_SPELLCAST_INTERRUPTED" or e=="UNIT_SPELLCAST_FAILED" then
   -- Unit event payloads may be protected. Compare only plain, readable tokens.
   if CC.Safety:IsText(name) and name=="player" then
    local kind=(e=="UNIT_SPELLCAST_INTERRUPTED" and "playerCastInterrupted")
      or (e=="UNIT_SPELLCAST_FAILED" and "playerCastFailed") or "playerCastStart"
    CC.AlertConditions:QueueEvent(kind)
   end
  elseif e=="UPDATE_BINDINGS" then CC.Bindings:InitializeDefault();CC.Bindings:InitializeNotesDefault();CC.Bindings:InitializeFishingDefault();CC.Bindings:RefreshStatus();CC.Bindings:RefreshActions()
  elseif e=="SPELL_DATA_LOAD_RESULT" then CC.TrackedSpells:RefreshVisible()
  elseif e=="QUEST_LOG_UPDATE" or e=="QUEST_WATCH_UPDATE" or e=="QUEST_ACCEPTED" or e=="QUEST_REMOVED"
      or e=="QUEST_TURNED_IN" or e=="WAYPOINT_UPDATE" or e=="ZONE_CHANGED_INDOORS" or e=="QUEST_WATCH_LIST_CHANGED" or e=="SUPER_TRACKING_CHANGED"
      or e=="SUPER_TRACKING_PATH_UPDATED" or e=="ZONE_CHANGED" or e=="ZONE_CHANGED_NEW_AREA"
      or e=="NAVIGATION_DESTINATION_REACHED" then
    CC.Navigation:Invalidate(e)
    if CC.QuestNotes then CC.QuestNotes:Invalidate() end
  elseif e=="UPDATE_MOUSEOVER_UNIT" then CC.Context:Invalidate()
  elseif e=="PLAYER_TARGET_CHANGED" or e=="PLAYER_FOCUS_CHANGED" then
   if e=="PLAYER_TARGET_CHANGED" then CC.AlertConditions:QueueEvent("targetChanged") end
   CC.Context:Invalidate() -- Palette re-resolves its own captured subject; never adopts this target.
   if CC.AlertConditions then CC.AlertConditions:InvalidateUnit(e=="PLAYER_TARGET_CHANGED" and "target" or "focus") end
  elseif e=="SPELLS_CHANGED" or e=="PLAYER_SPECIALIZATION_CHANGED" or e=="UPDATE_SHAPESHIFT_FORM" then
   if CC.state.running then CC.Context:Reset();CC.Timing:Stop();CC.Timing:Start();CC.Vitals:Refresh() else CC.Context:Stop();CC.Timing:Stop();CC.Vitals:Stop() end;CC.TrackedSpells:RefreshVisible()
  elseif e=="UI_SCALE_CHANGED" or e=="DISPLAY_SIZE_CHANGED" then CC.Trails:Flush();CC.Context:Invalidate();CC.Palette:Close();CC.TextLayout:ViewportChanged();if not CC.Safety:InCombat() then CC.Palette:Rebuild() end end
 end)
 if not ok then CC.Diagnostics:Fault("EVENT_FAULT");CC.VisualLifecycle:Stop("EVENT_FAULT") end
end)

-- The callback is installed before subscriptions, including early security
-- events. Known-unsupported or restricted events must not be probed here.
for _,e in ipairs(events) do register(e) end
for _,e in ipairs({"UNIT_SPELLCAST_START","UNIT_SPELLCAST_CHANNEL_START","UNIT_SPELLCAST_INTERRUPTED","UNIT_SPELLCAST_FAILED","ENCOUNTER_START","ENCOUNTER_END"}) do
 register(e)
end
