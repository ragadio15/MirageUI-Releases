local _,CC=...
CC.ContextBackend={lanes={},probes={},maxQueries=8,state={armed=false,source="mouseover",generation=0,configVersion=0,errors=0,queryCount=0}}
local P=CC.ContextBackend
function P:Print(s) CC:Print(s) end
function P:Readable(value)
    if type(issecretvalue)~="function" then return false,"GUARD_MISSING" end
    local ok,secret=pcall(issecretvalue,value)
    if not ok or secret~=false then return false,"RESTRICTED" end
    if value==nil then return true end
    if type(canaccessvalue)=="function" then
        local accessOK,access=pcall(canaccessvalue,value)
        if not accessOK or access~=true then return false,"RESTRICTED" end
    end
    return true
end
function P:Number(value)
    return self:Readable(value) and type(value)=="number" and value==value
        and value>-math.huge and value<math.huge
end
function P:PlainBool(fn,...)
    if type(fn)~="function" then return nil end
    local ok,value=pcall(fn,...)
    if ok and self:Readable(value) and type(value)=="boolean" then return value end
    return nil
end
function P:Lane(key)
    if not self.lanes[key] then self.lanes[key]={status="NOT_RUN",calls=0,held=false} end
    return self.lanes[key]
end
function P:Hold(key,reason,isFault)
    local l=self:Lane(key)
    if not l.held then
        l.held=true; l.status=reason
        if isFault then self.state.errors=math.min(9999,self.state.errors+1) end
        if self.state.armed then self:Print(key..": "..reason.."; this API is paused until an out-of-combat settings Apply or reload.") end
    end
    return nil,reason
end
function P:Read(key,fn,...)
    local l=self:Lane(key)
    if l.held then return nil,l.status end
    if type(fn)~="function" then return self:Hold(key,"UNSUPPORTED",false) end
    l.calls=math.min(999999,l.calls+1)
    local ok,value=pcall(fn,...)
    if not ok then return self:Hold(key,"API_ERROR",true) end
    local readable,reason=self:Readable(value)
    if not readable then return self:Hold(key,reason,false) end
    if value==nil then l.status="NO_VALUE"; return nil,"NO_VALUE" end
    l.status="READABLE"; return value,"READABLE"
end
function P:Scalar(key,fn,kind,...)
    local v,s=self:Read(key,fn,...)
    if s~="READABLE" then return nil,s end
    if type(v)~=kind or (kind=="number" and not self:Number(v)) then
        return self:Hold(key,"BAD_RETURN",true)
    end
    return v,s
end
function P:Field(t,key)
    if not self:Readable(t) or type(t)~="table" or type(canaccesstable)~="function" then return nil,"METADATA_UNREADABLE" end
    local ok,access=pcall(canaccesstable,t)
    if not ok or access~=true then return nil,"METADATA_UNREADABLE" end
    local fieldOK,v=pcall(function() return t[key] end)
    if not fieldOK or not self:Readable(v) then return nil,"METADATA_UNREADABLE" end
    return v,"READABLE"
end
function P:Now()
    if type(GetTime)~="function" then return nil end
    local ok,v=pcall(GetTime)
    if ok and self:Number(v) and v>=0 then return v end
    return nil
end
