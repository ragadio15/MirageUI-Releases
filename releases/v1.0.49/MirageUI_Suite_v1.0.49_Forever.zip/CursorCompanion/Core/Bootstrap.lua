local addonName, CC = ...
CC.name=addonName; CC.version="2.10.19"; CC.planVersion="2.10.4-forever-utility-p4-f10-8"; CC.schema=2
CC.API={}; CC.state={initialized=false,inWorld=false,cinematic=false,running=false,reason="STARTING",conflictAcknowledged=false}
CC.release="FOREVER_F10_5_NATIVE_TEST_PENDING"; CC.edition="F10.5"; CC.profileRevision=10
function CC:Print(text)
 if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage("|cffe88c2eCursor Companion:|r "..text) end
end
function CC:Copy(v,depth)
 depth=depth or 0; if depth>16 then return nil end
 if type(v)~="table" then return v end
 local r={}; for k,x in pairs(v) do r[k]=self:Copy(x,depth+1) end; return r
end
function CC:Initialize()
 if self.state.initialized then return end
 self.state.initializing=true;self.state.initializationStage="CLIENT_CHECK"
 self.ClientIdentity:Detect(); self.Capabilities:Probe()
 self.state.initializationStage="SETTINGS";self.SavedData:Initialize()
 self.state.initializationStage="VISUALS"
 self.Diagnostics:ScanConflicts(); self.CompanionFrame:Create(); self.Vitals:Initialize(); self.VisualLifecycle:CreateController()
 for _,key in ipairs({"Inventory","Utility","Fishing","Beacon","NativePings"}) do
  self.state.initializationStage=key:upper()
  local feature=self[key]
  local ok=feature and pcall(feature.Initialize,feature)
  if not ok then self.Diagnostics:OptionalFault(key:upper().."_INITIALIZE_FAILED") end
 end
 self.state.initializationStage="TIMING";self.Timing:Initialize()
 self.state.initializationStage="PALETTE";self.Palette:Create()
 self.state.initializationStage="QUESTNOTES";self.QuestNotes:Create()
 self.state.initializationStage="COMMANDS";self.Commands:Register()
 self.state.initializationStage="MINIMAP";self.Minimap:Create()
 self.state.initialized=true;self.state.initializing=false;self.state.initializationStage="READY"
 if MovieFrame and MovieFrame.HookScript then
  pcall(MovieFrame.HookScript,MovieFrame,"OnHide",function()
   if CC.state.cinematic then CC.state.cinematic=false;CC.VisualLifecycle:Reconcile();if CC.FishingStatus then CC.FishingStatus:ResumeChannel() end end
  end)
 end
 self:Print("Ready. Open settings from the MirageUI AddOns menu or the Cursor Companion minimap icon. /cc off stops the effects.")
 if self.SavedData.warning then self:Print(self.SavedData.warning) end
end
function CC:ApplyProfile()
 if not self.state.initialized then return end
 self.VisualLifecycle:Stop("RECONFIGURE"); self.QuestNotes:Close();if self.QuestRoutePanel then self.QuestRoutePanel:Close() end; self.Context:Reset(); self.CompanionFrame:ApplyAppearance()
 self.VisualLifecycle:Reconcile()
 if self.Palette then self.Palette:Rebuild() end
 if self.Fishing then self.Fishing:ApplyProfile() end
 if self.Navigation then self.Navigation:Invalidate("PROFILE_CHANGED") end
 if self.Bindings then self.Bindings:InitializeNotesDefault();self.Bindings:InitializeFishingDefault();self.Bindings:RefreshActions() end
 if self.Minimap then self.Minimap:Refresh() end
end
