local _,CC=...
-- Never classify unavailable combat aura data as an absent effect. The
-- restriction-state query is intentionally separated from the actual lookup.
CC.RestrictionGate={}
local G=CC.RestrictionGate
function G:Restricted(kind)
 local token=Enum and Enum.RestrictedActionType and Enum.RestrictedActionType[kind]
 if token~=nil and type(GetRestrictedActionStatus)=="function" then
  local ok,restricted=pcall(GetRestrictedActionStatus,token)
  if ok and CC.Safety:IsReadable(restricted) and type(restricted)=="boolean" then return restricted end
 end
 -- Fail closed if the build cannot reliably determine the aura restriction.
 return true
end
function G:AuraReadable() return not self:Restricted("SecretAuras") end
function G:ConditionsReadable()
 -- Only gate automatic comparisons on combat. SecretAuras reports *aura*
 -- restrictions, not the availability of independent unit-health and cast
 -- APIs; using it here used to shut down every Alert even out of combat.
 -- Each individual returned value is checked with Safety:IsReadable/IsNumber
 -- before any boolean or numeric operation. Unreadable means UNKNOWN.
 return not CC.Safety:InCombat()
end
