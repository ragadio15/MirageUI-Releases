local _,CC=...
CC.Safety={}
function CC.Safety:IsReadable(v)
 if type(issecretvalue)~="function" then return false end
 local ok,s=pcall(issecretvalue,v); if not ok or s~=false then return false end
 if type(canaccessvalue)=="function" then local a,b=pcall(canaccessvalue,v); if not a or b~=true then return false end end
 return true
end
function CC.Safety:IsNumber(v) return self:IsReadable(v) and type(v)=="number" and v==v and v>-math.huge and v<math.huge end
function CC.Safety:IsText(v) return self:IsReadable(v) and type(v)=="string" end
function CC.Safety:BoolCall(fn,...)
 if type(fn)~="function" then return nil end
 local ok,v=pcall(fn,...); if ok and self:IsReadable(v) and type(v)=="boolean" then return v end
end
function CC.Safety:InCombat() return self:BoolCall(InCombatLockdown)~=false end
function CC.Safety:Value(fn,...)
 if type(fn)~="function" then return nil end
 local ok,v=pcall(fn,...); if ok and self:IsReadable(v) then return v end
end
function CC.Safety:Field(t,k)
 if not self:IsReadable(t) or type(t)~="table" then return nil end
 if type(canaccesstable)~="function" or self:BoolCall(canaccesstable,t)~=true then return nil end
 local ok,v=pcall(function() return t[k] end); if ok and self:IsReadable(v) then return v end
end
