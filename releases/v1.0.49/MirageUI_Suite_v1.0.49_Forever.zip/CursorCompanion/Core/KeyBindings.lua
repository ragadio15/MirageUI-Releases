local _,CC=...
CC.Bindings={action="CURSORCOMPANION_PALETTE",defaultKey="BUTTON3",widgets={}}
local B=CC.Bindings;local S=CC.Safety
function B:RestorePrevious()
 if S:InCombat() or CC.SavedData.readOnly then return false,"Leave combat before changing the shortcut." end
 if type(GetCurrentBindingSet)~="function" or type(GetBindingAction)~="function" or type(SetBinding)~="function" or type(SaveBindings)~="function" then return false,"Restore this shortcut in WoW Key Bindings." end
 local db=CC.SavedData.character;local record=db and db.bindingUndo
 if not record or type(record.before)~="table" or type(record.after)~="table" then return false,"No previous shortcut to restore." end
 if GetCurrentBindingSet()~=record.set then return false,"Switch back to the same WoW binding set first." end
 for key,action in pairs(record.after) do
  if GetBindingAction(key)~=action then return false,"A shortcut changed elsewhere. Restore it in WoW Key Bindings instead." end
 end
 local ok,result=pcall(function()
  for key,action in pairs(record.before) do if not SetBinding(key,action~="" and action or nil) then error("BIND_REFUSED") end end
  local saved=SaveBindings(record.set);if saved==false then error("SAVE_REFUSED") end
 end)
 if not ok then for key,action in pairs(record.after) do pcall(SetBinding,key,action~="" and action or nil) end;return false,"The shortcut could not be restored." end
 db.bindingUndo=nil;self:RefreshActions();self:RefreshStatus();return true
end
function B:Current()
 if type(GetBindingKey)~="function" then return nil end
 local ok,key=pcall(GetBindingKey,self.action)
 if ok and S:IsText(key) and key~="" then return key end
end
function B:Conflict(key)
 if type(GetBindingAction)~="function" then return "Unavailable" end
 if S:Value(GetBindingAction,key,false)==self.action then return nil end
 local action=S:Value(GetBindingAction,key,true)
 if not S:IsText(action) then return "Unavailable" end
 if action~="" and action~=self.action then return action end
end
function B:Assign(key,replace)
 if S:InCombat() or CC.SavedData.readOnly then return false,"Leave combat before changing the shortcut." end
 if type(key)~="string" or #key>80 or not key:match("^[A-Z0-9%-]+$") then return false,"Choose a keyboard or mouse shortcut." end
 local base=key:match("([^-]+)$")
 if base=="BUTTON1" or base=="BUTTON2" then return false,"Left and right clicks stay available for normal controls. Choose middle mouse, a side button or the wheel." end
 local number=base and base:match("^BUTTON(%d+)$")
 if number and (tonumber(number)<3 or tonumber(number)>31 or base~="BUTTON"..tonumber(number)) then return false,"Choose a supported mouse button." end
 if not (type(SetBinding)=="function" and type(SaveBindings)=="function" and type(GetBindingKey)=="function" and type(GetCurrentBindingSet)=="function") then
  return false,"Open WoW Key Bindings to set this shortcut."
 end
 local conflict=self:Conflict(key)
 if conflict and not replace then return false,"That shortcut is already in use. Choose another or confirm replacement." end
 if conflict=="Unavailable" then return false,"WoW cannot check this shortcut right now." end
 local old1,old2=GetBindingKey(self.action)
 local snapshot={};for _,k in ipairs({key,old1,old2}) do
  if k then snapshot[k]=GetBindingAction(k) end
 end
 local function restore()
  for k,action in pairs(snapshot) do pcall(SetBinding,k,action~="" and action or nil) end
 end
 -- Only this action's old keys and the explicitly selected key may be changed.
 for _,old in ipairs({old1,old2}) do if old and old~=key then
  local ok,result=pcall(SetBinding,old,nil)
  if not ok or result~=true then restore();return false,"The previous shortcut could not be changed." end
 end end
 local ok,result=pcall(SetBinding,key,self.action)
 if not ok or result~=true then restore();return false,"WoW did not accept the shortcut." end
 local set=S:Value(GetCurrentBindingSet)
 if set~=1 and set~=2 then restore();return false,"Choose account or character key bindings in WoW first." end
 local saved,res=pcall(SaveBindings,set)
 if not saved or res==false then restore();return false,"The shortcut could not be saved." end
 if CC.SavedData.character then
  local applied={};for k in pairs(snapshot) do applied[k]=GetBindingAction(k) end
  CC.SavedData.character.bindingUndo={before=snapshot,after=applied,set=set}
 end
 self.notice=nil;self:RefreshStatus();return true
end
function B:InitializeDefault()
 if self.initializing or not CC.state.inWorld or S:InCombat() or CC.SavedData.readOnly then return end
 local db=CC.SavedData.character;if not db or db.bindingInitialized then return end
 if self:Current() then db.bindingInitialized=true;return end
 local conflict=self:Conflict(self.defaultKey)
 if conflict=="Unavailable" then return end
 if conflict then
  self.notice="Middle mouse is already assigned. Choose a shortcut or confirm replacement in Quick menu settings."
  db.bindingInitialized=true;return
 end
 self.initializing=true;local ok,why=self:Assign(self.defaultKey,false);self.initializing=false
 if ok then db.bindingInitialized=true else self.notice=why end
end
-- Native binding tokens, not the display names delivered by mouse callbacks.
-- Based on the reviewed Blizzard BindingUtil mapping; no global mouse hook is used.
local modifierKeys={LALT=true,RALT=true,LCTRL=true,RCTRL=true,LSHIFT=true,RSHIFT=true,LMETA=true,RMETA=true,ALT=true,CTRL=true,SHIFT=true,META=true}
function B:MouseToken(button)
 if button=="MiddleButton" then return "BUTTON3" end
 if button=="LeftButton" or button=="RightButton" or button=="Button1" or button=="Button2" then return nil end
 local n=type(button)=="string" and button:match("^Button(%d+)$")
 if n and tonumber(n)>=3 and tonumber(n)<=31 then return "BUTTON"..tonumber(n) end
end
function B:Chord(key)
 local prefix=""
 -- WoW's standard chord order is Alt, Ctrl, Shift, Meta.
 if IsAltKeyDown and IsAltKeyDown() then prefix=prefix.."ALT-" end
 if IsControlKeyDown and IsControlKeyDown() then prefix=prefix.."CTRL-" end
 if IsShiftKeyDown and IsShiftKeyDown() then prefix=prefix.."SHIFT-" end
 if IsMetaKeyDown and IsMetaKeyDown() then prefix=prefix.."META-" end
 return prefix..key
end
function B:Label(key)
 if not key then return "Not assigned" end
 local label=key:gsub("MOUSEWHEELUP$","Wheel up"):gsub("MOUSEWHEELDOWN$","Wheel down")
 label=label:gsub("BUTTON(%d+)$",function(n) return n=="3" and "Middle mouse" or "Mouse button "..n end)
 label=label:gsub("ALT%-","Alt-"):gsub("CTRL%-","Ctrl-"):gsub("SHIFT%-","Shift-"):gsub("META%-","Meta-")
 return label
end
function B:SetCaptureActive(active)
 self.captureGeneration=(self.captureGeneration or 0)+1
 local generation=self.captureGeneration
 self.captureActive=active==true
 local function suspend(value)
  for _,module in ipairs({CC.Palette,CC.Fishing}) do
   if module and module.SetBindingCapture then module:SetBindingCapture(value) end
  end
 end
 if active then suspend(true);return end
 local now=S:Value(GetTime);self.suppressUntil=S:IsNumber(now) and now+.30 or nil
 local function restore()
  if self.captureGeneration~=generation or self.captureActive then return end
  suspend(false)
 end
 if C_Timer and type(C_Timer.After)=="function" then C_Timer.After(.25,restore) else restore() end
end
function B:CancelCapture()
 for _,group in ipairs({self.widgets or {},self.notesWidgets or {}}) do
  for _,widget in ipairs(group) do if widget.key then CC.Skin:Select(widget.key,false) end end
 end
 self.callback=nil;self.pendingMouse=nil;self.pendingKey=nil
 if self.capture and self.capture:IsShown() then self.capture:Hide()
 elseif self.captureActive then self:SetCaptureActive(false) end
end
function B:AcceptCapture(key)
 if not self.callback or not self.capture or not self.capture:IsShown() then return end
 if S:InCombat() then self:CancelCapture();return end
 local now=CC.Safety:Value(GetTime);self.suppressUntil=CC.Safety:IsNumber(now) and now+.25 or nil
 local fn=self.callback;self.callback=nil;self.pendingMouse=nil;self.pendingKey=nil;self.capture:Hide()
 fn(key)
end
function B:IsMenuMouseToken(token)
 if not token or type(GetBindingAction)~="function" then return false end
 return CC.Safety:Value(GetBindingAction,self:Chord(token),true)==self.action
end
function B:SuppressMouseRelease()
 local now=CC.Safety:Value(GetTime);self.suppressUntil=CC.Safety:IsNumber(now) and now+.10 or nil
end
function B:SuppressInvocation()
 if self.capture and self.capture:IsShown() then return true end
 local now=CC.Safety:Value(GetTime)
 return self.suppressUntil and CC.Safety:IsNumber(now) and now<self.suppressUntil or false
end
function B:Capture(callback)
 if S:InCombat() or CC.SavedData.readOnly then return end
 CC.Palette:Close()
 if not self.capture then
  local f=CreateFrame("Frame","CursorCompanionKeyCapture",UIParent,"BackdropTemplate");self.capture=f
  f:SetSize(430,205);f:SetPoint("CENTER");f:SetFrameStrata("FULLSCREEN_DIALOG");f:SetClampedToScreen(true);f:EnableMouse(true);f:EnableMouseWheel(true);CC.Controls:Backdrop(f)
  local title=CC.Controls:Text(f,"Choose a keyboard or mouse shortcut",20,-20)
  local helpTop=20+CC.TextLayout:Text(title,390,18)+12
  local help=CC.Controls:Text(f,"Press a key, or click middle/side mouse buttons inside this box. Scrolling the wheel also works.\n\nAlt, Ctrl and Shift are optional. Left/right clicks stay available for normal controls. Escape cancels.",20,-51,"GameFontHighlightSmall")
  local helpHeight=CC.TextLayout:Text(help,390,80)
  help:ClearAllPoints();help:SetPoint("TOPLEFT",20,-helpTop)
  f:SetHeight(math.max(205,helpTop+helpHeight+54));CC.TextLayout:FitWindow(f)
  CC.Controls:Button(f,"Cancel",145,-f:GetHeight()+42,140,function() self:CancelCapture() end)
  f:EnableKeyboard(true);if f.SetPropagateKeyboardInput then f:SetPropagateKeyboardInput(false) end
  f:SetScript("OnKeyDown",function(_,key)
   if key=="ESCAPE" then self:CancelCapture();return end
   if modifierKeys[key] or key=="UNKNOWN" then return end
   self.pendingKey={token=key,chord=self:Chord(key)}
  end)
  f:SetScript("OnKeyUp",function(_,key)
   local pending=self.pendingKey
   if pending and pending.token==key then self.pendingKey=nil;self:AcceptCapture(pending.chord) end
  end)
  -- Commit on release, so the initiating press cannot fall through to controls below.
  f:SetScript("OnMouseDown",function(_,button)
   local token=self:MouseToken(button);self.pendingMouse=token and {button=button,key=self:Chord(token)} or nil
  end)
  f:SetScript("OnMouseUp",function(_,button)
   local pending=self.pendingMouse;self.pendingMouse=nil
   if pending and pending.button==button then self:AcceptCapture(pending.key) end
  end)
  f:SetScript("OnMouseWheel",function(_,delta)
   if delta~=0 then self:AcceptCapture(self:Chord(delta>0 and "MOUSEWHEELUP" or "MOUSEWHEELDOWN")) end
  end)
  f:SetScript("OnHide",function()
   self.callback=nil;self.pendingMouse=nil;self.pendingKey=nil
   if self.captureActive then self:SetCaptureActive(false) end
  end)
  tinsert(UISpecialFrames,"CursorCompanionKeyCapture");f:Hide()
 end
 self:SetCaptureActive(true);self.callback=callback;self.pendingMouse=nil;self.pendingKey=nil;CC.TextLayout:FitWindow(self.capture);self.capture:Show()
end
function B:CreateWidget(parent,owner)
 local C=CC.Controls;local w={owner=owner}
 local f=CreateFrame("Frame",nil,parent);w.frame=f;f:SetSize(410,54)
 C:Text(f,"Menu shortcut:",0,-6,"GameFontNormalSmall")
 w.key=C:Button(f,"",128,0,192,function() if w.choose then w.choose:Click() end end)
 w.choose=C:Button(f,"Edit",329,0,72,function()
  CC.Skin:Select(w.key,true)
  B:Capture(function(key)
   owner.bindingDraft=key;owner.bindingConfirm=false;CC.Skin:Select(w.key,false);w:Refresh()
   owner:Notice("Shortcut changed in this draft. Apply to save.")
  end)
 end)
 w.message=C:Text(f,"",0,-36,"GameFontHighlightSmall");w.message:SetWidth(405)
 w.confirm=C:Button(f,"Replace existing shortcut",0,-60,235,function()owner.bindingConfirm=true;w:Refresh()end)
 function w:Refresh()
  local key=self.owner.bindingDraft or B:Current();self.key:SetText(B:Label(key))
  local conflict=self.owner.bindingDraft and B:Conflict(self.owner.bindingDraft)
  local message=conflict and (self.owner.bindingConfirm and "Existing shortcut will be replaced when you Apply." or "Already used by: "..tostring(_G["BINDING_NAME_"..conflict] or conflict)) or (B.notice or "")
  self.message:SetText(message);self.message:SetShown(message~="")
  self.confirm:SetShown(conflict~=nil and conflict~=false and conflict~="Unavailable" and not self.owner.bindingConfirm)
  local y=message~="" and 36+CC.TextLayout:Text(self.message,405,16)+10 or 34
  self.confirm:ClearAllPoints();self.confirm:SetPoint("TOPLEFT",0,-y)
  self.frame:SetHeight(y+(self.confirm:IsShown() and self.confirm:GetHeight()+10 or 0))
  if self.owner.draft and not self.owner.rendering and self.frame:IsShown() then self.owner:Render(true) end
 end
 self.widgets[#self.widgets+1]=w;w:Refresh();return w
end
function B:RefreshStatus() for _,w in ipairs(self.widgets) do w:Refresh() end end
function B:CommitDraft(owner)
 if not owner.bindingDraft then return true end
 local ok,why=self:Assign(owner.bindingDraft,owner.bindingConfirm==true)
 if ok then owner.bindingDraft=nil;owner.bindingConfirm=false end
 return ok,why
end

-- Shared Navigation binding. Retain the legacy native action ID and saved keys;
-- the applied Quest/Beacon mode selects behavior, not the Quest Notes checkbox.
B.notesAction="CURSORCOMPANION_QUESTNOTES"
B.notesDefaultKey="SHIFT-BUTTON3"
B.notesWidgets={}
function B:NotesCurrent()
 if type(GetBindingKey)~="function" then return nil end
 local ok,key=pcall(GetBindingKey,self.notesAction)
 return ok and S:IsText(key) and key~="" and key or nil
end
function B:NotesConflict(key)
 if type(GetBindingAction)~="function" then return "Unavailable" end
 if S:Value(GetBindingAction,key,false)==self.notesAction then return nil end
 local action=S:Value(GetBindingAction,key,true)
 if not S:IsText(action) then return "Unavailable" end
 if action~="" and action~=self.notesAction then return action end
end
function B:AssignNotes(key,replace)
 if S:InCombat() or CC.SavedData.readOnly then return false,"Leave combat to change the shortcut." end
 if type(key)~="string" or #key>80 or not key:match("^[A-Z0-9%-]+$") then return false,"Choose a valid shortcut." end
 local base=key:match("([^-]+)$")
 if base=="BUTTON1" or base=="BUTTON2" then return false,"Left and right clicks are reserved." end
 if not (type(GetBindingAction)=="function" and type(GetBindingKey)=="function" and
  type(SetBinding)=="function" and type(SaveBindings)=="function" and type(GetCurrentBindingSet)=="function") then
  return false,"Configure Navigation in WoW Key Bindings instead."
 end
 local conflict=self:NotesConflict(key)
 if conflict=="Unavailable" then return false,"WoW could not check the shortcut." end
 if conflict and not replace then return false,"Shortcut is already used. Confirm replacement or choose another." end
 local a,b=GetBindingKey(self.notesAction)
 local snapshot={}
 for _,k in ipairs({key,a or "",b or ""}) do if k~="" then snapshot[k]=GetBindingAction(k) end end
 local set=S:Value(GetCurrentBindingSet)
 if set~=1 and set~=2 then return false,"Select an account or character binding set first." end
 local function restore()
  for k,v in pairs(snapshot) do pcall(SetBinding,k,v~="" and v or nil) end
 end
 for _,old in ipairs({a or "",b or ""}) do if old~="" and old~=key then
  local ok,result=pcall(SetBinding,old,nil)
  if not ok or result~=true then restore();return false,"Previous Navigation shortcut could not be removed." end
 end end
 local ok,result=pcall(SetBinding,key,self.notesAction)
 if not ok or result~=true then restore();return false,"WoW refused the shortcut." end
 local saved,res=pcall(SaveBindings,set)
 if not saved or res==false then restore();return false,"WoW could not save the shortcut." end
 if CC.SavedData.character then CC.SavedData.character.questNotesBindingInitialized=true end
 self.notesNotice=nil;self:RefreshStatus();return true
end
function B:InitializeNotesDefault()
 if self.initializing or self.notesInitializing then return end
 if not (CC.state.inWorld and CC.profile and CC.profile.enabled and CC.profile.compass.enabled and
     (CC.profile.compass.mode=="Beacon" or CC.profile.compass.mode=="Quest")) then return end
 if S:InCombat() or CC.SavedData.readOnly then return end
 local db=CC.SavedData.character
 if not db or db.questNotesBindingInitialized then return end
 if self:NotesCurrent() then db.questNotesBindingInitialized=true;return end
 local conflict=self:NotesConflict(self.notesDefaultKey)
 if conflict=="Unavailable" then return end
 if conflict then
  self.notesNotice="Shift + Middle Mouse is used by another action. Choose a Navigation shortcut here or in WoW Key Bindings."
  db.questNotesBindingInitialized=true;self:RefreshStatus();return
 end
 self.notesInitializing=true
 local ok,message=self:AssignNotes(self.notesDefaultKey,false)
 self.notesInitializing=false
 if not ok then self.notesNotice=message;self:RefreshStatus() end
end
function B:CreateNotesWidget(parent,owner)
 local w={owner=owner}
 local f=CreateFrame("Frame",nil,parent);w.frame=f;f:SetSize(410,110)
 local C=CC.Controls
 w.title=C:Text(f,"Navigation shortcut:",0,-6,"GameFontNormalSmall");w.title:SetWidth(145)
 w.key=C:Button(f,"",150,0,171,function() if w.choose then w.choose:Click() end end)
 w.value=w.key
 w.choose=C:Button(f,"Edit",329,0,72,function()
  CC.Skin:Select(w.key,true)
  B:Capture(function(key)
   owner.notesBindingDraft=key;owner.notesBindingConfirm=false;CC.Skin:Select(w.key,false);w:Refresh()
   owner:Notice("Navigation shortcut changed in this draft. Apply / Finish to save.")
  end)
 end)
 w.mode=C:Text(f,"",0,-35,"GameFontNormalSmall");w.mode:SetWidth(405)
 w.message=C:Text(f,"",0,-57,"GameFontHighlightSmall");w.message:SetWidth(405)
 w.default=C:Button(f,"Use Shift + Middle Mouse",0,-85,218,function()
  owner.notesBindingDraft=B.notesDefaultKey;owner.notesBindingConfirm=false;w:Refresh()
  owner:Notice("Navigation shortcut changed in this draft. Apply / Finish to save.")
 end)
 w.confirm=C:Button(f,"Confirm replacement",228,-85,177,function()
  owner.notesBindingConfirm=true;w:Refresh()
 end)
 function w:Layout()
  local y=math.max(self.key:GetHeight(),self.choose:GetHeight())+10
  self.mode:ClearAllPoints();self.mode:SetPoint("TOPLEFT",0,-y)
  y=y+CC.TextLayout:Text(self.mode,405,16)+6
  self.message:ClearAllPoints();self.message:SetPoint("TOPLEFT",0,-y)
  y=y+CC.TextLayout:Text(self.message,405,16)+10
  self.default:ClearAllPoints();self.default:SetPoint("TOPLEFT",0,-y)
  self.confirm:ClearAllPoints();self.confirm:SetPoint("TOPLEFT",228,-y)
  y=y+math.max(self.default:GetHeight(),self.confirm:IsShown() and self.confirm:GetHeight() or 0)+10
  self.frame:SetHeight(y)
  if owner.draft and not owner.rendering and self.frame:IsShown() and owner.Render then owner:Render(true) end
 end
 function w:Refresh()
  local key=owner.notesBindingDraft or B:NotesCurrent()
  self.key:SetText(B:Label(key))
  local active=CC.Navigation:Mode();local selected=CC.Navigation:Mode(owner.draft or CC.profile)
  local label=CC.Navigation:ModeLabel(active)
  local modeText="Active: "..label..(active=="Beacon" and " - transmit waypoint" or active=="Quest" and " - Quest Notes" or "")
  if selected~=active then modeText=modeText.." | Pending: "..CC.Navigation:ModeLabel(selected) end
  self.mode:SetText(modeText)
  local conflict=owner.notesBindingDraft and B:NotesConflict(owner.notesBindingDraft)
  local save=owner==CC.Wizard and "Finish" or "Apply"
  local pending,pendingMessage=CC.Navigation:PendingShortcutChange(owner)
  local hint=selected=="Beacon" and "Shared shortcut: sends your position privately to party/raid addon users. It never opens Quest Notes in Beacon mode."
   or selected=="Quest" and ((owner.draft or CC.profile).questNotes.enabled and "Shared shortcut: opens Quest Notes in Quest Compass mode; transmits a waypoint in Beacon mode."
   or "Quest Notes is disabled. Enable Quest Notes and "..save.." to use the shortcut here. Beacon mode uses it to transmit a waypoint.")
   or "Choose Quest Compass or Beacon and "..save.." to enable the shared Navigation shortcut."
  self.confirm:Hide()
  if conflict and conflict~="Unavailable" then
   self.confirm:SetShown(not owner.notesBindingConfirm)
   self.message:SetText(owner.notesBindingConfirm and "Existing shortcut will be replaced on "..save.."." or "Shortcut in use: confirm replacement or choose another key.")
  elseif conflict=="Unavailable" then
   self.message:SetText("WoW cannot check this shortcut.")
  elseif pending then
   self.message:SetText(pendingMessage)
  else
   self.message:SetText(B.notesNotice or hint)
  end
  self:Layout()
 end
 self.notesWidgets[#self.notesWidgets+1]=w;w:Refresh();return w
end
function B:CommitNotesDraft(owner)
 if not owner.notesBindingDraft then return true end
 local ok,reason=self:AssignNotes(owner.notesBindingDraft,owner.notesBindingConfirm==true)
 if ok then owner.notesBindingDraft=nil;owner.notesBindingConfirm=false end
 return ok,reason
end
local previousRefresh=B.RefreshStatus
function B:RefreshStatus()
 previousRefresh(self)
 for _,widget in ipairs(self.notesWidgets) do widget:Refresh() end
end

-- F8 Fishing has its own stored binding and independently owned secure overrides.
B.fishingAction="CURSORCOMPANION_FISHING"
B.fishingDefaultKey="ALT-BUTTON3"
B.fishingWidgets={}
function B:FishingCurrent()
 if type(GetBindingKey)~="function" then return nil end
 local ok,key=pcall(GetBindingKey,self.fishingAction)
 return ok and S:IsText(key) and key~="" and key or nil
end
function B:FishingConflict(key)
 if type(GetBindingAction)~="function" then return "Unavailable" end
 if S:Value(GetBindingAction,key,false)==self.fishingAction then return nil end
 local action=S:Value(GetBindingAction,key,true)
 if not S:IsText(action) then return "Unavailable" end
 if action~="" and action~=self.fishingAction then return action end
end
function B:AssignFishing(key,replace)
 if S:InCombat() or CC.SavedData.readOnly then return false,"Leave combat to change the shortcut." end
 if type(key)~="string" or #key>80 or not key:match("^[A-Z0-9%-]+$") then return false,"Choose a valid shortcut." end
 local base=key:match("([^-]+)$")
 if base=="BUTTON1" or base=="BUTTON2" then return false,"Left and right clicks are reserved." end
 if not (type(GetBindingAction)=="function" and type(GetBindingKey)=="function" and
  type(SetBinding)=="function" and type(SaveBindings)=="function" and type(GetCurrentBindingSet)=="function") then
  return false,"Configure Fishing Assistant in WoW Key Bindings instead."
 end
 local conflict=self:FishingConflict(key)
 if conflict=="Unavailable" then return false,"WoW could not check the shortcut." end
 if conflict and not replace then return false,"Shortcut is already used. Confirm replacement or choose another." end
 local a,b=GetBindingKey(self.fishingAction)
 local snapshot={}
 for _,k in ipairs({key,a or "",b or ""}) do if k~="" then snapshot[k]=GetBindingAction(k) end end
 local set=S:Value(GetCurrentBindingSet)
 if set~=1 and set~=2 then return false,"Select an account or character binding set first." end
 local function restore()
  for k,v in pairs(snapshot) do pcall(SetBinding,k,v~="" and v or nil) end
 end
 for _,old in ipairs({a or "",b or ""}) do if old~="" and old~=key then
  local ok,result=pcall(SetBinding,old,nil)
  if not ok or result~=true then restore();return false,"Previous Fishing Assistant shortcut could not be removed." end
 end end
 local ok,result=pcall(SetBinding,key,self.fishingAction)
 if not ok or result~=true then restore();return false,"WoW refused the shortcut." end
 local saved,res=pcall(SaveBindings,set)
 if not saved or res==false then restore();return false,"WoW could not save the shortcut." end
 if CC.SavedData.character then CC.SavedData.character.fishingBindingInitialized=true end
 self.fishingNotice=nil;self:RefreshStatus();return true
end
function B:InitializeFishingDefault()
 if not (CC.state.inWorld and CC.profile and CC.profile.fishing and CC.profile.fishing.enabled) then return end
 if self.fishingInitializing then return end
 if S:InCombat() or CC.SavedData.readOnly then return end
 local db=CC.SavedData.character
 if not db or db.fishingBindingInitialized then return end
 if self:FishingCurrent() then db.fishingBindingInitialized=true;return end
 local conflict=self:FishingConflict(self.fishingDefaultKey)
 if conflict=="Unavailable" then return end
 if conflict then
  self.fishingNotice="Alt + Middle Mouse is used by another action. Choose a Fishing shortcut here or in WoW Key Bindings."
  db.fishingBindingInitialized=true;self:RefreshStatus();return
 end
 self.fishingInitializing=true
 local ok,message=self:AssignFishing(self.fishingDefaultKey,false)
 self.fishingInitializing=false
 if not ok then self.fishingNotice=message;self:RefreshStatus() end
end
function B:CreateFishingWidget(parent,owner)
 local w={owner=owner}
 local f=CreateFrame("Frame",nil,parent);w.frame=f;f:SetSize(410,100)
 local C=CC.Controls
 C:Text(f,"Fishing shortcut",0,-2,"GameFontNormalSmall")
 w.value=C:Text(f,"",182,-2,"GameFontHighlightSmall")
 w.choose=C:Button(f,"Change shortcut",0,-27,155,function()
  B:Capture(function(key)
   owner.fishingBindingDraft=key;owner.fishingBindingConfirm=false;w:Refresh()
   owner:Notice("Fishing shortcut is not saved yet.")
  end)
 end)
 w.default=C:Button(f,"Alt + Middle Mouse",168,-27,170,function()
  owner.fishingBindingDraft=B.fishingDefaultKey;owner.fishingBindingConfirm=false;w:Refresh()
 end)
 w.confirm=C:Button(f,"Confirm replacement",0,-62,170,function()
  owner.fishingBindingConfirm=true;w:Refresh()
 end)
 w.message=C:Text(f,"",180,-65,"GameFontHighlightSmall");w.message:SetWidth(225)
 function w:Layout()
  local valueH=CC.TextLayout:Text(self.value,223,16)
  local buttonsY=math.max(27,valueH+12)
  self.choose:ClearAllPoints();self.choose:SetPoint("TOPLEFT",0,-buttonsY)
  self.default:ClearAllPoints();self.default:SetPoint("TOPLEFT",168,-buttonsY)
  local y=buttonsY+math.max(self.choose:GetHeight(),self.default:GetHeight())+10
  self.confirm:ClearAllPoints();self.confirm:SetPoint("TOPLEFT",0,-y)
  self.message:ClearAllPoints();self.message:SetPoint("TOPLEFT",180,-y-3)
  y=y+math.max(self.confirm:IsShown() and self.confirm:GetHeight() or 0,CC.TextLayout:Text(self.message,225,16)+3)+12
  self.frame:SetHeight(math.max(100,y))
  if owner.draft and not owner.rendering and self.frame:IsShown() and owner.Render then owner:Render(true) end
 end
 function w:Refresh()
  local key=owner.fishingBindingDraft or B:FishingCurrent()
  self.value:SetText(B:Label(key))
  local conflict=owner.fishingBindingDraft and B:FishingConflict(owner.fishingBindingDraft)
  if conflict and conflict~="Unavailable" then
   self.confirm:SetShown(not owner.fishingBindingConfirm)
   self.message:SetText(owner.fishingBindingConfirm and "Will replace on Apply/Finish." or "Shortcut in use: confirm to replace.")
  elseif conflict=="Unavailable" then
   self.confirm:Hide();self.message:SetText("WoW cannot check this shortcut.")
  else
   self.confirm:Hide();self.message:SetText(B.fishingNotice or "Press during an active Fishing channel to cancel/recast. Right-click bobber to reel; never unattended casting.")
  end
  self:Layout()
 end
 self.fishingWidgets[#self.fishingWidgets+1]=w;w:Refresh();return w
end
function B:CommitFishingDraft(owner)
 if not owner.fishingBindingDraft then return true end
 local ok,reason=self:AssignFishing(owner.fishingBindingDraft,owner.fishingBindingConfirm==true)
 if ok then owner.fishingBindingDraft=nil;owner.fishingBindingConfirm=false end
 return ok,reason
end

local f8PreviousRefresh=B.RefreshStatus
function B:RefreshStatus()
 f8PreviousRefresh(self)
 for _,widget in ipairs(self.fishingWidgets) do widget:Refresh() end
end
function B:RefreshActions()
 if self.refreshingActions or S:InCombat() then return end
 self.refreshingActions=true
 for _,module in ipairs({CC.Palette,CC.Fishing}) do
  if module and module.RefreshBindings then
   local ok=pcall(module.RefreshBindings,module)
   if not ok then CC.Diagnostics:OptionalFault("BINDING_REFRESH_FAILED") end
  end
 end
 self.refreshingActions=false
end
function CursorCompanion_FishingShortcut(keyState)
 if keyState=="down" then return end
 if B:SuppressInvocation() then return end
 if CC.Fishing then CC.Fishing:Invoke() end
end
BINDING_NAME_CURSORCOMPANION_FISHING="Fishing Assistant: equip / cast / recast"

-- Save all pending editor shortcuts as one transaction. A later refusal must
-- not leave an earlier shortcut changed while the settings still say unsaved.
function B:CommitAllDrafts(owner)
 local edits={
  {action=self.action,key=owner.bindingDraft,replace=owner.bindingConfirm,field="binding"},
  {action=self.notesAction,key=owner.notesBindingDraft,replace=owner.notesBindingConfirm,field="notesBinding"},
  {action=self.fishingAction,key=owner.fishingBindingDraft,replace=owner.fishingBindingConfirm,field="fishingBinding"}}
 local any=false;for _,e in ipairs(edits) do if e.key then any=true end end
 if not any then return true end
 if S:InCombat() or CC.SavedData.readOnly then return false,"Leave combat to save shortcuts." end
 if not (GetBindingAction and GetBindingKey and SetBinding and SaveBindings and GetCurrentBindingSet) then return false,"WoW key bindings are unavailable." end
 local set=S:Value(GetCurrentBindingSet)
 if set~=1 and set~=2 then return false,"Select account or character key bindings first." end
 local desired,snapshot={},{}
 for _,e in ipairs(edits) do if e.key then
  local key=e.key
  if type(key)~="string" or #key>80 or not key:match("^[A-Z0-9%-]+$") then return false,"Choose a valid shortcut." end
  local base=key:match("([^-]+)$");local button=base and base:match("^BUTTON(%d+)$")
  if base=="BUTTON1" or base=="BUTTON2" or (button and (tonumber(button)<3 or tonumber(button)>31 or base~="BUTTON"..tonumber(button))) then return false,"Choose middle mouse, a side button, the wheel, or a keyboard key." end
  if desired[key] and desired[key]~=e.action then return false,"Choose a different shortcut for each Cursor Companion action." end
  desired[key]=e.action
  local current=S:Value(GetBindingAction,key,false)
  if not S:IsText(current) then return false,"WoW cannot inspect this shortcut." end
  local conflict
  if e.field=="binding" then conflict=self:Conflict(key)
  elseif e.field=="notesBinding" then conflict=self:NotesConflict(key)
  else conflict=self:FishingConflict(key) end
  if conflict=="Unavailable" then return false,"WoW cannot inspect this shortcut." end
  if conflict and not e.replace then return false,"A shortcut is in use. Confirm its replacement before applying." end
  if current~="" and current~=e.action and not e.replace then return false,"A shortcut is in use. Confirm its replacement before applying." end
  snapshot[key]=current
  local a,b=GetBindingKey(e.action)
  e.beforeKeys={a or "",b or ""}
  for _,old in ipairs(e.beforeKeys) do if old~="" then snapshot[old]=GetBindingAction(old,false) end end
 end end
 local function rollback()
  for key,action in pairs(snapshot) do pcall(SetBinding,key,action~="" and action or nil) end
  pcall(SaveBindings,set)
 end
 self.initializing=true;self.notesInitializing=true;self.fishingInitializing=true
 local ok=pcall(function()
  for _,e in ipairs(edits) do if e.key then for _,key in ipairs(e.beforeKeys) do
   if key~="" and SetBinding(key,nil)~=true then error("UNBIND_REFUSED") end
  end end end
  for _,e in ipairs(edits) do if e.key and SetBinding(e.key,e.action)~=true then error("BIND_REFUSED") end end
  if SaveBindings(set)==false then error("SAVE_REFUSED") end
 end)
 if not ok then rollback() end
 self.initializing=false;self.notesInitializing=false;self.fishingInitializing=false
 if not ok then self:RefreshActions();return false,"Shortcuts could not be saved; previous assignments were restored." end
 local db=CC.SavedData.character
 if db and owner.bindingDraft then
  local after={};for key in pairs(snapshot) do after[key]=GetBindingAction(key,false) end
  db.bindingUndo={before=snapshot,after=after,set=set}
 end
 for _,e in ipairs(edits) do if e.key then
  owner[e.field.."Draft"]=nil;owner[e.field.."Confirm"]=false
  if db then
   if e.field=="binding" then db.bindingInitialized=true
   elseif e.field=="notesBinding" then db.questNotesBindingInitialized=true
   else db.fishingBindingInitialized=true end
  end
 end end
 self:RefreshActions();self:RefreshStatus();return true
end
