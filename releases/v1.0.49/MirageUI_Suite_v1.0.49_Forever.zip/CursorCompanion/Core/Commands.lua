local _,CC=...
CC.Commands={}
function CC.Commands:Register()
 SlashCmdList.CURSORCOMPANION=function(msg) self:Execute(msg) end;SLASH_CURSORCOMPANION1="/cursorcompanion"
 local used=false
 for key in pairs(SlashCmdList) do if key~="CURSORCOMPANION" then
  for i=1,10 do local v=_G["SLASH_"..key..i];if type(v)=="string" and v:lower()=="/cc" then used=true end end
 end end
 if not used then SLASH_CURSORCOMPANION2="/cc" end
end
function CC.Commands:Execute(msg)
 local command,rest=(msg or ""):match("^%s*(%S*)%s*(.-)%s*$");command=command:lower()
 if command=="off" then CC.SavedData:EmergencyOff();return end
 if command=="status" then CC:Print(CC.version.." | "..CC.ClientIdentity.verdict.." | "..CC.state.reason.."; /cc export for details");return end
 if command=="forever" or command=="compat" then CC:Print(CC.Diagnostics:ForeverStatus());return end
 if command=="nav" and rest=="" then CC:Print(CC.Navigation:Summary());CC:Print(CC.Navigation:ShortcutSummary());return end
 if command=="gcd" then
  local t=CC.Timing;local v=t.gcdStats or {};local lane=t.lanes and t.lanes.gcd
  local rings={}
  for _,key in ipairs({"inner","outer","outer2"}) do
   local r=CC.profile.rings[key]
   if r and r.enabled and r.role=="GCD" then
    rings[#rings+1]=key.." ("..math.floor((r.opacity or 1)*100+.5).."% opacity)"
   end
  end
  CC:Print("GCD rings="..(#rings>0 and table.concat(rings,",") or "NONE")
   .." | lane="..tostring(lane and lane.status or "NOT_RUN")
   .." | source="..tostring(v.source or "NOT_RUN").." | reason="..tostring(v.reason or "NOT_RUN")
   .." | table="..tostring(v.tableSamples or 0).." native="..tostring(v.nativeSamples or 0)
   .." | actions="..tostring(v.actionCandidates or 0).." slot="..tostring(v.actionSlot or 0)
   .." | actionStatus="..tostring(v.actionReason or "NOT_RUN")
   .." | idleWake="..tostring(t:IsGCDVisibilityNeeded())
   .." | cooldown events="..tostring(v.eventUpdates or 0).." casts="..tostring(v.castEvents or 0))
  return
 end
 if command=="gcdtest" then
  local ok,why=CC.Timing:RunGCDRenderTest()
  CC:Print(ok and "GCD VISUAL DEMO (not a real cooldown): 1.5s sweep; cast after it ends. /cc gcd for data status." or ("GCD visual demo unavailable: "..tostring(why)))
  return
 end
 if command=="test" then CC.Diagnostics:SelfTest();CC:Print(CC.Diagnostics.lastSelfTest);return end
 if command=="export" then CC.Settings:OpenDiagnostics();return end
 if command=="alerttest" then
  local ok,reason=CC.AlertConditions:LiveTest()
  CC:Print(ok and "Live alert test started at the cursor. Move the mouse over the game world if your windows hide cursor effects." or (reason or "Live alert unavailable."))
  return
 end
 if command=="beacon" then
  if rest=="history" then CC:Print(CC.NativePings:HistoryText())
  elseif rest=="clearhistory" then CC.NativePings:ClearHistory();CC:Print("Local signal history cleared.")
  elseif rest=="send" or rest=="publish" then local _,message=CC.Beacon:Publish();if message then CC:Print(message) end
  elseif rest=="clear" then CC.Beacon:Clear("CLEARED");CC:Print("Local Beacon cleared. Other players' waypoints are unchanged.")
  elseif rest=="sync" or rest=="recover" then local _,message=CC.Beacon:RequestSync();CC:Print(message)
  elseif rest=="hold" or rest=="lock" then local _,message=CC.Beacon:SetHeld(true);CC:Print(message)
  elseif rest=="release" or rest=="unlock" then local _,message=CC.Beacon:SetHeld(false);CC:Print(message)
  else CC:Print(CC.Beacon:Summary());CC:Print(CC.NativePings:Summary());CC:Print("Navigation shortcut publishes a hidden group waypoint. /cc beacon send | sync | hold | release | clear") end
  return
 end
 if command=="fish" or command=="fishing" then
  if rest=="restore" then local _,message=CC.Fishing:RequestRestore();if message then CC:Print(message) end
  else
   local s=CC.Fishing:GetStatus()
   CC:Print("Fishing: "..tostring(s.phase).." | access="..tostring(s.access).." | "..tostring(s.reason).." | swap="..tostring(s.swap).." | restore="..tostring(s.restoreWanted).." | water check=cast result; bite detection unavailable.")
  end
  return
 end
 if command=="palette" or command=="menu" then
  if CC.Safety:InCombat() then CC:Print("Open the combat menu with "..CC.Bindings:Label(CC.Bindings:Current())..". Escape closes it.")
  else CC.Palette:Toggle() end
  return
 end
 if CC.Safety:InCombat() then CC:Print("Edit settings after combat. The assigned Quick Menu shortcut remains available; /cc off stops cursor effects.");return end
 if command=="" or command=="config" then CC.Settings:Open()
 elseif command=="notes" then CC.QuestNotes:Toggle()
 elseif command=="route" then
  if rest=="" then CC.QuestRoutePanel:Open()
  elseif rest=="status" then CC:Print(CC.QuestRoute:Summary())
  elseif rest=="on" or rest=="suggest" or rest=="follow" or rest=="off" then
   local mode=rest=="follow" and "Follow route" or rest=="off" and "Off" or "Suggestions"
   local ok,why=CC.QuestRoute:SetMode(mode)
   CC:Print(ok and ("Experimental route mode: "..mode..". /cc route opens the review panel. Quest Compass must be enabled; ring roles are unchanged.") or why)
  elseif rest=="reset" then
   CC.QuestRoute:Reset(true);CC.QuestNavigation:Invalidate("ROUTE_RESET");CC.QuestNotes:Invalidate()
   CC:Print("Deferred destinations restored and route reset. Quest completion and your pin were not changed.")
  elseif rest=="skip" then
   CC.QuestNavigation:Snapshot();local first=CC.QuestRoute.plan[1]
   local ok,why=CC.QuestRoute:Defer(first and first.id);CC:Print(why)
  else CC:Print("/cc route = review; on = suggestions; follow = guide; off = disable; skip = defer first stop; reset = restore; status = diagnostics.") end
 elseif command=="nav" then
  if rest=="clear" then CC.QuestNavigation:ClearPin();CC.QuestCompass:Invalidate("PIN_CLEARED");CC.QuestNotes:Invalidate();CC:Print("Quest pin cleared; automatic guidance resumed.")
  elseif rest=="refresh" then
   CC.QuestNavigation:Refresh();CC.QuestCompass:Invalidate("MANUAL_REFRESH");CC.QuestNotes:Invalidate()
   CC:Print("Navigation data refreshed. Only readable Blizzard locations will be used.")
  elseif rest=="polish" or rest=="classic" then
   local p=CC:Copy(CC.profile);local enabled=rest=="polish"
   p.compass.selectionMode=enabled and "Focused" or "Nearest"
   p.compass.stableTarget=enabled;p.compass.smoothHeading=enabled;p.compass.arrivalCue=enabled;p.compass.showLabel=enabled
   if not enabled then p.compass.routeMode="Off" end
   local ok,why=CC.SavedData:Commit(p)
   CC:Print(ok and (enabled and "F6 navigation polish enabled. Quest Compass must be selected in Outside cursor. Ring roles were not changed."
    or "F5-like navigation options restored. Your manual quest pin, if any, is retained; /cc nav clear removes it.") or why)
  else CC:Print("/cc nav = status; /cc nav polish = enable new options; /cc nav classic = restore original options; /cc nav clear = unpin; /cc nav refresh = recheck location.") end
 elseif command=="custom" or command=="utility" then CC.Settings:Open();CC.Settings.page="Quick menu";CC.Settings:Render()
 elseif command=="setup" then CC.Wizard:Open(true)
 elseif command=="minimap" then CC.Settings:Open()
 elseif command=="on" or command=="toggle" then CC.state.fault=nil;CC.SavedData:Set("enabled",command=="on" or not CC.profile.enabled)
 elseif command=="record" then local test,result=rest:match("^(T%d%d)%s+(%S+)$");CC.Evidence:Record(test,result)
 elseif command=="size" or command=="opacity" or command=="idle" then
  local n=tonumber(rest);if CC.Safety:IsNumber(n) then local ok,why=CC.SavedData:Set(command=="idle" and "idleHideSeconds" or command,n);if not ok then CC:Print(why) end end
 elseif command=="offset" then
  local x,y=rest:match("^(%-?[%d%.]+)%s+(%-?[%d%.]+)$");x,y=tonumber(x),tonumber(y)
  if CC.Safety:IsNumber(x) and CC.Safety:IsNumber(y) then local p=CC:Copy(CC.profile);p.offsetX=x;p.offsetY=y;local ok,why=CC.SavedData:Commit(p);if not ok then CC:Print(why) end end
 elseif command=="theme" then
  for _,v in ipairs(CC.ThemeOrder) do if v:lower()==rest:lower() then CC.SavedData:Set("theme",v);return end end;CC:Print("Choose Manual, Class or Neutral in ring settings.")
 elseif command=="shape" then
  local found;for _,v in ipairs(CC.StyleOrder) do if v:lower()==rest:lower() then found=v end end
  if found then CC.SavedData:Set("shape",found) else CC:Print("Use Rings settings to select a style.") end
 elseif command=="profile" and (rest=="account" or rest=="character") then CC.SavedData:UseCharacter(rest=="character")
 elseif command=="reset" then if rest=="confirm" then CC.SavedData:Reset() else CC:Print("Reset active profile: /cc reset confirm") end
 elseif command=="coexist" and rest=="confirm" then CC.state.conflictAcknowledged=true;CC.VisualLifecycle:Reconcile()
 elseif command=="preset" then
  for _,name in ipairs(CC.PresetNames) do
   if name:lower()==rest:lower() then
    local p=CC:Preset(name)
    if name~="Developer Curated" then
     p.info.reference=CC.profile.info.reference
     for _,key in ipairs({"customMenus","quickMenus","utility","fishing","beacon"}) do p[key]=CC:Copy(CC.profile[key]) end
    end
    CC.SavedData:Commit(p);return
   end
  end
  CC:Print("Presets: "..table.concat(CC.PresetNames,", "))
 else CC:Print("config, on, off, toggle, status, forever, nav, beacon, fish, custom, route, notes, gcd, gcdtest, export, test, alerttest, palette, record T01 PASS, size N, opacity N, idle N, offset X Y, setup, minimap, shape NAME, profile account|character, reset confirm, coexist confirm, preset NAME") end
end
