-- Optional public settings entry. This file also works without MirageUI installed.
-- Register a closure; never create a window, load another addon or change saved settings here.
local addonName,A=...
local function outOfCombat()
    if type(InCombatLockdown)~="function" then return false end
    local ok,locked=pcall(InCombatLockdown)
    if not ok then return false end
    if type(issecretvalue)=="function" then
        local known,secret=pcall(issecretvalue,locked)
        if not known or secret then return false end
    end
    return locked==false or locked==nil
end
local function openSettings()
    if not outOfCombat() then return false,"Open settings after combat." end
    if not (A.state and A.state.initialized) then return false,"This addon has not finished loading." end
    local panel=A.Settings
    if type(panel)~="table" or type(panel.Open)~="function" then return false,"Settings are unavailable." end
    -- Open creates a new edit session. Selecting an already-open settings
    -- window must preserve its unapplied appearance and binding drafts.
    local current=panel.frame
    if current then
        if type(current.IsShown)~="function" then return false,"Existing settings visibility is unavailable." end
        local observed,shown=pcall(current.IsShown,current)
        if not observed then return false,"Existing settings visibility is unavailable." end
        if type(issecretvalue)=="function" then
            local known,secret=pcall(issecretvalue,shown)
            if not known or secret then return false,"Existing settings visibility is unavailable." end
        end
        if shown==true then
            if type(current.Raise)=="function" then pcall(current.Raise,current) end
            return true
        elseif shown~=false then return false,"Existing settings visibility is unavailable." end
    end
    local called,result,reason=pcall(panel.Open,panel)
    if not called then return false,"The settings window could not open." end
    if result==false then return false,reason or "Settings are unavailable." end
    local frame=panel.frame
    if not frame or type(frame.IsShown)~="function" then return false,"The settings window is unavailable." end
    local observed,shown=pcall(frame.IsShown,frame)
    if not observed or shown~=true then return false,"The settings window did not open." end
    return true
end
if _G.MirageUIAddonSettings==nil then _G.MirageUIAddonSettings={} end
if type(_G.MirageUIAddonSettings)=="table" then
    _G.MirageUIAddonSettings[addonName]={title="Cursor Companion",icon="Interface\\AddOns\\CursorCompanion\\Media\\CrosshairIcon.tga",order=10,
        open=openSettings,combatSafe=false,version=A.version}
end

-- Read-only activity contract for Wayfinder. It prevents the presence of an
-- installed but disabled/hidden cursor compass from suppressing its HUD.
-- No destination, ring setting, waypoint or quest tracking is changed here.
local function visible(frame)
    if not frame then return false end
    if type(frame.IsVisible)~="function" then return nil end
    local ok,value=pcall(frame.IsVisible,frame)
    if not ok then return nil end
    if type(issecretvalue)=="function" then
        local known,secret=pcall(issecretvalue,value)
        if not known or secret then return nil end
    end
    if type(value)=="boolean" then return value end
    return nil
end
local function navigationActivity()
    if not A.state or not A.state.initialized or not A.state.running then return false,"None" end
    if not A.Navigation or type(A.Navigation.Mode)~="function" then return nil,"Unknown" end
    if A.Wayfinder and A.Wayfinder:IsManaged() then
        local frame=A.CompanionFrame and A.CompanionFrame.compassLayer
        local showing=visible(frame and frame.root)
        return A.Wayfinder.leaseRevision~=nil and showing==true,"Wayfinder"
    end
    local ok,mode=pcall(A.Navigation.Mode,A.Navigation)
    if not ok then return nil,"Unknown" end
    if mode~="Quest" and mode~="Beacon" then return false,"None" end
    local body=A.CompanionFrame and A.CompanionFrame.compassLayer
    local arrow=visible(body and body.root)
    local label=visible(A.NavigationLabel and A.NavigationLabel.frame)
    if arrow==true or label==true then return true,mode end
    if arrow==nil or label==nil then return nil,mode end
    return false,mode
end
if _G.MirageUICursorNavBridge==nil then
    _G.MirageUICursorNavBridge={apiVersion=1,navigationVersion=2,provider="CursorCompanion",activityOnly=true,snapshotConsumer=true,
        SetStartupPresentation=function(active)
            if type(active)=="boolean" then A.VisualLifecycle:SetStartupPresentation(active) end
        end,
        SetBindingCapture=function(active)
            if type(active)~="boolean" or not A.Bindings or type(A.Bindings.SetCaptureActive)~="function" then return false end
            -- Suspending prepared shortcut overrides is separate from any
            -- saved binding. Their existing delayed release guard handles a
            -- final key-up without casting Fishing or opening the palette.
            A.Bindings:SetCaptureActive(active)
            if A.VisualLifecycle then
                A.VisualLifecycle.workspaceCapture=active
                A.VisualLifecycle:RefreshWorkspacePresentation()
            end
            return true
        end,
        CloseTransient=function()
            if not outOfCombat() then return false,"Close companion windows after combat." end
            local complete=true
            for _,entry in ipairs({{A.Settings,"CloseForCombat"},{A.Wizard,"CloseForCombat"},
                {A.Palette,"Close"},{A.QuestNotes,"Close"},{A.QuestRoutePanel,"Close"},{A.FishingStatus,"Hide"}}) do
                local object,method=entry[1],entry[2]
                if object and type(object[method])=="function" then
                    local ok=pcall(object[method],object);if not ok then complete=false end
                end
            end
            return complete
        end,
        IsAnyNavigationActive=function()local active=navigationActivity();return active end,
        GetSupportStatus=function()
            local w=A.Wayfinder
            return {running=A.state and A.state.running==true,managed=w and w.managed==true,
                source=w and w.managed and "WAYFINDER" or "STANDALONE",status=w and w.status or "NOT_READY",
                reason=w and w.reason,revision=w and w.navigationRevision,
                guidance=w and w.guidance and w.guidance.status or "NOT_SAMPLED",
                renderer=w and w.leaseRevision and "CURSOR" or "NONE"}
        end,
        GetState=function()
            if A.Wayfinder and A.Wayfinder:IsManaged() then
                local s=A.Wayfinder
                return {status=s.reason or "WAYFINDER_STARTING",mode="Wayfinder",owner="Wayfinder",renderer=s.leaseRevision and "CursorCompanion" or nil,
                    destinationID=s.selection and s.selection.id,revision=s.navigationRevision,nativeVerification="NOT_RUN"}
            end
            local active,mode=navigationActivity()
            return {status=active==true and "CURSOR_NAVIGATION_VISIBLE" or active==false and "CURSOR_NAVIGATION_HIDDEN" or "CURSOR_NAVIGATION_UNKNOWN",
                mode=mode,active=active,readOnly=true}
        end}
end
