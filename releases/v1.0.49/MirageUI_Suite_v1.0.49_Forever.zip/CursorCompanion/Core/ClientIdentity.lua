local _,CC=...
CC.ClientIdentity={}
function CC.ClientIdentity:Detect()
 local patch,build,interface=CC.API:GetBuild()
 self.version=patch or "unknown";self.build=build or "unknown";self.interface=interface or 0
 self.flavor=CC.adapter and CC.adapter.flavor or "unknown"
 local forever=self.flavor=="Forever" and patch=="1.60.1" and interface==16001
 local reviewed=forever and (build=="70938" or build=="70959" or build=="71037") or
  self.flavor=="Midnight" and patch=="12.1.5" and interface==120105 and build=="70575"
 self.sourceMatched=reviewed==true
 self.allowed=CC.adapter~=nil
 self.providerAllowed=self.allowed
 self.runtimePolicy="CAPABILITY_GUARDED"
 self.providerBuildStatus=reviewed and "REVIEWED_SOURCE_API_GUARDED" or "UNREVIEWED_CLIENT_API_GUARDED"
 self.verdict=self.allowed and self.providerBuildStatus or "ADAPTER_UNAVAILABLE"
 -- Vitals, GCD, casting, alerts and actions each probe their own APIs and
 -- restricted values. An absent optional API does not stop cursor artwork.
end
