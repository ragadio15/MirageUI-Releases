local _, CC = ...
assert(not CC.adapter, "Cursor Companion: more than one client adapter loaded")
CC.adapter = { flavor = "Forever", interface = 16001, patch = "1.60.1",
    evidence = "FOREVER_LAUNCH_1.60.1_API_SIGNATURES_NATIVE_NOT_CERTIFIED" }
