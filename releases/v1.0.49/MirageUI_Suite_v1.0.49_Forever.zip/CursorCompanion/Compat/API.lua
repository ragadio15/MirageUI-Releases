local _, CC = ...
local A = CC.API
function A:GetBuild()
    if type(GetBuildInfo) ~= "function" then return nil end
    local ok, version, build, date, interface = pcall(GetBuildInfo)
    if not ok or not CC.Safety:IsText(version) or not CC.Safety:IsText(build)
        or not CC.Safety:IsNumber(interface) then return nil end
    return version, build, interface
end
function A:GetAddOnLoaded(name)
    local fn = C_AddOns and C_AddOns.IsAddOnLoaded or IsAddOnLoaded
    return CC.Safety:BoolCall(fn, name) == true
end
function A:MouseCaptured()
    local looking = CC.Safety:BoolCall(IsMouselooking)
    if looking == nil then return true, "CAPTURE_UNKNOWN" end
    if looking then return true, "MOUSELOOK" end
    if CC.profile.hideOnMouseDown then
        local left = CC.Safety:BoolCall(IsMouseButtonDown, "LeftButton")
        local right = CC.Safety:BoolCall(IsMouseButtonDown, "RightButton")
        if left == nil or right == nil then return true, "BUTTON_STATE_UNKNOWN" end
        if left or right then return true, "MOUSE_BUTTON_HELD" end
    end
    return false
end
