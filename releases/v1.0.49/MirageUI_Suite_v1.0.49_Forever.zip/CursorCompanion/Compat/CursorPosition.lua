local _, CC = ...
CC.CursorPosition = {}
function CC.CursorPosition:Sample()
    local x, y = GetCursorPosition()
    if not CC.Safety:IsNumber(x) or not CC.Safety:IsNumber(y) then return nil, nil, "POSITION_UNKNOWN" end
    local scale = UIParent:GetEffectiveScale()
    local width, height = UIParent:GetWidth(), UIParent:GetHeight()
    if not CC.Safety:IsNumber(scale) or scale <= 0 or not CC.Safety:IsNumber(width)
        or not CC.Safety:IsNumber(height) or width <= 0 or height <= 0 then
        return nil, nil, "SCALE_UNKNOWN"
    end
    x, y = x / scale, y / scale
    if x < 0 or y < 0 or x > width or y > height then return nil, nil, "OUTSIDE_WINDOW" end
    -- Do NOT clamp the ring center: that would break its relationship to the hotspot.
    -- At screen edges the decorative ring may clip, while its center stays correct.
    return x, y
end
