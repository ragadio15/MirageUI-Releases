local _,CC=...
-- F6 presentation state. Location discovery/selection is shared with Notes.
CC.QuestCompass={status="OFF",kind="Quest",elapsed=0,requests=0,watchedCount=0,poiCount=0}
local Q=CC.QuestCompass
for _,name in ipairs({"RelativeAngle","MapWorld","PlayerWorld","MapChain","WatchedIDs","MapPOIs"}) do
 local method=name
 Q[method]=function(_,...) return CC.QuestNavigation[method](CC.QuestNavigation,...) end
end
function Q:BestWaypoint()
 local _,_,selected=CC.QuestNavigation:Snapshot(true);return selected
end
function Q:Reset(reason)
 self.status=reason or "UNAVAILABLE";self.angle=nil;self.questID=nil;self.source=nil;self.distance=nil
 self.name=nil;self.stage=nil;self.key=nil;self.selection=nil;self.elapsed=0;self.arrived=false;self.combatCached=nil
 CC.QuestNavigation:Invalidate(reason)
 CC.QuestNavigation.status=self.status
 if CC.QuestRoute then CC.QuestRoute:Suspend(reason=="RESTRICTED" and "RESTRICTED" or "OFF") end
 if reason=="RESTRICTED" or reason=="OFF" then CC.QuestNavigation.selected=nil end
end
function Q:Invalidate(reason)
 CC.QuestNavigation:Invalidate(reason);self.angle=nil;self.status="REFRESHING";self.arrived=false
end
function Q:Enabled()
 return CC.profile and CC.profile.enabled==true and CC.profile.compass
  and CC.profile.compass.enabled==true and CC.profile.compass.mode~="Beacon"
end
function Q:Tick(dt)
 if not self:Enabled() then self:Reset("OFF");return end
 if not CC.Safety:IsNumber(dt) or dt<0 then self:Reset("UNAVAILABLE");return end
 local nav=CC.QuestNavigation;nav.clock=nav.clock+math.min(dt,.25)
 self.elapsed=(self.elapsed or 0)+math.min(dt,.25)
 local now=nav:Now()
 if self.elapsed<.15 and self.lastTick and now-self.lastTick<.15 then return end
 self.elapsed=0;self.lastTick=now
 local _,status,target,player=nav:Snapshot()
 self.watchedCount=nav.watchedCount or 0;self.poiCount=nav.poiCount or 0
 self.selection=target;self.questID=target and target.id;self.name=target and target.name
 self.stage=target and target.stage;self.source=target and target.source
 self.confidence=target and target.confidence;self.distance=target and target.approxDistance
 self.combatCached=target and target.combatCached==true
 local priorKey=self.key;self.key=target and target.key
 if not target or not player or status~="LOCATED" or not CC.Safety:IsNumber(self.distance) then
  self.status=status;self.angle=nil;self.arrived=false;return
 end
 local pref=CC.profile.compass
 local radius=pref.arrivalRadius or 8
 if pref.arrivalCue then
  if priorKey~=self.key then self.arrived=false end
  self.arrived=self.distance<=(self.arrived and radius+4 or radius)
 else self.arrived=false end
 if self.arrived then self.status="NEAR_DESTINATION";self.angle=nil;return end
 local facing=CC.Safety:Value(GetPlayerFacing)
 if not CC.Safety:IsNumber(facing) then self.status="NO_FACING";self.angle=nil;return end
 self.angle=nav:RelativeAngle(player.x,player.y,target.x,target.y,facing)
 self.status=self.angle and "GUIDING" or "DESTINATION_REACHED"
end
function Q:Get() return self end
