local _,CC=...
-- Midnight-safe Alerts: event delivery ONLY. Do not poll or compare combat
-- health, resource, auras, enemy casts, or any protected combat values.
-- An event is a fact that it fired; the addon never inspects spell payloads.
CC.AlertConditions={active=false,triggers=0,unavailable=0,lastCondition=nil,
 status="NOT_STARTED",liveTests=0,pending=nil,queue={},testConfig=nil}
local A=CC.AlertConditions
function A:Start()
 self.active=CC.profile.alerts.enabled and CC.Capabilities.alerts and CC.state.running
 self.triggers=0;self.unavailable=0;self.lastCondition=nil
 self.queue={};self.pending=nil;self.testConfig=nil;self.lastQueued={}
 self.status=self.active and "READY" or "DISABLED_OR_UNAVAILABLE"
end
function A:Stop()
 self.active=false;self.queue={};self.pending=nil;self.testConfig=nil
 self.lastCondition=nil;self.status="STOPPED"
 if CC.CompanionFrame and CC.CompanionFrame.alert then CC.AlertEffects:Clear(CC.CompanionFrame.alert) end
end
function A:InvalidateUnit() end -- retained for older event dispatchers, never queries unit state
function A:QueueEvent(key)
 local cfg=CC.profile and CC.profile.alerts
 if not self.active or not cfg or not cfg.enabled or cfg[key]~=true then return false end
 if type(GetTime)~="function" then return false end
 local now=CC.Safety:Value(GetTime)
 if not CC.Safety:IsNumber(now) then return false end
 self.lastQueued=self.lastQueued or {}
 if self.lastQueued[key] and now-self.lastQueued[key]<.25 then return false end
 local queue=self.queue or {};self.queue=queue
 -- Throttle duplicate event bursts but preserve distinct nearby events.
 for _,entry in ipairs(queue) do
  if entry.key==key and now-entry.at<.25 then return false end
 end
 if #queue>=8 then table.remove(queue,1) end
 self.lastQueued[key]=now
 queue[#queue+1]={key=key,at=now,expires=now+math.max(3,(cfg.duration or .75)*4)}
 self.pending=queue[1];self.status="EVENT_QUEUED"
 return true
end
function A:EffectConfig()
 if self.testConfig and CC.CompanionFrame and CC.CompanionFrame.alert.active then return self.testConfig end
 self.testConfig=nil;return CC.profile.alerts
end
function A:LiveTest()
 if not CC.state.running or not CC.CompanionFrame or not CC.CompanionFrame.alert then
  return false,"Cursor Companion is not running. Enable it in Settings first."
 end
 if CC.Safety:InCombat() then return false,"Use /cc alerttest outside combat." end
 self.testConfig=CC:Copy(CC.profile.alerts);self.testConfig.enabled=true
 CC.AlertEffects:Fire(CC.CompanionFrame.alert,"preview",self.testConfig)
 self.liveTests=self.liveTests+1;self.status="LIVE_TEST"
 return true
end
function A:Tick(dt,visible)
 if not self.active or not CC.profile.alerts.enabled then
  self.status=self.testConfig and "LIVE_TEST" or "DISABLED_OR_UNAVAILABLE"
  return
 end
 local now=CC.Safety:Value(GetTime)
 if not CC.Safety:IsNumber(now) then self.status="CLOCK_UNAVAILABLE";return end
 local queue=self.queue or {}
 while #queue>0 and now>queue[1].expires do table.remove(queue,1) end
 self.pending=queue[1]
 if not self.pending then self.status="READY";return end
 if not visible then self.status="WAITING_VISIBILITY";return end
 if CC.CompanionFrame and CC.CompanionFrame.alert and CC.CompanionFrame.alert.active then self.status="PLAYING_PREVIOUS_EVENT";return end
 local pending=table.remove(queue,1)
 self.pending=queue[1];self.testConfig=nil
 CC.AlertEffects:Fire(CC.CompanionFrame.alert,pending.key,CC.profile.alerts)
 self.triggers=self.triggers+1;self.lastCondition=pending.key;self.status="EVENT_ALERT"
end
