local _,CC=...
-- One owner for the independent outer navigation layer. Neither provider
-- changes the other provider's preferences or Blizzard's quest tracking.
CC.Navigation={off={status="OFF",kind="None"}}
local N=CC.Navigation
function N:Mode(profile)
 local p=profile or CC.profile
 if not p or not p.enabled or not p.compass or not p.compass.enabled then return "None" end
 if p.compass.mode=="Beacon" then return "Beacon" end
 if p.compass.mode=="Quest" then return "Quest" end
 return "None"
end
function N:Provider()
 local mode=self:Mode()
 if mode~="None" and CC.Wayfinder and CC.Wayfinder:IsManaged() then return CC.Wayfinder end
 return mode=="Beacon" and CC.Beacon or mode=="Quest" and CC.QuestCompass or nil
end
function N:Tick(dt)
 if CC.Wayfinder then CC.Wayfinder:Sync(dt) end
 local mode=self:Mode()
 local shared=CC.Wayfinder and CC.Wayfinder:IsManaged() or false
 if mode~=self.mode or shared~=self.sharedOwner then
  if CC.QuestCompass then CC.QuestCompass:Reset("OFF") end
  if CC.Beacon then CC.Beacon:Reset("OFF") end
  self.mode=mode;self.sharedOwner=shared
 end
 local provider=self:Provider()
 if provider then provider:Tick(dt) end
 if CC.Wayfinder and provider~=CC.Wayfinder then CC.Wayfinder:Release() end
end
function N:Get()
 local provider=self:Provider()
 return provider and provider:Get() or self.off
end
function N:Reset(reason)
 if CC.Wayfinder then CC.Wayfinder:Reset(reason) end
 if CC.QuestCompass then CC.QuestCompass:Reset(reason) end
 if CC.Beacon then CC.Beacon:Reset(reason) end
end
function N:Invalidate(reason)
 if CC.Wayfinder then CC.Wayfinder.dirty=true end
 if CC.QuestCompass then CC.QuestCompass:Invalidate(reason) end
 if CC.Beacon then
  if reason=="PROFILE_CHANGED" then CC.Beacon:OnProfileChanged()
  elseif not reason or reason=="COMBAT_CHANGED" or reason=="PLAYER_ENTERING_WORLD"
   or reason=="ZONE_CHANGED_NEW_AREA" or reason=="ZONE_CHANGED" or reason=="ZONE_CHANGED_INDOORS" then
   CC.Beacon:Invalidate(reason)
  end
 end
end
-- The persisted binding ID remains CURSORCOMPANION_QUESTNOTES so existing
-- player assignments survive. The action itself belongs to Navigation, not
-- the Quest Notes window. Always resolve the applied mode at invocation time.
function N:ModeLabel(mode)
 return mode=="Beacon" and "Beacon" or mode=="Quest" and "Quest Compass" or "Off"
end
function N:PendingShortcutChange(owner)
 local function pending(editor)
  if not (editor and editor.draft and editor.frame and editor.frame.IsShown and editor.frame:IsShown()) then return end
  local active,selected=self:Mode(),self:Mode(editor.draft)
  local save=editor==CC.Wizard and "Finish" or "Apply"
  if active~=selected then
   return "MODE",save.." the selected "..self:ModeLabel(selected).." mode before using Navigation. Active mode: "..self:ModeLabel(active).."."
  end
  local key=CC.Bindings and CC.Bindings:NotesCurrent()
  if editor.notesBindingDraft and editor.notesBindingDraft~=key then
   return "SHORTCUT",save.." the Navigation shortcut before using it."
  end
  local current=CC.profile and CC.profile.questNotes
  local draft=editor.draft.questNotes
  if active=="Quest" and current and draft and current.enabled~=draft.enabled then
   return "QUEST_NOTES",save.." the Quest Notes setting before using Navigation."
  end
 end
 if owner then return pending(owner) end
 local reason,message=pending(CC.Settings)
 if reason then return reason,message end
 return pending(CC.Wizard)
end
function N:Action()
 local mode=self:Mode();self.lastMode=mode;self.lastAction="NONE"
 local pending,message=self:PendingShortcutChange()
 if pending then self.lastResult="PENDING_"..pending;return false,message end
 if mode=="None" then
  self.lastResult="DISABLED"
  return false,"Choose Quest Compass or Beacon in Outside cursor settings and Apply first."
 end
 if not (CC.state and CC.state.inWorld) then
  self.lastResult="WORLD_TRANSITION";return false,"Navigation is unavailable during a world transition."
 end
 if mode=="Beacon" then
  self.lastAction="BEACON_PUBLISH"
  -- A Beacon failure must never fall through to a quest-window action.
  if not (CC.Beacon and type(CC.Beacon.Publish)=="function") then
   self.lastResult="BEACON_UNAVAILABLE";return false,"Beacon is unavailable. No waypoint was sent."
  end
  local called,ok,why=pcall(CC.Beacon.Publish,CC.Beacon)
  if not called then
   self.lastResult="BEACON_ERROR"
   if CC.Diagnostics then CC.Diagnostics:OptionalFault("NAVIGATION_BEACON_FAILED") end
   return false,"Beacon could not send. No quest window was opened. /cc export contains support information."
  end
  self.lastResult=ok==true and "SUCCESS" or "BEACON_NOT_SENT"
  return ok==true,why or (ok~=true and "Beacon was not sent. /cc beacon shows its status." or nil)
 end
 self.lastAction="QUEST_NOTES"
 if not (CC.profile.questNotes and CC.profile.questNotes.enabled) then
  self.lastResult="QUEST_NOTES_DISABLED"
  return false,"Enable Quest Notes in Outside cursor settings and Apply to use this shortcut in Quest Compass mode."
 end
 if CC.Safety:InCombat() then
  self.lastResult="QUEST_NOTES_COMBAT";return false,"Quest Notes is available outside combat. Beacon transmission uses Beacon mode."
 end
 if not (CC.QuestNotes and type(CC.QuestNotes.Toggle)=="function") then
  self.lastResult="QUEST_NOTES_UNAVAILABLE";return false,"Quest Notes is unavailable."
 end
 local called,ok,why=pcall(CC.QuestNotes.Toggle,CC.QuestNotes)
 if not called then
  self.lastResult="QUEST_NOTES_ERROR"
  if CC.Diagnostics then CC.Diagnostics:OptionalFault("NAVIGATION_NOTES_FAILED") end
  return false,"Quest Notes could not open. /cc export contains support information."
 end
 self.lastResult=ok==false and "QUEST_NOTES_UNAVAILABLE" or "SUCCESS"
 return ok~=false,why
end
function N:ShortcutSummary()
 local key=CC.Bindings and CC.Bindings:NotesCurrent()
 return "Navigation shortcut="..(CC.Bindings and CC.Bindings:Label(key) or "Not assigned")
  .." | mode="..self:ModeLabel(self:Mode()).." | last="..(self.lastAction or "NOT_RUN")
  .." | result="..(self.lastResult or "NOT_RUN")
end
function CursorCompanion_NavigationShortcut(keyState)
 if keyState=="down" then return end
 if CC.Bindings and CC.Bindings:SuppressInvocation() then return end
 local _,message=N:Action()
 if message then CC:Print(message) end
end
-- Compatibility entry point for saved macros/older bindings; never directly
-- opens Quest Notes. Bindings.xml now calls the named Navigation dispatcher.
function CursorCompanion_ToggleQuestNotes(keyState)
 return CursorCompanion_NavigationShortcut(keyState)
end
function N:Summary()
 if CC.Wayfinder and CC.Wayfinder:IsManaged() then return CC.Wayfinder:Summary() end
 if self:Mode()=="Beacon" then return CC.Beacon:Summary() end
 if self:Mode()=="Quest" then return CC.QuestNavigation:Summary() end
 return "Navigation=OFF"
end
