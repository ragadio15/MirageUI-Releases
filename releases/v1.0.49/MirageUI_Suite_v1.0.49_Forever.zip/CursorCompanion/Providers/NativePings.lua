local _,CC=...
-- Public, read-only native ping ingestion. No C_PingSecure calls, replacement
-- callbacks, restricted pin-event registrations, screen-to-world inference, or
-- substitution of the SENDER's position. Only public chat/error/world events
-- are subscribed. pcall is not permission to probe a restricted native event.
-- CHAT_MSG_PING documents sender/text, NOT terrain coordinates. Position is used
-- only when an explicit native map hyperlink or an exact target identity exists.
CC.NativePings={log={},seen={},seenOrder={},sequence=0,elapsed=0,status="NOT_INITIALIZED",capacity=64,targetPrefix="CCTARGET10",targetSeq=0,targetHistory={},targetTimes={},pendingMenu=nil}
local N,S=CC.NativePings,CC.Safety
local labels={marker="Target marker",beacon="Beacon waypoint",attack="Attack ping",assist="Assist ping",warning="Warning ping",onmyway="On My Way ping",contextual="Contextual ping"}
local function call(fn,...)
 if type(fn)~="function" then return nil end
 local ok,a,b,c,d=pcall(fn,...);if not ok then return nil end
 if not S:IsReadable(a) then a=nil end;if not S:IsReadable(b) then b=nil end
 if not S:IsReadable(c) then c=nil end;if not S:IsReadable(d) then d=nil end
 return a,b,c,d
end
local function field(t,k) return S:Field(t,k) end
local function options() return CC.profile and CC.profile.beacon or {} end
local function number(n) return S:IsNumber(n) end
local function point(map,x,y)
 return number(map) and map%1==0 and map>0 and map<=10000000 and number(x) and number(y) and x>=0 and x<=1 and y>=0 and y<=1
end
function N:Color(kind,profile)
 local cfg=profile and profile.beacon or options()
 if cfg.typeColors==false then return nil end
 local colors=cfg.colors or {};return colors[kind or "beacon"] or colors.contextual
end
function N:Record(record,result)
 local item={kind=record.transmissionType or "beacon",sender=record.sender,stamp=record.stamp,id=record.id,
  source=record.source or "GROUP_BEACON",result=result or "ACCEPTED",mapID=record.mapID,mapX=record.mapX,mapY=record.mapY,
  targetGUID=record.targetGUID,location=record.location or "MAP_SNAPSHOT"}
 table.insert(self.log,1,item);while #self.log>self.capacity do table.remove(self.log) end
 return item
end
function N:ClearHistory() self.log={} end
function N:ClearGroup()
 self.log={};self.seen={};self.seenOrder={};self.restricted=0;self.targetHistory={};self.targetTimes={};self.pendingMenu=nil;self.lastWire=nil
end
-- Explicit allowlist: do not add events from the SecureOnly ping system here.
-- F9 subscribed to two restricted pin lifecycle events during startup, even
-- with Beacon off. A native denial can signal an event without raising Lua.
local publicEvents={"CHAT_MSG_PING","PING_SYSTEM_ERROR","PLAYER_LEAVING_WORLD","RAID_TARGET_UPDATE"}
N.eventPolicy="PUBLIC_EVENTS_ONLY"
function N:Initialize()
 self:RegisterTargetChannel()
 if self.frame then return self.registered and self.registered.CHAT_MSG_PING==true end
 self.frame=CreateFrame("Frame");self.registered={};self.registrationReasons={}
 -- Install the listener first, then subscribe only to supported public events.
 self.frame:SetScript("OnEvent",function(_,event,...)
  local ok=pcall(self.OnEvent,self,event,...)
  if not ok then self.status="EVENT_ERROR";if CC.Diagnostics then CC.Diagnostics:OptionalFault("NATIVE_PING_EVENT_ERROR") end end
 end)
 for _,event in ipairs(publicEvents) do
  local ok,result=pcall(self.frame.RegisterEvent,self.frame,event)
  local registered=ok and result~=false
  if registered and type(self.frame.IsEventRegistered)=="function" then
   local checked,active=pcall(self.frame.IsEventRegistered,self.frame,event)
   registered=checked and S:IsReadable(active) and active==true
  end
  self.registered[event]=registered==true
  self.registrationReasons[event]=registered and "REGISTERED" or (ok and "NOT_REGISTERED" or "API_ERROR")
 end
 self.status=self.registered.CHAT_MSG_PING and "LISTENING" or "EVENT_UNAVAILABLE"
 return self.registered.CHAT_MSG_PING
end
function N:RegisteredEvents()
 local result={}
 for _,event in ipairs(publicEvents) do
  if self.registered and self.registered[event] then result[#result+1]=event end
 end
 return #result>0 and table.concat(result,",") or "NONE"
end
function N:Kind(text)
 if not S:IsText(text) then return "contextual" end
 local lower=text:lower()
 -- Texture kit identifiers are language-independent. Localized native names
 -- are a fallback, never guessed from a numeric enum value.
 for _,pair in ipairs({{"attack","Attack"},{"assist","Assist"},{"warning","Warning"},{"onmyway","OnMyWay"}}) do
  local key,native=pair[1],pair[2]
  local enum=Enum and Enum.PingSubjectType and Enum.PingSubjectType[native]
  local kit=number(enum) and C_Ping and call(C_Ping.GetTextureKitForType,enum)
  if S:IsText(kit) and kit~="" then
   for atlas in lower:gmatch("|a:([^:|]+)") do if atlas:find("ping",1,true) and atlas:find(kit:lower(),1,true) then return key end end
  end
  local globalName=key=="onmyway" and "PING_TYPE_ON_MY_WAY" or "PING_TYPE_"..key:upper()
  local localized=_G[globalName]
  if S:IsText(localized) and localized~="" and lower:find(localized:lower(),1,true) then return key end
  -- Known native icon tokens only, not incidental player names/message words.
  for atlas in lower:gmatch("|a:([^:|]+)") do
   local condensed=atlas:gsub("[_%-]","")
   if condensed:find("ping",1,true) and condensed:find(key,1,true) then return key end
  end
 end
 return "contextual"
end
function N:ExplicitLocation(text)
 -- Use Blizzard's own hyperlink decoder; never guess units or scale factors.
 if not S:IsText(text) or not C_Map or type(C_Map.GetUserWaypointFromHyperlink)~="function" then return nil end
 local chosenMap,chosenX,chosenY
 for link in text:gmatch("(|Hworldmap:[^|]+|h.-|h)") do
  local record=call(C_Map.GetUserWaypointFromHyperlink,link)
  local map=field(record,"uiMapID");local pos=field(record,"position")
  local x,y=field(pos,"x"),field(pos,"y")
  if pos and type(field(pos,"GetXY"))=="function" then x,y=call(pos.GetXY,pos) end
  if point(map,x,y) then
   if chosenMap and (chosenMap~=map or chosenX~=x or chosenY~=y) then return nil end
   chosenMap,chosenX,chosenY=map,x,y
  end
 end
 return chosenMap,chosenX,chosenY
end
function N:ExplicitTarget(text,senderGUID)
 if not S:IsText(text) then return nil end
 local found
 local function accept(guid)
  if found and found~=guid then return false end;found=guid;return true
 end
 for guid in text:gmatch("|Hunit:([^:|]+)") do
  if #guid<=100 and guid:match("^[%a]+%-%x[%w%-]*$") and not accept(guid) then return nil end
 end
 if found then return found end
 -- A player hyperlink naming the author can be attribution, not a destination.
 -- Without an explicit unit hyperlink, never turn it into self-navigation.
 for name in text:gmatch("|Hplayer:([^:|]+)") do
  local normalized=CC.Beacon:NormalizeName(name)
  local member=normalized and CC.Beacon.roster[normalized]
  if member and S:IsText(member.guid) and member.guid~=senderGUID and not accept(member.guid) then return nil end
 end
 return found
end
function N:ResolveUnit(guid)
 if not S:IsText(guid) then return nil end
 local token=CC.Subject and CC.Subject:SafeToken(call(UnitTokenFromGUID,guid))
 if token and call(UnitGUID,token)==guid then return token end
 local group=CC.Beacon.rosterByGUID and CC.Beacon.rosterByGUID[guid]
 if group and call(UnitGUID,group.unit)==guid then return group.unit end
 for _,unit in ipairs({"player","target","focus","mouseover","pet","targettarget"}) do if call(UnitGUID,unit)==guid then return unit end end
 for i=1,40 do local unit="nameplate"..i;if call(UnitGUID,unit)==guid then return unit end end
 for i=1,8 do local unit="boss"..i;if call(UnitGUID,unit)==guid then return unit end end
end
function N:UnitPosition(record)
 local unit=record.lastUnit
 if not unit or call(UnitGUID,unit)~=record.targetGUID then unit=self:ResolveUnit(record.targetGUID) end
 if not unit then record.lastUnit=nil;record.targetState="UNRESOLVED";return nil end
 record.lastUnit=unit
 if S:BoolCall(UnitIsDeadOrGhost,unit)==true then record.targetState="DEAD";return nil end
 if S:BoolCall(UnitIsVisible,unit)==false or S:BoolCall(UnitIsConnected,unit)==false then record.targetState="UNAVAILABLE";return nil end
 if type(UnitPhaseReason)=="function" then
  local okay,phase=pcall(UnitPhaseReason,unit)
  if not okay or not S:IsReadable(phase) then record.targetState="RESTRICTED_OR_UNAVAILABLE";return nil end
  if phase~=nil then record.targetState="PHASE";return nil end
 end
 local x,y,_,world=call(UnitPosition,unit)
 if number(x) and number(y) and number(world) then record.targetState="READABLE";return world,x,y,unit end
 record.targetState="RESTRICTED_OR_UNAVAILABLE"
end
function N:Accept(text,sender,lineID,senderGUID)
 local B=CC.Beacon
 if not B:Enabled() or options().nativePings==false or not (CC.state and CC.state.inWorld) then return false,"INACTIVE" end
 if not S:IsText(text) or #text>2048 then self.restricted=(self.restricted or 0)+1;self.status="DATA_UNAVAILABLE";return false,"UNREADABLE" end
 if not B:EnsureRoster() then return false,"NO_ROSTER" end
 local member=S:IsText(senderGUID) and B.rosterByGUID[senderGUID] or nil
 if not member and S:IsText(sender) then member=B.roster[B:NormalizeName(sender) or ""] end
 if not member then return false,"NOT_IN_GROUP" end
 if S:IsText(senderGUID) and member.guid and member.guid~=senderGUID then return false,"SENDER_MISMATCH" end
 local clock,now=B:Clock(),B:Now();if not clock or not now then return false,"NO_CLOCK" end
 local key=member.name..":"..(number(lineID) and lineID>0 and tostring(lineID) or text)
 local previous=self.seen[key]
 if previous and ((number(lineID) and lineID>0) or clock-previous<5) then return false,"DUPLICATE" end
 self.seen[key]=clock;self.seenOrder[#self.seenOrder+1]={key=key,at=clock}
 while #self.seenOrder>128 do local old=table.remove(self.seenOrder,1);if self.seen[old.key]==old.at then self.seen[old.key]=nil end end
 self.sequence=self.sequence+1
 local kind=self:Kind(text)
 local record={nativePing=true,source="BLIZZARD_PING",transmissionType=kind,name=labels[kind],sender=member.name,guid=member.guid,
  stamp=now,receivedAt=clock,id="native:"..member.name..":"..self.sequence,location="UNAVAILABLE"}
 local pending=self:MatchingMenuPing(member,kind,clock)
 if not pending and member.name==B.localName and self.pendingMenu and self.pendingMenu.kind=="ping" then
  self.pendingMenu=nil;self.menuStatus="UNRELATED_NATIVE_PING"
 end
 local explicitGUID=self:ExplicitTarget(text,member.guid)
 if pending and explicitGUID and explicitGUID~=pending.guid then pending=nil;self.pendingMenu=nil end
 if pending then
  record.targetGUID=pending.guid
  if pending.pingType~="contextual" then record.transmissionType=pending.pingType;record.name=labels[pending.pingType] end
  self.pendingMenu=nil;self.menuStatus="PING_CONFIRMED"
 end
 record.mapID,record.mapX,record.mapY=self:ExplicitLocation(text)
 if record.mapID then record.location="NATIVE_MAP_LINK" else
  record.targetGUID=record.targetGUID or explicitGUID
  if record.targetGUID then
   record.world,record.worldX,record.worldY=self:UnitPosition(record)
   record.location=record.world and "UNIT_SNAPSHOT" or "UNIT_UNAVAILABLE"
  end
 end
 local accepted,why=self:AdoptSignal(record,member,"BLIZZARD_PING")
 if accepted and pending and record.targetGUID then self:ShareTarget(record) end
 return accepted,why
end
function N:OnEvent(event,...)
 if event=="CHAT_MSG_PING" then
  local text,sender=...;local lineID=select(11,...);local guid=select(12,...)
  return self:Accept(text,sender,lineID,guid)
 elseif event=="PING_SYSTEM_ERROR" then
  self.pendingMenu=nil;self.menuStatus="PING_REJECTED"
  local message=...;if S:IsText(message) then self.lastError=message:gsub("[|%c]",""):sub(1,160) end
 elseif event=="RAID_TARGET_UPDATE" then self:ConfirmMenuMarker()
 elseif event=="PLAYER_LEAVING_WORLD" then self.pendingMenu=nil;self.status="WORLD_TRANSITION"
 else return false,"UNSUPPORTED_PUBLIC_EVENT" end
end
function N:Tick(record,B)
 local now=B:Now();B.age=now and math.max(0,now-record.stamp) or nil
 B.sender=record.sender;B.name=record.name;B.key=record.id;B.selection=record;B.source=record.source;B.transmissionType=record.transmissionType;B.stale=false
 B.zone=nil
 local life=options().pingLifetime or 30
 if B.age and B.age>=life and not B.held then B:Clear("PING_EXPIRED");return true end
 if record.mapID then return false end -- validated native map hyperlink -> shared map navigation
 if not record.targetGUID then B.arrived=false;B.status="PING_LOCATION_UNAVAILABLE";return true end
 local world,x,y=record.world,record.worldX,record.worldY
 if options().trackPingUnits~=false then
  world,x,y=self:UnitPosition(record)
  -- On data loss the arrow is removed, not stuck on an old moving target.
 end
 local px,py,_,pw=call(UnitPosition,"player")
 if not number(world) or not number(x) or not number(y) or not number(px) or not number(py) or not number(pw) then B.arrived=false;B.status=record.targetState=="DEAD" and "SIGNAL_TARGET_DEAD" or record.targetState=="PHASE" and "SIGNAL_TARGET_PHASE" or "PING_TARGET_UNAVAILABLE";return true end
 if world~=pw then B.arrived=false;B.status="OTHER_WORLD";return true end
 local distance=math.sqrt((x-px)^2+(y-py)^2)
 if not number(distance) then B.status="NO_POSITION";return true end
 B.distance=distance;local cfg=CC.profile.compass;local radius=cfg.arrivalRadius or 8
 B.arrived=cfg.arrivalCue==true and distance<=(B.arrived and radius+4 or radius)
 if B.arrived then B.status="NEAR_DESTINATION";return true end
 local facing=call(GetPlayerFacing);if not number(facing) then B.status="NO_FACING";return true end
 B.angle=CC.QuestNavigation:RelativeAngle(px,py,x,y,facing);B.status=number(B.angle) and "GUIDING" or "DESTINATION_REACHED"
 B.confidence=options().trackPingUnits~=false and "NATIVE_UNIT_POSITION" or "UNIT_SNAPSHOT"
 return true
end
-- F10 menu target metadata: an optional hidden, bounded identity supplement.
-- No coordinates are invented, no privileged events are registered, and no
-- protected action executes from a timer or event handler.
local function targetGUID(value)
 return S:IsText(value) and #value>=5 and #value<=100 and value:match("^[%a]+%-%x[%w%-]*$") and value or nil
end
local function transportSuccess(kind,value)
 if not S:IsReadable(value) then return false end
 if value==true then return true end
 local code=Enum and Enum[kind] and Enum[kind].Success
 return number(code) and number(value) and code==value
end
function N:RegisterTargetChannel()
 if self.targetRegistered then return true end
 if not C_ChatInfo or type(C_ChatInfo.RegisterAddonMessagePrefix)~="function" then return false end
 local a,b=call(C_ChatInfo.RegisterAddonMessagePrefix,self.targetPrefix)
 self.targetRegistered=S:BoolCall(C_ChatInfo.IsAddonMessagePrefixRegistered,self.targetPrefix)==true
  or transportSuccess("RegisterAddonMessagePrefixResult",b~=nil and b or a)
 return self.targetRegistered==true
end
function N:BeginMenuSignal(item,unit)
 self.pendingMenu=nil
 if not item or not item.signal or unit=="cursor" or not S:IsText(unit) then return end
 local B=CC.Beacon
 if not B:Enabled() then self.menuStatus="NATIVE_ACTION_ONLY";return end
 local guid=targetGUID(call(UnitGUID,unit));local clock=B:Clock()
 if not guid or not clock then self.menuStatus="TARGET_ID_UNAVAILABLE";return end
 self.pendingMenu={guid=guid,unit=unit,at=clock,kind=item.kind,pingType=item.pingType,marker=item.marker}
 self.menuStatus=item.kind=="marker" and "MARKER_REQUESTED" or "PING_REQUESTED"
 local pending=self.pendingMenu
 if C_Timer and C_Timer.After then C_Timer.After(2.1,function()
  if self.pendingMenu==pending then self.pendingMenu=nil;self.menuStatus="NATIVE_CONFIRMATION_UNAVAILABLE" end
 end) end
end
function N:MatchingMenuPing(member,kind,clock)
 local p=self.pendingMenu
 if not p or p.kind~="ping" or member.name~=CC.Beacon.localName or clock-p.at<0 or clock-p.at>2 then return nil end
 if p.pingType~="contextual" and p.pingType~=kind then return nil end
 return p
end
function N:FinishMenuSignal(item)
 if item and item.kind=="marker" then self:ConfirmMenuMarker() end
end
function N:ConfirmMenuMarker()
 local p=self.pendingMenu;local B=CC.Beacon;local clock=B:Clock()
 if not p or p.kind~="marker" or not clock then return false end
 if clock-p.at>2 or clock<p.at then self.pendingMenu=nil;self.menuStatus="MARKER_CONFIRMATION_EXPIRED";return false end
 local unit=call(UnitGUID,p.unit)==p.guid and p.unit or self:ResolveUnit(p.guid)
 if not unit or type(GetRaidTargetIndex)~="function" then return false end
 local okay,index=pcall(GetRaidTargetIndex,unit)
 if not okay or not S:IsReadable(index) then return false end
 if p.marker==0 then if index~=nil and index~=0 then return false end
 elseif not number(index) or index~=p.marker then return false end
 self.pendingMenu=nil;self.menuStatus="MARKER_CONFIRMED"
 if not B:Enabled() or not B:EnsureRoster() then return true end
 local member=B.roster[B.localName];local now=B:Now();if not member or not now then return true end
 self.sequence=self.sequence+1
 local label=CC.MenuModel and CC.MenuModel.markerLabels[tostring(p.marker)] or "Target"
 local record={nativePing=true,source="LOCAL_MARKER",transmissionType="marker",marker=p.marker,targetGUID=p.guid,
  name=label.." marker",sender=member.name,guid=member.guid,stamp=now,receivedAt=clock,
  id="marker:"..member.name..":"..self.sequence,location="UNIT_UNAVAILABLE"}
 record.world,record.worldX,record.worldY=self:UnitPosition(record)
 if record.world then record.location="UNIT_SNAPSHOT" end
 if p.marker==0 then
  if not B.held and B.active and B.active.transmissionType=="marker" and B.active.targetGUID==p.guid then
   B:Clear("TARGET_MARK_REMOVED");B:NotifySignal("local",nil,record,true)
  end
  self:Record(record,"MARKER_CLEARED");self:ShareTarget(record);return true
 end
 local accepted=self:AdoptSignal(record,member,"LOCAL_MARKER")
 if accepted then self:ShareTarget(record) end
 return true
end
function N:AdoptSignal(record,member,source)
 local B=CC.Beacon
 if B.held then self:Record(record,"HELD");return false,"HELD" end
 if not B:AcceptSender(member) then self:Record(record,"SENDER_FILTER");return false,"SENDER_FILTER" end
 local previous=B.active
 if source=="CC_TARGET_SIGNAL" and previous and record.stamp<previous.stamp then return false,"OLDER_THAN_ACTIVE" end
 local near=previous and previous.nativePing and previous.sender==record.sender and previous.transmissionType==record.transmissionType
  and math.abs((previous.receivedAt or 0)-(record.receivedAt or 0))<=2
 if near and source=="BLIZZARD_PING" and previous.source=="CC_TARGET_SIGNAL" and not previous.nativeConfirmed then
  if record.targetGUID and record.targetGUID~=previous.targetGUID then return false,"TARGET_CORRELATION_MISMATCH" end
  previous.nativeConfirmed=true;self.status="NATIVE_SIGNAL_CORRELATED";return false,"CORRELATED_NATIVE"
 end
 if near and source=="CC_TARGET_SIGNAL" and previous.source=="BLIZZARD_PING" and not previous.targetEnvelope then
  if previous.mapID or (previous.targetGUID and previous.targetGUID~=record.targetGUID) then return false,"TARGET_CORRELATION_MISMATCH" end
  local enriched=previous.targetGUID==nil
  previous.targetGUID=record.targetGUID;previous.targetEnvelope=true
  previous.world,previous.worldX,previous.worldY=self:UnitPosition(previous)
  previous.location=previous.world and "UNIT_SNAPSHOT" or "UNIT_UNAVAILABLE"
  B.confidence=previous.location;B:Invalidate("TARGET_ENRICHED")
  self:Record(previous,"TARGET_ENRICHED");self.status="TARGET_ENRICHED"
  if enriched then B:NotifySignal("enriched",previous,previous,true) end
  return true,"ENRICHED"
 end
 B.active=record;B.acknowledged={};B.ackCount=0;B.held=false;B.selection=record;B.key=record.id
 B.name=record.name;B.sender=record.sender;B.source=record.source;B.confidence=record.location;B.transmissionType=record.transmissionType
 B:Invalidate("NEW_BEACON");self:Record(record);self.status="RECEIVED"
 B:NotifySignal(member.name==B.localName and "local" or "received",previous,record)
 return true
end
function N:ShareTarget(record)
 local B=CC.Beacon
 if not B:Enabled() or options().shareMenuTargets==false or not targetGUID(record.targetGUID) then return false end
 if not self:RegisterTargetChannel() or not B:EnsureRoster() or record.sender~=B.localName then return false end
 local clock=B:Clock();local session=B:Session()
 if not clock or not session or (self.lastTargetSend and clock-self.lastTargetSend<.25) then return false end
 local kind=record.marker~=nil and "mark"..record.marker or record.transmissionType
 if not ({contextual=true,attack=true,assist=true,warning=true,onmyway=true,mark0=true,mark1=true,mark2=true,mark3=true,mark4=true,mark5=true,mark6=true,mark7=true,mark8=true})[kind] then return false end
 self.targetSeq=self.targetSeq+1
 local payload=table.concat({"1",record.stamp,session,self.targetSeq,kind,record.targetGUID},";")
 if #payload>240 then return false end
 self.lastTargetSend=clock
 local a,b=call(C_ChatInfo.SendAddonMessage,self.targetPrefix,payload,B.channel)
 local okay=transportSuccess("SendAddonMessageResult",b~=nil and b or a)
 self.targetSendStatus=okay and "SENT" or "SEND_UNCONFIRMED"
 if okay then self.targetSent=(self.targetSent or 0)+1;B:NotifySignal("sent",nil,record) end
 return okay
end
function N:ReceiveTarget(payload,channel,sender)
 local B=CC.Beacon
 if not B:Enabled() or options().receiveMenuTargets==false or not (CC.state and CC.state.inWorld) then return false,"INACTIVE" end
 if not S:IsText(payload) or #payload>240 or not S:IsText(channel) or not B:EnsureRoster() or channel~=B.channel then return false,"CHANNEL_OR_PAYLOAD" end
 local full=B:NormalizeName(sender);local member=full and B.roster[full]
 if not member then return false,"NOT_IN_GROUP" end
 if full==B.localName then return false,"OWN_ECHO" end
 local stamp,session,seq,kind,guid=payload:match("^1;(%d+);([%x%-]+);(%d+);([%w]+);([^;]+)$")
 stamp,seq=tonumber(stamp),tonumber(seq)
 local marker=kind and tonumber(kind:match("^mark([0-8])$")) or nil
 local types={contextual=true,attack=true,assist=true,warning=true,onmyway=true}
 if not number(stamp) or stamp%1~=0 or stamp<1 or stamp>4102444800 or not number(seq) or seq%1~=0 or seq<1 or seq>2147483647
  or not session or #session<3 or #session>32 or (marker==nil and not types[kind]) or not targetGUID(guid) then return false,"MALFORMED_TARGET" end
 local now,clock=B:Now(),B:Clock()
 if not now or not clock or stamp>now+2 or now-stamp>10 then return false,"STALE_TARGET" end
 if B.held then return false,"HELD" end
 if not B:AcceptSender(member) then return false,"SENDER_FILTER" end
 if B.active and stamp<B.active.stamp then return false,"OLDER_THAN_ACTIVE" end
 -- Tables are bounded by the CURRENT roster, not arbitrary packet identities.
 for name in pairs(self.targetHistory) do if not B.roster[name] then self.targetHistory[name]=nil;self.targetTimes[name]=nil end end
 local old=self.targetHistory[full]
 if old and (stamp<old.stamp or (old.session==session and seq<=old.seq)) then return false,"DUPLICATE_TARGET" end
 local last=self.targetTimes[full];if last and clock-last<.2 then return false,"TARGET_RATE_LIMIT" end
 self.targetHistory[full]={stamp=stamp,session=session,seq=seq};self.targetTimes[full]=clock
 self.targetReceived=(self.targetReceived or 0)+1
 local record={nativePing=true,source="CC_TARGET_SIGNAL",transmissionType=marker~=nil and "marker" or kind,
  marker=marker,targetGUID=guid,sender=full,guid=member.guid,stamp=stamp,receivedAt=clock,
  id="target:"..full..":"..session..":"..seq,location="UNIT_UNAVAILABLE"}
 record.name=marker~=nil and ((CC.MenuModel and CC.MenuModel.markerLabels[tostring(marker)] or "Target").." marker") or labels[kind]
 if marker==0 then
  if B.active and B.active.transmissionType=="marker" and B.active.targetGUID==guid then B:Clear("TARGET_MARK_REMOVED");B:NotifySignal("enriched",nil,record,true) end
  self:Record(record,"MARKER_CLEARED");return true
 end
 record.world,record.worldX,record.worldY=self:UnitPosition(record)
 if record.world then record.location="UNIT_SNAPSHOT" end
 return self:AdoptSignal(record,member,"CC_TARGET_SIGNAL")
end

function N:Summary()
 return "NativePings="..self.status.." | events="..self.sequence.." | history="..#self.log.." | restricted="..(self.restricted or 0).." | precise terrain API=not exposed"
end
function N:HistoryText()
 local lines={"Recent group signals (session only; newest first):"}
 for i,item in ipairs(self.log) do
  lines[#lines+1]=i..". "..(labels[item.kind] or item.kind).." / "..(item.sender or "Unknown").." / "..item.location.." / "..item.result
 end
 if #self.log==0 then lines[#lines+1]="No readable signals recorded in this group." end
 return table.concat(lines,"\n")
end
