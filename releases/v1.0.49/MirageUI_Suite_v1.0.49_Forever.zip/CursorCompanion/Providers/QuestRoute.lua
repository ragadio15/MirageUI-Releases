local _,CC=...
-- Experimental F7 planner. Input is the sanitized navigation snapshot, never
-- a spawn database. One known location per quest; no terrain/pathfinding claims.
-- The planner is bounded (64 candidates, 12 stops) and never mutates game state.
CC.QuestRoute={status="OFF",plan={},groups={},excluded={},deferred={},deferOrder={},builds=0,cacheHits=0,generation=0}
local R=CC.QuestRoute
local function pref() return CC.profile and CC.profile.compass or {} end
local function number(n) return CC.Safety:IsNumber(n) end
local function distance(a,b)
 local d=(a.x-b.x)^2+(a.y-b.y)^2
 -- Both endpoints are already validated plain internal numbers. Avoid
 -- re-running secret-value API probes for each derived pairwise metric.
 return d==d and d>=0 and d<math.huge and math.sqrt(d) or math.huge
end
local function signature(row) return (row.key or tostring(row.id))..":"..(row.stage or "UNKNOWN") end
local function ordered(a,b)
 if a.approxDistance~=b.approxDistance then return a.approxDistance<b.approxDistance end
 return a.id<b.id
end
function R:Enabled() return pref().routeMode and pref().routeMode~="Off" end
function R:ClearAnnotations(rows)
 for _,row in ipairs(rows or {}) do
  row.routeIndex=nil;row.clusterID=nil;row.clusterSize=nil;row.routeReason=nil;row.routeDeferred=nil
 end
end
function R:Suspend(reason)
 self:ClearAnnotations(CC.QuestNavigation and CC.QuestNavigation.rows)
 self.status=reason or "UNAVAILABLE";self.plan={};self.groups={};self.excluded={};self.byID={}
 self.totalDistance=0;self.candidateCount=0;self.requested=nil;self.focusUnavailable=false
 self.fingerprint=nil;self.inputRevision=nil
 -- Combat temporarily suspends presentation, not the current route intention.
 if reason~="RESTRICTED" then self.head=nil end
end
function R:Reset(clearDeferred)
 self.head=nil;self.fingerprint=nil;self.inputRevision=nil;self.generation=self.generation+1
 if clearDeferred then self.deferred={};self.deferOrder={} end
end
function R:OnQuestRemoved(id)
 self.deferred[id]=nil
 if self.head and self.head.id==id then self.head=nil end
 self.inputRevision=nil
end
function R:Defer(id)
 if CC.Safety:InCombat() then return false,"Route changes are available outside combat." end
 if not self:Enabled() then return false,"Enable route suggestions first." end
 if not number(id) or id<1 or id%1~=0 then return false,"No route destination to defer." end
 local nav=CC.QuestNavigation
 if nav:PinnedID()==id or nav:SupertrackedID()==id then
  return false,"Unpin or change Blizzard's focused quest before deferring it. Your explicit focus takes priority."
 end
 local row=nav.byID[id]
 if not row or not self.byID or not self.byID[id] then return false,"This destination is no longer in the current route." end
 self.deferred[id]=signature(row)
 for i=#self.deferOrder,1,-1 do if self.deferOrder[i]==id then table.remove(self.deferOrder,i) end end
 self.deferOrder[#self.deferOrder+1]=id
 while #self.deferOrder>64 do self.deferred[table.remove(self.deferOrder,1)]=nil end
 if self.head and self.head.id==id then self.head=nil end
 self.generation=self.generation+1;self.inputRevision=nil;nav:Invalidate("ROUTE_DEFERRED")
 return true,"Destination deferred for this session, not completed. A changed quest stage/location or Reset restores it."
end
function R:Eligible(row,player)
 if not number(row.id) or row.id<1 or row.id%1~=0 then return false,"INVALID_ID" end
 if row.stage=="FAILED" then return false,"FAILED" end
 if row.locationState~="LOCATED" then return false,row.locationState or "NO_LOCATION" end
 if not (number(row.x) and number(row.y) and number(row.mapID) and number(row.continent)) then return false,"NO_LOCATION" end
 if row.mapID~=player.mapID or row.continent~=player.continent then return false,"OTHER_MAP_OR_FLOOR" end
 if row.routeMapUsable~=true then return false,"UNVERIFIED_MAP_GEOMETRY" end
 if row.stage~="OBJECTIVES" and row.stage~="READY_FOR_TURN_IN" then return false,"UNKNOWN_STAGE" end
 if not number(row.approxDistance) or row.approxDistance>(pref().routeRange or 2000) then return false,"OUTSIDE_RADIUS" end
 local skipped=self.deferred[row.id]
 if skipped and skipped~=signature(row) then self.deferred[row.id]=nil;skipped=nil end
 if skipped then return false,"DEFERRED" end
 return true
end
-- Complete-link grouping, not chained proximity: every pair in a cluster is
-- within the configured span. Different maps/floors never share a cluster.
function R:Cluster(candidates,radius)
 local list={};for _,row in ipairs(candidates) do list[#list+1]=row end
 table.sort(list,function(a,b)return a.id<b.id end)
 local groups={}
 for _,row in ipairs(list) do
  local best,bestDistance
  for _,group in ipairs(groups) do
   local fits=row.mapID==group.mapID and row.continent==group.continent
   local nearest=math.huge
   if fits then for _,member in ipairs(group.members) do
    local d=distance(row,member);nearest=math.min(nearest,d)
    if d>radius then fits=false;break end
   end end
   if fits and (not best or nearest<bestDistance) then best,bestDistance=group,nearest end
  end
  if not best then
   best={id=row.id,mapID=row.mapID,continent=row.continent,members={}}
   groups[#groups+1]=best
  end
  best.members[#best.members+1]=row
 end
 return groups
end
-- Ranking factors are explicit heuristics, not inferred completion, danger,
-- walkability, time-to-complete, experience or reward estimates.
function R:Score(row,group,from,groups,used,distances,neighbors)
 local p=pref();local d=distance(row,from);local policy=p.routePolicy or "Balanced"
 if policy=="Short travel" then return d end
 local size=math.min(#group.members-1,3)
 local score=d/(1+.15*size)
 if row.confidence~="BLIZZARD_WAYPOINT" then score=score*1.25 end
 if row.stage=="READY_FOR_TURN_IN" then score=score*(policy=="Nearby turn-ins" and .65 or .88) end
 if number(row.progress) then score=score*(1-.10*math.max(0,math.min(1,row.progress))) end
 -- A small one-stop lookahead discourages isolated detours. Its contribution
 -- is capped so a distant cluster cannot dominate a genuinely nearby task.
 local nextDistance
 if neighbors then
  for _,id in ipairs(neighbors[row.id]) do
   if not used[id] then nextDistance=distances[row.id][id];break end
  end
 else
  -- Pure helper path for tests or callers without a per-build distance cache.
  for _,other in ipairs(groups) do if other~=group then
   for _,candidate in ipairs(other.members) do if not used[candidate.id] then
    local value=distance(row,candidate)
    nextDistance=not nextDistance and value or math.min(value,nextDistance)
   end end
  end end
 end
 return score+.12*math.min(nextDistance or 0,p.clusterRadius or 60)
end
function R:Reason(row,group,fixed)
 local parts={}
 if fixed then parts[#parts+1]=fixed
 else parts[#parts+1]=(pref().routePolicy=="Short travel" and "short travel" or "balanced travel") end
 if #group.members>1 then parts[#parts+1]=#group.members.." nearby quests" end
 if row.stage=="READY_FOR_TURN_IN" then parts[#parts+1]="ready for turn-in" end
 if number(row.progress) and row.stage=="OBJECTIVES" then
  parts[#parts+1]=math.floor(row.progress*100+.5).."% readable objective progress"
 end
 parts[#parts+1]=row.confidence=="BLIZZARD_WAYPOINT" and "native waypoint" or "approximate map area"
 return table.concat(parts," / ")
end
function R:ApplyAnnotations(rows)
 self:ClearAnnotations(rows)
 for _,row in ipairs(rows) do
  local entry=self.byID and self.byID[row.id]
  if entry then
   -- Names can arrive after coordinates without a structural route change.
   -- Refresh display data on cache hits rather than preserving a placeholder.
   entry.name=row.name
   row.routeIndex=entry.index;row.clusterID=entry.clusterID;row.clusterSize=entry.clusterSize;row.routeReason=entry.reason
  end
  row.routeDeferred=self.excluded[row.id]=="DEFERRED" or nil
 end
end
function R:Update(rows,player,requested,now,revision)
 if CC.Safety:InCombat() then self:Suspend("RESTRICTED");return end
 if not self:Enabled() then self:Suspend("OFF");return end
 local p=pref()
 local options=table.concat({p.routeMode,p.routePolicy or "Balanced",p.clusterRadius or 60,p.routeRange or 2000,p.routeStops or 8,requested or 0,self.generation},":")
 if self.options~=options then self.head=nil end
 local moved=not self.origin or distance(self.origin,player)>=25
 if self.inputRevision==revision and self.options==options and not moved then
  self.cacheHits=self.cacheHits+1;return
 end
 local candidates,excluded,seen={},{},{}
 for _,row in ipairs(rows) do
  local ok,why=self:Eligible(row,player)
  if ok and not seen[row.id] then candidates[#candidates+1]=row;seen[row.id]=true
  elseif number(row.id) then excluded[row.id]=why or "DUPLICATE" end
 end
 table.sort(candidates,ordered)
 -- Reserve an eligible explicit focus even when it falls outside the nearest
 -- 64. It still must satisfy map, geometry, stage and planning-radius checks.
 if #candidates>64 and requested then
  for i=65,#candidates do if candidates[i].id==requested then
   candidates[64],candidates[i]=candidates[i],candidates[64];break
  end end
 end
 -- The nearest 64 eligible records (including reserved focus) bound the work.
 while #candidates>64 do excluded[candidates[#candidates].id]="CANDIDATE_LIMIT";candidates[#candidates]=nil end
 local facts={options,player.mapID,player.continent};local idOrder={}
 for _,row in ipairs(candidates) do idOrder[#idOrder+1]=row end
 table.sort(idOrder,function(a,b)return a.id<b.id end)
 for _,row in ipairs(idOrder) do facts[#facts+1]=signature(row)..":"..tostring(row.progress or "?")..":"..(row.confidence or "?") end
 local excludedIDs={};for id in pairs(excluded) do excludedIDs[#excludedIDs+1]=id end;table.sort(excludedIDs)
 for _,id in ipairs(excludedIDs) do facts[#facts+1]=id..":"..excluded[id] end
 local fingerprint=table.concat(facts,"|")
 self.inputRevision=revision;self.options=options;self.excluded=excluded
 if fingerprint==self.fingerprint and not moved then
  self.cacheHits=self.cacheHits+1;self:ApplyAnnotations(rows);return
 end
 self.fingerprint=fingerprint;self.origin={x=player.x,y=player.y};self.lastBuilt=now
 self.mapID=player.mapID;self.continent=player.continent;self.requested=requested
 local groups=self:Cluster(candidates,p.clusterRadius or 60)
 -- At most 2,016 unique pairs at the 64-candidate cap. Reuse them for every
 -- score/lookahead in this build; discard the table after the bounded pass.
 local distances={}
 for _,row in ipairs(candidates) do distances[row.id]={} end
 for i,row in ipairs(candidates) do
  distances[row.id][row.id]=0
  for j=i+1,#candidates do
   local other=candidates[j];local d=distance(row,other)
   distances[row.id][other.id]=d;distances[other.id][row.id]=d
  end
 end
 local byQuest={};for _,g in ipairs(groups) do for _,row in ipairs(g.members) do byQuest[row.id]={row=row,group=g} end end
 local neighbors={}
 for _,row in ipairs(candidates) do
  local ids={};neighbors[row.id]=ids
  if p.routePolicy~="Short travel" then
   for _,other in ipairs(candidates) do
    if byQuest[row.id].group~=byQuest[other.id].group then ids[#ids+1]=other.id end
   end
   local metrics=distances[row.id]
   table.sort(ids,function(a,b)if metrics[a]~=metrics[b] then return metrics[a]<metrics[b] end;return a<b end)
  end
 end
 -- Explicit focus wins even when the user left F6 in Nearest mode. Following
 -- never silently ignores an unavailable pin/supertracked quest.
 local first=byQuest[requested]
 local fixed=first and "explicit quest focus" or nil
 if not first and not requested and self.head and self.head.mapID==player.mapID then
  local held=byQuest[self.head.id]
  if held and held.row.stage==self.head.stage then first=held;fixed="retained current stop" end
 end
 self.focusUnavailable=requested and not first or false
 local used,plan,planByID={},{},{}
 local from={x=player.x,y=player.y};local total=0
 local limit=math.min(12,math.max(3,math.floor(p.routeStops or 8)))
 local activeGroup=first and first.group
 while #plan<limit do
  local best,bestGroup,bestScore
  if first then best,bestGroup=first.row,first.group;first=nil
  else
   -- Finish the compact cluster before moving to another; actual member
   -- coordinates, never an invented cluster centroid, drive the compass.
   for _,group in ipairs(groups) do
    if not activeGroup or group==activeGroup then
     for _,row in ipairs(group.members) do if not used[row.id] then
      local score=self:Score(row,group,from,groups,used,distances,neighbors)
      if not best or score<bestScore or (score==bestScore and row.id<best.id) then best,bestGroup,bestScore=row,group,score end
     end end
    end
   end
   if not best and activeGroup then activeGroup=nil
   elseif not best then break end
  end
  if best then
   local leg=distance(best,from)
   if not number(leg) then break end
   total=total+leg;used[best.id]=true
   local entry={id=best.id,index=#plan+1,name=best.name,x=best.x,y=best.y,mapID=best.mapID,
    stage=best.stage,key=best.key,confidence=best.confidence,clusterID=bestGroup.id,clusterSize=#bestGroup.members,
    legDistance=leg,totalDistance=total,reason=self:Reason(best,bestGroup,#plan==0 and fixed or nil)}
   plan[#plan+1]=entry;planByID[entry.id]=entry;from=best;activeGroup=bestGroup;fixed=nil
  end
 end
 self.groups=groups;self.plan=plan;self.byID=planByID;self.totalDistance=total;self.candidateCount=#candidates
 self.status=#plan>0 and "READY" or "NO_LOCAL_ROUTE";self.builds=self.builds+1
 local h=plan[1];self.head=h and {id=h.id,stage=h.stage,mapID=h.mapID} or nil
 self:ApplyAnnotations(rows)
end
function R:Target(byID)
 local entry=self.plan[1]
 return self.status=="READY" and entry and byID[entry.id] or nil
end
function R:SetMode(mode)
 if mode~="Off" and mode~="Suggestions" and mode~="Follow route" then return false,"Unknown route mode." end
 if CC.Safety:InCombat() then return false,"Route settings are out of combat only." end
 local profile=CC:Copy(CC.profile);profile.compass.routeMode=mode
 local ok,why=CC.SavedData:Commit(profile)
 if ok then self:Reset(false);CC.QuestNavigation:Invalidate("ROUTE_MODE");return true end
 return false,why
end
function R:Summary()
 local count=0;for _ in pairs(self.excluded) do count=count+1 end
 return "Experimental route="..self.status.." | mode="..(pref().routeMode or "Off")
  .." | stops="..#self.plan.." | eligible="..(self.candidateCount or 0).." | excluded="..count
  .." | builds="..self.builds.." cache="..self.cacheHits.." | straight-line estimates only"
end
R.ExclusionLabels={FAILED="Quest failed",NO_LOCATION="No readable location",NO_MAP_TRANSFORM="No map transform",
 OTHER_WORLD="Other world",OTHER_MAP_OR_FLOOR="Different map or floor",UNVERIFIED_MAP_GEOMETRY="Map geometry unverified",
 UNKNOWN_STAGE="Quest stage unavailable",OUTSIDE_RADIUS="Outside planning radius",DEFERRED="Deferred for this session",
 AWAITING_TURN_IN_LOCATION="Waiting for updated turn-in location",CANDIDATE_LIMIT="Beyond 64-candidate limit"}
