local _,CC=...
local P=CC.ContextBackend
function P:SampleContext()
    local u=self.state.source
    local s={source=u,generation=self.state.generation,configVersion=self.state.configVersion,
        exists=false,relationship="UNKNOWN",kind="UNKNOWN",
        attackable="UNKNOWN",dead="UNKNOWN",contextStatus="UNKNOWN",contextReason="NO_UNIT"}
    local exists,es=self:Scalar("exists",UnitExists,"boolean",u)
    if es~="READABLE" then s.contextReason=es; return s end
    if not exists then return s end
    s.exists=true
    local reaction,rs=self:Scalar("reaction",UnitReaction,"number",u,"player")
    if rs=="READABLE" and reaction>=1 and reaction<=8 and reaction%1==0 then
        if reaction<=3 then s.relationship="HOSTILE"
        elseif reaction==4 then s.relationship="NEUTRAL" else s.relationship="FRIENDLY" end
    end
    local player,ps=self:Scalar("kind",UnitIsPlayer,"boolean",u)
    if ps=="READABLE" then s.kind=player and "PLAYER" or "NONPLAYER" end
    local attack,as=self:Scalar("attackable",UnitCanAttack,"boolean","player",u)
    if as=="READABLE" then s.attackable=attack and "YES" or "NO" end
    local dead,ds=self:Scalar("dead",UnitIsDeadOrGhost,"boolean",u)
    if ds=="READABLE" then s.dead=dead and "YES" or "NO" end
    s.contextStatus=(s.relationship~="UNKNOWN" and s.kind~="UNKNOWN") and "AVAILABLE" or "UNKNOWN"
    s.contextReason=s.contextStatus=="AVAILABLE" and "READABLE_FACTS" or "ONE_OR_MORE_FACTS_UNAVAILABLE"
    -- Attackability is independent: NO is never interpreted as FRIENDLY.
    return s
end
