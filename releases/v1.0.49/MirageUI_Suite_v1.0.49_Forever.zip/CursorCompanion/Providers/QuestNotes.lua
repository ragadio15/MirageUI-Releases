local _,CC=...
-- Read-only notes for readable Blizzard quest positions. Quest-map POIs and
-- next-waypoints are approximate locations, not guaranteed pathfinding.
CC.QuestNotesData={}
local N=CC.QuestNotesData
local function read(fn,...)
 if type(fn)~="function" then return nil end
 local ok,a,b,c,d,e=pcall(fn,...)
 if not ok then return nil end
 return a,b,c,d,e
end
local function natural(n) return CC.Safety:IsNumber(n) and n>0 and n%1==0 end
local function text(s)
 -- Never byte-slice a readable objective: it loses instructions and may split
 -- a multibyte character. The UI grows the scroll child for all its text.
 return CC.Safety:IsText(s) and #s>0 and s or nil
end
-- Every readable quest subobjective is represented, including completed steps.
-- Quest position and objective text are separate Blizzard sources: the distance
-- is to a quest marker/waypoint and need not be the distance to each substep.
function N:Objectives(questID)
 local rows={}
 local raw=C_QuestLog and read(C_QuestLog.GetQuestObjectives,questID)
 -- GetQuestObjectives may return a restricted table; never index/length it
 -- until access is verified (and never infer missing data as an incomplete step).
 if CC.Safety:IsReadable(raw) and type(raw)=="table"
     and CC.Safety:BoolCall(canaccesstable,raw)==true then
  local ok,count=pcall(function() return #raw end)
  count=ok and CC.Safety:IsNumber(count) and math.max(0,math.min(count,40)) or 0
  for i=1,count do
   local entry=CC.Safety:Field(raw,i)
   if CC.Safety:IsReadable(entry) then
    local label=CC.Safety:Field(entry,"text")
    local done=CC.Safety:Field(entry,"finished")
    if text(label) then rows[#rows+1]={text=text(label),complete=CC.Safety:IsReadable(done) and done==true or false} end
   end
  end
 end
 if #rows==0 and C_QuestLog then
  local count=read(C_QuestLog.GetNumQuestObjectives,questID)
  if CC.Safety:IsNumber(count) and count>=0 then
   for i=1,math.min(40,math.floor(count)) do
    local label,_,done=read(GetQuestObjectiveInfo,questID,i,false)
    if text(label) then rows[#rows+1]={text=text(label),complete=CC.Safety:IsReadable(done) and done==true or false} end
   end
  end
 end
 if #rows==0 then
  local waypoint=C_QuestLog and read(C_QuestLog.GetNextWaypointText,questID)
  if text(waypoint) then rows[1]={text=text(waypoint),complete=false} end
 end
 return rows
end
function N:Objective(questID)
 local rows=self:Objectives(questID)
 for _,row in ipairs(rows) do if not row.complete then return row.text end end
 return rows[1] and rows[1].text or nil
end
-- Secure item use is only configured out of combat, for a real player click.
-- Never invoke UseItemByName/UseContainerItem or issue a cast automatically.
function N:SpecialItem(questID)
 if CC.Safety:InCombat() or type(GetQuestLogSpecialItemInfo)~="function" then return nil end
 local index=C_QuestLog and read(C_QuestLog.GetLogIndexForQuestID,questID)
 if not natural(index) then return nil end
 local link,icon,charges=read(GetQuestLogSpecialItemInfo,index)
 if not CC.Safety:IsText(link) or #link>512 or #link==0 then return nil end
 if not (CC.Safety:IsNumber(icon) and icon>0) then return nil end
 if charges~=nil and not CC.Safety:IsNumber(charges) then charges=nil end
 return {link=link,icon=icon,charges=charges}
end
function N:Title(id)
 local title=C_QuestLog and read(C_QuestLog.GetTitleForQuestID,id)
 if text(title) then return text(title) end
 local index=C_QuestLog and read(C_QuestLog.GetLogIndexForQuestID,id)
 local info=natural(index) and read(C_QuestLog.GetInfo,index)
 local fallback=info and CC.Safety:Field(info,"title")
 return text(fallback) or "Quest #"..id
end
function N:Nearby(limit,showAll)
 if CC.Safety:InCombat() then return {},"PAUSED_IN_COMBAT" end
 if not (CC.profile and CC.profile.compass and CC.profile.compass.enabled and
  CC.profile.questNotes and CC.profile.questNotes.enabled) then return {},"DISABLED" end
 local nav=CC.QuestNavigation
 local rows,status,selected=nav:Snapshot(true)
 if status=="NO_POSITION" or status=="NO_API" or status=="RESTRICTED" then return {},status end
 local results={}
 for _,source in ipairs(rows) do
  -- Retain the focused quest even when its location is unknown, so the player
  -- can see why there is no arrow and can unpin it without using a command.
  if source.x or source==selected or source.pinned then
   local row={};for key,value in pairs(source) do row[key]=value end
   results[#results+1]=row
  end
 end
 table.sort(results,function(a,b)
  if a.pinned~=b.pinned then return a.pinned end
  if CC.profile.compass.routeMode=="Follow route" then
   if a.guiding~=b.guiding then return a.guiding end
   local ai,bi=a.routeIndex or math.huge,b.routeIndex or math.huge
   if ai~=bi then return ai<bi end
  end
  local ad=a.distance2 or math.huge;local bd=b.distance2 or math.huge
  if ad~=bd then return ad<bd end
  if a.watched~=b.watched then return a.watched end
  return a.questID<b.questID
 end)
 limit=CC.Safety:IsNumber(limit) and math.max(3,math.min(8,math.floor(limit))) or 5
 -- "All" includes the nearby active quests, but is still capped to prevent a
 -- malformed/overpopulated map POI feed from allocating hundreds of UI frames.
 local maxVisible=showAll==true and 64 or limit
 if selected then
  local index
  for i,row in ipairs(results) do if row.questID==selected.id then index=i;break end end
  if index and index>maxVisible then
   local focused=table.remove(results,index);table.insert(results,maxVisible,focused)
  end
 end
 while #results>maxVisible do results[#results]=nil end
 for _,row in ipairs(results) do
  row.objectives=self:Objectives(row.questID)
  for _,objective in ipairs(row.objectives) do
   if not objective.complete then row.objective=objective.text;break end
  end
  row.objective=row.objective or (row.objectives[1] and row.objectives[1].text)
  row.specialItem=self:SpecialItem(row.questID)
 end
 return results,#results>0 and "READY" or "NO_READABLE_OBJECTIVES"
end
