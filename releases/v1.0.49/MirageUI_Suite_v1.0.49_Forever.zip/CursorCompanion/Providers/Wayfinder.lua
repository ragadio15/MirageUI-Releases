local _,CC=...
-- An optional consumer of Wayfinder's immutable public destination contract.
-- Saved Quest/Beacon preferences are untouched. Independent destination
-- selection resumes only when Wayfinder is absent or explicitly Off.
CC.Wayfinder={kind="Quest",status="OFF",reason="NOT_CONNECTED",elapsed=0,managed=false}
local W=CC.Wayfinder
local function number(v) return CC.Safety:IsNumber(v) end
local function text(v) return CC.Safety:IsText(v) end
local function call(fn,...)
    if type(fn)~="function" then return nil,false end
    local ok,a,b=pcall(fn,...)
    if not ok or not CC.Safety:IsReadable(a) then return nil,false end
    return a,true,b
end
local function installed()
    local fn=(type(C_AddOns)=="table" and C_AddOns.IsAddOnLoaded) or IsAddOnLoaded
    local loaded,ok=call(fn,"MirageIntel_Navigate")
    return ok and loaded==true
end
function W:HideNavigation()
    local layer=CC.CompanionFrame and CC.CompanionFrame.compassLayer
    if layer and layer.root then layer.root:Hide() end
    if CC.NavigationLabel then CC.NavigationLabel:Hide() end
end
function W:Release()
    local api=self.api
    if api and type(api.ReleaseRenderer)=="function" then pcall(api.ReleaseRenderer,"CursorCompanion") end
    self.leaseRevision=nil
end
function W:Reset(reason)
    self:Release()
    self.status="OFF";self.reason=reason or "OFF";self.angle=nil;self.distance=nil
    self.name=nil;self.selection=nil;self.key=nil;self.questID=nil;self.siteID=nil
    self.navigationRevision=nil;self.arrived=false;self.routeRevision=nil;self.route=nil;self.directionTarget=nil
    self.guidance=nil
end
function W:Subscribe()
    local core=MirageIntelCoreAPI
    if self.subscribedCore==core or type(core)~="table" or type(core.Subscribe)~="function" then return end
    local ok=pcall(core.Subscribe,"NAV_SESSION_CHANGED","CursorCompanionWayfinder",function(snapshot)
        -- The event hub already makes per-subscriber copies. The next Tick
        -- rereads the service; a Pause clears passive visuals immediately.
        self.dirty=true
        if type(snapshot)=="table" and snapshot.mode=="Pause" then
            self.snapshot=snapshot;self.managed=true;self:Reset("PAUSED");self:HideNavigation()
        elseif type(snapshot)=="table" and snapshot.mode=="Off" then
            self:Release();self.dirty=true
        end
    end)
    if ok then self.subscribedCore=core end
end
function W:Sync(dt,force)
    self.elapsed=self.elapsed+(number(dt) and math.max(0,math.min(.25,dt)) or 0)
    local api=MirageNavigateAPI
    if not force and not self.dirty and self.api==api and self.elapsed<.15 then return end
    self.elapsed=0;self.dirty=false
    if self.api~=api then self:Release();self.api=api;self.snapshot=nil end
    self:Subscribe()
    if type(api)~="table" then
        self.managed=installed();self:Reset(self.managed and "WAYFINDER_STARTING" or "NOT_PRESENT");return
    end
    if api.apiVersion~=1 or api.navigationVersion~=2 or type(api.GetNavigationSnapshot)~="function" then
        local legacy,ok=call(api.GetStatus)
        self.managed=not (ok and type(legacy)=="table" and legacy.mode=="Off")
        self:Reset(self.managed and "WAYFINDER_CONTRACT_UNAVAILABLE" or "OFF");return
    end
    local snapshot,ok=call(api.GetNavigationSnapshot)
    if not ok or type(snapshot)~="table" or snapshot.schemaVersion~=2 or not number(snapshot.revision) then
        self.managed=true;self.snapshot=nil;self:Reset("WAYFINDER_PROVIDER_ERROR");return
    end
    self.snapshot=snapshot;self.managed=snapshot.mode~="Off"
    if not self.managed then self:Reset("OFF") end
end
function W:IsManaged() return self.managed==true end
function W:Tick(dt)
    if not self.managed then self:Reset("OFF");return end
    local snapshot=self.snapshot
    if not snapshot or snapshot.mode=="Pause" then self:Reset(snapshot and "PAUSED" or self.reason);return end
    self.logicElapsed=(self.logicElapsed or 0)+(number(dt) and math.max(0,math.min(.25,dt)) or .15)
    if self.logicElapsed<.15 and self.lastRevision==snapshot.revision and self.selection then return end
    self.logicElapsed=0;self.lastRevision=snapshot.revision
    local d=snapshot.destination
    if type(d)~="table" or not text(d.id) or not number(d.revision) or not number(d.mapID) then
        self:Reset(snapshot.status or "NO_DESTINATION");return
    end
    -- P4 transport legs have a destination but no supplied path geometry.
    -- Retain the authoritative identity while yielding to Wayfinder's action
    -- hint. Never turn a flight booking into a straight-line walking arrow.
    if (snapshot.route~=nil or snapshot.nextLeg~=nil) and snapshot.directionTarget==nil then
        self:Reset(snapshot.route and "TRANSPORT_ACTION_NATIVE_MAP" or "NO_DIRECTION_GEOMETRY")
        self.selection=d;self.name=text(d.label) and d.label or "Wayfinder destination"
        self.navigationRevision=d.revision;self.routeRevision=snapshot.routeRevision
        self.route=snapshot.route;self.key=d.id..":"..d.revision
        self.sessionMode=snapshot.mode;self:HideNavigation();return
    end
    local direction=type(snapshot.directionTarget)=="table" and snapshot.directionTarget or d
    if type(direction.world)~="table" or not number(direction.world.x) or not number(direction.world.y) or
        not number(direction.world.continent) or not number(direction.mapID) then self:Reset("NO_DIRECTION_GEOMETRY");return end
    local distance,angle,guidance
    if self.api and self.api.guidanceVersion==1 then
        local good
        guidance,good=call(self.api.GetGuidanceSnapshot)
        if not good or type(guidance)~="table" or guidance.schemaVersion~=1 then self:Reset("GUIDANCE_UNAVAILABLE");return end
        if guidance.revision~=snapshot.revision or guidance.destinationID~=d.id or guidance.destinationRevision~=d.revision then
            self.dirty=true;self:Reset("GUIDANCE_REVALIDATING");return
        end
        local now=CC.Safety:Value(GetTime)
        if not number(now) or not number(guidance.sampledAt) or not number(guidance.expiresAt)
            or now<guidance.sampledAt or now>guidance.expiresAt then self:Reset("GUIDANCE_EXPIRED");return end
        if guidance.status~="GUIDING" and guidance.status~="NEAR_DESTINATION" then
            self:Reset(text(guidance.status) and guidance.status or "GUIDANCE_UNAVAILABLE");return
        end
        if guidance.mapID~=direction.mapID or (guidance.floorID or guidance.mapID)~=(direction.floorID or direction.mapID)
            or guidance.angleConvention~="POSITIVE_COUNTERCLOCKWISE" then self:Reset("GUIDANCE_CONTRACT_MISMATCH");return end
        distance=guidance.distance;angle=guidance.relativeAngle
        if not number(distance) or distance<0 or (angle~=nil and not number(angle)) then self:Reset("GUIDANCE_UNAVAILABLE");return end
    else
        -- Keep the public v2 consumer compatible with an older standalone
        -- Wayfinder. P12 always uses its common fresh measurement above.
        local c,px,py,mapID,floorID=CC.QuestNavigation:PlayerWorld()
        if not number(c) or not number(px) or not number(py) then self:Reset("NO_POSITION");return end
        if c~=direction.world.continent or mapID~=direction.mapID or
            (floorID or mapID)~=(direction.floorID or direction.mapID) then self:Reset("OTHER_MAP_OR_FLOOR");return end
        local dx,dy=direction.world.x-px,direction.world.y-py
        distance=math.sqrt(dx*dx+dy*dy)
        local facing=CC.Safety:Value(GetPlayerFacing)
        if not number(distance) or not number(facing) then self:Reset("NO_FACING");return end
        angle=CC.QuestNavigation:RelativeAngle(px,py,direction.world.x,direction.world.y,facing)
    end
    self.kind="Quest";self.selection=d;self.name=text(d.label) and d.label or "Wayfinder destination"
    self.questID=d.questID;self.siteID=d.siteID;self.stage=d.stage;self.source="WAYFINDER"
    self.confidence=d.confidence;self.precision=d.precision;self.intentOrigin=d.intentOrigin
    self.navigationRevision=d.revision;self.key=d.id..":"..d.revision;self.distance=distance
    self.route=snapshot.route;self.routeRevision=snapshot.routeRevision;self.directionTarget=direction;self.guidance=guidance
    self.reason=snapshot.status;self.sessionMode=snapshot.mode
    local pref=CC.profile and CC.profile.compass or {}
    local radius=number(pref.arrivalRadius) and pref.arrivalRadius or 8
    self.arrived=pref.arrivalCue==true and distance<=radius
    self.angle=not self.arrived and angle or nil
    self.status=self.arrived and "NEAR_DESTINATION" or self.angle and "GUIDING" or "OFF"
    if self.status=="OFF" then self:Release() end
end
function W:BeginRender(idle)
    if not self.managed then return true end
    local p=CC.profile and CC.profile.compass
    if idle or not p or not p.enabled or p.questCompass==false or (CC.Navigation and CC.Navigation:Mode()=="None") or not self.selection or
        (self.status~="GUIDING" and self.status~="NEAR_DESTINATION") then self:Release();return false end
    if self.api and self.api.guidanceVersion==1 then
        -- The presentation loop may run after a delayed provider tick. A
        -- renewed renderer lease must not keep an expired heading on screen.
        local g=self.guidance;local now=CC.Safety:Value(GetTime)
        if type(g)~="table" or not number(now) or not number(g.sampledAt) or not number(g.expiresAt) or
            now<g.sampledAt or now>g.expiresAt or g.destinationRevision~=self.navigationRevision then
            self.dirty=true;self:Reset("GUIDANCE_EXPIRED");self:HideNavigation();return false
        end
    end
    local granted,ok=call(self.api and self.api.AcquireRenderer,"CursorCompanion",self.navigationRevision,.5)
    if not ok or granted~=true then self:Release();return false end
    self.leaseRevision=self.navigationRevision
    return true
end
function W:FinishRender()
    if not self.managed or not self.leaseRevision then return end
    local layer=CC.CompanionFrame and CC.CompanionFrame.compassLayer
    local root=layer and layer.root
    local shown,ok=call(root and root.IsVisible,root)
    if not ok or shown~=true then self:Release() end
end
function W:Get() return self end
function W:Summary()
    return "Navigation=WAYFINDER | session="..tostring(self.snapshot and self.snapshot.mode or "STARTING")
        .." | status="..tostring(self.reason).." | destination="..tostring(self.selection and self.selection.id or "NONE")
        .." | revision="..tostring(self.navigationRevision or 0).." | renderer="..(self.leaseRevision and "CURSOR" or "WAYFINDER_FALLBACK")
        .." | route_revision="..tostring(self.routeRevision or 0)
        .." | saved Quest/Beacon mode resumes when Wayfinder is Off"
end
function W:SelectBeacon(record)
    self:Sync(0,true)
    if not self.managed then return true,"STANDALONE_BEACON" end
    if not self.api or type(self.api.RequestDestination)~="function" or type(record)~="table" then return false,"WAYFINDER_UNAVAILABLE" end
    local ok,result,reason=pcall(self.api.RequestDestination,"manual",{
        id=text(record.id) and ("beacon:"..record.id) or nil,mapID=record.mapID,x=record.mapX,y=record.mapY,
        label="Selected Beacon",purpose="BEACON",sourceRevision=record.seq,floorID=record.floorID,
    },{userInitiated=true})
    if ok and result==true then
        if type(self.api.Refresh)=="function" then pcall(self.api.Refresh) end
        self.dirty=true;return true,"WAYFINDER_MANUAL_BEACON"
    end
    return false,ok and reason or "WAYFINDER_BEACON_REQUEST_FAILED"
end
function W:SelectQuest(id)
    self:Sync(0,true)
    if not self.managed or not self.api then return false,"WAYFINDER_NOT_ACTIVE" end
    local operation,args
    if id==nil or id==0 then
        if not self:PinnedQuestID() then return false,"No quest focus is selected." end
        operation=self.api.ClearPin
    else operation=self.api.PinQuest;args=id end
    local result,called,reason=call(operation,args)
    if called and result==true then
        if type(self.api.Refresh)=="function" then pcall(self.api.Refresh) end
        self.dirty=true;self:Sync(0,true);return true
    end
    return false,reason or "Wayfinder could not select this native quest location."
end
function W:PinnedQuestID()
    local s=self.snapshot
    local focus=s and s.focus
    if type(focus)=="table" then return focus.kind=="quest" and number(focus.questID) and focus.questID or nil end
    local d=s and s.destination
    return d and d.kind=="quest" and d.intentOrigin=="PLAYER_EXPLICIT" and number(d.questID) and d.questID or nil
end
function W:OpenRoute()
    self:Sync(0,true)
    if not self.managed then return false end
    local opened,called,reason=call(self.api and self.api.Open)
    return true,called and opened~=false,reason
end
-- Quest Notes is another view of the same accepted quests and active focus.
-- It must not run the old Cursor planner behind the shared direction display.
function W:QuestSnapshot()
    local s=self.snapshot
    local candidates,ok=call(self.api and self.api.GetCandidates)
    if not s or not ok or type(candidates)~="table" then return {},"GUIDANCE_UNAVAILABLE",nil,nil end
    local guide,read
    if self.api.guidanceVersion==1 then guide,read=call(self.api.GetGuidanceSnapshot) end
    local player=read and type(guide)=="table" and guide.revision==s.revision and type(guide.player)=="table" and guide.player or nil
    local active=s.destination;local focus=self:PinnedQuestID()
    local rows,byID={},{}
    local order={}
    for index,stop in ipairs(s.itinerary and s.itinerary.stops or {}) do
        if number(stop.questID) then order[stop.questID]=index end
    end
    local function add(source)
        if type(source)~="table" or not number(source.questID) or source.questID<=0 or source.questID%1~=0 then return end
        local id=source.questID
        if byID[id] then return end
        local w=source.world
        local located=type(w)=="table" and number(w.x) and number(w.y) and number(w.continent) and number(source.mapID)
        local row={id=id,questID=id,name=text(source.label) and source.label or "Quest",stage=source.stage,
            mapID=source.mapID,floorID=source.floorID or source.mapID,source=source.source,confidence=source.confidence,
            watched=source.watched==true,pinned=focus==id,guiding=active and active.questID==id or false,
            routeIndex=order[id],locationState=source.awaitingTurnIn and "AWAITING_TURN_IN_LOCATION" or located and "LOCATED" or "NO_LOCATION"}
        if located then
            row.x,row.y,row.continent=w.x,w.y,w.continent
            row.key="wayfinder:"..id..":"..tostring(s.revision)
            if player and number(player.x) and number(player.y) and player.continent==w.continent and player.mapID==row.mapID
                and (player.floorID or player.mapID)==row.floorID then
                row.distance2=(w.x-player.x)^2+(w.y-player.y)^2
                row.distSq=row.distance2;row.approxDistance=math.sqrt(row.distance2)
            end
        end
        rows[#rows+1]=row;byID[id]=row
    end
    if active then add(active) end
    for index=1,math.min(#candidates,128) do add(candidates[index]) end
    return rows,s.mode=="Pause" and "PAUSED" or s.status,active and active.questID and byID[active.questID] or nil,player
end
