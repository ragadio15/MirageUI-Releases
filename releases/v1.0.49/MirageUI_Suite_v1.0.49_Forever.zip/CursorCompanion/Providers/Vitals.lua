local _,CC=...
-- Live player percentages are opaque values forwarded directly to native ring
-- radial-progress textures. Do not inspect or calculate on protected values.
CC.Vitals={active=false,hasHealth=false,hasPower=false,faults={},samples=0,
 valid={health=false,resource=false},radialFaults={}}
local V=CC.Vitals
function V:Initialize()
 self.frame=CreateFrame("Frame")
 self.frame:SetScript("OnEvent",function(_,event,unit)
  if not self.active then return end
  if event=="UNIT_HEALTH" or event=="UNIT_MAXHEALTH" then
   if CC.Safety:IsText(unit) and unit=="player" then self:Publish("health") end
  elseif event=="UNIT_POWER_UPDATE" or event=="UNIT_POWER_FREQUENT" or event=="UNIT_MAXPOWER" or event=="UNIT_DISPLAYPOWER" then
   if CC.Safety:IsText(unit) and unit=="player" then self:Publish("resource") end
  else self:Refresh() end
 end)
end
function V:Fault(kind,reason)
 local key=kind.."_"..reason
 if self.faults[key] then return end
 self.faults[key]=true;CC.Diagnostics:OptionalFault("VITALS_"..key:upper())
end
function V:Needed()
 self.hasHealth=false;self.hasPower=false
 for _,r in pairs(CC.profile.rings) do
  if r.enabled and r.role=="Health" then self.hasHealth=true end
  if r.enabled and r.role=="Resource" then self.hasPower=true end
 end
 return self.hasHealth or self.hasPower
end
function V:Start()
 if self.active then return end
 if not CC.state.running or not CC.profile.enabled or not self:Needed() then return end
 if not CC.Capabilities.vitals then self:Fault("provider","unavailable");return end
 -- Do not invoke a missing getter, and do not let one unavailable lane
 -- prevent the other independent player-ring provider from starting.
 self.hasHealth=self.hasHealth and CC.Capabilities.health
 self.hasPower=self.hasPower and CC.Capabilities.resource
 if not self.hasHealth and not self.hasPower then return end
 self.faults={};self.samples=0;self.valid={health=false,resource=false};self.radialFaults={}
 -- A successful pcall is not evidence that an event was subscribed. A lane
 -- needs a current-value event, not merely a maximum/display change event;
 -- otherwise its initial percentage can remain visible indefinitely.
 local function register(event)
  local ok,result=pcall(self.frame.RegisterUnitEvent,self.frame,event,"player")
  local registered=ok and CC.Safety:IsReadable(result) and result~=false
  if registered and type(self.frame.IsEventRegistered)=="function" then
   local checked,active=pcall(self.frame.IsEventRegistered,self.frame,event)
   registered=checked and CC.Safety:IsReadable(active) and active==true
  end
  if not registered and type(self.frame.UnregisterEvent)=="function" then
   pcall(self.frame.UnregisterEvent,self.frame,event)
  end
  return registered==true
 end
 if self.hasHealth then
  self.hasHealth=register("UNIT_HEALTH")
  if self.hasHealth then register("UNIT_MAXHEALTH") else self:Fault("health","events") end
 end
 if self.hasPower then
  local update=register("UNIT_POWER_UPDATE")
  local frequent=register("UNIT_POWER_FREQUENT")
  self.hasPower=update or frequent
  if self.hasPower then
   register("UNIT_MAXPOWER");register("UNIT_DISPLAYPOWER")
  else self:Fault("resource","events")
  end
 end
 if not self.hasHealth and not self.hasPower then
  self.frame:UnregisterAllEvents();self:Fault("events","unavailable");return
 end
 for _,event in ipairs({"PLAYER_ALIVE","PLAYER_DEAD","PLAYER_ENTERING_WORLD"}) do
  pcall(self.frame.RegisterEvent,self.frame,event)
 end
 self.active=true;self:Refresh()
end
function V:Stop()
 if self.frame then self.frame:UnregisterAllEvents() end
 self.active=false;self.hasHealth=false;self.hasPower=false
 self.valid={health=false,resource=false};self.radialFaults={}
end
function V:Refresh()
 if not self.active then return end
 if self.hasHealth then self:Publish("health") end
 if self.hasPower then self:Publish("resource") end
end
function V:Publish(kind)
 if not self.active or (kind=="health" and not self.hasHealth) or (kind=="resource" and not self.hasPower) then return end
 local ok,value
 if kind=="health" then ok,value=pcall(UnitHealthPercent,"player",false,CurveConstants.ZeroToOne)
 else ok,value=pcall(UnitPowerPercent,"player",nil,false,CurveConstants.ZeroToOne) end
 if not ok then
  self.valid[kind]=false;self:Fault(kind,"getter");return
 end
 self.valid[kind]=true
 local role=kind=="health" and "Health" or "Resource"
 for key,r in pairs(CC.profile.rings) do
  if r.enabled and r.role==role then
   local layer=CC.CompanionFrame.layers[key]
   if not layer or not layer.progress or type(layer.progress.SetRadialProgressBarPercent)~="function" then
    self.radialFaults[key]=true;self:Fault(kind,"radial_missing")
   elseif not pcall(layer.progress.SetRadialProgressBarPercent,layer.progress,value) then
    self.radialFaults[key]=true;layer.progress:Hide();self:Fault(kind,"radial_sink")
   else self.radialFaults[key]=nil end
  end
 end
 self.samples=self.samples+1
end
