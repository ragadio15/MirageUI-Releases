local _,CC=...
local S=CC.Safety
CC.Fishing={action="CURSORCOMPANION_FISHING",buttonName="CursorCompanionFishingAction",restoreName="CursorCompanionFishingRestore",
 phase="IDLE",access="UNKNOWN",reason="Water access needs a player cast check.",sequence=0,restoreAttempts={}}
local F=CC.Fishing
local MAIN,OFF,RANGED=16,17,18
local SPELL_IDS={7620,7731,7732,18248,131474}
local function num(v) return S:IsNumber(v) and v or nil end
local function txt(v) return S:IsText(v) and v or nil end
local function call(fn,...)
 if type(fn)~="function" then return nil end
 local ok,v=pcall(fn,...);if ok and S:IsReadable(v) then return v end
end
local function now() return num(call(GetTime)) or 0 end
local function cfg() return CC.profile and CC.profile.fishing or {} end
local function id(v)
 if not S:IsReadable(v) then return nil end
 if type(v)=="string" then v=tonumber(v:match("^%s*(%d+)%s*$")) end
 if num(v) and v>0 and v%1==0 then return v end
end
local function readEquipmentID(slot)
 if type(GetInventoryItemID)~="function" then return nil end
 local ok,value=pcall(GetInventoryItemID,"player",slot)
 if not ok or not S:IsReadable(value) then return nil end
 if value==nil or value==0 then return 0 end
 return id(value)
end
local function nativeItem(slot) return id(readEquipmentID(slot)) end
local function equipmentGUID(slot)
 if ItemLocation and type(ItemLocation.CreateFromEquipmentSlot)=="function" and C_Item and type(C_Item.GetItemGUID)=="function" then
  local ok,location=pcall(ItemLocation.CreateFromEquipmentSlot,ItemLocation,slot)
  if ok then return txt(call(C_Item.GetItemGUID,location)) end
 end
end
local function snapshotSlot(slot)
 local value=readEquipmentID(slot)
 if value==nil then return nil end
 return {id=value,link=txt(call(GetInventoryItemLink,"player",slot)),guid=equipmentGUID(slot)}
end
local function safeSlot(record)
 if type(record)~="table" then return nil end
 local item=id(record.id)
 if record.id==0 then return {id=0} end
 if not item then return nil end
 return {id=item,link=type(record.link)=="string" and #record.link<=512 and record.link or nil,
  guid=type(record.guid)=="string" and #record.guid<=100 and record.guid or nil}
end
local function sameEquipment(record,slot)
 if not record then return true end
 local currentID=readEquipmentID(slot)
 if currentID==nil or currentID~=record.id then return false end
 local current=equipmentGUID(slot)
 -- A previously observed exact identity must not silently degrade to an item
 -- ID when the current native identity is temporarily unreadable.
 if record.guid then return current~=nil and record.guid==current end
 local link=txt(call(GetInventoryItemLink,"player",slot))
 if record.link then return link~=nil and record.link==link end
 return true
end
local function position()
 local x,y,z,instance
 if type(UnitPosition)=="function" then
  local ok,a,b,c,d=pcall(UnitPosition,"player")
  if ok then x,y,z,instance=num(a),num(b),num(c),num(d) end
 end
 local facing=num(call(GetPlayerFacing))
 if x and y and instance then return {kind="world",x=x,y=y,z=z or 0,map=instance,facing=facing} end
 local map=num(call(C_Map and C_Map.GetBestMapForUnit,"player"))
 local vector=map and call(C_Map and C_Map.GetPlayerMapPosition,map,"player")
 if vector and S:IsReadable(vector) then
  local ok,a,b=pcall(function() return vector:GetXY() end)
  if ok and num(a) and num(b) then return {kind="map",map=map,x=a,y=b,facing=facing} end
 end
end
local function samePosition(a,b)
 if not a or not b or a.kind~=b.kind or a.map~=b.map then return false end
 local epsilon=a.kind=="world" and 0.75 or 0.0001
 if math.abs(a.x-b.x)>epsilon or math.abs(a.y-b.y)>epsilon then return false end
 if a.facing and b.facing then
  local diff=math.abs(a.facing-b.facing)%(2*math.pi);if math.min(diff,2*math.pi-diff)>.08 then return false end
 end
 return true
end
local function safePosition(value)
 if type(value)~="table" or (value.kind~="world" and value.kind~="map")
   or not num(value.x) or not num(value.y) or not num(value.map) then return nil end
 return {kind=value.kind,map=value.map,x=value.x,y=value.y,z=num(value.z),facing=num(value.facing)}
end
local function leftPosition(a,b)
 -- This is a session boundary, not a shoreline detector. A small translation
 -- tolerance ignores character jitter; turning in place can still recast.
 if not a or not b or a.kind~=b.kind then return false end
 if a.map~=b.map then return true end
 local distance=a.kind=="world" and 3 or .0005
 return (a.x-b.x)^2+(a.y-b.y)^2>distance*distance
end
local function dead() return S:BoolCall(UnitIsDeadOrGhost,"player")==true end
function F:IsEnabled()
 return CC.profile and CC.profile.enabled==true and cfg().enabled==true and not (CC.SavedData and CC.SavedData.readOnly)
end
function F:SetStatus(phase,message,persistent)
 self.phase=phase;self.reason=message
 if CC.FishingStatus then
  if self:IsEnabled() then CC.FishingStatus:Set(message,persistent) else CC.FishingStatus:Hide() end
 end
end
function F:GetStatus()
 return {phase=self.phase,access=self.access,reason=self.reason,spellID=self.spellID,spellName=self.spellName,
  poleID=self.poleID,waterProbe="CAST_RESULT_ONLY",biteDetection="UNAVAILABLE",nativeTest="PENDING",
  restorePending=self.restorePending==true,restoreWanted=self.restoreWanted==true,savedWeapons=self.saved~=nil,fault=self.fault,
  swap=self.swap and self.swap.kind or "NONE",swapSlot=self.swap and self.swap.slot or nil,
  bindAction=self.action,buttonName=self.buttonName,channelPress="CANCEL_AND_RECAST",recastRequests=self.recastRequests or 0,
  savedPoleID=self.saved and self.saved.poleID or nil,restoreTrigger="LEAVE_CONFIRMED_SPOT_OR_CAST_FAILURE"}
end
function F:GetButtonName() return self.buttonName end
function F:ClaimNativeAction(kind)
 CC.state=CC.state or {};CC.state.nativeActionOwner="Fishing"
 self.lastProtected=now();self.lastProtectedKind=kind
end
function F:ReadSavedEquipment()
 local db=CC.SavedData and CC.SavedData.character
 local record=db and db.fishingEquipment
 if type(record)~="table" then return end
 local main=safeSlot(record.main);local off=safeSlot(record.off)
 if main and off then
  self.saved={main=main,off=off,ranged=safeSlot(record.ranged),poleID=id(record.poleID),
   position=safePosition(record.position),restoring=record.restoring==true}
  self.sessionPosition=self.saved.position
  self.restoreWanted=record.restoring==true
 end
end
function F:SaveEquipment(record)
 self.saved=record
 if not record then self.restoreWanted=false;self.restorePending=false;self.restoreDeferred=false;self.sessionPosition=nil;self.restorePromptCaptureShown=nil end
 if not record and self.restoreButton and not S:InCombat() then
  self.restoreButton:Hide();self.restoreButton:SetAttribute("type",nil)
  self.restoreButton:SetAttribute("macrotext",nil);self.restorePrepared=nil
 end
 local db=CC.SavedData and CC.SavedData.character
 if db and not CC.SavedData.readOnly then db.fishingEquipment=record and CC:Copy(record) or nil end
end
function F:CaptureWeapons(poleID)
 if self.saved then
  if id(poleID) then self.saved.poleID=id(poleID);self:SaveEquipment(self.saved) end
  return true
 end
 local main,off=snapshotSlot(MAIN),snapshotSlot(OFF)
 if not main or not off then return false end
 if main.id>0 and (main.id==id(poleID) or CC.Inventory:IsPole(main.id)) then return false end
 local ranged=snapshotSlot(RANGED)
 -- Older clients expose a separate ranged slot; absent/unsupported ranged
 -- slots do not add a restoration requirement to a main/off-hand snapshot.
 if ranged and ranged.id==0 then ranged=nil end
 self:SaveEquipment({main=main,off=off,ranged=ranged,poleID=id(poleID)})
 return true
end
function F:LoadoutRestored()
 return self.saved and sameEquipment(self.saved.main,MAIN) and sameEquipment(self.saved.off,OFF)
  and sameEquipment(self.saved.ranged,RANGED) or false
end
function F:IsUnrelatedMainHand()
 local current=nativeItem(MAIN)
 if not self.saved or not current or current==self.saved.main.id or current==self.saved.poleID or current==self.poleID then return false end
 local item=CC.Inventory:GetItem(current)
 -- A cache miss is not evidence of a manual weapon change. The exact pole
 -- identity is retained separately from item class/name metadata.
 return item and item.loaded==true and not CC.Inventory:IsPole(current) or false
end
function F:LeftFishingSpot()
 return self.saved~=nil and leftPosition(self.sessionPosition or self.saved.position,position())
end
function F:ResolveSpell()
 self.spellID=nil;self.spellName=nil
 local known=C_SpellBook and C_SpellBook.IsSpellKnown or IsPlayerSpell or IsSpellKnown
 for _,spell in ipairs(SPELL_IDS) do
  if S:BoolCall(known,spell)==true then
   local name=txt(call(C_Spell and C_Spell.GetSpellName,spell))
   if not name and type(GetSpellInfo)=="function" then name=txt(call(GetSpellInfo,spell)) end
   if not name and C_Spell and type(C_Spell.GetSpellInfo)=="function" then name=txt(S:Field(call(C_Spell.GetSpellInfo,spell),"name")) end
   if name then self.spellID=spell;self.spellName=name;return true end
  end
 end
 return false
end
function F:IsFishingSpell(value)
 if not num(value) then return false end
 for _,spell in ipairs(SPELL_IDS) do if value==spell then return true end end
 return value==self.spellID
end
function F:ChannelInfo()
 if type(UnitChannelInfo)~="function" then return nil end
 local ok,name,_,_,_,finish,_,_,spell=pcall(UnitChannelInfo,"player")
 if not ok or not S:IsReadable(name) then return nil end
 if name==nil then return false end
 if (self.spellName and txt(name)==self.spellName) or self:IsFishingSpell(spell) then return true,num(finish) end
 return false
end
-- Public movement/death state identifies definite inability to cast. None of
-- these claims to measure distance to water. IsSwimming/IsUsableSpell are NOT
-- used as water detectors. Unknown shore geometry is checked by a player cast.
function F:AccessCheck()
 if S:InCombat() then return "NO_ACCESS","Fishing pauses during combat." end
 if dead() then return "NO_ACCESS","Fishing is unavailable while dead." end
 if S:BoolCall(UnitOnTaxi,"player")==true or S:BoolCall(IsFlying)==true then return "NO_ACCESS","Land before fishing." end
 if S:BoolCall(IsMounted)==true then return "NO_ACCESS","Dismount before fishing." end
 local speed=num(call(GetUnitSpeed,"player"))
 if speed and speed>0 then return "NO_ACCESS","Stop moving before fishing." end
 if self.accessPosition and not samePosition(self.accessPosition,position()) then self.access="UNKNOWN";self.accessPosition=nil end
 if self.access=="NO_ACCESS" and self.accessPosition then return "NO_ACCESS","The last cast here found no fishable water. Move or turn to try again." end
 if self.access=="CONFIRMED" and self.accessPosition then return "CONFIRMED","Fishing access confirmed by the last cast here." end
 return "UNKNOWN","Water access is unknown; the next player cast checks it."
end
function F:ResetAccess()
 self.access="UNKNOWN";self.accessPosition=nil
 self:SetStatus("READY","Water access is unknown. Face water and press the fishing shortcut.")
end
function F:ChoosePole()
 local equipped=nativeItem(MAIN)
 if equipped and (CC.Inventory:IsPole(equipped) or self.saved and self.saved.poleID==equipped) then
  return CC.Inventory:GetItem(equipped) or {id=equipped},true
 end
 local preferred=id(cfg().poleID)
 if preferred then
  local r=CC.Inventory:GetItem(preferred)
  if not CC.Inventory:IsPole(preferred) or not r or not r.loaded or not r.usable or (r.availableCount or 0)<1 then return nil,false,"The chosen fishing pole is unavailable or unusable." end
  return r,false
 end
 -- IsUsableItem asks about an item-use action, not whether equipment may
 -- occupy a slot. A pole with no use effect must not fail this selection.
 for _,r in ipairs(CC.Inventory:GetPoles()) do return r,false end
 return nil,false,"No usable fishing pole was found in your carried bags."
end
local function clearAction(button)
 if not button then return end
 for _,key in ipairs({"type","spell","item","macro","macrotext","unit","target-slot"}) do button:SetAttribute(key,nil) end
end
function F:ShowRestorePrompt()
 if not self.restoreButton or S:InCombat() then return false end
 if self.bindingCapture then
  self.restorePromptCaptureShown=true;clearAction(self.restoreButton);self.restoreButton:Hide();return false
 end
 self.restorePromptCaptureShown=nil;self.restoreButton:Show();return true
end
function F:Disarm()
 if S:InCombat() then self.bindingDirty=true;return end
 clearAction(self.button)
end
-- These macros run ONLY through a real secure button press. Inventory is read
-- again immediately before dispatch; no timer/event calls an equip API.
function F:PrepareSwap(button,entry,slot,kind)
 if S:InCombat() or dead() then return false end
 if S:BoolCall(CursorHasItem)==true then self:SetStatus("CURSOR_BUSY","Put down the item on your cursor before swapping equipment.");return false end
 CC.Inventory:Refresh(true)
 local found=CC.Inventory:FindSlot(entry.id,entry.guid,entry.link)
 if not found then self:SetStatus("SWAP_UNAVAILABLE","The required item is missing, locked, or cannot be uniquely identified. Check your bags and press again.");return false end
 local bag,itemSlot=found.bag,found.slot
 if not num(bag) or not num(itemSlot) or bag<0 or bag>7 or itemSlot<1 or bag%1~=0 or itemSlot%1~=0 then return false end
 local body=(kind=="RESTORE" and "/stopcasting\n" or "").."/equipslot "..slot.." "..bag.." "..itemSlot
 clearAction(button)
 button:SetAttribute("macrotext",body);button:SetAttribute("type","macro")
 self.swapSequence=(self.swapSequence or 0)+1
 self.swap={kind=kind,slot=slot,entry={id=entry.id,guid=found.guid or entry.guid,link=found.link or entry.link},
  sequence=self.swapSequence,untilTime=now()+3}
 self.clickKind=kind;self:ClaimNativeAction(kind=="RESTORE" and "RESTORE_CLICK" or "EQUIP_POLE")
 return true
end
function F:CheckSwap(timeout)
 local swap=self.swap;if not swap then return end
 if S:InCombat() or dead() then
  if swap.kind=="RESTORE" then self.restoreDeferred=true end
  return
 end
 if sameEquipment(swap.entry,swap.slot) then
  self.swap=nil;self.pendingPole=nil;self.restorePending=false
  if swap.kind=="RESTORE" then self:VerifyRestore(false)
  else self:SetStatus("READY","Pole equipped. Press the shortcut again to cast.") end
  return true
 end
 if timeout or now()>=swap.untilTime then
  self.swap=nil;self.pendingPole=nil;self.restorePending=false
  if swap.kind=="RESTORE" then
   self:SetStatus("RESTORE_RETRY","Weapon swap was not confirmed. Check bag space and item requirements, then press the fishing shortcut again.",true)
  else self:SetStatus("EQUIP_FAILED","Pole swap was not confirmed. Check bag space and pole requirements, then press again.") end
  return false
 end
end
function F:Prepare()
 if not self.button or S:InCombat() then return false,"COMBAT_DEFERRED" end
 self:Disarm()
 if not self:IsEnabled() then return false,"DISABLED" end
 if self.fault then return false,"FISHING_ISOLATED" end
 if not self.secureReady then return false,"SECURE_STATE_UNAVAILABLE" end
 self:ResolveSpell()
 if not self.spellName then return false,"LEARN_FISHING" end
 if self.channel then return true,"RECAST_WITH_PLAYER_PRESS" end
 return true,"READY_FOR_PLAYER_PRESS"
end
function F:Invoke()
 -- Bindings.xml fallback is deliberately nonprotected: never simulate Click().
 self:Prepare()
 if not self:IsEnabled() then CC:Print("Enable Fishing Assistant in settings first.")
 elseif S:InCombat() then CC:Print("Fishing pauses during combat.")
 elseif not self.secureReady then CC:Print("Fishing controls are unavailable on this client.")
 else self:RefreshBindings();CC:Print("Fishing shortcut prepared. Press it again to equip or cast.") end
end
function F:PreClick(button,down,restore)
 if S:InCombat() then return end
 clearAction(button);self.clickKind=nil;self.restorePrepared=nil
 if down then self.suppressRelease=false;return end
 if self.suppressRelease and not restore then self.suppressRelease=false;return end
 if self.swap then self:CheckSwap(false) end
 if self.swap then self:SetStatus("SWAPPING","Waiting for the equipment change to finish. Press again when ready.");return end
 if dead() then self:SetStatus("NO_ACCESS","Wait until alive to change fishing equipment.");return end
 if restore or self.restoreWanted then
  self:PrepareRestoreButton(button);return
 end
 if not self:IsEnabled() then self:SetStatus("DISABLED","Enable Fishing Assistant in settings first.");return end
 if self.fault then self:SetStatus("UNAVAILABLE","Fishing stopped after a restricted action. Reload before retrying.");return end
 if not self.secureReady then self:SetStatus("UNAVAILABLE","Secure fishing controls are unavailable on this client.");return end
 -- A channeling press must reach the secure action button, never INTERACTTARGET.
 -- A real button release executes BOTH macro commands; callbacks merely prepare
 -- that native action. No event, timer, or synthetic click starts another cast.
 local liveChannel=self:ChannelInfo()
 if liveChannel==true or (liveChannel==nil and self.channel) then
  if not self:ResolveSpell() then self:SetStatus("UNLEARNED","Learn Fishing before using this shortcut.");return end
  local name=self.spellName
  if not txt(name) or name:find("[\r\n]") or #name>100 then
   self:SetStatus("RECAST_UNAVAILABLE","Fishing spell name cannot be used in a native macro.");return
  end
  local body="/stopcasting\n/cast "..name
  if #body>255 then self:SetStatus("RECAST_UNAVAILABLE","Fishing macro is too long.");return end
  button:SetAttribute("macrotext",body);button:SetAttribute("type","macro")
  self.channel=true;self.recastClick=true;self.recastRequests=(self.recastRequests or 0)+1
  self.lastCastAttempt=now();self:ClaimNativeAction("RECAST")
  self.clickKind="RECAST"
  self:SetStatus("RECASTING","Canceling the current line and casting again. The game chooses the new bobber location.",true)
  return
 end
 if self.channel and liveChannel==false then self.channel=false end
 -- Once a successful fishing session has moved away, the next idle hardware
 -- press means return to the saved loadout. No movement event equips items.
 if self.saved and cfg().restoreWeapons and self:LeftFishingSpot() then
  self.restoreReason="LEFT_FISHING_SPOT";self:MarkRestoreWanted();self:PrepareRestoreButton(button);return
 end
 local access,why=self:AccessCheck()
 if access=="NO_ACCESS" then
  if self.saved and cfg().restoreWeapons then
   self:MarkRestoreWanted();self:PrepareRestoreButton(button)
  else self:SetStatus("NO_ACCESS",why) end
  return
 end
 if not self:ResolveSpell() then self:SetStatus("UNLEARNED","Learn Fishing before using this shortcut.");return end
 CC.Inventory:Refresh(true)
 local pole,equipped,reason=self:ChoosePole()
 if not pole then self:SetStatus("NO_POLE",reason);return end
 self.poleID=pole.id
 if not equipped then
  if not cfg().autoEquip then self:SetStatus("NO_POLE","Equip your fishing pole, or enable automatic pole equipping.");return end
  if nativeItem(OFF) and CC.Inventory:FreeGeneralSlots()<1 then self:SetStatus("BAGS_FULL","Free one general bag slot before putting away your off-hand item.");return end
  if not self:CaptureWeapons(pole.id) then
   self:SetStatus("EQUIPMENT_UNAVAILABLE","Your equipped weapons cannot be read safely. Try again outside combat before equipping the pole.");return
  end
  if self:PrepareSwap(button,{id=pole.id},MAIN,"POLE") then
   self.pendingPole=pole.id;self.pendingPoleUntil=now()+3
   self:SetStatus("EQUIPPING","Equipping your pole. Press again to cast once it is equipped.")
  end
 else
  button:SetAttribute("spell",self.spellName);button:SetAttribute("type","spell")
  self.lastCastAttempt=now();self:ClaimNativeAction("CAST");self.clickKind="CAST"
  self:SetStatus("CAST_CHECK",access=="CONFIRMED" and "Casting your line." or "Checking fishing access with your cast.")
 end
end
function F:PostClick(down,restore)
 if down or S:InCombat() then return end
 -- The protected macro action has completed; it may have emitted channel-stop
 -- and channel-start while processing /stopcasting followed by /cast Fishing.
 if self.recastClick then
  local ticket=self.recastRequests
  self.recastClick=nil
  -- Observation only. A failed recast must not leave a permanent "recasting"
  -- label, but the watchdog must never cast or click on the user's behalf.
  if C_Timer and C_Timer.After then
   local sequence=self.sequence
   C_Timer.After(4,function()
    if self.recastRequests==ticket and self.sequence==sequence and self.phase=="RECASTING" and self:IsEnabled() and self:ChannelInfo()~=true then
     self.channel=false
     self:SetStatus("RECAST_UNCONFIRMED","New cast not confirmed. Check your fishing position and press again; no automatic retry was made.",true)
    end
   end)
  end
 end
 local swap=self.swap
 if swap and C_Timer and C_Timer.After then
  -- Observation only. The off-hand is never equipped from these callbacks.
  C_Timer.After(.15,function() if self.swap==swap then self:CheckSwap(false) end end)
  C_Timer.After(3.1,function() if self.swap==swap then self:CheckSwap(true) end end)
 end
end
function F:SetBindingCapture(active)
 self.bindingCapture=active==true
 if S:InCombat() then self.bindingDirty=true;return false end
 if self.restoreButton and self.bindingCapture then
  if call(self.restoreButton.IsShown,self.restoreButton)==true then self.restorePromptCaptureShown=true end
  clearAction(self.restoreButton);self.restoreButton:Hide()
 elseif self.restorePromptCaptureShown and self.saved and self.restoreWanted and not dead() and not self.fault then
  self:ShowRestorePrompt()
 end
 return self:RefreshBindings()
end
function F:RefreshBindings()
 if not self.owner or S:InCombat() then self.bindingDirty=true;return false end
 self.bindingDirty=false
 if type(ClearOverrideBindings)=="function" then pcall(ClearOverrideBindings,self.owner) end
 if self.bindingCapture or not self:IsEnabled() or dead() or self.fault or not self.secureReady then self:Disarm();return false end
 if type(GetBindingKey)~="function" then return false end
 local ok,a,b=pcall(GetBindingKey,self.action)
 if not ok then return false end
 for _,key in ipairs({txt(a) or false,txt(b) or false}) do
  if key and #key<=100 then
   -- One permanent key -> secure button route. Switching to INTERACTTARGET
   -- during the channel would consume the press before the recast macro runs.
   if type(SetOverrideBindingClick)=="function" then
    pcall(SetOverrideBindingClick,self.owner,true,key,self.buttonName,"LeftButton")
   end
  end
 end
 return true
end
function F:StartChannel()
 if not self:IsEnabled() or S:InCombat() or dead() then return end
 local active,finish=self:ChannelInfo();if active~=true then return end
 self.channel=true;self.pendingPole=nil;self.sequence=self.sequence+1;local token=self.sequence
 self.access="CONFIRMED";self.accessPosition=position();self.sessionPosition=self.accessPosition;self.lastCastAttempt=now()
 if self.saved then self.saved.position=self.sessionPosition;self:SaveEquipment(self.saved) end
 self:SetStatus("CASTING","Line cast. Right-click the bobber to catch fish; press the fishing shortcut to cancel and recast at a new location.",true)
 -- The key remains bound to the secure button throughout the channel. Avoid
 -- rewriting protected overrides from a spellcast event.
 -- A single channel-end watchdog only cleans up missed events. It never casts
 -- or interacts and does not poll water, inventory, sound, or bobber objects.
 if finish and C_Timer and C_Timer.After then
  local delay=math.min(60,math.max(1,finish/1000-now()+1))
  C_Timer.After(delay,function() if self.channel and self.sequence==token and self:ChannelInfo()~=true then self:EndChannel("TIMEOUT") end end)
 end
end
function F:EndChannel(reason)
 local was=self.channel
 self.channel=false;self.sequence=self.sequence+1
 if was then self.suppressRelease=true;self.recentFishingAt=now() end
 -- The first command in a recast macro stops the OLD channel. Do not disarm
 -- its secure button before the second /cast command has been processed.
 if self.recastClick then
  self:SetStatus("RECASTING","Recast requested. Waiting for the new Fishing channel.",true)
  return
 end
 if not self:IsEnabled() then return end
 local access,why=self:AccessCheck()
 if access=="NO_ACCESS" then
  self:SetStatus("NO_ACCESS",why)
  if self.access=="NO_ACCESS" and cfg().restoreWeapons then self:RestoreWeapons("ACCESS_ENDED") end
 elseif not self.restorePending then
  local text=access=="CONFIRMED" and "Ready. Press again to check your pole and cast." or "Water access is unknown. Face water before the next press."
  self:SetStatus("READY",text)
 end
 -- Re-enter preparation only. No following cast is scheduled.
 self:Prepare()
end
function F:RestoreEntry()
 if not self.saved then return nil end
 if self.saved.main.id>0 and not sameEquipment(self.saved.main,MAIN) then return self.saved.main,MAIN end
 if self.saved.off.id>0 and not sameEquipment(self.saved.off,OFF) then return self.saved.off,OFF end
 if self.saved.ranged and self.saved.ranged.id>0 and not sameEquipment(self.saved.ranged,RANGED) then return self.saved.ranged,RANGED end
end
function F:MarkRestoreWanted()
 if not self.saved then return false end
 self.restoreWanted=true;self.saved.restoring=true
 self:SaveEquipment(self.saved)
 return true
end
function F:PrepareRestoreButton(button)
 if not self.secureReady then self:SetStatus("RESTORE_UNAVAILABLE","Secure restoration is unavailable. Equip your weapons in the bags.");return end
 if S:InCombat() or dead() or (CC.SavedData and CC.SavedData.readOnly) then self:SetStatus("RESTORE_WAIT","Restore your weapons after combat and while alive.");return end
 if not self.saved then self:SetStatus("NO_SAVED_WEAPONS","No previous weapons are saved. Start a fishing session with your normal weapons equipped.");return end
 if self.swap then self:SetStatus("SWAPPING","Wait for the current equipment change before pressing again.");return end
 if self:VerifyRestore(false) then return end
 local entry,slot=self:RestoreEntry()
 if not entry then
  self:SetStatus("RESTORE_MANUAL","The saved loadout included an empty slot. Put the extra equipment in your bags to finish restoring.",true);return
 end
 self:MarkRestoreWanted()
 if self:PrepareSwap(button,entry,slot,"RESTORE") then
  self.restorePrepared=true;self.restorePending=true
  self:SetStatus("RESTORING",slot==MAIN and "Restoring your main hand. Press again for remaining equipment if prompted."
   or slot==OFF and "Restoring your saved off-hand." or "Restoring your saved ranged weapon.",true)
 end
end
function F:RequestRestore()
 if not self.saved then return false,"No previous weapons are saved. Begin with your normal weapons equipped." end
 self:MarkRestoreWanted();self.channel=false;self.sequence=self.sequence+1
 if S:InCombat() or dead() then
  self.restoreDeferred=true;return false,"Restoration is prepared. Use the fishing shortcut after combat and while alive."
 end
 if self:VerifyRestore(false) then return true,"Your previous weapons are already equipped." end
 self:Disarm();self:RefreshBindings()
 if self.restoreButton then clearAction(self.restoreButton);self:ShowRestorePrompt() end
 self:SetStatus("RESTORE_READY","Press the fishing shortcut or click Restore weapons. Remaining weapon slots follow the main hand.",true)
 return true,"Press the fishing shortcut or click Restore weapons. Repeat if another saved slot remains."
end
function F:RestoreWeapons(reason)
 -- Event-driven requests only PREPARE restoration. Real player input executes
 -- every swap. This avoids silently failing EquipItemByName calls from timers.
 self.restoreReason=reason
 return self:RequestRestore()
end
function F:VerifyRestore(continue)
 if not self.saved then self.restorePending=false;return end
 if S:InCombat() or dead() then self.restoreDeferred=true;return end
 if self:LoadoutRestored() then
  self.swap=nil;self.pendingPole=nil;self.restoreAttempts={}
  self:SaveEquipment(nil);self:SetStatus("RESTORED","Your previous weapons are equipped.");return true
 end
 if self.restoreWanted and not self.swap then
  self.restorePending=false
  local entry,slot=self:RestoreEntry()
  local text=entry and (slot==OFF and "Main hand restored. Press the fishing shortcut again to restore your off-hand."
   or slot==RANGED and "Press the fishing shortcut again to restore your ranged weapon." or "Press the fishing shortcut to restore your saved main hand.")
   or "Put the extra equipped item in your bags to match the saved empty slot."
  self:SetStatus("RESTORE_READY",text,true)
  if self.restoreButton then clearAction(self.restoreButton);self:ShowRestorePrompt() end
 end
 return false
end
function F:WaterError(message)
 if not txt(message) or not self.lastCastAttempt or now()-self.lastCastAttempt>5 then return false end
 local matched=false
 for _,key in ipairs({"SPELL_FAILED_NOT_FISHABLE","SPELL_FAILED_TOO_SHALLOW","SPELL_FAILED_ONLY_ABOVEWATER"}) do
  local text=_G[key];if txt(text) and message==text then matched=true end
 end
 if not matched then return false end
 self.access="NO_ACCESS";self.accessPosition=position();self.channel=false;self.lastCastAttempt=nil
 self:SetStatus("NO_ACCESS","The cast found no fishable water. Move or face water before trying again.")
 self:RefreshBindings();self:Disarm()
 if cfg().restoreWeapons then self:RestoreWeapons("NO_FISHABLE_WATER") end
 return true
end
function F:Blocked(functionName)
 if not CC.state or CC.state.nativeActionOwner~="Fishing" then return false end
 if not self.lastProtected or now()-self.lastProtected>3 then return false end
 local fn=txt(functionName)
 if fn and not (fn:find("EquipItem",1,true) or fn:find("CastSpell",1,true) or fn:find("RunMacro",1,true) or fn:find("UseContainerItem",1,true) or fn:find("UseItem",1,true)) then return false end
 self.autoRestoreBlocked=true;self.restorePending=false;self.channel=false
 self.fault="FISHING_PROTECTED_ACTION";self.swap=nil;self.pendingPole=nil
 self:SetStatus("RESTRICTED","A fishing action was restricted. Use native controls; no retry was queued.")
 self:RefreshBindings();self:Disarm();return true
end
function F:ApplyProfile()
 if not self.owner then return self:Initialize() end
 if S:InCombat() then self.bindingDirty=true;return end
 if not self:IsEnabled() then
  self.channel=false;self:RefreshBindings();self:Disarm()
  if self.restoreButton then self.restoreButton:Hide();self.restoreButton:SetAttribute("type",nil);self.restorePrepared=nil end
  if self.saved and cfg().restoreWeapons then self:RestoreWeapons("DISABLED") end
  if CC.FishingStatus then CC.FishingStatus:Hide() end
 else self:Prepare();self:RefreshBindings() end
end
function F:OnEvent(event,a,b,c)
 if event=="ADDON_ACTION_BLOCKED" or event=="ADDON_ACTION_FORBIDDEN" then
  if txt(a)==CC.name then self:Blocked(b) end;return
 end
 if event=="PLAYER_REGEN_DISABLED" or event=="PLAYER_DEAD" then
  self.channel=false;self.sequence=self.sequence+1;self.bindingDirty=true
  self.access="UNKNOWN";self.accessPosition=nil
  if self.restorePending or self.restoreWanted then self.restoreDeferred=true end
  if CC.FishingStatus then CC.FishingStatus:Hide() end
  return -- secure state driver clears overrides and disarms protected buttons
 end
 if event=="PLAYER_REGEN_ENABLED" or event=="PLAYER_ALIVE" or event=="PLAYER_UNGHOST" then
  if self.swap then self:CheckSwap(true) end
  if self.restoreDeferred and cfg().restoreWeapons then self.restoreDeferred=false;self:RestoreWeapons("RECOVERY") end
  self:Prepare();self:RefreshBindings();return
 end
 if event=="UPDATE_BINDINGS" then self:RefreshBindings();return end
 if event=="SPELLS_CHANGED" then if not S:InCombat() then self:ResolveSpell();self:Prepare() end;return end
 if event=="PLAYER_ENTERING_WORLD" then
  self.channel=false;self.access="UNKNOWN";self.accessPosition=nil
  self:ApplyProfile()
  if self.restoreWanted and self.saved then self:RequestRestore() end
  if self:IsEnabled() and self:ChannelInfo()==true then self:StartChannel() end
  return
 end
 if event=="PLAYER_LEAVING_WORLD" then
  self.channel=false;self.sequence=self.sequence+1;self.access="UNKNOWN";self.accessPosition=nil
  if CC.FishingStatus then CC.FishingStatus:Hide() end
  self:RefreshBindings();self:Disarm();return
 end
 if event=="PLAYER_EQUIPMENT_CHANGED" or event=="BAG_UPDATE_DELAYED" then
  if S:InCombat() then return end
  local swapping=self.swap~=nil
  if swapping then self:CheckSwap(false) end
  if self.restoreWanted then self:VerifyRestore(false)
  elseif not swapping and event=="PLAYER_EQUIPMENT_CHANGED" and self.saved and not self.pendingPole then
   if self:LoadoutRestored() then self:SaveEquipment(nil)
   elseif num(a)==MAIN and self:IsUnrelatedMainHand() then
    -- A confirmed unrelated manual weapon choice supersedes the snapshot.
    self:SaveEquipment(nil)
   elseif sameEquipment(self.saved.main,MAIN) then
    -- Restoring only the main hand manually must not discard the off-hand.
    self:MarkRestoreWanted();self:VerifyRestore(false)
   end
  end
  return
 end
 if not self:IsEnabled() then return end
 if event=="PLAYER_STARTED_MOVING" or event=="PLAYER_STARTED_TURNING" or event=="PLAYER_STOPPED_TURNING" or event=="ZONE_CHANGED_NEW_AREA" then
  self.access="UNKNOWN";self.accessPosition=nil
  return
 end
 if event=="UI_ERROR_MESSAGE" then self:WaterError(txt(b) or txt(a));return end
 if event=="UNIT_SPELLCAST_CHANNEL_START" then
  if txt(a)=="player" and self:IsFishingSpell(c) then self:StartChannel() end
 elseif event=="UNIT_SPELLCAST_CHANNEL_STOP" or event=="UNIT_SPELLCAST_INTERRUPTED" or event=="UNIT_SPELLCAST_FAILED" then
  if txt(a)=="player" and (self:IsFishingSpell(c) or self.channel and self:ChannelInfo()==false) then self:EndChannel(event) end
 elseif event=="LOOT_OPENED" then
  if S:BoolCall(IsFishingLoot)==true then self.fishingLoot=true;self:SetStatus("LOOT","Collecting the catch follows your game's Auto Loot setting.") end
 elseif event=="LOOT_CLOSED" and self.fishingLoot then self.fishingLoot=false;self:EndChannel("LOOT_FINISHED") end
end
function F:Initialize()
 if self.owner then return end
 if S:InCombat() then return end
 if CC.Inventory then CC.Inventory:Initialize() end
 self:ReadSavedEquipment();self:ResolveSpell()
 local equipped=nativeItem(MAIN)
 if self.saved then
  if self:LoadoutRestored() then self:SaveEquipment(nil)
  elseif self.restoreWanted then -- Preserve a partly restored pair across /reload.
  elseif equipped and self:IsUnrelatedMainHand() then self:SaveEquipment(nil)
  elseif sameEquipment(self.saved.main,MAIN) then self:MarkRestoreWanted() end
 end
 local owner=CreateFrame("Frame","CursorCompanionFishingOwner",UIParent,"SecureHandlerStateTemplate");self.owner=owner
 local button=CreateFrame("Button",self.buttonName,UIParent,"SecureActionButtonTemplate");self.button=button
 local restore=CreateFrame("Button",self.restoreName,UIParent,"SecureActionButtonTemplate");self.restoreButton=restore
 for _,b in ipairs({button,restore}) do b:RegisterForClicks("AnyUp","AnyDown");b:SetAttribute("useOnKeyDown",false);b:Hide() end
 if CC.FishingStatus then CC.FishingStatus:CreateRestorePrompt(restore) end
 button:HookScript("PreClick",function(self,_,down) F:PreClick(self,down,false) end)
 button:HookScript("PostClick",function(_,_,down) F:PostClick(down,false) end)
 restore:HookScript("PreClick",function(self,mouse,down)
  if mouse=="RightButton" then
   if not S:InCombat() then
    self:SetAttribute("type",nil);self:SetAttribute("macrotext",nil);F.restorePrepared=nil
    if not down then self:Hide() end
   end
   return
  end
  F:PreClick(self,down,true)
 end)
 restore:HookScript("PostClick",function(_,_,down) F:PostClick(down,true) end)
 local ok=pcall(function()
  owner:SetFrameRef("cast",button);owner:SetFrameRef("restore",restore)
  owner:SetAttribute("_onstate-fishing",[[
   if newstate == "blocked" then
    self:ClearBindings();self:GetFrameRef("cast"):SetAttribute("type",nil);self:GetFrameRef("restore"):SetAttribute("type",nil)
    self:GetFrameRef("restore"):Hide()
   end
  ]])
  if type(RegisterStateDriver)~="function" then error("NO_SECURE_STATE_DRIVER") end
  RegisterStateDriver(owner,"fishing","[combat] blocked; [dead] blocked; ready")
 end)
 self.secureReady=ok
 local frame=CreateFrame("Frame");self.frame=frame
 for _,event in ipairs({"PLAYER_ENTERING_WORLD","PLAYER_LEAVING_WORLD","PLAYER_REGEN_DISABLED","PLAYER_REGEN_ENABLED","PLAYER_DEAD","PLAYER_ALIVE","PLAYER_UNGHOST","UPDATE_BINDINGS","SPELLS_CHANGED","PLAYER_EQUIPMENT_CHANGED","BAG_UPDATE_DELAYED","PLAYER_STARTED_MOVING","PLAYER_STARTED_TURNING","PLAYER_STOPPED_TURNING","ZONE_CHANGED_NEW_AREA","UNIT_SPELLCAST_CHANNEL_START","UNIT_SPELLCAST_CHANNEL_STOP","UNIT_SPELLCAST_INTERRUPTED","UNIT_SPELLCAST_FAILED","UI_ERROR_MESSAGE","LOOT_OPENED","LOOT_CLOSED","ADDON_ACTION_BLOCKED","ADDON_ACTION_FORBIDDEN"}) do pcall(frame.RegisterEvent,frame,event) end
 frame:SetScript("OnEvent",function(_,event,...)
  local success=pcall(self.OnEvent,self,event,...)
  if not success then
   self.fault="FISHING_EVENT_FAILED";self.channel=false;self:RefreshBindings();self:Disarm()
   if CC.Diagnostics then CC.Diagnostics:OptionalFault("FISHING_EVENT_FAILED") end
  end
 end)
 self:ApplyProfile()
end
