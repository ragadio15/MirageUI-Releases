local _,CC=...
local S=CC.Safety
CC.Inventory={items={},observers={},dirty=true,revision=0,requests={},reason="NOT_SCANNED"}
local I=CC.Inventory
local function num(v) return S:IsNumber(v) and v or nil end
local function txt(v) return S:IsText(v) and v or nil end
local function field(t,k) return S:Field(t,k) end
local function call(fn,...)
 if type(fn)~="function" then return nil end
 local ok,v=pcall(fn,...);if ok and S:IsReadable(v) then return v end
end
local function copy(t)
 local r={};for k,v in pairs(t) do if type(v)~="table" then r[k]=v end end;return r
end
local function itemID(value)
 if not S:IsReadable(value) then return nil end
 if type(value)=="string" then value=tonumber(value:match("^%s*(%d+)%s*$") or value:match("item:(%d+)")) end
 if num(value) and value>0 and value%1==0 then return value end
end
local function metadata(id)
 local r={id=id,count=0,loaded=false,usable=false,slots={}}
 local fn=C_Item and C_Item.GetItemInfo or GetItemInfo
 if type(fn)=="function" then
  local ok,name,link,quality,level,required,_,_,stack,equipLoc,icon,_,classID,subclassID=pcall(fn,id)
  if ok then
   r.name=txt(name);r.link=txt(link);r.icon=num(icon) or txt(icon);r.quality=num(quality)
   r.itemLevel=num(level);r.requiredLevel=num(required);r.stackSize=num(stack)
   r.equipLoc=txt(equipLoc);r.classID=num(classID);r.subclassID=num(subclassID)
   r.loaded=r.name~=nil and r.requiredLevel~=nil and r.itemLevel~=nil
  end
 end
 local instant=C_Item and C_Item.GetItemInfoInstant or GetItemInfoInstant
 if type(instant)=="function" then
  local ok,_,_,_,loc,icon,classID,subclassID=pcall(instant,id)
  if ok then
   r.equipLoc=r.equipLoc or txt(loc);r.icon=r.icon or num(icon) or txt(icon)
   r.classID=r.classID or num(classID);r.subclassID=r.subclassID or num(subclassID)
  end
 end
 local level=num(call(UnitLevel,"player"))
 r.usable=r.loaded and level~=nil and r.requiredLevel<=level
 -- Runtime item usability can be false simply because mana/health is full or
 -- the player is moving. Level eligibility is the stable preparation gate.
 -- A player click remains subject to Blizzard's actual use requirements.
 local catalog=CC.ConsumableCatalog
 local row=catalog and (catalog.food[id] or catalog.drink[id])
 if row then r.kind=row.kind;r.tier=row.tier;r.standard=true end
 return r
end
local function bagLimit()
 local n=num(NUM_TOTAL_EQUIPPED_BAG_SLOTS) or num(NUM_BAG_SLOTS) or 4
 return math.min(7,math.max(4,n))
end
local function guidAt(bag,slot)
 if not (ItemLocation and type(ItemLocation.CreateFromBagAndSlot)=="function" and C_Item and type(C_Item.GetItemGUID)=="function") then return nil end
 local ok,loc=pcall(ItemLocation.CreateFromBagAndSlot,ItemLocation,bag,slot)
 if not ok then return nil end
 return txt(call(C_Item.GetItemGUID,loc))
end
function I:Subscribe(owner,callback)
 if owner~=nil and type(callback)=="function" then self.observers[owner]=callback end
end
function I:Unsubscribe(owner) self.observers[owner]=nil end
function I:Notify()
 for owner,callback in pairs(self.observers) do
  local ok=pcall(callback,owner,self.revision)
  if not ok and CC.Diagnostics then CC.Diagnostics:OptionalFault("INVENTORY_SUBSCRIBER") end
 end
end
function I:MarkDirty(reason)
 self.dirty=true;self.reason=reason or "BAGS_CHANGED"
 if self.scheduled or S:InCombat() then return end
 if C_Timer and type(C_Timer.After)=="function" then
  self.scheduled=true
  C_Timer.After(0.15,function() self.scheduled=false;self:Refresh() end)
 end
end
function I:Refresh(force)
 if S:InCombat() then self.dirty=true;return false,"COMBAT_DEFERRED" end
 if self.refreshing or (not force and not self.dirty) then return not self.dirty end
 self.refreshing=true
 local ok,err=pcall(function()
  local getSlots=C_Container and C_Container.GetContainerNumSlots or GetContainerNumSlots
  local getInfo=C_Container and C_Container.GetContainerItemInfo
  local getID=C_Container and C_Container.GetContainerItemID or GetContainerItemID
  local getLink=C_Container and C_Container.GetContainerItemLink or GetContainerItemLink
  if type(getSlots)~="function" or (type(getInfo)~="function" and type(getID)~="function") then
   self.reason="INVENTORY_API_UNAVAILABLE";return
  end
  local items={};local missing={};local free=0;local readable=true
  for bag=0,bagLimit() do
   local slots=num(call(getSlots,bag))
   if slots and slots>=0 and slots<=100 then
    local freeFn=C_Container and C_Container.GetContainerNumFreeSlots or GetContainerNumFreeSlots
    if type(freeFn)=="function" then
     local valid,count,family=pcall(freeFn,bag)
     if valid and num(count) and num(family) and family==0 then free=free+math.max(0,count) end
    end
    for slot=1,slots do
     local info=call(getInfo,bag,slot)
     local id=itemID(field(info,"itemID")) or itemID(call(getID,bag,slot))
     if id then
      local r=items[id]
      if not r then r=metadata(id);items[id]=r;if not r.loaded then missing[id]=true end end
      local count=num(field(info,"stackCount"));local locked=field(info,"isLocked")
      if not count and type(GetContainerItemInfo)=="function" and not getInfo then
       local valid,_,legacyCount,legacyLocked=pcall(GetContainerItemInfo,bag,slot)
       if valid then count=num(legacyCount);if S:IsReadable(legacyLocked) then locked=legacyLocked end end
      end
      if not count then count=1 end
      if not S:IsReadable(locked) or type(locked)~="boolean" then locked=true end
      local link=txt(field(info,"hyperlink")) or txt(call(getLink,bag,slot))
      r.count=r.count+count
      r.slots[#r.slots+1]={bag=bag,slot=slot,count=count,locked=locked,link=link,guid=guidAt(bag,slot)}
      if locked==false then r.availableCount=(r.availableCount or 0)+count end
     elseif info~=nil then readable=false end
    end
   elseif slots==nil then readable=false end
  end
  self.items=items;self.freeGeneral=free;self.readable=readable;self.dirty=false
  self.revision=self.revision+1;self.reason=readable and "READY" or "PARTIAL_INVENTORY"
  local request=C_Item and C_Item.RequestLoadItemDataByID
  if type(request)=="function" then
   for id in pairs(missing) do
    if not self.requests[id] then self.requests[id]=true;pcall(request,id) end
   end
  end
  self:Notify()
 end)
 self.refreshing=false
 if not ok then self.reason="INVENTORY_SCAN_FAILED";self.dirty=true;if CC.Diagnostics then CC.Diagnostics:OptionalFault("INVENTORY_SCAN_FAILED") end end
 return ok and not self.dirty,err or self.reason
end
function I:GetItem(value)
 local id=itemID(value);if not id then return nil end
 if self.dirty and not S:InCombat() and not self.refreshing then self:Refresh() end
 local r=self.items[id]
 if r then return r end
 -- A configured item can be missing from the bags; retain metadata with a
 -- zero count so Utility can display the chosen item without changing it.
 r=metadata(id)
 if not r.loaded and not self.requests[id] and C_Item and type(C_Item.RequestLoadItemDataByID)=="function" and not S:InCombat() then
  self.requests[id]=true;pcall(C_Item.RequestLoadItemDataByID,id)
 end
 return r
end
function I:BestConsumable(kind)
 if kind~="food" and kind~="drink" then return nil end
 if self.dirty and not S:InCombat() and not self.refreshing then self:Refresh() end
 local best
 for _,r in pairs(self.items) do
  if r.kind==kind and r.standard and r.loaded and r.usable and (r.availableCount or 0)>0 then
   if not best or r.requiredLevel>best.requiredLevel
      or (r.requiredLevel==best.requiredLevel and r.tier>best.tier)
      or (r.requiredLevel==best.requiredLevel and r.tier==best.tier and r.itemLevel>best.itemLevel)
      or (r.requiredLevel==best.requiredLevel and r.tier==best.tier and r.itemLevel==best.itemLevel and r.id<best.id) then best=r end
  end
 end
 return best
end
function I:IsPole(id)
 local r=self:GetItem(id);if not r then return false end
 local class=Enum and Enum.ItemClass and Enum.ItemClass.Weapon or 2
 local subclass=Enum and Enum.ItemWeaponSubclass and (Enum.ItemWeaponSubclass.Fishingpole or Enum.ItemWeaponSubclass.FishingPole) or 20
 return r.classID==class and r.subclassID==subclass
end
function I:GetPoles()
 if self.dirty and not S:InCombat() and not self.refreshing then self:Refresh() end
 local out={}
 for id,r in pairs(self.items) do if self:IsPole(id) and r.loaded and r.usable and (r.availableCount or 0)>0 then out[#out+1]=r end end
 table.sort(out,function(a,b) if a.itemLevel~=b.itemLevel then return a.itemLevel>b.itemLevel end;return a.id<b.id end)
 return out
end
function I:FindSlot(value,guid,link)
 local r=self:GetItem(value);if not r then return nil end
 local candidates={};local readableGUID=false
 for _,slot in ipairs(r.slots) do
  if not slot.locked then
   if not guid and not link then return slot end
   if guid and slot.guid==guid then return slot end
   if slot.guid then readableGUID=true end
   if not link or slot.link==link then candidates[#candidates+1]=slot end
  end
 end
 -- Never substitute another readable GUID. When item GUIDs are unavailable,
 -- a single matching link/candidate is the only safe fallback.
 if guid and readableGUID then return nil end
 if #candidates==1 then return candidates[1] end
end
function I:FreeGeneralSlots()
 if self.dirty and not S:InCombat() and not self.refreshing then self:Refresh() end
 return self.freeGeneral or 0
end
function I:Initialize()
 if self.frame then return end
 local f=CreateFrame("Frame");self.frame=f
 for _,event in ipairs({"BAG_UPDATE_DELAYED","GET_ITEM_INFO_RECEIVED","ITEM_DATA_LOAD_RESULT","PLAYER_LEVEL_UP","PLAYER_ENTERING_WORLD","PLAYER_EQUIPMENT_CHANGED","PLAYER_REGEN_ENABLED"}) do pcall(f.RegisterEvent,f,event) end
 f:SetScript("OnEvent",function(_,event,id)
  if (event=="GET_ITEM_INFO_RECEIVED" or event=="ITEM_DATA_LOAD_RESULT") and itemID(id) then
   if not self.requests[id] and not self.items[id] then return end
  end
  self:MarkDirty(event)
 end)
 self:Refresh(true)
end
