local _,CC=...
local P=CC.ContextBackend
CC.Context={accum=0,generation=0}
function CC.Context:Needed()
 local p=CC.profile
 for _,r in pairs(p.rings) do if r.enabled and (r.role=="Spell range" or r.role=="Relationship") then return true end end
 return false
end
function CC.Context:Invalidate()
 P.state.generation=P.state.generation+1;self.latest=nil;self.accum=0.2
end
function CC.Context:Reset()
 P.lanes={};P.selected=nil;P.probes={};P.state.armed=false
 P.state.source=CC.profile.info.source;P.state.brackets=CC.profile.info.brackets
 P.state.configVersion=P.state.configVersion+1;self:Invalidate()
 self.reason="INACTIVE";self.ready=false;self.quarantined=false
 if not CC.profile.enabled or not CC.state.inWorld or not CC.Capabilities.context or not self:Needed() then return end
 if CC.Safety:InCombat() then self.reason="RECONFIGURE_OUT_OF_COMBAT";return end
 if CC.profile.info.reference~="" then P.selected,self.selectionReason=P:ResolveSpell(CC.profile.info.reference) end
 if CC.profile.info.brackets then
  local seen={}
  for token in CC.profile.info.probes:gmatch("[^,;]+") do
   if #P.probes>=7 then break end
   token=token:match("^%s*(.-)%s*$")
   local s=P:ResolveSpell(token)
   if s and s.min==0 and s.max>5 and not seen[s.id] then P.probes[#P.probes+1]=s;seen[s.id]=true end
  end
 end
 self.ready=true;self.reason="READY";P.state.armed=true
end
function CC.Context:Tick(elapsed)
 if not self:Needed() or not CC.Capabilities.context then self.latest=nil;return end
 if not self.ready then return end
 self.accum=self.accum+elapsed
 if self.accum<0.2 then return end;self.accum=0
 P.state.sampleQueries=0
 local s=P:SampleContext()
 P:SampleRange(s,CC.Safety:InCombat())
 s.time=P:Now();if not s.time then self.latest=nil;return end;self.latest=s;CC.Diagnostics.sampleCount=CC.Diagnostics.sampleCount+1
end
function CC.Context:Get()
 local s=self.latest
 if not s or s.generation~=P.state.generation then return nil end
 local now=GetTime();if not CC.Safety:IsNumber(now) or now-s.time>0.25 or now<s.time then return nil end
 return s
end
function CC.Context:Stop() self.latest=nil;P.state.armed=false end
