local _,CC=...
local P=CC.ContextBackend
function P:ResolveSpell(input)
    if type(input)~="string" or #input==0 or #input>512 then return nil,"ENTER_SPELL_NAME_OR_ID" end
    local identifier=input:match("spell:(%d+)") or input
    if identifier:match("^%d+$") then identifier=tonumber(identifier) end
    local info,reason=self:Read("spell_info",C_Spell and C_Spell.GetSpellInfo,identifier)
    if reason~="READABLE" then return nil,"SPELL_INFO_"..reason end
    local id=self:Field(info,"spellID"); local name=self:Field(info,"name")
    local minimum=self:Field(info,"minRange"); local maximum=self:Field(info,"maxRange")
    if not self:Number(id) or id<1 or id%1~=0 or type(name)~="string" or #name>200
        or not self:Number(minimum) or not self:Number(maximum) or minimum<0 or maximum<=0
        or maximum<minimum or maximum>200 then return nil,"INVALID_OR_UNREADABLE_SPELL_METADATA" end
    -- Spellbook membership alone can include unknown override abilities. Require actual player knowledge.
    local known,ks=self:Scalar("spell_known",C_SpellBook and C_SpellBook.IsSpellKnown,"boolean",id)
    if ks~="READABLE" or not known then return nil,"SPELL_NOT_KNOWN_OR_UNREADABLE" end
    local harmful,hs=self:Scalar("spell_harmful",C_Spell and C_Spell.IsSpellHarmful,"boolean",id)
    if hs~="READABLE" or not harmful then return nil,"SELECT_A_HARMFUL_PLAYER_SPELL" end
    local ranged,rs=self:Scalar("spell_hasrange",C_Spell and C_Spell.SpellHasRange,"boolean",id)
    if rs~="READABLE" or not ranged then return nil,"SPELL_HAS_NO_VALIDATED_RANGE" end
    local passive,ps=self:Scalar("spell_passive",C_Spell and C_Spell.IsSpellPassive,"boolean",id)
    if ps~="READABLE" or passive then return nil,"PASSIVE_OR_UNREADABLE_SPELL" end
    local override,os=self:Scalar("spell_override",C_Spell and C_Spell.GetOverrideSpell,"number",id)
    if os~="READABLE" or override<1 or override%1~=0 then return nil,"OVERRIDE_UNRESOLVED" end
    if override~=id then return nil,"SELECT_OVERRIDE_ID_EXPLICITLY_"..tostring(override) end
    return {id=id,name=name,min=minimum,max=maximum},"VALIDATED_METADATA_NOT_DISTANCE"
end
