local _,CC=...
-- F6: one read-only quest/location authority for Compass and Notes.
-- No database, route invention, game quest-state mutations, or combat polling.
CC.QuestNavigation={dirty=true,scans=0,cacheHits=0,revision=0,rows={},byID={},
 tombstones={},history={},clock=0,selected=nil,selectionReason="NONE",status="NOT_RUN"}
local N=CC.QuestNavigation
local pi=math.pi
local function call(fn,...)
 if type(fn)~="function" then return nil end
 local ok,a,b,c=pcall(fn,...)
 if not ok then return nil end
 if not CC.Safety:IsReadable(a) then a=nil end
 if not CC.Safety:IsReadable(b) then b=nil end
 if not CC.Safety:IsReadable(c) then c=nil end
 return a,b,c
end
local function number(v) return CC.Safety:IsNumber(v) end
local function natural(v) return number(v) and v>0 and v%1==0 end
local function xy(vector)
 if not CC.Safety:IsReadable(vector) then return nil end
 local kind=type(vector)
 if kind~="table" and kind~="userdata" then return nil end
 local ok,x,y=pcall(function() return vector.x,vector.y end)
 if ok and number(x) and number(y) then return x,y end
 local okMethod,method=pcall(function() return vector.GetXY end)
 if okMethod and type(method)=="function" then
  local a,b=call(method,vector)
  if number(a) and number(b) then return a,b end
 end
 return nil
end
local function field(row,key)
 if not CC.Safety:IsReadable(row) or type(row)~="table" then return nil end
 if type(canaccesstable)=="function" and CC.Safety:BoolCall(canaccesstable,row)~=true then return nil end
 local ok,value=pcall(function()return row[key] end)
 if ok and CC.Safety:IsReadable(value) then return value end
end
local function atan2(y,x)
 if math.atan2 then return math.atan2(y,x) end
 if x>0 then return math.atan(y/x) end
 if x<0 then return math.atan(y/x)+(y>=0 and pi or -pi) end
 return y>0 and pi/2 or y<0 and -pi/2 or 0
end
function N:RelativeAngle(px,py,tx,ty,facing)
 if not (number(px) and number(py) and number(tx) and number(ty) and number(facing)) then return nil end
 local dx,dy=tx-px,ty-py
 if dx*dx+dy*dy<.0025 then return nil end
 -- WoW world X points north, Y west; GetPlayerFacing grows counterclockwise.
 local a=atan2(dy,dx)-facing
 return (a+pi)%(2*pi)-pi
end
function N:MapWorld(mapID,x,y)
 if not (natural(mapID) and number(x) and number(y) and x>=0 and x<=1 and y>=0 and y<=1) then return end
 if not (C_Map and type(C_Map.GetWorldPosFromMapPos)=="function") then return end
 local point=type(CreateVector2)=="function" and CreateVector2(x,y) or {x=x,y=y}
 local continent,world=call(C_Map.GetWorldPosFromMapPos,mapID,point)
 local wx,wy=xy(world)
 -- The instance ID zero is valid, including Eastern Kingdoms.
 if number(continent) and continent>=0 and continent%1==0 and wx and wy then return continent,wx,wy end
end
function N:PlayerMap()
 if not C_Map then return end
 local mapID=call(C_Map.GetBestMapForUnit,"player")
 if not natural(mapID) then return end
 if type(C_Map.GetPlayerMapPosition)=="function" then
  local pos=call(C_Map.GetPlayerMapPosition,mapID,"player")
  local x,y=xy(pos)
  if number(x) and number(y) and x>=0 and x<=1 and y>=0 and y<=1 then return mapID,x,y end
 end
end
function N:PlayerWorld()
 if not C_Map then return end
 local mapID,x,y=self:PlayerMap()
 if mapID then
  local continent,wx,wy=self:MapWorld(mapID,x,y)
  if continent then return continent,wx,wy,mapID end
 end
 mapID=mapID or call(C_Map.GetBestMapForUnit,"player")
 if not natural(mapID) then return end
 -- Only a fallback; never assume UnitPosition uses the same map coordinates.
 if type(UnitPosition)=="function" then
  local ok,wx,wy,_,continent=pcall(UnitPosition,"player")
  if ok and number(wx) and number(wy) and number(continent) and continent>=0 then
   return continent,wx,wy,mapID
  end
 end
end
function N:MapChain(mapID)
 local chain,seen={},{}
 for _=1,5 do
  if not natural(mapID) or seen[mapID] then break end
  chain[#chain+1]=mapID;seen[mapID]=true
  local info=C_Map and call(C_Map.GetMapInfo,mapID)
  local parent=field(info,"parentMapID") -- no boolean branch on secret map metadata
  if not natural(parent) then break end
  mapID=parent
 end
 return chain
end
function N:WatchedIDs()
 local ids,seen={},{}
 if not C_QuestLog then return ids,seen end
 for _,names in ipairs({{"GetNumQuestWatches","GetQuestIDForQuestWatchIndex"},
                      {"GetNumWorldQuestWatches","GetQuestIDForWorldQuestWatchIndex"}}) do
  local count=call(C_QuestLog[names[1]])
  if number(count) then
   for index=1,math.min(40,math.max(0,math.floor(count))) do
    local id=call(C_QuestLog[names[2]],index)
    if natural(id) and not seen[id] then seen[id]=true;ids[#ids+1]=id end
   end
  end
 end
 -- Selected and supertracked quests are explicit Blizzard player choices.
 for _,id in ipairs({C_SuperTrack and call(C_SuperTrack.GetSuperTrackedQuestID) or 0,
                       call(C_QuestLog.GetSelectedQuest) or 0}) do
  if natural(id) and not seen[id] then seen[id]=true;ids[#ids+1]=id end
 end
 return ids,seen
end
function N:MapPOIs(chain)
 local records={}
 if not (C_QuestLog and type(C_QuestLog.GetQuestsOnMap)=="function") then return records end
 for _,mapID in ipairs(chain) do
  local entries=call(C_QuestLog.GetQuestsOnMap,mapID)
  if CC.Safety:IsReadable(entries) and type(entries)=="table"
     and (type(canaccesstable)~="function" or CC.Safety:BoolCall(canaccesstable,entries)==true) then
   local count=call(function() return #entries end)
   if number(count) then
    for i=1,math.min(80,math.floor(count)) do
     local entry=field(entries,i)
     local id=entry and field(entry,"questID")
     local x=entry and field(entry,"x")
     local y=entry and field(entry,"y")
     local starting=entry and field(entry,"isQuestStart")
     if natural(id) and number(x) and number(y) and starting~=true then
      records[#records+1]={id=id,mapID=mapID,x=x,y=y,inProgress=field(entry,"inProgress")}
     end
    end
   end
  end
 end
 return records
end
local function boolean(fn,...)
 local value=call(fn,...)
 if type(value)=="boolean" then return value end
end
local function text(value) return CC.Safety:IsText(value) and value~="" and value or nil end
local function options() return CC.profile and CC.profile.compass or {} end
function N:Now()
 local t=call(GetTime)
 return number(t) and t or self.clock
end
function N:PinnedID()
 if CC.Wayfinder and CC.Wayfinder:IsManaged() then return CC.Wayfinder:PinnedQuestID() end
 local store=CC.SavedData and CC.SavedData.character
 local nav=store and store.navigation
 local id=type(nav)=="table" and nav.pinnedQuestID
 return natural(id) and id or nil
end
function N:ClearPin()
 if CC.Wayfinder then
  CC.Wayfinder:Sync(0,true)
  if CC.Wayfinder:IsManaged() then return CC.Wayfinder:SelectQuest(0) end
 end
 self.absentPin=nil;self.absentSince=nil
 local store=CC.SavedData and CC.SavedData.character
 if store and not CC.SavedData.readOnly then store.navigation=nil end
 self:Invalidate("PIN_CLEARED")
end
function N:SetPin(id)
 if CC.Safety:InCombat() then return false,"Leave combat before changing quest focus." end
 if CC.SavedData.readOnly or not CC.SavedData.character then return false,"Settings are read-only." end
 if not CC.Safety:IsReadable(id) then return false,"Quest identity unavailable." end
 if CC.Wayfinder then
  CC.Wayfinder:Sync(0,true)
  if CC.Wayfinder:IsManaged() then return CC.Wayfinder:SelectQuest(id) end
 end
 if id==nil or id==0 then self:ClearPin();return true end
 if not natural(id) or self.tombstones[id] then return false,"Choose an active quest in Quest Notes." end
 local active=C_QuestLog and boolean(C_QuestLog.IsOnQuest,id)
 local index=C_QuestLog and call(C_QuestLog.GetLogIndexForQuestID,id)
 if active~=true and not natural(index) and not self.byID[id] then return false,"Quest is not currently available." end
 CC.SavedData.character.navigation={pinnedQuestID=id}
 self:Invalidate("PIN_CHANGED")
 return true
end
function N:SupertrackedID()
 if not C_SuperTrack then return nil end
 if boolean(C_SuperTrack.IsSuperTrackingQuest)==false then return nil end
 local id=call(C_SuperTrack.GetSuperTrackedQuestID)
 return natural(id) and not self.tombstones[id] and id or nil
end
function N:Invalidate(reason)
 self.dirty=true;self.lastReason=reason or "QUEST_UPDATE"
end
function N:Refresh()
 if CC.Wayfinder then
  CC.Wayfinder:Sync(0,true)
  if CC.Wayfinder:IsManaged() then
   local api=CC.Wayfinder.api
   if api and type(api.Refresh)=="function" then call(api.Refresh) end
   CC.Wayfinder.dirty=true;self:Invalidate("SHARED_REFRESH");return
  end
 end
 -- A deliberate user refresh may recheck a same-location turn-in. This uses
 -- newly read Blizzard coordinates, never an inferred NPC or fabricated route.
 -- Automatic refreshes retain the stale-objective guard.
 local id=self:PinnedID() or (self.selected and self.selected.id)
 if id then self.history[id]=nil end
 self:Invalidate("MANUAL_REFRESH")
end
function N:OnEvent(event,id,second)
 -- Event payloads may be restricted. Never index, compare or coerce before validation.
 if event=="QUEST_REMOVED" or event=="QUEST_TURNED_IN" then
  if natural(id) then
   self.removedOrder=self.removedOrder or {}
   if not self.tombstones[id] then self.removedOrder[#self.removedOrder+1]=id end
   self.tombstones[id]=true;self.history[id]=nil
   if CC.QuestRoute then CC.QuestRoute:OnQuestRemoved(id) end
   while #self.removedOrder>256 do self.tombstones[table.remove(self.removedOrder,1)]=nil end
   -- Wayfinder owns removal/focus reconciliation while connected. Keep the
   -- dormant standalone preference intact until its own mode resumes.
   if not (CC.Wayfinder and CC.Wayfinder:IsManaged()) and self:PinnedID()==id then self:ClearPin() end
  end
 elseif event=="QUEST_ACCEPTED" then
  local accepted=natural(second) and second or id
  if natural(accepted) then
   self.tombstones[accepted]=nil;self.history[accepted]=nil
   for i=#(self.removedOrder or {}),1,-1 do
    if self.removedOrder[i]==accepted then table.remove(self.removedOrder,i) end
   end
  end
 elseif event=="PLAYER_ENTERING_WORLD" or event=="ZONE_CHANGED_NEW_AREA" then
  self.mapID=nil;self.rows={};self.byID={};self.selected=nil
  if CC.QuestRoute then CC.QuestRoute:Reset(false) end
 end
 self:Invalidate(event)
end
-- F7: only readable objective counters contribute to ranking, never completion.
function N:Progress(id)
 local raw=C_QuestLog and call(C_QuestLog.GetQuestObjectives,id)
 if not CC.Safety:IsReadable(raw) or type(raw)~="table" then return nil end
 if type(canaccesstable)~="function" or CC.Safety:BoolCall(canaccesstable,raw)~=true then return nil end
 local count=call(function()return #raw end)
 if not number(count) or count<1 or count>40 then return nil end
 local total=0
 for i=1,count do
  local entry=field(raw,i)
  local done=field(entry,"finished")
  local have,need=field(entry,"numFulfilled"),field(entry,"numRequired")
  if done==true then total=total+1
  elseif number(have) and number(need) and have>=0 and need>0 then total=total+math.min(1,have/need)
  else return nil end -- unknown progress is not zero
 end
 return total/count
end
function N:RouteMapUsable(mapID)
 -- Validate both axes; all-zero/degenerate Forever map transforms must not
 -- turn unrelated points into a fictitious zero-distance cluster.
 local c,x,y=self:MapWorld(mapID,.25,.25)
 local cx,xx,xy=self:MapWorld(mapID,.75,.25)
 local cy,yx,yy=self:MapWorld(mapID,.25,.75)
 if c==nil or cx~=c or cy~=c then return false end
 local determinant=(xx-x)*(yy-y)-(xy-y)*(yx-x)
 return number(determinant) and math.abs(determinant)>.001
end
function N:Metadata(id)
 local title=C_QuestLog and text(call(C_QuestLog.GetTitleForQuestID,id))
 if not title and C_QuestLog then
  local index=call(C_QuestLog.GetLogIndexForQuestID,id)
  local info=natural(index) and call(C_QuestLog.GetInfo,index)
  title=text(field(info,"title"))
 end
 local complete=C_QuestLog and boolean(C_QuestLog.IsComplete,id)
 local failed=C_QuestLog and boolean(C_QuestLog.IsFailed,id)
 local stage=failed==true and "FAILED" or complete==true and "READY_FOR_TURN_IN"
  or complete==false and "OBJECTIVES" or "UNKNOWN"
 return title or ("Quest #"..id),stage,
  C_QuestLog and text(call(C_QuestLog.GetNextWaypointText,id)) or nil
end
local function rank(row)
 -- Retain the F5 fallback: watched route > watched marker > active marker.
 return row.route and 3 or row.watched and 2 or 1
end
local function nearer(a,b)
 if rank(a)~=rank(b) then return rank(a)>rank(b) end
 if a.distSq~=b.distSq then return a.distSq<b.distSq end
 return a.id<b.id
end
function N:Collect(c,px,py,mapID)
 local ids,seen=self:WatchedIDs()
 local watched={};for _,id in ipairs(ids) do watched[id]=true end
 local pin=self:PinnedID();local super=self:SupertrackedID()
 if pin and not seen[pin] then ids[#ids+1]=pin;seen[pin]=true end
 if super and not seen[super] then ids[#ids+1]=super;seen[super]=true end
 self.watchedCount=#ids;self.poiCount=0
 local byID={};local chain=self:MapChain(mapID)
 local function entry(id)
  if not natural(id) or self.tombstones[id] then return nil end
  if not byID[id] then byID[id]={id=id,questID=id,watched=watched[id]==true,locationState="NO_LOCATION"} end
  return byID[id]
 end
 local function consider(id,targetMap,x,y,source,route,priority)
  local row=entry(id);if not row then return end
  if not (natural(targetMap) and number(x) and number(y) and x>=0 and x<=1 and y>=0 and y<=1) then return end
  local tc,wx,wy=self:MapWorld(targetMap,x,y)
  if tc==nil then row.locationState=row.x and "LOCATED" or "NO_MAP_TRANSFORM";return end
  if tc~=c then row.locationState=row.x and "LOCATED" or "OTHER_WORLD";return end
  local d=(wx-px)^2+(wy-py)^2
  if not number(d) then return end
  if row.x and (row.locationPriority>priority or (row.locationPriority==priority and row.distSq<=d)) then return end
  row.x,row.y,row.continent,row.mapID=wx,wy,tc,targetMap
  row.distSq=d;row.approxDistance=math.sqrt(d);row.distance2=d
  row.locationPriority=priority;row.route=route;row.source=source
  row.confidence=route and "BLIZZARD_WAYPOINT" or "APPROXIMATE_MAP_AREA"
  row.locationState="LOCATED"
  row.key=id..":"..targetMap..":"..string.format("%.3f:%.3f",wx,wy)
 end
 if C_QuestLog then
  for _,id in ipairs(ids) do
   if entry(id) then
    local map,x,y=call(C_QuestLog.GetNextWaypoint,id)
    consider(id,map,x,y,id==super and "SUPERTRACKED_WAYPOINT" or "WATCHED_WAYPOINT",true,map==mapID and 5 or 4)
    if type(C_QuestLog.GetNextWaypointForMap)=="function" then
     for _,candidateMap in ipairs(chain) do
      local mx,my=call(C_QuestLog.GetNextWaypointForMap,id,candidateMap)
      consider(id,candidateMap,mx,my,"ZONE_WAYPOINT",true,candidateMap==mapID and 6 or 3)
     end
    end
   end
  end
  for _,poi in ipairs(self:MapPOIs(chain)) do
   self.poiCount=self.poiCount+1
   local active=boolean(C_QuestLog.IsOnQuest,poi.id)
   if seen[poi.id] or active==true or (active==nil and poi.inProgress==true) then
    consider(poi.id,poi.mapID,poi.x,poi.y,seen[poi.id] and "WATCHED_MAP_POI" or "ACTIVE_MAP_POI",false,1)
   end
  end
 end
 local rows,history={},{}
 local routeEnabled=CC.QuestRoute and CC.QuestRoute:Enabled()
 local routeMaps={}
 for id,row in pairs(byID) do
  row.name,row.stage,row.waypointText=self:Metadata(id)
  if routeEnabled and row.mapID==mapID and row.locationState=="LOCATED" then
   if routeMaps[mapID]==nil then routeMaps[mapID]=self:RouteMapUsable(mapID) end
   row.routeMapUsable=routeMaps[mapID]
   row.progress=self:Progress(id)
  end
  local previous=self.history[id]
  -- Completion is a native quest state, not a proximity test. If the client
  -- still exposes the old objective location, wait for new location evidence.
  if previous and row.stage~="OBJECTIVES" then
   if row.stage=="READY_FOR_TURN_IN" and previous.stage=="OBJECTIVES" then
    row.blockedKey=previous.key;row.blockedText=previous.waypointText
   elseif previous.blockedKey then
    row.blockedKey=previous.blockedKey;row.blockedText=previous.blockedText
   end
   if row.blockedKey then
    local newLocation=row.key and row.key~=row.blockedKey
    local newInstruction=row.waypointText and row.waypointText~=row.blockedText
    if newLocation or newInstruction then row.blockedKey=nil;row.blockedText=nil
    elseif row.key then row.locationState="AWAITING_TURN_IN_LOCATION" end
   end
  end
  history[id]={key=row.key,stage=row.stage,waypointText=row.waypointText,
   blockedKey=row.blockedKey,blockedText=row.blockedText}
  rows[#rows+1]=row
 end
 -- History is bounded by this scan, never an ever-growing quest database.
 self.history=history;self.rows=rows;self.byID=byID
 self.scans=self.scans+1;self.revision=self.revision+1
 self.lastScan=self:Now();self.mapID=mapID;self.continent=c;self.dirty=false
end
function N:Choose(px,py)
 local pin=self:PinnedID();local super=(options().selectionMode=="Focused" or options().routeMode=="Follow route") and self:SupertrackedID() or nil
 local requested=pin or super
 if requested then
  self.selectionReason=pin and "PINNED" or "SUPERTRACKED"
  return self.byID[requested]
 end
 if options().routeMode=="Follow route" and CC.QuestRoute then
  local target=CC.QuestRoute:Target(self.byID)
  self.selectionReason=target and "EXPERIMENTAL_ROUTE" or "NO_LOCAL_ROUTE"
  return target
 end
 local best
 for _,row in ipairs(self.rows) do
  if row.locationState=="LOCATED" and row.stage~="FAILED" and row.x then
   if not best or nearer(row,best) then best=row end
  end
 end
 self.selectionReason="NEAREST"
 if options().stableTarget and self.selected and best and self.selected.id~=best.id then
  local old=self.byID[self.selected.id]
  if old and old.locationState=="LOCATED" and old.stage~="FAILED" and rank(old)==rank(best) then
   -- Stay on the current target unless the alternative is at least 20% and
   -- ten yards closer. A two-second hold avoids switching back immediately.
   local gain=old.approxDistance-best.approxDistance
   if self:Now()-(self.switchedAt or 0)<2 or gain<10 or best.approxDistance>old.approxDistance*.8 then
    self.selectionReason="NEAREST_STABLE";return old
   end
  end
 end
 return best
end
function N:Snapshot(force)
 if CC.Wayfinder then
  CC.Wayfinder:Sync(0,force)
  if CC.Wayfinder:IsManaged() then
   local rows,status,selected,player=CC.Wayfinder:QuestSnapshot()
   self.rows=rows;self.byID={};for _,row in ipairs(rows) do self.byID[row.questID]=row end
   self.selected=selected;self.player=player;self.status=status;self.sharedOwner=true
   self.selectionReason="WAYFINDER";return rows,status,selected,player
  elseif self.sharedOwner then
   self.sharedOwner=nil;self.rows={};self.byID={};self.selected=nil;self.player=nil
   self.dirty=true;self.lastScan=nil
  end
 end
 if CC.Safety:InCombat() then
  -- The destination is the last readable quest location, not a cached bearing.
  -- Only fresh player geometry is read in combat; expensive quest discovery,
  -- automatic quest switching and experimental route rebuilds wait for combat
  -- to end. Explicit removal/world events make the cached target ineligible.
  local c,px,py,mapID=self:PlayerWorld()
  local selected=self.selected
  if selected and self.tombstones[selected.id] then selected=nil;self.selected=nil end
  if selected then selected.approxDistance=nil;selected.combatCached=true end
  if c==nil then self.status="NO_POSITION";return self.rows,self.status,selected,nil end
  self.player={continent=c,x=px,y=py,mapID=mapID}
  if not selected then self.status="QUEST_SCAN_DEFERRED";return self.rows,self.status,nil,self.player end
  if selected.continent~=c then self.status="OTHER_WORLD";return self.rows,self.status,selected,self.player end
  if selected.locationState~="LOCATED" or not number(selected.x) or not number(selected.y) then
   self.status=selected.locationState or "NO_LOCATION";return self.rows,self.status,selected,self.player
  end
  selected.distSq=(selected.x-px)^2+(selected.y-py)^2
  selected.approxDistance=math.sqrt(selected.distSq)
  self.status="LOCATED";return self.rows,self.status,selected,self.player
 end
 if not (C_Map and C_QuestLog) then self.status="NO_API";self.selected=nil;if CC.QuestRoute then CC.QuestRoute:Suspend(self.status) end;return {},self.status end
 local c,px,py,mapID=self:PlayerWorld()
 if c==nil then self.status="NO_POSITION";self.selected=nil;if CC.QuestRoute then CC.QuestRoute:Suspend(self.status) end;return {},self.status end
 -- A persisted pin is cleared only with a complete readable log and explicit
 -- absence. Nil/secret/missing API is not proof that a quest was removed.
 local pin=self:PinnedID()
 if pin and C_QuestLog then
  local count=call(C_QuestLog.GetNumQuestLogEntries)
  local on=boolean(C_QuestLog.IsOnQuest,pin)
  local index=call(C_QuestLog.GetLogIndexForQuestID,pin)
  if number(count) and count>=0 and on==false and not natural(index) then
   if self.absentPin~=pin then self.absentPin=pin;self.absentSince=self:Now()
   elseif self:Now()-(self.absentSince or self:Now())>=1.25 then self:ClearPin();self.absentPin=nil end
  else self.absentPin=nil;self.absentSince=nil end
 end
 local now=self:Now()
 if force or self.dirty or self.mapID~=mapID or self.continent~=c or not self.lastScan or now-self.lastScan>=1.25 then
  self:Collect(c,px,py,mapID)
 else self.cacheHits=self.cacheHits+1 end
 for _,row in ipairs(self.rows) do
  row.combatCached=nil
  if row.x then
   row.distSq=(row.x-px)^2+(row.y-py)^2;row.distance2=row.distSq;row.approxDistance=math.sqrt(row.distSq)
  end
 end
 self.player={continent=c,x=px,y=py,mapID=mapID}
 if CC.QuestRoute then
  local requested=self:PinnedID() or ((options().selectionMode=="Focused" or options().routeMode=="Follow route") and self:SupertrackedID() or nil)
  local ok=pcall(CC.QuestRoute.Update,CC.QuestRoute,self.rows,self.player,requested,now,self.revision)
  if not ok then
   CC.QuestRoute:Suspend("UNAVAILABLE")
   if not self.routeFaultReported then self.routeFaultReported=true;CC.Diagnostics:OptionalFault("QUEST_ROUTE_UNAVAILABLE") end
  end
 end
 local previous=self.selected and self.selected.id
 local selected=self:Choose(px,py)
 if (selected and selected.id)~=previous then self.switchedAt=now end
 self.selected=selected
 local pinned=self:PinnedID()
 for _,row in ipairs(self.rows) do row.pinned=row.id==pinned;row.guiding=selected==row end
 self.player={continent=c,x=px,y=py,mapID=mapID}
 self.status=selected and (selected.stage=="FAILED" and "QUEST_FAILED" or selected.locationState)
  or (options().routeMode=="Follow route" and "NO_LOCAL_ROUTE" or (#self.rows==0 and "NO_QUEST_DATA" or "NO_READABLE_QUEST_LOCATION"))
 return self.rows,self.status,selected,self.player
end
function N:SmoothAngle(current,target,dt,snap)
 if not number(target) then return nil end
 if snap or not number(current) or not number(dt) then return target end
 local delta=(target-current+pi)%(2*pi)-pi
 if math.abs(delta)>pi*.6 then return target end
 return (current+delta*(1-math.exp(-math.max(0,math.min(dt,.25))/.10))+pi)%(2*pi)-pi
end
function N:Summary()
 local row=self.selected
 return "Navigation="..self.status.." | selection="..self.selectionReason.." | pinned="..tostring(self:PinnedID() or 0)
  .." | quest="..tostring(row and row.id or 0).." | stage="..tostring(row and row.stage or "NONE")
  .." | location="..tostring(row and row.locationState or "NONE").." | source="..tostring(row and row.source or "NONE")
  .." | scans="..self.scans.." cache="..self.cacheHits
end
