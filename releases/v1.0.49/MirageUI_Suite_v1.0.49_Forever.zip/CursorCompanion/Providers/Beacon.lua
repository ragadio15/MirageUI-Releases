local _,CC=...
-- F8.2: quiet group snapshots, never continuous location tracking. The existing
-- CCBEACON v1 location packet is preserved; optional controls use a separate
-- prefix so older clients can still exchange ordinary publications.
CC.Beacon={prefix="CCBEACON",controlPrefix="CCBCONTROL",version=1,status="OFF",kind="Beacon",elapsed=0,
 sent=0,received=0,rejected=0,sequence=0,history={},receiveTimes={},transforms={},peers={},controlTimes={}}
local B,S=CC.Beacon,CC.Safety
local SCALE=1000000
local function call(fn,...)
 if type(fn)~="function" then return end
 local ok,a,b,c,d=pcall(fn,...);if not ok then return end
 if not S:IsReadable(a) then a=nil end;if not S:IsReadable(b) then b=nil end
 if not S:IsReadable(c) then c=nil end;if not S:IsReadable(d) then d=nil end
 return a,b,c,d
end
local function integer(v,low,high) return S:IsNumber(v) and v%1==0 and v>=low and v<=high end
local function field(t,k) return S:Field(t,k) end
local function safeText(value,limit)
 if not S:IsText(value) then return nil end
 local clean=value:gsub("[|%c]","")
 if clean=="" or #clean>(limit or 120) then return nil end
 return clean
end
local function enum(kind,name) return S:Value(function()return Enum and Enum[kind] and Enum[kind][name]end) end
local function successful(kind,result)
 if not S:IsReadable(result) then return false end
 if result==true then return true end
 local success=enum(kind,"Success")
 return S:IsNumber(success) and S:IsNumber(result) and result==success
end
local function resultOf(first,last)
 if S:IsReadable(last) and last~=nil then return last end
 return S:IsReadable(first) and first or nil
end
local function pref() return CC.profile and CC.profile.beacon or {} end
function B:Now() local n=call(GetServerTime);return integer(n,1,4102444800) and n or nil end
function B:Clock() local n=call(GetTime);return S:IsNumber(n) and n>=0 and n or nil end
function B:Enabled()
 local p=CC.profile
 return p and p.enabled==true and p.compass and p.compass.enabled==true and p.compass.mode=="Beacon"
  and not (CC.SavedData and CC.SavedData.readOnly) and not (CC.ClientIdentity and CC.ClientIdentity.allowed==false)
end
function B:Reject(reason)
 self.rejected=math.min(99999,self.rejected+1);self.lastReject=reason;return false,reason
end
function B:Reset(reason)
 self.status=reason or "OFF";self.angle=nil;self.distance=nil;self.arrived=false;self.stale=false
 self.transmissionType=nil;self.name=nil;self.sender=nil;self.age=nil;self.zone=nil;self.selection=nil;self.key=nil;self.elapsed=0
end
function B:Clear(reason)
 self.active=nil;self.held=false;self.acknowledged={};self.ackCount=0;self.syncPending=nil
 self:Reset(reason or "WAITING_BEACON")
 -- Preserve the ordering fence: delayed traffic cannot resurrect a cleared pin.
end
function B:ForgetGroup(reason)
 if CC.NativePings then CC.NativePings:ClearGroup() end
 self:Clear(reason or "NO_GROUP");self.orderFence=nil;self.history={};self.receiveTimes={};self.controlTimes={}
 self.roster={};self.rosterByGUID={};self.rosterAvailable=false;self.peers={};self.groupEpoch=(self.groupEpoch or 0)+1
 self.syncScheduled=false;self.syncStatus=nil;self.lastSync=nil
end
function B:Invalidate(reason)
 self.angle=nil;self.distance=nil;self.elapsed=.15
 self.status=self.active and "REFRESHING" or (self:Enabled() and "WAITING_BEACON" or "OFF")
 if reason=="NEW_BEACON" then self.arrived=false;self.stale=false;self.zone=nil end
 if reason=="PLAYER_ENTERING_WORLD" or reason=="ZONE_CHANGED_NEW_AREA" or reason=="COMBAT_CHANGED" then self.transforms={} end
end
function B:OnProfileChanged()
 local enabled=self:Enabled();local was=self.modeEnabled;self.modeEnabled=enabled
 if enabled then
  if self.active and self.active.nativePing and pref().nativePings==false then self:Clear("WAITING_BEACON") end
  self:Initialize();self:RefreshRoster()
  if self.active and self.rosterAvailable then
   local member=self.roster[self.active.sender]
   if member and not self:AcceptSender(member) then self:Clear("SENDER_FILTERED") end
  end
  self:Invalidate("PROFILE_CHANGED")
  if not was then self:ScheduleSync() end
 else self.syncPending=nil;self:Reset("OFF") end
end
function B:NormalizeName(name)
 -- Group identities come from the event sender and current unit roster, not
 -- a claimed packet name or a GUID that can differ across clients.
 if not S:IsText(name) or name:find("[|%c]") then return nil end
 name=safeText(name,120);if not name then return nil end
 local who,realm=name:match("^([^%-]+)%-(.+)$")
 if not who then who=name;realm=call(GetNormalizedRealmName) or call(GetRealmName) end
 realm=safeText(realm,80);if not realm or who:find("%s") then return nil end
 return who.."-"..realm:gsub("%s","")
end
function B:UnitName(unit)
 local name,realm=call(UnitFullName,unit)
 if not S:IsText(name) then name,realm=call(UnitName,unit) end
 return S:IsText(name) and self:NormalizeName(name..(S:IsText(realm) and realm~="" and "-"..realm or "")) or nil
end
function B:GroupChannel()
 local instance=type(LE_PARTY_CATEGORY_INSTANCE)=="number" and LE_PARTY_CATEGORY_INSTANCE or nil
 local home=type(LE_PARTY_CATEGORY_HOME)=="number" and LE_PARTY_CATEGORY_HOME or nil
 if instance and S:BoolCall(IsInGroup,instance)==true then return "INSTANCE_CHAT",instance,S:BoolCall(IsInRaid,instance)==true end
 if S:BoolCall(IsInGroup,home)~=true then return nil end
 local raid=S:BoolCall(IsInRaid,home)==true;return raid and "RAID" or "PARTY",home,raid
end
function B:RefreshRoster()
 local channel,category,raid=self:GroupChannel();self.rosterAt=self:Clock()
 if not channel then self.channel=nil;self.groupCategory=nil;self:ForgetGroup("NO_GROUP");return false end
 if self.groupCategory~=nil and category~=self.groupCategory then self:ForgetGroup("GROUP_CHANGED") end
 self.channel=channel;self.groupCategory=category
 local count=call(GetNumGroupMembers,category)
 if not integer(count,1,40) then self.rosterAvailable=false;return false end
 local roster,byGUID={},{}
 local function add(unit)
  local full=self:UnitName(unit);if not full then return false end
  local guid=call(UnitGUID,unit)
  local member={name=full,key=full,unit=unit,
   leader=S:BoolCall(UnitIsGroupLeader,unit,category)==true,assistant=S:BoolCall(UnitIsGroupAssistant,unit,category)==true}
  -- GUID is optional diagnostics only; it is not the cross-client ordering key.
  if S:IsText(guid) and #guid<=100 and guid~="" then member.guid=guid;byGUID[guid]=member end
  roster[full]=member;return true
 end
 local complete=true
 if raid then for i=1,count do if not add("raid"..i) then complete=false end end
 else
  if count>5 or not add("player") then complete=false end
  for i=1,math.min(4,count-1) do if not add("party"..i) then complete=false end end
 end
 local own=self:UnitName("player")
 if not own or not roster[own] then complete=false end
 if not complete then self.rosterAvailable=false;return false end
 -- No non-player overlap means a new group even when no solo event was seen.
 if self.rosterAvailable and self.roster and self.localName then
  local hadOther,overlap=false,false
  for name in pairs(self.roster) do if name~=self.localName then hadOther=true;if roster[name] then overlap=true end end end
  if hadOther and not overlap then self:ForgetGroup("GROUP_CHANGED") end
 end
 self.localName=own;self.roster=roster;self.rosterByGUID=byGUID;self.rosterAvailable=true
 for name in pairs(self.history) do if not roster[name] then self.history[name]=nil;self.receiveTimes[name]=nil end end
 for name in pairs(self.peers) do if not roster[name] then self.peers[name]=nil end end
 for name in pairs(self.controlTimes) do if not roster[name] then self.controlTimes[name]=nil end end
 for name in pairs(self.receiveTimes) do if not roster[name] then self.receiveTimes[name]=nil end end
 if self.acknowledged then
  self.ackCount=0
  for name in pairs(self.acknowledged) do if roster[name] then self.ackCount=self.ackCount+1 else self.acknowledged[name]=nil end end
 end
 if self.active and not roster[self.active.sender] then self:Clear("SENDER_LEFT") end
 return true
end
function B:EnsureRoster()
 local now=self:Clock()
 if not self.rosterAvailable or not now or not self.rosterAt or now-self.rosterAt>=2 then return self:RefreshRoster() end
 return true
end
function B:Initialize()
 if not self.frame and type(CreateFrame)=="function" then
  self.frame=CreateFrame("Frame")
  for _,event in ipairs({"CHAT_MSG_ADDON","GROUP_ROSTER_UPDATE","PLAYER_ENTERING_WORLD","PLAYER_LEAVING_WORLD","ZONE_CHANGED_NEW_AREA"}) do pcall(self.frame.RegisterEvent,self.frame,event) end
  self.frame:SetScript("OnEvent",function(_,event,...)
   local ok=pcall(B.OnEvent,B,event,...)
   if not ok then
    B.angle=nil;B.distance=nil;B.status="PROVIDER_ERROR"
    if not B.eventFaultReported and CC.Diagnostics then B.eventFaultReported=true;CC.Diagnostics:OptionalFault("BEACON_EVENT_ERROR") end
   end
  end)
 end
 if not (C_ChatInfo and type(C_ChatInfo.RegisterAddonMessagePrefix)=="function" and type(C_ChatInfo.SendAddonMessage)=="function") then self.transportStatus="NO_ADDON_CHANNEL";return false end
 local function register(prefix)
  local a,b=call(C_ChatInfo.RegisterAddonMessagePrefix,prefix)
  return S:BoolCall(C_ChatInfo.IsAddonMessagePrefixRegistered,prefix)==true or successful("RegisterAddonMessagePrefixResult",resultOf(a,b))
 end
 if not self.registered then self.registered=register(self.prefix) end
 if not self.controlRegistered then self.controlRegistered=register(self.controlPrefix) end
 self.transportStatus=self.registered and "READY" or "PREFIX_UNAVAILABLE"
 return self.registered
end
function B:OnEvent(event,...)
 if event=="CHAT_MSG_ADDON" then self:Receive(...)
 elseif event=="PLAYER_LEAVING_WORLD" then self.syncPending=nil;self:Reset("WORLD_TRANSITION")
 elseif event=="GROUP_ROSTER_UPDATE" then self:RefreshRoster();self:Invalidate(event);if not self.active then self:ScheduleSync() end
 elseif event=="PLAYER_ENTERING_WORLD" then self:Initialize();self:RefreshRoster();self:Invalidate(event);self:ScheduleSync()
 elseif event=="ZONE_CHANGED_NEW_AREA" then self:Invalidate(event) end
end
function B:Decode(payload)
 if not S:IsText(payload) or #payload>180 then return nil,"MALFORMED" end
 local stamp,order,session,seq,map,x,y=payload:match("^1;(%d+);(%d+);([%x%-]+);(%d+);(%d+);(%d+);(%d+)$")
 if not stamp or #session>32 or #session<3 then return nil,"PROTOCOL" end
 stamp,order,seq,map,x,y=tonumber(stamp),tonumber(order),tonumber(seq),tonumber(map),tonumber(x),tonumber(y)
 if not integer(stamp,1,4102444800) or not integer(order,1,1000000) or not integer(seq,1,2147483647)
  or not integer(map,1,10000000) or not integer(x,0,SCALE) or not integer(y,0,SCALE) then return nil,"BOUNDS" end
 return {stamp=stamp,order=order,session=session,seq=seq,mapID=map,mapX=x/SCALE,mapY=y/SCALE}
end
function B:Encode(record)
 return table.concat({"1",record.stamp,record.order,record.session,record.seq,record.mapID,
  math.floor(record.mapX*SCALE+.5),math.floor(record.mapY*SCALE+.5)},";")
end
local function newer(a,b)
 if not b then return true end
 for _,key in ipairs({"stamp","order","sender","session","seq"}) do if a[key]~=b[key] then return a[key]>b[key] end end
 return false
end
function B:AcceptSender(member)
 return member.name==self.localName or pref().acceptFrom~="Leader and assistants" or member.leader or member.assistant
end
function B:ValidAge(record,sync)
 local now=self:Now();if not now or record.stamp>now+5 then return false end
 local age=now-record.stamp
 local limit=sync and 86400 or 120
 local expiration=pref().expiration
 if sync and S:IsNumber(expiration) and expiration>0 then limit=math.min(limit,expiration) end
 return age<=limit
end
function B:SendControl(payload,channel,target)
 if not self.controlRegistered or not S:IsText(payload) or #payload>240 then return false end
 local ok,a,b=pcall(C_ChatInfo.SendAddonMessage,self.controlPrefix,payload,channel,target)
 return ok and successful("SendAddonMessageResult",resultOf(a,b))
end
function B:Acknowledge(record)
 if record.sender==self.localName then return end
 -- One receipt per publication; duplicates must not generate a whisper storm.
 if self.lastAck==record.id then return end
 if self:SendControl("A;"..record.session..";"..record.seq,"WHISPER",record.sender) then self.lastAck=record.id end
end
function B:NotifySignal(origin,previous,record,enriched)
 if not record then return end
 local A=CC.AlertConditions
 local function alert(key)
  if A and type(A.QueueEvent)=="function" then
   local okay=pcall(A.QueueEvent,A,key)
   if not okay and CC.Diagnostics then CC.Diagnostics:OptionalFault("BEACON_ALERT_ERROR") end
  end
 end
 if origin=="sent" then
  self.sentEvents=(self.sentEvents or 0)+1;alert("beaconSent")
 elseif origin=="received" then
  self.receivedEvents=(self.receivedEvents or 0)+1;alert("beaconReceived")
 end
 if enriched or (previous and previous.id~=record.id) then
  self.updatedEvents=(self.updatedEvents or 0)+1;alert("beaconUpdated")
 end
end
function B:Adopt(record,member,localSend)
 record.sender=member.name;record.guid=member.guid;record.id=member.name..":"..record.session..":"..record.seq
 if not localSend and self.held then return self:Reject("HELD") end
 if not localSend and self.active and self.active.nativePing and record.stamp<self.active.stamp then return self:Reject("OLDER_THAN_NATIVE") end
 if not localSend and not self:AcceptSender(member) then return self:Reject("SENDER_FILTER") end
 local old=self.history[member.name]
 if old and old.session==record.session and record.seq<=old.seq then return self:Reject("DUPLICATE") end
 if not newer(record,self.orderFence) then return self:Reject("OLDER") end
 self.history[member.name]={session=record.session,seq=record.seq}
 record.transmissionType="beacon";record.source="GROUP_BEACON";record.location="MAP_SNAPSHOT"
 local previous=self.active
 self.orderFence=record;self.active=record;self.acknowledged={};self.ackCount=0;self.held=false
 self.name="Beacon";self.sender=member.name;self.key=record.id;self.selection=record
 self.source="GROUP_BEACON";self.confidence="PLAYER_LOCATION_SNAPSHOT"
 if not localSend then self.received=math.min(99999,self.received+1);self:Acknowledge(record) end
 self.transmissionType="beacon"
 if CC.NativePings then CC.NativePings:Record(record) end
 self:Invalidate("NEW_BEACON");self:NotifySignal(localSend and "sent" or "received",previous,record);return true
end
function B:Receive(prefix,payload,channel,sender)
 if not self:Enabled() or not (CC.state and CC.state.inWorld) then return false,"INACTIVE" end
 if S:IsText(prefix) and CC.NativePings and prefix==CC.NativePings.targetPrefix then return CC.NativePings:ReceiveTarget(payload,channel,sender) end
 if not S:IsText(prefix) or (prefix~=self.prefix and prefix~=self.controlPrefix) then return false,"PREFIX" end
 if not S:IsText(channel) or not self:EnsureRoster() then return self:Reject("CHANNEL_OR_ROSTER") end
 local full=self:NormalizeName(sender);local member=full and self.roster[full]
 if not member then return self:Reject("NOT_IN_GROUP") end
 if prefix==self.controlPrefix then return self:ReceiveControl(payload,channel,member) end
 if channel~=self.channel then return self:Reject("CHANNEL") end
 local record,why=self:Decode(payload);if not record then return self:Reject(why) end
 if not self:ValidAge(record,false) then return self:Reject("EXPIRED_PACKET") end
 local clock=self:Clock();local prior=self.receiveTimes[full]
 if clock and prior and clock-prior<.2 then return self:Reject("RATE_LIMIT") end
 self.receiveTimes[full]=clock
 return self:Adopt(record,member,false)
end
function B:ReceiveControl(payload,channel,member)
 if not S:IsText(payload) or #payload>240 or member.name==self.localName then return false,"CONTROL" end
 local clock=self:Clock();if not clock then return false,"NO_CLOCK" end
 if channel~="WHISPER" and channel~=self.channel then return self:Reject("CONTROL_CHANNEL") end
 local action=payload:sub(1,1)
 if action~="A" and action~="Q" and action~="S" then return self:Reject("CONTROL_PROTOCOL") end
 local times=self.controlTimes[member.name] or {};self.controlTimes[member.name]=times
 local interval=action=="Q" and 3 or .2
 if times[action] and clock-times[action]<interval then return self:Reject("CONTROL_RATE_LIMIT") end
 times[action]=clock
 if action=="A" then
  if channel~="WHISPER" then return self:Reject("ACK_CHANNEL") end
  local session,sequence=payload:match("^A;([%x%-]+);(%d+)$");sequence=tonumber(sequence)
  local active=self.active
  if not session or #session>32 or not active or active.sender~=self.localName or active.session~=session or active.seq~=sequence then return self:Reject("ACK_MISMATCH") end
  self.acknowledged=self.acknowledged or {};self.acknowledged[member.name]=true;self.ackCount=0
  for _ in pairs(self.acknowledged) do self.ackCount=self.ackCount+1 end
  self.peers[member.name]=clock;return true
 elseif action=="Q" then
  if channel~=self.channel then return self:Reject("SYNC_CHANNEL") end
  local token=payload:match("^Q;([%x%-]+)$")
  if not token or #token>48 or #token<3 then return self:Reject("SYNC_TOKEN") end
  self.peers[member.name]=clock
  local active=self.active
  -- Only the ORIGINAL sender can supply a recovery record. No peer may
  -- impersonate the publisher by forwarding someone else's coordinates.
  if not active or active.nativePing or active.sender~=self.localName or not self:ValidAge(active,true) then return false,"NO_OWN_BEACON" end
  return self:SendControl("S;"..token..";"..self:Encode(active),"WHISPER",member.name)
 else
  if channel~="WHISPER" then return self:Reject("SYNC_REPLY_CHANNEL") end
  local token,packet=payload:match("^S;([%x%-]+);(.+)$")
  local pending=self.syncPending
  if not pending or token~=pending.token or clock>pending.untilTime or pending.epoch~=(self.groupEpoch or 0) then return self:Reject("UNSOLICITED_SYNC") end
  local record,why=self:Decode(packet);if not record then return self:Reject(why) end
  if not self:ValidAge(record,true) then return self:Reject("EXPIRED_SYNC") end
  if self.active and self.active.nativePing then return false,"NEW_NATIVE_SIGNAL" end
  local accepted,reason=self:Adopt(record,member,false)
  if accepted then self.syncStatus="RECOVERED";self.peers[member.name]=clock end
  return accepted,reason
 end
end
function B:Session()
 local now,clock=self:Now(),self:Clock();if not now or not clock then return nil end
 if not self.session or self.sequence>=2147483647 then self.session=string.format("%x-%x",now,math.floor(clock*1000)%2147483647);self.sequence=0 end
 return self.session
end
function B:RequestSync()
 if not self:Enabled() or not (CC.state and CC.state.inWorld) then return false,"Enable Beacon before requesting a group waypoint." end
 if self.held then return false,"This Beacon is held. Release it before requesting another destination." end
 if not self:Initialize() or not self.controlRegistered then return false,"Beacon recovery is unavailable on this client." end
 if not self:RefreshRoster() then return false,"Join a party or raid before requesting its Beacon." end
 local clock=self:Clock();local session=self:Session()
 if not clock or not session then return false,"Beacon could not read a reliable clock." end
 if self.lastSync and clock-self.lastSync<5 then return false,"A Beacon recovery request was just sent." end
 self.lastSync=clock;self.syncSequence=(self.syncSequence or 0)+1
 local token=session.."-"..string.format("%x",self.syncSequence%2147483647)
 self.syncPending={token=token,untilTime=clock+5,epoch=self.groupEpoch or 0};self.syncStatus="REQUESTED"
 if not self:SendControl("Q;"..token,self.channel) then self.syncPending=nil;self.syncStatus="SEND_FAILED";return false,"The game did not confirm the Beacon recovery request." end
 local pending=self.syncPending
 if C_Timer and C_Timer.After then C_Timer.After(5.1,function()
  if self.syncPending==pending then self.syncPending=nil;if self.syncStatus=="REQUESTED" then self.syncStatus="NO_REPLY" end end
 end) end
 return true,"Requested the group's latest Beacon quietly. The original sender must still be present with F8.2 or newer."
end
function B:ScheduleSync()
 if pref().autoSync==false or not self:Enabled() or self.active or self.held or self.syncScheduled then return end
 if not (C_Timer and C_Timer.After) then return end
 self.syncScheduled=true;local epoch=self.groupEpoch or 0
 C_Timer.After(.6,function()
  self.syncScheduled=false
  if epoch==(self.groupEpoch or 0) and self:Enabled() and not self.active and pref().autoSync~=false then self:RequestSync() end
 end)
end
function B:SetHeld(held)
 if held and not self.active then return false,"Receive or publish a Beacon before holding it." end
 self.held=held==true
 if self.held and CC.Wayfinder then
  local ok,reason=CC.Wayfinder:SelectBeacon(self.active)
  if not ok then return false,"Beacon is held, but Wayfinder could not select it: "..tostring(reason) end
 end
 return true,self.held and "Beacon held. Incoming publications will not replace this destination." or "Beacon released. New publications can replace it; /cc beacon sync requests the current group waypoint."
end
function B:Publish()
 if not self:Enabled() then return false,"Select Beacon in Outside cursor settings first." end
 if not (CC.state and CC.state.inWorld) then return false,"Beacon is unavailable during a world transition." end
 if not self:Initialize() then return false,"Beacon's addon channel is unavailable on this client." end
 if not self:RefreshRoster() then return false,"Join a party or raid with a readable roster before sharing a Beacon." end
 local now,clock=self:Now(),self:Clock();if not now or not clock or not self:Session() then return false,"Beacon could not read a reliable clock." end
 if self.lastSend and clock-self.lastSend<2 then return false,"Wait a moment before sharing another Beacon." end
 local map,x,y=CC.QuestNavigation:PlayerMap()
 if not integer(map,1,10000000) or not S:IsNumber(x) or not S:IsNumber(y) or x<0 or x>1 or y<0 or y>1 then return false,"Your current map coordinates are unavailable. Beacon was not shared." end
 local member=self.roster[self.localName];if not member then return false,"Your group identity is unavailable. Beacon was not shared." end
 self.sequence=self.sequence+1
 local stamp=self.orderFence and math.max(now,self.orderFence.stamp) or now
 local order=self.orderFence and self.orderFence.stamp==stamp and self.orderFence.order+1 or 1
 if order>1000000 then return false,"Wait a moment before sharing another Beacon." end
 local record={stamp=stamp,order=order,session=self.session,seq=self.sequence,mapID=map,mapX=x,mapY=y}
 self.lastSend=clock
 local ok,a,b=pcall(C_ChatInfo.SendAddonMessage,self.prefix,self:Encode(record),self.channel)
 local result=resultOf(a,b)
 self.lastSendResult=S:IsNumber(result) and result or (result==true and "true" or "unavailable")
 if not ok or not successful("SendAddonMessageResult",result) then
  self.transportStatus="SEND_FAILED";return false,"WoW did not confirm Beacon transmission. Your previous Beacon is unchanged."
 end
 self.transportStatus="READY";self.sent=math.min(99999,self.sent+1);self:Adopt(record,member,true)
 if CC.Wayfinder then
  local selected,reason=CC.Wayfinder:SelectBeacon(record)
  if not selected then return true,"Beacon sent. Wayfinder kept its destination: "..tostring(reason) end
 end
 return true,"Beacon sent quietly. Compatible F8.2 receivers can confirm receipt; /cc beacon shows confirmations."
end
function B:TransformUsable(mapID)
 if not integer(mapID,1,10000000) then return false end
 local cached=self.transforms[mapID];local now=self:Clock()
 if not cached or (not cached.usable and (not now or not cached.at or now-cached.at>=1)) then
  self.transforms[mapID]={usable=CC.QuestNavigation:RouteMapUsable(mapID)==true,at=now}
  local count=0;for _ in pairs(self.transforms) do count=count+1 end
  if count>32 then local value=self.transforms[mapID];self.transforms={[mapID]=value} end
 end
 return self.transforms[mapID].usable
end
local function dungeonMap(mapID)
 local info=C_Map and call(C_Map.GetMapInfo,mapID);local kind=field(info,"mapType");local dungeon=enum("UIMapType","Dungeon")
 return S:IsNumber(kind) and S:IsNumber(dungeon) and kind==dungeon
end
function B:Tick(dt)
 if not self:Enabled() then self:Reset("OFF");return end
 if not (CC.state and CC.state.inWorld) then self:Reset("WORLD_TRANSITION");return end
 if not S:IsNumber(dt) or dt<0 then self:Reset("UNAVAILABLE");return end
 self.elapsed=self.elapsed+math.min(dt,.25)
 local clock=self:Clock()
 if self.elapsed<.15 and self.lastTick and clock and clock-self.lastTick<.15 then return end
 self.elapsed=0;self.lastTick=clock;self.angle=nil;self.distance=nil
 if not self:EnsureRoster() then self.arrived=false;self.status=self.channel and "NO_ROSTER" or "NO_GROUP";return end
 local active=self.active
 if not active then
  local retained={BEACON_EXPIRED=true,PING_EXPIRED=true,SENDER_LEFT=true,CLEARED=true}
  if not retained[self.status] then self.status="WAITING_BEACON" end
  return
 end
 if active.nativePing and CC.NativePings then
  if CC.NativePings:Tick(active,self) then return end
 end
 local now=self:Now();self.age=now and math.max(0,now-active.stamp) or nil
 local options=pref();local expiration=options.expiration
 if S:IsNumber(expiration) and expiration>0 and self.age and self.age>=expiration then self:Clear("BEACON_EXPIRED");return end
 local staleAfter=options.staleAfter or 120;self.stale=staleAfter>0 and self.age~=nil and self.age>=staleAfter
 self.sender=active.sender;self.name=active.name or "Beacon";self.key=active.id;self.selection=active;self.transmissionType=active.transmissionType or "beacon"
 local info=C_Map and call(C_Map.GetMapInfo,active.mapID);self.zone=safeText(field(info,"name"),120) or ("Map "..active.mapID)
 local nav=CC.QuestNavigation;local c,px,py,map=nav:PlayerWorld()
 if not S:IsNumber(c) or not S:IsNumber(px) or not S:IsNumber(py) then self.arrived=false;self.status="NO_POSITION";return end
 if not self:TransformUsable(active.mapID) or not self:TransformUsable(map) then self.arrived=false;self.status="NO_MAP_TRANSFORM";return end
 local tc,tx,ty=nav:MapWorld(active.mapID,active.mapX,active.mapY)
 if not S:IsNumber(tc) or not S:IsNumber(tx) or not S:IsNumber(ty) then self.arrived=false;self.status="NO_MAP_TRANSFORM";return end
 if tc~=c then self.arrived=false;self.status="OTHER_WORLD";return end
 if map~=active.mapID and (dungeonMap(map) or dungeonMap(active.mapID)) then self.arrived=false;self.status="OTHER_FLOOR";return end
 local distance=math.sqrt((tx-px)^2+(ty-py)^2)
 if not S:IsNumber(distance) then self.arrived=false;self.status="NO_POSITION";return end
 self.distance=distance
 local compass=CC.profile.compass;local radius=compass.arrivalRadius or 8
 self.arrived=compass.arrivalCue==true and distance<=(self.arrived and radius+4 or radius)
 if self.arrived then self.status="NEAR_DESTINATION";return end
 local facing=call(GetPlayerFacing);if not S:IsNumber(facing) then self.status="NO_FACING";return end
 self.angle=nav:RelativeAngle(px,py,tx,ty,facing)
 self.status=self.angle and "GUIDING" or "DESTINATION_REACHED"
end
function B:DeliveryText()
 if not self.active or self.active.nativePing or self.active.sender~=self.localName then return nil end
 local count=self.ackCount or 0
 return count>0 and (count..(count==1 and " receiver confirmed" or " receivers confirmed")) or "Sent; no receiver confirmation"
end
function B:Get() return self end
function B:Summary()
 return "Beacon="..self.status.." | transport="..(self.transportStatus or "NOT_RUN").." | sent="..self.sent.." | received="..self.received
  .." | confirmed="..(self.ackCount or 0).." | held="..tostring(self.held==true).." | recovery="..(self.syncStatus or "NOT_REQUESTED")
  .." | active="..tostring(self.active~=nil).." | rejected="..self.rejected.." | last_reject="..(self.lastReject or "NONE")
end
