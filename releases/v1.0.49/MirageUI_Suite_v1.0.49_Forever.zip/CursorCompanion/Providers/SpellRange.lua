local _,CC=...
local P=CC.ContextBackend
function P:RangeResult(id,unit,cache)
    if cache[id] then return cache[id].verdict,cache[id].reason end
    if self.state.sampleQueries>=self.maxQueries then return "UNKNOWN","QUERY_BUDGET" end
    self.state.sampleQueries=self.state.sampleQueries+1
    self.state.queryCount=self.state.queryCount+1
    local known,ks=self:Scalar("spell_known",C_SpellBook and C_SpellBook.IsSpellKnown,"boolean",id)
    local current,os=self:Scalar("spell_override",C_Spell and C_Spell.GetOverrideSpell,"number",id)
    if ks~="READABLE" or not known or os~="READABLE" or current~=id then
        cache[id]={verdict="UNKNOWN",reason="SPELL_ELIGIBILITY_CHANGED"}
        return "UNKNOWN","SPELL_ELIGIBILITY_CHANGED"
    end
    -- Always pass an explicit token. A missing mouseover never falls back to target.
    local result,reason=self:Scalar("spell_range",C_Spell and C_Spell.IsSpellInRange,"boolean",id,unit)
    local verdict="UNKNOWN"
    if reason=="READABLE" then verdict=result and "IN" or "OUT" end
    cache[id]={verdict=verdict,reason=reason}
    return verdict,reason
end
-- Pure reducer over already readable zero-minimum spell-probe observations.
-- It estimates an ability-reach band, not geometric center-to-center world distance.
function P:ReduceBounds(rows)
    local lower,upper=nil,nil
    local thresholds={}; local count=0
    for _,r in ipairs(rows) do
        if r.verdict=="IN" or r.verdict=="OUT" then
            if not thresholds[r.max] then thresholds[r.max]=true; count=count+1 end
            if r.verdict=="IN" then upper=upper and math.min(upper,r.max) or r.max
            else lower=lower and math.max(lower,r.max) or r.max end
        end
    end
    if lower and upper and lower>=upper then return {result="UNKNOWN",reason="CONTRADICTORY_PROBES",count=count} end
    if lower and upper then return {result="CANDIDATE_INTERVAL",reason="UNCALIBRATED_SPELL_REACH",lower=lower,upper=upper,count=count} end
    if upper then return {result="CANDIDATE_UPPER",reason="UNCALIBRATED_SPELL_REACH",upper=upper,count=count} end
    if lower then return {result="CANDIDATE_LOWER",reason="UNCALIBRATED_SPELL_REACH",lower=lower,count=count} end
    return {result="UNKNOWN",reason="NO_VALID_PROBES",count=count}
end
function P:SampleRange(s,combat)
    s.range="UNKNOWN"; s.rangeReason="NO_ELIGIBLE_UNIT"
    s.bounds={result="UNKNOWN",reason="DISABLED",count=0}; s.probeRows={}
    if not s.exists or s.attackable~="YES" or s.dead~="NO" then return end
    local cache={}
    if self.selected then
        s.range,s.rangeReason=self:RangeResult(self.selected.id,s.source,cache)
    else s.rangeReason="REFERENCE_NOT_SET" end
    if not self.state.brackets then return end
    -- A proof boundary, NOT a claim that all combat bracket providers are universally prohibited.
    if combat~=false then s.bounds.reason="COMBAT_OR_STATE_UNKNOWN"; return end
    local items={}; local ids={}
    if self.selected and self.selected.min==0 and self.selected.max>5 then
        items[#items+1]=self.selected; ids[self.selected.id]=true
    end
    for _,p in ipairs(self.probes) do if not ids[p.id] then items[#items+1]=p; ids[p.id]=true end end
    for _,p in ipairs(items) do
        local verdict,reason=self:RangeResult(p.id,s.source,cache)
        s.probeRows[#s.probeRows+1]={id=p.id,max=p.max,verdict=verdict,reason=reason}
    end
    s.bounds=self:ReduceBounds(s.probeRows)
end
