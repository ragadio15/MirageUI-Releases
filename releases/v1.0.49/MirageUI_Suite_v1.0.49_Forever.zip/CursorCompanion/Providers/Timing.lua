local _, CC = ...
-- F5: GCD is a display of measured Blizzard cooldown data, never a predicted
-- timer. The 61304 dummy is not sufficient on every Forever build. A second
-- source uses a previously VERIFIED GCD-only action-bar spell and forwards the
-- native duration directly to Cooldown widgets. Secret values are never
-- inspected, compared, cached, formatted or used to choose actions.
CC.Timing = {lanes = {}, started = false, empower = false}
local T = CC.Timing
local lanes = {"cast", "channel", "gcd"}
local castEvents = {
 "UNIT_SPELLCAST_START", "UNIT_SPELLCAST_STOP", "UNIT_SPELLCAST_FAILED",
 "UNIT_SPELLCAST_INTERRUPTED", "UNIT_SPELLCAST_DELAYED", "UNIT_SPELLCAST_CHANNEL_START",
 "UNIT_SPELLCAST_CHANNEL_UPDATE", "UNIT_SPELLCAST_CHANNEL_STOP",
 "UNIT_SPELLCAST_EMPOWER_START", "UNIT_SPELLCAST_EMPOWER_UPDATE", "UNIT_SPELLCAST_EMPOWER_STOP",
 "UNIT_SPELLCAST_SUCCEEDED"
}
local actionEvents = {ACTIONBAR_SLOT_CHANGED=true, ACTIONBAR_PAGE_CHANGED=true,
                     UPDATE_BONUS_ACTIONBAR=true, SPELLS_CHANGED=true}
local function emptyGCDStats()
 return {source="NOT_RUN", reason="NOT_RUN", active=false, tableSamples=0,
         nativeSamples=0, idleSamples=0, failedTableSamples=0,
         eventUpdates=0, castEvents=0, changes=0, actionScans=0,
         actionCandidates=0, actionSamples=0, actionNative=0,
         actionTable=0, actionSlot=0, actionRejects=0,
         actionReason="NOT_RUN", renderTest="NOT_RUN"}
end
function T:Initialize()
 for _,name in ipairs(lanes) do self.lanes[name]={status="NOT_RUN",calls=0,failed=false,widgets={}} end
 self.gcdStats=emptyGCDStats()
 self.frame=CreateFrame("Frame")
 self.frame:SetScript("OnEvent",function(_,event,unit)
  -- The cooldown/actionbar events have no player token. For cast events we
  -- accept only an ordinary, readable literal unit; do not test secret units.
  if event=="SPELL_UPDATE_COOLDOWN" or actionEvents[event] then self:Event(event)
  elseif CC.Safety:IsText(unit) and unit=="player" then self:Event(event) end
 end)
end
function T:Fault(name,reason)
 local lane=self.lanes[name];if not lane or lane.failed then return end
 lane.failed=true;lane.status=reason
 if name=="gcd" then self.gcdStats.reason=reason;self.gcdStats.active=false end
 CC.Diagnostics:OptionalFault("TIMING_"..reason)
 for _,widget in ipairs(lane.widgets) do pcall(widget.Clear,widget);pcall(widget.Hide,widget) end
end
function T:Clear(name)
 local lane=self.lanes[name];if not lane or lane.failed then return end
 for _,widget in ipairs(lane.widgets) do
  if not pcall(widget.Clear,widget) then self:Fault(name,"CLEAR_FAULT");return end
 end
end
function T:Bind(name,getter,...)
 local lane=self.lanes[name];if not lane or lane.failed or #lane.widgets==0 then return end
 if type(getter)~="function" then self:Clear(name);lane.status="UNSUPPORTED_API";return end
 lane.calls=lane.calls+1
 local ok,duration=pcall(getter,...)
 if not ok then self:Fault(name,"GETTER_FAULT");return end
 local guarded,secret=pcall(issecretvalue,duration)
 if not guarded or (secret~=true and secret~=false) then self:Fault(name,"GUARD_FAULT");return end
 if secret==false then
  if duration==nil then self:Clear(name);if not lane.failed then lane.status="NO_OBJECT" end;return end
  local t=type(duration)
  if t~="userdata" and t~="table" then self:Fault(name,"HANDLE_TYPE");return end
 end
 for _,widget in ipairs(lane.widgets) do
  if type(widget.SetCooldownFromDurationObject)~="function"
      or not pcall(widget.SetCooldownFromDurationObject,widget,duration,true) then
   self:Fault(name,"CONSUMER_FAULT");return
  end
 end
 lane.status="DISPATCH_OK"
end
-- For opaque duration objects, only the WoW native widget can examine timing.
function T:ForwardGCDDuration(obj)
 local guarded,secret=pcall(issecretvalue,obj)
 if not guarded or (secret~=true and secret~=false) then return false,"HANDLE_GUARD_ERROR" end
 if secret==false then
  if obj==nil then return false,"NO_DURATION_OBJECT" end
  if type(obj)~="userdata" and type(obj)~="table" then return false,"DURATION_HANDLE_INVALID" end
 end
 for _,widget in ipairs(self.lanes.gcd.widgets) do
  if type(widget.SetCooldownFromDurationObject)~="function"
      or not pcall(widget.SetCooldownFromDurationObject,widget,obj,true) then
   return false,"NATIVE_WIDGET_REJECTED"
  end
  if not pcall(widget.Show,widget) then return false,"NATIVE_WIDGET_SHOW_REJECTED" end
 end
 return true
end
function T:ForwardGCDNumbers(start,duration,rate)
 local lane=self.lanes.gcd
 local now=CC.Safety:Value(GetTime)
 if not CC.Safety:IsNumber(start) or not CC.Safety:IsNumber(duration)
    or not CC.Safety:IsNumber(now) or start<=0 or duration<=0 then
  return false,"NUMERIC_DATA_RESTRICTED"
 end
 if not CC.Safety:IsNumber(rate) or rate<=0 then rate=nil end
 if start+duration/(rate or 1)<=now then return false,"EXPIRED" end
 for _,widget in ipairs(lane.widgets) do
  if type(widget.SetCooldown)~="function" then return false,"NUMERIC_WIDGET_ABSENT" end
  local ok
  if rate then ok=pcall(widget.SetCooldown,widget,start,duration,rate)
  else ok=pcall(widget.SetCooldown,widget,start,duration) end
  if not ok or not pcall(widget.Show,widget) then return false,"NUMERIC_WIDGET_REJECTED" end
 end
 return true
end
-- Read the official 61304 GCD dummy. An *idle* result is NOT conclusive on
-- Forever: F4 returned early and never tried real spell/action cooldowns.
function T:TryReadableGCD()
 local getter=C_Spell and C_Spell.GetSpellCooldown
 if type(getter)~="function" then return false,"TABLE_API_ABSENT" end
 local ok,info=pcall(getter,61304)
 if not ok then return false,"TABLE_GETTER_ERROR" end
 if not CC.Safety:IsReadable(info) or type(info)~="table" then return false,"TABLE_NO_READABLE_VALUE" end
 local start=CC.Safety:Field(info,"startTime")
 local duration=CC.Safety:Field(info,"duration")
 if not CC.Safety:IsNumber(start) or not CC.Safety:IsNumber(duration)
    or start<0 or duration<0 then return false,"TABLE_FIELDS_RESTRICTED" end
 local enabled=CC.Safety:Field(info,"isEnabled")
 local isActive=CC.Safety:Field(info,"isActive")
 local rate=CC.Safety:Field(info,"modRate")
 if not CC.Safety:IsNumber(rate) or rate<=0 then rate=nil end
 local now=CC.Safety:Value(GetTime)
 if not CC.Safety:IsNumber(now) then return false,"CLOCK_UNAVAILABLE" end
 local active=enabled~=false and isActive~=false and start>0 and duration>0
              and start+duration/(rate or 1)>now
 self.gcdStats.tableSamples=self.gcdStats.tableSamples+1
 if not active then return false,"TABLE_IDLE" end
 local last=self.lastGCDNumeric
 if self.gcdMode~="TABLE" or not last or last.start~=start or last.duration~=duration or last.rate~=rate then
  local good,why=self:ForwardGCDNumbers(start,duration,rate)
  if not good then return false,"TABLE_"..why end
  self.gcdStats.changes=self.gcdStats.changes+1
 end
 self.gcdMode="TABLE";self.lastGCDNumeric={start=start,duration=duration,rate=rate}
 self.gcdStats.source="COOLDOWN_TABLE";self.gcdStats.reason="ACTIVE";self.gcdStats.active=true
 self.lanes.gcd.status="GCD_ACTIVE_TABLE"
 return true,"TABLE_ACTIVE"
end
-- Scan at a bounded rate and only outside combat. Select real spell buttons
-- that have a GCD but NO independent base cooldown. Never assume that a
-- spell's own multi-second cooldown is the GCD. No action/cast is executed.
function T:ScanGCDActionSlots()
 if CC.Safety:InCombat() then self.pendingActionScan=true;return end
 self.pendingActionScan=false
 self.gcdStats.actionScans=self.gcdStats.actionScans+1
 self.gcdActionSlots={}
 if type(GetActionInfo)~="function" or type(GetSpellBaseCooldown)~="function" then
  self.gcdStats.actionReason="ACTION_SCAN_APIS_UNAVAILABLE"
  self.gcdStats.actionCandidates=0;return
 end
 local found={}
 for slot=1,120 do
  local ok,kind,spell=pcall(GetActionInfo,slot)
  if ok and CC.Safety:IsText(kind) and kind=="spell" and CC.Safety:IsNumber(spell)
     and spell>0 and spell==math.floor(spell) and not found[spell] then
   local cdOK,baseCD,gcdMS=pcall(GetSpellBaseCooldown,spell)
   if cdOK and CC.Safety:IsReadable(baseCD)
       and (baseCD==nil or (CC.Safety:IsNumber(baseCD) and baseCD==0))
       and CC.Safety:IsNumber(gcdMS) and gcdMS>0 then
    found[spell]=true
    self.gcdActionSlots[#self.gcdActionSlots+1]={slot=slot,spell=spell}
    if #self.gcdActionSlots>=12 then break end
   end
  end
 end
 self.gcdStats.actionCandidates=#self.gcdActionSlots
 self.gcdStats.actionReason=#self.gcdActionSlots>0 and "CANDIDATES_VERIFIED" or "NO_GCD_ONLY_SPELL_BUTTONS"
end
-- Prefer the permitted C_Spell APIs on the known *real* spell. This path
-- still works if the ActionBar cooldown API disallows tainted addon callers.
-- Base-cooldown validation ensures we never pass an ability's independent
-- multi-second recharge into a widget labelled Global Cooldown.
function T:TryVerifiedSpellGCD()
 local slots=self.gcdActionSlots
 if not slots or #slots==0 then return false,"SPELL_NO_CANDIDATES" end
 if not C_Spell or type(C_Spell.GetSpellCooldown)~="function" then
  return false,"SPELL_COOLDOWN_API_ABSENT"
 end
 for _,entry in ipairs(slots) do
  local ok,info=pcall(C_Spell.GetSpellCooldown,entry.spell)
  if ok and CC.Safety:IsReadable(info) and type(info)=="table" then
   local active=CC.Safety:Field(info,"isActive")
   local enabled=CC.Safety:Field(info,"isEnabled")
   local gcd=CC.Safety:Field(info,"isOnGCD")
   self.gcdStats.actionSamples=self.gcdStats.actionSamples+1
   if active==true and enabled~=false and gcd~=false then
    if type(C_Spell.GetSpellCooldownDuration)=="function" then
     local durationOK,obj=pcall(C_Spell.GetSpellCooldownDuration,entry.spell,false)
     if durationOK then
      local sent,why=self:ForwardGCDDuration(obj)
      if sent then
       self.gcdMode="SPELL";self.lastGCDNumeric=nil
       local stats=self.gcdStats;stats.source="VERIFIED_SPELL_DURATION"
       stats.reason="ACTIVE_GCD_ONLY_SPELL";stats.active=true
       stats.actionNative=stats.actionNative+1;stats.actionSlot=entry.slot
       self.lanes.gcd.status="GCD_ACTIVE_SPELL_DURATION"
       return true
      else self.gcdStats.actionReason=why end
     end
    end
    local start=CC.Safety:Field(info,"startTime")
    local duration=CC.Safety:Field(info,"duration")
    local rate=CC.Safety:Field(info,"modRate")
    local good,why=self:ForwardGCDNumbers(start,duration,rate)
    if good then
     self.gcdMode="SPELL_TABLE";self.lastGCDNumeric=nil
     local stats=self.gcdStats;stats.source="VERIFIED_SPELL_TABLE"
     stats.reason="ACTIVE_GCD_ONLY_SPELL";stats.active=true
     stats.actionTable=stats.actionTable+1;stats.actionSlot=entry.slot
     self.lanes.gcd.status="GCD_ACTIVE_SPELL_TABLE"
     return true
    end
    self.gcdStats.actionReason=why
   else self.gcdStats.actionRejects=self.gcdStats.actionRejects+1 end
  end
 end
 return false,"SPELL_NO_VERIFIED_ACTIVE_GCD"
end
function T:TryActionBarGCD()
 local slots=self.gcdActionSlots
 if not slots or #slots==0 then return false,"ACTION_NO_CANDIDATES" end
 local getter=C_ActionBar and C_ActionBar.GetActionCooldown
 if type(getter)~="function" then return false,"ACTION_COOLDOWN_API_ABSENT" end
 for _,entry in ipairs(slots) do
  local slot=entry.slot
  local ok,info=pcall(getter,slot)
  if ok and CC.Safety:IsReadable(info) and type(info)=="table" then
   local active=CC.Safety:Field(info,"isActive")
   local enabled=CC.Safety:Field(info,"isEnabled")
   local gcd=CC.Safety:Field(info,"isOnGCD")
   self.gcdStats.actionSamples=self.gcdStats.actionSamples+1
   -- isActive/isOnGCD are explicitly NeverSecret on supported Mainline.
   -- An absent isOnGCD is acceptable ONLY for pre-verified GCD-only spells.
   if active==true and enabled~=false and gcd~=false then
    local durationGetter=C_ActionBar.GetActionCooldownDuration
    if type(durationGetter)=="function" then
     local durationOK,obj=pcall(durationGetter,slot,false)
     if durationOK then
      local sent,why=self:ForwardGCDDuration(obj)
      if sent then
       self.gcdMode="ACTION";self.lastGCDNumeric=nil
       local stats=self.gcdStats;stats.source="ACTION_BAR_DURATION"
       stats.reason="ACTIVE_VERIFIED_GCD_ONLY_SPELL";stats.active=true
       stats.actionNative=stats.actionNative+1;stats.actionSlot=slot
       self.lanes.gcd.status="GCD_ACTIVE_ACTION_DURATION"
       return true
      else self.gcdStats.actionReason=why end
     end
    end
    -- When duration objects are absent, readable normal numbers may still
    -- work. Restricted numbers never enter SetCooldown or Lua arithmetic.
    local start=CC.Safety:Field(info,"startTime")
    local duration=CC.Safety:Field(info,"duration")
    local rate=CC.Safety:Field(info,"modRate")
    local good,why=self:ForwardGCDNumbers(start,duration,rate)
    if good then
     self.gcdMode="ACTION_TABLE";self.lastGCDNumeric=nil
     local stats=self.gcdStats;stats.source="ACTION_BAR_TABLE"
     stats.reason="ACTIVE_VERIFIED_GCD_ONLY_SPELL";stats.active=true
     stats.actionTable=stats.actionTable+1;stats.actionSlot=slot
     self.lanes.gcd.status="GCD_ACTIVE_ACTION_TABLE"
     return true
    end
    self.gcdStats.actionReason=why
   else
    self.gcdStats.actionRejects=self.gcdStats.actionRejects+1
   end
  end
 end
 return false,"ACTION_NO_VERIFIED_ACTIVE_GCD"
end
function T:PublishGCD()
 local lane=self.lanes.gcd
 if not lane or lane.failed or #lane.widgets==0 then return end
 lane.calls=lane.calls+1
 local handled,reason=self:TryReadableGCD()
 if handled then return end
 if reason~="TABLE_IDLE" then self.gcdStats.failedTableSamples=self.gcdStats.failedTableSamples+1 end
 local spellOK,spellReason=self:TryVerifiedSpellGCD()
 if spellOK then return end
 local actionOK,actionReason=self:TryActionBarGCD()
 if actionOK then return end
 self.gcdStats.actionReason=spellReason or actionReason or self.gcdStats.actionReason
 -- 61304 numeric *idle* is deliberately not accepted as the final answer
 -- until the action source has been probed. If non-idle but restricted, try
 -- the sanctioned native duration. Do not inspect its secret clock fields.
 if reason~="TABLE_IDLE" then
  local getter=C_Spell and C_Spell.GetSpellCooldownDuration
  if type(getter)=="function" then
   local ok,obj=pcall(getter,61304)
   if ok then
    local sent,why=self:ForwardGCDDuration(obj)
    if sent then
     self.gcdMode="DURATION";self.lastGCDNumeric=nil
     local stats=self.gcdStats
     stats.source="DURATION_OBJECT";stats.reason="FORWARDED_OPAQUE";stats.active=false
     stats.nativeSamples=stats.nativeSamples+1
     lane.status="GCD_DURATION_DISPATCH_OK"
     return
    end
    reason=why or reason
   else reason="GCD_DURATION_GETTER_ERROR" end
  elseif not reason then reason="BOTH_APIS_ABSENT" end
 end
 -- Clear the previous GCD when all measured sources are idle/unavailable.
 if self.gcdMode~="IDLE" and self.gcdMode~="UNAVAILABLE" then self:Clear("gcd") end
 if lane.failed then return end
 self.gcdMode=reason=="TABLE_IDLE" and "IDLE" or "UNAVAILABLE"
 self.lastGCDNumeric=nil
 local stats=self.gcdStats;stats.active=false;stats.source="NONE"
 stats.reason=reason or actionReason or "NO_GCD_SOURCE"
 if reason=="TABLE_IDLE" then
  stats.source="COOLDOWN_TABLE";stats.idleSamples=stats.idleSamples+1
  lane.status="GCD_IDLE_TABLE"
 else lane.status="GCD_UNAVAILABLE" end
end
function T:Start()
 if self.started or not CC.state.running or not CC.profile.enabled or not CC.Capabilities.timing then return end
 for _,name in ipairs(lanes) do
  local l=self.lanes[name];l.widgets={};l.failed=false;l.status="NOT_RUN";l.calls=0
 end
 self.gcdStats=emptyGCDStats();self.gcdMode="NONE";self.lastGCDNumeric=nil
 self.gcdDemoUntil=nil;self.gcdWakeUntil=nil;self.pendingActionScan=false
 for key,r in pairs(CC.profile.rings) do
  if r.enabled then
   local layer=CC.CompanionFrame.layers[key]
   if layer then
    if r.role=="Cast / channel" and CC.Capabilities.castTiming then
     if type(UnitCastingDuration)=="function" then table.insert(self.lanes.cast.widgets,layer.cast) end
     if type(UnitChannelDuration)=="function" then table.insert(self.lanes.channel.widgets,layer.channel) end
    elseif r.role=="GCD" and CC.Capabilities.gcdTiming then
     table.insert(self.lanes.gcd.widgets,layer.gcd)
    end
   end
  end
 end
 local castNeeded=#self.lanes.cast.widgets>0 or #self.lanes.channel.widgets>0
 local gcdNeeded=#self.lanes.gcd.widgets>0
 if not castNeeded and not gcdNeeded then return end
 local unitRegistered=0
 if castNeeded then
  for _,event in ipairs(castEvents) do
   if pcall(self.frame.RegisterUnitEvent,self.frame,event,"player") then unitRegistered=unitRegistered+1 end
  end
 elseif gcdNeeded then
  pcall(self.frame.RegisterUnitEvent,self.frame,"UNIT_SPELLCAST_SUCCEEDED","player")
 end
 local cooldownRegistered=false
 if gcdNeeded then
  cooldownRegistered=pcall(self.frame.RegisterEvent,self.frame,"SPELL_UPDATE_COOLDOWN")
  for event in pairs(actionEvents) do pcall(self.frame.RegisterEvent,self.frame,event) end
  self:ScanGCDActionSlots()
 end
 if castNeeded and unitRegistered==0 then
  self.lanes.cast.status="NO_EVENTS";self.lanes.channel.status="NO_EVENTS"
 end
 if gcdNeeded and not cooldownRegistered then self.lanes.gcd.status="POLLING_EVENTS_UNAVAILABLE" end
 for _,name in ipairs(lanes) do
  for _,widget in ipairs(self.lanes[name].widgets) do pcall(widget.Show,widget) end
 end
 self.started=true;self.empower=false;self.pendingCast=castNeeded;self.pendingGCD=gcdNeeded
 self.castElapsed=0;self.gcdElapsed=0;self.scanElapsed=0
end
function T:Stop()
 if self.frame then self.frame:UnregisterAllEvents() end
 for _,name in ipairs(lanes) do self:Clear(name) end
 self.started=false;self.empower=false;self.pendingCast=false;self.pendingGCD=false
 self.castElapsed=0;self.gcdElapsed=0;self.gcdMode="NONE";self.lastGCDNumeric=nil
 self.gcdDemoUntil=nil;self.gcdWakeUntil=nil
 if self.gcdStats then self.gcdStats.active=false end
end
function T:Event(event)
 if not self.started then return end
 if actionEvents[event] then self.pendingActionScan=true;return end
 if event=="SPELL_UPDATE_COOLDOWN" then
  self.gcdStats.eventUpdates=self.gcdStats.eventUpdates+1
  self.pendingGCD=true;return
 end
 if event=="UNIT_SPELLCAST_EMPOWER_START" or event=="UNIT_SPELLCAST_EMPOWER_UPDATE" then self.empower=true
 elseif event=="UNIT_SPELLCAST_EMPOWER_STOP" then self.empower=false end
 self.pendingCast=true
 if event=="UNIT_SPELLCAST_SUCCEEDED" then
  self.gcdStats.castEvents=self.gcdStats.castEvents+1
  self.pendingGCD=true
  local now=CC.Safety:Value(GetTime)
  -- Wake the *visibility* of the GCD ring after a cast, even if the mouse
  -- has been stationary. This never manufactures cooldown progress or time.
  if CC.Safety:IsNumber(now) then self.gcdWakeUntil=now+2.5 end
 end
end
function T:IsGCDVisibilityNeeded()
 if not self.started or #self.lanes.gcd.widgets==0 then return false end
 if self.gcdStats.active==true then return true end
 local now=CC.Safety:Value(GetTime)
 return CC.Safety:IsNumber(now) and
    ((self.gcdWakeUntil and now<self.gcdWakeUntil) or
     (self.gcdDemoUntil and now<self.gcdDemoUntil)) or false
end
-- Out-of-combat diagnostic ONLY: known literal demo duration, never a claimed
-- gameplay GCD. Enables users to separate rendering failures from API data.
function T:RunGCDRenderTest()
 if CC.Safety:InCombat() then return false,"OUT_OF_COMBAT_ONLY" end
 if not self.started or #self.lanes.gcd.widgets==0 then return false,"ENABLE_A_GCD_RING_FIRST" end
 local now=CC.Safety:Value(GetTime)
 if not CC.Safety:IsNumber(now) then return false,"CLOCK_NOT_READABLE" end
 for _,widget in ipairs(self.lanes.gcd.widgets) do
  if type(widget.SetCooldown)~="function"
       or not pcall(widget.SetCooldown,widget,now,1.5)
       or not pcall(widget.Show,widget) then
   self.gcdStats.renderTest="NATIVE_NUMERIC_WIDGET_REJECTED"
   return false,self.gcdStats.renderTest
  end
 end
 self.gcdDemoUntil=now+1.5
 self.gcdStats.renderTest="DEMO_STARTED_1_5_SECONDS_NOT_REAL_GCD"
 return true,self.gcdStats.renderTest
end
function T:Tick(dt)
 if not self.started then return end
 dt=type(dt)=="number" and dt>0 and math.min(dt,.25) or 0
 self.castElapsed=(self.castElapsed or 0)+dt
 self.gcdElapsed=(self.gcdElapsed or 0)+dt
 self.scanElapsed=(self.scanElapsed or 0)+dt
 if self.pendingActionScan or (#self.lanes.gcd.widgets>0 and
    self.scanElapsed>=10 and (not self.gcdActionSlots or #self.gcdActionSlots==0)) then
  if not CC.Safety:InCombat() then self.scanElapsed=0;self:ScanGCDActionSlots() end
 end
 if self.pendingCast or self.castElapsed>=.12 then
  self.castElapsed=0;self.pendingCast=false
  if self.empower then
   self:Clear("cast");self:Clear("channel")
  else
   self:Bind("cast",UnitCastingDuration,"player")
   self:Bind("channel",UnitChannelDuration,"player")
  end
 end
 local now=CC.Safety:Value(GetTime)
 if self.gcdDemoUntil and CC.Safety:IsNumber(now) and now<self.gcdDemoUntil then return end
 self.gcdDemoUntil=nil
 if self.pendingGCD or self.gcdElapsed>=.15 then
  self.gcdElapsed=0;self.pendingGCD=false
  self:PublishGCD()
 end
end
