local _, CC = ...
CC.L = {
    title = "CURSOR COMPANION",
    subtitle = "Glint-inspired secondary visual | Foundation candidate",
    deferred = "Context, range, trails, click effects and cosmetic keybinds are deferred.\nThis release shows a neutral/manual-color halo only.",
    native = "Blizzard's cursor, clicks and camera controls are never changed.",
    conflict = "Another cursor effect is loaded. Disable it yourself at character selection, or explicitly acknowledge coexistence for this session.",
}
