local _,I=...
-- Research is a read-only view of observed recipes and qualified references.
-- It never creates a craft, coordinate, destination or availability assertion.
I.Research={referenceCache={},referenceCount=0,referenceLimit=64,referenceSequence=0}
local R=I.Research
local function ready()
    return I.state.clientAllowed==true and I.Storage and not I.Storage.readOnly and
        type(I.Storage.character)=="table" and type(I.Storage.account)=="table"
end
local function fingerprint(rec)
    local parts={rec.id,rec.name,rec.outputID,rec.quantityMin,rec.quantityMax,tostring(rec.learned),
        tostring(rec.incomplete),rec.professionID or "?",rec.skillLineID or "?",
        rec.professionName or "?",rec.scanMode or "?",rec.knowledgeState or "?",rec.observedAt,rec.sourceBuild}
    for _,slot in ipairs(rec.slots) do
        parts[#parts+1]=tostring(slot.required)..":"..slot.quantity..":"..table.concat(slot.choices,",")
    end
    return table.concat(parts,"\031")
end
function R:Scope()
    local account,character=I.Storage and I.Storage.account,I.Storage and I.Storage.character
    if self.scopeAccount~=account or self.scopeCharacter~=character then
        self.scopeAccount=account;self.scopeCharacter=character;self.scopeRevision=(self.scopeRevision or 0)+1
    end
    return self.scopeRevision or 0
end
function R:Recipe(recipeID)
    if not ready() then return nil,"INSIGHT_UNAVAILABLE" end
    if not I:Integer(recipeID) then return nil,"INVALID_RECIPE" end
    local recipes=I.Storage.character.recipes
    local rec=type(recipes)=="table" and recipes[recipeID]
    if not I.Storage.ValidRecipe(rec) then return nil,"RECIPE_NOT_SCANNED" end
    local current=rec.knowledgeState~="HISTORICAL_NOT_IN_LATEST_COMPLETE"
    local model={recipeID=rec.id,name=rec.name,outputID=rec.outputID,
        quantityMin=rec.quantityMin,quantityMax=rec.quantityMax,professionID=rec.professionID,
        professionName=rec.professionName or "Older observation: profession unknown",skillLineID=rec.skillLineID,
        current=current,learnedObserved=rec.learned,
        incomplete=rec.incomplete,scanMode=rec.scanMode or "LEGACY_UNSCOPED",observedAt=rec.observedAt,
        sourceBuild=rec.sourceBuild,revision=I.Recipes.revision,scopeRevision=self:Scope(),signature=fingerprint(rec),ingredients={},
        source="CURRENT_CHARACTER_PROFESSION_OBSERVATIONS",nativeVerification="NOT_RUN"}
    if current then model.learned=rec.learned end
    for slotIndex,slot in ipairs(rec.slots) do
        for choiceIndex,itemID in ipairs(slot.choices) do
            model.ingredients[#model.ingredients+1]={itemID=itemID,quantity=slot.quantity,
                slotIndex=slotIndex,choiceIndex=choiceIndex,choiceCount=#slot.choices,required=slot.required}
        end
        if #slot.choices==0 then
            model.ingredients[#model.ingredients+1]={slotIndex=slotIndex,quantity=slot.quantity,
                required=slot.required,unresolved=true,choiceCount=0}
        end
    end
    return model,"OBSERVED_RECIPE"
end
function R:ResolveRecipe(model)
    if not ready() then return nil,"INSIGHT_UNAVAILABLE" end
    if not I:Readable(model) or type(model)~="table" or not I:Integer(model.recipeID) then return nil,"SELECT_A_RECIPE" end
    local current,why=self:Recipe(model.recipeID)
    if not current then return nil,why end
    if current.signature~=model.signature or current.revision~=model.revision or current.scopeRevision~=model.scopeRevision then
        return nil,"RECIPE_CHANGED_REFRESH_AND_SELECT_AGAIN"
    end
    return current,"READY"
end
local function safeText(value,maximum)
    return I:Label(value,maximum or 160)
end
local function natural(value,maximum)
    return I:Number(value) and value>=0 and value%1==0 and value<=(maximum or 2147483647)
end
local function qualified(raw,itemID)
    if not I:Readable(raw) or type(raw)~="table" or raw.itemID~=itemID or
        not safeText(raw.name,180) or not safeText(raw.qualification,100) or
        raw.locations~="NOT_PROVIDED" or raw.nativeVerification~="NOT_RUN" then return nil end
    local result={itemID=itemID,name=raw.name,category=safeText(raw.category,32),
        qualification=raw.qualification,source=safeText(raw.source,180),sourceVersion=safeText(raw.sourceVersion,100),
        sourceURL=I:Text(raw.sourceURL,600),locations="NOT_PROVIDED",currentEligibility="NOT_ESTABLISHED",
        nativeVerification="NOT_RUN",nodeVariants={}}
    if natural(raw.minSkill,10000) and natural(raw.maxSkill,10000) and raw.maxSkill>=raw.minSkill then
        result.minSkill=raw.minSkill;result.maxSkill=raw.maxSkill
    end
    if I:Integer(raw.skillLineID) then result.skillLineID=raw.skillLineID end
    if type(raw.nodeVariants)=="table" and I:Readable(raw.nodeVariants) then
        for n,row in ipairs(raw.nodeVariants) do
            if n>32 then return nil end
            if type(row)~="table" or not I:Readable(row) or not safeText(row.name,100) or
                not natural(row.skill,10000) then return nil end
            result.nodeVariants[#result.nodeVariants+1]={name=row.name,skill=row.skill,
                sharedBaseName=safeText(row.sharedBaseName,100)}
        end
    end
    return result
end
function R:Resource(item,options)
    if not ready() then return nil,"INSIGHT_UNAVAILABLE" end
    local account,character=I.Storage.account,I.Storage.character
    local itemID=I.Items:Parse(item)
    if not itemID then return nil,"INVALID_ITEM" end
    options=type(options)=="table" and options or {}
    local regions=options.regions==true
    local service=I.Context:Service("MapAddon")
    if not ready() or I.Storage.account~=account or I.Storage.character~=character then return nil,"REFERENCE_CONTEXT_CHANGED" end
    if not service or service.apiVersion~=1 or type(service.GetResourceReference)~="function" then
        return nil,"MAP_REFERENCE_UNAVAILABLE"
    end
    local now=I:Now()
    if self.referenceProvider~=service or self.referenceAccount~=account or self.referenceCharacter~=character then
        self.referenceCache={};self.referenceCount=0;self.referenceProvider=service
        self.referenceAccount=account;self.referenceCharacter=character
    end
    local key=tostring(itemID)..(regions and ":regions" or ":brief")
    local cached=self.referenceCache[key]
    self.referenceSequence=self.referenceSequence+1
    if cached and now>=cached.at and now-cached.at<30 then
        cached.used=self.referenceSequence
        return I:Copy(cached.result),cached.reason
    end
    local raw,ok,why=I:Call(service.GetResourceReference,itemID)
    local result=ok and qualified(raw,itemID) or nil
    if result and regions then
        local found,read=I:Call(service.FindResourceRegions,itemID)
        if read and type(found)=="table" and I:Readable(found) and found.itemID==itemID and
            found.locations=="NOT_PROVIDED" and found.nativeVerification=="NOT_RUN" and
            type(found.regions)=="table" then
            result.regions={}
            for n,row in ipairs(found.regions) do
                if n>64 then result.regions=nil;break end
                if type(row)~="table" or not I:Readable(row) or not I:Integer(row.mapID) or
                    not safeText(row.name,100) or row.locations~="NOT_PROVIDED" then
                    result.regions=nil;break
                end
                local region={mapID=row.mapID,name=row.name,qualification=safeText(row.qualification,100)}
                if natural(row.minLevel,999) and natural(row.maxLevel,999) and row.maxLevel>=row.minLevel then
                    region.minLevel=row.minLevel;region.maxLevel=row.maxLevel
                end
                result.regions[#result.regions+1]=region
            end
            result.regionCount=result.regions and #result.regions or nil
        end
    end
    -- Public provider queries can re-enter an addon/storage transition.
    if not ready() or account~=I.Storage.account or character~=I.Storage.character or
        service~=I.Context:Service("MapAddon") or not ready() or
        account~=I.Storage.account or character~=I.Storage.character then return nil,"REFERENCE_CONTEXT_CHANGED" end
    if not cached and self.referenceCount>=self.referenceLimit then
        local oldestKey,oldest
        for entryKey,entry in pairs(self.referenceCache) do
            if not oldest or entry.used<oldest then oldestKey=entryKey;oldest=entry.used end
        end
        if oldestKey then self.referenceCache[oldestKey]=nil;self.referenceCount=self.referenceCount-1 end
    end
    if not cached then self.referenceCount=self.referenceCount+1 end
    local reason=result and "HISTORICAL_REFERENCE_ONLY" or why or "NO_QUALIFIED_RESOURCE_REFERENCE"
    self.referenceCache[key]={result=result,reason=reason,at=now,used=self.referenceSequence}
    return I:Copy(result),reason
end
function R:OpenResource(item,options)
    if type(options)~="table" or options.userInitiated~=true then return false,"EXPLICIT_ACTION_REQUIRED" end
    if not ready() or I:Combat() then return false,"LEAVE_COMBAT_OR_RESUME_INSIGHT" end
    local account,character=I.Storage.account,I.Storage.character
    local id=I.Items:Parse(item)
    if not id then return false,"INVALID_ITEM" end
    local service=I.Context:Service("MapAddon")
    if not service or service.apiVersion~=1 or type(service.OpenResourceReference)~="function" then
        return false,"MAP_REFERENCE_UNAVAILABLE"
    end
    local function same()
        if not ready() or I:Combat() or account~=I.Storage.account or character~=I.Storage.character then return false end
        local current=I.Context:Service("MapAddon")
        return current==service and ready() and not I:Combat() and
            account==I.Storage.account and character==I.Storage.character
    end
    if not same() then return false,"REFERENCE_CONTEXT_CHANGED" end
    local accepted,called,why=I:Call(service.OpenResourceReference,id,{userInitiated=true})
    if not same() then return false,"REFERENCE_CONTEXT_CHANGED" end
    return called and accepted==true,why or "MAP_REFERENCE_UNAVAILABLE"
end
function R:GetStatus()
    return {recipeDetails="OBSERVED_REAGENTS_AND_YIELD",references="HISTORICAL_REGION_GUIDANCE_ONLY",
        referenceEntries=self.referenceCount,referenceLimit=self.referenceLimit,referenceTTL=30,
        nativeVerification="NOT_RUN"}
end
