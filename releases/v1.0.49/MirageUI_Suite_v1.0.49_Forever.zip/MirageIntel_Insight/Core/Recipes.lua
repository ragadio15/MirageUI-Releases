local _,I=...
I.Recipes={byOutput={},byReagent={},scanning=false,lastScan="NEVER_SCANNED",processed=0,failed=0,revision=0,generation=0,pendingScan=false,coverage={scanCount=0,legacyUnscoped=0,professionCount=0}}
local R=I.Recipes
function R:InvalidateTooltip()
    self.hoverRecipe=nil;self.tooltipRevision=(self.tooltipRevision or 0)+1
end
local function addIndex(index,itemID,rec)
    if not I:Integer(itemID) then return end
    local bucket=index[itemID]
    if not bucket then bucket={};index[itemID]=bucket end
    bucket[#bucket+1]=rec
end
local function currentKnowledge(rec)
    local current=I.state.clientInterface
    if current and current~=(rec.sourceInterface or 16001) then return false end
    return rec.knowledgeState~="HISTORICAL_NOT_IN_LATEST_COMPLETE"
end
local function summary(rec)
    local current=currentKnowledge(rec)
    local learned
    if current then learned=rec.learned end
    return {id=rec.id,name=rec.name,learned=learned,learnedObserved=rec.learned,current=current,
        knowledgeState=rec.professionID==nil and "LEGACY_UNSCOPED" or
            (current and "CURRENT_CHARACTER_OBSERVED" or "HISTORICAL_NOT_IN_LATEST_COMPLETE"),
        outputID=rec.outputID,quantityMin=rec.quantityMin,quantityMax=rec.quantityMax,incomplete=rec.incomplete,
        professionID=rec.professionID,skillLineID=rec.skillLineID,
        professionName=rec.professionName or "Legacy: profession unknown",
        scanMode=rec.scanMode or "LEGACY_UNSCOPED",observedAt=rec.observedAt,
        source="PLAYER_PROFESSION_SNAPSHOT_NOT_GLOBAL"}
end
local function stable(a,b)
    if a.name~=b.name then return a.name<b.name end
    return a.id<b.id
end
local function relationshipOrder(a,b)
    local ac,bc=currentKnowledge(a),currentKnowledge(b)
    if ac~=bc then return ac end
    if a.learned~=b.learned then return a.learned end
    return stable(a,b)
end
local knowledgeFilters={all=true,current=true,known=true,catalog=true,historical=true}
local completenessFilters={all=true,complete=true,incomplete=true}
local relationshipFilters={any=true,produces=true,uses=true}
local function usesItem(rec,itemID)
    for _,slot in ipairs(rec.slots) do
        for _,id in ipairs(slot.choices) do if id==itemID then return true end end
    end
    return false
end
local function searchMatch(rec,search)
    if not search then return true end
    -- Search is literal. IDs and observed profession names are useful even
    -- when an item is not cached; no native item requests run while filtering.
    if string.find(string.lower(rec.name),search,1,true) or
        string.find(string.lower(rec.professionName or ""),search,1,true) then return true end
    local id=tonumber(search:match("^#?(%d+)$"))
    return id and (rec.id==id or rec.outputID==id or usesItem(rec,id)) or false
end
function R:RebuildIndex()
    self.byOutput={};self.byReagent={};self.professionsByItem={};self.revision=self.revision+1
    self.listCache=nil;self:InvalidateTooltip()
    self.coverage={scanCount=0,legacyUnscoped=0,professionCount=0}
    if I.Storage.readOnly then return end
    local recipes=I.Storage.character and I.Storage.character.recipes
    if type(recipes)~="table" then return end
    for _,rec in pairs(recipes) do
        if I.Storage.ValidRecipe(rec) then
            addIndex(self.byOutput,rec.outputID,rec)
            local used={}
            for _,slot in ipairs(rec.slots) do
                for _,id in ipairs(slot.choices) do
                    if not used[id] then addIndex(self.byReagent,id,rec);used[id]=true end
                end
            end
        end
    end
    for _,set in ipairs({self.byOutput,self.byReagent}) do
        for _,bucket in pairs(set) do table.sort(bucket,relationshipOrder) end
    end
    -- Build compact profession labels once per recipe revision, never by
    -- walking the saved catalogue during an item hover.
    local sets={}
    for _,index in ipairs({self.byOutput,self.byReagent}) do
        for itemID,records in pairs(index) do
            local names=sets[itemID] or {};sets[itemID]=names
            for _,rec in ipairs(records) do
                if currentKnowledge(rec) and I:Label(rec.professionName,120) then names[rec.professionName]=true end
            end
        end
    end
    for itemID,names in pairs(sets) do
        local list={};for name in pairs(names) do list[#list+1]=name end
        table.sort(list);self.professionsByItem[itemID]=list
    end
    local stored=I.Storage:Status()
    self.coverage={scanCount=stored.scanCount or 0,legacyUnscoped=stored.legacyUnscoped or 0,
        professionCount=stored.professionCount or 0,recipeCount=stored.recipeCount or 0,
        learnedRecipeCount=stored.learnedRecipeCount or 0,historicalRecipeCount=stored.historicalRecipeCount or 0}
    if stored.scanCount and stored.scanCount>0 then
        self.lastScan=stored.legacyUnscoped>0 and "STORED_WITH_LEGACY_UNSCOPED" or "STORED_PROFESSION_OBSERVATIONS"
    end
end
function R:ProfessionsForItem(itemID)
    local out={}
    for _,name in ipairs(self.professionsByItem and self.professionsByItem[itemID] or {}) do out[#out+1]=name end
    return out
end
function R:Find(itemID,limit)
    if not I:Integer(itemID) then return {produced={},usedBy={},producedCount=0,usedByCount=0,status="INVALID_ITEM_ID"} end
    limit=I:Integer(limit) and math.min(limit,20) or 8
    local function take(source)
        local out={}
        for j=1,math.min(#(source or {}),limit) do
            local r=source[j]
            out[#out+1]=summary(r)
        end
        return out
    end
    -- Tooltip reads must not rescan all saved recipes on every hover.
    local stored=self.coverage
    local all=self.byOutput[itemID] or {}
    local uses=self.byReagent[itemID] or {}
    return {produced=take(all),usedBy=take(uses),producedCount=#all,usedByCount=#uses,
        status=(stored.scanCount or 0)>0 and "OBSERVED_PROFESSION_SNAPSHOTS_NOT_GLOBAL" or "NO_PROFESSION_CATALOG_SCANNED",
        legacyUnscoped=stored.legacyUnscoped,professionCount=stored.professionCount,revision=self.revision}
end
function R:List(options)
    options=type(options)=="table" and options or {}
    local professionID=options.professionID
    if professionID~=nil and not I:Integer(professionID) then return nil,"INVALID_PROFESSION_FILTER" end
    local skillLineID=options.skillLineID
    if skillLineID~=nil and not I:Integer(skillLineID) then return nil,"INVALID_SKILL_LINE_FILTER" end
    local search=options.search
    if search~=nil and (not I:Text(search,240) or search:find("[%c|]")) then return nil,"INVALID_QUERY" end
    local learnedOnly=options.learnedOnly==true
    local knowledge=options.knowledge or "all"
    local completeness=options.completeness or "all"
    local relationship=options.relationship or "any"
    local itemID=options.itemID
    if not I:Readable(knowledge) or type(knowledge)~="string" or not knowledgeFilters[knowledge] then return nil,"INVALID_KNOWLEDGE_FILTER" end
    if not I:Readable(completeness) or type(completeness)~="string" or not completenessFilters[completeness] then return nil,"INVALID_COMPLETENESS_FILTER" end
    if not I:Readable(relationship) or type(relationship)~="string" or not relationshipFilters[relationship] or (itemID~=nil and not I:Integer(itemID)) or
        (relationship~="any" and itemID==nil) then return nil,"INVALID_RELATIONSHIP_FILTER" end
    local offset=options.offset or 0
    local limit=options.limit or 8
    if not I:Number(offset) or offset<0 or offset%1~=0 or offset>3000 or
        not I:Integer(limit) or limit>30 then return nil,"INVALID_PAGE" end
    local records=I.Storage.character and I.Storage.character.recipes
    search=search and string.lower(search)
    local cache=self.listCache
    local matching=cache and cache.records==records and cache.revision==self.revision and
        cache.professionID==professionID and cache.skillLineID==skillLineID and
        cache.learnedOnly==learnedOnly and cache.search==search and cache.knowledge==knowledge and
        cache.completeness==completeness and cache.relationship==relationship and cache.itemID==itemID
    local filtered
    if matching then
        filtered=cache.rows;self.listCacheHits=(self.listCacheHits or 0)+1
    else
        filtered={}
        if type(records)=="table" then
            for _,rec in pairs(records) do
                if I.Storage.ValidRecipe(rec) and (not professionID or professionID==rec.professionID) and
                    (not skillLineID or skillLineID==(rec.skillLineID or rec.professionID)) and
                    (not learnedOnly or (rec.learned and currentKnowledge(rec))) and
                    (knowledge=="all" or knowledge=="current" and currentKnowledge(rec) or
                        knowledge=="known" and currentKnowledge(rec) and rec.learned or
                        knowledge=="catalog" and currentKnowledge(rec) and not rec.learned or
                        knowledge=="historical" and not currentKnowledge(rec)) and
                    (completeness=="all" or completeness=="complete" and not rec.incomplete or
                        completeness=="incomplete" and rec.incomplete) and
                    (not itemID or relationship=="produces" and rec.outputID==itemID or
                        relationship=="uses" and usesItem(rec,itemID) or
                        relationship=="any" and (rec.outputID==itemID or usesItem(rec,itemID))) and
                    searchMatch(rec,search) then
                    filtered[#filtered+1]=rec
                end
            end
        end
        table.sort(filtered,stable)
        -- A single revision-scoped filter snapshot makes page changes bounded
        -- by the requested page, without retaining an unbounded search history.
        self.listCache={records=records,revision=self.revision,professionID=professionID,
            skillLineID=skillLineID,learnedOnly=learnedOnly,search=search,knowledge=knowledge,
            completeness=completeness,relationship=relationship,itemID=itemID,rows=filtered}
        self.listBuilds=(self.listBuilds or 0)+1
    end
    local rows={}
    for j=offset+1,math.min(#filtered,offset+limit) do
        local rec=filtered[j]
        rows[#rows+1]=summary(rec)
    end
    return {rows=rows,total=#filtered,offset=offset,limit=limit,
        hasMore=offset+limit<#filtered,source="ONLY_SCANNED_PROFESSION_OBSERVATIONS"},"AVAILABLE"
end
-- Profession discovery runs only while a qualified own-character view is open.
-- The reviewed native frame uses linked/guild source flags and sourceCounter;
-- looking at a linked catalog must never claim another player's learned spells.
local TASK="MirageInsight_Recipes"
local function field(object,key)
    if not I:Readable(object) or type(object)~="table" then return nil end
    local ok,value=pcall(function()return object[key]end)
    if ok and I:Readable(value) then return value end
end
local function clock()
    local value,ok=I:Call(GetTime)
    if ok and I:Number(value) and value>=0 then return value end
    return I:Now()
end
local function tasks()
    if not I.core or type(I.core.GetService)~="function" then return nil end
    local service,ok=I:Call(I.core.GetService,"Tasks",1)
    if ok and type(service)=="table" and type(service.Queue)=="function" and type(service.Cancel)=="function" then return service end
end
local professionFrames={"ProfessionsFrame","TradeSkillFrame","CraftFrame"}
local function viewOpen()
    local observed=false
    for _,name in ipairs(professionFrames) do
        local frame=_G[name]
        if frame and type(frame.IsShown)=="function" then
            local shown,ok=I:Call(frame.IsShown,frame)
            if ok and type(shown)=="boolean" then
                observed=true
                if shown then return true end
            end
        end
    end
    if observed then return false end
    return R.viewOpen==true
end
local function ownContext()
    local api=C_TradeSkillUI
    if type(api)~="table" then return nil,"PROFESSION_API_UNAVAILABLE" end
    if not viewOpen() then return nil,"PROFESSION_WINDOW_CLOSED" end
    for _,name in ipairs({"IsTradeSkillLinked","IsTradeSkillGuild","IsNPCCrafting"}) do
        local value,ok=I:Call(api[name])
        if not ok or (value~=nil and type(value)~="boolean") then return nil,"PROFESSION_OWNER_UNAVAILABLE" end
        if value==true then return nil,"FOREIGN_PROFESSION_VIEW" end
    end
    if type(api.IsTradeSkillGuildMember)=="function" then
        local value,ok=I:Call(api.IsTradeSkillGuildMember)
        if not ok or (value~=nil and type(value)~="boolean") then return nil,"PROFESSION_OWNER_UNAVAILABLE" end
        if value==true then return nil,"FOREIGN_PROFESSION_VIEW" end
    end
    local base,ok=I:Call(api.GetBaseProfessionInfo)
    local child,childOK=I:Call(api.GetChildProfessionInfo)
    local baseID,name=field(base,"professionID"),field(base,"professionName")
    if not ok or not I:Integer(baseID) or not I:Label(name,120) then
        local childID,childName=field(child,"professionID"),field(child,"professionName")
        if not childOK or not I:Integer(childID) or not I:Label(childName,120) then return nil,"PROFESSION_CONTEXT_UNAVAILABLE" end
        base=child;baseID=childID;name=childName;child=nil
    end
    local childID=field(child,"professionID")
    local skill=I:Integer(childID) and childID or nil
    local counter=field(base,"sourceCounter")
    if counter~=nil and (not I:Number(counter) or counter<0 or counter%1~=0) then return nil,"PROFESSION_SOURCE_UNREADABLE" end
    local character,characterOK=I:Call(UnitGUID,"player")
    if not characterOK or not I:Text(character,100) then character=nil end
    return {professionID=baseID,name=name,skillLineID=skill,sourceCounter=counter,
        character=character,api=api,recipeInfo=api.GetRecipeInfo,schematic=api.GetRecipeSchematic,
        recipeScope=api.IsRecipeInSkillLine},"AVAILABLE"
end
local function sameContext(a,b)
    return a and b and a.professionID==b.professionID and a.name==b.name and
        a.skillLineID==b.skillLineID and a.sourceCounter==b.sourceCounter and a.character==b.character and
        a.api==b.api and a.recipeInfo==b.recipeInfo and a.schematic==b.schematic and a.recipeScope==b.recipeScope
end
local function arraySize(value,maximum)
    if not I:Readable(value) or type(value)~="table" then return nil end
    local count=0
    for key,entry in pairs(value) do
        count=count+1
        if count>maximum or not I:Integer(key) or key>maximum or not I:Readable(entry) then return nil end
    end
    for index=1,count do if value[index]==nil then return nil end end
    return count
end
local function sourceList(api,requestedMode)
    local ids,ok,mode
    if requestedMode==nil or requestedMode=="ALL_UNFILTERED_REPORTED" then
        ids,ok=I:Call(api.GetAllRecipeIDs)
        if ok and type(ids)=="table" then
            local count=arraySize(ids,I.maxSourceIDs)
            if not count then return nil,nil,"INVALID_OR_OVERSIZED_RECIPE_LIST" end
            if count>0 then mode="ALL_UNFILTERED_REPORTED" end
        end
        if requestedMode and not mode then return nil,nil,"RECIPE_LIST_NOT_READY" end
    end
    if not mode and (requestedMode==nil or requestedMode=="FILTERED_VISIBLE_ONLY") then
        ids,ok=I:Call(api.GetFilteredRecipeIDs)
        if ok and type(ids)=="table" then
            local count=arraySize(ids,I.maxSourceIDs)
            if not count then return nil,nil,"INVALID_OR_OVERSIZED_RECIPE_LIST" end
            if count>0 then mode="FILTERED_VISIBLE_ONLY" end
        end
    end
    if not mode then return nil,nil,"OPEN_A_PROFESSION_WINDOW_OR_NO_ACCESSIBLE_RECIPES" end
    local unique,queue={},{}
    for _,id in ipairs(ids) do
        if not I:Integer(id) then return nil,nil,"INVALID_PROFESSION_RECIPE_ID" end
        if not unique[id] then queue[#queue+1]=id;unique[id]=true end
    end
    table.sort(queue)
    return queue,mode
end
local function sameList(a,b)
    if not a or not b or #a~=#b then return false end
    for index=1,#a do if a[index]~=b[index] then return false end end
    return true
end
local function convert(id,ctx,mode)
    -- GetFilteredRecipeIDs can include another skill line while searching. The
    -- native crafting view qualifies this membership separately as well.
    local inScope,scopeOK=I:Call(ctx.recipeScope,id,ctx.skillLineID or ctx.professionID)
    if not scopeOK or type(inScope)~="boolean" then return nil,"RECIPE_SKILL_LINE_UNAVAILABLE" end
    if not inScope then return nil,"RECIPE_OUTSIDE_OPEN_SKILL_LINE" end
    local info,ok=I:Call(ctx.recipeInfo,id)
    local infoID,name,learned=field(info,"recipeID"),field(info,"name"),field(info,"learned")
    if not ok or infoID~=id or not I:Label(name,120) or type(learned)~="boolean" then return nil,"NO_RECIPE_INFO" end
    local schematic,success=I:Call(ctx.schematic,id,false)
    if not success or schematic==nil then return nil,"RECIPE_DETAILS_NOT_READY" end
    local outputID=field(schematic,"outputItemID")
    if not I:Integer(outputID) then return nil,"NON_ITEM_OR_NO_SCHEMATIC" end
    local minimum,maximum=field(schematic,"quantityMin"),field(schematic,"quantityMax")
    if not I:Integer(minimum) or not I:Integer(maximum) or maximum<minimum or maximum>100000 then return nil,"INVALID_OUTPUT_YIELD" end
    local slots=field(schematic,"reagentSlotSchematics")
    if not arraySize(slots,20) then return nil,"INVALID_REAGENT_SLOTS" end
    local rec={id=id,name=name,learned=learned,outputID=outputID,professionID=ctx.professionID,
        professionName=ctx.name,skillLineID=ctx.skillLineID,scanMode=mode,quantityMin=minimum,
        quantityMax=maximum,slots={},incomplete=false,knowledgeState="CURRENT_CHARACTER_OBSERVED",
        sourceBuild=I.state.clientBuild or "unknown",sourcePatch=I.state.clientPatch,
        sourceInterface=I.state.clientInterface,observedAt=I:Now()}
    for _,slot in ipairs(slots) do
        local quantity=field(slot,"quantityRequired")
        local required=field(slot,"required")
        local reagents=field(slot,"reagents")
        local choices,seen={},{}
        local count=arraySize(reagents,8)
        if count then
            for _,reagent in ipairs(reagents) do
                local itemID=field(reagent,"itemID")
                if I:Integer(itemID) then
                    if not seen[itemID] then choices[#choices+1]=itemID;seen[itemID]=true end
                else rec.incomplete=true end
            end
        else rec.incomplete=true end
        if not I:Integer(quantity) or quantity>100000 then rec.incomplete=true
        else
            if required~=true or #choices~=1 then rec.incomplete=true end
            -- A missing optionality flag is not enough evidence for a complete
            -- material-cost estimate; keep the relation, mark it incomplete.
            rec.slots[#rec.slots+1]={quantity=quantity,choices=choices,required=required==true}
        end
    end
    return rec
end
function R:GetTooltipRecipe(recipeID,itemID)
    if not I:Integer(recipeID) or not I:Integer(itemID) then return nil end
    local ctx=ownContext()
    if not ctx then return nil end
    -- One hovered recipe can be read while the automatic catalogue is still
    -- settling. This is a bounded read, never a scan or saved-data mutation.
    local generation=self.generation
    local clock,clockOK=I:Call(GetTime)
    local cached=self.hoverRecipe;local record
    -- The native output icon refreshes its tooltip every frame. Keep one
    -- short-lived recipe read so those refreshes do not rescan its schematic.
    if clockOK and I:Number(clock) and cached and cached.id==recipeID and
        cached.generation==generation and clock>=cached.at and clock-cached.at<.25 and sameContext(ctx,cached.context) then
        record=cached.record
    else
        record=convert(recipeID,ctx,"FILTERED_VISIBLE_ONLY")
        if not record or generation~=self.generation or not sameContext(ctx,ownContext()) then return nil end
        if clockOK and I:Number(clock) then
            self.hoverRecipe={id=recipeID,record=record,context=ctx,generation=generation,at=clock}
        end
    end
    if record.outputID~=itemID and not usesItem(record,itemID) then return nil end
    return record
end
local scanMessages={
    SCAN_ALREADY_RUNNING="A profession scan is already running.",
    UNSUPPORTED_BUILD="This client build is not supported.",
    LEAVE_COMBAT_TO_SCAN="Open the profession after combat to scan it.",
    PROFESSION_API_UNAVAILABLE="This client does not expose usable profession details.",
    PROFESSION_CONTEXT_UNAVAILABLE="Open your own profession window to scan it.",
    PROFESSION_WINDOW_CLOSED="Open your own profession window to scan it.",
    PROFESSION_OWNER_UNAVAILABLE="This profession view cannot be attributed to your character.",
    FOREIGN_PROFESSION_VIEW="Linked, guild and NPC profession views do not update your learned recipes.",
    OPEN_A_PROFESSION_WINDOW_OR_NO_ACCESSIBLE_RECIPES="Waiting for your profession's recipe data.",
    INVALID_OR_OVERSIZED_RECIPE_LIST="The recipe list is unavailable or exceeds the safe limit. Your previous scans are unchanged.",
    NO_ITEM_RECIPES_OBSERVED="No supported item recipes were found. Your previous scans are unchanged.",
    SCAN_CANCELLED="Scan canceled. Your previous scans are unchanged.",
    TASKS_UNAVAILABLE="The shared background scheduler is unavailable.",
    SCAN_INTERRUPTED_PROFESSION_CONTEXT_CHANGED="Profession changed. Your previous scans are unchanged.",
}
function R:DescribeScan(reason)
    if scanMessages[reason] then return scanMessages[reason] end
    if type(reason)=="string" then
        if reason:find("^SCAN_INTERRUPTED_") then return "Scan interrupted. Your previous scans are unchanged." end
        if reason:find("^COMMIT_FAILED_") then return "Could not save this scan. Your previous scans are unchanged." end
        if reason:find("_PRESERVED$") then return "Saved data needs recovery. No changes made." end
    end
    return "No new scan saved."
end
local function updateUI() if I.UI then I.UI:Update() end end
function R:Abort(why)
    self.generation=self.generation+1
    local service=tasks();if service then pcall(service.Cancel,TASK) end
    local hadWork=self.scanning or self.pendingScan
    self.scanning=false;self.pendingScan=false;self.origin=nil
    self.pending=nil;self.queue=nil;self.context=nil;self.mode=nil;self.storageIdentity=nil
    self.firstQueuedAt=nil;self.dueAt=nil
    self.retryContext=nil;self.detailRetries=nil;self.detailFailures=nil
    self.refreshNeeded=nil;self.refreshReason=nil;self.refreshKnowledge=nil
    if hadWork or why then self.lastScan=why or "SCAN_CANCELLED" end
    if hadWork then updateUI() end
end
function R:Begin(origin)
    if self.scanning then return false,"SCAN_ALREADY_RUNNING" end
    if I.state.clientAllowed~=true then return false,"UNSUPPORTED_BUILD" end
    if I:Combat() then return false,"LEAVE_COMBAT_TO_SCAN" end
    local writable,why=I.Storage:Writable();if not writable then return false,why end
    local generation=self.generation
    local ctx,reason=ownContext();if not ctx then return false,reason end
    if type(ctx.recipeInfo)~="function" or type(ctx.schematic)~="function" or type(ctx.recipeScope)~="function" then
        return false,"PROFESSION_API_UNAVAILABLE"
    end
    local queue,mode,listError=sourceList(ctx.api);if not queue then return false,listError end
    local fresh=ownContext()
    if generation~=self.generation or not sameContext(ctx,fresh) then return false,"SCAN_INTERRUPTED_PROFESSION_CONTEXT_CHANGED" end
    self.queue=queue;self.pending={};self.cursor=1;self.processed=0;self.failed=0;self.lastSkip=nil
    self.detailFailures=0;self.retryContext=nil
    self.context=ctx;self.mode=mode;self.startedAt=I:Now();self.scanning=true;self.pendingScan=false
    self.origin=origin or "MANUAL";self.storageIdentity=I.Storage.character
    self.storageRevision=I.Storage.character.revision;self.lastScan="SCANNING_"..mode
    updateUI();return true,mode=="FILTERED_VISIBLE_ONLY" and "SCAN_STARTED_FILTERED_VIEW" or "SCAN_STARTED_ALL_REPORTED"
end
function R:QueueWorker()
    local service=tasks();if not service then return false,"TASKS_UNAVAILABLE" end
    local generation=self.generation
    local accepted,ok=I:Call(service.Queue,TASK,function()return R:Tick(generation)end,generation)
    return ok and accepted==true,"TASKS_UNAVAILABLE"
end
function R:Start()
    if self.scanning then return false,"SCAN_ALREADY_RUNNING" end
    self:Abort()
    local ok,why=self:Begin("MANUAL");if not ok then self.lastScan=why;return false,why end
    local queued,error=self:QueueWorker()
    if not queued then self:Abort(error);return false,error end
    return true,why
end
function R:AutoEnabled()
    local prefs=I.Storage.account and I.Storage.account.preferences
    return prefs and prefs.autoScan==true and I.state.clientAllowed==true and not I.Storage.readOnly
end
function R:Schedule(reason)
    if not self:AutoEnabled() or I:Combat() or not viewOpen() then return false end
    if self.scanning then
        self.refreshNeeded=true;self.refreshReason=reason
        if reason=="NEW_RECIPE_LEARNED" then self.refreshKnowledge=true end
        return true
    end
    local t=clock()
    if self.pendingScan and self.firstQueuedAt and t>=self.firstQueuedAt then
        self.dueAt=math.min(t+0.3,self.firstQueuedAt+1.5);self.trigger=reason or self.trigger
        return true
    end
    self:Abort()
    self.pendingScan=true;self.origin="AUTOMATIC";self.firstQueuedAt=t;self.dueAt=t+0.3
    self.trigger=reason or "PROFESSION_REFRESH";self.retry=0;self.lastScan="AUTOMATIC_SCAN_DEBOUNCING"
    local ok,why=self:QueueWorker()
    if not ok then self:Abort(why);return false end
    return true
end
function R:Tick(generation)
    if generation~=self.generation then return false end
    if self.pendingScan then
        if not self:AutoEnabled() or I:Combat() or not viewOpen() then self:Abort("SCAN_INTERRUPTED_VIEW_OR_COMBAT");return false end
        local t=clock()
        if self.firstQueuedAt and t<self.firstQueuedAt then self:Abort("SCAN_INTERRUPTED_CLOCK_CHANGED");return false end
        if t<(self.dueAt or 0) then return true end
        if self.retryContext and not sameContext(self.retryContext,ownContext()) then
            self:Abort("SCAN_INTERRUPTED_PROFESSION_CONTEXT_CHANGED");return false
        end
        local ok,why=self:Begin("AUTOMATIC")
        if not ok then
            self.retry=(self.retry or 0)+1
            local notReady=why=="PROFESSION_CONTEXT_UNAVAILABLE" or why=="OPEN_A_PROFESSION_WINDOW_OR_NO_ACCESSIBLE_RECIPES" or why=="RECIPE_LIST_NOT_READY"
            if notReady and self.retry<6 then self.dueAt=t+math.min(2,0.4*self.retry);self.lastScan="WAITING_FOR_PROFESSION_DATA";return true end
            self:Abort(why);return false
        end
    end
    if self.scanning then return self:Step(6) end
    return false
end
function R:Step(limit)
    if not self.scanning then return false end
    local generation=self.generation
    if I:Combat() or I.state.clientAllowed~=true then self:Abort("SCAN_INTERRUPTED_CLIENT_OR_COMBAT");return false end
    local current=ownContext()
    if not sameContext(self.context,current) then self:Abort("SCAN_INTERRUPTED_PROFESSION_CONTEXT_CHANGED");return false end
    local writable=I.Storage:Writable()
    if not writable or self.storageIdentity~=I.Storage.character or self.storageRevision~=I.Storage.character.revision then
        self:Abort("SCAN_INTERRUPTED_STORAGE_CHANGED");return false
    end
    limit=I:Integer(limit) and math.min(limit,6) or 6
    local stop=math.min(#self.queue,self.cursor+limit-1)
    local start,clockOK=I:Call(debugprofilestop)
    local index=self.cursor
    while index<=stop do
        local id=self.queue[index]
        local rec,why=convert(id,self.context,self.mode)
        -- Native callbacks may close/change the profession while a queried
        -- schematic is being produced. Do not touch a retired transaction.
        if generation~=self.generation or not self.scanning then return false end
        if rec then self.pending[id]=rec else
            self.failed=self.failed+1;self.lastSkip=why
            if why=="NO_RECIPE_INFO" or why=="RECIPE_DETAILS_NOT_READY" then
                self.detailFailures=(self.detailFailures or 0)+1
            end
        end
        self.processed=self.processed+1;index=index+1
        local currentClock,valid=I:Call(debugprofilestop)
        if clockOK and valid and I:Number(start) and I:Number(currentClock) and currentClock-start>=0.5 then break end
    end
    self.cursor=index
    if self.cursor<=#self.queue then return true end
    local fresh=ownContext()
    if not sameContext(self.context,fresh) then self:Abort("SCAN_INTERRUPTED_PROFESSION_CONTEXT_CHANGED");return false end
    local finalIDs=sourceList(self.context.api,self.mode)
    if generation~=self.generation or not self.scanning then return false end
    if not sameList(self.queue,finalIDs) then
        self:Abort("SCAN_INTERRUPTED_RECIPE_LIST_CHANGED")
        self:Schedule("RECIPE_LIST_SETTLED");return false
    end
    local finalContext=ownContext()
    if generation~=self.generation or not self.scanning then return false end
    if not sameContext(self.context,finalContext) then self:Abort("SCAN_INTERRUPTED_PROFESSION_CONTEXT_CHANGED");return false end
    local recorded=0;for _ in pairs(self.pending) do recorded=recorded+1 end
    if self.origin=="AUTOMATIC" and self:AutoEnabled() and (self.detailFailures or 0)>0 and
        (self.detailRetries or 0)<2 then
        -- Recipe IDs can be ready before their details. Keep the previous
        -- snapshot intact while two bounded background attempts let those
        -- details arrive, even when the client emits no further refresh event.
        self.detailRetries=(self.detailRetries or 0)+1
        self.detailRecoveries=(self.detailRecoveries or 0)+1
        self.retryContext=self.context
        self.scanning=false;self.pendingScan=true
        self.pending=nil;self.queue=nil;self.context=nil;self.mode=nil;self.storageIdentity=nil
        self.firstQueuedAt=clock();self.dueAt=self.firstQueuedAt+.4*self.detailRetries
        self.lastScan="WAITING_FOR_RECIPE_DETAILS"
        updateUI();return true
    end
    if recorded==0 then self:Abort("NO_ITEM_RECIPES_OBSERVED");return false end
    local success,info=I.Storage:CommitRecipes(self.pending,self.context,self.mode,#self.queue,self.failed,self.storageRevision)
    local completedMode=self.mode
    self.scanning=false;self.pendingScan=false;self.origin=nil
    self.pending=nil;self.queue=nil;self.context=nil;self.mode=nil;self.storageIdentity=nil
    self.firstQueuedAt=nil;self.dueAt=nil
    self.retryContext=nil
    if success then
        self:RebuildIndex()
        self.lastScan=completedMode=="FILTERED_VISIBLE_ONLY" and "FILTERED_VIEW_ONLY" or
            (self.failed>0 and "PARTIAL_UNSUPPORTED_RECIPES" or "ALL_REPORTED_ELIGIBLE_RECIPES")
        if I.core and type(I.core.Publish)=="function" then
            I.core.Publish("RECIPE_CATALOG_READY",{source="MirageInsight",total=recorded,
                skipped=self.failed,coverage=completedMode,characterOnly=true,revision=self.revision})
        end
    else self.lastScan="COMMIT_FAILED_"..tostring(info);I:Fault("RECIPE_COMMIT_FAILED") end
    local refresh=self.refreshNeeded and (self.failed>0 or self.refreshKnowledge==true)
    self.refreshNeeded=nil;self.refreshReason=nil;self.refreshKnowledge=nil
    updateUI()
    if refresh and (self.refreshPasses or 0)<2 then
        self.refreshPasses=(self.refreshPasses or 0)+1
        self:Schedule("RECIPE_DETAILS_SETTLED")
    end
    return false
end
function R:IsProfessionOpen()
    local context=viewOpen() and ownContext() or nil
    if (context or self.tooltipContext) and not sameContext(context,self.tooltipContext) then
        -- A native source can change before its event is delivered. The item
        -- model's short cache must still follow the current profession owner.
        self:InvalidateTooltip();self.tooltipContext=context
    end
    return context~=nil
end
function R:InstallViewHooks()
    self.viewHooks=self.viewHooks or setmetatable({},{__mode="k"})
    for _,name in ipairs(professionFrames) do
        local frame=_G[name]
        if frame and not self.viewHooks[frame] and type(frame.HookScript)=="function" then
            local a=pcall(frame.HookScript,frame,"OnShow",function()
                R:InvalidateTooltip();R.viewOpen=true;R.refreshPasses=0;R:Schedule("PROFESSION_FRAME_OPENED")
                if I.Tooltip then I.Tooltip:RefreshVisible("PROFESSION_OPENED") end
            end)
            local b=pcall(frame.HookScript,frame,"OnHide",function()
                R:InvalidateTooltip()
                if not viewOpen() then R.viewOpen=false;R:Abort("SCAN_INTERRUPTED_PROFESSION_CLOSED") end
                if I.Tooltip then I.Tooltip:RefreshVisible("PROFESSION_CLOSED") end
            end)
            if a and b then self.viewHooks[frame]=true end
        end
    end
end
function R:OnPreferenceChanged(key)
    if key~="autoScan" then return end
    if self:AutoEnabled() then self:Schedule("AUTOMATIC_SCAN_ENABLED")
    elseif self.origin=="AUTOMATIC" then self:Abort("AUTOMATIC_SCAN_DISABLED") end
end
function R:Initialize()
    if self.initialized then return end
    self.initialized=true
    self:InstallViewHooks()
    if I.core and type(I.core.Subscribe)=="function" then
        I.core.Subscribe("INSIGHT_SETTINGS_CHANGED","MirageInsightRecipes",function(payload)
            local key=field(payload,"key");if key then R:OnPreferenceChanged(key) end
        end)
    end
    self:Schedule("INITIAL_OPEN_PROFESSION")
end
function R:OnEvent(event)
    if event:find("TRADE_SKILL",1,true) or event=="NEW_RECIPE_LEARNED" or event=="SKILL_LINES_CHANGED" or
        event=="PLAYER_LEAVING_WORLD" or event=="PLAYER_ENTERING_WORLD" then self:InvalidateTooltip() end
    if event=="ADDON_LOADED" then self:InstallViewHooks();self:Schedule("PROFESSION_ADDON_READY")
    elseif event=="TRADE_SKILL_SHOW" then
        self.viewOpen=true;self.refreshPasses=0;self:InstallViewHooks();self:Schedule(event)
    elseif event=="TRADE_SKILL_CLOSE" or event=="PLAYER_LEAVING_WORLD" then
        self.viewOpen=false;self:Abort("SCAN_INTERRUPTED_PROFESSION_CLOSED")
    elseif event=="PLAYER_REGEN_DISABLED" then self:Abort("SCAN_INTERRUPTED_COMBAT")
    elseif event=="TRADE_SKILL_DATA_SOURCE_CHANGING" then self:Abort("SCAN_INTERRUPTED_PROFESSION_SOURCE_CHANGING")
    elseif event=="PLAYER_ENTERING_WORLD" then self.viewOpen=nil;self:Schedule(event)
    elseif event=="TRADE_SKILL_DATA_SOURCE_CHANGED" or event=="TRADE_SKILL_LIST_UPDATE" or
        event=="TRADE_SKILL_DETAILS_UPDATE" or event=="TRADE_SKILL_NAME_UPDATE" or
        event=="NEW_RECIPE_LEARNED" or event=="SKILL_LINES_CHANGED" or event=="PLAYER_REGEN_ENABLED" then
        if event=="TRADE_SKILL_DATA_SOURCE_CHANGED" then
            self:Abort("SCAN_INTERRUPTED_PROFESSION_SOURCE_CHANGED");self.refreshPasses=0
        end
        self:Schedule(event)
    end
end
function R:GetStatus()
    local coverage=self.coverage or {}
    return {revision=self.revision,scanning=self.scanning,pending=self.pendingScan,lastScan=self.lastScan,
        listFilterBuilds=self.listBuilds or 0,listCacheHits=self.listCacheHits or 0,listCacheSlots=self.listCache and 1 or 0,
        sourceMode=self.mode or "STORED_OBSERVATIONS",scope="CURRENT_CHARACTER_OBSERVATIONS",
        trigger=self.trigger,processed=self.processed,skipped=self.failed,viewOpen=viewOpen(),
        detailRetries=self.detailRetries or 0,detailRecoveryAttempts=self.detailRecoveries or 0,
        automatic=self:AutoEnabled()==true,scanCount=coverage.scanCount or 0,
        recipeCount=coverage.recipeCount or 0,learnedRecipeCount=coverage.learnedRecipeCount or 0,
        historicalRecipeCount=coverage.historicalRecipeCount or 0,professionCount=coverage.professionCount or 0,
        legacyUnscoped=coverage.legacyUnscoped or 0,nativeQualification="NOT_RUN"}
end

-- P39-A: sample the existing recipe event handler without altering its events.
local p39RecipeEvent=R.OnEvent
function R:OnEvent(...)
    local core=I.core
    local perf,started
    if type(core)=='table' and type(core.GetService)=='function' then
        local ok,service=pcall(core.GetService,'Performance',1)
        if ok and type(service)=='table' and type(service.Begin)=='function' then
            perf=service
            local good,value=pcall(perf.Begin)
            if good and type(value)=='number' then started=value end
        end
    end
    local result=p39RecipeEvent(self,...)
    if started then pcall(perf.Finish,'insight.recipe_event',started) end
    return result
end
