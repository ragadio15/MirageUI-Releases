local _,I=...
I.API={}
local A=I.API
function A:Inspect(item)
    if I.state.clientAllowed==false then return nil,"UNSUPPORTED_BUILD" end
    local id,link=I.Items:Parse(item)
    if not id then return nil,link end
    local facts=I.Items:Facts(item)
    local relation=I.Recipes:Find(id,10)
    local result={itemID=id,facts=facts,relations=relation,market={status="PRICE_PROVIDER_OFF"},
        recipeCoverage="Character-scanned profession windows only. Missing relationships are not evidence of absence."}
    if I.Context then result.context=I.Context:Build(item,{detail=true,limit=24}) end
    if I.Storage.account and I.Storage.account.preferences.marketProvider=="Wealthcraft" then
        local baseRequested=I:Integer(item) or (I:Text(item,600) and item:match("^%s*%d+%s*$"))
        if link or baseRequested then
            local price,reason=I.Market:Get(link or id)
            result.market=price or {status=reason}
        else
            result.market={status="FULL_ITEM_LINK_REQUIRED_FOR_MARKET_VARIANTS"}
        end
    end
    return result,"AVAILABLE"
end
function A:SetPreference(key,value)
    local ok,why=I.Storage:SetPreference(key,value)
    if ok then
        if I.UtilityCard and ((key=="tooltip" and value==false) or
            (key=="tooltipPresentation" and value=="NATIVE")) then I.UtilityCard:Hide() end
        if I.Recipes.OnPreferenceChanged then I.Recipes:OnPreferenceChanged(key) end
        if I.Tooltip.RefreshVisible then I.Tooltip:RefreshVisible("PREFERENCE_CHANGED") end
        if I.UI and I.UI.Update then I.UI:Update() end
    end
    return ok,why
end
function A:ClearRecordedRecipes(expectedCharacter,expectedRevision)
    local allowed,why=I.Storage:Writable()
    if not allowed then return false,why end
    if I:Combat() then return false,"Clear recipes after combat." end
    if I.Storage.character~=expectedCharacter or I.Storage.character.revision~=expectedRevision then
        return false,"Recipe history changed. Review it again before clearing."
    end
    if I.Recipes and I.Recipes.Abort then I.Recipes:Abort("CLEARED_BY_PLAYER") end
    local ok,reason=I.Storage:ClearRecipes(expectedCharacter,expectedRevision)
    if not ok then return false,reason end
    if I.Recipes then I.Recipes:RebuildIndex() end
    if I.core and type(I.core.Publish)=="function" then
        I.core.Publish("RECIPE_CATALOG_READY",{source="MirageInsight",total=0,skipped=0,
            coverage="CLEARED_BY_PLAYER",characterOnly=true,revision=I.Recipes and I.Recipes.revision or 0})
    end
    if I.Tooltip and I.Tooltip.RefreshVisible then I.Tooltip:RefreshVisible("SOURCE_REVISION") end
    return true,"This character's recorded recipes were cleared."
end
function A:Install()
    local p={apiVersion=1,version=I.version,targetBuild=I.state.clientBuild or "unknown",nativeVerification="NOT_RUN"}
    function p.GetSupportStatus()
        local tooltip=I.Tooltip:GetStatus()
        local coverage=I.Recipes.coverage or {}
        local _,tooltipPolicy=I.Tooltip:DataPolicy(_G.GameTooltip)
        return {status=I.state.status,errors=I.state.errors,lastError=I.state.lastError,
            tooltipPolicy=tooltipPolicy,registered=tooltip.registered,hookStrategy=tooltip.hookStrategy,hookFailures=tooltip.hookFailures,
            activeContexts=tooltip.activeContexts,captures=tooltip.captureSuccesses,
            captureAttempts=tooltip.captureAttempts,prepared=tooltip.renderSuccesses,
            surfacePasses=tooltip.surfacePasses,lastRenderReason=tooltip.lastRenderReason,
            fadeReleases=tooltip.fadeReleases,
            lastPresentationReason=tooltip.lastPresentationReason,
            lastCaptureReason=tooltip.lastCaptureReason,scanCount=coverage.scanCount or 0,
            scanPending=I.Recipes.pendingScan==true or I.Recipes.scanning==true,
            recipeCount=coverage.recipeCount or 0,professionCount=coverage.professionCount or 0,
            automatic=I.Recipes:AutoEnabled()==true}
    end
    function p.GetStatus()
        return I:Copy({version=I.version,status=I.state.status,nativeVerification="NOT_RUN",
            errors=I.state.errors,lastError=I.state.lastError,clientAllowed=I.state.clientAllowed,
            tooltip=I.Tooltip.status,recipeScan=I.Recipes.lastScan,processed=I.Recipes.processed,
            utilityCard={status=I.UtilityCard.status,recordID=I.UtilityCard.model and I.UtilityCard.model.id,
                recordRevision=I.UtilityCard.model and I.UtilityCard.model.revision,
                generation=I.UtilityCard.generation},
            failed=I.Recipes.failed,scanning=I.Recipes.scanning,storage=I.Storage:Status(),
            recipeDiscovery=I.Recipes.GetStatus and I.Recipes:GetStatus(),
            items=I.Items.GetStatus and I.Items:GetStatus(),
            contextual=I.Context and I.Context:GetStatus(),actions=I.Actions and I.Actions:GetStatus(),
            tooltipDetail=I.Tooltip.GetStatus and I.Tooltip:GetStatus(),
            interface=I.UI and I.UI.GetStatus and I.UI:GetStatus(),
            research=I.Research and I.Research:GetStatus(),
            market=I.Market:Status(),preferences=I.Storage.account and I.Storage.account.preferences})
    end
    function p.GetItemFacts(item) return I:Copy(I.Items:Facts(item)) end
    function p.GetItemContext(item,context)
        local result,why=I.Context:Build(item,context)
        return I:Copy(result),why
    end
    function p.GetItemLocations(item,options)
        local id,why=I.Items:Parse(item)
        if not id then return nil,why end
        return I:Copy(I.Context:Locations(id,options))
    end
    function p.FindOnMap(record,options) return I.Actions:FindOnMap(record,options) end
    function p.NavigateRecord(record,options) return I.Actions:Navigate(record,options) end
    function p.InspectCurrentTooltip() return I.Tooltip:OpenInspector() end
    function p.OwnsTooltipPresentation(tooltip) return I.Tooltip:PresentationEnabled(tooltip) end
    function p.HandlesTooltipPresentation(tooltip)
        return I.state.clientAllowed==true and I.Storage.account~=nil and I.Tooltip:Surface(tooltip)~=nil
    end
    function p.RefreshTooltipPresentation(tooltip)
        if tooltip then
            local index=I.Tooltip:Surface(tooltip)
            if not index then return false end
            local enabled,why=I.Tooltip:DataPolicy(tooltip)
            if not enabled then I.Tooltip:Release(index,why);return false end
            local ok,result=pcall(I.Tooltip.Render,I.Tooltip,tooltip,nil,"CORE_PRESENTATION_CHANGED")
            return ok and result==true or I.Tooltip:PresentSurface(tooltip,"CORE_PRESENTATION_CHANGED")
        end
        I.Tooltip:RefreshVisible("CORE_PRESENTATION_CHANGED")
        return true
    end
    function p.RegisterTooltipOwner(owner,resolver) return I.Tooltip:RegisterExternalOwner(owner,resolver) end
    function p.UnregisterTooltipOwner(owner,resolver) return I.Tooltip:UnregisterExternalOwner(owner,resolver) end
    function p.GetRecipeRelationships(itemID,limit) return I:Copy(I.Recipes:Find(itemID,limit)) end
    function p.GetRecipeResearch(recipeID)
        if not I.Research then return nil,"RESEARCH_UNAVAILABLE" end
        local result,why=I.Research:Recipe(recipeID)
        return I:Copy(result),why
    end
    function p.GetResourceReference(item,options)
        if not I.Research then return nil,"RESEARCH_UNAVAILABLE" end
        local result,why=I.Research:Resource(item,options)
        return I:Copy(result),why
    end
    function p.ListRecipes(options)
        local r,why=I.Recipes:List(options)
        return I:Copy(r),why
    end
    function p.GetProfessions()
        return I:Copy(I.Storage:Status().professions)
    end
    function p.GetRecipe(recipeID)
        if not I:Integer(recipeID) then return nil,"INVALID_RECIPE" end
        local rec=I.Storage.character and I.Storage.character.recipes[recipeID]
        if not I.Storage.ValidRecipe(rec) then return nil,"RECIPE_NOT_SCANNED" end
        return I:Copy(rec),"AVAILABLE"
    end
    function p.InspectItem(item)
        local result,why=A:Inspect(item)
        return I:Copy(result),why
    end
    -- A deliberate item action opens the same styled item-link tooltip used by
    -- chat links. The settings window never becomes a second data browser.
    function p.OpenItem(item,options)
        if not I:Readable(options) or type(options)~="table" or options.userInitiated~=true then
            return false,"EXPLICIT_ACTION_REQUIRED"
        end
        return I.Tooltip:OpenItem(item)
    end
    function p.EstimateCraft(recipeID)
        local result,why=I.Analysis:Craft(recipeID)
        return I:Copy(result),why
    end
    function p.ScanOpenProfession() return I.Recipes:Start() end
    -- Utility providers pass copied public records, never item-tooltip frames.
    function p.ShowUtilityRecord(owner,record,context) return I.UtilityCard:Show(owner,record,context) end
    function p.HideUtilityRecord(owner) return I.UtilityCard:Hide(owner) end
    function p.GetUtilityRecordContext(record,context)
        local model,why=I.UtilityCard:Model(record,context)
        return I:Copy(model),why
    end
    function p.SetPreference(key,value) return A:SetPreference(key,value) end
    function p.Open() return I.UI:Open() end
    MirageInsightAPI=p
    if I.core and type(I.core.RegisterService)=="function" then
        local ok=I.core.RegisterService("Insight","MirageIntel_Insight",1,p)
        if not ok then I:Fault("CORE_SERVICE_COLLISION") end
    end
end
