local _,I=...
I.Market={}
local M=I.Market
local OWNER='MirageIntel_Insight'
local function field(value,key)
    if not I:Readable(value) or type(value)~='table' then return nil end
    if type(canaccesstable)=='function' then
        local ok,access=pcall(canaccesstable,value);if not ok or access==false then return nil end
    end
    local ok,result=pcall(function()return value[key] end)
    if ok and I:Readable(result) then return result end
end
local function preferences() return field(I.Storage.account,'preferences') end
local function provider(exact)
    local p=preferences()
    if field(p,'marketProvider')~='Wealthcraft' then return nil,nil,'PRICE_PROVIDER_OFF' end
    local api=WealthcraftAPI
    local version=field(api,'apiVersion')
    if version==nil then return nil,nil,'WEALTHCRAFT_NOT_PRESENT' end
    if version~=1 and version~=4 and version~=6 then return nil,nil,'WEALTHCRAFT_VERSION_NOT_QUALIFIED' end
    if type(field(api,'GetPrice'))~='function' or type(field(api,'GetMarketState'))~='function' then
        return nil,nil,'WEALTHCRAFT_API_INCOMPLETE'
    end
    if exact and version==6 and (field(api,'quoteContractVersion')~=1 or
        type(field(api,'GetQuoteForItemLink'))~='function') then
        return nil,nil,'WEALTHCRAFT_V6_EXACT_LINK_ADAPTER_NOT_QUALIFIED'
    end
    local ok,state=pcall(api.GetMarketState)
    local key=ok and field(state,'marketKey')
    local status=ok and field(state,'status')
    if not I:Text(key,250) or not I:Text(status,100) then return nil,nil,'MARKET_SCOPE_UNKNOWN' end
    if status=='BLOCKED' or status=='UNKNOWN' or status=='UNSUPPORTED' then return nil,nil,'MARKET_STATE_BLOCKED' end
    -- Base-item crafting estimates still require complete replication evidence;
    -- exact links may use explicitly labelled partial and targeted observations.
    if not exact and version==6 and status~='HISTORICAL_FULL_SCAN' then return nil,nil,'NO_COMPLETE_SCAN' end
    return api,key,'CONTRACT_V'..version..'_PRESENT_NATIVE_UNTESTED',field(state,'scopeStatus')
end
local function validPrice(value)
    return I:Number(value) and value>0 and value%1==0 and value<=9000000000000
end
local function ageLimit()
    local age=field(preferences(),'maxQuoteAgeSeconds')
    return I:Number(age) and age>=0 and age or nil
end
local sources={PLAYER_INITIATED_FULL_SCAN='COMPLETE_REPLICATION',
    AUTO_FULL_SCAN='COMPLETE_REPLICATION',
    PARTIAL_REPLICATION_EXACT_LINKS='PARTIAL_REPLICATION',
    PLAYER_INITIATED_TARGET_SEARCH='TARGETED_SEARCH',AH_OPEN_QUICK_REFRESH='TARGETED_SEARCH'}
local venueStatuses={PLAYER_DECLARED_ZONE_SCOPED=true,AUTOMATIC_AUCTIONEER_SCOPED=true,AUTOMATIC_SESSION_SCOPED=true}
local function validateExact(value,key,requested,stack)
    if not I:Readable(value) or type(value)~='table' then return nil,'PROVIDER_RESULT_UNAVAILABLE' end
    if field(value,'quoteContractVersion')~=1 or field(value,'sourceAPI')~='WEALTHCRAFT_EXACT_LINK_QUOTE_1' or
        field(value,'requestedLink')~=requested or field(value,'identityPrecision')~='EXACT_WEALTHCRAFT_VARIANT' then
        return nil,'EXACT_LINK_PROOF_MISSING'
    end
    -- Only the public producer normalizes market variants. Insight's ordinary
    -- item parser checks the requested item ID, never constructs a market key.
    local id=I.Items and I.Items:Parse(requested)
    if not I:Integer(id) or field(value,'itemID')~=id or not I:Label(field(value,'identity'),260) then
        return nil,'EXACT_LINK_PROOF_MISSING'
    end
    if field(value,'marketKey')~=key or not I:Label(key,250) then return nil,'MARKET_SCOPE_MISMATCH' end
    local mode=field(value,'marketContextMode')
    if (mode~='CURRENT' and mode~='LAST_SAVED') or not venueStatuses[field(value,'venueStatus')] or
        field(value,'venueVerified')~=false then return nil,'MARKET_SCOPE_UNKNOWN' end
    local source,coverage=field(value,'source'),field(value,'coverage')
    if not I:Label(source,100) or sources[source]~=coverage or
        field(value,'completeDepth')~=(coverage=='COMPLETE_REPLICATION') or
        not I:Label(field(value,'sourceSnapshotID'),180) or
        field(value,'snapshotID')~=field(value,'sourceSnapshotID') or not I:Integer(field(value,'sourceRevision')) then
        return nil,'SOURCE_SNAPSHOT_UNQUALIFIED'
    end
    if field(value,'readOnly')~=true or field(value,'priceBasis')~='OBSERVED_ASK_REFERENCE_PER_UNIT' or
        field(value,'unitBasis')~='ONE_ITEM' or field(value,'salesEvidence')~='NOT_CLAIMED' or
        field(value,'profitEvidence')~='NOT_CLAIMED' or not I:Label(field(value,'method'),100) then
        return nil,'PRICE_BASIS_UNKNOWN'
    end
    local price,age,observed=field(value,'priceCopper'),field(value,'ageSeconds'),field(value,'observedAt')
    if not validPrice(price) then return nil,'NO_VERIFIED_REFERENCE_PRICE' end
    if not I:Number(age) or age<0 or age>315360000 or not I:Integer(observed) then return nil,'PRICE_AGE_UNKNOWN' end
    local maxAge=ageLimit()
    if not maxAge then return nil,'PRICE_AGE_UNKNOWN' end
    local status=field(value,'status')
    if status~='STALE' and status~='PARTIAL_SAMPLE' and status~='LIMITED_EVIDENCE' and status~='STRONG_LOCAL_EVIDENCE' then
        return nil,'PROVIDER_QUOTE_BLOCKED'
    end
    local stackValue,stackBasis=field(value,'stackCount'),field(value,'stackBasis')
    local stackCopper=field(value,'stackCopper')
    if stack==nil then
        if stackValue~=nil or stackCopper~=nil or stackBasis~='NOT_SUPPLIED' then return nil,'STACK_BASIS_MISMATCH' end
    elseif stackValue~=stack or
        (stackBasis~='TOTAL_EXCEEDS_SUPPORTED_RANGE' and
        (stackBasis~='CALLER_OBSERVED_COUNT' or not validPrice(stackCopper) or stackCopper~=price*stack)) or
        (stackBasis=='TOTAL_EXCEEDS_SUPPORTED_RANGE' and (stackCopper~=nil or price<=math.floor(9000000000000/stack))) then
        return nil,'STACK_BASIS_MISMATCH'
    end
    return {priceCopper=price,averageCopper=validPrice(field(value,'averageCopper')) and field(value,'averageCopper') or nil,
        marketKey=key,ageSeconds=age,observedAt=observed,
        requestedLink=requested,itemID=id,identity=field(value,'identity'),identityPrecision=field(value,'identityPrecision'),
        source=source,snapshotID=field(value,'sourceSnapshotID'),sourceSnapshotID=field(value,'sourceSnapshotID'),
        sourceRevision=field(value,'sourceRevision'),quoteContractVersion=1,coverage=coverage,
        completeDepth=field(value,'completeDepth'),priceBasis=field(value,'priceBasis'),unitBasis='ONE_ITEM',
        stackCount=stackValue,stackCopper=stackCopper,stackBasis=stackBasis,method=field(value,'method'),
        stale=status=='STALE' or age>maxAge,confidence='Recorded asking prices',
        venueStatus=field(value,'venueStatus'),venueVerified=false,marketContextMode=mode,
        marketContextSource=I:Label(field(value,'marketContextSource'),100),
        marketLabel=I:Label(field(value,'marketLabel'),200),sourceBuild=field(value,'sourceBuild'),
        provider='Wealthcraft',providerAPI=6,status='HISTORICAL_OBSERVATION_NATIVE_UNTESTED',
        salesEvidence='NOT_CLAIMED',profitEvidence='NOT_CLAIMED',nativeQualification='NOT_RUN'},'AVAILABLE'
end
-- PriceView v1: evaluate the exact same role/reason supplied to WealthCraft.
-- The v6 decoder remains for old Suite installations, but new clients never
-- fall back to a base-ID price after exact-link qualification fails.
local function validatePriceView(view,key,requested,stack)
    if not I:Readable(view) or type(view)~='table' then return nil,'PROVIDER_RESULT_UNAVAILABLE' end
    if field(view,'model')~='WEALTHCRAFT_PRICE_VIEW_1' or field(view,'priceViewContractVersion')~=1 or
        field(view,'readOnly')~=true or field(view,'basis')~='ONE_ITEM' or
        field(view,'salesEvidence')~='NOT_CLAIMED' or field(view,'profitEvidence')~='NOT_CLAIMED' then
        return nil,'PRICE_VIEW_UNQUALIFIED'
    end
    local item,market,provenance,roles,freshness=field(view,'item'),field(view,'market'),
        field(view,'provenance'),field(view,'roles'),field(view,'freshness')
    local id=I.Items and I.Items:Parse(requested)
    if not I:Integer(id) or field(item,'itemID')~=id or field(item,'requestedLink')~=requested or
        field(item,'precision')~='EXACT_WEALTHCRAFT_VARIANT' or not I:Label(field(item,'identity'),260) then
        return nil,'EXACT_LINK_PROOF_MISSING'
    end
    if field(market,'key')~=key then return nil,'MARKET_SCOPE_MISMATCH' end
    local mode=field(market,'mode')
    if (mode~='CURRENT' and mode~='LAST_SAVED') or
        not venueStatuses[field(market,'venueStatus')] or field(market,'venueVerified')~=false then
        return nil,'MARKET_SCOPE_UNKNOWN'
    end
    local source,coverage=field(provenance,'source'),field(provenance,'coverage')
    local snapshot=field(provenance,'snapshotID')
    if not I:Label(source,100) or sources[source]~=coverage or not I:Label(snapshot,180) or
        not I:Integer(field(provenance,'revision')) or
        field(provenance,'completeDepth')~=(coverage=='COMPLETE_REPLICATION') then
        return nil,'SOURCE_SNAPSHOT_UNQUALIFIED'
    end
    local reference=field(roles,'reference')
    local price=field(reference,'valueCopper')
    if field(reference,'kind')~='HISTORICAL_REFERENCE' or
        field(reference,'basis')~='ONE_ITEM' or not validPrice(price) or
        price~=field(view,'priceCopper') then return nil,'NO_VERIFIED_REFERENCE_PRICE' end
    local age,observed=field(freshness,'ageSeconds'),field(freshness,'observedAt')
    if not I:Number(age) or age<0 or age>315360000 or not I:Integer(observed) then
        return nil,'PRICE_AGE_UNKNOWN'
    end
    local maxAge=ageLimit()
    if not maxAge then return nil,'PRICE_AGE_UNKNOWN' end
    local stackValue,stackCopper,stackBasis=field(view,'stackCount'),field(view,'stackCopper'),field(view,'stackBasis')
    if stack==nil then
        if stackValue~=nil or stackCopper~=nil or stackBasis~='NOT_SUPPLIED' then return nil,'STACK_BASIS_MISMATCH' end
    elseif stackValue~=stack or (stackBasis~='CALLER_OBSERVED_COUNT' and stackBasis~='TOTAL_EXCEEDS_SUPPORTED_RANGE') or
        (stackBasis=='CALLER_OBSERVED_COUNT' and (not validPrice(stackCopper) or stackCopper~=price*stack)) or
        (stackBasis=='TOTAL_EXCEEDS_SUPPORTED_RANGE' and (stackCopper~=nil or price<=math.floor(9000000000000/stack))) then
        return nil,'STACK_BASIS_MISMATCH'
    end
    local status=field(view,'status')
    if status~='STALE' and status~='LIMITED' and status~='AVAILABLE' then return nil,'PROVIDER_QUOTE_BLOCKED' end
    local average=field(field(roles,'average'),'valueCopper')
    local measured=field(roles,'measuredRange')
    local lo,hi=field(measured,'lowerCopper'),field(measured,'upperCopper')
    return {priceCopper=price,averageCopper=validPrice(average) and average or nil,
        measuredLowCopper=validPrice(lo) and lo or nil,measuredHighCopper=validPrice(hi) and hi or nil,
        marketKey=key,ageSeconds=age,observedAt=observed,requestedLink=requested,itemID=id,
        identity=field(item,'identity'),identityPrecision=field(item,'precision'),
        source=source,snapshotID=snapshot,sourceSnapshotID=snapshot,
        sourceRevision=field(provenance,'revision'),coverage=coverage,
        completeDepth=field(provenance,'completeDepth'),priceBasis='OBSERVED_ASK_REFERENCE_PER_UNIT',unitBasis='ONE_ITEM',
        stackCount=stackValue,stackCopper=stackCopper,stackBasis=stackBasis,
        method=field(provenance,'method'),stale=status=='STALE' or age>maxAge,
        venueStatus=field(market,'venueStatus'),venueVerified=false,marketContextMode=mode,
        marketContextSource=I:Label(field(market,'source'),100),
        marketLabel=I:Label(field(market,'label'),200),sourceBuild=field(market,'sourceBuild'),
        provider='Wealthcraft',providerAPI=6,priceViewContractVersion=1,
        status='HISTORICAL_OBSERVATION_NATIVE_UNTESTED',confidence='Recorded asking prices',
        salesEvidence='NOT_CLAIMED',profitEvidence='NOT_CLAIMED',nativeQualification='NOT_RUN'},'AVAILABLE'
end
local function validateLegacy(value,key,itemKey,version)
    if not I:Readable(value) or type(value)~='table' then return nil,'PROVIDER_RESULT_UNAVAILABLE' end
    local status=field(value,'status')
    if not I:Text(status,100) or status=='BLOCKED' or status=='UNAVAILABLE' or status=='INVALID' then return nil,'PROVIDER_QUOTE_BLOCKED' end
    if field(value,'marketKey')~=key then return nil,'MARKET_SCOPE_MISMATCH' end
    if version==6 and status~='LIMITED_EVIDENCE' and status~='STRONG_LOCAL_EVIDENCE' and status~='STALE' then
        return nil,'PROVIDER_QUOTE_BLOCKED'
    end
    if version==4 or version==6 then
        local identity=field(value,'identity')
        if not I:Text(identity,260) then return nil,'WEALTHCRAFT_IDENTITY_UNKNOWN' end
        if type(itemKey)=='number' then
            local base='id='..itemKey..';e=0;g=0,0,0,0;s=0;b='
            if identity~=base or field(value,'completeDepth')~=true then return nil,'NON_BASE_OR_PARTIAL_VARIANT' end
        else
            local requestedID=I.Items and I.Items:Parse(itemKey)
            if not I:Integer(requestedID) or field(value,'requestedLink')~=itemKey or
                identity:match('^id=(%d+);')~=tostring(requestedID) or
                field(value,'sourceAPI')~='WEALTHCRAFT_V4_EXACT_LINK_BRIDGE_1' then return nil,'EXACT_LINK_PROOF_MISSING' end
        end
    else
        local precision=field(value,'identityPrecision')
        if type(itemKey)=='number' then
            if field(value,'itemID')~=itemKey or precision~='EXACT_ITEM_ID' then return nil,'ITEM_VARIANT_UNVERIFIED' end
        elseif field(value,'itemKey')~=itemKey or precision~='EXACT_LINK' then return nil,'ITEM_LINK_NOT_VERIFIED' end
    end
    local price,age=field(value,'priceCopper'),field(value,'ageSeconds')
    if not validPrice(price) then return nil,'NO_VERIFIED_REFERENCE_PRICE' end
    if not I:Number(age) or age<0 or age>315360000 then return nil,'PRICE_AGE_UNKNOWN' end
    local source=field(value,'source')
    if not I:Label(source,100) or (version==6 and source~='PLAYER_INITIATED_FULL_SCAN' and source~='AUTO_FULL_SCAN') then return nil,'PRICE_PROVENANCE_UNKNOWN' end
    if version==6 and not venueStatuses[field(value,'venueStatus')] then return nil,'MARKET_SCOPE_UNKNOWN' end
    local maxAge=ageLimit();if not maxAge then return nil,'PRICE_AGE_UNKNOWN' end
    return {priceCopper=price,marketKey=key,ageSeconds=age,source=source,
        identityPrecision=type(itemKey)=='number' and 'BASE_ITEM' or 'EXACT_REQUESTED_LINK',
        requestedLink=type(itemKey)=='string' and itemKey or nil,
        snapshotID=I:Label(field(value,'snapshotID'),180),confidence=I:Label(field(value,'confidence') or status,100) or 'Unclassified',
        stale=status=='STALE' or age>maxAge,identity=field(value,'identity'),
        venueStatus=I:Label(field(value,'venueStatus'),100) or 'Venue not independently verified',
        completeDepth=field(value,'completeDepth')==true,provider='Wealthcraft',providerAPI=version,
        priceBasis='OBSERVED_ASK_REFERENCE_PER_UNIT',unitBasis='ONE_ITEM',stackBasis='NOT_SUPPLIED',
        status='HISTORICAL_OBSERVATION_NATIVE_UNTESTED'},'AVAILABLE'
end
function M:Get(itemKey,context)
    if not I:Integer(itemKey) and not I:Text(itemKey,600) then return nil,'BAD_ITEM_KEY' end
    local exact=type(itemKey)=='string'
    local api,key,reason=provider(exact)
    if not api then return nil,reason end
    local stack=field(context,'stackCount')
    if stack~=nil and (not I:Integer(stack) or stack>1000000) then return nil,'INVALID_STACK_COUNT' end
    local fn=api.GetPrice
    local useView=exact and api.apiVersion==6 and field(api,'priceViewContractVersion')==1 and
        type(field(api,'GetPriceViewForItemLink'))=='function'
    if useView then fn=api.GetPriceViewForItemLink
    elseif exact and api.apiVersion==6 then fn=api.GetQuoteForItemLink
    elseif exact and api.apiVersion==4 then
        fn=api.GetExactPriceForItemLink
        if type(fn)~='function' then return nil,'WEALTHCRAFT_V4_LINK_BRIDGE_NOT_INSTALLED' end
    end
    local ok,value,why=pcall(fn,itemKey,{marketKey=key,consumer=OWNER,readOnly=true,stackCount=stack})
    if not ok then return nil,'PROVIDER_QUERY_FAILED' end
    if value==nil then return nil,I:Label(why,100) or 'PROVIDER_RESULT_UNAVAILABLE' end
    local result,status
    if useView then result,status=validatePriceView(value,key,itemKey,stack)
    elseif exact and api.apiVersion==6 then result,status=validateExact(value,key,itemKey,stack)
    else result,status=validateLegacy(value,key,itemKey,api.apiVersion) end
    -- Do not publish an answer from a removed/replaced provider or a market that
    -- changed while its callbacks ran. No saved quote cache is written on hover.
    if result then
        local after,afterKey=provider(exact)
        if after~=api or afterKey~=key then return nil,'MARKET_SCOPE_CHANGED' end
    end
    return result,status
end
function M:CraftRevision()
    local api,key,reason=provider(false)
    if not api then return nil,reason end
    local version=field(api,'apiVersion')
    local token
    if version==6 then
        local fn=field(api,'GetQuoteRevision')
        if type(fn)~='function' then return nil,'PRICE_REVISION_UNAVAILABLE' end
        local ok,value=pcall(fn)
        token=ok and I:Text(value,600) or nil
        if not token then return nil,'PRICE_REVISION_UNAVAILABLE' end
    end
    -- The public revision includes source object identities. A new same-time
    -- scan cannot masquerade as the same analysis merely by reusing its label.
    local current,currentKey=provider(false)
    if current~=api or currentKey~=key then return nil,'MARKET_SCOPE_CHANGED' end
    return {api=api,key=key,version=version,token=token},'AVAILABLE'
end
function M:HasTooltipSection(tooltip,link,section)
    local api=self.ownerAPI or WealthcraftAPI
    local fn=field(api,'HasTooltipSection')
    if type(fn)~='function' or field(api,'tooltipSectionContractVersion')~=1 then return nil end
    local ok,owner=pcall(fn,tooltip,link,section or 'market')
    return ok and I:Label(owner,60) or nil
end
function M:TooltipRevision()
    local p=preferences()
    local api=WealthcraftAPI
    if not I:Readable(api) then api=nil end
    if api~=self.revisionAPI then
        self.revisionAPI=api;self.providerEpoch=(self.providerEpoch or 0)+1
    end
    local token,why
    local fn=field(api,'GetQuoteRevision')
    if field(p,'marketProvider')~='Wealthcraft' or field(p,'showMarketTooltip')~=true then token='PRICE_PROVIDER_OFF'
    elseif field(api,'quoteContractVersion')~=1 or type(fn)~='function' then token='QUOTE_REVISION_UNAVAILABLE'
    else
        local ok,value,reason=pcall(fn)
        token=ok and I:Text(value,600) or nil
        why=I:Label(reason,100)
    end
    local clock=I:Now()
    local bucket=I:Number(clock) and math.floor(clock/30) or 0
    local revision=field(I.Storage.account,'revision')
    return table.concat({self.providerEpoch or 0,token or why or 'QUOTE_REVISION_UNAVAILABLE',
        I:Number(revision) and revision or 0,bucket},':')
end
function M:InstallTooltipOwner()
    if not self.settingsSubscribed and I.core and type(I.core.Subscribe)=='function' then
        local ok,subscribed=pcall(I.core.Subscribe,'INSIGHT_SETTINGS_CHANGED','MirageInsightMarket',function(payload)
            local key=field(payload,'key')
            if key then
                -- Withdraw or rebuild the old companion before returning its
                -- market lease, including direct Storage preference callers.
                -- Any display preference can change the available layout.
                if I.Tooltip and type(I.Tooltip.RefreshVisible)=='function' then
                    pcall(I.Tooltip.RefreshVisible,I.Tooltip,'SETTINGS_CHANGED')
                end
                M:RefreshTooltipOwner()
            end
        end)
        self.settingsSubscribed=ok and subscribed==true
    end
    local api=WealthcraftAPI
    if field(api,'tooltipSectionContractVersion')~=1 or type(field(api,'RegisterTooltipSectionConsumer'))~='function' then
        return false,'SECTION_CONTRACT_UNAVAILABLE'
    end
    if self.ownerAPI==api and self.ownerResolver then return true end
    if self.ownerAPI and self.ownerResolver and type(field(self.ownerAPI,'UnregisterTooltipSectionConsumer'))=='function' then
        pcall(self.ownerAPI.UnregisterTooltipSectionConsumer,OWNER,self.ownerResolver)
    end
    local resolver=function(tooltip,data)
        local p=preferences()
        if WealthcraftAPI~=api or field(p,'tooltip')~=true or field(p,'marketProvider')~='Wealthcraft' or
            field(p,'showMarketTooltip')~=true or not I.Tooltip or type(I.Tooltip.ClaimMarket)~='function' then return false end
        local ok,claimed=pcall(I.Tooltip.ClaimMarket,I.Tooltip,tooltip,data)
        return ok and I:Readable(claimed) and claimed==true
    end
    local ok,registered=pcall(api.RegisterTooltipSectionConsumer,OWNER,resolver)
    if not ok or registered~=true then return false,'SECTION_REGISTRATION_FAILED' end
    self.ownerAPI,self.ownerResolver=api,resolver
    return true
end
function M:RefreshTooltipOwner()
    self:InstallTooltipOwner()
    local api=self.ownerAPI
    local fn=field(api,'RefreshTooltipSections')
    if type(fn)=='function' then return pcall(fn,OWNER) end
    return false
end
local labels={
    PRICE_PROVIDER_OFF='Price comparison is off.',WEALTHCRAFT_NOT_PRESENT='Wealthcraft is not loaded.',
    WEALTHCRAFT_VERSION_NOT_QUALIFIED='This Wealthcraft version is not supported.',
    WEALTHCRAFT_API_INCOMPLETE='Wealthcraft price service is unavailable.',
    NO_COMPLETE_SCAN='No complete Wealthcraft scan for this market.',
    NO_EXACT_LINK_OBSERVATION='No recorded asking price for this exact variation.',
    NO_PRICED_LISTINGS='Recorded listings have no priced buyout; value is unknown.',
    MARKET_SCOPE_UNKNOWN='The recorded market scope is unknown.',
    MARKET_SCOPE_MISMATCH='The quote is for a different market.',
    MARKET_SCOPE_CHANGED='The market changed; this observation was withheld.',
    SOURCE_SNAPSHOT_CHANGED='The source changed while reading; retry the current item.',
    SOURCE_SNAPSHOT_UNQUALIFIED='The source snapshot could not be verified.',
    SOURCE_RECORD_UNQUALIFIED='The saved observation could not be qualified.',
    PRICE_BASIS_UNKNOWN='The observed price basis is unknown.',
    NON_BASE_OR_PARTIAL_VARIANT='No complete quote for the base item.',
    PRICE_AGE_UNKNOWN='The quote age cannot be verified.',
    WEALTHCRAFT_V6_EXACT_LINK_ADAPTER_NOT_QUALIFIED='Update Wealthcraft for exact item-link observations.',
    WEALTHCRAFT_V4_LINK_BRIDGE_NOT_INSTALLED='The exact item-link bridge is not installed.',
    FULL_ITEM_LINK_REQUIRED_FOR_MARKET_VARIANTS='Enter an item link to inspect a specific variation.',
    FULL_ITEM_LINK_REQUIRED='A complete item link is required for variation prices.',
    NO_VERIFIED_REFERENCE_PRICE='No recorded reference price for this item.',
    INVALID_STACK_COUNT='The displayed stack count could not be verified.',
    STACK_BASIS_MISMATCH='The quote does not match the displayed stack.',
    UNSUPPORTED_CLIENT='Wealthcraft has not qualified this client.',
    STORAGE_UNAVAILABLE='Wealthcraft history is unavailable in this session.',
}
function M:Describe(reason) return labels[reason] or 'No verified observation for this item.' end
function M:AgeLabel(seconds)
    if not I:Number(seconds) or seconds<0 then return 'unknown age' end
    if seconds<60 then return 'less than 1 min ago' end
    if seconds<3600 then return math.floor(seconds/60)..' min ago' end
    if seconds<86400 then return math.floor(seconds/3600)..' hr ago' end
    return math.floor(seconds/86400)..' d ago'
end
function M:SourceLabel(quote)
    if quote.source=='AUTO_FULL_SCAN' then return 'Wealthcraft automatic complete scan' end
    if quote.source=='PLAYER_INITIATED_FULL_SCAN' then return 'Wealthcraft complete scan' end
    if quote.source=='PARTIAL_REPLICATION_EXACT_LINKS' then return 'Wealthcraft partial scan sample' end
    if quote.source=='PLAYER_INITIATED_TARGET_SEARCH' then return 'Wealthcraft targeted search sample' end
    if quote.source=='AH_OPEN_QUICK_REFRESH' then return 'Wealthcraft Auction House refresh sample' end
    return 'Wealthcraft recorded observation'
end
function M:Status()
    local api,key,reason=provider(true)
    return {enabled=field(preferences(),'marketProvider')=='Wealthcraft',available=api~=nil,
        marketKey=key,reason=reason,providerAPI=api and api.apiVersion,
        exactLinkBridge=api and ((api.apiVersion==6 and api.quoteContractVersion==1) or
            (api.apiVersion==4 and type(api.GetExactPriceForItemLink)=='function')) or false,
        quoteContractVersion=api and field(api,'quoteContractVersion'),
        sectionContractVersion=field(self.ownerAPI,'tooltipSectionContractVersion'),
        liveVerified=false,contract='Exact-link observed asks via public adapter; base-item crafting requires complete scans; no sales or profit claims'}
end
