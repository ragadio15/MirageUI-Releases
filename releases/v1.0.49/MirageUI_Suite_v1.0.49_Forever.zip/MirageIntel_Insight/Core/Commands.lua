local _,I=...
I.Commands={}
local K=I.Commands
function K:Run(value)
    local msg=type(value)=="string" and value:match("^%s*(.-)%s*$") or ""
    if msg=="" or msg=="open" or msg=="settings" or msg=="browse" then
        local ok,why=I.UI:Open();if not ok then I:Print(why) end;return
    end
    if msg=="inspect" then
        local ok,why=I.Tooltip:OpenInspector()
        if not ok then I:Print("Point at an item, then use /minsight inspect.") end
        return
    end
    if msg=="status" then
        local s=I.Storage:Status()
        I:Print(I.version.." | recipes="..s.recipeCount.." | professions="..s.professionCount..
            " | scan="..I.Recipes.lastScan.." | tooltip="..I.Tooltip.status)
        return
    end
    if msg=="scan" then
        local ok,why=I.Recipes:Start()
        I:Print(ok and "Updating your profession." or I.Recipes:DescribeScan(why));return
    end
    local cmd,arg=msg:match("^(%S+)%s+(.+)$")
    if cmd=="item" or cmd=="sources" then
        local ok,why=I.Tooltip:OpenItem(arg);if not ok then I:Print(why) end;return
    end
    local names={tooltip="tooltip",recipes="showRecipes",vendor="showVendorTooltip",market="showMarketTooltip",
        markettip="showMarketTooltip",autoscan="autoScan",locations="showLocations",quests="showQuestUses"}
    if names[cmd] and (arg=="on" or arg=="off") then
        if names[cmd]=="showMarketTooltip" and arg=="on" then I.API:SetPreference("marketProvider","Wealthcraft") end
        local ok=I.API:SetPreference(names[cmd],arg=="on")
        if ok then I:Print(cmd.." "..arg) end;return
    end
    I:Print("/minsight — settings · /minsight inspect — pin an item tooltip · /minsight item <link or number>")
end
function K:Install()
    BINDING_HEADER_MIRAGEINSIGHT="[MUI] Insight"
    BINDING_NAME_MIRAGEINSIGHT_INSPECT="Pin current item tooltip"
    SLASH_MIRAGEINSIGHT1="/minsight";SLASH_MIRAGEINSIGHT2="/mi"
    SlashCmdList.MIRAGEINSIGHT=function(msg)K:Run(msg)end
end
