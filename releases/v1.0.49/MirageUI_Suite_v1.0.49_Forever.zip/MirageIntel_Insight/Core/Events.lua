local _,I=...
local frame=CreateFrame("Frame")
I.eventFrame=frame
local events={"ADDON_LOADED","PLAYER_LOGIN","TRADE_SKILL_SHOW","TRADE_SKILL_CLOSE","TRADE_SKILL_LIST_UPDATE",
    "TRADE_SKILL_DETAILS_UPDATE","TRADE_SKILL_NAME_UPDATE","TRADE_SKILL_DATA_SOURCE_CHANGING",
    "TRADE_SKILL_DATA_SOURCE_CHANGED","NEW_RECIPE_LEARNED","SKILL_LINES_CHANGED",
    "PLAYER_LEAVING_WORLD","PLAYER_ENTERING_WORLD","PLAYER_REGEN_DISABLED","PLAYER_REGEN_ENABLED",
    "ITEM_DATA_LOAD_RESULT","GET_ITEM_INFO_RECEIVED","MODIFIER_STATE_CHANGED"}
I.state.registeredEvents={};I.state.unavailableEvents={}
for _,event in ipairs(events) do
    local ok=pcall(frame.RegisterEvent,frame,event)
    if ok then I.state.registeredEvents[event]=true else I.state.unavailableEvents[event]=true end
end
frame:SetScript("OnEvent",function(_,event,...)
    if (event=="ADDON_LOADED" and (...==I.name or ...=="MirageIntel_Core")) or
        event=="PLAYER_LOGIN" or event=="PLAYER_ENTERING_WORLD" then
        if I.state.initialized and I.state.clientAllowed~=true then
            I.core=MirageIntelCoreAPI or I.core
            if I:Allowed() then I.state.initialized=false end
        end
        if not I.state.initialized and (I.state.initializationAttempts or 0)<3 then
            local ok=pcall(I.Initialize,I)
            if not ok then I:Fault("INITIALIZE_FAILED");I.state.status="INITIALIZE_FAILED" end
        end
    end
    if not I.state.initialized then return end
    I.state.events=I.state.events+1
    if event=="PLAYER_LEAVING_WORLD" or event=="PLAYER_REGEN_DISABLED" then I.UtilityCard:Hide() end
    -- Invalidation precedes refresh. No item hover starts a profession or
    -- auction scan, and each subsystem owns its own cancellation rules.
    local function deliver(object,method,...)
        if object and type(object[method])=="function" then
            local ok=pcall(object[method],object,...)
            if not ok then I:Fault("EVENT_HANDLER_FAILED_"..event) end
        end
    end
    deliver(I.Items,"OnEvent",event,...)
    deliver(I.Recipes,"OnEvent",event,...)
    deliver(I.Tooltip,"OnEvent",event,...)
    if event=="ITEM_DATA_LOAD_RESULT" or event=="GET_ITEM_INFO_RECEIVED" then
        local id,success=...
        deliver(I.UI,"ItemDataLoaded",id,success)
    end
end)
