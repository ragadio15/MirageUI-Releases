local _,I=...
-- One read-only item model for passive cards and the explicit inspector.
-- Recipe and location relationships use base item IDs; market variants do not.
I.Context={revision=0,builds=0,maxRows=24,cacheHits=0,cacheSeconds=.25}
local X=I.Context
local function prefs() return I.Storage.account and I.Storage.account.preferences or {} end
function X:Service(name)
    local core=I.core
    if type(core)~="table" or type(core.GetService)~="function" then return nil end
    local service,ok=I:Call(core.GetService,name,1)
    return ok and type(service)=="table" and service or nil
end
local function sameLink(a,b)
    if not I:Text(a,600) or not I:Text(b,600) then return false end
    local function key(s) return s:match("|H(item:[^|]+)|h") or s end
    return key(a)==key(b)
end
function X:QuestUse(link,context)
    local bag=context.bagID
    local slot=context.slotIndex
    if not I:Number(bag) or bag%1~=0 or bag< -20 or bag>100 or not I:Integer(slot) or slot>256 then
        return {status="NO_QUALIFIED_BAG_CONTEXT",rows={}}
    end
    local container=type(C_Container)=="table" and C_Container
    if not container or type(container.GetContainerItemLink)~="function" or
        type(container.GetContainerItemQuestInfo)~="function" then return {status="QUEST_API_UNAVAILABLE",rows={}} end
    local before,ok=I:Call(container.GetContainerItemLink,bag,slot)
    if not ok or not sameLink(link,before) then return {status="BAG_IDENTITY_CHANGED",rows={}} end
    local q,readable=I:Call(container.GetContainerItemQuestInfo,bag,slot)
    local after,checked=I:Call(container.GetContainerItemLink,bag,slot)
    if not checked or not sameLink(before,after) then return {status="BAG_IDENTITY_CHANGED",rows={}} end
    if not readable or type(q)~="table" or not I:Readable(q.isQuestItem) or
        not I:Readable(q.questID) or not I:Readable(q.isActive) then return {status="QUEST_CONTEXT_UNAVAILABLE",rows={}} end
    local result={status="QUALIFIED_BAG_QUEST_FACT",isQuestItem=q.isQuestItem==true,rows={}}
    if I:Integer(q.questID) then
        local title
        if type(C_QuestLog)=="table" then title=I:Call(C_QuestLog.GetTitleForQuestID,q.questID) end
        result.rows[1]={questID=q.questID,title=I:Label(title,180),active=q.isActive==true,
            source="NATIVE_BAG_QUEST_ASSOCIATION"}
    end
    return result
end
function X:Locations(itemID,options)
    options=options or {}
    local records=self:Service("WorldRecords")
    if not records or type(records.QueryItem)~="function" then return {records={},status="LOCATION_INDEX_UNAVAILABLE"} end
    local limit=I:Integer(options.limit) and math.min(options.limit,32) or 6
    local mapID=options.mapID
    if options.scope~="all" and mapID==nil and type(I.core.GetPlayerPosition)=="function" then
        local p,ok=I:Call(I.core.GetPlayerPosition)
        if ok and type(p)=="table" and I:Integer(p.mapID) then mapID=p.mapID end
    end
    local found,ok
    if options.scope~="all" and I:Integer(mapID) then
        found,ok=I:Call(records.QueryItem,itemID,{mapID=mapID,limit=limit,cursor=options.cursor})
    end
    local localMatch=ok and type(found)=="table" and type(found.records)=="table" and #found.records>0
    -- A continuation cursor belongs to one exact map scope and world revision.
    -- Never reinterpret a stale local cursor as a fresh global query.
    if options.scope~="all" and options.cursor~=nil and ok and type(found)=="table" then
        localMatch=true
    end
    if not localMatch then found,ok=I:Call(records.QueryItem,itemID,{limit=limit,cursor=options.cursor}) end
    if not ok or type(found)~="table" or type(found.records)~="table" then return {records={},status="LOCATION_INDEX_UNAVAILABLE"} end
    found=I:Copy(found)
    if not found then return {records={},status="LOCATION_CONTEXT_UNREADABLE"} end
    found.scope=localMatch and "CURRENT_MAP_RECORDED_LOCATIONS" or "ALL_RECORDED_MAPS"
    found.liveAvailability="NOT_CLAIMED"
    return found
end
local function currentMap()
    if type(I.core)~="table" or type(I.core.GetPlayerPosition)~="function" then return nil end
    local player,ok=I:Call(I.core.GetPlayerPosition)
    if not ok or not I:Readable(player) or type(player)~="table" then return nil end
    local mapID,read=I:Call(function()return player.mapID end)
    return read and I:Integer(mapID) and mapID or nil
end
local function modelKey(item,options,p,professionOpen,detail,mapID)
    local function scalar(value)
        if value==nil then return "nil" end
        if not I:Readable(value) then return "unreadable" end
        local kind=type(value)
        if kind=="boolean" or I:Number(value) or I:Text(value,600) then return kind..":"..tostring(value) end
        return "invalid"
    end
    local account,character=I.Storage.account,I.Storage.character
    return table.concat({scalar(item),scalar(options.recipeID),scalar(options.bagID),scalar(options.slotIndex),
        scalar(options.stackCount),scalar(options.limit),scalar(options.family),scalar(professionOpen),scalar(detail),
        scalar(p.showItemID),scalar(p.showVendorTooltip),scalar(p.showRecipes),scalar(p.showQuestUses),
        scalar(p.showLocations),scalar(p.professionDetails),scalar(account and account.revision),
        scalar(character and character.revision),scalar(I.Items.revision),scalar(I.Items.generation),
        scalar(I.Recipes.revision),scalar(I.Recipes.generation),scalar(I.Recipes.tooltipRevision),scalar(X.revision),
        scalar(mapID)},"\031")
end
function X:Build(item,options)
    options=type(options)=="table" and options or {}
    if not I.state.clientAllowed then return nil,"UNSUPPORTED_BUILD" end
    local itemID,link=I.Items:Parse(item)
    if not itemID then return nil,link end
    local p=prefs()
    local professionOpen=I.Recipes.IsProfessionOpen and I.Recipes:IsProfessionOpen() or false
    local detail=options.detail==true and professionOpen and p.professionDetails~=false
    local clock,clockOK=I:Call(GetTime)
    local repeatedRecipe=options.family=="RECIPE_OUTPUT" or options.family=="RECIPE_REAGENT"
    local cacheable=options.passiveTooltip==true and repeatedRecipe and clockOK and I:Number(clock) and clock>=0
    local mapID=cacheable and p.showLocations~=false and currentMap() or nil
    local key=cacheable and modelKey(item,options,p,professionOpen,detail,mapID)
    local cached=self.modelCache
    if key and cached and cached.key==key and cached.account==I.Storage.account and
        cached.character==I.Storage.character and clock>=cached.at and clock-cached.at<self.cacheSeconds then
        local model=I:Copy(cached.model)
        if model then self.cacheHits=self.cacheHits+1;return model,"AVAILABLE" end
    end
    local facts=I.Items:Facts(item)
    local relation=I.Recipes:Find(itemID,detail and 6 or 2)
    local activeRecipe
    if detail and I.Recipes.GetTooltipRecipe and I:Integer(options.recipeID) then
        activeRecipe=I.Recipes:GetTooltipRecipe(options.recipeID,itemID)
    end
    -- The native reagent setter supplies the consuming recipe's ID. Its
    -- output is a different item; never label it as this reagent's recipe.
    local activeRecipeRole=activeRecipe and (activeRecipe.outputID==itemID and "PRODUCES_ITEM" or "CONSUMES_ITEM")
    local location=p.showLocations~=false and self:Locations(itemID,{limit=detail and 6 or 1}) or {records={},status="OFF"}
    local quest=p.showQuestUses~=false and self:QuestUse(link or item,options) or {rows={},status="OFF"}
    local result={itemID=itemID,link=link,item=item,facts=facts,relations=relation,questUses=quest,
        locations=location.records,locationStatus=location.status,locationScope=location.scope,
        locationTotal=location.totalMatched or 0,worldRevision=location.revision,revision=self.revision,
        rows={},status="READ_ONLY_CONTEXT",professionOpen=professionOpen,
        activeRecipeID=activeRecipe and activeRecipe.id,activeRecipeRole=activeRecipeRole,
        itemDependencies={},
        family=I:Label(options.family,48) or "ITEM"}
    local max=I:Integer(options.limit) and math.min(self.maxRows,options.limit) or 14
    local function row(label,value,role,section,vendorBasis)
        if #result.rows<max and I:Text(value,600) then
            result.rows[#result.rows+1]={label=label,value=value,text=label..": "..value,
                role=role or "text",section=section or "facts",vendorBasis=vendorBasis}
        end
    end
    local classification=I.Items.Classification and I.Items:Classification(facts,quest)
    if p.showItemID~=false then
        row("Item number",tostring(itemID)..(classification and " · "..classification or ""),"muted","facts")
    elseif classification then row("Type",classification,"muted","facts") end
    if facts and p.showVendorTooltip~=false and facts.vendorCopper~=nil then
        row(facts.vendorCopper==0 and "Vendor value" or "Vendor price (each)",
            facts.vendorCopper==0 and "No vendor value" or I.Items:Coin(facts.vendorCopper,true),"text","vendor","UNIT")
        if facts.vendorCopper>0 and I:Integer(options.stackCount) and options.stackCount>1 and options.stackCount<=10000 and
            facts.vendorCopper*options.stackCount<=9007199254740991 then
            row("Vendor price ("..options.stackCount.." items)",I.Items:Coin(facts.vendorCopper*options.stackCount,true),"muted","vendor","STACK")
        end
    end
    if p.showRecipes~=false then
        local professions=I.Recipes.ProfessionsForItem and I.Recipes:ProfessionsForItem(itemID) or {}
        if activeRecipe and I:Label(activeRecipe.professionName,120) then
            local present=false;for _,name in ipairs(professions) do if name==activeRecipe.professionName then present=true end end
            if not present then professions[#professions+1]=activeRecipe.professionName;table.sort(professions) end
        end
        if #professions>0 then row("Crafting",table.concat(professions,", "),"accent","recipes") end
    end
    for _,q in ipairs(quest.rows or {}) do
        if q.title then row("Quest",q.title,"accent","quest") end
    end
    if #result.locations>0 then
        local r=result.locations[1]
        local zone
        if type(C_Map)=="table" and type(C_Map.GetMapInfo)=="function" then
            local info=I:Call(C_Map.GetMapInfo,r.mapID)
            if I:Readable(info) and type(info)=="table" then zone=I:Label(info.name,100) end
        end
        if I:Label(r.label,160) and I:Number(r.x) and I:Number(r.y) then
            row("Recorded location",r.label..(zone and " · "..zone or "")..
                string.format(" · %.1f, %.1f",r.x*100,r.y*100),"muted","locations")
        end
    end
    if detail and p.showRecipes~=false then
        if activeRecipe then
            row(activeRecipeRole=="CONSUMES_ITEM" and "Used in recipe" or "Recipe",
                activeRecipe.name..(activeRecipe.learned==false and " · Not learned" or ""),"accent","recipe_details")
        end
        local used=0
        for _,r in ipairs(relation.usedBy or {}) do
            if r.current~=false and I:Label(r.name,120) and used<4 and (not activeRecipe or r.id~=activeRecipe.id) then
                row("Used in",r.name..(r.learned==false and " · Not learned" or ""),"text","recipe_details")
                used=used+1
            end
        end
        local recipe=activeRecipe
        for _,r in ipairs(relation.produced or {}) do
            if recipe then break end
            if r.current~=false then
                row("Recipe",r.name..(r.learned==false and " · Not learned" or ""),"text","recipe_details")
                recipe=I.Storage.character and I.Storage.character.recipes[r.id]
                break
            end
        end
        if recipe and I.Storage.ValidRecipe(recipe) then
            if recipe.quantityMin and recipe.quantityMax and recipe.quantityMax>1 then
                row(activeRecipeRole=="CONSUMES_ITEM" and "Recipe creates" or "Creates",
                    recipe.quantityMin==recipe.quantityMax and tostring(recipe.quantityMin) or
                    (recipe.quantityMin.."–"..recipe.quantityMax),"text","recipe_details")
            end
            local n=0
            for _,slot in ipairs(recipe.slots or {}) do
                if #result.rows>=max then break end
                if slot.required and #slot.choices==1 and n<5 then
                    local id=slot.choices[1]
                    -- Only the current visible model retains these bounded
                    -- material dependencies; no global per-item subscriptions.
                    result.itemDependencies[id]=true
                    local f=I.Items:Facts(id)
                    row(activeRecipeRole=="CONSUMES_ITEM" and "Recipe material" or "Material",
                        slot.quantity.." × "..(f and f.name or ("Item #"..id)),"muted","recipe_details")
                    n=n+1
                end
            end
        end
    end
    self.builds=self.builds+1
    -- Native profession output tooltips are refreshed every frame. Reuse one
    -- short-lived, copied context model for that exact item/recipe. Ordinary
    -- item and bag tooltips keep fresh quest-association reads. Source,
    -- preference, stack and profession revisions end the reuse immediately;
    -- explicit inspector/API requests remain fresh reads. No frames or native
    -- tooltip data are retained here, and market ownership is resolved later.
    local finalMap=key and prefs().showLocations~=false and currentMap() or nil
    if key and key==modelKey(item,options,prefs(),professionOpen,detail,finalMap) then
        self.modelCache={key=key,at=clock,model=I:Copy(result),account=I.Storage.account,character=I.Storage.character}
    end
    return result,"AVAILABLE"
end
function X:Initialize()
    if self.subscribed or not I.state.clientAllowed or type(I.core)~="table" or type(I.core.Subscribe)~="function" then return end
    local function changed()
        X.revision=X.revision+1;X.modelCache=nil
        if I.Tooltip and I.Tooltip.RefreshVisible then I.Tooltip:RefreshVisible("SOURCE_REVISION") end
        if I.UI and I.UI.SourceChanged then I.UI:SourceChanged() end
    end
    local a=I:Call(I.core.Subscribe,"WORLD_RECORDS_CHANGED","MirageIntel_Insight",changed)
    local b=I:Call(I.core.Subscribe,"RECIPE_CATALOG_READY","MirageIntel_Insight",changed)
    self.subscribed=a==true and b==true
end
function X:GetStatus()
    return {revision=self.revision,builds=self.builds,subscribed=self.subscribed==true,
        cacheHits=self.cacheHits,cacheEntries=self.modelCache and 1 or 0,cacheMaximum=1,cacheSeconds=self.cacheSeconds,
        locations="EXPLICIT_INDEXED_ASSOCIATIONS",questUses="QUALIFIED_NATIVE_BAG_CONTEXT",hoverNavigation="NEVER"}
end
