local _,I=...
I.Analysis={}
local A=I.Analysis
local function safeAmount(x)
    return I:Number(x) and x>=0 and x%1==0 and x<=9000000000000000
end
local function knowledge(rec,result)
    local current=rec.knowledgeState~="HISTORICAL_NOT_IN_LATEST_COMPLETE"
    result.current=current;result.learnedObserved=rec.learned
    if current then result.learned=rec.learned end
    result.knowledgeState=rec.professionID==nil and "LEGACY_UNSCOPED" or
        (current and "CURRENT_CHARACTER_OBSERVED" or "HISTORICAL_NOT_IN_LATEST_COMPLETE")
    return result
end
function A:Craft(recipeID)
    if not I:Integer(recipeID) then return nil,"INVALID_RECIPE" end
    local recipes=I.Storage.character and I.Storage.character.recipes
    local rec=type(recipes)=="table" and recipes[recipeID]
    if not rec or not I.Storage.ValidRecipe(rec) then return nil,"RECIPE_NOT_SCANNED" end
    if rec.incomplete then return knowledge(rec,{recipeID=recipeID,status="SCHEMATIC_INCOMPLETE"}) end
    local revision,revisionReason
    if type(I.Market.CraftRevision)=="function" then
        revision,revisionReason=I.Market:CraftRevision()
        if not revision then return knowledge(rec,{recipeID=recipeID,status="OUTPUT_PRICE_UNKNOWN",reason=revisionReason}) end
    end
    local output,why=I.Market:Get(rec.outputID)
    if not output then return knowledge(rec,{recipeID=recipeID,status="OUTPUT_PRICE_UNKNOWN",reason=why}) end
    if output.stale then return knowledge(rec,{recipeID=recipeID,status="OUTPUT_PRICE_TOO_OLD"}) end
    if output.providerAPI==6 and not output.snapshotID then
        return knowledge(rec,{recipeID=recipeID,status="OUTPUT_PRICE_UNKNOWN",reason="SCAN_IDENTITY_UNKNOWN"})
    end
    local cost,missing=0,{}
    for _,slot in ipairs(rec.slots) do
        if slot.required==false or #slot.choices~=1 then
            return knowledge(rec,{recipeID=recipeID,status="OPTIONAL_OR_AMBIGUOUS_REAGENTS"})
        end
        local id=slot.choices[1]
        local quote,missingReason=I.Market:Get(id)
        if not quote or quote.marketKey~=output.marketKey then
            missing[#missing+1]={itemID=id,reason=missingReason or "MARKET_SCOPE_MISMATCH"}
        elseif quote.providerAPI~=output.providerAPI or
            (output.providerAPI==6 and quote.snapshotID~=output.snapshotID) then
            missing[#missing+1]={itemID=id,reason="PRICE_SCAN_MISMATCH"}
        elseif quote.stale then
            missing[#missing+1]={itemID=id,reason="REAGENT_PRICE_TOO_OLD"}
        else
            local line=quote.priceCopper*slot.quantity
            if not safeAmount(line) or not safeAmount(cost+line) then
                return knowledge(rec,{recipeID=recipeID,status="PRICE_ARITHMETIC_OUT_OF_RANGE"})
            end
            cost=cost+line
        end
    end
    if #missing>0 then return knowledge(rec,{recipeID=recipeID,status="MISSING_OR_STALE_REAGENT_PRICES",missing=missing}) end
    if revision then
        local after=I.Market:CraftRevision()
        if not after or after.api~=revision.api or after.key~=revision.key or
            after.version~=revision.version or after.token~=revision.token then
            return knowledge(rec,{recipeID=recipeID,status="PRICE_CONTEXT_CHANGED",reason="REFRESH_RECIPE_ANALYSIS"})
        end
    end
    local grossLow,grossHigh=rec.quantityMin*output.priceCopper,rec.quantityMax*output.priceCopper
    if not safeAmount(grossLow) or not safeAmount(grossHigh) then
        return knowledge(rec,{recipeID=recipeID,status="PRICE_ARITHMETIC_OUT_OF_RANGE"})
    end
    -- Cost is only a verified market-reference material estimate. AH fees,
    -- actual purchase prices, deposits and completed sale proceeds are unknown.
    return knowledge(rec,{recipeID=recipeID,status="POTENTIAL_GROSS_BEFORE_FEES",
        marketKey=output.marketKey,snapshotID=output.snapshotID,costCopper=cost,
        grossDifferenceLowCopper=grossLow-cost,grossDifferenceHighCopper=grossHigh-cost,
        outputQuantityMin=rec.quantityMin,outputQuantityMax=rec.quantityMax,
        observedAt=rec.observedAt,professionName=rec.professionName or "Unknown",
        evidence="WEALTHCRAFT_LISTING_OBSERVATIONS_NOT_REALIZED_SALES"}),"AVAILABLE"
end
