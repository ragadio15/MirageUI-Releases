local _,I=...
-- Item facts are separate from rendered rows. Keys retain the complete item
-- payload, so a same-ID suffix/enchant change cannot reuse another variant.
I.Items={cache={},cacheCount=0,requests={},requestCount=0,revision=0,generation=0,
    sequence=0,cacheLimit=256,requestLimit=32,workerQueued=false,
    metrics={hits=0,misses=0,requested=0,completed=0,failed=0,expired=0,evicted=0}}
local A=I.Items
local TASK="MirageInsight_ItemLoads"
local function now()
    local value,ok=I:Call(GetTime)
    if ok and I:Number(value) and value>=0 then return value end
    return I:Now()
end
local function copy(source)
    local out={};for key,value in pairs(source) do out[key]=value end;return out
end
local function natural(value,max)
    return I:Number(value) and value>=0 and value%1==0 and value<=(max or 2147483647)
end
local function tasks()
    local core=I.core
    if type(core)~="table" or type(core.GetService)~="function" then return nil end
    local service,ok=I:Call(core.GetService,"Tasks",1)
    if ok and type(service)=="table" and type(service.Queue)=="function" and type(service.Cancel)=="function" then return service end
end
function A:Parse(item)
    if I:Integer(item) then return item,nil,nil end
    if not I:Text(item,600) then return nil,"INVALID_ITEM" end
    local cleaned=item:match("^%s*(.-)%s*$")
    local id=cleaned:match("^(%d+)$")
    local link,token
    if not id then
        -- Exactly one item hyperlink is allowed; text containing a link is not
        -- an identity. Bare item strings keep their variant fields as well.
        local payload=cleaned
        if payload:sub(1,2)=="|c" then
            -- Native links may use an explicit ARGB color or a named quality
            -- color. The color wrapper is presentation, never item identity.
            local body=payload:match("^|c%x%x%x%x%x%x%x%x(.+)|r$") or
                payload:match("^|cn[%a][%w_]*:(.+)|r$")
            if not body then return nil,"INVALID_ITEM_ID" end
            payload=body
        elseif payload:sub(-2)=="|r" then
            -- Native setters also return uncolored links with the closing
            -- reset. P16 rejected this valid envelope and lost all enrichment.
            payload=payload:sub(1,-3)
        end
        token=payload:match("^|H(item:[^|]+)|h%[[^|%c]+%]|h$")
        if token then link=cleaned else token=cleaned end
        local suffix
        id=token:match("^item:(%d+)$")
        if not id then
            id,suffix=token:match("^item:(%d+):([%d:%-]*)$")
            if id then
                for field in (suffix..":"):gmatch("(.-):") do
                    if field~="" and not field:match("^%-?%d+$") then id=nil;break end
                end
            end
        end
    end
    local n=tonumber(id)
    if not I:Integer(n) then return nil,"INVALID_ITEM_ID" end
    return n,link,token
end
function A:Identity(item)
    local id,link,token=self:Parse(item)
    if not id then return nil,link end
    return {itemID=id,requestedLink=link,itemString=token,
        inputKey=token or ("id:"..tostring(id)),
        identityPrecision=token and "EXACT_REQUESTED_ITEM_STRING" or "BASE_ITEM_ID"}
end
function A:Invalidate(itemID)
    if itemID~=nil and not I:Integer(itemID) then return end
    for key,entry in pairs(self.cache) do
        if itemID==nil or entry.itemID==itemID then self.cache[key]=nil;self.cacheCount=self.cacheCount-1 end
    end
    self.revision=self.revision+1
end
function A:Reset(reason)
    self.generation=self.generation+1
    local service=tasks();if service then pcall(service.Cancel,TASK) end
    self.workerQueued=false;self.requests={};self.requestCount=0
    self:Invalidate();self.lastReset=reason or "RESET"
end
function A:Maintain(t)
    if self.lastClock and t<self.lastClock then self:Reset("CLOCK_REBASED") end
    self.lastClock=t
    for id,request in pairs(self.requests) do
        if t>=request.expires then
            self.requests[id]=nil;self.requestCount=self.requestCount-1
            if request.state=="PENDING" or request.state=="QUEUED" then self.metrics.expired=self.metrics.expired+1 end
        end
    end
end
local function nativeFacts(identity)
    local api=C_Item
    local fn=type(api)=="table" and api.GetItemInfo or GetItemInfo
    local facts=copy(identity)
    facts.status="ITEM_CACHE_UNAVAILABLE";facts.vendorStatus="UNKNOWN"
    facts.source="NATIVE_C_ITEM_GET_ITEM_INFO";facts.nativeQualification="NOT_RUN"
    if type(fn)~="function" then facts.status="ITEM_API_UNAVAILABLE";return facts end
    local query=identity.requestedLink or identity.itemString or identity.itemID
    -- GetItemInfo has 18 documented returns on the reviewed client. Check each
    -- optional scalar rather than allowing a restricted description to taint
    -- otherwise public identity facts. Essential identity must be readable.
    local values={pcall(fn,query)}
    if not values[1] or not I:Label(values[2],180) then return facts end
    local resolved=values[3]
    local resolvedID=I:Text(resolved,600) and A:Parse(resolved) or nil
    if resolvedID and resolvedID~=identity.itemID then facts.status="ITEM_IDENTITY_MISMATCH";return facts end
    if resolved~=nil and not resolvedID then facts.status="ITEM_IDENTITY_UNREADABLE";return facts end
    facts.name=values[2];facts.status="CACHED_ITEM_FACTS"
    if resolvedID then facts.resolvedLink=resolved end
    local fields={[4]="quality",[5]="itemLevel",[6]="requiredLevel",[9]="stackMax",
        [13]="classID",[14]="subClassID",[15]="bindType",[16]="expansionID"}
    for index,key in pairs(fields) do if natural(values[index]) then facts[key]=values[index] end end
    if I:Label(values[7],100) then facts.itemType=values[7] end
    if I:Label(values[8],100) then facts.subType=values[8] end
    -- Empty equipLoc is a known unequippable item, not a missing requirement.
    if I:Readable(values[10]) and type(values[10])=="string" and #values[10]<=80 and not values[10]:find("[%c|]") then
        facts.equipLoc=values[10]
    end
    if I:Integer(values[11]) then facts.icon=values[11] end
    if natural(values[12],9000000000000000) then
        facts.vendorCopper=values[12];facts.vendorStatus=values[12]==0 and "KNOWN_ZERO" or "KNOWN"
    end
    if I:Readable(values[18]) and type(values[18])=="boolean" then facts.isCraftingReagent=values[18] end
    if type(api)=="table" and type(api.GetDetailedItemLevelInfo)=="function" then
        local level,ok=I:Call(api.GetDetailedItemLevelInfo,query)
        if ok and natural(level) then facts.itemLevel=level;facts.itemLevelSource="EXACT_INPUT_DETAILED_ITEM_LEVEL" end
    end
    return facts
end
function A:Facts(item)
    local identity,why=self:Identity(item)
    if not identity then return nil,why end
    if I.state.clientAllowed~=true then identity.status="UNSUPPORTED_BUILD";return identity end
    local t=now();self:Maintain(t)
    local getter=type(C_Item)=="table" and C_Item.GetItemInfo or GetItemInfo
    if self.getter~=getter then self.getter=getter;self:Invalidate() end
    local entry=self.cache[identity.inputKey]
    self.sequence=self.sequence+1
    local facts
    if entry and t<entry.expires then
        entry.used=self.sequence;facts=copy(entry.facts);self.metrics.hits=self.metrics.hits+1
    else
        facts=nativeFacts(identity);self.metrics.misses=self.metrics.misses+1
        if not entry and self.cacheCount>=self.cacheLimit then
            local oldestKey,oldest
            for key,cached in pairs(self.cache) do
                if not oldest or cached.used<oldest then oldestKey=key;oldest=cached.used end
            end
            if oldestKey then self.cache[oldestKey]=nil;self.cacheCount=self.cacheCount-1;self.metrics.evicted=self.metrics.evicted+1 end
        end
        if not entry then self.cacheCount=self.cacheCount+1 end
        self.cache[identity.inputKey]={itemID=identity.itemID,facts=copy(facts),used=self.sequence,
            expires=t+(facts.status=="CACHED_ITEM_FACTS" and 30 or 1)}
    end
    -- The caller's exact link wrapper belongs to this context, even when the
    -- same item payload was previously requested with a different visible name.
    facts.requestedLink=identity.requestedLink;facts.itemString=identity.itemString
    facts.inputKey=identity.inputKey;facts.revision=self.revision;facts.generation=self.generation
    if facts.status=="ITEM_CACHE_UNAVAILABLE" then
        local _,state=self:Request(item);facts.requestStatus=state
    end
    return facts
end
function A:Classification(facts,quest)
    if type(facts)~="table" then return nil end
    local labels,seen={},{}
    local function add(value)
        if I:Label(value,100) and not seen[value] and #labels<3 then
            for _,existing in ipairs(labels) do
                if existing:lower():find(value:lower(),1,true) then return end
            end
            seen[value]=true;labels[#labels+1]=value
        end
    end
    if quest and quest.isQuestItem==true then add(ITEM_CLASS_QUEST or "Quest Item") end
    local equip=facts.equipLoc
    if I:Label(equip,80) and equip~="" then add(_G[equip]) end
    if facts.isCraftingReagent==true then add(PROFESSIONS_CRAFTING_REAGENT or "Crafting Reagent") end
    if facts.subType~="Other" and facts.subType~="Miscellaneous" and
        (#labels==0 or facts.subType~=facts.itemType) then add(facts.subType) end
    if #labels==0 then add(facts.itemType) end
    return #labels>0 and table.concat(labels," · ") or nil
end
function A:Drain(generation)
    if generation~=self.generation or I.state.clientAllowed~=true then self.workerQueued=false;return false end
    local t=now();self:Maintain(t)
    local count=0
    local start,clockOK=I:Call(debugprofilestop)
    for id,request in pairs(self.requests) do
        if request.state=="QUEUED" then
            request.state="PENDING";request.expires=t+5
            local fn=type(C_Item)=="table" and C_Item.RequestLoadItemDataByID
            local _,ok=I:Call(fn,id)
            if generation~=self.generation then return false end
            if not ok and self.requests[id]==request then
                request.state="FAILED";request.expires=t+10;self.metrics.failed=self.metrics.failed+1
            else self.metrics.requested=self.metrics.requested+1 end
            count=count+1
            local current,valid=I:Call(debugprofilestop)
            if count>=4 or (clockOK and valid and I:Number(start) and I:Number(current) and current-start>=0.5) then break end
        end
    end
    for _,request in pairs(self.requests) do if request.state=="QUEUED" then return true end end
    self.workerQueued=false;return false
end
function A:Request(item)
    local itemID=self:Parse(item)
    if I.state.clientAllowed~=true or not itemID then return false,"INVALID_OR_UNSUPPORTED_ITEM" end
    local t=now();self:Maintain(t)
    local existing=self.requests[itemID]
    if existing then return existing.state~="FAILED",existing.state end
    if self.requestCount>=self.requestLimit then return false,"ITEM_REQUEST_LIMIT" end
    local api=C_Item
    if type(api)~="table" or type(api.RequestLoadItemDataByID)~="function" then return false,"ITEM_REQUEST_API_UNAVAILABLE" end
    local service=tasks();if not service then return false,"TASKS_UNAVAILABLE" end
    self.requests[itemID]={state="QUEUED",expires=t+5};self.requestCount=self.requestCount+1
    if not self.workerQueued then
        self.workerQueued=true;local generation=self.generation
        local accepted,ok=I:Call(service.Queue,TASK,function()return A:Drain(generation)end,generation)
        if not ok or accepted~=true then
            self.workerQueued=false;self.requests[itemID]=nil;self.requestCount=self.requestCount-1
            return false,"ITEM_REQUEST_QUEUE_UNAVAILABLE"
        end
    end
    return true,"QUEUED"
end
function A:OnEvent(event,itemID,success)
    if event=="PLAYER_LEAVING_WORLD" then self:Reset("WORLD_CONTEXT_CHANGED");return end
    if event~="ITEM_DATA_LOAD_RESULT" and event~="GET_ITEM_INFO_RECEIVED" then return end
    if I.state.clientAllowed~=true or not I:Integer(itemID) then return end
    local request=self.requests[itemID]
    if I:Readable(success) and success==true then
        if request then self.requests[itemID]=nil;self.requestCount=self.requestCount-1 end
        self.metrics.completed=self.metrics.completed+1;self:Invalidate(itemID)
    elseif I:Readable(success) and success==false then
        if request then request.state="FAILED";request.expires=now()+10 end
        self.metrics.failed=self.metrics.failed+1;self:Invalidate(itemID)
    end
end
function A:GetStatus()
    self:Maintain(now())
    local pending,queued,backoff=0,0,0
    for _,request in pairs(self.requests) do
        if request.state=="QUEUED" then queued=queued+1
        elseif request.state=="PENDING" then pending=pending+1
        elseif request.state=="FAILED" then backoff=backoff+1 end
    end
    local result={cacheEntries=self.cacheCount,cacheLimit=self.cacheLimit,pendingRequests=pending,
        queuedRequests=queued,backoffRequests=backoff,requestEntries=self.requestCount,
        requestLimit=self.requestLimit,revision=self.revision,generation=self.generation,
        identity="EXACT_INPUT_ITEM_STRING",nativeQualification="NOT_RUN"}
    for key,value in pairs(self.metrics) do result[key]=value end
    return result
end
function A:Coin(copper,fullNames)
    if not I:Number(copper) or copper<0 or copper%1~=0 then return "unknown" end
    local gold=math.floor(copper/10000)
    local silver=math.floor((copper%10000)/100)
    local coin=copper%100
    if fullNames then
        local parts={}
        if gold>0 then parts[#parts+1]=string.format("%d gold",gold) end
        if silver>0 then parts[#parts+1]=string.format("%d silver",silver) end
        if coin>0 or #parts==0 then parts[#parts+1]=string.format("%d copper",coin) end
        return table.concat(parts," ")
    end
    if gold>0 then return string.format("%dg %02ds %02dc",gold,silver,coin) end
    if silver>0 then return string.format("%ds %02dc",silver,coin) end
    return string.format("%dc",coin)
end
function A:SignedCoin(copper)
    if not I:Number(copper) or copper%1~=0 then return "unknown" end
    if copper<0 then return "-"..self:Coin(-copper) end
    return self:Coin(copper)
end
