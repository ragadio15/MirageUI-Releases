local _,I=...
I.Actions={lastAction="NONE",lastStatus="READY",count=0}
local A=I.Actions
local function valid(r)
    return I:Readable(r) and type(r)=="table" and I:Text(r.id,128) and I:Integer(r.mapID) and
        I:Number(r.x) and I:Number(r.y) and r.x>=0 and r.x<=1 and r.y>=0 and r.y<=1 and I:Label(r.label,160)
        and I:Readable(r.owner) and I:Readable(r.revision) and I:Readable(r.sourceRevision) and I:Readable(r.hidden)
        and I:Readable(r.floorID) and I:Readable(r.kind) and I:Readable(r.siteID) and I:Readable(r.questID)
        and I:Readable(r.availability)
end
function A:Resolve(record,options)
    if type(options)~="table" or options.userInitiated~=true then return nil,"EXPLICIT_ACTION_REQUIRED" end
    if not I.state.clientAllowed or I.Storage.readOnly then return nil,"INSIGHT_UNAVAILABLE" end
    if I:Combat() then return nil,"LEAVE_COMBAT_FOR_ACTION" end
    if not I:Readable(record) or not valid(record) then return nil,"SELECT_A_RECORDED_LOCATION" end
    local records=I.Context:Service("WorldRecords")
    local current,ok
    if records and type(records.Get)=="function" then current,ok=I:Call(records.Get,record.id) end
    -- Provider resolution/readback can re-enter a world or combat event. The
    -- click's initial state is not authorization to dispatch after that change.
    if I:Combat() then return nil,"LEAVE_COMBAT_FOR_ACTION" end
    if not I.state.clientAllowed or I.Storage.readOnly then return nil,"INSIGHT_UNAVAILABLE" end
    if not ok or not valid(current) then return nil,"LOCATION_NO_LONGER_AVAILABLE" end
    if current.hidden then return nil,"LOCATION_HIDDEN" end
    if current.id~=record.id or current.owner~=record.owner or current.revision~=record.revision or current.sourceRevision~=record.sourceRevision
        or current.mapID~=record.mapID or current.x~=record.x or current.y~=record.y or current.floorID~=record.floorID
        or current.kind~=record.kind or current.siteID~=record.siteID or current.questID~=record.questID then
        return nil,"LOCATION_CHANGED_REFRESH_AND_SELECT_AGAIN"
    end
    return current,"READY"
end
function A:Finish(action,ok,why)
    self.lastAction=action;self.lastStatus=why or (ok and "ACCEPTED" or "UNAVAILABLE")
    if ok then self.count=self.count+1 end
    return ok==true,self.lastStatus
end
function A:FindOnMap(record,options)
    local r,why=self:Resolve(record,options)
    if not r then return self:Finish("FIND_ON_MAP",false,why) end
    local map=I.Context:Service("MapAddon")
    if not map or type(map.ShowUtilityRecord)~="function" then return self:Finish("FIND_ON_MAP",false,"MAP_PLUS_UNAVAILABLE") end
    r,why=self:Resolve(record,options)
    if not r then return self:Finish("FIND_ON_MAP",false,why) end
    local accepted,ok,status=I:Call(map.ShowUtilityRecord,r,{userInitiated=true})
    return self:Finish("FIND_ON_MAP",ok and accepted==true,status or "MAP_REQUEST_UNAVAILABLE")
end
function A:Navigate(record,options)
    local r,why=self:Resolve(record,options)
    if not r then return self:Finish("NAVIGATE",false,why) end
    local nav=I.Context:Service("Navigate")
    if not nav then nav=type(MirageNavigateAPI)=="table" and MirageNavigateAPI or nil end
    if not nav or nav.apiVersion~=1 then return self:Finish("NAVIGATE",false,"WAYFINDER_UNAVAILABLE") end
    r,why=self:Resolve(record,options)
    if not r then return self:Finish("NAVIGATE",false,why) end
    if r.kind=="quest" and r.availability=="ACCEPTED" and I:Integer(r.questID) then
        if type(nav.PinQuest)~="function" then return self:Finish("NAVIGATE",false,"QUEST_NAVIGATION_UNAVAILABLE") end
        local accepted,ok,status=I:Call(nav.PinQuest,r.questID)
        if ok and accepted==true and type(nav.Refresh)=="function" then I:Call(nav.Refresh) end
        return self:Finish("NAVIGATE",ok and accepted==true,status or "NAVIGATION_REQUEST_UNAVAILABLE")
    end
    if type(nav.RequestDestination)~="function" then return self:Finish("NAVIGATE",false,"WAYFINDER_UNAVAILABLE") end
    -- A canonical gathering site must keep its identity under Wayfinder's
    -- authority, so hiding/withdrawing the record can suspend that selection.
    local gather=r.kind=="gather" and r.owner=="MirageIntel_Gather"
    local accepted,ok,status=I:Call(nav.RequestDestination,gather and "gather" or "manual",{recordID=r.id,siteID=r.siteID,
        mapID=r.mapID,x=r.x,y=r.y,floorID=r.floorID,label=r.label,sourceRevision=r.sourceRevision,
        name=r.name or r.label,category=r.category,requireRecord=gather,
        purpose=r.kind=="gather" and "HISTORICAL_SITE" or "MANUAL"},{userInitiated=true})
    if ok and accepted==true and type(nav.Refresh)=="function" then I:Call(nav.Refresh) end
    return self:Finish("NAVIGATE",ok and accepted==true,status or "NAVIGATION_REQUEST_UNAVAILABLE")
end
function A:OpenForContext(model)
    if not I.state.clientAllowed or I.Storage.readOnly or I:Combat() then return false,"LEAVE_COMBAT_OR_RESUME_INSIGHT" end
    if not I:Readable(model) or type(model)~="table" then return false,"NO_CURRENT_ITEM_CONTEXT" end
    local item=model.exactLink or model.link or model.itemLink or model.fullLink or model.item or model.itemID
    local id=I.Items:Parse(item)
    if not id then return false,"NO_CURRENT_ITEM_CONTEXT" end
    return I.Tooltip:OpenItem(item)
end
function A:GetStatus()
    return {lastAction=self.lastAction,lastStatus=self.lastStatus,accepted=self.count,policy="EXPLICIT_REVALIDATED_ACTIONS_ONLY"}
end
