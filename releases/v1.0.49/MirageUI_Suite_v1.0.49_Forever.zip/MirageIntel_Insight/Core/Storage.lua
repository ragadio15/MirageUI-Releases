local _,I=...
I.Storage={readOnly=false,reason="UNINITIALIZED"}
local S=I.Storage
local validMode={ALL_UNFILTERED_REPORTED=true,FILTERED_VISIBLE_ONLY=true}
local additiveDefaults={autoScan=true,detailModifier="ALT",tooltipAnchor="AUTO",tooltipTextSize=12,
    reducedMotion=true,tooltipPresentation="AUTO",showQuestUses=true,showLocations=true,
    showItemID=true,professionDetails=true,showUnitID=true,skinTooltips=true}
local booleanPrefs={tooltip=true,showRecipes=true,showVendorTooltip=true,expanded=true,
    learnedOnly=true,showMarketTooltip=true,autoScan=true,reducedMotion=true,showQuestUses=true,showLocations=true,
    showItemID=true,professionDetails=true,showUnitID=true,skinTooltips=true}
local function natural(value,max)
    return I:Number(value) and value>=0 and value%1==0 and value<=(max or 2147483647)
end
local function arraySize(value,maximum)
    if type(value)~="table" or not I:Readable(value) then return nil end
    local count=0
    for key in pairs(value) do
        count=count+1
        if count>maximum or not I:Integer(key) or key>maximum then return nil end
    end
    for index=1,count do if value[index]==nil then return nil end end
    return count
end
local function validPreference(key,value)
    if booleanPrefs[key] then return type(value)=="boolean" end
    if key=="marketProvider" then return value=="off" or value=="Wealthcraft" end
    if key=="maxQuoteAgeSeconds" then return I:Integer(value) and value>=3600 and value<=2592000 end
    if key=="tooltipTextSize" then return I:Integer(value) and value>=10 and value<=16 end
    if key=="tooltipAnchor" then return value=="AUTO" or value=="RIGHT" or value=="LEFT" end
    if key=="detailModifier" then return value=="ALT" or value=="CTRL" or value=="NONE" or value=="SHIFT" end
    if key=="tooltipPresentation" then return value=="AUTO" or value=="NATIVE" end
    return false
end
local function freshAccount()
    local account={schemaVersion=2,sentinel="INSIGHT_ACCOUNT_V2",revision=0,
        preferences={tooltip=true,showRecipes=true,showVendorTooltip=true,
          marketProvider="Wealthcraft",showMarketTooltip=true,expanded=false,learnedOnly=false,maxQuoteAgeSeconds=172800}}
    for key,value in pairs(additiveDefaults) do account.preferences[key]=value end
    -- Technical identifiers are opt-in for a new installation. Existing roots
    -- and their preference overrides retain the choices made in earlier builds.
    account.preferences.showItemID=false;account.preferences.showUnitID=false
    return account
end
local function freshCharacter()
    return {schemaVersion=2,sentinel="INSIGHT_CHAR_V2",revision=0,
       recipes={},professions={},lastScanAt=0,scanCount=0}
end
local function validRecipe(rec)
    if type(rec)~="table" or not I:Integer(rec.id) or not I:Label(rec.name,120) or
       type(rec.learned)~="boolean" or not I:Integer(rec.outputID) or
       not I:Integer(rec.quantityMin) or not I:Integer(rec.quantityMax) or
       rec.quantityMax<rec.quantityMin or rec.quantityMax>100000 or
       not I:Number(rec.observedAt) or rec.observedAt<0 or
       not arraySize(rec.slots,20) or
       type(rec.incomplete)~="boolean" then return false end
    local sourceBuild=I:Text(rec.sourceBuild,20)
    if not sourceBuild or not (sourceBuild=="unknown" or sourceBuild=="UNRECORDED" or
        sourceBuild:match("^%d+$") and I:Integer(tonumber(sourceBuild))) then return false end
    if rec.sourcePatch~=nil and not I:Label(rec.sourcePatch,80) or
        rec.sourceInterface~=nil and not I:Integer(rec.sourceInterface) then return false end
    -- Legacy Alpha 1 recipes had no profession ID. Keep them and label their scope unknown.
    if rec.professionID~=nil and (not I:Integer(rec.professionID) or
        not I:Label(rec.professionName,120) or not validMode[rec.scanMode] or
        (rec.skillLineID~=nil and not I:Integer(rec.skillLineID))) then return false end
    if rec.professionID==nil and (rec.scanMode~=nil or rec.skillLineID~=nil) then return false end
    if rec.knowledgeState~=nil and rec.knowledgeState~="CURRENT_CHARACTER_OBSERVED" and
        rec.knowledgeState~="HISTORICAL_NOT_IN_LATEST_COMPLETE" then return false end
    for _,slot in ipairs(rec.slots) do
        if type(slot)~="table" or not I:Integer(slot.quantity) or slot.quantity>100000 or
           not arraySize(slot.choices,8) or
           type(slot.required)~="boolean" or
           (not rec.incomplete and (#slot.choices~=1 or not slot.required)) then return false end
        for _,id in ipairs(slot.choices) do if not I:Integer(id) then return false end end
    end
    return true
end
S.ValidRecipe=validRecipe
local function validProfile(profile,key)
    if type(profile)~="table" or type(key)~="string" or not key:match("^%d+:%d+$") or
        not I:Integer(profile.professionID) or not I:Label(profile.name,120) or
        not validMode[profile.scanMode] or not I:Number(profile.scannedAt) or profile.scannedAt<0 or
        not natural(profile.listed,3000) or not natural(profile.recorded,3000) or not natural(profile.skipped,3000) or
        profile.recorded+profile.skipped~=profile.listed or
        not natural(profile.learned,3000) or not natural(profile.unlearned,3000) or
        profile.learned+profile.unlearned~=profile.recorded or
        (profile.skillLineID~=nil and not I:Integer(profile.skillLineID)) then return false end
    if profile.snapshotComplete~=nil and type(profile.snapshotComplete)~="boolean" then return false end
    local expected=tostring(profile.professionID)..":"..tostring(profile.skillLineID or profile.professionID)
    return key==expected
end
local function validPrefs(p,legacy)
    if type(p)~="table" or type(p.tooltip)~="boolean" or type(p.showRecipes)~="boolean" or
        type(p.showVendorTooltip)~="boolean" or type(p.expanded)~="boolean" or
        (p.marketProvider~="off" and p.marketProvider~="Wealthcraft") then return false end
    if not legacy and (type(p.learnedOnly)~="boolean" or type(p.showMarketTooltip)~="boolean" or
        not I:Integer(p.maxQuoteAgeSeconds) or p.maxQuoteAgeSeconds<3600 or
        p.maxQuoteAgeSeconds>2592000) then return false end
    -- Schema 2 gains only optional, validated preferences. Missing keys receive
    -- defaults after the complete saved roots pass validation; opt-outs survive.
    for key in pairs(additiveDefaults) do
        if p[key]~=nil and not validPreference(key,p[key]) then return false end
    end
    return true
end
local function validateStored(a,c,legacy)
    if not I:Readable(a) or not I:Readable(c) or type(a)~="table" or type(c)~="table" or
        a.schemaVersion~=(legacy and 1 or 2) or c.schemaVersion~=(legacy and 1 or 2) or
        not validPrefs(a.preferences,legacy) or type(c.recipes)~="table" or
        not I:Number(a.revision) or a.revision<0 or a.revision%1~=0 or
        not I:Number(c.revision) or c.revision<0 or c.revision%1~=0 or
        not I:Number(c.lastScanAt) or c.lastScanAt<0 or
        not I:Number(c.scanCount) or c.scanCount<0 or c.scanCount%1~=0 then return false,"SCHEMA_INVALID_OR_NEWER_PRESERVED" end
    local n=0
    for id,rec in pairs(c.recipes) do
        n=n+1
        if n>I.maxRecipes or not I:Integer(id) or type(rec)~="table" or id~=rec.id or not validRecipe(rec) then
            return false,"RECIPE_RECORD_INVALID_PRESERVED"
        end
    end
    if not legacy then
        if type(c.professions)~="table" then return false,"PROFESSION_INDEX_INVALID_PRESERVED" end
        n=0
        for key,profile in pairs(c.professions) do
            n=n+1
            if n>40 or not validProfile(profile,key) then
                return false,"PROFESSION_INDEX_INVALID_PRESERVED"
            end
        end
    end
    return true
end
function S:Initialize()
    self.account=nil;self.character=nil;self.readOnly=false;self.firstCharacter=false
    if I.state.clientAllowed~=true then
        self.readOnly=true;self.reason="UNSUPPORTED_CLIENT_NO_WRITES";return
    end
    local a,c=MirageIntelInsightDB,MirageIntelInsightCharDB
    if a==nil and c==nil then
        a=freshAccount();a.interfaceRevision=10;a.presentationRevision=12;c=freshCharacter()
        if I.state.clientAllowed then MirageIntelInsightDB=a;MirageIntelInsightCharDB=c end
    elseif a==nil then
        self.readOnly=true;self.reason="SAVED_TABLE_MISSING_PRESERVED";return
    elseif c==nil then
        -- Account SavedVariables are shared by alts. A character that has never
        -- loaded Insight legitimately has no per-character file yet. Validate
        -- the entire existing account against an empty matching character
        -- before allocating that character's independent recipe observations.
        -- A malformed/non-nil character root is never treated as a new alt.
        if type(a)~="table" or (a.schemaVersion~=1 and a.schemaVersion~=2) then
            self.readOnly=true;self.reason="UNKNOWN_ACCOUNT_SCHEMA_PRESERVED";return
        end
        local candidate=freshCharacter();candidate.schemaVersion=a.schemaVersion
        local valid,why=validateStored(a,candidate,a.schemaVersion==1)
        if not valid then self.readOnly=true;self.reason=why;return end
        c=candidate;self.firstCharacter=true
    end
    -- V1-to-V2 migration is validated first; original roots are retained intact
    -- in v2 legacyV1Backup, including the old recipe table for recovery/rollback.
    if type(a)~="table" or type(c)~="table" then
        self.readOnly=true;self.reason="INVALID_SAVED_ROOTS_PRESERVED";return
    end
    if a.schemaVersion==1 or c.schemaVersion==1 then
        if a.schemaVersion~=1 or c.schemaVersion~=1 then
            self.readOnly=true;self.reason="MIXED_SCHEMA_VERSIONS_PRESERVED";return
        end
        local ok,why=validateStored(a,c,true)
        if not ok then self.readOnly=true;self.reason=why;return end
        local nextA=freshAccount()
        for key,val in pairs(a.preferences) do nextA.preferences[key]=val end
        nextA.revision=a.revision;nextA.legacyV1Backup=a
        nextA.migration="VALIDATED_V1_TO_V2"
        local nextC=freshCharacter()
        nextC.recipes=c.recipes;nextC.scanCount=c.scanCount
        nextC.lastScanAt=c.lastScanAt;nextC.revision=c.revision
        nextC.legacyV1Backup=c
        local valid,migrationError=validateStored(nextA,nextC,false)
        if not valid then self.readOnly=true;self.reason=migrationError;return end
        if I.state.clientAllowed then
            MirageIntelInsightDB=nextA;MirageIntelInsightCharDB=nextC
        end
        a,c=nextA,nextC
        self.reason="V1_MIGRATED_WITH_BACKUP_RESTART_UNTESTED"
    else
        self.reason="RESTORE_REQUIRES_NATIVE_RELOAD_RELOG_RESTART"
    end
    local ok,why=validateStored(a,c,false)
    if not ok then self.readOnly=true;self.reason=why;return end
    local nextPreferences,changed={},false
    for key,value in pairs(a.preferences) do nextPreferences[key]=value end
    for key,value in pairs(additiveDefaults) do
        if nextPreferences[key]==nil then nextPreferences[key]=value;changed=true end
    end
    if changed then
        -- Do not edit a previously loaded preferences object in place. Unknown
        -- fields remain intact, and this additive upgrade does not change schema.
        a.preferences=nextPreferences
        a.revision=math.min(2147483647,a.revision+1)
    end
    -- P10 changes the requested experience once: details live in tooltips and
    -- profession observation is automatic. Keep the full previous preference
    -- object for an exact rollback; choices made after P10 are never reset.
    if a.interfaceRevision~=10 then
        a.p9Preferences=a.p9Preferences or I:Copy(a.preferences)
        local nextP={};for key,value in pairs(a.preferences) do nextP[key]=value end
        nextP.tooltip=true;nextP.tooltipPresentation="AUTO";nextP.skinTooltips=true
        nextP.showItemID=true;nextP.showVendorTooltip=true;nextP.showRecipes=true
        nextP.marketProvider="Wealthcraft";nextP.showMarketTooltip=true
        nextP.autoScan=true;nextP.professionDetails=true;nextP.expanded=false
        a.preferences=nextP;a.interfaceRevision=10
        a.revision=math.min(2147483647,a.revision+1)
    end
    -- P12 explicitly enables the user's requested item/unit/profession
    -- presentation. P11 had no per-control intent journal; keep its complete
    -- preferences for rollback and honor any later deliberate overrides.
    if a.presentationRevision~=12 then
        a.p11Preferences=a.p11Preferences or I:Copy(a.preferences)
        local overrides=type(a.preferenceOverrides)=="table" and a.preferenceOverrides or {}
        local requested={tooltip=true,tooltipPresentation="AUTO",skinTooltips=true,
            showItemID=true,showVendorTooltip=true,showRecipes=true,showUnitID=true,
            autoScan=true,professionDetails=true}
        local nextP={};for key,value in pairs(a.preferences) do nextP[key]=value end
        for key,value in pairs(requested) do if overrides[key]~=true then nextP[key]=value end end
        a.preferences=nextP;a.presentationRevision=12
        a.revision=math.min(2147483647,a.revision+1)
    end
    -- Older installations can carry the suite's historical native/off defaults.
    -- Settings changes are recorded per control. Adopt current tooltip defaults
    -- only for inherited fields; retain explicit off/native choices and the
    -- independent text-size, content and market preferences.
    if a.tooltipDefaultsRevision==nil then
        local overrides=type(a.preferenceOverrides)=="table" and a.preferenceOverrides or {}
        local defaults={tooltip=true,tooltipPresentation="AUTO",skinTooltips=true}
        local updated
        for key,value in pairs(defaults) do
            if overrides[key]~=true and a.preferences[key]~=value then
                if not updated then updated={};for k,v in pairs(a.preferences) do updated[k]=v end end
                updated[key]=value
            end
        end
        if updated then a.preferences=updated;a.revision=math.min(2147483647,a.revision+1) end
        a.tooltipDefaultsRevision=1
    end
    -- Restore the requested tooltip display once when upgrading a disabled legacy
    -- installation. Preserve the previous display settings and later choices.
    if a.tooltipDisplayRevision==nil then
        local p=a.preferences
        if p.tooltip==false then
            a.previousTooltipDisplay={tooltip=p.tooltip,tooltipPresentation=p.tooltipPresentation,skinTooltips=p.skinTooltips}
            local nextP={};for key,value in pairs(p) do nextP[key]=value end
            nextP.tooltip=true;nextP.tooltipPresentation="AUTO";nextP.skinTooltips=true
            a.preferences=nextP;a.revision=math.min(2147483647,a.revision+1)
        end
        a.tooltipDisplayRevision=1
    end
    if self.firstCharacter then MirageIntelInsightCharDB=c end
    self.account=a;self.character=c
end
function S:Writable()
    if self.readOnly then return false,self.reason end
    if not I.state.clientAllowed then return false,"UNSUPPORTED_BUILD" end
    if type(self.account)~="table" or type(self.character)~="table" or
        self.account~=MirageIntelInsightDB or self.character~=MirageIntelInsightCharDB then
        return false,"SAVED_ROOT_IDENTITY_CHANGED"
    end
    return true
end
function S:SetPreference(key,value)
    local allowed,why=self:Writable()
    if not allowed then return false,why end
    if not validPreference(key,value) then return false,"INVALID_OR_UNKNOWN_SETTING" end
    self.account.preferenceOverrides=type(self.account.preferenceOverrides)=="table" and self.account.preferenceOverrides or {}
    local displayChange=key=="tooltip" and value==true and
        (self.account.preferences.tooltipPresentation~="AUTO" or self.account.preferences.skinTooltips~=true)
    if self.account.preferences[key]==value and not displayChange then
        if self.account.preferenceOverrides[key]~=true then
            self.account.preferenceOverrides[key]=true
            self.account.revision=math.min(2147483647,self.account.revision+1)
        end
        return true,"UNCHANGED"
    end
    self.account.preferenceOverrides[key]=true
    self.account.preferences[key]=value
    if key=="tooltip" and value==true then
        self.account.preferences.tooltipPresentation="AUTO";self.account.preferences.skinTooltips=true
        self.account.preferenceOverrides.tooltipPresentation=true;self.account.preferenceOverrides.skinTooltips=true
    end
    self.account.revision=math.min(2147483647,self.account.revision+1)
    if I.core and type(I.core.Publish)=="function" then
        I.core.Publish("INSIGHT_SETTINGS_CHANGED",{key=key,revision=self.account.revision})
    end
    if I.UI then I.UI:Update() end
    return true,"PENDING_CLIENT_SAVE"
end
function S:ClearRecipes(expectedCharacter,expectedRevision)
    local allowed,why=self:Writable()
    if not allowed then return false,why end
    if I:Combat() then return false,"Clear recipes after combat." end
    if self.character~=expectedCharacter or self.character.revision~=expectedRevision then
        return false,"Recipe history changed. Review it again before clearing."
    end
    self.character.recipes={};self.character.professions={}
    self.character.lastScanAt=0;self.character.scanCount=0
    self.character.revision=math.min(2147483647,self.character.revision+1)
    return true
end
function S:CommitRecipes(rows,context,mode,listed,skipped,expectedRevision)
    local allowed,why=self:Writable()
    if not allowed then return false,why end
    if expectedRevision~=nil and expectedRevision~=self.character.revision then
        return false,"STORAGE_CHANGED_DURING_SCAN"
    end
    if type(rows)~="table" or type(context)~="table" or
        not I:Integer(context.professionID) or not I:Label(context.name,120) or
        not validMode[mode] or not I:Integer(listed) or listed>I.maxSourceIDs or
        not I:Number(skipped) or skipped<0 or skipped%1~=0 then
        return false,"INVALID_RECIPE_BATCH"
    end
    local nextRecipes={};local n=0
    for id,rec in pairs(self.character.recipes) do
        n=n+1
        if n>I.maxRecipes or not I:Integer(id) or not validRecipe(rec) or rec.id~=id then
            return false,"STORAGE_CHANGED_DURING_SCAN"
        end
        nextRecipes[id]=rec
    end
    local recorded,learned,unlearned=0,0,0
    for id,rec in pairs(rows) do
        if not I:Integer(id) or type(rec)~="table" or id~=rec.id or not validRecipe(rec) or
            rec.professionID~=context.professionID or rec.skillLineID~=context.skillLineID or rec.scanMode~=mode then
            return false,"INVALID_SCANNED_RECIPE"
        end
        if nextRecipes[id]==nil then n=n+1 end
        if n>I.maxRecipes then return false,"RECIPE_CAP_EXCEEDED" end
        nextRecipes[id]=rec;recorded=recorded+1
        if rec.learned then learned=learned+1 else unlearned=unlearned+1 end
    end
    if recorded==0 or recorded+skipped~=listed then return false,"EMPTY_OR_INCOMPLETE_BATCH" end
    local complete=mode=="ALL_UNFILTERED_REPORTED" and skipped==0
    if complete then
        for id,rec in pairs(nextRecipes) do
            if rows[id]==nil and rec.professionID==context.professionID and rec.skillLineID==context.skillLineID and
                rec.knowledgeState~="HISTORICAL_NOT_IN_LATEST_COMPLETE" then
                local historic={};for k,v in pairs(rec) do historic[k]=v end
                historic.knowledgeState="HISTORICAL_NOT_IN_LATEST_COMPLETE"
                nextRecipes[id]=historic
            end
        end
    end
    local skill=context.skillLineID
    local key=tostring(context.professionID)..":"..tostring(skill or context.professionID)
    local nextProfiles={};local profileCount=0
    for k,v in pairs(self.character.professions) do
        profileCount=profileCount+1
        if not validProfile(v,k) or profileCount>40 then return false,"STORAGE_CHANGED_DURING_SCAN" end
        nextProfiles[k]=v
    end
    if not nextProfiles[key] and profileCount>=40 then return false,"PROFESSION_CAP_EXCEEDED" end
    nextProfiles[key]={professionID=context.professionID,name=context.name,
        skillLineID=skill,scanMode=mode,scannedAt=I:Now(),listed=listed,
        recorded=recorded,skipped=skipped,learned=learned,unlearned=unlearned,snapshotComplete=complete}
    if not validProfile(nextProfiles[key],key) then return false,"INVALID_SCAN_SUMMARY" end
    -- No destructive pruning. A complete same-scope snapshot can mark old rows
    -- historical; a filtered/incomplete snapshot cannot imply absence or unlearning.
    self.character.recipes=nextRecipes
    self.character.professions=nextProfiles
    self.character.lastScanAt=I:Now()
    self.character.scanCount=math.min(2147483647,self.character.scanCount+1)
    self.character.revision=math.min(2147483647,self.character.revision+1)
    return true,recorded
end
function S:Status()
    local count,legacy,learned,historical=0,0,0,0
    if self.character and type(self.character.recipes)=="table" then
        for _,rec in pairs(self.character.recipes) do
            count=count+1
            if type(rec)=="table" and rec.professionID==nil then legacy=legacy+1 end
            if type(rec)=="table" and rec.knowledgeState=="HISTORICAL_NOT_IN_LATEST_COMPLETE" then
                historical=historical+1
            elseif type(rec)=="table" and rec.learned==true then learned=learned+1 end
        end
    end
    local profiles={};local p=self.character and self.character.professions
    if type(p)=="table" then
        for key,value in pairs(p) do
            if validProfile(value,key) then
                profiles[#profiles+1]={key=key,professionID=value.professionID,
                    name=value.name,skillLineID=value.skillLineID or value.professionID,scanMode=value.scanMode,scannedAt=value.scannedAt,
                    listed=value.listed,recorded=value.recorded,skipped=value.skipped,
                    learned=value.learned,unlearned=value.unlearned,snapshotComplete=value.snapshotComplete==true}
            end
        end
    end
    table.sort(profiles,function(a,b) if a.name~=b.name then return a.name<b.name end return a.key<b.key end)
    return {reason=self.reason,readOnly=self.readOnly,firstCharacter=self.firstCharacter==true,accountRevision=self.account and self.account.revision,
        characterRevision=self.character and self.character.revision,recipeCount=count,
        learnedRecipeCount=learned,historicalRecipeCount=historical,legacyUnscoped=legacy,professions=profiles,
        professionCount=#profiles,version=self.character and self.character.schemaVersion,
        v1BackupPresent=self.character and self.character.legacyV1Backup~=nil,
        lastScanAt=self.character and self.character.lastScanAt,
        scanCount=self.character and self.character.scanCount}
end
