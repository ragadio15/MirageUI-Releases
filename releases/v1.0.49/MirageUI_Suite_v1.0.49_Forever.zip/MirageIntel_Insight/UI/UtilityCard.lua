local _,I=...
-- Map and gathering hints share one passive, compact Mirage card.
I.UtilityCard={status="READY_ON_DEMAND",generation=0,hooked=setmetatable({},{__mode="k"})}
local T=I.UtilityCard
local function clean(value,max) return I:Label(value,max or 120) end
local function scalarRevision(value)
    return I:Number(value) and value>=0 and value%1==0 and value<=2147483647
end
function T:Model(record,context)
    if not I:Readable(record) or type(record)~="table" or not clean(record.id,128) or
        not clean(record.label,160) or not clean(record.kind,40) then return nil,"INVALID_UTILITY_RECORD" end
    local map=I.core and I.core.Map
    if type(map)~="table" or type(map.Valid)~="function" then return nil,"MAP_CONTRACT_UNAVAILABLE" end
    local valid,called=I:Call(map.Valid,map,record.mapID,record.x,record.y)
    if not called or valid~=true then return nil,"INVALID_UTILITY_POSITION" end
    context=I:Readable(context) and type(context)=="table" and context or {}
    local source=clean(record.source,96) or "UNKNOWN"
    local confidence=clean(record.confidence,40) or "UNKNOWN"
    local purpose=clean(context.purpose,120) or clean(record.purpose,120) or
        (record.kind=="gather" and "HISTORICAL_SITE" or record.kind=="note" and "PERSONAL_NOTE" or record.destination and "MANUAL" or "MAP_RECORD")
    local model={id=record.id,revision=scalarRevision(record.revision) and record.revision or 0,
        sourceRevision=(scalarRevision(record.sourceRevision) or clean(record.sourceRevision,96)) and record.sourceRevision or nil,
        title=record.label,kind=record.kind,source=source,confidence=confidence,
        mapID=record.mapID,x=record.x,y=record.y,purpose=purpose,lines={}}
    local lines=model.lines
    local kinds={quest="Quest",objective="Quest objective",["turn-in"]="Quest turn-in",gather="Recorded gathering node",
        herb="Herb",ore="Ore",fishing="Fishing",note="Personal note",flight="Flight master",service="Service",
        landmark="Landmark",vendor="Vendor",trainer="Trainer",["spirit-healer"]="Spirit healer",dungeon="Dungeon",raid="Raid"}
    local category=clean(record.category,40) or record.kind
    local kind=kinds[category] or kinds[record.kind] or "Location"
    if record.kind=="quest" and record.stage=="READY_FOR_TURN_IN" then kind="Quest turn-in" end
    lines[#lines+1]={text=kind,role="secondary"}
    local zone
    if type(C_Map)=="table" and type(C_Map.GetMapInfo)=="function" then
        local info,ok=I:Call(C_Map.GetMapInfo,record.mapID)
        if ok and I:Readable(info) and type(info)=="table" then zone=clean(info.name,100) end
    end
    lines[#lines+1]={text=(zone and zone.." · " or "")..string.format("%.1f, %.1f",record.x*100,record.y*100),role="text"}
    if record.availability=="UNAVAILABLE" then lines[#lines+1]={text="Not available",role="muted"} end
    if record.fishingType then
        if record.fishingType=="POOL" then lines[#lines+1]={text="Fishing pool",role="text"}
        elseif record.fishingType=="OPEN_WATER" then lines[#lines+1]={text="Open water",role="text"} end
        if I:Number(record.requiredSkill) and record.skillMeaning=="INTERACTION" then
            lines[#lines+1]={text="Fishing "..record.requiredSkill,role="text"}
        end
        if clean(record.catchSummary,220) then lines[#lines+1]={text="Recorded catches: "..record.catchSummary,role="text"} end
    elseif clean(record.serviceRoles,180) then lines[#lines+1]={text="Services: "..record.serviceRoles,role="text"}
    elseif clean(record.materialText,180) then lines[#lines+1]={text="Materials: "..record.materialText,role="text"} end
    if I:Number(record.observedAt) and record.observedAt>0 then
        local now=I:Now()
        if now>=record.observedAt then
            local age=now-record.observedAt
            local text=age<60 and "Recorded just now" or age<3600 and
                ("Recorded "..math.floor(age/60).."m ago") or age<86400 and
                ("Recorded "..math.floor(age/3600).."h ago") or ("Recorded "..math.floor(age/86400).."d ago")
            lines[#lines+1]={text=text,role="muted"}
        end
    end
    if record.destination then lines[#lines+1]={text="Current destination",role="secondary"} end
    local hint=clean(context.hint,140)
    if hint then lines[#lines+1]={text=hint,role="muted"} end
    return model,"AVAILABLE"
end
-- A pin may outlive its registry row or an account/provider replacement. Keep
-- the display attached to the exact context that produced its current model.
local function sameContext(proof)
    local storage=I.Storage
    local p=storage and storage.account and storage.account.preferences
    return proof and T.generation==proof.generation and storage==proof.storage and
        storage.account==proof.account and storage.character==proof.character and p==proof.preferences and
        p.tooltip==true and p.tooltipPresentation~="NATIVE" and not storage.readOnly and
        I.state.initialized and I.state.clientAllowed and I.core==proof.core and I.Context==proof.context and
        (not proof.context or proof.context.Service==proof.service) and
        p.tooltipTextSize==proof.textSize and p.tooltipAnchor==proof.anchor
end
local function sameRecord(record,model)
    return I:Readable(record) and type(record)=="table" and not record.hidden and
        record.id==model.id and record.label==model.title and record.kind==model.kind and
        record.mapID==model.mapID and record.x==model.x and record.y==model.y and
        (scalarRevision(record.revision) and record.revision or 0)==model.revision and
        record.sourceRevision==model.sourceRevision
end
local function provider(proof)
    if not proof.context or type(proof.service)~="function" then return nil,true end
    local records,read=I:Call(proof.service,proof.context,"WorldRecords")
    return records,read and sameContext(proof)
end
local function currentSource(proof)
    if not sameContext(proof) then return false end
    local records,read=provider(proof)
    if not read or records~=proof.records then return false end
    if not records then return true end
    if records.Get~=proof.get then return false end
    local row,ok=I:Call(proof.get,proof.model.id)
    if not sameContext(proof) or not ok then return false end
    -- Standalone/static hints remain supported; an existing registry identity
    -- must agree, and a once-registered record must not silently disappear.
    return row==nil and not proof.required or sameRecord(row,proof.model)
end
local function ownerVisible(owner)
    local method=type(owner.IsVisible)=="function" and owner.IsVisible or owner.IsShown
    local shown,read=I:Call(method,owner)
    return read and (shown==true or shown==1)
end
local function ownerHovered(owner)
    local method=type(owner.IsMouseOver)=="function" and owner.IsMouseOver
    local value,read
    if method then value,read=I:Call(method,owner)
    elseif type(MouseIsOver)=="function" then value,read=I:Call(MouseIsOver,owner) end
    if read and (value==true or value==1) then return true,true end
    if read and (value==false or value==nil or value==0) then return false,true end
    return nil,false
end
local function abandon(proof,why)
    -- An older callback must never hide a card opened by a newer callback.
    if proof and T.generation==proof.generation then T:Hide();T.status=why end
    return false,why
end
function T:Create()
    if self.frame then return true end
    if not UIParent or I:Combat() or type(CreateFrame)~="function" then return false end
    local f=CreateFrame("Frame","MirageIntelUtilityInsightCard",UIParent,"BackdropTemplate")
    if not f then return false end
    f:SetSize(306,164);f:SetFrameStrata("TOOLTIP");f:SetClampedToScreen(true);f:EnableMouse(false)
    local chrome=I.core and I.core.Chrome
    if chrome and type(chrome.Panel)=="function" then chrome.Panel(f)
    else
        f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8x8",edgeFile="Interface\\Buttons\\WHITE8x8",edgeSize=1})
        f:SetBackdropColor(.060,.060,.065,.97);f:SetBackdropBorderColor(.26,.26,.26,1)
    end
    local mark=f:CreateTexture(nil,"ARTWORK")
    mark:SetSize(20,20);mark:SetPoint("TOPLEFT",f,"TOPLEFT",10,-10)
    mark:SetTexture("Interface\\AddOns\\MirageIntel_Insight\\Media\\Badge.tga")
    local title=f:CreateFontString(nil,"OVERLAY","GameFontNormal")
    title:SetPoint("TOPLEFT",mark,"TOPRIGHT",6,-2);title:SetWidth(256);title:SetJustifyH("LEFT")
    title:SetTextColor(.96,.79,.36);title:SetWordWrap(true)
    f.title=title;f.rows={}
    for i=1,11 do
        local row=f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
        row:SetWidth(284);row:SetJustifyH("LEFT");row:SetJustifyV("TOP");row:SetWordWrap(true)
        f.rows[i]=row
    end
    f:SetScript("OnHide",function()
        if T.owner or T.displayContext then T.generation=T.generation+1 end
        T.owner=nil;T.model=nil;T.elapsed=0;T.sourceRecords=nil;T.displayContext=nil
    end)
    f:SetScript("OnUpdate",function(_,elapsed)
        T.elapsed=(T.elapsed or 0)+(I:Number(elapsed) and math.max(0,math.min(elapsed,.25)) or 0)
        if T.elapsed<.15 then return end
        T.elapsed=0
        local proof=T.displayContext
        if not proof then f:Hide();return end
        if proof.followHover then
            local over,read=ownerHovered(proof.owner)
            if read and not over then abandon(proof,"POINTER_LEFT_OWNER");return end
        end
        if not sameContext(proof) or not ownerVisible(proof.owner) or not currentSource(proof) then
            abandon(proof,"SOURCE_CHANGED_REOPEN_CARD")
        end
    end)
    f:Hide();self.frame=f
    return true
end
function T:Hide(owner)
    if owner~=nil and owner~=self.owner then return false,"NOT_CURRENT_OWNER" end
    self.generation=self.generation+1
    if self.frame then self.frame:Hide() end
    self.owner=nil;self.model=nil;self.elapsed=0;self.sourceRecords=nil;self.displayContext=nil
    return true
end
function T:Show(owner,record,context)
    if not I.state.initialized or not I.state.clientAllowed or I.Storage.readOnly then
        return false,"INSIGHT_UNAVAILABLE"
    end
    local pref=I.Storage.account and I.Storage.account.preferences
    if not pref or pref.tooltip~=true or pref.tooltipPresentation=="NATIVE" then
        self:Hide();return false,"INSIGHT_TOOLTIPS_DISABLED"
    end
    if not I:Readable(owner) or (type(owner)~="table" and type(owner)~="userdata") then
        return false,"INVALID_CARD_OWNER"
    end
    self.generation=self.generation+1
    local proof={generation=self.generation,owner=owner,storage=I.Storage,account=I.Storage.account,
        character=I.Storage.character,preferences=pref,textSize=pref.tooltipTextSize,anchor=pref.tooltipAnchor,
        core=I.core,context=I.Context,service=I.Context and I.Context.Service}
    if not ownerVisible(owner) or not sameContext(proof) then return abandon(proof,"CARD_OWNER_HIDDEN") end
    local model,why=self:Model(record,context)
    if not model or record.hidden then return abandon(proof,why or "INVALID_UTILITY_RECORD") end
    if not sameContext(proof) then return abandon(proof,"SOURCE_CHANGED_REOPEN_CARD") end
    proof.model=model
    local records,read=provider(proof)
    if not read then return abandon(proof,"SOURCE_CHANGED_REOPEN_CARD") end
    proof.records=records
    if records then
        if type(records)~="table" or type(records.Get)~="function" then return abandon(proof,"SOURCE_CHANGED_REOPEN_CARD") end
        proof.get=records.Get
        local current,ok=I:Call(proof.get,model.id)
        if not ok or not sameContext(proof) or (current~=nil and not sameRecord(current,model)) then
            return abandon(proof,"SOURCE_CHANGED_REOPEN_CARD")
        end
        proof.required=current~=nil
    end
    if I:Combat() or not sameContext(proof) or not self:Create() then return abandon(proof,"CARD_LAYOUT_UNAVAILABLE") end
    if not sameContext(proof) then return abandon(proof,"SOURCE_CHANGED_REOPEN_CARD") end
    if not self.hooked[owner] and type(owner.HookScript)=="function" then
        self.hooked[owner]=pcall(owner.HookScript,owner,"OnHide",function() T:Hide(owner) end)
    end
    if not sameContext(proof) then return abandon(proof,"SOURCE_CHANGED_REOPEN_CARD") end
    local f=self.frame
    local size=I:Number(pref.tooltipTextSize) and math.max(10,math.min(16,pref.tooltipTextSize)) or 12
    local function font(text,requested)
        if type(text.GetFont)~="function" or type(text.SetFont)~="function" then return sameContext(proof) end
        local face,ok,_,flags=I:Call(text.GetFont,text)
        if not sameContext(proof) then return false end
        if ok and I:Text(face,300) then I:Call(text.SetFont,text,face,requested,I:Text(flags,30) or "") end
        return sameContext(proof)
    end
    if not font(f.title,size+1) then return abandon(proof,"SOURCE_CHANGED_REOPEN_CARD") end
    -- Font measurements on hidden frames can describe the previous layout.
    -- Measure at the requested width while visible, within this single pass.
    f:Show()
    if not sameContext(proof) then return abandon(proof,"SOURCE_CHANGED_REOPEN_CARD") end
    f.title:SetText(model.title)
    local titleHeight,measured=I:Call(f.title.GetStringHeight,f.title)
    if not sameContext(proof) then return abandon(proof,"SOURCE_CHANGED_REOPEN_CARD") end
    local y=-(14+(measured and I:Number(titleHeight) and math.max(18,titleHeight) or 30)+8)
    for i,row in ipairs(f.rows) do
        local line=model.lines[i]
        if line then
            if not font(row,size) then return abandon(proof,"SOURCE_CHANGED_REOPEN_CARD") end
            row:ClearAllPoints();row:SetPoint("TOPLEFT",f,"TOPLEFT",11,y);row:SetText(line.text)
            if line.role=="secondary" then row:SetTextColor(.96,.79,.36)
            elseif line.role=="muted" then row:SetTextColor(.63,.62,.60)
            else row:SetTextColor(.90,.89,.87) end
            row:Show()
            local h,valid=I:Call(row.GetStringHeight,row)
            if not sameContext(proof) then return abandon(proof,"SOURCE_CHANGED_REOPEN_CARD") end
            y=y-(valid and I:Number(h) and math.max(13,h) or 26)-4
        else row:Hide() end
    end
    f:SetHeight(-y+9);f:ClearAllPoints()
    local right=I:Call(owner.GetRight,owner)
    local ownerScale=I:Call(owner.GetEffectiveScale,owner)
    local rootScale=I:Call(UIParent.GetEffectiveScale,UIParent)
    local screenWidth=I:Call(UIParent.GetWidth,UIParent)
    local autoLeft=pref.tooltipAnchor=="AUTO" and I:Number(right) and I:Number(ownerScale)
        and I:Number(rootScale) and rootScale>0 and I:Number(screenWidth)
        and right*ownerScale/rootScale+f:GetWidth()+8>screenWidth
    if pref.tooltipAnchor=="LEFT" or autoLeft then f:SetPoint("TOPRIGHT",owner,"TOPLEFT",-8,0)
    else f:SetPoint("TOPLEFT",owner,"TOPRIGHT",8,0) end
    local chrome=I.core and I.core.Chrome
    if chrome and type(chrome.Fit)=="function" then
        local fit,ok=I:Call(chrome.Fit,f,1)
        if not ok or fit==false then return abandon(proof,"CARD_LAYOUT_UNAVAILABLE") end
    end
    if not sameContext(proof) or not ownerVisible(owner) or not currentSource(proof) then
        return abandon(proof,"SOURCE_CHANGED_REOPEN_CARD")
    end
    self.owner=owner;self.model=model;self.sourceRecords=records;self.displayContext=proof;self.elapsed=0
    -- Pin providers normally send OnLeave. Also observe a confirmed hover so
    -- a missed leave callback cannot strand a card above a still-visible pin.
    proof.followHover=ownerHovered(owner)==true
    self.status="UTILITY_CARD_VISIBLE_NATIVE_UNTESTED"
    return true,"UTILITY_CARD_VISIBLE"
end
