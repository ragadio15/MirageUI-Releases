local _,M=...
M.Storage={readOnly=false,reason="UNINITIALIZED"}
local S=M.Storage
S.types={note=true,travel=true,quest=true,resource=true,danger=true}
S.settings={showMapButton=true,showCoordinates=false,showPersonalPins=true,
    showDestinationPin=true,mapPolicy="auto",pinLimit=50,kind="all",density="compact"}
-- Additive preferences do not invalidate a valid P2 account. Validate the old
-- schema first, then fill only absent new keys; corrupt values stay preserved.
S.additive={showQuestPins=true,showServicePins=true,showResourcePins=true,showPOIPins=true,
    showRouteStops=true,showRouteBearing=true,showUnexplored=true,showZoneGuide=true,
    filterFaction=false,filterClass=false,filterProfession=false,availability="all",
    placeLayer="all",resourceCategory="all"}
local layers={all=true,notes=true,quests=true,services=true,resources=true,pois=true,routes=true}
local categories={all=true,herb=true,ore=true,fish=true,pool=true,skin=true,treasure=true}
local function validExtra(key,value)
    local default=S.additive[key]
    if type(default)=="boolean" then return type(value)=="boolean" end
    if key=="availability" then return value=="all" or value=="usable" or value=="unknown" end
    if key=="placeLayer" then return layers[value]==true end
    if key=="resourceCategory" then return categories[value]==true end
    return false
end
local function freshAccount()
    local settings={};for k,v in pairs(S.settings) do settings[k]=v end
    for k,v in pairs(S.additive) do settings[k]=v end
    return {schemaVersion=1,sentinel="MIRAGEMAP_ACCOUNT_V1",revision=0,nextID=1,
      notes={},settings=settings}
end
local function freshCharacter()
    return {schemaVersion=1,sentinel="MIRAGEMAP_CHARACTER_V1",revision=0,
       hidden={},route={order={},cursor=0},panel={x=0,y=0,scale=1}}
end
local function count(t)
    local n=0;for _ in pairs(t) do n=n+1 end;return n
end
function S:ValidNote(note)
    return type(note)=="table" and M:Integer(note.id) and note.id<2147483647 and
        M:Integer(note.mapID) and note.mapID<1000000 and
        M.map and M.map:Valid(note.mapID,note.x,note.y) and
        M:Text(note.label,72) and S.types[note.kind]==true and
        (note.details==nil or M:Text(note.details,180)) and
        M:Number(note.createdAt) and note.createdAt>=0 and
        M:Number(note.updatedAt) and note.updatedAt>=0
end
function S:Initialize()
    if not M.state.clientAllowed then
        self.readOnly=true;self.reason="UNSUPPORTED_CLIENT_NO_WRITES";return
    end
    if MirageIntelMapDB==nil then MirageIntelMapDB=freshAccount() end
    if MirageIntelMapCharDB==nil then MirageIntelMapCharDB=freshCharacter() end
    local a,b=MirageIntelMapDB,MirageIntelMapCharDB
    self.account,self.character=a,b
    if not M:Readable(a) or not M:Readable(b) or type(a)~="table" or type(b)~="table" or
        a.schemaVersion~=1 or b.schemaVersion~=1 or type(a.notes)~="table" or
        type(a.settings)~="table" or type(b.hidden)~="table" or
        type(b.route)~="table" or type(b.route.order)~="table" or
        type(b.panel)~="table" or not M:Integer(a.nextID) or
        not M:Number(a.revision) or a.revision<0 or a.revision%1~=0 or
        not M:Number(b.revision) or b.revision<0 or b.revision%1~=0 then
        self.readOnly=true;self.reason="NEW_OR_CORRUPT_SCHEMA_PRESERVED";return
    end
    for key,default in pairs(S.settings) do
        local value=a.settings[key]
        if type(default)=="boolean" then
            if type(value)~="boolean" then self.readOnly=true;self.reason="INVALID_SETTINGS_PRESERVED";return end
        elseif key=="pinLimit" then
            if not M:Integer(value) or value>80 then self.readOnly=true;self.reason="INVALID_PIN_LIMIT";return end
        elseif key=="mapPolicy" then
            if value~="auto" and value~="manual" and value~="off" then self.readOnly=true;self.reason="INVALID_MAP_POLICY";return end
        elseif key=="kind" then
            if value~="all" and not S.types[value] then self.readOnly=true;self.reason="INVALID_CATEGORY";return end
        elseif key=="density" then
            if value~="compact" and value~="detailed" then self.readOnly=true;self.reason="INVALID_DENSITY";return end
        end
    end
    local size,maxID=0,0
    for id,record in pairs(a.notes) do
        size=size+1
        if size>M.maxNotes or not M:Integer(id) or not self:ValidNote(record) or record.id~=id then
            self.readOnly=true;self.reason="INVALID_NOTES_PRESERVED";return
        end
        maxID=math.max(maxID,id)
    end
    if a.nextID<=maxID then self.readOnly=true;self.reason="INVALID_COUNTER_PRESERVED";return end
    if count(b.hidden)>M.maxNotes then self.readOnly=true;self.reason="INVALID_HIDDEN_STATE";return end
    for id,hidden in pairs(b.hidden) do
        if not M:Integer(id) or not a.notes[id] or hidden~=true then
            self.readOnly=true;self.reason="INVALID_HIDDEN_STATE";return
        end
    end
    local r=b.route
    if #r.order>60 or not M:Number(r.cursor) or r.cursor<0 or r.cursor%1~=0 or
        (r.cursor>0 and r.cursor>#r.order) or (#r.order>0 and r.cursor==0) or
        (#r.order==0 and r.cursor~=0) then
        self.readOnly=true;self.reason="INVALID_ROUTE_PRESERVED";return
    end
    local included={}
    local entries=0
    for key in pairs(r.order) do
        entries=entries+1
        if type(key)~="number" or key%1~=0 or key<1 or key>#r.order or entries>60 then
            self.readOnly=true;self.reason="INVALID_ROUTE_PRESERVED";return
        end
    end
    if entries~=#r.order then self.readOnly=true;self.reason="INVALID_ROUTE_PRESERVED";return end
    for i,id in ipairs(r.order) do
        if not M:Integer(id) or not a.notes[id] or included[id] or i>60 then
            self.readOnly=true;self.reason="INVALID_ROUTE_PRESERVED";return
        end
        included[id]=true
    end
    local p=b.panel
    if not M:Number(p.x) or math.abs(p.x)>4000 or not M:Number(p.y) or math.abs(p.y)>4000 or
        not M:Number(p.scale) or p.scale<.7 or p.scale>1.5 then
        self.readOnly=true;self.reason="INVALID_PANEL_POSITION";return
    end
    for key in pairs(S.additive) do
        if a.settings[key]~=nil and not validExtra(key,a.settings[key]) then
            self.readOnly=true;self.reason="INVALID_ADDITIVE_SETTING_PRESERVED";return
        end
    end
    local migrated=false
    for key,value in pairs(S.additive) do
        if a.settings[key]==nil then a.settings[key]=value;migrated=true end
    end
    if migrated then a.revision=math.min(2147483647,a.revision+1) end
    self.readOnly=false
    self.reason="RESTORE_NEEDS_REAL_CLIENT_RELOAD_AND_RESTART"
    M.state.noteCount=size
end
function S:Writable()
    if self.readOnly then return false,self.reason end
    if not M.state.clientAllowed then return false,"UNSUPPORTED_BUILD" end
    return true
end
function S:Touch(scope)
    local t=scope=="character" and self.character or self.account
    t.revision=math.min(2147483647,t.revision+1)
end
function S:SetSetting(key,value)
    local ok,reason=self:Writable();if not ok then return false,reason end
    if self.settings[key]==nil and self.additive[key]==nil then return false,"UNKNOWN_SETTING" end
    if self.additive[key]~=nil then
        if not validExtra(key,value) then return false,"INVALID_PREFERENCE" end
    elseif type(self.settings[key])=="boolean" then
        if type(value)~="boolean" then return false,"INVALID_BOOLEAN" end
    elseif key=="pinLimit" then
        if not M:Integer(value) or value>80 then return false,"INVALID_PIN_LIMIT" end
    elseif key=="mapPolicy" then
        if value~="auto" and value~="manual" and value~="off" then return false,"INVALID_MAP_POLICY" end
    elseif key=="kind" then
        if value~="all" and not self.types[value] then return false,"INVALID_CATEGORY" end
    elseif key=="density" then
        if value~="compact" and value~="detailed" then return false,"INVALID_DENSITY" end
    end
    self.account.settings[key]=value
    self:Touch("account")
    if M.RecordQuery then M.RecordQuery:Invalidate() end
    if M.Canvas then M.Canvas:Dirty() end
    if M.Panel then M.Panel:Update() end
    return true,"PENDING_CLIENT_SAVE"
end
-- The Places reset/undo applies one validated preference transaction. A reset
-- must never expose an intermediate six-filter state to query subscribers.
function S:SetPlaceFilters(values)
    local account=self.account
    local ok,reason=self:Writable();if not ok then return false,reason end
    if M:Combat() then return false,"CHANGE_FILTERS_AFTER_COMBAT" end
    if type(values)~="table" or not M:Readable(values) then return false,"INVALID_FILTERS" end
    local allowed={filterFaction=true,filterClass=true,filterProfession=true,placeLayer=true,resourceCategory=true,availability=true}
    local prepared={};local count=0
    for key,value in pairs(values) do
        count=count+1
        if count>6 or not M:Readable(key) or not M:Readable(value) or not allowed[key] or not validExtra(key,value) then return false,"INVALID_FILTERS" end
        prepared[key]=value
    end
    if count~=6 then return false,"INCOMPLETE_FILTERS" end
    if self.account~=account or self.readOnly or not M.state.clientAllowed then return false,"FILTER_CONTEXT_CHANGED" end
    local changed=false
    for key,value in pairs(prepared) do if account.settings[key]~=value then changed=true end end
    if changed then
        for key,value in pairs(prepared) do account.settings[key]=value end
        self:Touch("account")
        if M.RecordQuery then M.RecordQuery:Invalidate() end
        if M.Canvas then M.Canvas:Dirty() end
        if M.Panel then M.Panel:Update() end
    end
    return true,changed and "FILTERS_UPDATED" or "FILTERS_UNCHANGED"
end
function S:Add(mapID,x,y,label,kind,details)
    local ok,reason=self:Writable();if not ok then return false,reason end
    if M:Combat() then return false,"COMBAT_NOTE_CHANGE_DEFERRED" end
    if not M.map:Valid(mapID,x,y) or not M:Text(label,72) or
       not self.types[kind or "note"] or (details~=nil and not M:Text(details,180)) then
        return false,"INVALID_NOTE"
    end
    -- Idempotent quick-save: the same label/category at nearly identical
    -- normalized coordinates is a single personal marker, not two icons.
    for _,existing in pairs(self.account.notes) do
        if existing.mapID==mapID and existing.kind==(kind or "note") and
            existing.label==label and math.abs(existing.x-x)<=.00005 and
            math.abs(existing.y-y)<=.00005 then return true,existing.id,"EXISTING_NOTE" end
    end
    if M.state.noteCount>=M.maxNotes or self.account.nextID>=2147483647 then
        return false,"NOTE_CAP_REACHED"
    end
    local id=self.account.nextID
    self.account.nextID=id+1
    local timestamp=M:When()
    self.account.notes[id]={id=id,mapID=mapID,x=x,y=y,label=label,
        kind=kind or "note",details=details,createdAt=timestamp,updatedAt=timestamp}
    M.state.noteCount=M.state.noteCount+1
    self:Touch("account")
    if M.Canvas then M.Canvas:Dirty() end
    if M.Panel then M.Panel:Update() end
    return true,id
end
function S:Edit(id,label,kind,details)
    local ok,reason=self:Writable();if not ok then return false,reason end
    if M:Combat() then return false,"COMBAT_NOTE_CHANGE_DEFERRED" end
    local rec=M:Integer(id) and self.account.notes[id]
    if not rec then return false,"NOTE_NOT_FOUND" end
    if not M:Text(label,72) or not self.types[kind] or
        (details~=nil and details~="" and not M:Text(details,180)) then
        return false,"INVALID_NOTE_EDIT" end
    rec.label=label;rec.kind=kind;rec.details=details~="" and details or nil
    rec.updatedAt=M:When()
    self:Touch("account")
    if M.Canvas then M.Canvas:Dirty() end
    return true,"NOTE_UPDATED"
end
function S:Delete(id,confirmed)
    local ok,reason=self:Writable();if not ok then return false,reason end
    if M:Combat() then return false,"COMBAT_NOTE_CHANGE_DEFERRED" end
    if not M:Integer(id) or not self.account.notes[id] then return false,"NOTE_NOT_FOUND" end
    if confirmed~=true then return false,"CONFIRMATION_REQUIRED" end
    self.account.notes[id]=nil
    self.character.hidden[id]=nil
    local r=self.character.route
    for i=#r.order,1,-1 do
        if r.order[i]==id then
            table.remove(r.order,i)
            if i<r.cursor then r.cursor=r.cursor-1 end
        end
    end
    if #r.order==0 then r.cursor=0 elseif r.cursor>#r.order then r.cursor=#r.order end
    M.state.noteCount=M.state.noteCount-1
    self:Touch("account");self:Touch("character")
    if M.Canvas then M.Canvas:Dirty() end
    return true,"PENDING_CLIENT_SAVE"
end
function S:Hide(id,hide)
    local ok,reason=self:Writable();if not ok then return false,reason end
    if not M:Integer(id) or not self.account.notes[id] or type(hide)~="boolean" then
        return false,"INVALID_NOTE_OR_VISIBILITY"
    end
    self.character.hidden[id]=hide and true or nil
    self:Touch("character")
    if M.RecordQuery then M.RecordQuery:Invalidate() end
    if M.Canvas then M.Canvas:Dirty() end
    if M.Panel then M.Panel:Update() end
    return true,"PENDING_CLIENT_SAVE"
end
function S:Collect(query)
    if self.readOnly then return {},0 end
    query=M:Readable(query) and type(query)=="table" and query or {}
    if not M:Readable(query.mapID) then return {},0 end
    local mapID=M:Integer(query.mapID) and query.mapID or nil
    if query.mapID~=nil and not mapID then return {},0 end
    local kind=M:Readable(query.kind) and type(query.kind)=="string" and self.types[query.kind] and query.kind or "all"
    local search=query.search
    local phrase=M:Readable(search) and type(search)=="string" and search:sub(1,60):match("^%s*(.-)%s*$"):lower() or ""
    local rows={}
    local notes=self.account and type(self.account.notes)=="table" and self.account.notes or {}
    local hidden=self.character and type(self.character.hidden)=="table" and self.character.hidden or {}
    for _,r in pairs(notes) do
        if type(r)=="table" and M:Text(r.label,72) and
            (not mapID or r.mapID==mapID) and (kind=="all" or r.kind==kind) and
            (query.includeHidden or not hidden[r.id]) and
            (phrase=="" or r.label:lower():find(phrase,1,true) or
             (r.details and r.details:lower():find(phrase,1,true))) then
             rows[#rows+1]=r
        end
    end
    table.sort(rows,function(a,b)
        if a.updatedAt~=b.updatedAt then return a.updatedAt>b.updatedAt end
        return a.id>b.id
    end)
    return rows,#rows
end
function S:List(query,limit,offset)
    local rows,total=self:Collect(query)
    local hidden=self.character and self.character.hidden or {}
    limit=M:Integer(limit) and math.min(limit,80) or 16
    offset=M:Number(offset) and math.max(0,math.min(math.floor(offset),M.maxNotes)) or 0
    local out={}
    for i=offset+1,math.min(total,offset+limit) do
        local r=rows[i]
        out[#out+1]={id=r.id,mapID=r.mapID,x=r.x,y=r.y,label=r.label,
           kind=r.kind,details=r.details,createdAt=r.createdAt,updatedAt=r.updatedAt,
           hidden=hidden[r.id]==true}
    end
    return out,total
end
function S:RouteAdd(id)
    local ok,reason=self:Writable();if not ok then return false,reason end
    if not M:Integer(id) or not self.account.notes[id] then return false,"UNKNOWN_NOTE" end
    local r=self.character.route
    if #r.order>=60 then return false,"ROUTE_FULL" end
    for _,existing in ipairs(r.order) do
        if existing==id then return false,"ALREADY_IN_ROUTE" end
    end
    r.order[#r.order+1]=id
    if r.cursor==0 then r.cursor=1 end
    self:Touch("character")
    return true,"ROUTE_STEP_SAVED"
end
function S:RouteRemove(index)
    local ok,reason=self:Writable();if not ok then return false,reason end
    local r=self.character.route
    if not M:Integer(index) or index>#r.order then return false,"INVALID_ROUTE_STEP" end
    table.remove(r.order,index)
    if #r.order==0 then r.cursor=0
    elseif r.cursor>index then r.cursor=r.cursor-1
    elseif r.cursor>#r.order then r.cursor=#r.order end
    self:Touch("character")
    return true,"ROUTE_STEP_REMOVED"
end
function S:RouteMove(from,to)
    local ok,reason=self:Writable();if not ok then return false,reason end
    if M:Combat() then return false,"COMBAT_ROUTE_CHANGE_DEFERRED" end
    local r=self.character.route
    if not M:Integer(from) or not M:Integer(to) or from>#r.order or to>#r.order then
        return false,"INVALID_ROUTE_STEP"
    end
    if from==to then return true,"ROUTE_UNCHANGED" end
    local active=r.order[r.cursor]
    local note=table.remove(r.order,from)
    table.insert(r.order,to,note)
    for i,id in ipairs(r.order) do
        if id==active then r.cursor=i;break end
    end
    self:Touch("character")
    return true,"ROUTE_STEP_MOVED"
end
function S:RouteSelect(index)
    local ok,reason=self:Writable();if not ok then return false,reason end
    local r=self.character.route
    if not M:Integer(index) or index>#r.order then return false,"INVALID_ROUTE_STEP" end
    r.cursor=index;self:Touch("character")
    return true,index
end
function S:RouteNext()
    local ok,reason=self:Writable();if not ok then return false,reason end
    local r=self.character.route
    if #r.order==0 then return false,"ROUTE_EMPTY" end
    if r.cursor==#r.order then return false,"END_OF_ROUTE_USE_RESET" end
    r.cursor=r.cursor+1;self:Touch("character")
    return true,r.cursor
end
function S:RouteReset()
    local ok,reason=self:Writable();if not ok then return false,reason end
    local r=self.character.route
    if #r.order==0 then return false,"ROUTE_EMPTY" end
    r.cursor=1;self:Touch("character")
    return true,r.cursor
end
function S:RouteClear()
    local ok,reason=self:Writable();if not ok then return false,reason end
    self.character.route={order={},cursor=0};self:Touch("character")
    return true,"ROUTE_CLEARED"
end
function S:RouteSnapshot()
    local r=type(self.character)=="table" and self.character.route
    if self.readOnly or type(r)~="table" or type(r.order)~="table" or type(self.account)~="table" or
       type(self.account.notes)~="table" then return {cursor=0,rows={}} end
    local rows={}
    for i,id in ipairs(r.order) do
        local n=self.account.notes[id]
        if n then rows[#rows+1]={index=i,id=id,label=n.label,mapID=n.mapID,x=n.x,y=n.y,kind=n.kind} end
    end
    return {cursor=r.cursor,rows=rows}
end
-- A read-only text snapshot, not an import format. Keep the public list limit
-- separate so the UI's 80-pin budget cannot truncate a player's notes export.
function S:Export(maxRows,offset)
    if self.readOnly then
        return "Map+ Ultra | saved notes unavailable ("..self.reason.."). Your files were not changed.",
            {available=false,count=0}
    end
    local limit=M:Integer(maxRows) and math.min(M.maxNotes,maxRows) or 100
    local rows,total=self:Collect({includeHidden=true})
    local start=M:Number(offset) and math.min(total,math.max(0,math.floor(offset))) or 0
    local last=math.min(total,start+limit)
    local hidden=self.character and self.character.hidden or {}
    local t={"Map+ Ultra | personal map notes | schema v1 | client build "..(M.state.clientBuild or "unknown"),
      string.format("Notes %d–%d of %d | includes hidden notes | manual observations",last>start and start+1 or 0,last,total),
      "id | type | label | mapID | x% | y% | visibility | details"}
    for i=start+1,last do
        local r=rows[i]
        t[#t+1]=table.concat({r.id,r.kind,r.label,r.mapID,
          string.format("%.6f",r.x*100),string.format("%.6f",r.y*100),hidden[r.id] and "hidden" or "shown",r.details or ""}," | ")
    end
    if start>0 or last<total then t[#t+1]=string.format("PARTIAL: %d of %d notes on this page.",last-start,total) end
    return table.concat(t,"\n"),{available=true,count=last-start,total=total,offset=start,nextOffset=last<total and last or nil}
end
