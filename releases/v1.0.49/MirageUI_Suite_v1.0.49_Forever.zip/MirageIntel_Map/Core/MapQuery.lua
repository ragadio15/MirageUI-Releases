local _,M=...
M.MapQuery={lastCursor=nil}
local Q=M.MapQuery
-- Window lifetime follows the entry point. A slash/minimap/API opening is
-- independent; a map marker or map launcher opens a companion of that map.
function Q:WindowOrigin(origin)
    if origin=="map" then return self:Shown() and self:Frame() or nil end
    if type(origin)=="table" or type(origin)=="userdata" then
        if origin==self:Frame() and self:Shown() then return origin end
    end
    return nil
end
function Q:BindWindow(frame,origin)
    if not frame then return nil end
    self.windows=self.windows or setmetatable({},{__mode="k"})
    local owner=self:WindowOrigin(origin)
    self.windows[frame]=owner
    return owner
end
function Q:CloseWindowsForMap(owner)
    if not owner or not self.windows then return end
    -- Suppress inspector's return-to-list callback before hiding either view.
    local inspector=M.Inspector
    if inspector and inspector.frame and self.windows[inspector.frame]==owner then inspector.returnToPanel=false end
    local closing={}
    for frame,map in pairs(self.windows) do if map==owner then closing[#closing+1]=frame end end
    for _,frame in ipairs(closing) do self.windows[frame]=nil;M:Call(frame.Hide,frame) end
    if M.Panel and M.Panel.mapOwner==owner then M.Panel.mapOwner=nil end
    if inspector and inspector.mapOwner==owner then inspector.mapOwner=nil end
end
function Q:Frame()
    if not M:Readable(WorldMapFrame) or not WorldMapFrame or
       type(WorldMapFrame.GetMapID)~="function" then return nil,"BLIZZARD_MAP_UNAVAILABLE" end
    return WorldMapFrame,"MAP_AVAILABLE"
end
function Q:Shown()
    local f=self:Frame()
    if not f then return false end
    local value,ok=M:Call(f.IsShown,f)
    return ok and value==true
end
function Q:CurrentMap()
    local f,why=self:Frame()
    if not f then return nil,why end
    local id,ok=M:Call(f.GetMapID,f)
    if not ok or not M:Integer(id) then return nil,"MAP_ID_UNAVAILABLE" end
    return id,"BLIZZARD_MAP"
end
-- A hidden world map retains its last browsed map. Standalone utility panels
-- should use the player's current map instead of that stale browser selection.
function Q:BrowseMap()
    if self:Shown() then return self:CurrentMap() end
    local player,why=self:Player()
    if player and M:Integer(player.mapID) then return player.mapID,"PLAYER_MAP" end
    return nil,why or "PLAYER_MAP_UNAVAILABLE"
end
function Q:Viewport()
    local f=self:Frame();local scroll=f and f.ScrollContainer;local canvas=scroll and scroll.Child
    local result={left=0,right=1,top=0,bottom=1,scale=1,status="WHOLE_MAP_FALLBACK"}
    if not scroll or not canvas then return result end
    local cs,cok=M:Call(canvas.GetEffectiveScale,canvas)
    local ss,sok=M:Call(scroll.GetEffectiveScale,scroll)
    if cok and sok and M:Number(cs) and M:Number(ss) and cs>0 and ss>0 then
        result.scale=math.max(.05,math.min(20,cs/ss))
    end
    local cl,a=M:Call(canvas.GetLeft,canvas);local cr,b=M:Call(canvas.GetRight,canvas)
    local ct,c=M:Call(canvas.GetTop,canvas);local cb,d=M:Call(canvas.GetBottom,canvas)
    local sl,e=M:Call(scroll.GetLeft,scroll);local sr,g=M:Call(scroll.GetRight,scroll)
    local st,h=M:Call(scroll.GetTop,scroll);local sb,i=M:Call(scroll.GetBottom,scroll)
    if not (a and b and c and d and e and g and h and i and cok and sok) then return result end
    for _,v in ipairs({cl,cr,ct,cb,sl,sr,st,sb,cs,ss}) do if not M:Number(v) then return result end end
    cl,cr,ct,cb=cl*cs,cr*cs,ct*cs,cb*cs
    sl,sr,st,sb=sl*ss,sr*ss,st*ss,sb*ss
    if cr<=cl or ct<=cb or sr<=sl or st<=sb then return result end
    local function clamp(v) return math.max(0,math.min(1,v)) end
    result.left=clamp((sl-cl)/(cr-cl));result.right=clamp((sr-cl)/(cr-cl))
    result.top=clamp((ct-st)/(ct-cb));result.bottom=clamp((ct-sb)/(ct-cb))
    if result.right<=result.left or result.bottom<=result.top then return {left=0,right=1,top=0,bottom=1,scale=result.scale,status="WHOLE_MAP_FALLBACK"} end
    result.status="PUBLIC_VIEWPORT";return result
end
function Q:Name(mapID)
    if not M:Integer(mapID) or type(C_Map)~="table" then return nil end
    local info,ok=M:Call(C_Map.GetMapInfo,mapID)
    if not ok or type(info)~="table" or not M:Readable(info) then return nil end
    return M:Text(info.name,90)
end
function Q:Player()
    if not M.map or type(M.map.Player)~="function" then return nil,"CORE_MAP_UNAVAILABLE" end
    local position,reason=M.map:Player()
    if not position then return nil,reason end
    return {mapID=position.mapID,floorID=position.floorID or position.mapID,x=position.x,y=position.y,world=position.world},"PLAYER_CURRENT_POSITION"
end
function Q:Cursor()
    if not self:Shown() then return nil,"OPEN_MAP_FIRST" end
    local mapID,reason=self:CurrentMap()
    if not mapID then return nil,reason end
    local f=WorldMapFrame
    local scroll=f and f.ScrollContainer
    if not scroll or not M:Readable(scroll) or type(scroll.GetNormalizedCursorPosition)~="function" then
        return nil,"CURSOR_API_UNAVAILABLE"
    end
    local over,ok=M:Call(scroll.IsMouseOver,scroll)
    if not ok or over~=true then return nil,"CURSOR_OUTSIDE_MAP" end
    local x,valid,y=M:Call(scroll.GetNormalizedCursorPosition,scroll)
    if not valid or not M.map:Valid(mapID,x,y) then return nil,"INVALID_MAP_CURSOR" end
    self.lastCursor={mapID=mapID,x=x,y=y,at=M:Now(),frame=f,scroll=scroll,canvas=scroll.Child}
    return {mapID=mapID,x=x,y=y},"MAP_CURSOR"
end
function Q:LastCursor()
    if not self:Shown() then self.lastCursor=nil;return nil,"OPEN_MAP_FIRST" end
    local r=self.lastCursor
    if not r or M:Now()-r.at>25 then return nil,"MOVE_CURSOR_OVER_MAP_FIRST" end
    local mapID=self:CurrentMap()
    local f=self:Frame()
    local scroll=f and f.ScrollContainer
    if not mapID or r.mapID~=mapID or r.frame~=f or not scroll or r.scroll~=scroll or
       r.canvas~=scroll.Child then
        self.lastCursor=nil;return nil,"MAP_CHANGED_SINCE_CURSOR_CAPTURE"
    end
    return {mapID=r.mapID,x=r.x,y=r.y},"RECENT_CURSOR"
end
function Q:Children(mapID,search,limit)
    if not M:Integer(mapID) then return {},"MAP_NOT_SELECTED" end
    if type(C_Map)~="table" or type(C_Map.GetMapChildrenInfo)~="function" then
        return {},"MAP_BROWSER_API_UNAVAILABLE"
    end
    local list,ok=M:Call(C_Map.GetMapChildrenInfo,mapID)
    local provenance="BLIZZARD_CHILD_MAPS_ONLY"
    -- A zone with no children shows sibling zones from its verified parent.
    -- Avoid guessing continent/zone IDs from names or a bundled map catalog.
    if (not ok or type(list)~="table" or not M:Readable(list) or #list==0) and type(C_Map.GetMapInfo)=="function" then
        local info,have=M:Call(C_Map.GetMapInfo,mapID)
        if have and type(info)=="table" and M:Integer(info.parentMapID) then
            local siblingData,got=M:Call(C_Map.GetMapChildrenInfo,info.parentMapID)
            if got and type(siblingData)=="table" and M:Readable(siblingData) then
                list=siblingData;ok=true;provenance="BLIZZARD_SIBLING_MAPS_ONLY"
            end
        end
    end
    if not ok or type(list)~="table" or not M:Readable(list) then return {},"NO_CHILD_MAP_DATA" end
    local rows,found={},{}
    local phrase=type(search)=="string" and search:sub(1,60):lower() or ""
    for _,entry in ipairs(list) do
        if #rows>=math.min(limit or 100,150) then break end
        if type(entry)=="table" and M:Readable(entry) and M:Integer(entry.mapID) and
           M:Text(entry.name,90) and not found[entry.mapID] then
            local name=entry.name
            if phrase=="" or name:lower():find(phrase,1,true) then
                found[entry.mapID]=true
                rows[#rows+1]={mapID=entry.mapID,name=name}
            end
        end
    end
    table.sort(rows,function(a,b)
        return a.name==b.name and a.mapID<b.mapID or a.name<b.name
    end)
    return rows,provenance
end
function Q:OpenMap()
    if not M.state.clientAllowed then return false,"UNSUPPORTED_FOREVER_BUILD" end
    if M:Combat() then return false,"LEAVE_COMBAT_TO_OPEN_MAP" end
    if self:Shown() then return true,"MAP_ALREADY_OPEN" end
    if type(ToggleWorldMap)~="function" then return false,"BLIZZARD_MAP_TOGGLE_UNAVAILABLE" end
    local _,ok=M:Call(ToggleWorldMap)
    return ok,ok and "MAP_TOGGLE_REQUESTED" or "MAP_TOGGLE_FAILED"
end
function Q:GoToMap(mapID)
    if not M.state.clientAllowed then return false,"UNSUPPORTED_FOREVER_BUILD" end
    if M:Combat() then return false,"MAP_SELECTION_DISABLED_IN_COMBAT" end
    if not self:Shown() then return false,"OPEN_MAP_FIRST" end
    if not M:Integer(mapID) then return false,"SELECT_ZONE_FIRST" end
    local f=self:Frame()
    if not f or type(f.SetMapID)~="function" then return false,"NATIVE_MAP_SELECTION_UNAVAILABLE" end
    -- Only a direct player click calls this; no quest tracker / protected changes.
    local _,ok=M:Call(f.SetMapID,f,mapID)
    if M.Canvas then M.Canvas:Dirty() end
    return ok,ok and "MAP_SELECTION_REQUESTED" or "NATIVE_SELECTION_FAILED"
end
