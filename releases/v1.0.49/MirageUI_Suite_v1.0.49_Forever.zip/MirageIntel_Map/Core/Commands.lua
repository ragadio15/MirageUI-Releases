local _,M=...
M.Commands={}
function M.Commands:Install()
    SLASH_MIRAGEMAP1="/miragemap"
    SLASH_MIRAGEMAP2="/mmap"
    SlashCmdList.MIRAGEMAP=function(message)
        local text=type(message)=="string" and message:match("^%s*(.-)%s*$") or ""
        local cmd,rest=text:match("^(%S+)%s*(.*)$")
        cmd=cmd and cmd:lower() or ""
        local result,why
        if cmd=="status" then
            local s=M.Storage
            M:Print("build "..(M.state.clientBuild or "unknown").." | state="..M.state.status.." | notes="..tostring(M.state.noteCount or 0)..
                " | storage="..s.reason.." | reason="..tostring(M.state.reason or "unknown").." | overlay="..M.Canvas.status.." | native=NOT_RUN")
            local overlaps=M.Integration:Conflicts()
            if #overlaps>0 then M:Print("External map addons: "..table.concat(overlaps,", ").." (independent utility layers)") end
        elseif cmd=="here" then
            result,why=M.API:PinHere(M:Text(rest,72) or "My location","note")
            M:Print(result and "Current position saved as a personal note." or why)
        elseif cmd=="cursor" then
            result,why=M.API:PinCursor(M:Text(rest,72) or "Map cursor","note")
            M:Print(result and "Last map cursor saved." or why)
        elseif cmd=="pin" then
            local x,y,label=rest:match("^(%d+%.?%d*)%s+(%d+%.?%d*)%s*(.*)$")
            result,why=M.API:PinCoordinates(tonumber(x),tonumber(y),M:Text(label,72) or "Map note","note")
            M:Print(result and "Map note saved at the selected map coordinates." or why)
        elseif cmd=="go" then
            local id=tonumber(rest)
            result,why=M.API:Select(id)
            M:Print(result and "Wayfinder destination selected." or why)
        elseif cmd=="route" then
            local sub,id=rest:match("^(%S+)%s*(%d*)")
            if sub=="add" then result,why=M.Storage:RouteAdd(tonumber(id))
            elseif sub=="remove" then result,why=M.Storage:RouteRemove(tonumber(id))
            elseif sub=="move" then
                local from,to=rest:match("^move%s+(%d+)%s+(%d+)%s*$")
                result,why=M.Storage:RouteMove(tonumber(from),tonumber(to))
            elseif sub=="next" then result,why=M.Storage:RouteNext()
            elseif sub=="go" then result,why=M.API:RouteNavigate()
            elseif sub=="reset" then result,why=M.Storage:RouteReset()
            elseif sub=="clear" then result,why=M.Storage:RouteClear()
            else result=false;why="Usage: /mmap route add <noteID>, move <from> <to>, remove <step>, next, go, reset, clear" end
            M:Print(result and "Route updated." or why)
            if result then M.Panel:Update() end
        elseif cmd=="scale" then
            result,why=M.Panel:SetRequestedScale(tonumber(rest))
            M:Print(result and "Map window scale saved." or why)
        elseif cmd=="places" or cmd=="search" then
            M.Panel.page="Places";M.Panel.offset=0;M.Panel.clusterMembers=nil
            result,why=M.Panel:Open()
            if result and M.Panel.search then M.Panel.search:SetText(rest or "");M.Panel:Update() end
            if not result then M:Print(why) end
        elseif cmd=="export" then M.Panel:ShowExport()
        elseif cmd=="map" then
            result,why=M.MapQuery:OpenMap();M:Print(why)
        elseif cmd=="help" then
            M:Print("/mmap (panel) | places [search] | map | here [name] | cursor [name] | pin X Y [name] | go ID | route | scale | status | export")
        else M.Panel:Open() end
    end
end
