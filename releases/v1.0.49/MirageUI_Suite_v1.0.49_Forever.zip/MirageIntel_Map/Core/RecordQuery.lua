local _,M=...
-- One revisioned map-local view. Query pages are consumed in cooperative 64-row
-- slices; canvas caps affect painting only, never the accessible result list.
M.RecordQuery={generation=0,dirty=true,rows={},byID={},status="NOT_REQUESTED",search="",material=""}
local Q=M.RecordQuery
local layerSettings={notes="showPersonalPins",quests="showQuestPins",services="showServicePins",resources="showResourcePins",pois="showPOIPins",routes="showDestinationPin"}
local orderedLayers={"notes","quests","services","resources","pois","routes"}
function Q:Layer(record)
    return record.layer or (record.kind=="gather" and "resources" or record.kind=="quest" and "quests" or
        (record.kind=="service" or record.kind=="flight" or record.kind=="transport") and "services" or
        record.kind=="note" and "notes" or record.kind=="destination" and "routes" or "pois")
end
function Q:Enabled(layer)
    local p=M.Storage.account and M.Storage.account.settings or {}
    if layer=="routes" then return p.showDestinationPin~=false or p.showRouteStops~=false or p.showRouteBearing~=false end
    return p[layerSettings[layer]]~=false
end
function Q:Invalidate()
    self.dirty=true;self.generation=self.generation+1;self.cursor=nil;self.loading=false;self.scheduled=false
    local tasks=M.Integration:Service("Tasks")
    if tasks and type(tasks.Cancel)=="function" then M:Call(tasks.Cancel,"MirageIntel_MapQuery") end
end
function Q:SetSearch(search,material)
    local clip=M.core and M.core.TextBytes
    search=type(search)=="string" and (clip and clip(search,96) or search:sub(1,96)) or ""
    material=type(material)=="string" and (clip and clip(material,96) or material:sub(1,96)) or ""
    if search:find("[%c|]") or material:find("[%c|]") then return false,"INVALID_SEARCH" end
    if self.search~=search or self.material~=material then
        self.search=search;self.material=material;self:Invalidate()
        if M.Canvas then M.Canvas:Dirty() end
    end
    return true
end
function Q:Context()
    local p=M.Storage.account.settings;local c={}
    if p.filterFaction then
        local faction,ok=M:Call(UnitFactionGroup,"player")
        if ok and (faction=="Alliance" or faction=="Horde") then c.faction=faction end
    end
    if p.filterClass then
        local _,ok,_,classID=M:Call(UnitClass,"player")
        if ok and M:Integer(classID) then c.classID=classID end
    end
    if p.filterProfession and type(C_SkillInfo)=="table" and type(C_SkillInfo.GetSkillLineInfoByID)=="function" then
        c.nativeSkills=true;c.professionReadback={}
        for _,id in ipairs({186,182,393,356}) do
            local info,ok=M:Call(C_SkillInfo.GetSkillLineInfoByID,id)
            if ok then
                c.professionReadback[id]=true
                c.professions=c.professions or {}
                if type(info)=="table" and M:Readable(info) and M:Readable(info.skillID) and info.skillID==id and M:Number(info.rank) and info.rank>0 and M:Readable(info.isHeader) and info.isHeader~=true then
                    c.professions[id]=info.rank
                end
            end
        end
    elseif p.filterProfession and type(GetProfessions)=="function" and type(GetProfessionInfo)=="function" then
        -- A filter selects a known profession; unrelated service POIs remain.
        local ids={M:Call(GetProfessions)}
        if ids[2]==true then
            for _,slot in ipairs({1,3,4,5,6}) do
                local index=ids[slot]
                if M:Integer(index) then
                    local ok,_,_,rank,_,_,_,skillLine=pcall(GetProfessionInfo,index)
                    if ok and M:Integer(skillLine) then
                        c.professions=c.professions or {};c.professions[skillLine]=M:Number(rank) and rank or 0
                    end
                end
            end
        end
    end
    return c
end
function Q:Request(mapID)
    local p=M.Storage.account.settings;local c=self:Context()
    local layers={}
    for _,layer in ipairs(orderedLayers) do
        if self:Enabled(layer) and (p.placeLayer==nil or p.placeLayer=="all" or p.placeLayer==layer) then layers[#layers+1]=layer end
    end
    return {mapID=mapID,limit=64,visibility="world",layers=layers,search=self.search~="" and self.search or nil,
        material=self.material~="" and self.material or nil,availability=p.availability or "all",faction=c.faction,classID=c.classID},c
end
function Q:Accept(record)
    local layer=self:Layer(record);local p=M.Storage.account.settings
    if not self:Enabled(layer) or (p.placeLayer and p.placeLayer~="all" and p.placeLayer~=layer) then return false end
    if record.hidden or record.showWorld==false then return false end
    if layer=="resources" and p.resourceCategory and p.resourceCategory~="all" and p.resourceCategory~=record.category then return false end
    if p.filterProfession and M:Integer(record.professionID) and self.context and self.context.nativeSkills and
        not self.context.professionReadback[record.professionID] then
        local info,ok=M:Call(C_SkillInfo.GetSkillLineInfoByID,record.professionID)
        -- Record-specific professions include crafting trainers as well as the
        -- four gathering skill lines. Unknown API evidence remains unknown.
        self.context.professionReadback[record.professionID]=ok and "KNOWN" or "UNKNOWN"
        if ok then
            self.context.professions=self.context.professions or {}
            if type(info)=="table" and M:Readable(info) and M:Readable(info.skillID) and info.skillID==record.professionID and M:Number(info.rank) and info.rank>0 and M:Readable(info.isHeader) and info.isHeader~=true then
                self.context.professions[record.professionID]=info.rank
            end
        end
    end
    if p.filterProfession and M:Integer(record.professionID) and self.context and self.context.professions and
        (not self.context.nativeSkills or (self.context.professionReadback[record.professionID] and self.context.professionReadback[record.professionID]~="UNKNOWN")) then
        local rank=self.context.professions[record.professionID]
        if not rank then return false end
        if M:Number(record.requiredSkill) and record.skillMeaning=="INTERACTION" and record.requiredSkill>rank then return false end
    end
    return true
end
function Q:MatchLocal(record)
    if not self:Accept(record) then return false end
    local availability=M.Storage.account.settings.availability
    if availability=="usable" and record.availability~="AVAILABLE" and record.availability~="ACCEPTED" and record.availability~="KNOWN" then return false end
    if availability=="unknown" and record.availability and record.availability~="UNKNOWN" then return false end
    local text=table.concat({record.label or "",record.category or "",record.details or "",record.serviceRoles or "",record.materialText or ""}," "):lower()
    if self.search~="" and not text:find(self.search:lower(),1,true) then return false end
    if self.material~="" and not (record.materialText or ""):lower():find(self.material:lower(),1,true) then return false end
    return true
end
function Q:Append(record)
    if not M.Integration:ValidRecord(record) or not self:Accept(record) or self.byID[record.id] then return end
    self.byID[record.id]=record;self.rows[#self.rows+1]=record
end
function Q:Sort()
    -- Live flight-master observations carry learned-state evidence. Prefer
    -- them when the independently published map catalog depicts the same stop.
    local flights={}
    for _,r in ipairs(self.rows) do
        if r.source=="NATIVE_TAXI_OBSERVATION" then flights[#flights+1]=r end
    end
    if #flights>0 then
        for i=#self.rows,1,-1 do
            local r=self.rows[i]
            if r.kind=="flight" and r.source~="NATIVE_TAXI_OBSERVATION" then
                for _,observed in ipairs(flights) do
                    if (r.nodeID and r.nodeID==observed.nodeID or
                        r.label==observed.label and math.abs(r.x-observed.x)<.006 and math.abs(r.y-observed.y)<.006) then
                        table.remove(self.rows,i);self.byID[r.id]=nil;break
                    end
                end
            end
        end
    end
    table.sort(self.rows,function(a,b)
        local aa=a.availability=="AVAILABLE" or a.availability=="ACCEPTED"
        local ba=b.availability=="AVAILABLE" or b.availability=="ACCEPTED"
        if aa~=ba then return aa end
        if a.label~=b.label then return a.label<b.label end
        return a.id<b.id
    end)
end
function Q:Notify()
    if M.Canvas then M.Canvas:Dirty() end
    if M.Panel and not self.notifying then
        self.notifying=true
        local ok=pcall(M.Panel.Update,M.Panel)
        self.notifying=false
        if not ok then M:Fault("QUERY_PANEL_UPDATE_FAILED") end
    end
end
function Q:Step(generation)
    if generation~=self.generation or not self.loading then return false end
    local service=M.Integration:Service("WorldRecords")
    if not service or type(service.Query)~="function" then
        self.status="WORLD_RECORDS_UNAVAILABLE";self.loading=false;self:Notify();return false
    end
    local request=M.core.Copy(self.request);request.cursor=self.cursor
    local result,ok=M:Call(service.Query,request)
    if generation~=self.generation then return false end
    if not ok or type(result)~="table" or type(result.records)~="table" then
        self.status="QUERY_UNAVAILABLE";self.loading=false;self:Notify();return false
    end
    if self.cursor and result.status=="STALE_CURSOR" then
        self:Invalidate();self.status="RECORDS_CHANGED";self:Notify();return false
    end
    for i,record in ipairs(result.records) do if i>64 then break end;self:Append(record) end
    self.revision=result.revision;self.totalMatched=result.totalMatched or #self.rows
    self.cursor=result.nextCursor;self.loading=self.cursor~=nil;self.status=self.loading and "LOADING_PAGES" or result.status or "READY"
    if not self.loading then self:Sort() end
    self:Notify()
    return generation==self.generation and self.loading
end
function Q:Ensure(mapID)
    local a=M.Storage.account
    local character=M.Storage.character
    if not M:Integer(mapID) or M.Storage.readOnly or not a then return self.rows end
    if not self.dirty and self.mapID==mapID and self.noteRevision==a.revision and
        self.characterRevision==(character and character.revision) then return self.rows end
    self:Invalidate();self.dirty=false;self.mapID=mapID;self.noteRevision=a.revision
    self.characterRevision=character and character.revision
    self.rows={};self.byID={};self.request,self.context=self:Request(mapID)
    self.status="LOADING_PAGES";self.totalMatched=0;self.loading=true
    -- Storage's public List API pages at 80 rows. The map's complete local
    -- model must include every saved note before applying its marker budget.
    local notes=M.Storage.Collect and M.Storage:Collect({mapID=mapID,kind="all"}) or
        M.Storage:List({mapID=mapID,kind="all"},M.maxNotes,0)
    for index,note in ipairs(notes) do
        if index>M.maxNotes then break end
        local record=M.Integration:NoteRecord(note)
        if record and self:MatchLocal(record) then self:Append(record) end
    end
    local generation=self.generation
    self:Step(generation)
    if generation==self.generation and self.loading then
        local tasks=M.Integration:Service("Tasks")
        if tasks and type(tasks.Queue)=="function" then
            local accepted,ok=M:Call(tasks.Queue,"MirageIntel_MapQuery",function() return Q:Step(generation) end,generation)
            if self.generation==generation then self.scheduled=ok and accepted==true end
        else self.scheduled=false end
    end
    return self.rows
end
function Q:Tick()
    if self.loading and not self.scheduled then self:Step(self.generation) end
end
function Q:List(mapID,memberIDs)
    self:Ensure(mapID)
    if not memberIDs then return self.rows end
    local rows={}
    local stops={};for _,r in ipairs(M.Integration:RouteStops(mapID)) do stops[r.id]=r end
    for _,id in ipairs(memberIDs) do
        local record=self.byID[id] or stops[id]
        if not record and type(id)=="string" then
            local noteID=tonumber(id:match("^mapnote:(%d+)$"))
            if noteID and not M.Storage.character.hidden[noteID] then record=M.Integration:NoteRecord(M.Storage.account.notes[noteID]) end
        end
        if record then rows[#rows+1]=record end
    end
    return rows
end
function Q:Inside(record,view)
    return record.x>=view.left and record.x<=view.right and record.y>=view.top and record.y<=view.bottom
end
function Q:PaintModel(mapID,w,h,view,budget,destination,selected,blockedLayers)
    local rows=self:Ensure(mapID);budget=math.max(3,math.min(80,budget or 50))
    view=view or {left=0,right=1,top=0,bottom=1,scale=1}
    local floorID=view.floorID or mapID
    local function onFloor(record)
        return record.mapID==mapID and (record.floorID or record.mapID)==floorID
    end
    local priority,represented={},{}
    local function identity(record)
        if record.kind=="quest" and M:Integer(record.questID) then
            return "quest:"..record.mapID..":"..record.questID..":"..string.format("%.5f:%.5f",record.x,record.y)
        end
        return record.siteID or record.id
    end
    local function reserve(record,role)
        if record and onFloor(record) and not represented[identity(record)] and self:Inside(record,view) and
            self:Enabled(role=="destination" and "routes" or self:Layer(record)) and
            (not blockedLayers or not blockedLayers[role=="destination" and "routes" or self:Layer(record)]) then
            represented[identity(record)]=true;priority[#priority+1]={record=record,role=role,members={record.id},x=record.x,y=record.y}
        end
    end
    reserve(destination,"destination");reserve(selected,"selected")
    local radius=(M.Storage.account.settings.density=="detailed" and 32 or 40)
    local sx,sy=math.max(1,w*(view.scale or 1)),math.max(1,h*(view.scale or 1))
    local candidates={}
    local routeIDs={}
    for _,record in ipairs(M.Integration:RouteStops(mapID)) do
        if onFloor(record) and self:Enabled("routes") and (not blockedLayers or not blockedLayers.routes) and not represented[identity(record)] and self:Inside(record,view) then
            candidates[#candidates+1]=record;routeIDs[identity(record)]=true
        end
    end
    for _,record in ipairs(rows) do
        if not represented[identity(record)] and not routeIDs[identity(record)] and onFloor(record) and self:Inside(record,view) and
            (not blockedLayers or not blockedLayers[self:Layer(record)]) then candidates[#candidates+1]=record end
    end
    -- Start nearby groups at the landmark itself. A lower-priority gathering
    -- record or a dungeon beneath a capital must not displace its city icon.
    local ranked={{},{},{}}
    for _,r in ipairs(candidates) do
        local rank=r.category=="city" and 1 or r.category=="entrance" and 2 or 3
        ranked[rank][#ranked[rank]+1]=r
    end
    candidates={}
    for _,bucket in ipairs(ranked) do for _,r in ipairs(bucket) do candidates[#candidates+1]=r end end
    local cells,groups={},{}
    local function build(cellSize)
        cells={};groups={}
        local icons=M.core and M.core.MapIcons
        if icons and type(icons.ClusterPoints)=="function" then
            local points={}
            for _,record in ipairs(candidates) do points[#points+1]={record=record,x=record.x*sx,y=record.y*sy} end
            for _,cluster in ipairs(icons.ClusterPoints(points,cellSize)) do
                local group={record=cluster.point.record,role=#cluster.points>1 and "cluster" or "record",
                    members={},x=cluster.x/sx,y=cluster.y/sy,layers={}}
                for _,point in ipairs(cluster.points) do
                    local record=point.record
                    group.members[#group.members+1]=record.id;group.layers[self:Layer(record)]=true
                end
                groups[#groups+1]=group
            end
            return
        end
        for _,record in ipairs(candidates) do
            local key=math.floor(record.x*sx/cellSize)..":"..math.floor(record.y*sy/cellSize)
            local group=cells[key]
            if not group then group={record=record,role="record",members={},x=0,y=0,layers={}};cells[key]=group;groups[#groups+1]=group end
            group.members[#group.members+1]=record.id;group.x=group.x+record.x;group.y=group.y+record.y
            group.layers[self:Layer(record)]=true
        end
        for _,group in ipairs(groups) do group.x=group.x/#group.members;group.y=group.y/#group.members;if #group.members>1 then group.role="cluster" end end
    end
    build(radius)
    local remaining=math.max(1,budget-#priority)
    -- Coarsen boundedly instead of dropping colliding/low-priority records.
    for _=1,12 do if #groups<=remaining then break end;radius=radius*1.6;build(radius) end
    if #groups>remaining then
        -- Defensive final aggregate; all members remain in the list.
        local merged={record=groups[1].record,role="cluster",members={},layers={},x=0,y=0}
        for _,group in ipairs(groups) do
            for _,id in ipairs(group.members) do merged.members[#merged.members+1]=id end
            for layer in pairs(group.layers) do merged.layers[layer]=true end
            merged.x=merged.x+group.x*#group.members;merged.y=merged.y+group.y*#group.members
        end
        merged.x=merged.x/#merged.members;merged.y=merged.y/#merged.members;groups={merged}
    end
    for _,group in ipairs(groups) do
        local r=group.record
        if group.role=="cluster" and (r.category=="city" or r.category=="entrance") then
            group.landmark=true;group.x=r.x;group.y=r.y
        end
    end
    local all={};for _,p in ipairs(priority) do all[#all+1]=p end;for _,g in ipairs(groups) do all[#all+1]=g end
    return all,{records=#candidates+#priority,markers=#all,loading=self.loading,status=self.status,revision=self.revision}
end
function Q:GetStatus()
    return {mapID=self.mapID,status=self.status,loaded=#self.rows,matched=self.totalMatched,loading=self.loading==true,
        revision=self.revision,generation=self.generation,search=self.search,material=self.material}
end
