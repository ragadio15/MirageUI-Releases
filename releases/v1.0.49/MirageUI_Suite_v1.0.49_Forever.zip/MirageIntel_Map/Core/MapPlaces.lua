local _,M=...
-- Cartographic facts have a different lifetime from quest eligibility or a
-- merchant interaction. Publish each viewed map atomically under its own owner.
local P={owner="MirageIntel_MapPlaces",status="NOT_REQUESTED",serial=0}
M.Places=P
local catalog=M.Catalog
-- Capital/zone associations and the measured Undercity fallback are from
-- ForeverPlusPlus Data/PointsOfInterest.lua (MIT, see ThirdParty/FPP-LICENSE.txt).
local cityZones={[1453]=1429,[1454]=1411,[1455]=1426,[1456]=1412,[1457]=1438,[1458]=1420}
local citySource="https://github.com/xIGBClutchIx/ForeverPlusPlus/blob/8c5d56cb5320bce9a3ef1e6818bc2df944bb8272/ForeverPlusPlus/Data/PointsOfInterest.lua"
local function worldPoint(child,parent,u)
    local point=M:Call(CreateVector2,u,u)
    if not point then return end
    local worldID,ok,world=M:Call(C_Map and C_Map.GetWorldPosFromMapPos,child,point)
    if not ok or not M:Number(worldID) or not world then return end
    local mapped,read,position=M:Call(C_Map.GetMapPosFromWorldPos,worldID,world,parent)
    if read and mapped==parent then return M.map:XY(position) end
end
local function rect(child,parent)
    local l,ok,r,t,b=M:Call(C_Map and C_Map.GetMapRectOnMap,child,parent)
    if ok and M:Number(l) and M:Number(r) and M:Number(t) and M:Number(b) and
        r>l and b>t and not (l==0 and r==1 and t==0 and b==1) then
        return {l,r,t,b}
    end
    -- Some city maps lack a direct rectangle. Two independent world samples
    -- establish the scale and direction on the requested map.
    local x1,y1=worldPoint(child,parent,.25)
    local x2,y2=worldPoint(child,parent,.75)
    if x1 and x2 and x2>x1 and y2>y1 then
        local dx,dy=(x2-x1)*.5,(y2-y1)*.5
        return {x1-dx,x2+dx,y1-dy,y2+dy}
    end
    if child==1458 and parent==1420 then return {.4789,.6912,.6402,.8527,reference=true} end
end
local function project(box,x,y)
    if box then return box[1]+(box[2]-box[1])*x,box[3]+(box[4]-box[3])*y end
end
local function mapInfo(id)
    local info=M:Call(C_Map and C_Map.GetMapInfo,id)
    return type(info)=="table" and info or nil
end
local function parentIs(zone,view)
    local info=mapInfo(zone)
    return info and M:Integer(info.parentMapID) and info.parentMapID==view
end
local function duplicate(stage,r)
    for _,other in ipairs(stage.rows) do
        if other.category==r.category and other.label==r.label and
            math.abs(other.x-r.x)<.006 and math.abs(other.y-r.y)<.006 then return true end
    end
end
local function isCity(id)
    return M:Integer(id) and (cityZones[id] or M:Call(C_Map and C_Map.IsCityMap,id)==true)
end
function P:MapLinks(stage,id)
    local links=M:Call(C_Map and C_Map.GetMapLinksForMap,id)
    local byPoi,byCity={},{}
    for _,r in ipairs(stage.rows) do
        if r.areaPoiID then byPoi[r.areaPoiID]=r end
        if isCity(r.linkedMapID) then r.category="city";byCity[r.linkedMapID]=true end
    end
    if type(links)=="table" then
        for i,link in ipairs(links) do
            if i>256 then break end
            if M:Readable(link) and type(link)=="table" and M:Integer(link.areaPoiID) and M:Integer(link.linkedUiMapID) then
                local poi,child=link.areaPoiID,link.linkedUiMapID
                local x,y=M.map:XY(link.position)
                local r=byPoi[poi] or catalog:Base("maplink:"..id..":"..poi,id,x,y,link.name,"poi","landmark")
                if r then
                    r.areaPoiID=poi;r.linkedMapID=child
                    if isCity(child) then r.category="city";byCity[child]=true end
                    catalog:Add(stage,r);byPoi[poi]=r
                end
            end
        end
    end
    return byCity
end
function P:Flights(stage,id)
    local api=C_TaxiMap
    if not api or M:Call(api.ShouldMapShowTaxiNodes,id)~=true then return end
    local nodes=M:Call(api.GetTaxiNodesForMap,id)
    if type(nodes)~="table" then return end
    local factions=Enum and Enum.FlightPathFaction
    for i,node in ipairs(nodes) do
        if i>256 then break end
        if M:Readable(node) and type(node)=="table" and M:Integer(node.nodeID) then
            local x,y=M.map:XY(node.position)
            local r=catalog:Base("mapflight:"..id..":"..node.nodeID,id,x,y,node.name,"flight","flight")
            if r then
                r.nodeID=node.nodeID;r.sourceLabel="Flight point on this map"
                if factions and M:Number(node.faction) then
                    if node.faction==factions.Horde then r.faction="Horde"
                    elseif node.faction==factions.Alliance then r.faction="Alliance" end
                end
                r.learned="UNKNOWN";catalog:Add(stage,r)
            end
        end
    end
end
local function cityName(name)
    if M:Text(name,160) then return name:lower():gsub("^the ",""):gsub(" city$","") end
end
local function qualifyCity(stage,city,info)
    local name=info and cityName(info.name)
    local best
    -- Forever also supplies ordinary AreaPOIs for capitals without a linked
    -- map ID. Match the client's localized names within the known parent.
    for _,r in ipairs(stage.rows) do
        if r.linkedMapID==city then best=r;break end
        if name and r.areaPoiID and not r.linkedMapID and cityName(r.label)==name then best=r end
    end
    if not best then return false end
    best.category="city";best.linkedMapID=city
    for i=#stage.rows,1,-1 do
        local r=stage.rows[i]
        if r~=best and r.areaPoiID and name and cityName(r.label)==name and
            (r.linkedMapID==nil or r.linkedMapID==city) and math.abs(r.x-best.x)<.008 and math.abs(r.y-best.y)<.008 then
            best.alternateAreaPoiID=r.areaPoiID;table.remove(stage.rows,i)
        end
    end
    return true
end
function P:Capitals(stage,id,byCity,continent)
    if not M:ReferenceFamily() then return end
    for city,zone in pairs(cityZones) do
        if zone==id or (continent and parentIs(zone,id)) then
            local inner=rect(city,zone)
            local direct=zone==id and inner or rect(city,id)
            local outer=continent and rect(zone,id)
            local function locate(x,y)
                if direct then return project(direct,x,y) end
                if inner and outer then
                    local zx,zy=project(inner,x,y)
                    return project(outer,zx,zy)
                end
            end
            local x,y=locate(.5,.5)
            local info=mapInfo(city)
            local supplied=qualifyCity(stage,city,info)
            if info and not supplied and not byCity[city] and M.map:Valid(id,x,y) then
                local r=catalog:Base("mapcity:"..id..":"..city,id,x,y,info.name,"poi","city","CAPITAL_MAP_REFERENCE")
                if r then
                    r.linkedMapID=city;r.precision="CITY_MAP_CENTER";r.sourceURL=citySource
                    r.sourceLabel="Capital map extent";r.confidence="MAP_RECT_PROJECTION";r.license="MIT"
                    if (direct or inner).reference then r.precision="HISTORICAL_CITY_RECT";r.confidence="CATALOG_CANDIDATE" end
                    catalog:Add(stage,r)
                end
            end
            -- City entrance locations also belong on the surrounding zone.
            if not continent then
                for _,seed in ipairs(M.ServiceReference[city] or {}) do
                    if seed.category=="entrance" then
                        local ex,ey=locate(seed.x,seed.y)
                        self:AddEntrance(stage,id,ex,ey,seed)
                    end
                end
            end
        end
    end
end
function P:AddEntrance(stage,id,x,y,seed)
    local r=catalog:Base(seed.id..":view:"..id,id,x,y,seed.label,"poi","entrance","FOREVER_SERVICE_REFERENCE")
    if r and not duplicate(stage,r) then
        r.sourceURL=citySource;r.sourceLabel="Projected entrance reference";r.license="MIT"
        r.confidence="CATALOG_CANDIDATE";r.precision="PROJECTED_REFERENCE";r.instanceID=seed.instanceID
        r.sourceQualification=seed.sourceQualification;r.details=seed.details
        catalog:Add(stage,r)
    end
end
function P:Overview(stage,id)
    if not stage.zones then
        stage.zones={}
        for child in pairs(M.ServiceReference or {}) do stage.zones[#stage.zones+1]=child end
        table.sort(stage.zones);stage.zoneCursor=1
    end
    for n=stage.zoneCursor,math.min(#stage.zones,stage.zoneCursor+3) do
        local child=stage.zones[n]
        if parentIs(child,id) then
            local box=rect(child,id)
            if box then
                for _,seed in ipairs(M.ServiceReference[child]) do
                    if seed.category=="entrance" then
                        local x,y=project(box,seed.x,seed.y)
                        self:AddEntrance(stage,id,x,y,seed)
                    end
                end
            end
        end
    end
    stage.zoneCursor=stage.zoneCursor+4
    return stage.zoneCursor<=#stage.zones
end
function P:Invalidate()
    self.dirty=true
end
function P:Refresh(id)
    if not M.state.clientAllowed or not M:Integer(id) or M:Combat() then return end
    local now=M:Now()
    if self.mapID==id and (self.token or (self.retryAt and now<self.retryAt) or
        (self.lastAt and now>=self.lastAt and now-self.lastAt<(self.dirty and 1 or 30))) then return end
    local records,tasks=M.Integration:Service("WorldRecords"),M.Integration:Service("Tasks")
    if not records or not tasks then return end
    if self.token then records.CancelSnapshot(self.owner,self.token);tasks.Cancel(self.owner) end
    self.serial=self.serial+1;self.mapID=id;self.dirty=false;self.retryAt=nil;self.lastAt=now
    local serial=self.serial
    local token,why=records.BeginSnapshot(self.owner,serial)
    self.token=token;self.status="LOADING"
    local function fail(reason)
        if serial~=self.serial then return end
        if token then records.CancelSnapshot(self.owner,token) end
        self.token=nil;self.status=reason;self.dirty=true;self.retryAt=M:Now()+1
    end
    if not token then fail(why);return end
    local info=mapInfo(id)
    local continent=info and M:Number(info.mapType) and info.mapType==(Enum and Enum.UIMapType and Enum.UIMapType.Continent or 2)
    local stage={rows={},seen={},omitted=0}
    local phase,cursor=1,1
    local function step()
        if serial~=self.serial then return false end
        if M:Combat() then fail("WAITING_FOR_COMBAT");return false end
        if phase==1 then
            if not catalog:NativePOIs(stage,id) then phase=2 end
        elseif phase==2 then
            self:Capitals(stage,id,self:MapLinks(stage,id),continent)
            self:Flights(stage,id)
            catalog:Seeds(stage,id);phase=3
        elseif phase==3 then
            if not catalog:ServiceReferences(stage,id) then phase=4 end
        elseif phase==4 and continent and M:ReferenceFamily() and self:Overview(stage,id) then
            return true
        else
            phase=5
            local batch={}
            for i=cursor,math.min(#stage.rows,cursor+31) do batch[#batch+1]=stage.rows[i] end
            if #batch>0 then
                local ok,reason=records.PutBatch(self.owner,token,batch)
                if not ok then fail(reason);return false end
                cursor=cursor+#batch
                if cursor<=#stage.rows then return true end
            end
            local ok,reason=records.CommitSnapshot(self.owner,token)
            if serial~=self.serial then return false end
            if not ok then fail(reason);return false end
            self.token=nil;self.publishedMap=id;self.count=#stage.rows;self.nativeCount=0
            for _,row in ipairs(stage.rows) do if row.source=="NATIVE_MAP_API" then self.nativeCount=self.nativeCount+1 end end
            self.status=self.count>0 and "READY" or "READY_EMPTY"
            return false
        end
        return true
    end
    local accepted,reason=tasks.Queue(self.owner,function()
        local ok,more=pcall(step)
        if not ok then fail("MAP_PLACE_READ_FAILED");return false end
        return more
    end,serial)
    if not accepted then fail(reason) end
end
