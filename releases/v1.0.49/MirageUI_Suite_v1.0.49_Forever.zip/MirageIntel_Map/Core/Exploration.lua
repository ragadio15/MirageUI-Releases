-- Read-only exploration planning. The client exposes explored areas only; the
-- bundled catalog supplies art identifiers, never exploration or achievement state.
local _,M=...
M.Exploration={epoch=0,status="NOT_REQUESTED",owner="MirageIntel_Map.exploration",maxAreas=48,maxTiles=96}
local E=M.Exploration
local function service(name)
    if not M.core or type(M.core.GetService)~="function" then return nil end
    local api,ok=M:Call(M.core.GetService,name,1)
    return ok and type(api)=="table" and api or nil
end
local function nonnegative(v) return M:Number(v) and v>=0 and v<=8192 and v==math.floor(v) end
local function areaKey(w,h,x,y)
    return tostring(w)..":"..tostring(h)..":"..tostring(x)..":"..tostring(y)
end
function E:Cancel(reason)
    local tasks=service("Tasks")
    if tasks and self.pendingKey then tasks.Cancel(self.owner) end
    self.pendingKey=nil
    if reason then self.status=reason end
end
function E:Invalidate(reason)
    self:Cancel(reason or "EXPLORATION_CHANGED")
    self.epoch=self.epoch+1;self.cache=nil;self.failedKey=nil;self.failedUntil=nil
    if M.ExplorationUI then M.ExplorationUI:Hide("EXPLORATION_CHANGED") end
    if M.Canvas then M.Canvas:Dirty() end
end
function E:Initialize()
    if self.eventFrame or type(CreateFrame)~="function" then return end
    local frame=CreateFrame("Frame");self.eventFrame=frame
    pcall(frame.RegisterEvent,frame,"MAP_EXPLORATION_UPDATED")
    pcall(frame.RegisterEvent,frame,"PLAYER_ENTERING_WORLD")
    frame:SetScript("OnEvent",function(_,event) E:Invalidate(event) end)
end
function E:Identity(mapID,layerIndex)
    local catalog=M.ExplorationData
    if not catalog or not M:Integer(mapID) then return nil,"MAP_ID_UNAVAILABLE" end
    local patch,ok,build,_,interface=M:Call(GetBuildInfo)
    if not ok or patch~=catalog.patch or interface~=catalog.interface or
        (type(build)~="number" and type(build)~="string") or not M:Integer(tonumber(build)) then
        return nil,"EXPLORATION_BUILD_NOT_CATALOGUED"
    end
    -- Patch and interface establish the API family. The map, floor, art and
    -- tile geometry establish identity even when Forever increments its build.
    local historical=tostring(build)~=catalog.build
    local profile=catalog.maps[mapID]
    if not profile then return nil,"EXPLORATION_MAP_OUTSIDE_PILOT" end
    if layerIndex~=catalog.layer then return nil,"EXPLORATION_LAYER_NOT_CATALOGUED" end
    if type(C_Map)~="table" then return nil,"MAP_ART_API_UNAVAILABLE" end
    local art,have=M:Call(C_Map.GetMapArtID,mapID)
    if not have or not M:Integer(art) then return nil,"MAP_ART_UNREADABLE" end
    if art~=profile.artID then return nil,"EXPLORATION_ART_MISMATCH" end
    local layers,read=M:Call(C_Map.GetMapArtLayers,mapID)
    if not read or not M:Readable(layers) or type(layers)~="table" then return nil,"MAP_LAYERS_UNREADABLE" end
    local layer=layers[layerIndex]
    if not M:Readable(layer) or type(layer)~="table" then return nil,"MAP_LAYER_UNAVAILABLE" end
    local w,h,tw,th=layer.layerWidth,layer.layerHeight,layer.tileWidth,layer.tileHeight
    if not M:Integer(w) or not M:Integer(h) or w>8192 or h>8192 or
        not M:Readable(tw) or not M:Readable(th) or tw~=catalog.tileWidth or th~=catalog.tileHeight or
        w<profile.maxX or h<profile.maxY then return nil,"EXPLORATION_GEOMETRY_MISMATCH" end
    -- uiMapID is the floor identity here. Only these outdoor zone identities
    -- are catalogued; no parent-map substitution is made for a dungeon floor.
    local id={mapID=mapID,artID=art,layer=layerIndex,width=w,height=h,tileWidth=tw,tileHeight=th,
        profile=profile,build=tostring(build),source=catalog.source,sourceVersion=catalog.sourceVersion,
        catalogBuild=catalog.build,historicalCatalog=historical}
    id.key=table.concat({build,mapID,art,layerIndex,w,h,tw,th,self.epoch},":")
    return id,"CATALOG_IDENTITY_MATCHED"
end
local function powerOfTwo(n)
    local value=16
    while value<n do value=value*2 end
    return value
end
function E:AppendArea(plan,area)
    local w,h,x,y=area[1],area[2],area[3],area[4]
    if not M:Integer(w) or not M:Integer(h) or w>4096 or h>4096 or not nonnegative(x) or not nonnegative(y) then
        return false,"INVALID_CATALOG_RECTANGLE"
    end
    local cols,rows=math.ceil(w/plan.tileWidth),math.ceil(h/plan.tileHeight)
    if #area~=4+cols*rows or cols*rows>64 or #plan.tiles+cols*rows>self.maxTiles then
        return false,"CATALOG_TILE_COUNT_INVALID"
    end
    local first=#plan.tiles+1
    for row=1,rows do
        local ph=math.min(plan.tileHeight,h-(row-1)*plan.tileHeight)
        local fh=row==rows and powerOfTwo(ph) or plan.tileHeight
        for col=1,cols do
            local pw=math.min(plan.tileWidth,w-(col-1)*plan.tileWidth)
            local fw=col==cols and powerOfTwo(pw) or plan.tileWidth
            local fileID=area[4+(row-1)*cols+col]
            if not M:Integer(fileID) then return false,"INVALID_CATALOG_ASSET" end
            plan.tiles[#plan.tiles+1]={fileID=fileID,
                left=(x+(col-1)*plan.tileWidth)/plan.width,top=(y+(row-1)*plan.tileHeight)/plan.height,
                width=pw/plan.width,height=ph/plan.height,u0=0,u1=pw/fw,v0=0,v1=ph/fh}
        end
    end
    plan.areas[#plan.areas+1]={left=x/plan.width,top=y/plan.height,width=w/plan.width,height=h/plan.height,
        firstTile=first,lastTile=#plan.tiles}
    return true
end
function E:Request(mapID,layerIndex)
    local identity,reason=self:Identity(mapID,layerIndex)
    if not identity then self:Cancel(reason);self.cache=nil;return nil,reason end
    if self.cache and self.cache.key==identity.key then return self.cache,self.status end
    if self.pendingKey==identity.key then return nil,"EXPLORATION_SCAN_PENDING" end
    if self.failedKey==identity.key and self.failedUntil and M:Now()<self.failedUntil then return nil,self.status end
    self:Cancel();self.cache=nil;self.status="EXPLORATION_SCAN_PENDING"
    local tasks=service("Tasks")
    if not tasks or type(tasks.Queue)~="function" then self.status="EXPLORATION_TASKS_UNAVAILABLE";return nil,self.status end
    if type(C_MapExplorationInfo)~="table" or type(C_MapExplorationInfo.GetExploredMapTextures)~="function" then
        self.status="EXPLORATION_API_UNAVAILABLE";return nil,self.status
    end
    local list,ok=M:Call(C_MapExplorationInfo.GetExploredMapTextures,mapID)
    -- MayReturnNothing is part of the exact native API. A successful nil is
    -- an empty explored set; a failed/unreadable response is not.
    if not ok or (list~=nil and (not M:Readable(list) or type(list)~="table")) then
        self.status="EXPLORATION_STATE_UNREADABLE";return nil,self.status
    end
    list=list or {}
    if #list>512 then self.status="EXPLORATION_STATE_LIMIT";return nil,self.status end
    if #identity.profile.areas>self.maxAreas then self.status="EXPLORATION_CATALOG_LIMIT";return nil,self.status end
    local key=identity.key;self.pendingKey=key
    local explored,cursor,areaCursor={},1,1
    local plan={key=key,mapID=mapID,artID=identity.artID,layer=layerIndex,width=identity.width,height=identity.height,
        tileWidth=identity.tileWidth,tileHeight=identity.tileHeight,tiles={},areas={},exploredCount=0,
        source=identity.source,sourceVersion=identity.sourceVersion,build=identity.build,epoch=self.epoch,
        catalogBuild=identity.catalogBuild,historicalCatalog=identity.historicalCatalog}
    local catalogAreas={}
    for _,area in ipairs(identity.profile.areas) do catalogAreas[areaKey(area[1],area[2],area[3],area[4])]=area end
    local function fail(why)
        E.pendingKey=nil;E.status=why;E.cache=nil;E.failedKey=key;E.failedUntil=M:Now()+2
        if M.Canvas then M.Canvas:Dirty() end
        return false
    end
    local queued,why=tasks.Queue(self.owner,function()
        if E.pendingKey~=key then return false end
        if M:Combat() or (M.MapQuery and not M.MapQuery:Shown()) then return fail("EXPLORATION_PAUSED") end
        -- Every slice is bounded; character exploration is never written.
        if cursor<=#list then
            for _=1,16 do
                local info=list[cursor]
                if cursor>#list then break end
                if info==nil then return fail("EXPLORATION_STATE_UNREADABLE") end
                if not M:Readable(info) or type(info)~="table" then return fail("EXPLORATION_STATE_UNREADABLE") end
                local w,h,x,y=info.textureWidth,info.textureHeight,info.offsetX,info.offsetY
                if not M:Integer(w) or not M:Integer(h) or w>8192 or h>8192 or not nonnegative(x) or not nonnegative(y) or
                    not M:Readable(info.isShownByMouseOver) then return fail("EXPLORATION_STATE_UNREADABLE") end
                if not M:Readable(info.isDrawOnTopLayer) or type(info.isDrawOnTopLayer)~="boolean" or
                    type(info.isShownByMouseOver)~="boolean" then return fail("EXPLORATION_STATE_UNREADABLE") end
                -- A hover does not establish discovery. A top-layer decoration
                -- can share a terrain rectangle; match its actual tiles first.
                if not info.isShownByMouseOver then
                    local rect=areaKey(w,h,x,y)
                    local area=catalogAreas[rect]
                    if area then
                        local files=info.fileDataIDs
                        if not M:Readable(files) or type(files)~="table" then return fail("EXPLORATION_STATE_UNREADABLE") end
                        local matches=#files==#area-4
                        if matches then
                            for i=1,#files do
                                if not M:Integer(files[i]) then return fail("EXPLORATION_STATE_UNREADABLE") end
                                if files[i]~=area[i+4] then matches=false;break end
                            end
                        end
                        if matches then explored[rect]=true
                        elseif not info.isDrawOnTopLayer then return fail("NATIVE_OVERLAY_ASSET_MISMATCH") end
                    elseif identity.historicalCatalog and not info.isDrawOnTopLayer then
                        return fail("HISTORICAL_ART_NATIVE_OVERLAY_MISMATCH")
                    end
                end
                cursor=cursor+1
            end
            return true
        end
        for _=1,4 do
            local area=identity.profile.areas[areaCursor]
            if not area then break end
            if explored[areaKey(area[1],area[2],area[3],area[4])] then plan.exploredCount=plan.exploredCount+1
            else
                local added,error=E:AppendArea(plan,area)
                if not added then return fail(error) end
            end
            areaCursor=areaCursor+1
        end
        if areaCursor<=#identity.profile.areas then return true end
        E.pendingKey=nil;E.cache=plan
        E.status=#plan.tiles==0 and "PILOT_MAP_FULLY_EXPLORED" or "UNEXPLORED_ART_READY"
        if M.Canvas then M.Canvas:Dirty() end
        return false
    end,key)
    if not queued then self.pendingKey=nil;self.status=why or "EXPLORATION_QUEUE_REJECTED" end
    return nil,self.status
end
function E:GetStatus()
    local plan=self.cache
    local catalog=M.ExplorationData
    return {status=self.status,pending=self.pendingKey~=nil,revision=self.epoch,
        mapID=plan and plan.mapID,artID=plan and plan.artID,layer=plan and plan.layer,
        unexploredAreas=plan and #plan.areas or 0,tiles=plan and #plan.tiles or 0,
        -- Keep the original pilot count and status vocabulary for existing
        -- report consumers. P8 coverage is additive and explicitly scoped.
        exploredAreas=plan and plan.exploredCount or 0,pilotMaps=catalog.pilotMapCount or 8,
        mappedCount=catalog.mapCount or 8,catalogMaps=catalog.mapCount or 8,
        addedMaps=catalog.addedMapCount or 0,catalogRevision=catalog.revision or "P3_PILOT",
        scope=catalog.scope or "OUTDOOR_ZONES",
        catalogBuild=catalog.build,source=M.ExplorationData.source,sourceVersion=M.ExplorationData.sourceVersion,
        clientBuild=plan and plan.build,historicalCatalog=plan and plan.historicalCatalog or false,
        qualification=not plan and "NOT_QUALIFIED" or plan.historicalCatalog and "HISTORICAL_ART_NATIVE_IDENTITY_GUARDED" or "CATALOGUED_BUILD",
        nativeAcceptance="NOT_RUN",input="PASSIVE",explorationMutation="NONE"}
end
