-- P8 reference-only resource details. No coordinates, live spawns or eligibility.
-- Adapted from ForeverPlusPlus Data/Professions.lua, MIT, Cameron Weaver (2026).
-- See ThirdParty/FPP-LICENSE.txt. Classic values remain unverified on Forever.
-- Source commit 0ae2c5006b28a640c3a3c17914d3d4543717ce5d.
local _,M=...
M.ResourceReference={
    source="ForeverPlusPlus profession reference",
    sourceVersion="0ae2c5006b28a640c3a3c17914d3d4543717ce5d",
    sourceURL="https://github.com/xIGBClutchIx/ForeverPlusPlus/blob/0ae2c5006b28a640c3a3c17914d3d4543717ce5d/ForeverPlusPlus/Data/Professions.lua",
    qualification="CLASSIC_REFERENCE_UNVERIFIED_FOREVER",license="MIT",
    items={
        [765]={skillLineID=182,category="herb",minSkill=1,maxSkill=1,variants={
            {name="Silverleaf",skill=1},
        }},
        [785]={skillLineID=182,category="herb",minSkill=50,maxSkill=50,variants={
            {name="Mageroyal",skill=50},
        }},
        [2447]={skillLineID=182,category="herb",minSkill=1,maxSkill=1,variants={
            {name="Peacebloom",skill=1},
        }},
        [2449]={skillLineID=182,category="herb",minSkill=15,maxSkill=15,variants={
            {name="Earthroot",skill=15},
        }},
        [2450]={skillLineID=182,category="herb",minSkill=70,maxSkill=70,variants={
            {name="Briarthorn",skill=70},
        }},
        [2453]={skillLineID=182,category="herb",minSkill=100,maxSkill=100,variants={
            {name="Bruiseweed",skill=100},
        }},
        [2770]={skillLineID=186,category="ore",minSkill=1,maxSkill=1,variants={
            {name="Copper Vein",skill=1},
        }},
        [2771]={skillLineID=186,category="ore",minSkill=65,maxSkill=65,variants={
            {name="Tin Vein",skill=65},
        }},
        [2772]={skillLineID=186,category="ore",minSkill=125,maxSkill=125,variants={
            {name="Iron Deposit",skill=125},
            {name="Ooze Covered Iron Deposit",skill=125},
        }},
        [2775]={skillLineID=186,category="ore",minSkill=75,maxSkill=75,variants={
            {name="Ooze Covered Silver Vein",skill=75,sharedBaseName="Tin Vein"},
            {name="Silver Vein",skill=75,sharedBaseName="Tin Vein"},
        }},
        [2776]={skillLineID=186,category="ore",minSkill=155,maxSkill=155,variants={
            {name="Gold Vein",skill=155,sharedBaseName="Iron Deposit"},
            {name="Ooze Covered Gold Vein",skill=155,sharedBaseName="Iron Deposit"},
        }},
        [2835]={skillLineID=186,category="stone",minSkill=1,maxSkill=1,variants={
        }},
        [2836]={skillLineID=186,category="stone",minSkill=65,maxSkill=65,variants={
        }},
        [2838]={skillLineID=186,category="stone",minSkill=125,maxSkill=125,variants={
        }},
        [3340]={skillLineID=186,category="ore",minSkill=65,maxSkill=65,variants={
            {name="Incendicite Mineral Vein",skill=65},
        }},
        [3355]={skillLineID=182,category="herb",minSkill=115,maxSkill=115,variants={
            {name="Wild Steelbloom",skill=115},
        }},
        [3356]={skillLineID=182,category="herb",minSkill=125,maxSkill=125,variants={
            {name="Kingsblood",skill=125},
        }},
        [3357]={skillLineID=182,category="herb",minSkill=150,maxSkill=150,variants={
            {name="Liferoot",skill=150},
        }},
        [3358]={skillLineID=182,category="herb",minSkill=185,maxSkill=185,variants={
            {name="Khadgar's Whisker",skill=185},
        }},
        [3369]={skillLineID=182,category="herb",minSkill=120,maxSkill=120,variants={
            {name="Grave Moss",skill=120},
        }},
        [3818]={skillLineID=182,category="herb",minSkill=160,maxSkill=160,variants={
            {name="Fadeleaf",skill=160},
        }},
        [3819]={skillLineID=182,category="herb",minSkill=195,maxSkill=195,variants={
            {name="Wintersbite",skill=195},
        }},
        [3820]={skillLineID=182,category="herb",minSkill=85,maxSkill=85,variants={
            {name="Stranglekelp",skill=85},
        }},
        [3821]={skillLineID=182,category="herb",minSkill=170,maxSkill=170,variants={
            {name="Goldthorn",skill=170},
        }},
        [3858]={skillLineID=186,category="ore",minSkill=175,maxSkill=175,variants={
            {name="Mithril Deposit",skill=175},
            {name="Ooze Covered Mithril Deposit",skill=175},
        }},
        [4278]={skillLineID=186,category="ore",minSkill=75,maxSkill=75,variants={
            {name="Lesser Bloodstone Deposit",skill=75},
        }},
        [4625]={skillLineID=182,category="herb",minSkill=205,maxSkill=205,variants={
            {name="Firebloom",skill=205},
        }},
        [5833]={skillLineID=186,category="ore",minSkill=150,maxSkill=150,variants={
            {name="Indurium Mineral Vein",skill=150},
        }},
        [7911]={skillLineID=186,category="ore",minSkill=230,maxSkill=230,variants={
            {name="Ooze Covered Truesilver Deposit",skill=230,sharedBaseName="Mithril Deposit"},
            {name="Truesilver Deposit",skill=230,sharedBaseName="Mithril Deposit"},
        }},
        [7912]={skillLineID=186,category="stone",minSkill=175,maxSkill=175,variants={
        }},
        [8831]={skillLineID=182,category="herb",minSkill=210,maxSkill=210,variants={
            {name="Purple Lotus",skill=210},
        }},
        [8836]={skillLineID=182,category="herb",minSkill=220,maxSkill=220,variants={
            {name="Arthas' Tears",skill=220},
        }},
        [8838]={skillLineID=182,category="herb",minSkill=230,maxSkill=230,variants={
            {name="Sungrass",skill=230},
        }},
        [8839]={skillLineID=182,category="herb",minSkill=235,maxSkill=235,variants={
            {name="Blindweed",skill=235},
        }},
        [8845]={skillLineID=182,category="herb",minSkill=245,maxSkill=245,variants={
            {name="Ghost Mushroom",skill=245},
        }},
        [8846]={skillLineID=182,category="herb",minSkill=250,maxSkill=250,variants={
            {name="Gromsblood",skill=250},
        }},
        [10620]={skillLineID=186,category="ore",minSkill=245,maxSkill=275,variants={
            {name="Ooze Covered Thorium Vein",skill=245},
            {name="Small Thorium Vein",skill=245},
            {name="Hakkari Thorium Vein",skill=275},
            {name="Ooze Covered Rich Thorium Vein",skill=275},
            {name="Rich Thorium Vein",skill=275},
        }},
        [11370]={skillLineID=186,category="ore",minSkill=230,maxSkill=230,variants={
            {name="Dark Iron Deposit",skill=230},
        }},
        [12365]={skillLineID=186,category="stone",minSkill=245,maxSkill=245,variants={
        }},
        [13463]={skillLineID=182,category="herb",minSkill=270,maxSkill=270,variants={
            {name="Dreamfoil",skill=270},
        }},
        [13464]={skillLineID=182,category="herb",minSkill=260,maxSkill=260,variants={
            {name="Golden Sansam",skill=260},
        }},
        [13465]={skillLineID=182,category="herb",minSkill=280,maxSkill=280,variants={
            {name="Mountain Silversage",skill=280},
        }},
        [13466]={skillLineID=182,category="herb",minSkill=285,maxSkill=285,variants={
            {name="Plaguebloom",skill=285},
        }},
        [13467]={skillLineID=182,category="herb",minSkill=290,maxSkill=290,variants={
            {name="Icecap",skill=290},
        }},
        [13468]={skillLineID=182,category="herb",minSkill=300,maxSkill=300,variants={
            {name="Black Lotus",skill=300},
        }},
        [22202]={skillLineID=186,category="ore",minSkill=305,maxSkill=305,variants={
            {name="Small Obsidian Chunk",skill=305},
        }},
        [22203]={skillLineID=186,category="ore",minSkill=305,maxSkill=305,variants={
            {name="Large Obsidian Chunk",skill=305},
        }},
    },
    fishingPools={
        "Firefin Snapper School",
        "Floating Debris",
        "Floating Wreckage",
        "Greater Sagefish School",
        "Oil Spill",
        "Oily Blackmouth School",
        "Patch of Elemental Water",
        "Sagefish School",
        "School of Deviate Fish",
        "Schooner Wreckage",
        "Stonescale Eel Swarm",
        "Waterlogged Wreckage",
    },
    professionTools={
        [2901]=186,
        [5956]=164,
        [6219]=202,
        [7005]=393,
    },
}
