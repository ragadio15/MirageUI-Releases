-- Passive map art below native explored overlays and all interactive pins.
-- Native masks and explicit normalized clipping keep zoom/pan edges contained.
local _,M=...
M.ExplorationUI={textures={},lines={},status="NOT_ATTACHED",owner="MirageIntel_Map.explorationArt",generation=0}
local U=M.ExplorationUI
local function method(object,name)
    if not M:Readable(object) or (type(object)~="table" and type(object)~="userdata") then return nil end
    local ok,fn=pcall(function() return object[name] end)
    return ok and type(fn)=="function" and fn or nil
end
local function tasks()
    if not M.core or type(M.core.GetService)~="function" then return nil end
    local api,ok=M:Call(M.core.GetService,"Tasks",1)
    return ok and type(api)=="table" and api or nil
end
local function bounded(v,low,high) return M:Number(v) and v>=low and v<=high end
function U:Cancel()
    local api=tasks()
    if api and self.pendingKey then api.Cancel(self.owner) end
    self.pendingKey=nil;self.generation=self.generation+1
end
function U:Release()
    for _,texture in ipairs(self.textures) do texture:Hide() end
    for _,texture in ipairs(self.lines) do texture:Hide() end
    self.visibleTiles=0;self.visibleOutlines=0
    if self.frame then self.frame:Hide() end
end
function U:Hide(reason)
    self:Cancel();self:Release();self.renderedKey=nil;self.failedKey=nil
    if M.Exploration and M.Exploration.pendingKey then M.Exploration:Cancel(reason or "EXPLORATION_HIDDEN") end
    self.status=reason or "HIDDEN"
end
function U:Attach(canvas)
    if M:Combat() then self:Hide("COMBAT");return false,"COMBAT" end
    local map=M.MapQuery and M.MapQuery:Frame()
    if not map or not canvas then self:Hide("CANVAS_UNAVAILABLE");return false,self.status end
    if self.map and self.map~=map then
        -- Native masks retain their registered textures. Avoid sharing a pool
        -- between two map owners with independent masks; reloading is safe.
        self:Hide("MAP_OWNER_CHANGED_RELOAD_REQUIRED");return false,self.status
    end
    if type(map.AddMaskableTexture)~="function" then
        self:Hide("MAP_MASK_API_UNAVAILABLE");return false,self.status
    end
    local manager,got=M:Call(map.GetPinFrameLevelsManager,map)
    local level,read=M:Call(got and method(manager,"GetValidFrameLevel"),manager,"PIN_FRAME_LEVEL_MAP_EXPLORATION")
    local default,known=M:Call(got and method(manager,"GetValidFrameLevel"),manager,"PIN_FRAME_LEVEL_DEFAULT")
    -- The native getter falls back to DEFAULT for an unregistered name. A
    -- successful call alone does not establish that exploration is installed.
    if not read or not known or not M:Integer(level) or not M:Integer(default) or level<2 or level==default then
        self:Hide("NATIVE_EXPLORATION_LAYER_UNAVAILABLE");return false,self.status
    end
    if not self.frame then
        local ok,frame=pcall(function()
            local owned=CreateFrame("Frame",nil,canvas)
            owned:EnableMouse(false)
            if type(owned.EnableMouseWheel)=="function" then owned:EnableMouseWheel(false) end
            owned:Hide()
            return owned
        end)
        if not ok or not frame then self.status="EXPLORATION_FRAME_CREATE_FAILED";return false,self.status end
        self.frame=frame
    elseif self.canvas~=canvas then
        self:Hide("CANVAS_CHANGED");self.frame:SetParent(canvas)
    end
    self.frame:ClearAllPoints();self.frame:SetAllPoints(canvas)
    self.frame:SetFrameLevel(level-1)
    self.map,self.canvas=map,canvas
    return true
end
function U:Layer()
    local map=self.map
    local container,ok=M:Call(map and map.GetCanvasContainer,map)
    if not ok or not container then return nil end
    local layer,read=M:Call(method(container,"GetCurrentLayerIndex"),container)
    return read and M:Integer(layer) and layer or nil
end
function U:Bounds()
    local view=M.MapQuery and M.MapQuery:Viewport()
    if type(view)~="table" or not bounded(view.left,0,1) or not bounded(view.right,0,1) or
        not bounded(view.top,0,1) or not bounded(view.bottom,0,1) or
        view.right<=view.left or view.bottom<=view.top then
        return {left=0,right=1,top=0,bottom=1,scale=1,status="NATIVE_MASK_ONLY"}
    end
    return {left=view.left,right=view.right,top=view.top,bottom=view.bottom,
        scale=bounded(view.scale,.01,100) and view.scale or 1,status=view.status}
end
-- UV cropping uses the actual partial-tile file size, including the padded
-- power-of-two files at the right/bottom edge. It never stretches their padding.
function U:ClipTile(tile,view)
    if not tile or not M:Number(tile.width) or not M:Number(tile.height) or tile.width<=0 or tile.height<=0 then return nil end
    local left=math.max(0,view.left,tile.left)
    local top=math.max(0,view.top,tile.top)
    local right=math.min(1,view.right,tile.left+tile.width)
    local bottom=math.min(1,view.bottom,tile.top+tile.height)
    if right<=left or bottom<=top then return nil end
    local du,dv=tile.u1-tile.u0,tile.v1-tile.v0
    local function uv(value,low,high) return math.max(low,math.min(high,value)) end
    return {left=left,top=top,width=right-left,height=bottom-top,
        u0=uv(tile.u0+(left-tile.left)/tile.width*du,tile.u0,tile.u1),
        u1=uv(tile.u0+(right-tile.left)/tile.width*du,tile.u0,tile.u1),
        v0=uv(tile.v0+(top-tile.top)/tile.height*dv,tile.v0,tile.v1),
        v1=uv(tile.v0+(bottom-tile.top)/tile.height*dv,tile.v0,tile.v1),
        fileID=tile.fileID}
end
function U:Texture(index,line)
    local pool=line and self.lines or self.textures
    local cap=line and 192 or 96
    if index>cap then return nil,"EXPLORATION_POOL_LIMIT" end
    local texture=pool[index]
    if not texture then
        texture=self.frame:CreateTexture(nil,line and "OVERLAY" or "ARTWORK")
        if not texture then return nil,"TEXTURE_CREATION_FAILED" end
        local _,ok=M:Call(self.map.AddMaskableTexture,self.map,texture)
        if not ok then texture:Hide();return nil,"MAP_MASK_REGISTRATION_FAILED" end
        pool[index]=texture
    end
    return texture
end
function U:DrawTile(tile,view,w,h,index)
    local clipped=self:ClipTile(tile,view)
    if not clipped then return true,false end
    local texture,why=self:Texture(index,false)
    if not texture then return false,why end
    local loaded,ok=M:Call(texture.SetTexture,texture,tile.fileID,nil,nil,"TRILINEAR")
    if not ok or loaded==false then texture:Hide();return false,"CATALOG_ASSET_REJECTED" end
    texture:ClearAllPoints()
    texture:SetPoint("TOPLEFT",self.frame,"TOPLEFT",clipped.left*w,-clipped.top*h)
    texture:SetSize(clipped.width*w,clipped.height*h)
    texture:SetTexCoord(clipped.u0,clipped.u1,clipped.v0,clipped.v1)
    if type(texture.SetDesaturated)=="function" then pcall(texture.SetDesaturated,texture,true) end
    texture:SetVertexColor(.64,.67,.70,.94)
    texture:Show()
    return true,true
end
function U:DrawOutline(area,view,w,h,index)
    -- P10: zone patch rectangles are implementation geometry, not map features.
    -- Terrain remains shaded, without drawing its source tile/area boundaries.
    if not (M.Storage.account and M.Storage.account.settings.showTerrainEdges==true) then return index end
    local l,t,r,b=area.left,area.top,area.left+area.width,area.top+area.height
    local left,right=math.max(0,view.left,l),math.min(1,view.right,r)
    local top,bottom=math.max(0,view.top,t),math.min(1,view.bottom,b)
    if right<=left or bottom<=top then return index end
    local specs={}
    -- Do not invent an outline along the viewport's clipping edge.
    if t>=view.top and t>=0 and t<=view.bottom and t<=1 then specs[#specs+1]={left*w,-t*h,(right-left)*w,1} end
    if b>=view.top and b>=0 and b<=view.bottom and b<=1 then specs[#specs+1]={left*w,-b*h,(right-left)*w,1} end
    if l>=view.left and l>=0 and l<=view.right and l<=1 then specs[#specs+1]={l*w,-top*h,1,(bottom-top)*h} end
    if r>=view.left and r>=0 and r<=view.right and r<=1 then specs[#specs+1]={r*w,-top*h,1,(bottom-top)*h} end
    for _,spec in ipairs(specs) do
        local texture,why=self:Texture(index+1,true)
        if not texture then return nil,why end
        local loaded,ok=M:Call(texture.SetTexture,texture,"Interface\\Buttons\\WHITE8x8")
        if not ok or loaded==false then return nil,"OUTLINE_TEXTURE_UNAVAILABLE" end
        texture:ClearAllPoints();texture:SetPoint("TOPLEFT",self.frame,"TOPLEFT",spec[1],spec[2])
        texture:SetSize(spec[3],spec[4]);texture:SetVertexColor(.80,.70,.48,.18);texture:Show()
        index=index+1
    end
    return index
end
function U:Refresh(mapID)
    local settings=M.Storage.account and M.Storage.account.settings
    if not settings or settings.showUnexplored==false then self:Hide("LAYER_DISABLED");return end
    if M:Combat() or not M.MapQuery:Shown() then self:Hide("HIDDEN");return end
    local expectedCanvas=M.Canvas and M.Canvas.canvas
    if not self.frame or not self.canvas or (expectedCanvas and self.canvas~=expectedCanvas) or self.map~=M.MapQuery:Frame() then
        if not expectedCanvas or not self:Attach(expectedCanvas) then return end
    end
    local layer=self:Layer()
    local plan,why=M.Exploration:Request(mapID,layer)
    if not plan then
        if self.pendingKey or self.renderedKey or self.failedKey then
            self:Cancel();self:Release();self.renderedKey=nil;self.failedKey=nil
        end
        self.status=why;return
    end
    local w,ow=M:Call(self.canvas.GetWidth,self.canvas)
    local h,oh=M:Call(self.canvas.GetHeight,self.canvas)
    if not ow or not oh or not bounded(w,10,32768) or not bounded(h,10,32768) then self:Hide("CANVAS_SIZE_UNAVAILABLE");return end
    local scroll=self.map.ScrollContainer
    local clips=M:Call(method(scroll,"DoesClipChildren"),scroll)
    local view=clips==true and {left=0,right=1,top=0,bottom=1} or self:Bounds()
    local alpha,ao=M:Call(self.map.GetGlobalAlpha,self.map)
    self.frame:SetAlpha(ao and bounded(alpha,0,1) and alpha or 1)
    local key=table.concat({plan.key,w,h,view.left,view.right,view.top,view.bottom,settings.showTerrainEdges==true and 1 or 0},":")
    if self.pendingKey==key or self.renderedKey==key or self.failedKey==key then return end
    self:Cancel();self:Release();self.renderedKey=nil
    if #plan.tiles==0 then self.status="PILOT_MAP_FULLY_EXPLORED";self.renderedKey=key;return end
    local api=tasks()
    if not api then self.status="EXPLORATION_TASKS_UNAVAILABLE";return end
    self.pendingKey=key;self.status="UNEXPLORED_ART_RENDER_PENDING"
    local generation=self.generation
    local tileCursor,areaCursor,visible,lineCount=1,1,0,0
    local function fail(reason)
        U.pendingKey=nil
        if reason~="EXPLORATION_RENDER_CANCELLED" then U.failedKey=key end
        U.status=reason;U:Release();return false
    end
    local queued,reason=api.Queue(self.owner,function()
        if U.pendingKey~=key or U.generation~=generation then return false end
        if M:Combat() or not M.MapQuery:Shown() or M.MapQuery:CurrentMap()~=mapID or U:Layer()~=layer or
            not M.Exploration.cache or M.Exploration.cache.key~=plan.key then return fail("EXPLORATION_RENDER_CANCELLED") end
        local art,read=M:Call(C_Map and C_Map.GetMapArtID,mapID)
        if not read or art~=plan.artID then return fail("EXPLORATION_ART_CHANGED") end
        if tileCursor<=#plan.tiles then
            for _=1,4 do
                local tile=plan.tiles[tileCursor]
                if not tile then break end
                local wrote,ok,drawn=pcall(U.DrawTile,U,tile,view,w,h,visible+1)
                if not wrote then return fail("EXPLORATION_TEXTURE_WRITE_FAILED") end
                if not ok then return fail(drawn) end
                if drawn then visible=visible+1 end
                tileCursor=tileCursor+1
            end
            return true
        end
        for _=1,2 do
            local area=plan.areas[areaCursor]
            if not area then break end
            local wrote,count,error=pcall(U.DrawOutline,U,area,view,w,h,lineCount)
            if not wrote then return fail("EXPLORATION_OUTLINE_WRITE_FAILED") end
            if not count then return fail(error) end
            lineCount=count;areaCursor=areaCursor+1
        end
        if areaCursor<=#plan.areas then return true end
        U.pendingKey=nil;U.renderedKey=key;U.visibleTiles=visible;U.visibleOutlines=lineCount
        U.status=visible>0 and "UNEXPLORED_ART_VISIBLE" or "UNEXPLORED_ART_OUTSIDE_VIEWPORT"
        if visible>0 then U.frame:Show() end
        if M.Canvas then M.Canvas:Dirty() end
        return false
    end,key)
    if not queued then self.pendingKey=nil;self.status=reason or "EXPLORATION_QUEUE_REJECTED" end
end
function U:Legend()
    if self.status=="UNEXPLORED_ART_VISIBLE" then
        local plan=M.Exploration and M.Exploration.cache
        return "Shaded areas are unexplored",self.status
    end
    if self.status=="PILOT_MAP_FULLY_EXPLORED" then return "Map art explored",self.status end
    if self.status=="EXPLORATION_MAP_OUTSIDE_PILOT" then return "",self.status end
    if self.status=="EXPLORATION_SCAN_PENDING" or self.status=="UNEXPLORED_ART_RENDER_PENDING" then return "Loading map details…",self.status end
    if self.status=="LAYER_DISABLED" or self.status=="HIDDEN" then return nil,self.status end
    return "",self.status
end
function U:GetStatus()
    return {status=self.status,visibleTiles=self.visibleTiles or 0,outlineSegments=self.visibleOutlines or 0,
        pooledTiles=#self.textures,pooledOutlineSegments=#self.lines,pending=self.pendingKey~=nil,
        input="NONE",nativeAcceptance="NOT_RUN"}
end
