local _,M=...
-- The explorer owns presentation/session state only. Coordinates, availability
-- and navigation authority continue to come from the existing providers.
M.Explorer={}
local E=M.Explorer
local media="Interface\\AddOns\\MirageIntel_Core\\Media\\"
local filterKeys={"filterFaction","filterClass","filterProfession","placeLayer","resourceCategory","availability"}
local choiceSets={
    placeLayer={{"all","All places"},{"notes","Personal notes"},{"quests","Quests"},{"services","Services / travel"},{"resources","Gathering / fishing"},{"pois","Points of interest"},{"routes","Destinations / stops"}},
    availability={{"all","All places"},{"usable","Ready to visit"},{"unknown","Other places"}},
    resourceCategory={{"all","All resources"},{"herb","Herbs"},{"ore","Ore"},{"fish","Fishing"},{"pool","Fishing pools"},{"skin","Skinning"},{"treasure","Treasure"}},
    sort={{"relevance","Availability first"},{"name","Name A–Z"},{"category","Category"},{"nearest","Nearest (straight line)"}},
}
local layerLabels={notes="Note",quests="Quest",services="Service",resources="Resource",pois="Place",routes="Destination"}
local badgeKeys={notes="map",quests="navigate",services="map",resources="gather",pois="map",routes="navigate"}
local statusLabels={AVAILABLE="Available now",ACCEPTED="Accepted quest",KNOWN="Known location",UNKNOWN="",UNAVAILABLE=""}
local sortLabels={relevance="availability",name="name",category="category",nearest="nearest"}
local function ready()
    return M.state.clientAllowed and not M.Storage.readOnly and type(M.Storage.account)=="table" and not M:Combat()
end
local function same(a,b)
    if type(a)~="table" or type(b)~="table" then return false end
    for _,key in ipairs(filterKeys) do if a[key]~=b[key] then return false end end
    return true
end
local function filters()
    local result={};local cfg=M.Storage.account.settings
    for _,key in ipairs(filterKeys) do result[key]=cfg[key] end
    return result
end
local function choiceName(key,value)
    for _,row in ipairs(choiceSets[key] or {}) do if row[1]==value then return row[2] end end
    return tostring(value or "all")
end
local function plain(text)
    return type(text)=="string" and text:gsub("_"," "):lower() or "unknown"
end
function E:Create(U,label,button)
    if U.explorerCreated then return end
    U.explorerCreated=true;U.placeSort=U.placeSort or "relevance"
    U.heading:SetWidth(410)
    U.sortButton=button(U.frame,"Sort: availability",442,-129,179,25,function()
        E:Choices(U,"sort",U.sortButton)
    end)
    U.sortButton:Hide()
    U.emptyHeading=label(U.frame,"",38,-334,564)
    U.emptyDetail=label(U.frame,"",38,-364,564,true)
    if M.core.Chrome then M.core.Chrome.Tint(U.emptyHeading,"secondary");M.core.Chrome.Tint(U.emptyDetail,"muted") end
    U.emptyHeading:Hide();U.emptyDetail:Hide()
    for _,row in ipairs(U.rows) do
        row.explorerBadge=row:CreateTexture(nil,"ARTWORK")
        row.explorerBadge:SetSize(24,24);row.explorerBadge:SetPoint("LEFT",row,"LEFT",8,0);row.explorerBadge:Hide()
        row.explorerSub=label(row,"",42,-19,546,true);row.explorerSub:Hide()
        if M.core.Chrome then M.core.Chrome.OneLine(row.explorerSub);M.core.Chrome.Tint(row.explorerSub,"muted") end
    end
    local menu=CreateFrame("Frame","MirageIntelMapChoices",U.frame,"BackdropTemplate")
    menu:SetSize(244,220);menu:SetFrameStrata("FULLSCREEN_DIALOG");menu:EnableMouse(true);menu:SetClampedToScreen(true)
    if M.core.Chrome then M.core.Chrome.Panel(menu);M.core.Chrome.Escape(menu) end
    menu.rows={}
    for i=1,7 do
        menu.rows[i]=button(menu,"",8,-8-(i-1)*28,228,26,function()
            local key,value=menu.key,menu.values and menu.values[i] and menu.values[i][1]
            menu:Hide()
            if not ready() or not value then return end
            if key=="sort" then
                U.placeSort=value;U.nearest=nil;U.offset=0
                E:CancelDistance(U)
            else
                U.filterUndo=nil;U.clusterMembers=nil;U.offset=0
                local ok,why=M.Storage:SetSetting(key,value)
                if not ok then M:Print(M:UserMessage(why)) end
            end
            U:Update()
        end)
        menu.rows[i].title:SetJustifyH("LEFT")
    end
    menu:Hide();U.choiceMenu=menu
    U.frame:HookScript("OnHide",function()
        menu:Hide();E:CancelDistance(U)
        for _,control in ipairs({U.search,U.material,U.name,U.x,U.y}) do if control and control.ClearFocus then control:ClearFocus() end end
    end)
    if U.layerFilter then U.layerFilter:SetScript("OnClick",function()E:Choices(U,"placeLayer",U.layerFilter)end) end
    if U.availability then U.availability:SetScript("OnClick",function()E:Choices(U,"availability",U.availability)end) end
    if U.resourceFilter then U.resourceFilter:SetScript("OnClick",function()E:Choices(U,"resourceCategory",U.resourceFilter)end) end
end
function E:Choices(U,key,anchor)
    local values=choiceSets[key]
    if not ready() or not values or not U.choiceMenu or U.page~="Places" then return false end
    local menu=U.choiceMenu
    if menu:IsShown() and menu.key==key then menu:Hide();return true end
    menu.key=key;menu.values=values
    menu:ClearAllPoints();menu:SetPoint("TOPRIGHT",anchor,"BOTTOMRIGHT",0,-4);menu:SetHeight(16+#values*28)
    local current=key=="sort" and U.placeSort or M.Storage.account.settings[key]
    for i,row in ipairs(menu.rows) do
        local value=values[i]
        if value then
            row.title:SetText(value[2]);row:Show()
            if M.core.Chrome then M.core.Chrome.Active(row,value[1]==current) end
        else row:Hide() end
    end
    menu:Show();return true
end
function E:CanUndo(U)
    local saved=U.filterUndo
    return saved and saved.account==M.Storage.account and same(saved.after,M.Storage.account.settings) and
        (U.search:GetText() or "")=="" and (U.material:GetText() or "")==""
end
function E:ResetFilters(U)
    if not ready() or not M.Storage.SetPlaceFilters then return false,"FILTERS_UNAVAILABLE" end
    local saved=U.filterUndo
    if self:CanUndo(U) then
        local ok,why=M.Storage:SetPlaceFilters(saved.before)
        if not ok then return false,why end
        U.filterUndo=nil;U.offset=0;U.clusterMembers=nil
        U.syncingSearch=true
        U.search:SetText(saved.search);U.material:SetText(saved.material)
        U.syncingSearch=false;U:ApplyPlaceSearch()
        return true,"FILTERS_RESTORED"
    end
    local previous={account=M.Storage.account,before=filters(),search=U.search:GetText(),material=U.material:GetText()}
    local reset={filterFaction=false,filterClass=false,filterProfession=false,placeLayer="all",resourceCategory="all",availability="all"}
    local ok,why=M.Storage:SetPlaceFilters(reset)
    if not ok then return false,why end
    U.offset=0;U.clusterMembers=nil;U.syncingSearch=true
    U.search:SetText("");U.material:SetText("");U.syncingSearch=false;U:ApplyPlaceSearch()
    previous.after=filters();U.filterUndo=previous
    return true,"FILTERS_RESET"
end
function E:CancelDistance(U)
    U.distanceGeneration=(U.distanceGeneration or 0)+1
    local service=M.Integration:Service("Tasks")
    if service and type(service.Cancel)=="function" then M:Call(service.Cancel,"MirageIntel_MapDistance") end
    if U.nearest and U.nearest.loading then U.nearest=nil end
end
function E:Nearest(U,rows,mapID)
    if not ready() then U.sortHint="Distance sorting resumes outside combat";return nil end
    local player=M.MapQuery:Player()
    if not player or not player.world or not M.map or type(M.map.World)~="function" or type(M.map.Measure)~="function" then
        U.sortHint="Distance unavailable · names shown";return nil
    end
    local keys={tostring(mapID)}
    for _,row in ipairs(rows) do keys[#keys+1]=row.id..":"..tostring(row.sourceRevision or row.revision)..":"..row.x..":"..row.y end
    local key=table.concat(keys,";");local old=U.nearest
    local moved=old and M.map:Measure(player,old.player)
    if old and old.mapper==M.map and old.key==key and M:Number(moved) and moved<20 then
        U.sortHint=old.loading and "Measuring straight-line distance…" or "Distance from you"
        return not old.loading and old.distances or nil
    end
    self:CancelDistance(U)
    local generation=U.distanceGeneration
    local job={key=key,player=player,rows=rows,index=1,distances={},loading=true,account=M.Storage.account,generation=generation,
        mapper=M.map,queryGeneration=M.RecordQuery and M.RecordQuery.generation}
    U.nearest=job;U.sortHint="Measuring straight-line distance…"
    local function active()
        return U.nearest==job and U.distanceGeneration==generation and U.page=="Places" and
            U.placeSort=="nearest" and U.frame:IsShown() and M.Storage.account==job.account and M.map==job.mapper and
            (not M.RecordQuery or M.RecordQuery.generation==job.queryGeneration) and M.MapQuery:BrowseMap()==mapID and ready()
    end
    local function step()
        if not active() then if U.nearest==job then U.nearest=nil;U.dirty=true end;return false end
        for _=1,16 do
            local row=job.rows[job.index]
            if not row then
                job.loading=false
                U.dirty=true
                return false
            end
            local world=M.map:World(row.mapID,row.x,row.y)
            if not active() then if U.nearest==job then U.nearest=nil;U.dirty=true end;return false end
            if world then
                local distance=M.map:Measure(job.player,{world=world})
                if not active() then if U.nearest==job then U.nearest=nil;U.dirty=true end;return false end
                if M:Number(distance) and distance>=0 then job.distances[row.id]=distance end
            end
            job.index=job.index+1
        end
        return true
    end
    job.step=step
    local service=M.Integration:Service("Tasks")
    if service and type(service.Queue)=="function" then
        local accepted,ok=M:Call(service.Queue,"MirageIntel_MapDistance",step,generation)
        job.scheduled=ok and accepted==true
    end
    if not job.scheduled then step() end
    return not job.loading and job.distances or nil
end
function E:Sort(U,rows,mapID)
    local mode=U.placeSort or "relevance"
    U.sortHint=nil
    local distances=mode=="nearest" and self:Nearest(U,rows,mapID) or nil
    local result={};for _,row in ipairs(rows) do result[#result+1]=row end
    local function rank(row)
        return (row.availability=="AVAILABLE" or row.availability=="ACCEPTED") and 1 or row.availability=="KNOWN" and 2 or 3
    end
    table.sort(result,function(a,b)
        if not not a.destination~=not not b.destination then return a.destination==true end
        if mode=="nearest" and distances then
            local ad,bd=distances[a.id] or math.huge,distances[b.id] or math.huge
            if ad~=bd then return ad<bd end
        elseif mode=="category" then
            local ac,bc=a.category or a.kind or "",b.category or b.kind or ""
            if ac~=bc then return ac<bc end
        elseif mode=="relevance" and rank(a)~=rank(b) then return rank(a)<rank(b) end
        local an,bn=a.label:lower(),b.label:lower()
        return an==bn and a.id<b.id or an<bn
    end)
    return result
end
function E:Tick(U)
    if U.nearest and U.nearest.loading and not U.nearest.scheduled then U.nearest.step() end
    if U.page=="Places" and U.placeSort=="nearest" and M:Now()-(U.distancePollAt or -10)>=1 then
        U.distancePollAt=M:Now();U.dirty=true
    end
end
function E:Home(U)
    local mapID=M.MapQuery:BrowseMap();local player=M.MapQuery:Player()
    local zone=mapID and (M.MapQuery:Name(mapID) or "Map #"..mapID) or "Choose a zone"
    local route=M.Storage:RouteSnapshot();local destination=M.Integration:CurrentDestination()
    local rows=M.RecordQuery and mapID and M.RecordQuery:List(mapID) or {}
    local resources=M.ZoneGuide and mapID and M.ZoneGuide:GetResources(mapID)
    local materialCount=resources and (#(resources.herbs or {})+#(resources.ores or {})) or 0
    local location=player and player.mapID==mapID and string.format("You: %.1f, %.1f",player.x*100,player.y*100) or "Browse this zone"
    local guide=M.ZoneGuide and mapID and M.ZoneGuide:Summary(mapID)
    U.homeCards={
        {label=zone,detail=location..(guide and " · "..guide or ""),badge="map",page="Zones"},
        {label="Explore places",detail=#rows.." places · quests, services and gathering",badge="map",page="Places"},
        {label="Resource guide",detail=materialCount>0 and (materialCount.." materials · fishing and tools") or "Find materials, fishing and profession tools",badge="gather",page="Coverage",reference=true},
        {label="Personal notes",detail=tostring(M.state.noteCount or 0).." saved places · add a note or plan a stop",badge="map",page="Notes"},
        {label="Your route",detail="View upcoming stops and manage saved routes",badge="navigate",page="Route"},
        {label=destination and destination.label or "Wayfinder",detail=destination and "Current destination · open navigation controls" or "Automatic questing and gathering routes",badge="navigate",external=true},
        {label="Layers and appearance",detail="Choose visible data, marker density and window size",badge="map",page="Settings"},
    }
    U.heading:SetText("Explore your world")
    U.details:SetText("Choose a tool to explore, gather or plan your journey.")
    U.currentRows={};U.previous:Disable();U.next:Disable()
    for i,card in ipairs(U.homeCards) do
        local row=U.rows[i];row:Show();row.title:SetText(card.label);row.detailText=card.detail
    end
    U.pager:SetText("")
    U.action1.title:SetText("Open map");U.action2.title:SetText("Wayfinder");U.action3.title:SetText("Gather Mate");U.action4.title:SetText("Settings")
    U.action2:SetEnabled(ready() and M.Integration:Navigate()~=nil);U.action3:SetEnabled(ready() and M.Integration:Gather()~=nil)
end
function E:HomeAction(U,index)
    if not ready() then return false end
    local card=U.homeCards and U.homeCards[index];if not card then return false end
    if card.external then
        local nav=M.Integration:Navigate()
        if not nav or type(nav.Open)~="function" or not ready() then return false end
        local accepted,ok=M:Call(nav.Open)
        if ok and accepted then U.frame:Hide();return true end
        return false
    end
    U.page=card.page;U.offset=0;U.clusterMembers=nil
    if card.reference then U.referenceMode="materials";U.referenceItem=nil;U.referenceRegion=nil end
    U:Update();return true
end
function E:Paint(U)
    if not U.explorerCreated then return end
    U.emptyHeading:Hide();U.emptyDetail:Hide()
    local active=ready()
    U.sortButton:SetShown(U.page=="Places");U.sortButton:SetEnabled(active)
    U.sortButton.title:SetText("Sort: "..(sortLabels[U.placeSort] or "availability"))
    if U.choiceMenu:IsShown() and (not active or U.page~="Places") then U.choiceMenu:Hide() end
    if M.Storage.readOnly then U.sortButton:Hide();return end
    if U.page=="Places" then
        U.layerFilter.title:SetText(choiceName("placeLayer",M.Storage.account.settings.placeLayer))
        U.availability.title:SetText(choiceName("availability",M.Storage.account.settings.availability))
        U.resourceFilter.title:SetText(choiceName("resourceCategory",M.Storage.account.settings.resourceCategory))
        if not U.clusterMembers then U.action4.title:SetText(self:CanUndo(U) and "Undo reset" or "Reset filters") end
        if U.sortHint then U.pager:SetText(U.pager:GetText().."\n"..U.sortHint) end
    end
    for i,row in ipairs(U.rows) do
        row.explorerBadge:Hide();row.explorerSub:Hide()
        row.title:ClearAllPoints();row.title:SetPoint("LEFT",row,"LEFT",6,0);row.title:SetPoint("RIGHT",row,"RIGHT",-6,0)
        row.title:SetWordWrap(true);if row.title.SetMaxLines then row.title:SetMaxLines(2) end
        local record=U.currentRows and U.currentRows[i]
        local card=U.page=="Home" and U.homeCards and U.homeCards[i]
        local title,detail,badge,selected
        if card then title,detail,badge=card.label,card.detail,card.badge
        elseif record and U.page=="Places" then
            local layer=M.RecordQuery and M.RecordQuery:Layer(record) or record.layer or "pois"
            title=record.label;badge=badgeKeys[layer] or "map"
            local availability=statusLabels[record.availability] or ""
            if record.kind=="gather" then availability="Recorded spot" end
            detail=(record.category and plain(record.category) or layerLabels[layer] or "Place").." · "..
                string.format("%.1f, %.1f",record.x*100,record.y*100)..(availability~="" and " · "..availability or "")
            selected=M.state.utilitySelection and M.state.utilitySelection.id==record.id
        elseif record and U.page=="Notes" then
            title=record.label;badge=record.kind=="resource" and "gather" or record.kind=="travel" and "navigate" or "map"
            detail=plain(record.kind).." · "..string.format("%.1f, %.1f",record.x*100,record.y*100).." · right-click to edit"
            selected=M.state.selection==record.id
        elseif record and U.page=="Route" then
            title=record.index..". "..record.label;badge="navigate"
            detail=string.format("%.1f, %.1f",record.x*100,record.y*100)..(U.liveRoute and (record.index==1 and " · Next stop" or "") or " · Shift-click to reorder")
            selected=(U.liveRoute and record.index==1) or (not U.liveRoute and M.Storage.character.route.cursor==record.index)
        elseif record and U.page=="Zones" then
            title=record.name;badge="map";selected=U.zoneSelected==record.mapID
            detail=M.ZoneGuide and M.ZoneGuide:Summary(record.mapID) or "Select to browse this zone"
        elseif record and U.page=="Coverage" then
            title=record.label;detail=record.state;badge=U.referenceMode and "gather" or "map"
        end
        if title then
            row.title:ClearAllPoints();row.title:SetPoint("TOPLEFT",row,"TOPLEFT",42,-3);row.title:SetPoint("TOPRIGHT",row,"TOPRIGHT",-8,-3)
            row.title:SetWordWrap(false);if row.title.SetMaxLines then row.title:SetMaxLines(1) end
            row.title:SetText(title)
            row.explorerSub:SetText(detail or "");row.explorerSub:Show()
            if record and U.page=="Places" and M.core.MapIcons then M.core.MapIcons.Apply(row.explorerBadge,record)
            else row.explorerBadge:SetTexture(media..(badge or "map")) end;row.explorerBadge:Show()
        end
        row:SetEnabled(active and (not card or not card.external or M.Integration:Navigate()~=nil))
        if M.core.Chrome then M.core.Chrome.Active(row,selected==true) end
    end
    local empty=U.currentRows and #U.currentRows==0 and U.page~="Home" and U.page~="Settings"
    if empty then
        local text={Places={"No matching places",U.details:GetText()},Notes={"Make this map yours","Save your current position, enter coordinates, or use Cursor note while browsing the map."},
            Route={"Plan your first stop","Select a personal note and choose Add to route. Your stop order remains editable."},
            Zones={"No matching zones","Clear the search or choose another zone on the map."},
            Coverage={"No resources to show",U.details:GetText()}}
        local spec=text[U.page]
        if spec then U.emptyHeading:SetText(spec[1]);U.emptyDetail:SetText(spec[2]);U.emptyHeading:Show();U.emptyDetail:Show() end
    end
end
