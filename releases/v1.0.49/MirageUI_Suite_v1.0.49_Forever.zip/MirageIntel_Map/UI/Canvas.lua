local _,M=...
M.Canvas={dirty=true,status="WORLD_MAP_NOT_LOADED",pins={},sharedPins={},lastMap=nil,elapsed=0,attached=false,hooked=setmetatable({},{__mode="k"})}
local P=M.Canvas
local warm=M.colors.secondary
local function colorFor(kind)
    if kind=="travel" then return .45,.72,.77 end
    if kind=="quest" then return .87,.77,.46 end
    if kind=="resource" then return .50,.72,.53 end
    if kind=="danger" then return .83,.44,.40 end
    return warm[1],warm[2],warm[3]
end
function P:Dirty() self.dirty=true;self.elapsed=.25 end
function P:HidePins(keepLayerPins)
    for _,b in ipairs(self.pins) do b:Hide();b.note=nil;b.record=nil end
    for _,b in ipairs(self.sharedPins) do b:Hide();b.record=nil end
    if self.destinationPin then self.destinationPin:Hide();self.destinationPin.record=nil end
    if not keepLayerPins then
        for _,b in ipairs(self.layerPins or {}) do b:Hide();b.record=nil;b.model=nil;b.modelKey=nil;b.press=nil end
    end
    if self.bearing then self.bearing:Hide() end
    for _,line in ipairs(self.routeLines or {}) do line:Hide() end
    for _,line in ipairs(self.routeShadows or {}) do line:Hide() end
    self.routeLineCount=0
    self.visible=0;self.sharedVisible=0;self.renderedRecords={};self.representedRecords=0
end
function P:HideAll()
    if M.NativeMarkers then M.NativeMarkers:Clear() end
    self.active=false
    M.Integration:ReleaseGatherLayer()
    for layer in pairs(self.layerOwners or {}) do M.Integration:ReleaseLayer(layer) end
    self.layerOwners={}
    if M.ExplorationUI then M.ExplorationUI:Hide() end
    if self.legend then self.legend:Hide() end
    if self.legendBack then self.legendBack:Hide() end
    self.zoneCardStatus="HIDDEN"
    self:Dirty() -- visibility changes invalidate otherwise unchanged pin geometry
    self:HidePins()
    if self.coords then self.coords:Hide() end
    if self.launcher then self.launcher:Hide() end
    if self.view then self.view:Hide() end
    if self.pinHost then self.pinHost:Hide() end
end
function P:Pin()
    if M:Combat() or not self.canvas then return nil end
    local b=CreateFrame("Button",nil,self.pinHost or self.canvas)
    if not b then return nil end
    b:SetSize(32,32)
    b:EnableMouse(true)
    local bg=b:CreateTexture(nil,"ARTWORK")
    bg:SetAllPoints(b);bg:SetTexture("Interface\\AddOns\\MirageIntel_Core\\Media\\MapIcons\\note.tga")
    b.color=bg
    b:SetScript("OnEnter",function(self)
        local r=self.note
        if r then M.Integration:ShowRecord(self,M.Integration:NoteRecord(r),
            {purpose="PERSONAL_NOTE",hint="Click to edit this note"}) end
    end)
    local function release(self) M.Integration:HideRecord(self) end
    b:SetScript("OnLeave",release);b:SetScript("OnHide",release)
    b:SetScript("OnClick",function(self)
        if self.note then
            M.state.selection=self.note.id
            M.Panel.page="Notes"
            M.Panel:Open("map")
        end
    end)
    self.pins[#self.pins+1]=b
    return b
end
function P:SharedPin(destination)
    if M:Combat() or not self.canvas then return nil end
    local b=CreateFrame("Button",nil,self.pinHost or self.canvas)
    if not b then return nil end
    b:SetSize(destination and 36 or 32,destination and 36 or 32);b:EnableMouse(true)
    b.texture=b:CreateTexture(nil,"ARTWORK");b.texture:SetAllPoints(b)
    b.texture:SetTexture("Interface\\AddOns\\MirageIntel_Core\\Media\\"..(destination and "navigate" or "gather"))
    b:SetScript("OnEnter",function(self)
        if self.record then M.Integration:ShowRecord(self,self.record,
            {purpose=self.record.purpose,hint="Click for details"}) end
    end)
    local function release(self) M.Integration:HideRecord(self) end
    b:SetScript("OnLeave",release);b:SetScript("OnHide",release)
    b:SetScript("OnClick",function(self)
        if self.record then
            local ok,why=M.Integration:SelectRecord(self.record,"map")
            if not ok then M:Print(why) end
        end
    end)
    if not destination then self.sharedPins[#self.sharedPins+1]=b end
    return b
end
function P:EnsureDestinationPin()
    if self.destinationPin or M:Combat() or not self.canvas then return end
    self.destinationPin=self:SharedPin(true)
end
function P:Identity()
    local f=M.MapQuery:Frame()
    if not f then return nil,nil,nil,"BLIZZARD_MAP_NOT_LOADED" end
    local sc=f.ScrollContainer
    local canvas=M:Readable(sc) and sc and sc.Child
    if not M:Readable(canvas) or not canvas or type(canvas.GetWidth)~="function" or
        type(canvas.GetHeight)~="function" then return f,sc,nil,"MAP_CANVAS_UNAVAILABLE" end
    return f,sc,canvas
end
function P:CreateOverlay(f,canvas)
    local view=CreateFrame("Frame",nil,f)
    view:SetAllPoints(f);view:EnableMouse(false);view:Hide()
    local pinHost=CreateFrame("Frame",nil,canvas)
    pinHost:SetAllPoints(canvas);pinHost:EnableMouse(false);pinHost:Hide()
    local l=CreateFrame("Button",nil,view)
    l:SetSize(90,25)
    l:SetPoint("BOTTOMRIGHT",view,"BOTTOMRIGHT",-21,12)
    local tx=l:CreateTexture(nil,"BACKGROUND")
    tx:SetAllPoints(l);tx:SetTexture("Interface\\Buttons\\WHITE8x8")
    tx:SetVertexColor(.060,.060,.065,.93)
    l.bg=tx
    local badge=l:CreateTexture(nil,"ARTWORK")
    badge:SetSize(16,16);badge:SetPoint("LEFT",l,"LEFT",6,0)
    badge:SetTexture("Interface\\AddOns\\MirageIntel_Map\\Media\\Badge")
    local caption=l:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    caption:SetPoint("LEFT",badge,"RIGHT",3,0);caption:SetPoint("RIGHT",l,"RIGHT",-4,0)
    caption:SetText("Map+ Ultra")
    caption:SetTextColor(M.colors.secondary[1],M.colors.secondary[2],M.colors.secondary[3])
    l:SetScript("OnClick",function() M.Panel:Open("map") end)
    local function unhover(self)
        self.bg:SetVertexColor(.060,.060,.065,.93)
        if GameTooltip and GameTooltip.IsOwned and GameTooltip:IsOwned(self) then GameTooltip:Hide() end
    end
    l:SetScript("OnEnter",function(self)
        self.bg:SetVertexColor(.19,.21,.22,.96)
        if GameTooltip then
            GameTooltip:SetOwner(self,"ANCHOR_TOP")
            GameTooltip:AddLine("Open Map+ Ultra")
            if P.legendDetail then GameTooltip:AddLine(P.legendDetail,.90,.89,.87,true) end
            GameTooltip:Show()
        end
    end)
    l:SetScript("OnLeave",unhover);l:SetScript("OnHide",unhover)
    local coord=view:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    -- Keep our optional readout above the native map's bottom coordinate band.
    coord:SetPoint("BOTTOMRIGHT",view,"BOTTOMRIGHT",-123,17)
    coord:SetWidth(290);coord:SetJustifyH("RIGHT")
    coord:SetWordWrap(false)
    coord:SetTextColor(.85,.85,.83)
    if M.core and M.core.Chrome and M.core.Chrome.Font then
        M.core.Chrome.Font(coord,"small");M.core.Chrome.Font(caption,"small")
    end
    self.view,self.pinHost,self.launcher,self.launcherLabel,self.coords=view,pinHost,l,caption,coord
end
function P:Attach(policyChecked)
    if M:Combat() then return false,"COMBAT" end
    if policyChecked~=true then
        local allowed,reason=M.Integration:AllowMapOverlay()
        if not allowed then self:HideAll();self.status=reason;return false,reason end
    end
    local f,sc,canvas,why=self:Identity()
    if self.attached and self.frame==f and self.scroll==sc and self.canvas==canvas then return true end
    if self.frame and self.frame~=f and M.MapQuery.CloseWindowsForMap then M.MapQuery:CloseWindowsForMap(self.frame) end
    self.attached=false
    self:HideAll()
    self.lastMap,self.lastW,self.lastH,self.lastDestination=nil,nil,nil,nil
    M.MapQuery.lastCursor=nil
    if not canvas then self.status=why;return false,why end
    -- Hooks guard frame identity and introduce no replacement or ownership of native input.
    -- Reuse one owned chrome and pin pool when the game replaces the map or scroll child.
    if not self.hooked[f] then
        if type(f.HookScript)=="function" then
            local open=pcall(f.HookScript,f,"OnShow",function(owner) if P.frame==owner then P:Dirty() end end)
            local close=pcall(f.HookScript,f,"OnHide",function(owner)
                if M.MapQuery.CloseWindowsForMap then M.MapQuery:CloseWindowsForMap(owner) end
                if P.frame==owner then M.MapQuery.lastCursor=nil;P:HideAll() end
            end)
            self.hooked[f]=open and close and "READY" or "REJECTED"
        else self.hooked[f]="REJECTED" end
    end
    if self.hooked[f]~="READY" then
        self.status="MAP_HOOK_REJECTED";return false,self.status
    end
    if not self.view then self:CreateOverlay(f,canvas)
    else
        if self.frame~=f then
            self.view:SetParent(f)
            self.view:ClearAllPoints();self.view:SetAllPoints(f)
        end
        if self.canvas~=canvas then
            self.pinHost:SetParent(canvas)
            self.pinHost:ClearAllPoints();self.pinHost:SetAllPoints(canvas)
        end
    end
    self.frame,self.scroll,self.canvas=f,sc,canvas
    -- A native map replacement keeps our pooled frames but changes anchors.
    if self.legend then
        self.legendBack:ClearAllPoints();self.legendBack:SetPoint("TOPLEFT",sc,"TOPLEFT",28,-12)
    end
    if M.ExplorationUI then M.ExplorationUI:Attach(canvas) end
    self.attached=true;self.status="ATTACHED_NATIVE_UNTESTED";self:Dirty()
    return true
end
function P:Place(pin,record,w,h)
    pin:ClearAllPoints()
    pin:SetPoint("CENTER",self.canvas,"TOPLEFT",record.x*w,-record.y*h)
    pin:Show()
end
function P:Refresh()
    if not M.state.initialized or not M.state.clientAllowed then return end
    if M:Combat() or not M.MapQuery:Shown() then self:HideAll();return end
    local enabled,reason=M.Integration:AllowMapOverlay()
    if not enabled then self:HideAll();self.status=reason;return end
    if not self.attached or self.frame then
        if not self:Attach(true) then return end
    end
    local cfg=M.Storage.account and M.Storage.account.settings
    if not cfg then self:HideAll();self.status="SETTINGS_UNAVAILABLE";return end
    local mapID=M.MapQuery:CurrentMap()
    local w,ok=M:Call(self.canvas.GetWidth,self.canvas)
    local h,valid=M:Call(self.canvas.GetHeight,self.canvas)
    if not mapID or not ok or not valid or not M:Number(w) or not M:Number(h) or w<=10 or h<=10 then
        self:HideAll();self.status="INVALID_MAP_GEOMETRY";return
    end
    if self.lastMap and mapID~=self.lastMap then M.MapQuery.lastCursor=nil end
    if self.view then self.view:Show() end
    if self.pinHost then self.pinHost:Show() end
    self.launcher:SetShown(cfg.showMapButton)
    self.active=true
    if cfg.showCoordinates and not (self.frame and self.frame.CoordinateDisplay and self.frame.CoordinateDisplay.IsShown and self.frame.CoordinateDisplay:IsShown()) then
        local player=M.MapQuery:Player()
        local cur=M.MapQuery:Cursor()
        local pText=(player and player.mapID==mapID) and string.format("%.1f, %.1f",player.x*100,player.y*100) or ""
        local cText=cur and string.format("Cursor %.1f, %.1f",cur.x*100,cur.y*100) or ""
        self.coords:SetText(cText~="" and cText or pText)
        if self.launcher and self.launcher.IsMouseOver and self.launcher:IsMouseOver() then self.coords:Show() else self.coords:Hide() end
    else self.coords:Hide() end
    local destination=M.Integration:CurrentDestination()
    if M.Integration:RouteOverlay().showMap==false then destination=nil end
    if M.RecordQuery then self:RefreshLayers(mapID,w,h,cfg,destination);return end
    local prefs=M.Integration:GatherPreferences()
    local gKey=prefs and tostring(prefs.showMapPins)..":"..tostring(prefs.category)..":"..tostring(prefs.maxPins) or "unavailable"
    local dKey=destination and (destination.id..":"..tostring(destination.revision)..":"..
        tostring(destination.navigationRevision)..":"..destination.mapID..":"..destination.x..":"..destination.y) or "none"
    -- A live owner renews its lease even when no data or geometry changed.
    -- Expiry allows Gather's fallback to recover if Map+ stops rendering.
    if self.sharedVisible and self.sharedVisible>0 then
        if not M.Integration:ClaimGatherLayer() then self:Dirty() end
    end
    if not self.dirty and self.lastMap==mapID and self.lastW==w and self.lastH==h and
       self.lastDestination==dKey and self.lastGatherPreferences==gKey then return end
    self.dirty=false;self.lastMap=mapID;self.lastW=w;self.lastH=h;self.lastDestination=dKey;self.lastGatherPreferences=gKey
    self:HidePins()
    local pinBlocked=false
    local shared,meta=M.Integration:GatherRecords(mapID,64)
    self.sharedRevision=meta.revision;self.sharedStatus=meta.status;self.sharedTruncated=meta.nextCursor~=nil
    local budget=math.min(cfg.pinLimit,M.maxPins)
    local gatherReserve=math.min(16,#shared,budget)
    if cfg.showPersonalPins then
        local rows=M.Storage:List({mapID=mapID,kind=cfg.kind},M.maxNotes,0)
        local occupied={};local visible=0
        for _,r in ipairs(rows) do
            if visible>=budget-gatherReserve then break end
            local cell=math.floor(r.x*w/12)..":"..math.floor(r.y*h/12)
            if not occupied[cell] then
                occupied[cell]=true;visible=visible+1
                local pin=self.pins[visible] or self:Pin()
                if not pin then visible=visible-1;pinBlocked=true;break end
                pin.note=r
                pin.record=M.Integration:NoteRecord(r)
                local cr,cg,cb=colorFor(r.kind)
                pin.color:SetVertexColor(cr,cg,cb,.88)
                self:Place(pin,r,w,h)
            end
        end
        self.visible=visible
    end
    local gatherLimit=math.max(0,budget-self.visible)
    local claimed=#shared>0 and gatherLimit>0 and M.Integration:ClaimGatherLayer()
    local occupied={}
    if claimed then
        for _,record in ipairs(shared) do
            if self.sharedVisible>=gatherLimit then break end
            -- The destination marker represents this same shared record once.
            local isDestination=cfg.showDestinationPin and destination and destination.mapID==mapID and
                destination.id==record.id
            local cell=(record.category or record.kind)..":"..math.floor(record.x*w/14)..":"..math.floor(record.y*h/14)
            if not isDestination and not occupied[cell] then
                occupied[cell]=true
                local pin=self.sharedPins[self.sharedVisible+1] or self:SharedPin()
                if not pin then pinBlocked=true;break end
                self.sharedVisible=self.sharedVisible+1;pin.record=record
                pin.texture:SetVertexColor(1,1,1,record.confidence=="PROBABLE" and .75 or .94)
                self:Place(pin,record,w,h)
                self.renderedRecords[#self.renderedRecords+1]={id=record.id,revision=record.revision,sourceRevision=record.sourceRevision}
            end
        end
    end
    if cfg.showDestinationPin and destination and destination.mapID==mapID then
        self:EnsureDestinationPin()
        if self.destinationPin then
            self.destinationPin.record=destination
            self:Place(self.destinationPin,destination,w,h)
            self.renderedRecords[#self.renderedRecords+1]={id=destination.id,revision=destination.revision,
                sourceRevision=destination.sourceRevision,navigationRevision=destination.navigationRevision,destination=true}
            if claimed and destination.kind=="gather" then self.sharedVisible=self.sharedVisible+1 end
        end
    end
    if self.sharedVisible==0 then M.Integration:ReleaseGatherLayer() end
    self.status=pinBlocked and "PIN_CREATION_BLOCKED" or "MAP_OVERLAY_ACTIVE"
end
function P:Tick(dt)
    if not M:Number(dt) or dt<0 then return end
    self.elapsed=self.elapsed+math.min(.25,dt)
    if self.elapsed<.25 then return end
    self.elapsed=0
    if M.Catalog and M.Catalog.TickObservations then M.Catalog:TickObservations() end
    if M.Panel and M.Panel.Tick then M.Panel:Tick() end
    if M.RecordQuery then M.RecordQuery:Tick() end
    if M.state.initialized and (M.MapQuery:Shown() or self.active) then
        local performance=M.Integration:Service("Performance")
        local started=performance and performance.Begin and M:Call(performance.Begin)
        local ok=pcall(self.Refresh,self)
        if performance and performance.Finish then M:Call(performance.Finish,"map.paint",started) end
        if not ok then M:Fault("MAP_REFRESH_FAILED");self:HideAll() end
    end
end

-- Independent semantic layers. The map remains the sole owner of pan/zoom and
-- native pins; these controls own only their individual clickable glyphs.
function P:LayerPin(index)
    self.layerPins=self.layerPins or {}
    if self.layerPins[index] then return self.layerPins[index] end
    if M:Combat() or index>80 then return nil end
    local b=CreateFrame("Button",nil,self.pinHost)
    b:SetSize(32,32);b:EnableMouse(true)
    if type(b.RegisterForClicks)=="function" then b:RegisterForClicks("LeftButtonUp","RightButtonUp") end
    if self.glyphLevel and type(b.SetFrameLevel)=="function" then b:SetFrameLevel(self.glyphLevel) end
    b.texture=b:CreateTexture(nil,"ARTWORK");b.texture:SetAllPoints(b)
    b.halo=b:CreateTexture(nil,"OVERLAY");b.halo:SetAllPoints(b)
    b.halo:SetTexture("Interface\\AddOns\\MirageIntel_Core\\Media\\MapIcons\\active.tga");b.halo:Hide()
    b.glyph=b:CreateFontString(nil,"OVERLAY","GameFontNormalSmall");b.glyph:SetAllPoints(b);b.glyph:SetJustifyH("CENTER")
    if type(b.glyph.SetShadowColor)=="function" then b.glyph:SetShadowColor(0,0,0,1);b.glyph:SetShadowOffset(1,-1) end
    local function showHint(self)
        local model=self.model
        if not model then return end
        if model.role=="cluster" then
            local lines={}
            if model.landmark then lines[#lines+1]=model.record.label end
            lines[#lines+1]=model.record.linkedMapID and "Click for places · Right-click to open map" or "Click to view these places"
            M.Integration:ShowMapHint(self,#model.members.." places",lines)
        else M.Integration:ShowRecord(self,self.record,{purpose=self.record.purpose,hint=self.record.linkedMapID and "Click for details · Right-click to open map" or "Click for details"}) end
    end
    b:SetScript("OnEnter",function(self) self.hovered=true;showHint(self) end)
    b.refreshHint=showHint
    local function release(self) self.hovered=nil;M.Integration:HideRecord(self) end
    b:SetScript("OnLeave",release)
    b:SetScript("OnHide",function(self) self.press=nil;release(self) end)
    b:SetScript("OnMouseDown",function(self,button)
        if (button=="LeftButton" or button=="RightButton") and self.model then
            self.press={key=self.modelKey,mapID=M.MapQuery:CurrentMap(),canvas=P.canvas,at=M:Now()}
        end
    end)
    b:SetScript("OnClick",function(self,button)
        if button and button~="LeftButton" and button~="RightButton" then return end
        local press=self.press;self.press=nil
        local mapID=M.MapQuery:CurrentMap()
        if press and (press.mapID~=mapID or press.canvas~=P.canvas or press.key~=self.modelKey or M:Now()-press.at>3) then return end
        -- Retain the pressed identity, then inspect its latest same-identity
        -- data (quest progress may have updated while the mouse was down).
        local model=self.model
        if not model or not M.MapQuery:Shown() then return end
        local ok,why
        if button=="RightButton" then
            if not M:Integer(model.record.linkedMapID) then return end
            ok,why=M.MapQuery:GoToMap(model.record.linkedMapID)
        elseif model.role=="cluster" then ok,why=M.Panel:OpenCluster(model.members,"map",mapID)
        else ok,why=M.Integration:SelectRecord(model.record,"map") end
        P.lastClickStatus=ok and "OPENED" or why or "UNAVAILABLE"
        P.clicks=(P.clicks or 0)+1
        if not ok then M:Print(M:UserMessage(why)) end
    end)
    self.layerPins[index]=b;return b
end
function P:ModelKey(entry,mapID)
    local members={}
    for _,id in ipairs(entry.members or {}) do members[#members+1]=tostring(id) end
    table.sort(members)
    return tostring(mapID)..":"..tostring(entry.role)..":"..table.concat(members,",")
end
function P:AcquireLayerPin(key,needed,used)
    for _,pin in ipairs(self.layerPins or {}) do
        if not used[pin] and pin.modelKey==key then used[pin]=true;return pin end
    end
    for _,pin in ipairs(self.layerPins or {}) do
        if not used[pin] and not needed[pin.modelKey] and not pin.press then
            M.Integration:HideRecord(pin);pin.modelKey=key;used[pin]=true;return pin
        end
    end
    local pin=self:LayerPin(#(self.layerPins or {})+1)
    if pin then pin.modelKey=key;used[pin]=true end
    return pin
end
function P:EnsureLegend()
    if self.legend then return end
    -- The zone card uses the same charcoal panel, gold title and measured text
    -- as map tooltips. Separate rows cannot clip each other at small UI scales.
    local card=CreateFrame("Frame",nil,self.view,"BackdropTemplate")
    card:SetSize(336,84);card:SetPoint("TOPLEFT",self.scroll,"TOPLEFT",28,-12);card:EnableMouse(M.Waypoint~=nil)
    local chrome=M.core and M.core.Chrome
    if chrome and type(chrome.Panel)=="function" then chrome.Panel(card)
    else
        card:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8x8",edgeFile="Interface\\Buttons\\WHITE8x8",edgeSize=1})
        card:SetBackdropColor(.060,.060,.065,.97);card:SetBackdropBorderColor(.26,.26,.26,1)
    end
    local icon=card:CreateTexture(nil,"ARTWORK")
    icon:SetTexture("Interface\\AddOns\\MirageIntel_Map\\Media\\Badge.tga")
    icon:SetSize(24,24);icon:SetPoint("TOPLEFT",card,"TOPLEFT",12,-12)
    local title=card:CreateFontString(nil,"OVERLAY","GameFontNormal")
    title:SetPoint("TOPLEFT",icon,"TOPRIGHT",7,-2);title:SetWidth(278)
    title:SetJustifyH("LEFT");title:SetJustifyV("TOP");title:SetWordWrap(true);title:SetTextColor(.91,.55,.18)
    local subtitle=card:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    subtitle:SetWidth(310);subtitle:SetJustifyH("LEFT");subtitle:SetJustifyV("TOP");subtitle:SetWordWrap(true)
    subtitle:SetTextColor(.90,.89,.87)
    local route=card:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    route:SetWidth(310);route:SetJustifyH("LEFT");route:SetJustifyV("TOP");route:SetWordWrap(true)
    route:SetTextColor(.72,.71,.68)
    if chrome and type(chrome.Font)=="function" then
        chrome.Font(title,"title");chrome.Font(subtitle,"body");chrome.Font(route,"small")
    end
    self.legendBack,self.legend,self.legendSubtitle,self.legendRoute,self.legendIcon=card,title,subtitle,route,icon
    if self.glyphLevel and card.SetFrameLevel then card:SetFrameLevel(self.glyphLevel+1) end
    if M.Waypoint then M.Waypoint:Create(card) end
end
function P:UpdateLegend(mapID,destination,meta,cfg)
    self:EnsureLegend()
    local available,read=M:Call(self.scroll.GetWidth,self.scroll)
    local width=read and M:Number(available) and math.max(280,math.min(336,available-56)) or 336
    self.legendBack:SetWidth(width);self.legend:SetWidth(width-58)
    self.legendSubtitle:SetWidth(width-26);self.legendRoute:SetWidth(width-26)
    local zoneName=M.MapQuery:Name(mapID) or "Map+ Ultra"
    local guide=cfg.showZoneGuide~=false and M.ZoneGuide and M.ZoneGuide:Get(mapID)
    local subtitle=guide and string.format("Suggested level %d–%d",guide.recommendedMin,guide.recommendedMax) or
        tostring(self.representedRecords or 0).." places"
    local placesPending=M.Places and M.Places.mapID==mapID and M.Places.publishedMap~=mapID and M.Places.status=="LOADING"
    if placesPending and not guide and (self.representedRecords or 0)==0 then subtitle="Loading places…" end
    local detail
    if destination and type(destination.label)=="string" and destination.label~="" then
        detail="Next · "..destination.label
    elseif placesPending or (meta and meta.loading) then detail="Loading places…"
    else
        local count=self.sharedVisible or 0
        detail=tostring(self.representedRecords or 0).." places"..(count>0 and "  ·  "..count..(count==1 and " gathering spot" or " gathering spots") or "")
    end
    if not guide and not destination then subtitle=detail;detail=nil end
    if M.ExplorationUI and M.ExplorationUI.status=="UNEXPLORED_ART_VISIBLE" then
        subtitle=subtitle.."  ·  "..M.ExplorationUI:Legend()
    end
    self.legend:SetText(zoneName)
    local function height(label,minimum)
        local value,ok=M:Call(label.GetStringHeight,label)
        return ok and M:Number(value) and math.max(minimum,value) or minimum
    end
    local y=math.max(36,14+height(self.legend,20))+9
    self.legendSubtitle:ClearAllPoints();self.legendSubtitle:SetPoint("TOPLEFT",self.legendBack,"TOPLEFT",13,-y)
    self.legendSubtitle:SetText(subtitle);self.legendSubtitle:Show();y=y+height(self.legendSubtitle,16)+5
    if detail then
        self.legendRoute:ClearAllPoints();self.legendRoute:SetPoint("TOPLEFT",self.legendBack,"TOPLEFT",13,-y)
        self.legendRoute:SetText(detail);self.legendRoute:Show();y=y+height(self.legendRoute,14)+5
    else self.legendRoute:SetText("");self.legendRoute:Hide() end
    if M.Waypoint then y=y+8+M.Waypoint:Update(mapID,y+8,self) end
    self.legendBack:SetHeight(y+8)
    self.legendDetail="Quests · Services · Gathering · Personal notes\nClick a marker for details. Route numbers show your upcoming stops."
    self.legend:Show();self.legendBack:Show();self.zoneCardStatus="VISIBLE"
end
function P:QualifyLayerStack()
    local function apply(hostLevel,glyphLevel,viewLevel,status)
        self.glyphLevel=glyphLevel;self.layerStack=status
        local previous=self.layerLevels
        if previous and previous.canvas==self.canvas and previous.frame==self.frame and
            previous.hostLevel==hostLevel and previous.glyphLevel==glyphLevel and previous.viewLevel==viewLevel then return end
        -- These owned frames retain their levels between data repaints. Native
        -- manager/parent changes invalidate the snapshot and reapply the pool.
        local function set(frame,level)
            if frame and M:Number(level) and type(frame.SetFrameLevel)=="function" then
                frame:SetFrameLevel(level)
                self.layerLevelWrites=(self.layerLevelWrites or 0)+1
            end
        end
        set(self.pinHost,hostLevel)
        for _,pin in ipairs(self.layerPins or {}) do set(pin,glyphLevel) end
        set(self.view,viewLevel)
        if self.legendBack then set(self.legendBack,glyphLevel and glyphLevel+1 or viewLevel and viewLevel+1) end
        self.layerLevels={canvas=self.canvas,frame=self.frame,hostLevel=hostLevel,glyphLevel=glyphLevel,viewLevel=viewLevel}
    end
    local function fallback()
        local level,valid=M:Call(self.canvas.GetFrameLevel,self.canvas)
        local viewLevel,read=M:Call(self.frame.GetFrameLevel,self.frame)
        apply(valid and M:Number(level) and level+1 or nil,valid and M:Number(level) and level+2 or nil,
            read and M:Number(viewLevel) and viewLevel+1 or nil,"INHERITED_SMALL_GLYPHS_NATIVE_NOT_QUALIFIED")
    end
    local manager,ok=M:Call(self.frame.GetPinFrameLevelsManager,self.frame)
    if not ok or not manager or type(manager.GetValidFrameLevel)~="function" or type(self.pinHost.SetFrameLevel)~="function" then
        fallback();return
    end
    local art,valid=M:Call(manager.GetValidFrameLevel,manager,"PIN_FRAME_LEVEL_MAP_EXPLORATION")
    local default,haveDefault=M:Call(manager.GetValidFrameLevel,manager,"PIN_FRAME_LEVEL_DEFAULT")
    if not valid or not M:Number(art) or not haveDefault or not M:Number(default) or art==default then
        fallback();return
    end
    local lastInteractive=art
    for _,name in ipairs({"PIN_FRAME_LEVEL_DIG_SITE","PIN_FRAME_LEVEL_DUNGEON_ENTRANCE","PIN_FRAME_LEVEL_FLIGHT_POINT","PIN_FRAME_LEVEL_AREA_POI","PIN_FRAME_LEVEL_MAP_LINK","PIN_FRAME_LEVEL_QUEST_OFFER","PIN_FRAME_LEVEL_ACTIVE_QUEST","PIN_FRAME_LEVEL_SUPER_TRACKED_QUEST"}) do
        local level,read=M:Call(manager.GetValidFrameLevel,manager,name,1)
        -- Missing names resolve to DEFAULT on this client. One missing
        -- band must not demote all glyphs beneath the exploration artwork.
        if read and M:Number(level) and level~=default and level>art then
            local top=M:Call(manager.GetValidFrameLevel,manager,name,9000)
            lastInteractive=math.max(lastInteractive,level,M:Number(top) and top or level)
        end
    end
    -- Only each visible 32px glyph is interactive. A quest-zone overlay can
    -- accept clicks without accepting motion, so placing glyphs below it makes
    -- their hover tooltip work while their clicks disappear. Leave every
    -- native level unchanged and lift the small owned controls above that band.
    apply(art,lastInteractive+1,art+1,"PUBLIC_LEVELS_OWNED_GLYPHS_CLICKABLE")
end
function P:RenderBearing(destination,mapID,w,h,cfg,viewport)
    if self.bearing then self.bearing:Hide() end
    for _,line in ipairs(self.routeLines or {}) do line:Hide() end
    for _,line in ipairs(self.routeShadows or {}) do line:Hide() end
    self.routeLineCount=0;self.routeLabel=nil;self.routePrecision=nil;self.routeNextLegID=nil
    if cfg.showRouteBearing==false or not self.layerOwners.routes then return end
    local overlay=M.Integration:RouteOverlay()
    if overlay and overlay.showMap==false then return end
    local leg,target=M.Integration:GuidanceFor(destination)
    local stops=overlay and overlay.stops or {}
    if not destination and #stops==0 then return end
    self.routePrecision=leg and leg.precision;self.routeNextLegID=leg and leg.id
    self.routeLabel="Suggested route"
    self.routeLines=self.routeLines or {};self.routeShadows=self.routeShadows or {}
    local icons=M.core and M.core.MapIcons
    local bounds=viewport or {left=0,right=1,top=0,bottom=1}
    local zoom=bounds.scale or 1
    local player=M.MapQuery:Player()
    local floorID=player and player.mapID==mapID and (player.floorID or player.mapID) or mapID
    local function segment(ax,ay,bx,by,active)
        if self.routeLineCount>=128 then return end
        local index=self.routeLineCount+1
        local line,shadow=self.routeLines[index],self.routeShadows[index]
        if not line and type(self.pinHost.CreateLine)=="function" then
            local value,ok=M:Call(self.pinHost.CreateLine,self.pinHost,nil,"BACKGROUND")
            if ok then line=value;self.routeLines[index]=line end
        end
        if not shadow and type(self.pinHost.CreateLine)=="function" then
            local value,ok=M:Call(self.pinHost.CreateLine,self.pinHost,nil,"BACKGROUND")
            if ok then shadow=value;self.routeShadows[index]=shadow end
        end
        if not line or type(line.SetStartPoint)~="function" or type(line.SetEndPoint)~="function" or type(line.SetColorTexture)~="function" then return end
        local function paint(value,outline)
            value:SetStartPoint("TOPLEFT",P.canvas,ax*w,-ay*h)
            value:SetEndPoint("TOPLEFT",P.canvas,bx*w,-by*h)
            if outline then value:SetColorTexture(.025,.02,.015,.86)
            elseif active then value:SetColorTexture(.96,.79,.36,.98)
            else value:SetColorTexture(.91,.55,.18,.88) end
            if type(value.SetThickness)=="function" then value:SetThickness((outline and 6 or active and 3.4 or 2.8)/zoom) end
            if type(value.SetDrawLayer)=="function" then value:SetDrawLayer("BACKGROUND",outline and 0 or 1) end
            value:Show()
        end
        local ok=pcall(function() if shadow then paint(shadow,true) end;paint(line,false) end)
        if not ok then line:Hide();if shadow then shadow:Hide() end else self.routeLineCount=index end
    end
    local function link(a,b,active,solid)
        if type(a)~="table" or type(b)~="table" or a.mapID~=mapID or b.mapID~=mapID or
            (a.floorID or a.mapID)~=floorID or (b.floorID or b.mapID)~=floorID or
            not M.map:Valid(mapID,a.x,a.y) or not M.map:Valid(mapID,b.x,b.y) then return end
        local ax,ay,bx,by=a.x,a.y,b.x,b.y
        if icons then ax,ay,bx,by=icons.ClipSegment(ax,ay,bx,by,bounds)
        elseif not M.RecordQuery:Inside(a,bounds) or not M.RecordQuery:Inside(b,bounds) then return end
        if not ax then return end
        if solid then segment(ax,ay,bx,by,active);return end
        local dx,dy=bx-ax,by-ay;local length=math.sqrt((dx*w*zoom)^2+(dy*h*zoom)^2)
        if not M:Number(length) or length<1 then return end
        local maxDashes=math.max(4,math.floor(120/math.max(1,math.min(12,#stops))))
        local count=math.min(40,maxDashes,math.max(1,math.ceil(length/15)))
        for index=0,count-1 do
            local t=index/count;local u=(index+.68)/count
            segment(ax+dx*t,ay+dy*t,ax+dx*u,ay+dy*u,active)
        end
    end
    if leg and leg.precision=="VALIDATED_GRAPH_ROUTE" then
        if leg.geometry=="SOURCE_POLYLINE" and type(leg.polyline)=="table" then
            for index=1,math.min(#leg.polyline-1,31) do link(leg.polyline[index],leg.polyline[index+1],true,true) end
        end
        self.routeLabel=leg.mode=="FLIGHT" and "Flight route" or "Travel route"
        return
    end
    local previous=player
    if #stops>0 then
        for index,stop in ipairs(stops) do
            if index>12 then break end
            link(previous,stop,index==1,false);previous=stop
        end
    elseif target then link(previous,target,true,false) end
end
function P:RefreshLayers(mapID,w,h,cfg,destination)
    self:QualifyLayerStack()
    if M.Catalog then M.Catalog:Refresh(mapID) end
    if M.ExplorationUI then M.ExplorationUI:Refresh(mapID) end
    local query=M.RecordQuery
    query:Ensure(mapID)
    local view=M.MapQuery:Viewport()
    local selected=M.state.utilitySelection
    if selected then
        local current=query.byID[selected.id]
        if current then selected=current
        elseif selected.owner=="MirageIntel_Map" then
            local id=selected.recordID
            selected=(id and not M.Storage.character.hidden[id]) and M.Integration:NoteRecord(M.Storage.account.notes[id]) or nil
        elseif selected.owner and selected.owner~="MirageIntel_Map" then
            local service=M.Integration:Service("WorldRecords")
            local record,ok
            if service then record,ok=M:Call(service.Get,selected.id) end
            if ok and M.Integration:ValidRecord(record) and not record.hidden and record.showWorld~=false then selected=record else selected=nil end
        end
    end
    local routeDestination=destination
    if cfg.showDestinationPin==false then destination=nil end
    local position=M.MapQuery:Player()
    local floorID=position and position.mapID==mapID and (position.floorID or position.mapID) or mapID
    view.floorID=floorID
    local overlay=M.Integration:RouteOverlay()
    local dKey=(routeDestination and table.concat({routeDestination.id,tostring(routeDestination.revision),tostring(routeDestination.navigationRevision),tostring(routeDestination.floorID or routeDestination.mapID)},":") or "none")..":"..tostring(overlay and overlay.revision)
    local sKey=selected and selected.id or "none"
    local viewKey=string.format("%.4f:%.4f:%.4f:%.4f:%.3f",view.left,view.right,view.top,view.bottom,view.scale)
    local positionKey=position and string.format("%d:%d:%.4f:%.4f",position.mapID,position.floorID or position.mapID,position.x,position.y) or "none"
    for layer in pairs(self.layerOwners or {}) do
        if not M.Integration:ClaimLayer(layer) then self:Dirty() end
    end
    if not self.dirty and self.lastMap==mapID and self.lastW==w and self.lastH==h and self.lastView==viewKey and
        self.lastDestination==dKey and self.lastSelected==sKey and self.lastFloor==floorID then
        if M.NativeMarkers then M.NativeMarkers:Refresh(self,mapID,false) end
        if self.lastPosition~=positionKey then self.lastPosition=positionKey;self:RenderBearing(routeDestination,mapID,w,h,cfg,view) end
        -- Coordinate editing has a separate lifetime from map pins. Expiring
        -- feedback and provider readiness must remain live on a cached map,
        -- without rebuilding every marker for each typed character.
        if M.Waypoint and M.Waypoint:NeedsUpdate(mapID) then self:UpdateLegend(mapID,routeDestination,self.paintStatus,cfg) end
        return
    end
    self.dirty=false;self.lastMap=mapID;self.lastW=w;self.lastH=h;self.lastView=viewKey
    self.lastDestination=dKey;self.lastSelected=sKey;self.lastPosition=positionKey;self.lastFloor=floorID
    -- Keep current controls alive through press/release. Navigation updates in
    -- the player's quest zone are frequent; hiding a hovered button here used
    -- to cancel the native click before its OnClick handler could run.
    self:HidePins(true)
    local layers={}
    local nextLeg=M.Integration:GuidanceFor(routeDestination)
    for _,record in ipairs(query.rows) do if query:Inside(record,view) then layers[query:Layer(record)]=true end end
    if destination and destination.mapID==mapID then layers.routes=true end
    if cfg.showRouteBearing~=false and routeDestination and routeDestination.mapID==mapID then layers.routes=true end
    if nextLeg and nextLeg.geometry=="SOURCE_POLYLINE" and nextLeg.from and nextLeg.from.mapID==mapID then layers.routes=true end
    if selected and selected.mapID==mapID then layers[query:Layer(selected)]=true end
    if #M.Integration:RouteStops(mapID)>0 then layers.routes=true end
    local blocked={};local claimed={}
    for layer in pairs(layers) do
        if query:Enabled(layer) and M.Integration:ClaimLayer(layer) then claimed[layer]=true else blocked[layer]=true end
    end
    for layer in pairs(self.layerOwners or {}) do if not claimed[layer] then M.Integration:ReleaseLayer(layer) end end
    self.layerOwners=claimed
    local model,meta=query:PaintModel(mapID,w,h,view,cfg.pinLimit,destination,selected,blocked)
    local used,usedPins,needed={},{},{}
    for _,entry in ipairs(model) do needed[self:ModelKey(entry,mapID)]=true end
    self.clusters=0;self.visible=0;self.sharedVisible=0
    for index,entry in ipairs(model) do
        local pin=self:AcquireLayerPin(self:ModelKey(entry,mapID),needed,usedPins);if not pin then break end
        pin.model=entry;pin.record=entry.record
        local followsLink=M:Integer(entry.record.linkedMapID)
        if pin.followsLink~=followsLink and type(pin.SetPassThroughButtons)=="function" then
            if followsLink then M:Call(pin.SetPassThroughButtons,pin)
            else M:Call(pin.SetPassThroughButtons,pin,"RightButton") end
            pin.followsLink=followsLink
        end
        local layer=entry.role=="destination" and "routes" or query:Layer(entry.record)
        local active=entry.role=="destination" or entry.role=="selected"
        local icons=M.core and M.core.MapIcons
        if icons then pin.hasMarkerArt=icons.Apply(pin.texture,entry.record,entry.landmark and "record" or entry.role)
        else pin.hasMarkerArt=false;pin.texture:SetTexture("Interface\\AddOns\\MirageIntel_Core\\Media\\map") end
        local sizes=icons and icons.sizes
        local size=active and (sizes and sizes.worldActive or 36) or (sizes and sizes.world or 32)
        self.nativeIconSize=size
        local zoom=view.scale or 1
        pin:SetSize(size/zoom,size/zoom)
        pin.halo:SetShown(active)
        pin.glyph:ClearAllPoints()
        if type(pin.glyph.GetFont)=="function" and type(pin.glyph.SetFont)=="function" then
            local file,ok,_,flags=M:Call(pin.glyph.GetFont,pin.glyph)
            if ok and type(file)=="string" then
                M:Call(pin.glyph.SetFont,pin.glyph,file,(entry.role=="cluster" and 14 or 12)/zoom,flags or "")
            end
        end
        if entry.role=="cluster" then
            if entry.landmark then pin.glyph:SetPoint("BOTTOMRIGHT",pin,"BOTTOMRIGHT",3/zoom,-3/zoom)
            else pin.glyph:SetAllPoints(pin) end
            pin.glyph:SetText(#entry.members>99 and "99+" or tostring(#entry.members));pin.glyph:Show()
            self.clusters=self.clusters+1
        elseif entry.record.suggestedStop then
            pin.glyph:SetPoint("BOTTOMRIGHT",pin,"BOTTOMRIGHT",4/zoom,-3/zoom)
            pin.glyph:SetText(tostring(entry.record.suggestedStop));pin.glyph:Show()
        else pin.glyph:SetText("");pin.glyph:Hide() end
        pin.glyph:SetTextColor(.98,.94,.82)
        self:Place(pin,entry,w,h);self.visible=self.visible+1
        -- A pin can be reused or repainted under a stationary pointer without
        -- another OnEnter. Rebind its tooltip to the freshly painted record.
        if pin.hovered then
            M.Integration:HideRecord(pin)
            if pin:IsMouseOver() then pin:refreshHint() else pin.hovered=nil end
        end
        if entry.layers then for name in pairs(entry.layers) do used[name]=true end else used[layer]=true end
        if entry.role=="destination" and entry.record.kind=="gather" and claimed.resources then used.resources=true end
        for _,id in ipairs(entry.members) do
            local record=query.byID[id] or (entry.record.id==id and entry.record)
            self.representedRecords=self.representedRecords+1
            if #self.renderedRecords<80 then self.renderedRecords[#self.renderedRecords+1]={id=id,revision=record and record.revision,sourceRevision=record and record.sourceRevision,
                navigationRevision=entry.role=="destination" and entry.record.navigationRevision or nil,destination=entry.role=="destination",cluster=#entry.members>1}
            end
            if record and record.kind=="gather" then self.sharedVisible=self.sharedVisible+1 end
        end
    end
    for _,pin in ipairs(self.layerPins or {}) do
        if not usedPins[pin] then pin:Hide();pin.model=nil;pin.record=nil;pin.modelKey=nil;pin.press=nil end
    end
    if (routeDestination and routeDestination.mapID==mapID and cfg.showRouteBearing~=false) or (destination and destination.mapID==mapID) or #M.Integration:RouteStops(mapID)>0 or (nextLeg and nextLeg.geometry=="SOURCE_POLYLINE" and nextLeg.from and nextLeg.from.mapID==mapID) then used.routes=true end
    for layer in pairs(claimed) do if not used[layer] then M.Integration:ReleaseLayer(layer);self.layerOwners[layer]=nil end end
    self:RenderBearing(routeDestination,mapID,w,h,cfg,view)
    if M.NativeMarkers then M.NativeMarkers:Refresh(self,mapID,true) end
    self:UpdateLegend(mapID,routeDestination,meta,cfg)
    self.sharedRevision=query.revision;self.sharedStatus=query.status;self.sharedTruncated=query.loading==true
    self.status="MAP_LAYERS_ACTIVE";self.paintStatus=meta
end
