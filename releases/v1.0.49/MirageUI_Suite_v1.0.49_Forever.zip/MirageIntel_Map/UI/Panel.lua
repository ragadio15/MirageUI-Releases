local _,M=...
M.Panel={page="Home",offset=0,mapOnly=true,kind="all",zoneSelected=nil,deletePending=nil,searches={}}
local U=M.Panel
local PAGE={"Home","Places","Notes","Route","Zones","Coverage","Settings"}
local warm=M.colors.secondary
local chrome=M.core and M.core.Chrome
local muted=M.colors.muted
local function fit(frame,requested)
    if not UIParent or M:Combat() then return false end
    local w,wOK=M:Call(UIParent.GetWidth,UIParent)
    local h,hOK=M:Call(UIParent.GetHeight,UIParent)
    local fw,fwOK=M:Call(frame.GetWidth,frame)
    local fh,fhOK=M:Call(frame.GetHeight,frame)
    local state=M.Storage.character
    local saved=type(state)=="table" and state.panel
    local scale=requested or (type(saved)=="table" and saved.scale)
    if not M:Number(scale) or scale<.7 or scale>1.5 then scale=1 end
    if chrome then return chrome.Fit(frame,scale) end
    if wOK and hOK and fwOK and fhOK and M:Number(w) and M:Number(h) and
       M:Number(fw) and M:Number(fh) and w>24 and h>24 and fw>0 and fh>0 then
        scale=math.min(scale,(w-24)/fw,(h-24)/fh)
        frame:SetScale(scale)
        return true
    end
    return false
end
function U:Fit(requested)
    if M:Combat() then return false end
    local fitted=true
    for _,frame in pairs({self.frame,self.editPanel,self.exportPanel}) do
        if not fit(frame,requested) then fitted=false end
    end
    return fitted
end
function U:SetRequestedScale(value)
    if not M:Number(value) or value<.7 or value>1.5 then
        return false,"Use /mmap scale 0.7 through 1.5"
    end
    local writable,reason=M.Storage:Writable()
    if not writable then return false,reason end
    if M:Combat() then return false,"Change window scale outside combat." end
    local previous=M.Storage.character.panel.scale
    if not self:Fit(value) then
        self:Fit(previous)
        return false,"Not enough space to fit the map window."
    end
    if value~=previous then
        M.Storage.character.panel.scale=value
        M.Storage:Touch("character")
    end
    self:Update()
    return true
end
local function label(parent,text,x,y,w,small)
    local t=parent:CreateFontString(nil,"OVERLAY",small and "GameFontHighlightSmall" or "GameFontNormal")
    t:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
    if w then t:SetWidth(w) end
    t:SetJustifyH("LEFT");t:SetJustifyV("TOP")
    t:SetText(text or "")
    if chrome and chrome.Font then chrome.Font(t,small and "small" or "body") end
    return t
end
local function button(parent,text,x,y,w,h,fn)
    if chrome then return chrome.Button(parent,text,x,y,w,h or 25,fn) end
    local b=CreateFrame("Button",nil,parent)
    b:SetSize(w,h or 25)
    b:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
    local bg=b:CreateTexture(nil,"BACKGROUND")
    bg:SetTexture("Interface\\Buttons\\WHITE8x8")
    bg:SetAllPoints(b);bg:SetVertexColor(.15,.17,.19,.93)
    b.fill=bg
    local fs=b:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    fs:SetAllPoints(b);fs:SetJustifyH("CENTER");fs:SetText(text)
    fs:SetTextColor(M.colors.text[1],M.colors.text[2],M.colors.text[3])
    b.title=fs
    b:SetScript("OnClick",fn)
    b:SetScript("OnEnter",function(self)self.fill:SetVertexColor(.28,.29,.28,1)end)
    b:SetScript("OnLeave",function(self)self.fill:SetVertexColor(.15,.17,.19,.93)end)
    return b
end
local function input(parent,x,y,w,initial)
    local e=CreateFrame("EditBox",nil,parent,"InputBoxTemplate")
    e:SetSize(w,22);e:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
    e:SetAutoFocus(false);e:SetMaxLetters(90)
    e:SetText(initial or "")
    if chrome and chrome.Font then chrome.Font(e,"body") end
    e:SetScript("OnEscapePressed",function(self)self:ClearFocus()end)
    return e
end
local function sameRow(a,b)
    if type(a)~="table" or type(b)~="table" then return false end
    for key,value in pairs(a) do if b[key]~=value then return false end end
    for key,value in pairs(b) do if a[key]~=value then return false end end
    return true
end
local function retireRow(button)
    button.rowBinding=nil
    -- A retired press must not become a synthetic click on a recycled row.
    if button.rowPress~=nil then button.rowPress=false end
end
function U:RowBinding(index,mapID)
    local account,character=M.Storage.account,M.Storage.character
    if type(account)~="table" or type(character)~="table" or M.Storage.readOnly then return nil end
    local binding={page=self.page,account=account,character=character,mapOwner=self.mapOwner,mapID=mapID}
    if self.page=="Settings" then
        local def=self.settingRows and self.settingRows[index]
        local legacy={"showMapButton","showCoordinates","showPersonalPins","showDestinationPin","mapPolicy","pinLimit","windowScale"}
        binding.setting=def and def[1] or (not M.RecordQuery and legacy[index])
        if not binding.setting then return nil end
        binding.value=binding.setting=="windowScale" and character.panel.scale or account.settings[binding.setting]
    elseif self.page=="Home" then
        local card=self.homeCards and self.homeCards[index]
        if not card then return nil end
        binding.targetPage=card.page;binding.reference=card.reference;binding.external=card.external
    else
        local record=self.currentRows and self.currentRows[index]
        if not record then return nil end
        for _,key in ipairs({"id","owner","kind","floorID","x","y","index","itemID"}) do binding[key]=record[key] end
        binding.recordMapID=record.mapID
        if self.page=="Route" then binding.liveRoute=self.liveRoute==true end
        if self.page=="Coverage" then
            binding.referenceMode=self.referenceMode;binding.referenceItem=self.referenceItem
        end
    end
    return binding
end
function U:BindRows(mapID)
    self.rowsMapID=mapID
    for index,button in ipairs(self.rows or {}) do
        local binding=button:IsShown() and self:RowBinding(index,mapID) or nil
        if not sameRow(button.rowBinding,binding) then
            retireRow(button);button.rowBinding=binding
        end
    end
end
function U:RowClickAllowed(button,index,mouseButton,pressed)
    if not self.frame or not self.frame:IsShown() or not button:IsShown() or not button:IsEnabled() or
        M:Combat() or not M.state.clientAllowed or M.Storage.readOnly then return false end
    local binding=button.rowBinding
    local current=self:RowBinding(index,M.MapQuery:BrowseMap())
    if not sameRow(binding,current) then return false end
    if pressed~=nil and (pressed==false or pressed.binding~=binding or pressed.mouse~=mouseButton) then return false end
    if self.page=="Notes" or (self.page=="Route" and not self.liveRoute) then
        -- Saved route indexes can move before the next repaint. The displayed
        -- stop must still own its slot before remove, select or reorder runs.
        local note=M.Storage.account.notes[binding.id]
        if not note or note.mapID~=binding.recordMapID or note.x~=binding.x or note.y~=binding.y then return false end
        if self.page=="Route" and M.Storage.character.route.order[binding.index]~=binding.id then return false end
    end
    return true
end
function U:Create()
    if self.frame then return true end
    if not UIParent or M:Combat() then return false end
    local f=CreateFrame("Frame","MirageIntelMapPanel",UIParent,"BackdropTemplate")
    if not f then return false end
    local account=M.Storage.account
    self.kind=(not M.Storage.readOnly and type(account)=="table" and account.settings.kind) or "all"
    f:SetSize(640,626)
    local state=M.Storage.character
    local saved=type(state)=="table" and type(state.panel)=="table" and state.panel or {}
    f:SetPoint("CENTER",UIParent,"CENTER",M:Number(saved.x) and saved.x or 0,
       M:Number(saved.y) and saved.y or 0)
    f:SetFrameStrata("DIALOG");f:SetClampedToScreen(true)
    fit(f)
    f:EnableMouse(true);f:SetMovable(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart",function(self)if not M:Combat() then self:StartMoving()end end)
    f:SetScript("OnDragStop",function(self)
        self:StopMovingOrSizing()
        local x,y
        if type(self.GetCenter)=="function" and type(UIParent.GetCenter)=="function" then
            local fx,fy=self:GetCenter()
            local ux,uy=UIParent:GetCenter()
            if M:Number(fx) and M:Number(fy) and M:Number(ux) and M:Number(uy) then
                local fs,ok=M:Call(self.GetEffectiveScale,self)
                local us,valid=M:Call(UIParent.GetEffectiveScale,UIParent)
                if ok and valid and M:Number(fs) and M:Number(us) and fs>0 and us>0 then
                    x=fx-ux*us/fs;y=fy-uy*us/fs
                end
            end
        end
        if M:Number(x) and M:Number(y) and math.abs(x)<=4000 and math.abs(y)<=4000 and
           not M:Combat() and M.Storage:Writable() then
            self:ClearAllPoints()
            self:SetPoint("CENTER",UIParent,"CENTER",x,y)
            M.Storage.character.panel.x=x;M.Storage.character.panel.y=y
            M.Storage:Touch("character")
        end
    end)
    if chrome then chrome.Panel(f) else
        f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8x8",edgeFile="Interface\\Buttons\\WHITE8x8",edgeSize=1})
        f:SetBackdropColor(.060,.060,.065,.975)
        f:SetBackdropBorderColor(.26,.26,.26,.96)
    end
    self.title=label(f,"Maps",17,-16,290)
    self.title:SetTextColor(warm[1],warm[2],warm[3])
    if chrome and chrome.Heading then chrome.Heading(f,self.title,17,-16,"map") end
    local subtitle=label(f,"Places, routes and map layers",18,-39,405,true)
    if chrome then chrome.Tint(subtitle,"muted") end
    button(f,"Close",559,-13,66,25,function()f:Hide()end)
    self.status=label(f,"",18,-65,602,true)
    if chrome then chrome.OneLine(self.status);chrome.Tint(self.status,"muted") end
    self.tabs={}
    for i,page in ipairs(PAGE) do
        self.tabs[page]=button(f,page=="Coverage" and "Guide" or page,18+(i-1)*86,-91,80,26,function()
            U.page=page;U.offset=0;U.deletePending=nil;U:Update()
        end)
    end
    self.heading=label(f,"",19,-133,602)
    self.heading:SetTextColor(warm[1],warm[2],warm[3])
    self.details=label(f,"",19,-158,602,true)
    self.routeViewButton=button(f,"Saved route",436,-128,185,25,function()
        U.routeView=U.routeView=="saved" and "upcoming" or "saved"
        U.offset=0;U:Update()
    end)
    self.routeViewButton:Hide()
    self.routeUp=button(f,"Move up",20,-184,108,25,function() U:EditRouteStop("up") end)
    self.routeDown=button(f,"Move down",137,-184,108,25,function() U:EditRouteStop("down") end)
    self.routeRemove=button(f,"Remove stop",254,-184,126,25,function() U:EditRouteStop("remove") end)
    self.routeUp:Hide();self.routeDown:Hide();self.routeRemove:Hide()
    self.searchTitle=label(f,"Search",19,-184,76,true)
    self.search=input(f,85,-179,340,"")
    self.search:SetScript("OnEnterPressed",function(self)self:ClearFocus();U.offset=0;U:Update()end)
    self.search:SetScript("OnTextChanged",function()
        if U.syncingSearch then return end
        U.offset=0;U.clusterMembers=nil
        U.searches[U:SearchKey()]=U.search:GetText()
        if U.page=="Places" and M.RecordQuery then U:ApplyPlaceSearch() end
        U:Update()
    end)
    self.resourceGuide=button(f,"Resource guide",436,-179,185,25,function()
        if U.ToggleResourceGuide then U:ToggleResourceGuide() end
    end)
    self.resourceGuide:Hide()
    self.category=button(f,"Type: All",436,-179,185,25,function()
        local kinds={"all","note","travel","quest","resource","danger"}
        local index=1
        for i,v in ipairs(kinds) do if v==U.kind then index=i end end
        U.kind=kinds[index%#kinds+1];U.offset=0
        local ok,why=M.Storage:SetSetting("kind",U.kind)
        if not ok then M:Print(M:UserMessage(why)) end
        U:Update()
    end)
    self.nameTitle=label(f,"New note",19,-220,80,true)
    self.name=input(f,94,-215,330,"")
    self.scopeButton=button(f,"This map",437,-215,184,25,function()
        U.mapOnly=not U.mapOnly;U.offset=0;U:Update()
    end)
    self.coordsTitle=label(f,"Coordinates %",19,-253,95,true)
    self.xTitle=label(f,"X",117,-254,15,true)
    self.x=input(f,134,-249,54,"")
    self.yTitle=label(f,"Y",192,-254,15,true)
    self.y=input(f,209,-249,54,"")
    self.addHere=button(f,"Save here",279,-248,164,25,function()
        local name=M:Text(U.name:GetText(),72) or "My location"
        local kind=U.kind~="all" and U.kind or "note"
        local ok,why=M.API:PinHere(name,kind)
        U:Respond(ok,why)
    end)
    self.addCoords=button(f,"Save X/Y",453,-248,168,25,function()
        local name=M:Text(U.name:GetText(),72) or "Map note"
        local kind=U.kind~="all" and U.kind or "note"
        local ok,why=M.API:PinCoordinates(tonumber(U.x:GetText()),tonumber(U.y:GetText()),name,kind)
        U:Respond(ok,why)
    end)
    if M.RecordQuery then self:CreatePlaceControls(f,label,input,button) end
    self.rows={}
    for i=1,7 do
        local item=button(f,"",20,-292-(i-1)*36,600,32,function(self,mouseButton)
            if not U:RowClickAllowed(self,i,mouseButton,self.rowPress) then self.rowPress=false;return end
            self.rowPress=nil
            if U.page=="Settings" then U:SettingsRowClick(i);return end
            if U.page=="Home" then
                if M.Explorer then M.Explorer:HomeAction(U,i) end
                return
            end
            if U.page=="Coverage" then
                if U.referenceMode and U.ResourceRowClick then U:ResourceRowClick(i) end
                return
            end
            if U.page=="Notes" and mouseButton=="RightButton" then
                local r=U.currentRows and U.currentRows[i]
                if r then U:EditPopup(r.id) end
                return
            end
            if U.page=="Route" and U.liveRoute then
                local row=U.currentRows and U.currentRows[i]
                if row then M.Integration:SelectRecord(row,U.mapOwner) end
                return
            end
            if U.page=="Route" and mouseButton=="RightButton" then
                local r=U.currentRows and U.currentRows[i]
                if r then U:Respond(M.Storage:RouteRemove(r.index)) end
                return
            end
            local r=U.currentRows and U.currentRows[i]
            if not r then return end
            if U.page=="Places" then
                M.state.utilitySelection=M.core.Copy(r)
                if M.Inspector then M.Inspector:Open(r,U.mapOwner) end
            elseif U.page=="Zones" then U.zoneSelected=r.mapID
            elseif U.page=="Route" then
                if IsShiftKeyDown and IsShiftKeyDown() then
                    local target=r.index-1
                    if target>=1 then U:Respond(M.Storage:RouteMove(r.index,target)) end
                    return
                end
                M.Storage:RouteSelect(r.index)
            else M.state.selection=r.id end
            U.deletePending=nil;U:Update()
        end)
        item.title:SetJustifyH("LEFT")
        if chrome and chrome.Font then chrome.Font(item.title,"body") end
        item.title:SetWordWrap(true)
        if item.title.SetMaxLines then item.title:SetMaxLines(2) end
        item:RegisterForClicks("LeftButtonUp","RightButtonUp")
        item:HookScript("OnMouseDown",function(self,mouseButton)
            self.rowPress=U:RowClickAllowed(self,i,mouseButton) and {binding=self.rowBinding,mouse=mouseButton} or false
        end)
        item:HookScript("OnEnter",function(self)
            if self.utilityRecord then M.Integration:ShowRecord(self,self.utilityRecord,
                {purpose=self.utilityRecord.purpose,hint="Select this place, then choose Navigate."})
            elseif self.detailText and GameTooltip then
                GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
                GameTooltip:AddLine(self.detailText,.90,.89,.87,true);GameTooltip:Show()
            end
        end)
        local function release(self)
            M.Integration:HideRecord(self)
            if GameTooltip and GameTooltip.IsOwned and GameTooltip:IsOwned(self) then GameTooltip:Hide() end
        end
        item:HookScript("OnLeave",release)
        item:HookScript("OnHide",function(self)retireRow(self);release(self)end)
        self.rows[i]=item
    end
    self.previous=button(f,"Previous",20,-550,84,24,function()
        U.offset=math.max(0,U.offset-7);U:Update()
    end)
    self.next=button(f,"Next",113,-550,76,24,function()
        U.offset=U.offset+7;U:Update()
    end)
    self.pager=label(f,"",202,-554,418,true)
    self.action1=button(f,"Open map",20,-587,141,23,function()U:Action(1)end)
    self.action2=button(f,"Navigate",173,-587,141,23,function()U:Action(2)end)
    self.action3=button(f,"Add to route",326,-587,141,23,function()U:Action(3)end)
    self.action4=button(f,"Settings",479,-587,141,23,function()U:Action(4)end)
    f:HookScript("OnHide",function()
        for _,row in ipairs(U.rows) do retireRow(row) end
    end)
    if chrome then chrome.Escape(f) end
    f:Hide();self.frame=f
    if M.Explorer then M.Explorer:Create(self,label,button) end
    return true
end
function U:SearchKey()
    if self.page=="Coverage" then return "Resources" end
    return self.page
end
function U:ApplyPlaceSearch()
    if not M.RecordQuery then return false end
    local ok,why=M.RecordQuery:SetSearch(self.search:GetText(),self.material and self.material:GetText() or "")
    self.searchError=not ok and why or nil
    if ok then
        self.syncingSearch=true
        if self.search:GetText()~=M.RecordQuery.search then self.search:SetText(M.RecordQuery.search) end
        if self.material and self.material:GetText()~=M.RecordQuery.material then self.material:SetText(M.RecordQuery.material) end
        self.syncingSearch=false
        self.searches.Places=M.RecordQuery.search
    end
    return ok,why
end
function U:SyncSearch()
    local key=self:SearchKey()
    if self.searchContext==key then return end
    if self.searchContext and self.search then self.searches[self.searchContext]=self.search:GetText() end
    self.searchContext=key
    local value=self.searches[key] or ""
    if key=="Places" and self.searches[key]==nil and M.RecordQuery then value=M.RecordQuery.search or "" end
    self.syncingSearch=true;self.search:SetText(value);self.syncingSearch=false
    if key=="Places" and M.RecordQuery then self:ApplyPlaceSearch() end
    if self.choiceMenu then self.choiceMenu:Hide() end
    if key~="Places" and M.Explorer then M.Explorer:CancelDistance(self) end
end
function U:Respond(ok,reason)
    if ok then
        M:Print(type(reason)=="number" and "Saved note #"..reason or "Updated successfully")
    else
        M:Print(M:UserMessage(reason))
    end
    self:Update()
end
function U:Open(origin)
    if M:Combat() or not self:Create() then return false,"Open Maps after combat." end
    if fit(self.frame)==false then return false,"Not enough space to open this panel." end
    self.mapOwner=M.MapQuery:BindWindow(self.frame,origin)
    if M.Inspector and M.Inspector.frame then M.Inspector.returnToPanel=false;M.Inspector.frame:Hide() end
    self.frame:Show();self:RefreshData(true);self:Update()
    return true
end
function U:SelectedNote()
    local s=M.Storage.account
    return type(s)=="table" and type(s.notes)=="table" and s.notes[M.state.selection] or nil
end
local PAGE_SIZE=7
function U:ClampPage(total)
    local last=math.floor(math.max(0,total-1)/PAGE_SIZE)*PAGE_SIZE
    self.offset=math.min(last,math.max(0,self.offset))
end
function U:PageRows(all)
    self:ClampPage(#all)
    local rows={}
    for i=self.offset+1,math.min(self.offset+PAGE_SIZE,#all) do rows[#rows+1]=all[i] end
    return rows
end
function U:ShowRows(rows,total)
    self.currentRows=rows
    for i,button in ipairs(self.rows) do
        local record=rows[i]
        local previous=button.utilityRecord
        local previousDetail=button.detailText
        button.utilityRecord=nil
        button.detailText=nil
        if record then
            local text=""
            if self.page=="Places" then
                local selected=M.state.utilitySelection
                text=string.format("%s%s  ·  %s  ·  %.1f, %.1f",selected and selected.id==record.id and "› " or "  ",
                    record.label,record.destination and "destination" or record.category or record.kind,record.x*100,record.y*100)
                button.utilityRecord=record
            elseif self.page=="Notes" then
                local selected=(M.state.selection==record.id) and "› " or "  "
                text=string.format("%s%s  ·  %s  ·  %.1f, %.1f",selected,
                    record.label,record.kind,record.x*100,record.y*100)
                button.utilityRecord=M.Integration:NoteRecord(record)
            elseif self.page=="Route" then
                local cursor=self.liveRoute and 1 or M.Storage.character.route.cursor
                text=string.format("%s %d.  %s  ·  %.1f, %.1f",record.index==cursor and "›" or " ",
                    record.index,record.label,record.x*100,record.y*100)
                if self.liveRoute then button.utilityRecord=record
                else button.utilityRecord=M.Integration:NoteRecord(M.Storage.account.notes[record.id]) end
            elseif self.page=="Zones" then
                text=(self.zoneSelected==record.mapID and "› " or "  ")..record.name.."  ["..record.mapID.."]"
            elseif self.page=="Coverage" then
                text=record.label.."\n"..(record.state or "REFERENCE")
                button.detailText=record.label.."\n"..(record.detail or "").."\n"..""
            end
            button.detailText=button.detailText or text
            local nextRecord=button.utilityRecord
            if previous and (not nextRecord or previous.id~=nextRecord.id or previous.revision~=nextRecord.revision or
                previous.sourceRevision~=nextRecord.sourceRevision) then M.Integration:HideRecord(button) end
            if previousDetail~=button.detailText and GameTooltip and GameTooltip.IsOwned and GameTooltip:IsOwned(button) then GameTooltip:Hide() end
            button.title:SetText(text);button:Show()
        else button:Hide() end
    end
    self.pager:SetText((total or 0).." results  ·  "..(total==0 and 0 or self.offset+1).."–"..
        math.min(total or 0,self.offset+7).."")
    self.previous:SetEnabled(self.offset>0)
    self.next:SetEnabled(self.offset+7<(total or 0))
    self:BindRows(M.MapQuery:BrowseMap())
end
function U:FindNotes()
    local query={kind=self.kind,search=self.search:GetText()}
    if self.mapOnly then
        query.mapID=M.MapQuery:BrowseMap()
        if not query.mapID then self.offset=0;return {},0,"NO_CURRENT_MAP" end
    end
    local from=self.offset
    local list,total=M.Storage:List(query,PAGE_SIZE,from)
    self:ClampPage(total)
    if self.offset~=from and total>0 then list,total=M.Storage:List(query,PAGE_SIZE,self.offset) end
    return list,total
end
function U:UpdateHome()
    if M.Explorer then return M.Explorer:Home(self) end
    local p=M.MapQuery:Player()
    local mapID=M.MapQuery:BrowseMap()
    local route=M.Storage:RouteSnapshot()
    local g=M.Integration:Gather()
    self.heading:SetText("Exploration overview")
    self.details:SetText("Save places, plan stops or browse zones.")
    local lines={
        "Current zone: "..(p and (M.MapQuery:Name(p.mapID) or "Map #"..p.mapID) or "location unavailable"),
        "Position: "..(p and string.format("%.1f, %.1f",p.x*100,p.y*100) or "—"),
        "Viewing: "..(mapID and (M.MapQuery:Name(mapID) or "Map #"..mapID) or "Open world map first"),
        "Personal notes: "..tostring(M.state.noteCount or 0).."  ·  Route steps: "..#route.rows,
        "Gathering spots: "..(g and "Recorded locations in Places" or "Install Gather Mate"),
        "Selected destination: "..(M.Integration:CurrentDestination() and "Wayfinder" or "No located destination"),
        "Map overlays: "..(M.Integration:AllowMapOverlay() and "On" or "Off"),
        ""
    }
    if M.ZoneGuide and mapID and M.Storage.account.settings.showZoneGuide~=false then lines[7]=M.ZoneGuide:Summary(mapID) end
    if self.renderedPage~=self.page then
        self:ShowRows({},0);self.renderedPage=self.page
    end
    self.homeLines=lines
    for i=1,7 do
        self.rows[i]:Show();self.rows[i].title:SetText(lines[i] or "");self.rows[i].detailText=lines[i]
    end
    self.pager:SetText(lines[8])
    self.action1.title:SetText("Open map");self.action2.title:SetText("Wayfinder");
    self.action3.title:SetText("Gather Mate");self.action4.title:SetText("Settings")
    self.action2:SetEnabled(M.state.clientAllowed and M.Integration:Navigate()~=nil)
    self.action3:SetEnabled(M.state.clientAllowed and g~=nil)
end
function U:UpdateCoverage()
    self.referenceMode=self.referenceMode or "materials"
    if self.UpdateResources then self:UpdateResources();return end
    self.heading:SetText("Resource guide");self.details:SetText("Choose a resource to browse its regions.")
    self:ShowRows({},0)
end
function U:UpdatePlaces()
    if M.RecordQuery then return self:UpdateSharedPlaces() end
    self.heading:SetText("Shared places")
    local selected=M.state.utilitySelection
    self.details:SetText(selected and ("Selected: "..selected.label.." · choose Navigate to set a destination.") or
        "Recorded gathering spots and your destination. Select a place to navigate.")
    local mapID=M.MapQuery:BrowseMap()
    local rows,meta={},{}
    if mapID then rows,meta=M.Integration:GatherRecords(mapID,64) end
    local destination=M.Integration:CurrentDestination()
    local all,seen={},{}
    local search=M:Text(self.search:GetText(),72)
    search=search and string.lower(search)
    local function add(record)
        if record and not seen[record.id] and (not search or string.find(string.lower(record.label),search,1,true)) then
            seen[record.id]=true;all[#all+1]=record
        end
    end
    if destination and destination.mapID==mapID then add(destination) end
    for _,record in ipairs(rows) do add(record) end
    self:ShowRows(self:PageRows(all),#all)
    self.pager:SetText(meta.nextCursor and "First 64 matching places" or (#all.." places"))
    self.action1.title:SetText("Open map");self.action2.title:SetText("Navigate")
    self.action3.title:SetText("Wayfinder");self.action4.title:SetText("Clear selection")
    self.action2:SetEnabled(M.state.clientAllowed and selected~=nil and M.Integration:Navigate()~=nil)
    self.action3:SetEnabled(M.state.clientAllowed and M.Integration:Navigate()~=nil)
end
function U:UpdateNotes()
    self.heading:SetText("Personal notes")
    self.details:SetText("Amber note · Teal travel · Green resource · Red caution · Right-click to edit.")
    local list,total,why=self:FindNotes();self:ShowRows(list,total)
    local r=self:SelectedNote()
    local first=total>0 and self.offset+1 or 0
    self.pager:SetText(string.format("%d–%d of %d  ·  %s",first,math.min(total,self.offset+PAGE_SIZE),
        total,r and ("Selected #"..r.id) or "Select a note"))
    if why=="NO_CURRENT_MAP" then self.pager:SetText("Open the world map or select All maps.") end
    self.action1.title:SetText("Cursor note");self.action2.title:SetText("Navigate")
    self.action3.title:SetText("Add to route");self.action4.title:SetText("Delete note")
end
function U:UpdateRoute()
    local overlay=M.Integration:RouteOverlay()
    local stops=overlay and overlay.stops or {}
    self.liveRoute=self.routeView~="saved"
    self.routeViewButton.title:SetText(self.routeView=="saved" and "Upcoming stops" or "Saved route")
    if self.liveRoute then
        self.heading:SetText("Your upcoming stops")
        self.details:SetText(#stops>0 and "Wayfinder updates your route as you play. Select a stop for details." or
            "Open Wayfinder to choose your next destination.")
        local rows={}
        for i,stop in ipairs(stops) do
            local row=M.core.Copy(stop);row.index=i;row.suggestedStop=i;row.purpose="ROUTE_STOP"
            rows[#rows+1]=row
        end
        self:ShowRows(self:PageRows(rows),#rows)
        self.action1.title:SetText("Wayfinder");self.action2.title:SetText("Skip stop")
        self.action3.title:SetText("Pause");self.action4.title:SetText("Open map")
        self.action1:SetEnabled(M.state.clientAllowed and M.Integration:Navigate()~=nil)
        self.action2:SetEnabled(M.state.clientAllowed and #stops>0)
        self.action3:SetEnabled(M.state.clientAllowed and #stops>0)
    else
        self.heading:SetText("Saved route")
        self.details:SetText("Select a stop to change its order. Start the route when you're ready.")
        local all=M.Storage:RouteSnapshot();self:ShowRows(self:PageRows(all.rows),#all.rows)
        self.action1.title:SetText("Start route");self.action2.title:SetText("Next stop")
        self.action3.title:SetText("Restart");self.action4.title:SetText("Clear route")
    end
    local saved=not self.liveRoute
    local route=M.Storage.character.route
    self.routeUp:SetShown(saved);self.routeDown:SetShown(saved);self.routeRemove:SetShown(saved)
    self.routeUp:SetEnabled(saved and route.cursor>1)
    self.routeDown:SetEnabled(saved and route.cursor>0 and route.cursor<#route.order)
    self.routeRemove:SetEnabled(saved and route.cursor>0)
end
function U:EditRouteStop(action)
    if self.page~="Route" or self.liveRoute or M:Combat() then return end
    local route=M.Storage.character and M.Storage.character.route
    if not route or route.cursor==0 then return end
    if action=="remove" then self:Respond(M.Storage:RouteRemove(route.cursor))
    elseif action=="up" then self:Respond(M.Storage:RouteMove(route.cursor,route.cursor-1))
    elseif action=="down" then self:Respond(M.Storage:RouteMove(route.cursor,route.cursor+1)) end
end
function U:UpdateZones()
    self.heading:SetText("Zone browser")
    self.details:SetText("Select a zone to explore its map.")
    local mapID=M.MapQuery:BrowseMap()
    local all=M.MapQuery:Children(mapID,self.search:GetText(),150)
    self:ShowRows(self:PageRows(all),#all)
    if M.ZoneGuide and mapID and M.Storage.account.settings.showZoneGuide~=false then self.details:SetText(M.ZoneGuide:Summary(mapID)) end
    self.action1.title:SetText("Open map")
    self.action2.title:SetText("View selected")
    self.action3.title:SetText("This map")
    self.action4.title:SetText("Notes")
end
function U:GatherLayer()
    local g=M.Integration:Gather()
    if type(g)~="table" or type(g.GetStatus)~="function" or type(g.SetPreference)~="function" then return nil end
    local status,valid=M:Call(g.GetStatus)
    local prefs=valid and type(status)=="table" and status.preferences
    if type(prefs)=="table" and type(prefs.showMapPins)=="boolean" then return g,prefs.showMapPins end
end
function U:UpdateSettings()
    if M.RecordQuery then return self:UpdateLayerSettings() end
    self.heading:SetText("Map layers and display")
    local p=M.Storage.account.settings
    self.details:SetText("Choose the details you want to see on your map.")
    local rows={
      "World-map shortcut   "..(p.showMapButton and "ON" or "OFF"),
      "Coordinates on Map+ hover   "..(p.showCoordinates and "ON" or "OFF"),
      "Personal note pins   "..(p.showPersonalPins and "ON" or "OFF"),
      "Selected destination pin   "..(p.showDestinationPin and "ON" or "OFF"),
      "Map+ overlays   "..(p.mapPolicy=="off" and "OFF" or "ON"),
      "Maximum visible markers   "..p.pinLimit,
      "Window scale   "..math.floor(M.Storage.character.panel.scale*100+0.5).."%"
    }
    for i,b in ipairs(self.rows) do b.title:SetText(rows[i]);b:Show()end
    self.currentRows={};self.pager:SetText("Click a row to toggle the corresponding setting")
    self.action1.title:SetText("Open map")
    local gather,shown=self:GatherLayer()
    self.action2:SetEnabled(M.state.clientAllowed and gather~=nil)
    self.action2.title:SetText(gather and (shown and "Hide gather pins" or "Show gather pins") or "Gather unavailable")
    self.action3.title:SetText("Wayfinder");self.action4.title:SetText("Gather Mate")
end
function U:UpdateContent()
    if not self.frame or not self.frame:IsShown() then return end
    local account=M.Storage.account
    if self.settingsDecorated and self.page~="Settings" then
        if chrome then
            if chrome.CloseChoices then chrome.CloseChoices() end
            for _,b in ipairs(self.rows) do chrome.Active(b,false) end
            for i=1,4 do chrome.Active(self["action"..i],false) end
        end
        self.settingsDecorated=nil
    end
    local ready=type(account)=="table" and not M.Storage.readOnly
    for _,button in pairs(self.tabs) do button:SetEnabled(not not ready) end
    for _,button in ipairs({self.action1,self.action2,self.action3,self.action4,self.addHere,self.addCoords}) do
        button:SetEnabled(not not ready and M.state.clientAllowed)
    end
    if not ready then
        if self.choiceMenu then self.choiceMenu:Hide() end
        if self.sortButton then self.sortButton:Hide() end
        if self.emptyHeading then self.emptyHeading:Hide();self.emptyDetail:Hide() end
        if self.resourceGuide then self.resourceGuide:Hide() end
        if self.routeViewButton then self.routeViewButton:Hide();self.routeUp:Hide();self.routeDown:Hide();self.routeRemove:Hide() end
        for _,control in ipairs(self.placeControls or {}) do control:Hide() end
        self.status:SetText("Saved data needs recovery. No changes made.")
        self.heading:SetText("Map notes unavailable")
        self.details:SetText("Your saved notes and routes were left untouched.")
        self.pager:SetText("")
        self.previous:Disable();self.next:Disable()
        for _,control in ipairs({self.searchTitle,self.search,self.category,self.nameTitle,self.name,
             self.scopeButton,self.coordsTitle,self.x,self.y,self.xTitle,self.yTitle,self.addHere,self.addCoords}) do
            control:Hide()
        end
        for _,b in ipairs(self.rows) do b:Hide() end
        return
    end
    local mapID=M.MapQuery:BrowseMap()
    self:SyncSearch()
    local title=mapID and (M.MapQuery:Name(mapID) or "Map "..mapID) or "World map not open"
    self.status:SetText(M.state.clientAllowed and title or "This client build is not supported.")
    self.routeViewButton:SetShown(self.page=="Route")
    self.routeViewButton:SetEnabled(M.state.clientAllowed)
    if self.page~="Route" then self.routeUp:Hide();self.routeDown:Hide();self.routeRemove:Hide() end
    for page,b in pairs(self.tabs) do
        b.title:SetText(page=="Coverage" and "Guide" or page)
        if chrome then chrome.Active(b,page==self.page)
        else b.title:SetTextColor(page==self.page and warm[1] or .87,
             page==self.page and warm[2] or .84,page==self.page and warm[3] or .81) end
    end
    local normal=self.page=="Notes" or self.page=="Zones" or self.page=="Places" or
        (self.page=="Coverage" and self.referenceMode=="materials")
    self.searchTitle:SetShown(normal)
    self.search:SetShown(normal)
    if self.resourceGuide then
        self.resourceGuide:SetShown(self.page=="Coverage" and self.UpdateResources~=nil)
        self.resourceGuide.title:SetText("Materials / fishing")
        self.resourceGuide:SetEnabled(M.state.clientAllowed)
    end
    self.category:SetShown(self.page=="Notes")
    self.nameTitle:SetShown(self.page=="Notes")
    self.name:SetShown(self.page=="Notes")
    self.scopeButton:SetShown(self.page=="Notes")
    self.coordsTitle:SetShown(self.page=="Notes")
    self.x:SetShown(self.page=="Notes")
    self.y:SetShown(self.page=="Notes")
    self.xTitle:SetShown(self.page=="Notes")
    self.yTitle:SetShown(self.page=="Notes")
    self.addHere:SetShown(self.page=="Notes")
    self.addCoords:SetShown(self.page=="Notes")
    self.category:SetEnabled(M.state.clientAllowed)
    self.category.title:SetText("Type: "..self.kind)
    self.scopeButton.title:SetText(self.mapOnly and "This map" or "All maps")
    for _,control in ipairs(self.placeControls or {}) do control:SetShown(self.page=="Places") end
    if self.renderedPage~=self.page then
        self:ShowRows({},0);self.renderedPage=self.page
    end
    if self.page=="Home" then self:UpdateHome()
    elseif self.page=="Places" then self:UpdatePlaces()
    elseif self.page=="Notes" then self:UpdateNotes()
    elseif self.page=="Route" then self:UpdateRoute()
    elseif self.page=="Zones" then self:UpdateZones()
    elseif self.page=="Coverage" then self:UpdateCoverage()
    elseif self.page=="Settings" then self:UpdateSettings() end

    local start,step,height=292,36,32
    if self.page=="Home" or self.page=="Settings" then start,step,height=204,44,40
    elseif self.page=="Coverage" then start,step,height=210,44,40
    elseif self.page=="Zones" then start,step,height=229,44,40
    elseif self.page=="Route" then start,step,height=self.liveRoute and 204 or 229,44,40 end
    for i,b in ipairs(self.rows) do
        b:ClearAllPoints();b:SetPoint("TOPLEFT",self.frame,"TOPLEFT",20,-start-(i-1)*step);b:SetHeight(height)
    end
    if M.Explorer then M.Explorer:Paint(self) end
    self:BindRows(mapID)
end
function U:RefreshData(force)
    if not self.frame or not self.frame:IsShown() or M:Combat() or not M.state.clientAllowed then return end
    local mapID=M.MapQuery:BrowseMap();local now=M:Now()
    if not force and mapID==self.dataMapID and now-(self.lastDemand or -10)<1 then return end
    local changed=mapID~=self.dataMapID
    self.dataMapID=mapID;self.lastDemand=now
    if changed then
        self.clusterMembers=nil;self.offset=0;self.dirty=true
        if M.state.utilitySelection and M.state.utilitySelection.mapID~=mapID then M.state.utilitySelection=nil end
    end
    if mapID then
        if M.Catalog then M.Catalog:Refresh(mapID) end
        if M.RecordQuery then M.RecordQuery:Ensure(mapID) end
    end
end
function U:Update()
    if not self.frame or not self.frame:IsShown() then return end
    if self.updating then self.dirty=true;return end
    self.updating=true;self.dirty=false
    local ok=pcall(self.UpdateContent,self)
    self.updating=false
    if not ok then M:Fault("MAP_PANEL_REFRESH_FAILED") end
end
function U:Tick()
    if not self.frame or not self.frame:IsShown() then return end
    self:RefreshData(false)
    if M.Explorer then M.Explorer:Tick(self) end
    if self.dirty then self:Update() end
end
function U:GetStatus()
    return {page=self.page,shown=self.frame and self.frame:IsShown() or false,
        mapID=self.dataMapID,requestedScale=M.Storage.character and M.Storage.character.panel and M.Storage.character.panel.scale,
        panelRefresh="VISIBLE_PANEL_OR_NATIVE_MAP",inspectorLayout="EXCLUSIVE_WITH_RETURN_TO_LIST",
        windowLifetime=self.mapOwner and "WORLD_MAP_COMPANION" or "INDEPENDENT",
        coverage=M.Coverage~=nil,localeText="UTF8_PRESERVED_NATIVE_FONT; ENGLISH_UI",
        explorer=M.Explorer and {searches="ISOLATED_PER_VIEW",sort=self.placeSort or "relevance",
            distanceStatus=self.nearest and self.nearest.loading and "COOPERATIVE_MEASUREMENT" or self.sortHint,
            distanceChunk=16,rowPool=7,filterReset="ATOMIC_WITH_SESSION_UNDO"} or nil}
end
function U:Action(which)
    if M.Storage.readOnly or not M.state.clientAllowed then return end
    if M:Combat() then self:Respond(false,"Use map actions outside combat.");return end
    local note=self:SelectedNote()
    local ok,why
    if self.page=="Places" then
        if M.RecordQuery then self:SharedPlaceAction(which);return end
        if which==1 then ok,why=M.MapQuery:OpenMap()
        elseif which==2 then ok,why=M.Integration:NavigateRecord(M.state.utilitySelection)
        elseif which==3 then
            local nav=M.Integration:Navigate()
            if nav and type(nav.Open)=="function" then ok,why=nav.Open() else ok,why=false,"NAVIGATE_NOT_INSTALLED" end
        else M.state.utilitySelection=nil;ok=true;why="SELECTION_CLEARED" end
    elseif self.page=="Notes" then
        if which==1 then
            ok,why=M.API:PinCursor(M:Text(self.name:GetText(),72) or "Map cursor",self.kind~="all" and self.kind or "note")
        elseif which==2 then
            if note then ok,why=M.API:Select(note.id) else ok,why=false,"SELECT_NOTE_FIRST" end
        elseif which==3 then
            if note then ok,why=M.Storage:RouteAdd(note.id) else ok,why=false,"SELECT_NOTE_FIRST" end
        else
            if not note then ok=false;why="SELECT_NOTE_FIRST"
            elseif self.deletePending==note.id and M:Now()<self.deleteUntil then
                ok,why=M.Storage:Delete(note.id,true)
                if ok then M.state.selection=nil end
                self.deletePending=nil
            else
                self.deletePending=note.id;self.deleteUntil=M:Now()+8
                ok=false;why="Press Delete note again within 8 seconds to confirm"
            end
        end
    elseif self.page=="Route" then
        if self.liveRoute then
            local nav=M.Integration:Navigate()
            if which==1 and nav and nav.Open then nav.Open()
            elseif which==2 and nav and nav.SkipDestination then nav.SkipDestination()
            elseif which==3 and nav and nav.Pause then nav.Pause()
            elseif which==4 then M.MapQuery:OpenMap() end
            self:Update();return
        end
        if which==1 then ok,why=M.API:RouteNavigate()
        elseif which==2 then
            ok,why=M.Storage:RouteNext()
            if ok then local navOK,navWhy=M.API:RouteNavigate();if not navOK then M:Print(M:UserMessage(navWhy)) end end
        elseif which==3 then ok,why=M.Storage:RouteReset()
        else ok,why=M.Storage:RouteClear() end
    elseif self.page=="Zones" then
        if which==1 then ok,why=M.MapQuery:OpenMap()
        elseif which==2 then
            ok,why=M.MapQuery:OpenMap()
            if ok then ok,why=M.MapQuery:GoToMap(self.zoneSelected) end
        elseif which==3 then self.page="Notes";self.mapOnly=true;self.offset=0;ok=true
        else self.page="Notes";self.offset=0;ok=true end
    elseif self.page=="Coverage" then
        if self.referenceMode and self.ResourceAction then self:ResourceAction(which);return end
        if which==1 then ok,why=M.MapQuery:OpenMap()
        elseif which==2 then self.page="Places";self.offset=0;self:Update();return
        elseif which==3 then
            local handler=SlashCmdList and SlashCmdList.MIRAGEUTILITYCORE
            if type(handler)=="function" then handler("report");return end
            ok,why=false,"Utility report unavailable"
        else
            local g=M.Integration:Gather()
            if g and type(g.Open)=="function" then ok,why=g.Open() else ok,why=false,"GATHER_NOT_INSTALLED" end
        end
    elseif self.page=="Settings" then
        if M.RecordQuery then if chrome and chrome.CloseChoices then chrome.CloseChoices() end;self.settingGroup=which;self.offset=0;self:Update();return end
        if which==1 then ok,why=M.MapQuery:OpenMap()
        elseif which==2 then
            if M.RecordQuery then self.page="Places";self.offset=0;self:Update();return end
            local g,shown=self:GatherLayer()
            if g then
                local good,accepted,reason=pcall(g.SetPreference,"showMapPins",not shown)
                ok=good and accepted==true
                why=good and reason or "GATHER_SETTINGS_UNAVAILABLE"
            else ok=false;why="GATHER_SETTINGS_UNAVAILABLE" end
        elseif which==3 then
            local nav=M.Integration:Navigate();if nav and nav.Open then nav.Open() end;return
        else
            local gather=M.Integration:Gather();if gather and gather.Open then gather.Open() end;return end
    else
        if which==1 then ok,why=M.MapQuery:OpenMap()
        elseif which==2 then
            local a=M.Integration:Navigate()
            if a and type(a.Open)=="function" then ok,why=a.Open()
            else ok,why=false,"NAVIGATE_NOT_INSTALLED" end
        elseif which==3 then
            local g=M.Integration:Gather()
            if g and type(g.Open)=="function" then ok,why=g.Open()
            else ok,why=false,"GATHER_NOT_INSTALLED" end
        else self.page="Settings";self.offset=0;self:Update();return end
    end
    self:Respond(ok,why)
end
function U:EditPopup(id)
    if M.Storage.readOnly or not M.state.clientAllowed then return end
    if M:Combat() then M:Print("Edit notes outside combat.");return end
    local note=M.Storage.account and M.Storage.account.notes and M.Storage.account.notes[id]
    if not note then M:Print("Note not found.");return end
    if not self.editPanel then
        local f=CreateFrame("Frame","MirageIntelMapNoteEditor",UIParent,"BackdropTemplate")
        f:SetSize(420,221);f:SetPoint("CENTER",UIParent,"CENTER",0,140)
        f:SetFrameStrata("FULLSCREEN_DIALOG");f:SetClampedToScreen(true)
        if chrome then chrome.Panel(f) else
            f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8x8",edgeFile="Interface\\Buttons\\WHITE8x8",edgeSize=1})
            f:SetBackdropColor(.060,.060,.065,.98);f:SetBackdropBorderColor(.26,.26,.26,1)
        end
        self.editTitle=label(f,"Edit map note",16,-15,280)
        self.editTitle:SetTextColor(warm[1],warm[2],warm[3])
        if chrome and chrome.Heading then chrome.Heading(f,self.editTitle,16,-15,"map") end
        button(f,"Close",337,-13,66,24,function()f:Hide()end)
        label(f,"Title",18,-51,75,true)
        local title=input(f,100,-46,284,"");title:SetMaxLetters(72)
        label(f,"Details",18,-86,75,true)
        local details=input(f,100,-80,284,"");details:SetMaxLetters(180)
        label(f,"Category",18,-122,75,true)
        local category=button(f,"note",100,-117,143,25,function()
            local kinds={"note","travel","quest","resource","danger"}
            local idx=1
            for i,k in ipairs(kinds) do if f.categoryValue==k then idx=i end end
            f.categoryValue=kinds[idx%#kinds+1];f.category.title:SetText(f.categoryValue)
        end)
        f.category=category
        f.saveButton=button(f,"Save changes",100,-168,136,30,function()
            local ok,why=M.Storage:Edit(f.noteID,title:GetText(),f.categoryValue,details:GetText())
            if ok then f:Hide() end
            U:Respond(ok,why)
        end)
        button(f,"Cancel",248,-168,90,30,function()f:Hide()end)
        f.titleEdit=title;f.detailEdit=details
        f:SetScript("OnHide",function()title:ClearFocus();details:ClearFocus()end)
        if chrome then chrome.Escape(f) end
        f:Hide();self.editPanel=f
    end
    local f=self.editPanel
    f.noteID=id;f.titleEdit:SetText(note.label);f.detailEdit:SetText(note.details or "")
    f.categoryValue=note.kind;f.category.title:SetText(note.kind)
    if fit(f)~=false then M.MapQuery:BindWindow(f,self.mapOwner);f:Show() end
end
-- Each copy page stays below the native edit-box byte limit even with
-- maximum allowed names and details on every record.
local EXPORT_PAGE_SIZE=40
function U:UpdateExport(offset)
    local f=self.exportPanel
    local export,meta=M.Storage:Export(EXPORT_PAGE_SIZE,offset)
    if not meta.available then return end
    if meta.count==0 and meta.total>0 then
        local lastOffset=math.floor((meta.total-1)/EXPORT_PAGE_SIZE)*EXPORT_PAGE_SIZE
        export,meta=M.Storage:Export(EXPORT_PAGE_SIZE,lastOffset)
    end
    f.meta=meta
    local pages=math.max(1,math.ceil(meta.total/EXPORT_PAGE_SIZE))
    local page=math.floor(meta.offset/EXPORT_PAGE_SIZE)+1
    f.pager:SetText(string.format("Page %d/%d  ·  %d map notes",page,pages,meta.total))
    f.previous:SetEnabled(meta.offset>0)
    f.next:SetEnabled(meta.nextOffset~=nil)
    f.edit:SetText(export)
end
function U:ShowExport()
    if M.Storage.readOnly then M:Print("Saved notes unavailable; files were not changed.");return end
    if M:Combat() then M:Print("Open exports outside combat.");return end
    if not self.exportPanel then
        local f=CreateFrame("Frame","MirageIntelMapExport",UIParent,"BackdropTemplate")
        f:SetSize(565,392);f:SetPoint("CENTER");f:SetFrameStrata("FULLSCREEN_DIALOG");f:SetClampedToScreen(true)
        if chrome then chrome.Panel(f) else
            f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8x8",edgeFile="Interface\\Buttons\\WHITE8x8",edgeSize=1})
            f:SetBackdropColor(.060,.060,.065,.98);f:SetBackdropBorderColor(.26,.26,.26,1)
        end
        self.exportTitle=label(f,"Copy map notes",17,-15,410)
        self.exportTitle:SetTextColor(warm[1],warm[2],warm[3])
        if chrome and chrome.Heading then chrome.Heading(f,self.exportTitle,17,-15,"map") end
        button(f,"Close",487,-11,60,24,function()f:Hide()end)
        label(f,"Select all (Ctrl+A), then copy (Ctrl+C). Copy every page for all notes.",17,-45,523,true)
        f.previous=button(f,"Previous",17,-66,72,23,function()
            if f.meta and not M:Combat() then U:UpdateExport(math.max(0,f.meta.offset-EXPORT_PAGE_SIZE)) end
        end)
        f.next=button(f,"Next",96,-66,57,23,function()
            if f.meta and f.meta.nextOffset and not M:Combat() then U:UpdateExport(f.meta.nextOffset) end
        end)
        f.pager=label(f,"",165,-71,360,true)
        local scroll=chrome and chrome.Scroll and chrome.Scroll(f) or CreateFrame("ScrollFrame",nil,f)
        scroll:SetPoint("TOPLEFT",f,"TOPLEFT",20,-99)
        scroll:SetPoint("BOTTOMRIGHT",f,"BOTTOMRIGHT",-39,19)
        local edit=CreateFrame("EditBox",nil,scroll)
        edit:SetMultiLine(true);edit:SetAutoFocus(false);edit:SetFontObject("ChatFontNormal")
        edit:SetWidth(470);edit:SetHeight(2300);edit:SetMaxLetters(16000)
        edit:SetScript("OnEscapePressed",function()f:Hide()end)
        f:SetScript("OnHide",function()edit:ClearFocus()end)
        scroll:SetScrollChild(edit)
        if chrome then chrome.Escape(f) end
        f.edit=edit;f:Hide();self.exportPanel=f
    end
    if fit(self.exportPanel)==false then return end
    M.MapQuery:BindWindow(self.exportPanel,self.mapOwner)
    self.exportPanel:Show();self:UpdateExport(0)
    self.exportPanel.edit:SetFocus();self.exportPanel.edit:HighlightText()
end
-- Settings rows have explicit click handlers, never inert decoration.
function U:SettingsRowClick(i)
    if self.page~="Settings" then return end
    local p=M.Storage.account and M.Storage.account.settings
    if not p then return end
    if M.RecordQuery and self.settingRows then return self:LayerSettingClick(i) end
    local fields={"showMapButton","showCoordinates","showPersonalPins","showDestinationPin","mapPolicy","pinLimit"}
    local k=fields[i]
    if i==7 then
        local saved=M.Storage.character.panel
        local nxt=saved.scale+.1
        if nxt>1.31 then nxt=.8 end
        self:Respond(self:SetRequestedScale(math.floor(nxt*10+.5)/10))
        return
    end
    if not k then return end
    local nextValue
    if k=="mapPolicy" then nextValue=p.mapPolicy=="auto" and "manual" or p.mapPolicy=="manual" and "off" or "auto"
    elseif k=="pinLimit" then nextValue=p.pinLimit==50 and 80 or p.pinLimit==80 and 20 or 50
    else nextValue=not p[k] end
    self:Respond(M.Storage:SetSetting(k,nextValue))
end

local layerNames={"all","notes","quests","services","resources","pois","routes"}
local resourceNames={"all","herb","ore","fish","pool","skin","treasure"}
local function cycle(values,current)
    local index=1;for i,value in ipairs(values) do if value==current then index=i;break end end
    return values[index%#values+1]
end
function U:CreatePlaceControls(frame,label,input,button)
    self.layerFilter=button(frame,"Layer: all",436,-179,185,25,function()
        U.clusterMembers=nil;U.offset=0
        M.Storage:SetSetting("placeLayer",cycle(layerNames,M.Storage.account.settings.placeLayer));U:Update()
    end)
    self.materialLabel=label(frame,"Material",19,-220,70,true)
    self.material=input(frame,85,-215,340,"");self.material:SetMaxLetters(96)
    self.material:SetScript("OnTextChanged",function()
        if U.syncingSearch then return end
        U.offset=0;U.clusterMembers=nil;U:ApplyPlaceSearch();U:Update()
    end)
    self.availability=button(frame,"Availability: all",436,-215,185,25,function()
        U.clusterMembers=nil;U.offset=0
        M.Storage:SetSetting("availability",cycle({"all","usable","unknown"},M.Storage.account.settings.availability));U:Update()
    end)
    self.factionFilter=button(frame,"Faction: all",20,-249,143,25,function() U:TogglePlaceFilter("filterFaction") end)
    self.classFilter=button(frame,"Class: all",173,-249,143,25,function() U:TogglePlaceFilter("filterClass") end)
    self.professionFilter=button(frame,"Skills: all",326,-249,143,25,function() U:TogglePlaceFilter("filterProfession") end)
    self.resourceFilter=button(frame,"Resource: all",479,-249,142,25,function()
        U.clusterMembers=nil;U.offset=0
        M.Storage:SetSetting("resourceCategory",cycle(resourceNames,M.Storage.account.settings.resourceCategory));U:Update()
    end)
    self.placeControls={self.layerFilter,self.materialLabel,self.material,self.availability,self.factionFilter,self.classFilter,self.professionFilter,self.resourceFilter}
    for _,control in ipairs(self.placeControls) do control:Hide() end
end
function U:TogglePlaceFilter(key)
    self.filterUndo=nil
    self.clusterMembers=nil;self.offset=0
    M.Storage:SetSetting(key,not M.Storage.account.settings[key]);self:Update()
end
function U:OpenCluster(ids,origin,mapID)
    self.dataMapID=mapID or M.MapQuery:BrowseMap()
    self.page="Places";self.offset=0;self.clusterMembers=M.core.Copy(ids)
    return self:Open(origin)
end
function U:UpdateSharedPlaces()
    local cfg=M.Storage.account.settings
    self.heading:SetText(self.clusterMembers and "Places in this group" or "Places on this map")
    self.details:SetText("Find quests, services and gathering spots.")
    self.layerFilter.title:SetText("Layer: "..(cfg.placeLayer or "all"))
    self.availability.title:SetText("Availability: "..(cfg.availability or "all"))
    self.factionFilter.title:SetText(cfg.filterFaction and "Faction: mine" or "Faction: all")
    self.classFilter.title:SetText(cfg.filterClass and "Class: mine" or "Class: all")
    self.professionFilter.title:SetText(cfg.filterProfession and "Skills: mine" or "Skills: all")
    self.resourceFilter.title:SetText("Resource: "..(cfg.resourceCategory or "all"))
    local mapID=M.MapQuery:BrowseMap();local all={};local seen={}
    if mapID then
        local rows=M.RecordQuery:List(mapID,self.clusterMembers)
        local destination=M.Integration:CurrentDestination()
        if destination and destination.mapID==mapID and not self.clusterMembers then all[#all+1]=destination;seen[destination.id]=true end
        for _,record in ipairs(rows) do if not seen[record.id] then all[#all+1]=record;seen[record.id]=true end end
    end
    if M.Explorer then all=M.Explorer:Sort(self,all,mapID) end
    self:ShowRows(self:PageRows(all),#all)
    local status=M.RecordQuery:GetStatus()
    local from=#all>0 and self.offset+1 or 0
    self.pager:SetText(string.format("%d–%d of %d%s · %s",from,math.min(#all,self.offset+7),#all,status.loading and "+" or "",
        status.loading and "loading more places" or self.clusterMembers and "all group members" or "places"))
    if not mapID then self.pager:SetText("Current location is unavailable. Open the world map to choose a zone.")
    elseif #all==0 then
        local catalog=M.Catalog and M.Catalog:GetStatus()
        self.details:SetText((status.loading or (catalog and catalog.status=="BUILDING")) and "Loading places for this map…" or
            "No places match. Clear your filters or choose another zone.")
    end
    self.action1.title:SetText("Open map");self.action2.title:SetText("Navigate")
    self.action3.title:SetText("Inspect");self.action4.title:SetText(self.clusterMembers and "All results" or "Reset filters")
    local selected=M.state.utilitySelection
    local visibleSelection=selected and selected.mapID==mapID and seen[selected.id]
    if visibleSelection then self.details:SetText("Selected: "..selected.label.." · choose Navigate or Inspect.") end
    if self.searchError then self.details:SetText("Search was not applied. Use plain text or an item number; clear game links and control characters.") end
    self.action2:SetEnabled(visibleSelection and M.Integration:Navigate()~=nil or false)
    self.action3:SetEnabled(visibleSelection or false)
end
function U:SharedPlaceAction(which)
    local ok,why
    if which==1 then ok,why=M.MapQuery:OpenMap()
    elseif which==2 then ok,why=M.Integration:NavigateRecord(M.state.utilitySelection)
    elseif which==3 then ok,why=M.Inspector:Open(M.state.utilitySelection,self.mapOwner)
    elseif self.clusterMembers then self.clusterMembers=nil;self.offset=0;ok=true
    elseif M.Explorer then ok,why=M.Explorer:ResetFilters(self)
    else
        self.offset=0;self.search:SetText("");self.material:SetText("");M.RecordQuery:SetSearch("","")
        for _,key in ipairs({"filterFaction","filterClass","filterProfession"}) do M.Storage:SetSetting(key,false) end
        for _,key in ipairs({"placeLayer","resourceCategory","availability"}) do M.Storage:SetSetting(key,"all") end
        ok=true
    end
    self:Respond(ok,why)
end
local settingGroups={
    {name="Layers",rows={
        {"showQuestPins","Quest objectives and offers"},{"showServicePins","Services and flight points"},
        {"showResourcePins","Gathering and fishing records"},{"showPOIPins","Points of interest"},
        {"showPersonalPins","Personal notes"},{"showDestinationPin","Active destination"},
        {"showRouteStops","Upcoming route stops"},{"showRouteBearing","Suggested route line"},
        {"showUnexplored","Unexplored terrain preview"},{"showZoneGuide","Zone level guide"}}},
    {name="Relevance filters",rows={
        {"filterFaction","My faction"},{"filterClass","My class"},{"filterProfession","My professions"}}},
    {name="Appearance",rows={
        {"mapPolicy","Map overlays"},{"showMapButton","World-map shortcut"},
        {"showCoordinates","Coordinates on map hover"},{"windowScale","Window scale"}}},
    {name="Advanced",rows={{"pinLimit","Marker limit"},{"density","Marker spacing"}}},
}
function U:UpdateLayerSettings()
    self.settingsDecorated=true
    self.settingGroup=self.settingGroup or 1
    local group=settingGroups[self.settingGroup]
    self.heading:SetText(group.name)
    self.details:SetText(self.settingGroup==4 and "Fine-tune marker density and grouping." or "Choose what appears on your map.")
    self.settingRows=self:PageRows(group.rows);self.currentRows={}
    local cfg=M.Storage.account.settings
    for i,b in ipairs(self.rows) do
        local def=self.settingRows[i]
        if def then
            local value=cfg[def[1]];local active=value==true
            if type(value)=="boolean" then value=value and "On" or "Off" end
            if def[1]=="mapPolicy" then active=value~="off";value=active and "On" or "Off" end
            if def[1]=="density" then value=value=="detailed" and "Detailed" or "Grouped" end
            if def[1]=="windowScale" then value=math.floor(M.Storage.character.panel.scale*100+.5).."%" end
            b.title:SetText(def[2].."  ·  "..tostring(value));b:Show()
            if chrome then chrome.Active(b,active) end
        else b:Hide() end
    end
    self.previous:SetEnabled(self.offset>0);self.next:SetEnabled(self.offset+7<#group.rows)
    self.pager:SetText("Changes save immediately."..(#group.rows>7 and string.format("  %d–%d / %d",self.offset+1,math.min(self.offset+7,#group.rows),#group.rows) or ""))
    for i,entry in ipairs(settingGroups) do
        local b=self["action"..i];b.title:SetText(entry.name);b:SetEnabled(true)
        if chrome then chrome.Active(b,self.settingGroup==i) end
    end
end
function U:LayerSettingClick(i)
    local def=self.settingRows and self.settingRows[i];if not def then return end
    local key=def[1];local account,character=M.Storage.account,M.Storage.character;local cfg=account.settings
    local function save(value)
        if U.page~="Settings" or U.settingRows[i]~=def or M.Storage.account~=account or M.Storage.character~=character then return end
        if key=="windowScale" then U:Respond(U:SetRequestedScale(value))
        else U:Respond(M.Storage:SetSetting(key,value)) end
    end
    local choices
    if key=="windowScale" then
        choices={};for n=7,15 do choices[#choices+1]={n/10,n*10 .."%"} end
    elseif key=="pinLimit" then choices={{20,"20 markers"},{50,"50 markers"},{80,"80 markers"}}
    elseif key=="density" then choices={{"compact","Grouped"},{"detailed","Detailed"}} end
    if choices and chrome and chrome.Choose then
        chrome.Choose(self.rows[i],choices,key=="windowScale" and character.panel.scale or cfg[key],save)
    elseif key=="mapPolicy" then save(cfg.mapPolicy=="off" and "auto" or "off")
    elseif not choices then save(not cfg[key]) end
end
