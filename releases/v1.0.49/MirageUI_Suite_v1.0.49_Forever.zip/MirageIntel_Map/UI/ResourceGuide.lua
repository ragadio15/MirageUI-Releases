local _,M=...
-- Optional Coverage subview. It reuses the panel's seven rows and pagination.
-- Region references have no point coordinates and cannot become destinations.
local U=M.Panel
if not U then return end
local professions={[182]="Herbalism",[186]="Mining",[356]="Fishing",[164]="Blacksmithing",[202]="Engineering",[393]="Skinning"}
local function allowed()
    return not M:Combat() and type(M.Storage)=="table" and not M.Storage.readOnly and M.state.clientAllowed
end
-- An optional receiver may open successfully while its callbacks change the
-- originating view or profile. Only the exact view that initiated the handoff
-- may be dismissed; a replacement panel belongs to the newer context.
local function handoffContext(panel,name)
    local frame,page,mode,item,region=panel.frame,panel.page,panel.referenceMode,panel.referenceItem,panel.referenceRegion
    local storage,integration=M.Storage,M.Integration
    local account,character=storage and storage.account,storage and storage.character
    local function intact()
        local usable=allowed()
        return usable and M.Panel==panel and panel.frame==frame and frame~=nil and
            panel.page==page and panel.referenceMode==mode and panel.referenceItem==item and panel.referenceRegion==region and
            M.Storage==storage and storage.account==account and storage.character==character and M.Integration==integration
    end
    local function provider()
        if name=="Gather" then return integration:Gather() end
        return integration:Service(name)
    end
    if not intact() then return nil end
    local selected=provider()
    local function unchanged()
        if not intact() then return false end
        local current=provider()
        return current==selected and intact()
    end
    return selected,unchanged,frame
end
local function skillText(row)
    local profession=professions[row.skillLineID] or "Gathering"
    if not M:Number(row.minSkill) then return profession.."" end
    local value=tostring(row.minSkill)
    if M:Number(row.maxSkill) and row.maxSkill~=row.minSkill then value=value.."–"..row.maxSkill end
    return profession.." · skill guide "..value
end
local function provenance(row)
    return (row.source or "ForeverPlusPlus reference").." · MIT\n"..
        (row.sourceVersion or "").."\n"..(row.sourceURL or "")
end
local function materialDetail(row)
    local lines={row.name or ("Item #"..row.itemID),skillText(row)}
    if row.skillMeaning=="LOWEST_YIELDING_VEIN_REFERENCE" then
        lines[#lines+1]="Collected while mining ore veins."
    end
    for i,node in ipairs(row.nodeVariants or {}) do
        if i>24 then break end
        local text=node.name or "Node reference"
        if M:Number(node.skill) then text=text.." · "..node.skill end
        if node.sharedBaseName then text=text.." · also found in "..node.sharedBaseName end
        lines[#lines+1]=text
    end

    return table.concat(lines,"\n")
end
local function matches(row,query)
    if not query or query=="" then return true end
    query=string.lower(query)
    if tostring(row.itemID or ""):find(query,1,true) or string.lower(row.name or ""):find(query,1,true) then return true end
    for _,node in ipairs(row.nodeVariants or {}) do
        if string.lower(node.name or ""):find(query,1,true) then return true end
    end
    return false
end
function U:ToggleResourceGuide()
    if not allowed() then return false end
    self.referenceMode=self.referenceMode=="fishing" and "materials" or "fishing"
    self.referenceItem=nil;self.referenceRegion=nil;self.offset=0
    if self.search then self.search:SetText("") end
    self:Update();return true
end
function U:ResourceRows()
    local guide=M.ZoneGuide
    if not guide or not guide.GetResourceCatalog then return {},"Open a map to browse resources." end
    local rows={}
    if self.referenceMode=="regions" then
        local info=guide:FindResourceRegions(self.referenceItem)
        if not info then return {},"Select a material to browse its regions." end
        for _,region in ipairs(info.regions or {}) do
            local label=region.name or ("Map #"..region.mapID)
            if region.minLevel and region.maxLevel then label=label.." · levels "..region.minLevel.."–"..region.maxLevel end
            rows[#rows+1]={mapID=region.mapID,itemID=info.itemID,
                label=(self.referenceRegion==region.mapID and "› " or "")..label,
                state="Select to view map",
                detail="Explore this region",
                source=provenance(info)}
        end
        return rows,#rows==0 and "No regions listed for this material." or
            "Choose a region, then select View map."
    end
    local catalog=guide:GetResourceCatalog()
    if not catalog then return {},"No resources to show." end
    if self.referenceMode=="fishing" then
        local mapID=M.MapQuery:BrowseMap()
        local zone=mapID and guide:GetResources(mapID)
        if zone and zone.fishingSkill then
            local label="Fishing skill guide: "..zone.fishingSkill
            if zone.coastalFishingSkill then label=label.." inland / "..zone.coastalFishingSkill.." coast" end
            rows[#rows+1]={label=label,state="This zone",
                detail="Regional fishing skill guide",source=provenance(zone)}
        end
        for _,name in ipairs(catalog.fishingPools or {}) do
            local label=type(name)=="table" and name.name or name
            rows[#rows+1]={label=label,state="Fishing pool",
                detail="Record your finds with Gather Mate.",source=provenance(catalog)}
        end
        for _,tool in ipairs(catalog.professionTools or {}) do
            rows[#rows+1]={label=tool.name or ("Item #"..tool.itemID),state="Profession tool",
                detail=(professions[tool.skillLineID] or "Profession").." · item #"..tool.itemID,source=provenance(catalog)}
        end
        return rows,"Fishing pools and profession tools."
    end
    local allowed
    local mapID=M.MapQuery:BrowseMap()
    if not self.referenceAll then
        allowed={}
        local region=mapID and guide:GetResources(mapID)
        if region then for _,kind in ipairs({"herbs","ores"}) do
            for _,item in ipairs(region[kind] or {}) do allowed[item.itemID]=true end
        end end
    end
    local query=self.search and M:Text(self.search:GetText(),90) or ""
    for _,item in ipairs(catalog.items or {}) do
        if (not allowed or allowed[item.itemID]) and matches(item,query) then
            rows[#rows+1]={itemID=item.itemID,label=item.name or ("Item #"..item.itemID),
                state=skillText(item),detail=materialDetail(item),source=provenance(item)}
        end
    end
    return rows,#rows==0 and "No matching materials. Try All materials or clear the search." or
        "Choose a material to see where to gather it."
end
function U:UpdateResources()
    local title="Resource guide"
    if self.referenceMode=="regions" then
        local item=M.ZoneGuide and M.ZoneGuide:GetResource(self.referenceItem)
        title=item and (item.name.." · Regions") or "Regions"
    elseif self.referenceMode=="fishing" then title="Fishing and profession tools" end
    self.heading:SetText(title)
    local rows,hint=self:ResourceRows();self.details:SetText(hint)
    self:ShowRows(self:PageRows(rows),#rows)
    self.pager:SetText(string.format("%d–%d of %d",
        #rows>0 and self.offset+1 or 0,math.min(#rows,self.offset+7),#rows))
    self.action4.title:SetText("Places")
    if self.referenceMode=="regions" then
        self.action1.title:SetText("Inspect item");self.action2.title:SetText("View map")
        self.action3.title:SetText("Materials")
        local insight=M.Integration:Service("Insight")
        self.action1:SetEnabled(insight~=nil and type(insight.OpenItem)=="function")
        self.action2:SetEnabled(self.referenceRegion~=nil)
    else
        self.action1.title:SetText(self.referenceAll and "This zone" or "All materials")
        self.action2.title:SetText(self.referenceMode=="fishing" and "Materials" or "Fishing / tools")
        self.action3.title:SetText("Gather Mate")
        self.action1:SetEnabled(self.referenceMode~="fishing")
        self.action3:SetEnabled(M.Integration:Gather()~=nil)
    end
end
function U:ResourceRowClick(index)
    if not allowed() then return end
    local row=self.currentRows and self.currentRows[index]
    if not row then return end
    if self.referenceMode=="materials" and row.itemID then
        self.referenceItem=row.itemID;self.referenceMode="regions";self.referenceRegion=nil;self.offset=0
    elseif self.referenceMode=="regions" and row.mapID then self.referenceRegion=row.mapID
    else return end
    self:Update()
end
function U:ResourceAction(which)
    if not allowed() then return false end
    if which==4 then self.page="Places";self.offset=0;self:Update();return true end
    if self.referenceMode=="regions" then
        if which==1 then
            local selected=self.referenceItem
            local insight,unchanged,frame=handoffContext(self,"Insight")
            if not insight or type(insight.OpenItem)~="function" then return false end
            local item=M.ZoneGuide:GetResource(selected)
            if not item or item.itemID~=selected or not unchanged() then return false,"RESOURCE_CONTEXT_CHANGED" end
            local accepted,ok=M:Call(insight.OpenItem,item.itemID,{userInitiated=true})
            if not unchanged() then return false,"RESOURCE_CONTEXT_CHANGED" end
            if ok and accepted==true then frame:Hide();return true end
            M:Print("Item inspection is unavailable.");return false
        elseif which==2 then
            -- Re-read the selected region before explicit map browsing. No world
            -- record, route or synthetic coordinate is created by this action.
            local itemID,selected=self.referenceItem,self.referenceRegion
            local info=M.ZoneGuide:FindResourceRegions(itemID)
            local found=false
            for _,region in ipairs(info and info.regions or {}) do
                if region.mapID==selected then found=true;break end
            end
            if not allowed() or self.referenceMode~="regions" or self.referenceItem~=itemID or
                self.referenceRegion~=selected then return false end
            if not found then self.referenceRegion=nil;self:Update();return false end
            local ok,why=M.MapQuery:OpenMap()
            if ok then
                if not allowed() or self.referenceMode~="regions" or self.referenceItem~=itemID or
                    self.referenceRegion~=selected then return false end
                ok,why=M.MapQuery:GoToMap(selected)
            end
            if not ok then M:Print(M:UserMessage(why)) end
            return ok
        else self.referenceMode="materials";self.referenceRegion=nil;self.offset=0 end
    elseif which==1 then self.referenceAll=not self.referenceAll;self.offset=0
    elseif which==2 then self.referenceMode=self.referenceMode=="fishing" and "materials" or "fishing";self.offset=0
    elseif which==3 then
        local gather,unchanged,frame=handoffContext(self,"Gather")
        if gather and type(gather.Open)=="function" and unchanged() then
            local accepted,ok=M:Call(gather.Open)
            if not unchanged() then return false,"RESOURCE_CONTEXT_CHANGED" end
            if ok and accepted==true then frame:Hide();return true end
        end
        return false
    end
    self:Update();return true
end
