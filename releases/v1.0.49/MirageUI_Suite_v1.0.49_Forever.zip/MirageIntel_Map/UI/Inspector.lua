local _,M=...
M.Inspector={}
local U=M.Inspector
local function text(value,limit) return M:Text(value,limit or 180) end
local names={objective="Quest objective",["turn-in"]="Quest turn-in",available="Quest giver",herb="Herbalism",ore="Mining",
    skin="Skinning",fish="Fishing",pool="Fishing pool",flight="Flight master",["spirit-healer"]="Spirit healer",
    dungeon="Dungeon entrance",raid="Raid entrance",vendor="Vendor",repair="Repairs",trainer="Trainer",note="Personal note",landmark="Landmark"}
function U:Model(record)
    if not M.Integration:ValidRecord(record) then return nil end
    local rows={}
    local function add(value) if value and value~="" then rows[#rows+1]=value end end
    local category=names[record.category] or names[record.kind] or "Place"
    add(category.."  ·  "..string.format("%.1f, %.1f",record.x*100,record.y*100))
    local zone=M.MapQuery and M.MapQuery:Name(record.mapID)
    if zone then add(zone) end
    if record.availability=="ACCEPTED" then add("In your quest log")
    elseif record.availability=="AVAILABLE" then add("Available") end
    if record.serviceRoles then add("Services: "..(text(record.serviceRoles,180) or ""):gsub("[_,]"," ")) end
    if record.materialText or record.materialSummary then add("Materials: "..(text(record.materialText,180) or text(record.materialSummary,180) or "")) end
    if record.kind=="gather" then add("Recorded gathering spot") end
    if record.fishingType=="POOL" then add("Fishing pool") elseif record.fishingType=="OPEN_WATER" then add("Open-water fishing") end
    if record.catchSummary then add("Catches: "..(text(record.catchSummary,220) or "")) end
    if M:Number(record.requiredSkill) then add("Skill guide: "..record.requiredSkill) end
    if record.learned=="OBSERVED_KNOWN" or record.flightDiscovered==true then add("Flight point learned") end
    if record.kind=="flight" and M.Integration.FlightPreview then
        local route=M.Integration:FlightPreview(record)
        if route and route.nextLeg and route.nextLeg.from and route.nextLeg.to then
            add("Flight: "..route.nextLeg.from.label.." → "..route.nextLeg.to.label)
        end
    end
    if record.destination then add("Current destination") elseif record.suggestedStop then add("Route stop "..record.suggestedStop) end
    if record.kind=="note" and text(record.details,300) then add(record.details) end
    return {id=record.id,title=record.label,lines=rows}
end
function U:Create()
    if self.frame then return true end
    if M:Combat() then return false end
    local f=CreateFrame("Frame","MirageIntelMapInspector",UIParent,"BackdropTemplate")
    f:SetSize(460,330);f:SetPoint("CENTER",UIParent,"CENTER",0,30);f:SetFrameStrata("DIALOG");f:SetClampedToScreen(true);f:EnableMouse(true)
    local chrome=M.core and M.core.Chrome
    if chrome then chrome.Panel(f) else
        f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8x8",edgeFile="Interface\\Buttons\\WHITE8x8",edgeSize=1})
        f:SetBackdropColor(.060,.060,.065,.98);f:SetBackdropBorderColor(.26,.26,.26,1)
    end
    local mark=f:CreateTexture(nil,"ARTWORK");mark:SetSize(20,20);mark:SetPoint("TOPLEFT",f,"TOPLEFT",12,-12)
    mark:SetTexture("Interface\\AddOns\\MirageIntel_Map\\Media\\Badge.tga")
    local title=f:CreateFontString(nil,"OVERLAY","GameFontNormal")
    title:SetPoint("TOPLEFT",mark,"TOPRIGHT",8,-2);title:SetWidth(360);title:SetJustifyH("LEFT");title:SetWordWrap(true);title:SetTextColor(.96,.79,.36);f.title=title
    if chrome and chrome.Font then chrome.Font(title,"body") end
    local scroll=chrome and chrome.Scroll and chrome.Scroll(f) or CreateFrame("ScrollFrame",nil,f)
    scroll:SetPoint("TOPLEFT",f,"TOPLEFT",18,-58);scroll:SetPoint("BOTTOMRIGHT",f,"BOTTOMRIGHT",-32,80)
    local body=CreateFrame("EditBox",nil,scroll);body:SetSize(406,340);body:SetMultiLine(true);body:SetAutoFocus(false)
    body:SetFontObject("GameFontHighlightSmall");body:SetMaxLetters(8000);body:SetScript("OnEscapePressed",function(self) self:ClearFocus() end)
    if chrome and chrome.Font then chrome.Font(body,"body") end
    body:SetScript("OnTextChanged",function(self,user) if user and U.bodyText then self:SetText(U.bodyText) end end)
    scroll:SetScrollChild(body);f.body=body;f.scroll=scroll
    local measure=f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    measure:SetWidth(406);measure:SetWordWrap(true);measure:Hide()
    if chrome and chrome.Font then chrome.Font(measure,"body") end
    f.measure=measure
    local function button(caption,x,y,width,fn)
        if chrome then return chrome.Button(f,caption,x,y,width,24,fn) end
        local b=CreateFrame("Button",nil,f,"UIPanelButtonTemplate");b:SetSize(width,24);b:SetPoint("TOPLEFT",f,"TOPLEFT",x,y);b:SetText(caption);b:SetScript("OnClick",fn);return b
    end
    button("×",424,-10,24,function() U:Close() end)
    f.navigate=button("Navigate",18,-423,132,function() U:Act("navigate") end)
    f.navigate:ClearAllPoints();f.navigate:SetPoint("BOTTOMLEFT",f,"BOTTOMLEFT",18,44)
    f.note=button("Add note",160,-423,132,function() U:Act("note") end)
    f.note:ClearAllPoints();f.note:SetPoint("BOTTOMLEFT",f,"BOTTOMLEFT",160,44)
    f.filter=button("Filter type",302,-423,138,function() U:Act("filter") end)
    f.filter:ClearAllPoints();f.filter:SetPoint("BOTTOMLEFT",f,"BOTTOMLEFT",302,44)
    f.map=button("Open map",18,-456,202,function() M.MapQuery:OpenMap();M.MapQuery:GoToMap(U.record.mapID) end)
    f.map:ClearAllPoints();f.map:SetPoint("BOTTOMLEFT",f,"BOTTOMLEFT",18,12)
    f.back=button("Back to places",230,-456,210,function() M.Panel.page="Places";M.Panel:Open(U.mapOwner) end)
    f.back:ClearAllPoints();f.back:SetPoint("BOTTOMLEFT",f,"BOTTOMLEFT",230,12)
    f:SetScript("OnHide",function()
        body:ClearFocus()
        local restore=U.returnToPanel;U.returnToPanel=false
        if restore and M.Panel and not M:Combat() then M.Panel:Open(U.mapOwner) end
    end)
    if chrome then chrome.Watch(f) end
    f:Hide();self.frame=f;return true
end
function U:Refresh()
    local model=self:Model(self.record,self.sourceView)
    if not model or not self.frame then return false end
    self.frame.title:SetText(model.title)
    local titleHeight,titleRead=M:Call(self.frame.title.GetStringHeight,self.frame.title)
    local header=math.max(58,30+(titleRead and M:Number(titleHeight) and titleHeight or 28))
    self.frame.scroll:ClearAllPoints()
    self.frame.scroll:SetPoint("TOPLEFT",self.frame,"TOPLEFT",18,-header)
    self.frame.scroll:SetPoint("BOTTOMRIGHT",self.frame,"BOTTOMRIGHT",-32,80)
    self.headerHeight=header
    self.bodyText=table.concat(model.lines,"\n\n")
    self.frame.body:SetText(self.bodyText)
    -- Keep long notes selectable and contained in a real scroll child.
    local lines=0;for _,line in ipairs(model.lines) do lines=lines+math.max(1,math.ceil(#line/48))+1 end
    self.frame.measure:SetText(self.bodyText)
    local height,ok=M:Call(self.frame.measure.GetStringHeight,self.frame.measure)
    local contentHeight=ok and M:Number(height) and height+24 or lines*18
    self.frame:SetHeight(math.min(490,math.max(270,contentHeight+142+header-58)))
    self.frame.body:SetHeight(math.max(130,contentHeight))
    if self.frame.scroll.MirageScrollTo then self.frame.scroll:MirageScrollTo(0) end
    local available=M.state.clientAllowed and not M.Storage.readOnly and not M:Combat()
    self.frame.navigate:SetEnabled(available and M.Integration:Navigate()~=nil)
    self.frame.note:SetEnabled(available);self.frame.filter:SetEnabled(available)
    return true
end
function U:Open(record,origin)
    if not M.Integration:ValidRecord(record) or M:Combat() or not self:Create() then return false,"INSPECTOR_UNAVAILABLE" end
    self.record=M.core.Copy(record);self.sourceView=false;M.state.utilitySelection=M.core.Copy(record)
    self.mapOwner=M.MapQuery:BindWindow(self.frame,origin)
    self.returnToPanel=(self.frame:IsShown() and self.returnToPanel) or (M.Panel.frame and M.Panel.frame:IsShown()) or false
    if M.Panel.frame then M.Panel.frame:Hide() end
    self:Refresh()
    local chrome=M.core and M.core.Chrome
    if chrome then chrome.Fit(self.frame,1) end
    self.frame:Show();if M.Canvas then M.Canvas:Dirty() end
    return true,"RECORD_SELECTED"
end
function U:Close()
    local restore=self.returnToPanel;self.returnToPanel=false
    if self.frame then self.frame:Hide() end
    if restore and M.Panel and not M:Combat() then M.Panel:Open(self.mapOwner) end
end
function U:Act(action)
    if M:Combat() or not self.record then return false,"ACTION_UNAVAILABLE" end
    if not M.state.clientAllowed or M.Storage.readOnly then return false,"MAP_STORAGE_READ_ONLY" end
    local ok,why
    if action=="navigate" then
        ok,why=M.Integration:NavigateRecord(self.record)
        if not ok and M.state.utilitySelection then self.record=M.core.Copy(M.state.utilitySelection);self:Refresh() end
    elseif action=="note" then
        local kind=self.record.kind=="gather" and "resource" or self.record.kind=="quest" and "quest" or "note"
        local raw=names[self.record.category] or names[self.record.kind] or "Saved place"
        local name=M.core.TextBytes and M.core.TextBytes(self.record.label,72) or self.record.label:sub(1,72)
        local detail=M.core.TextBytes and M.core.TextBytes(raw,180) or raw:sub(1,180)
        ok,why=M.Storage:Add(self.record.mapID,self.record.x,self.record.y,name,kind,detail)
    elseif action=="filter" then
        local layer=M.RecordQuery and M.RecordQuery:Layer(self.record) or "all"
        ok,why=M.Storage:SetSetting("placeLayer",layer)
        if ok and self.record.kind=="gather" and self.record.category then M.Storage:SetSetting("resourceCategory",self.record.category) end
        M.Panel.page="Places";M.Panel.clusterMembers=nil;M.Panel.offset=0;M.Panel:Open(self.mapOwner)
    end
    if why then M:Print(ok and "Updated successfully" or M:UserMessage(why)) end
    return ok,why
end
