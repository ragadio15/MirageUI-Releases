local _,M=...
-- Replace the art of known world-map POI widgets only. Blizzard keeps the
-- widgets, their data, focus, clicks and tracking. Textures return to their
-- original alpha when the native pool releases them or the overlay closes.
local N={pool=setmetatable({},{__mode="k"}),hooked=setmetatable({},{__mode="k"}),dirty=true,count=0}
M.NativeMarkers=N
local templates={
    AreaPOIPinTemplate={"pois","place","areaPoiID"},
    MapLinkPinTemplate={"pois","place","linkedMapID"},
    DungeonEntrancePinTemplate={"pois","dungeon","journalInstanceID"},
    FlightPointPinTemplate={"services","flight","nodeID"},
    GossipPinTemplate={"pois","place","gossipPoiID"},
    QuestHubPinTemplate={"quests","quest","areaPoiID"},
    QuestOfferPinTemplate={"quests","quest","questID"},
    QuestPinTemplate={"quests","quest","questID"},
}
local function release(state)
    if state.icon then state.icon:Hide() end
    local source=state.source
    if source then
        if M:Call(source.GetAlpha,source)==0 then M:Call(source.SetAlpha,source,state.alpha) end
        state.source=nil
    end
end
function N:Clear()
    for _,state in pairs(self.pool) do release(state) end
    self.at=nil;self.mapID=nil;self.count=0;self.dirty=true
end
function N:Attach(frame)
    if self.hooked[frame]~=nil then return end
    local function mark(owner,template)
        if M.Canvas.frame==owner and (type(template)~="string" or templates[template]) then N.dirty=true end
    end
    local ok=type(hooksecurefunc)=="function"
    if ok then
        for _,method in ipairs({"AcquirePin","RemovePin","RemoveAllPinsByTemplate"}) do
            if type(frame[method])~="function" or not pcall(hooksecurefunc,frame,method,mark) then ok=false end
        end
    end
    self.hooked[frame]=ok
end
local function add(index,field,id,r)
    if not M:Integer(id) then return end
    local key=field..":"..id
    local rows=index[key] or {};index[key]=rows;rows[#rows+1]=r
end
local function nameKey(label)
    if M:Text(label,160) then return "name:"..label:lower():gsub("^the ",""):gsub(" city$","") end
end
function N:Index(canvas)
    local index={}
    for _,button in ipairs(canvas.layerPins or {}) do
        local model=button.model
        if model and button.hasMarkerArt and button:IsShown() then
            for _,id in ipairs(model.members) do
                local r=M.RecordQuery.byID[id] or (model.record.id==id and model.record)
                if r then
                    if r.category=="city" or r.category=="entrance" then
                        local key=nameKey(r.label)
                        if key then local sites=index[key] or {};index[key]=sites;sites[#sites+1]=r end
                    end
                    add(index,"areaPoiID",r.alternateAreaPoiID,r)
                    for _,field in ipairs({"areaPoiID","linkedMapID","journalInstanceID","nodeID","questID"}) do
                        add(index,field,r[field],r)
                    end
                end
            end
        end
    end
    return index
end
local function classify(pin,spec,index,mapID)
    local info=pin.poiInfo
    if not M:Readable(info) or type(info)~="table" then info={} end
    local field=spec[3]
    local id
    if field=="linkedMapID" then id=pin.linkedUiMapID or info.linkedUiMapID
    elseif field=="questID" then id=pin.questID or M:Call(pin.GetQuestID,pin)
    else id=info[field] or pin[field] end
    local x,ok,y=M:Call(pin.GetGlobalPosition or pin.GetPosition,pin)
    if not ok or not M.map:Valid(mapID,x,y) then return end
    if M:Integer(id) then
        for _,r in ipairs(index[field..":"..id] or {}) do
            if r.mapID==mapID and math.abs(r.x-x)<=.008 and math.abs(r.y-y)<=.008 then return "covered" end
        end
    end
    if field=="areaPoiID" or field=="journalInstanceID" or field=="linkedMapID" then
        for _,r in ipairs(index[nameKey(info.name)] or {}) do
            if r.mapID==mapID and math.abs(r.x-x)<=.012 and math.abs(r.y-y)<=.012 then return "covered" end
        end
    end
    if field=="linkedMapID" and M:Integer(id) and M:Call(C_Map and C_Map.IsCityMap,id)==true then return "city" end
    if field=="questID" and M:Integer(id) and M:Call(C_QuestLog and C_QuestLog.IsComplete,id)==true then return "turnin" end
    return spec[2]
end
function N:PaintPin(pin,spec,index,mapID,icons)
    if not M:Readable(pin) or not pin:IsShown() then return end
    local protected,known=M:Call(pin.IsProtected,pin)
    if not known or protected then return end
    local source=pin.Texture or pin.NormalTexture
    if not M:Readable(source) or not source or type(source.GetAlpha)~="function" or type(source.SetAlpha)~="function" or
        type(source.IsShown)~="function" or not source:IsShown() then return end
    local key=classify(pin,spec,index,mapID)
    if not key then return end
    local state=self.pool[pin]
    if not state then
        state={}
        if type(pin.HookScript)~="function" or not pcall(pin.HookScript,pin,"OnHide",function() release(state);N.dirty=true end) then return end
        self.pool[pin]=state
    end
    if state.source~=source then release(state) end
    local alpha=M:Call(source.GetAlpha,source)
    if not M:Number(alpha) or alpha<0 or alpha>1 or (alpha==0 and not state.source) then return end
    if key~="covered" then
        if not state.icon then state.icon=pin:CreateTexture(nil,"OVERLAY",nil,1) end
        local icon=state.icon
        if not icon then return end
        if state.key~=key then
            local loaded,ok=M:Call(icon.SetTexture,icon,icons.Path(key))
            if not ok or loaded==false then release(state);return end
            state.key=key
        end
        if state.source~=source then icon:ClearAllPoints();icon:SetAllPoints(source) end
        icon:SetAlpha(alpha>0 and alpha or state.alpha);icon:Show()
    elseif state.icon then state.icon:Hide() end
    if alpha>0 then state.alpha=alpha;source:SetAlpha(0) end
    state.source=source;state.pass=self.pass
    self.count=self.count+1
end
function N:Refresh(canvas,mapID,repaint)
    local frame=canvas.frame
    local icons=M.core and M.core.MapIcons
    if not frame or type(frame.EnumeratePinsByTemplate)~="function" or not icons then return end
    self:Attach(frame)
    local now=M:Now()
    if not repaint and self.mapID==mapID and not self.dirty and self.at and
        (self.hooked[frame] or now-self.at<1) then return end
    self.at=now;self.mapID=mapID;self.dirty=false;self.count=0;self.pass=(self.pass or 0)+1
    local index=self:Index(canvas)
    local cfg=M.Storage.account.settings
    for template,spec in pairs(templates) do
        if M.RecordQuery:Enabled(spec[1]) and (not cfg.placeLayer or cfg.placeLayer=="all" or cfg.placeLayer==spec[1]) then
            -- An unsupported or restricted provider must not interrupt other
            -- providers, the legend, terrain art or navigation.
            pcall(function()
                for pin in frame:EnumeratePinsByTemplate(template) do self:PaintPin(pin,spec,index,mapID,icons) end
            end)
        end
    end
    for _,state in pairs(self.pool) do if state.source and state.pass~=self.pass then release(state) end end
end
