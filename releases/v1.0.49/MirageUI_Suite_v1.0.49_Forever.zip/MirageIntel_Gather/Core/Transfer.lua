-- Text-only source packs. Never loadstring/import executable Lua.
local _,G=...
G.Transfer={state="IDLE",generation=0,providers={},errors={},jobOwner="MirageIntel_Gather.transfer",limit=1048576}
local T=G.Transfer
local licenses={PERSONAL=true,CC0=true,["CC-BY-4.0"]=true,["CC-BY-SA-4.0"]=true,MIT=true,["BSD-2-Clause"]=true,["BSD-3-Clause"]=true,PERMISSION=true}
local meanings={UNKNOWN=true,INTERACTION=true,RECOMMENDED=true,NO_JUNK=true}
local fishing={UNKNOWN_WATER=true,POOL=true,OPEN_WATER=true}
local function safe(v,max) return type(v)=="string" and #v<=max and not v:find("[|%c]") end
local function buildNumber(value)
    return G:Text(value,20) and value:match("^%d+$") and G:Natural(tonumber(value)) and tonumber(value)<=999999999
end
local function patchName(value) return safe(value,80) and value:match("^%d+%.%d+[%w%.%-]*$") end
local function clientFlavor(interface) return interface==16001 and "Forever" or ("Client"..interface) end
function T:ClientIdentity()
    local patch,ok,build,_,interface=G:Call(GetBuildInfo)
    if not ok or not patchName(patch) or not buildNumber(build) or not G:Natural(interface) or interface>999999999 then
        return nil,"CLIENT_IDENTITY_UNAVAILABLE"
    end
    return {flavor=clientFlavor(interface),patch=patch,build=build,interface=interface}
end
local function encode(v) return tostring(v or ""):gsub("[%%|\r\n]",function(c)return string.format("%%%02X",c:byte())end) end
local function decode(v)
    if v:gsub("%%[%x][%x]",""):find("%%") then return nil end
    return (v:gsub("%%(%x%x)",function(x)return string.char(tonumber(x,16))end))
end
local function split(line)
    local out={};for part in (line.."|"):gmatch("(.-)|") do local value=decode(part);if value==nil then return nil end;out[#out+1]=value end
    return out
end
local function tasks() return G.core and G.core.GetService and G.core.GetService("Tasks",1) end
local function ui() if G.DataUI then G.DataUI:Update() end end
local function densePage(rows)
    if type(rows)~="table" or #rows>32 then return false end
    local count=0
    for key in pairs(rows) do
        count=count+1
        if count>32 or not G:Natural(key) or key>#rows then return false end
    end
    if count~=#rows then return false end
    for i=1,count do if rows[i]==nil then return false end end
    return true
end
local function digest(hash,text)
    for i=1,#text do hash=(hash*33+text:byte(i))%2147483647 end
    return hash
end
function T:Manifest(m)
    if type(m)~="table" or not safe(m.sourceID,48) or not m.sourceID:match("^[%w_%-]+$") or
        not G:Natural(m.revision) or m.revision>2147483647 then return false,"INVALID_SOURCE_ID_OR_REVISION" end
    local current=self:ClientIdentity()
    if not current then return false,"CLIENT_IDENTITY_UNAVAILABLE" end
    if not G:Natural(m.interface) or m.interface>999999999 or m.flavor~=clientFlavor(m.interface) or
        not patchName(m.patch) or not buildNumber(tostring(m.build)) or m.interface~=current.interface then
        return false,"WRONG_CLIENT_BUILD_OR_FLAVOR"
    end
    if m.coordinates~="UI_MAP_NORMALIZED" then return false,"UNQUALIFIED_COORDINATE_SYSTEM" end
    if not licenses[m.license] or not safe(m.sourceURL,240) or not safe(m.sourceLabel,90) or m.sourceLabel=="" then
        return false,"SOURCE_LICENSE_OR_PROVENANCE_REQUIRED"
    end
    if not m.sourceURL:match("^https://") and not (m.license=="PERSONAL" and m.sourceURL=="local://personal-observations") then
        return false,"SOURCE_URL_REQUIRED"
    end
    if m.license=="PERMISSION" and (not safe(m.permission,240) or m.permission=="") then return false,"PERMISSION_REFERENCE_REQUIRED" end
    return true
end
function T:Header(m)
    local values={"MUI-GATHER","2",m.sourceID,m.revision,m.flavor,m.patch,m.build,m.interface,
        m.coordinates,m.license,m.sourceURL,m.sourceLabel,m.permission or ""}
    for i,v in ipairs(values) do values[i]=encode(v) end
    return table.concat(values,"|")
end
function T:ParseHeader(line)
    local a=split(line)
    if not a or a[1]~="MUI-GATHER" or a[2]~="2" or #a~=13 then return nil,"UNSUPPORTED_TEXT_FORMAT" end
    local m={sourceID=a[3],revision=tonumber(a[4]),flavor=a[5],patch=a[6],build=a[7],interface=tonumber(a[8]),
        coordinates=a[9],license=a[10],sourceURL=a[11],sourceLabel=a[12],permission=a[13]}
    local ok,why=self:Manifest(m);return ok and m or nil,why
end
function T:RowText(row)
    local material,ids=G.Sites:Materials(row)
    local id=row.externalID or tostring(row.id):gsub("^catalog:[^:]+:","")
    local kind=row.kind
    if kind=="pool" and row.fishingType~="POOL" then kind="fish" end
    local values={"S",id,kind,row.name,row.mapID,string.format("%.6f",row.x),string.format("%.6f",row.y),
        row.floorID or row.mapID,row.objectID or "",row.requiredSkill or "",row.skillMeaning or "UNKNOWN",material,
        row.fishingType or "",row.precision or "HISTORICAL_PLAYER_POSITION",row.quality or "PROBABLE",
        row.possibleCatches or "",row.origin=="CATALOG" and (row.sourceSampleCount or 0) or row.sampleCount or 0,row.lastSeen or 0,
        row.origin=="CATALOG" and (row.sourceCatchSummary or "") or G.Sites:CatchSummary(row),table.concat(ids or {},","),
        buildNumber(tostring(row.clientBuild)) and tostring(row.clientBuild) or "UNRECORDED",
        row.clientPatch or "1.60.1",row.clientInterface or 16001}
    for i,v in ipairs(values) do values[i]=encode(v) end
    return table.concat(values,"|")
end
function T:ParseRow(line,m)
    local a=split(line)
    if not a or (#a~=18 and #a~=20 and #a~=21 and #a~=23) or a[1]~="S" then return nil,"INVALID_SITE_COLUMNS" end
    if #a==23 and (not patchName(a[22]) or not a[23]:match("^%d+$") or not G:Natural(tonumber(a[23]))) then
        return nil,"INVALID_OBSERVATION_CLIENT"
    end
    local r={externalID=a[2],kind=a[3],name=a[4],mapID=tonumber(a[5]),x=tonumber(a[6]),y=tonumber(a[7]),
        floorID=tonumber(a[8]),objectID=a[9]~="" and tonumber(a[9]) or nil,
        requiredSkill=a[10]~="" and tonumber(a[10]) or nil,skillMeaning=a[11],materialText=a[12],
        fishingType=a[13]~="" and a[13] or nil,precision=a[14],quality=a[15],possibleCatches=a[16],
        sourceSampleCount=tonumber(a[17]),observedAt=tonumber(a[18]),sourceCatchSummary=a[19] or "",materialIDs={},
        observationBuild=a[21],clientPatch=a[22],clientInterface=a[23] and tonumber(a[23])}
    for value in (a[20] or ""):gmatch("[^,]+") do r.materialIDs[#r.materialIDs+1]=tonumber(value) or false end
    return self:ValidateRow(r,m)
end
function T:ValidateRow(input,m)
    if type(input)~="table" then return nil,"SITE_NOT_A_RECORD" end
    local r={}
    for _,key in ipairs({"externalID","kind","name","mapID","x","y","floorID","objectID","requiredSkill",
        "skillMeaning","materialText","fishingType","precision","quality","possibleCatches","sourceSampleCount","observedAt","sourceCatchSummary","observationBuild","clientPatch","clientInterface"}) do
        r[key]=input[key]
    end
    r.materialIDs={}
    if input.materialIDs~=nil then
        if type(input.materialIDs)~="table" then return nil,"INVALID_MATERIAL_IDS" end
        local count=0
        for index,id in pairs(input.materialIDs) do
            count=count+1;if count>24 or not G:Natural(index) or index>24 or not G:Natural(id) then return nil,"INVALID_MATERIAL_IDS" end
            r.materialIDs[#r.materialIDs+1]=id
        end
        table.sort(r.materialIDs)
    end
    if not safe(r.externalID,48) or not r.externalID:match("^[%w_%-]+$") or not G.Storage.kinds[r.kind] or not G:Label(r.name) then
        return nil,"INVALID_SITE_ID_CATEGORY_OR_NAME"
    end
    if not G.map:Valid(r.mapID,r.x,r.y) or not G:Natural(r.floorID) or r.floorID~=r.mapID then return nil,"INVALID_COORDINATE_OR_FLOOR_ID" end
    if r.objectID~=nil and not G:Natural(r.objectID) then return nil,"INVALID_OBJECT_ID" end
    if not meanings[r.skillMeaning or "UNKNOWN"] then return nil,"INVALID_SKILL_THRESHOLD_MEANING" end
    if r.requiredSkill~=nil and (not G:Number(r.requiredSkill) or r.requiredSkill<0 or r.requiredSkill>1000 or r.requiredSkill%1~=0 or r.skillMeaning=="UNKNOWN") then
        return nil,"UNQUALIFIED_SKILL_THRESHOLD"
    end
    if r.requiredSkill==nil and r.skillMeaning~="UNKNOWN" then return nil,"THRESHOLD_VALUE_REQUIRED" end
    if (r.kind=="fish" or r.kind=="pool") and not fishing[r.fishingType or "UNKNOWN_WATER"] then return nil,"INVALID_FISHING_SOURCE" end
    if r.kind=="pool" and (r.fishingType~="POOL" or not r.objectID) then return nil,"POOL_OBJECT_IDENTITY_REQUIRED" end
    if r.fishingType=="POOL" and (r.kind~="pool" or not r.objectID) then return nil,"POOL_OBJECT_IDENTITY_REQUIRED" end
    if not safe(r.materialText or "",240) or not safe(r.possibleCatches or "",240) or not safe(r.sourceCatchSummary or "",240) or
        not G.Storage.quality[r.quality or "PROBABLE"] or
        (r.precision~="HISTORICAL_PLAYER_POSITION" and r.precision~="CATALOG_SITE_POSITION" and r.precision~="AREA") then
        return nil,"INVALID_SITE_PROVENANCE_OR_DETAIL"
    end
    if r.sourceSampleCount~=nil and (not G:Number(r.sourceSampleCount) or r.sourceSampleCount<0 or r.sourceSampleCount>999999 or r.sourceSampleCount%1~=0) then
        return nil,"INVALID_SOURCE_SAMPLE_COUNT"
    end
    r.id="catalog:"..m.sourceID..":"..r.externalID;r.origin="CATALOG";r.packID=m.sourceID;r.sourceRevision=m.revision
    r.sourceURL=m.sourceURL;r.sourceLabel=m.sourceLabel;r.license=m.license;r.permission=m.permission
    if r.observationBuild~=nil and r.observationBuild~="UNRECORDED" and not buildNumber(r.observationBuild) then return nil,"INVALID_OBSERVATION_BUILD" end
    if r.clientPatch~=nil and not patchName(r.clientPatch) or
        r.clientInterface~=nil and r.clientInterface~=m.interface then return nil,"INVALID_OBSERVATION_CLIENT" end
    r.clientBuild=r.observationBuild or tostring(m.build);r.observationBuild=nil
    r.clientPatch=r.clientPatch or m.patch;r.clientInterface=r.clientInterface or m.interface
    r.scope="OUTDOOR";r.instanceID=0;r.skillMeaning=r.skillMeaning or "UNKNOWN"
    if r.kind=="fish" or r.kind=="pool" then r.fishingType=r.fishingType or "UNKNOWN_WATER" end
    r.materialText=r.materialText or "";r.quality=r.quality or "PROBABLE";r.count=1;r.sampleCount=0
    r.firstSeen=G:Number(r.observedAt) and math.max(0,r.observedAt) or 0;r.lastSeen=r.firstSeen
    r.world=G.map:World(r.mapID,r.x,r.y);r.evidence="ATTRIBUTED_SOURCE_PACK"
    if not G.Sites:ValidCatalog(r) then return nil,"INVALID_CATALOG_RECORD" end
    return r
end
function T:Error(line,reason)
    self.rejected=(self.rejected or 0)+1
    if #self.errors<64 then self.errors[#self.errors+1]={line=line,reason=reason} end
end
function T:Cancel()
    self.generation=self.generation+1;local q=tasks();if q then q.Cancel(self.jobOwner) end
    self.staged=nil;self.providerJob=nil;self.providerDone=nil;self.merge=nil;self.state="CANCELLED";ui();return true
end
function T:Ready()
    local ok,why=G.Storage:Writable();if not ok then return false,why end
    if not G.Sites or G.Storage.account.schemaVersion~=2 then return false,"SCHEMA2_REQUIRED" end
    if not tasks() then return false,"TASKS_UNAVAILABLE" end
    return true
end
function T:Queue(callback,generation)
    local scheduler=tasks()
    local queued,reason=false,"TASKS_UNAVAILABLE"
    if scheduler then queued,reason=scheduler.Queue(self.jobOwner,callback,generation) end
    if not queued then
        self.staged=nil;self.merge=nil;self.providerDone=nil
        self.state=reason or "TASK_QUEUE_REJECTED";ui()
    end
    return queued,reason
end
function T:Begin(m)
    local ok,why=self:Ready();if not ok then return false,why end
    ok,why=self:Manifest(m);if not ok then return false,why end
    local a=G.Storage.account;local source=a.sources[m.sourceID]
    if source and m.revision<source.revision then return false,"OLDER_SOURCE_REVISION" end
    if not source then local count=0;for _ in pairs(a.sources) do count=count+1 end;if count>=16 then return false,"SOURCE_LIMIT" end end
    self:Cancel();self.manifest=G.Sites:Copy(m);self.staged={};self.errors={};self.rejected=0;self.processed=0
    self.hash=5381;self.state="IMPORTING";self.started=G:Now();return true
end
function T:Add(row,line,raw)
    self.processed=self.processed+1
    if self.processed>G.Sites.catalogLimit then self:Error(line,"SOURCE_SITE_LIMIT");return end
    if not row then return end
    if self.staged[row.id] then self:Error(line,"DUPLICATE_SOURCE_SITE_ID");return end
    self.staged[row.id]=row;self.hash=digest(self.hash,raw or self:RowText(row))
end
function T:Finish()
    local a=G.Storage.account;local m=self.manifest
    if self.rejected>0 then
        a.quarantine={sourceID=m.sourceID,revision=m.revision,at=G:When(),rejected=self.rejected,errors=G.Sites:Copy(self.errors)}
        self.state="REJECTED_WITH_QUARANTINE";self.staged=nil;ui();return false
    end
    local old=a.sources[m.sourceID]
    if old and old.revision==m.revision then
        if old.digest==self.hash then self.state="UNCHANGED_IDEMPOTENT" else self.state="REVISION_CONTENT_CONFLICT" end
        self.staged=nil;ui();return false
    end
    local merge=self.merge
    if not merge then merge={rows={},count=0,phase=1,key=nil,original=a.catalog};self.merge=merge end
    if merge.original~=a.catalog then self.state="CATALOG_CHANGED_RETRY";self.staged=nil;self.merge=nil;ui();return false end
    for _=1,32 do
        local row
        if merge.phase==1 then
            merge.key,row=next(a.catalog,merge.key)
            if not merge.key then merge.phase=2;merge.key=nil end
            if row and row.packID~=m.sourceID then merge.rows[merge.key]=row;merge.count=merge.count+1 end
        end
        if merge.phase==2 then
            merge.key,row=next(self.staged,merge.key)
            if not merge.key then merge.phase=3;break end
            merge.rows[merge.key]=row;merge.count=merge.count+1
        end
    end
    if merge.phase<3 then self.state="COMMITTING_SOURCE";ui();return true end
    if merge.count>G.Sites.catalogLimit then self.state="CATALOG_CAPACITY_EXCEEDED";self.staged=nil;self.merge=nil;ui();return false end
    -- One pointer swap commits a complete source correction. Personal sites
    -- and character hides are separate and remain untouched.
    a.catalog=merge.rows;a.sources[m.sourceID]={revision=m.revision,digest=self.hash,license=m.license,
        sourceURL=m.sourceURL,sourceLabel=m.sourceLabel,permission=m.permission,count=self.processed,importedAt=G:When(),
        build=tostring(m.build),patch=m.patch,interface=m.interface,flavor=m.flavor}
    G.state.catalogCount=merge.count;G.Storage:Touch("account");G.Sites:Reindex();self.staged=nil;self.merge=nil
    self.state="IMPORTED";G.Records:Changed();if G.Pins then G.Pins:Dirty() end;ui();return false
end
function T:ImportText(text)
    if type(text)~="string" or #text>self.limit then return false,"TEXT_TOO_LARGE" end
    local header,offset=text:match("^([^\r\n]+)\r?\n()")
    if not header then return false,"HEADER_AND_SITE_ROWS_REQUIRED" end
    if #header>1024 then return false,"HEADER_TOO_LARGE" end
    local m,why=self:ParseHeader(header);if not m then return false,why end
    local ok;ok,why=self:Begin(m);if not ok then return false,why end
    local generation=self.generation;local line=1
    return self:Queue(function()
        if generation~=self.generation then return false end
        if G:Combat() then self.state="IMPORT_PAUSED_COMBAT";ui();return true end
        self.state="IMPORTING"
        for _=1,32 do
            if offset>#text then return self:Finish() end
            local ending=text:find("\n",offset,true) or (#text+1)
            local value=text:sub(offset,ending-1):gsub("\r$","");offset=ending+1;line=line+1
            if line>2050 then self:Error(line,"SOURCE_LINE_LIMIT");return self:Finish() end
            if value~="" then
                local row,reason
                if #value>4096 then reason="SITE_LINE_TOO_LARGE" else row,reason=self:ParseRow(value,m) end
                if not row then self:Error(line,reason) end
                self:Add(row,line,value)
            end
        end
        ui();return true
    end,generation)
end
function T:RegisterProvider(owner,manifest,callback)
    if not G:Text(owner,64) or not owner:match("^[%w_%-]+$") or type(callback)~="function" then return false,"INVALID_PROVIDER" end
    local ok,why=self:Manifest(manifest);if not ok then return false,why end
    local count=0;for _ in pairs(self.providers) do count=count+1 end
    if not self.providers[owner] and count>=8 then return false,"PROVIDER_LIMIT" end
    self.providers[owner]={manifest=G.Sites:Copy(manifest),readPage=callback};ui();return true
end
function T:ImportProvider(owner)
    local p=self.providers[owner];if not p then return false,"PROVIDER_NOT_AVAILABLE" end
    local ok,why=self:Begin(p.manifest);if not ok then return false,why end
    local generation=self.generation;local cursor=nil;local pages=0
    return self:Queue(function()
        if generation~=self.generation then return false end
        if G:Combat() then self.state="IMPORT_PAUSED_COMBAT";return true end
        if self.providerDone then return self:Finish() end
        pages=pages+1
        local called,rows,nextCursor=pcall(p.readPage,cursor,32)
        if not called or not densePage(rows) or pages>64 or (nextCursor~=nil and nextCursor==cursor) then
            self:Error(pages,"PROVIDER_PAGE_INVALID");return self:Finish()
        end
        for _,input in ipairs(rows) do local row,reason=self:ValidateRow(input,p.manifest)
            if not row then self:Error(self.processed+1,reason) end;self:Add(row,self.processed+1) end
        cursor=nextCursor;if cursor==nil then self.providerDone=true;return self:Finish() end;ui();return true
    end,generation)
end
function T:Export(scope,source)
    local ok,why=self:Ready();if not ok then return false,why end
    scope=scope or "PERSONAL"
    local a=G.Storage.account;local m
    if scope=="PERSONAL" then
        -- The header identifies this export client. Per-row fields preserve
        -- the original build/patch/interface even across later updates.
        local identity,reason=self:ClientIdentity();if not identity then return false,reason end
        m={sourceID="personal_observations",revision=math.max(1,a.revision),flavor=identity.flavor,patch=identity.patch,
            build=identity.build,interface=identity.interface,
            coordinates="UI_MAP_NORMALIZED",license="PERSONAL",sourceURL="local://personal-observations",sourceLabel="Personal gathering observations"}
    elseif scope=="CATALOG" and a.sources[source] then
        local s=a.sources[source];m={sourceID=source,revision=s.revision,flavor=s.flavor or "Forever",patch=s.patch or "1.60.1",build=s.build or "70959",interface=s.interface or 16001,
            coordinates="UI_MAP_NORMALIZED",license=s.license,sourceURL=s.sourceURL,sourceLabel=s.sourceLabel,permission=s.permission}
    else return false,"EXPLICIT_EXPORT_SCOPE_REQUIRED" end
    local manifestOK,manifestWhy=self:Manifest(m)
    if not manifestOK then return false,manifestWhy end
    self:Cancel();self.state="EXPORTING";self.processed=0;self.output=nil
    local generation=self.generation;local revision=a.revision;local iterator=G.Sites:Each();local lines={self:Header(m)}
    return self:Queue(function()
        if generation~=self.generation then return false end
        if revision~=a.revision then self.state="EXPORT_SOURCE_CHANGED_RETRY";ui();return false end
        if G:Combat() then self.state="EXPORT_PAUSED_COMBAT";return true end
        self.state="EXPORTING"
        for _=1,32 do
            local _,row=iterator()
            if not row then self.output=table.concat(lines,"\n").."\n";self.state="EXPORTED";ui();return false end
            if (scope=="PERSONAL" and row.origin~="CATALOG") or (scope=="CATALOG" and row.packID==source) then
                lines[#lines+1]=self:RowText(row);self.processed=self.processed+1
            end
        end
        ui();return true
    end,generation)
end
function T:QuarantineText()
    local q=G.Storage.account and G.Storage.account.quarantine or {}
    local lines={"Gather import quarantine: "..tostring(q.sourceID or "none").." revision "..tostring(q.revision or "-")}
    for _,error in ipairs(q.errors or {}) do lines[#lines+1]="Row "..error.line..": "..error.reason end
    return table.concat(lines,"\n")
end
