local _,G=...
G.Storage={readOnly=false,reason="UNINITIALIZED"}
local S=G.Storage
local kinds={herb=true,ore=true,fish=true,pool=true,skin=true,treasure=true}
local quality={CONFIRMED=true,PROBABLE=true,MANUAL=true}
local function freshAccount()
    return {schemaVersion=1,sentinel="GATHER_ACCOUNT_V1",revision=0,nextID=1,records={},
        preferences={enabled=true,showMapPins=true,showMinimapPins=true,category="all",maxPins=100}}
end
local function freshCharacter()
    return {schemaVersion=1,sentinel="GATHER_CHAR_V1",revision=0,hidden={},notes={}}
end
function S:ValidateRecord(record)
    return type(record)=="table" and G:Natural(record.id) and record.id<=2147483647 and
        G:Label(record.name) and kinds[record.kind]==true and quality[record.quality]==true and
        G:Natural(record.mapID) and G.map and G.map:Valid(record.mapID,record.x,record.y) and
        G:Number(record.firstSeen) and G:Number(record.lastSeen) and
        G:Natural(record.count) and record.count<1000000 and
        G:Number(record.instanceID) and record.instanceID>=0 and record.instanceID%1==0 and record.instanceID<100000000 and
        (record.world==nil or
         (type(record.world)=="table" and G:Number(record.world.x) and
          G:Number(record.world.y) and G:Number(record.world.continent)))
end
function S:Initialize()
    if not G.state.clientAllowed then
        self.readOnly=true;self.reason="UNSUPPORTED_CLIENT_NO_WRITES";return
    end
    if MirageIntelGatherDB==nil then MirageIntelGatherDB=freshAccount() end
    if MirageIntelGatherCharDB==nil then MirageIntelGatherCharDB=freshCharacter() end
    self.account=MirageIntelGatherDB
    self.character=MirageIntelGatherCharDB
    local a,b=self.account,self.character
    if not G:Readable(a) or not G:Readable(b) or type(a)~="table" or type(b)~="table" or
       (a.schemaVersion~=1 and a.schemaVersion~=2) or b.schemaVersion~=1 or not G:Number(a.revision) or a.revision<0 or a.revision%1~=0 or
       not G:Number(b.revision) or b.revision<0 or b.revision%1~=0 or not G:Natural(a.nextID) or
       type(a.records)~="table" or type(b.hidden)~="table" or type(b.notes)~="table" or
       type(a.preferences)~="table" or type(a.preferences.enabled)~="boolean" or
       type(a.preferences.showMapPins)~="boolean" or not G:Natural(a.preferences.maxPins) or
       (a.preferences.showMinimapPins~=nil and type(a.preferences.showMinimapPins)~="boolean") or
       a.preferences.maxPins>150 or
       (a.preferences.category~="all" and not kinds[a.preferences.category]) then
        self.readOnly=true;self.reason="CORRUPT_OR_NEWER_SCHEMA_PRESERVED";return
    end
    local total,maxID=0,0
    for id,record in pairs(a.records) do
        total=total+1
        if total>G.maxRecords or not G:Natural(id) or (type(record)~="table" or id~=record.id or not self:ValidateRecord(record)) then
            self.readOnly=true;self.reason="CORRUPT_RECORDS_PRESERVED";return
        end
        maxID=math.max(maxID,id)
    end
    if a.nextID<=maxID then self.readOnly=true;self.reason="INVALID_COUNTER_PRESERVED";return end
    local hiddenCount=0
    for id,hidden in pairs(b.hidden) do
        hiddenCount=hiddenCount+1
        if hiddenCount>G.maxRecords or not G:Natural(id) or hidden~=true then
            self.readOnly=true;self.reason="CORRUPT_HIDDEN_STATE_PRESERVED";return
        end
    end
    G.state.observations=total
    if a.schemaVersion==1 and G.Sites and not self.legacySnapshot then self.legacySnapshot=G.Sites:Copy(a) end
    -- Keep all historic rows/IDs, but do not mislabel earlier type-only
    -- source matches as confirmed. Do not mutate saves on unsupported builds.
    if G.state.clientAllowed then
        -- Additive preference only. Existing record IDs, confidence, notes and
        -- hidden flags keep schema 1 and remain readable by the prior release.
        if a.preferences.showMinimapPins==nil then
            a.preferences.showMinimapPins=true;self:Touch("account")
        end
        local rescored=0
        for _,record in pairs(a.records) do
            if record.quality=="CONFIRMED" and record.evidence=="CAST_AND_COMPATIBLE_LOOT_SOURCE" then
                record.quality="PROBABLE"
                record.evidence="LEGACY_LOOT_SOURCE_UNVERIFIED"
                rescored=rescored+1
            end
        end
        if rescored>0 then self:Touch("account");G.state.legacyConfidenceAdjusted=rescored end
    end
    self.reason="RESTORE_REQUIRES_LIVE_RELOAD_AND_RESTART_PROOF"
end
function S:Writable()
    if self.readOnly then return false,self.reason end
    if not G.state.clientAllowed then return false,"UNSUPPORTED_BUILD" end
    return true
end
function S:Touch(scope)
    local root=scope=="character" and self.character or self.account
    root.revision=math.min(2147483647,root.revision+1)
end
function S:Hidden(id)
    if type(id)=="string" then
        id=id:gsub("^gather:","")
        local numeric=tonumber(id);if numeric then id=numeric end
    end
    return self.character and (type(id)=="number" and self.character.hidden[id]==true or
        type(id)=="string" and self.character.hiddenCatalog and self.character.hiddenCatalog[id]==true) or false
end
function S:Hide(id,hide)
    local ok,reason=self:Writable()
    if not ok then return false,reason end
    local row=G.Sites and G.Sites:Get(id) or self.account.records[id]
    if not row then return false,"UNKNOWN_RECORD" end
    id=row.id
    if type(hide)~="boolean" then return false,"INVALID_HIDE_STATE" end
    local hidden=type(id)=="number" and self.character.hidden or self.character.hiddenCatalog
    if not hidden then return false,"UNKNOWN_RECORD" end
    if hide and type(id)=="string" and not hidden[id] then
        local count=0;for _ in pairs(hidden) do count=count+1 end
        if count>=(G.Sites and G.Sites.catalogLimit or 2000) then return false,"HIDDEN_CATALOG_CAPACITY" end
    end
    if hide then hidden[id]=true else hidden[id]=nil end
    self:Touch("character")
    if G.Records then G.Records:Changed(id) end
    if G.Pins then G.Pins:Dirty() end
    return true,"PENDING_CLIENT_SAVE"
end
function S:SetPreference(key,value)
    local ok,reason=self:Writable()
    if not ok then return false,reason end
    local a=self.account.preferences
    if key=="enabled" or key=="showMapPins" or key=="showMinimapPins" or key=="professionOnly" or key=="knownSkillOnly" then
        if type(value)~="boolean" then return false,"INVALID_PREFERENCE" end
    elseif key=="category" then
        if value~="all" and not kinds[value] then return false,"INVALID_CATEGORY" end
    elseif key=="maxPins" then
        if not G:Natural(value) or value>80 then return false,"INVALID_PIN_CAP" end
    elseif key=="material" then
        if type(value)~="string" or #value>60 or value:find("[|%c]") then return false,"INVALID_MATERIAL" end
    elseif key=="sourceFilter" then
        if value~="all" and value~="PERSONAL" and value~="CATALOG" then return false,"INVALID_SOURCE_FILTER" end
    else return false,"UNKNOWN_SETTING" end
    if a[key]==value then return true,"UNCHANGED" end
    a[key]=value;self:Touch("account")
    if G.Records then G.Records:Changed() end
    if key=="enabled" and not value and G.Collector then G.Collector:Reset("RECORDING_DISABLED") end
    if key=="enabled" and not value and G.Fishing then G.Fishing:Reset("RECORDING_DISABLED") end
    if G.Pins then G.Pins:Dirty() end
    if G.UI then G.UI:Update() end
    return true,"PENDING_CLIENT_SAVE"
end
S.kinds=kinds
S.quality=quality
