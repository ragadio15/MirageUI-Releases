-- MirageGather: evidence-first, local-only observation recorder.
-- Separate addon; no UI replacement and no protected gameplay actions.
local name,G=...
G.name=name
G.version="1.11.2"
G.apiVersion=1
G.core=MirageIntelCoreAPI
G.state={initialized=false,events=0,errors=0,status="STARTING",nativeVerification="NOT_RUN",observations=0}
G.maxRecords=1800
function G:Readable(v)
    if v==nil then return true end
    if type(issecretvalue)=="function" then
        local ok,secret=pcall(issecretvalue,v)
        if not ok or secret then return false end
    end
    if type(canaccessvalue)=="function" then
        local ok,yes=pcall(canaccessvalue,v)
        if not ok or not yes then return false end
    end
    return true
end
function G:Number(v)
    return self:Readable(v) and type(v)=="number" and v==v and v>-math.huge and v<math.huge
end
function G:Natural(v) return self:Number(v) and v>0 and v%1==0 end
function G:Text(v,max)
    max=max or 90
    return self:Readable(v) and type(v)=="string" and #v>0 and #v<=max and v or nil
end
function G:Label(v)
    return self:Text(v,90) and not v:find("[|%c]") and v or nil
end
function G:Call(fn,...)
    if not self:Readable(fn) or type(fn)~="function" then return nil,false end
    local ok,a,b,c,d,e,f,h,j=pcall(fn,...)
    if not ok then return nil,false end
    if not self:Readable(a) or not self:Readable(b) or not self:Readable(c) or
       not self:Readable(d) or not self:Readable(e) or not self:Readable(f) or
       not self:Readable(h) or not self:Readable(j) then return nil,false end
    return a,true,b,c,d,e,f,h,j
end
function G:Now()
    local t,ok=self:Call(GetTime)
    return ok and self:Number(t) and t or 0
end
function G:When()
    local timestamp,ok=self:Call(time)
    if ok and self:Number(timestamp) and timestamp>0 then return math.floor(timestamp) end
    return 0
end
function G:Fault(code)
    self.state.errors=self.state.errors+1
    self.state.lastError=code
end
function G:Print(message)
    if DEFAULT_CHAT_FRAME and type(DEFAULT_CHAT_FRAME.AddMessage)=="function" then
        DEFAULT_CHAT_FRAME:AddMessage("|cffe8b77dGather Mate:|r "..tostring(message))
    end
end
function G:Combat()
    local value,ok=self:Call(InCombatLockdown)
    -- A successful nil is the legacy WoW unlocked result, not an API failure.
    return not ok or (value~=nil and value~=false)
end
function G:Allowed()
    local core=self.core
    if type(core)~="table" or core.apiVersion~=1 or type(core.GetCapabilities)~="function" then return false end
    local info,ok=self:Call(core.GetCapabilities)
    local c=ok and type(info)=="table" and info.client
    if type(c)~="table" then return false end
    self.state.clientBuild=self:Text(c.build,20) or "unknown"
    self.state.clientPatch=self:Text(c.patch,80)
    self.state.clientInterface=self:Natural(c.interface) and c.interface or nil
    self.state.clientFlavor=self.state.clientInterface==16001 and "Forever" or
        self.state.clientInterface and ("Client"..self.state.clientInterface) or nil
    return c.allowed==true and type(core.Map)=="table" and
        type(core.Map.Valid)=="function" and type(core.Map.Player)=="function"
end
function G:Initialize()
    if self.state.initialized then return end
    self.state.clientAllowed=self:Allowed()
    self.map=self.core and self.core.Map
    self.Storage:Initialize()
    if self.Sites then self.Sites:Initialize() end
    self.state.status=not self.state.clientAllowed and "UNSUPPORTED_BUILD" or
        self.Storage.readOnly and "STORAGE_READ_ONLY" or "READY_NATIVE_UNTESTED"
    self.state.initialized=true
    self.API:Install()
    if self.core and type(self.core.RegisterModule)=="function" then
        self.core.RegisterModule("MirageIntel_Gather",1,{harvestObservations=true,historicalNodes=true,
            manualCorrections=true,mapPins=true,optionalNavigation=true,priceProvider=false})
    end
    self.Commands:Install()
    self.Records:Initialize()
    self.Session:Initialize()
    self.Pins:Initialize()
end
