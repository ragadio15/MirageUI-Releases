local _,G=...
G.API={}
local A=G.API
local function snapshot(data)
    if G.core and type(G.core.Copy)=="function" then return G.core.Copy(data) end
    return nil
end
function A:RecordHere(kind,name)
    if G:Combat() then return false,"COMBAT_MANUAL_RECORD_UNAVAILABLE" end
    if not G.Storage.kinds[kind] or not G:Label(name) then return false,"INVALID_CATEGORY_OR_NAME" end
    local position,reason=G.Observations:Context()
    if not position then return false,reason end
    return G.Observations:Insert(kind,name,"MANUAL","PLAYER_ENTERED",position)
end
function A:Install()
    local p={apiVersion=1,gatheringSessionVersion=2,siteSchemaVersion=2,transferVersion=2,
        version=G.version,targetBuild=G.state.clientBuild or "unknown",nativeVerification="NOT_RUN"}
    function p.GetPreferences()
        return snapshot(G.Storage.account and G.Storage.account.preferences or {})
    end
    function p.GetStatus()
        return snapshot({state=G.state,status=G.state.status,storage=G.Storage.reason,
            readOnly=G.Storage.readOnly,recordCount=G.state.observations,
            catalogCount=G.state.catalogCount,schemaVersion=G.Storage.account and G.Storage.account.schemaVersion,
            fishing=G.Fishing and G.Fishing.status,
            transfer=G.Transfer and {state=G.Transfer.state,processed=G.Transfer.processed,rejected=G.Transfer.rejected},
            accountRevision=G.Storage.account and G.Storage.account.revision,
            charRevision=G.Storage.character and G.Storage.character.revision,
            preferences=G.Storage.account and G.Storage.account.preferences,
            lastBlocked=G.Collector.lastBlocked,collectorReason=G.Collector.lastLootReason,
            publication=G.Records.status,gatheringSession=G.Session.status,
            navigation=G.Session:Snapshot(),lastSessionOutcome=G.Session.lastOutcome,
            mapPresentation=G.Pins.status or "NOT_READY",nativeVerification="NOT_RUN"})
    end
    function p.GetGatherLocations(filters,limit,offset)
        local rows,count=G.Observations:List(filters,limit,offset)
        return snapshot(rows),count
    end
    function p.GetNearestKnown(filters)
        local record,reason=G.Observations:Nearest(filters)
        return snapshot(record),reason
    end
    -- Optional WealthCraft integration: only complete exact item hyperlinks
    -- from the requesting user are qualified. Gathering sites are NOT item
    -- listings, and labels/material names never imply an item ID or live price.
    function p.GetMarketReferenceForItemLink(link)
        if not G:Text(link,600) or not link:find('item:',1,true) then return nil,'FULL_ITEM_LINK_REQUIRED' end
        local provider=_G.WealthcraftAPI
        if type(provider)~='table' or provider.priceViewContractVersion~=1 or
            type(provider.GetPriceViewForItemLink)~='function' then
            return nil,'MARKET_REFERENCE_PROVIDER_UNAVAILABLE'
        end
        local ok,view,reason=pcall(provider.GetPriceViewForItemLink,link,
            {consumer='MirageGather',readOnly=true})
        if not ok then return nil,'MARKET_REFERENCE_PROVIDER_FAILED' end
        if type(view)~='table' then return nil,reason or 'NO_VERIFIED_SAVED_QUOTE' end
        local item,market,roles,freshness,provenance=view.item,view.market,view.roles,view.freshness,view.provenance
        local ref=type(roles)=='table' and roles.reference
        if view.model~='WEALTHCRAFT_PRICE_VIEW_1' or view.readOnly~=true or
            type(item)~='table' or item.precision~='EXACT_WEALTHCRAFT_VARIANT' or
            item.requestedLink~=link or type(ref)~='table' or ref.kind~='HISTORICAL_REFERENCE' or
            not G:Natural(ref.valueCopper) or type(market)~='table' or type(freshness)~='table' or
            type(provenance)~='table' or type(freshness.ageSeconds)~='number' or
            freshness.ageSeconds<0 or freshness.ageSeconds~=freshness.ageSeconds then
            return nil,'PRICE_VIEW_UNQUALIFIED' end
        return snapshot({label='Market reference',valueCopper=ref.valueCopper,
            measuredRange=type(roles.measuredRange)=='table' and
                {label='Measured Range',low=roles.measuredRange.lowerCopper,
                 high=roles.measuredRange.upperCopper} or nil,
            ageSeconds=freshness.ageSeconds,source=provenance.source,
            sourceRevision=provenance.revision,marketMode=market.mode,
            status=view.status,precision=item.precision,
            basis='RECORDED_ASKS_PER_ITEM_NOT_SALES',currentLive=false}), 'AVAILABLE'
    end
    function p.SetGatheringSession(enabled) return G.Session:SetEnabled(enabled) end
    function p.SkipGatheringSite() return G.Session:Skip() end
    function p.GetGatheringSession()
        return snapshot({status=G.Session.status,navigation=G.Session:Snapshot(),
            publication=G.Records.status,source="LOCAL_OBSERVATION",spawnState="HISTORICAL_ONLY",
            harvestability="UNKNOWN",lastOutcome=G.Session.lastOutcome})
    end
    function p.GetSiteRecord(id)
        local row=G.Sites and G.Sites:Get(id) or G:Natural(id) and G.Storage.account and G.Storage.account.records[id]
        return snapshot(row and G.Records:Record(row))
    end
    function p.BeginImportText(text) return G.Transfer:ImportText(text) end
    function p.BeginExport(scope,source) return G.Transfer:Export(scope,source) end
    function p.CancelTransfer() return G.Transfer:Cancel() end
    function p.GetTransferStatus()
        return snapshot({state=G.Transfer.state,processed=G.Transfer.processed,rejected=G.Transfer.rejected,
            errors=G.Transfer.errors,source=G.Transfer.manifest})
    end
    function p.GetExportText() return G.Transfer.output end
    function p.ExportQuarantine() return G.Transfer:QuarantineText() end
    function p.RegisterSourceProvider(owner,manifest,readPage) return G.Transfer:RegisterProvider(owner,manifest,readPage) end
    function p.ImportSourceProvider(owner) return G.Transfer:ImportProvider(owner) end
    function p.ResetScope(scope,source) return G.Sites:Reset(scope,source) end
    function p.OpenData() return G.DataUI:Open() end
    function p.RecordHere(kind,name) return A:RecordHere(kind,name) end
    function p.HideObservation(id,hide) return G.Storage:Hide(id,hide) end
    function p.SelectDestination(id) return G.Nav:Select(id) end
    function p.ClearDestination() return G.Nav:Clear() end
    function p.SetPreference(key,value) return G.Storage:SetPreference(key,value) end
    function p.ExportText(limit,offset) return G.Observations:Export(limit,offset) end
    function p.Open() return G.UI:Open() end
    MirageGatherAPI=p
    if G.core and type(G.core.RegisterService)=="function" then
        local ok=G.core.RegisterService("Gather","MirageIntel_Gather",1,p)
        if not ok then G:Fault("CORE_GATHER_SERVICE_COLLISION") end
    end
end
