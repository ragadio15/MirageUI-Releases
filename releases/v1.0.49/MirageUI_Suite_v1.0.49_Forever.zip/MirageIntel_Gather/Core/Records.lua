-- Canonical publication of personal history and explicitly admitted catalogs.
-- Source SavedVariables remain authoritative; publication is not a live-node claim.
local _,G=...
G.Records={owner="MirageIntel_Gather",jobOwner="MirageIntel_Gather.records",status="NOT_STARTED"}
local R=G.Records
local function service(name)
    local core=G.core
    if not core or type(core.GetService)~="function" then return nil end
    local result,ok=G:Call(core.GetService,name,1)
    return ok and type(result)=="table" and result or nil
end
function R:Revision()
    local a,b=G.Storage.account,G.Storage.character
    return tostring(a and a.revision or 0)..":"..tostring(b and b.revision or 0)
end
function R:Record(row,skills)
    if not row or not (row.origin=="CATALOG" and G.Sites and G.Sites:ValidCatalog(row) or G.Storage:ValidateRecord(row)) then return nil end
    local p=G.Storage.account.preferences
    local selected=p.category=="all" or p.category==row.kind
    local material,ids
    if G.Sites then selected=G.Sites:Matches(row,nil,skills);material,ids=G.Sites:Materials(row) end
    return {id="gather:"..row.id,siteID="gather:"..row.id,recordID=row.id,layer="resources",
        mapID=row.mapID,x=row.x,y=row.y,label=row.name,name=row.name,
        kind="gather",category=row.kind,source=row.origin=="CATALOG" and "QUALIFIED_SOURCE_PACK" or "LOCAL_OBSERVATION",
        origin=row.origin or "PERSONAL",confidence=row.quality,precision=row.precision or "HISTORICAL_PLAYER_POSITION",
        sourceLabel=row.sourceLabel or "Personal observations",sourceURL=row.sourceURL or "local://personal-observations",
        license=row.license or "PERSONAL",packID=row.packID,packRevision=row.sourceRevision,
        coverage="RECORD_SPECIFIC",materialText=material or row.materialText or "",materialIDs=ids,
        materialSummary=material or row.materialText or "",objectID=row.objectID,floorID=row.floorID or row.mapID,
        professionID=({herb=182,ore=186,skin=393,fish=356,pool=356})[row.kind],
        requiredSkill=row.requiredSkill,skillMeaning=row.skillMeaning or "UNKNOWN",fishingType=row.fishingType,
        sampleCount=row.sampleCount or 0,sourceSampleCount=row.sourceSampleCount,
        catchSummary=G.Sites and G.Sites:CatchSummary(row),sourceCatchSummary=row.sourceCatchSummary,possibleCatches=row.possibleCatches,
        availability="UNKNOWN",availabilityReason="Historical location; live spawn not observed",
        observedAt=row.lastSeen,firstSeen=row.firstSeen,count=row.count,
        evidence=row.evidence,clientBuild=row.clientBuild,instanceID=row.instanceID,
        scope=row.scope,hidden=G.Storage:Hidden(row.id),
        showWorld=p.showMapPins and selected,showMinimap=p.showMinimapPins~=false and selected,
        harvestability="UNKNOWN",spawnState="HISTORICAL_ONLY",world=row.world}
end
function R:Diagnostics()
    local diag=service("Diagnostics")
    if diag and type(diag.Set)=="function" then
        diag.Set(self.owner,{publication=self.status,revision=self:Revision(),published=self.published or 0,
            nativeVerification="NOT_RUN",spawnState="HISTORICAL_ONLY"})
    end
end
function R:Rebuild()
    local records,tasks=service("WorldRecords"),service("Tasks")
    if not records or not tasks then self.status="SHARED_SERVICES_UNAVAILABLE";return false end
    if self.token then records.CancelSnapshot(self.owner,self.token);self.token=nil end
    tasks.Cancel(self.jobOwner)
    if G.Storage.readOnly or not G.state.clientAllowed then
        records.ClearOwner(self.owner);self.status="HISTORY_NOT_ADMITTED";self:Diagnostics();return false
    end
    local revision=self:Revision()
    local skillRevision=G.Session and G.Session.skillRevision or 0
    local skills=G.Session and G.Session:Skills() or {}
    local token,why=records.BeginSnapshot(self.owner,revision)
    if not token then self.status=why or "SNAPSHOT_UNAVAILABLE";return false end
    self.token=token;self.status="PUBLISHING_HISTORY"
    local rows=G.Storage.account.records
    local iterator=G.Sites and G.Sites:Each()
    local key,count=nil,0
    local queued,reason=tasks.Queue(self.jobOwner,function()
        if self.token~=token then return false end
        if revision~=self:Revision() or rows~=G.Storage.account.records or
            skillRevision~=(G.Session and G.Session.skillRevision or 0) then
            self:Rebuild();return false
        end
        local batch={}
        for _=1,32 do
            local row
            if iterator then key,row=iterator() else key,row=next(rows,key) end
            if not key then break end
            local record=self:Record(row,skills)
            if record then batch[#batch+1]=record;count=count+1 end
        end
        if #batch>0 then
            local ok,err=records.PutBatch(self.owner,token,batch)
            if not ok then
                records.CancelSnapshot(self.owner,token);self.token=nil
                self.status=err or "PUBLICATION_REJECTED";self:Diagnostics();return false
            end
        end
        if key then return true end
        local ok,err=records.CommitSnapshot(self.owner,token)
        -- A world-record listener can already have started the next publication.
        if self.token~=token then return false end
        self.token=nil
        self.status=ok and "LOCAL_HISTORY_PUBLISHED" or (err or "PUBLICATION_REJECTED")
        if ok then self.published=count;self.publishedSkills=G.core.Copy(skills) end
        self:Diagnostics()
        return false
    end)
    if not queued then
        records.CancelSnapshot(self.owner,token);self.token=nil
        self.status=reason or "PUBLICATION_QUEUE_UNAVAILABLE";self:Diagnostics();return false
    end
    return true
end
-- Profession changes affect stored display flags as well as route selection.
-- Coalesce native event bursts, compare at most 32 sites per slice, and publish
-- a new atomic snapshot only if an actual filter decision changes. An ordinary
-- skill point that crosses no threshold must not churn every map pin.
function R:RefreshSkillVisibility()
    local tasks=service("Tasks")
    if not tasks or G.Storage.readOnly or not G.state.clientAllowed then return false end
    self.skillSerial=(self.skillSerial or 0)+1
    local serial=self.skillSerial
    local revision=self:Revision()
    local skillRevision=G.Session and G.Session.skillRevision or 0
    local previous,skills,iterator
    local queued=tasks.Queue("MirageIntel_Gather.skillVisibility",function()
        if serial~=self.skillSerial or G.Storage.readOnly or not G.state.clientAllowed then return false end
        if revision~=self:Revision() or skillRevision~=(G.Session and G.Session.skillRevision or 0) then
            self:RefreshSkillVisibility();return false
        end
        if self.token or not self.publishedSkills or not G.Sites then self:Rebuild();return false end
        if not skills then
            previous=G.core.Copy(self.publishedSkills)
            skills=G.core.Copy(G.Session:Skills());iterator=G.Sites:Each()
        end
        for _=1,32 do
            local id,row=iterator()
            if not id then
                self.publishedSkills=skills
                return false
            end
            local before=G.Sites:Matches(row,nil,previous)
            local after=G.Sites:Matches(row,nil,skills)
            if before~=after then
                self:Rebuild()
                if G.Pins then G.Pins:Dirty() end
                return false
            end
        end
        return true
    end,skillRevision)
    return queued==true
end
function R:Changed(id)
    local row=id and (G.Sites and G.Sites:Get(id) or G.Storage.account.records[id])
    -- A normal observation/quality update must not invalidate the route
    -- generation captured before that same harvest (especially in combat).
    -- Removed or character-hidden rows, and global preference changes, do
    -- require immediate revalidation of Wayfinder's retained destination.
    local localOnly=id~=nil and row~=nil and not G.Storage:Hidden(id)
    if G.Session then G.Session:Invalidate("HISTORY_CHANGED",localOnly) end
    if self.token or self.status~="LOCAL_HISTORY_PUBLISHED" or not id then return self:Rebuild() end
    local records=service("WorldRecords")
    if not records then self.status="SHARED_SERVICES_UNAVAILABLE";return false end
    local record=self:Record(row)
    local ok,why
    if record then ok,why=records.Upsert(self.owner,record,self:Revision())
    else ok,why=records.Remove(self.owner,"gather:"..id,self:Revision()) end
    if not ok then self.status=why or "PUBLICATION_REJECTED" else self.published=G.state.observations+(G.state.catalogCount or 0) end
    self:Diagnostics()
    return ok
end
function R:Initialize() return self:Rebuild() end
