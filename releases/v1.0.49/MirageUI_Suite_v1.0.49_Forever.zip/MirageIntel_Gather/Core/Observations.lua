local _,G=...
G.Observations={}
local O=G.Observations
local function allRows()
    if G.Sites then return G.Sites:Each() end
    local rows=G.Storage.account and G.Storage.account.records or {};local key=nil
    return function()local row;key,row=next(rows,key);return key,row end
end
function O:Context()
    if not G.state.clientAllowed or not G.map then return nil,"UNSUPPORTED_BUILD" end
    if not G:Natural(G.state.clientInterface) then return nil,"CLIENT_IDENTITY_UNAVAILABLE" end
    -- We do not infer matching dungeon instances from repeated map IDs.
    -- The alpha stores outdoors only until instance identity is qualified.
    local active,ok=G:Call(IsInInstance)
    if not ok or type(active)~="boolean" then return nil,"INSTANCE_CONTEXT_UNKNOWN" end
    if active then return nil,"INSTANCE_RECORDING_NOT_YET_SUPPORTED" end
    local player,why=G.map:Player()
    if not player or not G.map:Valid(player.mapID,player.x,player.y) then
        return nil,why or "MAP_POSITION_UNAVAILABLE"
    end
    local zone,zok=G:Call(GetZoneText);local subzone,sok=G:Call(GetSubZoneText)
    return {mapID=player.mapID,floorID=player.floorID or player.mapID,x=player.x,y=player.y,
        zone=zok and G:Label(zone) or nil,subzone=sok and G:Label(subzone) or nil,
        world=player.world,instanceID=0,scope="OUTDOOR",scopeReason=player.worldReason}
end
function O:Comparable(row,context,kind,name)
    if G.Sites then return G.Sites:Comparable(row,context,kind,name) end
    if row.kind~=kind or row.name~=name or row.mapID~=context.mapID or
       row.instanceID~=context.instanceID or row.scope~="OUTDOOR" then return false end
    if context.world and row.world and
       context.world.continent==row.world.continent then
        local dx=row.world.x-context.world.x
        local dy=row.world.y-context.world.y
        return dx*dx+dy*dy<=20*20
    end
    -- Map-space fallback is conservative, map-only and never a yard distance.
    if context.world or row.world then return false end
    local dx=row.x-context.x;local dy=row.y-context.y
    return dx*dx+dy*dy<=.001*.001
end
function O:Insert(kind,name,quality,reason,context)
    local writable,why=G.Storage:Writable()
    if not writable then return false,why end
    if not G:Natural(G.state.clientInterface) then return false,"CLIENT_IDENTITY_UNAVAILABLE" end
    if not G.Storage.kinds[kind] or not G.Storage.quality[quality] or not G:Label(name) then
        return false,"INVALID_OBSERVATION"
    end
    context=context or self:Context()
    if type(context)~="table" or context.scope~="OUTDOOR" or context.instanceID~=0 or
       not G.map:Valid(context.mapID,context.x,context.y) or
       (context.floorID~=nil and not G:Natural(context.floorID)) then
       return false,"INVALID_LOCATION_OR_SCOPE"
    end
    local records=G.Storage.account.records
    local found=nil
    local ids=G.Sites and G.Sites:PersonalMergeCandidates(context,kind,name)
    local function candidates()
        if not ids then return pairs(records) end
        local key
        return function()
            key=next(ids,key)
            if key then return key,records[key] end
        end
    end
    for _,row in candidates() do
        if row and self:Comparable(row,context,kind,name) then
            if not found or row.id<found.id then found=row end
        end
    end
    local stamp=G:When()
    local created=false
    local id
    if found then
        id=found.id
        found.lastSeen=math.max(found.lastSeen,stamp)
        found.count=math.min(999999,found.count+1)
        -- Keep the evidence paired with the strongest recorded confidence.
        -- A manual note about an already observed site is still a newer visit,
        -- but should not replace the reason the site was classified as observed.
        local newerReason=G:Text(reason)
        if quality=="CONFIRMED" or (quality=="PROBABLE" and found.quality=="MANUAL") then
            found.quality=quality
            found.evidence=newerReason or "OBSERVATION"
        elseif quality==found.quality and newerReason then
            found.evidence=newerReason
        end
    else
        if G.state.observations>=G.maxRecords then return false,"RECORD_LIMIT_EXPORT_AND_COMPACT_FIRST" end
        id=G.Storage.account.nextID
        if not G:Natural(id) or id>=2147483647 then return false,"ID_LIMIT_REACHED" end
        local row={id=id,kind=kind,name=name,quality=quality,
            mapID=context.mapID,floorID=context.floorID or context.mapID,x=context.x,y=context.y,
            scope=context.scope,instanceID=context.instanceID,
            world=context.world and {continent=context.world.continent,
                 x=context.world.x,y=context.world.y} or nil,
            firstSeen=stamp,lastSeen=stamp,count=1,
            evidence=G:Text(reason) or "OBSERVATION",clientBuild=G.state.clientBuild or "unknown",
            clientPatch=G.state.clientPatch,clientInterface=G.state.clientInterface}
        if not G.Storage:ValidateRecord(row) then return false,"OBSERVATION_FAILED_VALIDATION" end
        records[id]=row
        G.Storage.account.nextID=id+1
        G.state.observations=G.state.observations+1
        created=true
    end
    G.Storage:Touch("account")
    if G.Sites then G.Sites:Observe(records[id],context,quality,G:Text(reason) or "OBSERVATION") end
    if G.Records then G.Records:Changed(id) end
    if G.Pins then G.Pins:Dirty() end
    if G.UI then G.UI:Update() end
    if G.core and type(G.core.Publish)=="function" then
        G.core.Publish("GATHER_OBSERVATION_SAVED",{id=id,kind=kind,quality=quality,
            mapID=context.mapID,firstObservation=created})
    end
    return true,id,created
end
function O:Upgrade(id,kind,quality,evidence)
    local writable,why=G.Storage:Writable()
    if not writable then return false,why end
    local row=G.Storage.account.records[id]
    if not row or row.kind~=kind or quality~="CONFIRMED" then return false,"CANNOT_UPGRADE" end
    if row.quality=="CONFIRMED" then return true,"ALREADY_CONFIRMED" end
    row.quality="CONFIRMED";row.evidence=G:Text(evidence) or "CORRELATED_LOOT_SOURCE"
    G.Storage:Touch("account")
    if G.Records then G.Records:Changed(id) end
    if G.Pins then G.Pins:Dirty() end
    if G.UI then G.UI:Update() end
    return true,"UPGRADED"
end
local function allowed(row,filter)
    if type(filter)~="table" or not G:Readable(filter) then filter={} end
    if G.Storage:Hidden(row.id) and not filter.includeHidden then return false end
    if filter.kind and filter.kind~="all" and row.kind~=filter.kind then return false end
    if filter.mapID and row.mapID~=filter.mapID then return false end
    if filter.quality and row.quality~=filter.quality then return false end
    if G.Sites and not G.Sites:Matches(row,filter) then return false end
    return true
end
local function listRows(filter,limit,offset,maxLimit)
    if G.Storage.readOnly then return {},0 end
    filter=type(filter)=="table" and G:Readable(filter) and filter or {}
    limit=G:Natural(limit) and math.min(limit,maxLimit) or 20
    offset=G:Number(offset) and math.max(0,math.min(math.floor(offset),10000)) or 0
    local phrase=filter.search
    phrase=G:Readable(phrase) and type(phrase)=="string" and
        phrase:sub(1,60):match("^%s*(.-)%s*$"):lower() or ""
    local list={}
    -- Browser-only ordering never alters recording, shared pins or the next
    -- gathering suggestion. Distances require the same qualified world space.
    local order=filter.sort=="name" and "name" or filter.sort=="nearest" and "nearest" or "recent"
    local origin=order=="nearest" and O:Context() or nil
    local distances={}
    for _,row in allRows() do
        local materials,ids
        local matches=phrase=="" or row.name:lower():find(phrase,1,true)
        if not matches and G.Sites then
            materials,ids=G.Sites:Materials(row)
            matches=type(materials)=="string" and materials:lower():find(phrase,1,true)
        end
        if not matches and ids then
            for _,id in ipairs(ids) do if tostring(id)==phrase then matches=true;break end end
        end
        if matches and allowed(row,filter) then
            list[#list+1]=row
            if origin and origin.world and row.world and row.scope=="OUTDOOR" and row.instanceID==0 and
                row.world.continent==origin.world.continent then
                local dx=row.world.x-origin.world.x;local dy=row.world.y-origin.world.y
                local distance=math.sqrt(dx*dx+dy*dy)
                if G:Number(distance) then distances[row.id]=distance end
            end
        end
    end
    table.sort(list,function(a,b)
        if order=="nearest" then
            local da,db=distances[a.id],distances[b.id]
            if da and db and da~=db then return da<db elseif da and not db then return true elseif db and not da then return false end
        elseif order=="name" then
            local an,bn=a.name:lower(),b.name:lower()
            if an~=bn then return an<bn end
        end
        if a.lastSeen~=b.lastSeen then return a.lastSeen>b.lastSeen end
        return tostring(a.id)<tostring(b.id)
    end)
    local out={}
    for i=offset+1,math.min(#list,offset+limit) do
        local r=list[i]
        out[#out+1]={id=r.id,kind=r.kind,name=r.name,mapID=r.mapID,floorID=r.floorID or r.mapID,x=r.x,y=r.y,
            siteID="gather:"..r.id,recordID=r.id,source=r.origin=="CATALOG" and "QUALIFIED_SOURCE_PACK" or "LOCAL_OBSERVATION",
            origin=r.origin or "PERSONAL",materialText=r.materialText,fishingType=r.fishingType,
            sampleCount=r.sampleCount or 0,catchSummary=G.Sites and G.Sites:CatchSummary(r),
            precision="HISTORICAL_PLAYER_POSITION",sourceRevision=G.Records and G.Records:Revision(),
            instanceID=r.instanceID,world=r.world and {x=r.world.x,y=r.world.y,
                 continent=r.world.continent} or nil,
            quality=r.quality,firstSeen=r.firstSeen,lastSeen=r.lastSeen,count=r.count,
            evidence=r.evidence,hidden=G.Storage:Hidden(r.id)}
        local result=out[#out]
        result.zone=r.zone;result.subzone=r.subzone
        result.precision=r.precision or "HISTORICAL_PLAYER_POSITION"
        result.sourceLabel=r.sourceLabel or "Personal observation"
        result.sourceURL=r.sourceURL;result.license=r.license
        result.clientBuild=r.clientBuild;result.requiredSkill=r.requiredSkill;result.skillMeaning=r.skillMeaning
        if G.Sites then result.materialText,result.materialIDs=G.Sites:Materials(r) end
        -- Never return a catalog's nested array by reference.
        if type(result.materialIDs)=="table" then
            local ids={};for j,id in ipairs(result.materialIDs) do ids[j]=id end;result.materialIDs=ids
        else result.materialIDs={} end
        result.distance=distances[r.id]
        result.distanceBasis=result.distance and "SAME_WORLD_STRAIGHT_LINE_YARDS" or nil
    end
    return out,#list
end
function O:List(filter,limit,offset)
    return listRows(filter,limit,offset,50)
end
function O:Nearest(filter)
    if G.Storage.readOnly then return nil,"STORAGE_READ_ONLY_OR_INVALID" end
    local player,why=self:Context()
    if not player then return nil,why end
    if not player.world then return nil,"WORLD_GEOMETRY_NOT_AVAILABLE" end
    local best,bestDist
    local records=G.Storage.account and G.Storage.account.records
    if type(records)~="table" then return nil,"STORAGE_READ_ONLY_OR_INVALID" end
    for _,row in allRows() do
        if allowed(row,filter) and row.world and
           row.world.continent==player.world.continent then
            local dx=row.world.x-player.world.x
            local dy=row.world.y-player.world.y
            local dist=math.sqrt(dx*dx+dy*dy)
            if G:Number(dist) and (not bestDist or dist<bestDist or (dist==bestDist and tostring(row.id)<tostring(best.id))) then
                best,bestDist=row,dist
            end
        end
    end
    if not best then return nil,"NO_SAME_WORLD_HISTORY" end
    local result={id=best.id,kind=best.kind,name=best.name,mapID=best.mapID,
        x=best.x,y=best.y,quality=best.quality,distance=bestDist,
        distanceBasis="SAME_WORLD_STRAIGHT_LINE_YARDS"}
    return result,"HISTORICAL_OBSERVATION_ONLY"
end
function O:Export(maxRows,offset)
    if G.Storage.readOnly then return "History unavailable: saved data needs recovery and has not been changed." end
    local limit=G:Natural(maxRows) and math.min(maxRows,200) or 100
    offset=G:Number(offset) and math.max(0,math.min(math.floor(offset),G.maxRecords or 1800)) or 0
    local rows,total=listRows({includeHidden=true},limit,offset,200)
    local output={"Gather Mate | local history export | schema 1 | current client build "..(G.state.clientBuild or "unknown"),
        "Source=local observations; these locations are not live resource spawns.",
        "Columns: id | kind | name | mapID | x | y | quality | count | lastSeen | hidden"}
    for _,r in ipairs(rows) do
        local name=r.name:gsub("[|\r\n]"," ")
        output[#output+1]=table.concat({r.id,r.kind,name,r.mapID,
            string.format("%.5f",r.x),string.format("%.5f",r.y),r.quality,
            r.count,r.lastSeen,r.hidden and "yes" or "no"}," | ")
    end
    if offset>0 or total>#rows then
        output[#output+1]=offset==0 and ("Exported "..#rows.." of "..total.." records (most recent first).")
            or ("Exported rows "..(offset+1).."–"..(offset+#rows).." of "..total.." (most recent first).")
    end
    return table.concat(output,"\n"),#rows,total
end
