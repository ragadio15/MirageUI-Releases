local _,G=...
G.Nav={}
function G.Nav:Select(id)
    if G:Combat() then return false,"UNAVAILABLE_DURING_COMBAT" end
    if G.Storage.readOnly then return false,"STORAGE_READ_ONLY" end
    local record=G.Sites and G.Sites:Get(id) or G.Storage.account and G.Storage.account.records and G.Storage.account.records[id]
    if not record or G.Storage:Hidden(record.id) then return false,"RECORD_NOT_FOUND_OR_HIDDEN" end
    if not G.state.clientAllowed then return false,"UNSUPPORTED_BUILD" end
    local api=MirageNavigateAPI
    if type(api)~="table" or api.apiVersion~=1 or type(api.RequestDestination)~="function" then
        return false,"MIRAGE_NAVIGATE_NOT_AVAILABLE"
    end
    local called,ok,reason=pcall(api.RequestDestination,"gather",{
        mapID=record.mapID,x=record.x,y=record.y,
        label=record.name,name=record.name,category=record.kind,
        siteID="gather:"..record.id,recordID="gather:"..record.id,floorID=record.floorID or record.mapID,
        sourceRevision=G.Records and G.Records:Revision(),requireRecord=true
    },{userInitiated=true,ttlSeconds=1800})
    if not called or type(ok)~="boolean" then return false,"NAVIGATION_UNAVAILABLE" end
    if ok and type(api.Refresh)=="function" then pcall(api.Refresh) end
    return ok,reason
end
function G.Nav:Clear()
    if G:Combat() then return false,"UNAVAILABLE_DURING_COMBAT" end
    local api=MirageNavigateAPI
    if type(api)~="table" or api.apiVersion~=1 or type(api.ReleaseDestination)~="function" then
        return false,"NAVIGATION_UNAVAILABLE"
    end
    local called,ok,reason=pcall(api.ReleaseDestination,"gather")
    if not called or type(ok)~="boolean" then return false,"NAVIGATION_UNAVAILABLE" end
    if ok and type(api.Refresh)=="function" then pcall(api.Refresh) end
    return ok,reason
end
-- Keep API reason tokens stable; translate only where shown to the player.
function G.Nav:Message(reason)
    if reason=="MIRAGE_NAVIGATE_NOT_AVAILABLE" or reason=="NAVIGATION_UNAVAILABLE" then
        return "Wayfinder is not available."
    end
    if reason=="UNAVAILABLE_DURING_COMBAT" then return "Try again after combat." end
    if reason=="STORAGE_READ_ONLY" then return "Saved history is preserved for recovery. Navigation changes are unavailable." end
    if reason=="RECORD_NOT_FOUND_OR_HIDDEN" then return "This site is no longer available. Refresh the history list." end
    if reason=="NO_SAME_WORLD_HISTORY" then return "No nearby saved observations on this continent." end
    if reason=="WORLD_GEOMETRY_NOT_AVAILABLE" then return "Distance is unavailable in this area." end
    return type(reason)=="string" and reason:find(" ") and reason or "Choose a saved site, then try again."
end
