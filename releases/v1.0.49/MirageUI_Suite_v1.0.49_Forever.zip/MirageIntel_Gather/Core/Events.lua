local _,G=...
local frame=CreateFrame("Frame")
G.eventFrame=frame
local events={"ADDON_LOADED","UNIT_SPELLCAST_SENT","UNIT_SPELLCAST_SUCCEEDED",
    "UNIT_SPELLCAST_FAILED","UNIT_SPELLCAST_INTERRUPTED","LOOT_READY","LOOT_OPENED","LOOT_CLOSED","LOOT_SLOT_CLEARED",
    "PLAYER_ENTERING_WORLD","PLAYER_LEAVING_WORLD","ZONE_CHANGED_NEW_AREA","PLAYER_REGEN_ENABLED","PLAYER_REGEN_DISABLED",
    "SKILL_LINES_CHANGED"}
G.state.registeredEvents={};G.state.unavailableEvents={}
for _,event in ipairs(events) do
    local ok=pcall(frame.RegisterEvent,frame,event)
    if ok then G.state.registeredEvents[event]=true else G.state.unavailableEvents[event]=true end
end
frame:SetScript("OnEvent",function(_,event,...)
    if event=="ADDON_LOADED" then
        local name=...
        if name==G.name and not G.state.initialized then
            local ok=pcall(G.Initialize,G)
            if not ok then G:Fault("INITIALIZATION_FAILED");G.state.status="INITIALIZATION_FAILED" end
        elseif G.state.initialized and (name=="Blizzard_WorldMap" or name=="Blizzard_WorldMapFrame") then
            G.Pins:Initialize()
        end
        if G.state.initialized and name=="MirageIntel_Navigate" then G.Session:Connect() end
        return
    end
    if not G.state.initialized then return end
    G.state.events=G.state.events+1
    if event=="PLAYER_ENTERING_WORLD" then G.Collector:Reset(event);if G.Fishing then G.Fishing:Reset(event) end;G.Session:SkillsChanged(event);G.Session:Connect();G.Pins:Initialize();return end
    if event=="SKILL_LINES_CHANGED" then
        G.Session:SkillsChanged(event);return
    end
    if event=="PLAYER_LEAVING_WORLD" or event=="ZONE_CHANGED_NEW_AREA" then G.Session:Invalidate(event) end
    if event=="PLAYER_REGEN_DISABLED" then G.Pins:HideAll();G.UI:Update();return end
    if event=="PLAYER_REGEN_ENABLED" then G.Session:FlushOutcome();G.Session:FlushInteraction();G.Pins:Initialize();G.Pins:Dirty();G.UI:Update();return end
    local ok=pcall(G.Collector.Event,G.Collector,event,...)
    if not ok then G:Fault("GATHER_EVENT_FAILED_"..event) end
end)
