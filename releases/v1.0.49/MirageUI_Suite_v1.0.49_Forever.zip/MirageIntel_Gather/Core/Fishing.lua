-- Fishing loot identifies a catch source, not a pool's position. Only cleared
-- item slots become samples; offered loot and full bags do not prove a catch.
local _,G=...
G.Fishing={status="WAITING_FOR_FISHING",serial=0}
local F=G.Fishing
function F:Reset(reason) self.cast=nil;self.window=nil;self.status=reason or "IDLE" end
function F:Sent(unit,target,guid,spellID)
    if unit~="player" or not G.Collector:Enabled() then return end
    self.window=nil
    if G.Classifier:FromSpell(spellID)~="fish" then self.cast=nil;return end
    local context=G.Observations:Context()
    if not context or not G:Text(guid,100) then self.cast=nil;return end
    context.fishingType="UNKNOWN_WATER";context.precision="AREA"
    self.cast={guid=guid,spellID=spellID,at=G:Now(),context=context}
    self.status="CAST_WITHOUT_CATCH"
end
function F:Open()
    if not G.Collector:Enabled() then return end
    local cast=self.cast
    local fishing,known=G:Call(IsFishingLoot)
    if not cast or not known or fishing~=true then self.window=nil;return end
    local now=G:Now()
    if now<cast.at or now-cast.at>45 then self:Reset("FISHING_CAST_EXPIRED");return end
    local previous=self.window and self.window.guid==cast.guid and self.window or nil
    local here=G.Observations:Context()
    if not here or here.mapID~=cast.context.mapID or here.floorID~=cast.context.floorID then
        self.window=nil;self.status="FISHING_CONTEXT_CHANGED";return
    end
    local distance=G.map:Measure(here,cast.context)
    if not distance or distance>15 then self.window=nil;self.status="FISHING_POSITION_CHANGED";return end
    local count,read=G:Call(GetNumLootItems)
    if not read or not G:Natural(count) or count>32 then self.window=nil;self.status="FISHING_LOOT_UNREADABLE";return end
    local slots={};local source=previous and previous.sourceGUID
    for i=1,count do
        -- READY can precede readable item links; OPENED may fill them later.
        -- Retain exactly-once acquisition across both events, including an
        -- auto-looted slot already cleared before the second snapshot.
        if not (previous and previous.clearedSlots[i]) then
            local item=G.Sites:ReadLoot(i)
            local guid,ok,quantity,second=G:Call(GetLootSourceInfo,i)
            if not ok or not G:Text(guid,150) or not G:Natural(quantity) or second~=nil or
                (source and source~=guid) then
                self.window=nil;self.status="FISHING_SOURCE_AMBIGUOUS";return
            end
            source=guid;if item then slots[i]=item end
        end
    end
    if not next(slots) then
        if previous then previous.slots=slots else self.status="NO_READABLE_FISHING_ITEMS" end
        return
    end
    if previous then previous.slots=slots;self.window=previous
    else
        self.serial=self.serial+1
        self.window={guid=cast.guid,sourceGUID=source,slots=slots,clearedSlots={},context=cast.context,at=now,serial=self.serial}
    end
    self.status="FISHING_LOOT_OFFERED_NOT_ACQUIRED"
end
function F:Cleared(slot)
    local w=self.window
    if not w or not G:Natural(slot) or not w.slots[slot] or G:Now()<w.at or G:Now()-w.at>60 then return end
    local item=w.slots[slot];w.slots[slot]=nil;w.clearedSlots[slot]=true
    if not G.Collector:Enabled() then return end
    local here=G.Observations:Context()
    if not here or here.mapID~=w.context.mapID or here.floorID~=w.context.floorID then
        self.status="FISHING_CONTEXT_CHANGED";return
    end
    local row=w.recordID and G.Storage.account.records[w.recordID]
    if not row then
        local name=(G:Label(w.context.subzone) or G:Label(w.context.zone) or "Local water").." fishing area"
        name=name:sub(1,90)
        local ok,id=G.Observations:Insert("fish",name,"CONFIRMED","NATIVE_FISHING_CLEARED_ITEM",w.context)
        if not ok then self.status=id;return end
        w.recordID=id;row=G.Storage.account.records[id]
        row.sampleCount=math.min(999999,(row.sampleCount or 0)+1)
        local skills=G.Session:Skills();row.observedSkill=skills.fish and skills.fish.rank or nil
        row.skillMeaning="UNKNOWN";row.requiredSkill=nil
    end
    G.Sites:AddMaterial(row,item.itemID,item.name,item.quantity)
    row.lastSeen=G:When();G.Storage:Touch("account");G.Records:Changed(row.id)
    self.status="OBSERVED_CATCH_ACQUIRED_SOURCE_TYPE_UNKNOWN"
    -- No pool GUID/position correlation exists here; do not complete a
    -- Wayfinder pool destination merely because a fishing item was looted.
end
function F:Event(event,...)
    if event=="UNIT_SPELLCAST_SENT" then self:Sent(...)
    elseif event=="LOOT_READY" or event=="LOOT_OPENED" then self:Open()
    elseif event=="LOOT_SLOT_CLEARED" then self:Cleared(...)
    elseif event=="LOOT_CLOSED" then self.window=nil;self.cast=nil
    elseif event=="PLAYER_LEAVING_WORLD" or event=="ZONE_CHANGED_NEW_AREA" then self:Reset(event) end
end
