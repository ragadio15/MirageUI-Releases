-- A gathering session visits saved sites, never inferred live spawns. Wayfinder
-- owns intent and progression; this provider only supplies local candidates.
local _,G=...
G.Session={status="OFF",deferred={},deferralRevision=0,skillRevision=0,jobOwner="MirageIntel_Gather.selection"}
local S=G.Session
local skillLines={herb=182,ore=186,skin=393,fish=356,pool=356}
local function navigation()
    local api=MirageNavigateAPI
    return type(api)=="table" and api.navigationVersion==2 and api or nil
end
local function service(name)
    if not G.core or type(G.core.GetService)~="function" then return nil end
    local value,ok=G:Call(G.core.GetService,name,1)
    return ok and type(value)=="table" and value or nil
end
function S:Snapshot()
    local nav=navigation()
    if not nav or type(nav.GetNavigationSnapshot)~="function" then return nil end
    local snap,ok=G:Call(nav.GetNavigationSnapshot)
    return ok and type(snap)=="table" and snap or nil
end
function S:Invalidate(reason,localOnly)
    self.scanSerial=(self.scanSerial or 0)+1
    self.cache=nil;self.pendingKey=nil;self.pendingContext=nil;self.pendingOrigin=nil;self.status=reason or "HISTORY_CHANGED"
    local tasks=service("Tasks")
    if tasks then tasks.Cancel(self.jobOwner) end
    -- External history, filter and profession changes must also invalidate
    -- Wayfinder's retained choice. Provider-internal scans/deferrals already
    -- run inside its reconciliation and must never recursively refresh it.
    local nav=navigation()
    if not localOnly and self.registeredAPI==nav and nav and type(nav.InvalidateGatherProvider)=="function" then
        pcall(nav.InvalidateGatherProvider,"MirageIntel_Gather")
    end
end
-- The native 70959 SkillInfo contract supplies rank and skillID. A missing or
-- unreadable response is unknown, never treated as a learned profession.
function S:Skills()
    local now=G:Now()
    if self.skillsCache and self.skillsCache.revision==self.skillRevision and now>=self.skillsCache.at and
        now-self.skillsCache.at<5 then return self.skillsCache.values end
    local out,byID={},{}
    for kind,id in pairs(skillLines) do
        if not byID[id] then
            local info,ok=G:Call(C_SkillInfo and C_SkillInfo.GetSkillLineInfoByID,id)
            if ok and type(info)=="table" and G:Readable(info.skillID) and info.skillID==id and
                G:Number(info.rank) and info.rank>0 and G:Readable(info.isHeader) and info.isHeader~=true then
                byID[id]={known=true,rank=info.rank}
            else byID[id]={known=false,reason=ok and "PROFESSION_NOT_OBSERVED" or "PROFESSION_API_UNAVAILABLE"} end
        end
        -- Fishing areas and pools use the same native profession observation.
        local skill=byID[id];out[kind]={known=skill.known,rank=skill.rank,reason=skill.reason}
    end
    self.skillsCache={at=now,revision=self.skillRevision,values=out}
    return out
end
function S:SkillsChanged(reason)
    self.skillRevision=self.skillRevision+1;self.skillsCache=nil
    self:Invalidate(reason or "SKILL_LINES_CHANGED")
    if G.Records and G.Records.RefreshSkillVisibility then G.Records:RefreshSkillVisibility() end
end
local function effectiveFilters(context)
    local f=type(context.filters)=="table" and context.filters or {}
    if G.Sites and (f.followGatherPreferences==true or next(f)==nil) then return G.Sites:Filters() end
    return f
end
function S:GetStatus(context)
    local result={status=self.status,history="PERSONAL_AND_ATTRIBUTED_CATALOG",spawnState="HISTORICAL_ONLY",
        harvestability="UNKNOWN",lastOutcome=self.lastOutcome}
    if not G.state.clientAllowed or G.Storage.readOnly or not G.Storage.account then
        result.professionReason="GATHER_HISTORY_UNAVAILABLE";return result
    end
    local filters=effectiveFilters(type(context)=="table" and context or {})
    local category=filters.category or filters.kind or "all"
    result.category=category
    if category=="treasure" then result.professionReady=true;result.professionReason="NO_PROFESSION_REQUIRED_FOR_NOTE";return result end
    local skills=self:Skills();local unknown=false
    for kind,skill in pairs(skills) do
        if category=="all" or category==kind then
            if skill.known then result.professionReady=true;result.professionReason="NATIVE_SKILL_OBSERVED";return result end
            if skill.reason=="PROFESSION_API_UNAVAILABLE" then unknown=true end
        end
    end
    if not unknown then result.professionReady=false end
    result.professionReason=unknown and "PROFESSION_API_UNAVAILABLE" or "SELECTED_PROFESSION_NOT_OBSERVED"
    return result
end
local function eligible(row,context,skills,deferred)
    if G.Storage:Hidden(row.id) or row.scope~="OUTDOOR" or row.instanceID~=0 then return false end
    local id="gather:"..row.id
    if deferred[id] or (type(context.excludedIDs)=="table" and context.excludedIDs[id]) then return false end
    local p=context.player
    -- P2 does not know cross-zone travel or cave access. Keep the suggestion
    -- on the player's current outdoor map with a qualified world transform.
    if row.mapID~=p.mapID then return false end
    local world=row.world or G.map:World(row.mapID,row.x,row.y)
    if not world or world.continent~=p.world.continent then return false end
    local f=effectiveFilters(context)
    local category=f.category or f.kind or "all"
    if G.Sites and not G.Sites:Matches(row,f,skills) then return false end
    if (row.floorID or row.mapID)~=(p.floorID or p.mapID) then return false end
    if row.kind=="fish" and category~="fish" then return false end
    if row.kind=="pool" and row.fishingType and row.fishingType~="POOL" then return false end
    if category~="all" and row.kind~=category then return false end
    if f.quality and f.quality~=row.quality then return false end
    if G:Text(f.search,60) and not row.name:lower():find(f.search:lower(),1,true) then return false end
    if row.kind=="treasure" then
        -- No profession requirement is claimed for manual treasure notes.
        if category~="treasure" then return false end
    elseif not (skills[row.kind] and skills[row.kind].known) then return false end
    return true
end
function S:IsEligible(siteID,context)
    if not G.state.clientAllowed or G.Storage.readOnly or type(context)~="table" or
        type(context.player)~="table" or not context.player.world then return false,"GATHER_CONTEXT_UNAVAILABLE" end
    local id=G:Text(siteID,160) and tonumber(siteID:match("^gather:(%d+)$"))
    local row=G.Sites and G.Sites:Get(siteID) or id and G.Storage.account.records[id]
    local inside,known=G:Call(IsInInstance)
    if not row or not known or inside~=false then return false,"GATHER_SITE_UNAVAILABLE" end
    return eligible(row,context,self:Skills(),self.deferred),"HISTORICAL_ELIGIBILITY"
end
local function contextKey(context)
    local filter=effectiveFilters(context)
    return table.concat({tostring(context.sessionID),G.Records:Revision(),tostring(context.player.mapID),
        tostring(context.player.floorID or context.player.mapID),filter.category or filter.kind or "all",
        G:Text(filter.search,60) or "",G:Text(filter.quality,20) or "",G:Text(filter.material,60) or "",
        tostring(filter.sourceFilter),tostring(filter.professionOnly),tostring(filter.knownSkillOnly),
        tostring(context.player.world.continent),tostring(S.deferralRevision),tostring(S.skillRevision)},":")
end
local function nearOrigin(a,b,range)
    if not a or not b or a.mapID~=b.mapID or (a.floorID or a.mapID)~=(b.floorID or b.mapID) then return false end
    local distance=G.map:Measure(a,b)
    return G:Number(distance) and distance<=range
end
local function candidate(row,revision)
    return {id="gather:"..row.id,siteID="gather:"..row.id,recordID=row.id,
        mapID=row.mapID,floorID=row.floorID or row.mapID,x=row.x,y=row.y,name=row.name,category=row.kind,
        label=row.name,kind="gather",confidence=row.quality,
        sourceRevision=revision,purpose="HISTORICAL_SITE",harvestability="UNKNOWN"}
end
function S:GetNext(context)
    if not G.state.clientAllowed or G.Storage.readOnly then return nil,"GATHER_HISTORY_UNAVAILABLE" end
    if type(context)~="table" or type(context.player)~="table" or not context.player.world then
        return nil,"WORLD_GEOMETRY_NOT_AVAILABLE"
    end
    local active,readable=G:Call(IsInInstance)
    if not readable or active~=false then return nil,"OUTDOOR_CONTEXT_REQUIRED" end
    if self.sessionID~=context.sessionID then
        self:Invalidate("NEW_GATHER_SESSION",true);self.sessionID=context.sessionID
        self.deferred={};self.deferralRevision=0
    end
    local filter=effectiveFilters(context)
    local category=filter.category or filter.kind or "all"
    if category~="all" and not G.Storage.kinds[category] then return nil,"INVALID_GATHER_CATEGORY" end
    local evidenceKey=contextKey(context)
    local key=evidenceKey..":"..tostring(context.generation)
    local now=G:Now()
    if self.cache and self.cache.key==key and now>=self.cache.at and now-self.cache.at<3 and
        nearOrigin(self.cache.origin,context.player,32) then
        local result=self.cache.candidate
        if result and type(context.excludedIDs)=="table" and context.excludedIDs[result.siteID] then
            self:Invalidate("CANDIDATE_EXCLUDED",true)
        else return result and G.core.Copy(result) or nil,self.cache.reason end
    end
    if self.pendingKey==key and nearOrigin(self.pendingOrigin,context.player,64) then return nil,"GATHER_SITE_SCAN_PENDING" end
    local tasks=service("Tasks")
    if not tasks then return nil,"GATHER_SCHEDULER_UNAVAILABLE" end
    self:Invalidate("GATHER_SITE_SCAN_PENDING",true);self.pendingKey=key
    local serial=self.scanSerial
    self.pendingContext={sessionID=context.sessionID,generation=context.generation}
    local captured=G.core.Copy(context)
    if not captured or not captured.player or not captured.player.world then
        self.pendingKey=nil;self.pendingContext=nil;return nil,"INVALID_GATHER_CONTEXT"
    end
    self.pendingOrigin=G.core.Copy(captured.player)
    local account=G.Storage.account
    local skills=self:Skills()
    local rows=account.records
    local iterator=G.Sites and G.Sites:Each()
    local revision=G.Records:Revision()
    local function current()
        return self.pendingKey==key and self.scanSerial==serial and revision==G.Records:Revision() and
            G.state.clientAllowed and not G.Storage.readOnly and account==G.Storage.account and rows==account.records
    end
    local function abandon()
        if self.pendingKey==key and self.scanSerial==serial then
            self.pendingKey=nil;self.pendingContext=nil;self.pendingOrigin=nil;self.status="GATHER_CONTEXT_CHANGED"
        end
        return false
    end
    if not current() then abandon();return nil,"GATHER_CONTEXT_CHANGED" end
    local cursor,nearest=nil,{}
    local scanned=0
    local queued,why=tasks.Queue(self.jobOwner,function()
        if not current() then return abandon() end
        -- Retain the closest bounded pool while visiting the complete history
        -- in small slices. Catalog order cannot exclude a better later site.
        for _=1,32 do
            local row
            if iterator then cursor,row=iterator() else cursor,row=next(rows,cursor) end
            if not cursor then break end
            scanned=scanned+1
            if eligible(row,captured,skills,self.deferred) then
                local world=row.world or G.map:World(row.mapID,row.x,row.y)
                local distance=world and G.map:Measure(captured.player,{world=world})
                if not current() then return abandon() end
                if G:Number(distance) then
                    local entry={row=row,distance=distance};local insert=#nearest+1
                    for i,other in ipairs(nearest) do
                        if distance<other.distance or (distance==other.distance and tostring(row.id)<tostring(other.row.id)) then insert=i;break end
                    end
                    if insert<=32 then table.insert(nearest,insert,entry);if #nearest>32 then nearest[#nearest]=nil end end
                end
            end
        end
        if not current() then return abandon() end
        if cursor then return true end
        local pool={}
        for _,entry in ipairs(nearest) do pool[#pool+1]=candidate(entry.row,revision) end
        local selected=pool[1]
        local reason=selected and "HISTORICAL_SITE_SUGGESTION" or "NO_ELIGIBLE_LOCAL_HISTORY"
        local at=G:Now()
        if not current() then return abandon() end
        self.cache={key=key,evidenceKey=evidenceKey,at=at,candidate=selected,candidates=pool,reason=reason,
            origin=G.core.Copy(captured.player),scanned=scanned}
        self.pendingKey=nil;self.pendingContext=nil;self.pendingOrigin=nil;self.status=reason
        local nav=navigation()
        if nav and type(nav.Refresh)=="function" then pcall(nav.Refresh) end
        if G.UI then G.UI:Update() end
        return false
    end,context.generation)
    if not queued and self.pendingKey==key and self.scanSerial==serial then
        self.pendingKey=nil;self.pendingContext=nil;self.pendingOrigin=nil;self.status=why or "GATHER_SCHEDULER_UNAVAILABLE"
    end
    return nil,self.status
end
function S:GetCandidates(context)
    if type(context)~="table" or type(context.player)~="table" or not context.player.world then return nil,"GATHER_CONTEXT_UNAVAILABLE" end
    local cache=self.cache
    if cache and cache.evidenceKey==contextKey(context) and nearOrigin(cache.origin,context.player,64) then
        return G.core.Copy(cache.candidates or {}),"NEAREST_32_FROM_COMPLETE_HISTORY"
    end
    self:GetNext(context)
    return nil,"GATHER_SITE_SCAN_PENDING"
end
function S:Defer(siteID,reason)
    if not G:Text(siteID,160) or not siteID:match("^gather:") then return false end
    local id=tonumber(siteID:match("^gather:(%d+)$"))
    if not (G.Sites and G.Sites:Get(siteID) or id and G.Storage.account and G.Storage.account.records[id]) then return false end
    self.deferred[siteID]=G:Text(reason,80) or "SKIPPED"
    self.deferralRevision=self.deferralRevision+1
    self:Invalidate("SITE_DEFERRED_THIS_SESSION",true)
    return true
end
function S:SetEnabled(enabled)
    if type(enabled)~="boolean" then return false,"INVALID_GATHER_MODE" end
    if not G.state.clientAllowed or G.Storage.readOnly then return false,"GATHER_HISTORY_UNAVAILABLE" end
    if G:Combat() then return false,"UNAVAILABLE_DURING_COMBAT" end
    self:Connect()
    local nav=navigation()
    if not nav then return false,"MIRAGE_NAVIGATE_NOT_AVAILABLE" end
    if enabled and type(nav.StartGatherSession)=="function" then
        local p=G.Storage.account.preferences
        local filters=G.Sites and G.Sites:Filters() or {category=p.category}
        if G.Sites then filters.followGatherPreferences=true end
        return nav.StartGatherSession({userInitiated=true,filters=filters})
    elseif not enabled then
        local snap=self:Snapshot()
        if snap and snap.mode=="Auto" and type(nav.SetRoutePreference)=="function" then
            local ok,why=nav.SetRoutePreference("gatherFallback",false)
            if ok and type(nav.Refresh)=="function" then nav.Refresh() end
            return ok,why
        end
        if type(nav.StopGatherSession)=="function" then return nav.StopGatherSession() end
    end
    return false,"NAVIGATION_SESSION_UNAVAILABLE"
end
function S:Skip()
    local nav=navigation()
    if G:Combat() then return false,"UNAVAILABLE_DURING_COMBAT" end
    if not nav or type(nav.SkipGatherDestination)~="function" then return false,"NAVIGATION_SESSION_UNAVAILABLE" end
    return nav.SkipGatherDestination("PLAYER_SKIPPED")
end
-- Freeze destination identity before the attempt. Never adopt whichever site
-- happens to be current when a later loot event arrives.
function S:Capture(kind,name,context)
    local snap=self:Snapshot()
    local dest=snap and snap.destination
    if type(dest)~="table" or dest.kind~="gather" or dest.category~=kind or dest.name~=name then return nil end
    local siteID=G:Text(dest.siteID,160)
    local id=siteID and tonumber(siteID:match("^gather:(%d+)$"))
    local row=siteID and G.Sites and G.Sites:Get(siteID) or id and G.Storage.account.records[id]
    if not row then return nil end
    local catalog=row.origin=="CATALOG"
    if catalog then
        -- Imported identity stays separate from the new personal observation.
        -- Only an exact cast-side source (currently qualified skinning) can
        -- associate its acquired loot with this selected, nearby catalog site.
        if not G:Text(context.sourceGUID,150) or not row.objectID or row.objectID~=context.objectID or
            row.kind~=kind or row.name~=name or row.mapID~=context.mapID or
            (row.floorID or row.mapID)~=(context.floorID or context.mapID) then return nil end
        local distance=G.map:Measure(context,row)
        if not G:Number(distance) or distance>8 then return nil end
    elseif not G.Observations:Comparable(row,context,kind,name) then return nil end
    return {siteID=siteID,recordID=not catalog and id or nil,catalog=catalog,sourceRevision=row.sourceRevision,
        castSourceGUID=context.sourceGUID,objectID=context.objectID,
        sessionID=dest.sessionID or snap.sessionID,generation=dest.generation or snap.generation}
end
function S:CaptureInteraction(kind,name,context)
    if kind~="herb" and kind~="ore" then return nil end
    local snap=self:Snapshot();local dest=snap and snap.destination
    if not dest or (snap.mode~="Auto" and snap.mode~="Gather") or dest.source~="GATHER_SESSION" or
        dest.kind~="gather" or dest.category~=kind or dest.name~=name or dest.mapID~=context.mapID or
        (dest.floorID or dest.mapID)~=(context.floorID or context.mapID) then return nil end
    local row=G.Sites and G.Sites:Get(dest.siteID)
    if not row or row.kind~=kind or row.name~=name or row.mapID~=dest.mapID or row.x~=dest.x or row.y~=dest.y or
        (row.floorID or row.mapID)~=(dest.floorID or dest.mapID) then return nil end
    local world=row.world or G.map:World(row.mapID,row.x,row.y)
    local distance=world and G.map:Measure(context,{world=world})
    if not G:Number(distance) or distance>8 then return nil end
    return {siteID=dest.siteID,sessionID=dest.sessionID or snap.sessionID,generation=dest.generation or snap.generation,
        mapID=context.mapID,floorID=context.floorID or context.mapID,x=context.x,y=context.y,category=kind,name=name}
end
function S:Interacted(pending)
    local proof=pending and pending.interactionProof
    if not proof or pending.interactionNotified or not pending.succeededAt or not G:Text(pending.guid,100) then return false end
    self.interactionIDs=self.interactionIDs or {};self.interactionOrder=self.interactionOrder or {}
    local now=G:Now()
    for i=#self.interactionOrder,1,-1 do
        local old=self.interactionOrder[i]
        if now<old.at or now-old.at>120 then self.interactionIDs[old.guid]=nil;table.remove(self.interactionOrder,i) end
    end
    if self.interactionIDs[pending.guid] then return false end
    self.interactionIDs[pending.guid]=true;self.interactionOrder[#self.interactionOrder+1]={guid=pending.guid,at=now}
    while #self.interactionOrder>64 do local old=table.remove(self.interactionOrder,1);self.interactionIDs[old.guid]=nil end
    pending.interactionNotified=true
    self.pendingInteraction=G.core.Copy(proof);self.pendingInteraction.castGUID=pending.guid;self.pendingInteraction.at=now
    return self:FlushInteraction()
end
function S:FlushInteraction()
    local proof=self.pendingInteraction
    if not proof then return false end
    local now=G:Now()
    if now<proof.at or now-proof.at>60 then self.pendingInteraction=nil;return false end
    if G:Combat() then return false end
    local nav=navigation()
    if not nav or type(nav.NotifyGatherInteraction)~="function" then self.pendingInteraction=nil;return false end
    local sent,accepted,reason=pcall(nav.NotifyGatherInteraction,proof.siteID,proof.sessionID,proof.generation,
        {outcome="CAST_COMPLETED",castGUID=proof.castGUID,category=proof.category,name=proof.name,
         mapID=proof.mapID,floorID=proof.floorID,x=proof.x,y=proof.y})
    self.lastInteraction=sent and (accepted and "MATCHED_CAST_ACCEPTED" or reason) or "NAVIGATION_UNAVAILABLE"
    if reason~="COMBAT_OUTCOME_DEFERRED" then self.pendingInteraction=nil end
    return sent and accepted==true
end
function S:Confirmed(pending)
    local proof=pending and pending.sessionProof
    if not proof or pending.sessionNotified or pending.confirmed~=true or not pending.sourceGUID then return false end
    if proof.catalog then
        local row=G.Sites and G.Sites:Get(proof.siteID)
        local personal=G.Storage.account and G.Storage.account.records[pending.recordID]
        if not row or row.sourceRevision~=proof.sourceRevision or not personal or
            pending.sourceGUID~=proof.castSourceGUID or personal.sourceGUID~=proof.castSourceGUID or
            personal.objectID~=proof.objectID then return false end
    elseif pending.recordID~=proof.recordID then return false end
    pending.sessionNotified=true
    self.pendingOutcome={siteID=proof.siteID,sessionID=proof.sessionID,generation=proof.generation,at=G:Now()}
    return self:FlushOutcome()
end
function S:FlushOutcome()
    local proof=self.pendingOutcome
    if not proof then return false end
    local now=G:Now()
    if now<proof.at or now-proof.at>60 then self.pendingOutcome=nil;self.lastOutcome="EXPIRED_CORRELATED_OUTCOME";return false end
    if G:Combat() then self.lastOutcome="COMBAT_OUTCOME_DEFERRED";return false end
    local nav=navigation()
    if not nav or type(nav.ConfirmGatherOutcome)~="function" then return false end
    local sent,ok,reason=pcall(nav.ConfirmGatherOutcome,proof.siteID,proof.sessionID,proof.generation,
        {quality="CONFIRMED",sourceMatched=true,outcome="HARVESTED"})
    self.lastOutcome=sent and (ok and "CORRELATED_HARVEST_ACCEPTED" or reason) or "NAVIGATION_UNAVAILABLE"
    if reason~="COMBAT_OUTCOME_DEFERRED" then self.pendingOutcome=nil end
    return sent and ok==true
end
function S:Connect()
    local nav=navigation()
    if not nav or type(nav.RegisterGatherProvider)~="function" then self.status="WAYFINDER_NOT_AVAILABLE";return false end
    if self.registeredAPI==nav then return true end
    local ok,accepted=pcall(nav.RegisterGatherProvider,"MirageIntel_Gather",2,{
        GetNext=function(context) return S:GetNext(context) end,
        GetCandidates=function(context) return S:GetCandidates(context) end,
        IsEligible=function(siteID,context) return S:IsEligible(siteID,context) end,
        Defer=function(siteID,reason) return S:Defer(siteID,reason) end,
        GetStatus=function(context) return S:GetStatus(context) end})
    if ok and accepted==true then self.registeredAPI=nav;self.status="READY";return true end
    self.status="GATHER_PROVIDER_REGISTRATION_UNAVAILABLE";return false
end
function S:Initialize()
    self:Connect()
    if G.core and type(G.core.Subscribe)=="function" then
        G.core.Subscribe("NAV_SESSION_CHANGED","MirageIntel_Gather",function(snapshot)
            local pending=self.pendingContext
            if pending and type(snapshot)=="table" and
                ((snapshot.mode~="Gather" and snapshot.mode~="Auto") or snapshot.sessionID~=pending.sessionID or snapshot.generation~=pending.generation) then
                self:Invalidate("NAVIGATION_INTENT_CHANGED",true)
            end
            if G.UI then G.UI:Update() end
        end)
    end
end
