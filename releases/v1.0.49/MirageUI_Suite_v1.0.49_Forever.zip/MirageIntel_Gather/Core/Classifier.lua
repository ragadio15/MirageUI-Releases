local _,G=...
G.Classifier={names={},nextNameProbe=0}
local C=G.Classifier
-- Client spell IDs for Forever must be checked in-game; names are a fallback
-- and never alone prove a harvest. Generic spell names cannot certify a node.
local spells={
    [2576]="ore",[2366]="herb",[8613]="skin",[7620]="fish",
}
local function spellName(info)
    if type(info)~="table" then return nil end
    local name,ok=G:Call(function() return info.name end)
    return ok and G:Label(name) or nil
end
function C:LocalizedNames()
    local now=G:Now()
    if now<self.nextNameProbe then return self.names end
    self.nextNameProbe=now+5
    local lookup=C_Spell and C_Spell.GetSpellInfo
    if type(lookup)~="function" then return self.names end
    -- Names are compared exactly with the client's own names for the known
    -- profession spell IDs. Do not lowercase UTF-8 or guess translated words.
    local names={}
    for id,kind in pairs(spells) do
        local info,ok=G:Call(lookup,id)
        local name=ok and spellName(info)
        if G:Label(name) then
            if names[name]~=nil and names[name]~=kind then names[name]=false else names[name]=kind end
        end
    end
    self.names=names
    return names
end
function C:FromSpell(spellID)
    if G:Natural(spellID) and spells[spellID] then return spells[spellID],"KNOWN_CANDIDATE_ID" end
    local f=C_Spell and C_Spell.GetSpellInfo
    if type(f)=="function" and G:Natural(spellID) then
        local info,valid=G:Call(f,spellID)
        local name=valid and spellName(info)
        if G:Label(name) then
            local kind=self:LocalizedNames()[name]
            if kind then return kind,"NATIVE_LOCALIZED_SPELL_NAME" end
        end
    end
    return nil,"UNKNOWN_CAST"
end
function C:TargetKind(kind,target)
    if kind=="fish" then
        if G:Label(target) then
            local lower=string.lower(target)
            if lower:find("school",1,true) or lower:find("pool",1,true) then
                return "pool","POOL_TARGET_NAME"
            end
        end
        return "fish","WATER_SOURCE_UNIDENTIFIED"
    end
    if kind=="ore" or kind=="herb" then
        if not G:Label(target) then return nil,"TARGET_UNKNOWN" end
        return kind,"CAST_TARGET_OBSERVED"
    end
    if kind=="skin" then
        if not G:Label(target) then return nil,"CREATURE_UNKNOWN" end
        return "skin","CREATURE_TARGET_OBSERVED"
    end
    return nil,"UNSUPPORTED_CATEGORY"
end
function C:DisplayName(kind,target)
    if G:Label(target) then return target end
    if kind=="fish" then return "Water source (unidentified)" end
    return nil
end

-- Only use the selected dead creature when it matches the spellcast's named
-- recipient. A generic Creature/GameObject prefix and a loot time window do
-- not establish identity. Other node types offer no qualified cast-side GUID.
function C:ExactCastSource(kind,target)
    if kind~="skin" or not G:Label(target) then return nil end
    local name,named=G:Call(UnitName,"target")
    if not named or not G:Label(name) or name~=target then return nil end
    local dead,readable=G:Call(UnitIsDead,"target")
    if not readable or dead~=true then return nil end
    local guid,ok=G:Call(UnitGUID,"target")
    if ok and G:Text(guid,150) and guid:match("^Creature%-[%w%-]+$") then return guid end
end
