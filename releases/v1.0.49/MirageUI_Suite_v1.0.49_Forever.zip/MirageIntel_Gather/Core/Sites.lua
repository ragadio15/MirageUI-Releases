-- Site identity and retained evidence are separate from display clusters.
local _,G=...
G.Sites={catalogLimit=2000,sampleLimit=16,materialLimit=24,revision=0}
local S=G.Sites
local function plain(v,max) return type(v)=="string" and #v<=max and not v:find("[|%c]") end
local function validBuild(value)
    return G:Text(value,20) and value:match("^%d+$") and G:Natural(tonumber(value)) and tonumber(value)<=999999999
end
function S:ClientMatches(row)
    -- Keep foreign-interface history in SavedVariables, but never project it
    -- into this client's map, route, or harvest-merging indexes.
    local current=G.state.clientInterface
    if current==nil then return false end
    local source=row.clientInterface
    if source==nil and row.origin=="CATALOG" then
        local pack=G.Storage.account and G.Storage.account.sources and G.Storage.account.sources[row.packID]
        source=pack and pack.interface
    end
    return current==(source or 16001)
end
local function boundedItems(value,cap,fn)
    if type(value)~="table" then return false end
    local count=0
    for k,v in pairs(value) do count=count+1;if count>cap or not fn(k,v) then return false end end
    return true
end
local function clone(v,depth)
    if type(v)~="table" then return v end
    if (depth or 0)>8 then return nil end
    local out={};for k,x in pairs(v) do out[k]=clone(x,(depth or 0)+1) end;return out
end
function S:ID(row) return type(row.id)=="number" and ("gather:"..row.id) or ("gather:"..row.id) end
function S:Get(id)
    local a=G.Storage.account
    if not a then return nil end
    if type(id)=="string" then
        id=id:gsub("^gather:","")
        local numeric=tonumber(id)
        if numeric and numeric%1==0 then id=numeric end
    end
    local row=type(id)=="number" and a.records[id] or a.catalog and a.catalog[id]
    return row and self:ClientMatches(row) and row or nil
end
function S:Each()
    local a=G.Storage.account or {};local phase,key=1,nil
    return function()
        while true do
            local rows=phase==1 and a.records or a.catalog
            local row
            key,row=next(rows or {},key)
            if not key and phase==1 then phase=2;key,row=next(a.catalog or {}) end
            if not key or self:ClientMatches(row) then return key,row end
        end
    end
end
function S:Copy(row) return clone(row) end
function S:Initialize()
    if G.Storage.readOnly or not G.state.clientAllowed then return end
    local a=G.Storage.account
    if a.schemaVersion==1 then
        -- Keep the exact old account as a recovery checkpoint. Migrate into
        -- separate tables; never rewrite the only copy of the old records.
        local fresh={schemaVersion=2,sentinel="GATHER_ACCOUNT_V2",revision=a.revision,nextID=a.nextID,
            records={},preferences=clone(a.preferences),catalog={},sources={},quarantine={},schema1Backup=G.Storage.legacySnapshot or a}
        for id,row in pairs(a.records) do
            local copy=clone(row);copy.origin="PERSONAL";copy.floorID=copy.mapID
            copy.precision="HISTORICAL_PLAYER_POSITION";copy.sampleCount=0;copy.samples={};copy.materials={}
            copy.fishingType=(copy.kind=="fish" or copy.kind=="pool") and "UNKNOWN_WATER" or nil
            fresh.records[id]=copy
        end
        MirageIntelGatherDB=fresh;G.Storage.account=fresh;a=fresh
        G.Storage:Touch("account")
    end
    if a.schemaVersion~=2 or type(a.catalog)~="table" or type(a.sources)~="table" or type(a.quarantine)~="table" then
        G.Storage.readOnly=true;G.Storage.reason="GATHER_SCHEMA2_INVALID_PRESERVED";return
    end
    for _,row in pairs(a.records) do
        if not self:ValidPersonal(row) then G.Storage.readOnly=true;G.Storage.reason="GATHER_PERSONAL_EVIDENCE_INVALID_PRESERVED";return end
    end
    local count=0
    local sourceCounts={}
    for id,row in pairs(a.catalog) do
        count=count+1
        if count>self.catalogLimit or type(id)~="string" or type(row)~="table" or row.id~=id or not self:ValidCatalog(row) then
            G.Storage.readOnly=true;G.Storage.reason="GATHER_CATALOG_INVALID_PRESERVED";return
        end
        local source=a.sources[row.packID]
        if type(source)~="table" or source.revision~=row.sourceRevision or source.license~=row.license or
            source.sourceURL~=row.sourceURL or source.sourceLabel~=row.sourceLabel then
            G.Storage.readOnly=true;G.Storage.reason="GATHER_SOURCE_LINK_INVALID_PRESERVED";return
        end
        sourceCounts[row.packID]=(sourceCounts[row.packID] or 0)+1
    end
    local sources=0
    for id,value in pairs(a.sources) do
        sources=sources+1
        if sources>16 or not G:Text(id,48) or type(value)~="table" or not G:Natural(value.revision) or
            (value.build~=nil and not validBuild(value.build)) or
            (value.interface~=nil and (not G:Natural(value.interface) or value.interface>999999999)) or
            (value.patch~=nil and not plain(value.patch,80)) or
            (value.flavor~=nil and (not plain(value.flavor,40) or value.flavor~="Forever" and not value.flavor:match("^Client%d+$"))) or
            not G:Text(value.license,80) or not G:Text(value.sourceURL,240) or not G:Label(value.sourceLabel) or
            not G:Number(value.count) or value.count~=(sourceCounts[id] or 0) or
            not G:Number(value.digest) or value.digest<0 or value.digest%1~=0 then
            G.Storage.readOnly=true;G.Storage.reason="GATHER_SOURCES_INVALID_PRESERVED";return
        end
    end
    if a.quarantine.errors~=nil and not boundedItems(a.quarantine.errors,64,function(i,entry)
        return G:Natural(i) and i<=64 and type(entry)=="table" and G:Number(entry.line) and entry.line>=0 and G:Text(entry.reason,120)
    end) then G.Storage.readOnly=true;G.Storage.reason="GATHER_QUARANTINE_INVALID_PRESERVED";return end
    local b=G.Storage.character
    if b.hiddenCatalog==nil then b.hiddenCatalog={} end
    if type(b.hiddenCatalog)~="table" then G.Storage.readOnly=true;G.Storage.reason="GATHER_HIDES_INVALID_PRESERVED";return end
    local hidden=0;for id,v in pairs(b.hiddenCatalog) do
        hidden=hidden+1
        if hidden>self.catalogLimit or not G:Text(id,120) or v~=true then
            G.Storage.readOnly=true;G.Storage.reason="GATHER_HIDES_INVALID_PRESERVED";return
        end
    end
    local p=a.preferences
    if p.material==nil then p.material="" end
    if p.sourceFilter==nil then p.sourceFilter="all" end
    if p.professionOnly==nil then p.professionOnly=true end
    if p.knownSkillOnly==nil then p.knownSkillOnly=false end
    if type(p.material)~="string" or #p.material>60 or p.material:find("[|%c]") or
        (p.sourceFilter~="all" and p.sourceFilter~="PERSONAL" and p.sourceFilter~="CATALOG") or
        type(p.professionOnly)~="boolean" or type(p.knownSkillOnly)~="boolean" then
        G.Storage.readOnly=true;G.Storage.reason="GATHER_FILTERS_INVALID_PRESERVED";return
    end
    p.maxPins=math.min(p.maxPins,80)
    G.state.catalogCount=count;self:Reindex()
end
function S:ValidPersonal(row)
    if not G.Storage:ValidateRecord(row) or (row.origin~=nil and row.origin~="PERSONAL") or
        (row.floorID~=nil and not G:Natural(row.floorID)) or
        (row.objectID~=nil and not G:Natural(row.objectID)) or
        (row.sourceGUID~=nil and not G:Text(row.sourceGUID,150)) or
        (row.siteKey~=nil and not G:Text(row.siteKey,320)) or
        (row.materialText~=nil and not plain(row.materialText,240)) or
        (row.fishingType~=nil and row.fishingType~="POOL" and row.fishingType~="OPEN_WATER" and row.fishingType~="UNKNOWN_WATER") or
        (row.sampleCount~=nil and (not G:Number(row.sampleCount) or row.sampleCount<0 or row.sampleCount>999999 or row.sampleCount%1~=0)) or
        (row.clientInterface~=nil and (not G:Natural(row.clientInterface) or row.clientInterface>999999999)) or
        (row.clientPatch~=nil and not plain(row.clientPatch,80)) then return false end
    if row.samples~=nil then
        if type(row.samples)~="table" then return false end
        local count=0
        for index,sample in pairs(row.samples) do
            count=count+1
            if count>self.sampleLimit or not G:Natural(index) or index>self.sampleLimit or type(sample)~="table" or
                not G:Number(sample.at) or not G.Storage.quality[sample.quality] or not G:Text(sample.evidence,90) or
                not G.map:Valid(row.mapID,sample.x,sample.y) then return false end
        end
        if count~=#row.samples then return false end
    end
    if row.materials~=nil then
        if type(row.materials)~="table" then return false end
        local count=0
        for id,item in pairs(row.materials) do
            count=count+1
            if count>self.materialLimit or not G:Natural(id) or type(item)~="table" or not G:Label(item.name) or
                not G:Number(item.quantity) or item.quantity<0 or item.quantity>999999999 or item.quantity%1~=0 or
                not G:Number(item.samples) or item.samples<0 or item.samples>999999 or item.samples%1~=0 then return false end
        end
    end
    return true
end
function S:ValidCatalog(row)
    local valid=type(row)=="table" and G:Text(row.id,120) and row.id:match("^catalog:[%w_%-]+:[%w_%-]+$") and
        row.origin=="CATALOG" and G.Storage.kinds[row.kind] and G:Label(row.name) and
        G.map:Valid(row.mapID,row.x,row.y) and G:Natural(row.floorID) and row.floorID==row.mapID and
        G:Text(row.packID,48) and G:Natural(row.sourceRevision) and G:Text(row.license,80) and
        plain(row.sourceURL,240) and G:Label(row.sourceLabel) and G:Number(row.lastSeen) and row.lastSeen>=0 and
        G:Number(row.firstSeen) and row.firstSeen>=0 and row.scope=="OUTDOOR" and row.instanceID==0 and
        G.Storage.quality[row.quality] and plain(row.materialText or "",240) and plain(row.possibleCatches or "",240) and
        plain(row.sourceCatchSummary or "",240) and row.sampleCount==0 and
        (row.precision=="CATALOG_SITE_POSITION" or row.precision=="HISTORICAL_PLAYER_POSITION" or row.precision=="AREA")
    if not valid then return false end
    if row.clientInterface~=nil and (not G:Natural(row.clientInterface) or row.clientInterface>999999999) or
        row.clientPatch~=nil and not plain(row.clientPatch,80) then return false end
    if row.id~="catalog:"..row.packID..":"..tostring(row.externalID) then return false end
    if row.objectID~=nil and not G:Natural(row.objectID) then return false end
    if row.world~=nil and (type(row.world)~="table" or not G:Number(row.world.continent) or row.world.continent<0 or
        row.world.continent%1~=0 or not G:Number(row.world.x) or not G:Number(row.world.y)) then return false end
    if row.materialIDs~=nil and not boundedItems(row.materialIDs,24,function(i,id)return G:Natural(i) and i<=24 and G:Natural(id)end) then return false end
    if row.sourceSampleCount~=nil and (not G:Number(row.sourceSampleCount) or row.sourceSampleCount<0 or row.sourceSampleCount>999999 or row.sourceSampleCount%1~=0) then return false end
    if row.requiredSkill~=nil and (not G:Number(row.requiredSkill) or row.requiredSkill<0 or row.requiredSkill>1000 or row.requiredSkill%1~=0) then return false end
    if row.skillMeaning~="UNKNOWN" and row.skillMeaning~="INTERACTION" and row.skillMeaning~="RECOMMENDED" and row.skillMeaning~="NO_JUNK" then return false end
    if (row.requiredSkill==nil)~=(row.skillMeaning=="UNKNOWN") then return false end
    if row.kind=="fish" or row.kind=="pool" then
        if row.fishingType~="POOL" and row.fishingType~="OPEN_WATER" and row.fishingType~="UNKNOWN_WATER" then return false end
        if row.kind=="pool" and (row.fishingType~="POOL" or not row.objectID) then return false end
        if row.fishingType=="POOL" and (row.kind~="pool" or not row.objectID) then return false end
    end
    return true
end
local function cellKey(mapID,floorID,kind,x,y)
    return table.concat({mapID,floorID or mapID,kind,math.floor(x*10000),math.floor(y*10000)},":")
end
function S:IndexRow(row)
    if not self:ClientMatches(row) then return end
    local key=tostring(row.mapID)..":"..tostring(row.floorID or row.mapID)..":"..row.kind
    self.index=self.index or {};self.index[key]=self.index[key] or {};self.index[key][row.id]=true
    if type(row.id)~="number" or row.origin=="CATALOG" then return end
    self.mergeCells=self.mergeCells or {};self.mergeIdentities=self.mergeIdentities or {};self.mergeKeys=self.mergeKeys or {}
    local previous=self.mergeKeys[row.id]
    local cell=cellKey(row.mapID,row.floorID,row.kind,row.x,row.y)
    local identity=row.siteKey
    if previous then
        for _,part in ipairs({{self.mergeCells,previous.cell,cell},{self.mergeIdentities,previous.identity,identity}}) do
            local old=part[2] and part[1][part[2]]
            if old and part[2]~=part[3] then old[row.id]=nil;if not next(old) then part[1][part[2]]=nil end end
        end
    end
    self.mergeCells[cell]=self.mergeCells[cell] or {};self.mergeCells[cell][row.id]=true
    if identity then self.mergeIdentities[identity]=self.mergeIdentities[identity] or {};self.mergeIdentities[identity][row.id]=true end
    self.mergeKeys[row.id]={cell=cell,identity=identity}
end
function S:Reindex()
    self.index={};self.mergeCells={};self.mergeIdentities={};self.mergeKeys={};self.revision=self.revision+1
    for _,row in self:Each() do self:IndexRow(row) end
end
function S:PersonalMergeCandidates(context,kind,name)
    if not self.mergeCells then return nil end
    local result={}
    local cell=cellKey(context.mapID,context.floorID,kind,context.x,context.y)
    local identity=self:Identity(kind,name,context)
    -- The cell includes old observations that have no exact identity yet.
    -- The exact identity also finds a known object recorded from another
    -- player position without examining unrelated zones or categories.
    for id in pairs(self.mergeCells[cell] or {}) do result[id]=true end
    for id in pairs(self.mergeIdentities[identity] or {}) do result[id]=true end
    return result
end
function S:Identity(kind,name,context)
    local object=G:Natural(context.objectID) and tostring(context.objectID) or name
    local identity=G:Text(context.sourceGUID,150) or G:Text(context.siteIdentity,120)
    -- Uncertain player locations use small normalized cells; a 20-yard
    -- proximity merge no longer collapses two nearby known objects/sites.
    return table.concat({context.mapID,context.floorID or context.mapID,kind,object,
        identity or (math.floor(context.x*10000)..":"..math.floor(context.y*10000))},":")
end
function S:Comparable(row,context,kind,name)
    if not self:ClientMatches(row) then return false end
    if row.kind~=kind or row.mapID~=context.mapID or row.scope~="OUTDOOR" or
        row.instanceID~=context.instanceID or (row.floorID or row.mapID)~=(context.floorID or context.mapID) then return false end
    if row.objectID and context.objectID and row.objectID~=context.objectID then return false end
    if row.sourceGUID and context.sourceGUID and row.sourceGUID~=context.sourceGUID then return false end
    if row.name~=name and not (row.objectID and row.objectID==context.objectID) then return false end
    local sameCell=math.floor(row.x*10000)==math.floor(context.x*10000) and math.floor(row.y*10000)==math.floor(context.y*10000)
    -- Upgrade one uncertain same-cell observation to a first known identity;
    -- never combine two different known identities.
    if not row.sourceGUID and not row.objectID and context.sourceGUID and sameCell then return true end
    local key=self:Identity(kind,name,context)
    if row.siteKey then return row.siteKey==key end
    if row.sourceGUID or context.sourceGUID or row.objectID or context.objectID then return false end
    return math.floor(row.x*10000)==math.floor(context.x*10000) and math.floor(row.y*10000)==math.floor(context.y*10000)
end
function S:Observe(row,context,quality,evidence)
    row.origin="PERSONAL";row.floorID=context.floorID or context.mapID
    row.siteKey=(context.sourceGUID and not row.sourceGUID) and self:Identity(row.kind,row.name,context) or
        row.siteKey or self:Identity(row.kind,row.name,context)
    row.objectID=row.objectID or context.objectID;row.sourceGUID=row.sourceGUID or context.sourceGUID
    row.precision=context.precision or row.precision or "HISTORICAL_PLAYER_POSITION"
    row.zone=context.zone or row.zone;row.subzone=context.subzone or row.subzone
    row.samples=type(row.samples)=="table" and row.samples or {}
    row.samples[#row.samples+1]={at=G:When(),quality=quality,evidence=evidence,x=context.x,y=context.y}
    while #row.samples>self.sampleLimit do table.remove(row.samples,1) end
    row.materials=type(row.materials)=="table" and row.materials or {}
    if row.kind=="fish" or row.kind=="pool" then
        row.fishingType=context.fishingType or row.fishingType or "UNKNOWN_WATER"
        row.sampleCount=row.sampleCount or 0
    end
    self:IndexRow(row)
    self.revision=self.revision+1
end
function S:Materials(row)
    local names,ids={},{}
    if row.origin=="CATALOG" then return row.materialText or "",row.materialIDs or {} end
    for id,item in pairs(row.materials or {}) do
        if #ids>=self.materialLimit then break end
        ids[#ids+1]=id;names[#names+1]=(G:Label(item.name) or ("Item "..id))
    end
    table.sort(names);table.sort(ids)
    return (#names>0 and table.concat(names,", "):sub(1,240) or row.materialText or ""),ids
end
function S:AddMaterial(row,itemID,name,quantity)
    if not row or row.origin=="CATALOG" or not G:Natural(itemID) or not G:Natural(quantity) or quantity>10000 then return false end
    row.materials=row.materials or {};local existing=row.materials[itemID]
    if not existing then
        local count=0;for _ in pairs(row.materials) do count=count+1 end
        if count>=self.materialLimit then return false end
        existing={name=G:Label(name) or ("Item "..itemID),quantity=0,samples=0};row.materials[itemID]=existing
    end
    existing.quantity=math.min(999999999,existing.quantity+quantity)
    existing.samples=math.min(999999,existing.samples+1)
    row.materialText=self:Materials(row)
    return true
end
function S:CatchSummary(row)
    if row.origin=="CATALOG" then
        if row.sourceCatchSummary and row.sourceCatchSummary~="" then return ("Source observed catches: "..row.sourceCatchSummary):sub(1,240) end
        return row.possibleCatches and ("Source possible catches: "..row.possibleCatches):sub(1,240) or ""
    end
    local out={}
    for id,item in pairs(row.materials or {}) do
        out[#out+1]=(G:Label(item.name) or ("Item "..id)).." x"..tostring(item.quantity or 0)
        if #out>=6 then break end
    end
    table.sort(out);return table.concat(out,"; "):sub(1,240)
end
function S:Filters()
    local p=G.Storage.account.preferences
    return {category=p.category,material=p.material,sourceFilter=p.sourceFilter,
        professionOnly=p.professionOnly,knownSkillOnly=p.knownSkillOnly}
end
function S:Matches(row,filter,skills)
    local p=G.Storage.account.preferences
    local f=type(filter)=="table" and filter or p
    local category=f.category or f.kind or p.category
    if category and category~="all" and row.kind~=category then return false,"CATEGORY_FILTER" end
    local source=f.sourceFilter or p.sourceFilter
    if source and source~="all" and (row.origin or "PERSONAL")~=source then return false,"SOURCE_FILTER" end
    local material=f.material
    if material==nil then material=p.material end
    if type(material)=="string" and material~="" then
        local text,ids=self:Materials(row);local matched=text:lower():find(material:lower(),1,true)
        if not matched then for _,id in ipairs(ids) do if tostring(id)==material then matched=true;break end end end
        if not matched then return false,"MATERIAL_FILTER" end
    end
    local only=f.professionOnly;if only==nil then only=p.professionOnly end
    local known=f.knownSkillOnly;if known==nil then known=p.knownSkillOnly end
    skills=skills or (G.Session and G.Session:Skills()) or {}
    local learned=skills[row.kind]
    if only and row.kind~="treasure" and not (learned and learned.known) then return false,"PROFESSION_UNKNOWN_OR_UNLEARNED" end
    if row.kind=="treasure" and category~="treasure" and only then return false,"TREASURE_REQUIRES_SELECTION" end
    local qualified=row.skillMeaning=="INTERACTION" and G:Number(row.requiredSkill)
    if qualified and learned and learned.known and learned.rank<row.requiredSkill then return false,"KNOWN_SKILL_TOO_LOW" end
    if known and not (qualified and learned and learned.known and learned.rank>=row.requiredSkill) then return false,"INTERACTION_THRESHOLD_UNKNOWN" end
    return true
end
function S:ReadLoot(slot)
    if not G:Natural(slot) or slot>32 then return nil end
    local link,read=G:Call(GetLootSlotLink,slot)
    if not read or not G:Text(link,400) then return nil end
    local itemID=tonumber(link:match("item:(%d+)"))
    local _,valid,name,quantity,currencyID,quality,locked=G:Call(GetLootSlotInfo,slot)
    if not valid or not G:Natural(itemID) or not G:Label(name) or not G:Natural(quantity) or quantity>10000 or
        (currencyID~=nil and currencyID~=0) or locked==true then return nil end
    return {itemID=itemID,name=name,quantity=quantity,quality=quality,slot=slot}
end
function S:Reset(scope,source)
    local ok,why=G.Storage:Writable();if not ok then return false,why end
    if G:Combat() then return false,"UNAVAILABLE_DURING_COMBAT" end
    local a=G.Storage.account
    if scope=="samples" then
        for _,row in pairs(a.records) do row.samples={};row.materials={};row.materialText="";row.sampleCount=0 end
    elseif scope=="hidden" then
        local removed={};local retained={};local count=0
        for id,row in pairs(a.records) do
            if G.Storage:Hidden(id) then removed[id]=row;G.Storage.character.hidden[id]=nil
            else retained[id]=row;count=count+1 end
        end
        -- One bounded recovery checkpoint; site IDs are never recycled.
        a.lastRemovedPersonal={at=G:When(),records=removed};a.records=retained
        G.state.observations=count;G.Storage:Touch("character")
    elseif scope=="catalog" and G:Text(source,48) and a.sources[source] then
        -- Cancel pending transfer work before removing a source. A new table
        -- also invalidates any staged merge holding the old catalog identity.
        if G.Transfer then G.Transfer:Cancel() end
        local retained={}
        for id,row in pairs(a.catalog) do if row.packID~=source then retained[id]=row end end
        a.catalog=retained
        a.sources[source]=nil
    else return false,"EXPLICIT_SCOPE_REQUIRED" end
    local count=0;for _ in pairs(a.catalog) do count=count+1 end;G.state.catalogCount=count
    G.Storage:Touch("account");self:Reindex();G.Records:Changed();return true
end
