local _,G=...
G.Commands={}
local function describe()
    G:Print("/mgather - open dashboard; /mgather data - sources and filters; /mgather session <on|off>; /mgather skip; /mgather status; /mgather add <herb|ore|fish|pool|skin|treasure> <name>; /mgather pin <id>; /mgather hide <id>; /mgather show <id>; /mgather nearest; /mgather category <all|kind>; /mgather pins <on|off>; /mgather minimap <on|off>; /mgather recording <on|off>; /mgather export; /mgather clear-route")
end
function G.Commands:Run(msg)
    msg=type(msg)=="string" and msg:match("^%s*(.-)%s*$") or ""
    if msg=="" or msg=="open" then
        local ok,why=G.UI:Open();if not ok then G:Print(why) end;return
    end
    if msg=="help" then describe();return end
    if msg=="data" or msg=="import" then local ok,why=G.DataUI:Open();if not ok then G:Print(why) end;return end
    if msg=="status" then
        G:Print(G.state.status.." | records="..G.state.observations.." | "..G.Storage.reason..
            " | map="..(G.Pins.status or "UNAVAILABLE").." | session="..G.Session.status..
            " | publication="..G.Records.status.." | historical sites only | client verification NOT_RUN")
        return
    end
    if msg=="export" then
        local ok,why=G.DataUI:Open();if ok then G.Transfer:Export("PERSONAL") else G:Print(why) end;return
    end
    if msg=="skip" then
        local ok,why=G.Session:Skip();G:Print(ok and "Site deferred for this gathering session." or G.Nav:Message(why));return
    end
    if msg=="nearest" then
        local pref=G.Storage.account and G.Storage.account.preferences
        local record,why=G.Observations:Nearest({kind=pref and pref.category or "all"})
        if not record then G:Print(why);return end
        local ok,reason=G.Nav:Select(record.id)
        G:Print(ok and ("Historical destination selected: "..record.name) or G.Nav:Message(reason))
        return
    end
    if msg=="clear-route" then local ok,reason=G.Nav:Clear();G:Print(ok and "Gather route cleared." or G.Nav:Message(reason));return end
    local action,arg=msg:match("^(%S+)%s+(.*)$")
    if action=="session" and (arg=="on" or arg=="off") then
        local ok,why=G.Session:SetEnabled(arg=="on")
        G:Print(ok and (arg=="on" and "Gathering guidance enabled for saved sites." or "Returned to the previous quest policy.") or G.Nav:Message(why));return
    end
    if action=="add" then
        local kind,name=arg:match("^(%S+)%s+(.+)$")
        local ok,id=G.API:RecordHere(kind,name)
        G:Print(ok and ("Manual observation #"..id.." saved in memory; reload/logout persists it.") or tostring(id))
        return
    end
    if action=="pin" or action=="hide" or action=="show" then
        local id=tonumber(arg) or arg
        local ok,reason
        if not G.Sites:Get(id) then G:Print("Use a valid observation ID from the panel.");return end
        if action=="pin" then ok,reason=G.Nav:Select(id)
        else ok,reason=G.Storage:Hide(id,action=="hide") end
        G:Print(ok and (action.." completed for #"..id) or tostring(reason))
        return
    end
    if action=="category" then
        local ok,reason=G.Storage:SetPreference("category",arg)
        G:Print(ok and ("Category filter: "..arg) or reason);return
    end
    if action=="pins" or action=="recording" or action=="minimap" then
        if arg~="on" and arg~="off" then describe();return end
        local key=action=="pins" and "showMapPins" or action=="minimap" and "showMinimapPins" or "enabled"
        local ok,reason=G.Storage:SetPreference(key,arg=="on")
        G:Print(ok and (action.." "..arg) or reason)
        return
    end
    describe()
end
function G.Commands:Install()
    SLASH_MIRAGEGATHER1="/mgather"
    SLASH_MIRAGEGATHER2="/miragegather"
    SlashCmdList.MIRAGEGATHER=function(msg)G.Commands:Run(msg)end
end
