local _,G=...
G.Collector={pending=nil}
local C=G.Collector
function C:Reset(reason)
    self.pending=nil;self.lastResetReason=reason
end
function C:Enabled()
    local p=G.Storage.account and G.Storage.account.preferences
    return G.state.initialized and G.state.clientAllowed and not G.Storage.readOnly and
        p and p.enabled==true
end
function C:Sent(unit,target,guid,spellID)
    if not self:Enabled() or not G:Text(unit) or unit~="player" then return end
    if G:Text(guid,100) and self.pending and self.pending.guid==guid and self.pending.spellID==spellID then return end
    -- A second player cast supersedes all queued evidence from the first.
    self:Reset("NEW_PLAYER_CAST")
    if not G:Text(guid,100) then return end
    local kind=G.Classifier:FromSpell(spellID)
    if not kind then return end
    local targetKind=G.Classifier:TargetKind(kind,target)
    if not targetKind then return end
    -- A generic cast only tells us that the player tried to fish. It does
    -- not identify a pool or prove a catch. Manual fishing entries remain.
    if targetKind=="fish" then self.lastBlocked="FISH_SOURCE_UNIDENTIFIED";return end
    local name=G.Classifier:DisplayName(kind,target)
    if not name then return end
    local context,reason=G.Observations:Context()
    if not context then self.lastBlocked=reason;return end
    self.lastBlocked=nil
    self.lastLootReason=nil
    local sourceGUID=G.Classifier:ExactCastSource(targetKind,target)
    if sourceGUID then
        context.sourceGUID=sourceGUID
        context.objectID=tonumber(sourceGUID:match("^Creature%-%d+%-%d+%-%d+%-%d+%-(%d+)%-"))
    end
    self.pending={guid=guid,spellID=spellID,kind=targetKind,name=name,
        context=context,sentAt=G:Now(),sourceGUID=sourceGUID,
        sessionProof=G.Session and G.Session:Capture(targetKind,name,context),
        interactionProof=G.Session and G.Session:CaptureInteraction(targetKind,name,context)}
end
function C:Success(unit,guid,spellID)
    if not self:Enabled() or not G:Text(unit) or unit~="player" or
       not G:Text(guid,100) or not G:Natural(spellID) then return end
    local p=self.pending
    local now=G:Now()
    if not p or p.guid~=guid or p.spellID~=spellID or p.succeededAt or
        now<p.sentAt or now-p.sentAt>15 then return end
    self.completedCasts=self.completedCasts or {};self.completedOrder=self.completedOrder or {}
    for i=#self.completedOrder,1,-1 do
        local entry=self.completedOrder[i]
        if now<entry.at or now-entry.at>120 then self.completedCasts[entry.guid]=nil;table.remove(self.completedOrder,i) end
    end
    if self.completedCasts[guid] then return end
    self.completedCasts[guid]=true;self.completedOrder[#self.completedOrder+1]={guid=guid,at=now}
    while #self.completedOrder>64 do local old=table.remove(self.completedOrder,1);self.completedCasts[old.guid]=nil end
    p.succeededAt=now
    -- Fishing success may denote cast start, not a catch. Even a named pool
    -- must be recorded manually until a cast-side source can be qualified.
    if p.kind=="pool" then self.lastBlocked="FISH_CATCH_UNVERIFIED";return end
    local matched=p.clearedAt and now>=p.clearedAt and now-p.clearedAt<=3
    local quality=matched and "CONFIRMED" or "PROBABLE"
    local evidence=matched and "CAST_AND_MATCHED_SOURCE_GUID" or "CAST_SUCCESS_TARGET_OBSERVED"
    local ok,id=G.Observations:Insert(p.kind,p.name,quality,evidence,p.context)
    if ok then
        p.recordID=id
        p.confirmed=matched
        if matched then self:ApplyAcquired(p) end
        if matched and G.Session then G.Session:Confirmed(p) end
        if G.Session then G.Session:Interacted(p) end
    else
        self.lastBlocked=id
    end
end
function C:CompatibleLoot()
    local p=self.pending
    if not p or not p.sourceGUID then return false,"LOOT_SOURCE_NOT_CORRELATED" end
    if type(GetNumLootItems)~="function" or type(GetLootSourceInfo)~="function" then
        return false,"SOURCE_API_UNAVAILABLE"
    end
    local count,valid=G:Call(GetNumLootItems)
    if not valid or not G:Natural(count) or count>32 then return false,"NO_BOUNDED_LOOT" end
    -- Reject ambiguous/grouped loot, even if one GUID matches. A second
    -- GUID/count pair must not be silently ignored.
    for i=1,count do
        local guid,ok,quantity,secondGUID=G:Call(GetLootSourceInfo,i)
        if not ok or not G:Text(guid,150) or guid~=p.sourceGUID or
           not G:Natural(quantity) or secondGUID~=nil then
            return false,"LOOT_SOURCE_NOT_CORRELATED"
        end
    end
    return true,"EXACT_CAST_SOURCE_MATCHED"
end
function C:CloseLoot()
    local p=self.pending
    if p then p.lootAt=nil;p.lootOpen=false;p.lootSlots=nil;p.clearedSlots=nil end
end
function C:Loot()
    if not self:Enabled() then return end
    local p=self.pending
    if not p or p.confirmed then return end
    local now=G:Now()
    if now<p.sentAt or now-p.sentAt>15 or
       p.succeededAt and (now<p.succeededAt or now-p.succeededAt>5) then return end
    local compatible,why=self:CompatibleLoot()
    self.lastLootReason=why
    if not compatible then self:CloseLoot();return end
    if not p.lootOpen then
        p.lootWindow=(p.lootWindow or 0)+1;p.clearedSlots={}
        if p.lootWindow>4 then self:CloseLoot();self.lastLootReason="LOOT_WINDOW_LIMIT";return end
    end
    p.lootOpen=true
    p.lootAt=now
    -- READY and OPENED may describe one window. Refresh offered slots from
    -- that window, while retaining its already-cleared set exactly once.
    p.lootSlots={}
    if G.Sites then
        local count=G:Call(GetNumLootItems)
        for i=1,count or 0 do
            local item=G.Sites:ReadLoot(i);if item and not (p.clearedSlots and p.clearedSlots[i]) then p.lootSlots[i]=item end
        end
    end
end
function C:ApplyAcquired(p)
    local row=p.recordID and G.Storage.account.records[p.recordID]
    if not row or not G.Sites then return end
    local changed=false
    for slot,item in pairs(p.acquiredItems or {}) do
        if not item.applied then
            item.applied=true
            if G.Sites:AddMaterial(row,item.itemID,item.name,item.quantity) then changed=true end
        end
    end
    if changed then G.Storage:Touch("account");G.Records:Changed(row.id) end
end
function C:Cleared(slot)
    local p=self.pending
    if not G:Natural(slot) or slot>32 or not p or not p.lootOpen or not p.lootAt or not p.lootSlots or not p.lootSlots[slot] or not p.sourceGUID or
        G:Now()<p.sentAt or G:Now()-p.sentAt>15 then return end
    local item=p.lootSlots[slot];p.lootSlots[slot]=nil
    p.clearedSlots=p.clearedSlots or {};p.clearedSlots[slot]=true;p.clearedAt=G:Now()
    p.acquiredItems=p.acquiredItems or {};p.acquiredItems[tostring(p.lootWindow)..":"..slot]=item
    if p.recordID and p.succeededAt then
        local ok=G.Observations:Upgrade(p.recordID,p.kind,"CONFIRMED","CAST_AND_MATCHED_SOURCE_GUID")
        if ok then
            p.confirmed=true
            self:ApplyAcquired(p)
            if G.Session then G.Session:Confirmed(p) end
        end
    end
end
function C:Failed(unit,guid)
    if G:Text(unit) and unit=="player" and G:Text(guid,100) and self.pending and self.pending.guid==guid then
        self:Reset("INTERRUPTED")
    end
end
function C:Event(event,...)
    if G.Fishing then G.Fishing:Event(event,...) end
    if event=="UNIT_SPELLCAST_SENT" then self:Sent(...)
    elseif event=="UNIT_SPELLCAST_SUCCEEDED" then self:Success(...)
    elseif event=="UNIT_SPELLCAST_FAILED" or event=="UNIT_SPELLCAST_INTERRUPTED" then self:Failed(...)
    elseif event=="LOOT_READY" or event=="LOOT_OPENED" then self:Loot()
    elseif event=="LOOT_SLOT_CLEARED" then self:Cleared(...)
    elseif event=="LOOT_CLOSED" then self:CloseLoot()
    elseif event=="PLAYER_LEAVING_WORLD" or event=="ZONE_CHANGED_NEW_AREA" then self:Reset(event) end
end
