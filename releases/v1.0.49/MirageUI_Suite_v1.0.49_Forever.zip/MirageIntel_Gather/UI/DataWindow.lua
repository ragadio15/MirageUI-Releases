local _,G=...
G.DataUI={sourceIndex=1,providerIndex=1}
local U=G.DataUI
local function chrome()return G.core and G.core.Chrome end
function U:Writable()
    return G.state.clientAllowed and not G.Storage.readOnly and type(G.Storage.account)=="table"
        and G.Storage.account.schemaVersion==2 and type(G.Storage.account.preferences)=="table"
end
local function choose(owner,values,current,fn)
    local c=chrome();if not (c and c.Choose) then return false end
    local account,character=G.Storage.account,G.Storage.character
    return c.Choose(owner,values,current,function(value)
        if G.Storage.account~=account or G.Storage.character~=character or not U:Writable() or G:Combat() then return end
        fn(value)
    end)
end
local function text(parent,value,x,y,width)
    local f=parent:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    f:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y);f:SetWidth(width or 660);f:SetJustifyH("LEFT");f:SetText(value)
    local c=chrome();if c then c.Tint(f,"text");if c.Font then c.Font(f,"body") end end;return f
end
local function button(parent,value,x,y,width,callback,passiveAction)
    local passive=passiveAction or value=="Close" or value=="Cancel" or value=="Select all"
    local function guarded(...)
        if not passive and (not U:Writable() or G:Combat()) then
            return U:Message(false,"Data changes are available after combat with readable saved data.")
        end
        return callback(...)
    end
    local c=chrome();local b
    if c then b=c.Button(parent,value,x,y,width,24,guarded) else
        b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate");b:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
        b:SetSize(width,24);b:SetText(value);b:SetScript("OnClick",guarded)
    end
    if not passive then U.controls=U.controls or {};U.controls[#U.controls+1]=b end
    return b
end
function U:Sources()
    local out={};for id in pairs(G.Storage.account and G.Storage.account.sources or {}) do out[#out+1]=id end
    table.sort(out);return out
end
function U:Providers()
    local out={};for id in pairs(G.Transfer.providers) do out[#out+1]=id end;table.sort(out);return out
end
function U:Message(ok,why)
    self.message=ok and (why or "Working; existing history remains available.") or tostring(why or "Unavailable")
    self:Update()
end
function U:SetPage(page)
    local c=chrome();if c and c.CloseChoices then c.CloseChoices() end
    self.confirmSource=nil;self.confirmSamples=nil;self.confirmHidden=nil
    self.page=page
    if not self.pages then return end
    for key,pane in pairs(self.pages) do
        pane:SetShown(key==page)
        local c=chrome();if c then c.Active(self.tabs[key],key==page) end
    end
    self:Update()
end
function U:Create()
    if self.frame or not self:Writable() or G:Combat() or not UIParent then return end
    local f=CreateFrame("Frame","MirageIntelGatherData",UIParent,"BackdropTemplate")
    f:SetSize(730,610);f:SetPoint("CENTER");f:SetFrameStrata("DIALOG");f:SetClampedToScreen(true)
    f:EnableMouse(true);f:SetMovable(true);f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart",function(self)self:StartMoving()end)
    f:SetScript("OnDragStop",function(self)self:StopMovingOrSizing()end)
    local c=chrome();if c then c.Panel(f) end
    local title=text(f,"Gathering settings",18,-18,610)
    if c and c.Heading then c.Heading(f,title,18,-18,"gather") end
    button(f,"Close",636,-13,76,function()f:Hide()end)
    self.summary=text(f,"",18,-48,690)
    self.pages={};self.tabs={}
    for index,spec in ipairs({{"filters","Filters and display"},{"transfer","Import and export"},{"advanced","Advanced data tools"}}) do
        local key=spec[1]
        self.tabs[key]=button(f,spec[2],18+(index-1)*234,-78,226,function()U:SetPage(key)end,true)
        local pane=CreateFrame("Frame",nil,f);pane:SetPoint("TOPLEFT",f,"TOPLEFT",0,-122);pane:SetSize(730,410)
        self.pages[key]=pane
    end
    local filters=self.pages.filters
    text(filters,"Relevance",18,0,690)
    self.profession=button(filters,"",18,-30,340,function()
        local p=G.Storage.account.preferences;U:Message(G.Storage:SetPreference("professionOnly",not p.professionOnly))
    end)
    self.skill=button(filters,"",372,-30,340,function()
        local p=G.Storage.account.preferences;U:Message(G.Storage:SetPreference("knownSkillOnly",not p.knownSkillOnly))
    end)
    self.origin=button(filters,"",18,-66,340,function(owner)
        if c and c.Choose then choose(owner,{{"all","All locations"},{"PERSONAL","Personal observations"},{"CATALOG","Imported collections"}},G.Storage.account.preferences.sourceFilter,function(value)
            U:Message(G.Storage:SetPreference("sourceFilter",value))
        end) end
    end)
    text(filters,"Material name or item ID",18,-118,220)
    local material=CreateFrame("EditBox",nil,filters,"InputBoxTemplate")
    material:SetPoint("TOPLEFT",filters,"TOPLEFT",22,-145);material:SetSize(448,24);material:SetAutoFocus(false);material:SetMaxLetters(60)
    material:SetScript("OnEscapePressed",function(self)self:ClearFocus()end);self.material=material
    button(filters,"Apply filter",486,-145,138,function()material:ClearFocus();U:Message(G.Storage:SetPreference("material",material:GetText()))end)
    button(filters,"Clear",634,-145,78,function()material:SetText("");U:Message(G.Storage:SetPreference("material",""))end)
    text(filters,"Only the locations shown on your maps are filtered. Your recorded history stays available.",18,-198,690)
    local transfer=self.pages.transfer
    self.source=button(transfer,"Collection: none",18,0,330,function(owner)
        local choices={};for _,id in ipairs(U:Sources()) do choices[#choices+1]={id,id} end
        if c and c.Choose then choose(owner,choices,U:Sources()[U.sourceIndex],function(value)
            for i,id in ipairs(U:Sources()) do if id==value then U.sourceIndex=i;break end end
            U.confirmSource=nil;U:Update()
        end) end
    end,true)
    button(transfer,"Export personal",360,0,168,function()U:Message(G.Transfer:Export("PERSONAL"))end)
    self.exportSource=button(transfer,"Export collection",540,0,172,function()
        U:Message(G.Transfer:Export("CATALOG",U:Sources()[U.sourceIndex]))
    end)
    self.provenance=text(transfer,"",18,-34,690)
    self.provider=button(transfer,"Provider: none",18,-70,330,function(owner)
        local choices={};for _,id in ipairs(U:Providers()) do choices[#choices+1]={id,id} end
        if c and c.Choose then choose(owner,choices,U:Providers()[U.providerIndex],function(value)
            for i,id in ipairs(U:Providers()) do if id==value then U.providerIndex=i;break end end;U:Update()
        end) end
    end,true)
    self.importProvider=button(transfer,"Import provider",360,-70,168,function()U:Message(G.Transfer:ImportProvider(U:Providers()[U.providerIndex]))end)
    button(transfer,"Import pasted pack",540,-70,172,function()U:Message(G.Transfer:ImportText(U.box:GetText()))end)
    text(transfer,"Paste a gathering pack, or copy your export below.",18,-108,690)
    local scroll=c and c.Scroll and c.Scroll(transfer) or CreateFrame("ScrollFrame",nil,transfer,"UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT",transfer,"TOPLEFT",21,-140);scroll:SetSize(665,218)
    local box=CreateFrame("EditBox",nil,scroll)
    box:SetMultiLine(true);box:SetAutoFocus(false);box:SetFontObject(ChatFontNormal or GameFontHighlightSmall)
    box:SetSize(650,218);box:SetMaxLetters(G.Transfer.limit)
    box:SetScript("OnEscapePressed",function(self)self:ClearFocus()end)
    box:SetScript("OnTextChanged",function(self)
        local h=self.GetStringHeight and self:GetStringHeight() or 218;self:SetHeight(math.max(218,h+16))
    end)
    scroll:SetScrollChild(box);self.box=box;self.scroll=scroll
    button(transfer,"Select all",18,-372,144,function()U.box:SetFocus();U.box:HighlightText()end)
    button(transfer,"Cancel",568,-372,144,function()U:Message(G.Transfer:Cancel(),"Transfer cancelled; existing collections retained.")end)
    local advanced=self.pages.advanced
    text(advanced,"Appearance",18,0,690)
    self.pins=button(advanced,"",18,-30,330,function(owner)
        if c and c.Choose then choose(owner,{{20,"20 markers"},{40,"40 markers"},{60,"60 markers"},{80,"80 markers"}},G.Storage.account.preferences.maxPins,function(value)
            U:Message(G.Storage:SetPreference("maxPins",value))
        end) end
    end)
    text(advanced,"Import details",18,-85,690)
    button(advanced,"Rejected entries",18,-116,220,function()
        U:SetPage("transfer");U.box:SetText(G.Transfer:QuarantineText());U.lastOutput=nil
    end,true)
    text(advanced,"Imported packs retain their recorded client version and source attribution.",18,-152,690)
    text(advanced,"Remove saved data",18,-207,690)
    self.advancedSource=text(advanced,"",18,-239,690)
    self.reset=button(advanced,"Remove collection",18,-269,220,function()
        local id=U:Sources()[U.sourceIndex];if not id then return end
        if U.confirmSource~=id then U.confirmSource=id;U.message="Click Remove collection again to remove "..id..". Personal observations remain.";U:Update();return end
        U.confirmSource=nil;U:Message(G.Sites:Reset("catalog",id))
    end)
    button(advanced,"Reset catch samples",250,-269,220,function()
        if not U.confirmSamples then U.confirmSamples=true;U.message="Click Reset catch samples again to clear catch counts. Locations remain.";U:Update();return end
        U.confirmSamples=nil;U:Message(G.Sites:Reset("samples"))
    end)
    button(advanced,"Remove hidden sites",482,-269,230,function()
        if not U.confirmHidden then U.confirmHidden=true;U.message="Export first. Click again to remove hidden personal sites from shared history.";U:Update();return end
        U.confirmHidden=nil;U:Message(G.Sites:Reset("hidden"))
    end)
    self.status=text(advanced,"",18,-330,690)
    self.hint=text(f,"",18,-548,690)
    local save=text(f,"Changes save immediately.",18,-580,690);if c then c.Tint(save,"muted") end
    for _,event in ipairs({"PLAYER_REGEN_DISABLED","PLAYER_REGEN_ENABLED","SKILL_LINES_CHANGED"}) do pcall(f.RegisterEvent,f,event) end
    f:SetScript("OnEvent",function()if f:IsShown() then U:Update() end end)
    f:SetScript("OnHide",function()
        U.confirmSource=nil;U.confirmSamples=nil;U.confirmHidden=nil;U.message=nil
        U.material:ClearFocus();U.box:ClearFocus()
        if c and c.HideTip then c.HideTip() end
    end)
    if c then c.Watch(f) end;f:Hide();self.frame=f;self:SetPage(self.page or "filters")
end
function U:Update()
    if not self.frame or not self.frame:IsShown() then return end
    local a=G.Storage.account;local p=a and a.preferences
    if not self:Writable() then
        self.message="Saved data is preserved read-only; data changes are unavailable."
        self.frame:Hide();return
    end
    local writable=not G:Combat()
    for _,control in ipairs(self.controls or {}) do control:SetEnabled(writable) end
    self.profession:SetText("My professions only: "..(p.professionOnly and "On" or "Off"))
    self.skill:SetText("Known gathering skill only: "..(p.knownSkillOnly and "On" or "Off"))
    self.origin:SetText("Locations: "..(({all="All",PERSONAL="Personal",CATALOG="Imported"})[p.sourceFilter] or "All"));self.pins:SetText("Marker limit: "..p.maxPins)
    if not self.material:HasFocus() then self.material:SetText(p.material or "") end
    local sources=self:Sources();if self.sourceIndex>#sources then self.sourceIndex=1 end
    local id=sources[self.sourceIndex];local source=id and a.sources[id]
    self.source:SetText("Collection: "..(id or "none"));self.advancedSource:SetText("Selected collection: "..(id or "none"));self.exportSource:SetEnabled(writable and id~=nil);self.reset:SetEnabled(writable and id~=nil)
    self.provenance:SetText(source and ((source.sourceLabel or id).." · Imported collection") or
        "Import a collection to add more gathering locations.")
    local providers=self:Providers();if self.providerIndex>#providers then self.providerIndex=1 end
    local provider=providers[self.providerIndex];self.provider:SetText("Provider: "..(provider or "none installed"))
    self.importProvider:SetEnabled(writable and provider~=nil)
    for _,control in ipairs({self.profession,self.skill,self.origin,self.pins}) do control:SetEnabled(writable) end
    self.summary:SetText((G.state.observations or 0).." personal sites · "..(G.state.catalogCount or 0).." imported sites · shown on your maps")
    self.status:SetText("Transfer: "..G.Transfer.state.." · rows "..(G.Transfer.processed or 0).." · rejected "..(G.Transfer.rejected or 0))
    self.hint:SetText(self.message or (self.page=="advanced" and "Map limit: up to 80 markers; minimap: up to 32. Export before removing data." or ""))
    if G.Transfer.output and self.lastOutput~=G.Transfer.output then
        self.box:SetText(G.Transfer.output);self.lastOutput=G.Transfer.output;self.box:SetFocus();self.box:HighlightText()
    end
end
function U:Open()
    if not self:Writable() then return false,"Saved data is preserved read-only; data controls are unavailable." end
    if G:Combat() then return false,"Open data controls after combat." end
    self:Create();if not self.frame then return false,"UI_UNAVAILABLE" end
    local c=chrome();if c and not c.Fit(self.frame) then return false,"Not enough screen space." end
    self.frame:Show();self:Update();return true
end
