local _,G=...
G.Pins={dirty=true,status="MAP_NOT_YET_AVAILABLE",pins={},elapsed=0,mapID=nil}
local P=G.Pins
local function layers()
    if G.core and type(G.core.GetService)=="function" then return G.core.GetService("MapLayers",1) end
end
local function validFrame(f)
    return f and G:Readable(f) and type(f.GetWidth)=="function" and type(f.GetHeight)=="function"
end
local function pinZoom(canvas,container)
    local a,ok=G:Call(canvas and canvas.GetEffectiveScale,canvas)
    local b,known=G:Call(container and container.GetEffectiveScale,container)
    if ok and known and G:Number(a) and G:Number(b) and a>0 and b>0 then return math.max(.05,math.min(20,a/b)) end
    return 1
end
local function taskService()
    if G.core and type(G.core.GetService)=="function" then return G.core.GetService("Tasks",1) end
end
function P:Dirty()
    self.dirty=true;self.scanSerial=(self.scanSerial or 0)+1;self.scanPending=nil
    local tasks=taskService()
    if tasks then tasks.Cancel("MirageIntel_Gather.mapPins") end
end
function P:Initialize()
    if not self.layerSubscribed and G.core and type(G.core.Subscribe)=="function" then
        G.core.Subscribe("MAP_LAYER_CHANGED","MirageIntel_Gather",function(change)
            if type(change)=="table" and change.key=="world:gather" then
                if change.owner and change.owner~="MirageIntel_Gather" then P:HideAll() end
                P:Dirty()
            end
        end)
        -- Loot/material enrichment and scoped history resets publish through
        -- Records without necessarily touching this renderer. Reconcile every
        -- committed history change, including changed material filters.
        G.core.Subscribe("WORLD_RECORDS_CHANGED","MirageIntel_Gather_MapPins",function(change)
            if type(change)=="table" and change.owner=="MirageIntel_Gather" then P:Dirty() end
        end)
        self.layerSubscribed=true
    end
    if G:Combat() then return end
    local frame=WorldMapFrame
    if not frame or not G:Readable(frame) or type(frame.HookScript)~="function" then
        self:HideAll();self.status="MAP_FRAME_NOT_LOADED";return
    end
    local container=frame.ScrollContainer
    local canvas=container and container.Child
    if frame~=self.frame then
        self:HideAll()
        self.frame=frame
        local existing=self.hookStates and self.hookStates[frame]
        self.hooked=existing==true;self.hookRejected=existing==false
    end
    if not validFrame(canvas) then
        self:HideAll();self.status="MAP_CANVAS_NOT_SUPPORTED";return
    end
    if canvas~=self.canvas then
        self:HideAll()
        self.canvas=canvas
        for i,pin in ipairs(self.pins) do
            local ok=type(pin.SetParent)=="function" and pcall(pin.SetParent,pin,canvas)
            if not ok then
                -- Preserve dense indexing and retire the previous map's pool
                -- if the client refuses moving its UI children.
                self.pins={};break
            end
        end
    end
    if self.hooked or self.hookRejected then return end
    local p=self
    local function live() return p.hooked and p.frame==frame end
    local ok=pcall(frame.HookScript,frame,"OnShow",function() if live() then p:Dirty();p:Refresh() end end)
    local update=pcall(frame.HookScript,frame,"OnUpdate",function(_,elapsed)
        if not live() then return end
        p.elapsed=p.elapsed+(G:Number(elapsed) and math.min(elapsed,.2) or 0)
        if p.elapsed>=.65 then p.elapsed=0;p:Refresh() end
    end)
    local hide=pcall(frame.HookScript,frame,"OnHide",function() if live() then p:HideAll() end end)
    self.hookStates=self.hookStates or setmetatable({},{__mode="k"})
    self.hooked=ok and update and hide
    self.hookStates[frame]=self.hooked
    self.hookRejected=not self.hooked
    self.status=self.hooked and "MAP_PINS_NATIVE_UNTESTED" or "MAP_SCRIPT_HOOK_UNAVAILABLE"
    self:Dirty()
end
function P:HideAll(repainting)
    if not repainting then self:Dirty() end
    if not repainting then local registry=layers();if registry then registry.Release("world:gather","MirageIntel_Gather") end end
    for _,pin in ipairs(self.pins) do
        pin:Hide();pin.record=nil;pin.key=nil;pin.published=false
        if pin.press~=nil then pin.press=false end
    end
    self.visibleCount=0
end
function P:PinKey(row)
    if type(row)~="table" then return nil end
    local values={row.id,row.mapID,row.floorID or row.mapID,row.x,row.y,row.kind,row.name}
    for i,value in ipairs(values) do
        value=type(value)=="number" and string.format("%.17g",value) or tostring(value)
        values[i]=#value..":"..value
    end
    return table.concat(values)
end
function P:CurrentRecord(pin)
    if not pin or not pin.published or not pin.record or self.frame~=WorldMapFrame or
        not self.frame.ScrollContainer or self.frame.ScrollContainer.Child~=self.canvas or G:Combat() or
        G.Storage.readOnly or not G.state.clientAllowed then return nil end
    local shown,visible=G:Call(self.frame.IsShown,self.frame)
    local mapID,read=G:Call(self.frame.GetMapID,self.frame)
    if not visible or shown~=true or not read or mapID~=self.mapID then return nil end
    local prefs=G.Storage.account and G.Storage.account.preferences
    if not prefs or prefs.showMapPins~=true then return nil end
    local registry=layers()
    if registry and registry.GetOwner("world:gather")~="MirageIntel_Gather" then return nil end
    local row=G.Sites and G.Sites:Get(pin.record.id) or G.Storage.account.records[pin.record.id]
    if not row or self:PinKey(row)~=pin.key or row.mapID~=mapID or (row.floorID or row.mapID)~=mapID or
        G.Storage:Hidden(row.id) or (G.Sites and not G.Sites:Matches(row)) or
        (prefs.category~="all" and prefs.category~=row.kind) then return nil end
    return row
end
function P:AcquirePin(key,used)
    for _,pin in ipairs(self.pins) do
        if not used[pin] and pin.key==key then used[pin]=true;return pin end
    end
    -- A bounded spare pool prepares replacements while the last committed
    -- display stays clickable. Retain at most two complete 80-pin displays.
    for _,pin in ipairs(self.pins) do
        if not used[pin] and not pin.published then used[pin]=true;return pin end
    end
    if #self.pins>=160 then return nil end
    local pin=self:NewPin();if pin then used[pin]=true end;return pin
end
function P:NewPin()
    if G:Combat() or not self.canvas then return nil end
    local b=CreateFrame("Button",nil,self.canvas)
    if not b then return nil end
    b:SetSize(32,32)
    local texture=b:CreateTexture(nil,"ARTWORK")
    texture:SetAllPoints(b)
    texture:SetTexture("Interface\\AddOns\\MirageIntel_Core\\Media\\MapIcons\\herb.tga")
    b.texture=texture
    b:SetScript("OnEnter",function(self)
        local r=P:CurrentRecord(self)
        if not r then return end
        local insight=MirageInsightAPI
        if type(insight)=="table" and type(insight.ShowUtilityRecord)=="function" then
            local record=G.Records:Record(r)
            local shared=G.core and G.core.GetService and G.core.GetService("WorldRecords",1)
            if shared then record=shared.Get("gather:"..r.id) or record end
            local called,shown=pcall(insight.ShowUtilityRecord,self,record,
                {purpose="HISTORICAL_SITE",hint="Click to navigate"})
            if called and shown then return end
        end
        if not GameTooltip then return end
        GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
        GameTooltip:AddLine(r.name,.96,.79,.36,true)
        local kind=({herb="Herbalism",ore="Mining",skin="Skinning",fish="Fishing",pool="Fishing pool",treasure="Treasure"})[r.kind] or "Gathering"
        GameTooltip:AddLine(kind.." · recorded gathering spot",.90,.89,.87,true)
        GameTooltip:AddLine(string.format("%.1f, %.1f",r.x*100,r.y*100),.8,.8,.8,true)
        GameTooltip:Show()
    end)
    local function release(self)
        local insight=MirageInsightAPI
        if type(insight)=="table" and type(insight.HideUtilityRecord)=="function" then pcall(insight.HideUtilityRecord,self) end
        if GameTooltip and GameTooltip.IsOwned and GameTooltip:IsOwned(self) then GameTooltip:Hide() end
    end
    b:SetScript("OnLeave",release);b:SetScript("OnHide",function(self)
        if self.press~=nil then self.press=false end;release(self)
    end)
    b:SetScript("OnMouseDown",function(self,button)
        if button=="LeftButton" and P:CurrentRecord(self) then
            self.press={key=self.key,canvas=P.canvas,mapID=P.mapID,at=G:Now()}
        else self.press=false end
    end)
    b:SetScript("OnClick",function(self,button)
        local press=self.press
        if press==false then return end -- retired presses cannot target a reused button
        self.press=nil
        if button and button~="LeftButton" then return end
        if press and (press.key~=self.key or press.canvas~=P.canvas or press.mapID~=P.mapID or
            G:Now()<press.at or G:Now()-press.at>3) then return end
        local row=P:CurrentRecord(self)
        if row then
            local ok,reason=G.Nav:Select(row.id)
            G:Print(ok and "Destination selected." or G.Nav:Message(reason))
        end
    end)
    self.pins[#self.pins+1]=b
    return b
end
function P:Refresh()
    if not G.state.initialized or not G.state.clientAllowed then return end
    self:Initialize()
    if not self.frame or not self.hooked or not self.canvas then return end
    if G:Combat() or G.Storage.readOnly then self:HideAll();return end
    local container=self.frame.ScrollContainer
    if self.frame~=WorldMapFrame or not container or container.Child~=self.canvas then
        self:HideAll();return
    end
    local shown,valid=G:Call(self.frame.IsShown,self.frame)
    if not valid or not shown then self:HideAll();return end
    local mapID,ok=G:Call(self.frame.GetMapID,self.frame)
    if not ok or not G:Natural(mapID) then
        self:HideAll();self.status="MAP_ID_UNAVAILABLE";return
    end
    local width,wok=G:Call(self.canvas.GetWidth,self.canvas)
    local height,hok=G:Call(self.canvas.GetHeight,self.canvas)
    if not wok or not hok or not G:Number(width) or not G:Number(height) or width<=1 or height<=1 then
        self:HideAll();self.status="MAP_GEOMETRY_UNAVAILABLE";return
    end
    local prefs=G.Storage.account and G.Storage.account.preferences
    if not prefs or not prefs.showMapPins then self:HideAll();self.status="MAP_PINS_DISABLED";return end
    local mapAPI=MirageMapAPI
    if type(mapAPI)=="table" and (type(mapAPI.GetLayerPreferences)=="function" or type(mapAPI.GetStatus)=="function") then
        local state,known=G:Call(mapAPI.GetLayerPreferences or mapAPI.GetStatus)
        local settings=known and type(state)=="table" and state.settings
        if type(settings)=="table" and settings.mapPolicy~="off" and settings.showResourcePins==false and
            state.readOnly~=true and state.clientAllowed~=false and (not state.state or state.state.clientAllowed~=false) then
            self:HideAll();self.status="MAP_RESOURCE_LAYER_EXPLICITLY_DISABLED";return
        end
    end
    local registry=layers()
    local owned=registry and registry.Acquire("world:gather","MirageIntel_Gather",10,3)
    if not owned then self:HideAll();self.status="MAP_LAYER_OWNED_BY_MAP_OR_UNAVAILABLE";return end
    local zoom=pinZoom(self.canvas,container)
    if not self.dirty and self.mapID==mapID and self.width==width and self.height==height and self.zoom==zoom then return end
    local sameView=self.mapID==mapID and self.width==width and self.height==height and self.zoom==zoom
    if not sameView then self:HideAll(true) end
    self.dirty=false;self.mapID=mapID;self.width=width;self.height=height;self.zoom=zoom
    local tasks=taskService()
    if not tasks or type(tasks.Queue)~="function" then self.dirty=true;self.status="MAP_SCHEDULER_UNAVAILABLE";return end
    local limit=math.min(prefs.maxPins,80)
    local selected,byCell={},{}
    local found=0
    local account=G.Storage.account;local revision=G.Records:Revision();local records=account.records
    if type(records)~="table" then self.status="STORAGE_UNAVAILABLE";return end
    local key=nil
    local iterator=G.Sites and G.Sites:Each() or function()local row;key,row=next(records,key);return key,row end
    self.scanSerial=(self.scanSerial or 0)+1;local serial=self.scanSerial
    self.scanPending=serial;self.status="PREPARING_MAP_PINS"
    local phase,paintIndex="SCAN",1
    local prepared,usedPins={},{}
    local function current()
        if self.scanSerial~=serial or self.dirty or G:Combat() or G.Storage.readOnly or not G.state.clientAllowed or
            G.Storage.account~=account or revision~=G.Records:Revision() or self.mapID~=mapID or self.width~=width or self.height~=height then return false end
        if self.frame~=WorldMapFrame or not self.frame.ScrollContainer or self.frame.ScrollContainer.Child~=self.canvas then return false end
        local shown,read=G:Call(self.frame.IsShown,self.frame)
        local view,known=G:Call(self.frame.GetMapID,self.frame)
        return read and shown and known and view==mapID and pinZoom(self.canvas,self.frame.ScrollContainer)==zoom and registry.GetOwner("world:gather")=="MirageIntel_Gather"
    end
    local function newer(a,b)
        if a.lastSeen~=b.lastSeen then return a.lastSeen>b.lastSeen end
        return tostring(a.id)<tostring(b.id)
    end
    local function retain(row)
        local cell=row.kind..":"..math.floor(row.x*120)..":"..math.floor(row.y*120)
        local old=byCell[cell]
        if old then
            if not newer(row,old.row) then return end
            for i,entry in ipairs(selected) do if entry==old then table.remove(selected,i);break end end
        end
        local entry={row=row,cell=cell};local at=#selected+1
        for i,other in ipairs(selected) do if newer(row,other.row) then at=i;break end end
        if at<=limit then
            table.insert(selected,at,entry);byCell[cell]=entry
            if #selected>limit then local removed=table.remove(selected);byCell[removed.cell]=nil end
        elseif old then byCell[cell]=nil end
    end
    local queued=tasks.Queue("MirageIntel_Gather.mapPins",function()
        if not current() then
            if self.scanPending==serial then self:HideAll();self.status="MAP_CONTEXT_CHANGED" end
            return false
        end
        if phase=="SCAN" then
            for _=1,32 do
                local id,row=iterator()
                if not id then phase="PAINT";break end
                if row.mapID==mapID and (row.floorID or row.mapID)==mapID and not G.Storage:Hidden(row.id) and
                    (not G.Sites or G.Sites:Matches(row)) and (prefs.category=="all" or prefs.category==row.kind) then
                    found=found+1;retain(row)
                end
            end
            return true
        end
        -- Keep stable identities through data repaints. Prepare only new or
        -- hidden buttons in bounded slices, then publish the replacement set.
        for _=1,8 do
            local entry=selected[paintIndex]
            if not entry then
                if not current() then return false end
                for _,pin in ipairs(self.pins) do if not usedPins[pin] then
                    pin:Hide();pin.record=nil;pin.key=nil;pin.published=false
                    if pin.press~=nil then pin.press=false end
                end end
                for _,value in ipairs(prepared) do
                    local pin=value.pin;pin.record=value.row;pin.key=value.key;pin.published=true;pin:Show()
                end
                self.visibleCount=#selected;self.eligibleCount=found;self.scanPending=nil
                self.status="HISTORICAL_PINS:"..#selected.."/"..found
                return false
            end
            local row=entry.row;local key=self:PinKey(row);local pin=self:AcquirePin(key,usedPins)
            if not pin then self:HideAll();self.status="MAP_FRAME_CREATION_BLOCKED";return false end
            if not pin.published then
                pin:Hide();pin:ClearAllPoints()
                pin:SetPoint("CENTER",self.canvas,"TOPLEFT",row.x*width,-row.y*height)
                local icons=G.core and G.core.MapIcons
                pin:SetSize((icons and icons.sizes and icons.sizes.world or 32)/zoom,(icons and icons.sizes and icons.sizes.world or 32)/zoom)
                if icons then icons.Apply(pin.texture,{kind="gather",category=row.kind})
                else pin.texture:SetVertexColor(1,1,1,1) end
            end
            prepared[#prepared+1]={pin=pin,row=row,key=key}
            paintIndex=paintIndex+1
        end
        return true
    end,revision)
    if not queued then self.scanPending=nil;self.dirty=true;self.status="MAP_QUEUE_UNAVAILABLE" end
end
