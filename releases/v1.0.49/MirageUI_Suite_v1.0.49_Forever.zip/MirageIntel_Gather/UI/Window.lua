local _,G=...
G.UI={offset=0,exportOffset=0,includeHidden=false,manualKind="herb",scope="all",sort="recent",materialIndex=1}
local U=G.UI
local chrome=G.core and G.core.Chrome
local PAGE=6
local function finish(frame) if chrome then chrome.Watch(frame) end end
local function fit(frame) return not chrome or chrome.Fit(frame) end
local sources={CONFIRMED="Gathered",PROBABLE="Recorded",MANUAL="Saved"}
local kinds={all="All resources",herb="Herbs",ore="Ore",fish="Fish",pool="Pools",skin="Skins",treasure="Treasure"}
local function label(parent,value,x,y,font,width)
    local region=parent:CreateFontString(nil,"OVERLAY",font or "GameFontHighlightSmall")
    if chrome and chrome.Font then chrome.Font(region,font=="GameFontNormalLarge" and "title" or "body") end
    region:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y);region:SetJustifyH("LEFT")
    if width then region:SetWidth(width) end;region:SetText(value or "")
    if chrome then chrome.Tint(region,font and "secondary" or "text") end
    return region
end
local function button(parent,value,x,y,width,fn,height)
    if chrome then return chrome.Button(parent,value,x,y,width,height or 25,fn) end
    local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
    b:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y);b:SetSize(width,height or 25);b:SetText(value);b:SetScript("OnClick",fn);return b
end
local function small(region)
    if chrome and chrome.Font then chrome.Font(region,"small") end
    if chrome then chrome.Tint(region,"muted") end
end
local function hook(frame,event,fn)
    if type(frame.HookScript)=="function" then frame:HookScript(event,fn)
    else
        local previous=type(frame.GetScript)=="function" and frame:GetScript(event)
        frame:SetScript(event,function(self,...)
            if type(previous)=="function" then previous(self,...) end;fn(self,...)
        end)
    end
end
local function valid()
    local a=G.Storage.account
    return G.state.clientAllowed and not G.Storage.readOnly and type(a)=="table" and type(a.preferences)=="table"
end
local function sameRow(a,b)
    if type(a)~="table" or type(b)~="table" then return false end
    for key,value in pairs(a) do if b[key]~=value then return false end end
    for key,value in pairs(b) do if a[key]~=value then return false end end
    return true
end
local function retireRow(button)
    button.rowBinding=nil
    if button.rowPress~=nil then button.rowPress=false end
end
function U:RowBinding(record)
    if not record then return nil end
    return {account=G.Storage.account,character=G.Storage.character,id=record.id,kind=record.kind,
        mapID=record.mapID,floorID=record.floorID or record.mapID,x=record.x,y=record.y,name=record.name,
        origin=record.origin or "PERSONAL",hidden=record.hidden==true}
end
function U:RowClickAllowed(button,index,mouse,pressed)
    local entry=self.entries[index];local record=entry and entry.record
    if not self:CanChange() or not self.frame:IsShown() or not button:IsShown() or not button:IsEnabled() or
        not sameRow(button.rowBinding,self:RowBinding(record)) then return false end
    if pressed~=nil and (pressed==false or pressed.binding~=button.rowBinding or pressed.mouse~=mouse) then return false end
    local current=G.Sites and G.Sites:Get(record.id)
    if not current then return false end
    local binding=self:RowBinding(current);binding.hidden=G.Storage:Hidden(record.id)==true
    return sameRow(button.rowBinding,binding)
end
function U:BindEntry(entry)
    local binding=self:RowBinding(entry.record)
    for _,button in ipairs({entry.choose,entry.hide}) do
        local current=button:IsShown() and binding or nil
        if not sameRow(button.rowBinding,current) then retireRow(button);button.rowBinding=current end
    end
end
function U:CanChange() return valid() and not G:Combat() end
function U:UnavailableReason()
    if G.Storage.readOnly then return "STORAGE_READ_ONLY" end
    if not G.state.clientAllowed then return "This game build is not available for utility actions." end
    return "UNAVAILABLE_DURING_COMBAT"
end
function U:Result(ok,reason)
    self.message=ok and (type(reason)=="string" and reason:find(" ") and reason or "Updated.") or G.Nav:Message(reason)
    self:Update();return ok,reason
end
function U:MapName(id,record)
    if record and G:Label(record.zone) then return record.zone end
    self.mapNames=self.mapNames or {}
    if self.mapNames[id] then return self.mapNames[id] end
    local api=MirageMapAPI
    local guide,read=G:Call(type(api)=="table" and api.GetZoneGuide,id)
    local name=read and type(guide)=="table" and G:Label(guide.name)
    if name then self.mapNames[id]=name end
    return name or ("Map "..tostring(id))
end
function U:Age(stamp)
    local now=G:When()
    if not G:Number(stamp) or stamp<=0 or now<stamp then return "time not recorded" end
    local age=now-stamp
    if age<60 then return "seen just now" elseif age<3600 then return "seen "..math.floor(age/60).."m ago"
    elseif age<86400 then return "seen "..math.floor(age/3600).."h ago" end
    return "seen "..math.floor(age/86400).."d ago"
end
function U:Select(record)
    self.selectedID=record and record.id or nil;self.selected=record;self.materialIndex=1;self.message=nil;self:Update()
end
function U:CurrentSelection()
    local selected=self.selected
    if not valid() or not selected or selected.id~=self.selectedID or selected.sourceRevision~=G.Records:Revision() then return nil end
    local row=G.Sites and G.Sites:Get(selected.id)
    if not row or row.mapID~=selected.mapID or (row.floorID or row.mapID)~=(selected.floorID or selected.mapID) or
        row.x~=selected.x or row.y~=selected.y or
        row.name~=selected.name or row.kind~=selected.kind or G.Storage:Hidden(row.id) then return nil end
    return row
end
-- Optional handoffs consume current canonical records. A stale displayed row
-- may never select the coordinates of a replacement site or a different item.
function U:ShowOnMap()
    if not self:CanChange() then return self:Result(false,self:UnavailableReason()) end
    local row=self:CurrentSelection();if not row then return self:Result(false,"RECORD_NOT_FOUND_OR_HIDDEN") end
    local account=G.Storage.account;local revision=G.Records:Revision();local selectedID=self.selectedID
    local map=MirageMapAPI
    if type(map)~="table" or map.apiVersion~=1 or type(map.ShowUtilityRecord)~="function" then
        return self:Result(false,"Map+ Ultra is not available.")
    end
    local records,read=G:Call(G.core and G.core.GetService,"WorldRecords",1)
    local record,got=G:Call(read and records and records.Get,"gather:"..row.id)
    if not self:CanChange() or self.selectedID~=selectedID or account~=G.Storage.account or revision~=G.Records:Revision() or
        MirageMapAPI~=map or self:CurrentSelection()~=row then return self:Result(false,"The selected site changed. Select it again.") end
    if not got or type(record)~="table" or record.hidden or record.owner~="MirageIntel_Gather" or
        record.mapID~=row.mapID or (record.floorID or record.mapID)~=(row.floorID or row.mapID) or
        record.x~=row.x or record.y~=row.y or record.name~=row.name then
        return self:Result(false,"This site is being published. Try View map again.")
    end
    local ok,called,why=G:Call(map.ShowUtilityRecord,record,{userInitiated=true})
    if not called or not ok then return self:Result(false,why or "Map inspection is unavailable.") end
    if self:CanChange() and self.selectedID==selectedID and account==G.Storage.account and revision==G.Records:Revision() and MirageMapAPI==map then self.frame:Hide() end
    return true,"SITE_SHOWN_ON_MAP"
end
function U:InspectMaterial()
    if not self:CanChange() then return self:Result(false,self:UnavailableReason()) end
    local row=self:CurrentSelection();if not row then return self:Result(false,"RECORD_NOT_FOUND_OR_HIDDEN") end
    local _,ids=G.Sites:Materials(row);local item=ids and ids[self.materialIndex]
    if not G:Natural(item) then return self:Result(false,"No observed material is selected for this site.") end
    local account=G.Storage.account;local revision=G.Records:Revision();local selectedID=self.selectedID
    local api=MirageInsightAPI
    if type(api)~="table" or api.apiVersion~=1 or type(api.OpenItem)~="function" then return self:Result(false,"Insight is not available.") end
    if not self:CanChange() or account~=G.Storage.account or revision~=G.Records:Revision() or self.selectedID~=selectedID then
        return self:Result(false,"The selected site changed. Select it again.")
    end
    local ok,called,why=G:Call(api.OpenItem,item,{userInitiated=true})
    if not called or not ok then return self:Result(false,why or "Item details are unavailable.") end
    if self:CanChange() and account==G.Storage.account and revision==G.Records:Revision() and self.selectedID==selectedID and MirageInsightAPI==api then self.frame:Hide() end
    return true,"ITEM_OPENED"
end
function U:ResetBrowse()
    -- Only this window's filters are reset. Recording and route preferences
    -- stay under the player's existing controls.
    self.scope="all";self.sort="recent";self.includeHidden=false;self.offset=0;self.selectedID=nil;self.selected=nil
    self.search:SetText("");self.message="Browsing all areas. Resource and profession filters are in Data / filters."
    self:Update()
end
function U:SessionSummary(snap)
    if not snap then return "Connect Wayfinder to start a gathering route.","Your recording and saved sites work independently." end
    local confirmed,deferred=0,0
    for _,entry in pairs(snap.deferrals or {}) do
        if entry.outcome=="HARVESTED" then confirmed=confirmed+1 else deferred=deferred+1 end
    end
    local stops=snap.itinerary and snap.itinerary.stops or {}
    local progress=snap.progress
    local details={#stops.." stops"}
    if progress then
        if (progress.castCompletions or 0)>0 then details[#details+1]=progress.castCompletions.." completed casts" end
        if (progress.confirmedHarvests or 0)>0 then details[#details+1]=progress.confirmedHarvests.." loot confirmed" end
        if (progress.visited or 0)>0 then details[#details+1]=progress.visited.." visited" end
        if (progress.skipped or 0)>0 then details[#details+1]=progress.skipped.." skipped" end
    else
        details[#details+1]=confirmed.." loot confirmed";details[#details+1]=deferred.." visited"
    end
    local counts=table.concat(details," · ")
    if snap.mode=="Pause" then return "Navigation paused",snap.sessionID and counts or "Resume your route in Wayfinder or start a gathering session here." end
    if snap.mode~="Gather" and not (snap.mode=="Auto" and snap.destination and snap.destination.kind=="gather") then return "Recording as you gather", "Saved sites appear on your map and minimap automatically." end
    local dest=snap.destination
    if dest then
        return dest.kind=="gather" and (dest.name or dest.label or "Gathering stop") or "Your explicit destination has priority",counts
    end
    local reason=({BAGS_FULL="Make room in your bags to continue.",PROFESSION_REQUIRED="Choose a resource for a learned profession.",
        PLAYER_DEAD="Navigation resumes after you revive.",PLAYER_ON_TAXI="Navigation resumes after your flight.",
        WAITING_GATHER_PROVIDER="Gather Mate is reconnecting.",GATHER_SITE_SCAN_PENDING="Finding nearby nodes…",
        NO_ELIGIBLE_LOCAL_HISTORY="Gather a resource to save a location, or adjust your filters.",
        ALL_SITES_DEFERRED="Route complete. Start a new gathering route whenever you are ready."})[snap.gatherStatus or snap.status]
    return "Finding your next site",reason or counts
end
function U:Create()
    if self.frame or not UIParent or G:Combat() then return end
    local f=CreateFrame("Frame","MirageIntelGatherPanel",UIParent,"BackdropTemplate")
    f:SetSize(720,684);f:SetPoint("CENTER",UIParent,"CENTER",35,15);f:SetFrameStrata("DIALOG");f:SetClampedToScreen(true)
    f:EnableMouse(true);f:SetMovable(true);f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart",function(self)self:StartMoving()end);f:SetScript("OnDragStop",function(self)self:StopMovingOrSizing()end)
    if chrome then chrome.Panel(f) else
        f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8x8",edgeFile="Interface\\Buttons\\WHITE8x8",edgeSize=1})
        f:SetBackdropColor(.06,.06,.065,.97);f:SetBackdropBorderColor(.26,.26,.26,1)
    end
    local title=label(f,"Gather Mate",18,-17,"GameFontNormalLarge")
    if chrome and chrome.Heading then chrome.Heading(f,title,18,-17,"gather") end
    button(f,"Close",622,-14,80,function()f:Hide()end)
    self.summary=label(f,"",18,-50,nil,684);self.summary:SetHeight(27)
    self.enabledButton=button(f,"Record gathering locations: On",18,-82,238,function()
        if not U:CanChange() then return end;U:Result(G.Storage:SetPreference("enabled",not G.Storage.account.preferences.enabled))
    end)
    self.pinsButton=button(f,"World map ON",264,-82,112,function()
        if not U:CanChange() then return end;U:Result(G.Storage:SetPreference("showMapPins",not G.Storage.account.preferences.showMapPins))
    end)
    self.minimapButton=button(f,"Minimap ON",384,-82,112,function()
        if not U:CanChange() then return end;U:Result(G.Storage:SetPreference("showMinimapPins",G.Storage.account.preferences.showMinimapPins==false))
    end)
    self.dataButton=button(f,"Settings",504,-82,94,function()if G.DataUI then G.DataUI:Open() end end)
    self.exportButton=button(f,"Export",606,-82,96,function()U:Export()end)
    local card=CreateFrame("Frame",nil,f,"BackdropTemplate");card:SetPoint("TOPLEFT",f,"TOPLEFT",18,-119);card:SetSize(684,79)
    if chrome then chrome.Panel(card,"hud") end
    self.sessionHint=label(card,"",12,-12,nil,474);self.sessionHint:SetHeight(20)
    if chrome then chrome.OneLine(self.sessionHint) end
    self.sessionMeta=label(card,"",12,-36,nil,474);self.sessionMeta:SetHeight(34);small(self.sessionMeta)
    self.sessionButton=button(card,"Start gathering",496,-10,176,function()
        if not U:CanChange() then return end
        local snap=G.Session:Snapshot();U:Result(G.Session:SetEnabled(not (snap and (snap.mode=="Gather" or snap.mode=="Auto" and snap.destination and snap.destination.kind=="gather"))))
    end)
    self.skipButton=button(card,"Skip stop",496,-43,176,function()
        if not U:CanChange() then return U:Result(false,U:UnavailableReason()) end
        U:Result(G.Session:Skip())
    end)
    self.categoryButton=button(f,"All resources",18,-214,126,function()
        if not U:CanChange() then return end
        local order={"all","herb","ore","fish","pool","skin","treasure"};local current=G.Storage.account.preferences.category;local idx=1
        for i,v in ipairs(order) do if v==current then idx=i;break end end
        U.offset=0;U:Result(G.Storage:SetPreference("category",order[idx%#order+1]))
    end)
    self.scopeButton=button(f,"All areas",152,-214,104,function()U.scope=U.scope=="all" and "local" or "all";U.offset=0;U:Update()end)
    self.sortButton=button(f,"Recent first",264,-214,121,function()
        U.sort=({recent="nearest",nearest="name",name="recent"})[U.sort] or "recent";U.offset=0;U:Update()
    end)
    self.resetButton=button(f,"Reset view",393,-214,92,function()U:ResetBrowse()end)
    local search=CreateFrame("EditBox",nil,f,"InputBoxTemplate")
    search:SetPoint("TOPLEFT",f,"TOPLEFT",499,-214);search:SetSize(200,25);search:SetAutoFocus(false);search:SetMaxLetters(60)
    search:SetScript("OnTextChanged",function()U.offset=0;U:Update()end)
    search:SetScript("OnEnterPressed",function(box)box:ClearFocus()end);search:SetScript("OnEscapePressed",function(box)box:ClearFocus()end)
    self.search=search
    local searchHint=label(f,"Search sites or materials",499,-200,nil,200);small(searchHint)
    self.entries={}
    for i=1,PAGE do
        local y=-249-(i-1)*39
        local choose=button(f,"",18,y,601,function(self,mouse)
            if not U:RowClickAllowed(self,i,mouse,self.rowPress) then self.rowPress=false;return end
            self.rowPress=nil;U:Select(U.entries[i].record)
        end,35)
        local title=label(choose,"",9,-4,nil,581);local meta=label(choose,"",9,-20,nil,581);small(meta)
        if chrome then chrome.OneLine(title);chrome.OneLine(meta) end
        local hide=button(f,"Hide",627,y-4,75,function(self,mouse)
            if not U:RowClickAllowed(self,i,mouse,self.rowPress) then self.rowPress=false;return end
            self.rowPress=nil;local row=U.entries[i].record
            U:Result(G.Storage:Hide(row.id,not G.Storage:Hidden(row.id)))
        end)
        self.entries[i]={text=title,detail=meta,choose=choose,hide=hide}
        for _,control in ipairs({choose,hide}) do
            hook(control,"OnMouseDown",function(self,mouse)
                self.rowPress=U:RowClickAllowed(self,i,mouse) and {binding=self.rowBinding,mouse=mouse} or false
            end)
            hook(control,"OnHide",retireRow)
        end
        hook(choose,"OnEnter",function(self)
            local row=U.entries[i] and U.entries[i].record
            if row and chrome and chrome.Tip then
                local body=(row.origin=="CATALOG" and "Imported location" or sources[row.quality] or "Saved location").." · "..
                    U:MapName(row.mapID,row)..string.format(" · %.1f, %.1f",row.x*100,row.y*100).."\n"..U:Age(row.lastSeen)..
                    "\n"..(row.materialText and row.materialText~="" and row.materialText or "No material sample recorded.")..
                    "\nSelect to visit this location."
                chrome.Tip(self,row.name,body)
            end
        end)
        hook(choose,"OnLeave",function(self)if chrome and chrome.HideTip then chrome.HideTip(self) end end)
        hook(choose,"OnHide",function(self)if chrome and chrome.HideTip then chrome.HideTip(self) end end)
    end
    self.hint=label(f,"",18,-488,nil,486);small(self.hint)
    self.prev=button(f,"Previous",510,-482,91,function()U.offset=math.max(0,U.offset-PAGE);U:Update()end)
    self.next=button(f,"Next",609,-482,93,function()U.offset=U.offset+PAGE;U:Update()end)
    self.selection=label(f,"",18,-516,nil,684);self.selection:SetHeight(47);small(self.selection)
    self.navigate=button(f,"Navigate",18,-568,106,function()
        local row=U:CurrentSelection()
        if row then local ok,why=G.Nav:Select(row.id);U:Result(ok,ok and "Wayfinder is guiding you to this site." or why)
        else U:Result(false,"RECORD_NOT_FOUND_OR_HIDDEN") end
    end)
    self.viewMap=button(f,"View map",132,-568,106,function()U:ShowOnMap()end)
    self.clearButton=button(f,"Clear route",246,-568,110,function()
        if not U:CanChange() then return U:Result(false,U:UnavailableReason()) end
        U:Result(G.Nav:Clear())
    end)
    self.materialButton=button(f,"No material",364,-568,207,function()U.materialIndex=U.materialIndex+1;U:Update()end)
    self.inspect=button(f,"Insight",579,-568,123,function()U:InspectMaterial()end)
    local caption=label(f,"Record a location",18,-605,nil,190);small(caption)
    self.showHidden=button(f,"Show hidden",592,-601,110,function()U.includeHidden=not U.includeHidden;U.offset=0;U:Update()end)
    self.manualCategory=button(f,"Add: Herbs",18,-628,112,function()
        local order={"herb","ore","fish","pool","skin","treasure"}
        for i,v in ipairs(order) do if v==U.manualKind then U.manualKind=order[i%#order+1];break end end;U:Update()
    end)
    self.manualName=CreateFrame("EditBox",nil,f,"InputBoxTemplate")
    self.manualName:SetPoint("TOPLEFT",f,"TOPLEFT",144,-628);self.manualName:SetSize(430,25);self.manualName:SetAutoFocus(false);self.manualName:SetMaxLetters(90)
    local function saveHere()
        if not U:CanChange() then return end
        local name=U.manualName:GetText():match("^%s*(.-)%s*$")
        if not G:Label(name) then U:Result(false,"Enter a resource name before saving.");return end
        local ok,why=G.API:RecordHere(U.manualKind,name)
        if ok then U.manualName:SetText("");U.manualName:ClearFocus();U.offset=0 end
        U:Result(ok,ok and "Location saved." or why)
    end
    self.manualName:SetScript("OnEnterPressed",saveHere);self.manualName:SetScript("OnEscapePressed",function(box)box:ClearFocus()end)
    self.saveManual=button(f,"Save here",586,-628,116,saveHere)
    local footer=label(f,"Gather to save locations automatically · follow your route in Wayfinder",18,-663,nil,684);small(footer)
    f:SetScript("OnHide",function()
        for _,entry in ipairs(self.entries) do retireRow(entry.choose);retireRow(entry.hide) end
        self.search:ClearFocus();self.manualName:ClearFocus();if chrome and chrome.HideTip then chrome.HideTip() end
    end)
    finish(f);f:Hide();self.frame=f
end
function U:Open()
    if G:Combat() then return false,"Open Gather after combat." end
    self:Create();if not self.frame then return false,"UI_UNAVAILABLE_OR_COMBAT" end
    if not fit(self.frame) then return false,"Not enough space to open this panel." end
    self.frame:Show();self:Update();G.Pins:Initialize();return true
end
function U:Update()
    if not self.frame or not self.frame:IsShown() then return end
    local a=G.Storage.account;local ready=not G.Storage.readOnly and type(a)=="table" and type(a.preferences)=="table"
    local writable=ready and G.state.clientAllowed and not G:Combat()
    local snap=ready and G.Session:Snapshot() or nil;local gathering=snap and (snap.mode=="Gather" or snap.mode=="Auto" and snap.destination and snap.destination.kind=="gather")
    self.sessionButton:SetEnabled(writable and snap~=nil);self.skipButton:SetEnabled(writable and gathering and snap.destination and snap.destination.kind=="gather" or false)
    self.sessionButton:SetText(gathering and "End gathering" or snap and snap.mode=="Pause" and snap.sessionID and "Resume gathering" or "Start gathering")
    local title,meta=self:SessionSummary(snap);self.sessionHint:SetText(title);self.sessionMeta:SetText(meta)
    if chrome then chrome.Active(self.sessionButton,gathering==true) end
    for _,control in ipairs({self.categoryButton,self.enabledButton,self.pinsButton,self.minimapButton,self.manualCategory,self.saveManual}) do control:SetEnabled(writable) end
    for _,control in ipairs({self.exportButton,self.dataButton,self.scopeButton,self.sortButton,self.resetButton,self.showHidden}) do control:SetEnabled(ready) end
    self.clearButton:SetEnabled(writable);self.search:SetShown(ready);self.manualName:SetShown(writable)
    if not writable then self.manualName:ClearFocus() end
    self.showHidden:SetText(self.includeHidden and "Exclude hidden" or "Show hidden")
    self.manualCategory:SetText("Add: "..(kinds[self.manualKind] or "Resource"))
    self.scopeButton:SetText(self.scope=="local" and "This area" or "All areas")
    self.sortButton:SetText(({recent="Recent first",nearest="Nearest first",name="Name A–Z"})[self.sort] or "Recent first")
    local records,total={},0
    if ready then
        local p=a.preferences
        self.categoryButton:SetText(kinds[p.category] or "All resources")
        self.enabledButton:SetText(p.enabled and "Record gathering locations: On" or "Record gathering locations: Off")
        self.pinsButton:SetText(p.showMapPins and "World map ON" or "World map OFF")
        self.minimapButton:SetText(p.showMinimapPins~=false and "Minimap ON" or "Minimap OFF")
        if chrome then chrome.Active(self.enabledButton,p.enabled);chrome.Active(self.pinsButton,p.showMapPins);chrome.Active(self.minimapButton,p.showMinimapPins~=false) end
        self.summary:SetText(G.state.clientAllowed and ((G.state.observations or 0).." personal sites  ·  "..(G.state.catalogCount or 0).." imported sites  ·  automatic map pins") or
            "This game build is unavailable. Your saved observations are preserved.")
        local context=self.scope=="local" and G.Observations:Context() or nil
        local filter={kind=p.category,search=self.search:GetText(),includeHidden=self.includeHidden,sort=self.sort,mapID=context and context.mapID}
        if self.scope~="local" or context then records,total=G.Observations:List(filter,PAGE,self.offset) end
        if self.offset>0 and self.offset>=total then
            self.offset=math.floor(math.max(0,total-1)/PAGE)*PAGE
            if self.scope~="local" or context then records,total=G.Observations:List(filter,PAGE,self.offset) end
        end
        self.hint:SetText(total>0 and string.format("%d–%d of %d sites · select a site for details",self.offset+1,self.offset+#records,total) or
            self.scope=="local" and not context and "Your current outdoor map is unavailable. Choose All areas." or
            "No matching sites. Reset view, choose All resources, or check Data / filters.")
    else
        self.search:ClearFocus();self.summary:SetText("Saved data needs recovery. Your history is preserved.")
        self.offset=0;self.selected=nil;self.selectedID=nil;self.hint:SetText("Your saved history was left untouched.")
    end
    self.prev:SetEnabled(self.offset>0);self.next:SetEnabled(self.offset+#records<total)
    local found
    for i,element in ipairs(self.entries) do
        local record=records[i]
        if element.record and (not record or element.record.id~=record.id or element.record.sourceRevision~=record.sourceRevision) and chrome and chrome.HideTip then chrome.HideTip(element.choose) end
        element.record=record;element.choose:SetShown(record~=nil);element.hide:SetShown(record~=nil)
        element.choose:SetEnabled(writable)
        if record then
            local selected=record.id==self.selectedID;if selected then found=record end
            element.text:SetText((record.hidden and "Hidden · " or "")..record.name)
            local near=record.distance and string.format(" · ~%.0f yd",record.distance) or ""
            element.detail:SetText((record.origin=="CATALOG" and "Imported" or sources[record.quality] or "Saved").." · "..
                (kinds[record.kind] or "Resource").." · "..self:MapName(record.mapID,record)..string.format(" %.1f, %.1f",record.x*100,record.y*100)..near)
            element.hide:SetText(record.hidden and "Unhide" or "Hide");element.hide:SetEnabled(writable)
            if chrome then chrome.Active(element.choose,selected) end
        else element.text:SetText("");element.detail:SetText("") end
        self:BindEntry(element)
    end
    -- A search/page change clears selection instead of leaving an unrelated
    -- hidden selection actionable below the visible rows.
    self.selected=found;if not found then self.selectedID=nil;self.materialIndex=1 end
    local row=found and self:CurrentSelection();local ids=found and found.materialIDs or {}
    if self.materialIndex>#ids then self.materialIndex=1 end
    local item=ids[self.materialIndex]
    self.navigate:SetEnabled(writable and row~=nil)
    self.viewMap:SetEnabled(writable and row~=nil and type(MirageMapAPI)=="table" and type(MirageMapAPI.ShowUtilityRecord)=="function")
    self.inspect:SetEnabled(writable and row~=nil and item~=nil and type(MirageInsightAPI)=="table" and type(MirageInsightAPI.OpenItem)=="function")
    self.materialButton:SetEnabled(row~=nil and #ids>1)
    local materialName=item and row and row.materials and row.materials[item] and G:Label(row.materials[item].name)
    self.materialButton:SetText(item and ((materialName or ("Item #"..item))..(#ids>1 and (" · "..self.materialIndex.." / "..#ids) or "")) or "No recorded material")
    if found then
        self.selection:SetText((self.message and (self.message.."\n") or "")..(found.sourceLabel or "Personal observations").." · "..self:Age(found.lastSeen).." · "..
            tostring(found.count or 0).." visits\n"..(found.materialText and found.materialText~="" and ("Materials: "..found.materialText) or "No material sample is recorded.")..
            (found.catchSummary and found.catchSummary~="" and ("\n"..found.catchSummary) or ""))
    else self.selection:SetText(self.message or "Select a site to view its location and materials. New gathering locations are saved automatically.") end
end
function U:Export()
    if G:Combat() then G:Print("Open export after combat.");return end
    if G.Storage.readOnly then G:Print("History export is unavailable while saved data needs recovery.");return end
    if not self.exportFrame then
        local f=CreateFrame("Frame","MirageIntelGatherExportPanel",UIParent,"BackdropTemplate")
        f:SetSize(600,390);f:SetPoint("CENTER",UIParent,"CENTER")
        f:SetFrameStrata("FULLSCREEN_DIALOG");f:SetClampedToScreen(true)
        if chrome then chrome.Panel(f) else
        f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8x8",edgeFile="Interface\\Buttons\\WHITE8x8",edgeSize=1})
        f:SetBackdropColor(.055,.064,.072,.99);f:SetBackdropBorderColor(.24,.28,.3,.95) end
        local title=label(f,"Gather Mate · Copy history",18,-18,"GameFontNormalLarge")
        if chrome and chrome.Heading then chrome.Heading(f,title,18,-18,"gather") end
        label(f,"Select all (Ctrl+A), then copy (Ctrl+C).",18,-48,nil,556)
        local scroll=chrome and chrome.Scroll and chrome.Scroll(f) or CreateFrame("ScrollFrame",nil,f,"UIPanelScrollFrameTemplate")
        scroll:SetPoint("TOPLEFT",f,"TOPLEFT",18,-76)
        scroll:SetPoint("BOTTOMRIGHT",f,"BOTTOMRIGHT",-40,48)
        local edit=CreateFrame("EditBox",nil,scroll)
        edit:SetMultiLine(true);edit:SetAutoFocus(false)
        edit:SetFontObject("ChatFontNormal")
        edit:SetWidth(525)
        edit:SetHeight(250)
        edit:SetScript("OnEscapePressed",function()f:Hide()end)
        f:SetScript("OnHide",function()edit:ClearFocus()end)
        scroll:SetScrollChild(edit)
        self.exportEdit=edit;self.exportFrame=f
        self.exportPrev=button(f,"Previous",18,-353,91,function()U:ShowExportPage(U.exportOffset-100)end)
        self.exportNext=button(f,"Next",118,-353,91,function()U:ShowExportPage(U.exportOffset+100)end)
        self.exportPage=label(f,"",223,-358,nil,268)
        button(f,"Close",509,-353,72,function()f:Hide()end)
        finish(f)
        f:Hide()
    end
    if not fit(self.exportFrame) then G:Print("Not enough space to show the history export.");return end
    self.exportFrame:Show()
    self:ShowExportPage(0)
end
function U:ShowExportPage(offset)
    self.exportOffset=math.max(0,offset)
    local output,count,total=G.Observations:Export(100,self.exportOffset)
    count,total=count or 0,total or 0
    self.exportPrev:SetEnabled(self.exportOffset>0)
    self.exportNext:SetEnabled(self.exportOffset+count<total)
    self.exportPage:SetText(total>0 and ("Rows "..(self.exportOffset+1).."–"..(self.exportOffset+count).." of "..total)
        or "No observations")
    self.exportEdit:SetText(output)
    self.exportEdit:SetFocus()
    self.exportEdit:HighlightText()
end
