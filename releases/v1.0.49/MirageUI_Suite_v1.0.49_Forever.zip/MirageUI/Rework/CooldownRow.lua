local _,M=...
-- Original Mirage presentation. Native CDM widgets remain the data authority:
-- public identities select a tile; the actual native timer and charge widgets
-- retain their updater. Only permitted texture display values are mirrored.
-- Item timers use only public, finite values from the reviewed item API.
-- No cooldown arithmetic or secret scalar timer submission occurs here.
local R,S,L=M.Rework,M.Safety,M.Rework.CombatLeases
local names={"EssentialCooldownViewer","UtilityCooldownViewer","BuffIconCooldownViewer","BuffBarCooldownViewer"}
local C={id="cooldowns",module="Cooldowns",nativeRoots={},layoutIDs={["Cooldowns.row"]=true,["Cooldowns.tracked"]=true},
 roots={},surfaces={},tiles={},borrowed={},hooks=setmetatable({},{__mode="k"}),bridges=setmetatable({},{__mode="k"}),
 events={ADDON_LOADED=true,PLAYER_ENTERING_WORLD=true,PLAYER_LEAVING_WORLD=true,PLAYER_REGEN_DISABLED=true,PLAYER_REGEN_ENABLED=true,
  PLAYER_TARGET_CHANGED=true,SPELLS_CHANGED=true,SPELL_UPDATE_COOLDOWN=true,SPELL_UPDATE_CHARGES=true,SPELL_UPDATE_USES=true,
  SPELL_DATA_LOAD_RESULT=true,SPELL_UPDATE_ICON=true,ITEM_DATA_LOAD_RESULT=true,GET_ITEM_INFO_RECEIVED=true,
  BAG_UPDATE_COOLDOWN=true,BAG_UPDATE_DELAYED=true,PLAYER_EQUIPMENT_CHANGED=true,
  PLAYER_SPECIALIZATION_CHANGED=true,UNIT_AURA=true,COOLDOWN_VIEWER_DATA_LOADED=true,COOLDOWN_VIEWER_TABLE_HOTFIXED=true,
  COOLDOWN_VIEWER_SPELL_OVERRIDE_UPDATED=true,EDIT_MODE_LAYOUTS_UPDATED=true},status="NOT_INITIALIZED"}
for _,name in ipairs(names) do C.nativeRoots[name]=true;C.layoutIDs["Cooldowns."..name]=true end
R.CombatCooldowns=C;R.CooldownRow=C
local MAX=160
local auraModes={Aura=true,Debuff=true,TargetAura=true,TargetDebuff=true,ItemAura=true}
local addedModes={Debuff=true,TargetAura=true,TargetDebuff=true,Item=true,ItemAura=true}
local modeLabels={Cooldown="Ability cooldown",Recharge="Charge recharge",Aura="Player buff",Debuff="Player debuff",
 TargetAura="Target buff",TargetDebuff="Target debuff",Item="Item cooldown",ItemAura="Item buff duration"}
local handoffDelays={.25,.75,2}
local function cfg(profile) return (profile or M.profile).modules.Cooldowns end
local function chosen() return R:Qualified() and R:Selected("cooldowns") and not M.state.safe end
local function public(o,key,kind,...) return L:Public(o,key,kind,...) end
local function field(o,key) return L:Field(o,key) end
local function validID(id) return S:Number(id) and id>0 and id<=2147483647 and id%1==0 end
local function visible(frame) return S:Frame(frame,false) and public(frame,"IsShown","boolean")==true end
local function producerVisible(frame)
 -- Alpha suppression leaves this true. A native OnHide, however, stops the
 -- viewer's aura/target subscriptions, so its timer is no longer a live feed.
 return S:Frame(frame,false) and public(frame,"IsVisible","boolean")==true
end
local function settingsOpen() return visible(_G.CooldownViewerSettings) end
local function result(kind,why) return R:Result(kind,why) end
local function copy(t) local out={};for k,v in pairs(t or {}) do out[k]=v end;return out end
function C:Current(generation,profile)
 return self.active and self.generation==generation and self.profile==profile and M.profile==profile and chosen()
  and R:NativeEditState()=="CLOSED" and not self.releasing
end
function C:MarkDirty(kind)
 if kind=="catalogue" then self.catalogueDirty=true else self.dataDirty=true end
end
function C:Hook(object,method,fn)
 if not S:Frame(object,false) or type(field(object,method))~="function" or type(hooksecurefunc)~="function" then return false end
 local seen=self.hooks[object];if not seen then seen={};self.hooks[object]=seen end
 if seen[method] then return true end
 local ok=pcall(hooksecurefunc,object,method,fn)
 if ok then seen[method]=true end
 return ok
end
local function numericList(values)
 if not S:Readable(values) or type(values)~="table" then return nil end
 local out={}
 for i=1,MAX+1 do
  local value,state=S:FieldAccess(values,i)
  if state=="ABSENT" then return out end
  if state~="KNOWN" or not validID(value) or i>MAX then return nil end
  out[#out+1]=value
 end
end
function C:NativeInfo(id)
 local value,state=S:Public(C_CooldownViewer and C_CooldownViewer.GetCooldownViewerCooldownInfo,"table",id)
 if state~="KNOWN" then return nil end
 local spell=field(value,"spellID");if not validID(spell) then return nil end
 local info={cooldownID=id,spellID=spell,overrideSpellID=field(value,"overrideSpellID"),
  isKnown=field(value,"isKnown"),charges=field(value,"charges"),hasAura=field(value,"hasAura"),selfAura=field(value,"selfAura"),
  linkedSpellIDs=numericList(field(value,"linkedSpellIDs")) or {}}
 if not validID(info.overrideSpellID) then info.overrideSpellID=nil end
 return info
end
function C:ReadNativeCatalogue()
 local catalogue,ordered,seen={},{},{}
 self.observedRoots={}
 for index,name in ipairs(names) do
  local frame=_G[name]
  self.observedRoots[name]=frame or false
  if S:Frame(frame,false) then
   local ids=public(frame,"GetCooldownIDs","table")
   ids=numericList(ids)
   if not ids then ids=numericList(S:Public(C_CooldownViewer and C_CooldownViewer.GetCooldownViewerCategorySet,"table",index-1,false)) end
   for _,id in ipairs(ids or {}) do
    local info=self:NativeInfo(id)
    if info then
     info.viewer=name;catalogue[id]=info
     if index<=2 and info.isKnown~=false and not seen[info.spellID] then
      ordered[#ordered+1]={id=info.spellID,mode="Cooldown"};seen[info.spellID]=true
     end
    end
   end
   for _,method in ipairs({"RefreshLayout","OnCooldownDataChanged","OnAcquireItemFrame","RefreshData"}) do
    self:Hook(frame,method,function() if self.active then self.catalogueDirty=true end end)
   end
   for _,method in ipairs({"Show","Hide","SetShown"}) do
    self:Hook(frame,method,function() self:SourceVisibilityChanged(frame) end)
   end
  end
 end
 return catalogue,ordered
end
function C:NativeAssignments()
 local _,ordered=self:ReadNativeCatalogue()
 return ordered
end
function C:RequestSpellMetadata(id)
 if not validID(id) then return end
 if self.spellLoadProfile~=M.profile then self.spellLoads={};self.spellLoadProfile=M.profile end
 if self.spellLoads[id] then return end
 self.spellLoads[id]="REQUESTED"
 local api=C_Spell and C_Spell.RequestLoadSpellData
 if type(api)~="function" then self.spellLoads[id]="UNSUPPORTED";return end
 -- The event may be delivered synchronously by this request. Record demand
 -- first, and consume only its public spell ID/success flag on completion.
 if not pcall(api,id) then self.spellLoads[id]="REQUEST_REJECTED" end
end
function C:RequestItemMetadata(id)
 if not validID(id) then return end
 if self.itemLoadProfile~=M.profile then self.itemLoads={};self.itemLoadProfile=M.profile end
 if self.itemLoads[id] then return end
 self.itemLoads[id]="REQUESTED"
 local api=C_Item and C_Item.RequestLoadItemDataByID
 if type(api)~="function" then self.itemLoads[id]="UNSUPPORTED";return end
 if not pcall(api,id) then self.itemLoads[id]="REQUEST_REJECTED" end
end
local function matches(info,id)
 if info.spellID==id or info.overrideSpellID==id then return true end
 for _,linked in ipairs(info.linkedSpellIDs) do if linked==id then return true end end
 return false
end
function C:Metadata(entry,catalogue)
 if entry.mode=="Item" or entry.mode=="ItemAura" then
  local name=S:Public(C_Item and C_Item.GetItemNameByID,"string",entry.id)
  local icon=S:Public(C_Item and C_Item.GetItemIconByID,"number",entry.id)
  if not name or not icon then
   self:RequestItemMetadata(entry.id)
   -- Loading callbacks may complete inside the request. Re-read before the
   -- rebuild consumes its dirty marker so synchronous completion is not lost.
   name=S:Public(C_Item and C_Item.GetItemNameByID,"string",entry.id)
   icon=S:Public(C_Item and C_Item.GetItemIconByID,"number",entry.id)
  end
  local meta={id=entry.id,itemID=entry.id,mode=entry.mode,name=name or ("Item "..entry.id),icon=icon,learned=true,
   ready=name~=nil and icon~=nil,status=name and icon and "METADATA_READY" or "ITEM_METADATA_UNAVAILABLE"}
  if entry.mode=="ItemAura" then
   meta.spellID=entry.auraID
   local aura,status=S:Public(C_Spell and C_Spell.GetSpellInfo,"table",entry.auraID)
   if status~="KNOWN" then
    self:RequestSpellMetadata(entry.auraID)
    aura,status=S:Public(C_Spell and C_Spell.GetSpellInfo,"table",entry.auraID)
   end
   if status=="KNOWN" then meta.auraName=field(aura,"name") end
   if not S:Text(meta.auraName) then meta.ready=false;meta.status="ITEM_BUFF_METADATA_UNAVAILABLE" end
  end
  return meta
 end
 local native
 for _,info in pairs(catalogue) do if not addedModes[entry.mode] and matches(info,entry.id) then
  -- Prefer the ability viewer over a duplicate buff display for ability timers.
  local aura=entry.mode=="Aura"
  if not native or aura and info.viewer=="BuffIconCooldownViewer" or not aura and info.viewer=="EssentialCooldownViewer" then native=info end
 end end
 local id=native and native.overrideSpellID or entry.id
 if not native and not auraModes[entry.mode] then
  local override=S:Public(C_Spell and C_Spell.GetOverrideSpell,"number",id)
  if validID(override) then id=override end
 end
 local info,status=S:Public(C_Spell and C_Spell.GetSpellInfo,"table",id)
 if status~="KNOWN" then
  self:RequestSpellMetadata(id)
  info,status=S:Public(C_Spell and C_Spell.GetSpellInfo,"table",id)
  if status~="KNOWN" then return {id=entry.id,spellID=id,mode=entry.mode,ready=false,status="METADATA_UNAVAILABLE",native=native} end
 end
 local name,icon=field(info,"name"),field(info,"iconID")
 local known=native and native.isKnown
 if type(known)~="boolean" then known=S:Public(C_SpellBook and C_SpellBook.IsSpellKnown,"boolean",id) end
 -- A deliberately selected aura can be a proc or an external buff and need
 -- not occur in the learned spellbook. Its public metadata names the slot.
 if auraModes[entry.mode] then known=true end
 return {id=entry.id,spellID=id,mode=entry.mode,name=S:Text(name) and name or ("Spell "..entry.id),
  icon=(S:Number(icon) or S:Text(icon)) and icon or nil,native=native,learned=known,
  ready=known~=nil and (S:Number(icon) or S:Text(icon)),status=known==false and "NOT_LEARNED" or "METADATA_READY"}
end
function C:Create()
 if self.frame then return true end
 if S:InCombat() then return false end
 local f=CreateFrame("Frame",nil,UIParent);f:Hide();S:Passive(f);f:SetFrameStrata("MEDIUM")
 local content=CreateFrame("Frame",nil,f);content:SetPoint("CENTER",f,"CENTER",0,0);S:Passive(content)
 local secondary=CreateFrame("Frame",nil,f);secondary:Hide();S:Passive(secondary)
 local empty=CreateFrame("Frame",nil,secondary);S:Passive(empty)
 empty.fill=empty:CreateTexture(nil,"BACKGROUND");empty.fill:SetAllPoints(empty);empty.fill:SetColorTexture(.035,.035,.035,.85)
 empty.edges={}
 for i=1,4 do local edge=empty:CreateTexture(nil,"BORDER");edge:SetColorTexture(.26,.26,.26,1);empty.edges[i]=edge end
 empty.edges[1]:SetPoint("TOPLEFT",empty,"TOPLEFT",0,0);empty.edges[1]:SetPoint("TOPRIGHT",empty,"TOPRIGHT",0,0);empty.edges[1]:SetSize(1,1)
 empty.edges[2]:SetPoint("BOTTOMLEFT",empty,"BOTTOMLEFT",0,0);empty.edges[2]:SetPoint("BOTTOMRIGHT",empty,"BOTTOMRIGHT",0,0);empty.edges[2]:SetSize(1,1)
 empty.edges[3]:SetPoint("TOPLEFT",empty,"TOPLEFT",0,0);empty.edges[3]:SetPoint("BOTTOMLEFT",empty,"BOTTOMLEFT",0,0);empty.edges[3]:SetSize(1,1)
 empty.edges[4]:SetPoint("TOPRIGHT",empty,"TOPRIGHT",0,0);empty.edges[4]:SetPoint("BOTTOMRIGHT",empty,"BOTTOMRIGHT",0,0);empty.edges[4]:SetSize(1,1)
 empty:SetPoint("CENTER",secondary,"CENTER",0,0);empty:Hide()
 self.frame,self.content,self.secondaryContent,self.secondaryEmpty=f,content,secondary,empty
 if M.TrackRoot then
  local cleanup,sourceDebt=self.CanCleanupRoots,self.HasSourceDebt
  local borrowed,roots=self.borrowed,self.roots
  self.cleanupGuard=function()
   if M.Rework~=R or R.CooldownRow~=self or R.CombatCooldowns~=self or self.frame~=f
    or self.CanCleanupRoots~=cleanup or self.HasSourceDebt~=sourceDebt or self.borrowed~=borrowed or self.roots~=roots then
    return false,"OWNERSHIP_CHANGED"
   end
   return cleanup(self)
  end
  M:TrackRoot("Cooldowns",f,true,self.cleanupGuard)
 end
 self.surface={id="Cooldowns.row",label="Tracked cooldown row",module="Cooldowns",frame=f,security="OWNED_VISUAL",groups={combat=true},
  fallback="HIDDEN",editable=true,minWidth=24,minHeight=16,reworkProvider=self,layout={x=0,y=-.25,width=50,height=50,scale=1}}
 self.surface.Intent=function(_,snapshot) return self:Intent(snapshot) end
 self.surface.Apply=function(_,alpha,state,options) return self:ApplyVisibility(state,alpha,options) end
 M.CVE:Register(self.surface);self.surfaces[self.surface.id]=self.surface
 return true
end
function C:ApplyVisibility(state,alpha,options)
 options=options or {}
 local frame=self.frame
 if not S:Frame(frame,true) then return "PRESERVED" end
 local effects=M.Effects
 if self.handoffVisible then
  -- Borrowed native widgets need a visible handback until their original
  -- owners have actually accepted them. This is an access floor, not a cue.
  if effects and effects.CancelTransition then effects:CancelTransition(self,frame,false) end
  frame:SetAlpha(1);frame:Show();return "NATIVE_HANDOFF_PENDING"
 end
 local generation,profile=self.generation,M.profile
 local function current()
  return self.frame==frame and self:Current(generation,profile) and self.presentationReady
 end
 local available=current() and not settingsOpen() and not M.state.keybindWorkspace and not M.state.trackerWorkspace
 local show=state~="HIDDEN" and available
 if not available then
  if effects and effects.CancelTransition then effects:CancelTransition(self,frame,false) end
  frame:Hide();return "HIDDEN"
 end
 local opacity=S:Number(alpha) and math.max(0,math.min(1,alpha)) or 1
 if effects and effects.Transition then
  local accepted=effects:Transition(self,frame,show,{alpha=opacity,ceiling=cfg().alpha or 1,guard=current,
   recipient="COMBAT",reason=options.reason or self.surface and self.surface.reason,urgent=options.urgent,
   duration=options.immediate and 0 or nil})
  if accepted then return show and "VISIBLE" or "HIDDEN" end
 end
 -- A client without animation capability still retains the resolved CVE
 -- decision. Never independently infer visibility while applying a result.
 frame:SetAlpha(opacity);frame:SetShown(show)
 return show and "VISIBLE" or "HIDDEN"
end
function C:Intent(snapshot)
 if not self.presentationReady or not self.active or settingsOpen() or M.state.keybindWorkspace or M.state.trackerWorkspace then return "HIDDEN","COOLDOWN_ROW_UNAVAILABLE",0 end
 if M.state.edit or S:Now()<(M.state.revealUntil or 0) then return "VISIBLE","COOLDOWN_ROW_INSPECTION",0 end
 local c=cfg()
 if c.rowVisibility==1 then return "VISIBLE","COOLDOWN_ROW_ALWAYS",0 end
 local groups=M.PresentationGroups
 if c.rowVisibility==3 and groups and groups:Enabled() then
  local show,reason=groups:Demand("COMBAT",snapshot)
  if show==nil then return nil,"COOLDOWN_ROW_CONTEXT_UNKNOWN" end
  return show and "VISIBLE" or "HIDDEN",reason or "GROUP_COMBAT",1
 end
 -- Explicit combat-only remains a useful independent preference. The
 -- default contextual row participates in combat, target, focus and observed
 -- hostile-targeting demand exactly like the other combat displays.
 local combat=S:Public(InCombatLockdown,"boolean")
 local target=c.rowVisibility==3 and S:Public(UnitExists,"boolean","target")
 local show=combat==true or c.rowVisibility==3 and target==true
 return show and "VISIBLE" or "HIDDEN",show and "COOLDOWN_ROW_COMBAT_OR_TARGET" or "COOLDOWN_ROW_QUIET",0
end
function C:RefreshVisibility()
 if not self.frame or not self.surface then return end
 local state,reason=self:Intent()
 local alpha=cfg().alpha or 1
 local handoff=self.handoffVisible==true
 if self.visibilityProfile==M.profile and self.visibilityGeneration==self.generation
  and self.visibilityIntent==state and self.visibilityReason==reason and self.visibilityAlpha==alpha
  and self.visibilityHandoff==handoff then return end
 self.visibilityProfile=M.profile;self.visibilityGeneration=self.generation
 self.visibilityIntent=state;self.visibilityReason=reason;self.visibilityAlpha=alpha;self.visibilityHandoff=handoff
 M.state.forceEvaluate=true
 -- Provider events renew a decision; they do not bypass workspace, Alt-Z,
 -- cinematic or module policy by directly showing the cooldown container.
 if M.CVE and type(M.CVE.Tick)=="function" then M.CVE:Tick(true)
 else self:ApplyVisibility(state,alpha) end
end
function C:CreateTile(index)
 local tile=self.tiles[index];if tile then return tile end
 if S:InCombat() then return nil,"SETUP_COMBAT_DEFERRED" end
 -- Construction is resumed on an explicit retry. Never publish a half-built
 -- tile into the live roster or allocate another orphan after a rejected API.
 self.buildTiles=self.buildTiles or {}
 tile=self.buildTiles[index] or {index=index};self.buildTiles[index]=tile
 local generation,profile=self.generation,M.profile
 local function current() return self:Current(generation,profile) and not S:InCombat() end
 local function step(stage,fn)
  self.setupStage=stage;self.setupSlot=index
  if not current() then return false,"ROW_SETUP_SUPERSEDED" end
  local ok,value=pcall(fn)
  if not current() then return false,"ROW_SETUP_SUPERSEDED" end
  if not ok or value==false then return false,stage.."_UNAVAILABLE" end
  return true
 end
 local ok,why=step("TILE_FRAME",function()
  tile.frame=tile.frame or CreateFrame("Frame",nil,self.content)
  tile.frame:Hide();S:Passive(tile.frame)
 end)
 if ok then ok,why=step("TILE_ART",function()
  tile.backdrop=tile.backdrop or tile.frame:CreateTexture(nil,"BACKGROUND")
  tile.backdrop:SetAllPoints(tile.frame);tile.backdrop:SetColorTexture(.025,.025,.025,1)
  tile.icon=tile.icon or tile.frame:CreateTexture(nil,"ARTWORK")
  tile.groupTop=tile.groupTop or tile.frame:CreateTexture(nil,"OVERLAY")
  tile.groupBottom=tile.groupBottom or tile.frame:CreateTexture(nil,"OVERLAY")
  tile.groupTop:Hide();tile.groupBottom:Hide()
  tile.glow=tile.glow or tile.frame:CreateTexture(nil,"OVERLAY")
  tile.glow:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
  if tile.glow.SetBlendMode then tile.glow:SetBlendMode("ADD") end
  local highlight=(M.Theme and M.Theme.secondary) or M.VisualTokens and M.VisualTokens.options and M.VisualTokens.options.secondary or {.96,.79,.36,1}
  tile.glow:SetVertexColor(highlight[1],highlight[2],highlight[3],.65)
  tile.glow:SetPoint("TOPLEFT",tile.frame,"TOPLEFT",-8,8)
  tile.glow:SetPoint("BOTTOMRIGHT",tile.frame,"BOTTOMRIGHT",8,-8);tile.glow:Hide()
 end) end
 if ok then ok,why=step("TILE_TIMER",function()
  tile.timer=tile.timer or CreateFrame("Cooldown",nil,tile.frame,"CooldownFrameTemplate")
  S:Passive(tile.timer)
  -- This accessor is documented and creates/returns the actual countdown
  -- string. GetRegions enumeration is only a compatibility fallback.
  tile.durationFont=public(tile.timer,"GetCountdownFontString")
  if not tile.durationFont then
   local read,regions=pcall(function() return {tile.timer:GetRegions()} end)
   if read then for _,region in ipairs(regions) do
    if public(region,"GetObjectType","string")=="FontString" then tile.durationFont=region;break end
   end end
  end
 end) end
 if ok then ok,why=step("TILE_COUNT_FONT",function()
  tile.countFrame=tile.countFrame or CreateFrame("Frame",nil,tile.frame)
  S:Passive(tile.countFrame);tile.countFrame:SetAllPoints(tile.frame)
  tile.count=tile.count or tile.countFrame:CreateFontString(nil,"OVERLAY","GameFontNormal")
  if not current() then return false end
  local set=tile.count:SetFont(M.Visual.font or STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",cfg().chargeSize or 11,"OUTLINE")
  if not current() then return false end
  local font,size=tile.count:GetFont()
  if not current() or set==false or not (S:Text(font) or S:Number(font)) or not L:GeometryEqual(size,cfg().chargeSize or 11) then return false end
  tile.count:SetPoint("BOTTOMRIGHT",tile.frame,"BOTTOMRIGHT",-2,2)
  if not current() then return false end
  -- A new untemplated native FontString has no font. Establish and read back
  -- the font before even empty SetText; beta51 did those operations reversed.
  tile.count:SetText("")
 end) end
 if ok then ok,why=step("TILE_HOLDER",function()
  tile.nativeHolder=tile.nativeHolder or CreateFrame("Frame",nil,tile.frame)
  tile.nativeHolder:SetAllPoints(tile.frame);S:Passive(tile.nativeHolder)
 end) end
 if ok then ok,why=step("TILE_INTERACTION",function()
  if tile.frame.SetMouseClickEnabled and tile.frame.SetMouseMotionEnabled then tile.frame:SetMouseClickEnabled(false);tile.frame:SetMouseMotionEnabled(true) end
  tile.frame:SetScript("OnEnter",function() self:Tooltip(tile) end)
  tile.frame:SetScript("OnLeave",function() self:HideTooltip(tile) end)
 end) end
 if not ok then
  if self.generation==generation and self.profile==profile and tile.frame and S:Frame(tile.frame,true) then pcall(tile.frame.Hide,tile.frame) end
  return nil,why
 end
 self.tiles[index]=tile;self.buildTiles[index]=nil
 return tile
end
function C:HideTooltip(tile)
 local tip=GameTooltip
 if S:Frame(tip,false) and self.tooltipTile and (not tile or tile==self.tooltipTile) and public(tip,"GetOwner")==self.tooltipTile.frame then pcall(tip.Hide,tip) end
 self.tooltipTile=nil
end
function C:Tooltip(tile)
 if not cfg().rowTooltips or not self.presentationReady or not visible(self.frame) or not tile.meta or not S:Frame(GameTooltip,false) then return end
 local generation,profile=self.generation,M.profile
 self:HideTooltip();self.tooltipTile=tile
 if not self:Current(generation,profile) then return end
 local ok=pcall(function()
  GameTooltip:SetOwner(tile.frame,"ANCHOR_TOP")
  if tile.meta.itemID then GameTooltip:SetItemByID(tile.meta.itemID) else GameTooltip:SetSpellByID(tile.meta.spellID) end
  if type(GameTooltip.AddLine)=="function" then
   GameTooltip:AddLine(modeLabels[tile.meta.mode] or "Tracked cooldown",.84,.72,.45)
   if tile.meta.mode=="ItemAura" then GameTooltip:AddLine("Buff: "..(tile.meta.auraName or ("Spell "..tile.meta.spellID)),.85,.85,.85) end
   if tile.sourceWarning then GameTooltip:AddLine("Timer unavailable. Check the item or aura selection in Customize UI > Cooldown Manager > Configure Tracker; the game may restrict this reading.",1,.72,.35,true) end
  end
  GameTooltip:Show()
 end)
 if not ok or not self:Current(generation,profile) then self:HideTooltip(tile) end
end
-- Only public geometry is journalled. These snapshots never contain timer
-- values, charge counts, or aura identities.
local function points(frame)
 local n=public(frame,"GetNumPoints","number")
 if not n or n<0 or n>8 then return nil end
 local out={}
 for i=1,n do
  local ok,p,r,rp,x,y=pcall(frame.GetPoint,frame,i)
  if not ok or not S:Text(p) or not S:Readable(r) or not S:Text(rp) or not S:Number(x) or not S:Number(y) then return nil end
  out[i]={p,r,rp,x,y}
 end
 return out
end
local function samePoints(a,b)
 if not a or not b or #a~=#b then return false end
 for i=1,#a do for k=1,5 do
  if k>=4 then if not L:GeometryEqual(a[i][k],b[i][k]) then return false end
  elseif a[i][k]~=b[i][k] then return false end
 end end
 return true
end
local function geometryText(value)
 return S:Number(value) and string.format("%.9f",value) or "UNAVAILABLE"
end
function C:AccentPlan(entry,groups,previous,following,size,gap)
 if not entry or not entry.group then return nil end
 local group
 for _,candidate in ipairs(groups or {}) do if candidate.id==entry.group then group=candidate;break end end
 local bar=entry.bar or "Primary"
 if not group or group.bar~=bar then return nil end
 local function same(other) return other and other.group==entry.group and (other.bar or "Primary")==bar end
 local left=same(previous) and gap/2 or 0;local right=same(following) and gap/2 or 0
 return {r=group.r,g=group.g,b=group.b,alpha=group.alpha,left=left,right=right,width=size+left+right,top=4,bottom=1}
end
function C:PaintGroupAccents(tile,plan,writer)
 if not tile.groupTop or not tile.groupBottom then return true end
 local function send(object,method,...)
  if writer then return writer(object,method,...) end
  return object[method](object,...)~=false
 end
 if not send(tile.groupTop,"Hide") or not send(tile.groupBottom,"Hide") then return false end
 if not plan then return true end
 for _,texture in ipairs({tile.groupTop,tile.groupBottom}) do
  if not send(texture,"ClearAllPoints") or not send(texture,"SetColorTexture",plan.r,plan.g,plan.b,plan.alpha) then return false end
 end
 return send(tile.groupTop,"SetPoint","BOTTOMLEFT",tile.frame,"TOPLEFT",-plan.left,2) and send(tile.groupTop,"SetSize",plan.width,plan.top)
  and send(tile.groupBottom,"SetPoint","TOPLEFT",tile.frame,"BOTTOMLEFT",-plan.left,-2) and send(tile.groupBottom,"SetSize",plan.width,plan.bottom)
  and send(tile.groupTop,"Show") and send(tile.groupBottom,"Show")
end
function C:DisplayMetrics(size,gap)
 -- Group artwork extends 3 units below a slot and 6 above it. Sixteen
 -- units between icon edges leave 7 clear units even with both accents.
 -- Both runtime rows share their scale, so that clearance scales together.
 return {secondarySize=size*.9,secondaryGap=gap*.9,sectionGap=16}
end
function C:Geometry(profile,count)
 profile=profile or M.profile;local c=cfg(profile)
 local w,h,uiScale=M.Layout:Screen();if not w then return nil,"VIEWPORT_PENDING" end
 local pixels=1
 local viewport=M.Managed and M.Managed.viewportStable
 if viewport and S:Number(uiScale) and uiScale>0 and L:GeometryEqual(viewport.width,w)
  and L:GeometryEqual(viewport.height,h) and L:GeometryEqual(viewport.scale,uiScale)
  and S:Number(viewport.physicalHeight) and viewport.physicalHeight>0 then
  pixels=768/viewport.physicalHeight/uiScale
 end
 local primary,secondary=0,0
 if count~=nil then primary=count;secondary=self.secondaryCount or 0
 elseif profile==M.profile and self.primaryCount~=nil then primary=self.primaryCount;secondary=self.secondaryCount or 0
 elseif c.rowCustom or #(c.spells or {})>0 then
  for _,entry in ipairs(c.spells or {}) do if entry.bar=="Secondary" then secondary=secondary+1 else primary=primary+1 end end
 else primary=self.count or 1 end
 count=primary
 local size,gap=c.iconSize or 50,c.gap or 3
 local baseWidth=math.max(1,count)*size+math.max(0,count-1)*gap
 -- Match the action interface's 40px / 36px primary-secondary icon tiers.
 local rowMetrics=self:DisplayMetrics(size,gap)
 local secondarySize,secondaryGap,sectionGap=rowMetrics.secondarySize,rowMetrics.secondaryGap,rowMetrics.sectionGap
 local secondaryWidth=math.max(1,secondary)*secondarySize+math.max(0,secondary-1)*secondaryGap
 local grouped=false;for _,entry in ipairs(c.spells or {}) do if entry.group then grouped=true;break end end
 local outset=grouped and 6 or 0
 local envelopeWidth=c.rowSecondary and math.max(baseWidth,secondaryWidth) or baseWidth
 -- A symmetric enclosing rectangle keeps the primary anchor stable while
 -- including all secondary pixels. Its upper spare space is intentional.
 local envelopeHeight=c.rowSecondary and size+2*(sectionGap+secondarySize+outset) or size+2*outset
 local authored=profile.layouts and profile.layouts["Cooldowns.row"]
 local scale=authored and authored.scale or 1
 local contentScale=(c.rowScale or 100)/100*pixels
 contentScale=math.min(contentScale,(w-16*pixels)/(envelopeWidth*scale),(h-16*pixels)/(envelopeHeight*scale))
 local width,height=envelopeWidth*contentScale,envelopeHeight*contentScale
 local primaryHeight=size*contentScale
 local x,y=0,-.25
 if authored then x,y=authored.x,authored.y
 elseif c.rowFollowHUD~=false then
  local hud=profile.modules.UnderCharacterHUD
  if hud and M.HUDView then
   local _,hudHeight=M.HUDView:Geometry(hud)
   local hudScale=(hud.hudScale or 100)/100
   local pitch=M.HUDView:RowPitch(hud)
   local order=hud.layoutOrder==2 and {"cast","health","resource"} or {"health","resource","cast"}
   local last=0
   for i,key in ipairs(order) do if hud[key] then
    local endAt=(i-1)*pitch+(hud[key.."Height"] or 0)
    -- HUDView places the cast name/state in its bottom footer in both row
    -- orders. Reserve that configured footer even between casts, keeping the
    -- cooldown row stationary and clear of text when a cast starts.
    if key=="cast" then endAt=math.max(endAt,hudHeight) end
    last=math.max(last,endAt)
   end end
   x=(hud.x or 0)/w;y=((hud.y or 0)+hudHeight*hudScale/2-last*hudScale-6*pixels-primaryHeight*scale/2)/h
  end
 end
 local layout={x=x or 0,y=y or 0,width=width,height=height,scale=scale,anchorTo=authored and authored.anchorTo}
 local limitX=math.min(.48,math.max(0,.5-(width*scale/2+8*pixels)/w))
 local limitY=math.min(.48,math.max(0,.5-(height*scale/2+8*pixels)/h))
 layout.x=math.max(-limitX,math.min(limitX,layout.x));layout.y=math.max(-limitY,math.min(limitY,layout.y))
 return layout,contentScale,baseWidth,size,gap,w,h,{primary=primary,secondary=secondary,secondarySize=secondarySize,secondaryGap=secondaryGap,secondaryWidth=secondaryWidth,sectionGap=sectionGap,secondaryEnabled=c.rowSecondary==true}
end
function C:ResolveLayout(_,profile) return self:Geometry(profile) end
function C:ApplyLayout(surface)
 self.setupStage="ROW_LAYOUT"
 if surface~=self.surface or not self.active or not chosen() then return false,"NOT_SELECTED" end
 if S:InCombat() then surface.layoutPending=true;return false,"LAYOUT_COMBAT_DEFERRED" end
 if type(self.count)~="number" then surface.layoutPending=true;return false,"ROW_TILES_PENDING" end
 for i=1,self.count do if not self.tiles[i] then surface.layoutPending=true;return false,"ROW_TILES_PENDING" end end
 local l,contentScale,baseWidth,size,gap,w,h,plan=self:Geometry()
 if not l then surface.layoutPending=true;return false,contentScale end
 local generation,profile=self.generation,M.profile
 local frame,content,tiles,count,c=self.frame,self.content,self.tiles,self.count,cfg()
 local candidates={};for i=1,count do candidates[i]=tiles[i] end
 local tileIndex,retired
 local function current()
  if retired then return false end
  local owned=self:Current(generation,profile) and not S:InCombat() and self.surface==surface
   and self.frame==frame and self.content==content and self.tiles==tiles and self.count==count and cfg()==c
   and (not tileIndex or tiles[tileIndex]==candidates[tileIndex])
  if not owned then retired=true end
  return owned
 end
 local function write(object,method,...)
  if not current() or not S:Frame(object,false) then return false end
  local fn=field(object,method);if type(fn)~="function" or not current() then return false end
  local ok,value=pcall(fn,object,...)
  if current() then self.layoutWriteAttempts=(self.layoutWriteAttempts or 0)+1 end
  return ok and value~=false and current()
 end
 if not current() then return false,"ROW_LAYOUT_SUPERSEDED" end
 self.layoutPasses=(self.layoutPasses or 0)+1
 self.layoutReadback="PENDING";self.layoutReadbackProperty=nil;self.layoutExpected=nil;self.layoutObserved=nil;self.layoutCalculated=nil
 local relative=l.anchorTo and M.surfaces[l.anchorTo] and M.surfaces[l.anchorTo].frame or UIParent
 local rootPoints={{"CENTER",relative,"CENTER",l.x*w/l.scale,l.y*h/l.scale}}
 if not write(frame,"SetSize",l.width,l.height) or not write(frame,"SetScale",l.scale)
  or not write(frame,"ClearAllPoints") or not write(frame,"SetPoint",unpack(rootPoints[1]))
  or not write(content,"SetSize",baseWidth,size) or not write(content,"SetScale",contentScale)
  or not write(content,"SetAlpha",(c.rowOpacity or 100)/100) then
  if not current() then return false,"ROW_LAYOUT_SUPERSEDED" end
  surface.layoutPending=true;return false,"ROW_LAYOUT_PENDING"
 end
 local secondary=self.secondaryContent
 if secondary then
  if not write(secondary,"SetSize",plan.secondaryWidth,plan.secondarySize) or not write(secondary,"SetScale",contentScale)
   or not write(secondary,"ClearAllPoints") or not write(secondary,"SetPoint","TOP",content,"BOTTOM",0,-plan.sectionGap)
   or not write(secondary,"SetAlpha",(c.rowOpacity or 100)/100) or not write(secondary,"SetShown",plan.secondaryEnabled)
   or not write(self.secondaryEmpty,"SetSize",plan.secondarySize,plan.secondarySize)
   or not write(self.secondaryEmpty,"SetShown",plan.secondaryEnabled and plan.secondary==0) then
   if not current() then return false,"ROW_LAYOUT_SUPERSEDED" end
   surface.layoutPending=true;return false,"SECONDARY_LAYOUT_PENDING"
  end
 end
 local barSlots={Primary={},Secondary={}}
 for i=1,count do
  local tile=candidates[i];local bar=tile.meta and tile.meta.bar or "Primary"
  barSlots[bar][#barSlots[bar]+1]=tile
 end
 local positions={}
 for bar,slots in pairs(barSlots) do for index,tile in ipairs(slots) do positions[tile]={bar=bar,index=index,previous=slots[index-1],following=slots[index+1]} end end
 for i=1,count do
  tileIndex=i
  local tile=candidates[i];local border=c.rowBorder or 1;local zoom=(c.rowZoom or 8)/100
  local position=positions[tile];local secondaryTile=position.bar=="Secondary"
  local tileSize=secondaryTile and plan.secondarySize or size;local tileGap=secondaryTile and plan.secondaryGap or gap
  local tileParent=secondaryTile and secondary or content
  tile.layoutParent=tileParent;tile.layoutSize=tileSize;tile.layoutX=(position.index-1)*(tileSize+tileGap)
  if tile.meta and tile.meta.highlight and tile.meta.highlight~="None" then border=math.max(1,border) end
  if tiles[i]~=tile then return false,"ROW_LAYOUT_SUPERSEDED" end
  if not write(tile.frame,"SetParent",tileParent) or not write(tile.frame,"SetSize",tileSize,tileSize) or not write(tile.frame,"ClearAllPoints")
   or not write(tile.frame,"SetPoint","LEFT",tileParent,"LEFT",tile.layoutX,0)
   or not write(tile.icon,"ClearAllPoints") or not write(tile.icon,"SetPoint","TOPLEFT",tile.frame,"TOPLEFT",border,-border)
   or not write(tile.icon,"SetPoint","BOTTOMRIGHT",tile.frame,"BOTTOMRIGHT",-border,border)
   or not write(tile.icon,"SetTexCoord",zoom,1-zoom,zoom,1-zoom)
   or not write(tile.timer,"SetAllPoints",tile.icon)
   or not write(tile.count,"SetFont",M.Visual.font or "Fonts\\FRIZQT__.TTF",c.chargeSize or 11,"OUTLINE") then
   if not current() then return false,"ROW_LAYOUT_SUPERSEDED" end
   surface.layoutPending=true;return false,"ROW_LAYOUT_PENDING"
  end
  if tile.durationFont and not write(tile.durationFont,"SetFont",M.Visual.font or "Fonts\\FRIZQT__.TTF",c.durationSize or 12,"OUTLINE") then
   if not current() then return false,"ROW_LAYOUT_SUPERSEDED" end
   surface.layoutPending=true;return false,"ROW_LAYOUT_PENDING"
  end
  if type(tile.timer.SetHideCountdownNumbers)=="function" then write(tile.timer,"SetHideCountdownNumbers",c.showNumbers==false) end
  local accent=self:AccentPlan(tile.meta,c.groups,position.previous and position.previous.meta,position.following and position.following.meta,tileSize,tileGap)
  if not current() then return false,"ROW_LAYOUT_SUPERSEDED" end
  local painted,complete=pcall(self.PaintGroupAccents,self,tile,accent,write)
  if not current() then return false,"ROW_LAYOUT_SUPERSEDED" end
  if not painted or complete==false then surface.layoutPending=true;return false,"ROW_GROUP_LAYOUT_PENDING" end
 end
 tileIndex=nil
 if not current() then return false,"ROW_LAYOUT_SUPERSEDED" end
 local function failed(property,expected,observed,calculated)
  if current() then
   self.layoutReadback="UNCONFIRMED";self.layoutReadbackProperty=property
   self.layoutExpected=expected;self.layoutObserved=observed;self.layoutCalculated=calculated
  end
  return false
 end
 local function number(object,property,method,expected,explicit)
  local value,state
  if explicit==nil then value,state=public(object,method,"number") else value,state=public(object,method,"number",explicit) end
  if not current() then return false end
  if state=="KNOWN" and L:GeometryEqual(value,expected) then return true end
  local calculated=explicit and public(object,method,"number") or nil
  return failed(property,geometryText(expected),geometryText(value),geometryText(calculated))
 end
 local function parent(object,property,expected)
  local value,state=public(object,"GetParent")
  if not current() then return false end
  if state=="KNOWN" and value==expected then return true end
  return failed(property,"OWNED_PARENT",state=="KNOWN" and "DIFFERENT_PARENT" or "UNAVAILABLE")
 end
 local function anchors(object,property,expected)
  local actual=points(object)
  if not current() then return false end
  if samePoints(actual,expected) then return true end
  return failed(property,"OWNED_ANCHORS",actual and "DIFFERENT_ANCHORS" or "UNAVAILABLE")
 end
 -- SetSize authors explicit dimensions. The default getters instead expose
 -- the computed rectangle, whose independently rounded edges (or an invalid
 -- first-frame rectangle) are not a setter receipt. The native ignoreRect
 -- argument supplies that receipt. Verify its scale, ancestry and complete
 -- anchor vector separately, without broadening numeric tolerances.
 local ready=number(frame,"ROW_WIDTH_EXPLICIT","GetWidth",l.width,true)
  and number(frame,"ROW_HEIGHT_EXPLICIT","GetHeight",l.height,true)
  and number(frame,"ROW_SCALE","GetScale",l.scale)
  and parent(frame,"ROW_PARENT",UIParent) and anchors(frame,"ROW_ANCHORS",rootPoints)
  and number(content,"CONTENT_WIDTH_EXPLICIT","GetWidth",baseWidth,true)
  and number(content,"CONTENT_HEIGHT_EXPLICIT","GetHeight",size,true)
  and number(content,"CONTENT_SCALE","GetScale",contentScale)
  and parent(content,"CONTENT_PARENT",frame) and anchors(content,"CONTENT_ANCHORS",{{"CENTER",frame,"CENTER",0,0}})
 if ready and secondary then
  ready=number(secondary,"SECONDARY_WIDTH_EXPLICIT","GetWidth",plan.secondaryWidth,true)
   and number(secondary,"SECONDARY_HEIGHT_EXPLICIT","GetHeight",plan.secondarySize,true)
   and number(secondary,"SECONDARY_SCALE","GetScale",contentScale)
   and parent(secondary,"SECONDARY_PARENT",frame)
   and anchors(secondary,"SECONDARY_ANCHORS",{{"TOP",content,"BOTTOM",0,-plan.sectionGap}})
   and number(self.secondaryEmpty,"SECONDARY_EMPTY_WIDTH_EXPLICIT","GetWidth",plan.secondarySize,true)
   and number(self.secondaryEmpty,"SECONDARY_EMPTY_HEIGHT_EXPLICIT","GetHeight",plan.secondarySize,true)
   and parent(self.secondaryEmpty,"SECONDARY_EMPTY_PARENT",secondary)
   and anchors(self.secondaryEmpty,"SECONDARY_EMPTY_ANCHORS",{{"CENTER",secondary,"CENTER",0,0}})
 end
 for i=1,count do
  if not ready then break end
  tileIndex=i
  local tile=candidates[i]
  if tiles[i]~=tile then return false,"ROW_LAYOUT_SUPERSEDED" end
  local label="TILE_"..i
  ready=number(tile.frame,label.."_WIDTH_EXPLICIT","GetWidth",tile.layoutSize,true)
   and number(tile.frame,label.."_HEIGHT_EXPLICIT","GetHeight",tile.layoutSize,true)
   and parent(tile.frame,label.."_PARENT",tile.layoutParent)
   and anchors(tile.frame,label.."_ANCHORS",{{"LEFT",tile.layoutParent,"LEFT",tile.layoutX,0}})
 end
 tileIndex=nil
 if not current() then return false,"ROW_LAYOUT_SUPERSEDED" end
 if not ready then
  surface.layoutPending=true;return false,"ROW_LAYOUT_READBACK_PENDING"
 end
 self.layoutReadback="EXPLICIT_SIZE_SCALE_AND_ANCHORS_CONFIRMED"
 self.layout=l;surface.layoutPending=nil;self.layoutDirty=nil;return true,"ROW_LAYOUT_READY"
end
function C:GetFrame(id) return id=="Cooldowns.row" and self.frame or nil end
function C:Bounds(id) if id~="Cooldowns.row" or not self.layout then return nil end;return copy(self.layout) end
function C:CustomizeVisible(surface) return surface and surface.id=="Cooldowns.row" end
function C:BridgeCurrent(binding)
 local tile,item=binding.tile,binding.item
 if not self:Current(binding.generation,binding.profile) or tile.binding~=binding or _G[binding.viewer]~=binding.root
  or not S:Frame(tile.frame,true) or not S:Frame(item,false) or not producerVisible(binding.root) then return false end
 if public(item,"GetParent")~=binding.parent or field(item,"cooldownID")~=binding.cooldownID then return false end
 return self:Current(binding.generation,binding.profile) and tile.binding==binding
end
function C:BorrowCurrent(lease,release)
 local b=lease.binding
 if self.borrowed[lease.widget]~=lease or not S:Frame(lease.widget,false) or not S:Frame(b.item,false)
  or field(b.item,lease.sourceKey)~=lease.widget then return false end
 if not release and not self:BridgeCurrent(b) then return false end
 return true
end
local function fontState(font)
 local ok,path,size,flags=pcall(font.GetFont,font)
 if not ok or not (S:Text(path) or S:Number(path)) or not S:Number(size) or not S:Text(flags) then return nil end
 return {path,size,flags}
end
local function sameFont(a,b)
 return a and b and a[1]==b[1] and L:GeometryEqual(a[2],b[2]) and a[3]==b[3]
end
local function recordedPoints(lease,value)
 if not value then return false end
 for _,receipt in ipairs(lease.pointStates) do if samePoints(value,receipt) then return true end end
 return false
end
local function recordPoints(lease,value)
 if not recordedPoints(lease,value) then lease.pointStates[#lease.pointStates+1]=value end
end
function C:BorrowWidget(binding,widget,key)
 if S:InCombat() or not self:BridgeCurrent(binding) or not S:Frame(widget,true)
  or public(widget,"IsProtected","boolean")~=false then return false end
 if self.borrowed[widget] then return false end
 local parent=public(widget,"GetParent");local anchor=points(widget)
 local scale=public(widget,"GetScale","number")
 if not parent or not anchor or not scale or scale<=0 then return false end
 local lease={widget=widget,sourceKey=key,binding=binding,parent=parent,points=anchor,scale=scale,fonts={},pointStates={anchor},
  targetParent=binding.tile.nativeHolder,targetPoints={{"TOPLEFT",binding.tile.icon,"TOPLEFT",0,0},{"BOTTOMRIGHT",binding.tile.icon,"BOTTOMRIGHT",0,0}}}
 self.borrowed[widget]=lease
 binding.widgets[#binding.widgets+1]=widget
 if key=="Cooldown" then binding.tile.borrowedTimer=widget end
 local function current() return not S:InCombat() and self:BorrowCurrent(lease,false) end
 local function write(method,...)
  if not current() then return false end
  local fn=field(widget,method);if type(fn)~="function" or not current() then return false end
  self.borrowWriting=true;local ok,value=pcall(fn,widget,...);self.borrowWriting=nil
  return ok and value~=false and current()
 end
 -- Every possible intermediate anchor vector is retained before its write.
 -- A thrown setter or reentrant combat transition can leave that exact vector.
 recordPoints(lease,{})
 recordPoints(lease,{lease.targetPoints[1]})
 recordPoints(lease,lease.targetPoints)
 if not write("SetParent",lease.targetParent) or not write("SetScale",1) or not write("ClearAllPoints")
  or not write("SetPoint",unpack(lease.targetPoints[1])) or not write("SetPoint",unpack(lease.targetPoints[2])) then return false end
 if public(widget,"GetParent")~=lease.targetParent or not L:GeometryEqual(public(widget,"GetScale","number"),1)
  or not samePoints(points(widget),lease.targetPoints) or not current() then return false end
 local fonts={}
 if key=="Cooldown" then
  local countdown=public(widget,"GetCountdownFontString")
  if countdown then fonts[1]=countdown end
  local getter=field(widget,"GetRegions")
  if #fonts==0 and type(getter)=="function" then
   local okay,regions=pcall(function() return {getter(widget)} end)
   if okay and #regions<=16 then for _,region in ipairs(regions) do if public(region,"GetObjectType","string")=="FontString" then fonts[#fonts+1]=region end end end
  end
  local hidden=public(widget,"GetHideCountdownNumbers","boolean")
  if hidden~=nil and type(field(widget,"SetHideCountdownNumbers"))=="function" then
   lease.hideNumbers=hidden;lease.appliedHideNumbers=cfg().showNumbers==false
   if not write("SetHideCountdownNumbers",lease.appliedHideNumbers)
    or public(widget,"GetHideCountdownNumbers","boolean")~=lease.appliedHideNumbers or not current() then return false end
  end
 else
  local text=field(widget,"Current") or field(widget,"Applications")
  if text then fonts[1]=text end
 end
 for _,font in ipairs(fonts) do
  if not current() then return false end
  local original=fontState(font)
  if original then
   local desired={M.Visual.font or STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",key=="Cooldown" and (cfg().durationSize or 12) or (cfg().chargeSize or 11),"OUTLINE"}
   lease.fonts[#lease.fonts+1]={object=font,original=original,applied=desired}
   local okay,value=pcall(font.SetFont,font,unpack(desired))
   if not okay or value==false or not current() or not sameFont(fontState(font),desired) or not current() then return false end
  end
 end
 lease.applied=true
 for _,method in ipairs({"SetParent","SetPoint","ClearAllPoints","SetScale"}) do
  self:Hook(widget,method,function()
   if self.active and not self.borrowWriting then
    self.catalogueDirty=true;self:RevalidateItem(binding.item);self:WakeWidgetHandoff(widget)
   end
  end)
 end
 return true
end
function C:ReleaseWidgets()
 if next(self.borrowed)==nil then self.handoffIssue=nil;self.handoffWidgetCount=0;return true end
 if S:InCombat() then return false,"COMBAT_LOCKDOWN" end
 if self.widgetReleaseBusy then return false,"NATIVE_WIDGET_HANDOFF_PENDING" end
 local token={};self.widgetReleaseBusy=token
 local generation,profile,borrowed=self.generation,M.profile,self.borrowed
 local function same() return self.widgetReleaseBusy==token and self.generation==generation and M.profile==profile and self.borrowed==borrowed end
 self.handoffPasses=(self.handoffPasses or 0)+1
 local complete,first=true,nil
 local ordered={};for _,lease in pairs(borrowed) do ordered[#ordered+1]=lease end
 table.sort(ordered,function(a,b)
  local ai,bi=a.binding.tile.index or 0,b.binding.tile.index or 0
  return ai<bi or ai==bi and a.sourceKey<b.sourceKey
 end)
 local function fail(lease,property,reason,observed)
  complete=false
  if not first then first={slot=lease.binding.tile.index or 0,widget=lease.sourceKey,viewer=lease.binding.viewer,
   property=property,reason=reason,observed=observed or "UNAVAILABLE"} end
  return false
 end
 for _,lease in ipairs(ordered) do
  if not same() or S:InCombat() then complete=false;break end
  local widget=lease.widget
  if borrowed[widget]==lease then
   local parent=public(widget,"GetParent")
   if not same() then complete=false;break end
   if not self:BorrowCurrent(lease,true) then
    if parent and parent~=lease.targetParent then borrowed[widget]=nil
    else fail(lease,"SOURCE_IDENTITY","SOURCE_UNAVAILABLE_OR_CHANGED",parent and "HELD_PARENT" or "UNAVAILABLE") end
   elseif parent and parent~=lease.targetParent and parent~=lease.parent then
    borrowed[widget]=nil
   elseif not parent then fail(lease,"GetParent","READ_UNAVAILABLE")
   else
    local function current()
     return same() and not S:InCombat() and self:BorrowCurrent(lease,true) and same()
    end
    local function write(method,...)
     if not current() then return fail(lease,method,"CUSTODY_CHANGED") end
     local fn=field(widget,method)
     if type(fn)~="function" then return fail(lease,method,"METHOD_UNAVAILABLE") end
     if not current() then return fail(lease,method,"CUSTODY_CHANGED") end
     self.borrowWriting=true;local okay,value=pcall(fn,widget,...);self.borrowWriting=nil
     if not okay or value==false then return fail(lease,method,okay and "WRITE_REFUSED" or "WRITE_REJECTED") end
     if not current() then return fail(lease,method,"CUSTODY_CHANGED") end
     return true
    end
    local function confirm(okay,property,observed)
     return okay and current() or fail(lease,property,"READBACK_PENDING",observed)
    end
    local ok=current() and (parent==lease.parent or write("SetParent",lease.parent))
    if ok then ok=confirm(public(widget,"GetParent")==lease.parent,"GetParent","ORIGINAL_PARENT_NOT_CONFIRMED") end
    if ok and lease.hideNumbers~=nil and not lease.hideNumbersRetired then
     local value=public(widget,"GetHideCountdownNumbers","boolean")
     if value==nil then ok=fail(lease,"GetHideCountdownNumbers","READ_UNAVAILABLE")
     elseif value==lease.hideNumbers then
     elseif value==lease.appliedHideNumbers then
      ok=write("SetHideCountdownNumbers",lease.hideNumbers)
      if ok then ok=confirm(public(widget,"GetHideCountdownNumbers","boolean")==lease.hideNumbers,"GetHideCountdownNumbers","ORIGINAL_FLAG_NOT_CONFIRMED") end
     else lease.hideNumbersRetired=true end
    end
    for _,font in ipairs(lease.fonts) do
     if ok and not font.retired then
      local observed=fontState(font.object)
      if not observed or not current() then ok=fail(lease,"GetFont","FONT_READ_UNAVAILABLE")
      elseif sameFont(observed,font.original) then
      elseif sameFont(observed,font.applied) then
       local written,value=pcall(font.object.SetFont,font.object,unpack(font.original))
       if not written or value==false then ok=fail(lease,"SetFont",written and "WRITE_REFUSED" or "WRITE_REJECTED")
       else ok=confirm(sameFont(fontState(font.object),font.original),"GetFont","ORIGINAL_FONT_NOT_CONFIRMED") end
      else font.retired=true end
     end
    end
    if ok and not lease.pointsRetired then
     local observed=points(widget)
     if not observed or not current() then ok=fail(lease,"GetPoint","ANCHORS_READ_UNAVAILABLE")
     elseif samePoints(observed,lease.points) then
     elseif recordedPoints(lease,observed) then
      recordPoints(lease,{})
      local prefix={}
      for _,anchor in ipairs(lease.points) do
       local nextPrefix={};for i,value in ipairs(prefix) do nextPrefix[i]=value end
       nextPrefix[#nextPrefix+1]=anchor;prefix=nextPrefix;recordPoints(lease,prefix)
      end
      ok=write("ClearAllPoints")
      for _,anchor in ipairs(lease.points) do if ok then ok=write("SetPoint",unpack(anchor)) end end
      if ok then ok=confirm(samePoints(points(widget),lease.points),"GetPoint","ORIGINAL_ANCHORS_NOT_CONFIRMED") end
     else lease.pointsRetired=true end
    end
    if ok and not lease.scaleRetired then
     local value=public(widget,"GetScale","number")
     if not value or not current() then ok=fail(lease,"GetScale","SCALE_READ_UNAVAILABLE")
     elseif L:GeometryEqual(value,lease.scale) then
     elseif L:GeometryEqual(value,1) then
      ok=write("SetScale",lease.scale)
      if ok then ok=confirm(L:GeometryEqual(public(widget,"GetScale","number"),lease.scale),"GetScale",geometryText(public(widget,"GetScale","number"))) end
     else lease.scaleRetired=true end
    end
    if ok and current() and public(widget,"GetParent")==lease.parent and current() then borrowed[widget]=nil
    elseif not first then fail(lease,"FINAL_CUSTODY","READBACK_PENDING") else complete=false end
   end
  end
 end
 if not same() then
  if self.widgetReleaseBusy==token then self.widgetReleaseBusy=nil end
  return false,"NATIVE_WIDGET_HANDOFF_PENDING"
 end
 local pending=0;for _ in pairs(borrowed) do pending=pending+1 end
 for _,lease in pairs(borrowed) do
  lease.handoffParent=public(lease.widget,"GetParent")
  lease.handoffPoints=points(lease.widget);lease.handoffScale=public(lease.widget,"GetScale","number")
 end
 if not same() then
  if self.widgetReleaseBusy==token then self.widgetReleaseBusy=nil end
  return false,"NATIVE_WIDGET_HANDOFF_PENDING"
 end
 self.widgetReleaseBusy=nil
 self.handoffWidgetCount=pending;self.handoffIssue=first
 if first then self.lastHandoffIssue=first end
 return complete,complete and "NATIVE_WIDGETS_RESTORED" or "NATIVE_WIDGET_HANDOFF_PENDING"
end
function C:WakeWidgetHandoff(widget)
 local retry=self.handoffRetry;local lease=self.borrowed[widget]
 if not retry or not lease or not self.repairBlocked or not self:Current(retry.generation,retry.profile) then return end
 local parent=public(widget,"GetParent");local anchors=points(widget);local scale=public(widget,"GetScale","number")
 if not self:Current(retry.generation,retry.profile) or self.borrowed[widget]~=lease then return end
 -- A repeated native no-op does not reset the bounded retry budget. Actual
 -- public custody changes can make a previously refused inverse possible.
 local changed=parent and parent~=lease.handoffParent
  or anchors and not samePoints(anchors,lease.handoffPoints)
  or scale and not L:GeometryEqual(scale,lease.handoffScale)
 if not changed then return end
 lease.handoffParent=parent;lease.handoffPoints=anchors;lease.handoffScale=scale
 retry.nextAt=math.max(S:Now()+.1,(retry.lastAttempt or 0)+.25)
 retry.nativeWake=true
end
function C:Forward(object,kind,method,...)
 -- Numeric cooldown setters and SetShown reject secret arguments from addon
 -- code in this client. They are deliberately absent from this bridge.
 if method=="SetTexture" then for i=1,select("#",...) do if not S:Readable(select(i,...)) then return end end end
 for _,binding in ipairs(self.bridges[object] or {}) do if self:BridgeCurrent(binding) then
  local tile=binding.tile;local target=tile[kind];local fn=target and field(target,method)
  local ok=type(fn)=="function" and pcall(fn,target,...)
  if not ok then tile.artPending=true else tile.nativeUpdates=(tile.nativeUpdates or 0)+1 end
 end end
end
function C:BridgeObject(binding,object,kind,methods)
 if not S:Frame(object,false) then return false end
 local bindings=self.bridges[object];if not bindings then bindings={};self.bridges[object]=bindings end
 bindings[#bindings+1]=binding
 local ready=true
 for _,method in ipairs(methods) do
  if type(field(object,method))=="function" then
   local operation=method
   ready=self:Hook(object,method,function(source,...) self:Forward(source,kind,operation,...) end) and ready
  end
 end
 return ready
end
function C:InvalidateItem(item)
 for _,tile in ipairs(self.tiles) do if tile.binding and tile.binding.item==item then
  -- The pool's reset/identity boundary conceals borrowed children immediately.
  -- An ordinary inactive aura Hide is not an identity boundary.
  tile.nativeHolder:Hide();tile.nativeInitial=nil;tile.sourceRetired=true
  self.dataDirty=true;self.catalogueDirty=true
 end end
end
function C:RevalidateBinding(binding)
 local tile=binding.tile
 local timer=tile.borrowedTimer and self.borrowed[tile.borrowedTimer]
 local valid=timer and timer.applied and self:BridgeCurrent(binding)
 for _,widget in ipairs(binding.widgets) do
  local lease=self.borrowed[widget]
  valid=valid and lease and lease.binding==binding and lease.applied and self:BorrowCurrent(lease,false)
   and public(widget,"GetParent")==lease.targetParent and samePoints(points(widget),lease.targetPoints)
   and L:GeometryEqual(public(widget,"GetScale","number"),1)
 end
 if tile.binding~=binding then return end
 if valid and self:BridgeCurrent(binding) then
  if not tile.nativeInitial or tile.sourceRetired then
   tile.nativeInitial=true;tile.sourceRetired=nil;tile.nativeHolder:Show();self.dataDirty=true
  end
 else self:InvalidateItem(binding.item) end
end
function C:RevalidateItem(item)
 for _,tile in ipairs(self.tiles) do
  if tile.binding and tile.binding.item==item then self:RevalidateBinding(tile.binding) end
 end
end
function C:SourceVisibilityChanged(root)
 for _,tile in ipairs(self.tiles) do
  local binding=tile.binding
  if binding and binding.root==root then
   if producerVisible(root) then self:RevalidateBinding(binding) else self:InvalidateItem(binding.item) end
  end
 end
 if self.active then self.catalogueDirty=true;self.dataDirty=true end
end
function C:Bind(tile,source)
 local item=source.item;local parent=public(item,"GetParent")
 if not parent or not S:Frame(parent,false) then return false end
 local binding={widgets={},tile=tile,item=item,viewer=source.viewer,root=source.root,cooldownID=source.cooldownID,
  parent=parent,profile=M.profile,generation=self.generation}
 tile.binding=binding;tile.sourceRetired=nil
 local timer=field(item,"Cooldown");local icon=field(item,"Icon")
 if public(icon,"GetObjectType","string")~="Texture" then icon=field(icon,"Icon") end
 local countKey=field(item,"ChargeCount") and "ChargeCount" or "Applications"
 local countFrame=field(item,countKey)
 local ready=self:BorrowWidget(binding,timer,"Cooldown")
 if ready and countFrame and cfg().rowShowCharges~=false then ready=self:BorrowWidget(binding,countFrame,countKey) end
 if not ready then tile.nativeHolder:Hide();return false end
 self:BridgeObject(binding,icon,"icon",{"SetTexture","SetDesaturated","SetVertexColor"})
 self:Hook(item,"ResetCooldownData",function() self:InvalidateItem(item) end)
 self:Hook(item,"ClearCooldownID",function() self:InvalidateItem(item) end)
 self:Hook(item,"SetCooldownID",function() self:RevalidateItem(item) end)
 if not self:BridgeCurrent(binding) then tile.nativeHolder:Hide();return false end
 if icon then
  local texture=public(icon,"GetTexture")
  if texture then pcall(tile.icon.SetTexture,tile.icon,texture) end
  -- These two texture sinks explicitly accept secret arguments when tainted.
  pcall(function() tile.icon:SetDesaturated(icon:IsDesaturated());tile.icon:SetVertexColor(icon:GetVertexColor()) end)
 end
 tile.nativeInitial=true;tile.borrowedTimer=timer;tile.timer:Hide();tile.countFrame:Hide();tile.nativeHolder:Show()
 return true
end
function C:FindSources(catalogue)
 local out={}
 for _,name in ipairs(names) do
  local root=_G[name];local pool=field(root,"itemFramePool");local enumerate=field(pool,"EnumerateActive")
  if producerVisible(root) and type(enumerate)=="function" then
   local count=0
   pcall(function()
    for item in enumerate(pool) do
     count=count+1;if count>MAX then break end
     if not S:Frame(item,false) then break end
     local id=field(item,"cooldownID");local info=validID(id) and (catalogue[id] or self:NativeInfo(id))
     if info then out[#out+1]={item=item,cooldownID=id,info=info,viewer=name,root=root} end
    end
   end)
  end
 end
 return out
end
function C:Rebuild()
 if S:InCombat() then self.catalogueDirty=true;return false,"SETUP_COMBAT_DEFERRED" end
 self.setupStage="PRIOR_WIDGET_HANDOFF";self.setupSlot=nil
 local released,releaseWhy=self:ReleaseWidgets()
 if not released then return false,releaseWhy end
 self.handoffVisible=nil
 local generation,profile=self.generation,M.profile
 self.setupStage="NATIVE_CATALOGUE";self.setupSlot=nil
 local catalogue,nativeOrder=self:ReadNativeCatalogue()
 local authored=cfg().spells or {};local entries=(#authored>0 or cfg().rowCustom==true) and authored or nativeOrder
 local sources=self:FindSources(catalogue)
 local metas={};local skipped=0
 for i,entry in ipairs(entries) do
  if i>MAX then break end
  if not self:Current(generation,profile) then return false,"ROW_SETUP_SUPERSEDED" end
  self.setupStage="SPELL_METADATA";self.setupSlot=i
  local meta=self:Metadata(entry,catalogue)
  meta.highlight=entry.highlight;meta.bar=entry.bar;meta.group=entry.group
  if entry.bar=="Secondary" and not cfg().rowSecondary then
   -- Retain disabled assignments without collecting their timer widgets.
  elseif meta.learned~=false then metas[#metas+1]=meta else skipped=skipped+1 end
 end
 local maximum=cfg().rowMaxIcons or 0
 local count=maximum>0 and math.min(maximum,#metas) or #metas
 self.bridges=setmetatable({},{__mode="k"});self.count=count;self.assigned=#entries;self.unlearned=skipped;self.hasFallback=false;self.hasAura=false
 self.primaryCount,self.secondaryCount=0,0
 for i=1,count do if metas[i].bar=="Secondary" then self.secondaryCount=self.secondaryCount+1 else self.primaryCount=self.primaryCount+1 end end
 for i,tile in ipairs(self.tiles) do
  tile.binding=nil;tile.nativeInitial=nil;tile.borrowedTimer=nil;tile.displayReady=nil;tile.nativeHolder:Hide()
  if i>count then tile.frame:Hide();tile.timer:Clear();tile.count:SetText("") end
 end
 for i=1,count do
  if not self:Current(generation,profile) then return false,"ROW_SETUP_SUPERSEDED" end
  local tile,createWhy=self:CreateTile(i);if not tile then return false,createWhy or "ROW_TILE_PENDING" end
  tile.meta=metas[i];tile.auraActive=nil;tile.sourceWarning=nil;tile.frame:Show();tile.icon:SetTexture(tile.meta.icon or 134400)
  if auraModes[tile.meta.mode] then self.hasAura=true end
  tile.backdrop:SetColorTexture(.025,.025,.025,1)
  if tile.glow then tile.glow:Hide() end
  tile.icon:SetVertexColor(1,1,1,1);tile.icon:SetDesaturated(false);tile.timer:Clear();tile.timer:Show();tile.count:SetText("");tile.countFrame:Show()
  local preferred
  for _,source in ipairs(sources) do if matches(source.info,tile.meta.id) then
   if not preferred or tile.meta.native and source.cooldownID==tile.meta.native.cooldownID then preferred=source end
  end end
  -- Plain abilities/recharges use the public duration-object contract. Native
  -- widgets are needed only for native active-aura decisions that these spell
  -- APIs cannot reproduce, or a selected aura unavailable to public lookup.
  local native=tile.meta.native
  tile.nativeRequired=not addedModes[tile.meta.mode] and tile.meta.mode~="Recharge" and native~=nil
   and (tile.meta.mode=="Aura" and not self:PaintAura(tile) or tile.meta.mode~="Aura" and native.hasAura~=false)
  self.setupStage="NATIVE_WIDGET_BIND";self.setupSlot=i
  if tile.nativeRequired and preferred and not self:Bind(tile,preferred) then
   local restored=self:ReleaseWidgets()
   if not restored then return false,"NATIVE_WIDGET_HANDOFF_PENDING" end
   -- A rejected transplant does not leave earlier tiles claiming ownership.
   for _,earlier in ipairs(self.tiles) do earlier.binding=nil;earlier.nativeInitial=nil;earlier.borrowedTimer=nil;earlier.nativeHolder:Hide() end
  end
  if not tile.nativeInitial then self.hasFallback=true end
 end
 if not self:Current(generation,profile) then return false,"ROW_SETUP_SUPERSEDED" end
 self.catalogueDirty=nil;self.dataDirty=true;self.layoutDirty=true;self.needsRebind=nil
 return self:ApplyLayout(self.surface)
end
function C:Duration(widget,api,...)
 local clear=field(widget,"Clear")
 local function unavailable(why)
  if type(clear)=="function" then pcall(clear,widget) end
  return why
 end
 local sink=field(widget,"SetCooldownFromDurationObject")
 if type(api)~="function" or type(sink)~="function" then return unavailable("UNSUPPORTED") end
 local ok,handle=pcall(api,...)
 if not ok then return unavailable("UNAVAILABLE") end
 -- The object's contents stay native. The handle itself must be public:
 -- this setter accepts secret arguments only from untainted callers.
 if not S:Readable(handle) then return unavailable("RESTRICTED_DURATION_HANDLE") end
 if handle==nil then return unavailable("NO_OBJECT") end
 if type(handle)~="table" and type(handle)~="userdata" then return unavailable("INVALID_DURATION_HANDLE") end
 local sent,value=pcall(sink,widget,handle,true)
 if not sent or value==false then return unavailable("UNAVAILABLE") end
 return "NATIVE_WIDGET_DISPATCH"
end
function C:PaintAura(tile)
 local meta=tile.meta
 local unit=(meta.mode=="TargetDebuff" or meta.mode=="TargetAura") and "target" or "player"
 local harmful=meta.mode=="Debuff" or meta.mode=="TargetDebuff"
 local auraName=meta.auraName or meta.name
 local function unavailable(reason)
  tile.timerStatus=reason;tile.auraActive=nil;tile.timer:Clear();tile.count:SetText("")
  return false
 end
 local unitLookup=harmful or unit=="target"
 local fn=C_UnitAuras and (unitLookup and C_UnitAuras.GetUnitAuraBySpellID or C_UnitAuras.GetPlayerAuraBySpellID)
 local ok,aura
 if type(fn)=="function" then
  if unitLookup then ok,aura=pcall(fn,unit,meta.spellID) else ok,aura=pcall(fn,meta.spellID) end
  if not ok or not S:Readable(aura) then return unavailable("AURA_LOOKUP_RESTRICTED") end
 end
 -- Nightfall's learned talent and Shadow Trance's proc have different IDs.
 -- This explicit legacy selection mapping never derives identity from combat.
 if not unitLookup and aura==nil and meta.id==18094 and not meta.itemID and type(fn)=="function" then
  ok,aura=pcall(fn,17941)
  if not ok or not S:Readable(aura) then return unavailable("AURA_LOOKUP_RESTRICTED") end
 end
 if aura~=nil and type(aura)~="table" then return unavailable("AURA_LOOKUP_UNAVAILABLE") end
 -- GetUnitAuraBySpellID has no polarity argument. A public polarity decides
 -- whether its result is suitable; otherwise ask the filtered native query.
 if unitLookup and aura~=nil then
  local polarity,state=S:FieldAccess(aura,harmful and "isHarmful" or "isHelpful")
  if state~="KNOWN" or polarity~=true then aura=nil end
 end
 if aura==nil and C_UnitAuras and type(C_UnitAuras.GetAuraDataBySpellName)=="function" and S:Text(auraName) then
  ok,aura=pcall(C_UnitAuras.GetAuraDataBySpellName,unit,auraName,harmful and "HARMFUL" or "HELPFUL")
  if not ok or not S:Readable(aura) then return unavailable("AURA_LOOKUP_RESTRICTED") end
 elseif type(fn)~="function" and aura==nil then return unavailable("AURA_LOOKUP_UNSUPPORTED") end
 if aura==nil then
  tile.timer:Clear();tile.count:SetText("");tile.icon:SetDesaturated(true)
  tile.auraActive=false;tile.timerStatus="AURA_ABSENT";return true
 end
 if type(aura)~="table" then return unavailable("AURA_LOOKUP_UNAVAILABLE") end
 local instance,state=S:FieldAccess(aura,"auraInstanceID")
 -- The reviewed duration API only permits public instance arguments from
 -- addon code. Private auras keep the existing native CDM bridge when present.
 if state~="KNOWN" or not validID(instance) then return unavailable("AURA_INSTANCE_RESTRICTED") end
 local status=self:Duration(tile.timer,C_UnitAuras.GetAuraDuration,unit,instance)
 tile.timerStatus=status
 if status~="NATIVE_WIDGET_DISPATCH" and status~="NO_OBJECT" then return unavailable("AURA_DURATION_"..status) end
 tile.auraActive=true;tile.icon:SetDesaturated(false);tile.timer:Show();tile.count:SetText("")
 if cfg().rowShowCharges~=false then
  -- Stack counts may be private; the font remains their only consumer.
  if not pcall(function() tile.count:SetText(aura.applications) end) then tile.count:SetText("") end
 end
 return true
end
function C:PaintItem(tile)
 local api=C_Item and C_Item.GetItemCooldown or C_Container and C_Container.GetItemCooldown
 local function unavailable(reason)
  tile.timerStatus=reason;tile.timer:Clear();tile.count:SetText("");return false
 end
 if type(api)~="function" then return unavailable("ITEM_COOLDOWN_UNSUPPORTED") end
 local ok,start,duration,enabled=pcall(api,tile.meta.itemID)
 -- No subtraction, ordering, or dispatch is attempted until every scalar is
 -- known public. C_Item returns a Boolean; the compatibility container API
 -- returns 0/1. Neither is silently coerced from an opaque value.
 if not ok or not S:Number(start) or not S:Number(duration) or start<0 or duration<0
  or not S:Readable(enabled) then return unavailable("ITEM_COOLDOWN_RESTRICTED") end
 local allowed=enabled==true or S:Number(enabled) and enabled==1
 if enabled~=false and enabled~=true and not (S:Number(enabled) and (enabled==0 or enabled==1)) then
  return unavailable("ITEM_COOLDOWN_UNAVAILABLE")
 end
 tile.count:SetText("")
 if not allowed then tile.timer:Clear();tile.icon:SetDesaturated(true);tile.timerStatus="ITEM_TIMER_DISABLED";return true end
 if duration==0 then tile.timer:Clear();tile.icon:SetDesaturated(false);tile.timerStatus="ITEM_READY";return true end
 local sink=field(tile.timer,"SetCooldown")
 if type(sink)~="function" then return unavailable("ITEM_TIMER_UNSUPPORTED") end
 local sent,value=pcall(sink,tile.timer,start,duration,1)
 if not sent or value==false then return unavailable("ITEM_TIMER_UNAVAILABLE") end
 tile.icon:SetDesaturated(false);tile.timer:Show();tile.timerStatus="PUBLIC_ITEM_COOLDOWN";return true
end
function C:PaintFallback(tile)
 local meta=tile.meta
 if not meta.ready then tile.timerStatus=meta.status or "METADATA_UNAVAILABLE";tile.timer:Clear();return false end
 if auraModes[meta.mode] then return self:PaintAura(tile) end
 if meta.mode=="Item" then return self:PaintItem(tile) end
 -- Preview tiles are reused across timer types and temporary source failures.
 -- A successful ability timer must retire an earlier aura/unknown appearance.
 tile.auraActive=nil
 local charge=meta.mode=="Recharge" or meta.native and meta.native.charges==true
 local api=charge and C_Spell and C_Spell.GetSpellChargeDuration or C_Spell and C_Spell.GetSpellCooldownDuration
 local state
 if charge then state=self:Duration(tile.timer,api,meta.spellID)
 else state=self:Duration(tile.timer,api,meta.spellID,cfg().ignoreGCD==true) end
 tile.timerStatus=state
 local ready=state=="NATIVE_WIDGET_DISPATCH" or state=="NO_OBJECT"
 if ready then tile.icon:SetDesaturated(false);tile.timer:Show() end
 if cfg().rowShowCharges~=false and C_Spell and type(C_Spell.GetSpellCharges)=="function" then
  local ok,charges=pcall(C_Spell.GetSpellCharges,meta.spellID)
  if ok and S:Readable(charges) and type(charges)=="table" then
   -- The count itself may be secret. A font is its only consumer.
   if not pcall(function() tile.count:SetText(charges.currentCharges) end) then tile.count:SetText("") end
  else tile.count:SetText("") end
 end
 return ready
end
function C:PaintAppearance(tile)
 local aura=auraModes[tile.meta and tile.meta.mode]
 local ready=tile.displayReady~=false and not tile.sourceWarning
 local active=not aura or tile.auraActive==true and ready
 -- Keep every authored aura slot available by default. A quiet grey icon
 -- means the effect is absent; it is not a synthetic cooldown or proc timer.
 -- Restricted native texture state is already forwarded to an allowed sink,
 -- and is never read back or converted into an addon-authored active signal.
 if aura and (not tile.nativeInitial or tile.auraActive~=nil) then
  tile.icon:SetDesaturated(not active)
  local value=active and 1 or .58;tile.icon:SetVertexColor(value,value,value,1)
 elseif not tile.nativeInitial and ready then tile.icon:SetVertexColor(1,1,1,1) end
 local highlighted=ready and active and (tile.meta.highlight=="Accent" or tile.meta.highlight=="Glow")
 local theme=M.Theme or M.VisualTokens and M.VisualTokens.options or {}
 local border=highlighted and (theme.secondary or { .96,.79,.36,1 }) or { .025,.025,.025,1 }
 if tile.backdrop then tile.backdrop:SetColorTexture(unpack(border)) end
 if tile.glow then
  local color=theme.secondary or { .96,.79,.36,1 }
  tile.glow:SetVertexColor(color[1],color[2],color[3],.65)
  tile.glow:SetShown(highlighted and tile.meta.highlight=="Glow" or false)
 end
 return highlighted==true
end
function C:Paint()
 local generation,profile=self.generation,M.profile
 local complete=(self.count and self.count>0) or cfg().rowSecondary==true or (cfg().rowCustom==true and self.assigned==0)
 self.sourceWarnings=0;self.activeAuras=0
 for i=1,self.count or 0 do
  if not self:Current(generation,profile) then return false,"ROW_PAINT_SUPERSEDED" end
  local tile=self.tiles[i];local binding=tile.binding
  local lease=tile.borrowedTimer and self.borrowed[tile.borrowedTimer]
  if binding and self:BridgeCurrent(binding) and tile.nativeInitial and lease and lease.applied and self:BorrowCurrent(lease,false)
   and public(lease.widget,"GetParent")==lease.targetParent then
   tile.displayReady=true;tile.timerStatus="NATIVE_CDM_DISPLAY"
   -- The native aura producer may expose this state as a restricted value.
   -- Only a public boolean can drive addon-authored effects; its native timer
   -- and texture sinks continue to own restricted presentation unchanged.
   if auraModes[tile.meta.mode] then tile.auraActive=public(binding.item,"IsActive","boolean") end
  else
   if binding and not self:BridgeCurrent(binding) then tile.nativeHolder:Hide();tile.nativeInitial=nil;self.catalogueDirty=true end
   tile.displayReady=not tile.nativeRequired and self:PaintFallback(tile) or false
  end
  tile.sourceWarning=nil
  if not tile.displayReady then
   tile.timer:Clear();tile.count:SetText("")
   -- An optional item/debuff source must not take down healthy spell timers.
   -- Its deliberately marked placeholder cannot be mistaken for a ready item.
   if addedModes[tile.meta.mode] then
    tile.sourceWarning=true;tile.icon:SetDesaturated(true);tile.count:SetText("?");tile.countFrame:Show()
    self.sourceWarnings=self.sourceWarnings+1
   end
  end
  if cfg().rowShowCharges==false and not tile.sourceWarning then tile.count:SetText("");tile.countFrame:Hide() end
  self:PaintAppearance(tile)
  if auraModes[tile.meta.mode] and not tile.sourceWarning then
   if tile.auraActive==false and cfg().rowShowInactive==false then tile.frame:Hide();self:HideTooltip(tile)
   else tile.frame:Show();if tile.auraActive then self.activeAuras=self.activeAuras+1 end end
  else tile.frame:Show() end
  complete=complete and (tile.displayReady==true or tile.sourceWarning==true)
 end
 if not self:Current(generation,profile) then return false,"ROW_PAINT_SUPERSEDED" end
 self.presentationReady=complete and not self.surface.layoutPending or false
 self.dataDirty=nil
 if self.presentationReady then self.status=self.assigned==0 and "COOLDOWN_ROW_EMPTY" or self.sourceWarnings>0 and "COOLDOWN_ROW_READY_WITH_UNAVAILABLE_SOURCES" or "COOLDOWN_ROW_READY";self.handoffVisible=nil;self.releasePending=nil
 elseif (self.count or 0)==0 then self.status="WAITING_FOR_TRACKED_SPELLS"
 else self.status="COOLDOWN_ROW_SOURCE_PENDING" end
 self:RefreshVisibility()
 return self.presentationReady,self.status
end
function C:HasSourceDebt()
 for _,row in pairs(self.roots) do
  if row.leaseOwner and row.leaseOwner.records and next(row.leaseOwner.records)~=nil then return true end
 end
 return false
end
function C:CanCleanupRoots()
 if next(self.borrowed)~=nil or self:HasSourceDebt() then return false,"NATIVE_RELEASE_PENDING" end
 return true
end
function C:ReleaseSources()
 if not self:HasSourceDebt() then return true,"NATIVE_PRESENTATION_RESTORED" end
 if S:InCombat() then return false,"COMBAT_LOCKDOWN" end
 local okay=true
 for _,row in pairs(self.roots) do
  local owner=row.leaseOwner;owner.active=false;owner.generation=(owner.generation or 0)+1
  local restored=L:Release(owner)
  okay=restored and okay
  if restored then row.suppressed=nil else row.releasePending=true end
 end
 return okay,okay and "NATIVE_PRESENTATION_RESTORED" or "NATIVE_HANDOFF_PENDING"
end
function C:RestorePresentation()
 -- Widgets return before source opacity. A hidden Mirage ancestor must never
 -- retain a live native timer while claiming that the native fallback resumed.
 local generation,profile,borrowed=self.generation,M.profile,self.borrowed
 local function current() return self.generation==generation and M.profile==profile and self.borrowed==borrowed end
 local widgets,widgetWhy=self:ReleaseWidgets()
 if not current() then return false,"ROW_SETUP_SUPERSEDED" end
 local sources,sourceWhy=self:ReleaseSources()
 if not current() then return false,"ROW_SETUP_SUPERSEDED" end
 local held,heldInRow={},false
 for _,lease in pairs(self.borrowed) do
  held[lease.binding.tile]=true
  local parent=public(lease.widget,"GetParent")
  if not parent or parent==lease.targetParent then heldInRow=true end
 end
 for _,tile in ipairs(self.tiles) do
  if not current() then return false,"ROW_SETUP_SUPERSEDED" end
  if not held[tile] then
   tile.binding=nil;tile.nativeInitial=nil;tile.borrowedTimer=nil;tile.nativeHolder:Hide()
  elseif tile.sourceRetired or not tile.binding or not producerVisible(tile.binding.root) then
   -- The handback floor never resurrects a recycled or stopped producer.
   tile.nativeHolder:Hide()
  else
   local lease=tile.borrowedTimer and self.borrowed[tile.borrowedTimer]
   local binding=tile.binding
   if lease and lease.applied and _G[binding.viewer]==binding.root
    and field(binding.item,"cooldownID")==binding.cooldownID and self:BorrowCurrent(lease,true)
    and public(lease.widget,"GetParent")==lease.targetParent and samePoints(points(lease.widget),lease.targetPoints)
    and S:Frame(tile.nativeHolder,true) then tile.nativeHolder:Show() end
  end
  if tile.timerStatus=="NATIVE_CDM_DISPLAY" then tile.timerStatus=held[tile] and "WIDGET_HANDOFF_PENDING" or "NATIVE_FALLBACK" end
  tile.displayReady=false
 end
 if not current() then return false,"ROW_SETUP_SUPERSEDED" end
 self.needsRebind=true
 self.handoffVisible=(heldInRow or self:HasSourceDebt()) and true or nil
 self.releasePending=not widgets or not sources or nil
 self:RefreshVisibility()
 return widgets and sources,not widgets and widgetWhy or sourceWhy
end
function C:SuppressSources()
 if self.profile~=M.profile then return false,"PROFILE_CHANGED" end
 if not self.presentationReady or settingsOpen() or not chosen() then return self:ReleaseSources() end
 if S:InCombat() then return true,"SUPPRESSION_COMBAT_RETAINED" end
 local okay=true
 for _,name in ipairs(names) do
  local f=_G[name];local row=self.roots[name]
  if S:Frame(f,false) then
   if row and row.frame~=f then
    row.leaseOwner.active=false
    local released=L:Release(row.leaseOwner)
    if not released then okay=false else self.roots[name]=nil;row=nil end
   end
   if not row then
    local parent=public(f,"GetParent")
    if parent then
     row={frame=f,spec={name=name}}
     local owner={id="cooldowns",rootRow=row,parentOwner=self,parentGeneration=self.generation,active=true,rootParentTracked=true,rootParent=parent}
     row.leaseOwner=owner;self.roots[name]=row;L:Begin(owner)
    else okay=false end
   end
   if row and row.frame==f then
    local owner=row.leaseOwner
    owner.parentGeneration=self.generation;owner.active=true
    if not owner.records then L:Begin(owner) end
    local suppressed=L:Scalar(owner,f,"alpha","GetAlpha","SetAlpha",0)
    row.suppressed=suppressed==true;okay=suppressed and okay
    self:Hook(f,"SetAlpha",function()
     if self.active and (owner.leaseWriteDepth or 0)==0 and not owner.releasing then self.sourceDirty=true end
    end)
   end
  end
 end
 self.sourceDirty=nil
 return okay,okay and "NATIVE_PRESENTATION_SUPERSEDED" or "NATIVE_SUPPRESSION_PENDING"
end
function C:SetupFailure(why)
 local generation,profile=self.generation,M.profile
 self.failureStage=self.setupStage or "UNKNOWN";self.failureSlot=self.setupSlot;self.failureReason=why or "ROW_SETUP_UNAVAILABLE"
 self.presentationReady=false;self.repairBlocked=true
 self.catalogueDirty=nil;self.layoutDirty=nil;self.dataDirty=nil;self.sourceDirty=nil
 local _,releaseWhy=self:RestorePresentation()
 if self.generation~=generation or M.profile~=profile then return result("DEFERRED_HANDOFF","ROW_SETUP_SUPERSEDED") end
 self.releaseWake=nil
 if why=="NATIVE_WIDGET_HANDOFF_PENDING" and self.active and self.profile==M.profile then
  self.handoffRetry={generation=self.generation,profile=M.profile,attempts=0,nextAt=S:Now()+handoffDelays[1]}
 else self.handoffRetry=nil end
 self.status=why or releaseWhy or "COOLDOWN_ROW_RECOVERY_REQUIRED"
 self:RefreshVisibility()
 return result(S:InCombat() and self.releasePending and "DEFERRED_COMBAT" or "PARTIAL",self.status)
end
function C:ContinueWidgetHandoff(now)
 local retry=self.handoffRetry
 if not retry or not self:Current(retry.generation,retry.profile) then return result("DEFERRED_HANDOFF","ROW_SETUP_SUPERSEDED") end
 if S:InCombat() then return result("DEFERRED_COMBAT","COMBAT_LOCKDOWN") end
 local open=settingsOpen()
 local explicitWake=self.releaseWake==true or self.nativeSettings~=open
 local wake=explicitWake or retry.nativeWake==true
 if not wake and (not retry.nextAt or now<retry.nextAt) then return result("PARTIAL",self.status) end
 if retry.nextAt and now<retry.nextAt and not explicitWake then return result("PARTIAL",self.status) end
 self.nativeSettings=open
 self.releaseWake=nil;retry.nativeWake=nil
 retry.attempts=retry.attempts+1;retry.lastAttempt=now
 local restored,why=self:RestorePresentation()
 if self.handoffRetry~=retry or not self:Current(retry.generation,retry.profile) then return result("DEFERRED_HANDOFF","ROW_SETUP_SUPERSEDED") end
 if not restored then
  retry.nextAt=handoffDelays[retry.attempts+1] and now+handoffDelays[retry.attempts+1] or nil
  self.status=why or "NATIVE_WIDGET_HANDOFF_PENDING"
  return result("PARTIAL",self.status)
 end
 -- Only completed native handback clears this local latch. Fresh binding,
 -- layout, data readiness and source suppression must still all succeed.
 self.handoffRetry=nil;self.repairBlocked=nil
 self.handoffRecoveries=(self.handoffRecoveries or 0)+1
 self.catalogueDirty=true;self.dataDirty=true;self.sourceDirty=true
 self.status="COOLDOWN_ROW_HANDOFF_COMPLETE"
 return nil
end
function C:Initialize()
 if not chosen() then return false,"NOT_SELECTED" end
 if S:InCombat() then return false,"SETUP_COMBAT_DEFERRED" end
 return true
end
function C:Configure()
 self.setupStage="ADMISSION";self.setupSlot=nil
 self.configureCount=(self.configureCount or 0)+1
 if not chosen() then return self:Suspend("UNSELECTED") end
 if cfg().rowEnabled==false then
  local okay,why=self:Suspend("ROW_DISABLED")
  if okay then self.active=true;self.rowDisabled=true;return result("READY","NATIVE_COOLDOWN_PRESENTATION") end
  return result("DEFERRED_HANDOFF",why)
 end
 self.rowDisabled=nil;self.repairBlocked=nil;self.releaseWake=nil;self.handoffRetry=nil
 local editing=R:NativeEditState()
 if editing=="UNKNOWN" then return result("DEFERRED_HANDOFF","NATIVE_EDIT_UNKNOWN") end
 if editing=="OPEN" then return self:Suspend("NATIVE_EDIT_HANDOFF") end
 if S:InCombat() then return false,"SETUP_COMBAT_DEFERRED" end
 if not M.Layout:Screen() then self.viewportPending=true;self.status="VIEWPORT_PENDING";return result("WAITING",self.status) end
 self.viewportPending=nil;self.generation=(self.generation or 0)+1;self.profile=M.profile;self.active=true
 local generation=self.generation
 self.setupStage="ROW_CREATE"
 if not self:Create() then return false,"ROW_CREATE_PENDING" end
 if self.generation~=generation then return result("DEFERRED_HANDOFF","ROW_SETUP_SUPERSEDED") end
 self.surface.disabled=false
 if settingsOpen() then
  local restored=self:RestorePresentation()
  self.nativeSettings=true;self.presentationReady=false;self:RefreshVisibility()
  if not restored then return result("DEFERRED_HANDOFF","NATIVE_WIDGET_HANDOFF_PENDING") end
  return result("WAITING","NATIVE_COOLDOWN_SETTINGS_OPEN")
 end
 local ok,why=self:Rebuild()
 if self.generation~=generation then return result("DEFERRED_HANDOFF","ROW_SETUP_SUPERSEDED") end
 if not ok then return self:SetupFailure(why) end
 self.setupStage="INITIAL_CONTENT";self.setupSlot=nil
 self:Paint()
 if self.generation~=generation then return result("DEFERRED_HANDOFF","ROW_SETUP_SUPERSEDED") end
 if self.presentationReady then
  self.setupStage="NATIVE_SOURCE_SUPPRESSION"
  local suppressed,reason=self:SuppressSources()
  if not suppressed then return self:SetupFailure(reason) end
 else
  local restored,releaseWhy=self:RestorePresentation()
  if not restored then return result("DEFERRED_HANDOFF",releaseWhy) end
 end
 self.nextProbe=S:Now()+2;self.nativeSettings=settingsOpen()
 if not self.presentationReady then return result("WAITING",self.status) end
 self.setupStage="COMPLETE";self.setupSlot=nil
 return result("READY",self.status)
end
function C:OnViewportReady()
 if self.active then self.layoutDirty=true end
end
function C:OnEvent(event,unit,success)
 if event=="PLAYER_LEAVING_WORLD" then return self:Suspend("WORLD_LEFT") end
 if event=="SPELL_DATA_LOAD_RESULT" then
  if self.spellLoadProfile==M.profile and validID(unit) and self.spellLoads and self.spellLoads[unit]
   and S:Readable(success) and type(success)=="boolean" then
   self.spellLoads[unit]=success and "LOADED" or "FAILED"
   if success and not self.repairBlocked then self.catalogueDirty=true;self.dataDirty=true end
  end
  return
 end
 if event=="ITEM_DATA_LOAD_RESULT" or event=="GET_ITEM_INFO_RECEIVED" then
  if self.itemLoadProfile==M.profile and validID(unit) and self.itemLoads and self.itemLoads[unit]
   and S:Readable(success) and type(success)=="boolean" then
   self.itemLoads[unit]=success and "LOADED" or "FAILED"
   if success and not self.repairBlocked then self.catalogueDirty=true;self.dataDirty=true end
  end
  return
 end
 if event=="UNIT_AURA" and S:Text(unit) and unit~="player" and unit~="target" then return end
 if event=="PLAYER_TARGET_CHANGED" or event=="PLAYER_REGEN_DISABLED" or event=="PLAYER_REGEN_ENABLED" then self:RefreshVisibility() end
 if event=="PLAYER_REGEN_DISABLED" or event=="PLAYER_REGEN_ENABLED" then
  if event=="PLAYER_REGEN_ENABLED" then
   if self.releasePending then self.releaseWake=true end
   self.sourceDirty=true
  end
  -- Combat changes presentation authority, not the tracked spell catalogue.
  -- Structural events received during lockdown already set catalogueDirty.
  return
 end
 if self.repairBlocked then return end
 if event=="SPELL_UPDATE_COOLDOWN" or event=="SPELL_UPDATE_CHARGES" or event=="SPELL_UPDATE_USES" or event=="UNIT_AURA"
  or event=="PLAYER_TARGET_CHANGED" or event=="BAG_UPDATE_COOLDOWN" or event=="BAG_UPDATE_DELAYED" or event=="PLAYER_EQUIPMENT_CHANGED" then
  if self.hasFallback or not self.presentationReady or event=="UNIT_AURA" and self.hasAura then self.dataDirty=true end
  if self.needsRebind then self.catalogueDirty=true end
 else self.catalogueDirty=true end
end
function C:NeedsRuntimeTick(now,combat)
 if not self.active or self.rowDisabled then return false end
 if combat==nil then combat=S:InCombat() end
 if self.repairBlocked then
  if combat then return false end
  local retry=self.handoffRetry
  if retry and not self:Current(retry.generation,retry.profile) then return false end
  return self.releaseWake==true or retry and (self.nativeSettings~=settingsOpen() or retry.nextAt~=nil and now>=retry.nextAt) or false
 end
 if self.releaseWake and not combat then return true end
 if (not combat and (self.catalogueDirty or self.layoutDirty or self.sourceDirty or self.fallbackPending)) or self.dataDirty or self.nativeSettings~=settingsOpen() then return true end
 return now>=(self.nextProbe or 0),.5
end
function C:Tick(now)
 if not self.active then return end
 local generation=self.generation
 if not chosen() then return self:Suspend("UNSELECTED") end
 local editing=R:NativeEditState()
 if editing=="UNKNOWN" then return result("DEFERRED_HANDOFF","NATIVE_EDIT_UNKNOWN") end
 if editing=="OPEN" then return self:Suspend("NATIVE_EDIT_HANDOFF") end
 now=S:Number(now) and now or S:Now()
 if self.repairBlocked and self.handoffRetry then
  local pending=self:ContinueWidgetHandoff(now);if pending then return pending end
 elseif self.repairBlocked then
  if self.releaseWake and not S:InCombat() then return self:SetupFailure(self.status) end
  return result("PARTIAL",self.status)
 end
 local open=settingsOpen()
 if open~=self.nativeSettings then
  self.nativeSettings=open;self.catalogueDirty=true
  if open then
   self:HideTooltip();self.presentationReady=false;self:RestorePresentation()
  else self.dataDirty=true end
 end
 if open then
  if self.releasePending and self.releaseWake and not S:InCombat() then
   self.releaseWake=nil;self:RestorePresentation()
  end
  if self.releasePending then return result(S:InCombat() and "DEFERRED_COMBAT" or "DEFERRED_HANDOFF","NATIVE_WIDGET_HANDOFF_PENDING") end
  return result("WAITING","NATIVE_COOLDOWN_SETTINGS_OPEN")
 end
 local probe=now>=(self.nextProbe or 0)
 if probe then
  self.nextProbe=now+2
  if self.hasFallback then self.dataDirty=true end
  for _,name in ipairs(names) do
   if not self.observedRoots or self.observedRoots[name]~=(_G[name] or false) then self.catalogueDirty=true end
  end
  for _,tile in ipairs(self.tiles) do
   if tile.binding then self:RevalidateBinding(tile.binding) end
  end
 end
 local rebuilt=false
 if self.catalogueDirty and not S:InCombat() then
  local okay,why=self:Rebuild()
  rebuilt=okay
  if self.generation~=generation then return result("DEFERRED_HANDOFF","ROW_SETUP_SUPERSEDED") end
  if not okay then return self:SetupFailure(why) end
 end
 if self.layoutDirty and not S:InCombat() then
  local okay,why=self:ApplyLayout(self.surface);if not okay then return self:SetupFailure(why) end
 end
 local previouslyReady=self.presentationReady
 if self.dataDirty then self:Paint() end
 if self.fallbackPending or not self.presentationReady then
  local restored,releaseWhy=self:RestorePresentation()
  self.fallbackPending=nil
  if not restored then return result(S:InCombat() and "DEFERRED_COMBAT" or "DEFERRED_HANDOFF",releaseWhy) end
 elseif not S:InCombat() and (probe or rebuilt or self.sourceDirty or not previouslyReady) then
  local okay,why=self:SuppressSources();if not okay then return self:SetupFailure(why) end
 end
 self:RefreshVisibility()
 return result(self.presentationReady and "READY" or "WAITING",self.status)
end
function C:Suspend(reason)
 if reason=="INITIALIZE_FAILED" or reason=="PROVIDER_RETRY_FAILED" or reason=="TICK_FAILED" then
  self.failureStage=self.setupStage or "UNKNOWN";self.failureSlot=self.setupSlot;self.failureReason=reason
 end
 self.active=false;self.generation=(self.generation or 0)+1;self.presentationReady=false;self.handoffRetry=nil
 self:HideTooltip()
 local okay,why=self:RestorePresentation()
 if self.frame and S:Frame(self.frame,true) then self.frame:SetShown(self.handoffVisible==true) end
 if okay then
  for _,tile in ipairs(self.tiles) do tile.binding=nil;tile.borrowedTimer=nil end
  self.bridges=setmetatable({},{__mode="k"})
 end
 if self.surface then self.surface.disabled=not self.handoffVisible end
 self.status=okay and (reason or "SUSPENDED") or why
 return okay,why
end
function C:Coverage()
 return self.status.."; row_icons="..tostring(self.count or 0).."; assigned="..tostring(self.assigned or 0)
  .."; unlearned="..tostring(self.unlearned or 0).."; configure="..tostring(self.configureCount or 0).."; timers=NATIVE_WIDGETS_OR_DURATION_OBJECTS_OR_PUBLIC_ITEM_TIMERS; layout="..(cfg().rowSecondary and "TWO_ROWS_SHARED_CONTEXT" or "SINGLE_ROW")
  .."; primary_icons="..tostring(self.primaryCount or 0).."; secondary_icons="..tostring(self.secondaryCount or 0).."; groups="..tostring(#(cfg().groups or {}))
  .."; active_auras="..tostring(self.activeAuras or 0).."; unavailable_sources="..tostring(self.sourceWarnings or 0)
end
function C:Status()
 local slots={}
 local handoff=self.handoffIssue or {}
 local retry=self.handoffRetry
 local placement=M.profile.layouts and M.profile.layouts["Cooldowns.row"] and "CUSTOM_LAYOUT"
  or cfg().rowFollowHUD~=false and "HUD_CONFIGURED_BOTTOM_PLUS_6PX" or "DEFAULT_POSITION"
 for i=1,math.min(self.count or 0,12) do
  local tile=self.tiles[i]
  slots[#slots+1]=i..":"..(tile and (tile.timerStatus or tile.meta and tile.meta.status) or "NOT_CREATED")
 end
 return self:Coverage().."; startup_stage="..(self.setupStage or "NOT_STARTED").."; startup_slot="..tostring(self.setupSlot or 0)
  .."; last_failure_stage="..(self.failureStage or "NONE").."; last_failure_slot="..tostring(self.failureSlot or 0)
  .."; last_failure="..(self.failureReason or "NONE").."; slot_readiness="..table.concat(slots,",")
  .."; duration_contract=PUBLIC_OBJECT_OR_PUBLIC_ITEM_SCALARS; placement="..placement
  .."; layout_readback="..(self.layoutReadback or "NOT_RUN").."; layout_readback_property="..(self.layoutReadbackProperty or "NONE")
  .."; layout_requested="..(self.layoutExpected or "NONE").."; layout_observed_explicit="..(self.layoutObserved or "NONE")
  .."; layout_observed_calculated="..(self.layoutCalculated or "NONE").."; layout_passes="..tostring(self.layoutPasses or 0)
  .."; layout_write_attempts="..tostring(self.layoutWriteAttempts or 0)
  .."; handoff_widgets="..tostring(self.handoffWidgetCount or 0).."; handoff_slot="..tostring(handoff.slot or 0)
  .."; handoff_widget="..(handoff.widget or "NONE").."; handoff_viewer="..(handoff.viewer or "NONE")
  .."; handoff_property="..(handoff.property or "NONE").."; handoff_reason="..(handoff.reason or "NONE")
  .."; handoff_observed="..(handoff.observed or "NONE").."; handoff_passes="..tostring(self.handoffPasses or 0)
  .."; handoff_retry="..(retry and (retry.nextAt and "SCHEDULED" or "WAITING_FOR_NATIVE_CHANGE_OR_RETRY") or "NONE")
  .."; handoff_retry_attempts="..tostring(retry and retry.attempts or 0)
  .."; handoff_recoveries="..tostring(self.handoffRecoveries or 0)
end
function C:Retry()
 self.spellLoads={};self.spellLoadProfile=M.profile;self.itemLoads={};self.itemLoadProfile=M.profile
 self.repairBlocked=nil;self.releaseWake=nil;self.handoffRetry=nil;self.catalogueDirty=true;self.dataDirty=true;self.sourceDirty=true
end
