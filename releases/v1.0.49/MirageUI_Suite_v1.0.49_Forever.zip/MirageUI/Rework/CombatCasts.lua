local _,M=...
local R,S,L,F=M.Rework,M.Safety,M.Rework.CombatLeases,M.Rework.CombatFactory
local pack=L.Pack
local function screen()
 if M.Layout and M.Layout.Screen then return M.Layout:Screen() end
 if M.Managed and M.Managed.Viewport then return M.Managed:Viewport() end
 return L:Public(UIParent,"GetWidth","number"),L:Public(UIParent,"GetHeight","number")
end
local C=F:New("casts","UnderCharacterHUD",{{name="PlayerCastingBarFrame",id="UnderCharacterHUD.nativeCast",
 editable=false,noContext=true,roleOnly=true}})
R.CombatCasts=C
function C.selection(profile)
 local mods=profile and profile.modules
 if not mods then return false end
 for _,id in ipairs({"UnderCharacterHUD","ResourceBars","UnitFrames","Cursor"}) do if F:ModuleEnabled(id,profile) then return true end end
 return false
end
for _,event in ipairs({"UNIT_SPELLCAST_START","UNIT_SPELLCAST_SUCCEEDED","UNIT_SPELLCAST_CHANNEL_START","UNIT_SPELLCAST_EMPOWER_START",
 "UNIT_SPELLCAST_EMPOWER_UPDATE","UNIT_SPELLCAST_STOP","UNIT_SPELLCAST_CHANNEL_STOP","UNIT_SPELLCAST_EMPOWER_STOP",
 "UNIT_SPELLCAST_INTERRUPTED","UNIT_SPELLCAST_FAILED","PLAYER_DEAD","PLAYER_ALIVE","PLAYER_UNGHOST",
 "UNIT_ENTERED_VEHICLE","UNIT_EXITED_VEHICLE","PET_BATTLE_OPENING_START","PET_BATTLE_CLOSE"}) do C.events[event]=true end
local function castParentCurrent(frame,owner,receipt,sealed,restoring)
 if not sealed() or not R:TargetMatched() then return false end
 local parent,state=L:Public(frame,"GetParent")
 if state~="KNOWN" or not sealed() then return false end
 if (not owner.rootParentTracked or parent==owner.rootParent)
  and (not receipt.parentTracked or parent==receipt.nativeParent) then return sealed() end
 -- The exact native player cast is a managed frame. Its documented OnShow
 -- and Edit Mode paths move it between UIParent, its bottom layout container
 -- and the player's frame. Returning the sole showCastbar receipt must not
 -- mistake those native moves for a permanent foreign-owner conflict.
 -- This exception only restores that switch. It grants no new suppression,
 -- changes no geometry and never rebases or discards the original journal.
 if not restoring or S:InCombat() or frame~=_G.PlayerCastingBarFrame
  or receipt.object~=frame or receipt.key~="castEnabled" or #owner.records~=1 or owner.records[1]~=receipt
  or not owner.rootParentTracked or not receipt.parentTracked or owner.rootParent~=receipt.nativeParent then return false end
 local bottom=_G.BottomManagedFrameContainer
 local layout=L:Field(bottom,"BottomManagedLayoutContainer")
 local function nativeParent(value)
  return value~=nil and (value==_G.UIParent or value==_G.PlayerFrame or value==bottom or value==layout)
 end
 if not nativeParent(owner.rootParent) or not nativeParent(parent) or not S:Frame(parent,false)
  or L:Field(frame,"isManagedFrame")~=true or L:Field(frame,"layoutParent")~=bottom or not S:Frame(bottom,false) then return false end
 local attached=L:Field(frame,"attachedToPlayerFrame")
 local ignored=L:Field(frame,"ignoreFramePositionManager")
 if attached~=nil and type(attached)~="boolean" or ignored~=nil and type(ignored)~="boolean" then return false end
 if parent==_G.PlayerFrame then
  if attached~=true or ignored~=true then return false end
 elseif parent==_G.UIParent then
  if attached==true then return false end
 else
  local onBottom=L:Field(frame,"layoutOnBottom")
  if onBottom~=nil and type(onBottom)~="boolean" then return false end
  if attached==true or ignored==true or parent~=(onBottom and layout or bottom)
   or L:Public(frame,"IsInDefaultPosition","boolean")~=true then return false end
 end
 local after,afterState=L:Public(frame,"GetParent")
 return afterState=="KNOWN" and after==parent and sealed()
end
local function setCastEnabled(frame,values)
 -- This setter has two native phases. A synchronous native posthook can
 -- retire custody during the first; never dispatch resync under that old lease.
 local row=C.roots.PlayerCastingBarFrame;local owner=row and row.leaseOwner
 local lookup=owner and owner.lookup;local entries=lookup and lookup[frame]
 local receipt=entries and entries.castEnabled
 if not receipt then return false end
 local providerGeneration,ownerGeneration=C.generation,owner.generation
 local original,setter,getter=receipt.original,receipt.set,receipt.get
 local function sealed()
  return R.CombatCasts==C and C.roots.PlayerCastingBarFrame==row and row.frame==frame and row.leaseOwner==owner
   and frame==_G.PlayerCastingBarFrame and C.generation==providerGeneration and owner.generation==ownerGeneration
   and owner.lookup==lookup and lookup[frame]==entries and entries.castEnabled==receipt
   and receipt.original==original and receipt.set==setter and receipt.get==getter
 end
 local function current()
  return castParentCurrent(frame,owner,receipt,sealed,values[1]==original[1])
 end
 if not current() then return false end
 local previousRefresh=C.nativeRefresh
 local refresh
 if values[1] then refresh={frame=frame};C.nativeRefresh=refresh end
 local result=frame:SetAndUpdateShowCastbar(values[1])
 if result==false or not current() then return false end
 if values[1] then
  -- Native UpdateIsShown only replays self.casting. A channel instead sets
  -- casting=nil/channeling=true, so the switch alone hides that fallback.
  -- The reviewed native world-entry handler rebuilds either current lifetime.
  local event=L:Field(frame,"OnEvent")
  if type(event)~="function" or C.nativeRefresh~=refresh or not current() then return false end
  local delivered=event(frame,"PLAYER_ENTERING_WORLD")
  if delivered==false or not current() then return false end
  if C.nativeRefresh==refresh then C.nativeRefresh=nil end
 elseif previousRefresh and C.nativeRefresh==previousRefresh and previousRefresh.frame==frame then
  C.nativeRefresh=nil
 end
 return result
end
function C:ReturnNativePlayerCast()
 -- Emergency restoration is only for this source-qualified, exact native
 -- switch receipt. It does not make generic protected cleanup legal in combat.
 local row=self.roots.PlayerCastingBarFrame;local frame=row and row.frame
 local owner=row and row.leaseOwner
 local lookup=owner and owner.lookup
 local entries=lookup and lookup[frame]
 local receipt=entries and entries.castEnabled
 if not receipt then
  if self.nativeRefresh and self.nativeRefresh.frame==frame then self.nativeReturn="NATIVE_CAST_REFRESH_DEBT";return false end
  self.nativeReturn="NO_NATIVE_SWITCH_LEASE";return true
 end
 local providerGeneration,ownerGeneration=self.generation,owner.generation
 local originalValues,setter,getter=receipt.original,receipt.set,receipt.get
 local function retained()
  return R.CombatCasts==self and self.roots.PlayerCastingBarFrame==row and row.leaseOwner==owner
   and row.frame==frame and receipt.object==frame and receipt.key=="castEnabled"
   and self.generation==providerGeneration and owner.generation==ownerGeneration
   and owner.lookup==lookup and lookup[frame]==entries and entries.castEnabled==receipt
   and receipt.original==originalValues and receipt.set==setter and receipt.get==getter
 end
 local function sealed() return retained() and frame==_G.PlayerCastingBarFrame end
 local function current()
  return castParentCurrent(frame,owner,receipt,sealed,true)
 end
 if not retained() then self.nativeReturn="NATIVE_CAST_CUSTODY_CHANGED";return false end
 local original=receipt.original and receipt.original[1]
 local value=L:Field(frame,"showCastbar")
 if not retained() then self.nativeReturn="NATIVE_CAST_CUSTODY_CHANGED";return false end
 if type(original)~="boolean" or type(value)~="boolean" then self.nativeReturn="NATIVE_CAST_SWITCH_UNREADABLE";return false end
 local refreshPending=self.nativeRefresh and self.nativeRefresh.frame==frame
 -- Native handback can restore this switch before returning the frame to
 -- another parent (or replacing the global source). A retained receipt whose
 -- original value is already observed needs no write and no old custody.
 -- Keep a separate resync ticket authoritative: original=true alone cannot
 -- certify an interrupted native channel/cast refresh.
 if value==original and not refreshPending then self.nativeReturn="NATIVE_SWITCH_RESTORED";return true end
 if not current() then self.nativeReturn="NATIVE_CAST_CUSTODY_CHANGED";return false end
 if value~=original and value~=(receipt.written and receipt.written[1]) and value~=(receipt.attempt and receipt.attempt[1]) then
  self.nativeReturn="NATIVE_CAST_EXTERNAL_SWITCH";return false
 end
 if not S:Frame(frame,S:InCombat()) then self.nativeReturn="NATIVE_CAST_RETURN_DEFERRED";return false end
 if not current() then self.nativeReturn="NATIVE_CAST_CUSTODY_CHANGED";return false end
 self.castRoleCommitted=nil
 if M.Presentation then M.Presentation:RefreshHUD() end
 if not current() then self.nativeReturn="NATIVE_CAST_CUSTODY_CHANGED";return false end
 receipt.attempt=receipt.original
 local ok,result=pcall(setter,frame,originalValues)
 local after=L:Field(frame,"showCastbar")
 if not current() then self.nativeReturn="NATIVE_CAST_CUSTODY_CHANGED";return false end
 if type(after)=="boolean" then receipt.written=pack(after) end
 if not ok or result==false or after~=original then
  receipt.pending=true;self.nativeReturn="NATIVE_CAST_RETURN_PENDING";return false
 end
 -- Leave the journal intact. The normal release verifies and retires it once
 -- combat permits the complete provider handback; no restoration debt is lost.
 self.nativeReturn="NATIVE_SWITCH_RESTORED";return true
end
local releaseCastRoot=C.ReleaseRoot
function C:ReleaseRoot(row,...)
 if row.spec.name=="PlayerCastingBarFrame" and not self:ReturnNativePlayerCast() then
  row.leaseBlocked=true
  self:RootState(row,"DEFERRED_HANDOFF",self.nativeReturn or "NATIVE_CAST_RETURN_PENDING")
  return false,S:InCombat() and "COMBAT_LOCKDOWN" or self.nativeReturn or "NATIVE_CAST_RETURN_PENDING"
 end
 return releaseCastRoot(self,row,...)
end
function C:OwnsPlayerCast()
 local row=self.roots.PlayerCastingBarFrame
 if not self.active or not R:Selected("casts") or M.state.safe or not row or row.leaseBlocked
  or row.frame~=_G.PlayerCastingBarFrame or self.castRoleProfile~=M.profile
  or self.castRoleGeneration~=self.generation or self.castRoleCommitted~=true then return false end
 local owner=row.leaseOwner
 return owner and owner.active and owner.parentGeneration==self.generation
  and L:Field(row.frame,"showCastbar")==false and L:Public(row.frame,"IsShown","boolean")==false
  and M.Presentation:Available("UnderCharacterHUD","cast") or false
end
function C:Role(frame)
 local allowed,reason=M.Presentation:Allows("Native","cast")
 self.requestedOwner=M.Presentation:CastOwner(M.profile)
 local hud=M.UnderCharacterHUD
 local context
 self.hudAvailabilityReason="NOT_OBSERVED"
 if hud and type(hud.CastAvailable)=="function" then
  local ok,available,why=pcall(hud.CastAvailable,hud)
  self.hudAvailabilityReason=ok and why or "CAST_AVAILABILITY_UNAVAILABLE"
  if ok and available==false and (why=="PLAYER_DEAD" or why=="VEHICLE" or why=="PET_BATTLE" or why=="WORLD_UNAVAILABLE")
   and M.Presentation:Configured(M.profile,"UnderCharacterHUD","cast") and M:IsModuleActive("UnderCharacterHUD") then context=why end
 end
 self.role=allowed and "NATIVE_FALLBACK" or "MIRAGE_PLAYER_CAST"
 self.roleReason=reason
 self.castRoleCommitted=nil
 local flag=L:Field(frame,"showCastbar")
 if type(flag)~="boolean" or type(L:Field(frame,"SetAndUpdateShowCastbar"))~="function" then
  self.role="NATIVE_FALLBACK";self.roleReason="NATIVE_CAST_SWITCH_UNAVAILABLE"
  return L:Gap(self,"castEnabled","NATIVE_CAST_SWITCH_UNAVAILABLE")
 end
 if type(L:Field(frame,"OnEvent"))~="function" then
  -- Source-qualified channel restoration requires this native resync entry.
  -- Never acquire a switch without its complete inverse contract available.
  self.role="NATIVE_FALLBACK";self.roleReason="NATIVE_CAST_REFRESH_UNAVAILABLE"
  return L:Gap(self,"castEnabled","NATIVE_CAST_REFRESH_UNAVAILABLE")
 end
 local lease=L:Owner(self,frame)
 local receipt=lease.lookup and lease.lookup[frame] and lease.lookup[frame].castEnabled
 if not allowed and not S:Frame(frame,true) then
  -- Do not acquire a switch whose native tree would make an ordinary combat
  -- fallback illegal. Exact protection observations remain a hard boundary.
  self.role="NATIVE_FALLBACK";self.roleReason="NATIVE_CAST_TREE_UNSAFE"
  return L:Gap(self,"castEnabled","NATIVE_CAST_TREE_UNSAFE")
 end
 local written=true
 if not allowed or receipt then
  local wanted=allowed and receipt.original[1] or false
  -- Retain the exact original switch; do not unregister native cast events or
  -- interfere with PetCastingBarFrame, target/focus casts, or native lifetimes.
  written=L:Write(self,frame,"castEnabled",function(x)
   local v=L:Field(x,"showCastbar");if type(v)~="boolean" then return nil end;return pack(v)
  end,setCastEnabled,pack(wanted),
   not wanted and L:Public(frame,"IsShown","boolean")==true)
 end
 self.castRoleProfile=M.profile;self.castRoleGeneration=self.generation
 self.castRoleCommitted=not allowed and written and L:Field(frame,"showCastbar")==false
  and L:Public(frame,"IsShown","boolean")==false or false
 if not allowed and written and not self.castRoleCommitted then
  written=false;L:Gap(self,"castEnabled","NATIVE_CAST_VISIBILITY_UNCONFIRMED")
 end
 if not written then self.role="CAST_HANDOFF_PENDING" end
 if allowed and self.requestedOwner=="UnderCharacterHUD" then
  if written and context then
   -- Death, vehicles and pet battles deliberately return the native cast.
   -- A complete native return is healthy contextual standby, not a failed
   -- custom widget. Never let this classification conceal a failed inverse.
   self.role="NATIVE_CONTEXT";self.roleReason=context;return true
  end
  if not written then return false end
  -- Native access is healthy fallback, but it is not proof that the requested
  -- sole custom cast is operational. Preserve that local readiness boundary.
  return L:Gap(self,"castEnabled",reason or "CAST_PRIMARY_UNAVAILABLE_NATIVE_RETAINED")
 end
 return written
end
function C:Skin(row)
 self:Role(row.frame)
 -- No fallback re-skin or geometry ownership: if replacement readiness fails,
 -- the original native player cast is the single complete fallback immediately.
 -- Native reset hooks enqueue this one role even when the native bar is hidden.
 for _,method in ipairs({"Show","SetAndUpdateShowCastbar","UpdateShownState"}) do
  L:Hook(self,row.frame,method,function()
   self:MarkRoot(row,"role")
   if L:Public(row.frame,"IsShown","boolean")==true then
    self.castRoleCommitted=nil
    if M.Presentation then M.Presentation:RefreshHUD() end
   end
  end)
 end
 if M.Presentation then M.Presentation:Refresh() end
end
local castEvent=C.OnEvent
function C:OnEvent(event,unit)
 if event:sub(1,5)=="UNIT_" and (not S:Text(unit) or unit~="player") then return end
 castEvent(self,event,unit)
 if self.active and event~="PLAYER_LEAVING_WORLD" then
  local row=self.roots.PlayerCastingBarFrame
  if row then self:MarkRoot(row,"role") end
 end
end
local castSuspend=C.Suspend
function C:Suspend(reason)
 self:ReturnNativePlayerCast()
 self.castRoleCommitted=nil
 local ok,why=castSuspend(self,reason)
 if M.Presentation then M.Presentation:Refresh() end
 return ok,why
end
local status=C.Status
function C:Status()
 local frame=_G.PlayerCastingBarFrame
 local nativeShown=L:Public(frame,"IsShown","boolean")
 local nativeEnabled=L:Field(frame,"showCastbar")
 local hud=M.UnderCharacterHUD;local bar=hud and hud.view and hud.view.rows.cast
 local customShown=L:Public(bar,"IsShown","boolean")
 local preference=M.profile and M.profile.presentation
 local function publicFlag(value) return type(value)=="boolean" and (value and "true" or "false") or "UNAVAILABLE" end
 return status(self).."; role="..(self.role or "PENDING").."; role_reason="..(self.roleReason or "NOT_OBSERVED")
  .."; requested_owner="..(self.requestedOwner or M.Presentation:CastOwner(M.profile))
  .."; saved_cast_mirror="..publicFlag(preference and preference.castMirror)
  .."; hud_prepared="..publicFlag(M.Presentation:Available("UnderCharacterHUD","cast"))
  .."; hud_context="..(self.hudAvailabilityReason or "NOT_OBSERVED")
  .."; native_enabled="..publicFlag(nativeEnabled).."; native_shown="..publicFlag(nativeShown).."; custom_shown="..publicFlag(customShown)
  .."; native_return="..(self.nativeReturn or "NOT_REQUESTED")
  .."; exclusive="..(self:OwnsPlayerCast() and "SWITCH_CONFIRMED" or "NATIVE_FALLBACK_OR_PENDING")
end

local specs={
 {name="StatusTrackingBarManager",id="NativeControls.progression",module="ActionBars",editable=false},
 {name="MainStatusTrackingBarContainer",id="NativeControls.MainStatusTrackingBarContainer",module="ActionBars",noContext=true,resize=true,prepareHidden=true,
  layout={x=.38,y=-.39,width=225,height=20,scale=1}},
 {name="SecondaryStatusTrackingBarContainer",id="NativeControls.SecondaryStatusTrackingBarContainer",module="ActionBars",noContext=true,resize=true,prepareHidden=true,
  layout={x=.38,y=-.37,width=225,height=20,scale=1}},
 {name="MirrorTimerContainer",module="Notifications",editable=false,safety=true,prepareHidden=true},
 {name="DurabilityFrame",module="Notifications",editable=false,safety=true,prepareHidden=true},
 {name="UIErrorsFrame",module="Notifications",editable=false,safety=true},
 {name="DeadlyDebuffFrame",module="Notifications",editable=false,safety=true}}
local A=F:New("alerts","Notifications",specs);R.CombatAlerts=A
A.layoutIDs["Notifications.durability"]=true
local alertApplyLayout=A.ApplyLayout
function A:ApplyLayout(surface,...)
 if surface and surface.id=="Notifications.durability" and R.DurabilityDisplay then return R.DurabilityDisplay:ApplyLayout() end
 return alertApplyLayout(self,surface,...)
end
local alertBounds=A.Bounds
function A:Bounds(id,...)
 if id=="Notifications.durability" and R.DurabilityDisplay then return R.DurabilityDisplay:Bounds() end
 return alertBounds(self,id,...)
end
local alertReleaseRoot=A.ReleaseRoot
function A:ReleaseRoot(row,...)
 if row.spec.name=="DurabilityFrame" and R.DurabilityDisplay then R.DurabilityDisplay:Stop(self,row) end
 return alertReleaseRoot(self,row,...)
end
local progressNames={"MainStatusTrackingBarContainer","SecondaryStatusTrackingBarContainer"}
local progressContainers={MainStatusTrackingBarContainer=true,SecondaryStatusTrackingBarContainer=true}
function A:ProgressContents(frame)
 -- The source manager preallocates every progression template in both roots.
 -- Only GetShownBar() and the explicit pending index identify live content;
 -- hidden prototype geometry is not a prerequisite for showing player XP.
 if not S:Frame(frame,false) then return nil,"NATIVE_CONTAINER_UNAVAILABLE" end
 local getter=L:Field(frame,"GetShownBar")
 if type(getter)~="function" then return nil,"NATIVE_SELECTION_UNAVAILABLE" end
 local okay,current=pcall(getter,frame)
 if not okay or not S:Readable(current) or current~=nil and not S:Frame(current,false) then return nil,"NATIVE_SELECTION_UNAVAILABLE" end
 local result={};if current then result[1]=current end
 local pendingKnown,index=pcall(function() return frame.pendingBarToShowIndex end)
 if not pendingKnown or not S:Readable(index) then return nil,"NATIVE_PENDING_UNAVAILABLE" end
 if index~=nil then
  local bars=L:Field(frame,"bars")
  if not S:Number(index) or not S:Readable(bars) or type(bars)~="table" then return nil,"NATIVE_PENDING_UNAVAILABLE" end
  local found,pending=pcall(function() return bars[index] end)
  if not found or not S:Readable(pending) or pending~=nil and not S:Frame(pending,false) then return nil,"NATIVE_PENDING_UNAVAILABLE" end
  if pending and pending~=current then result[#result+1]=pending end
 end
 return result,#result>0 and "NATIVE_CONTENT_ACTIVE" or "NATIVE_CONTENT_EMPTY"
end
local registerAlert=A.Register
function A:Register(spec,frame)
 local row,why=registerAlert(self,spec,frame)
 if row and row.surface and progressContainers[spec.name] then
  -- One parent gate owns the entire progress pair. Child surfaces remain in
  -- the layout catalog, but cannot create competing visibility/effect scopes.
  row.surface.contextDelegate="NativeControls.progression"
 end
 return row,why
end
local resolveAlertLayout=A.ResolveLayout
function A:ResolveLayout(surface,profile)
 local l=resolveAlertLayout(self,surface,profile)
 if surface.id=="NativeControls.MainStatusTrackingBarContainer" or surface.id=="NativeControls.SecondaryStatusTrackingBarContainer" then
  profile=profile or M.profile
  if M.SidebarLayout and type(M.SidebarLayout.ProgressLayout)=="function" then
   local shared=M.SidebarLayout:ProgressLayout(surface.id,profile)
   if shared then return shared end
  elseif profile.autoLayout then
   local w,h=screen()
   if w and h and w>0 and h>0 then
    local width=225
    l={width=width,height=20,scale=1,x=.5-(width/2+18)/w,
     y=.5-(surface.id=="NativeControls.MainStatusTrackingBarContainer" and 420 or 434)/h}
   end
  end
 end
 return l
end
local function progressGeometry(self,row)
 if not row or not row.surface then return false,"ROOT_UNAVAILABLE" end
 if row.frame~=_G[row.spec.name] then return false,"ROOT_REPLACED" end
 if row.leaseBlocked or row.leaseRepair then return false,"CUSTODY_REPAIR_PENDING" end
 if row.paintBlocked then return false,"PAINT_RETRY_REQUIRED" end
 -- PaintRoot owns the live failure state and clears it after any successful
 -- native-event repaint. A separate reveal-only latch survives that recovery
 -- and can keep an already-repaired sidebar hidden indefinitely.
 if row.paintReason then return false,"PAINT_PENDING" end
 -- A native XP/reputation update can change the selected bar's pixels and
 -- label without changing its container rectangle. Do not expose yesterday's
 -- paint merely because the authored root anchors still match.
 if row.dirty and (row.dirty.style or row.dirty.content) then return false,"NATIVE_PRESENTATION_PENDING" end
 if row.surface.layoutPending then return false,"LAYOUT_WRITE_PENDING" end
 if row.dirty and row.dirty.geometry then return false,"NATIVE_LAYOUT_CHANGED" end
 local frame=row.frame;local l=self:ResolveLayout(row.surface)
 local w,h=screen()
 if not w or not h or w<=0 or h<=0 then return false,"VIEWPORT_PENDING" end
 local scale=l.scale or 1;local divisor=M.profile.managed and scale or 1
 local points,ps=L:Public(frame,"GetNumPoints","number")
 local pointMethod=L:Field(frame,"GetPoint")
 if type(pointMethod)~="function" then return false,"ANCHOR_UNAVAILABLE" end
 local ok,a,b,c,x,y=pcall(pointMethod,frame,1)
 if ps~="KNOWN" or points~=1 or not ok or not S:Text(a) or not S:Readable(b) or not S:Text(c)
  or not S:Number(x) or not S:Number(y) or a~="CENTER" or b~=UIParent or c~="CENTER"
  or not L:GeometryEqual(x,l.x*w/divisor) or not L:GeometryEqual(y,l.y*h/divisor) then return false,"ANCHOR_UNCONFIRMED" end
 local actualScale,ss=L:Public(frame,"GetScale","number")
 local width,ww=L:Public(frame,"GetWidth","number",true);local height,hh=L:Public(frame,"GetHeight","number",true)
 if ss~="KNOWN" or not L:GeometryEqual(actualScale,scale) then return false,"SCALE_UNCONFIRMED" end
 if ww~="KNOWN" or hh~="KNOWN" or not L:GeometryEqual(width,l.width) or not L:GeometryEqual(height,l.height) then return false,"SIZE_UNCONFIRMED" end
 return true,"READY"
end
local function publicXPPercent(bar)
 if L:Field(bar,"isExpBar")~=true then return nil,"NATIVE_CAPTION" end
 if type(L:Field(bar,"IsCapped"))=="function" then
  local capped,state=L:Public(bar,"IsCapped","boolean")
  if state~="KNOWN" or capped then return nil,"NATIVE_XP_FILL_TOOLTIP_NO_PUBLIC_PERCENT" end
 end
 local method=L:Field(bar,"GetLevelData")
 if type(method)~="function" then return nil,"NATIVE_XP_FILL_TOOLTIP_NO_PUBLIC_PERCENT" end
 local ok,current,maximum=pcall(method,bar)
 if not ok or not S:Number(current) or not S:Number(maximum) or current<0 or maximum<=0 or current>maximum then
  return nil,"NATIVE_XP_FILL_TOOLTIP_NO_PUBLIC_PERCENT"
 end
 return string.format("%d%%",math.floor(current/maximum*100)),"PUBLIC_XP_PERCENT_NATIVE_FILL_TOOLTIP"
end
local function progressArtHidden(object)
 return not object or L:Public(object,"GetAlpha","number")==0
end
function A:ProgressChromeReady(frame,contents)
 -- Native border/divider pixels are independent of the fill and caption.
 -- A correct percentage alone cannot certify the completed presentation.
 if not progressArtHidden(L:Field(frame,"BarFrameTexture")) then return false,"NATIVE_BORDER_PENDING" end
 local pool=L:Field(frame,"HorizontalDividersPool")
 if pool then
  local enumerate=L:Field(pool,"EnumerateActive")
  if type(enumerate)~="function" then return false,"NATIVE_DIVIDERS_UNAVAILABLE" end
  local okay,hidden=pcall(function()
   local count=0
   for divider in enumerate(pool) do
    count=count+1
    if count>64 or not S:Frame(divider,false) or not progressArtHidden(L:Field(divider,"BarDividerTexture")) then return false end
   end
   return true
  end)
  if not okay or not hidden then return false,"NATIVE_DIVIDERS_PENDING" end
 end
 for _,bar in ipairs(contents or {}) do
  if L:Field(bar,"isExpBar")==true then
   local status=L:Field(bar,"StatusBar")
   for _,art in ipairs({{bar,"ExhaustionLevelFillBar"},{bar,"ExhaustionTick"},{status,"Underlay"},{status,"Overlay"}}) do
    if art[1] and not progressArtHidden(L:Field(art[1],art[2])) then return false,"NATIVE_XP_ART_PENDING" end
   end
   if not progressArtHidden(L:Path(bar,"OverlayFrame","Text")) then return false,"NATIVE_XP_CAPTION_PENDING" end
  end
 end
 return true,"NATIVE_CHROME_HIDDEN"
end
function A:HideProgressArt(object)
 if not object then return end
 L:Alpha(self,object,0)
 -- A native pool reset or delayed update may reauthor alpha after our first
 -- paint. Queue a scoped repaint; never write inside its native callback.
 L:Hook(self,object,"SetAlpha")
end
function A:ProgressContentReady(row,contents)
 if not row then return false,"ROOT_UNAVAILABLE" end
 contents=contents or self:ProgressContents(row.frame)
 if not contents then return false,"NATIVE_SELECTION_UNAVAILABLE" end
 local chrome,chromeWhy=self:ProgressChromeReady(row.frame,contents)
 if not chrome then return false,chromeWhy end
 for _,bar in ipairs(contents) do
  local receipt=self.progressContent and self.progressContent[bar]
  local status=L:Field(bar,"StatusBar")
  if not receipt or not receipt.painted or receipt.frame~=row.frame or receipt.status~=status
   or receipt.profile~=M.profile or receipt.generation~=self.generation then return false,"SELECTED_CONTENT_NOT_PAINTED" end
  if not S:Frame(status,false) or L:Public(status,"GetParent")~=bar then return false,"NATIVE_FILL_IDENTITY_CHANGED" end
  local isXP=L:Field(bar,"isExpBar")==true
  local width=L:Public(row.frame,"GetWidth","number",true);local height=L:Public(row.frame,"GetHeight","number",true)
  if not width or not height or not L:GeometryEqual(L:Public(status,"GetWidth","number",true),isXP and width or math.max(1,width-2))
   or not L:GeometryEqual(L:Public(status,"GetHeight","number",true),isXP and math.min(10,height-2) or height-2) then return false,"NATIVE_FILL_GEOMETRY_PENDING" end
  local expected,mode=publicXPPercent(bar)
  if receipt.readoutMode~=mode or receipt.percent~=expected then return false,"SELECTED_CONTENT_CHANGED" end
  if expected then
   local panel=receipt.panel;local label=panel and panel.progressPercent
   if not S:Frame(panel,false) or not S:Frame(label,false) or L:Public(panel,"GetParent")~=bar
    or L:Public(label,"GetParent")~=panel or L:Public(label,"GetText","string")~=expected
    or L:Public(panel,"IsShown","boolean")~=true or L:Public(label,"IsShown","boolean")~=true
    or L:Public(panel,"GetAlpha","number")~=1 or L:Public(label,"GetAlpha","number")~=1 then return false,"XP_READOUT_PENDING" end
  end
 end
 return true,"SELECTED_CONTENT_READY"
end
function A:ProgressionReady()
 if not self.active or not R:Selected(self.id) or M.state.safe then return false,"INACTIVE" end
 if self.preparingProgression then return false,"PREPARING" end
 if R:NativeEditState()~="CLOSED" then return false,"NATIVE_EDIT_HANDOFF" end
 local profile,generation=M.profile,self.generation
 local manager=self.roots.StatusTrackingBarManager
 if not manager or manager.frame~=_G.StatusTrackingBarManager then return false,"MANAGER_UNAVAILABLE" end
 if manager.leaseBlocked or manager.leaseRepair then return false,"MANAGER_CUSTODY_PENDING" end
 if manager.contextUnavailable or not manager.contextGate then return false,"MANAGER_GATE_PENDING" end
 local context=M.ContextualNative
 if not context or not context.OwnedReady or not context:OwnedReady(self,"StatusTrackingBarManager") then return false,"MANAGER_GATE_PENDING" end
 local found,active=0,0
 for _,name in ipairs(progressNames) do
  if _G[name]~=nil then
   found=found+1
   local contents,selection=self:ProgressContents(_G[name])
   local prefix=name==progressNames[1] and "MAIN:" or "SECONDARY:"
   if not contents then return false,prefix..selection end
   if #contents>0 then
    active=active+1
    local ready,why=progressGeometry(self,self.roots[name])
    if not ready then return false,prefix..why end
    local contentReady,contentWhy=self:ProgressContentReady(self.roots[name],contents)
    if not contentReady then return false,prefix..contentWhy end
   end
  end
 end
 if found==0 then return false,"NATIVE_CONTENT_UNAVAILABLE" end
 if M.profile~=profile or self.generation~=generation or self.active~=true then return false,"OWNER_CHANGED" end
 self.progressionActiveRoots=active
 return true,active>0 and "READY" or "NATIVE_CONTENT_EMPTY"
end
function A:ProgressionReadback(ready)
 local pending=ready~=true
 if self.progressionWithheld~=pending then self.progressionHealthPending=true;M.state.forceEvaluate=true end
 self.progressionWithheld=pending;self.progressionProfile=M.profile;self.progressionGeneration=self.generation
 self.progressionLayout=ready and "SIDEBAR_READY" or "SIDEBAR_REPAIR_PENDING"
 local manager=self.roots.StatusTrackingBarManager
 if manager then
  if ready or manager.leaseBlocked or manager.leaseRepair or manager.contextUnavailable then self:RefreshRootHealth(manager)
  else self:RootState(manager,"PARTIAL","SIDEBAR_LAYOUT_PENDING") end
 end
end
function A:PrepareProgressionReveal()
 if self:ProgressionReady() then self:ProgressionReadback(true);return true end
 if S:InCombat() or R:NativeEditState()~="CLOSED" or self.preparingProgression or not self.active or not R:Selected(self.id) or M.state.safe then return false end
 local profile,generation=M.profile,self.generation
 self.preparingProgression=true
 local ok=pcall(function()
  -- Repair actual native content before reveal. An unused secondary root
  -- keeps its independent repair/diagnostic state and cannot veto healthy XP.
  for _,name in ipairs(progressNames) do
   if M.profile~=profile or self.generation~=generation or S:InCombat() or R:NativeEditState()~="CLOSED" or not self.active then return end
   local row=self.roots[name]
   local contents=row and row.frame==_G[name] and self:ProgressContents(row.frame)
   if contents and #contents>0 and not row.leaseBlocked and not row.leaseRepair and not row.paintBlocked
    and (not progressGeometry(self,row) or not self:ProgressContentReady(row,contents)) then
    local dirty=row.dirty
    local needsLayout=row.surface.layoutPending or dirty and dirty.geometry
    local geometryReason=select(2,progressGeometry(self,row))
    needsLayout=needsLayout or geometryReason~="READY" and geometryReason~="NATIVE_PRESENTATION_PENDING"
    local sent,applied=true,true
    if needsLayout then
     local before=self.painting;self.painting=true
     sent,applied=pcall(self.ApplyLayout,self,row.surface)
     self.painting=before
    end
    if sent and applied and M.profile==profile and self.generation==generation and not S:InCombat() then
     -- Consume only the captured work. A native callback may publish a newer
     -- dirty table while the painter runs; that successor must remain queued.
     if row.dirty==dirty then row.dirty={} end
     local painted=self:PaintRoot(row)
     if not painted and row.dirty then
      for kind,value in pairs(dirty or {}) do if value then row.dirty[kind]=true end end
     end
    end
   end
  end
  local manager=self.roots.StatusTrackingBarManager
  if manager and manager.frame==_G.StatusTrackingBarManager then self:ProgressHover(manager) end
 end)
 self.preparingProgression=nil
 local ready=ok and M.profile==profile and self.generation==generation and self:ProgressionReady()
 -- Refused out-of-combat repair is diagnostic debt. Profile retirement or a
 -- combat edge is not evidence of a failed native presentation.
 if M.profile==profile and self.generation==generation and self.active and not S:InCombat() and R:NativeEditState()=="CLOSED" then self:ProgressionReadback(ready) end
 return ready
end
function A:StartupPrepared()
 -- Local preparation evidence only; there is no global startup barrier.
 return self:ProgressionReady()
end
local configureAlert=A.Configure
function A:Configure()
 local result,why=configureAlert(self)
 -- Gate acquisition can request a reveal before the children are registered.
 -- Publish the completed readback after the existing transaction, so a healthy
 -- first setup does not retain that intermediate pending status until a tick.
 if self:ProgressionReady() then self:ProgressionReadback(true) end
 -- Native first-world layout/fade work completes after initial configuration.
 -- Verify a bounded set of later turns even if the player never moves/hovers.
 if self.active then self.progressStartupCheck={profile=M.profile,generation=self.generation,step=1,at=S:Now()+.05} end
 return result,why
end
local alertNeedsRuntimeTick=A.NeedsRuntimeTick
function A:NeedsRuntimeTick(now,combat)
 if self.active and self.progressionHealthPending and not combat then return true end
 local check=self.progressStartupCheck
 if self.active and check and not combat and now>=check.at then return true end
 return alertNeedsRuntimeTick(self,now,combat)
end
local alertTick=A.Tick
function A:Tick(now)
 local check=self.progressStartupCheck
 if check and self.active and not S:InCombat() and now>=check.at then
  local function current()
   return self.progressStartupCheck==check and check.profile==M.profile and check.generation==self.generation and self.active and not S:InCombat()
  end
  if current() then
   for _,name in ipairs(progressNames) do
    if not current() then break end
    local row=self.roots[name]
    local contents=row and self:ProgressContents(row.frame)
    if not current() then break end
    if contents then
     local chrome=self:ProgressChromeReady(row.frame,contents)
     if not current() then break end
     local content=#contents==0 or self:ProgressContentReady(row,contents)
     if not current() then break end
     if not chrome or not content then self:MarkRoot(row,"style") end
    end
   end
   if current() then
    check.step=check.step+1
    if check.step<=4 then check.at=now+({.05,.20,.50,.75})[check.step] else self.progressStartupCheck=nil end
   end
  elseif self.progressStartupCheck==check then self.progressStartupCheck=nil end
 end
 local result,why=alertTick(self,now)
 self.progressionHealthPending=nil
 if self.active and not S:InCombat() and self.progressionWithheld
  and self.progressionProfile==M.profile and self.progressionGeneration==self.generation then
  if self:ProgressionReady() then self:ProgressionReadback(true);self.progressionHealthPending=nil
  else
   local kind=R:ResultKind(result,why,self)
   self:ProgressionReadback(false);self.progressionHealthPending=nil
   if kind~="FAULT" and kind~="CONFLICT" and kind~="DEFERRED_HANDOFF" and kind~="DEFERRED_COMBAT" then
    return R:Result("PARTIAL","SIDEBAR_LAYOUT_PENDING","NativeControls.progression")
   end
  end
 end
 return result,why
end
function A.selection(profile)
 local modules=profile and profile.modules
 return modules and (F:ModuleEnabled("Notifications",profile) or F:ModuleEnabled("ActionBars",profile)) or false
end
for _,event in ipairs({"MIRROR_TIMER_START","MIRROR_TIMER_STOP","UPDATE_INVENTORY_DURABILITY","UPDATE_INVENTORY_ALERTS","PLAYER_EQUIPMENT_CHANGED","PLAYER_XP_UPDATE","UPDATE_EXHAUSTION","UPDATE_FACTION","PLAYER_LEVEL_UP","PLAYER_MAX_LEVEL_UPDATE"}) do A.events[event]=true end
local timerAtlases={["ui-castingbar-background"]="panel"}
function A:Durability(frame)
 local row=self.roots and self.roots.DurabilityFrame
 if row and row.frame==frame and R.DurabilityDisplay then
  local okay,why=R.DurabilityDisplay:Skin(self,row)
  -- Native fallback remains accessible while this one presentation waits.
  -- Its refusal must remain visible to per-root health; a nonthrowing false
  -- result is not proof that the custom warning has been prepared.
  if not okay and why~="DURABILITY_SCOPE_RETIRED" then L:Gap(self,"durability",why or "DURABILITY_PRESENTATION_PENDING") end
  return okay,why
 end
 -- Without the qualified custom component, keep the original warning intact.
end
local function progressOriginalAlpha(owner,label)
 local byObject=owner.lookup and owner.lookup[label]
 local receipt=byObject and byObject.alpha
 return receipt and receipt.original and receipt.original[1]
end
function A:ProgressReadout(bar,status,width,height)
 if S:InCombat() then return false end
 local label=L:Path(bar,"OverlayFrame","Text")
 local owner=L:Owner(self,bar)
 local isXP=L:Field(bar,"isExpBar")==true
 local percent,mode=publicXPPercent(bar)
 local receipt=self.progressContent and self.progressContent[bar]
 if receipt then receipt.percent=percent;receipt.readoutMode=mode;receipt.panel=nil end
 -- The XP display has one centered percentage over its fill. Unreadable or
 -- banked/capped XP must never retain an old or invented percentage. Its
 -- native fill and hover tooltip continue; non-XP bars keep native captions.
 if not percent or not width or not height then
  L:HidePanel(owner,bar,"progressReadout")
  local original=label and progressOriginalAlpha(owner,label)
 if isXP then
   if label then self:HideProgressArt(label) end
   self.progressReadout="NATIVE_XP_FILL_TOOLTIP_NO_PUBLIC_PERCENT"
  elseif original then L:Alpha(owner,label,original) end
  return false
 end
 local panel=L:Panel(owner,bar,bar,"progressReadout",0)
 if not panel then return false end
 local profile,generation=M.profile,owner.generation
 local ok=pcall(function()
  if not panel.progressPercent then panel.progressPercent=panel:CreateFontString(nil,"OVERLAY") end
  -- Clear older owned decoration if a retained panel survives a provider
  -- restart. The percentage is the only caption; no divisions or rest pip.
  if panel.progressLabel then panel.progressLabel:Hide() end
  for _,tick in ipairs(panel.progressTicks or {}) do tick:Hide() end
  for _,piece in pairs(panel.miragePanelPieces or {}) do piece:Hide() end
  local fontSize=12*math.max(.65,math.min(2,M.profile.textScale or 1))
  panel.progressPercent:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",fontSize,"OUTLINE")
  panel.progressPercent:ClearAllPoints();panel.progressPercent:SetPoint("CENTER",status,"CENTER",0,0)
  panel.progressPercent:SetWidth(math.max(1,width-8));panel.progressPercent:SetJustifyH("CENTER")
  if panel.progressPercent.SetShadowColor then panel.progressPercent:SetShadowColor(0,0,0,1) end
  if panel.progressPercent.SetShadowOffset then panel.progressPercent:SetShadowOffset(1,-1) end
  panel.progressPercent:SetTextColor(1,1,1,1)
  panel.progressPercent:SetText(percent)
  panel:SetAlpha(1);panel.progressPercent:SetAlpha(1);panel.progressPercent:Show()
 end)
 if M.profile~=profile or owner.generation~=generation or not owner.active then return false end
 if not ok then
  L:HidePanel(owner,bar,"progressReadout");return L:Gap(owner,"progressReadout","XP_LABEL_UNAVAILABLE")
 end
 -- Hide only duplicate native pixels. The native label and its show/hide
 -- controller keep their original text and lifecycle for an exact handback.
 if label then self:HideProgressArt(label) end
 if receipt then receipt.panel=panel end
 self.progressReadout="PUBLIC_XP_PERCENT_NATIVE_FILL_TOOLTIP"
 return true
end
function A:ProgressHover(row)
 if not row.surface or not M.SidebarLayout or S:InCombat() or R:NativeEditState()~="CLOSED" then return end
 local plan=M.SidebarLayout:Plan();if not plan then return end
 local owner=self:RootOwner(row)
 owner.decorations[row.frame]=owner.decorations[row.frame] or {}
 local cache=owner.decorations[row.frame]
 local frame=cache.progressHover
 if not frame then frame=CreateFrame("Frame",nil,row.frame);cache.progressHover=frame;S:Passive(frame) end
 local layout=plan.progression
 frame:ClearAllPoints();frame:SetScale(layout.scale);frame:SetSize(layout.width,layout.height)
 frame:SetPoint("CENTER",UIParent,"CENTER",layout.x*plan.screenWidth/layout.scale,layout.y*plan.screenHeight/layout.scale)
 frame:Show();row.surface.hoverFrame=frame;row.surface.occlusionFrame=frame
end
function A:Progress(frame)
 local row=self.paintingRoot
 -- The native container may switch while it is faded out. Observe the source
 -- lifecycle methods even when there is no current bar, and schedule the new
 -- selected/pending content for its existing bounded root painter.
 for _,method in ipairs({"InitializeBars","ResizeContainerBars","UpdateDividers","SetShownBar","ApplyPendingBarToShow","UpdateShownState"}) do
  L:Hook(self,frame,method,function()
   if row then self:MarkRoot(row,"geometry") end
   if M.SidebarLayout and M.SidebarLayout.RefreshProgression then M.SidebarLayout:RefreshProgression(frame) end
  end)
 end
 if M.SidebarLayout and M.SidebarLayout.RefreshProgression then M.SidebarLayout:RefreshProgression(frame) end
 local bars,why=self:ProgressContents(frame)
 if not bars then L:Gap(self,"progressSelection",why);return end
 self:HideProgressArt(L:Field(frame,"BarFrameTexture"))
 -- Source-defined pooled divider artwork is retired independently of each
 -- divider's native shown state. Do not enumerate arbitrary UI descendants.
 local dividers=L:Field(frame,"HorizontalDividersPool")
 if dividers then L:Pool(self,dividers,64,function(divider)
  self:HideProgressArt(L:Field(divider,"BarDividerTexture"))
 end) end
 if #bars==0 then return end
 for _,bar in ipairs(bars) do
  if S:Frame(bar,false) then
   local status=L:Field(bar,"StatusBar")
   self.progressContent=self.progressContent or setmetatable({},{__mode="k"})
   local receipt={frame=frame,status=status,profile=M.profile,generation=self.generation,painted=false}
   self.progressContent[bar]=receipt
   if status then
    local isXP=L:Field(bar,"isExpBar")==true
    -- The sidebar size was authored earlier in this root transaction. Native
    -- screen rectangles may still be from the bottom action-bar placement.
    local width=L:Public(frame,"GetWidth","number",true)
    local height=L:Public(frame,"GetHeight","number",true)
    local priorWidth=L:Public(bar,"GetWidth","number",true)
    local priorHeight=L:Public(bar,"GetHeight","number",true)
    if width and width>0 and height and height>=6 then
     local trackHeight=isXP and math.min(10,height-2) or height-2
     local sized=L:AnchoredSize(self,bar,width,height,pack("CENTER",frame,"CENTER",0,0))
     sized=L:AnchoredSize(self,status,math.max(1,isXP and width or width-2),trackHeight,pack("LEFT",bar,"LEFT",isXP and 0 or 1,0)) and sized
     -- The native rested forecast calculates a pixel width, not an anchor
     -- ratio. Resizing the bar without its own UpdateTick left the old
     -- 804-unit prediction stretched across the compact sidebar. It remains
     -- native data even while its decorative forecast is transparent.
     local update=L:Field(bar,"UpdateTick")
     if sized and not S:InCombat() and type(update)=="function" and (priorWidth~=width or priorHeight~=height) then
      local refreshed=pcall(update,bar);if not refreshed then L:Gap(self,"progressForecast","NATIVE_TICK_REFRESH_FAILED") end
     end
    end
    -- 70862's XP template uses a white BarColor and colored fill atlases.
    -- Replacing just that atlas with the neutral Mirage beam loses its color.
    -- Classify only these public presentation assets; XP values, progression
    -- text and native animation/tick controllers remain untouched.
    self.progressKinds=self.progressKinds or setmetatable({},{__mode="k"})
    local texture=L:Public(status,"GetStatusBarTexture")
    local atlas=texture and L:Public(texture,"GetAtlas","string")
    if atlas=="UI-HUD-ExperienceBar-Fill-Experience" then self.progressKinds[status]="EXPERIENCE"
    elseif atlas=="UI-HUD-ExperienceBar-Fill-Rested" then self.progressKinds[status]="RESTED" end
    L:Bar(self,status,isXP and L.white or nil)
    local background=L:Field(status,"Background")
    L:Texture(self,background,L.white)
    if background then
     L:Points(self,background,pack("TOPLEFT",status,"TOPLEFT",0,0,"BOTTOMRIGHT",status,"BOTTOMRIGHT",0,0))
     L:Color(self,background,"progressTrackTint","GetVertexColor","SetVertexColor",.012,.012,.012,.76)
    end
    local kind=self.progressKinds[status]
    local color=kind=="RESTED" and M.VisualTokens.world.mana or kind=="EXPERIENCE" and M.VisualTokens.options.accent
    if color then L:Color(self,status,"progressTint","GetStatusBarColor","SetStatusBarColor",color[1],color[2],color[3],1) end
    if isXP then
     -- These exact source-template decorations can imply a second progress
     -- value. Retire only their pixels; native XP, rested state, animation
     -- controllers and tooltip handlers remain owned by the client.
     self:HideProgressArt(L:Field(bar,"ExhaustionLevelFillBar"))
     self:HideProgressArt(L:Field(bar,"ExhaustionTick"))
     self:HideProgressArt(L:Field(status,"Underlay"))
     self:HideProgressArt(L:Field(status,"Overlay"))
     L:HidePanel(self,status,"progress")
    else
     L:Panel(self,status,status,"progress",.1)
    end
    for _,name in ipairs({"TextString","Text","LeftText","RightText"}) do L:Font(self,L:Field(status,name),10) end
    self:ProgressReadout(bar,status,width,height)
    receipt.painted=true
   else L:Gap(self,"progressContent","NATIVE_FILL_UNAVAILABLE") end
   -- XP's native label is intentionally alpha-hidden: only its owned,
   -- centered percentage is visible. Keep the hidden native label's sizing,
   -- typography and anchors untouched. GetWidth() may still describe its old
   -- screen rectangle immediately after SetWidth; styling invisible text was
   -- creating a real width readback failure and withholding the whole XP gate.
   if L:Field(bar,"isExpBar")~=true then
    for _,name in ipairs({"TextString","Text"}) do L:Font(self,L:Field(bar,name),10) end
    local label=L:Path(bar,"OverlayFrame","Text")
    L:Font(self,label,10)
    if label then
     L:Points(self,label,pack("CENTER",bar,"CENTER",0,0))
     local width=L:Public(frame,"GetWidth","number",true)
     if width and width>12 then L:Scalar(self,label,"width","GetWidth","SetWidth",width-8) end
     L:Color(self,label,"progressTextColor","GetTextColor","SetTextColor",.91,.92,.89,1)
    end
   end
   for _,method in ipairs({"UpdateStatusBarTextures","Update","UpdateCurrentText"}) do L:Hook(self,bar,method) end
  else L:Gap(self) end
 end
end
function A:Skin(row)
 local name,frame=row.spec.name,row.frame
 if name=="StatusTrackingBarManager" then
  self:ProgressHover(row)
  -- Gate the manager, never its children: native container methods obtain
  -- their manager via GetParent(), which must keep its original meaning.
  for _,method in ipairs({"UpdateBarsShown","CheckForLayoutChange"}) do
   L:Hook(self,frame,method,function()
    for _,name in ipairs({"MainStatusTrackingBarContainer","SecondaryStatusTrackingBarContainer"}) do
     local child=self.roots[name];if child then self:MarkRoot(child,"geometry") end
    end
   end)
  end
 elseif name=="MirrorTimerContainer" and R.BreathDisplay then
  R.BreathDisplay:Skin(self,row)
 elseif name=="MirrorTimerContainer" then
  L:List(self,L:Field(frame,"mirrorTimers"),3,function(timer)
   local bar=L:Field(timer,"StatusBar")
   if bar then L:Bar(self,bar);L:Panel(self,bar,bar,"warning",0) end
   L:Alpha(self,L:Field(timer,"Border"),0);L:Texture(self,L:Field(timer,"TextBorder"),L.panel)
   L:Font(self,L:Field(timer,"Text"),12);L:Regions(self,timer,timerAtlases)
  end)
 elseif name=="UIErrorsFrame" then
  L:Font(self,frame,14) -- Native warning text, severity colors and cadence stay intact.
 elseif name=="DeadlyDebuffFrame" then
  L:Font(self,L:Field(frame,"WarningText"),18)
  local debuff=L:Field(frame,"Debuff");if debuff then R.CombatIcon(self,debuff) end
 elseif name=="DurabilityFrame" then
  self:Durability(frame)
 else self:Progress(frame) end
end
local alertStatus=A.Status
function A:Status()
 local ready,detail=self:ProgressionReady()
 return alertStatus(self).."; critical_warning_visibility=NATIVE_TIMER_LIFETIME_SHARED_DURABILITY_GROUP"
 .."; "..(R.DurabilityDisplay and R.DurabilityDisplay:Status() or "durability_display=NATIVE_FALLBACK")
 .."; "..(R.BreathDisplay and R.BreathDisplay:Status(self) or "breath_display=NATIVE_FALLBACK")
 .."; progression_layout="..(self.progressionLayout or "NOT_REQUESTED")
 .."; progression_geometry_readback="..(ready and "READY" or "NOT_READY")
 .."; progression_blocker="..(detail or "UNAVAILABLE")
 .."; progression_readout="..(self.progressReadout or "NATIVE_TEXT_FALLBACK")
 .."; progression_content_readback="..(ready and "SELECTED_CONTENT_READY" or detail or "NOT_READY")
 .."; progression_value_owner=NATIVE; progression_native_rendering=NOT_RUN" end
