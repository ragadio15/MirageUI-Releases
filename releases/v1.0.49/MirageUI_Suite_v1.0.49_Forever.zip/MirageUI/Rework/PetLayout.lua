local _,M=...
local R,S=M.Rework,M.Safety
-- Forever 1.60.1.70938: PetFrame.OnHide calls RemoveManagedFrame, whose
-- Layout runs SetSize on the protected player container. Keep the native pet
-- lifetime and input, but remove its managed-layout membership while Mirage
-- owns the unit presentation. No native callback or unit watch is replaced.
local P={status="NOT_ACQUIRED"}
R.PetLayout=P
local function field(o,key) return S:FieldAccess(o,key) end
local function read(o,key,kind,...)
 local fn=field(o,key)
 if type(fn)~="function" then return nil,"UNAVAILABLE" end
 return S:Public(fn,kind,o,...)
end
local function equal(a,b)
 return S:Number(a) and S:Number(b) and math.abs(a-b)<=math.max(.0001,math.max(math.abs(a),math.abs(b))*2^-22)
end
local function anchors(frame)
 local count=read(frame,"GetNumPoints","number")
 if not count or count<0 or count>8 or count%1~=0 then return nil end
 local points={}
 for i=1,count do
  local ok,p,r,rp,x,y=pcall(frame.GetPoint,frame,i)
  if not ok or not S:Text(p) or not S:Readable(r) or not S:Text(rp) or not S:Number(x) or not S:Number(y) then return nil end
  points[i]={p,r,rp,x,y}
 end
 return points
end
local function samePoints(a,b)
 if not a or not b or #a~=#b then return false end
 for i=1,#a do for k=1,5 do
  if k>=4 then if not equal(a[i][k],b[i][k]) then return false end
  elseif a[i][k]~=b[i][k] then return false end
 end end
 return true
end
local function recorded(row,value)
 for _,points in ipairs(row.pointStates) do if samePoints(points,value) then return true end end
 return false
end
local function record(row,value)
 if value and not recorded(row,value) then row.pointStates[#row.pointStates+1]=value end
end
local function flag(frame)
 local value,state=field(frame,"ignoreFramePositionManager")
 if state=="ABSENT" or state=="KNOWN" and type(value)=="boolean" then return value,true end
 return nil,false
end
local function member(row)
 local value,state=field(row.members,row.frame)
 if state=="ABSENT" then return false end
 if state=="KNOWN" and value==row.frame then return true end
 return nil
end
function P:Source(row)
 return M.Rework==R and R.PetLayout==self and self.lease==row and _G.PetFrame==row.frame and _G.PlayerFrame==row.player
  and _G.PlayerBottomManagedFrameContainer==row.manager and S:Frame(row.frame,false) and S:Frame(row.player,false)
  and S:Frame(row.manager,false) and read(row.manager,"GetParent")==row.player
  and field(row.frame,"layoutParent")==row.manager and field(row.frame,"isPlayerFrameBottomManagedFrame")==true
  and field(row.manager,"showingFrames")==row.members and field(row.manager,"AddManagedFrame")==row.add
  and field(row.manager,"RemoveManagedFrame")==row.remove
end
local function observedNativeMethods(watch)
 local mixin=_G.EditModeSystemMixin
 return watch and watch.ready and mixin==watch.mixin
  and field(mixin,"ApplySystemAnchor")==watch.native.ApplySystemAnchor
  and field(mixin,"UpdateSystem")==watch.native.UpdateSystem
  and field(watch.frame,"ApplySystemAnchor")==watch.installed.ApplySystemAnchor
  and field(watch.frame,"UpdateSystem")==watch.installed.UpdateSystem
end
function P:NativeRefreshCurrent(row)
 local receipt=row and row.nativeRefresh
 if not receipt then return false end
 local owner,frame=row.owner,row.frame
 local function current()
  return self:Source(row) and row.nativeRefresh==receipt and M.profile==receipt.profile
   and owner==receipt.owner and owner.generation==receipt.generation
   and observedNativeMethods(receipt.watch)
 end
 if not current() then return false end
 local value,known=flag(frame)
 local parent,parentState=read(frame,"GetParent")
 local shown,shownState=read(frame,"IsShown","boolean")
 local default,defaultState=read(frame,"IsInDefaultPosition","boolean")
 local points,scale=anchors(frame),read(frame,"GetScale","number")
 local matches=known and value==nil and parentState=="KNOWN" and parent==receipt.parent
  and shownState=="KNOWN" and shown==receipt.shown and defaultState=="KNOWN" and default==true
  and member(row)==receipt.member and samePoints(points,receipt.points) and equal(scale,receipt.scale)
  and field(frame,"IsInDefaultPosition")==receipt.defaultMethod and current()
 if not matches then return false end
 -- Native getters may be Lua overrides. A later read must not authorize a
 -- flag/parent change made after the first snapshot in this same admission.
 local finalFlag,finalKnown=flag(frame)
 return finalKnown and finalFlag==nil and read(frame,"GetParent")==receipt.parent
  and member(row)==receipt.member and current()
end
function P:NativeLayoutObserved(watch,method)
 local row=self.lease
 if not row or row.frame~=watch.frame or row.passive or row.busy or not row.owner or row.owner.active~=true
  or not self:Source(row) or not observedNativeMethods(watch) or M.state.safe or not R:Qualified()
  or R:NativeEditState()~="CLOSED" then return end
 local owner,profile,generation=row.owner,M.profile,row.owner.generation
 local function current()
  return self:Source(row) and row.owner==owner and owner.active==true and owner.generation==generation
   and M.profile==profile and not row.busy and not M.state.safe and R:Qualified()
   and R:NativeEditState()=="CLOSED" and observedNativeMethods(watch)
   and self.lease==row and M.profile==profile and owner.generation==generation
 end
 local value,known=flag(row.frame)
 local parent,parentState=read(row.frame,"GetParent")
 local shown,shownState=read(row.frame,"IsShown","boolean")
 local defaultMethod=field(row.frame,"IsInDefaultPosition")
 local default,defaultState=read(row.frame,"IsInDefaultPosition","boolean")
 local membership=member(row)
 local bottom,bottomState=field(row.frame,"layoutOnBottom")
 local nativeParent=bottom and field(row.manager,"BottomManagedLayoutContainer") or row.manager
 local points,scale=anchors(row.frame),read(row.frame,"GetScale","number")
 if not current() or not known or value~=nil or parentState~="KNOWN" or shownState~="KNOWN"
  or defaultState~="KNOWN" or default~=true or type(defaultMethod)~="function" or membership==nil
  or bottomState~="ABSENT" and (bottomState~="KNOWN" or type(bottom)~="boolean")
  or not S:Frame(nativeParent,false) or not points or not scale or scale<=0 then return end
 -- ApplySystemAnchor's default branch clears the opt-out, then native Add
 -- registers/parents a shown pet. A hidden pet remains unregistered until
 -- its own next OnShow; accept only its existing native ancestry. Capturing
 -- the completed callback is evidence a plain flag comparison cannot give.
 if shown then
  if membership~=true or parent~=nativeParent then return end
 elseif membership~=false or parent~=row.player and parent~=nativeParent then return end
 if not current() then return end
 local receipt={watch=watch,method=method,owner=owner,profile=profile,generation=generation,
  parent=parent,points=points,scale=scale,shown=shown,member=membership,defaultMethod=defaultMethod}
 row.nativeRefresh=receipt
 if not self:NativeRefreshCurrent(row) or not current() then
  if row.nativeRefresh==receipt then row.nativeRefresh=nil end
  return
 end
 row.ready=nil
 self.nativeRefreshes=(self.nativeRefreshes or 0)+1
 self.status="PET_LAYOUT_NATIVE_REFRESH_PENDING"
 -- A post-hook only records completed native intent. Protected membership
 -- and geometry are reconciled by the existing provider's legal next pass.
 owner.nativeDirty=owner.nativeDirty or {};owner.nativeDirty.pet=true
 owner.pendingWork=true;owner.geometryDirty=true
end
function P:WatchNativeLayout(frame)
 if type(hooksecurefunc)~="function" then return false end
 self.nativeObservers=self.nativeObservers or setmetatable({},{__mode="k"})
 local watch=self.nativeObservers[frame]
 if watch then return observedNativeMethods(watch) end
 local mixin=_G.EditModeSystemMixin
 local methods={ApplySystemAnchor=field(mixin,"ApplySystemAnchor"),UpdateSystem=field(mixin,"UpdateSystem")}
 for name,method in pairs(methods) do if type(method)~="function" or field(frame,name)~=method then return false end end
 if type(methods.ApplySystemAnchor)~="function" or type(methods.UpdateSystem)~="function" then return false end
 watch={frame=frame,mixin=mixin,native=methods,installed={}}
 self.nativeObservers[frame]=watch
 for _,name in ipairs({"ApplySystemAnchor","UpdateSystem"}) do
  local okay=pcall(hooksecurefunc,frame,name,function(nativeFrame)
   if nativeFrame==frame then self:NativeLayoutObserved(watch,name) end
  end)
  local installed=field(frame,name)
  if not okay or type(installed)~="function" then return false end
  watch.installed[name]=installed
 end
 watch.ready=true
 return observedNativeMethods(watch)
end
function P:Ready(owner)
 local row=self.lease
 local generation=owner and owner.generation
 if row and row.owner==owner and owner and owner.active and row.nativeRefresh and self:NativeRefreshCurrent(row) then
  return false,"PET_LAYOUT_NATIVE_REFRESH_PENDING"
 end
 if not row or row.owner~=owner or not owner or not owner.active or not row.ready or row.busy or not self:Source(row) then
  return false,self.status=="NOT_ACQUIRED" and "PET_LAYOUT_NOT_ACQUIRED" or "PET_LAYOUT_HANDOFF_PENDING"
 end
 local value,known=flag(row.frame)
 if not known or value~=true or member(row)~=false or read(row.frame,"GetParent")~=row.player then
  self.status="PET_LAYOUT_CUSTODY_CHANGED";return false,self.status
 end
 if not self:Source(row) or not owner.active or owner.generation~=generation then return false,"PET_LAYOUT_CUSTODY_CHANGED" end
 return true,"PET_LAYOUT_DETACHED"
end
local function targetGeometry(frame,player,parent,points,scale,effective,playerScale)
 local desiredScale=effective/playerScale
 if not S:Number(desiredScale) or desiredScale<=0 or desiredScale>8 then return nil end
 local ok,x,y=pcall(frame.GetCenter,frame)
 local ready,px,py=pcall(player.GetCenter,player)
 if ok and ready and S:Number(x) and S:Number(y) and S:Number(px) and S:Number(py) then
  return {{"CENTER",player,"CENTER",(x*effective-px*playerScale)/effective,(y*effective-py*playerScale)/effective}},desiredScale,"NATIVE_CENTER_PRESERVED"
 end
 if #points>0 then
  local out={}
  for i,p in ipairs(points) do out[i]={p[1],p[2] or parent,p[3],p[4],p[5]} end
  return out,desiredScale,"NATIVE_ANCHORS_PRESERVED"
 end
 -- A never-shown native pet may have no rectangle or anchors yet. Author a
 -- small default below PlayerFrame before combat; do not wait for a summon
 -- to enter the very managed layout this lease must prevent. The inverse
 -- retains the genuinely empty original and native Add decides later layout.
 return {{"TOPLEFT",player,"BOTTOMLEFT",0,-6/desiredScale}},desiredScale,"AUTHORED_UNPLACED_PET_DEFAULT"
end
function P:Acquire(owner)
 local profile,generation=M.profile,owner and owner.generation
 if not owner or owner.active~=true or not R:Qualified() or M.state.safe or R:NativeEditState()~="CLOSED" then return false,"PET_LAYOUT_INELIGIBLE" end
 if S:InCombat() then return false,"PET_LAYOUT_COMBAT_DEFERRED" end
 local prior=self.lease
 if prior then
  if prior.owner~=owner then return false,"PET_LAYOUT_OWNER_RETAINED" end
  if self:Ready(owner) then
   if M.profile~=profile or owner.generation~=generation or not owner.active or M.state.safe or S:InCombat() then return false,"PET_LAYOUT_SETUP_SUPERSEDED" end
   return true,"PET_LAYOUT_DETACHED"
  end
  if prior.ready or prior.busy then return false,self.status end
  if not self:Release(owner) then return false,self.status end
 end
 local frame,player,manager=_G.PetFrame,_G.PlayerFrame,_G.PlayerBottomManagedFrameContainer
 if self.contestedFrame==frame then return false,"PET_LAYOUT_NEWER_OWNER_RETAINED" end
 if not S:Frame(frame,false) or not S:Frame(player,false) or not S:Frame(manager,false)
  or read(manager,"GetParent")~=player or field(frame,"layoutParent")~=manager or field(frame,"isPlayerFrameBottomManagedFrame")~=true then
  self.status="PET_LAYOUT_NATIVE_SOURCE_UNAVAILABLE";return false,self.status
 end
 local parent=read(frame,"GetParent");local bottom=field(manager,"BottomManagedLayoutContainer")
 if parent~=player and parent~=manager and (not bottom or parent~=bottom or read(bottom,"GetParent")~=manager) then
  self.status="PET_LAYOUT_NEWER_PARENT_RETAINED";return false,self.status
 end
 local members,access=field(manager,"showingFrames")
 local ignore,flagKnown=flag(frame);local points=anchors(frame);local scale=read(frame,"GetScale","number")
 local effective=read(frame,"GetEffectiveScale","number");local playerScale=read(player,"GetEffectiveScale","number")
 local shown=read(frame,"IsShown","boolean");local add,remove=field(manager,"AddManagedFrame"),field(manager,"RemoveManagedFrame")
 if access~="KNOWN" or type(members)~="table" or not flagKnown or not points or not scale or scale<=0
  or not effective or effective<=0 or not playerScale or playerScale<=0 or shown==nil or type(add)~="function" or type(remove)~="function" then
  self.status="PET_LAYOUT_SNAPSHOT_UNAVAILABLE";return false,self.status
 end
 local row={owner=owner,frame=frame,player=player,manager=manager,members=members,add=add,remove=remove,
  originalParent=parent,originalPoints=points,originalScale=scale,originalFlag=ignore,originalShown=shown,
  pointStates={points},releaseAttempts=0}
 if M.profile~=profile or owner.generation~=generation or not owner.active or S:InCombat() or M.state.safe or R:NativeEditState()~="CLOSED" then
  return false,"PET_LAYOUT_SETUP_SUPERSEDED"
 end
 self.lease=row
 self:WatchNativeLayout(frame)
 local membership=member(row)
 if membership==nil then self.lease=nil;self.status="PET_LAYOUT_MEMBERSHIP_UNAVAILABLE";return false,self.status end
 row.originalMember=membership
 if ignore==true then
  if parent~=player or membership then self.lease=nil;self.status="PET_LAYOUT_NATIVE_OPTOUT_UNAVAILABLE";return false,self.status end
  row.passive=true;row.ready=true;self.status="PET_LAYOUT_NATIVE_OPTOUT_RETAINED";return self:Ready(owner)
 end
 row.points,row.scale,row.positionMode=targetGeometry(frame,player,parent,points,scale,effective,playerScale)
 if not row.points then self.lease=nil;self.status="PET_LAYOUT_POSITION_UNAVAILABLE";return false,self.status end
 row.busy=true
 local function current()
  return self:Source(row) and row.busy and M.profile==profile and owner.active==true and owner.generation==generation
   and not S:InCombat() and not M.state.safe and R:NativeEditState()=="CLOSED"
   and M.profile==profile and owner.active==true and owner.generation==generation and self.lease==row
 end
 local function call(fn,...)
  if not current() or type(fn)~="function" then return false end
  local ok,value=pcall(fn,...)
  return ok and value~=false and current()
 end
 local function geometryPoints(wanted)
  record(row,{})
  if not call(R.NativeClearPoints,frame) then return false end
  local prefix={}
  for _,point in ipairs(wanted) do
   local nextPrefix={};for i,p in ipairs(prefix) do nextPrefix[i]=p end;nextPrefix[#nextPrefix+1]=point;prefix=nextPrefix;record(row,prefix)
   if not call(R.NativeSetPoint,frame,unpack(point)) then return false end
  end
  return samePoints(anchors(frame),wanted) and current()
 end
 local okay=call(function() row.flagAttempted=true;frame.ignoreFramePositionManager=true end)
 local applied,known=flag(frame)
 okay=okay and known and applied==true and current()
 if okay then row.removeAttempted=true;okay=call(remove,manager,frame) end
 if okay then
  record(row,anchors(frame))
  okay=member(row)==false and (read(frame,"GetParent")==parent or read(frame,"GetParent")==player) and current()
 end
 if okay and parent~=player then row.parentAttempted=true;okay=call(frame.SetParent,frame,player) and read(frame,"GetParent")==player and current() end
 if okay then row.scaleAttempted=true;okay=call(R.NativeScale,frame,row.scale) and equal(read(frame,"GetScale","number"),row.scale) and current() end
 if okay then okay=geometryPoints(row.points) end
 row.busy=nil;row.ready=okay or nil
 if not row.flagAttempted then self.lease=nil;self.status="PET_LAYOUT_SETUP_SUPERSEDED";return false,self.status end
 if okay then okay=self:Ready(owner) end
 self.status=okay and "PET_LAYOUT_DETACHED" or "PET_LAYOUT_SETUP_PENDING"
 return okay,self.status
end
function P:Release(owner)
 local row=self.lease
 if not row or row.owner~=owner then return true,"PET_LAYOUT_NOT_OWNED" end
 if row.busy then return false,"PET_LAYOUT_REENTRY_DEFERRED" end
 if S:InCombat() then self.status="PET_LAYOUT_COMBAT_DEFERRED";return false,self.status end
 if row.passive then self.lease=nil;self.status="PET_LAYOUT_NATIVE_OPTOUT_RETAINED";return true,self.status end
 if self:NativeRefreshCurrent(row) then
  -- The exact native callback already completed this handback. Never restore
  -- our obsolete anchors over that native result, nor label it a new addon
  -- owner. Later Acquire snapshots that verified native state from scratch.
  self.lease=nil;self.status="PET_LAYOUT_NATIVE_REFRESH_RESTORED"
  self.nativeRefreshRetired=(self.nativeRefreshRetired or 0)+1
  return true,self.status
 end
 if (row.releaseAttempts or 0)>=3 then self.status="PET_LAYOUT_RETRY_REQUIRED";return false,self.status end
 row.releaseAttempts=(row.releaseAttempts or 0)+1
 local profile,generation=M.profile,owner.generation
 row.busy=true;row.ready=nil
 local function current()
  return self:Source(row) and row.busy and M.profile==profile and owner.generation==generation and not S:InCombat() and R:Qualified()
   and M.profile==profile and owner.generation==generation and self.lease==row
 end
 local function call(fn,...)
  if not current() or type(fn)~="function" then return false end
  local ok,value=pcall(fn,...)
  return ok and value~=false and current()
 end
 local function finish(okay,reason,contested)
  row.busy=nil;self.status=reason
  if okay then self.lease=nil;if contested then self.contestedFrame=row.frame end end
  return okay,reason
 end
 local function nativeEligible()
  local shown,shownState=read(row.frame,"IsShown","boolean")
  local method,access=field(row.frame,"IsInDefaultPosition")
  if shownState~="KNOWN" or not current() then return nil end
  if not shown then return false end
  if access=="ABSENT" then return true end
  if access~="KNOWN" or type(method)~="function" then return nil end
  local allowed,state=read(row.frame,"IsInDefaultPosition","boolean")
  if state~="KNOWN" or not current() then return nil end
  return allowed
 end
 if not current() then return finish(false,"PET_LAYOUT_SOURCE_CHANGED") end
 local frame,parent=row.frame,read(row.frame,"GetParent")
 local observed,known=flag(frame)
 if not known or not parent or member(row)==nil then return finish(false,"PET_LAYOUT_READBACK_UNAVAILABLE") end
 if not row.flagRestoreAttempted and observed~=true or row.flagRestored and observed~=row.originalFlag
  or observed~=true and observed~=row.originalFlag then
  return finish(true,"PET_LAYOUT_NEWER_FLAG_PRESERVED",true)
 end
 local bottom,bottomState=field(frame,"layoutOnBottom")
 if bottomState~="ABSENT" and (bottomState~="KNOWN" or type(bottom)~="boolean") then return finish(false,"PET_LAYOUT_NATIVE_ELIGIBILITY_PENDING") end
 local nativeParent=bottom and field(row.manager,"BottomManagedLayoutContainer") or row.manager
 if not S:Frame(nativeParent,false) then return finish(false,"PET_LAYOUT_NATIVE_ELIGIBILITY_PENDING") end
 if row.flagRestored and row.addAttempted and parent==nativeParent and member(row)==true then
  -- A rejected native Add can have moved/registered first. Retain that debt
  -- and finish the native operation on a later legal pass; its own resulting
  -- layout is not an unrelated writer of our earlier temporary anchors.
  local eligible=nativeEligible()
  if eligible==nil then return finish(false,"PET_LAYOUT_NATIVE_ELIGIBILITY_PENDING") end
  if not eligible then return finish(true,"PET_LAYOUT_NATIVE_LIFETIME_RESTORED") end
  if not call(row.add,row.manager,frame) then return finish(false,"PET_LAYOUT_NATIVE_REGISTRATION_PENDING") end
  if member(row)~=true or read(frame,"GetParent")~=nativeParent or not current() then return finish(false,"PET_LAYOUT_NATIVE_REGISTRATION_PENDING") end
  return finish(true,"PET_LAYOUT_NATIVE_REGISTRATION_RESTORED")
 end
 local pointState=anchors(frame);local scale=read(frame,"GetScale","number")
 if not pointState or not scale or not current() then return finish(false,"PET_LAYOUT_READBACK_UNAVAILABLE") end
 local foreign=parent~=row.player and parent~=row.originalParent
  or not recorded(row,pointState) or not equal(scale,row.originalScale) and not equal(scale,row.scale)
 if not foreign then
  if parent~=row.originalParent then
   row.parentRestoreAttempted=true
   if not call(frame.SetParent,frame,row.originalParent) or read(frame,"GetParent")~=row.originalParent then return finish(false,"PET_LAYOUT_PARENT_RESTORE_PENDING") end
  end
  if not equal(read(frame,"GetScale","number"),row.originalScale) then
   if not call(R.NativeScale,frame,row.originalScale) or not equal(read(frame,"GetScale","number"),row.originalScale) then return finish(false,"PET_LAYOUT_SCALE_RESTORE_PENDING") end
  end
  if not samePoints(anchors(frame),row.originalPoints) then
   record(row,{})
   if not call(R.NativeClearPoints,frame) then return finish(false,"PET_LAYOUT_ANCHOR_RESTORE_PENDING") end
   local prefix={}
   for _,point in ipairs(row.originalPoints) do
    local nextPrefix={};for i,p in ipairs(prefix) do nextPrefix[i]=p end;nextPrefix[#nextPrefix+1]=point;prefix=nextPrefix;record(row,prefix)
    if not call(R.NativeSetPoint,frame,unpack(point)) then return finish(false,"PET_LAYOUT_ANCHOR_RESTORE_PENDING") end
   end
  end
  if not current() or read(frame,"GetParent")~=row.originalParent or not samePoints(anchors(frame),row.originalPoints)
   or not equal(read(frame,"GetScale","number"),row.originalScale) then return finish(false,"PET_LAYOUT_RESTORE_READBACK_PENDING") end
 end
 if not row.flagRestored then
  row.flagRestoreAttempted=true
  if not call(function() frame.ignoreFramePositionManager=row.originalFlag end) then return finish(false,"PET_LAYOUT_FLAG_RESTORE_PENDING") end
  observed,known=flag(frame)
  if not current() or not known or observed~=row.originalFlag then return finish(false,"PET_LAYOUT_FLAG_RESTORE_PENDING") end
  row.flagRestored=true
 end
 if foreign then return finish(true,"PET_LAYOUT_NEWER_GEOMETRY_PRESERVED",true) end
 local eligible=nativeEligible()
 if eligible==nil then return finish(false,"PET_LAYOUT_NATIVE_ELIGIBILITY_PENDING") end
 if not eligible then return finish(true,"PET_LAYOUT_NATIVE_LIFETIME_RESTORED") end
 -- IsInDefaultPosition is external native code. Recheck the exact layout and
 -- opt-out receipt after it before granting the manager another parent write.
 observed,known=flag(frame)
 if not current() or not known or observed~=row.originalFlag or read(frame,"GetParent")~=row.originalParent
  or not samePoints(anchors(frame),row.originalPoints) then return finish(false,"PET_LAYOUT_RESTORE_SUPERSEDED") end
 row.addAttempted=true
 if not call(row.add,row.manager,frame) then return finish(false,"PET_LAYOUT_NATIVE_REGISTRATION_PENDING") end
 if member(row)~=true or read(frame,"GetParent")~=nativeParent or not current() then return finish(false,"PET_LAYOUT_NATIVE_REGISTRATION_PENDING") end
 return finish(true,"PET_LAYOUT_NATIVE_REGISTRATION_RESTORED")
end
function P:Retry(owner)
 if S:InCombat() then return false end
 if self.lease and self.lease.owner==owner then self.lease.releaseAttempts=0 end
 self.contestedFrame=nil
 return true
end
-- Explicit resume/setup must be able to retry cleanup before any provider is
-- configured again. Rearm only this retained current lease; automatic cleanup
-- never calls this method, and no native field or inverse receipt is changed.
function P:RearmRetainedCleanup(owner)
 local row=self.lease
 if not row then return true end
 local state,profile,contexts=M.state,M.profile,M.ContextualNative
 local children=contexts and contexts.nativeChildren
 local child=children and children.PetFrame
 local generation=owner and owner.generation
 local function current()
  return M.Rework==R and R.PetLayout==self and R.UnitFrames==owner and self.lease==row and row.owner==owner
   and M.state==state and M.profile==profile and M.ContextualNative==contexts and contexts.nativeChildren==children
   and children.PetFrame==child and child.owner==owner and child.petLayout==self and child.frame==row.frame
   and owner.generation==generation and not row.busy and not S:InCombat()
 end
 if not owner or not contexts or not children or not child or not current() or not self:Source(row) or not current() then return false end
 row.releaseAttempts=0
 return true
end
function P:Status()
 local row=self.lease
 return self.status.."; pet_layout_position="..(row and row.positionMode or "NATIVE")
  .."; pet_layout_pending="..(row and not row.ready and "true" or "false")
  .."; pet_native_refreshes="..(self.nativeRefreshes or 0).."; pet_native_refresh_retired="..(self.nativeRefreshRetired or 0)
  .."; pet_lifetime=NATIVE_SHOW_HIDE_EVENTS_UNMODIFIED"
end
