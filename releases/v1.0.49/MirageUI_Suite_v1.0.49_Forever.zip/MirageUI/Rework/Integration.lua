-- The M06 providers replace only their named presentations. The suite keeps
-- its existing lifecycle, transaction engine, optional switches and recovery.
local _,M=...
local R,S=M.Rework,M.Safety
for _,entry in ipairs({{"main",R.MainAction},{"units",R.UnitFrames},{"groups",R.UnitGroups},{"minimap",R.Minimap},{"nameplates",R.Nameplates},
 {"auras",R.CombatAuras},{"cooldowns",R.CombatCooldowns},{"meters",R.CombatMeters},{"casts",R.CombatCasts},{"alerts",R.CombatAlerts},
 {"tasks",R.TaskWindows},{"maps",R.Navigation},{"objectives",R.Objectives},{"chat",R.Communication},{"tooltips",R.TooltipMenus},{"inventory",R.Inventory},{"character",R.CharacterWindows},{"system",R.SystemWindows}}) do
 assert(entry[2],"Missing M06 provider: "..entry[1])
 R:RegisterProvider(entry[1],entry[2])
end

local nativeOwners,layoutOwners=R.nativeOwners,R.layoutOwners
-- The native management sidebar remains accessible; retiring the old group
-- owner must not conceal its ready-check, marker and group-management controls.
if R.providers.groups then nativeOwners.CompactRaidFrameManager="groups" end
local function reserved(name)
 local id=nativeOwners[name]
 local row=id and R.providers[id]
 return id and (R:Selected(id) or row and (row.started or row.pending)) or false
end

-- Preserve the proven profile publisher. New storage checkpoints the raw input
-- before initialization, then mirrors successful publications without changing
-- its schema, exports, cursor envelope, Undo or conflict detection.
local initializeProfiles=M.Profiles.Initialize
function M.Profiles:Initialize(...)
 R:CaptureMigrationInput()
 local a,b=initializeProfiles(self,...)
 R:InitializeStorage()
 return a,b
end
local syncing=0
for _,name in ipairs({"Commit","Undo","UseCharacter","SaveNamed","DeleteNamed","CopyNamed","LoadNamed","PublishCursorPreferences"}) do
 local prior=M.Profiles[name]
 if prior then M.Profiles[name]=function(self,...)
  syncing=syncing+1
  local ok,a,b,c=pcall(prior,self,...)
  syncing=syncing-1
  if not ok then error(a,0) end
  if a==true and syncing==0 and not R.rollbackPendingReload then
   local saved,complete=pcall(R.SyncStorage,R)
   if not saved or complete~=true then
    if not saved then R.migrationStatus="SNAPSHOT_FAILED" end
    R.storageReady=false;R.pendingStop=true
   end
  end
  return a,b,c
 end end
end

-- A selected custom provider reserves its native presentation even while it is
-- quiet or recovering. Old fit/fallback owners must not take it back; its own
-- reversible lease decides when native recovery is complete.
local managedAcquire=M.ManagedNative.Acquire
function M.ManagedNative:Acquire(name,...)
 if reserved(name) then self.status[name]="REWORK_CUSTOM_PROVIDER";return nil end
 return managedAcquire(self,name,...)
end
local contextualAcquire=M.ContextualNative.Acquire
function M.ContextualNative:Acquire(name,...)
 if reserved(name) then self.status[name]="REWORK_CUSTOM_PROVIDER";return false end
 return contextualAcquire(self,name,...)
end
local legacyModules={Minimap="minimap",Auras="auras",Cooldowns="cooldowns",DamageMeters="meters",
 Chat="chat",QuestTracker="objectives",Bags="inventory",Tooltips="tooltips"}
local function ownerReserved(id)
 local row=id and R.providers[id]
 return id and (R:Selected(id) or row and (row.started or row.pending)) or false
end
local function legacyReserved(module,frame)
 if M.NativeWindowPolicy and M.NativeWindowPolicy:ModuleNative(module) then return true end
 if ownerReserved(legacyModules[module]) then return true end
 -- Reserve every source-qualified named game window for exactly one pack.
 -- Unregistered surfaces remain outside the custom ownership claim.
 if module=="BlizzardSkin" and frame then
  for name,id in pairs(nativeOwners) do
   if (id=="tasks" or id=="maps" or id=="character" or id=="system") and rawequal(_G[name],frame) and ownerReserved(id) then return true end
  end
 end
 return false
end
local nativeAcquire=M.Native.Acquire
function M.Native:Acquire(module,id,frame,...)
 if legacyReserved(module,frame) then
  if M.NativeWindowPolicy and M.NativeWindowPolicy:ModuleNative(module) then
   local implementation=M.modules[module];if implementation then implementation.status="NATIVE_BY_DESIGN" end
  end
  return nil
 end
 return nativeAcquire(self,module,id,frame,...)
end
local nativeDecorate=M.Native.Decorate
function M.Native:Decorate(module,frame,...)
 if legacyReserved(module,frame) then self:HideDecoration(frame);return nil end
 return nativeDecorate(self,module,frame,...)
end
local square=M.NavigationStyle.Square
function M.NavigationStyle:Square(...)
 if R:Selected("minimap") then self.status.Minimap="REWORK_CUSTOM_PROVIDER";return true end
 return square(self,...)
end
local questColumn=M.NavigationStyle.QuestColumn
function M.NavigationStyle:QuestColumn(...)
 if ownerReserved("objectives") then
  self.status.QuestTracker="REWORK_CUSTOM_PROVIDER";return self:Restore("QuestTracker")
 end
 return questColumn(self,...)
end
local styleHandles=M.NavigationStyle.Handles
function M.NavigationStyle:Handles(name,...)
 if reserved(name) then return false end
 return styleHandles(self,name,...)
end
local nativeStyleScalar=M.NavigationStyle.Scalar
function M.NavigationStyle:Scalar(module,...)
 if ownerReserved(legacyModules[module]) then return false end
 return nativeStyleScalar(self,module,...)
end

-- Custom envelopes have actual layout consumers; native aspect fitting and
-- moveNative permissions describe the old renderer only.
local rootFor=M.NativeLayout.RootFor
function M.NativeLayout:RootFor(id)
 local owner=layoutOwners[id]
 if owner and R:Selected(owner) then return nil end
 return rootFor(self,id)
end
local geometry=M.NativeLayout.Geometry
function M.NativeLayout:Geometry(name,...)
 if reserved(name) then return nil end
 return geometry(self,name,...)
end
local configureNativeLayout=M.NativeLayout.Configure
function M.NativeLayout:Configure(module,...)
 if M.NativeWindowPolicy and M.NativeWindowPolicy:ModuleNative(module) then return self:Restore(module) end
 if ownerReserved(legacyModules[module]) then return self:Restore(module) end
 return configureNativeLayout(self,module,...)
end
local quietConfigure=M.NativeQuiet.Configure
function M.NativeQuiet:Configure(module,...)
 if M.NativeWindowPolicy and M.NativeWindowPolicy:ModuleNative(module) then return end
 if ownerReserved(legacyModules[module]) then
  for _,surface in pairs(M.Native.records) do if surface.module==module then self:Release(surface) end end
  local button=self.buttons[module]
  if button and not S:InCombat() then button:Hide() end
  return
 end
 return quietConfigure(self,module,...)
end

-- A previous adapter may already exist when a selected provider is resumed.
-- Complete its handback before deleting registrations. Failure retains the old
-- receipt and prevents the new provider from acquiring an intermediate state.
function R:RetireLegacyNative(providerID)
 if S:InCombat() then return false end
 for module,id in pairs(legacyModules) do if (not providerID or id==providerID) and ownerReserved(id) then
  if M.NavigationStyle and M.NavigationStyle:Restore(module)~=true then return false end
  if M.NativeLayout and M.NativeLayout:Restore(module)~=true then return false end
  local row=M.NativeLayout and M.NativeLayout.rows[module]
  if row then
   local surface=row.surface
   if row.original or row.pending then return false end
   if surface and not surface.reworkProvider and M.surfaces[surface.id]==surface then
    if row.anchor and S:Frame(row.anchor,false) then row.anchor:Hide() end
    M.Effects.active[surface.id]=nil;M.Policy:Release(surface);M.surfaces[surface.id]=nil
   end
   M.NativeLayout.rows[module]=nil
  end
 end end
 local retire={}
 for frame,surface in pairs(M.Native.records) do
  local owner=legacyModules[surface.module]
  if not owner then for name,id in pairs(nativeOwners) do if rawequal(_G[name],frame) then owner=id;break end end end
  if (not providerID or owner==providerID) and legacyReserved(surface.module,frame) then
   M.Native:RestoreSurface(frame,surface)
   if surface.restorePending or surface.quietRestorePending then return false end
   if M.NativeQuiet then M.NativeQuiet:Release(surface) end
   if surface.quietRestorePending or not M.Native:HideDecoration(frame) then return false end
   retire[#retire+1]={frame=frame,surface=surface}
  end
 end
 for _,entry in ipairs(retire) do
  local frame,surface=entry.frame,entry.surface
  M.Effects.active[surface.id]=nil;M.Policy:Release(surface)
  if M.surfaces[surface.id]==surface then M.surfaces[surface.id]=nil end
  if M.Native.records[frame]==surface then M.Native.records[frame]=nil end
  local implementation=M.modules[surface.module]
  if implementation and implementation.surfaces then
   for name,old in pairs(implementation.surfaces) do if old==surface then implementation.surfaces[name]=nil end end
  end
 end
 return true
end
local releaseBaseline=R.ReleaseBaseline
function R:ReleaseBaseline(providerID)
 return releaseBaseline(self,providerID) and self:RetireLegacyNative(providerID)
end

-- Retire the old plate pipeline once before allowing the new pooled runtime to
-- assign frames. A blocked restoration remains visible in the provider report.
local plates=M.modules.Nameplates
local oldPlateSuspend=plates.Suspend
local function retirePlates()
 if R.oldPlatesRetired then return true end
 if S:InCombat() then return false end
 oldPlateSuspend(plates)
 if M.NameplateCards and next(M.NameplateCards.pending or {}) then return false end
 R.oldPlatesRetired=true;return true
end
R.providers.nameplates.prepare=retirePlates
for _,name in ipairs({"Initialize","Resume","ApplyConfig","Refresh","OnEvent","Tick"}) do
 local prior=plates[name]
 plates[name]=function(self,...)
  if R:Selected("nameplates") then
   retirePlates();self.status="REWORK_CUSTOM_PROVIDER";return
  end
  R.oldPlatesRetired=nil
  return prior(self,...)
 end
end
function plates:Suspend(...)
 R.oldPlatesRetired=nil
 return oldPlateSuspend(self,...)
end

local apply=M.ApplyProfile
function M:ApplyProfile(...)
 local a,b=apply(self,...)
 if a==true then
  if R:Selected("nameplates") then retirePlates() end
  R:Configure()
  if not M.state.safe then M.Presentation:Refresh() end
 end
 return a,b
end

-- Merge provider demand before Core reconciles subscriptions. A rejected event
-- probe is cached as unavailable, never treated as a subscription to remove.
function M:CollectProviderEvents(wanted)
 for _,id in ipairs(R.order) do
  if R:Selected(id) then for event in pairs(R.providers[id].object.events or {}) do
   wanted[event]=true
  end end
 end
end
local event=M.Event
function M:Event(name,...)
 -- NAME_PLATE_CREATED can precede the provider's first Configure. Observe
 -- only its public native lifecycle here; qualification and presentation
 -- admission remain separate, and no inactive renderer is started by an event.
 if name=="NAME_PLATE_CREATED" and self.state.initialized and not self.state.safe then
  local plates=R.Nameplates
  if plates and type(plates.ObserveNativeCreation)=="function" then
   local okay=pcall(plates.ObserveNativeCreation,plates,...)
   if not okay then plates.earlyObserverFailures=(plates.earlyObserverFailures or 0)+1 end
  end
 end
 if name=="PLAYER_LEAVING_WORLD" then R:OnEvent(name,...) end
 event(self,name,...)
 if not self.state.initialized then return end
 if name=="PLAYER_LOGOUT" then
  R:OnEvent(name,...)
  if not R.rollbackPendingReload then R:SyncStorage() end
 elseif name~="PLAYER_LEAVING_WORLD" then R:OnEvent(name,...) end
end

-- Cleanup participates in the existing retained-debt recovery protocol. An
-- apparent baseline cleanup success never erases a pending M01 native lease.
local cleanupOwned=M.CleanupOwned
function M:CleanupOwned(owner,...)
 local ready,why=R:PrepareOwnedRootCleanup(owner)
 if not ready then return false,why end
 return cleanupOwned(self,owner,...)
end
local cleanup=M.ProcessSafeCleanup
function M:ProcessSafeCleanup(...)
 local a,b=cleanup(self,...)
 local released=R:Stop("SAFE_MODE")
 if not released then self.state.safeCleanupPending=true;return false,"REWORK_RESTORE_PENDING" end
 return a,b
end
local safeMode=M.SafeMode
function M:SafeMode(reason,...)
 if reason=="USER_REQUEST" or reason=="USER_BINDING" then R:ResetReleaseBudget() end
 return safeMode(self,reason,...)
end
local recover=M.Recover
function M:Recover(...)
 if R.rollbackPendingReload then self:Print("Reload after profile rollback before resuming MirageUI.");return false end
 local ready,why=R:Retry()
 if not ready then self:Print("MirageUI recovery is pending: "..why);return false,why end
 return recover(self,...)
end

-- Core's single update driver calls R:Tick, including while safe cleanup is
-- pending. No second frame driver competes with the shared work budget.
R.driver=nil

local commands=M.Commands.Run
function M.Commands:Run(input)
 local command,rest=(input or ""):match("^%s*(%S*)%s*(.-)%s*$")
 if command:lower()~="rework" then return commands(self,input) end
 if rest=="rollback b34" or rest=="rollback b34 confirm" then
  if rest~="rollback b34 confirm" then M:Print("Use /mirage rework rollback b34 confirm to restore the complete pre-b35 profile checkpoint. Then exit the game and replace all three folders with b34.");return end
  local ok,why=R:Rollback(true,"b34");M:Print(why);return ok
 end
 if rest=="rollback m05" or rest=="rollback m05 confirm" then
  if rest~="rollback m05 confirm" then M:Print("Use /mirage rework rollback m05 confirm to restore the pre-M06 settings. Exit the game afterward and install all three M05 folders together.");return end
  local ok,why=R:Rollback(true,"M05");M:Print(why);return ok
 end
 local retryID=rest:match("^retry%s+([a-z]+)$")
 if retryID then
  if not R.providers[retryID] then M:Print("Unknown display provider. Open Help for the affected display ID.");return false end
  local ok,why=R:Retry(retryID);M:Print(ok and "This display is queued for a local retry." or (why or "Retry is waiting for a legal transition."));return ok
 end
 if rest=="preferences" then M.UI:CopyWindow("Preserved preference mapping",R:PreferenceReport());return end
 if rest=="rollback-m03" or rest=="rollback-m03 confirm" then
  if rest~="rollback-m03 confirm" then M:Print("Use /mirage rework rollback-m03 confirm to restore the pre-M04 settings. Exit the game afterward and install all three M03 folders together.");return end
  local ok,why=R:Rollback(true,"M03");M:Print(why);return ok
 end
 if rest=="rollback" or rest=="rollback confirm" then
  local _,message=R:Rollback(rest=="rollback confirm");M:Print(message)
 else M.UI:CopyWindow("MirageUI M06 runtime report",R:Report()) end
end
local export=M.Diagnostics.Export
function M.Diagnostics:Export(...)
 -- A supplied b37 capture stopped at exactly 65,536 bytes before the rework
 -- section. Its truncating boundary is unknown. Put the actionable provider
 -- evidence first and include an end marker so a cut copy is detectable.
 local body=export(self,...)
 local newline=body:find("\n",1,true)
 local header=newline and body:sub(1,newline-1) or body
 local remainder=newline and body:sub(newline+1) or ""
 return header.."\n\n"..R:Report().."\n\n"..remainder.."\nMIRAGEDIAG_END=1"
end
