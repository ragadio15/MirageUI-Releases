local _,M=...
-- Rich tooltip content stays in the engine widgets, with owner-sensitive
-- placement supplied by TooltipAnchor. This provider never calls SetOwner,
-- ClearLines, SetHyperlink or SetPoint on a tooltip or comparison stack.
local R,S=M.Rework,M.Safety
local L=R.CombatLeases
local T={id="tooltips",status="NOT_INITIALIZED",tips={},menus=setmetatable({},{__mode="k"}),
 hooks=setmetatable({},{__mode="k"}),surfaceOwners=setmetatable({},{__mode="k"}),scaleOwners=setmetatable({},{__mode="k"}),roots={},surfaceDirty=setmetatable({},{__mode="k"}),nativeRoots={},events={ADDON_LOADED=true,PLAYER_ENTERING_WORLD=true,
 PLAYER_REGEN_ENABLED=true,UI_SCALE_CHANGED=true,DISPLAY_SIZE_CHANGED=true}}
R.TooltipMenus=T
local names={"GameTooltip","ItemRefTooltip","ShoppingTooltip1","ShoppingTooltip2","ItemRefShoppingTooltip1","ItemRefShoppingTooltip2",
 "WorldMapTooltip","SmallTextTooltip","BattlePetTooltip","FloatingBattlePetTooltip","FriendsTooltip",
 "SettingsTooltip","EncounterJournalTooltip","BrowserSettingsTooltip"}
for _,name in ipairs(names) do T.nativeRoots[name]=true end
local function wanted()
 local cfg=M.profile and M.profile.modules and M.profile.modules.Tooltips or {}
 return cfg.enabled~=false and cfg.style~=false and R:Qualified() and R:Selected("tooltips") and not M.state.safe and not R:NativeEditing()
end
local function get(o,k) return L:Field(o,k) end
local function kind(o) return L:Public(o,"GetObjectType","string") end
local function eligible(frame)
 if not S:Frame(frame,false) then return false end
 local fn=get(frame,"GetOwner")
 if type(fn)=="function" then
  local ok,owner=pcall(fn,frame)
  if not ok or not S:Readable(owner) or owner and not S:Frame(owner,false) then return false end
 end
 return true
end
function T:Watch(frame)
 if not eligible(frame) then return false end
 self.hooks[frame]=self.hooks[frame] or {}
 local hooks=self.hooks[frame]
 if not hooks.hide and type(get(frame,"HookScript"))=="function" then
  local ok=pcall(frame.HookScript,frame,"OnHide",function() if T.active then T.surfaceDirty[frame]=true;T.dirty=true end end)
  if ok then hooks.hide=true end
 end
 if not hooks.script and type(get(frame,"HookScript"))=="function" then
  local ok=pcall(frame.HookScript,frame,"OnShow",function() if T.active then T.surfaceDirty[frame]=true;T.dirty=true end end)
  if ok then hooks.script=true end
 end
 for _,method in ipairs({"SetOwner","SetText","AddLine","AddDoubleLine","SetTooltipData","ProcessInfo","RefreshData","Layout","SetBackdrop","SetBackdropColor","SetBackdropBorderColor"}) do
  if not hooks[method] and type(get(frame,method))=="function" and type(hooksecurefunc)=="function" then
   local ok=pcall(hooksecurefunc,frame,method,function() if T.active and not T.writing then T.surfaceDirty[frame]=true;T.dirty=true end end)
   if ok then hooks[method]=true end
  end
 end
 return true
end
function T:StyleTooltip(frame,owner)
 owner=owner or self
 if not eligible(frame) then self.skippedOwners=(self.skippedOwners or 0)+1;return true end
 if S:InCombat() then self.combatPending=true;return false end
 local K=R.WindowKit;if not K then return false end
 local generation,profile=self.generation,M.profile
 local seen,queue,count={},{{frame,0}},0
 local complete=true
 self.writing=true
 while #queue>0 do
  local item=table.remove(queue);local node,depth=item[1],item[2]
  if not self.active or self.generation~=generation or M.profile~=profile or not wanted() then self.writing=nil;return false end
  if eligible(node) and not seen[node] and not K.owned[node] then
   seen[node]=true;count=count+1
   if count>256 then self.scanLimited=true;self.writing=nil;return false end
   local k=kind(node)
   if k~="Model" and k~="PlayerModel" and k~="DressUpModel" and k~="ModelScene" then
    -- Tooltip textures can be inserted rich content. Only the source-pinned
    -- backdrop pieces below are suppressed; never classify item pictures,
    -- texture lines or comparison content by their draw layer.
    local fn=get(node,"GetRegions")
    if type(fn)=="function" then
     local good,regions=pcall(function() return {fn(node)} end)
     if not good or #regions>384 then self.scanLimited=true;self.writing=nil;return false end
     for _,region in ipairs(regions) do
      if S:Frame(region,false) and not K.owned[region] and kind(region)=="FontString" then
       complete=K:StyleFont(owner,region) and complete
      end
     end
    end
    if node==frame or k=="GameTooltip" then complete=K:Panel(owner,node,.96) and complete end
    if k=="StatusBar" then complete=L:Bar(owner,node) and complete
    elseif k=="Button" or k=="CheckButton" then K:StyleButton(owner,node) end
    -- Named classic Backdrop and NineSlice regions are presentation only;
    -- their existing visibility/tooltip population remains game-owned.
    local nine=get(node,"NineSlice")
    if S:Frame(nine,false) then
     for _,key in ipairs({"TopLeftCorner","TopRightCorner","BottomLeftCorner","BottomRightCorner","TopEdge","BottomEdge","LeftEdge","RightEdge","Center"}) do
      local art=get(nine,key);if art then complete=L:Alpha(owner,art,0) and complete end
     end
    end
    if type(get(node,"GetChildren"))=="function" then
     local ok,children=pcall(function() return {node:GetChildren()} end)
     if not ok or #children>128 then self.scanLimited=true;self.writing=nil;return false end
     for _,child in ipairs(children) do
      if eligible(child) and not K.owned[child] then
       if depth>=8 then self.scanLimited=true;self.writing=nil;return false end
       queue[#queue+1]={child,depth+1}
      end
     end
    end
   end
  end
 end
 self.writing=nil;self:Watch(frame);self.styledTips=(self.styledTips or 0)+1;return complete
end
function T:OfferMenu(frame)
 if not eligible(frame) then return false end
 self.menus[frame]=true;self.surfaceDirty[frame]=true;self.dirty=true;return true
end
local function meterOwns(frame)
 local meter=R.CombatMeters
 for _,lease in pairs(meter and meter.menus or {}) do
  if lease.frame==frame and (lease.active or lease.records and #lease.records>0) then return true end
 end
 return false
end
local function insightProvider(frame)
 local api=_G.MirageInsightAPI
 if type(api)~="table" or api.apiVersion~=1 or type(api.HandlesTooltipPresentation)~="function" or
  type(api.RefreshTooltipPresentation)~="function" then return nil end
 local ok,supported=pcall(api.HandlesTooltipPresentation,frame)
 if ok and supported==true then return api end
end
function T:SurfaceOwner(frame,key)
 local owner=self.surfaceOwners[frame]
 if not owner then
  owner={id=self.id,parentOwner=self,surfaceKey=key or "Menu",frame=frame,retryAttempts=0}
  self.surfaceOwners[frame]=owner
 end
 return owner
end
local scalableTips={GameTooltip=true,ItemRefTooltip=true,ShoppingTooltip1=true,ShoppingTooltip2=true,ItemRefShoppingTooltip1=true,ItemRefShoppingTooltip2=true}
function T:ReleaseScale(frame)
 local owner=self.scaleOwners[frame]
 if not owner then return true end
 owner.active=false
 local released=L:Release(owner)==true
 owner.releasePending=not released or nil
 if released and self.scaleOwners[frame]==owner then
  self.scaleOwners[frame]=nil
  if owner.rootRow and self.roots[owner.rootRow.spec.name]==owner.rootRow then self.roots[owner.rootRow.spec.name]=nil end
 end
 return released
end
function T:ScaleSurface(frame,key,visible)
 if not scalableTips[key] then return true end
 local cfg=M.profile and M.profile.modules and M.profile.modules.Tooltips or {}
 local percent=cfg.tooltipScale or 100
 if visible~=true or percent==100 then return self:ReleaseScale(frame) end
 if not S:Number(percent) or percent<70 or percent>160 then percent=100 end
 if percent==100 then return self:ReleaseScale(frame) end
 local owner=self.scaleOwners[frame]
 if owner and (owner.profile~=M.profile or owner.percent~=percent or owner.parentGeneration~=self.generation or owner.releasePending) then
  if not self:ReleaseScale(frame) then return false end
  owner=nil
 end
 if owner and owner.blocked then return false end
 if not owner then
  if not eligible(frame) or not S:Frame(frame,true) or S:InCombat() then return false end
  local base,state=L:Public(frame,"GetScale","number")
  if state~="KNOWN" or not S:Number(base) or base<=0 or base>10 then return false end
  local parent,parentState=L:Public(frame,"GetParent")
  if parentState~="KNOWN" or not S:Readable(parent) or not rawequal(_G[key],frame) then return false end
  owner={id=self.id,parentOwner=self,parentGeneration=self.generation,profile=M.profile,percent=percent,base=base,active=true}
  owner.rootRow={frame=frame,spec={name=key},leaseOwner=owner};owner.rootParentTracked=true;owner.rootParent=parent
  self.roots[key]=owner.rootRow
  self.scaleOwners[frame]=owner;L:Begin(owner)
 end
 if owner.applied then
  local actual,state=L:Public(frame,"GetScale","number")
  if state~="KNOWN" or not S:Number(actual) then return false end
  if not L:GeometryEqual(actual,owner.applied) then
   owner.active=false;owner.blocked=true;owner.releasePending=L:Release(owner)~=true or nil
   self.scaleStatus="NEWER_NATIVE_SCALE_RETAINED";return false
  end
 end
 local okay=L:Scalar(owner,frame,"scale","GetScale","SetScale",owner.base*percent/100)
 if self.scaleOwners[frame]~=owner or owner.profile~=M.profile or owner.parentGeneration~=self.generation or not self.active then return false end
 if not okay then
  owner.active=false;owner.blocked=true;owner.releasePending=L:Release(owner)~=true or nil
  self.scaleStatus="NATIVE_SCALE_RETAINED";return false
 end
 owner.applied=L:Public(frame,"GetScale","number")
 self.scaleStatus="CUSTOM_SCALE_APPLIED";return true
end
function T:PaintSurface(frame,key,menu,force)
 local owner=self:SurfaceOwner(frame,key)
 self:Watch(frame)
 local visible=L:Public(frame,"IsShown","boolean")
 local scaleReady=menu or self:ScaleSurface(frame,key,visible)
 if visible~=true then
  self.waitingTips=self.waitingTips+1
  if owner.active or owner.releasePending then
   owner.active=false
   if owner.retryAttempts>=3 then R:RecordSurface(self,key,"DEFERRED_HANDOFF","SURFACE_RETRY_REQUIRED");return false end
   local restored=L:Release(owner);owner.releasePending=not restored or nil
   if not restored then owner.retryAttempts=owner.retryAttempts+1 end
   if not restored then R:RecordSurface(self,key,"DEFERRED_HANDOFF","TOOLTIP_HANDOFF_PENDING");return false end
  end
  owner.retryAttempts=0;owner.blocked=nil
  R:RecordSurface(self,key,"EMPTY","WAITING_FOR_OPEN");return scaleReady
 end
 local insight=not menu and insightProvider(frame)
 if insight then
  -- One writer owns each shared tooltip. Release any earlier core receipt
  -- before Insight styles the same native body; never run competing skins.
  if owner.active or owner.releasePending then
   owner.active=false
   local released=L:Release(owner);owner.releasePending=not released or nil
   if not released then R:RecordSurface(self,key,"DEFERRED_HANDOFF","TOOLTIP_HANDOFF_PENDING");return false end
  end
  if force or self.surfaceDirty[frame] or owner.parentGeneration~=self.generation then
   owner.parentGeneration=self.generation;self.surfaceDirty[frame]=nil
   local ok,ready=pcall(insight.RefreshTooltipPresentation,frame)
   owner.insightReady=ok and ready==true
  end
  self.styledTips=self.styledTips+(owner.insightReady and 1 or 0)
  R:RecordSurface(self,key,owner.insightReady and "READY" or "EMPTY",owner.insightReady and "INSIGHT_MIRAGE_PRESENTATION" or "INSIGHT_WAITING_FOR_CONTENT")
  return scaleReady
 end
 if not force and not self.surfaceDirty[frame] and owner.parentGeneration==self.generation then
  return not owner.blocked and not owner.releasePending and scaleReady
 end
 self.surfaceDirty[frame]=nil
 if (owner.blocked or owner.releasePending) and owner.retryAttempts>=3 then
  R:RecordSurface(self,key,"PARTIAL","SURFACE_RETRY_REQUIRED");return false
 end
 if owner.releasePending then
  owner.active=false
  if not L:Release(owner) then
   owner.retryAttempts=owner.retryAttempts+1
   R:RecordSurface(self,key,"DEFERRED_HANDOFF","TOOLTIP_HANDOFF_PENDING");return false
  end
  owner.releasePending=nil
 end
 owner.parentGeneration=self.generation;owner.active=true;L:Begin(owner)
 local good,painted
 if menu then good,painted=pcall(R.WindowKit.StyleTree,R.WindowKit,owner,frame,{maxNodes=256,maxDepth=10,fill=.97})
 else good,painted=pcall(self.StyleTooltip,self,frame,owner) end
 self.writing=nil
 if not good or not painted or (owner.gaps or 0)>0 then
  -- Restore only the failed tooltip/menu. Other roots keep their own receipts.
  owner.active=false;owner.blocked=true;owner.retryAttempts=owner.retryAttempts+1
  owner.releasePending=L:Release(owner)~=true or nil
  local why=not good and "SURFACE_PAINT_FAILED" or "SURFACE_PRESENTATION_PARTIAL"
  R:RecordSurface(self,key,owner.releasePending and "DEFERRED_HANDOFF" or "PARTIAL",why)
  return false
 end
 owner.blocked=nil;owner.retryAttempts=0
 R:RecordSurface(self,key,"READY","CUSTOM_RICH_CONTENT_READY")
 return scaleReady
end
function T:Discover(force)
 force=force or self.refreshOpen;self.refreshOpen=nil
 if not R.WindowKit then return R:Result("WAITING","WINDOW_KIT_UNAVAILABLE") end
 self.styledTips=0;self.styledMenus=0;self.skippedOwners=0;self.waitingTips=0;self.waitingFonts=0
 local partial=false
 for _,name in ipairs(names) do
  local f=_G[name];local previous=self.tips[name]
  local handoff=true
  if previous and previous~=f then
   if not self:ReleaseScale(previous) then handoff=false;partial=true end
   local owner=self.surfaceOwners[previous]
   if owner then
    owner.active=false
    if owner.retryAttempts>=3 then handoff=false
    else
     handoff=L:Release(owner)==true and handoff
     if not handoff then owner.retryAttempts=owner.retryAttempts+1 end
    end
    owner.releasePending=not handoff or nil;partial=not handoff or partial
   end
  end
  if not handoff then R:RecordSurface(self,name,"DEFERRED_HANDOFF","TOOLTIP_HANDOFF_PENDING")
  elseif S:Frame(f,false) then
   self.tips[name]=f
   if not self:PaintSurface(f,name,false,force) then partial=true end
  else R:RecordSurface(self,name,"WAITING","WAITING_FOR_NATIVE_LOAD") end
 end
 for i=1,3 do local f=_G["DropDownList"..i];if eligible(f) then self.menus[f]="DropDownList"..i end end
 local menu=_G.Menu
 if type(menu)=="table" and type(menu.GetManager)=="function" then
  local good,manager=pcall(menu.GetManager)
  if good and S:Readable(manager) and type(manager)=="table" and type(manager.GetOpenMenu)=="function" then
   local ok,f=pcall(manager.GetOpenMenu,manager);if ok and eligible(f) and not self.menus[f] then self:OfferMenu(f) end
  end
 end
 local count=0
 for f,key in pairs(self.menus) do
  count=count+1
  if eligible(f) and not meterOwns(f) then
   if type(key)~="string" then self.menuSerial=(self.menuSerial or 0)+1;key="Menu"..self.menuSerial;self.menus[f]=key end
   if not self:PaintSurface(f,key,true,force) then partial=true end
   if L:Public(f,"IsShown","boolean")==true then self.styledMenus=self.styledMenus+1 end
  end
 end
 self.dirty=nil;self.scanLimited=nil
 if partial then return R:Result("PARTIAL","RICH_CONTENT_PARTIAL") end
 return R:Result("READY","CUSTOM_RICH_TOOLTIPS_AND_MENUS")
end
function T:Initialize()
 if S:InCombat() then return false,"COMBAT_LOCKDOWN" end
 local registry=_G.EventRegistry
 if not self.menuCallback and S:Readable(registry) and type(registry)=="table" and type(registry.RegisterCallback)=="function" then
  local ok=pcall(registry.RegisterCallback,registry,"MenuProxy.OnShow",function(_,frame)
   if T.active then T:OfferMenu(frame) end
  end,self)
  self.menuCallback=ok or nil
 end
 if not self.dropdownHook and type(_G.ToggleDropDownMenu)=="function" and type(hooksecurefunc)=="function" then
  self.dropdownHook=pcall(hooksecurefunc,"ToggleDropDownMenu",function() if T.active then T.refreshOpen=true;T.dirty=true end end) or nil
 end
 if not self.backdropHook and type(_G.SharedTooltip_SetBackdropStyle)=="function" and type(hooksecurefunc)=="function" then
  self.backdropHook=pcall(hooksecurefunc,"SharedTooltip_SetBackdropStyle",function(frame) if T.active and eligible(frame) and not T.writing then T.surfaceDirty[frame]=true;T.dirty=true end end) or nil
 end
 return true
end
function T:Configure()
 if not wanted() then return self:Suspend("NOT_SELECTED") end
 if S:InCombat() then return false,"COMBAT_LOCKDOWN" end
 if not self.active and self.records and #self.records>0 then local ok,why=self:Suspend("HANDOFF");if not ok then return false,why end end
 local ok,why=self:Initialize();if not ok then return false,why end
 self.active=true;L:Begin(self);self.dirty=true
 local result=self:Discover(true);self.status=result.reason
 return result
end
function T:Tick()
 if not self.active then return end
 if not wanted() then return self:Suspend("NOT_SELECTED") end
 if self.dirty and not S:InCombat() then
  local result=self:Discover();self.status=result.reason;return result
 end
end
function T:OnEvent(event)
 self.dirty=true
 if event=="PLAYER_ENTERING_WORLD" or event=="ADDON_LOADED" or event=="UI_SCALE_CHANGED" or event=="DISPLAY_SIZE_CHANGED" then
  for frame in pairs(self.surfaceOwners) do self.surfaceDirty[frame]=true end
 end
end
function T:Retry()
 for frame,owner in pairs(self.surfaceOwners) do owner.retryAttempts=0;owner.blocked=nil;self.surfaceDirty[frame]=true end
 self.dirty=true;return true
end
function T:Suspend(reason)
 self.active=false
 local insight=_G.MirageInsightAPI
 if type(insight)=="table" and type(insight.RefreshTooltipPresentation)=="function" then pcall(insight.RefreshTooltipPresentation) end
 local complete=true
 for frame in pairs(self.scaleOwners) do complete=self:ReleaseScale(frame) and complete end
 for _,owner in pairs(self.surfaceOwners) do
  owner.active=false;owner.releasePending=L:Release(owner)~=true or nil;complete=not owner.releasePending and complete
 end
 local ok,why=L:Release(self);ok=ok and complete;self.status=ok and (reason or "STOPPED") or why or "TOOLTIP_HANDOFF_PENDING"
 return ok,self.status
end
function T:Status()
 return self.status.."; rich_tips="..tostring(self.styledTips or 0).."; open_menus="..tostring(self.styledMenus or 0)
  .."; waiting_closed_tips="..tostring(self.waitingTips or 0).."; waiting_empty_fonts="..tostring(self.waitingFonts or 0)
  .."; forbidden_owners_skipped="..tostring(self.skippedOwners or 0).."; owner_and_comparison_anchors=UNCHANGED"
  .."; size="..(self.scaleStatus or "NATIVE_SCALE")
end
