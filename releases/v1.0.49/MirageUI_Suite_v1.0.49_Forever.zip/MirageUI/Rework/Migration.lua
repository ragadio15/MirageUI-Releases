-- Versioned rework storage beside the proven profile transaction engine.
-- The existing account/character roots remain runtime-authoritative. Immutable
-- pre-upgrade checkpoints and current snapshots are kept in separately versioned
-- roots; a stale/partially persisted mirror never overwrites live preferences.
local _,M=...
local R,S=M.Rework,M.Safety
-- Storage identity describes the original rework schema/checkpoint, not the
-- currently running build. Retaining it keeps pre-upgrade recovery readable.
-- Runtime admission is checked independently through the reviewed source tuples.
local target="Forever:1.60.1:70862:16001"
local function plain(t) return type(t)=="table" and getmetatable(t)==nil end
local function snapshot(input)
 local seen,count={},0
 local function copy(v,depth)
  if depth>30 or not S:Readable(v) then error("UNREADABLE_DATA",0) end
  local t=type(v)
  if t=="nil" or t=="boolean" or t=="string" then return v end
  if t=="number" then if not S:Number(v) then error("INVALID_NUMBER",0) end;return v end
  if t~="table" or not plain(v) or seen[v] then error("INVALID_DATA",0) end
  seen[v]=true;local result={}
  for k,x in next,v do
   count=count+1;if count>150000 or not S:Readable(k) or (type(k)~="string" and type(k)~="number") then error("DATA_LIMIT",0) end
   if type(k)=="number" and not S:Number(k) then error("INVALID_KEY",0) end
   result[k]=copy(x,depth+1)
  end
  seen[v]=nil;return result
 end
 local ok,result=pcall(copy,input,0)
 return ok,result
end
R.Snapshot=snapshot
local function checkpoint(root)
 local ok,copy=snapshot(root)
 if not ok then return nil end
 return {present=root~=nil,root=copy}
end
local function validStore(store,character)
 if not plain(store) or store.schema~=1 or store.target~=target or not S:Number(store.revision) or store.revision<1 then return false end
 if store.preferenceRevision~=nil and store.preferenceRevision~=4 then return false end
 if store.m04SourceDisabled~=nil and type(store.m04SourceDisabled)~="boolean" then return false end
 if store.m04Checkpoint~=nil and (not plain(store.m04Checkpoint) or type(store.m04Checkpoint.present)~="boolean" or store.m04Checkpoint.present and not plain(store.m04Checkpoint.root)) then return false end
 if store.m06Revision~=nil and store.m06Revision~=1 then return false end
 if store.m06SourceDisabled~=nil and type(store.m06SourceDisabled)~="boolean" then return false end
 if store.m06Checkpoint~=nil and (not plain(store.m06Checkpoint) or type(store.m06Checkpoint.present)~="boolean" or store.m06Checkpoint.present and not plain(store.m06Checkpoint.root)) then return false end
 if store.beta35Revision~=nil and store.beta35Revision~=1 then return false end
 if store.beta35SourceDisabled~=nil and type(store.beta35SourceDisabled)~="boolean" then return false end
 if store.beta35Checkpoint~=nil and (not plain(store.beta35Checkpoint) or type(store.beta35Checkpoint.present)~="boolean" or store.beta35Checkpoint.present and not plain(store.beta35Checkpoint.root)) then return false end
 if store.m06DelegatedGeometry~=nil and (not plain(store.m06DelegatedGeometry) or store.m06DelegatedGeometry.schema~=1 or not plain(store.m06DelegatedGeometry.rows)) then return false end
 if not plain(store.checkpoint) or type(store.checkpoint.present)~="boolean" or not plain(store.active) then return false end
 if store.checkpoint.present and not plain(store.checkpoint.root) then return false end
 if not character then
  if not plain(store.cvars) or type(store.disabled)~="boolean" then return false end
  local count=0
  for key,row in pairs(store.cvars) do
   count=count+1
   if count>32 or type(key)~="string" or not (key:match("^nameplate[%w_]+$") or R:IsJournalCVar(key)) or not plain(row)
    or type(row.owner)~="string" or type(row.original)~="string" or #row.original>128
    or row.written~=nil and type(row.written)~="string" or row.attempt~=nil and type(row.attempt)~="string"
    or row.conflict~=nil and type(row.conflict)~="boolean"
    or row.restoreAttempts~=nil and (not S:Number(row.restoreAttempts) or row.restoreAttempts<0 or row.restoreAttempts>3 or row.restoreAttempts%1~=0) then return false end
  end
 end
 return true
end
local optionalFields={Auras={"playerPanel","preparation","privateAuras"},Cooldowns={"tracker"},QuestTracker={"compactPanel"},
 DamageMeters={"summary"},Bags={"browser"},PvP={"contacts","badge","automaticLens"},TacticalSignals={"legend"},
 ResourceBars={"classResource","runes","totems","empoweredStages"}}
function R:CodeRollbackPending()
 local a,c=MirageUIReworkDB,MirageUIReworkCharacterDB
 return validStore(a,false) and validStore(c,true) and a.rollbackTarget=="b34"
end
local primaryOrder={"main","units","groups","minimap","nameplates","auras","cooldowns","meters","chat","tooltips","maps","objectives","inventory","tasks","character","system"}
local function preferenceRow(profile,label,active)
 local row={label=label,active=active==true,primary={},optionalOff={},authoredLayouts=0,hiddenContexts=0,unresolved=0,
  layouts="PRESERVED",bindings="UNMODIFIED",cursor="PRESERVED",enabled=profile.enabled~=false}
 local modules=plain(profile.modules) and profile.modules or {}
 for _,id in ipairs(primaryOrder) do
  local selected,why=R:PrimaryChoice(id,profile)
  row.primary[id]=why
  if why=="DISABLED_PRIMARY_UNRESOLVED" or why=="OPAQUE_PRIMARY_DATA" or why=="MISSING_MODULE" then row.unresolved=row.unresolved+1 end
 end
 for module,keys in pairs(optionalFields) do
  local cfg=modules[module]
  if plain(cfg) then for _,key in ipairs(keys) do if cfg[key]==false then row.optionalOff[#row.optionalOff+1]=module.."."..key end end end
 end
 table.sort(row.optionalOff)
 for _ in pairs(plain(profile.layouts) and profile.layouts or {}) do row.authoredLayouts=row.authoredLayouts+1 end
 for _,rules in pairs(plain(profile.elementContexts) and profile.elementContexts or {}) do
  if plain(rules) then for _,state in pairs(rules) do if state=="HIDE" then row.hiddenContexts=row.hiddenContexts+1 end end end
 end
 row.legacyPositionSelectors={}
 for _,module in ipairs({"Minimap","Chat","QuestTracker"}) do
  local cfg=modules[module]
  if plain(cfg) and cfg.moveNative==false then row.legacyPositionSelectors[#row.legacyPositionSelectors+1]=module..":CUSTOM_USES_AUTHORED_GEOMETRY" end
 end
 return row
end
local function mapping(root,character)
 local out={schema=1,revision=4,profiles=0,named=0,primary="SEMANTIC_SELECTION",optional="PRESERVED",layouts="PRESERVED",bindings="UNMODIFIED",rows={},unresolved=0,foreignFamilies=0}
 if not plain(root) or not plain(root.clients) then return out end
 local function add(p,label,active,named)
  if not plain(p) then return end
  out.profiles=out.profiles+1;if named then out.named=out.named+1 end
  if #out.rows>=1024 then out.truncated=true;return end
  local row=preferenceRow(p,label,active);out.rows[#out.rows+1]=row;out.unresolved=out.unresolved+row.unresolved
 end
 -- Foreign-family profiles remain opaque and recoverable. Do not apply a
 -- Forever semantic map to them or turn unknown fields into runtime options.
 for family,branch in pairs(root.clients) do
  if family~="Forever" then out.foreignFamilies=out.foreignFamilies+1
  elseif plain(branch) then
   add(branch.profile,character and "CHARACTER" or "ACCOUNT",not character or branch.useCharacter==true,false)
   local names={}
   for key in pairs(plain(branch.named) and branch.named or {}) do if type(key)=="string" then names[#names+1]=key end end
   table.sort(names)
   for _,name in ipairs(names) do add(branch.named[name],"NAMED:"..name,false,true) end
  end
 end
 return out
end
R.PreferenceMapping=mapping
-- Native geometry is deliberately dormant, never deleted or rewritten into a
-- new game layout. The complete raw checkpoint also covers all other fields,
-- foreign families and inactive named profiles; this index is only an aid.
local function delegatedGeometry(root,character)
 local out={schema=1,rows={},count=0}
 local branch=plain(root) and plain(root.clients) and root.clients.Forever
 if not plain(branch) then return out end
 local function add(profile,label)
  if not plain(profile) or not plain(profile.layouts) then return end
  local row={label=label,layouts={}}
  for _,id in ipairs({"NativeControls.BagsBar","NativeControls.MicroMenuContainer"}) do
   if profile.layouts[id]~=nil then
    local ok,value=snapshot(profile.layouts[id]);if ok then row.layouts[id]=value;out.count=out.count+1 end
   end
  end
  if next(row.layouts) then out.rows[#out.rows+1]=row end
 end
 add(branch.profile,character and "CHARACTER" or "ACCOUNT")
 for name,profile in pairs(plain(branch.named) and branch.named or {}) do
  if type(name)=="string" then add(profile,"NAMED:"..name) end
 end
 return out
end
function R:PreferenceReport()
 local lines={"MirageUI preserved preference mapping", "Saved settings remain authoritative. Original checkpoints and the pre-M04 account and character roots are retained.",
  "Primary mode: 0 = effective previous choice; 1 = Mirage presentation; 2 = explicit native recovery.",
  "Optional panels keep their own switches. Context HIDE keeps primary ownership; it does not select native artwork.",
  "Managed actions map to the custom primary even when the old supplemental-bar flag was off. moveNative=false does not reject a custom minimap, chat or tracker.",
  "Unknown disabled primary intent is retained for review; essential game controls remain available. Shortcuts and Cursor settings are unchanged.",
  "M06 retains a separate pre-upgrade checkpoint. Bag and menu positions remain saved but dormant; Blizzard Edit HUD owns their geometry. Utility context visibility uses the saved Action Bars preferences.", ""}
 for _,entry in ipairs({{"Account",self.store},{"Character",self.characterStore}}) do
  local data=entry[2] and entry[2].mapping
  if data and data.rows then
   lines[#lines+1]=entry[1]..": "..data.profiles.." stored profiles; "..data.named.." named; "..data.unresolved.." primary choices retained for review."
   for _,row in ipairs(data.rows) do
    lines[#lines+1]=row.label..": "..row.authoredLayouts.." authored rectangles; "..row.hiddenContexts.." hidden contexts; "..#row.optionalOff.." optional features off."
    for _,id in ipairs(primaryOrder) do lines[#lines+1]="  "..id..": "..row.primary[id] end
    if #row.optionalOff>0 then lines[#lines+1]="  Kept off: "..table.concat(row.optionalOff,", ") end
   end
   if data.truncated then lines[#lines+1]="Additional profiles remain in the complete checkpoint; this report reached its 1024-profile limit." end
  else lines[#lines+1]=entry[1]..": mapping unavailable; original storage retained." end
 end
 return table.concat(lines,"\n")
end
-- Pure slot seals follow the existing profile publisher's final-custody model.
-- Validation/copy helpers may call readability APIs; the last publication guard
-- must call none. Only exact baseline cleanup journal slots are excluded.
local function seal(values,ignored)
 local nodes,seen,count={},{},0
 local function walk(v,depth)
  if depth>30 then return false end
  local kind=type(v)
  if kind~="table" then return kind=="nil" or kind=="string" or kind=="number" or kind=="boolean" end
  if not plain(v) then return false end
  if seen[v] then return true end
  seen[v]=true
  local node={object=v,fields={},count=0,skip=ignored[v] or {}};nodes[#nodes+1]=node
  for k,x in next,v do if not node.skip[k] then
   count=count+1;if count>150000 or type(k)~="string" and type(k)~="number" then return false end
   node.fields[#node.fields+1]={key=k,value=x};node.count=node.count+1
   if not walk(x,depth+1) then return false end
  end end
  return true
 end
 for _,v in ipairs(values) do if not walk(v,0) then return nil end end
 return function()
  for _,node in ipairs(nodes) do
   if not plain(node.object) then return false end
   local n=0
   for k in next,node.object do if not node.skip[k] then n=n+1;if n>node.count then return false end end end
   if n~=node.count then return false end
   for _,field in ipairs(node.fields) do if not rawequal(rawget(node.object,field.key),field.value) then return false end end
  end
  return true
 end
end
function R:CaptureMigrationInput()
 if not self:TargetMatched() then return end
 local sourceA,sourceC=MirageUIDB,MirageUICharacterDB
 local unchanged=seal({{account=sourceA,character=sourceC}},{})
 if not unchanged then return end
 local a=checkpoint(sourceA);local c=checkpoint(sourceC)
 if a and c and rawequal(sourceA,MirageUIDB) and rawequal(sourceC,MirageUICharacterDB) and unchanged() then
  self.migrationInput={account=a,character=c,sourceA=sourceA,sourceC=sourceC}
 end
end
function R:InitializeStorage()
 self.storageReady=false
 if M.Profiles.readOnly or not self:TargetMatched() then self.migrationStatus="PROFILE_OR_CLIENT_UNAVAILABLE";return false end
 local input=self.migrationInput
 if not input then self.migrationStatus="CHECKPOINT_UNAVAILABLE";return false end
 local a,c=MirageUIReworkDB,MirageUIReworkCharacterDB
 local liveA,liveC=MirageUIDB,MirageUICharacterDB
 local profiles,profile,db=M.Profiles,M.profile,M.db
 local unchanged=seal({{account=liveA,character=liveC,store=a,characterStore=c,input=input}},{})
 if not unchanged then self.migrationStatus="MIGRATION_OWNER_CHANGED";return false end
 -- Complete detached copies first; unknown versioned stores are never normalized.
 local okA,newA=snapshot(a);local okC,newC=snapshot(c)
 if not okA or not okC or a~=nil and not validStore(newA,false) or c~=nil and not validStore(newC,true) then
  self.migrationStatus="UNKNOWN_REWORK_SCHEMA_PRESERVED";return false
 end
 local copyA,activeA=snapshot(liveA);local copyC,activeC=snapshot(liveC)
 if not copyA or not copyC then self.migrationStatus="PROFILE_SNAPSHOT_UNAVAILABLE";return false end
 local freshA=a==nil;local freshC=c==nil
 newA=newA or {schema=1,target=target,revision=1,checkpoint=input.account,active={},cvars={},disabled=false}
 newC=newC or {schema=1,target=target,revision=1,checkpoint=input.character,active={}}
 local reconcile=not freshA and not freshC and (newA.committed~=newA.revision or newC.committed~=newC.revision or newC.accountRevision~=newA.revision)
 newA.active={root=activeA};newC.active={root=activeC}
 -- The pre-rework checkpoint remains immutable. M04 adds a separate raw
 -- upgrade checkpoint so installing the previous complete ZIP can be paired
 -- with its exact pre-M04 settings, including inactive and named profiles.
 if newA.m04SourceDisabled==nil then newA.m04SourceDisabled=newA.disabled end
 newA.m04Checkpoint=newA.m04Checkpoint or input.account
 newC.m04Checkpoint=newC.m04Checkpoint or input.character
 if newA.m06SourceDisabled==nil then newA.m06SourceDisabled=newA.disabled end
 newA.m06Checkpoint=newA.m06Checkpoint or input.account
 newC.m06Checkpoint=newC.m06Checkpoint or input.character
 newA.beta34Checkpoint=newA.beta34Checkpoint or input.account
 newC.beta34Checkpoint=newC.beta34Checkpoint or input.character
 newA.beta35Checkpoint=newA.beta35Checkpoint or input.account
 newC.beta35Checkpoint=newC.beta35Checkpoint or input.character
 if newA.beta35SourceDisabled==nil then newA.beta35SourceDisabled=newA.disabled end
 newA.beta35Revision=1;newC.beta35Revision=1
 newA.m06DelegatedGeometry=newA.m06DelegatedGeometry or delegatedGeometry(newA.m06Checkpoint.root,false)
 newC.m06DelegatedGeometry=newC.m06DelegatedGeometry or delegatedGeometry(newC.m06Checkpoint.root,true)
 newA.m06Revision=1;newC.m06Revision=1
 newA.preferenceRevision=4;newC.preferenceRevision=4
 newA.mapping=mapping(activeA,false);newC.mapping=mapping(activeC,true)
 newA.committed=newA.revision;newC.committed=newC.revision;newC.accountRevision=newA.revision
 if not rawequal(MirageUIDB,liveA) or not rawequal(MirageUICharacterDB,liveC)
  or not rawequal(MirageUIReworkDB,a) or not rawequal(MirageUIReworkCharacterDB,c)
  or not rawequal(M.Profiles,profiles) or rawget(profiles,"readOnly") or not rawequal(M.profile,profile) or not rawequal(M.db,db)
  or not unchanged() then self.migrationStatus="MIGRATION_OWNER_CHANGED";return false end
 -- No callbacks between publication of the pair. Disk persistence remains
 -- separate; the next boot reconciles from authoritative profile roots above.
 MirageUIReworkDB,MirageUIReworkCharacterDB=newA,newC
 self.store,self.characterStore=newA,newC;self.storageReady=true;self.rolledBack=newA.disabled==true or newA.rollbackTarget=="M03" or newA.rollbackTarget=="M05" or newA.rollbackTarget=="b34"
 self.migrationInput=nil
 self.migrationStatus=(freshA or freshC) and "CHECKPOINTED" or reconcile and "PARTIAL_MIRROR_RECONCILED" or "CURRENT"
 return true
end
function R:SyncStorage()
 if not self.storageReady then return false end
 if M.Profiles.readOnly then self.storageReady=false;self.migrationStatus="PROFILE_OR_CLIENT_UNAVAILABLE";return false end
 local a,c=self.store,self.characterStore
 if not rawequal(a,MirageUIReworkDB) or not rawequal(c,MirageUIReworkCharacterDB) or not validStore(a,false) or not validStore(c,true) then
  self.storageReady=false;self.migrationStatus="STORE_OWNER_CHANGED";return false
 end
 local liveA,liveC=MirageUIDB,MirageUICharacterDB
 local profiles,profile,db=M.Profiles,M.profile,M.db
 local unchanged=seal({{account=liveA,character=liveC,store=a,characterStore=c}},{})
 if not unchanged then self.migrationStatus="SNAPSHOT_DEFERRED";return false end
 local okA,copyA=snapshot(liveA);local okC,copyC=snapshot(liveC)
 if not okA or not okC then self.migrationStatus="SNAPSHOT_DEFERRED";return false end
 local mapA,mapC=mapping(copyA,false),mapping(copyC,true)
 local revision=math.min(a.revision+1,2147483647);local charRevision=math.min(c.revision+1,2147483647)
 if not rawequal(MirageUIDB,liveA) or not rawequal(MirageUICharacterDB,liveC) or not rawequal(MirageUIReworkDB,a)
  or not rawequal(MirageUIReworkCharacterDB,c) or not rawequal(M.Profiles,profiles) or rawget(profiles,"readOnly")
  or not rawequal(M.profile,profile) or not rawequal(M.db,db) or not unchanged() then self.migrationStatus="SNAPSHOT_DEFERRED";return false end
 -- Detached work is complete. No game/readability callback can run between
 -- the last custody seal and these logical commit markers.
 a.committed=nil;c.committed=nil
 a.revision=revision;c.revision=charRevision
 a.active={root=copyA};c.active={root=copyC};a.mapping=mapA;c.mapping=mapC
 c.accountRevision=revision;c.committed=charRevision;a.committed=revision
 return true
end
function R:Rollback(confirm,previous)
 if confirm~=true then return false,"Use /mirage rework rollback confirm to restore the pre-rework addon profiles. Your current profiles will also be retained in the recovery store." end
 if S:InCombat() or self:NativeEditing() or M.applying or M.WorkspaceModel and M.WorkspaceModel.draft then return false,"Finish combat and close settings and Customize before rollback." end
 if not self.storageReady or not validStore(self.store,false) or not validStore(self.characterStore,true) then return false,"The recovery checkpoint is unavailable; no profiles were changed." end
 local a,c=self.store,self.characterStore
 local liveA,liveC,profile,profiles,db=MirageUIDB,MirageUICharacterDB,M.profile,M.Profiles,M.db
 local sourceKey=previous=="b34" and "beta35SourceDisabled" or previous=="M05" and "m06SourceDisabled" or "m04SourceDisabled"
 local sourceDisabled,disabled,rollbackTarget=a[sourceKey],a.disabled,a.rollbackTarget
 if not plain(liveA) or not plain(liveC) or not plain(profile) or M.Profiles.readOnly or not rawequal(db,liveA) then
  return false,"The authoritative profile owner changed; no profiles were replaced."
 end
 local checkpointKey=previous=="b34" and "beta35Checkpoint" or previous=="M05" and "m06Checkpoint" or previous=="M03" and "m04Checkpoint" or "checkpoint"
 local checkpointA,checkpointC=a[checkpointKey],c[checkpointKey]
 if not plain(checkpointA) or not plain(checkpointC) then return false,"The requested upgrade checkpoint is unavailable; no profiles were changed." end
 local presentA,presentC=checkpointA.present,checkpointC.present
 local ignored={}
 if plain(liveA) then
  ignored[liveA]={safe=true,worldCombatTextRecovery=true}
  local branches=rawget(liveA,"clients");local branch=plain(branches) and rawget(branches,"Forever")
  if plain(branch) then ignored[branch]={managedPRD=true} end
 end
 local unchanged=seal({liveA,liveC,profile,checkpointA,checkpointC},ignored)
 if not unchanged then return false,"The current data could not be sealed; no profiles were changed." end
 local okA,oldA=snapshot(checkpointA.root);local okC,oldC=snapshot(checkpointC.root)
 local saveA,currentA=snapshot(MirageUIDB);local saveC,currentC=snapshot(MirageUICharacterDB)
 if not okA or not okC or not saveA or not saveC then return false,"The checkpoint could not be copied; no profiles were changed." end
 local function current()
  if not plain(a) or not plain(c) or not rawequal(a,MirageUIReworkDB) or not rawequal(c,MirageUIReworkCharacterDB) or not rawequal(a,self.store) or not rawequal(c,self.characterStore)
   or not rawequal(MirageUIDB,liveA) or not rawequal(MirageUICharacterDB,liveC) or not rawequal(M.profile,profile) or not rawequal(M.Profiles,profiles) or not rawequal(M.db,db)
   or rawget(profiles,"readOnly") or not rawequal(rawget(a,sourceKey),sourceDisabled)
   or not rawequal(rawget(a,"disabled"),disabled) or not rawequal(rawget(a,"rollbackTarget"),rollbackTarget)
   or not rawequal(rawget(a,checkpointKey),checkpointA) or not rawequal(rawget(c,checkpointKey),checkpointC) or not rawequal(rawget(a,"schema"),1) or not rawequal(rawget(c,"schema"),1)
   or not rawequal(rawget(a,"target"),target) or not rawequal(rawget(c,"target"),target) then return false end
  return unchanged()
 end
 local changed="Settings ownership or profile contents changed during recovery; no profiles were replaced."
 if not current() then return false,changed end
 M:SafeMode("USER_REQUEST")
 if not current() then return false,changed end
 local clean=M:ProcessSafeCleanup(true)
 if not current() then return false,changed end
 local restored=self:Stop("ROLLBACK")
 if not current() then return false,changed end
 local settings=self:RestoreCVars()
 if not current() then return false,changed end
 if not clean or not restored or not settings then return false,"Recovery is still pending. No profiles were replaced; inspect /mirage rework and finish recovery first." end
 local backupA,backupC
 saveA,backupA=snapshot(liveA);saveC,backupC=snapshot(liveC)
 -- Publication below is callback-free. These copies include the completed
-- cleanup metadata, while the immutable pre-upgrade checkpoint stays intact.
 if not saveA or not saveC or not current() then return false,changed end
 a.beforeRollback={root=backupA};c.beforeRollback={root=backupC}
 local previousRelease=previous=="M03" or previous=="M05" or previous=="b34"
 a.disabled=previousRelease and sourceDisabled==true or not previousRelease
 a.rollbackTarget=previousRelease and previous or nil;self.rolledBack=true
 MirageUIDB=presentA and oldA or nil
 MirageUICharacterDB=presentC and oldC or nil
 self.rollbackPendingReload=true;self.migrationStatus="ROLLBACK_RELOAD_REQUIRED"
 if previous=="b34" then return true,"Pre-b35 profiles restored. Exit the game and replace all three addon folders with the b34 ZIP before playing again. b35 stays paused; your current settings remain in the recovery store." end
 if previous=="M05" then return true,"Pre-M06 profiles restored. Exit the game and restore all three folders from the M05 ZIP. M06 remains paused until its code is replaced; current settings remain in the recovery store." end
 if previous=="M03" then return true,"Pre-M04 profiles restored. Exit the game and restore all three folders from the M03 ZIP. M04 stays paused until its code is replaced; current settings remain in the recovery store. The earlier build retains its known startup defect." end
 return true,"Pre-rework profiles restored. Exit the game before restoring the beta.24 folders, or /reload to continue with the rework disabled. Current profiles remain retained in the recovery store."
end
