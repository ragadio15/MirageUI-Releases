local _,M=...
-- The client owns the warning thresholds. This passive strip consumes the
-- same eleven GetInventoryAlertStatus slots as its pinned DurabilityFrame;
-- it never computes a replacement percentage or changes equipment state.
local R,S,L=M.Rework,M.Safety,M.Rework.CombatLeases
local D={id="Notifications.durability",status="NOT_INITIALIZED"}
R.DurabilityDisplay=D
local WHITE="Interface\\Buttons\\WHITE8X8"
local function theme(key,fallback) return M.Theme and M.Theme[key] or fallback end
local function public(frame,method,kind,...) return L:Public(frame,method,kind,...) end
local function enabled()
 local p=M.profile;local cfg=p and p.modules and p.modules.Notifications
 return p and p.enabled~=false and cfg and cfg.enabled~=false and not M.state.safe and M.state.world==true
end
function D:Current(provider,row,profile,generation,request)
 return self.provider==provider and self.row==row and M.profile==profile and provider.generation==generation
  and (request==nil or self.request==request) and provider.active and not row.leaseBlocked
  and provider.roots.DurabilityFrame==row and row.frame==_G.DurabilityFrame and enabled()
end
function D:Observe(live)
 if type(GetInventoryAlertStatus)~="function" then return nil,"NATIVE_ALERT_API_UNAVAILABLE" end
 local any,broken=false,false
 for index=1,11 do
  local v,state=S:Public(GetInventoryAlertStatus,"number",index)
  if live and not live() then return nil,"DURABILITY_SCOPE_RETIRED" end
  if state~="KNOWN" or not S:Number(v) or v%1~=0 or v<0 or v>2 then return nil,"NATIVE_ALERT_STATUS_UNAVAILABLE" end
  any=any or v==1 or v==2;broken=broken or v==2
 end
 local rule=Enum and Enum.GameRule and Enum.GameRule.RepairArmorDisabled
 if rule and C_GameRules and type(C_GameRules.IsGameRuleActive)=="function" then
  local disabled,state=S:Public(C_GameRules.IsGameRuleActive,"boolean",rule)
  if state~="KNOWN" then return nil,"NATIVE_REPAIR_RULE_UNAVAILABLE" end
  if disabled then return false,"NATIVE_REPAIRS_DISABLED",false end
 end
 if Kiosk and type(Kiosk.IsEnabled)=="function" then
  local kiosk,state=S:Public(Kiosk.IsEnabled,"boolean")
  if state~="KNOWN" then return nil,"NATIVE_KIOSK_STATE_UNAVAILABLE" end
  if kiosk then return false,"NATIVE_KIOSK_HIDDEN",false end
 end
 for _,name in ipairs({"VehicleSeatIndicator","CompactArenaFrame"}) do
  local frame=_G[name]
  if frame then
   local shown,state=public(frame,"IsShown","boolean")
   if state~="KNOWN" then return nil,"NATIVE_WARNING_CONTEXT_UNAVAILABLE" end
   if shown then return false,"NATIVE_WARNING_CONTEXT_HIDDEN",broken end
  end
 end
 return any,any and "NATIVE_EQUIPMENT_ALERT" or "NATIVE_EQUIPMENT_CLEAR",broken
end
function D:Height(profile)
 local size=profile and profile.textScale or 1
 size=S:Number(size) and math.max(.65,math.min(2,size)) or 1
 return math.max(30,14*size+16)
end
function D:ReserveHeight(profile)
 return self.warning==true and enabled() and self.profile==profile and self:Height(profile) or 0
end
function D:Initialize(provider,live)
 live=live or function() return true end
 if not self.frame then
  if S:InCombat() then return false,"DURABILITY_SETUP_DEFERRED" end
  if self.initializing then return false,"DURABILITY_SETUP_PENDING" end
  self.initializing=true
  local frame,rule,label
  local okay=pcall(function()
   -- Do not publish a half-built widget when a hooked setter changes profile
   -- or retires the provider. A native FontString needs a font before text.
   frame=CreateFrame("Frame",nil,UIParent,"BackdropTemplate")
   frame:SetAlpha(0);frame:Hide();S:Passive(frame)
   if not live() then return end
   frame:SetSize(225,30);if not live() then return end
   frame:SetFrameStrata("LOW");if not live() then return end
   frame:SetBackdrop({bgFile=WHITE,edgeFile=WHITE,edgeSize=1});if not live() then return end
   rule=frame:CreateTexture(nil,"OVERLAY")
   rule:SetPoint("TOPLEFT",1,-1);rule:SetPoint("TOPRIGHT",-1,-1);rule:SetHeight(1)
   if not live() then return end
   label=frame:CreateFontString(nil,"OVERLAY");label.mirageSemanticColor=true
   label:SetFont(M.Theme and M.Theme.font or STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",12,"")
   if not live() then return end
   label:SetPoint("LEFT",10,0);label:SetPoint("RIGHT",-10,0);label:SetJustifyH("CENTER");label:SetJustifyV("MIDDLE")
   if label.SetWordWrap then label:SetWordWrap(false) end
   if not live() then return end
   label:SetText("Alert: Durability Low")
  end)
  self.initializing=nil
  if not okay or not live() or not label then
   if frame then frame:SetAlpha(0);frame:Hide() end
   return false,okay and "DURABILITY_SCOPE_RETIRED" or "DURABILITY_SETUP_PENDING"
  end
  self.frame,self.rule,self.label=frame,rule,label
 end
 if not self.surface then
  local surface={id=self.id,layoutID=self.id,module="Notifications",frame=self.frame,security="OWNED_VISUAL",
   groups={objectives=true},activityRecipient="TRACKER",fallback="HIDDEN",editable=false,reworkProvider=provider,
   presentationHidden=true,hoverOwnerID="QuestTracker.nativePosition",layout={x=.4,y=-.3,width=225,height=30,scale=1}}
  self.surface=surface;M.CVE:Register(surface)
 elseif M.Policy and M.Policy.owners then
  local owner=M.Policy.owners[self.id]
  if owner and owner~=self.surface then return false,"DURABILITY_OWNER_REPLACED" end
  if not owner then
   if not M.Policy:Register(self.surface) then return false,"DURABILITY_OWNER_PENDING" end
   self.surface.actual="UNINITIALIZED";self.surface.desired=nil
   self.surface.revision=(self.surface.revision or 0)+1
  end
 end
 if not live() then return false,"DURABILITY_SCOPE_RETIRED" end
 self.surface.reworkProvider=provider;self.surface.disabled=false
 provider.surfaces[self.id]=self.surface
 return true
end
function D:ApplyLayout()
 local profile,provider,row,request=M.profile,self.provider,self.row,self.request
 if not provider or not row then return false,"DURABILITY_SCOPE_RETIRED" end
 local generation=provider.generation
 self.layoutRequest=(self.layoutRequest or 0)+1;local layoutRequest=self.layoutRequest
 local function live()
  return self.layoutRequest==layoutRequest and self:Current(provider,row,profile,generation,request)
 end
 if not live() then return false,"DURABILITY_SCOPE_RETIRED" end
 if S:InCombat() then
  self.layoutDirty=true
  if self.provider then self.provider.combatPending=true end
  return self.layout~=nil,"DURABILITY_LAYOUT_COMBAT_DEFERRED"
 end
 local plan=M.SidebarLayout and M.SidebarLayout:Plan(profile)
 if not live() then return false,"DURABILITY_SCOPE_RETIRED" end
 if not self.frame or not plan then self.layoutDirty=true;return false,"DURABILITY_VIEWPORT_PENDING" end
 local objectives=R.Objectives
 local quest=objectives and objectives.active and objectives.layout and objectives.surface and not objectives.surface.disabled and objectives.layout
 local reference=quest or plan.objectives
 -- If the full Quest display is disabled, remain immediately after the
 -- progression strip rather than reserving an invisible Quest-sized hole.
 if not quest then reference=plan.progression end
 local scale=plan.scale;local height=self:Height(profile)
 local top=reference.y*plan.screenHeight-reference.height*(reference.scale or scale)/2-plan.gap*scale
 local layout={x=plan.map.x,y=(top-height*scale/2)/plan.screenHeight,width=plan.width,height=height,scale=scale}
 local textScale=S:Number(profile.textScale) and math.max(.65,math.min(2,profile.textScale)) or 1
 local old=self.layout
 if not old or old.x~=layout.x or old.y~=layout.y or old.width~=layout.width or old.height~=height or old.scale~=scale
  or self.layoutProfile~=profile or self.textScale~=textScale then
  local frame=self.frame
  frame:SetSize(layout.width,height);if not live() then return false,"DURABILITY_SCOPE_RETIRED" end
  frame:SetScale(scale);if not live() then return false,"DURABILITY_SCOPE_RETIRED" end
  frame:ClearAllPoints();if not live() then return false,"DURABILITY_SCOPE_RETIRED" end
  frame:SetPoint("CENTER",UIParent,"CENTER",layout.x*plan.screenWidth/scale,layout.y*plan.screenHeight/scale)
  if not live() then return false,"DURABILITY_SCOPE_RETIRED" end
  local bg=theme("background",{.035,.035,.038,.98});local edge=theme("edge",{.26,.26,.26,1})
  frame:SetBackdropColor(bg[1],bg[2],bg[3],(bg[4] or 1)*.8);if not live() then return false,"DURABILITY_SCOPE_RETIRED" end
  frame:SetBackdropBorderColor(unpack(edge));if not live() then return false,"DURABILITY_SCOPE_RETIRED" end
  self.rule:SetColorTexture(unpack(theme("accent",{1,.55,0,1})))
  if not live() then return false,"DURABILITY_SCOPE_RETIRED" end
  self.label:SetFont(M.Theme and M.Theme.font or STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",12*textScale,"")
  if not live() then return false,"DURABILITY_SCOPE_RETIRED" end
  local measured=public(self.label,"GetStringWidth","number")
  if not live() then return false,"DURABILITY_SCOPE_RETIRED" end
  if measured and measured>layout.width-20 then
   self.label:SetFont(M.Theme and M.Theme.font or STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",math.max(10,12*textScale*(layout.width-20)/measured),"")
   if not live() then return false,"DURABILITY_SCOPE_RETIRED" end
  end
  self.label:SetTextColor(unpack(theme("secondary",{1,.82,.18,1})))
  if not live() then return false,"DURABILITY_SCOPE_RETIRED" end
  self.layout=layout;self.layoutProfile=profile;self.textScale=textScale
 end
 self.surface.layout=layout;self.surface.layoutPending=nil;self.layoutDirty=nil
 return true
end
local function restoreProperty(owner,frame,key,getter,setter,live)
 if live and not live() then return false end
 local receipt=owner and owner.lookup and owner.lookup[frame] and owner.lookup[frame][key]
 if not receipt then return true end
 local current,state=public(frame,getter)
 if live and not live() then return false end
 if state~="KNOWN" or not S:Readable(current) then return false end
 -- Another writer wins. Never reassert our baseline over a later value.
 if receipt.written and current~=receipt.written[1] and current~=receipt.original[1] then return true end
 return L:Scalar(owner,frame,key,getter,setter,receipt.original[1])
end
function D:Unmask(provider,row,live)
 if live and not live() then return false end
 local owner=row and row.leaseOwner
 if not owner then return true end
 local mouse=restoreProperty(owner,row.frame,"durabilityMouse","IsMouseEnabled","EnableMouse",live)
 -- A synchronous native hook may have installed a newer custom claim. Its
 -- alpha mask must survive this older handback, even in the same generation.
 if not mouse or live and not live() then return false end
 local alpha=restoreProperty(owner,row.frame,"alpha","GetAlpha","SetAlpha",live)
 return alpha and (not live or live())
end
function D:Mask(provider,row,live)
 if live and not live() then return false,"DURABILITY_SCOPE_RETIRED" end
 local owner=provider:RootOwner(row);local frame=row.frame
 -- Only its passive pixels and tooltip hit region are borrowed. Native
 -- Show/Hide, dimensions, anchors, SetAlerts and event delivery stay intact.
 local mouse=public(frame,"IsMouseEnabled","boolean")
 if live and not live() then return false,"DURABILITY_SCOPE_RETIRED" end
 if type(mouse)~="boolean" then return false,"NATIVE_WARNING_INPUT_UNAVAILABLE" end
 local okay=L:Scalar(owner,frame,"durabilityMouse","IsMouseEnabled","EnableMouse",false)
 if live and not live() then return false,"DURABILITY_SCOPE_RETIRED" end
 if okay then okay=L:Alpha(owner,frame,0) end
 if live and not live() then return false,"DURABILITY_SCOPE_RETIRED" end
 if not okay then return false,"NATIVE_WARNING_MASK_PENDING" end
 return true
end
function D:Handback(provider,row,live,status)
 local restored=self:Unmask(provider,row,live)
 if not live() then return false,"DURABILITY_SCOPE_RETIRED" end
 if restored then
  self.claimed=false;self:SetPresentation(false);self.status=status
 else
  self.layoutDirty=true;provider.combatPending=true
  self.status="DURABILITY_NATIVE_RESTORE_PENDING"
  self:SetPresentation(self.claimed==true and self.warning==true)
 end
 return restored,self.status
end
function D:SetPresentation(ready)
 local surface=self.surface
 if not surface then return end
 local hidden=not ready or self.warning~=true
 if surface.presentationHidden~=hidden then surface.presentationHidden=hidden;M.state.forceEvaluate=true end
end
function D:Skin(provider,row)
 local profile,generation=M.profile,provider.generation
 self.request=(self.request or 0)+1;local request=self.request
 self.provider,self.row,self.profile=provider,row,profile
 local function current() return D:Current(provider,row,profile,generation,request) end
 if not current() then return false end
 -- Keep the exact native invalidation edges even if this first observation
 -- or custom layout is not ready. A native UpdateShownState/SetAlerts pass
 -- can make the warning usable again without a new equipment event; waiting
 -- until success to watch those methods strands the native fallback.
 L:Hook(provider,row.frame,"SetAlerts",function() provider:MarkRoot(row,"style") end)
 L:Hook(provider,row.frame,"UpdateShownState",function() provider:MarkRoot(row,"style") end)
 if not current() then return false,"DURABILITY_SCOPE_RETIRED" end
 local initialized,why=self:Initialize(provider,current)
 if not initialized or not current() then return false,why end
 local warning,status,broken=self:Observe(current)
 if not current() then return false,"DURABILITY_SCOPE_RETIRED" end
 local changed=self.warning~=warning
 if warning==nil then
  local restored=self:Handback(provider,row,current,status)
  if not current() then return false,"DURABILITY_SCOPE_RETIRED" end
  if not restored then
   -- A protected native restore cannot run during combat. Retain the last
   -- confirmed warning until native pixels can be returned; never suppress
   -- both presentations merely because the next observation is unavailable.
   return false,self.status
  end
  self.warning,self.broken,self.status=nil,nil,status
  self.claimed=false;self:SetPresentation(false)
  if changed and M.SidebarLayout then M.SidebarLayout:RefreshFollowers() end
  return false,status
 end
 self.warning,self.broken,self.status=warning,broken,status
 -- Reserve the strip before fitting the objective viewport. The actual
 -- expanded/collapsed quest height then determines its immediate next row.
 if (changed or self.layoutDirty) and M.SidebarLayout then M.SidebarLayout:RefreshFollowers() end
 if not current() then return false,"DURABILITY_SCOPE_RETIRED" end
 local placed,detail=self:ApplyLayout()
 if not current() then return false,"DURABILITY_SCOPE_RETIRED" end
 if not placed then self:Handback(provider,row,current,detail);return false,detail end
 local masked,maskWhy=self:Mask(provider,row,current)
 if not current() then return false,"DURABILITY_SCOPE_RETIRED" end
 if not masked then self:Handback(provider,row,current,maskWhy);return false,maskWhy end
 self.claimed=true;self:SetPresentation(true)
 self.status=masked and status or maskWhy
 return masked,self.status
end
function D:Stop(provider,row)
 if self.provider~=provider or row and self.row~=row then return end
 self.request=(self.request or 0)+1;self.layoutRequest=(self.layoutRequest or 0)+1
 local request,frame,surface=self.request,self.frame,self.surface
 local function current()
  return self.request==request and self.provider==provider and self.row==nil and self.frame==frame and self.surface==surface
 end
 self.claimed=false;self.warning=nil;self.status="NATIVE_WARNING_RESTORED";self.row=nil
 if surface then
  surface.disabled=true;surface.presentationHidden=true
  if M.Effects and M.Effects.active then M.Effects.active[self.id]=nil end
  if M.Policy then M.Policy:Release(surface) end
 end
 if not current() then return end
 if frame then frame:SetAlpha(0);if not current() then return end;frame:Hide() end
 if not current() then return end
 M.state.forceEvaluate=true
end
function D:Bounds()
 if not self.frame or not self.layout then return nil end
 local out=M:Copy(self.layout);out.frame=self.frame;out.id=self.id;out.source="MIRAGE_DURABILITY_SIDEBAR"
 return out
end
function D:Status()
 return "durability_display="..self.status.."; durability_thresholds=NATIVE_GET_INVENTORY_ALERT_STATUS"
  .."; durability_layout=BELOW_ACTUAL_QUEST_SAME_WIDTH; durability_context=SHARED_NAVIGATION"
  .."; durability_native_rendering=NOT_RUN"
end
