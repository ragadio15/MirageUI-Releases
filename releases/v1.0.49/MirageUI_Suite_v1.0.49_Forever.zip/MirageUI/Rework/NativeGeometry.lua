-- Forever's EditModeSystemMixin replaces SetPoint/ClearAllPoints/SetScale with
-- Lua layout bookkeeping. Calling those overrides from an addon taints their
-- later native anchor pass. Use base widget methods for our reversible leases.
-- This does not grant protected access: all operations remain outside combat,
-- require the exact source/client boundary, and can be rejected by the engine.
local _,M=...
local R,S=M.Rework,M.Safety
local probe=CreateFrame("Frame")
local methods={}
for _,key in ipairs({"ClearAllPoints","SetPoint","SetSize","SetScale"}) do methods[key]=probe[key] end
probe:Hide()
local function gate(frame)
 if not R:Qualified() then return false,"UNQUALIFIED_CLIENT" end
 if S:InCombat() then return false,"COMBAT_LOCKDOWN" end
 if not S:Frame(frame,false) then return false,"NATIVE_FRAME_UNAVAILABLE" end
 return true
end
local function sameUnit(a,b)
 -- The shared lease reader uses this same property-specific roundoff bound.
 -- NativeGeometry is loaded first, so resolve the helper only at call time.
 if R.CombatLeases and R.CombatLeases.GeometryEqual then return R.CombatLeases:GeometryEqual(a,b) end
 return S:Number(a) and S:Number(b) and math.abs(a-b)<=math.max(.0001,math.max(math.abs(a),math.abs(b))*2^-22)
end
-- Legacy leased placement can select the same base method while retaining its
-- existing request/current-owner seals and per-field readback journal.
function R.NativeMethod(frame,key)
 if not methods[key] or not gate(frame) then return nil end
 local marker=key=="SetPoint" and "SetPointBase" or key=="ClearAllPoints" and "ClearAllPointsBase" or key=="SetScale" and "SetScaleBase"
 local ok,base=pcall(function() return marker and frame[marker] end)
 if ok and type(base)=="function" then return methods[key] end
 return nil
end
function R.NativeClearPoints(frame)
 local ok,why=gate(frame);if not ok then return false,why end
 local sent=pcall(methods.ClearAllPoints,frame)
 local count,state=S:Public(frame.GetNumPoints,"number",frame)
 return sent and state=="KNOWN" and count==0,"NATIVE_GEOMETRY_CLEAR_FAILED"
end
function R.NativeSetPoint(frame,point,relative,relativePoint,x,y)
 local ok,why=gate(frame);if not ok then return false,why end
 if not S:Text(point) or not S:Text(relativePoint) or not S:Readable(relative) or not S:Number(x) or not S:Number(y) then return false,"NATIVE_GEOMETRY_INVALID" end
 local sent=pcall(methods.SetPoint,frame,point,relative,relativePoint,x,y)
 local count,state=S:Public(frame.GetNumPoints,"number",frame)
 if not sent or state~="KNOWN" or count<1 or count>8 then return false,"NATIVE_GEOMETRY_POINT_FAILED" end
 for i=1,count do
  local good,a,b,c,d,e=pcall(frame.GetPoint,frame,i)
  if good and S:Text(a) and S:Readable(b) and S:Text(c) and S:Number(d) and S:Number(e)
   and a==point and b==relative and c==relativePoint and sameUnit(d,x) and sameUnit(e,y) then return true end
 end
 return false,"NATIVE_GEOMETRY_POINT_FAILED"
end
function R.NativeScale(frame,scale)
 local ok,why=gate(frame);if not ok then return false,why end
 if not S:Number(scale) or scale<=0 or scale>8 then return false,"NATIVE_GEOMETRY_INVALID" end
 local sent=pcall(methods.SetScale,frame,scale)
 local value,state=S:Public(frame.GetScale,"number",frame)
 return sent and state=="KNOWN" and sameUnit(value,scale),"NATIVE_GEOMETRY_SCALE_FAILED"
end
function R.NativeSize(frame,width,height)
 local ok,why=gate(frame);if not ok then return false,why end
 if not S:Number(width) or not S:Number(height) or width<=0 or height<=0 or width>8192 or height>8192 then return false,"NATIVE_GEOMETRY_INVALID" end
 local sent=pcall(methods.SetSize,frame,width,height)
 -- Verify the constraints just written, not the cached screen rectangle. The
 -- client lays out a hidden/reanchored native root in a later frame.
 local w,ws=S:Public(frame.GetWidth,"number",frame,true);local h,hs=S:Public(frame.GetHeight,"number",frame,true)
 if not sent or ws~="KNOWN" or hs~="KNOWN" or not sameUnit(w,width) or not sameUnit(h,height) then return false,"NATIVE_GEOMETRY_SIZE_FAILED" end
 return true
end
function R.NativeGeometry(frame,width,height,point,relative,relativePoint,x,y)
 local ok,why=gate(frame);if not ok then return false,why end
 if width~=nil or height~=nil then
  local sized,reason=R.NativeSize(frame,width,height);if not sized then return false,reason end
 end
 if not R.NativeClearPoints(frame) then return false,"NATIVE_GEOMETRY_CLEAR_FAILED" end
 return R.NativeSetPoint(frame,point,relative,relativePoint,x,y)
end
