local _,M=...
-- WP09 keeps the engine's projection, canvas, pins and secure map handlers.
-- Only the surrounding presentation and the native quest-log controls are owned.
local R,S,L=M.Rework,M.Safety,M.Rework.CombatLeases
local N=R.CombatFactory:New("maps","BlizzardSkin",{
 {name="WorldMapFrame",editable=false,noContext=true},
 {name="QuestMapFrame",editable=false,noContext=true},
 {name="BattlefieldMapFrame",editable=false,noContext=true},
 {name="BattlefieldMapTab",editable=false,noContext=true},
})
R.Navigation=N
N.cooperativeStyle=true
N.events.QUEST_LOG_UPDATE=true;N.events.QUEST_DATA_LOAD_RESULT=true
N.events.QUEST_WATCH_LIST_CHANGED=true;N.events.WORLD_MAP_UPDATE=true
N.events.ZONE_CHANGED_NEW_AREA=true;N.events.ZONE_CHANGED=true
N.events.SUPER_TRACKING_CHANGED=true;N.events.AREA_POIS_UPDATED=true
N.events.DISPLAY_SIZE_CHANGED=true;N.events.UI_SCALE_CHANGED=true
local function safeField(o,k) return L:Field(o,k) end
local function background(owner,object)
 if object and S:Frame(object,false) then
  L:Texture(owner,object,L.white)
  if type(safeField(object,"GetVertexColor"))=="function" then
   L:Color(owner,object,"vertexColor","GetVertexColor","SetVertexColor",.025,.035,.045,.96)
  end
 end
end
function N:Skin(row)
 local f=row.frame;local kit=R.WindowKit
 if not kit then return L:Gap(self) end
 local skip={}
 -- The canvas contains map tiles, world icons, fog of war and engine-managed
 -- secure hit targets. Never enumerate or reparent that subtree for a skin.
 local canvas=safeField(f,"ScrollContainer")
 if canvas then skip[canvas]=true end
 local blackout=safeField(f,"BlackoutFrame")
 if blackout then skip[blackout]=true end
 -- QuestMapFrame is an independently owned root and may be attached to a map.
 local quest=safeField(f,"QuestLog")
 if quest then skip[quest]=true end
 -- These registered overlays receive their own bounded traversal below. If
 -- they are also children of the outer frame, exclude them from its walk so
 -- neither their controls nor their continuation queues are visited twice.
 local overlays={}
 if row.spec.name=="WorldMapFrame" then
  local nativeOverlays=safeField(f,"overlayFrames")
  if nativeOverlays then L:List(self,nativeOverlays,64,function(overlay)
   overlays[#overlays+1]=overlay;skip[overlay]=true
  end) end
 end
 local ok,why=kit:StyleTree(self,f,{maxNodes=768,maxDepth=14,fill=.94,header=true,skip=skip,role="window"})
 if ok==false and why~="WINDOW_WORK_QUEUED" then L:Gap(self) end
 for _,method in ipairs({"Show","RefreshQuestLog","RefreshOverlayFrames","AddOverlayFrame","SetMapID","SetDisplayState","Minimize","Maximize","UpdateLayout"}) do L:Hook(self,f,method) end
 if row.spec.name=="WorldMapFrame" then
  -- These overlays are children of the outer map, distinct from map pins.
  -- The public list is populated by WorldMapMixin:AddOverlayFrame in 70862.
  for _,overlay in ipairs(overlays) do
   local styled,reason=kit:StyleTree(self,overlay,{maxNodes=192,maxDepth=8,fill=.90,role="content"})
   if styled==false and reason~="WINDOW_WORK_QUEUED" then L:Gap(self) end
   for _,method in ipairs({"Show","Refresh","PostRefresh"}) do L:Hook(self,overlay,method) end
  end
  local overscroll=safeField(f,"OverscrollBG")
  background(self,safeField(overscroll,"Texture"))
  for _,key in ipairs({"TopLeftVignette","TopRightVignette","BottomLeftVignette","BottomRightVignette"}) do L:Alpha(self,safeField(overscroll,key),0) end
  local border=safeField(f,"BorderFrame")
  for _,key in ipairs({"Portrait","PortraitContainer","TopTileStreaks","InsetBorderTop"}) do L:Alpha(self,safeField(border,key),0) end
  local tracking=safeField(f,"WorldMapTrackingOptionsButton")
  if tracking then L:Glyph(self,tracking,"≡") end
 elseif row.spec.name=="BattlefieldMapFrame" then
  local border=safeField(f,"BorderFrame")
  for _,key in ipairs({"TopLeft","TopRight","BottomLeft","BottomRight","Top","Bottom","Left","Right"}) do L:Alpha(self,safeField(border,key),0) end
 elseif row.spec.name=="BattlefieldMapTab" then
  for _,key in ipairs({"Left","Middle","Right"}) do L:Alpha(self,safeField(f,key),0) end
 end
end
function N:Status()
 return self.status.."; windows="..(self.found or 0).."; properties="..(self.styled or 0).."/"..(self.expected or 0)
  .."; gaps="..(self.gaps or 0).."; canvas=ENGINE_PROJECTION; input=NATIVE_RETAINED; placement=AUTHORED_NATIVE; native=NOT_RUN"
end
-- A queued tree is a continuation of its existing root paint. Reconfiguring
-- here advanced the lease generation and discarded the queue on every tick,
-- so a large map repeatedly painted its prefix instead of reaching the end.
-- The shared Tick/demand probe keep that generation, budget and root identity.
local tick=N.Tick
function N:Tick(now)
 if self.active and S:InCombat() and (self.dirty or self.stylePending) then self.status="MAP_PRESENTATION_COMBAT_DEFERRED" end
 return tick(self,now)
end
