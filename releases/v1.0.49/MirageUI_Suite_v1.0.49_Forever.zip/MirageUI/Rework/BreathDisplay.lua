local _,M=...
-- A custom presentation on the client's exact mirror-timer widgets. The
-- native container retains Setup/Clear, pause/refill, event ownership, values,
-- OnUpdate and the lifetime of each of its three reusable timer slots.
local R,S,L=M.Rework,M.Safety,M.Rework.CombatLeases
local B={};R.BreathDisplay=B
local pack=L.Pack
local backgrounds={["ui-castingbar-background"]="hide"}
local function token(name,fallback)
 local value=M.Theme and M.Theme[name]
 return type(value)=="table" and value or fallback
end
local function current(provider,row,generation,profile)
 local function owned()
  return provider.active and provider.roots.MirrorTimerContainer==row
   and row.frame==_G.MirrorTimerContainer and not row.leaseBlocked
   and (generation==nil or provider.generation==generation) and (profile==nil or M.profile==profile)
 end
 return owned() and R:Qualified() and R:Selected(provider.id) and not M.state.safe and not R:NativeEditing() and owned()
end
local function supports(object,methods)
 if not S:Frame(object,false) then return false end
 for _,name in ipairs(methods) do if type(L:Field(object,name))~="function" then return false end end
 return true
end
function B:SkinTimer(provider,row,timer)
 local generation,profile=provider.generation,M.profile
 local function live() return current(provider,row,generation,profile) end
 local bar,text=L:Field(timer,"StatusBar"),L:Field(timer,"Text")
 -- An incomplete or replaced native widget keeps its functional presentation.
 -- No duration, progress, timer name or native label is needed to admit art.
 if not supports(timer,{"GetFrameLevel","CreateTexture","GetRegions"})
  or not supports(bar,{"GetStatusBarTexture","SetStatusBarTexture","GetStatusBarColor","SetStatusBarColor",
   "GetWidth","GetHeight","SetSize","GetNumPoints","GetPoint","ClearAllPoints","SetPoint","GetFrameLevel"})
  or not supports(text,{"GetFont","SetFont","GetTextColor","SetTextColor","GetHeight","SetHeight",
   "GetNumPoints","GetPoint","ClearAllPoints","SetPoint"}) then return false,"NATIVE_TIMER_INCOMPLETE" end
 local level=L:Public(bar,"GetFrameLevel","number")
 if not level or level<1 or not live() then return false,"NATIVE_TIMER_LAYER_UNAVAILABLE" end
 -- Create the native-child decoration while the root is prepared out of
 -- combat, including when no timer is active. Entering water in combat then
 -- needs only the native timer's existing value/lifetime updates.
 local panel=L:Panel(provider,timer,timer,"breath",.94)
 if not panel or not live() then return false,"TIMER_CHROME_PENDING" end
 local bg=token("background",{.035,.035,.038,.98})
 local edge=token("edge",{.26,.26,.26,1})
 local accent=token("accent",{1,.59,0,1})
 local gold=token("secondary",{1,.82,.18,1})
 if not S:InCombat() then
  -- Native StatusBar is lowered by its XML OnLoad. Keep our complete panel
  -- strictly below that bar and the native label, never over their content.
  if L:Public(panel,"GetFrameLevel","number")~=level-1 then panel:SetFrameLevel(level-1) end
  local pieces=panel.miragePanelPieces
  pieces.fill:SetTexture(L.white);pieces.fill:SetVertexColor(bg[1],bg[2],bg[3],.94)
  for _,side in ipairs({"TOP","BOTTOM","LEFT","RIGHT"}) do
   local color=side=="TOP" and accent or edge
   pieces[side]:SetVertexColor(color[1],color[2],color[3],side=="TOP" and .78 or .70)
  end
  local track=pieces.airTrack
  if not track then
   track=panel:CreateTexture(nil,"ARTWORK");pieces.airTrack=track
   track:SetTexture(L.white);track:SetAllPoints(bar)
  end
  track:SetVertexColor(.13,.13,.14,.92)
 end
 if not live() then return false,"TIMER_OWNER_CHANGED" end
 local ok=L:AnchoredSize(provider,text,nil,14,pack("TOPLEFT",timer,"TOPLEFT",8,-3,"TOPRIGHT",timer,"TOPRIGHT",-8,-3))
 if not live() then return false,"TIMER_OWNER_CHANGED" end
 ok=L:AnchoredSize(provider,bar,nil,6,pack("BOTTOMLEFT",timer,"BOTTOMLEFT",8,5,"BOTTOMRIGHT",timer,"BOTTOMRIGHT",-8,5)) and ok
 if not live() then return false,"TIMER_OWNER_CHANGED" end
 ok=L:Font(provider,text,12) and ok
 if not live() then return false,"TIMER_OWNER_CHANGED" end
 ok=L:Color(provider,text,"breathTextColor","GetTextColor","SetTextColor",accent[1],accent[2],accent[3],1) and ok
 if not live() then return false,"TIMER_OWNER_CHANGED" end
 local kind=L:Field(timer,"timer")
 local breath=kind==nil or kind=="BREATH"
 -- Idle slots are prepared for breath. Other mirror timers retain the
 -- client's distinct fill atlas and severity; Setup restores it on reuse.
 if breath then ok=L:Bar(provider,bar,L.white) and ok end
 if not live() then return false,"TIMER_OWNER_CHANGED" end
 local fill=breath and gold or {1,1,1,1}
 ok=L:Color(provider,bar,"breathBarColor","GetStatusBarColor","SetStatusBarColor",fill[1],fill[2],fill[3],1) and ok
 if not live() then return false,"TIMER_OWNER_CHANGED" end
 if not ok then
  L:HidePanel(provider,timer,"breath")
  return false,"TIMER_PRESENTATION_PENDING"
 end
 -- Retire only the three source-defined decorative regions. The original
 -- status bar, label, parent, event registration and scripts stay in place.
 ok=L:DecorativeAlpha(provider,L:Field(timer,"Border"),0) and ok
 if not live() then return false,"TIMER_OWNER_CHANGED" end
 ok=L:DecorativeAlpha(provider,L:Field(timer,"TextBorder"),0) and ok
 if not live() then return false,"TIMER_OWNER_CHANGED" end
 L:Regions(provider,timer,backgrounds)
 if not live() then return false,"TIMER_OWNER_CHANGED" end
 L:Hook(provider,timer,"Setup",function()
  if current(provider,row) then provider:MarkRoot(row,"style") end
 end)
 L:Hook(provider,timer,"Clear",function()
  if current(provider,row) then provider:MarkRoot(row,"style") end
 end)
 return ok,ok and "NATIVE_TIMER_CUSTOM_PRESENTATION" or "TIMER_ART_PENDING"
end
function B:Skin(provider,row)
 if not current(provider,row) then return false end
 local generation,profile=provider.generation,M.profile
 local count,ready=0,0
 L:List(provider,L:Field(row.frame,"mirrorTimers"),3,function(timer)
  if not current(provider,row,generation,profile) then return end
  count=count+1
  local ok,why=self:SkinTimer(provider,row,timer)
  if ok then ready=ready+1 else row.breathReason=why;L:Gap(provider,"breath",why) end
 end)
 if not current(provider,row,generation,profile) then return false end
 row.breathPrepared=ready;row.breathSlots=count
 if count>0 and ready==count then row.breathReason="NATIVE_TIMER_CUSTOM_PRESENTATION" end
 return count>0 and ready==count
end
function B:Status(provider)
 local row=provider and provider.roots and provider.roots.MirrorTimerContainer
 return (row and row.breathReason or "WAITING_NATIVE_TIMER").."; breath_slots_prepared="..(row and row.breathPrepared or 0)
  .."; breath_value_owner=NATIVE; breath_lifetime=NATIVE; breath_native_rendering=NOT_RUN"
end
