local _,M=...
-- Named Forever 70862 windows. Native models, focus, bindings, confirmations,
-- group actions and browser/model canvases remain authoritative. The custom
-- presentation never calls an action, changes a script or opens a window.
local R,S,L,K=M.Rework,M.Safety,M.Rework.CombatLeases,M.Rework.WindowKit
local F=R.CombatFactory
local specs={}
local function windows(group,names)
 for _,name in ipairs(names) do specs[#specs+1]={name=name,group=group,editable=false,noContext=true} end
end
windows("social",{"FriendsFrame","SocialUIFrame","FriendsFriendsFrame","AddFriendFrame","BattleNetInviteFrame",
 "QuickJoinRoleSelectionFrame","RecruitAFriendRecruitmentFrame","RecruitAFriendRewardsFrame",
 "CommunitiesFrame","CommunitiesSettingsDialog","CommunitiesTicketManagerDialog","CommunitiesAvatarPickerDialog",
 "CommunitiesGuildTextEditFrame","CommunitiesGuildLogFrame","CommunitiesGuildNewsFiltersFrame","GuildControlUI",
 "GuildInviteFrame","GuildRegistrarFrame","PetitionFrame","TabardFrame"})
windows("groups",{"PVEFrame","LFGListApplicationDialog","LFGListInviteDialog","LFGDungeonReadyPopup",
 "LFGReadyCheckPopup","LFDRoleCheckPopup","LFGInvitePopup","QueueStatusFrame","QueueStatusButton","ReadyCheckFrame","RolePollPopup","RoleChangedFrame",
 "PVPFramePopup","PlunderstormFramePopup","PVPRoleCheckPopup","PVPReadyDialog","PVPReadyPopup","PlunderstormQueueTutorialFrame",
 "RaidParentFrame","RaidFrame","RaidInfoFrame","InstanceAbandonPopup","InstanceAbandonFrame","PVPRankFrame"})
windows("system",{"GameMenuFrame","SettingsPanel","ClickBindingFrame","AddonList","AddonDialog","HelpFrame",
 "TicketStatusFrame","ReportCheatingDialog"})
windows("secondary",{"AchievementFrame","AchievementFrameAchievementsObjectives","CollectionsJournal","CalendarFrame",
 "EncounterJournal","DressUpFrame","SideDressUpFrame","TransmogAndMountDressupFrame","GroupLootHistoryFrame","DestinyFrame","TrackingInterfaceShortcutsFrame"})
windows("temporary",{"AlertFrame","BossBanner","RaidWarningFrame","HonorLevelUpBanner","PrestigeLevelUpBanner"})
local P=F:New("system","BlizzardSkin",specs);R.SystemWindows=P
-- No speculative event subscriptions: common ADDON_LOADED, world, native-edit
-- and regen events plus passive source-method hooks cover these native windows.
P.windowStates={};P.nodeOwners={};P.nodeCache=setmetatable({},{__mode="k"});P.nodeCount=0
P.maximumNodes=2048
local function live(self)
 return self.active and R:Qualified() and R:Selected(self.id) and not M.state.safe and not R:NativeEditing()
end
local function shown(frame)
 local visible,state=L:Public(frame,"IsVisible","boolean")
 if state=="KNOWN" then return visible end
 local x=frame
 for _=1,24 do
  local value,known=L:Public(x,"IsShown","boolean")
  if known~="KNOWN" or not value then return false end
  x=L:Public(x,"GetParent")
  if not x then return true end
 end
 return false
end
local function identity(frame)
 -- Reference equality of public row data is enough to notice pooled rebinding;
 -- content is never inspected, formatted, persisted or exported.
 local get=L:Field(frame,"GetElementData")
 if type(get)=="function" then
  local ok,value=pcall(get,frame);if ok and S:Readable(value) then return value end
 end
end
local function parent(frame) return L:Public(frame,"GetParent") end
local function descendant(frame,root)
 for _=1,24 do
  if rawequal(frame,root) then return true end
  frame=parent(frame);if not frame then return false end
 end
 return false
end
function P:SkipRoots(root)
 local skip={}
 -- Each named root has one lease owner, even if it is currently parented to a
 -- different pack (PVPRankFrame is normally a CharacterFrame child).
 for _,spec in ipairs(self.specs) do local f=_G[spec.name];if f and f~=root then skip[f]=true end end
 for name,id in pairs(R.nativeOwners or {}) do
  local f=_G[name];if id~=self.id and f and f~=root then skip[f]=true end
 end
 -- Exact XML HelpFrame.xml defines a native Browser widget; its web canvas is
 -- engine-rendered. The surrounding help window and native error UI are styled.
 if _G.HelpBrowser then skip[_G.HelpBrowser]=true end
 return skip
end
local updateMethods={"InitButtons","UpdateButtons","UpdateCategories","UpdateSearchResults","UpdateResults",
 "UpdateList","UpdateListContents","RefreshList","RefreshView","OnTabChanged","SetSelectedTab","SetTab",
 "SetSelectedCategory","SelectCategory","DisplayCategory","DisplayLayout","SettingsUpdated","CategoriesUpdated",
 "ScrollToElementData","UpdateVisibleItems","UpdateEntries",
 "UpdateAchievements","UpdateSummary","UpdateCalendar","UpdateRoster","UpdateApplications","SetDisplayMode",
 "FullUpdate","Rebuild","UpdateElements","SetElementData","Init","Initialize","PlayBanner","StopBanner",
 "AddAlertFrame","AddAlertFrameSubSystem","UpdateAnchors","ReparentAlerts","AddMessage","AcquireSlot","AcquireOrEvictSlot"}
function P:HookLateBannerContent()
 -- These exact global functions create/rebind loot rows after BossBanner's
 -- initial OnShow. A post-hook only schedules a pass outside native dispatch.
 if S:InCombat() or type(hooksecurefunc)~="function" then return end
 self.bannerGlobalHooks=self.bannerGlobalHooks or {}
 for _,name in ipairs({"BossBanner_AnimLootInsert","BossBanner_ConfigureLootFrame"}) do
  if not self.bannerGlobalHooks[name] and type(_G[name])=="function" then
   local ok=pcall(hooksecurefunc,name,function() if self.active then K:MarkWindowDirty(self,_G.BossBanner) end end)
   if ok then self.bannerGlobalHooks[name]=true end
  end
 end
end
function P:TransientArtwork(owner,frame,preserve)
 local get=L:Field(frame,"GetRegions");if type(get)~="function" then return end
 local ok,regions=pcall(function() return {get(frame)} end)
 if not ok or #regions>96 then L:Gap(owner);return end
 local icon=L:Field(frame,"Icon") or L:Field(frame,"icon")
 for _,region in ipairs(regions) do if region~=icon and L:Public(region,"GetObjectType","string")=="Texture" then
  local receipt=owner.lookup[region] and owner.lookup[region].texture
  local original=receipt and receipt.original
  local atlas=original and original[2] or L:Public(region,"GetAtlas","string")
  local path=original and original[1] or L:Public(region,"GetTexture")
  atlas=S:Text(atlas) and atlas:lower() or "";path=S:Text(path) and path:lower():gsub("/","\\") or ""
  local decorative=atlas:find("bossbanner%-bg") or atlas:find("bossbanner%-.*fillagree") or atlas:find("bossbanner%-skullspikes")
   or atlas:find("lootbanner%-itembg") or atlas:find("ui%-achievement%-alert") or atlas:find("toast%-frame")
   or atlas:find("toast%-flash") or atlas:find("toast%-iconbg") or atlas:find("loottoast%-bg")
   or atlas:find("loottoast%-glow") or atlas:find("loottoast%-sheen") or atlas:find("recruitafriend_.*toast")
   or atlas:find("bonusobjectives%-title%-bg") or atlas:find("titleprestige%-")
   or atlas:find("garr_.*toast") or atlas:find("shipmission_toast") or path:find("interface\\lootframe\\loottoast",1,true)
   or path:find("interface\\achievementframe\\ui-achievement-alert-glow",1,true)
  -- The original fading and animation tracks continue to drive the same region.
  -- Do not set its alpha, shown state, elapsed time or queue/reward identity.
  if decorative then
   preserve[region]=true
   local glow=atlas:find("glow") or atlas:find("shine") or atlas:find("flash") or atlas:find("sheen") or path:find("glow")
   L:Texture(owner,region,glow and L.beam or L.panel)
   -- LootBanner's native background tint carries item quality, so preserve it.
   if not atlas:find("lootbanner%-itembg") then
    L:Color(owner,region,"transientTint","GetVertexColor","SetVertexColor",glow and 1 or .04,glow and .66 or .055,glow and .2 or .065,1)
   end
  end
 end end
end
function P:PreserveQueueStateIcons(frame,preserve)
 -- LFGEyeTemplate's sprite frames are native queue/search/found state icons.
 -- Keep their visibility/flipbook animation while custom panels replace chrome.
 local fn=L:Field(frame,"GetRegions");if type(fn)~="function" then return end
 local ok,regions=pcall(function() return {fn(frame)} end)
 if not ok or #regions>96 then return end
 for _,region in ipairs(regions) do
  local atlas=L:Public(region,"GetAtlas","string")
  if S:Text(atlas) and atlas:lower():find("^groupfinder%-eye") then preserve[region]=true end
 end
end
function P:ModelChrome(model,root)
 if not S:Frame(model,false) then return end
 local objectType=L:Public(model,"GetObjectType","string")
 if objectType~="ModelScene" and objectType~="DressUpModel" and objectType~="PlayerModel" and objectType~="Model" then return end
 K:HookScript(self,model,"OnShow");K:HookScript(self,model,"OnHide")
 if not shown(model) then return end
 self.modelSeen=self.modelSeen or setmetatable({},{__mode="k"})
 if self.modelSeen[model]==self.scanEpoch then return end
 self.modelSeen[model]=self.scanEpoch
 local owner=self:NodeOwner(model,root);if not owner then return end
 -- These are explicit public chrome fields in DressUpFrames, MountCollection,
 -- Classic PetCollection and EncounterJournal XML. Never enumerate scene actors,
 -- camera state, model data, animations or arbitrary ModelScene descendants.
 for _,key in ipairs({"BGTopLeft","BGTopRight","BGBottomLeft","BGBottomRight","dungeonBG"}) do
  local texture=L:Field(model,key)
  if texture and L:Public(texture,"GetObjectType","string")=="Texture" then
   L:Texture(owner,texture,L.panel);L:Color(owner,texture,"modelPanelTint","GetVertexColor","SetVertexColor",.04,.055,.065,1)
  end
 end
 local n=L:Public(model,"GetName","string")
 if n then for _,suffix in ipairs({"Shadow","TitleBG"}) do
  local t=_G[n..suffix]
  if S:Frame(t,false) and parent(t)==model then L:Texture(owner,t,L.panel) end
 end end
 for _,key in ipairs({"imageTitle","modelDisplayIdLabel","modelDisplayId","modelName","modelNameLabel","NewString"}) do
  K:StyleFont(owner,L:Field(model,key))
 end
 -- Collected/selected/disabled overlays retain native visibility and tint on
 -- wardrobe tiles. The thin custom band keeps those state channels distinct.
 for _,key in ipairs({"Border","TransmogStateTexture"}) do
  local t=L:Field(model,key);if t and L:Public(t,"GetObjectType","string")=="Texture" then L:Underline(owner,t,model) end
 end
 local disabled=L:Field(model,"DisabledOverlay")
 if disabled then L:Texture(owner,disabled,L.white) end
 for _,key in ipairs({"ControlFrame","TogglePlayer","RotateLeftButton","RotateRightButton","Favorite","HideVisual"}) do
  local control=L:Field(model,key)
  if control and S:Frame(control,false) then
   K:StyleTree(self,control,{role="content",visibleOnly=true,maxNodes=64,maxDepth=6,
    leaseOwner=function(node) return self:NodeOwner(node,root) end,
    visit=function(node,nodeOwner) return self:Visit(node,nodeOwner,nil) end})
   if (key=="RotateLeftButton" or key=="RotateRightButton") and shown(control) then
    local nodeOwner=self.nodeOwners[control]
    if nodeOwner and K:Panel(nodeOwner,control,.75) then
     local normal=L:Public(control,"GetNormalTexture");if normal then L:Alpha(nodeOwner,normal,0) end
     local cache=nodeOwner.decorations[control];local label=cache.m04ModelGlyph
     if not label then label=control:CreateFontString(nil,"OVERLAY");cache.m04ModelGlyph=label;K.owned[label]=true end
     label:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",15,"");label:SetAllPoints(control)
     label:SetTextColor(1,.66,.20,1);label:SetText(key=="RotateLeftButton" and "‹" or "›");label:Show()
    end
   end
  end
 end
 for _,method in ipairs({"OnDressModel","Refresh","Update","SetSelectedAppearance"}) do K:WatchNative(self,model,method) end
end
function P:Visit(frame,owner,root)
 local objectType=L:Public(frame,"GetObjectType","string")
 if objectType=="Browser" or objectType=="ModelScene" or objectType=="Model" or objectType=="PlayerModel"
  or objectType=="DressUpModel" or objectType=="GameTooltip" then return false end
 if frame==root then K:Panel(owner,frame,.95) end
 K:HookScript(self,frame,"OnHide")
 if frame==_G.PVPFramePopup then
  local ring=_G.PVPFramePopupRing
  if S:Frame(ring,false) and parent(ring)==frame then L:Underline(owner,ring,frame) end
 end
 for _,method in ipairs(updateMethods) do K:WatchNative(self,frame,method) end
 local nativeRoot=owner.root
 for _,key in ipairs({"ModelScene","modelScene","model","Model"}) do
  local model=L:Field(frame,key);if model then self:ModelChrome(model,nativeRoot) end
 end
 local models=L:Field(frame,"Models")
 if S:Readable(models) and type(models)=="table" then
  for i=1,33 do
   local model,known=S:FieldAccess(models,i);if known=="ABSENT" then break end
   if i>32 then self.windowScanLimited=true;L:Gap(self);break end
   if known=="KNOWN" then self:ModelChrome(model,nativeRoot) else L:Gap(self) end
  end
 end
 -- Search result and permission/state colors remain native. Shared WindowKit
 -- handles real text, checkboxes, button states, sliders, dropdowns, item icons,
 -- HTML and scroll rows without changing native input geometry.
 return true
end
function P:Skin(row)
 local frame=row.frame;local state={group=row.spec.group,native="NOT_RUN"}
 self.windowStates[row.spec.name]=state
 if row.spec.name=="AlertFrame" then return self:SkinAlertPools(row,state) end
 if not shown(frame) then state.state="WAITING_FOR_OPEN";return end
 local before=self.gaps or 0
 local preserve={};local transient=row.spec.group=="temporary"
 local ok=K:StyleTree(self,frame,{role="content",visibleOnly=true,maxNodes=1024,maxDepth=14,
  skip=self:SkipRoots(frame),preserveTextures=preserve,
  leaseOwner=function(node) return self:NodeOwner(node,frame) end,
  visit=function(node,owner)
   if transient then self:TransientArtwork(owner,node,preserve) end
   if row.spec.group=="groups" then self:PreserveQueueStateIcons(node,preserve) end
   -- Animated banners retain native per-region alpha tracks. An extra opaque
   -- root panel would bypass those fades. Warning text likewise has no window;
   -- the normal font pass never reads or changes the native message value.
   local panelRoot=frame;if transient then panelRoot=nil end
   return self:Visit(node,owner,panelRoot)
  end})
 state.state=ok and (self.gaps or 0)==before and "CUSTOM_CONTROLS_READY" or "PARTIAL_NEEDS_ATTENTION"
 state.input="NATIVE_IDENTITIES_RETAINED";state.geometry="NATIVE_WINDOW_MANAGER"
end
function P:SkinAlertPools(row,state)
 local frame=row.frame;local list=L:Field(frame,"alertFrameSubSystems")
 for _,method in ipairs({"AddAlertFrame","AddAlertFrameSubSystem","UpdateAnchors","ReparentAlerts"}) do K:WatchNative(self,frame,method) end
 if not S:Readable(list) or type(list)~="table" then state.state="WAITING_FOR_NATIVE_CONTENT";return end
 local count,before=0,self.gaps or 0
 self.alertFrames={}
 for i=1,65 do
  local system,known=S:FieldAccess(list,i)
  if known=="ABSENT" then break end
  if i>64 then self.windowScanLimited=true;L:Gap(self);break end
  if known~="KNOWN" then L:Gap(self)
  else
   local pool=L:Field(system,"alertFramePool")
   if pool then L:Pool(self,pool,32,function(alert)
    if self.alertFrames[alert] or not shown(alert) then return end
    if count>=128 then self.windowScanLimited=true;L:Gap(self);return end
    self.alertFrames[alert]=true;count=count+1
    local preserve={}
    K:StyleTree(self,alert,{role="content",visibleOnly=true,maxNodes=256,maxDepth=12,
     skip=self:SkipRoots(alert),preserveTextures=preserve,
     leaseOwner=function(node) return self:NodeOwner(node,alert) end,
     visit=function(node,owner)
      self:TransientArtwork(owner,node,preserve)
      return self:Visit(node,owner,nil)
     end})
   end) end
  end
 end
 self.alertPoolCount=count
 state.state=(self.gaps or 0)>before and "PARTIAL_NEEDS_ATTENTION" or count>0 and "CUSTOM_CONTROLS_READY" or "WAITING_FOR_NATIVE_CONTENT"
 state.input="NATIVE_QUEUE_CLICK_AND_FADE_RETAINED";state.geometry="NATIVE_ALERT_STACK"
end
function P:WindowStatus(name)
 local state=self.windowStates[name]
 return state and state.state or "NOT_INITIALIZED"
end
function P:Status()
 local ready,partial,waiting=0,0,0
 for _,row in pairs(self.windowStates) do
  if row.state=="CUSTOM_CONTROLS_READY" then ready=ready+1
  elseif row.state=="PARTIAL_NEEDS_ATTENTION" or row.state=="INACCESSIBLE_NATIVE_SURFACE" or row.state=="RESTORE_PENDING" then partial=partial+1
  else waiting=waiting+1 end
 end
 return (self.status or "NOT_INITIALIZED").."; pack=SOCIAL_GROUP_SYSTEM_SECONDARY; windows="..#self.specs
  .."; ready="..ready.."; waiting="..waiting.."; partial="..partial.."; active_nodes="..self.nodeCount
  .."; alert_pool_frames="..(self.alertPoolCount or 0).."; controls=NATIVE_IDENTITIES_PRESERVED; secure_community_dialog=ENGINE_EXCEPTION; browser_canvas=ENGINE_EXCEPTION; private_boss_emotes=ENGINE_EXCEPTION; native=NOT_RUN"
end

K:InstallIsolatedPack(P)
