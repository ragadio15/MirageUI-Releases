local _,M=...
-- M03 window controls retain their native click, drag, focus and transaction
-- handlers. Only presentation properties are leased. The kit is used by named
-- packs; it never walks UIParent, a model scene, a map canvas or forbidden data.
local R,S,L=M.Rework,M.Safety,M.Rework.CombatLeases
local pack=L.Pack
local K={owned=setmetatable({},{__mode="k"})}
R.WindowKit=K
local function selected(owner)
 return owner.active and not owner.releasing and R:Qualified() and R:Selected(owner.id)
  and (not owner.parentOwner or owner.parentOwner.active and owner.parentGeneration==owner.parentOwner.generation)
  and not M.state.safe and not R:NativeEditing()
end
local function kind(o) return L:Public(o,"GetObjectType","string") end
local function text(v) return S:Text(v) and v or "" end
local function name(o) return text(L:Public(o,"GetName","string")) end
local function color(owner,o,key,r,g,b,a)
 return L:Color(owner,o,key,"GetVertexColor","SetVertexColor",r,g,b,a)
end
local function point(texture,...)
 texture:ClearAllPoints();texture:SetPoint(...)
end
local function ownRegion(owner,parent,key,layer,sub)
 if not selected(owner) or not S:Frame(parent,false) then return end
 owner.decorations=owner.decorations or {}
 local cache=owner.decorations[parent]
 if not cache then cache={};owner.decorations[parent]=cache end
 local region=cache[key]
 if not region then
  if S:InCombat() then owner.combatPending=true;return end
  local make=L:Field(parent,"CreateTexture");if type(make)~="function" then return end
  local ok,value=pcall(make,parent,nil,layer,nil,sub or 0)
  if not ok or not S:Frame(value,false) then L:Gap(owner);return end
  region=value;cache[key]=region;K.owned[region]=true
 end
 if not S:InCombat() then region:Show() end
 return region
end
function K:Panel(owner,frame,fill)
 if not selected(owner) or not S:Frame(frame,false) then return false end
 if S:InCombat() then owner.combatPending=true;return false end
 -- These five regions are Mirage-owned and remain anchored to their parent.
 -- Reopening a native window does not require rewriting their texture,
 -- anchors and colors. A new journal generation recreates the visible paint
 -- after handback; native frame geometry still flows through the anchors.
 local panel=owner.windowPanelReceipts and owner.windowPanelReceipts[frame]
 if panel and panel.generation==owner.generation and panel.profile==M.profile and panel.fill==(fill or .94) then return true end
 local bg=ownRegion(owner,frame,"m03Fill","BACKGROUND",-8)
 if not bg then return false end
 bg:SetTexture(L.white);bg:ClearAllPoints();bg:SetAllPoints(frame)
 bg:SetVertexColor(.035,.035,.038,fill or .94)
 for _,edge in ipairs({"Top","Bottom","Left","Right"}) do
  local t=ownRegion(owner,frame,"m03Edge"..edge,"OVERLAY",7)
  if not t then return false end
  t:SetTexture(L.white);t:SetVertexColor(.26,.26,.26,1);t:ClearAllPoints()
  if edge=="Top" or edge=="Bottom" then
   t:SetPoint(edge=="Top" and "TOPLEFT" or "BOTTOMLEFT",frame,edge=="Top" and "TOPLEFT" or "BOTTOMLEFT",0,0)
   t:SetPoint(edge=="Top" and "TOPRIGHT" or "BOTTOMRIGHT",frame,edge=="Top" and "TOPRIGHT" or "BOTTOMRIGHT",0,0);t:SetHeight(1)
  else
   t:SetPoint(edge=="Left" and "TOPLEFT" or "TOPRIGHT",frame,edge=="Left" and "TOPLEFT" or "TOPRIGHT",0,0)
   t:SetPoint(edge=="Left" and "BOTTOMLEFT" or "BOTTOMRIGHT",frame,edge=="Left" and "BOTTOMLEFT" or "BOTTOMRIGHT",0,0);t:SetWidth(1)
  end
 end
 owner.windowPanelReceipts=owner.windowPanelReceipts or setmetatable({},{__mode="k"})
 owner.windowPanelReceipts[frame]={generation=owner.generation,profile=M.profile,fill=fill or .94}
 return true
end
function K:StyleFont(owner,font)
 if not font or not S:Frame(font,false) or type(L:Field(font,"GetFont"))~="function" then return true end
 local row=owner.lookup and owner.lookup[font] and owner.lookup[font].font
 local original=row and row.original
 local readable,path,size=pcall(font.GetFont,font)
 if not readable or not S:Readable(path) or not S:Readable(size) then return L:Gap(owner,"font","SNAPSHOT_UNAVAILABLE") end
 if original then path,size=original[1],original[2] end
 if not L:AssetEqual(path,path) or not S:Number(size) or size<=0 then
  -- Native pools can allocate empty FontStrings before assigning a font.
  -- There is nothing to paint yet, and nil is not a restorable SetFont value.
  -- Wake this owner when that region receives content; a nonempty unreadable
  -- label remains a real gap instead of being counted as completed styling.
  local getter=L:Field(font,"GetText")
  local public,value=false,nil
  if type(getter)=="function" then public,value=pcall(getter,font) end
  if kind(font)=="FontString" and public and S:Readable(value) and (value==nil or S:Text(value) and value=="") then
   owner.waitingFonts=(owner.waitingFonts or 0)+1
   for _,method in ipairs({"SetText","SetFormattedText","SetFontObject","Show"}) do L:Hook(owner,font,method) end
   return true
  end
  return L:Gap(owner,"font","SNAPSHOT_UNAVAILABLE")
 end
 local scale=M.profile and M.profile.textScale or 1
 if not S:Number(size) then return L:Gap(owner) end
 size=math.max(10,math.min(20,size))*scale
 local ok=L:Font(owner,font,size)
 local get=L:Field(font,"GetTextColor")
 if type(get)=="function" then
  local public,rr,gg,bb,aa=pcall(get,font)
  -- Dark parchment body text becomes readable on the custom dark panel.
  -- Quest/item quality, warnings, red errors and disabled gray remain semantic.
  if public and S:Number(rr) and S:Number(gg) and S:Number(bb) and rr<.35 and gg<.35 and bb<.35 then
   ok=L:Color(owner,font,"textColor","GetTextColor","SetTextColor",.90,.89,.87,aa or 1) and ok
  end
 end
 return ok
end
local decorationFields={"Bg","bg","Background","background","Background1Slot","Background2Slot","Background3Slot",
 "TitleBg","TitleBackground","DialogBG","InsetBg","InsetBackground","ButtonBorder","Border","border","BorderTop","BorderBottom",
 "TopLeftCorner","TopRightCorner","BottomLeftCorner","BottomRightCorner","TopEdge","BottomEdge","LeftEdge","RightEdge",
 "TopLeft","TopRight","BottomLeft","BottomRight","TopTile","BottomTile","LeftTile","RightTile",
 "PortraitFrame","PortraitFrameOverlay","PortraitFrameBg","TitleButtonHighlight","SlotTexture","NameFrame","Parchment"}
local function decorativeTexture(region,force)
 if K.owned[region] then return false end
 if force then return true end
 local n=name(region):lower()
 local atlas=text(L:Public(region,"GetAtlas","string")):lower()
 local path=L:Public(region,"GetTexture")
 path=type(path)=="string" and path:lower():gsub("/","\\") or ""
 if n:find("icon",1,true) or n:find("portrait",1,true) or n:find("highlight",1,true) then return false end
 local layer=L:Public(region,"GetDrawLayer","string")
 return layer=="BACKGROUND" or layer=="BORDER"
  or n:match("background")~=nil or n:match("border")~=nil or n:match("nameframe$")~=nil or n:match("^buybackbg$")~=nil
  -- Native frame layouts also use tiled _UI-Frame- and !UI-Frame- atlases.
  or atlas:match("^ui%-frame%-")~=nil or atlas:match("^[_!]ui%-frame%-")~=nil or atlas:match("^ui%-background%-")~=nil or atlas:match("^ui%-merchant%-")~=nil
  or atlas:match("^quest%-parchment")~=nil or atlas:match("^bank%-divider")~=nil
  or atlas:match("^bank%-frame%-")~=nil or atlas:match("^common%-dialog%-")~=nil
  or atlas:match("^common%-box%-")~=nil or atlas:match("^common%-coinbox")~=nil or atlas:match("^_common%-coinbox")~=nil
  or path:find("interface\\dialogframe\\",1,true)~=nil or path:find("interface\\paperdollinfoframe\\ui-char",1,true)~=nil
  or path:find("interface\\merchantframe\\",1,true)~=nil or path:find("interface\\containerframe\\ui-bag",1,true)~=nil
  or path:find("interface\\questframe\\ui-quest",1,true)~=nil or path:find("interface\\mailframe\\ui-mail",1,true)~=nil
  or path:find("interface\\tradeframe\\ui-trade",1,true)~=nil
  or path:match("ui%-emptyslot")~=nil or path:match("ui%-quickslot")~=nil
end
function K:Decorations(owner,frame,opts)
 opts=opts or {}
 local known,semantic={},{}
 for _,key in ipairs({"Icon","icon","iconTexture","Portrait","portrait","QualityStripe","HighlightNameFrame","PushedNameFrame",
  "Highlight","HighlightTexture","Selection","Selected","SelectedTexture","selected","SelectionTexture",
  "DisabledOverlay","IconQuestTexture","NewItemTexture","BattlepayItemTexture","JunkIcon","UpgradeIcon","Check","CheckMark"}) do
  local region=L:Field(frame,key);if region then semantic[region]=true end
 end
 for _,key in ipairs(decorationFields) do
  local region=L:Field(frame,key)
  if region and kind(region)=="Texture" and not (opts.preserveTextures and opts.preserveTextures[region]) then known[region]=true end
 end
 local fn=L:Field(frame,"GetRegions")
 if type(fn)~="function" then return end
 local ok,regions=pcall(function() return {fn(frame)} end)
 if not ok or #regions>96 then L:Gap(owner);return end
 for _,region in ipairs(regions) do
  if not K.owned[region] and S:Frame(region,false) then
   local k=kind(region)
   if k=="FontString" then if opts.fonts~=false then self:StyleFont(owner,region) end
   elseif k=="Texture" and not semantic[region] and not (opts.preserveTextures and opts.preserveTextures[region]) and decorativeTexture(region,known[region]) then
    L:Alpha(owner,region,0)
   end
  end
 end
 -- Loot click/quality bands are native state channels. Repaint their actual
 -- texture without changing the engine's shown state, color or transaction.
 for _,key in ipairs({"QualityStripe","HighlightNameFrame","PushedNameFrame"}) do
  local region=L:Field(frame,key)
  if region and kind(region)=="Texture" and not (opts.preserveTextures and opts.preserveTextures[region]) then L:DecorativeTexture(owner,region,L.white) end
 end
 -- Source-defined selected-row textures may live on BACKGROUND or BORDER.
 -- Keep the native shown state and hit area while replacing the stock cue.
 for _,key in ipairs({"Selection","Selected","SelectedTexture","selected","SelectionTexture"}) do
  local region=L:Field(frame,key)
  if region and kind(region)=="Texture" and not (opts.preserveTextures and opts.preserveTextures[region]) then
   L:DecorativeTexture(owner,region,L.white);color(owner,region,"selectedTint",1,.66,.20,.18)
  end
 end
end
local function stateTexture(owner,button,getter,r,g,b,a)
 local texture=L:Public(button,getter)
 if not texture then return end
 L:DecorativeTexture(owner,texture,L.white);color(owner,texture,"stateTint",r,g,b,a)
 -- Native button state continues to choose when this texture is visible.
 L:Points(owner,texture,pack("TOPLEFT",button,"TOPLEFT",1,-1,"BOTTOMRIGHT",button,"BOTTOMRIGHT",-1,1))
end
function K:StyleButton(owner,button)
 if not S:Frame(button,false) then return false end
 if not self:Panel(owner,button,.75) then return false end
 local icon=L:Field(button,"Icon") or L:Field(button,"icon") or L:Field(button,"iconTexture")
 local label=L:Public(button,"GetFontString") or L:Field(button,"Text") or L:Field(button,"text")
 if label then self:StyleFont(owner,label) end
 -- Icon-only controls retain the action glyph. Text buttons lose native bezels.
 local normal=L:Public(button,"GetNormalTexture")
 if normal and (label or icon) then L:Alpha(owner,normal,0) end
 stateTexture(owner,button,"GetHighlightTexture",1,.66,.20,.16)
 stateTexture(owner,button,"GetPushedTexture",1,.66,.20,.25)
 stateTexture(owner,button,"GetDisabledTexture",.035,.035,.038,.65)
 local checked=L:Public(button,"GetCheckedTexture")
 if checked then
  L:DecorativeTexture(owner,checked,L.white);color(owner,checked,"stateTint",1,.65,.18,.75)
  L:Points(owner,checked,pack("BOTTOMLEFT",button,"BOTTOMLEFT",2,2,"BOTTOMRIGHT",button,"BOTTOMRIGHT",-2,2))
  L:Scalar(owner,checked,"height","GetHeight","SetHeight",2)
 end
 local n=name(button):lower()
 -- Modern templates use anonymous parentKey controls. Resolve only known
 -- source-defined aliases on the immediate parent; never scan all frame fields.
 local parent=L:Public(button,"GetParent")
 if parent then
  for _,key in ipairs({"CloseButton","closeButton","MinimizeButton","minimizeButton","NextPageButton","PrevPageButton","ScrollUpButton","ScrollDownButton","IncrementButton","DecrementButton"}) do
   if L:Field(parent,key)==button then n=key:lower();break end
  end
 end
 local glyph
 if n:match("closebutton$") or L:Field(button,"isCloseButton")==true then glyph="×"
 elseif n:match("minimizebutton$") then glyph="−"
 elseif n:match("prevpagebutton$") or n:match("scrollupbutton$") then glyph="‹"
 elseif n:match("nextpagebutton$") or n:match("scrolldownbutton$") then glyph="›"
 elseif n:match("incrementbutton$") then glyph="+"
 elseif n:match("decrementbutton$") then glyph="−" end
 if glyph and not S:InCombat() then
  if normal then L:Alpha(owner,normal,0) end
  local cache=owner.decorations[button];local f=cache and cache.m03Glyph
  if not f then f=button:CreateFontString(nil,"OVERLAY");cache.m03Glyph=f;K.owned[f]=true end
  f:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",15,"");f:SetAllPoints(button);f:SetTextColor(1,.66,.20,1);f:SetText(glyph);f:Show()
 end
 return true
end
function K:StyleEdit(owner,edit)
 if not self:Panel(owner,edit,.8) then return false end
 self:StyleFont(owner,edit)
 -- A thin owned focus mark follows the real widget focus; native input limits,
 -- selection, Escape/Enter and keyboard handlers are not replaced.
 local focus=ownRegion(owner,edit,"m04Focus","OVERLAY",7)
 if focus then
  focus:SetTexture(L.white);focus:SetVertexColor(1,.66,.20,1);focus:ClearAllPoints()
  focus:SetPoint("BOTTOMLEFT",edit,"BOTTOMLEFT",1,1);focus:SetPoint("BOTTOMRIGHT",edit,"BOTTOMRIGHT",-1,1);focus:SetHeight(2)
  focus:SetAlpha(L:Public(edit,"HasFocus","boolean")==true and 1 or 0)
 end
 self:HookScript(owner,edit,"OnEditFocusGained");self:HookScript(owner,edit,"OnEditFocusLost")
 return true
end
function K:StyleHTML(owner,html)
 -- SimpleHTML's named text elements are not necessarily returned by GetRegions.
 -- Read and lease only the native font/color API; native markup and hyperlinks
 -- continue to render through the original widget.
 local get,set=L:Field(html,"GetFont"),L:Field(html,"SetFont")
 if type(get)~="function" or type(set)~="function" then return L:Gap(owner) end
 for _,tag in ipairs({"p","h1","h2","h3"}) do
  local ok,_,size=pcall(get,html,tag)
  local key="htmlFont:"..tag;local old=owner.lookup[html] and owner.lookup[html][key]
  if old then size=old.original[2] end
  if ok and S:Number(size) then
   L:Write(owner,html,key,function(x) local p,s,f=get(x,tag);return pack(p,s,f or "") end,
    function(x,v) set(x,tag,v[1],v[2],v[3]) end,
    pack(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",math.max(10,math.min(20,size))*(M.profile.textScale or 1),""))
   local getColor,setColor=L:Field(html,"GetTextColor"),L:Field(html,"SetTextColor")
   if type(getColor)=="function" and type(setColor)=="function" then
    local readable,rr,gg,bb,aa=pcall(getColor,html,tag)
    if readable and S:Number(rr) and S:Number(gg) and S:Number(bb) and rr<.35 and gg<.35 and bb<.35 then
     L:Write(owner,html,"htmlColor:"..tag,function(x) return pack(getColor(x,tag)) end,
      function(x,v) setColor(x,tag,v[1],v[2],v[3],v[4]) end,pack(.90,.89,.87,aa or 1))
    end
   end
  else L:Gap(owner) end
 end
end
function K:StyleItem(owner,item)
 if not S:Frame(item,false) then return false end
 self:Panel(owner,item,.65)
 local icon=L:Field(item,"icon") or L:Field(item,"Icon") or L:Field(item,"iconTexture") or L:Public(item,"GetIconTexture")
 if icon and kind(icon)=="Texture" and not owner.preserveNativeIconCrop then L:Crop(owner,icon) end
 for _,key in ipairs({"Count","count","Name","name","Level","Stock"}) do self:StyleFont(owner,L:Field(item,key)) end
 local normal=L:Public(item,"GetNormalTexture");if normal then L:Alpha(owner,normal,0) end
 stateTexture(owner,item,"GetHighlightTexture",1,.66,.20,.18)
 stateTexture(owner,item,"GetPushedTexture",1,.66,.20,.25)
 -- Quality, quest, new-item and selection borders keep native semantic tint,
 -- shown/animation state, while their artwork is a thin custom rectangle.
 for _,key in ipairs({"IconBorder","IconQuestTexture","NewItemTexture","BattlepayItemTexture","Highlight","BagIndicator"}) do
  local edge=L:Field(item,key)
  if edge and kind(edge)=="Texture" then
   L:DecorativeTexture(owner,edge,L.white)
   L:Points(owner,edge,pack("BOTTOMLEFT",item,"BOTTOMLEFT",1,1,"BOTTOMRIGHT",item,"BOTTOMRIGHT",-1,1))
   L:Scalar(owner,edge,"height","GetHeight","SetHeight",2)
  end
 end
 local extended=L:Field(item,"ExtendedSlot");if extended then L:Alpha(owner,extended,0) end
 return true
end
function K:HookScript(owner,frame,event)
 if S:InCombat() or not S:Frame(frame,false) then return false end
 owner.windowScriptHooks=owner.windowScriptHooks or setmetatable({},{__mode="k"})
 local hooks=owner.windowScriptHooks[frame];if not hooks then hooks={};owner.windowScriptHooks[frame]=hooks end
 if hooks[event] then return true end
 local fn=L:Field(frame,"HookScript");if type(fn)~="function" then return false end
 local ok=pcall(fn,frame,event,function()
  if owner.active then
   K:MarkWindowDirty(owner,frame)
  end
 end)
 if ok then hooks[event]=true end
 return ok
end
-- Visit only named, bounded native subtrees. Pool packs may assign a separate
-- lease to each row so released/recycled controls cannot inherit stale receipts.
local function withinTree(frame,root,skip,maxDepth)
 -- A retained queue is only a candidate list. Native pools may move a child
 -- between slices, including into a deliberately excluded canvas. Revalidate
 -- its current ancestry before installing hooks or acquiring a lease there.
 for _=0,maxDepth do
  if K.owned[frame] or skip and skip[frame] then return false end
  if frame==root then return true end
  local parent,state=L:Public(frame,"GetParent")
  if state~="KNOWN" or not S:Frame(parent,false) then return false end
  frame=parent
 end
 return false
end
function K:StyleTree(owner,root,opts)
 opts=opts or {};if not selected(owner) or not S:Frame(root,false) then return false end
 if S:InCombat() then owner.combatPending=true;owner.dirty=true;return false end
 local generation,profile=owner.generation,M.profile
 local isolated=owner.isolatedWindowPack==true
 local cooperative=isolated or owner.cooperativeStyle==true
 -- A native bag's final layout callback is a complete, bounded presentation
 -- transaction. Do not expose its intermediate eight-slot slices to render.
 -- Other windows retain the cooperative budget and all identity fences.
 local atomic=opts.atomic==true and owner.id=="inventory" and not isolated
 if cooperative then
  owner.windowJobs=owner.windowJobs or setmetatable({},{__mode="k"})
  owner.completedTrees=owner.completedTrees or setmetatable({},{__mode="k"})
 end
 local job=cooperative and owner.windowJobs[root]
 local serial=isolated and owner.scanSerial or owner.paintingToken or generation
 if cooperative and owner.completedTrees[root]==serial then return true end
 if job and (job.generation~=generation or job.profile~=profile or job.serial~=serial) then job=nil;owner.windowJobs[root]=nil end
 local seen,queue,count=job and job.seen or {},job and job.queue or {{root,0,owner}},job and job.count or 0
 if job then opts=job.opts end
 local steps,started=0,nil
 local sharedBudget=not isolated and owner.styleBudget
 if cooperative and type(debugprofilestop)=="function" then local ok,v=pcall(debugprofilestop);if ok and S:Number(v) then started=v end end
 if sharedBudget then started=sharedBudget.started or started;sharedBudget.started=started end
 local maxNodes=math.min(1024,opts.maxNodes or 512);local maxDepth=math.min(14,opts.maxDepth or 10)
 while #queue>0 do
  if cooperative and not atomic then
   local elapsed=false
   -- One native node can contain several expensive journalled properties.
   -- Check elapsed work after the first node, not after an eight-node burst.
   -- This still guarantees forward progress when one node exceeds the budget.
   if started and (sharedBudget and sharedBudget.steps or steps)>=1 then local ok,v=pcall(debugprofilestop);elapsed=ok and S:Number(v) and v-started>=.35 end
   local exhausted=isolated and (owner.treeBudget or 0)<=0 or not isolated and (sharedBudget and sharedBudget.remaining<=0 or steps>=(opts.budgetNodes or 48))
   if exhausted or elapsed then
    owner.windowJobs[root]={rootName=owner.paintingWindow,generation=generation,profile=profile,serial=serial,
     rootRow=owner.paintingRoot,seen=seen,queue=queue,count=count,opts=opts}
    if not isolated then owner.stylePending=true end
    return false,"WINDOW_WORK_QUEUED"
   end
   if isolated then owner.treeBudget=owner.treeBudget-1 end
   if sharedBudget then sharedBudget.remaining=sharedBudget.remaining-1;sharedBudget.steps=sharedBudget.steps+1 end
   steps=steps+1
  end
  local entry=table.remove(queue);local frame,depth,leaseOwner=entry[1],entry[2],entry[3]
  if not selected(owner) or owner.generation~=generation or M.profile~=profile then return false end
  if not S:Frame(frame,false) then L:Gap(owner)
  elseif not seen[frame] and not self.owned[frame] and not (opts.skip and opts.skip[frame])
   and (not cooperative or withinTree(frame,root,opts.skip,maxDepth)) then
   seen[frame]=true;count=count+1
   if count>maxNodes then owner.windowScanLimited=true;L:Gap(owner);return false end
   local k=kind(frame)
   if k~="GameTooltip" and k~="Model" and k~="PlayerModel" and k~="DressUpModel" and k~="ModelScene" and k~="Minimap" then
    if owner.isolatedWindowPack and owner.paintingWindow then owner.nodeRoot[frame]=owner.paintingWindow end
    if opts.hookScripts~=false then self:HookScript(owner,frame,"OnShow") end
    local visible=not opts.visibleOnly or L:Public(frame,"IsShown","boolean")==true
    if visible and opts.leaseOwner then
     local assigned=opts.leaseOwner(frame,leaseOwner)
     if assigned~=nil then leaseOwner=assigned end
    end
    local admitted=visible and leaseOwner~=false and selected(leaseOwner)
    if admitted and opts.visit then admitted=opts.visit(frame,leaseOwner)~=false end
    if admitted then
     local leaseGeneration=leaseOwner.generation
     if frame==root and opts.role~="content" then self:Panel(leaseOwner,root,opts.fill or .94) end
     -- Source-specific packs can present a known leaf directly. Inventory
     -- slots have a pinned template; their cooldowns, filters and animations
     -- do not need a generic recursive window skin on every native update.
     local handled=opts.paintNode and opts.paintNode(frame,leaseOwner,k)
     if not handled then
     self:Decorations(leaseOwner,frame,opts)
     if k=="ItemButton" or type(L:Field(frame,"GetBagID"))=="function" then self:StyleItem(leaseOwner,frame)
     elseif k=="Button" or k=="CheckButton" or k=="DropdownButton" then
      if opts.buttons~=false then self:StyleButton(leaseOwner,frame) end
     elseif k=="EditBox" then self:StyleEdit(leaseOwner,frame)
     elseif k=="SimpleHTML" then self:StyleHTML(leaseOwner,frame)
     elseif k=="ScrollingMessageFrame" then self:StyleFont(leaseOwner,frame)
     elseif k=="Slider" then
      self:Panel(leaseOwner,frame,.4)
      local thumb=L:Public(frame,"GetThumbTexture")
      if thumb then L:DecorativeTexture(leaseOwner,thumb,L.white);color(leaseOwner,thumb,"thumbTint",1,.66,.20,.8) end
     elseif k=="StatusBar" then L:Bar(leaseOwner,frame) end
     end
     if opts.painted then
      if not selected(owner) or owner.generation~=generation or M.profile~=profile or not selected(leaseOwner) or leaseOwner.generation~=leaseGeneration then return false end
      opts.painted(frame,leaseOwner)
     end
     if opts.watchNative~=false then for _,method in ipairs({"Update","Refresh","RefreshData","Layout","UpdateLayout","SetDataProvider","UpdateItemSlots","GenerateItemSlotsForSelectedTab",
      "FullUpdate","Rebuild","UpdateElements","SetElementData","Init","Initialize"}) do
       -- A content provider may already own a source-specific posthook for
       -- this exact method. Preserve it instead of replacing its callback
       -- with the generic dirty flag during a later bounded tree scan.
       if type(opts.watchNative)~="function" or opts.watchNative(frame,method) then self:WatchNative(leaseOwner,frame,method) end
      end
     end
     local fn=L:Field(frame,"GetChildren")
     if handled~="LEAF" and type(fn)=="function" then
      local ok,children=pcall(function() return {fn(frame)} end)
      if not ok or #children>maxNodes then owner.windowScanLimited=true;L:Gap(owner)
      elseif depth>=maxDepth and #children>0 then owner.windowScanLimited=true;L:Gap(owner)
      else for _,child in ipairs(children) do if not self.owned[child] then queue[#queue+1]={child,depth+1,leaseOwner} end end end
     end
    end
   end
  end
 end
 owner.windowNodes=(owner.windowNodes or 0)+count
 if cooperative then
  owner.windowJobs[root]=nil
  owner.completedTrees[root]=serial
  if not isolated then
   local pending=false;for _ in pairs(owner.windowJobs) do pending=true;break end
   if not pending then owner.stylePending=nil end
  end
 end
 return true
end

-- M06 independent native-window journals. Each native node belongs to exactly
-- one named root. A pooled-row or handback failure never retires another root.
function K:MarkWindowDirty(owner,frame)
 local packOwner=owner.parentOwner or owner
 if not packOwner.active or packOwner.painting then return end
 if type(packOwner.MarkNativeWindowDirty)=="function" and packOwner:MarkNativeWindowDirty(frame,owner)==true then return end
 if packOwner.isolatedWindowPack then
  local name=(packOwner.nodeRoot and packOwner.nodeRoot[frame]) or owner.rootName
  if name then
   packOwner.dirtyRoots[name]=true
   for _,job in pairs(packOwner.windowJobs or {}) do if job.rootName==name then job.invalidated=true end end
  else packOwner.dirty=true end
 else
  owner.dirty=true
  if owner.parentOwner and owner.parentGeneration==owner.parentOwner.generation then owner.parentOwner.dirty=true end
 end
end
function K:WatchNative(owner,frame,method)
 L:Hook(owner,frame,method,function() self:MarkWindowDirty(owner,frame) end)
end
function K:ReleaseWindowNode(packOwner,frame,owner,unbounded)
 owner.active=false
 if not unbounded and (owner.releaseAttempts or 0)>=3 then return false end
 owner.releaseAttempts=(owner.releaseAttempts or 0)+1
 local ok=L:Release(owner)
 owner.releasePending=not ok or nil
 if ok then
  if packOwner.nodeOwners[frame]==owner then packOwner.nodeOwners[frame]=nil;packOwner.nodeCount=math.max(0,packOwner.nodeCount-1) end
  owner.root=nil;owner.rootName=nil;owner.windowName=nil;owner.identityKnown=nil;owner.releaseAttempts=0
 end
 return ok
end
function K:WindowNodeOwner(packOwner,frame,root)
 local owner=packOwner.nodeOwners[frame]
 local parent=L:Public(frame,"GetParent")
 local id=L:Public(frame,"GetID","number")
 local data=L:Public(frame,"GetElementData")
 local name=packOwner.paintingWindow
 if not name then return false end
 if owner and (owner.releasePending or owner.identityKnown and (owner.nativeParent~=parent or owner.nativeID~=id or owner.nativeData~=data or owner.rootName~=name)) then
  if not self:ReleaseWindowNode(packOwner,frame,owner) then L:Gap(packOwner);return false end
  owner=nil
 end
 if not owner then
  if packOwner.nodeCount>=(packOwner.maximumNodes or 4096) then packOwner.windowScanLimited=true;L:Gap(packOwner);return false end
  owner=packOwner.nodeCache[frame] or {id=packOwner.id,parentOwner=packOwner}
  if (owner.paintFailures or 0)>=3 then L:Gap(packOwner);return false end
  packOwner.nodeCache[frame]=owner;packOwner.nodeOwners[frame]=owner;packOwner.nodeCount=packOwner.nodeCount+1
 end
 packOwner.nodeRoot[frame]=name
 owner.rootName=name;owner.windowName=name;owner.root=root or packOwner.paintingRoot
 owner.nativeParent=parent;owner.nativeID=id;owner.nativeData=data;owner.identityKnown=true
 owner.parent=parent;owner.element=data
 if owner.seen~=packOwner.scanSerial then
  owner.active=true;owner.parentGeneration=packOwner.generation;owner.seen=packOwner.scanSerial
  owner.releaseAttempts=0;L:Begin(owner)
 end
 return owner
end
local function windowVisible(frame)
 local visible,known=L:Public(frame,"IsVisible","boolean")
 if known=="KNOWN" then return visible end
 local seen={}
 for _=1,24 do
  if not S:Frame(frame,false) or seen[frame] then return false end
  seen[frame]=true
  if L:Public(frame,"IsShown","boolean")~=true then return false end
  local parent,state=L:Public(frame,"GetParent")
  if state~="KNOWN" then return false end
  if not parent then return true end
  frame=parent
 end
 return false
end
function K:ReleaseWindowRoot(packOwner,name,unseen,unbounded)
 local complete=true
 for frame,owner in pairs(packOwner.nodeOwners) do
  if owner.rootName==name and (not unseen or owner.seen~=packOwner.scanSerial) then
   if not self:ReleaseWindowNode(packOwner,frame,owner,unbounded) then complete=false end
  end
 end
 return complete
end
function K:WindowOutcome(packOwner)
 local ready,partial,waiting=0,0,0
 for _,state in pairs(packOwner.surfaceStates or {}) do
  if state.kind=="READY" then ready=ready+1
  elseif state.kind=="PARTIAL" or state.kind=="DEFERRED_HANDOFF" or state.kind=="FAULT" or state.kind=="CONFLICT" then partial=partial+1
  else waiting=waiting+1 end
 end
 packOwner.readyRoots=ready;packOwner.partialRoots=partial;packOwner.waitingRoots=waiting
 local kind=partial>0 and "PARTIAL" or ready>0 and "READY" or "WAITING"
 packOwner.status=partial>0 and "MIRAGE_NATIVE_PRESENTATION_PARTIAL" or ready>0 and "CUSTOM_NATIVE_WINDOWS" or "WAITING_FOR_NATIVE_CONTENT"
 return R:Result(kind,packOwner.status)
end
function K:PaintWindowRoot(packOwner,spec)
 local name,frame=spec.name,_G[spec.name]
 local old=packOwner.roots[name]
 packOwner.dirtyRoots[name]=nil
 if old and old.frame~=frame then
  for root,job in pairs(packOwner.windowJobs) do if job.rootName==name then packOwner.windowJobs[root]=nil end end
  if not self:ReleaseWindowRoot(packOwner,name) then
   packOwner.blockedRows[name]="DEFERRED_HANDOFF";R:RecordSurface(packOwner,name,"DEFERRED_HANDOFF","ROOT_HANDOFF_PENDING");return
  end
  packOwner.roots[name]=nil;old=nil;packOwner.blockedRows[name]=nil
 end
 if not S:Frame(frame,false) then
  R:RecordSurface(packOwner,name,"WAITING","NATIVE_ROOT_UNAVAILABLE");return
 end
 local row=old or {frame=frame,spec=spec}
 packOwner.roots[name]=row;packOwner.nodeRoot[frame]=name
 self:HookScript(packOwner,frame,"OnShow");self:HookScript(packOwner,frame,"OnHide")
 if not windowVisible(frame) and name~="AlertFrame" then
  for tree,job in pairs(packOwner.windowJobs) do if job.rootName==name then packOwner.windowJobs[tree]=nil end end
  row.paintSerial=nil;row.paintGaps=nil
  local released=self:ReleaseWindowRoot(packOwner,name)
  R:RecordSurface(packOwner,name,released and "EMPTY" or "DEFERRED_HANDOFF",released and "WAITING_FOR_OPEN" or "WINDOW_ROW_HANDOFF_PENDING")
  if packOwner.windowStates then packOwner.windowStates[name]={state=released and "WAITING_FOR_OPEN" or "RESTORE_PENDING",group=spec.group,native="NOT_RUN"} end
  return
 end
 if row.faultLatched then R:RecordSurface(packOwner,name,"PARTIAL","SURFACE_RETRY_REQUIRED");return end
 local invalidated=false
 for root,job in pairs(packOwner.windowJobs) do
  if job.rootName==name and job.invalidated then packOwner.windowJobs[root]=nil;invalidated=true end
 end
 if invalidated then row.paintSerial=nil;row.paintGaps=nil end
 if not row.paintSerial then packOwner.scanSequence=(packOwner.scanSequence or 0)+1;row.paintSerial=packOwner.scanSequence end
 packOwner.scanSerial=row.paintSerial;packOwner.scanEpoch=packOwner.scanSerial
 packOwner.treeBudget=32;packOwner.windowScanLimited=nil;packOwner.gaps=0;packOwner.windowNodes=0
 packOwner.paintingWindow=name;packOwner.paintingRoot=frame;packOwner.painting=true
 local ok=pcall(packOwner.Skin,packOwner,row)
 packOwner.painting=nil;packOwner.paintingWindow=nil;packOwner.paintingRoot=nil
 row.paintGaps=(row.paintGaps or 0)+(packOwner.gaps or 0)
 local queued=false
 for root,job in pairs(packOwner.windowJobs) do if job.rootName==name then
  if not ok or packOwner.windowScanLimited then packOwner.windowJobs[root]=nil else queued=true end
 end end
 if queued then
  packOwner.dirtyRoots[name]=true;R:RecordSurface(packOwner,name,"WAITING","NATIVE_STYLE_QUEUED")
  return
 end
 row.paintSerial=nil
 local complete=self:ReleaseWindowRoot(packOwner,name,true)
 local gaps=row.paintGaps or 0;row.paintGaps=nil
 for node,owner in pairs(packOwner.nodeOwners) do
  if owner.rootName==name then
   gaps=gaps+(owner.gaps or 0)
   if owner.releasePending then complete=false end
   if (owner.gaps or 0)>0 then
    owner.paintFailures=(owner.paintFailures or 0)+1
    if not self:ReleaseWindowNode(packOwner,node,owner) then complete=false end
   end
  end
 end
 if not ok then
  row.faultLatched=true
  self:ReleaseWindowRoot(packOwner,name)
  if M.Incidents then M.Incidents:Record("FAULT",packOwner.id,"WINDOW_PAINT","SURFACE_PAINT_FAILED",name) end
 end
 local partial=not ok or not complete or gaps>0 or packOwner.windowScanLimited
 local state=packOwner.windowStates and packOwner.windowStates[name]
 local empty=not partial and state and state.state=="WAITING_FOR_NATIVE_CONTENT"
 R:RecordSurface(packOwner,name,partial and "PARTIAL" or empty and "EMPTY" or "READY",empty and "WAITING_FOR_NATIVE_CONTENT" or not ok and "SURFACE_PAINT_FAILED" or not complete and "WINDOW_ROW_HANDOFF_PENDING" or partial and "SURFACE_STYLE_PARTIAL" or "CUSTOM_NATIVE_WINDOW")
 packOwner.blockedRows[name]=not complete and "DEFERRED_HANDOFF" or nil
 if packOwner.coverage then packOwner.coverage[name]=partial and "PARTIAL_OPEN" or "STYLED_OPEN_NATIVE_NOT_RUN" end
 if packOwner.windowStates and packOwner.windowStates[name] then packOwner.windowStates[name].state=partial and "PARTIAL_NEEDS_ATTENTION" or empty and "WAITING_FOR_NATIVE_CONTENT" or "CUSTOM_CONTROLS_READY" end
 packOwner.windowTransactions=(packOwner.windowTransactions or 0)+1
end
function K:InstallIsolatedPack(packOwner)
 packOwner.isolatedWindowPack=true;packOwner.nodeOwners={};packOwner.nodeCount=0
 packOwner.nodeCache=setmetatable({},{__mode="k"});packOwner.nodeRoot=setmetatable({},{__mode="k"})
 packOwner.dirtyRoots={};packOwner.blockedRows={};packOwner.knownGlobals={}
 packOwner.windowJobs=setmetatable({},{__mode="k"});packOwner.completedTrees=setmetatable({},{__mode="k"})
 packOwner.NodeOwner=function(self,frame,root) return K:WindowNodeOwner(self,frame,root) end
 packOwner.ReleaseNodes=function(self)
  local complete=true
  for frame,owner in pairs(self.nodeOwners) do if not K:ReleaseWindowNode(self,frame,owner,true) then complete=false end end
  return complete
 end
 packOwner.Configure=function(self)
  if S:InCombat() then self.combatPending=true;return R:Result("DEFERRED_COMBAT","STYLE_COMBAT_DEFERRED") end
  if not selected(self) and self.active then return self:Suspend("UNSELECTED") end
  if not R:Qualified() or not R:Selected(self.id) or M.state.safe then return self:Suspend("UNSELECTED") end
  if R:NativeEditState()~="CLOSED" then return R:Result("DEFERRED_HANDOFF","NATIVE_EDIT_UNKNOWN") end
  local scope=M.state.settingsGeneration or 0
  if not self.active or self.configuredGeneration~=scope then
   self.active=true;self.configuredGeneration=scope;L:Begin(self)
   self.windowJobs=setmetatable({},{__mode="k"});self.completedTrees=setmetatable({},{__mode="k"})
   for _,row in pairs(self.roots) do row.paintSerial=nil;row.paintGaps=nil end
   for _,spec in ipairs(self.specs) do
    self.knownGlobals[spec.name]=_G[spec.name] or false
    if _G[spec.name] or self.roots[spec.name] then self.dirtyRoots[spec.name]=true
    else R:RecordSurface(self,spec.name,"WAITING","NATIVE_ROOT_UNAVAILABLE") end
   end
  elseif self.dirty then for _,spec in ipairs(self.specs) do self.dirtyRoots[spec.name]=true end end
  self.dirty=nil;self.combatPending=nil
  if self.HookLateBannerContent then self:HookLateBannerContent() end
  return K:WindowOutcome(self)
 end
 packOwner.NeedsRuntimeTick=function(self,now,combat)
  if not self.active or combat or R:NativeEditState()~="CLOSED" then return false end
  if not R:Selected(self.id) or M.state.safe then return true end -- retained owner cleanup
  if self.dirty or now>=(self.nextRootProbe or 0) then return true end
  for name in pairs(self.dirtyRoots) do
   local row=self.roots[name]
   -- This journal owns native OnShow/OnHide work and yielded tree chunks.
   -- A closed root still needs one pass to retire its old node receipts; the
   -- painter then clears demand without walking the hidden native subtree.
   -- Blocked custody alone is not demand. A real event may reach the existing
   -- bounded handback checks, while a latched paint fault needs explicit Retry
   -- or an actual root replacement before another paint can be attempted.
   if not row or row.frame~=_G[name] or not row.faultLatched then return true end
  end
  return false
 end
 packOwner.Tick=function(self,now)
  if not self.active then return end
  if R:NativeEditState()~="CLOSED" then return end
  if not R:Selected(self.id) or M.state.safe then return self:Suspend("UNSELECTED") end
  if S:InCombat() then return end
  if self.dirty then self.dirty=nil;for _,spec in ipairs(self.specs) do self.dirtyRoots[spec.name]=true end end
  if now>=(self.nextRootProbe or 0) then
   self.nextRootProbe=now+1
   for _,spec in ipairs(self.specs) do
    local frame=_G[spec.name] or false
    if self.knownGlobals[spec.name]~=frame then self.knownGlobals[spec.name]=frame;self.dirtyRoots[spec.name]=true end
   end
  end
  -- One root transaction per turn; no unchanging tree is traversed by a timer.
  for offset=1,#self.specs do
   local index=((self.windowCursor or 0)+offset-1)%#self.specs+1
   local spec=self.specs[index]
   if self.dirtyRoots[spec.name] then self.windowCursor=index;K:PaintWindowRoot(self,spec);return K:WindowOutcome(self) end
  end
 end
 packOwner.OnEvent=function(self,event)
  if not self.active then return end
  if self.events[event] then
   for _,spec in ipairs(self.specs) do
    local row=self.roots[spec.name]
    if event=="ADDON_LOADED" or event=="PLAYER_ENTERING_WORLD" or row and windowVisible(row.frame) then
     if row then K:MarkWindowDirty(self,row.frame) else self.dirtyRoots[spec.name]=true end
    end
   end
  end
 end
 packOwner.Retry=function(self)
  if S:InCombat() then return false end
  for _,owner in pairs(self.nodeCache) do owner.releaseAttempts=0;owner.paintFailures=0 end
  for _,row in pairs(self.roots) do row.faultLatched=nil end
  for _,spec in ipairs(self.specs) do self.dirtyRoots[spec.name]=true end
  return true
 end
 packOwner.Suspend=function(self,why)
  self.active=false;self.dirty=nil;self.dirtyRoots={};self.windowJobs=setmetatable({},{__mode="k"})
  if S:InCombat() then return false,"COMBAT_LOCKDOWN" end
  local complete=self:ReleaseNodes()
  local rootComplete=L:Release(self)
  if complete and rootComplete then self.roots={};self.configuredGeneration=nil end
  self.status=complete and rootComplete and (why or "SUSPENDED") or "WINDOW_ROW_HANDOFF_PENDING"
  return complete and rootComplete,self.status
 end
end

-- First task packs: talk/quest, loot/roll, merchant/buyback, mail, trade and
-- native transaction confirmations. Character/social/system packs are M04.
local specs={}
for _,n in ipairs({"GossipFrame","QuestFrame","QuestModelScene","MerchantFrame","TradeFrame","MailFrame","OpenMailFrame","SendMailFrame",
 "LootFrame","MasterLooterFrame","GroupLootFrame1","GroupLootFrame2","GroupLootFrame3","GroupLootFrame4","GamepadGroupLootRollFrame","BonusRollFrame",
 "StaticPopup1","StaticPopup2","StaticPopup3","StaticPopup4","StackSplitFrame"}) do specs[#specs+1]={name=n,editable=false,noContext=true} end
local T=R.CombatFactory:New("tasks","BlizzardSkin",specs);R.TaskWindows=T
for _,event in ipairs({"GOSSIP_SHOW","GOSSIP_CLOSED","QUEST_DETAIL","QUEST_PROGRESS","QUEST_COMPLETE","QUEST_GREETING","QUEST_FINISHED",
 "MERCHANT_SHOW","MERCHANT_UPDATE","MERCHANT_CLOSED","LOOT_OPENED","LOOT_CLOSED","LOOT_SLOT_CLEARED","START_LOOT_ROLL","CANCEL_LOOT_ROLL",
 "MAIL_SHOW","MAIL_CLOSED","MAIL_INBOX_UPDATE","MAIL_SEND_INFO_UPDATE","TRADE_SHOW","TRADE_CLOSED","TRADE_PLAYER_ITEM_CHANGED","TRADE_TARGET_ITEM_CHANGED",
 "TRADE_ACCEPT_UPDATE","TRADE_MONEY_CHANGED","PLAYER_MONEY"}) do T.events[event]=true end
function T:Skin(row)
 local skip={}
 for _,spec in ipairs(self.specs) do local frame=_G[spec.name];if frame and frame~=row.frame then skip[frame]=true end end
 K:StyleTree(self,row.frame,{maxNodes=768,maxDepth=12,fill=.94,visibleOnly=true,skip=skip,
  leaseOwner=function(frame) return self:NodeOwner(frame,row.frame) end})
 -- Quest text and reward controls are sometimes reparented between detail and
 -- reward panels. The selected root is revisited after the actual quest event.
end
function T:Status()
 return (self.status or "NOT_INITIALIZED").."; pack=QUEST_LOOT_MERCHANT_MAIL_TRADE_CONFIRMATIONS; nodes="..(self.windowNodes or 0)
  .."; controls=NATIVE_IDENTITIES_PRESERVED; native=NOT_RUN"..(self.windowScanLimited and "; bounded_scan=PARTIAL" or "")
end

K:InstallIsolatedPack(T)
