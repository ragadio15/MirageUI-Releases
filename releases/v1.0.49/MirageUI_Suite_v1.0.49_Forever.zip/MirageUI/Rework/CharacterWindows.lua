local _,M=...
-- M04 character, progression and item windows. The pinned native widgets remain
-- the input/data owners. Presentation is acquired only after a window opens;
-- neither a lookup nor an event may open a panel, commit a talent, or buy an item.
local R,S,L,K=M.Rework,M.Safety,M.Rework.CombatLeases,M.Rework.WindowKit
local specs={}
for _,name in ipairs({"CharacterFrame","InspectFrame","EquipmentFlyoutFrame","GearManagerPopupFrame",
 "PlayerSpellsFrame","ClassTalentLoadoutCreateDialog","ClassTalentLoadoutEditDialog","ClassTalentLoadoutImportDialog","HeroTalentsSelectionDialog",
 "MacroFrame","MacroPopupFrame","ProfessionsFrame","ProfessionsCustomerOrdersFrame","ClassTrainerFrame",
 "AuctionHouseFrame","ItemInteractionFrame","ItemSocketingFrame","ItemUpgradeFrame","ScrappingMachineFrame",
 "ObliterumForgeFrame","TransmogFrame","PetStableFrame","CurrencyTransferMenu"}) do
 specs[#specs+1]={name=name,editable=false,noContext=true}
end
local C=R.CombatFactory:New("character","BlizzardSkin",specs);R.CharacterWindows=C
C.nodeOwners={};C.nodeCache=setmetatable({},{__mode="k"});C.nodeCount=0;C.coverage={};C.poolHooks=setmetatable({},{__mode="k"})
for _,event in ipairs({"UPDATE_MACROS","SPELLS_CHANGED","PLAYER_TALENT_UPDATE","TRAIT_CONFIG_UPDATED","INSPECT_READY",
 "UNIT_INVENTORY_CHANGED","EQUIPMENT_SETS_CHANGED","BAG_UPDATE_DELAYED","SKILL_LINES_CHANGED","UPDATE_FACTION","CURRENCY_DISPLAY_UPDATE",
 "TRAINER_UPDATE","TRAINER_DESCRIPTION_UPDATE","TRAINER_SERVICE_INFO_NAME_UPDATE","UNIT_PET_TRAINING_POINTS",
 "TRADE_SKILL_SHOW","TRADE_SKILL_CLOSE","TRADE_SKILL_LIST_UPDATE","TRADE_SKILL_DATA_SOURCE_CHANGED","OPEN_RECIPE_RESPONSE",
 "AUCTION_HOUSE_SHOW","AUCTION_HOUSE_CLOSED","AUCTION_HOUSE_BROWSE_RESULTS_UPDATED","AUCTION_HOUSE_NEW_RESULTS_RECEIVED",
 "AUCTION_HOUSE_POST_WARNING","AUCTION_HOUSE_POST_ERROR","ITEM_SEARCH_RESULTS_UPDATED","COMMODITY_SEARCH_RESULTS_UPDATED",
 "OWNED_AUCTIONS_UPDATED","ITEM_UNLOCKED","SOCKET_INFO_UPDATE","ITEM_UPGRADE_MASTER_UPDATE","ITEM_INTERACTION_ITEM_SELECTION_UPDATED",
 "SCRAPPING_MACHINE_PENDING_ITEM_CHANGED","TRANSMOG_COLLECTION_UPDATED","TRANSMOG_SOURCE_COLLECTABILITY_UPDATE",
 "PET_STABLE_SHOW","PET_STABLE_UPDATE","PET_STABLE_CLOSED","PLAYER_MONEY"}) do C.events[event]=true end

local function selected(self)
 return self.active and R:Qualified() and R:Selected(self.id) and not M.state.safe and not R:NativeEditing()
end
local function kind(frame) return L:Public(frame,"GetObjectType","string") end
local function visible(frame)
 local value,state=L:Public(frame,"IsVisible","boolean")
 if state=="KNOWN" then return value end
 -- Some named popups are children of a hidden panel and keep IsShown=true.
 -- Check the public ancestor chain when the client lacks IsVisible support.
 local seen={}
 for _=1,24 do
  if not S:Frame(frame,false) or seen[frame] or L:Public(frame,"IsShown","boolean")~=true then return false end
  seen[frame]=true
  local parent,status=L:Public(frame,"GetParent")
  if status~="KNOWN" then return false end
  if not parent then return true end
  frame=parent
 end
 return false
end
-- Pools are ordinary Lua controllers, not frame objects. The exact source uses
-- rowPools in CharacterFrame and button/row pools in the other named packs.
-- Hooks only invalidate; they never style inside Acquire/Release or a native
-- click handler. No inactive pool stack or item data is enumerated.
function C:HookPool(pool)
 if S:InCombat() or not S:Readable(pool) or type(pool)~="table" or type(hooksecurefunc)~="function" then return end
 self.poolRoots=self.poolRoots or setmetatable({},{__mode="k"});self.poolRoots[pool]=self.paintingWindow
 local hooks=self.poolHooks[pool];if not hooks then hooks={};self.poolHooks[pool]=hooks end
 for _,method in ipairs({"Acquire","Release","ReleaseAll"}) do
  if not hooks[method] and type(L:Field(pool,method))=="function" then
   local ok=pcall(hooksecurefunc,pool,method,function()
    local root=self.poolRoots[pool];local row=root and self.roots[root]
    if self.active and row then K:MarkWindowDirty(self,row.frame) end
   end)
   if ok then hooks[method]=true end
  end
 end
end
local artFields={"TopBackgroundStrip","TopBackgroundStripBottomEdge","ClassBackground","BackgroundBorder",
 "OverlayBackgroundRight","OverlayBackgroundMid","MainRing","TextBackground","Divider","DividerTop","DividerBottom","DividerBar",
 "DividerHorizontalLeft","DividerHorizontalRight","DividerVerticalLeft","DividerVerticalRight","GradientTop","GradientBottom","GradientLeft","GradientRight",
 "Clouds1","Clouds2","AirParticlesClose","AirParticlesFar"}
local semanticFields={"Icon","icon","iconTexture","SpecIcon","Gem","StateTexture","SelectedBar","HighlightBar",
 "Selection","SelectedTexture","SelectionTexture","LearnedTexture","LockedTexture","DisabledOverlay","Check","CheckMark",
 "QualityStripe","IconBorder","IconQuestTexture","NewItemTexture","SpellHighlightTexture","SearchHighlight"}
function C:Visit(frame,owner,options)
 for _,key in ipairs(semanticFields) do
  local region=L:Field(frame,key)
  if region and kind(region)=="Texture" then options.preserveTextures[region]=true end
 end
 for _,key in ipairs(artFields) do
  local region=L:Field(frame,key)
  if region and kind(region)=="Texture" then L:Alpha(owner,region,0) end
 end
 for _,key in ipairs({"rowPools","rowPool","buttonPool","framePool","itemFramePool","nodePool","tabPool"}) do self:HookPool(L:Field(frame,key)) end
 -- Most panels use ScrollBox/Refresh/Layout. These additional methods are
 -- source-qualified names for local content changes without a global event.
 for _,method in ipairs({"UpdateContent","UpdateTabs","RefreshView","UpdateDisplay","UpdateRows","UpdateResults",
  "RefreshDisplay","UpdateSearchResults","UpdateFilters","SetDisplayMode","SetTab","SelectTab","SelectRecipe","UpdateTree"}) do K:WatchNative(self,frame,method) end
 return true
end
function C:Options(root)
 local skip={};local native=R.nativeOwners or {}
 for name,id in pairs(native) do local frame=_G[name];if frame and frame~=root and id~=self.id then skip[frame]=true end end
 -- A separately parented popup can also be a descendant of its main window.
 -- Its own row handles it, so no texture receives two leases.
 for _,spec in ipairs(self.specs) do local frame=_G[spec.name];if frame and frame~=root then skip[frame]=true end end
 local options={maxNodes=1024,maxDepth=14,visibleOnly=true,fill=.94,skip=skip,preserveTextures={}}
 options.leaseOwner=function(frame) return self:NodeOwner(frame) end
 options.visit=function(frame,owner) return self:Visit(frame,owner,options) end
 return options
end
function C:ModelChrome(model,options)
 if not S:Frame(model,false) or not visible(model) then return end
 local owner=self:NodeOwner(model);if not owner then return end
 -- Only named surrounding artwork is leased. The engine actor, camera,
 -- rotation, animations, hit testing and model scene state are untouched.
 for _,key in ipairs({"BackgroundTopLeft","BackgroundTopRight","BackgroundBotLeft","BackgroundBotRight","BackgroundOverlay"}) do
  local region=L:Field(model,key);if region and kind(region)=="Texture" then L:Alpha(owner,region,0) end
 end
 local controls=L:Field(model,"ControlFrame") or L:Field(model,"controlFrame")
 if S:Frame(controls,false) then local opts=self:Options(controls);opts.role="content";K:StyleTree(self,controls,opts) end
end
function C:Skin(row)
 local frame=row.frame
 K:HookScript(self,frame,"OnShow");K:HookScript(self,frame,"OnHide")
 if not visible(frame) then self.coverage[row.spec.name]="WAITING_FOR_OPEN";return end
 local before=self.gaps or 0;local options=self:Options(frame);self.paintingWindow=row.spec.name
 local ok=K:StyleTree(self,frame,options)
 if row.spec.name=="CharacterFrame" then self:ModelChrome(_G.CharacterModelScene,options)
 elseif row.spec.name=="InspectFrame" then self:ModelChrome(_G.InspectModelFrame,options)
 elseif row.spec.name=="TransmogFrame" then self:ModelChrome(L:Path(frame,"CharacterPreview","ModelScene"),options)
 elseif row.spec.name=="PetStableFrame" then self:ModelChrome(L:Field(frame,"modelScene"),options) end
 local gaps=0
 for _,owner in pairs(self.nodeOwners) do if owner.seen==self.scanSerial and owner.windowName==row.spec.name then gaps=gaps+(owner.gaps or 0) end end
 self.paintingWindow=nil
 self.coverage[row.spec.name]=ok and self.gaps==before and gaps==0 and not self.windowScanLimited and "STYLED_OPEN_NATIVE_NOT_RUN" or "PARTIAL_OPEN"
end
function C:Status()
 local out={self.status or "NOT_INITIALIZED","pack=CHARACTER_PROGRESS_PROFESSIONS_AUCTION_ITEMS","nodes="..(self.windowNodes or 0),
  "controls=NATIVE_IDENTITIES_PRESERVED","geometry=NATIVE_PANEL_MANAGER","native=NOT_RUN"}
 for _,spec in ipairs(self.specs) do out[#out+1]=spec.name.."="..(self.coverage[spec.name] or "NOT_RUN") end
 if self.windowScanLimited then out[#out+1]="bounded_scan=PARTIAL" end
 return table.concat(out,"; ")
end

K:InstallIsolatedPack(C)
