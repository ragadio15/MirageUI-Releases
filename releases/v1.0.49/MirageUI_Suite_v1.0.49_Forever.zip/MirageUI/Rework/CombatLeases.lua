local _,M=...
-- WP08 operates on named presentation properties, never combat payloads. Native
-- callbacks only request a later pass; no styling runs inside mouseover or secure
-- event dispatch. All receipts remain until a verified handback or newer writer.
local R,S=M.Rework,M.Safety
local L={white="Interface\\Buttons\\WHITE8X8",beam="Interface\\AddOns\\MirageUI\\Media\\LightBeam.tga",
 panel="Interface\\AddOns\\MirageUI\\Media\\SubtlePanel.tga",square="Interface\\AddOns\\MirageUI\\Media\\SquareMask.tga",
 underline="Interface\\AddOns\\MirageUI\\Media\\AuraUnderlineMask.tga"}
R.CombatLeases=L
local unpack=unpack or table.unpack
local function pack(...) return {n=select("#",...),...} end
function L:Field(o,key)
 if not S:Readable(o) or (type(o)~="table" and type(o)~="userdata") then return nil end
 local ok,v=pcall(function() return o[key] end)
 if ok and S:Readable(v) then return v end
end
function L:Path(o,...)
 for i=1,select("#",...) do o=self:Field(o,select(i,...));if not o then return nil end end
 return o
end
function L:Call(o,key,...)
 if not S:Frame(o,false) then return false end
 local f=self:Field(o,key);if type(f)~="function" then return false end
 return pcall(f,o,...)
end
function L:Public(o,key,kind,...)
 if not S:Frame(o,false) then return nil,"UNAVAILABLE" end
 return S:Public(self:Field(o,key),kind,o,...)
end
local function fileID(v)
 -- Local addon files can have signed, session-local identities. Zero is the
 -- empty source; sign is not a validity check. Never persist these identities.
 return S:Number(v) and v~=0 and v%1==0
end
local function asset(v)
 return S:Readable(v) and ((type(v)=="string" and v~="") or fileID(v))
end
local function assetID(v)
 if fileID(v) then return v end
 if not S:Text(v) or v=="" or type(GetFileIDFromPath)~="function" then return nil end
 local ok,id=pcall(GetFileIDFromPath,v)
 if ok and fileID(id) then return id end
end
local function assetSpelling(v)
 return S:Text(v) and v:gsub("/","\\"):lower() or nil
end
local function directAssetEqual(a,b)
 if a==b then return a==false or asset(a) end
 if not asset(a) or not asset(b) then return false end
 if type(a)=="string" and type(b)=="string" and assetSpelling(a)==assetSpelling(b) then return true end
 local ai,bi=assetID(a),assetID(b)
 return ai~=nil and bi~=nil and ai==bi
end
-- A requested path may be returned as a file ID or a normalized path by the
-- native widget. Only a verified public asset resolution proves that alias;
-- arbitrary readback, nil and the unresolved ID 0 never prove success.
function L:AssetEqual(a,b)
 if not S:Readable(a) or not S:Readable(b) then return false end
 if a==b then return a==false or asset(a) end
 -- Only aliases actually observed on an owned texture are admitted. Do not
 -- strip extensions from arbitrary native assets or equate unresolved ID 0.
 local aliases=self.assetProofs
 if aliases then
  local ap=type(a)=="string" and aliases[a]
  local bp=type(b)=="string" and aliases[b]
  if ap and ap.source and directAssetEqual(ap.source,b) then return true end
  if bp and bp.source and directAssetEqual(a,bp.source) then return true end
 end
 return directAssetEqual(a,b)
end
-- uiUnit geometry traverses the native float representation and effective UI
-- scale. Bound geometry/font-height roundoff separately from paint channels.
-- A distinct layout remains a newer writer.
function L:GeometryEqual(a,b)
 return S:Number(a) and S:Number(b) and math.abs(a-b)<=math.max(.0001,math.max(math.abs(a),math.abs(b))*2^-22)
end
-- Color channels may round-trip through native byte storage. Accept only an
-- observed byte-grid representation of the authored channel (floor or nearest),
-- not an arbitrary wider epsilon. Two distinct byte values are different owners.
function L:ColorEqual(a,b)
 if not S:Number(a) or not S:Number(b) then return false end
 if math.abs(a-b)<=.0001 then return true end
 if a<0 or a>1 or b<0 or b>1 then return false end
 local ar,br=math.floor(a*255+.5),math.floor(b*255+.5)
 local ag,bg=math.abs(a-ar/255)<=.000001,math.abs(b-br/255)<=.000001
 if ag==bg then return false end
 local byte,value=ag and ar or br,ag and b or a
 return byte==math.floor(value*255+.000001) or byte==math.floor(value*255+.5)
end
local function colorKey(key)
 return key=="menuArrow" or key=="color" or key:sub(1,10)=="htmlColor:"
  or key:find("Color",1,true)~=nil or key:find("Tint",1,true)~=nil
end
local function fontKey(key) return key=="font" or key:sub(1,9)=="htmlFont:" end
local function valid(key,v)
 if type(v)~="table" or not S:Number(v.n) or v.n<0 or v.n>48 or v.n%1~=0 then return false end
 for i=1,v.n do
  if not S:Readable(v[i]) or type(v[i])=="number" and not S:Number(v[i]) then return false end
 end
 if fontKey(key) then return v.n==3 and asset(v[1]) and S:Number(v[2]) and v[2]>0 and S:Text(v[3]) end
 if key=="texture" or key=="barTexture" then
  if v.n~=2 and v.n~=10 then return false end
  if v[1]~=false and not asset(v[1]) or v[2]~=false and (not S:Text(v[2]) or v[2]=="") then return false end
  for i=3,v.n do if not S:Number(v[i]) then return false end end
 elseif key=="dimensions" then
  return v.n==2 and S:Number(v[1]) and v[1]>0 and S:Number(v[2]) and v[2]>0
 elseif key=="decorativeAlpha" then
  return v.n==1 and S:Number(v[1]) and v[1]>=0 and v[1]<=1
 elseif key=="crop" then
  if v.n~=8 then return false end
  for i=1,8 do if not S:Number(v[i]) then return false end end
 elseif key=="points" or key=="heightPoints" or key=="boxPoints" then
  local offset=key=="heightPoints" and 1 or key=="boxPoints" and 2 or 0
  if (v.n-offset)%5~=0 then return false end
  for i=1,offset do if not S:Number(v[i]) or v[i]<0 then return false end end
  for i=1+offset,v.n,5 do
   if not S:Text(v[i]) or v[i]=="" or not S:Text(v[i+2]) or v[i+2]=="" or not S:Number(v[i+3]) or not S:Number(v[i+4]) then return false end
  end
 end
 return true
end
local function equal(key,a,b)
 if not a or not b or a.n~=b.n or not valid(key,a) or not valid(key,b) then return false end
 for i=1,a.n do
  if (key=="texture" or key=="barTexture") and i==1 then
   -- An atlas is the restorable identity; its backing sheet may be represented
   -- by a path on one read and a file ID on another.
   if not (a[2]~=false and a[2]==b[2]) and not L:AssetEqual(a[i],b[i]) then return false end
  elseif fontKey(key) and i==1 then
   if not L:AssetEqual(a[i],b[i]) then return false end
  elseif key=="dimensions" or key=="width" or key=="height" or key=="scale" or fontKey(key) and i==2 or key=="points" and (i%5==4 or i%5==0)
   or key=="heightPoints" and (i==1 or (i-1)%5==4 or (i-1)%5==0)
   or key=="boxPoints" and (i<=2 or (i-2)%5==4 or (i-2)%5==0) then
   if not L:GeometryEqual(a[i],b[i]) then return false end
  elseif colorKey(key) and type(a[i])=="number" and type(b[i])=="number" then
   if not L:ColorEqual(a[i],b[i]) then return false end
  elseif type(a[i])=="number" and type(b[i])=="number" then
   if math.abs(a[i]-b[i])>.0001 then return false end
  elseif a[i]~=b[i] then return false end
 end
 return true
end
local function observe(get,o,key)
 local ok,v=pcall(get,o)
 if ok and valid(key,v) then return v end
end
local function parentCurrent(object,parent)
 local current,state=L:Public(object,"GetParent")
 return state=="KNOWN" and rawequal(current,parent)
end
local function rootCurrent(owner,releasing)
 local row,parent=owner.rootRow,owner.parentOwner
 if not row then return true end
 if not parent or parent.roots[row.spec.name]~=row or row.leaseOwner~=owner then return false end
 if not releasing and not rawequal(_G[row.spec.name],row.frame) then return false end
 if owner.rootParentTracked and not parentCurrent(row.frame,owner.rootParent) then return false end
 -- GetParent can invoke an observing hook. Recheck the pure identity after it.
 return parent.roots[row.spec.name]==row and row.leaseOwner==owner and (releasing or rawequal(_G[row.spec.name],row.frame))
end
local function receiptCurrent(row)
 if row.parentTracked and not parentCurrent(row.object,row.nativeParent) then return false end
 for _,edge in ipairs(row.lineage or {}) do
  if not parentCurrent(edge.object,edge.parent) then return false end
 end
 return true
end
-- A native viewer can lose its external context parent without moving its
-- icon subtree. Capture that subtree once, while acquiring each receipt. An
-- exact descendant lineage permits restorative leaf paint in that case; it
-- never grants permission to move the root or a recycled/reparented child.
local function captureLineage(owner,object)
 local root=owner.rootRow and owner.rootRow.frame
 if not root or rawequal(object,root) then return nil end
 local lineage,seen={},{}
 local node=object
 for _=1,24 do
  if not S:Frame(node,false) or seen[node] then return nil end
  seen[node]=true
  local parent,state=L:Public(node,"GetParent")
  if state~="KNOWN" or not S:Frame(parent,false) then return nil end
  lineage[#lineage+1]={object=node,parent=parent}
  if rawequal(parent,root) then return lineage end
  node=parent
 end
end
local leafRestore={texture=true,barTexture=true,font=true,crop=true,menuArrow=true,underlineMask=true,decorativeAlpha=true}
local function decorativeLeaf(owner,object)
 -- Only a public Texture can carry this receipt. Frame alpha controls an
 -- entire native subtree and must keep the stricter original-parent custody.
 return not (owner.rootRow and rawequal(object,owner.rootRow.frame))
  and L:Public(object,"GetObjectType","string")=="Texture"
end
local function restoreCustody(owner,receipt)
 if receipt.key=="decorativeAlpha" and not decorativeLeaf(owner,receipt.object) then return false end
 if rootCurrent(owner,true) and receiptCurrent(receipt) then
  -- Descendant getters can synchronously retire the root owner or change its
  -- external parent. Fence the entire inspection before authorizing a setter.
  local row,parent=owner.rootRow,owner.parentOwner
  if row then
   if owner.rootParentTracked and not parentCurrent(row.frame,owner.rootParent) then return false end
   if not parent or parent.roots[row.spec.name]~=row or row.leaseOwner~=owner then return false end
  end
  return true,owner.rootParent
 end
 local row,parent=owner.rootRow,owner.parentOwner
 if not row or not parent or not leafRestore[receipt.key] or not receipt.lineage
  or rawequal(receipt.object,row.frame) then return false end
 local function identity()
  return parent.roots[row.spec.name]==row and row.leaseOwner==owner
   and rawequal(_G[row.spec.name],row.frame)
 end
 if not identity() then return false end
 local external,state=L:Public(row.frame,"GetParent")
 if state~="KNOWN" or not S:Frame(external,false) then return false end
 for _,edge in ipairs(receipt.lineage) do
  if not identity() or not parentCurrent(edge.object,edge.parent) then return false end
 end
 -- Fence getters that synchronously trigger native layout/owner callbacks.
 return identity() and parentCurrent(row.frame,external) and identity(),external
end
local function live(owner,generation,profile)
 return rootCurrent(owner,false) and owner.active and not owner.releasing and owner.generation==generation and M.profile==profile and R:Qualified() and R:Selected(owner.id)
  and (not owner.parentOwner or owner.parentOwner.active and owner.parentGeneration==owner.parentOwner.generation)
  and not M.state.safe and not R:NativeEditing()
end
-- Scalar paint on a verified unprotected native widget is distinct from input,
-- visibility and layout. Never mutate a protected/forbidden ancestor in combat.
local combatPaint={texture=true,barTexture=true,font=true,crop=true,menuArrow=true,castEnabled=true}
-- castEnabled is used only by the reviewed PlayerCastingBarFrame switch. The
-- same public-tree check below rejects protected/forbidden roots and ancestors;
-- it is not permission to mutate arbitrary secure visibility in combat.
local diagnosticKeys={texture=true,barTexture=true,font=true,crop=true,points=true,dimensions=true,alpha=true,decorativeAlpha=true,underlineMask=true,panel=true,
 icon=true,item=true,list=true,pool=true,
 width=true,height=true,heightPoints=true,boxPoints=true,scale=true,parent=true,shown=true,mouse=true,ignoreParentAlpha=true,castEnabled=true,menuArrow=true}
local function property(key)
 if type(key)~="string" then return "property" end
 if diagnosticKeys[key] then return key end
 if key:sub(1,9)=="htmlFont:" then return "htmlFont" end
 if key:sub(1,10)=="htmlColor:" or key:find("Color",1,true) or key:find("Tint",1,true) then return "color" end
 return "property"
end
local function failure(owner,key,phase,reason)
 local d=owner.leaseDiagnostics or {};owner.leaseDiagnostics=d
 local value=phase..":"..property(key)..":"..reason
 d.first=d.first or value;d.last=value
end
local function observation(owner,key,want,actual)
 if key~="texture" and key~="barTexture" then return end
 local detail="READBACK_UNAVAILABLE"
 if actual and want then
  if equal(key,want,actual) then detail="READBACK_MATCHED"
  elseif actual.n~=want.n then detail="TUPLE_SHAPE"
  elseif actual[2]~=want[2] then detail="ATLAS_IDENTITY"
  elseif not L:AssetEqual(actual[1],want[1]) and not (actual[2]~=false and actual[2]==want[2]) then detail="ASSET_IDENTITY"
  else detail="TEXTURE_COORDINATES" end
 end
 local d=owner.leaseDiagnostics or {};owner.leaseDiagnostics=d
 d.textureObservation=detail
end
function L:Begin(owner)
 owner.generation=(owner.generation or 0)+1;owner.records=owner.records or {};owner.lookup=owner.lookup or setmetatable({},{__mode="k"})
 owner.decorations=owner.decorations or {};owner.hooks=owner.hooks or setmetatable({},{__mode="k"})
 owner.gaps=0;owner.styled=0;owner.expected=0;owner.leaseDiagnostics={}
 owner.supersededWrites=0
 owner.preservedSources=nil;owner.preservedNativeSources=0
end
-- A combat provider can expose several independent native roots. Its methods
-- still run on the provider, while each root holds its own restore journal.
-- The read index stays shared for callers such as native cast-role preference
-- restoration; a receipt itself belongs to exactly one lease owner.
function L:Owner(owner,object)
 if not owner.rootScoped then return owner end
 if owner.leaseScope then return owner.leaseScope end
 local mapped=object and owner.leaseObjectOwners and owner.leaseObjectOwners[object]
 if mapped and mapped.rootRow and owner.roots[mapped.rootRow.spec.name]==mapped.rootRow then return mapped end
 local only
 for name,lease in pairs(owner.rootLeaseOwners or {}) do
  if owner.roots[name] and owner.roots[name].leaseOwner==lease then
   if only then return owner end
   only=lease
  end
 end
 return only or owner
end
local function count(owner,key,amount)
 owner[key]=(owner[key] or 0)+amount
 local parent=owner.accountingOwner
 if parent and owner.parentGeneration==parent.generation then parent[key]=(parent[key] or 0)+amount end
end
function L:Gap(owner,key,reason)
 owner=self:Owner(owner)
 count(owner,"gaps",1)
 if key and reason then failure(owner,key,"apply",reason) end
 return false
end
function L:Diagnostics(owner)
 local d=owner.leaseDiagnostics or {};local pending,keys=0,{}
 local first,last,release=d.first,d.last,d.release
 local preserved,textureObservation=0,d.textureObservation
 local function journal(lease)
  for _,row in ipairs(lease.records or {}) do if row.pending then pending=pending+1;keys[property(row.key)]=true end end
  local diagnostic=lease.leaseDiagnostics or {}
  first=first or diagnostic.first;last=diagnostic.last or last
  preserved=preserved+(lease.preservedNativeSources or 0);textureObservation=diagnostic.textureObservation or textureObservation
  if diagnostic.release=="PENDING" then release="PENDING" elseif not release then release=diagnostic.release end
 end
 journal(owner)
 local roots={};for name in pairs(owner.rootLeaseOwners or {}) do roots[#roots+1]=name end;table.sort(roots)
 for _,name in ipairs(roots) do journal(owner.rootLeaseOwners[name]) end
 local names={};for key in pairs(keys) do names[#names+1]=key end;table.sort(names)
 while #names>8 do table.remove(names) end
 return "generation="..tostring(owner.generation or 0).."; first="..(first or "NONE").."; last="..(last or "NONE")
  .."; release="..(release or "NONE").."; pending="..pending.."; properties="..(#names>0 and table.concat(names,",") or "NONE")
  .."; native_color_preserved="..preserved.."; texture_mismatch="..(textureObservation or "NONE")
  .."; superseded_writes="..tostring(owner.supersededWrites or 0)
end
-- SetAtlas authors its own coordinates before any explicit crop is applied.
-- The pinned C_Texture contract exposes that exact intermediate rectangle.
local function atlasDefaultTuple(value)
 if not value or value[2]==false or not C_Texture or type(C_Texture.GetAtlasInfo)~="function" then return nil end
 local info,state=S:Public(C_Texture.GetAtlasInfo,nil,value[2])
 if state~="KNOWN" or not S:Readable(info) or type(info)~="table" then return nil end
 local left=S:FieldAccess(info,"leftTexCoord");local right=S:FieldAccess(info,"rightTexCoord")
 local top=S:FieldAccess(info,"topTexCoord");local bottom=S:FieldAccess(info,"bottomTexCoord")
 if not S:Number(left) or not S:Number(right) or not S:Number(top) or not S:Number(bottom) then return nil end
 return pack(value[1],value[2],left,top,left,bottom,right,top,right,bottom)
end
local function rememberAttempt(row,value)
 row.alternateAttempts=row.alternateAttempts or {}
 for _,candidate in ipairs(row.alternateAttempts) do if equal(row.key,value,candidate) then return true end end
 if #row.alternateAttempts>=16 then return false end
 row.alternateAttempts[#row.alternateAttempts+1]=value;return true
end
local function unprovenAtlas(row,value)
 return row.atlasSourceUnproven and value[2]~=false and value[2]==row.atlasSourceUnproven[2]
end
local function matchesAttempt(row,value)
 if equal(row.key,value,row.attempt) then return true end
 for _,candidate in ipairs(row.alternateAttempts or {}) do if equal(row.key,value,candidate) then return true end end
 return false
end
function L:Write(owner,o,key,get,set,want,reassert)
 owner=self:Owner(owner,o)
 count(owner,"expected",1)
 if owner.rootScoped then return self:Gap(owner,key,"ROOT_SCOPE_UNAVAILABLE") end
 local generation,profile=owner.generation,M.profile
 if not live(owner,generation,profile) or not S:Frame(o,false) then
  if owner.rootRow then owner.rootRow.leaseRepair=true end
  return self:Gap(owner,key,"OWNER_UNAVAILABLE")
 end
 -- Native getters and post-hooks may synchronously submit a newer request to
 -- this very property without changing the provider generation. Seal the
 -- request before the snapshot, not just before the setter: an older read
 -- must not overwrite the newer value or mark its confirmed receipt pending.
 -- Other properties remain independent, and unresolved inverse receipts stay
 -- in the original journal until the ordinary release verifies them.
 owner.writeRequests=owner.writeRequests or setmetatable({},{__mode="k"})
 local requests=owner.writeRequests[o]
 if not requests then requests={};owner.writeRequests[o]=requests end
 owner.writeSerial=(owner.writeSerial or 0)+1
 local request=owner.writeSerial;requests[key]=request
 local function requestCurrent() return owner.writeRequests[o]==requests and requests[key]==request end
 local function superseded()
  count(owner,"supersededWrites",1)
  return false,"PROPERTY_WRITE_SUPERSEDED"
 end
 local function scoped() return requestCurrent() and live(owner,generation,profile) and requestCurrent() end
 if key=="decorativeAlpha" and not decorativeLeaf(owner,o) then return self:Gap(owner,key,"DECORATIVE_TEXTURE_REQUIRED") end
 local now=observe(get,o,key)
 if not requestCurrent() then return superseded() end
 if not now then return self:Gap(owner,key,"SNAPSHOT_UNAVAILABLE") end
 if not equal(key,want,want) then return self:Gap(owner,key,"TARGET_INVALID") end
 if not scoped() then if not requestCurrent() then return superseded() end;return self:Gap(owner,key,"OWNER_CHANGED") end
 local byObject=owner.lookup[o]
 if not byObject then byObject={};owner.lookup[o]=byObject end
 local row=byObject[key]
 if row and row.leaseOwner and row.leaseOwner~=owner then return self:Gap(owner,key,"PROPERTY_OTHER_ROOT") end
 local custody=not row or receiptCurrent(row)
 if not requestCurrent() then return superseded() end
 if not custody then
  row.pending=true;if owner.rootRow then owner.rootRow.leaseRepair=true end
  return self:Gap(owner,key,"NATIVE_CUSTODY_CHANGED")
 end
 local decorativeLineage
 if key=="decorativeAlpha" and owner.rootRow then
  decorativeLineage=row and row.lineage or captureLineage(owner,o)
  local admitted=decorativeLineage and receiptCurrent({lineage=decorativeLineage})
  if not requestCurrent() then return superseded() end
  if not admitted then return self:Gap(owner,key,"DESCENDANT_LINEAGE_UNAVAILABLE") end
  if not scoped() then if not requestCurrent() then return superseded() end;return self:Gap(owner,key,"OWNER_CHANGED") end
 end
 local parent=owner.accountingOwner
 -- Accounting-only children (inventory slots) keep independent lookup tables.
 -- The object-to-root index exists only for root-scoped property dispatch.
 if parent and parent.leaseObjectOwners then parent.leaseObjectOwners[o]=owner end
 if not row and equal(key,now,want) and not reassert then count(owner,"styled",1);return true end
 if not row then
  -- A nil texture source can be an engine color texture. The public API has
  -- no inverse for SetColorTexture; do not turn it into an unrestorable asset.
  if (key=="texture" or key=="barTexture") and now[1]==false and now[2]==false then return self:Gap(owner,key,"SOURCE_UNRESTORABLE") end
  if #owner.records>=6000 then return self:Gap(owner,key,"JOURNAL_LIMIT") end
  row={object=o,key=key,get=get,set=set,original=now,leaseOwner=owner}
  if owner.rootRow and type(self:Field(o,"GetParent"))=="function" then
   local nativeParent,state=self:Public(o,"GetParent")
   if not requestCurrent() then return superseded() end
   if state~="KNOWN" then return self:Gap(owner,key,"NATIVE_CUSTODY_UNAVAILABLE") end
   row.parentTracked=true;row.nativeParent=nativeParent
  end
  if owner.rootRow and leafRestore[key] then
   row.lineage=decorativeLineage or captureLineage(owner,o)
  end
  if not requestCurrent() then return superseded() end
  byObject[key]=row;owner.records[#owner.records+1]=row
 elseif row.pending then return self:Gap(owner,key,"RESTORE_REQUIRED") end
 -- Native pool setup can reauthor a field without changing object identity.
 -- If it is a genuinely newer public value, the next cosmetic application
 -- leases that value; a later handback must not resurrect an older pool use.
 if leafRestore[key] and row.lineage and row.written and not equal(key,now,row.written) and not equal(key,now,row.attempt)
  and not equal(key,now,row.original) then
  row.original=now;row.written=nil;row.attempt=nil
  owner.nativeRebases=(owner.nativeRebases or 0)+1
 end
 if not scoped() then if not requestCurrent() then return superseded() end;return self:Gap(owner,key,"OWNER_CHANGED") end
 custody=receiptCurrent(row)
 if not requestCurrent() then return superseded() end
 if not custody then row.pending=true;if owner.rootRow then owner.rootRow.leaseRepair=true end;return self:Gap(owner,key,"NATIVE_CUSTODY_CHANGED") end
 if equal(key,now,want) and not reassert then row.written=now;count(owner,"styled",1);return true end
 if S:InCombat() and (not combatPaint[key] or not S:Frame(o,true)) then owner.combatPending=true;return self:Gap(owner,key,"COMBAT_DEFERRED") end
 if not scoped() then if not requestCurrent() then return superseded() end;return self:Gap(owner,key,"OWNER_CHANGED") end
 -- A successor can begin while the previous setter is still on the stack.
 -- Keep an observed earlier attempt as owned evidence before replacing that
 -- attempt token. If the successor is refused, cleanup still owes the exact
 -- original instead of mistaking the interrupted older value for a foreign
 -- writer. An unrelated public value is never adopted by this rule.
 if matchesAttempt(row,now) then row.written=now end
 row.attempt=want;row.alternateAttempts=nil;row.atlasSourceUnproven=nil
 -- Native post-hooks run synchronously inside setters. Fence the exact lease
 -- write as well as its provider so it cannot enqueue its own repair work.
 local depth=owner.leaseWriteDepth or 0;owner.leaseWriteDepth=depth+1
 local parent=owner.parentOwner
 local parentDepth=parent and parent~=owner and (parent.leaseWriteDepth or 0)
 if parentDepth then parent.leaseWriteDepth=parentDepth+1 end
 -- Compound setters receive the same exact receipt fence at every stage.
 -- A staged attempt records a known intermediate target (for example no
 -- anchors after ClearAllPoints), so an interrupted transaction keeps its
 -- native inverse instead of misidentifying that partial write as foreign.
 local function current()
  local function retained()
   return requestCurrent() and owner.lookup[o]==byObject and byObject[key]==row and owner.generation==generation and M.profile==profile
    and owner.active and not owner.releasing and not M.state.safe
    and (not owner.parentOwner or owner.parentOwner.active and owner.parentGeneration==owner.parentOwner.generation)
  end
  return retained() and live(owner,generation,profile) and receiptCurrent(row)
   and (not S:InCombat() or combatPaint[key] and S:Frame(o,true)) and retained()
 end
 local function attempt(value,alternate)
  if not current() or not valid(key,value) then return false end
  if alternate=="unprovenAtlas" then row.atlasSourceUnproven=value
  elseif alternate then return rememberAttempt(row,value) and current()
  else row.attempt=value end
  return true
 end
 local ok,result=pcall(set,o,want,current,attempt)
 owner.leaseWriteDepth=depth
 if parentDepth then parent.leaseWriteDepth=parentDepth end
 local after=observe(get,o,key)
 if not current() then
  if not requestCurrent() then return superseded() end
  row.pending=true;if owner.rootRow then owner.rootRow.leaseRepair=true end
  return self:Gap(owner,key,"OWNER_CHANGED")
 end
 if ok and result~=false and equal(key,after,want) then row.written=after;row.attempt=nil;row.alternateAttempts=nil;row.atlasSourceUnproven=nil;count(owner,"styled",1);return true end
 -- A throwing setter may have partially changed the property. Retain its actual
 -- public result for cleanup; a no-op setter is not a completed cosmetic write.
 if after and not equal(key,after,now) then row.written=after end
 row.pending=true;if owner.rootRow then owner.rootRow.leaseRepair=true end
 observation(owner,key,want,after)
 return self:Gap(owner,key,(not ok or result==false) and "SETTER_REJECTED" or not after and "READBACK_UNAVAILABLE" or "READBACK_MISMATCH")
end
function L:Scalar(owner,o,key,getName,setName,want)
 if not o then return true end
 local getter,setter=self:Field(o,getName),self:Field(o,setName)
 if type(getter)~="function" or type(setter)~="function" then return self:Gap(owner,key,"SCALAR_API_UNAVAILABLE") end
 if not S:Readable(want) or type(want)=="number" and not S:Number(want) then return self:Gap(owner,key,"TARGET_INVALID") end
 return self:Write(owner,o,key,function(x)
  -- Dimensions are constraints, not the cached on-screen rectangle. Hidden
  -- native labels/containers can retain their previous computed width until
  -- the next layout pass. Compare the explicit value authored by the setter
  -- and restore that exact constraint, just as compound geometry already does.
  local v
  if (key=="width" and getName=="GetWidth") or (key=="height" and getName=="GetHeight") then v=getter(x,true)
  else v=getter(x) end
  if type(v)~=type(want) or type(v)=="number" and not S:Number(v) then return nil end
  return pack(v)
 end,function(x,v,current)
  if current and not current() then return false end
  if key=="scale" and R.NativeScale then assert(R.NativeScale(x,v[1]),"NATIVE_SCALE_UNCONFIRMED")
  else return setter(x,unpack(v,1,v.n)) end
 end,pack(want))
end
function L:Alpha(owner,o,value) return self:Scalar(owner,o,"alpha","GetAlpha","SetAlpha",value) end
function L:DecorativeAlpha(owner,o,value) return self:Scalar(owner,o,"decorativeAlpha","GetAlpha","SetAlpha",value) end
-- GetTexture is the restorable asset. GetTextureFilePath is also used by the
-- native inspection UI and can describe a file ID instead of naming a file.
-- Never feed that display label back to a source setter or let it shadow the
-- actual public asset. The requested path is never used as a readback fallback.
-- Optional third result identifies the successful getter or a precise refusal.
-- A fourth result retains a malformed PUBLIC value for the four owned probes;
-- it never turns that value into a source or records native/user texture paths.
function L:TextureSource(texture)
 if not S:Frame(texture,false) then return nil,nil,"OBJECT_UNAVAILABLE" end
 local source,atlas=false,false;local observed=false;local emptyGetters
 local getAtlas=self:Field(texture,"GetAtlas")
 if type(getAtlas)=="function" then
  local ok,value=pcall(getAtlas,texture)
  if not ok then return nil,nil,"GetAtlas:THREW" end
  if not S:Readable(value) then return nil,nil,"GetAtlas:RESTRICTED" end
  if value~=nil and value~=false and value~="" then
   if not S:Text(value) then return nil,nil,"GetAtlas:INVALID" end
   atlas=value
  end
 end
 for _,method in ipairs({"GetTexture","GetTextureFileID","GetTextureFilePath"}) do
  local getter=self:Field(texture,method)
  if type(getter)=="function" then
   local ok,value=pcall(getter,texture)
   if not ok then return nil,nil,method..":THREW" end
   if not S:Readable(value) then return nil,nil,method..":RESTRICTED" end
   observed=true
   if S:Text(value) and value:match("^FileData ID %-?%d+$") then
    -- This is a diagnostic description, including ID zero for an empty or
    -- non-file region. The numeric accessor above is the restorable route.
    emptyGetters=emptyGetters or {};emptyGetters[#emptyGetters+1]=method..":DESCRIPTOR_ONLY"
   elseif asset(value) then return value,atlas,method
   elseif value~=nil and value~=false and value~="" and value~=0 then return nil,nil,method..":INVALID",value
   else emptyGetters=emptyGetters or {};emptyGetters[#emptyGetters+1]=method..":EMPTY" end
  end
 end
 if not observed then return nil,nil,"SOURCE_GETTERS_UNAVAILABLE" end
 return source,atlas,table.concat(emptyGetters,"+")
end
-- GetTextureFilePath may canonicalize an addon filename independently of the
-- file-ID resolver. Establish that spelling on a hidden addon-owned texture,
-- once per authored asset, before leasing a native region. A different file,
-- nil/zero, stale atlas or rejected setter cannot become an alias. This proves
-- public source identity only; it does not certify native rasterization.
function L:ResetAssetProofs()
 self.assetProofs={}
end
-- Only the allowlisted owned asset probes use these diagnostic snapshots. No
-- arbitrary native texture path or user content is retained in support output.
local function probeValue(value)
 if value==false then return "EMPTY" end
 if S:Number(value) then return tostring(value) end
 if S:Text(value) then
  local text=value:gsub("[%c;|,@]","?")
  return #text>112 and text:sub(1,109).."..." or text
 end
 return "UNAVAILABLE"
end
local function probeObservation(proof,source,atlas,getter,invalid)
 proof.observedKind=type(source)=="number" and (source<0 and "LOCAL_FILE_ID" or "FILE_ID") or type(source)=="string" and "PATH" or source==false and "EMPTY" or invalid~=nil and "INVALID_PUBLIC_VALUE" or "UNAVAILABLE"
 proof.sourceGetter=getter or "UNKNOWN"
 proof.observedValue=probeValue(source==nil and invalid or source)
 proof.observedAtlas=probeValue(atlas)
end
local function probeCheck(proof,phase,source,atlas,getter)
 proof.checkPhase=phase;proof.checkGetter=getter or "UNKNOWN"
 proof.checkValue=probeValue(source);proof.checkAtlas=probeValue(atlas)
end
function L:PrepareAsset(path)
 if path~=self.white and path~=self.beam and path~=self.panel and path~=self.square and path~=self.underline then return end
 self.assetProofs=self.assetProofs or {}
 if self.assetProofs[path] or S:InCombat() or not R:Qualified() or not S:Frame(UIParent,false) then return end
 local proof={};self.assetProofs[path]=proof
 local ok=pcall(function()
  local probe=self.assetProbe
  if not probe then
   probe=UIParent:CreateTexture(nil,"BACKGROUND");self.assetProbe=probe
   probe:Hide();probe:SetAlpha(0)
  end
  if not S:Frame(probe,true) then return end
  -- A stale source must not be mistaken for this request, even on a native
  -- getter that returns only runtime file IDs. Reset the owned probe first.
  probe:SetTexture(nil)
  local empty,emptyAtlas,emptyGetter=self:TextureSource(probe)
  if empty~=false or emptyAtlas~=false then
   probeCheck(proof,"CLEAR_BEFORE",empty,emptyAtlas,emptyGetter)
   proof.state="PROBE_CLEAR_UNCONFIRMED";return
  end
  local sent=probe:SetTexture(path)
  local source,atlas,getter,invalid=self:TextureSource(probe)
  probeObservation(proof,source,atlas,getter,invalid)
  if sent==false then proof.state="SETTER_REJECTED";return end
  if not asset(source) or atlas~=false then proof.state="SOURCE_UNAVAILABLE";return end
  local compatible=directAssetEqual(source,path)
  if not compatible and type(source)=="string" then
   -- Only the exact authored stem without its explicit TGA suffix is a
   -- candidate. The independently observed widget result is still required.
   compatible=assetSpelling(path):gsub("%.tga$","")==assetSpelling(source)
  end
  if not compatible and fileID(source) then
   -- Some native asset routes expose a runtime ID without an independent
   -- GetFileIDFromPath entry. On our own cleared texture, require the public
   -- file-ID getter to agree and a second source read to remain stable. A
   -- known conflicting path resolution is never replaced by this evidence.
   local resolved=assetID(path)
   local id,idState=self:Public(probe,"GetTextureFileID","number")
   local repeated,repeatedAtlas,repeatedGetter=self:TextureSource(probe)
   compatible=resolved==nil and idState=="KNOWN" and id==source and repeated==source and repeatedAtlas==false
   if compatible then proof.route=source<0 and "OWNED_SESSION_FILE_ID" or "OWNED_RUNTIME_FILE_ID" end
   if not compatible then probeCheck(proof,"REPEATED_SOURCE",repeated,repeatedAtlas,repeatedGetter) end
  end
  if compatible and type(source)=="number" and source<0 then
   -- A local identity must also survive its actual numeric inverse. A getter
   -- sentinel or an ID accepted only as a path cannot authorize native writes.
   local reapplied=probe:SetTexture(source)
   local restored,restoredAtlas,restoredGetter=self:TextureSource(probe)
   if reapplied==false or restored~=source or restoredAtlas~=false then
    probeCheck(proof,"LOCAL_ID_RESTORE",restored,restoredAtlas,restoredGetter)
    proof.state="LOCAL_ID_RESTORE_UNCONFIRMED";return
   end
  end
  if compatible then
   -- Verify reset again so a constant/stale accessor cannot authorize an alias.
   probe:SetTexture(nil)
   local cleared,clearedAtlas,clearedGetter=self:TextureSource(probe)
   if cleared~=false or clearedAtlas~=false then
    probeCheck(proof,"CLEAR_AFTER",cleared,clearedAtlas,clearedGetter)
    proof.state="PROBE_CLEAR_UNCONFIRMED";return
   end
   proof.source=source;proof.state="OBSERVED";proof.route=proof.route or "PUBLIC_ASSET_MATCH"
  else proof.state="SOURCE_MISMATCH" end
 end)
 if not ok then proof.state="PROBE_UNAVAILABLE" end
end
function L:AssetReport()
 local rows={}
 for _,key in ipairs({"white","beam","panel","square","underline"}) do
  local proof=self.assetProofs and self.assetProofs[self[key]]
  local source=proof and proof.source
  local kind=type(source)=="string" and "PATH" or fileID(source) and (source<0 and "LOCAL_FILE_ID" or "FILE_ID") or "NONE"
  rows[#rows+1]=key..":"..(proof and proof.state or "NOT_PROBED")..":"..kind
   ..":"..(proof and proof.route or "NONE")..":observed_"..(proof and proof.observedKind or "NONE")
   ..":getter="..(proof and proof.sourceGetter or "NONE")..":value="..(proof and proof.observedValue or "NONE")
   ..":atlas="..(proof and proof.observedAtlas or "NONE")
   ..(proof and proof.checkPhase and ":check="..proof.checkPhase.."@"..proof.checkGetter.."@"..proof.checkValue.."@atlas="..proof.checkAtlas or "")
 end
 return table.concat(rows,",").."; raster=NOT_RUN"
end
function L:Texture(owner,o,path)
 if not o then return true end
 local getTexture,getAtlas,setTexture,setAtlas=self:Field(o,"GetTexture"),self:Field(o,"GetAtlas"),self:Field(o,"SetTexture"),self:Field(o,"SetAtlas")
 if type(getTexture)~="function" or type(setTexture)~="function" then return self:Gap(owner) end
 local getCoords,setCoords=self:Field(o,"GetTexCoord"),self:Field(o,"SetTexCoord")
 if type(getCoords)~="function" or type(setCoords)~="function" then return self:Gap(owner) end
 self:PrepareAsset(path)
 if (path==self.white or path==self.beam or path==self.panel or path==self.square or path==self.underline)
  and not (self.assetProofs and self.assetProofs[path] and self.assetProofs[path].source) then
  return self:Gap(self:Owner(owner,o),"texture","ASSET_PROBE_UNCONFIRMED")
 end
 return self:Write(owner,o,"texture",function(x)
  local p,a=self:TextureSource(x)
  if p==nil then return nil end
  return pack(p,a,getCoords(x))
 end,function(x,v,current,attempt)
  assert(not current or current(),"STYLE_OWNER_RETIRED")
  -- Some sources preserve existing UVs and others reset to the authored full
  -- rectangle. Both exact public possibilities retain a known inverse if the
  -- source call retires this owner before our coordinate call may run.
  local sourceOnly=pack(v[1],v[2],getCoords(x))
  assert(not current or current(),"STYLE_OWNER_RETIRED")
  assert(not attempt or attempt(sourceOnly,true),"STYLE_OWNER_RETIRED")
  if v[2]~=false then
   local atlas=atlasDefaultTuple(v)
   assert(not current or current(),"STYLE_OWNER_RETIRED")
   -- Without metadata a source-only interruption is ambiguous. Keep its debt
   -- for later evidence; never infer ownership of arbitrary returned UVs.
   assert(not attempt or attempt(atlas or v,atlas and true or "unprovenAtlas"),"STYLE_OWNER_RETIRED")
  end
  local sent
  if v[2]~=false then assert(type(setAtlas)=="function","ATLAS_RESTORE_UNAVAILABLE");sent=setAtlas(x,v[2])
  else sent=setTexture(x,v[1]~=false and v[1] or nil) end
  if sent==false then return false end
  assert(not current or current(),"STYLE_OWNER_RETIRED")
  -- Source changes can reset UVs. Snapshot and restore them in the same receipt,
  -- before either setter runs, instead of capturing already-mutated atlas UVs.
  return setCoords(x,unpack(v,3,v.n))
 end,pack(path,false,0,0,0,1,1,0,1,1))
end
-- Optional native decoration can be an engine color fill or a reserved empty
-- state texture. Keep that source and its native visibility/color meaning;
-- geometry/tint and the surrounding owned panel still receive Mirage styling.
-- Required masks and data textures continue to use the strict Texture method.
function L:DecorativeTexture(owner,o,path)
 if not o then return true end
 local p,a=self:TextureSource(o)
 if p==false and a==false then
  local lease=self:Owner(owner,o)
  if not live(lease,lease.generation,M.profile) or not S:Frame(o,false) then return self:Gap(lease,"texture","OWNER_UNAVAILABLE") end
  local previous=lease.lookup and lease.lookup[o] and lease.lookup[o].texture
  if previous then
   -- A failed earlier write can itself have cleared the source. It is not a
   -- fresh native color region, and its handback must finish before admission.
   previous.pending=true;if lease.rootRow then lease.rootRow.leaseRepair=true end
   return self:Gap(lease,"texture","RESTORE_REQUIRED")
  end
  lease.preservedSources=lease.preservedSources or setmetatable({},{__mode="k"})
  if not lease.preservedSources[o] then
   lease.preservedSources[o]=true;lease.preservedNativeSources=(lease.preservedNativeSources or 0)+1
  end
  return true,"NATIVE_COLOR_OR_EMPTY_PRESERVED"
 end
 return self:Texture(owner,o,path)
end
function L:Color(owner,o,key,getName,setName,r,g,b,a)
 if not o then return true end
 local get,set=self:Field(o,getName),self:Field(o,setName)
 if type(get)~="function" or type(set)~="function" then return self:Gap(owner) end
 local function color(rr,gg,bb,aa)
  if not S:Number(rr) or not S:Number(gg) or not S:Number(bb) or aa~=nil and not S:Number(aa) then return nil end
  return pack(rr,gg,bb,aa==nil and 1 or aa)
 end
 return self:Write(owner,o,key,function(x) return color(get(x)) end,
  function(x,v) return set(x,unpack(v,1,v.n)) end,color(r,g,b,a))
end
function L:Font(owner,o,size)
 if not o then return true end
 local get,set=self:Field(o,"GetFont"),self:Field(o,"SetFont")
 if type(get)~="function" or type(set)~="function" then return self:Gap(owner,"font","FONT_API_UNAVAILABLE") end
 return self:Write(owner,o,"font",function(x) local p,s,f=get(x);return pack(p,s,f or "") end,
  function(x,v) return set(x,v[1],v[2],v[3]) end,pack(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",size or 11,""))
end
function L:TexCoords(owner,o,coords)
 if not o then return true end
 local get,set=self:Field(o,"GetTexCoord"),self:Field(o,"SetTexCoord")
 if type(get)~="function" or type(set)~="function" then return self:Gap(owner) end
 return self:Write(owner,o,"crop",function(x) return pack(get(x)) end,function(x,v) return set(x,unpack(v,1,v.n)) end,
  coords)
end
function L:Crop(owner,o) return self:TexCoords(owner,o,pack(.06,.06,.06,.94,.94,.06,.94,.94)) end
local function stage(current,attempt,value)
 assert(not current or current(),"STYLE_OWNER_RETIRED")
 assert(not attempt or attempt(value),"STYLE_OWNER_RETIRED")
end
function L:Points(owner,o,points)
 if not o then return false end
 return self:Write(owner,o,"points",function(x)
  local n=x:GetNumPoints();if not S:Number(n) or n<0 or n>8 or n%1~=0 then return nil end
  local v={n=0}
  for i=1,n do local p=pack(x:GetPoint(i));if p.n~=5 then return nil end;for j=1,5 do v.n=v.n+1;v[v.n]=p[j] end end
  return v
 end,function(x,v,current,attempt)
  stage(current,attempt,{n=0})
  if R.NativeClearPoints then assert(R.NativeClearPoints(x),"NATIVE_CLEAR_UNCONFIRMED") else x:ClearAllPoints() end
  for i=1,v.n,5 do
   local partial={n=i+4};for j=1,partial.n do partial[j]=v[j] end
   stage(current,attempt,partial)
   if R.NativeSetPoint then assert(R.NativeSetPoint(x,unpack(v,i,i+4)),"NATIVE_POINT_UNCONFIRMED")
   else x:SetPoint(unpack(v,i,i+4)) end
  end
  assert(not current or current(),"STYLE_OWNER_RETIRED")
 end,points)
end
-- Read dimensions and anchors before touching either. Native stretch anchors
-- can mask an intermediate SetHeight/SetWidth, so independent immediate
-- readbacks incorrectly report a failure before the final geometry exists.
function L:AnchoredSize(owner,o,width,height,points)
 if not o then return false end
 local both=width~=nil;local offset=both and 2 or 1
 local want=both and pack(width,height) or pack(height)
 for i=1,points.n do want.n=want.n+1;want[want.n]=points[i] end
 return self:Write(owner,o,both and "boxPoints" or "heightPoints",function(x)
  -- Explicit native constraints are available before the next layout/render
  -- pass, including hidden aura borders and stretched progression bars. The
  -- computed rectangle can still be nil or reflect the previous layout here.
  -- Zero remains a legitimate original stretch constraint for exact handback.
  local values=both and pack(x:GetWidth(true),x:GetHeight(true)) or pack(x:GetHeight(true))
  local n=x:GetNumPoints();if not S:Number(n) or n<0 or n>8 or n%1~=0 then return nil end
  for i=1,n do
   local p=pack(x:GetPoint(i));if p.n~=5 then return nil end
   for j=1,5 do values.n=values.n+1;values[values.n]=p[j] end
  end
  return values
 end,function(x,v,current,attempt)
  assert(not current or current(),"STYLE_OWNER_RETIRED")
  local cleared=both and pack(x:GetWidth(true),x:GetHeight(true)) or pack(x:GetHeight(true))
  stage(current,attempt,cleared)
  if R.NativeClearPoints then assert(R.NativeClearPoints(x),"NATIVE_CLEAR_UNCONFIRMED") else x:ClearAllPoints() end
  local sized=both and pack(v[1],v[2]) or pack(v[1]);stage(current,attempt,sized)
  if both then x:SetSize(v[1],v[2]) else x:SetHeight(v[1]) end
  for i=offset+1,v.n,5 do
   local partial={n=i+4};for j=1,partial.n do partial[j]=v[j] end
   stage(current,attempt,partial)
   if R.NativeSetPoint then assert(R.NativeSetPoint(x,unpack(v,i,i+4)),"NATIVE_POINT_UNCONFIRMED")
   else x:SetPoint(unpack(v,i,i+4)) end
  end
  assert(not current or current(),"STYLE_OWNER_RETIRED")
 end,want)
end
function L:Bar(owner,bar,source)
 if not bar then return true end
 local get,set=self:Field(bar,"GetStatusBarTexture"),self:Field(bar,"SetStatusBarTexture")
 if type(get)~="function" or type(set)~="function" then return self:Gap(owner) end
 local originalTexture=get(bar)
 if not S:Frame(originalTexture,false) then return self:Gap(owner) end
 source=source or self.beam
 self:PrepareAsset(source)
 if not (self.assetProofs and self.assetProofs[source] and self.assetProofs[source].source) then
  return self:Gap(self:Owner(owner,bar),"barTexture","ASSET_PROBE_UNCONFIRMED")
 end
 return self:Write(owner,bar,"barTexture",function(x)
  local t=x:GetStatusBarTexture();if not S:Frame(t,false) then return nil end
  local path,atlas=self:TextureSource(t)
  if path==nil then return nil end
  return pack(path,atlas)
 end,function(x,v)
  -- StatusBar owns atlas selection as well as disk textures. Mutating its
  -- internal Texture directly bypasses that routing and can reject handback.
  return set(x,v[2]~=false and v[2] or v[1])
 end,pack(source,false))
end
function L:Underline(owner,texture,anchor)
 if not texture then return true end
 local ok=self:DecorativeTexture(owner,texture,self.white)
 ok=self:AnchoredSize(owner,texture,nil,2,pack("BOTTOMLEFT",anchor,"BOTTOMLEFT",0,0,"BOTTOMRIGHT",anchor,"BOTTOMRIGHT",0,0)) and ok
 return ok -- Native visibility/color retain dispel and enchant meaning.
end
-- Native aura borders can have inaccessible anchors even when their artwork is
-- public. An owned alpha mask leaves that geometry and the native dispel atlas
-- completely intact. In particular, dispel colors can be baked into the atlas;
-- replacing it with a white texture would discard information.
function L:BorderUnderline(owner,texture)
 if not texture then return true end
 owner=self:Owner(owner,texture)
 if owner.rootScoped or not live(owner,owner.generation,M.profile) then return self:Gap(owner,"underlineMask","OWNER_UNAVAILABLE") end
 local parent,state=self:Public(texture,"GetParent")
 if state~="KNOWN" or not S:Frame(parent,false) then return self:Gap(owner,"underlineMask","NATIVE_CUSTODY_UNAVAILABLE") end
 for _,method in ipairs({"GetNumMaskTextures","GetMaskTexture","AddMaskTexture","RemoveMaskTexture"}) do
  if type(self:Field(texture,method))~="function" then return self:Gap(owner,"underlineMask","MASK_API_UNAVAILABLE") end
 end
 owner.underlineMasks=owner.underlineMasks or setmetatable({},{__mode="k"})
 local mask=owner.underlineMasks[texture]
 local nativeAtlas=self:Public(texture,"GetAtlas","string")
 local keepDispelSymbol=nativeAtlas and nativeAtlas:match("^ui%-debuff%-border%-%a+%-icon$")~=nil
 -- The optional native dispel symbol is meaningful content. Keep its complete
 -- artwork instead of clipping it to a line; an existing mask is removed by
 -- the same observable journal when native settings turn that symbol on.
 if keepDispelSymbol and not mask then return true end
 self:PrepareAsset(self.underline)
 if not (self.assetProofs and self.assetProofs[self.underline] and self.assetProofs[self.underline].source) then
  return self:Gap(owner,"underlineMask","ASSET_PROBE_UNCONFIRMED")
 end
 if not mask then
  if S:InCombat() then owner.combatPending=true;return self:Gap(owner,"underlineMask","COMBAT_DEFERRED") end
  local ok=pcall(function()
   assert(type(self:Field(parent,"CreateMaskTexture"))=="function","MASK_CREATE_UNAVAILABLE")
   mask=parent:CreateMaskTexture(nil,"ARTWORK")
   assert(S:Frame(mask,false),"MASK_CREATE_UNAVAILABLE")
   mask:SetAllPoints(texture)
   assert(mask:SetTexture(self.underline,"CLAMPTOBLACKADDITIVE","CLAMPTOBLACKADDITIVE")~=false,"MASK_SOURCE_REJECTED")
   local source,atlas=self:TextureSource(mask)
   assert(self:AssetEqual(source,self.underline) and atlas==false,"MASK_SOURCE_UNCONFIRMED")
  end)
  if not ok then return self:Gap(owner,"underlineMask","MASK_CREATE_UNCONFIRMED") end
  if not live(owner,owner.generation,M.profile) or not parentCurrent(texture,parent) then return self:Gap(owner,"underlineMask","OWNER_CHANGED") end
  owner.underlineMasks[texture]=mask
 end
 local maskSource,maskAtlas=self:TextureSource(mask)
 if not self:AssetEqual(maskSource,self.underline) or maskAtlas~=false then return self:Gap(owner,"underlineMask","MASK_SOURCE_UNCONFIRMED") end
 return self:Write(owner,texture,"underlineMask",function(x)
  local n,known=self:Public(x,"GetNumMaskTextures","number")
  if known~="KNOWN" or n<0 or n>8 or n%1~=0 then return nil end
  local present=false
  for i=1,n do
   local value,status=self:Public(x,"GetMaskTexture",nil,i)
   if status~="KNOWN" or not S:Frame(value,false) then return nil end
   if rawequal(value,mask) then present=true end
  end
  return pack(present)
 end,function(x,v)
  if v[1] then return x:AddMaskTexture(mask) else return x:RemoveMaskTexture(mask) end
 end,pack(not keepDispelSymbol))
end
function L:Panel(owner,parent,anchor,key,fill)
 owner=self:Owner(owner,parent)
 if owner.rootScoped then self:Gap(owner,nil,"ROOT_SCOPE_UNAVAILABLE");return nil end
 if not S:Frame(parent,false) or not S:Frame(anchor or parent,false) then self:Gap(owner,"panel","PARENT_UNAVAILABLE");return nil end
 local generation,profile=owner.generation,M.profile
 local cache=owner.decorations[parent];if not cache then cache={};owner.decorations[parent]=cache end
 local f=cache[key]
 if not f or not f.miragePanelReady then
  if S:InCombat() then owner.combatPending=true;self:Gap(owner,"panel","COMBAT_DEFERRED");return nil end
  self:PrepareAsset(self.white);self:PrepareAsset(self.panel)
  if not (self.assetProofs and self.assetProofs[self.white] and self.assetProofs[self.white].source
   and self.assetProofs[self.panel] and self.assetProofs[self.panel].source) then self:Gap(owner,"panel","ASSET_PROBE_UNCONFIRMED");return nil end
  local ok=pcall(function()
   if not f then f=CreateFrame("Frame",nil,parent);cache[key]=f end
   f:Hide()
   assert(live(owner,generation,profile),"STYLE_OWNER_RETIRED");S:Passive(f)
   f:ClearAllPoints()
   f:SetPoint("TOPLEFT",anchor or parent,"TOPLEFT",-1,1);f:SetPoint("BOTTOMRIGHT",anchor or parent,"BOTTOMRIGHT",1,-1)
   local level=self:Public(parent,"GetFrameLevel","number") or 1;f:SetFrameLevel(level+1)
   -- BackdropTemplate immediately divides GetWidth/GetHeight while calculating
   -- UV repeats. A newly anchored/hidden native subtree may have no rect yet.
   -- Four owned anchored edges provide the same one-pixel chrome without ever
   -- reading, inventing or polling that native rectangle.
   f.miragePanelPieces=f.miragePanelPieces or {}
   local function piece(name,layer,source,r,g,b,a)
    local t=f.miragePanelPieces[name]
    if not t then t=f:CreateTexture(nil,layer);f.miragePanelPieces[name]=t end
    t:ClearAllPoints();assert(t:SetTexture(source)~=false,"PANEL_SOURCE_REJECTED")
    local actual,atlas=self:TextureSource(t)
    assert(self:AssetEqual(actual,source) and atlas==false,"PANEL_SOURCE_UNCONFIRMED")
    t:SetVertexColor(r,g,b,a);return t
   end
   local bg=piece("fill","BACKGROUND",self.panel,.035,.045,.055,fill or 0);bg:SetAllPoints(f)
   for _,side in ipairs({"TOP","BOTTOM","LEFT","RIGHT"}) do
    local t=piece(side,"BORDER",self.white,.30,.43,.46,.8)
    if side=="TOP" or side=="BOTTOM" then
     t:SetPoint(side.."LEFT",f,side.."LEFT",0,0);t:SetPoint(side.."RIGHT",f,side.."RIGHT",0,0);t:SetHeight(1)
    else
     t:SetPoint("TOP"..side,f,"TOP"..side,0,0);t:SetPoint("BOTTOM"..side,f,"BOTTOM"..side,0,0);t:SetWidth(1)
    end
   end
   assert(live(owner,generation,profile),"STYLE_OWNER_RETIRED")
   f.miragePanelReady=true
  end)
  if not ok then if f then f.miragePanelReady=nil;self:Call(f,"Hide") end;self:Gap(owner,"panel","PANEL_CREATE_UNCONFIRMED");return nil end
 end
 if not live(owner,generation,profile) then
  if not S:InCombat() then self:Call(f,"Hide") end
  self:Gap(owner,"panel","OWNER_CHANGED");return nil
 end
 local shown,state=L:Public(f,"IsShown","boolean")
 if state~="KNOWN" then self:Gap(owner,"panel","PANEL_SHOWN_UNAVAILABLE");return nil end
 if not shown then
  if S:InCombat() then owner.combatPending=true;self:Gap(owner,"panel","COMBAT_DEFERRED");return nil end
  if not self:Call(f,"Show") or self:Public(f,"IsShown","boolean")~=true then self:Gap(owner,"panel","PANEL_SHOW_UNCONFIRMED");return nil end
 end
 return f
end
function L:HidePanel(owner,parent,key)
 owner=self:Owner(owner,parent)
 local cache=owner.decorations and owner.decorations[parent]
 local frame=cache and cache[key]
 if not frame then return true end
 if not S:Frame(frame,false) then return self:Gap(owner,nil,"DECORATION_UNAVAILABLE") end
 if self:Public(frame,"IsShown","boolean")==false then return true end
 if S:InCombat() and not S:Frame(frame,true) then
  owner.combatPending=true;return self:Gap(owner,nil,"DECORATION_COMBAT_DEFERRED")
 end
 local ok=self:Call(frame,"Hide")
 return ok and self:Public(frame,"IsShown","boolean")==false or self:Gap(owner,nil,"DECORATION_HIDE_UNCONFIRMED")
end
function L:Glyph(owner,button,text)
 if not button then return nil end
 local f=self:Panel(owner,button,button,"glyph",.65);if not f then return end
 if S:InCombat() then return f end
 if not f.label then
  f.label=f:CreateFontString(nil,"OVERLAY");f.label:SetAllPoints();f.label:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",12,"")
  f.label:SetTextColor(1,.72,.30,1)
 end
 f.label:SetText(text)
 for _,get in ipairs({"GetNormalTexture","GetPushedTexture","GetDisabledTexture"}) do
  local texture=self:Public(button,get);if texture then self:DecorativeAlpha(owner,texture,0) end
 end
 self:DecorativeAlpha(owner,self:Field(button,"Icon"),0)
 return f
end
function L:Regions(owner,frame,atlases)
 if not frame or not S:Frame(frame,false) then return end
 local fn=self:Field(frame,"GetRegions");if type(fn)~="function" then return end
 local ok,regions=pcall(function() return {fn(frame)} end)
 if not ok or #regions>48 then self:Gap(owner);return end
 for _,region in ipairs(regions) do
  local atlas=self:Public(region,"GetAtlas","string")
  local action=atlas and atlases[atlas]
  if action=="mask" then self:Texture(owner,region,self.square)
  elseif action=="panel" then self:DecorativeTexture(owner,region,self.panel)
  elseif action=="hide" then self:DecorativeAlpha(owner,region,0) end
 end
end
function L:Hook(owner,o,method,changed)
 owner=self:Owner(owner,o)
 if owner.rootScoped then return end
 if S:InCombat() or not S:Frame(o,false) or type(self:Field(o,method))~="function" or type(hooksecurefunc)~="function" then return end
 local row=owner.hooks[o];if not row then row={};owner.hooks[o]=row end
 -- Register the native callback once. A later lifecycle can replace its scoped
 -- invalidator without stacking another post-hook on the same method.
 if changed then row.callbacks=row.callbacks or {};row.callbacks[method]=changed end
 row.generations=row.generations or {};row.generations[method]=owner.generation
 if row[method] then return end
 local ok=pcall(hooksecurefunc,o,method,function(...)
  local parent=owner.parentOwner
  local writing=owner.painting or owner.writing or (owner.leaseWriteDepth or 0)>0
  local parentWriting=parent and (parent.painting or parent.writing or (parent.leaseWriteDepth or 0)>0)
  if owner.active and not writing and not parentWriting and row.generations[method]==owner.generation
   and (not parent or parent.active and owner.parentGeneration==parent.generation) then
   local callback=row.callbacks and row.callbacks[method]
   if callback then
    local sent=pcall(callback,o,method,...)
    if not sent then
     owner.dirty=true;owner.hookReason="DIRTY_CALLBACK_FAILED"
     if owner.rootRow and parent and parent.MarkRoot then parent:MarkRoot(owner.rootRow,"style") end
    end
   elseif owner.rootRow and parent and parent.MarkRoot then parent:MarkRoot(owner.rootRow,"style")
   else owner.dirty=true end
   -- A pooled row can hold its own receipts while only its provider is ticked.
   -- Wake that current provider without painting inside native dispatch.
   if parent and parent.active and owner.parentGeneration==parent.generation and not owner.rootRow
    and not (callback and (parent.isolatedWindowPack or parent.scopedWindowInvalidation)) then parent.dirty=true end
  end
 end)
 if ok then row[method]=true end
end
function L:List(owner,list,limit,visit)
 if not S:Readable(list) or type(list)~="table" then return self:Gap(owner,"list","LIST_UNAVAILABLE") end
 for i=1,limit do
  local value,state=S:FieldAccess(list,i)
  if state=="ABSENT" then return true end
  if state~="KNOWN" or not S:Frame(value,false) then self:Gap(owner,"list","LIST_ENTRY_UNAVAILABLE") else visit(value,i) end
 end
 local _,state=S:FieldAccess(list,limit+1);if state~="ABSENT" then return self:Gap(owner,"list","LIST_LIMIT_EXCEEDED") end
 return true
end
function L:Pool(owner,pool,limit,visit)
 if not S:Readable(pool) or type(pool)~="table" then return self:Gap(owner,"pool","POOL_UNAVAILABLE") end
 local seen,count={},0
 -- Build 70862 exposes active enumeration only. Never inspect a pool's private
 -- inactive stack or reserve/release frames merely to manufacture decorations.
 local fn=self:Field(pool,"EnumerateActive")
 if type(fn)~="function" then self:Gap(owner,"pool","POOL_ENUMERATOR_UNAVAILABLE");return 0 end
 local ok=pcall(function()
  for item in fn(pool) do
   count=count+1;if count>limit then error("POOL_LIMIT") end
   if not S:Frame(item,false) then self:Gap(owner,"pool","POOL_ITEM_UNAVAILABLE")
   elseif not seen[item] then seen[item]=true;visit(item) end
  end
 end)
 if not ok then self:Gap(owner,"pool",count>limit and "POOL_LIMIT_EXCEEDED" or "POOL_ENUMERATION_FAILED") end
 return count
end
function L:Release(owner)
 -- A native callback can request handback before the current setter returns.
 -- Its last mutation is not committed yet; keep every inverse until then.
 if (owner.leaseWriteDepth or 0)>0 then return false,"STYLE_WRITE_IN_PROGRESS" end
 if owner.releasing then return false,"STYLE_RESTORE_REENTERED" end
 if not owner.records then return true end
 if R.TargetMatched and not R:TargetMatched() and #owner.records>0 then return false,"RESTORE_CLIENT_UNQUALIFIED" end
 if S:InCombat() then return false,"COMBAT_LOCKDOWN" end
 local complete=true
 local generation,profile,records,lookup=owner.generation,M.profile,owner.records,owner.lookup
 owner.releasing=true
 local function releaseCurrent()
  return owner.generation==generation and M.profile==profile and not owner.active and owner.releasing
   and owner.records==records and owner.lookup==lookup
 end
 local function finish(ok,why)
  owner.releasing=nil;owner.leaseDiagnostics=owner.leaseDiagnostics or {}
  owner.leaseDiagnostics.release=ok and "VERIFIED" or "PENDING"
  return ok,why
 end
 for i=#records,1,-1 do
  if not releaseCurrent() then return finish(false,"STYLE_RESTORE_REENTERED") end
  local row=records[i];local current=observe(row.get,row.object,row.key)
  local atlas=current and unprovenAtlas(row,current) and atlasDefaultTuple(row.atlasSourceUnproven)
  if not releaseCurrent() or records[i]~=row or not lookup[row.object] or lookup[row.object][row.key]~=row then
   return finish(false,"STYLE_RESTORE_REENTERED")
  end
  if atlas and rememberAttempt(row,atlas) then row.atlasSourceUnproven=nil end
  if not current or not S:Frame(row.object,false) then failure(owner,row.key,"release","READBACK_UNAVAILABLE");row.pending=true;complete=false
  elseif equal(row.key,current,row.original) then
   owner.lookup[row.object][row.key]=nil;table.remove(owner.records,i)
  elseif not equal(row.key,current,row.written) and not matchesAttempt(row,current) then
   if unprovenAtlas(row,current) then
    failure(owner,row.key,"release","ATLAS_COORDINATES_UNAVAILABLE");row.pending=true;complete=false
   else owner.lookup[row.object][row.key]=nil;table.remove(owner.records,i) end
  elseif not restoreCustody(owner,row) then
   -- A moved/recycled native identity is no longer a legal restore target.
   -- Public original/newer-writer values above can still retire without writes.
   failure(owner,row.key,"release","NATIVE_CUSTODY_CHANGED");row.pending=true;complete=false
  else
   if not releaseCurrent() then return finish(false,"STYLE_RESTORE_REENTERED") end
   local admitted,external=restoreCustody(owner,row)
   if not admitted then
    failure(owner,row.key,"release","NATIVE_CUSTODY_CHANGED");row.pending=true;complete=false
   else
   local function retained()
    return releaseCurrent() and records[i]==row
     and lookup[row.object] and lookup[row.object][row.key]==row
   end
   local function restoreCurrent()
    return retained() and not S:InCombat() and restoreCustody(owner,row)
     and (not owner.rootRow or not external or parentCurrent(owner.rootRow.frame,external)) and retained()
   end
   local function attempt(value,alternate)
    if not restoreCurrent() or not valid(row.key,value) then return false end
    if alternate=="unprovenAtlas" then row.atlasSourceUnproven=value
    elseif alternate then return rememberAttempt(row,value) and restoreCurrent()
    else row.attempt=value end
    return true
   end
   if not restoreCurrent() then return finish(false,"STYLE_RESTORE_PENDING") end
   local ok,result=pcall(row.set,row.object,row.original,restoreCurrent,attempt);local after=observe(row.get,row.object,row.key)
   if not retained() then return finish(false,"STYLE_RESTORE_REENTERED") end
   local custody=restoreCustody(owner,row)
   if owner.rootRow and external then custody=custody and parentCurrent(owner.rootRow.frame,external) end
   if not retained() then return finish(false,"STYLE_RESTORE_REENTERED") end
   if ok and result~=false and equal(row.key,after,row.original) and custody then owner.lookup[row.object][row.key]=nil;table.remove(owner.records,i)
   else
    observation(owner,row.key,row.original,after)
    failure(owner,row.key,"release",(not ok or result==false) and "SETTER_REJECTED" or not after and "READBACK_UNAVAILABLE" or "READBACK_MISMATCH")
    row.pending=true;row.attempt=row.original;if after then row.written=after end;complete=false
   end
   end
  end
 end
 -- Generated glyphs can be the only visible artwork on a native button while
 -- its original regions are alpha-hidden. Keep them until native handback is
 -- verified, including failed or partially successful setter/readback attempts.
 if complete then for _,rows in pairs(owner.decorations or {}) do for _,f in pairs(rows) do
  if not releaseCurrent() then return finish(false,"STYLE_RESTORE_REENTERED") end
  local ok=self:Call(f,"Hide");local shown,state=self:Public(f,"IsShown","boolean")
  if not releaseCurrent() then return finish(false,"STYLE_RESTORE_REENTERED") end
  if not ok or state~="KNOWN" or shown~=false then failure(owner,nil,"release","DECORATION_UNCONFIRMED");complete=false end
 end end end
 if complete then return finish(true) end
 return finish(false,"STYLE_RESTORE_PENDING")
end
L.Pack=pack
