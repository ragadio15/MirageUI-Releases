local _,M=...
local R,S,L,F=M.Rework,M.Safety,M.Rework.CombatLeases,M.Rework.CombatFactory
local D=F:New("meters","DamageMeters",{{name="DamageMeter",id="DamageMeters.native",resize=true,
 layout={x=.36,y=-.32,width=300,height=200,scale=1}}})
R.CombatMeters=D
for _,event in ipairs({"DAMAGE_METER_COMBAT_SESSION_UPDATED","DAMAGE_METER_CURRENT_SESSION_UPDATED","DAMAGE_METER_RESET"}) do D.events[event]=true end
local function panelTexture(self,texture)
 if not texture then return end
 L:DecorativeTexture(self,texture,L.panel)
 -- Preserve native alpha (including disabled/unavailable presentations) and
 -- the engine's class/category colors. This is not a second ranking source.
end
local menuAtlases={["common-dropdown-bg"]="panel",["common-dropdown-c-bg"]="panel"}
function D:ReleaseMenu(button)
 local lease=self.menus and self.menus[button];if not lease then return true end
 lease.active=false;lease.generation=(lease.generation or 0)+1
 local ok,why=L:Release(lease)
 if ok then self.menus[button]=nil else self.menuPending=why or "MENU_RESTORE_PENDING" end
 return ok
end
function D:MenuEntry(lease,frame)
 -- Only the documented native menu-entry fields are styled. Radio/checkbox
 -- presence, selection state, enabled state and responders remain native.
 L:Font(lease,L:Field(frame,"fontString"),12);L:Font(lease,L:Field(frame,"Text"),12)
 L:DecorativeTexture(lease,L:Field(frame,"highlight"),L.beam)
 L:DecorativeTexture(lease,L:Field(frame,"leftTexture1"),L.panel)
 local selected=L:Field(frame,"leftTexture2")
 if selected then L:DecorativeTexture(lease,selected,L.white);L:Color(lease,selected,"menuArrow","GetVertexColor","SetVertexColor",1,.72,.30,1) end
end
function D:MenuChildren(lease,parent)
 local fn=L:Field(parent,"GetChildren");if type(fn)~="function" then return end
 local ok,children=pcall(function() return {fn(parent)} end)
 if not ok or #children>160 then L:Gap(lease);return end
 for _,child in ipairs(children) do
  if not S:Frame(child,false) then L:Gap(lease)
  elseif L:Field(child,"fontString") or L:Field(child,"leftTexture1") or L:Field(child,"highlight") then self:MenuEntry(lease,child) end
 end
end
function D:Menu(button)
 if M.NativeWindowPolicy and M.NativeWindowPolicy:ProviderNative("tooltips") then
  -- Native context menus follow the b35 native-window boundary even though
  -- the invoking meter has custom chrome. Do not activate the older fallback
  -- menu painter merely because the broad tooltip pack was retired.
  if not self:ReleaseMenu(button) then L:Gap(self) end
  self.menuDelegated=nil;return
 end
 self.menuSeen[button]=true;self.menus=self.menus or {}
 local menu=L:Field(button,"menu")
 if not menu or not S:Frame(menu,false) or L:Public(menu,"GetOwnerRegion")~=button then self:ReleaseMenu(button);return end
 -- M03's context-menu provider is the sole painter when selected. A lease
 -- from the retained meter implementation must finish restoring before the
 -- pooled menu is offered; otherwise its original receipt would be stacked.
 if R:Selected("tooltips") and R.TooltipMenus and R.TooltipMenus.OfferMenu then
  if not self:ReleaseMenu(button) then L:Gap(self);return end
  R.TooltipMenus:OfferMenu(menu);self.menuDelegated=true;return
 end
 local lease=self.menus[button]
 if lease and (lease.frame~=menu or not lease.active) then if not self:ReleaseMenu(button) then L:Gap(self);return end;lease=nil end
 if not lease then lease={id=self.id,frame=menu,parentOwner=self};self.menus[button]=lease end
 lease.active=true;lease.parentGeneration=self.generation;L:Begin(lease)
 L:Regions(lease,menu,menuAtlases)
 local nine=L:Field(menu,"NineSlice")
 if nine then for _,key in ipairs({"Center","TopEdge","BottomEdge","LeftEdge","RightEdge","TopLeftCorner","TopRightCorner","BottomLeftCorner","BottomRightCorner"}) do
  L:DecorativeTexture(lease,L:Field(nine,key),L.panel)
 end end
 -- The pinned menu proxy exposes direct entry children. Scroll mode reparents
 -- those same entries under native list holders; inspect only that declared
 -- holder depth, never menu descriptions or combat/session payloads.
 self:MenuChildren(lease,menu)
 local scroll=L:Field(menu,"ScrollBox");local each=scroll and L:Field(scroll,"ForEachFrame")
 if type(each)=="function" then
  local count=0;local ok=pcall(each,scroll,function(holder)
   count=count+1;if count>160 or not S:Frame(holder,false) then error("MENU_SCOPE_UNAVAILABLE") end
   self:MenuChildren(lease,holder)
  end)
  if not ok then L:Gap(lease) end
 end
 self.gaps=self.gaps+lease.gaps
 self.expected=self.expected+lease.expected;self.styled=self.styled+lease.styled
end
-- Native meter values/text/ranking stay entirely in their existing widgets.
-- Refresh callbacks request only the visible subtree whose art can change.
function D:QueuePart(object,kind,session)
 if not self.active or not S:Frame(object,false) then return end
 if self.failedParts and (self.failedParts[object] or 0)>=3 then return end
 self.pendingParts=self.pendingParts or {}
 if session and self.pendingParts[session] then return end
 if kind=="session" then
  for key,part in pairs(self.pendingParts) do if part.session==object then self.pendingParts[key]=nil end end
 end
 if self.pendingParts[object] then self.workCounts.coalesced=self.workCounts.coalesced+1
 else
  self.partSerial=(self.partSerial or 0)+1
  self.pendingParts[object]={kind=kind,session=session,queued=S:Now(),serial=self.partSerial}
 end
end
function D:HookPart(object,method,kind,session)
 L:Hook(self,object,method,function() self:QueuePart(object,kind,session) end)
end
function D:DrainParts(now)
 local object,part
 for candidate,work in pairs(self.pendingParts or {}) do
  if not part or work.serial<part.serial then object,part=candidate,work end
 end
 if not object then return true end
 self.pendingParts[object]=nil
 if L:Public(object,"IsShown","boolean")==false then return true end
 local handlers={entry=self.Entry,scroll=self.Scroll,session=self.SessionWindow,detail=self.SourceWindow,menu=self.RefreshDropdown}
 local fn=handlers[part.kind]
 if not fn then return true end
 local previous=self.paintingSession;self.paintingSession=part.session
 self.painting=true
 local beforeGaps=self.gaps or 0
 local ok=pcall(fn,self,object)
 self.painting=nil;self.paintingSession=previous
 self.partGaps=self.partGaps or setmetatable({},{__mode="k"})
 self.partGaps[object]=(self.gaps or 0)-beforeGaps
 self.workCounts.parts=(self.workCounts.parts or 0)+1
 self.workCounts.maxPartAge=math.max(self.workCounts.maxPartAge or 0,now-part.queued)
 if not ok then
  L:Gap(self,"panel","METER_"..string.upper(part.kind).."_STYLE_FAILED")
  self.failedParts=self.failedParts or setmetatable({},{__mode="k"})
  self.failedParts[object]=(self.failedParts[object] or 0)+1
  self.status="METER_PARTIAL_SUBTREE"
  if R.Result then return R:Result("PARTIAL",self.status,"meters") end
 elseif self.failedParts then self.failedParts[object]=nil
 end
 return true
end
function D:Entry(frame)
 self.entryStyles=self.entryStyles or setmetatable({},{__mode="k"})
 local style=self.entryStyles[frame]
 if not style then style={dirty=true};self.entryStyles[frame]=style end
 if style.generation==self.generation and not style.dirty then
  self.gaps=(self.gaps or 0)+(style.gaps or 0)
  self.styled=(self.styled or 0)+(style.styled or 0);self.expected=(self.expected or 0)+(style.expected or 0)
  return
 end
 local gaps,styled,expected=self.gaps or 0,self.styled or 0,self.expected or 0
 local bar=L:Field(frame,"StatusBar")
 if not bar then L:Gap(self,"barTexture","METER_STATUS_BAR_UNAVAILABLE");return end
 L:Bar(self,bar);panelTexture(self,L:Field(bar,"Background"))
 L:Alpha(self,L:Field(bar,"BackgroundEdge"),0)
 L:Font(self,L:Field(bar,"Name"),11);L:Font(self,L:Field(bar,"Value"),11)
 local picture=L:Path(frame,"Icon","Icon")
 if picture then L:Crop(self,picture);L:Panel(self,L:Field(frame,"Icon"),picture,"icon",0) end
 L:Panel(self,bar,bar,"meterRow",0)
 self.entries=(self.entries or 0)+1
 style.gaps=(self.gaps or 0)-gaps;style.styled=(self.styled or 0)-styled;style.expected=(self.expected or 0)-expected
 style.generation=self.generation;style.dirty=nil
 local session=self.paintingSession
 local function changed()
  style.dirty=true
  self:QueuePart(frame,"entry",session)
 end
 L:Hook(self,bar,"SetStatusBarTexture",changed)
 for _,key in ipairs({"Name","Value"}) do L:Hook(self,L:Field(bar,key),"SetFont",changed) end
 if picture then L:Hook(self,picture,"SetTexCoord",changed) end
end
function D:Scroll(scroll)
 if not scroll then return end
 local fn=L:Field(scroll,"ForEachFrame")
 if type(fn)~="function" then L:Gap(self,"panel","METER_ROW_ENUMERATOR_UNAVAILABLE");return end
 local count=0
 local ok=pcall(fn,scroll,function(frame)
  count=count+1;if count>160 or not S:Frame(frame,false) then error("METER_FRAME_LIST_UNAVAILABLE") end
  -- Deliberately ignore the callback's elementData argument. No amount, name,
  -- spell identity, session identity or ranking enters the addon renderer.
  self:Entry(frame)
 end)
 if not ok then L:Gap(self,"panel","METER_ROW_ENUMERATION_FAILED") end
 self:HookPart(scroll,"FullUpdate","scroll",self.paintingSession);self:HookPart(scroll,"Update","scroll",self.paintingSession)
end
function D:ScrollBar(scroll)
 if not scroll then return end
 for _,path in ipairs({{"Back"},{"Forward"},{"Track","Thumb"}}) do
  local button=L:Path(scroll,unpack(path))
  if button then L:Panel(self,button,button,"scroll",.25) end
 end
 -- MinimalScrollBar's thumb remains the real native drag control.
 local thumb=L:Path(scroll,"Track","Thumb")
 if thumb then
  for _,key in ipairs({"Begin","Middle","End"}) do panelTexture(self,L:Field(thumb,key)) end
 end
end
function D:Dropdown(button,labelKey,glyph)
 if not button then return end
 L:Panel(self,button,button,"selector",.30)
 if labelKey then L:Font(self,L:Field(button,labelKey),12) end
 if glyph then L:Glyph(self,button,glyph) end
 -- Only declared dropdown art is suppressed. Selection text and menu handlers
 -- retain the original native controls, including all session/category entries.
 for _,key in ipairs({"Background","BackgroundLeft","BackgroundRight"}) do panelTexture(self,L:Field(button,key)) end
 local arrow=L:Field(button,"Arrow")
 if arrow then
  if L:Public(arrow,"GetObjectType","string")=="Texture" then
   -- The triangle identifies a menu; its native hit target is the parent.
   L:Color(self,arrow,"menuArrow","GetVertexColor","SetVertexColor",1,.72,.30,1)
  else L:Panel(self,arrow,arrow,"arrow",0) end
 end
 self.dropdownStyles=self.dropdownStyles or setmetatable({},{__mode="k"})
 self.dropdownStyles[button]={label=labelKey,glyph=glyph,session=self.paintingSession}
 self:HookPart(button,"OpenMenu","menu",self.paintingSession);self:HookPart(button,"CloseMenu","menu",self.paintingSession)
 self:Menu(button)
end
function D:RefreshDropdown(button)
 local style=self.dropdownStyles and self.dropdownStyles[button]
 if style then self:Dropdown(button,style.label,style.glyph) end
end
function D:SourceWindow(source)
 if not source then return end
 panelTexture(self,L:Field(source,"Background"));L:Panel(self,source,source,"detail",0)
 self:Scroll(L:Field(source,"ScrollBox"));self:ScrollBar(L:Field(source,"ScrollBar"))
 L:Glyph(self,L:Field(source,"CloseButton"),"x");L:Glyph(self,L:Field(source,"ResizeButton"),"/")
 local session=self.paintingSession
 L:Hook(self,source,"Refresh",function()
  local scroll=L:Field(source,"ScrollBox")
  if scroll then self:QueuePart(scroll,"scroll",session) end
 end)
 for _,name in ipairs({"SetStyle","SetTextScale","OnShow"}) do self:HookPart(source,name,"detail",session) end
 self.details=(self.details or 0)+1
end
function D:SessionWindow(window)
 local previous=self.paintingSession;self.paintingSession=window
 panelTexture(self,L:Field(window,"Header"));L:Panel(self,window,window,"window",0)
 L:Font(self,L:Field(window,"SessionTimer"),12)
 self:Dropdown(L:Field(window,"SessionDropdown"),"SessionName")
 self:Dropdown(L:Field(window,"DamageMeterTypeDropdown"),"TypeName")
 self:Dropdown(L:Field(window,"SettingsDropdown"),nil,"...")
 local minimized=L:Public(window,"IsMinimized","boolean")
 L:Glyph(self,L:Field(window,"MinimizeButton"),minimized and "+" or "-")
 local content=L:Field(window,"MinimizeContainer")
 if content then
  panelTexture(self,L:Field(content,"Background"));L:Font(self,L:Field(content,"NotActive"),12)
  self:Scroll(L:Field(content,"ScrollBox"));self:ScrollBar(L:Field(content,"ScrollBar"))
  local localPlayer=L:Field(content,"LocalPlayerEntry");if localPlayer then self:Entry(localPlayer) end
  L:Glyph(self,L:Field(content,"ResizeButton"),"/")
  self:SourceWindow(L:Field(content,"SourceWindow"))
 else L:Gap(self,"panel","METER_CONTAINER_UNAVAILABLE") end
 -- Refresh normally changes native values only. The source-observed entry
 -- callbacks expose frame identity without us inspecting elementData; known
 -- styled entries do no work, and a newly acquired entry queues just itself.
 for _,name in ipairs({"InitEntry","SetupEntry"}) do
  L:Hook(self,window,name,function(_,_,_,entry)
   if S:Frame(entry,false) then
    local style=self.entryStyles and self.entryStyles[entry]
    if not style or style.generation~=self.generation or style.dirty then self:QueuePart(entry,"entry",window) end
   end
  end)
 end
 for _,name in ipairs({"SetStyle","SetTextScale","SetMinimized","OnShow"}) do self:HookPart(window,name,"session",window) end
 self.sessions=(self.sessions or 0)+1;self.paintingSession=previous
end
function D:Skin(row)
 self.entries,self.sessions,self.details=0,0,0;self.menuSeen={};self.menuPending=nil
 self.partGaps=nil
 local list=L:Field(row.frame,"windowDataList")
 if list and S:Readable(list) and type(list)=="table" then
  for i=1,3 do
   local data,state=S:FieldAccess(list,i)
   if state=="KNOWN" then
    local window=L:Field(data,"sessionWindow")
    if window and S:Frame(window,false) then self:SessionWindow(window)
    elseif window then L:Gap(self,"panel","METER_SESSION_FRAME_UNAVAILABLE") end
   elseif state~="ABSENT" then L:Gap(self,"panel","METER_SESSION_LIST_UNAVAILABLE") end
  end
 else
  -- The pinned source also names each session window. This discovers late
  -- allocation without touching saved combat/session records.
  for i=1,3 do local window=_G["DamageMeterSessionWindow"..i];if window and S:Frame(window,false) then self:SessionWindow(window) end end
 end
 self:HookRoot(row,row.frame,"SetupSessionWindow","style");self:HookRoot(row,row.frame,"RefreshLayout","style")
 for button in pairs(self.menus or {}) do if not self.menuSeen[button] then self:ReleaseMenu(button) end end
end
local baseTick,baseEvent=D.Tick,D.OnEvent
local baseNeeds=D.NeedsRuntimeTick
function D:NeedsRuntimeTick(now,combat)
 if self.active and not combat and next(self.pendingParts or {}) then return true end
 return baseNeeds(self,now,combat)
end
function D:OnEvent(event,...)
 if event=="DAMAGE_METER_COMBAT_SESSION_UPDATED" or event=="DAMAGE_METER_CURRENT_SESSION_UPDATED" or event=="DAMAGE_METER_RESET" then
  -- Source-observed Refresh/Scroll/Setup callbacks carry the actual changed
  -- presentation scope. The data event itself does not justify a full scan.
  return
 end
 if event=="PLAYER_REGEN_ENABLED" then
  -- A cached entry painted during combat can retain a legitimate deferred
  -- decoration. Retry that entry when layout is legal, without treating each
  -- native value/session update as a reason to rescan the entire meter.
  for _,style in pairs(self.entryStyles or {}) do if (style.gaps or 0)>0 then style.dirty=true end end
 end
 return baseEvent(self,event,...)
end
function D:Tick(now)
 local result,why=baseTick(self,now)
 if result==false or not self.active then return result,why end
 local part=self:DrainParts(S:Number(now) and now or S:Now())
 if type(part)=="table" then return part end
 local partial=false
 for _,gaps in pairs(self.partGaps or {}) do if gaps>0 then partial=true;break end end
 if not partial then for _,failed in pairs(self.failedParts or {}) do if failed>0 then partial=true;break end end end
 if partial then
  self.status="METER_PARTIAL_SUBTREE"
  if R.Result then return R:Result("PARTIAL",self.status,"meters") end
 end
 return result,why
end
local baseSuspend=D.Suspend
local baseRetry=D.Retry
function D:Retry()
 self.failedParts=nil;self.partGaps=nil
 for _,style in pairs(self.entryStyles or {}) do style.dirty=true end
 return baseRetry(self)
end
function D:Suspend(reason)
 self.pendingParts=nil
 local ok,why=baseSuspend(self,reason)
 for button in pairs(self.menus or {}) do if not self:ReleaseMenu(button) then ok=false;why=self.menuPending end end
 if not ok then self.status=why or "MENU_RESTORE_PENDING" end
 return ok,why
end
local baseStatus=D.Status
function D:Status()
 return baseStatus(self).."; sessions="..(self.sessions or 0).."; details="..(self.details or 0).."; styled_rows="..(self.entries or 0)
  .."; subtree_updates="..tostring(self.workCounts.parts or 0).."; max_subtree_age="..tostring(self.workCounts.maxPartAge or 0)
  .."; data=NATIVE_UNINSPECTED; availability=GAME_OWNED; menu="..(self.menuPending or "SCOPED_NATIVE_CONTROLS")
end
