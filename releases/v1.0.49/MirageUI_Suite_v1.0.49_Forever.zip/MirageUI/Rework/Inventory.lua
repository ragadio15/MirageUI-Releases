local _,M=...
-- Beta57: a small Mirage shell, with the entire item grid owned by the game.
-- No slot enumeration, item journals, replacement paging, geometry writes,
-- value reads, item callbacks or sorting are part of this provider.
local R,S,L,K=M.Rework,M.Safety,M.Rework.CombatLeases,M.Rework.WindowKit
local specs={{name="ContainerFrameCombinedBags",editable=false,noContext=true,prepareHidden=true},
 {name="BankFrame",editable=false,noContext=true,prepareHidden=true},
 {name="GuildBankFrame",editable=false,noContext=true,prepareHidden=true}}
for i=1,32 do specs[#specs+1]={name="ContainerFrame"..i,editable=false,noContext=true,prepareHidden=true} end
local I=R.CombatFactory:New("inventory","Bags",specs);R.Inventory=I
I.rootScoped=true;I.rootLeaseOwners={};I.leaseObjectOwners=setmetatable({},{__mode="k"})
I.scopedWindowInvalidation=true;I.layoutIDs["Bags.inventory"]=true
I.inventoryWork={valueEvents=0,showBoundaries=0,cachedShows=0,shellPaints=0}
local nativeValues={BAG_UPDATE=true,BAG_UPDATE_DELAYED=true,BAG_UPDATE_COOLDOWN=true,ITEM_LOCK_CHANGED=true,
 BAG_NEW_ITEMS_UPDATED=true,BAG_SLOT_FLAGS_UPDATED=true,INVENTORY_SEARCH_UPDATE=true,PLAYERBANKSLOTS_CHANGED=true,
 PLAYER_ACCOUNT_BANK_TAB_SLOTS_CHANGED=true,GET_ITEM_INFO_RECEIVED=true,PLAYER_MONEY=true,CURSOR_CHANGED=true,
 GUILDBANKBAGSLOTS_CHANGED=true,GUILDBANK_ITEM_LOCK_CHANGED=true,GUILDBANK_UPDATE_MONEY=true,
 GUILDBANK_UPDATE_WITHDRAWMONEY=true,GUILDBANKLOG_UPDATE=true,GUILDBANK_UPDATE_TEXT=true}
for event in pairs(nativeValues) do I.events[event]=true end
for _,event in ipairs({"BAG_OPEN","BAG_CLOSED","BANKFRAME_OPENED","BANKFRAME_CLOSED","BANK_TABS_CHANGED",
 "GUILDBANKFRAME_OPENED","GUILDBANKFRAME_CLOSED","GUILDBANK_UPDATE_TABS","GAME_PAD_ACTIVE_CHANGED",
 "DISPLAY_SIZE_CHANGED","UI_SCALE_CHANGED"}) do I.events[event]=true end
local function selected(self)
 return self.active and R:Qualified() and R:Selected(self.id) and not M.state.safe and not R:NativeEditing()
end
local function current(self,row,generation,profile)
 return self.active and self.generation==generation and M.profile==profile
  and self.roots[row.spec.name]==row and _G[row.spec.name]==row.frame
  and row.leaseOwner and row.leaseOwner.active and row.leaseOwner.parentGeneration==generation
end
-- Fixed decorative aliases from native frame/NineSlice templates. No root
-- child walk is needed and no native Frame alpha or item value is changed.
local chromeFields={"Bg","bg","Background","background","TitleBg","TitleBackground","PortraitFrame","PortraitFrameBg",
 "Center","TopLeftCorner","TopRightCorner","BottomLeftCorner","BottomRightCorner","TopEdge","BottomEdge","LeftEdge","RightEdge"}
function I:ShellMetrics(frame)
 local scale,state=L:Public(frame,"GetEffectiveScale","number")
 local pixel=1
 if state=="KNOWN" and S:Number(scale) and scale>0 and type(GetPhysicalScreenSize)=="function" then
  local okay,_,height=pcall(GetPhysicalScreenSize)
  -- Same physical-to-UI conversion used by the reviewed native PixelUtil.
  -- No native rectangle or item coordinates are needed to paint this shell.
  if okay and S:Number(height) and height>0 then pixel=768/height/scale end
 end
 if not S:Number(pixel) or pixel<=0 then pixel=1 end
 local cut=math.max(4*pixel,math.floor(8/pixel+.5)*pixel)
 return pixel,cut,math.ceil(cut/(2*pixel))*pixel
end
function I:ShellPadding(frame,pixel)
 local cfg=M.profile and M.profile.modules and M.profile.modules.Bags or {}
 local wanted=S:Number(cfg.shellPadding) and math.max(0,math.min(16,cfg.shellPadding)) or 8
 local combined=rawequal(frame,_G.ContainerFrameCombinedBags)
 local bank=rawequal(frame,_G.BankFrame) or rawequal(frame,_G.GuildBankFrame)
 -- Reviewed native bag flow has 8-unit vertical and 11-unit column gaps.
 -- Reserve at least a unit between separate contours without moving a slot.
 local horizontal=math.min(wanted,bank and 16 or combined and 6 or 4)
 local vertical=math.min(wanted,(combined or bank) and 16 or 3)
 local pad={left=horizontal,right=horizontal,top=vertical,bottom=vertical}
 local scale=L:Public(frame,"GetEffectiveScale","number")
 local uiScale=L:Public(UIParent,"GetEffectiveScale","number")
 local width=L:Public(UIParent,"GetWidth","number")
 local height=L:Public(UIParent,"GetHeight","number")
 if S:Number(scale) and scale>0 and S:Number(uiScale) and uiScale>0 and S:Number(width) and S:Number(height) then
  local ratio=scale/uiScale
  local left=L:Public(frame,"GetLeft","number");local right=L:Public(frame,"GetRight","number")
  local top=L:Public(frame,"GetTop","number");local bottom=L:Public(frame,"GetBottom","number")
  if S:Number(left) then pad.left=math.min(pad.left,math.max(0,left-1/ratio)) end
  if S:Number(right) then pad.right=math.min(pad.right,math.max(0,(width-1)/ratio-right)) end
  if S:Number(top) then pad.top=math.min(pad.top,math.max(0,(height-1)/ratio-top)) end
  if S:Number(bottom) then pad.bottom=math.min(pad.bottom,math.max(0,bottom-1/ratio)) end
 end
 for key,value in pairs(pad) do pad[key]=math.floor(value/pixel)*pixel end
 return pad
end
local function samePadding(a,b)
 return a and b and a.left==b.left and a.right==b.right and a.top==b.top and a.bottom==b.bottom
end
function I:ShellPanel(row,owner,retained)
 local frame=row.frame
 if not retained() then return false end
 local pixel,cut,inset=self:ShellMetrics(frame)
 local padding=self:ShellPadding(frame,pixel)
 if not retained() then return false end
 local receipt=row.shellPanelReceipt
 if receipt and receipt.owner==owner and receipt.generation==owner.generation and receipt.profile==M.profile
  and receipt.pixel==pixel and receipt.cut==cut and samePadding(receipt.padding,padding) then return retained() end
 owner.decorations[frame]=owner.decorations[frame] or {}
 local cache=owner.decorations[frame]
 local function write(object,method,...)
  if not retained() then return false end
  local fn=L:Field(object,method)
  if type(fn)~="function" then return L:Gap(owner,"panel","METHOD_UNAVAILABLE") end
  local okay,result=pcall(fn,object,...)
  if not retained() then return false end
  if not okay or result==false then return L:Gap(owner,"panel",okay and "WRITE_REFUSED" or "WRITE_FAILED") end
  return true
 end
 local function region(key,layer,sub)
  if not retained() then return end
  local texture=cache[key]
  if texture then return texture end
  local okay,created=pcall(frame.CreateTexture,frame,nil,layer,nil,sub)
  if not okay or not created then if retained() then L:Gap(owner,"panel","CONSTRUCTION_FAILED") end;return end
  -- Creation can synchronously retire this owner before its returned passive
  -- region is registered. Hide that unclaimed region; never resume its paint.
  if not retained() then
   local hide=L:Field(created,"Hide");if type(hide)=="function" then pcall(hide,created) end
   return
  end
  cache[key]=created;K.owned[created]=true
  return created
 end
 local bg=region("m03Fill","BACKGROUND",-8)
 if not bg or not write(bg,"SetTexture",L.white) or not write(bg,"ClearAllPoints")
  or not write(bg,"SetPoint","TOPLEFT",frame,"TOPLEFT",inset-padding.left,padding.top-inset)
  or not write(bg,"SetPoint","BOTTOMRIGHT",frame,"BOTTOMRIGHT",padding.right-inset,inset-padding.bottom)
  or not write(bg,"SetVertexColor",.025,.032,.038,.94) or not write(bg,"Show") then return false end
 -- An eight-sided, one-physical-pixel contour echoes the action section.
 -- The inset body stays inside the expanded chamfers. Added breathing room is
 -- passive artwork; native root bounds, close buttons and item input remain.
 for _,edge in ipairs({"Top","Bottom","Left","Right"}) do
  local t=region("m03Edge"..edge,"OVERLAY",7)
  if not t or not write(t,"SetTexture",L.white) or not write(t,"SetVertexColor",.79,.55,.27,.64) or not write(t,"ClearAllPoints") then return false end
  if edge=="Top" or edge=="Bottom" then
   local a,b=edge=="Top" and "TOPLEFT" or "BOTTOMLEFT",edge=="Top" and "TOPRIGHT" or "BOTTOMRIGHT"
   local y=edge=="Top" and padding.top or -padding.bottom
   if not write(t,"SetPoint",a,frame,a,cut-padding.left,y) or not write(t,"SetPoint",b,frame,b,padding.right-cut,y) or not write(t,"SetHeight",pixel) then return false end
  else
   local a,b=edge=="Left" and "TOPLEFT" or "TOPRIGHT",edge=="Left" and "BOTTOMLEFT" or "BOTTOMRIGHT"
   local x=edge=="Left" and -padding.left or padding.right
   if not write(t,"SetPoint",a,frame,a,x,padding.top-cut) or not write(t,"SetPoint",b,frame,b,x,cut-padding.bottom) or not write(t,"SetWidth",pixel) then return false end
  end
  if not write(t,"Show") then return false end
 end
 for _,corner in ipairs({{"TOPLEFT",1,-1,1},{"TOPRIGHT",-1,-1,-1},{"BOTTOMLEFT",1,1,-1},{"BOTTOMRIGHT",-1,1,1}}) do
  local t=region("m03Corner"..corner[1],"OVERLAY",7)
  local x=corner[2]*cut/2+(corner[2]==1 and -padding.left or padding.right)
  local y=corner[3]*cut/2+(corner[3]==-1 and padding.top or -padding.bottom)
  if not t or not write(t,"SetTexture",L.white) or not write(t,"SetVertexColor",.91,.64,.30,.72)
   or not write(t,"ClearAllPoints") or not write(t,"SetPoint","CENTER",frame,corner[1],x,y)
   or not write(t,"SetSize",cut*math.sqrt(2),pixel) or not write(t,"SetRotation",corner[4]*math.pi/4)
   or not write(t,"Show") then return false end
 end
 if not retained() then return false end
 row.shellPanelReceipt={owner=owner,generation=owner.generation,profile=M.profile,pixel=pixel,cut=cut,padding=padding}
 return true
end
-- All native contents, including search, sorting, counts, quality borders,
-- cooldowns, quest markers, currency and bank permissions remain native. A
-- fixed root-only chrome pass cannot grow with the number of occupied slots.
function I:Skin(row)
 local generation,profile=self.generation,M.profile
 local owner=self:RootOwner(row);local leaseGeneration=owner.generation
 local function retained()
  if not current(self,row,generation,profile) or owner.generation~=leaseGeneration or S:InCombat() or not selected(self) then return false end
  local parent,state=L:Public(row.frame,"GetParent")
  return current(self,row,generation,profile) and owner.generation==leaseGeneration
   and state=="KNOWN" and parent==owner.rootParent
 end
 if not retained() then return end
 local frame=row.frame
 if not self:ShellPanel(row,owner,retained) then return end
 local function maskChrome(container)
  for _,key in ipairs(chromeFields) do
   if not retained() then return false end
   local texture=L:Field(container,key)
   if texture and S:Frame(texture,false) and not K.owned[texture] and L:Public(texture,"GetObjectType","string")=="Texture"
    and L:Public(texture,"GetParent")==container then
    -- Descendant-only restorative receipts can survive the native fullscreen
    -- bag reparent while preserving that new parent and all interactive input.
    L:DecorativeAlpha(owner,texture,0)
   end
  end
  return retained()
 end
 if not maskChrome(frame) then return end
 local slice=L:Field(frame,"NineSlice")
 if slice and S:Frame(slice,false) and L:Public(slice,"GetParent")==frame then
  if not maskChrome(slice) then return end
 end
 if not retained() then return end
 local title=L:Field(frame,"TitleText") or L:Field(frame,"Title") or L:Path(frame,"TitleContainer","TitleText")
 if title and S:Frame(title,false) and type(L:Field(title,"GetFont"))=="function" then
  -- Font is a descendant-only restorative receipt. Native semantic title
  -- color is retained, including during supported fullscreen reparenting.
  L:Font(owner,title,13*math.max(.65,math.min(2,M.profile.textScale or 1)))
 end
 if not retained() then return end
 row.shellGeneration=generation;row.shellProfile=profile;row.shellLeaseGeneration=leaseGeneration
 self.inventoryWork.shellPaints=self.inventoryWork.shellPaints+1
end
function I:ShellReady(row)
 local owner=row.leaseOwner
 return row.shellGeneration==self.generation and row.shellProfile==M.profile and owner and owner.active
  and owner.parentGeneration==self.generation and row.shellLeaseGeneration==owner.generation and not row.leaseBlocked and not row.leaseRepair
  and not row.paintBlocked and (row.paintGaps or 0)==0
end
function I:PresentRoot(row)
 if not row or self.roots[row.spec.name]~=row or _G[row.spec.name]~=row.frame or not selected(self) then return false end
 self.inventoryWork.showBoundaries=self.inventoryWork.showBoundaries+1
 if self:ShellReady(row) then self.inventoryWork.cachedShows=self.inventoryWork.cachedShows+1;return true end
 if S:InCombat() or self.painting then self:MarkRoot(row,"style");return false end
 if row.leaseBlocked or row.paintBlocked then return false end
 local generation,profile=self.generation,M.profile
 local ok,why=self:PaintRoot(row)
 if not current(self,row,generation,profile) then return false end
 row.dirty=nil;self:RefreshRootHealth(row)
 return ok,why
end
local register=I.Register
function I:Register(spec,frame)
 local row,why=register(self,spec,frame)
 if not row then return row,why end
 local owner=self:RootOwner(row)
 -- Replace the factory's broad invalidation callback under the same existing
 -- post-hook. Native OnShow, click/drag handlers and item pool callbacks stay
 -- untouched. A prewarmed current shell is an O(1) reopen fast path.
 L:Hook(owner,frame,"Show",function() self:PresentRoot(row) end)
 L:Hook(owner,frame,"SetPoint",function()
  if S:InCombat() or not selected(self) then return end
  local receipt=row.shellPanelReceipt
  if receipt and not samePadding(receipt.padding,self:ShellPadding(frame,receipt.pixel)) then
   row.shellPanelReceipt=nil;row.shellGeneration=nil;self:MarkRoot(row,"style")
  end
 end)
 L:Hook(owner,frame,"SetScale",function()
  row.shellPanelReceipt=nil;row.shellGeneration=nil;self:MarkRoot(row,"style")
 end)
 return row
end
function I:SelectSurface()
 local frame=_G.ContainerFrameCombinedBags
 if not S:Frame(frame,false) or L:Public(frame,"IsShown","boolean")~=true then
  local separate=_G.ContainerFrame1
  if S:Frame(separate,false) then frame=separate end
 end
 if not S:Frame(frame,false) then return end
 local surface=self.surface
 if surface and M.surfaces[surface.id]~=surface then self.surface=nil;surface=nil end
 if not surface then
  if M.surfaces["Bags.inventory"] then return false,"SURFACE_OWNER_CONFLICT" end
  surface={id="Bags.inventory",module="Bags",frame=frame,native=true,security="SECURE_PREDECLARED",fallback="VISIBLE",
   editable=false,groups={bags=true,tasks=true},reworkProvider=self,layout={x=.26,y=-.05,width=400,height=400,scale=1}}
  self.surface=surface;self.surfaces[surface.id]=surface;M.CVE:Register(surface)
 end
 surface.frame=frame;surface.disabled=false
 return true
end
function I:ResolveLayout(surface,profile)
 local layout=M.Layout:Get(surface,profile or M.profile)
 local box=M.Elements and M.Elements:Measure(surface.frame)
 if box then
  for _,key in ipairs({"x","y","width","height","scale"}) do if S:Number(box[key]) then layout[key]=box[key] end end
 end
 return M.Layout:Clamp(layout)
end
function I:ApplyLayout() return true,"NATIVE_BAG_FLOW" end
function I:Bounds(id)
 if id~="Bags.inventory" or not self.surface then return end
 local layout=self:ResolveLayout(self.surface)
 return {id=id,frame=self.surface.frame,x=layout.x,y=layout.y,width=layout.width,height=layout.height,
  scale=layout.scale,source="NATIVE_BAG_FLOW"}
end
function I:GetFrame(id) if id=="Bags.inventory" and self.surface then return self.surface.frame end end
local configure=I.Configure
function I:Configure(...)
 local ready,why=configure(self,...)
 if not ready or not self.active then return ready,why end
 local ok,reason=self:SelectSurface()
 if ok==false then return false,reason end
 return ready,why
end
local onEvent=I.OnEvent
function I:OnEvent(event,...)
 if nativeValues[event] then self.inventoryWork.valueEvents=self.inventoryWork.valueEvents+1;return end
 if event=="BAG_CLOSED" or event=="BANKFRAME_CLOSED" or event=="GUILDBANKFRAME_CLOSED" then return end
 if event=="BAG_OPEN" or event=="BANKFRAME_OPENED" or event=="GUILDBANKFRAME_OPENED" or event=="BANK_TABS_CHANGED"
  or event=="GUILDBANK_UPDATE_TABS" or event=="GAME_PAD_ACTIVE_CHANGED" then
  -- Only discover new named roots. Native grid changes do not invalidate art.
  self.discoveryDirty=true;return
 end
 if event=="DISPLAY_SIZE_CHANGED" or event=="UI_SCALE_CHANGED" then
  for _,row in pairs(self.roots) do
   row.shellPanelReceipt=nil;row.shellGeneration=nil;self:MarkRoot(row,"style")
  end
  return
 end
 return onEvent(self,event,...)
end
local needs=I.NeedsRuntimeTick
function I:NeedsRuntimeTick(now,combat)
 if combat then return false end
 return needs(self,now,combat)
end
local tick=I.Tick
function I:Tick(now)
 if S:InCombat() then return end
 local ready,why=tick(self,now)
 if self.active then
  local ok,reason=self:SelectSurface();if ok==false then return false,reason end
 end
 return ready,why
end
local suspend=I.Suspend
function I:Suspend(reason)
 local ok,why=suspend(self,reason)
 if self.surface then self.surface.disabled=true;M.Effects.active[self.surface.id]=nil end
 return ok,why
end
function I:Open()
 if not R:Selected(self.id) or M.state.safe or R:NativeEditing() then return false,"Enable Bags outside Edit Mode first." end
 if S:InCombat() then return false,"Your existing bag keys remain available during combat." end
 if type(OpenAllBags)~="function" then return false,"Bags are unavailable in this game state." end
 if not pcall(OpenAllBags) then return false,"The game could not open the bags." end
 local ready
 if self.active then self.discoveryDirty=true;ready=self:Tick(S:Now()) else ready=self:Configure() end
 return ready,ready and "Bags opened. Search, sort, click, drag or split items normally." or "Inventory presentation needs recovery."
end
function I:Status()
 local partial={}
 for _,spec in ipairs(self.specs) do
  local row=self.roots[spec.name]
  if row and (row.leaseBlocked or row.leaseRepair or row.paintBlocked or (row.paintGaps or 0)>0) then
   partial[#partial+1]=spec.name..":"..(row.leaseReason or row.paintReason or "SHELL_RETRY_PENDING")
  end
 end
 while #partial>8 do table.remove(partial) end
 return (self.status or "NOT_INITIALIZED").."; presentation=MINIMAL_SHELL_NATIVE_GRID; item_paints=0; item_journals=0; grid_scans=0; custom_pages=0"
  .."; placement=NATIVE_BAG_FLOW; combined_choice=NATIVE; input=CLICK_DRAG_SPLIT_USE_SELL_MAIL_TRADE_NATIVE; bank=NATIVE_SESSION_RETAINED"
  .."; value_events_native="..self.inventoryWork.valueEvents.."; shell_paints="..self.inventoryWork.shellPaints
  .."; padding=PASSIVE_NATIVE_FLOW_GUTTERS"
  .."; show_boundaries="..self.inventoryWork.showBoundaries.."; cached_shows="..self.inventoryWork.cachedShows
  .."; incomplete_roots="..(#partial>0 and table.concat(partial,",") or "NONE")
  .."; configure="..self.workCounts.configure.."; root_paints="..self.workCounts.rootPaint.."; native=NOT_RUN"
end
local B=M.modules.Bags
local oldOpen=B.OpenBrowser
function B:OpenBrowser(...)
 if R:Selected("inventory") then return I:Open() end
 return oldOpen(self,...)
end

-- P39-A: optional public utility capture; never mutates native bag controls.
local p39InventoryTick=I.Tick
function I:Tick(...)
    local core=MirageIntelCoreAPI
    local perf,started
    if type(core)=='table' and type(core.GetService)=='function' then
        local ok,service=pcall(core.GetService,'Performance',1)
        if ok and type(service)=='table' and type(service.Begin)=='function' then
            perf=service
            local good,value=pcall(perf.Begin)
            if good and type(value)=='number' then started=value end
        end
    end
    local a,b=p39InventoryTick(self,...)
    if started then pcall(perf.Finish,'mirage.bag_presentation',started) end
    return a,b
end
