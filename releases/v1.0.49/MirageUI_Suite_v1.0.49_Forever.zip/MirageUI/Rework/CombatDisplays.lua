local _,M=...
local R,S,L=M.Rework,M.Safety,M.Rework.CombatLeases
local pack=L.Pack
-- Native content is the supported secure/display channel. This provider replaces
-- accessible presentation, without reading aura identities, durations or ranks.
local commonEvents={ADDON_LOADED=true,PLAYER_ENTERING_WORLD=true,PLAYER_REGEN_ENABLED=true,
 EDIT_MODE_LAYOUTS_UPDATED=true,PLAYER_LEAVING_WORLD=true}
local function eligible(self) return R:Qualified() and R:Selected(self.id) and not M.state.safe end
local function configured(self) return eligible(self) and not R:NativeEditing() end
local function screen()
 if M.Layout and type(M.Layout.Screen)=="function" then return M.Layout:Screen() end
 if M.Managed and type(M.Managed.Viewport)=="function" then return M.Managed:Viewport() end
 return S:Public(UIParent.GetWidth,"number",UIParent),S:Public(UIParent.GetHeight,"number",UIParent)
end
local Factory={}
R.CombatFactory=Factory
local contextGateRoots={BuffFrame=true,DebuffFrame=true,EssentialCooldownViewer=true,
 UtilityCooldownViewer=true,BuffIconCooldownViewer=true,BuffBarCooldownViewer=true,StatusTrackingBarManager=true}
function Factory:AcquireContextGate(row)
 local context=M.ContextualNative
 if not contextGateRoots[row.spec.name] or not context or type(context.AcquireOwned)~="function" then return false end
 local existing=context.rows and context.rows[row.spec.name]
 if row.contextGate and existing and existing.ownedOwner==self and existing.active and not existing.pending
  and not existing.ownerHandback and existing.frame==row.frame then return true end
 local owner=row.leaseOwner
 -- The native-parent snapshot belongs to the property journal. Acquire a gate
 -- before taking that snapshot, or only after its previous receipts are gone.
 if owner and #(owner.records or {})>0 then return false end
 local ready=context:AcquireOwned(self,row.spec.name,row.spec.module or self.module,row.spec.id)
 if ready then
  row.contextGate=true;row.contextUnavailable=nil
  if owner and owner.rootParentTracked then owner.rootParent=L:Public(row.frame,"GetParent") end
 end
 return ready==true
end
function Factory:ReleaseContextGate(row)
 local context=M.ContextualNative
 local retained=context and context.rows and context.rows[row.spec.name]
 if not row.contextGate and not (retained and retained.ownedOwner==self) then return true end
 if not context or type(context.ReleaseOwned)~="function" then return false end
 local ready=context:ReleaseOwned(self,row.spec.name)
 if ready then row.contextGate=nil end
 return ready==true
end
function Factory:OnNativeContextHealthChanged(name)
 local row=self.roots[name]
 local context=M.ContextualNative and M.ContextualNative.rows and M.ContextualNative.rows[name]
 if not row or not context or context.ownedOwner~=self or context.frame~=row.frame then return end
 row.contextUnavailable=true
 if not row.repairLatched and (row.releaseAttempts or 0)<3 then row.repairRequested=true end
 -- This callback only requests the existing bounded out-of-combat handback.
 -- It cannot reparent, restyle or conceal native content during notification.
 self.pendingWork=true
 self:RootState(row,"DEFERRED_HANDOFF","CONTEXT_OWNER_HANDOFF_PENDING")
end
-- Quiet hides are authored outside combat. A predeclared secure callback can
-- reveal only a root that this provider actually hid; it never hides a root,
-- changes native ancestry, or replaces the game's input/content lifecycle.
local revealDriver="[vehicleui] special; [overridebar] special; [possessbar] special; [petbattle] special; [combat] combat; [@target,exists] target; [@focus,exists] target; quiet"
local revealProgram=[=[
self:SetAttribute("mirage-context",newstate)
if self:GetAttribute("mirage-active") and self:GetAttribute("mirage-hidden") then
 local reveal = (newstate == "combat" and self:GetAttribute("mirage-combat"))
  or ((newstate == "target" or newstate == "special") and self:GetAttribute("mirage-target"))
 if reveal then
  local subject = self:GetFrameRef("subject")
  if subject then
   subject:Show()
   self:SetAttribute("mirage-hidden",false)
   self:SetAttribute("mirage-revealed",true)
  end
 end
end
]=]
Factory.contextRevealDriver=revealDriver
Factory.contextRevealProgram=revealProgram
function Factory:ContextReveal(row,hidden)
 if S:InCombat() or not configured(self) or not row or self.roots[row.spec.name]~=row or _G[row.spec.name]~=row.frame then return false end
 if type(RegisterStateDriver)~="function" or type(UnregisterStateDriver)~="function" or not S:Frame(row.frame,false) then return false end
 -- Restricted frame handles permit combat Show only for protected subjects.
 -- Unprotected roots retain native visibility until they have a separately
 -- validated ordinary combat reveal path; creating a controller is not proof.
 if hidden and L:Public(row.frame,"IsProtected","boolean")~=true then return false end
 if row.contextAttemptProfile~=M.profile then row.contextAttempts=0;row.contextAttemptProfile=M.profile end
 if hidden and (row.contextAttempts or 0)>=3 then return false end
 self.contextControllers=self.contextControllers or {}
 local controller=row.contextController or self.contextControllers[row.spec.name]
 local cfg=M:ModuleConfig(row.surface.module) or {}
 local preference=M.ElementRules and M.ElementRules:Preference(row.surface.id,"Combat",M.profile)
 local combatAllowed=cfg.visibility~="Manual" and preference~="HIDE"
 local targetAllowed=cfg.visibility~="Manual"
 if controller and row.contextRegistered and row.contextGuardReady and row.contextArmed==(hidden==true)
  and row.contextProfile==M.profile and row.contextCombat==combatAllowed and row.contextTarget==targetAllowed
  and L:Public(controller,"GetAttribute","boolean","mirage-active")==true
  and L:Public(controller,"GetAttribute","boolean","mirage-hidden")== (hidden==true)
  and L:Public(controller,"GetAttribute","boolean","mirage-revealed")==false then return true end
 row.contextAttempts=(row.contextAttempts or 0)+1
 local ok=pcall(function()
  if not controller then
   controller=CreateFrame("Frame",nil,UIParent,"SecureHandlerStateTemplate")
   self.contextControllers[row.spec.name]=controller
   S:Passive(controller)
  end
  row.contextController=controller
  assert(S:InitializeSecureHandler(controller),"CONTEXT_HANDLER_UNAVAILABLE")
  controller:SetAttribute("mirage-active",false)
  controller:SetAttribute("mirage-hidden",false)
  controller:SetAttribute("mirage-revealed",false)
  controller:SetFrameRef("subject",row.frame)
  controller:SetAttribute("mirage-combat",combatAllowed)
  controller:SetAttribute("mirage-target",targetAllowed)
  controller:SetAttribute("_onstate-miragequiet",revealProgram)
  if not row.contextRegistered then
   -- A previous registration's state is not proof that this registration ran.
   -- Native unregister retains state-*; clear it while inactive so re-enabling
   -- in the same context still produces the native initial state callback.
   controller:SetAttribute("mirage-active",false)
   controller:SetAttribute("state-miragequiet",nil)
   controller:SetAttribute("mirage-context",nil)
   assert(RegisterStateDriver(controller,"miragequiet",revealDriver)~=false,"CONTEXT_REGISTRATION_REFUSED")
   row.contextRegistered=true
  end
  controller:SetAttribute("mirage-active",true)
  controller:SetAttribute("mirage-hidden",hidden==true)
 end)
 if not ok or S:InCombat() or not configured(self) then
  row.contextGuardReady=nil
  if controller and not S:InCombat() then pcall(controller.SetAttribute,controller,"mirage-active",false) end
  return false
 end
 local active,state=L:Public(controller,"GetAttribute","boolean","mirage-active")
 local armed,known=L:Public(controller,"GetAttribute","boolean","mirage-hidden")
 local observed,observedState=L:Public(controller,"GetAttribute","string","mirage-context")
 local validContext=observed=="quiet" or observed=="combat" or observed=="target" or observed=="special"
 row.contextGuardReady=state=="KNOWN" and active==true and known=="KNOWN" and armed==(hidden==true) and observedState=="KNOWN" and validContext
 if row.contextGuardReady then
  row.contextProfile=M.profile;row.contextArmed=hidden==true;row.contextCombat=combatAllowed;row.contextTarget=targetAllowed
  row.contextAttempts=0;row.contextUnavailable=nil
 elseif not S:InCombat() then
  pcall(controller.SetAttribute,controller,"mirage-active",false)
  pcall(controller.SetAttribute,controller,"mirage-hidden",false)
 end
 return row.contextGuardReady==true
end
function Factory:RetireContextHide(row)
 -- A completed one-shot secure Show ends only our visibility receipt. Native
 -- code can hide the root afterwards; neither recovery nor a later target
 -- transition may resurrect it. All artwork and geometry receipts remain.
 local owner=row.leaseOwner or self
 local fields=owner.lookup and owner.lookup[row.frame]
 local receipt=fields and fields.shown
 if receipt and receipt.leaseOwner==owner then
  for i=#(owner.records or {}),1,-1 do
   if owner.records[i]==receipt then table.remove(owner.records,i);break end
  end
  fields.shown=nil
 end
 row.contextHidden=nil;row.contextArmed=false
end
function Factory:ReconcileContextReveal(row)
 local controller=row.contextController
 if not controller then return true end
 if S:InCombat() then return false end
 if L:Public(controller,"GetAttribute","boolean","mirage-revealed")==true then
  self:RetireContextHide(row)
  local ok=pcall(controller.SetAttribute,controller,"mirage-revealed",false)
  return ok and L:Public(controller,"GetAttribute","boolean","mirage-revealed")==false
 end
 return true
end
function Factory:ReleaseContextReveal(row)
 local controller=row.contextController
 if not controller then row.contextAttempts=0;row.contextUnavailable=nil;return true end
 if S:InCombat() then return false end
 if not self:ReconcileContextReveal(row) then return false end
 local ok=pcall(function()
  controller:SetAttribute("mirage-active",false)
  controller:SetAttribute("mirage-hidden",false)
  if row.contextRegistered then
   assert(type(UnregisterStateDriver)=="function","CONTEXT_UNREGISTER_UNAVAILABLE")
   assert(UnregisterStateDriver(controller,"miragequiet")~=false,"CONTEXT_UNREGISTER_REFUSED")
  end
 end)
 local active,state=L:Public(controller,"GetAttribute","boolean","mirage-active")
 if not ok or state~="KNOWN" or active~=false then return false end
 row.contextRegistered=nil;row.contextGuardReady=nil;row.contextProfile=nil;row.contextArmed=nil
 row.contextAttempts=0;row.contextUnavailable=nil
 return true
end
local scopedProviders={auras=true,cooldowns=true,meters=true,casts=true,alerts=true}
function Factory:ModuleEnabled(id,profile)
 local cfg=profile and profile.modules and profile.modules[id] or M:ModuleConfig(id)
 local impl=M.modules and M.modules[id]
 local enabled=cfg and cfg.enabled==true
 local primary={ActionBars="main",UnitFrames="units",PartyRaid="groups",Minimap="minimap",Nameplates="nameplates",Auras="auras",Cooldowns="cooldowns",DamageMeters="meters",Chat="chat",Tooltips="tooltips",QuestTracker="objectives",Bags="inventory",BlizzardSkin="tasks"}
 if primary[id] and type(R.PrimaryChoice)=="function" then enabled=R:PrimaryChoice(primary[id],profile or M.profile) end
 -- These packs retain the user's BlizzardSkin preference but have independent
 -- runtime health. A retired umbrella painter cannot quarantine healthy packs.
 if id=="BlizzardSkin" and (self.id=="maps" or self.id=="tasks" or self.id=="character" or self.id=="system") then return enabled==true end
 return enabled and not (impl and (impl.quarantined or impl.initializationFailed or impl.maintenanceFailed)) or false
end
function Factory:New(id,module,specs)
 local p={id=id,module=module,specs=specs,roots={},surfaces={},nativeRoots={},layoutIDs={},events={},status="NOT_INITIALIZED",workCounts={configure=0,rootPaint=0,probes=0,coalesced=0}}
 if scopedProviders[id] then p.rootScoped=true;p.rootLeaseOwners={};p.leaseObjectOwners=setmetatable({},{__mode="k"}) end
 p.viewportRequired=id=="auras" or id=="cooldowns" or id=="meters" or id=="alerts"
 for e in pairs(commonEvents) do p.events[e]=true end
 for _,s in ipairs(specs) do p.nativeRoots[s.name]=true;if s.id then p.layoutIDs[s.id]=true end end
 for k,v in pairs(self) do if k~="New" then p[k]=v end end
 return p
end
function Factory:Initialize()
 if not configured(self) then return false,"NOT_SELECTED" end
 if S:InCombat() then return false,"SETUP_COMBAT_DEFERRED" end
 L:Begin(self);return true
end
function Factory:RootOwner(row)
 if not self.rootScoped then return self end
 local owner=row.leaseOwner
 if not owner then
  owner={id=self.id,parentOwner=self,accountingOwner=self,rootRow=row}
  row.leaseOwner=owner;self.rootLeaseOwners[row.spec.name]=owner
 end
 if not owner.records or not owner.active and not row.leaseBlocked then
  L:Begin(owner);owner.lookup=self.lookup;owner.active=true
  if type(L:Field(row.frame,"GetParent"))=="function" then
   local parent,state=L:Public(row.frame,"GetParent")
   owner.rootParentTracked=true;owner.rootParent=parent
   if state~="KNOWN" then owner.active=false;row.leaseBlocked=true;self:RootState(row,"PARTIAL","NATIVE_CUSTODY_UNAVAILABLE") end
  end
 end
 if owner.active then owner.parentGeneration=self.generation end
 self.leaseObjectOwners[row.frame]=owner
 return owner
end
function Factory:RootState(row,kind,why)
 row.leaseState=kind;row.leaseReason=why
 if R.RecordSurface then R:RecordSurface(self,row.spec.id or row.spec.name,kind,why) end
end
function Factory:RefreshRootHealth(row)
 if not self.rootScoped or row.leaseBlocked then return end
 local kind,why="READY","ROOT_PRESENTATION_READY"
 if row.leaseRepair then kind,why="DEFERRED_HANDOFF","STYLE_RESTORE_PENDING"
 elseif row.contextUnavailable then kind,why="PARTIAL","CONTEXT_GATE_UNAVAILABLE"
 elseif row.paintBlocked or (row.paintGaps or 0)>0 then kind,why="PARTIAL",row.paintReason or "ROOT_PRESENTATION_PARTIAL"
 elseif row.surface and row.surface.layoutPending then kind,why="PARTIAL","ROOT_LAYOUT_PENDING"
 elseif row.stylePending or self.boundedItems and row.dirty and next(row.dirty) then kind,why="WAITING","PRESENTATION_WORK_QUEUED" end
 -- Configure is only an initial observation. Native pooled updates can fail
 -- later or recover in place, so per-root health must follow current evidence.
 if row.leaseState~=kind or row.leaseReason~=why then self:RootState(row,kind,why) end
end
function Factory:DetachRoot(row)
 local surface=row.surface
 if surface then
  if M.surfaces[surface.id]==surface then
   M.Policy:Release(surface);M.surfaces[surface.id]=nil;M.Effects.active[surface.id]=nil
  end
  self.surfaces[surface.id]=nil
 end
 self.roots[row.spec.name]=nil;self.rootLeaseOwners[row.spec.name]=nil
end
function Factory:ReleaseRoot(row,remove,unbounded)
 row.itemWork=nil;row.stylePending=nil
 if not self:ReleaseContextReveal(row) then
  row.leaseBlocked=true;self:RootState(row,"DEFERRED_HANDOFF","CONTEXT_RELEASE_PENDING")
  return false,"CONTEXT_RELEASE_PENDING"
 end
 local owner=row.leaseOwner
 if not unbounded and (row.releaseAttempts or 0)>=3 then
  row.leaseBlocked=true;row.leaseRepair=nil;row.repairRequested=nil;row.repairLatched=true
  self:RootState(row,"DEFERRED_HANDOFF","ROOT_HANDOFF_PENDING")
  return false,"ROOT_HANDOFF_PENDING"
 end
 row.releaseAttempts=(row.releaseAttempts or 0)+1
 if not owner then
  if not self:ReleaseContextGate(row) then
   row.leaseBlocked=true;self:RootState(row,"DEFERRED_HANDOFF","CONTEXT_RELEASE_PENDING")
   return false,"CONTEXT_RELEASE_PENDING"
  end
  row.leaseBlocked=nil;row.leaseRepair=nil;row.repairRequested=nil;row.releaseAttempts=0
  if remove then self:DetachRoot(row) end;return true
 end
 if owner.active then owner.active=false;owner.generation=(owner.generation or 0)+1 end
 local ok,why=L:Release(owner)
 row.leaseRepair=nil;row.repairRequested=nil
 if not ok then
  row.leaseBlocked=true;if row.surface then row.surface.disabled=true;M.Effects.active[row.surface.id]=nil end
  self:RootState(row,"DEFERRED_HANDOFF",why or "ROOT_HANDOFF_PENDING")
  return false,why
 end
 -- Restore property/geometry receipts while their recorded native parent is
 -- still the gate. Detaching the gate first would invalidate that custody.
 if not self:ReleaseContextGate(row) then
  row.leaseBlocked=true;self:RootState(row,"DEFERRED_HANDOFF","CONTEXT_RELEASE_PENDING")
  return false,"CONTEXT_RELEASE_PENDING"
 end
 row.leaseBlocked=nil;row.contextHidden=nil;row.releaseAttempts=0;row.dirty=nil
 row.items=nil;row.paintGaps=0;row.paintExpected=0;row.paintStyled=0
 self:RootState(row,"READY","ROOT_HANDOFF_VERIFIED")
 if remove then self:DetachRoot(row) end
 return true
end
function Factory:Register(spec,frame)
 local row=self.roots[spec.name]
 if row and row.frame~=frame then return nil,"ROOT_REPLACED" end
 if not row then
  row={frame=frame,spec=spec,origin=M.Elements and M.Elements:Measure(frame)};self.roots[spec.name]=row
 end
 if row.leaseBlocked then return nil,"ROOT_HANDOFF_PENDING" end
 local gateReady=self:AcquireContextGate(row)
 local retained=M.ContextualNative and M.ContextualNative.rows and M.ContextualNative.rows[spec.name]
 if not gateReady and retained and retained.ownedOwner==self and (retained.pending or retained.attempted) then
  row.leaseBlocked=true;row.leaseRepair=true
  self:RootState(row,"DEFERRED_HANDOFF","CONTEXT_ACQUIRE_PENDING")
  return nil,"CONTEXT_ACQUIRE_PENDING"
 end
 local owner=self:RootOwner(row)
 if spec.id and not row.surface then
  local old=M.surfaces[spec.id]
  if old and old.reworkProvider~=self then return nil,"SURFACE_OWNER_CONFLICT" end
  local surface=old or {id=spec.id,layoutID=spec.id,module=spec.module or self.module,frame=frame,
   native=true,security="SECURE_PREDECLARED",fallback="VISIBLE",editable=spec.editable~=false,
   groups=spec.groups or {combat=true},layout=spec.layout or {x=0,y=0,width=280,height=50,scale=1},reworkProvider=self}
  surface.frame=frame;surface.disabled=false;row.surface=surface;self.surfaces[spec.id]=surface
  if not old then M.CVE:Register(surface) end
 end
 if row.surface then row.surface.disabled=false end
 for _,method in ipairs({"Show","SetPoint","SetScale"}) do
  local kind=method=="Show" and "style" or "geometry"
  L:Hook(owner,frame,method,function() self:MarkRoot(row,kind) end)
 end
 return row
end
function Factory:ResolveLayout(surface,profile)
 profile=profile or M.profile
 local l=M.Layout:Get(surface,profile)
 local row;for _,v in pairs(self.roots) do if v.surface==surface then row=v;break end end
 local spec=row and row.spec
 if row and not spec.resize then
  local width=L:Public(row.frame,"GetWidth","number");local height=L:Public(row.frame,"GetHeight","number")
  if width and width>0 then l.width=width end;if height and height>0 then l.height=height end
 end
 if profile.layouts and profile.layouts[surface.id] then return M.Layout:Clamp(l) end
 local cfg=profile.modules[surface.module] or {}
 local scale=cfg.scale or 1
 if surface.id=="Auras.BuffFrame" or surface.id=="Auras.DebuffFrame" then scale=(cfg.nativeScale or 100)/100 end
 l.scale=scale
 local origin=row and row.origin
 if origin then l.x,l.y=origin.x,origin.y end
 if profile.managed and profile.autoLayout and spec and M.AdaptiveLayout then
  local w,h=M.AdaptiveLayout:Screen()
  if w and h then
   local hud=profile.modules.UnderCharacterHUD
   local central=profile.modules.Cooldowns.centralGroup==true
   local reference=profile.modules.UnitFrames.referenceLayout
   local signature=M.AdaptiveLayout:Signature(w,h,hud,central,reference)
   if self.planProfile~=profile or self.planSignature~=signature then
    self.plan=M.AdaptiveLayout:Plan(w,h,hud,central,reference);self.planProfile=profile;self.planSignature=signature
   end
   local geometry=self.plan and self.plan.native[spec.name]
   if geometry then
    l.x,l.y=geometry.x/w,geometry.y/h
    if spec.resize then
     l.width=(geometry.width or geometry.maxW)/scale
     l.height=(geometry.height or geometry.maxH)/scale+(spec.footerHeight or 0)
     l.y=l.y-(spec.footerHeight or 0)*scale/(2*h)
    end
   end
  end
 end
 return M.Layout:Clamp(l)
end
function Factory:ApplyLayout(surface)
 if not self.active or not configured(self) or not surface or surface.reworkProvider~=self then return false,"NOT_SELECTED" end
 if S:InCombat() then surface.layoutPending=true;self.status="LAYOUT_COMBAT_DEFERRED";return false,self.status end
 local row
 for _,v in pairs(self.roots) do if v.surface==surface then row=v;break end end
 if not row then return false,"SURFACE_UNAVAILABLE" end
 if row.leaseBlocked then return false,"ROOT_HANDOFF_PENDING" end
 local w,h=screen()
 if not w or not h then
  surface.layoutPending=true;row.awaitingViewport=true;row.viewportLayoutReady=nil
  return false,"VIEWPORT_PENDING"
 end
 local owner=self:RootOwner(row)
 local spec,f=row.spec,row.frame
 if spec.editable==false then return true end
 local l=self:ResolveLayout(surface);local relative=UIParent
 local linked=l.anchorTo and M.surfaces[l.anchorTo]
 if linked and linked~=surface and S:Frame(linked.frame,false) then relative=linked.frame end
 local scale=l.scale or 1;local divisor=M.profile.managed and scale or 1
 local ok=L:Points(owner,f,pack("CENTER",relative,"CENTER",l.x*w/divisor,l.y*h/divisor+(spec.footerHeight or 0)/2))
 ok=L:Scalar(owner,f,"scale","GetScale","SetScale",scale) and ok
 -- The engine owns the native aura/cooldown flow. Its real bounds remain the
 -- editor evidence; arbitrary envelopes do not silently change native counts.
 if spec.resize then
  local desired=pack(l.width,math.max(6,l.height-(spec.footerHeight or 0)))
  ok=L:Write(owner,f,"dimensions",function(x) return pack(x:GetWidth(true),x:GetHeight(true)) end,function(x,v)
   if R.NativeSize then
    assert(R.NativeSize(x,v[1],v[2]),"NATIVE_SIZE_UNCONFIRMED")
   else x:SetSize(v[1],v[2]) end
  end,desired) and ok
 end
 surface.layoutPending=not ok or nil;row.layout=l
 if row.awaitingViewport then
  row.viewportLayoutReady=ok or nil
  -- Once a real write was possible, a refused property is ordinary local
  -- recovery debt; later viewport publications must not reset its budget.
  if not ok then row.awaitingViewport=nil end
 end
 return ok,ok and "LAYOUT_APPLIED" or "LAYOUT_PENDING"
end
function Factory:OnViewportReady()
 local pending=false
 for _,row in pairs(self.roots) do
  if row.awaitingViewport and row.frame==_G[row.spec.name] and not row.leaseBlocked and not row.leaseRepair
   and not row.repairLatched and not row.paintBlocked then
   -- Shared ApplyAll may already have placed the root. Its native child
   -- painter still needs one bounded pass before readiness can be claimed.
   self:MarkRoot(row,row.viewportLayoutReady and "style" or "geometry");pending=true
  end
 end
 return pending
end
function Factory:Visibility(row)
 if row.leaseBlocked then return true end
 if row.spec.safety or row.spec.noContext then return true end
 local surface=row.surface;if not surface then return true end
 local wanted=surface.desired~="HIDDEN" and not surface.disabled
 row.contextWanted=wanted
 if row.contextGate then
  -- The shared secure parent owns contextual visibility. The native aura or
  -- viewer keeps its original own shown state, private children and handlers.
  local context=M.ContextualNative
  local gate=context and context.rows and context.rows[row.spec.name]
  if gate and gate.active and not gate.pending and not gate.ownerHandback and gate.ownedOwner==self and gate.frame==row.frame then
   row.contextUnavailable=nil;return true
  end
  row.contextUnavailable=true;self:RootState(row,"PARTIAL","CONTEXT_GATE_UNAVAILABLE")
  return false
 end
 if S:InCombat() then
  if (row.contextHidden==true)~=(not wanted) then self.contextDeferred=true end
  return true
 end
 local owner=self:RootOwner(row)
 if not self:ReconcileContextReveal(row) then return L:Gap(owner,"shown","CONTEXT_RELEASE_PENDING") end
 local function guard(hidden)
  if self:ContextReveal(row,hidden) then return true end
  row.contextUnavailable=true;self:RootState(row,"PARTIAL","CONTEXT_REVEAL_UNAVAILABLE")
  return L:Gap(owner,"shown","CONTEXT_REVEAL_UNAVAILABLE")
 end
 if not wanted then
  local shown,state=L:Public(row.frame,"IsShown","boolean")
  if state~="KNOWN" then return L:Gap(owner) end
  if row.contextHidden and not guard(true) then return false end
  if shown then
   -- Do not hide essential content without a working secure reveal path. In
   -- particular an OOC Hide must not leave auras/cooldowns invisible for an
   -- entire fight because insecure setters are correctly deferred in combat.
   if not guard(true) then return false end
   local context=L:Public(row.contextController,"GetAttribute","string","mirage-context")
   local combat=L:Public(row.contextController,"GetAttribute","boolean","mirage-combat")
   local target=L:Public(row.contextController,"GetAttribute","boolean","mirage-target")
   local known=context=="quiet" or context=="combat" or context=="target" or context=="special"
   if not known or context=="combat" and combat or (context=="target" or context=="special") and target then
    return guard(false)
   end
   if not L:Scalar(owner,row.frame,"shown","IsShown","SetShown",false) then
    if L:Public(row.frame,"IsShown","boolean")==true then
     self:RetireContextHide(row);guard(false)
    end
    return false
   end
   row.contextHidden=true
  end
 elseif row.contextHidden then
  -- A contextual reveal synchronizes retained presentation before restoring
  -- native visibility. Hidden aura/cooldown art otherwise stays dormant.
  if row.dirty and (row.dirty.style or row.dirty.content) and not row.paintBlocked then
   self:PaintRoot(row);row.dirty.style=nil;row.dirty.content=nil
  end
  if not L:Scalar(owner,row.frame,"shown","IsShown","SetShown",true) then return false end
  if not guard(false) then return false end
  row.contextHidden=nil
 end
 local cfg=M:ModuleConfig(row.surface.module)
 if cfg and cfg.alpha and wanted then L:Alpha(owner,row.frame,cfg.alpha) end
 return true
end
-- Native updates invalidate the smallest known presentation scope. A heartbeat
-- compares root identity only; it never calls Configure or walks pooled rows in
-- an unchanged scene. Window packs with their own journals keep their own scan.
function Factory:MarkRoot(row,kind)
 if not row or not row.spec or self.roots[row.spec.name]~=row then return false end
 kind=kind or "style"
 if row.leaseBlocked then
  if not row.repairLatched and (row.releaseAttempts or 0)<3 then row.repairRequested=true end
  return true
 end
 -- Successful items remain cached. A previously unavailable required field
 -- needs one fresh attempt when native content/layout signals change; keeping
 -- its old failed cache forever strands an otherwise recovered aura subtree.
 for _,state in pairs(row.items or {}) do
  if (state.gaps or 0)>0 then state.dirty=true end
 end
 row.dirty=row.dirty or {}
 if row.dirty[kind] then self.workCounts.coalesced=self.workCounts.coalesced+1 else row.dirty[kind]=true end
 self.rootWorkPending=true
 return true
end
function Factory:HookRoot(row,object,method,kind)
 L:Hook(self:RootOwner(row),object,method,function() self:MarkRoot(row,kind or "style") end)
end
function Factory:StyleItem(row,item,paint)
 if not S:Frame(item,false) then return L:Gap(self,"item","ITEM_UNAVAILABLE") end
 row.items=row.items or setmetatable({},{__mode="k"})
 local state=row.items[item]
 if not state then state={dirty=true};row.items[item]=state end
 local repaint=state.dirty==true
 if repaint then
  local gaps,styled,expected=self.gaps or 0,self.styled or 0,self.expected or 0
  paint(item)
  state.gaps=(self.gaps or 0)-gaps;state.styled=(self.styled or 0)-styled;state.expected=(self.expected or 0)-expected
  state.dirty=nil
 else
  -- Cached presentation remains part of honest coverage. Skipping its setters
  -- must not erase a retained unavailable property from the next root report.
  self.gaps=(self.gaps or 0)+(state.gaps or 0)
  self.styled=(self.styled or 0)+(state.styled or 0)
  self.expected=(self.expected or 0)+(state.expected or 0)
 end
 if repaint or state.hooksPending and not S:InCombat() then
  local function changed() state.dirty=true;self:MarkRoot(row,"style") end
  if S:InCombat() then state.hooksPending=true;self.combatPending=true
  else
   state.hooksPending=nil
   -- Watch only presentation properties that Mirage owns. Duration/value/text
   -- changes stay inside native widgets and never invalidate whole icon art.
   local paths={{"Icon"},{"Icon","Icon"},{"Duration"},{"Count"},{"Symbol"},
    {"ChargeCount","Current"},{"Applications","Applications"},{"Icon","Applications"},
    {"Bar","Name"},{"Bar","Duration"},{"Bar"},{"DebuffBorder"},{"TempEnchantBorder"},{"DebuffBorder","Texture"}}
   for _,path in ipairs(paths) do
    local object=L:Path(item,unpack(path))
    if object then
     for _,method in ipairs({"SetFont","SetTexCoord","SetStatusBarTexture","SetTexture","SetAtlas"}) do L:Hook(self,object,method,changed) end
    end
   end
  end
 end
end
function Factory:ProbeRoots()
 self.workCounts.probes=self.workCounts.probes+1
 self.observedRoots=self.observedRoots or {}
 local changed=false
 for _,spec in ipairs(self.specs) do
  local frame=_G[spec.name] or false
  if self.observedRoots[spec.name]~=frame then changed=true end
  self.observedRoots[spec.name]=frame
 end
 return changed
end
function Factory:PaintRoot(row)
 if row.leaseBlocked then return false,"ROOT_HANDOFF_PENDING" end
 if row.awaitingViewport and not row.viewportLayoutReady then return false,"VIEWPORT_PENDING" end
 local beforeGaps,beforeStyled,beforeExpected=self.gaps or 0,self.styled or 0,self.expected or 0
 local priorScope,priorPainting=self.leaseScope,self.painting
 local continuing=(self.cooperativeStyle or self.boundedItems) and row.stylePending
 if self.cooperativeStyle and not continuing then row.paintToken={} end
 local priorRoot,priorToken=self.paintingRoot,self.paintingToken
 self.paintingRoot=row;self.paintingToken=row.paintToken
 if self.rootScoped then self.leaseScope=self:RootOwner(row) end
 self.painting=true
 local ok,why=pcall(self.Skin,self,row)
 self.painting=priorPainting;self.leaseScope=priorScope
 self.paintingRoot=priorRoot;self.paintingToken=priorToken
 self.workCounts.rootPaint=self.workCounts.rootPaint+1
 row.awaitingViewport=nil;row.viewportLayoutReady=nil
 row.paintGaps=(continuing and row.paintGaps or 0)+(self.gaps or 0)-beforeGaps
 row.paintStyled=(continuing and row.paintStyled or 0)+(self.styled or 0)-beforeStyled
 row.paintExpected=(continuing and row.paintExpected or 0)+(self.expected or 0)-beforeExpected
 if self.cooperativeStyle or self.boundedItems then
  row.stylePending=row.itemWork~=nil or nil
  for _,job in pairs(self.windowJobs or {}) do if job.rootRow==row then row.stylePending=true;break end end
 end
 if not ok then
  row.itemWork=nil;row.stylePending=nil
  row.paintFaults=(row.paintFaults or 0)+1;row.paintReason="ROOT_STYLE_EXCEPTION";row.paintGaps=row.paintGaps+1;self.gaps=beforeGaps+row.paintGaps
  if row.paintFaults>=3 then row.paintBlocked=true end
  self.status="MIRAGE_NATIVE_PRESENTATION_PARTIAL"
  return false,"ROOT_STYLE_EXCEPTION"
 end
 row.paintReason=nil;row.paintFaults=0
 return true
end
function Factory:RefreshDirtyRoots(now)
 self.rootWorkPending=nil
 if self.cooperativeStyle then self.styleBudget={remaining=48,steps=0} end
 local total=#self.specs
 local cursor=self.rootCursor or 0
 for offset=1,total do
  local index=(cursor+offset-1)%total+1
  local spec=self.specs[index]
  local row=self.roots[spec.name]
  if row and not row.leaseBlocked then
   local before=self.workCounts.rootPaint
   self:Visibility(row)
   if self.workCounts.rootPaint~=before then self.rootCursor=index;break end
   local dirty=row.dirty
   if dirty and next(dirty) or row.stylePending then
    if row.paintBlocked then row.dirty={}
    elseif not row.spec.roleOnly and not row.spec.prepareHidden and not self:RootVisible(row) then -- retain dormant art until native OnShow
    elseif self.cooperativeStyle and S:InCombat() or dirty and dirty.geometry and S:InCombat() then
    else
     -- One root transaction per provider turn. Shared scheduling budgets the
     -- remaining providers; multiple aura/cooldown roots cannot burst together.
     if dirty and dirty.geometry and row.surface then
      -- Geometry precedes both a new child paint and continuation of a bounded
      -- painter; a resized native parent cannot leave one stale full-width pass.
      self.painting=true;self:ApplyLayout(row.surface);self.painting=nil
     end
     if row.stylePending then
      -- Continue the same bounded tree/journal generation. New native events
      -- remain in row.dirty for one subsequent pass instead of restarting the
      -- unfinished traversal at its first node every heartbeat.
      self:PaintRoot(row)
     else
      row.dirty={}
      if dirty.style or dirty.content or dirty.role or dirty.geometry then self:PaintRoot(row) end
     end
     self.rootCursor=index
     break
    end
   end
  end
 end
 local gaps,styled,expected=0,0,0
 local blocked
 for _,row in pairs(self.roots) do
  gaps=gaps+(row.paintGaps or 0);styled=styled+(row.paintStyled or 0);expected=expected+(row.paintExpected or 0)
  if row.leaseBlocked or row.leaseRepair or row.contextUnavailable or row.surface and row.surface.layoutPending then
   gaps=gaps+1;blocked=blocked or row.spec.id or row.spec.name
  end
  self:RefreshRootHealth(row)
  if not row.leaseBlocked and not row.paintBlocked and (row.spec.roleOnly or row.spec.prepareHidden or self:RootVisible(row))
   and (row.stylePending or row.dirty and next(row.dirty)) then self.rootWorkPending=true end
 end
 self.styleBudget=nil
 self.gaps,self.styled,self.expected=gaps,styled,expected
 self.status=self.found==0 and not blocked and "WAITING_FOR_NATIVE_CONTENT" or gaps>0 and "MIRAGE_NATIVE_PRESENTATION_PARTIAL" or "MIRAGE_NATIVE_PRESENTATION_OWNED"
 if self.contextDeferred then self.status="VISIBILITY_COMBAT_DEFERRED" end
 if (self.cooperativeStyle or self.boundedItems) and self.rootWorkPending then self.status="PRESENTATION_WORK_QUEUED" end
 if self.QueueContinuation and self.rootWorkPending then self:QueueContinuation() end
 if R.Result and gaps>0 then return R:Result("PARTIAL",self.status,blocked or self.id) end
 return true
end
function Factory:RootVisible(row)
 local value,state=L:Public(row.frame,"IsVisible","boolean")
 if state=="KNOWN" then return value end
 return L:Public(row.frame,"IsShown","boolean")~=false
end
function Factory:NeedsRuntimeTick(now,combat)
 if not self.active then return false end
 if not configured(self) then return true end
 -- A root identity probe remains available even when every closed window is
 -- dormant. Cosmetic failure/hidden-content debt alone never wakes a hot loop.
 if self.discoveryDirty or now>=(self.nextRootProbe or 0) then return true end
 if combat then
  if self.cooperativeStyle then return false end
 else
  if self.topologyDirty or self.dirty or self.contextDeferred then return true end
 end
 for _,row in pairs(self.roots) do
  if not combat and (row.leaseRepair or row.repairRequested) and not row.repairLatched then return true end
  if not row.leaseBlocked then
   if row.surface and not row.spec.safety and not row.spec.noContext then
    local wanted=row.surface.desired~="HIDDEN" and not row.surface.disabled
    if wanted~=row.contextWanted then return true end
    if not combat and row.contextController and L:Public(row.contextController,"GetAttribute","boolean","mirage-revealed")==true then return true end
   end
   local d=row.dirty
   if not row.paintBlocked and (row.spec.roleOnly or row.spec.prepareHidden or self:RootVisible(row)) and (row.stylePending or d and next(d))
    and (not combat or not self.cooperativeStyle and not (d and d.geometry)) then return true end
  end
 end
 return false
end
function Factory:Retry()
 if M.ContextualNative and type(M.ContextualNative.RetryOwned)=="function" then M.ContextualNative:RetryOwned(self) end
 for _,row in pairs(self.roots) do
  local contextRepair=row.contextUnavailable and contextGateRoots[row.spec.name]
  row.contextAttempts=0
  if row.contextUnavailable and not S:InCombat() then self:ReleaseContextReveal(row) end
  row.paintBlocked=nil;row.paintFaults=0
  row.releaseAttempts=0;row.repairAttempts=0;row.repairLatched=nil
  -- Re-enter parent custody only after the existing property journal has
  -- handed back. A failed-but-cleaned gate can otherwise keep its acquisition
  -- limit while a successful fallback paint prevents another gate attempt.
  if row.leaseBlocked or row.leaseRepair or contextRepair then row.repairRequested=true end
  for _,item in pairs(row.items or {}) do item.dirty=true end
  self:MarkRoot(row,"style")
 end
 self.discoveryDirty=true
 return true
end
function Factory:RepairRoot(row,remove)
 if S:InCombat() then row.repairRequested=true;return false,"COMBAT_LOCKDOWN" end
 if row.repairLatched then return false,"ROOT_RETRY_REQUIRED" end
 row.repairAttempts=(row.repairAttempts or 0)+1
 local ok,why=self:ReleaseRoot(row,remove)
 if not ok then return false,why end
 if remove then return true end
 if row.repairAttempts>=3 then
  -- A property that repeatedly fails to acquire must stop at its own native
  -- fallback. Successful cleanup is not permission for an endless repaint loop.
  row.repairLatched=true;row.leaseBlocked=true
  if row.surface then row.surface.disabled=true;M.Effects.active[row.surface.id]=nil end
  self:RootState(row,"PARTIAL","ROOT_RETRY_REQUIRED")
  return false,"ROOT_RETRY_REQUIRED"
 end
 self:RootOwner(row)
 return true
end
function Factory:ScanScoped()
 local generation,profile=self.generation,M.profile
 local function current() return self.active and self.generation==generation and M.profile==profile and configured(self) end
 self.found=0
 for _,spec in ipairs(self.specs) do
  if not current() then return false,"STYLE_DISPATCH_SUPERSEDED" end
  local frame=_G[spec.name]
  local permitted=not spec.module or self:ModuleEnabled(spec.module)
  local previous=self.roots[spec.name]
  if permitted and frame and S:Frame(frame,false) and not (previous and previous.leaseBlocked) then
   local row,why=self:Register(spec,frame)
   if row then
    self.found=self.found+1
    if row.items then for _,item in pairs(row.items) do item.dirty=true end end
    if row.surface and row.surface.editable then self.painting=true;self:ApplyLayout(row.surface);self.painting=nil end
    if self.boundedItems then
     row.itemWork=nil;row.stylePending=nil;row.dirty={style=true};self.rootWorkPending=true
    else self:PaintRoot(row);row.dirty=nil end
    if not current() then return false,"STYLE_DISPATCH_SUPERSEDED" end
    self:Visibility(row)
    if self.boundedItems then self:RefreshRootHealth(row)
    elseif not row.leaseRepair and not row.paintBlocked and not row.contextUnavailable and (row.paintGaps or 0)==0 then
     row.repairAttempts=0;self:RootState(row,"READY","ROOT_PRESENTATION_READY")
    else self:RootState(row,"PARTIAL","ROOT_PRESENTATION_PARTIAL") end
   else
    L:Gap(self);if previous then self:RootState(previous,"PARTIAL",why or "ROOT_UNAVAILABLE") end
   end
  elseif previous and previous.leaseBlocked then
   L:Gap(self)
  elseif permitted and frame~=nil then L:Gap(self)
  elseif permitted and R.RecordSurface then R:RecordSurface(self,spec.id or spec.name,"WAITING","WAITING_FOR_NATIVE_CONTENT") end
 end
 return true
end
function Factory:Scan()
 if self.rootScoped then return self:ScanScoped() end
 local generation,profile=self.generation,M.profile
 local function current() return self.active and self.generation==generation and M.profile==profile and configured(self) end
 self.found=0
 for _,spec in ipairs(self.specs) do
  if not current() then return false,"STYLE_DISPATCH_SUPERSEDED" end
  local permitted=not spec.module or self:ModuleEnabled(spec.module)
  local frame=_G[spec.name]
  if permitted and frame and S:Frame(frame,false) then
   local row,why=self:Register(spec,frame)
   if not row then self.status=why or "ROOT_UNAVAILABLE";return false,self.status end
   self.found=self.found+1
   if row.items then for _,item in pairs(row.items) do item.dirty=true end end
   if self.cooperativeStyle then
    row.stylePending=nil;row.dirty={style=true};self.rootWorkPending=true
   else self:PaintRoot(row);row.dirty=nil end
   if not current() then return false,"STYLE_DISPATCH_SUPERSEDED" end
   if row.surface and row.surface.editable then self.painting=true;self:ApplyLayout(row.surface);self.painting=nil end
   self:Visibility(row)
  elseif permitted and frame~=nil then L:Gap(self) end
 end
 return true
end
function Factory:Configure()
 self.workCounts.configure=self.workCounts.configure+1
 if self.releasing then return false,"STYLE_RESTORE_REENTERED" end
 if not eligible(self) then return self:Suspend("UNSELECTED") end
 local editing=R:NativeEditState()
 if editing=="UNKNOWN" then return R:Result("DEFERRED_HANDOFF","NATIVE_EDIT_UNKNOWN") end
 if editing=="OPEN" then return self:Suspend("NATIVE_EDIT_HANDOFF") end
 if S:InCombat() then self.status="STYLE_COMBAT_DEFERRED";self.dirty=true;return false,self.status end
 if self.viewportRequired and self.active~=true and not screen() then
  -- These providers need native root geometry before their first child paint.
  -- Keep native custody untouched until publication queues this setup once.
  self.viewportPending=true;self.status="VIEWPORT_PENDING"
  return R:Result("WAITING",self.status)
 end
 self.viewportPending=nil
 if not self.records then L:Begin(self) end
 if self.rootScoped then
  -- Reconcile only the journal whose native identity, selected scope or failed
  -- receipt changed. Healthy siblings retain their original geometry receipts.
  for _,spec in ipairs(self.specs) do
   local row=self.roots[spec.name]
   if row then
    local changed=_G[spec.name]~=row.frame
    local permitted=not spec.module or self:ModuleEnabled(spec.module)
    if changed or not permitted then
     if changed and row.replacementTarget~=(_G[spec.name] or false) then
      row.releaseAttempts=0;row.repairAttempts=0;row.repairLatched=nil;row.replacementTarget=_G[spec.name] or false
     end
     self:ReleaseRoot(row,true)
    elseif row.leaseRepair or row.leaseBlocked or row.repairRequested then self:RepairRoot(row,false) end
   end
  end
  self.active=true;L:Begin(self);self.contextDeferred=nil
  for _,row in pairs(self.roots) do if row.leaseOwner and row.leaseOwner.active then row.leaseOwner.parentGeneration=self.generation end end
  local generation,profile=self.generation,M.profile
  local ok,why=self:Scan()
  if self.generation~=generation or not self.active or M.profile~=profile or not configured(self) then return false,"STYLE_DISPATCH_SUPERSEDED" end
  self.dirty=nil;self.discoveryDirty=nil;self.nextRootProbe=S:Now()+2;self:ProbeRoots()
  if not ok then return false,why end
  local blocked
  for _,row in pairs(self.roots) do if row.leaseBlocked or row.leaseRepair then blocked=blocked or row.spec.id or row.spec.name end end
  self.status=self.found==0 and not blocked and "WAITING_FOR_NATIVE_CONTENT" or (self.gaps>0 or blocked) and "MIRAGE_NATIVE_PRESENTATION_PARTIAL" or "MIRAGE_NATIVE_PRESENTATION_OWNED"
  if blocked and R.Result then return R:Result("PARTIAL",self.status,blocked) end
  if self.boundedItems and self.rootWorkPending then
   self.status="PRESENTATION_WORK_QUEUED";self:QueueContinuation()
   return R:Result("WAITING",self.status)
  end
  return true
 end
 local replaced=false
 local selected={}
 for i,spec in ipairs(self.specs) do selected[i]=(not spec.module or self:ModuleEnabled(spec.module)) and "1" or "0" end
 local scope=table.concat(selected)
 if self.scope and scope~=self.scope then replaced=true end
 for name,row in pairs(self.roots) do if _G[name]~=row.frame then replaced=true;break end end
 -- A failed cosmetic receipt stays local and remains available for explicit
 -- restoration. It must not repeatedly release/reacquire every healthy window.
 -- Native identity or module-scope replacement still requires full handback.
 if replaced then
  self.active=false
  self.generation=(self.generation or 0)+1
  local released=L:Release(self);if not released then self.status="ROOT_HANDOFF_PENDING";return false,self.status end
  for id,surface in pairs(self.surfaces) do
   if M.surfaces[id]==surface then M.Policy:Release(surface);M.surfaces[id]=nil;M.Effects.active[id]=nil end
  end
  self.roots={};self.surfaces={}
 end
 self.scope=scope
 if not self.active then
  for _,row in pairs(self.roots) do row.origin=M.Elements and M.Elements:Measure(row.frame) or row.origin end
 end
 self.active=true;L:Begin(self);self.contextDeferred=nil
 local generation,profile=self.generation,M.profile
 local ok,why=self:Scan()
 if self.generation~=generation or not self.active or M.profile~=profile or not configured(self) then return false,"STYLE_DISPATCH_SUPERSEDED" end
 self.dirty=nil;self.discoveryDirty=nil;self.nextRootProbe=S:Now()+2;self:ProbeRoots()
 if not ok then return false,why end
 self.status=self.found==0 and "WAITING_FOR_NATIVE_CONTENT" or self.gaps>0 and "MIRAGE_NATIVE_PRESENTATION_PARTIAL" or "MIRAGE_NATIVE_PRESENTATION_OWNED"
 if self.cooperativeStyle then return self:RefreshDirtyRoots(S:Now()) end
 return true
end
function Factory:Tick(now)
 if not self.active then return end
 if not eligible(self) then return self:Suspend("UNSELECTED") end
 local editing=R:NativeEditState()
 if editing=="UNKNOWN" then return R:Result("DEFERRED_HANDOFF","NATIVE_EDIT_UNKNOWN") end
 if editing=="OPEN" then return self:Suspend("NATIVE_EDIT_HANDOFF") end
 now=S:Number(now) and now or S:Now()
 if self.isolatedWindowPack then return true end -- its root journal owns dispatch
 if self.discoveryDirty or now>=(self.nextRootProbe or 0) then
  self.discoveryDirty=nil;self.nextRootProbe=now+2
  if self:ProbeRoots() then self.topologyDirty=true end
 end
 if self.topologyDirty then
  if S:InCombat() then self.status="SETUP_COMBAT_DEFERRED"
  else self.topologyDirty=nil;return self:Configure() end
 end
 if self.rootScoped and not S:InCombat() then
  for _,spec in ipairs(self.specs) do
   local row=self.roots[spec.name]
   if row and (row.leaseRepair or row.repairRequested) and not row.repairLatched then
    if _G[spec.name]~=row.frame or spec.module and not self:ModuleEnabled(spec.module) then return self:Configure() end
    if self:RepairRoot(row,false) then
     local current=self:Register(row.spec,row.frame)
     if current then
      if row.surface and row.surface.editable then self.painting=true;self:ApplyLayout(row.surface);self.painting=nil end
      self:PaintRoot(row)
      self:Visibility(row)
      if not row.leaseRepair and (row.paintGaps or 0)==0 then row.repairAttempts=0;self:RootState(row,"READY","ROOT_PRESENTATION_READY") end
     end
    end
    break
   end
  end
 end
 if self.dirty then
  self.dirty=nil
  for _,row in pairs(self.roots) do self:MarkRoot(row,"style") end
 end
 if self.contextDeferred and not S:InCombat() then self.contextDeferred=nil end
 return self:RefreshDirtyRoots(now)
end
function Factory:OnEvent(event,unit)
 if event=="PLAYER_LEAVING_WORLD" then return self:Suspend("WORLD_LEFT") end
 if self.isolatedWindowPack then self.dirty=true;return end
 if event=="ADDON_LOADED" or event=="PLAYER_ENTERING_WORLD" then self.discoveryDirty=true
 elseif event=="EDIT_MODE_LAYOUTS_UPDATED" then
  for _,row in pairs(self.roots) do self:MarkRoot(row,"geometry") end
 elseif event=="PLAYER_REGEN_ENABLED" then
  local parentPending=self.combatPending;self.combatPending=nil
  for _,row in pairs(self.roots) do
   local owner=row.leaseOwner
   if parentPending or owner and owner.combatPending then
    if owner then owner.combatPending=nil end
    -- MarkRoot retries actual presentation gaps. Items without their hooks
    -- also need one current paint: native artwork may have changed after the
    -- combat paint while no item callback could observe it. Settled siblings
    -- retain their artwork instead of repainting the whole buff/debuff cache.
    for _,item in pairs(row.items or {}) do if item.hooksPending then item.dirty=true end end
    self:MarkRoot(row,row.spec.roleOnly and "role" or "style")
   end
  end
 elseif self.id=="cooldowns" and (event=="SPELL_UPDATE_COOLDOWN" or event=="SPELL_UPDATE_CHARGES" or event=="UNIT_AURA") then
  -- The native duration/charge widgets already own these values. New children
  -- are discovered by acquire/layout callbacks, never by repainting every tick.
  return
 elseif event=="UNIT_AURA" and unit~=nil and unit~="player" then return
 else
  for _,row in pairs(self.roots) do self:MarkRoot(row,"style") end
 end
end
function Factory:Suspend(reason)
 self.active=false;self.generation=(self.generation or 0)+1;self.dirty=nil
 if self.boundedItems and M.RuntimeScheduler then M.RuntimeScheduler:Cancel("Rework.auras.continue") end
 if self.rootScoped then
  local complete,detail=true,nil
  for _,spec in ipairs(self.specs) do
   local row=self.roots[spec.name]
   if row then
    local ok,why=self:ReleaseRoot(row,false,true)
    if not ok then complete=false;detail=detail or why end
   end
  end
  self.status=complete and (reason or "SUSPENDED") or detail or "STYLE_RESTORE_PENDING"
  return complete,detail
 end
 local guards=true
 for _,row in pairs(self.roots) do guards=self:ReleaseContextReveal(row) and guards end
 local ok,why=L:Release(self)
 if not guards then ok=false;why="CONTEXT_RELEASE_PENDING" end
 if ok then for _,row in pairs(self.roots) do row.contextHidden=nil end end
 self.status=ok and (reason or "SUSPENDED") or why or "STYLE_RESTORE_PENDING"
 return ok,why
end
function Factory:Bounds(id)
 local s=self.surfaces[id];if not s then return nil end
 local l=self:ResolveLayout(s);local width=L:Public(s.frame,"GetWidth","number");local height=L:Public(s.frame,"GetHeight","number")
 local footer=0;for _,row in pairs(self.roots) do if row.surface==s then footer=row.spec.footerHeight or 0 end end
 return {frame=s.frame,id=id,x=l.x,y=l.y,width=width or l.width,height=(height and height+footer) or l.height,scale=l.scale or 1,
  anchorTo=l.anchorTo,source="QUALIFIED_NATIVE_CONTENT_CUSTOM_ART"}
end
function Factory:GetFrame(id) local s=self.surfaces[id];return s and s.frame end
function Factory:Status()
 return self.status.."; roots="..(self.found or 0).."; properties="..(self.styled or 0).."/"..(self.expected or 0)
  .."; gaps="..(self.gaps or 0).."; configure="..self.workCounts.configure.."; root_paints="..self.workCounts.rootPaint.."; identity_probes="..self.workCounts.probes.."; coalesced="..self.workCounts.coalesced.."; native_input=RETAINED_NOT_RUN; flow=NATIVE; combat_paint=UNPROTECTED_SCALARS_ONLY"
end
local function icon(owner,button)
 local picture=L:Field(button,"Icon")
 if not picture then L:Gap(owner,"icon","ICON_UNAVAILABLE");return end
 local kind=L:Public(picture,"GetObjectType","string")
 local parent,actual=button,picture
 if kind~="Texture" then parent,actual=picture,L:Field(picture,"Icon") end
 if not actual then return end
 -- Reserved native slots are not visible content. Only the public artwork
 -- identity admits our extra border; unknown/restricted art remains entirely
 -- native. No spell/aura identity or duration is inspected to make this choice.
 local source,atlas=L:TextureSource(actual)
 if source==nil or source==false and atlas==false then
  L:HidePanel(owner,parent,"icon");return
 end
 L:Crop(owner,actual);L:Panel(owner,parent,actual,"icon",0)
end
R.CombatIcon=icon
local auraSpecs={
 {name="BuffFrame",id="Auras.BuffFrame",layout={x=.25,y=.41,width=300,height=64,scale=1}},
 {name="DebuffFrame",id="Auras.DebuffFrame",layout={x=.25,y=.32,width=300,height=64,scale=1}},
 {name="ExternalDefensivesFrame",editable=false,safety=true}}
local A=Factory:New("auras","Auras",auraSpecs);R.CombatAuras=A
A.boundedItems=true
A.events.UNIT_AURA=true
local function auraButton(self,button)
 local anchor=L:Field(button,"isAuraAnchor")
 if anchor==true then
  -- A private aura anchor can be empty while its permitted parent is shown.
  -- Its content is intentionally opaque, so it receives no enclosing Mirage
  -- placeholder. Leave the native private icon and anchor lifecycle intact.
  local parent=L:Field(button,"Icon");if parent then L:HidePanel(self,parent,"private") end
  return
 end
 icon(self,button)
 for _,key in ipairs({"Duration","Count","Symbol"}) do L:Font(self,L:Field(button,key),11) end
 local picture=L:Field(button,"Icon")
 if picture then for _,key in ipairs({"DebuffBorder","TempEnchantBorder"}) do L:BorderUnderline(self,L:Field(button,key)) end end
end
function A:Skin(row)
 local frame=row.frame;local work=row.itemWork
 if not work then
  work={items={},cursor=1,private=0,generation=self.generation,profile=M.profile,frame=frame};row.itemWork=work
  local function collect(button,holder,list,index,consolidated,tooltip)
   work.items[#work.items+1]={object=button,holder=holder,list=list,index=index,consolidated=consolidated,tooltip=tooltip}
  end
  -- The public native pool is enumerated once per invalidation, not once per
  -- continuation. Native content/expiry/input keep running during styling.
  local list=L:Field(frame,"auraFrames")
  L:List(self,list,80,function(button,index) collect(button,frame,list,index) end)
  self:HookRoot(row,frame,"UpdateAuraButtons","style");self:HookRoot(row,frame,"UpdateGridLayout","geometry")
  local consolidated=L:Field(frame,"ConsolidatedBuffs")
  if consolidated then
   collect(consolidated,frame,nil,nil,consolidated)
   local tooltip=L:Field(consolidated,"Tooltip")
   if tooltip then
    L:Panel(self,tooltip,tooltip,"consolidated",.9)
    local auras=L:Field(tooltip,"Auras")
    if auras then
     local nested=L:Field(auras,"auraFrames")
     L:List(self,nested,80,function(button,index) collect(button,auras,nested,index,consolidated,tooltip) end)
     self:HookRoot(row,auras,"UpdateAuraButtons","style")
    end
   end
  end
  local toggle=L:Field(frame,"CollapseAndExpandButton")
  if toggle then local checked=L:Public(toggle,"GetChecked","boolean");L:Glyph(self,toggle,checked and "<" or ">") end
 end
 local painted,visited=0,0
 local scheduler=M.RuntimeScheduler
 local started=scheduler and scheduler.StageClock and scheduler:StageClock()
 local function current()
  return self.active and self.generation==work.generation and M.profile==work.profile
   and self.roots[row.spec.name]==row and row.frame==work.frame and _G[row.spec.name]==work.frame
 end
 local function retained(entry)
  if not S:Frame(entry.object,false) or not current() then return false,"ITEM_CUSTODY_UNAVAILABLE" end
  if entry.consolidated and L:Field(frame,"ConsolidatedBuffs")~=entry.consolidated then return false,"ITEM_IDENTITY_CHANGED" end
  if entry.tooltip and (L:Field(entry.consolidated,"Tooltip")~=entry.tooltip or L:Field(entry.tooltip,"Auras")~=entry.holder) then return false,"ITEM_IDENTITY_CHANGED" end
  if entry.list and (L:Field(entry.holder,"auraFrames")~=entry.list or L:Field(entry.list,entry.index)~=entry.object) then return false,"ITEM_IDENTITY_CHANGED" end
  -- The queue is only a candidate list. Native pools may move or retire a
  -- button between slices; public current membership and ancestry are both
  -- required before its old presentation journal can be applied again.
  local object=entry.object
  for _=1,16 do
   if object==entry.holder then return current() end
   object=L:Public(object,"GetParent")
   if not object or not S:Frame(object,false) then return false,"ITEM_CUSTODY_UNAVAILABLE" end
  end
  return false,"ITEM_CUSTODY_CHANGED"
 end
 while work.cursor<=#work.items do
  if not current() then row.itemWork=nil;return end
  local clock=started and scheduler:StageClock()
  if visited>0 and clock and clock-started>=1 then break end
  local entry=work.items[work.cursor];local item=entry.object
  local valid,reason=retained(entry)
  if not valid then
   if not current() then row.itemWork=nil;return end
   self.workCounts.retiredQueuedItems=(self.workCounts.retiredQueuedItems or 0)+1
   if reason=="ITEM_IDENTITY_CHANGED" then self:MarkRoot(row,"style")
   else L:Gap(self,"item",reason) end
   work.cursor=work.cursor+1
  else
  local cached=row.items and row.items[item]
  local dirty=not cached or cached.dirty or cached.hooksPending and not S:InCombat()
  -- One item is the indivisible property journal. Yield between new/dirty
  -- items; clean cached coverage can be accounted without repainting it.
  if dirty and painted>=2 then break end
  if L:Field(item,"isAuraAnchor")==true then work.private=work.private+1 end
  self:StyleItem(row,item,function(button) auraButton(self,button) end)
  if dirty then painted=painted+1 end
  work.cursor=work.cursor+1
  end
  visited=visited+1
 end
 self.workCounts.itemSlices=(self.workCounts.itemSlices or 0)+1
 self.workCounts.maxItemsPerSlice=math.max(self.workCounts.maxItemsPerSlice or 0,painted)
 if work.cursor<=#work.items then return end
 row.privateCount=work.private;row.itemWork=nil;self.privateCount=0
 for _,owned in pairs(self.roots) do self.privateCount=self.privateCount+(owned.privateCount or 0) end
end
function A:QueueContinuation()
 local q=M.RuntimeScheduler
 if not q or not q.Request or not self.active then return end
 local generation,profile=self.generation,M.profile
 q:Request("Rework.auras.continue",function(now)
  local result,why=self:Tick(now)
  if not self.active or self.generation~=generation or M.profile~=profile then return end
  local provider=R.providers and R.providers.auras
  if provider and provider.object==self and R.Health then
   local kind,reason,surface=R:ResultKind(result,why,self);R:Health(provider,kind,reason,surface)
  end
 end,{owner="auras",priority=6,combat="allow",guard=function()
  return self.active and self.generation==generation and M.profile==profile and configured(self)
 end})
end
local auraStatus=A.Status
function A:Status()
 return auraStatus(self).."; item_slices="..(self.workCounts.itemSlices or 0).."; max_new_items_per_slice="..(self.workCounts.maxItemsPerSlice or 0)
  .."; retired_queued_items="..(self.workCounts.retiredQueuedItems or 0).."; slice_budget=2_ITEMS_OR_1MS_BETWEEN_ITEMS"
end

local cooldownSpecs={}
for i,name in ipairs({"EssentialCooldownViewer","UtilityCooldownViewer","BuffIconCooldownViewer","BuffBarCooldownViewer"}) do
 cooldownSpecs[#cooldownSpecs+1]={name=name,id="Cooldowns."..name,layout={x=0,y=-.30+(i-1)*.075,width=420,height=i==4 and 80 or 50,scale=1}}
end
local C=Factory:New("cooldowns","Cooldowns",cooldownSpecs);R.CombatCooldowns=C
for _,event in ipairs({"SPELLS_CHANGED","SPELL_UPDATE_COOLDOWN","SPELL_UPDATE_CHARGES","PLAYER_SPECIALIZATION_CHANGED","UNIT_AURA"}) do C.events[event]=true end
local cdAtlases={["UI-HUD-CoolDownManager-Mask"]="mask",["UI-HUD-CoolDownManager-IconOverlay"]="hide"}
function C:SkinItem(item)
 icon(self,item);L:Regions(self,item,cdAtlases)
 local pic=L:Field(item,"Icon");if pic then L:Regions(self,pic,cdAtlases) end
 for _,path in ipairs({{"ChargeCount","Current"},{"Applications","Applications"},{"Icon","Applications"}}) do L:Font(self,L:Path(item,unpack(path)),11) end
 local cooldown=L:Field(item,"Cooldown")
 if cooldown then
  -- The native cooldown owns the duration/charge state and number formatter.
  local fn=L:Field(cooldown,"GetRegions")
  if type(fn)=="function" then
   local ok,regions=pcall(function() return {fn(cooldown)} end)
   if ok and #regions<=16 then for _,region in ipairs(regions) do if L:Public(region,"GetObjectType","string")=="FontString" then L:Font(self,region,12) end end end
  end
 end
 local border=L:Path(item,"DebuffBorder","Texture")
 if border and pic then L:BorderUnderline(self,border) end
 local bar=L:Field(item,"Bar")
 if bar then
  L:Bar(self,bar);L:DecorativeTexture(self,L:Field(bar,"BarBG"),L.panel);L:Panel(self,bar,bar,"bar",0)
  L:Font(self,L:Field(bar,"Name"),11);L:Font(self,L:Field(bar,"Duration"),11)
  L:DecorativeTexture(self,L:Field(bar,"Pip"),L.white)
 end
end
function C:Skin(row)
 L:Pool(self,L:Field(row.frame,"itemFramePool"),160,function(item)
  self:StyleItem(row,item,function(button) self:SkinItem(button) end)
 end)
 L:Hook(self,row.frame,"OnAcquireItemFrame",function(_,_,_,item)
  if row.items and S:Frame(item,false) and row.items[item] then row.items[item].dirty=true end
  self:MarkRoot(row,"style")
 end)
 for _,method in ipairs({"RefreshLayout","Layout","UpdateLayout","RefreshData"}) do self:HookRoot(row,row.frame,method,"style") end
end
