local _,M=...
-- Mirage group artwork follows native party and raid member controls. The
-- native subgroup manager retains membership and child arrangement. Mirage
-- can move and uniformly resize each whole party/raid control after an edit.
local R,S,U=M.Rework,M.Safety,M.Rework.UnitFrames
local G={groups={},views={},all={},status="NOT_INITIALIZED",events={}}
R.UnitGroups=G
G.nativeRoots={PartyFrame=true,CompactPartyFrame=true,CompactRaidFrameContainer=true}
G.layoutIDs={}
G.geometryRoots={['PartyRaid.partyFrame']='PartyFrame',['PartyRaid.raidFrame']='CompactRaidFrameContainer'}
for id in pairs(G.geometryRoots) do G.layoutIDs[id]=true end
for i=1,4 do G.layoutIDs["PartyRaid.party"..i]=true end
for i=1,40 do G.layoutIDs["PartyRaid.raid"..i]=true end
for i=1,8 do G.layoutIDs["PartyRaid.group"..i]=true end
for i=1,5 do G.nativeRoots["CompactPartyFrameMember"..i]=true end
for event in pairs(U.events) do G.events[event]=true end
local function selected() return not M.state.safe and R:Qualified() and R:Selected("groups",M.profile) end
-- M06: native membership and native secure input with Mirage passive cards.
-- CompactRaidGroup1..8 are observed real subgroup roots. Their saved independent
-- Mirage envelopes remain in the profile; the native container still lays out
-- its actual group roots, so this path does not reanchor or fight that manager.
local N=R.NativeUnitPresentation
G.nativeBacked=true;G.id="groups"
function G:OwnsGeometry(id,profile) return self.geometryRoots[id]~=nil and (profile or M.profile).managed==true end
-- The native raid container owns subgroup arrangement and all of its secure
-- children. Subgroup/member selections lead to that one editable container;
-- absent groups still have a real saved-layout consumer when a roster arrives.
function G:CustomizeTarget(id)
 if self.geometryRoots[id] then return id end
 if type(id)~="string" then return nil end
 local group=tonumber(id:match("^PartyRaid%.group([1-8])$"))
 local raid=tonumber(id:match("^PartyRaid%.raid(%d+)$"))
 local party=tonumber(id:match("^PartyRaid%.party([1-4])$"))
 if group or raid and raid>=1 and raid<=40 then return "PartyRaid.raidFrame" end
 if party then return "PartyRaid.partyFrame" end
end
function G:Customization(id,profile)
 local target=self:CustomizeTarget(id)
 if not target or not self:OwnsGeometry(target,profile) then return nil end
 local frame=self:GetFrame(target)
 local present=S:Frame(frame,false)==true
 local ready,reason=self:GeometryContentReady(target)
 return {target=target,authorable=true,wholeControl=true,subgroup=id~=target,
  nativePresent=present,contentReady=ready==true,contentReason=reason,
  mode=ready==true and "NATIVE_WHOLE_GROUP" or "DRAFT_WAITING_FOR_ROSTER",
  layout=self:ResolveLayout({id=target},profile or M.profile),
  placement="OUT_OF_COMBAT",input="NATIVE_ORIGINAL",arrangement="NATIVE_SUBGROUPS"}
end
function G:ResolveLayout(surface,profile)
 profile=profile or M.profile
 if self:OwnsGeometry(surface.id,profile) then
  if not (profile.layouts and profile.layouts[surface.id]) and self:GeometryContentReady(surface.id)~=true then
   local definition=M.Elements and M.Elements.definitions[surface.id]
   local fallback=surface.id=="PartyRaid.raidFrame" and {x=-.35,y=.15,width=320,height=300,scale=1}
    or {x=-.40,y=.15,width=200,height=280,scale=1}
   return M.Layout:Get({id=surface.id,layout=definition and definition.layout or fallback},profile)
  end
  return N:GeometryLayout(self,surface.id,profile)
 end
 local bounds=self:Bounds(surface.id)
 return bounds or M.Layout:Get(surface,profile)
end
function G:GeometryPreview(id,profile)
 local content,reason=self:GeometryContentReady(id)
 if content~=true then return nil,reason end
 return N:GeometryPreview(self,id,profile)
end
function G:GeometryReference(id,frame,bounds,layout)
 -- An envelope describes the space available to a group, not space that a
 -- smaller roster must fill. In particular, never turn a 120x55 lone member
 -- into the height of the whole saved party. Measure native member pitch and
 -- reserve the remaining party slots without showing or moving those slots.
 local l=R.CombatLeases
 local ceiling=layout.scale or 1
 if id~='PartyRaid.partyFrame' then return bounds.width,bounds.height,ceiling end
 local compact=_G.CompactPartyFrame
 local compactShown=l:Public(compact,'IsShown','boolean')==true
 local capacity=compactShown and 5 or 4
 local present=0
 for i=1,capacity do
  local unit=compactShown and (i==1 and 'player' or 'party'..(i-1)) or 'party'..i
  local exists,state=S:Public(UnitExists,'boolean',unit)
  if state~='KNOWN' then return bounds.width,bounds.height,ceiling end
  if exists then present=present+1 end
 end
 if present==0 then return bounds.width,bounds.height,ceiling end
 local rootScale=l:Public(frame,'GetEffectiveScale','number')
 if not rootScale or rootScale<=0 then return bounds.width,bounds.height,ceiling end
 local memberWidth,memberHeight=0,0
 for i=1,capacity do
  local member
  if compactShown then
   member=l:Field(l:Field(compact,'memberUnitFrames'),i) or _G['CompactPartyFrameMember'..i]
  else
   local getter=l:Field(frame,'GetPartyMemberFrame')
   member=type(getter)=='function' and S:Public(getter,nil,frame,i) or l:Field(frame,'MemberFrame'..i)
  end
  local w=l:Public(member,'GetWidth','number');local h=l:Public(member,'GetHeight','number')
  local scale=l:Public(member,'GetEffectiveScale','number')
  if w and h and scale and w>0 and h>0 and scale>0 then
   memberWidth=math.max(memberWidth,w*scale/rootScale);memberHeight=math.max(memberHeight,h*scale/rootScale)
  end
 end
 if memberWidth<=0 or memberHeight<=0 then return bounds.width,bounds.height,ceiling end
 local horizontal=false
 local spacing=0
 if compactShown then
  local manager=_G.EditModeManagerFrame
  local getter=l:Field(manager,'ShouldRaidFrameUseHorizontalRaidGroups')
  local known
  horizontal,known=S:Public(getter,'boolean',manager,l:Field(compact,'groupType'))
  if known~='KNOWN' then return bounds.width,bounds.height,ceiling end
 else
  spacing=l:Field(frame,'spacing')
  if not S:Number(spacing) or spacing<0 or spacing>100 then return bounds.width,bounds.height,ceiling end
 end
 local function padding(object,key)
  local v=l:Field(object,key)
  return S:Number(v) and math.max(0,v) or 0
 end
 local width=horizontal and capacity*memberWidth+(capacity-1)*spacing or memberWidth
 local height=horizontal and memberHeight or capacity*memberHeight+(capacity-1)*spacing
 if compactShown then
  local title=l:Field(compact,'title')
  local titleHeight=l:Public(title,'GetHeight','number') or 0
  local titleScale=l:Public(title,'GetEffectiveScale','number') or rootScale
  height=height+math.max(0,titleHeight)*titleScale/rootScale
  local border=l:Field(compact,'borderFrame')
  if l:Public(border,'IsShown','boolean')==true then
   local compactScale=l:Public(compact,'GetEffectiveScale','number') or rootScale
   width=width+(horizontal and 4 or 8)*compactScale/rootScale
   height=height+(horizontal and 0 or 2)*compactScale/rootScale
  end
 end
 width=width+padding(frame,'leftPadding')+padding(frame,'rightPadding')
 height=height+padding(frame,'topPadding')+padding(frame,'bottomPadding')
 -- Roster and native-layout events need not arrive in the same order. The
 -- full-capacity floor also prevents one stale, still-small root rectangle
 -- from briefly enlarging all members after a join. Current extra pet space
 -- can require further shrinking, but never permits roster-based inflation.
 width=math.max(bounds.width,width);height=math.max(bounds.height,height)
 return width,height,nil
end
function G:GeometryContentReady(id)
 local token=id=='PartyRaid.raidFrame' and 'raid1' or 'party1'
 local exists,state=S:Public(UnitExists,'boolean',token)
 if state~='KNOWN' then return false,'WAITING_FOR_GROUP_CONTENT_OBSERVATION' end
 if not exists then return false,'WAITING_FOR_GROUP_CONTENT' end
 local name=self.geometryRoots[id];local frame=name and _G[name]
 local shown,known=R.CombatLeases:Public(frame,'IsShown','boolean')
 if known~='KNOWN' or not shown then return false,'WAITING_FOR_GROUP_LAYOUT' end
 return true
end
function G:GetFrame(id) local name=self.geometryRoots[id];return name and _G[name] end
local partyElements,raidElements={},{}
for i=1,4 do partyElements[#partyElements+1]="PartyRaid.party"..i end
for i=1,40 do raidElements[#raidElements+1]="PartyRaid.raid"..i end
function G:ConfigureContext()
 self.contextStatus={};self.contextReady=true
 -- CompactPartyFrame is a child of PartyFrame in the pinned client. Gate
 -- that one container, preserving every native member/pet/group parent.
 for _,spec in ipairs({{"PartyFrame",partyElements},{"CompactRaidFrameContainer",raidElements}}) do
  if _G[spec[1]] then
   local ready,status=N:Context(self,spec[1],"PartyRaid",nil,spec[2])
   if not ready then self.contextReady=false end
   self.contextStatus[spec[1]]=status or (ready and "SECURE_CONTEXT_READY" or "CONTEXT_UNAVAILABLE")
  end
 end
 if self.nativeArtFailed or self.contextReady==false or self.nativeGeometryChanged then return N:Outcome(self) end
end
function G:InvalidateNative(frame,reprepareAll)
 if not self.active then return end
 self.nativeDiscoveryDirty=true;self.pendingWork=true;self.geometryDirty=true
 self.nativeDiscoveryRevision=(self.nativeDiscoveryRevision or 0)+1
 if reprepareAll then self.nativeReprepareAll=true end
 -- A native setup callback identifies the one existing control it changed.
 -- Preserve that reprepare request even when discovery finds the same pool.
 local view
 if S:Frame(frame,false) and N.cards then view=N.cards[frame] end
 if view and view.reworkProvider==self and self.nativeCards and self.nativeCards[view.controlKey]==view then
  self.nativeDirty[view.controlKey]=true
 end
end
function G:ObservePartyRoot()
 local frame=_G.PartyFrame;local L=R.CombatLeases
 if not S:Frame(frame,false) or type(hooksecurefunc)~="function" then return end
 self.partyRootHooks=self.partyRootHooks or setmetatable({},{__mode="k"})
 if self.partyRootHooks[frame] then return end
 -- The actual party root rebuilds its pooled buttons from OnShow. Neither
 -- GROUP_ROSTER_UPDATE nor the compact-raid factory observes that rebuild.
 -- Only invalidate after the native setup; never call its Layout or Setup.
 local method=L:Field(frame,"InitializePartyMemberFrames")
 if type(method)=="function" then
  local ok=pcall(hooksecurefunc,frame,"InitializePartyMemberFrames",function()
   if _G.PartyFrame==frame then G:InvalidateNative(nil,true) end
  end)
  if ok then self.partyRootHooks[frame]=true end
 end
end
function G:DiscoverNative(force)
 local L=R.CombatLeases
 self:ObservePartyRoot()
 -- Acquiring the contextual parent can call native OnShow and rebuild the
 -- party pool. Resolve member identities after that transition has settled.
 self:ConfigureContext()
 local discoveryRevision=self.nativeDiscoveryRevision or 0
 local reprepareAll=force or self.nativeReprepareAll
 local specs,seen={},{}
 self.nativeFrameKeys=self.nativeFrameKeys or setmetatable({},{__mode="k"})
 local function add(key,frame,fallback)
  if not S:Frame(frame,false) or seen[frame] then return end
  seen[frame]=true
  local unit=L:Field(frame,"unit")
  if not S:Text(unit) or not (unit=="player" or unit:match("^party[1-4]$") or unit:match("^raid%d+$")) then unit=fallback end
  if not unit then return end
  specs[#specs+1]={key=key,frame=frame,unit=unit}
 end
 for i=1,4 do
  local getter=L:Field(_G.PartyFrame,"GetPartyMemberFrame")
  local member=type(getter)=="function" and S:Public(getter,nil,_G.PartyFrame,i) or nil
  add("party_"..i,member or L:Field(_G.PartyFrame,"MemberFrame"..i),"party"..i)
  add("legacy_party_"..i,_G["PartyMemberFrame"..i],"party"..i)
 end
 local compactMembers=L:Field(_G.CompactPartyFrame,"memberUnitFrames")
 for i=1,5 do add("compact_party_"..i,L:Field(compactMembers,i) or _G["CompactPartyFrameMember"..i],i==1 and "player" or "party"..(i-1)) end
 self.groups={}
 for group=1,8 do
  local root=_G["CompactRaidGroup"..group]
  if S:Frame(root,false) then
   self.groups[group]={index=group,frame=root,surface={id="PartyRaid.group"..group,frame=root,editable=false,nativeEdit=true},nativeBacked=true}
   local members=L:Field(root,"memberUnitFrames")
   for slot=1,5 do
    local frame=_G["CompactRaidGroup"..group.."Member"..slot]
    if not frame and type(members)=="table" and S:Readable(members) then frame=L:Field(members,slot) end
    add("group_"..group.."_"..slot,frame,"raid"..((group-1)*5+slot))
   end
  end
 end
 -- Flat raid mode uses children of the named native container. This bounded
 -- one-level discovery runs only on a roster/lifecycle invalidation, never on
 -- health/power events or the steady update heartbeat.
 local root=_G.CompactRaidFrameContainer;local getter=L:Field(root,"GetChildren")
 if type(getter)=="function" and S:Frame(root,false) then
  local ok,children=pcall(function() return {getter(root)} end)
  if ok and #children<=160 then
   for _,frame in ipairs(children) do
    local key=self.nativeFrameKeys[frame]
    if not key then self.nativeFrameSerial=(self.nativeFrameSerial or 0)+1;key="flat_"..self.nativeFrameSerial;self.nativeFrameKeys[frame]=key end
    add(key,frame,nil)
   end
  else R:RecordSurface(self,"PartyRaid.nativeDiscovery","PARTIAL","NATIVE_DISCOVERY_LIMIT") end
 end
 for key,view in pairs(self.nativeCards) do
  if not seen[view.inputFrame] then
   if (view.releaseAttempts or 0)<3 then
    view.releaseAttempts=(view.releaseAttempts or 0)+1
    if N:ReleaseCard(self,view) then
     self.nativeCards[key]=nil
     R:RecordSurface(self,"PartyRaid."..key,"EMPTY","NATIVE_ROOT_RETIRED")
    else R:RecordSurface(self,"PartyRaid."..key,"DEFERRED_HANDOFF","ROOT_HANDOFF_PENDING") end
   end
  end
 end
 self.nativeRequests=specs
 for _,spec in ipairs(specs) do
  local view=self.nativeCards[spec.key]
  N:RearmReplacedRoot(self,spec.key,spec.frame)
  if reprepareAll or not view or view.inputFrame~=spec.frame or view.baseUnit~=spec.unit or not view.controlReady then
   self.nativeDirty[spec.key]=true
  elseif not self.nativeDirty[spec.key] then
   -- Discovery is an identity census, not a blanket style invalidation.
   -- Native Show/size/setup callbacks retain their explicit repair requests;
   -- unrelated pool/roster notifications do not recreate every healthy card.
   self.discoveryCardsRetained=(self.discoveryCardsRetained or 0)+1
  end
 end
 self.nativeDiscoveryDirty=(self.nativeDiscoveryRevision or 0)~=discoveryRevision or nil
 if not self.nativeDiscoveryDirty then self.nativeReprepareAll=nil end
end
function G:Configure()
 if not selected() then return self:Suspend() end
 local result=N:Configure(self);if result~=true then return result end
 self.mode="NATIVE_VISIBLE_SUBGROUPS";self.nativeDiscoveryDirty=true
 -- The exact-source setup callbacks only invalidate; they never call native
 -- layout methods, create a raid group, or alter a unit assignment.
 if type(hooksecurefunc)=="function" then
  self.nativeDiscoveryHooks=self.nativeDiscoveryHooks or {}
  for _,name in ipairs({"CompactRaidGroup_GenerateForGroup","CompactUnitFrame_SetUpFrame","CompactPartyFrame_Generate"}) do
   if type(_G[name])=="function" and not self.nativeDiscoveryHooks[name] then
    local setup=name=="CompactUnitFrame_SetUpFrame"
    local ok=pcall(hooksecurefunc,name,function(frame)
     if setup then G:InvalidateNative(frame) else G:InvalidateNative() end
    end)
    if ok then self.nativeDiscoveryHooks[name]=true end
   end
  end
 end
 self:DiscoverNative(true)
 self.geometryDirty=true;N:GeometryTick(self)
 return N:Outcome(self)
end
function G:Initialize() return self:Configure() end
function G:PublishViews(painted)
 self.views={};self.all={}
 for _,view in pairs(self.nativeCards or {}) do
  if view.controlReady then
   self.all[#self.all+1]=view
   -- A paint revision already resolved the secure assignment used by the
   -- passive artwork. A second native read can observe the next assignment
   -- and make lookup/geometry claim a unit that has not been painted yet.
   -- Structural discovery retains its ordinary fresh native resolution.
   local unit
   if painted then unit=view.unit else unit=U:EffectiveUnit(view) end
   if unit then
    view.unit=unit
    local shown=R.CombatLeases:Public(view.inputFrame,"IsVisible","boolean")
    if shown or not self.views[unit] then self.views[unit]=view end
   end
  end
 end
 M.modules.PartyRaid.views=self.views
 self.publishedUnitRevision=self.nativeUnitRevision or 0
end
function G:Tick(now)
 if not self.active then return end
 if R:NativeEditState()~="CLOSED" then return end
 if not selected() then return self:Suspend() end
 N:BeginRuntimeTick(self,now)
 N:ContextHealth(self)
 N:Paint(self,"TICK") -- apply native unit substitutions without waiting for a later UNIT event
 -- Secure unit substitution can happen during combat without a roster event.
 -- Publish only changed membership; steady ticks keep their existing tables.
 if self.publishedUnitRevision~=(self.nativeUnitRevision or 0) then self:PublishViews(true) end
 if S:InCombat() then if self.nativeArtFailed or self.contextReady==false then return N:Outcome(self) end;return end
 N:GeometryTick(self)
 if self.nativeDiscoveryDirty then self:DiscoverNative() end
 for _,spec in ipairs(self.nativeRequests or {}) do
  if self.nativeDirty[spec.key] and not self.nativeFailed[spec.key] then
   N:Refresh(self,spec.key,spec.unit,spec.frame,"Group member","PartyRaid","PartyRaid."..spec.key)
   self:PublishViews();return N:Outcome(self)
  end
 end
 if self.nativeArtFailed or self.contextReady==false or self.nativeGeometryChanged then return N:Outcome(self) end
end
function G:NeedsRuntimeTick(now,combat) return N:RuntimeDemand(self,now,combat) end
function G:OnNativeContextHealthChanged() self.pendingWork=true;self.nativeHealthDirty=true;N:ContextHealth(self) end
function G:Refresh(roster)
 if roster and self.active then self.nativeDiscoveryDirty=true end
 self:PublishViews()
end
function G:OnEvent(event,unit)
 if not self.active then return end
 -- Roster/factory/native-show callbacks retain discovery debt through combat.
 -- An unchanged combat exit must not rediscover and reprepare every member.
 if event=="GROUP_ROSTER_UPDATE" or event=="PLAYER_ENTERING_WORLD" or event=="ADDON_LOADED" then self.nativeDiscoveryDirty=true end
 if event=="GROUP_ROSTER_UPDATE" or event=="EDIT_MODE_LAYOUTS_UPDATED" or event=="UI_SCALE_CHANGED" or event=="DISPLAY_SIZE_CHANGED" then self.geometryDirty=true end
 if event=="PLAYER_ENTERING_WORLD" or event=="ADDON_LOADED" then self.geometryDirty=true end
 N:Paint(self,event,S:Text(unit) and unit or nil)
 local changed=self.publishedUnitRevision~=(self.nativeUnitRevision or 0)
 if event=="GROUP_ROSTER_UPDATE" or event=="UNIT_ENTERED_VEHICLE" or event=="UNIT_EXITED_VEHICLE"
  or changed then self:PublishViews(changed) end
end
function G:MaintainSecure(event,unit) if self.active or self.suspendPending then N:Paint(self,event,S:Text(unit) and unit or nil) end end
function G:Suspend() return N:Suspend(self) end
function G:Retry()
 if S:InCombat() then return false end
 if not N:Suspend(self) then return false end
 if M.ContextualNative then M.ContextualNative:RetryOwned(self) end
 self.nativeFailed={};self.nativeFailureFrames={};self.nativeDiscoveryDirty=true
 self.geometryDirty=true;for _,row in pairs(self.geometryRows or {}) do row.attempts=0 end
 for _,view in pairs(self.nativeCards or {}) do view.releaseAttempts=0;view.paintAttempts=0 end
 return true
end
function G:GetView(unit) return self.views[unit] end
function G:GetGroup(index) return self.groups[index] end
function G:IsReady(unit) local view=self.views[unit];return self.active and view and view.controlReady==true and view.contextReady~=false or false end
function G:Bounds(id)
 if not S:Text(id) then return nil end
 if self.geometryRoots[id] then return N:Bounds(_G[self.geometryRoots[id]],id) end
 local group=tonumber(id:match("^PartyRaid%.group([1-8])$"))
 if group then local row=self.groups[group];return row and N:Bounds(row.frame,id) or nil end
 local unit=id:match("^PartyRaid%.(.+)$") or id;local view=self.views[unit]
 return view and N:Bounds(view.inputFrame,"PartyRaid."..unit) or nil
end
function G:ApplyLayout(surface)
 if surface and self:OwnsGeometry(surface.id) then return N:ApplyGeometry(self,surface.id) end
 return false,"NATIVE_BACKED_GEOMETRY"
end
function G:OptionalBounds() return {} end
function G:Status()
 local count=0;for _ in pairs(self.groups) do count=count+1 end
 local geometry={};for _,id in ipairs({'PartyRaid.partyFrame','PartyRaid.raidFrame'}) do
  geometry[#geometry+1]=id..':'..N:GeometryReport(self,id)
 end
 return (self.status or "WAITING_FOR_NATIVE_CONTENT").."; input=NATIVE_ORIGINAL; visibility="..(self.contextReady==true and "SECURE_CONTEXT_NATIVE_LIFETIME" or "CONTEXT_PARTIAL_NATIVE_INPUT_RETAINED").."; raid_subgroup_roots_observed="..count.."; membership=NATIVE_SUBGROUPS; card_header=LEVEL_NAME_TARGET_FORMAT; pooled_party_refresh=OBSERVED; discovery_cards_retained="..(self.discoveryCardsRetained or 0).."; geometry=MIRAGE_WHOLE_GROUP_ENVELOPES; geometry_controls="..table.concat(geometry,',').."; authored_subgroups=DORMANT_PRESERVED; aura_cast=NATIVE_LIFETIME; "..N:RuntimeDemandStatus(self).."; native=NOT_RUN"
end
