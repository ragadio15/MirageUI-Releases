local _, M = ...
-- SecureUnitButtonTemplate itself routes native click bindings. This adapter only
-- exposes the native configuration screen; it never executes, copies or rewrites bindings.
M.ClickCasting={status="NOT_CHECKED"}
function M.ClickCasting:Available()
    return M.Client.allowed and C_ClickBindings and type(C_ClickBindings.GetBindingType)=="function" and type(ToggleClickBindingFrame)=="function"
end
function M.ClickCasting:Describe()
    if self:Available() then
        return "Uses the game's click-casting settings. MirageUI unit buttons keep their inherited secure click handler. Native bindings may replace normal target/menu clicks."
    end
    return "Native click-casting setup is unavailable on this client. Standard target and menu clicks remain unchanged."
end
function M.ClickCasting:Open()
    if M.Safety:InCombat() then return false,"Open click-casting setup after combat." end
    if not self:Available() or M.state.safe or not M.state.world then return false,"Native click-casting setup is unavailable in this session." end
    if ClickBindingFrame and M.Safety:Frame(ClickBindingFrame,false) and M.Safety:Public(ClickBindingFrame.IsShown,"boolean",ClickBindingFrame)==true then
        return true,"The game's click-casting settings are already open."
    end
    local ok=pcall(ToggleClickBindingFrame)
    self.status=ok and "NATIVE_SETUP_REQUESTED" or "NATIVE_SETUP_UNAVAILABLE"
    return ok,ok and "Configure and save click-casting in the game's window. MirageUI does not copy or change that profile." or "The game's click-casting window could not be opened."
end
