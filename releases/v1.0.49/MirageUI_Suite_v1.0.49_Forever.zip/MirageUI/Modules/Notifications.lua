local _,M=...
local S=M.Safety
local N={events={CHAT_MSG_LOOT=true,CHAT_MSG_MONEY=true,CHAT_MSG_SKILL=true,CHAT_MSG_COMBAT_FACTION_CHANGE=true,PLAYER_LEVEL_UP=true,ADDON_LOADED=true,PLAYER_ENTERING_WORLD=true,PLAYER_LEAVING_WORLD=true},rows={},fontLeases={},delivered=0,dropped=0}
local colors={loot={.95,.81,.50},money={.96,.73,.37},profession={.40,.85,.74},status={.72,.83,.91}}
local labels={loot="ACQUIRED",money="CURRENCY",profession="PROFESSION",status="PROGRESS"}
-- Native localized SELF-system formats only; ordinary chat and balance changes
-- are never consumed. Positional placeholders preserve localized argument order.
local function matchTemplate(text,template)
 if not S:Text(text) or #text>1024 or not S:Text(template) or #template>512 then return nil end
 local pattern,order={},{};local i,index=1,0
 while i<=#template do
  local tail=template:sub(i)
  local positional,kind=tail:match("^%%(%d+)%$([sd])")
  local token=positional and ("%"..positional.."$"..kind) or tail:match("^%%[sd]")
  if token then
   index=index+1;order[index]=positional and tonumber(positional) or index
   if order[index]>8 then return nil end
   pattern[#pattern+1]=token:sub(-1)=="d" and "(%d+)" or "(.-)";i=i+#token
  elseif tail:sub(1,2)=="%%" then pattern[#pattern+1]="%%";i=i+2
  else
   local c=template:sub(i,i)
   pattern[#pattern+1]=c:match("[%^%$%(%)%%%.%[%]%*%+%-%?]") and "%"..c or c;i=i+1
  end
 end
 local matches={text:match("^"..table.concat(pattern).."$")}
 if #matches==0 then return nil end
 local result={};for n,value in ipairs(matches) do result[order[n] or n]=value end
 return result
end
N.MatchTemplate=matchTemplate
local function selfLoot(text)
 for _,key in ipairs({"LOOT_ITEM_SELF_MULTIPLE","LOOT_ITEM_SELF","LOOT_ITEM_PUSHED_SELF_MULTIPLE","LOOT_ITEM_PUSHED_SELF","LOOT_ITEM_CREATED_SELF_MULTIPLE","LOOT_ITEM_CREATED_SELF"}) do
  local match=matchTemplate(text,_G[key])
  if match and match[1] then
   local itemID=match[1]:match("|Hitem:(%d+):")
   if itemID then
    local count=match[2] and tonumber(match[2]) or 1
    if S:Number(count) and count>=1 and count<=999999 then return match[1],itemID,count end
   end
  end
 end
end
local function professionName(name)
 if not S:Text(name) or type(GetProfessions)~="function" or type(GetProfessionInfo)~="function" then return false end
 local ok,a,b,c,d,e,f=pcall(GetProfessions);if not ok then return false end
 for _,index in pairs({a,b,c,d,e,f}) do
  if S:Number(index) then
   local value,status=S:Public(GetProfessionInfo,"string",index)
   if status=="KNOWN" and value==name then return true end
  end
 end
 return false
end
function N:Initialize()
 self.frame=M:TrackRoot(self.id,M.UI:Card(UIParent,340,172),true)
 -- Transparent presentation region; each active message has its own quiet line.
 self.frame:SetBackdropColor(0,0,0,0);self.frame:SetBackdropBorderColor(0,0,0,0)
 -- This is a transparent feed, not a themed card. Theme refresh must not
 -- turn its full edit region into an opaque live panel.
 M.UI.backdrops[self.frame]=nil
 self.surface={id="Notifications.feed",module=self.id,frame=self.frame,security="OWNED_VISUAL",groups={notifications=true},fallback="HIDDEN",editable=true,minWidth=220,minHeight=60,layout={x=.14,y=-.10,width=340,height=172,scale=1}}
 self.surface.Intent=function()
  if N:IsOccluded() then return "HIDDEN","NATIVE_TASK_OCCLUSION",1 end
  return #N.rows>0 and "VISIBLE" or "HIDDEN","ACTIVITY_FEED",1
 end
 self.surface.OnLayout=function()
  -- Paint owns toast/label geometry, including a same-size layout reapply.
  -- Invalidate its small cache instead of writing a competing label width.
  for _,toast in ipairs(N.toasts or {}) do toast.render.width=nil end
 end
 M.CVE:Register(self.surface);M.Layout:Apply(self.surface)
 self.lines={};self.toasts={}
 for i=1,4 do
  local toast=CreateFrame("Frame",nil,self.frame,"BackdropTemplate");toast:EnableMouse(false)
  toast:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
  toast:SetBackdropColor(.025,.032,.041,.78);toast:SetBackdropBorderColor(.29,.34,.37,.36)
  local accent=toast:CreateTexture(nil,"BORDER");accent:SetPoint("TOPLEFT",1,-1);accent:SetPoint("BOTTOMLEFT",1,1);accent:SetWidth(2)
  local category=M.UI:Text(toast,"",10,-5,9,310);category.mirageSemanticColor=true
  local line=M.UI:Text(toast,"",10,-18,14,316);line:SetHeight(30);line.mirageSemanticColor=true
  local life=toast:CreateTexture(nil,"BORDER");life:SetPoint("BOTTOMLEFT",3,1);life:SetHeight(1)
  self.toasts[i]={frame=toast,accent=accent,category=category,life=life,render={}};self.lines[i]=line;toast:Hide()
 end
 -- Only visible, active receipts animate. Text/layout and occlusion retain
 -- their bounded event/tick work; the thin lifetime rule follows render time.
 self.frame:SetScript("OnUpdate",function() N:Animate(S:Now()) end)
 self.status="READY_SELF_SYSTEM_EVENTS";self:StyleCombatText()
end
function N:IsOccluded()
 return M.DisplayOcclusion and self.frame and M.DisplayOcclusion:Blocks(self.frame,true)==true or false
end
function N:UpdateOcclusion(now)
 local blocked=self:IsOccluded()
 if blocked then
  -- Only the newest unexpired local receipt survives an overlapping task.
  -- Retain its original deadline: a long task never replays an old backlog.
  while #self.rows>1 do table.remove(self.rows,1);self.dropped=self.dropped+1 end
 elseif self.occluded then
  for _,row in ipairs(self.rows) do row.born=now end
 end
 if blocked~=self.occluded then self.occluded=blocked;M.state.forceEvaluate=true end
 return blocked
end
function N:Emit(kind,text,key,count,life)
 if not M:IsModuleActive(self.id) or not colors[kind] or not S:Text(text) or #text>512 then return false end
 local cfg=M:ModuleConfig(self.id);if not cfg[kind] then return false end
 local now=S:Now();count=count or 1
 life=S:Number(life) and math.max(.22,math.min(8,life)) or cfg.duration
 local blocked=self:UpdateOcclusion(now)
 for _,row in ipairs(self.rows) do
  if row.kind==kind and row.key==key and now-row.time<1.2 then
   row.count=math.min(999999,row.count+count);row.time=now;row.life=life;row.expires=now+life;self:Paint(now);return true
  end
 end
 local capacity=blocked and 1 or cfg.maxRows
 while #self.rows>=capacity do table.remove(self.rows,1);self.dropped=self.dropped+1 end
 self.rows[#self.rows+1]={kind=kind,text=text,key=key,count=count,time=now,born=now,life=life,expires=now+life}
 self.delivered=self.delivered+1
 -- A feed-only intent, not an interaction lease: explicit context preferences
 -- can suppress receipts without a loot event waking any unrelated display.
 M.state.forceEvaluate=true
 self:Paint(now);return true
end
function N:OnEvent(event,text)
 if event=="PLAYER_ENTERING_WORLD" or event=="PLAYER_LEAVING_WORLD" then
  self.rows={};self.occluded=nil;self:Paint(S:Now());M.state.forceEvaluate=true
  if event=="PLAYER_ENTERING_WORLD" then self:StyleCombatText() end
  return
 end
 if event=="ADDON_LOADED" then self:StyleCombatText();return end
 if event=="PLAYER_LEVEL_UP" then
  if S:Number(text) and text>=1 and text<=999 then self:Emit("status","Level "..text,"level:"..text,1,8) end
  return
 end
 if not S:Text(text) then return end
 if event=="CHAT_MSG_LOOT" then
  local link,id,count=selfLoot(text)
  if link then self:Emit("loot",link,"item:"..link,count) end
 elseif event=="CHAT_MSG_MONEY" then
  local match=matchTemplate(text,_G.YOU_LOOT_MONEY) or matchTemplate(text,_G.LOOT_MONEY_SPLIT)
  if match and match[1] and #match[1]<=240 then self:Emit("money","+ "..match[1],"receipt:"..match[1],1) end
 elseif event=="CHAT_MSG_SKILL" then
  local match=matchTemplate(text,_G.SKILL_RANK_UP)
  if match and professionName(match[1]) and match[2] and match[2]:match("^%d+$") then
   self:Emit("profession",match[1].."  •  "..match[2],"profession:"..match[1]..":"..match[2],1)
  end
 elseif event=="CHAT_MSG_COMBAT_FACTION_CHANGE" then
  -- Native COMBAT_TEXT_UPDATE/FACTION already paints this receipt when its
  -- dedicated preference is enabled. Keep one renderer without changing any
  -- native text category or suppressing other combat/status information.
  local native,state=S:Public(C_CVar and C_CVar.GetCVar,"string","floatingCombatTextRepChanges_v2")
  self.reputationRoute=state=="KNOWN" and native=="0" and "CUSTOM_PUBLIC_RECEIPT" or "NATIVE_REPUTATION_FALLBACK"
  if self.reputationRoute=="CUSTOM_PUBLIC_RECEIPT" then self:Emit("status",text,"reputation:"..text,1) end
 end
end
function N:Paint(now)
 local cfg=M:ModuleConfig(self.id)
 local height=math.max(44,cfg.textSize*2+18)
 local available=self.frame and self.frame:GetHeight() or 172
 local width=self.frame and self.frame:GetWidth() or 340
 local capacity=math.max(1,math.min(cfg.maxRows,math.floor((available-8)/(height+6))))
 -- A deliberately short notification region keeps the newest receipts visible.
 local first=math.max(0,#self.rows-capacity)
 local font=STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"
 local fontGeneration=M.UI.fontRefreshGeneration or 0
 for i,line in ipairs(self.lines or {}) do
  local row=self.rows[first+i]
  local toast=self.toasts[i];local f=toast.frame;local rendered=toast.render
  -- Receipt changes do not require repeated layouts, text replacement or
  -- font submissions. Per-render lifetime animation is isolated below.
  if rendered.width~=width or rendered.height~=height then
   f:ClearAllPoints();f:SetPoint("TOPLEFT",4,-4-(i-1)*(height+6));f:SetSize(math.max(120,width-8),height)
   line:SetHeight(height-21);line:SetWidth(math.max(96,width-28))
   rendered.width=width;rendered.height=height
  end
  if row and i<=capacity then
   if rendered.font~=font or rendered.fontSize~=cfg.textSize or rendered.fontGeneration~=fontGeneration then
    line:SetFont(font,cfg.textSize,"")
    rendered.font=font;rendered.fontSize=cfg.textSize;rendered.fontGeneration=fontGeneration
   end
   if rendered.text~=row.text or rendered.count~=row.count then
    line:SetText(row.text..(row.count>1 and ("  ×"..row.count) or ""))
    rendered.text=row.text;rendered.count=row.count
   end
   if rendered.kind~=row.kind then
    local c=colors[row.kind]
    line:SetTextColor(unpack(c));toast.category:SetText(labels[row.kind]);toast.category:SetTextColor(.66,.72,.74,1)
    toast.accent:SetColorTexture(c[1],c[2],c[3],.9);toast.life:SetColorTexture(c[1],c[2],c[3],.45)
    rendered.kind=row.kind
   end
   toast.activeRow=row;toast.lifeSpan=row.life or cfg.duration
   toast.lifeTrack=math.max(1,width-14)
   if rendered.shown~=true then f:Show();rendered.shown=true end
  else
   toast.activeRow=nil
   if rendered.shown~=false then f:Hide();rendered.shown=false end
   if rendered.text~="" then line:SetText("");rendered.text="";rendered.count=nil end
  end
 end
 self:Animate(now)
end
function N:Animate(now)
 -- Four passive Mirage rows at most; never inspect game objects or relayout
 -- native frames here. A fractional width on each render removes the visible
 -- staircase caused by the former scheduler-driven 20 Hz lifetime updates.
 local fade=math.max(.12,M.profile and M.profile.fade or .22)
 for _,toast in ipairs(self.toasts or {}) do
  local row,rendered=toast.activeRow,toast.render
  if row and rendered.shown then
   local remaining=math.max(0,row.expires-now)
   local fraction=math.max(0,math.min(1,remaining/(toast.lifeSpan or 4)))
   local width=math.max(.01,(toast.lifeTrack or 1)*fraction)
   if rendered.lifeWidth~=width then toast.life:SetWidth(width);rendered.lifeWidth=width end
   local alpha=math.max(0,math.min(1,remaining/fade,(now-(row.born or row.time))/fade))
   if rendered.alpha~=alpha then toast.frame:SetAlpha(alpha);rendered.alpha=alpha end
  end
 end
end
function N:Tick(now)
 if now<(self.nextPaint or 0) then return end;self.nextPaint=now+.05
 local changed=false
 for i=#self.rows,1,-1 do if now>=self.rows[i].expires then table.remove(self.rows,i);changed=true end end
 if #self.rows>0 or self.occluded then self:UpdateOcclusion(now) end
 if changed then M.state.forceEvaluate=true end
 if #self.rows>0 or changed then self:Paint(now) end
end
local function fontState(font)
 if not font or not S:Readable(font) or type(font.GetFont)~="function" then return nil end
 local ok,path,size,flags=pcall(font.GetFont,font)
 if not ok or not S:Text(path) or not S:Number(size) or not S:Text(flags or "") then return nil end
 return {path,size,flags or ""}
end
local function same(a,b) return a and b and a[1]==b[1] and a[2]==b[2] and a[3]==b[3] end
function N:RestoreFonts()
 if not next(self.fontLeases) then self.fontRestorePending=false;return true end
 if self.fontRestoring or S:InCombat() then self.fontRestorePending=true;return false end
 self.fontRestoring=true
 for _,name in ipairs({"CombatTextFont","CombatTextFontOutline"}) do
  local lease=self.fontLeases[name]
  if lease then
   if S:InCombat() then break end
   local current=fontState(_G[name])
   -- Both getters and setters may run callbacks. Recheck each object's lease,
   -- global identity and combat state immediately before the next mutation.
   if self.fontLeases[name]==lease then
    if _G[name]~=lease.font then self.fontLeases[name]=nil
    elseif current and same(current,lease.original) then self.fontLeases[name]=nil
    elseif current and not same(current,lease.written) then self.fontLeases[name]=nil
    elseif current and not S:InCombat() then
     pcall(lease.font.SetFont,lease.font,unpack(lease.original))
     if self.fontLeases[name]==lease and _G[name]==lease.font and not S:InCombat() then
      local after=fontState(lease.font)
      if self.fontLeases[name]==lease and _G[name]==lease.font and same(after,lease.original) then self.fontLeases[name]=nil end
     end
    end
   end
  end
 end
 self.fontRestoring=false;self.fontRestorePending=next(self.fontLeases)~=nil
 if not self.fontRestorePending then self.fontRetryCount=0 end
 return not self.fontRestorePending
end
function N:RetryFonts(now)
 if not self.fontRestorePending or S:InCombat() or now<(self.fontRetryAt or 0) or (self.fontRetryCount or 0)>=3 then return end
 self.fontRetryAt=now+.5;self.fontRetryCount=(self.fontRetryCount or 0)+1
 self:RestoreFonts()
end
function N:StyleCombatText()
 if M.WorldCombatText then M.WorldCombatText:Apply() end
 if self.fontRestoring or S:InCombat() then return end
 local cfg=M:ModuleConfig(self.id)
 if not cfg.combatText or not M:IsModuleActive(self.id) then self:RestoreFonts();return end
 local count=0
 for _,name in ipairs({"CombatTextFont","CombatTextFontOutline"}) do
  if S:InCombat() or cfg~=M:ModuleConfig(self.id) or not M:IsModuleActive(self.id) then break end
  local font=_G[name];local current=fontState(font);local old=self.fontLeases[name]
  if _G[name]==font and current and type(font.SetFont)=="function" and (not old or old.font==font and same(current,old.written))
   and not S:InCombat() and cfg==M:ModuleConfig(self.id) and M:IsModuleActive(self.id) then
   local original=old and old.original or current
   local written={STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",cfg.combatTextSize,"OUTLINE"}
   local lease={font=font,original=original,written=written};self.fontLeases[name]=lease
   local ok=pcall(font.SetFont,font,unpack(written))
   if self.fontLeases[name]==lease and _G[name]==font and not S:InCombat() then
    local after=fontState(font)
    if self.fontLeases[name]==lease and _G[name]==font then
     if ok and same(after,written) then count=count+1
     elseif same(after,original) then self.fontLeases[name]=nil
     else self.fontRestorePending=true end
    end
   else self.fontRestorePending=true end
  end
 end
 self.combatTextStatus=count>0 and "NATIVE_SCROLLING_FONT_STYLED" or "WAITING_FOR_NATIVE_SCROLLING_TEXT"
end
function N:ApplyConfig()
 if self.receiptProfile~=M.profile then self.rows={};self.occluded=nil;self.receiptProfile=M.profile end
 self:StyleCombatText();M.Layout:Apply(self.surface)
 while #self.rows>M:ModuleConfig(self.id).maxRows do table.remove(self.rows,1) end
 self:Paint(S:Now())
end
function N:Resume() self:ApplyConfig() end
function N:Suspend()
 self.fontRetryCount=0;self.fontRetryAt=nil
 local worldRestored=true
 if M.WorldCombatText then M.WorldCombatText.retryCount=0;M.WorldCombatText.retryAt=nil;worldRestored=M.WorldCombatText:Restore() end
 self.rows={};self.occluded=nil;self:Paint(S:Now());self.surface.interactingUntil=nil;local restored=self:RestoreFonts();M.Effects:Stop(self.surface);return restored and worldRestored
end
M:RegisterModule("Notifications",N)
