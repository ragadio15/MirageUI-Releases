-- Original display-only native private-aura anchors. The addon never reads their contents.
local _, M = ...
local A=M.modules.Auras
local S=M.Safety
M.PrivateAuras={ids={},status="DISABLED"}
local P=M.PrivateAuras
local ownedFrame,ownedSurface

function P:Available()
    if not S:Readable(C_UnitAuras) then return false end
    return C_UnitAuras and type(S:Field(C_UnitAuras,"AddPrivateAuraAnchor"))=="function"
        and type(S:Field(C_UnitAuras,"RemovePrivateAuraAnchor"))=="function"
end
function P:Create()
    if ownedSurface or not S:Readable(self.frame) or self.frame or S:InCombat() then return end
    self.frame=M:TrackRoot("Auras",CreateFrame("Frame","MirageUIPrivateAuraAnchor",UIParent))
    self.frame:SetSize(152,44);S:Passive(self.frame);self.frame:Hide()
    self.surface={id="Auras.private",module="Auras",frame=self.frame,security="NATIVE_READ_ONLY",groups={},
        fallback="VISIBLE",editable=true,minWidth=80,minHeight=40,layout={x=0,y=.26,width=152,height=44,scale=1}}
    ownedFrame,ownedSurface=self.frame,self.surface
    M.CVE:Register(self.surface)
end
local function frameCurrent(self)
    -- Native private content can protect its exact addon-owned anchor parent.
    -- Registration, removal and presentation changes already defer out of combat;
    -- a public-tree refusal here would retire a correctly registered anchor.
    return ownedSurface and S:Frame(ownedFrame,false) and S:Readable(self.frame) and self.frame==ownedFrame
        and S:Readable(ownedSurface.frame) and ownedSurface.frame==ownedFrame
        and S:Readable(self.surface) and self.surface==ownedSurface
        and S:Readable(M.surfaces["Auras.private"]) and M.surfaces["Auras.private"]==ownedSurface
end
-- Anchor handles belong to the registration provider. A replacement can
-- legitimately use the same integers for its own registrations.
local function ownerCurrent(self)
    return self.provider and S:Readable(C_UnitAuras) and C_UnitAuras==self.provider
        and S:Field(self.provider,"AddPrivateAuraAnchor")==self.addAnchor
        and S:Field(self.provider,"RemovePrivateAuraAnchor")==self.removeAnchor
end
local function remove(self)
    if S:InCombat() then self.pending=true;self.status="REMOVAL_DEFERRED";return false end
    if (self.removeFailures or 0)>=3 then self.status="REMOVAL_FAILED_RELOAD_REQUIRED";return false end
    local retained={}
    for _,id in ipairs(self.ids) do
        if S:InCombat() or not ownerCurrent(self) or not pcall(self.removeAnchor,id) then retained[#retained+1]=id end
    end
    self.ids=retained;self.pending=#retained>0
    if not S:InCombat() and frameCurrent(self) then self.frame:Hide() end
    if self.pending then
        self.removeFailures=(self.removeFailures or 0)+1
        self.status=self.removeFailures>=3 and "REMOVAL_FAILED_RELOAD_REQUIRED" or "REMOVAL_PENDING";self.retryAt=S:Now()+2
    else
        self.status="DISABLED";self.signature=nil;self.removeFailures=0
        self.provider,self.addAnchor,self.removeAnchor=nil,nil,nil
    end
    return not self.pending
end
local function showRegistered(self)
    if not frameCurrent(self) then
        if remove(self) then self.status="ANCHOR_FRAME_UNAVAILABLE" end
        return
    end
    self.status="NATIVE_ANCHORS_REGISTERED_NOT_CERTIFIED"
    self.frame:Show()
    if self.queued or not ownerCurrent(self) or not frameCurrent(self) then remove(self) end
end
local function configure(self)
    if S:InCombat() then self.reconfigure=true;return end
    self.reconfigure=nil
    local cfg=M:ModuleConfig("Auras")
    local wanted=M:IsModuleActive("Auras") and cfg.privateAuras==true
    if not wanted then remove(self);return end
    if not self:Available() then
        if remove(self) then self.status="UNSUPPORTED" end
        return
    end
    local signature=cfg.privateCount..":"..cfg.privateSize
    if self.signature==signature and #self.ids==cfg.privateCount and not self.pending and ownerCurrent(self) then
        showRegistered(self);return
    end
    if not remove(self) or self.queued then return end
    self:Create()
    if not frameCurrent(self) then self.status="ANCHOR_FRAME_UNAVAILABLE";return end
    local size=cfg.privateSize;local gap=6
    self.surface.minWidth=cfg.privateCount*size+(cfg.privateCount-1)*gap+8
    self.surface.minHeight=size+8
    self.surface.layout.width=self.surface.minWidth;self.surface.layout.height=self.surface.minHeight
    M.Layout:Apply(self.surface)
    -- All slots use the player token. No guessing, aura enumeration or anchor introspection.
    if self.queued then return end
    if not self:Available() then self.status="UNSUPPORTED";return end
    if S:InCombat() then self.reconfigure=true;self.status="REGISTRATION_DEFERRED";return end
    if not frameCurrent(self) then self.status="ANCHOR_FRAME_UNAVAILABLE";return end
    self.provider=C_UnitAuras
    self.addAnchor,self.removeAnchor=self.provider.AddPrivateAuraAnchor,self.provider.RemovePrivateAuraAnchor
    for i=1,cfg.privateCount do
        local args={unitToken="player",auraIndex=i,parent=self.frame,showCooldownFrame=true,showCooldownEdge=false,
            showCountdownNumbers=true,showDispelIcon=true,isContainer=false,
            iconInfo={iconAnchor={point="CENTER",relativeTo=self.frame,relativePoint="CENTER",offsetX=(i-(cfg.privateCount+1)/2)*(size+gap),offsetY=0},
                iconWidth=size,iconHeight=size,borderScale=1}}
        local ok,id=pcall(self.addAnchor,args)
        if not ok or not S:Number(id) or id<0 or id%1~=0 then
            if remove(self) then self.status="REGISTRATION_FAILED" end;return
        end
        self.ids[#self.ids+1]=id
        if self.queued or not ownerCurrent(self) or S:InCombat() or not frameCurrent(self) then
            remove(self);return
        end
    end
    self.signature=signature;showRegistered(self)
end
-- A native call may synchronously invoke Suspend or ApplyConfig. Only one
-- operation edits the handle list. Defer the latest request to the existing
-- retry route, after handling any handle returned by the interrupted add.
local function run(self,action,request)
    if self.busy then self.queued=request;return false end
    self.busy=true
    local ok,result=pcall(action,self)
    self.busy=nil
    if self.queued then
        self.reconfigure=self.queued=="configure" or nil
        self.queued=nil
        self.pending=true
        self.retryAt=S:Now()+2
    end
    if not ok then
        self.pending=true
        self.retryAt=S:Now()+2
        self.removeFailures=(self.removeFailures or 0)+1
        self.status=self.removeFailures>=3 and "REMOVAL_FAILED_RELOAD_REQUIRED" or "REMOVAL_PENDING"
        error("PRIVATE_ANCHOR_OPERATION_FAILED",0)
    end
    return result
end
function P:Remove() return run(self,remove,"stop") end
function P:Configure() run(self,configure,"configure") end
local function stop(self)
    self.reconfigure=nil
    return remove(self)
end
function P:Stop() return run(self,stop,"stop") end
function P:Retry()
    if S:InCombat() then return end
    if self.pending and (self.removeFailures or 0)<3 and S:Now()>=(self.retryAt or 0) then self:Remove() end
    if self.reconfigure and not self.pending then self:Configure() end
end
local oldApply,oldSuspend=A.ApplyConfig,A.Suspend
function A:ApplyConfig() oldApply(self);P:Configure() end
function A:Suspend() oldSuspend(self);P:Stop() end
