local _, M = ...
-- Shared adapter mechanics. Each registration declares its own exact native frame list.
function M:CreateNativeModule(id,names,groups,dim)
    local mod={names=names,groups=groups,dim=dim,surfaces={},events={ADDON_LOADED=true,PLAYER_ENTERING_WORLD=true,PLAYER_REGEN_ENABLED=true}}
    function mod:Initialize() self:Refresh() end
    function mod:Refresh()
        if M.NativeWindowPolicy and M.NativeWindowPolicy:ModuleNative(id) then
            M.Native:Restore(id);self.nativeSurfaces=0;self.styledSurfaces=0;self.status="NATIVE_BY_DESIGN";return
        end
        if M.Native:Conflict() then M.Native:Restore(self.id or id);self.status="CONFLICT_NATIVE_OWNER";return end
        local found,styled=0,0
        for _,name in ipairs(self.names) do
            local frame=_G[name]
            if frame and (not self.surfaces[name] or self.surfaces[name].frame~=frame) then
                local surface=M.Native:Acquire(id,id.."."..name,frame,self.groups,self.dim)
                if surface then self.surfaces[name]=surface end
            end
            if frame and self.surfaces[name] and self.surfaces[name].frame==frame then
                found=found+1
                if M:ModuleConfig(id).style and M.Native:Decorate(id,frame) then styled=styled+1 end
            end
        end
        self.nativeSurfaces,self.styledSurfaces=found,styled
        self.status=found==0 and "WAITING_FOR_NATIVE_SURFACE" or styled==found and "MIRAGE_PANELS_NATIVE_CONTENT"
            or styled>0 and "MIRAGE_PANELS_PARTIAL" or "NATIVE_CONTENT_PRESERVED"
    end
    function mod:OnEvent() self:Refresh() end
    function mod:ApplyConfig() if not M:ModuleConfig(id).style then M.Native:Undecorate(id) end;self:Refresh() end
    function mod:Suspend() M.Native:Restore(id) end
    function mod:Resume() self:Refresh() end
    self:RegisterModule(id,mod)
    return mod
end
M:CreateNativeModule("Minimap",{"MinimapCluster"},{navigation=true},true)
M:CreateNativeModule("QuestTracker",{"ObjectiveTrackerFrame"},{objectives=true},true)
M:CreateNativeModule("BlizzardSkin",{"CharacterFrame","SpellBookFrame","PlayerSpellsFrame","GossipFrame","QuestFrame","MerchantFrame","MailFrame","FriendsFrame"},{tasks=true},false)
M:CreateNativeModule("Bags",{"ContainerFrameCombinedBags","ContainerFrame1","ContainerFrame2","ContainerFrame3","ContainerFrame4","ContainerFrame5","BankFrame"},{bags=true},false)
local chat=M:CreateNativeModule("Chat",{"ChatFrame1","ChatFrame2","ChatFrame3","ChatFrame4","ChatFrame5","ChatFrame6","ChatFrame7"},{chat=true},true)
function chat:Tick(now)
    if now<(self.nextRead or 0) then return end;self.nextRead=now+.2
    -- The fallback keeps the same local input rule as custom chat. A native
    -- settings/search box must not hold every unrelated chat window open.
    local activity=M.ScopedActivity;if not activity then return end
    for _,surface in pairs(self.surfaces) do
        if activity:ChatTyping(surface.frame) then surface.interactingUntil=now+.4 end
    end
end
-- The passive child follows its tooltip parent's visibility. No styling work
-- runs inside a native OnShow callback or changes tooltip hover ownership.
M:CreateNativeModule("Tooltips",{"GameTooltip","ItemRefTooltip","ShoppingTooltip1","ShoppingTooltip2"},{tasks=true},false)
