-- Optional exact-ID preparation list attached to the existing Auras module.
local _, M = ...
local A=M.modules.Auras
local oldInit,oldApply,oldResume,oldSuspend,oldEvent,oldTick,oldWants = A.Initialize,A.ApplyConfig,A.Resume,A.Suspend,A.OnEvent,A.Tick,A.WantsEvent
local S=M.Safety
A.events.PLAYER_REGEN_DISABLED=true
A.events.PLAYER_REGEN_ENABLED=true
A.events.SPELLS_CHANGED=true

function A:CreatePreparation()
    if self.preparationFrame or S:InCombat() then return end
    local f=M:TrackRoot(self.id,M.UI:Card(UIParent,280,100));f:Hide()
    self.preparationFrame=f
    self.preparationTitle=M.UI:Text(f,"Preparation",10,-8,12,260)
    self.preparationRows={}
    for i=1,8 do
        local row={ name=M.UI:Text(f,"",10,-30-(i-1)*27,11,164), status=M.UI:Text(f,"",178,-30-(i-1)*27,10,92) }
        row.status.mirageSemanticColor=true -- RefreshPreparation owns this status color, not chrome themes.
        self.preparationRows[i]=row
    end
    self.preparationFooter=M.UI:Text(f,"",10,-75,10,260)
    self.preparationSurface={id="Auras.preparation",module=self.id,frame=f,security="OWNED_VISUAL",groups={preparation=true},
        fallback="HIDDEN",outOfCombatOnly=true,editable=true,holdOnHover=true,minWidth=240,minHeight=88,
        layout={x=-.32,y=.13,width=280,height=118,scale=1}}
    self.preparationSurface.OnLayout=function(_,l)
        self.preparationTitle:SetWidth(l.width-20)
        self.preparationFooter:SetWidth(l.width-20);self.preparationFooter:ClearAllPoints();self.preparationFooter:SetPoint("BOTTOMLEFT",10,8)
        for _,row in ipairs(self.preparationRows) do row.name:SetWidth(l.width-116);row.status:ClearAllPoints();row.status:SetPoint("TOPLEFT",row.name,"TOPRIGHT",8,0) end
    end
    M.CVE:Register(self.preparationSurface)
end
function A:ClearPreparation(reason)
    self.preparationState=reason or "DISABLED"
    if not self.preparationFrame then return end
    for _,r in ipairs(self.preparationRows) do r.name:SetText("");r.status:SetText("") end
    self.preparationFooter:SetText("")
    self.preparationData=nil
    M.Effects:Stop(self.preparationSurface)
end
function A:ConfigurePreparation()
    if S:InCombat() then return end
    local cfg=M:ModuleConfig(self.id)
    if cfg.preparation then self:CreatePreparation() end
    if not self.preparationFrame then return end
    self.preparationSurface.disabled=not cfg.preparation or #cfg.reminders==0
    self.preparationSurface.layout.height=62+math.max(1,#cfg.reminders)*27
    self.preparationSurface.minHeight=self.preparationSurface.layout.height
    self:ClearPreparation(cfg.preparation and "WAITING" or "DISABLED")
    self.preparationDirty=true;self.preparationNext=0
    M.Layout:Apply(self.preparationSurface)
end
function A:RefreshPreparation()
    local cfg=M:ModuleConfig(self.id)
    if not cfg.preparation or #cfg.reminders==0 or S:InCombat() then self:ClearPreparation("COMBAT_OR_DISABLED");return end
    local data=M.PreparationSnapshot:Read(cfg.reminders)
    self.preparationState=data.state
    local missing=false
    for i,r in ipairs(self.preparationRows) do
        local entry=data.entries[i]
        local meta=entry and M.PreparationSnapshot:Describe(entry.id)
        r.name:SetText(meta and meta.name or entry and ("Spell "..entry.id) or "")
        local state=entry and entry.state
        r.status:SetText(state=="PRESENT" and "Present" or state=="NOT_OBSERVED" and "Not observed" or entry and "Unavailable" or "")
        if state=="NOT_OBSERVED" then missing=true end
        r.status:SetTextColor(state=="PRESENT" and .5 or .86,state=="PRESENT" and .84 or .78,.7,1)
    end
    self.preparationFooter:SetText("Exact buff IDs · outside combat only")
    self.preparationData=nil -- no retained live aura list or timestamps
    self.preparationSurface.checklistNeedsAttention=data.state~="COMPLETE_PUBLIC_SCAN" or missing
    -- Updating a checklist is not user input. Visibility remains governed by
    -- its explicit configuration, pins and an actual visible interaction.
    M.state.forceEvaluate=true
end
function A:WantsEvent(event)
    if event=="UNIT_AURA" or event=="SPELLS_CHANGED" then
        return M:ModuleConfig(self.id).preparation or (oldWants and oldWants(self,event))
    end
    return not oldWants or oldWants(self,event)
end
function A:Initialize() oldInit(self);self:ConfigurePreparation() end
function A:ApplyConfig() oldApply(self);self:ConfigurePreparation() end
function A:Resume() if oldResume then oldResume(self) end;self.preparationDirty=true end
function A:Suspend() if oldSuspend then oldSuspend(self) end;self:ClearPreparation("DISABLED") end
function A:OnEvent(event,unit,...)
    if oldEvent then oldEvent(self,event,unit,...) end
    if event=="PLAYER_REGEN_DISABLED" or event=="PLAYER_LEAVING_WORLD" then self:ClearPreparation("COMBAT_PAUSED") end
    if event~="UNIT_AURA" or (S:Text(unit) and unit=="player") then self.preparationDirty=true end
end
function A:Tick(now)
    if oldTick then oldTick(self,now) end
    if not self.preparationFrame or self.preparationSurface.disabled then return end
    if S:InCombat() then self:ClearPreparation("COMBAT_PAUSED");return end
    -- Event-coalesced, at most two bounded scans per second, and no scan while the module is inactive.
    if self.preparationDirty and now>=(self.preparationNext or 0) then
        self.preparationDirty=false;self.preparationNext=now+.5;self:RefreshPreparation()
    end
end
