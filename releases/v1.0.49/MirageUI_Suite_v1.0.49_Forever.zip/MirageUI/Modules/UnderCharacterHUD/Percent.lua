local _,M=...
-- HUD47: authored typography probes and opaque native text are strictly separate.
-- A successful submission is not proof of native paint or current game truth.
local P,S={},M.Safety;M.HUDPercent=P
local keys={"health","resource"}
local samples={};for i=0,100 do samples[#samples+1]=string.format("%d%%",i) end
local function clear(row,reason)
    row.status=reason;row.ready=false
    for _,font in ipairs({row.font,row.copyFont}) do pcall(font.SetText,font,"");pcall(font.Hide,font) end
end
function P:Invalidate(view,reason)
    if not view then return end
    view.percentGeneration=(view.percentGeneration or 0)+1
    view.percentSeal=nil
    for _,row in pairs(view.percent or {}) do clear(row,reason or "FIT_PENDING") end
end
function P:Status(view,key)
    local row=view and view.percent and view.percent[key]
    return row and row.status or "DISABLED"
end
local function equalPublic(a,b) return S:Readable(a) and a==b end
local function fontMatches(f,font,size)
    local ok,path,height,flags=pcall(f.GetFont,f)
    return ok and S:Text(path) and S:Number(height) and S:Text(flags) and path==font and height==size and flags==""
end
local function configureFont(f,font,size,width,height)
    if f:SetFont(font,size,"")~=true then return false end
    f:SetTextScale(1);f:SetIgnoreParentScale(false)
    f:SetWordWrap(false);f:SetNonSpaceWrap(false);f:SetIndentedWordWrap(false);f:SetMaxLines(1);f:SetSpacing(0)
    f:SetShadowOffset(0,0);f:SetShadowColor(0,0,0,0)
    f:SetJustifyH("CENTER");f:SetJustifyV("MIDDLE");f:SetSize(width,height)
    return fontMatches(f,font,size) and equalPublic(f:GetTextScale(),1) and equalPublic(f:IsIgnoringParentScale(),false)
end
local function current(view,q)
    local ok,scale=pcall(view.content.GetEffectiveScale,view.content)
    return ok and S:Number(scale) and scale==q.effectiveScale and view.percentSeal==q and view.percentGeneration==q.generation and M.Client.allowed==true and
        M.Client.key==q.client and STANDARD_TEXT_FONT==q.fontGlobal and M.profile==q.profile and
        M.profile.textScale==q.profileScale and q.cfg.showPercent==true and q.cfg.percentTextSize==q.textSize and
        q.cfg.percentTextOpacity==q.opacity and q.cfg.width==q.width and q.cfg.healthHeight==q.healthHeight and
        q.cfg.resourceHeight==q.resourceHeight and q.cfg.hudScale==q.hudScale
end
local function probeMatches(view,q,text)
    local f=view.percentProbe
    return current(view,q) and S:Frame(f,false) and fontMatches(f,q.font,q.size) and
        equalPublic(f:GetParent(),view.percentProbeRoot) and equalPublic(f:IsShown(),false) and
        equalPublic(view.percentProbeRoot:IsShown(),false) and equalPublic(view.percentProbeRoot:GetParent(),view.content) and
        equalPublic(view.percentProbeRoot:GetScale(),1) and equalPublic(f:GetScale(),1) and equalPublic(f:GetEffectiveScale(),q.effectiveScale) and
        equalPublic(f:GetTextScale(),1) and equalPublic(f:IsIgnoringParentScale(),false) and equalPublic(f:GetText(),text) and
        equalPublic(f:GetWidth(),16384) and equalPublic(f:GetHeight(),16384) and
        equalPublic(f:CanWordWrap(),false) and equalPublic(f:CanNonSpaceWrap(),false) and
        equalPublic(f:GetIndentedWordWrap(),false) and equalPublic(f:GetMaxLines(),1) and equalPublic(f:GetSpacing(),0)
end
function P:Layout(view,cfg,textScale)
    self:Invalidate(view,"DISABLED")
    if cfg.showPercent~=true then return end
    view.percent=view.percent or {health={},resource={}}
    for _,key in ipairs(keys) do clear(view.percent[key],"FIT_UNAVAILABLE") end
    if not M.Client.allowed then return end
    if S:InCombat() then for _,key in ipairs(keys) do clear(view.percent[key],"FIT_PENDING") end;return end
    textScale=textScale or M.profile.textScale
    local font=STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"
    if not S:Text(font) or not S:Number(textScale) or textScale<.8 or textScale>1.5 then return end
    local effective,access=S:Public(view.content.GetEffectiveScale,"number",view.content)
    if access~="KNOWN" or effective<=0 then return end
    local q={effectiveScale=effective,generation=view.percentGeneration,cfg=cfg,profile=M.profile,profileScale=M.profile.textScale,
        client=M.Client.key,font=font,fontGlobal=STANDARD_TEXT_FONT,size=cfg.percentTextSize*textScale,
        textSize=cfg.percentTextSize,opacity=cfg.percentTextOpacity,width=cfg.width,
        healthHeight=cfg.healthHeight,resourceHeight=cfg.resourceHeight,hudScale=cfg.hudScale}
    view.percentSeal=q
    local ok,measured=pcall(function()
        if not S:Frame(view.content,false) or not current(view,q) then return end
        -- One hidden, detached-from-game-data probe per view, reused on layout.
        if not view.percentProbeRoot then
            local root=CreateFrame("Frame",nil,view.content);root:Hide();M.Safety:Passive(root)
            root:SetScale(1);view.percentProbeRoot=root
        end
        if not view.percentProbe then view.percentProbe=view.percentProbeRoot:CreateFontString(nil,"OVERLAY") end
        local f=view.percentProbe;f:Hide();f:SetText("");f:SetScale(1)
        if not configureFont(f,font,q.size,16384,16384) then return end
        local width,height=0,0
        for _,text in ipairs(samples) do
            if S:InCombat() or not current(view,q) then return end
            f:SetText(text)
            if not probeMatches(view,q,text) then return end
            local w,h,line,cut=f:GetUnboundedStringWidth(),f:GetStringHeight(),f:GetLineHeight(),f:IsTruncated()
            if not probeMatches(view,q,text) or not S:Number(w) or not S:Number(h) or not S:Number(line) or
                w<=0 or h<=0 or line<=0 or w>16384 or h>16384 or line>16384 or not equalPublic(cut,false) then return end
            width=math.max(width,w);height=math.max(height,h,line)
        end
        f:SetText("")
        if not probeMatches(view,q,"") then return end
        return {width=width,height=height}
    end)
    if not ok or not measured or not current(view,q) then
        self:Invalidate(view,"FIT_UNAVAILABLE");return
    end
    for _,key in ipairs(keys) do
        local row=view.percent[key]
        -- Two horizontal UI units per edge; no vertical resizing or shrinking.
        if measured.width>cfg.width-4 or measured.height>cfg[key.."Height"] then clear(row,"DOES_NOT_FIT")
        else
            local painted,ready=pcall(function()
                if S:InCombat() or not current(view,q) or not S:Frame(view.rows[key],false) then return false end
                for i,bar in ipairs({view.rows[key],view.copies and view.copies[key]}) do
                    local field=i==1 and "font" or "copyFont"
                    if not row[field] then row[field]=bar:CreateFontString(nil,"OVERLAY") end
                    local fs=row[field];fs:Hide();fs:SetText("");fs:SetScale(1)
                    if not configureFont(fs,font,q.size,cfg.width-4,cfg[key.."Height"]) then return false end
                    fs:ClearAllPoints();fs:SetPoint("CENTER",bar,"CENTER",0,0)
                    fs:SetTextColor(1,1,1,cfg.percentTextOpacity/100)
                    if not (current(view,q) and fontMatches(fs,font,q.size) and equalPublic(fs:GetScale(),1) and equalPublic(fs:GetEffectiveScale(),q.effectiveScale) and
                        equalPublic(fs:GetTextScale(),1) and equalPublic(fs:IsIgnoringParentScale(),false) and equalPublic(fs:GetParent(),bar)) then return false end
                end
                return true
            end)
            row.ready=painted and ready==true
            row.status=row.ready and "FIT_READY" or "FIT_UNAVAILABLE"
            if not row.ready then clear(row,row.status) end
        end
    end
end
function P:Ready(view,cfg,key)
    local row=view.percent and view.percent[key];local q=view.percentSeal
    if not row or not row.ready then return false end
    -- Font identity is public configuration; never query live text/extent/fit.
    local ok,yes=pcall(function()
        if not (cfg==q.cfg and current(view,q)) then return false end
        for i,font in ipairs({row.font,row.copyFont}) do
            local bar=i==1 and view.rows[key] or view.copies and view.copies[key]
            if not (S:Frame(font,false) and fontMatches(font,q.font,q.size) and equalPublic(font:GetScale(),1) and equalPublic(font:GetEffectiveScale(),q.effectiveScale) and
                equalPublic(font:GetTextScale(),1) and equalPublic(font:IsIgnoringParentScale(),false) and equalPublic(font:GetParent(),bar)) then return false end
        end
        return row.font~=nil
    end)
    if not ok or not yes then clear(row,"FIT_PENDING");return false end
    return true
end
function P:Refresh(view,cfg,key,presented,powerType)
    local row=view.percent and view.percent[key]
    if not row then return end
    if not presented or not cfg[key] then
        for _,font in ipairs({row.font,row.copyFont}) do pcall(font.SetText,font,"");pcall(font.Hide,font) end
        row.status="ROW_NOT_PRESENTED";return
    end
    if not self:Ready(view,cfg,key) then return end
    local ok,status=true,"NATIVE_TEXT_SUBMITTED"
    for _,font in ipairs({row.font,row.copyFont}) do
        local good,why=M.HUDData:Percent(font,key,powerType)
        if not good then ok=false;status=why end
    end
    if not self:Ready(view,cfg,key) then return end
    row.status=status
    for _,font in ipairs({row.font,row.copyFont}) do if ok then font:Show() else font:Hide() end end
end
function P:Sample(view,cfg,key)
    local row=view.percent and view.percent[key]
    if not row or not self:Ready(view,cfg,key) then return end
    -- Authored demo text is never a fallback for missing live data.
    for _,font in ipairs({row.font,row.copyFont}) do font:SetText(key=="health" and "78%" or "62%");font:SetShown(cfg[key]==true) end
    row.status="DEMO_FIT_READY"
end
