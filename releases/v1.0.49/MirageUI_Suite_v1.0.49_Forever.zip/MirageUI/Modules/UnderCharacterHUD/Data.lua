local _, M = ...
M.HUDData = {}
local D,S=M.HUDData,M.Safety
function D:Health(bar,copy)
    if type(UnitHealth)~="function" or type(UnitHealthMax)~="function" then return false,"UNSUPPORTED" end
    local ok=pcall(function()
        -- Secret payloads go directly to native consumers; no formatting,
        -- division, equality tests, thresholds, persistence or CVE publication.
        local maximum,value=UnitHealthMax("player"),UnitHealth("player")
        bar:SetMinMaxValues(0,maximum);bar:SetValue(value)
        if copy then copy:SetMinMaxValues(0,maximum);copy:SetValue(value) end
    end)
    return ok,ok and "NATIVE_DISPLAY_SUBMITTED" or "DISPLAY_UNAVAILABLE"
end
function D:PrimaryType()
    local kind,status=S:Public(UnitPowerType,"number","player")
    if status~="KNOWN" or kind<0 or kind%1~=0 then return nil,"UNAVAILABLE" end
    local has,access=S:Public(UnitHasPowerType,"boolean","player",kind)
    if access=="KNOWN" and not has then return nil,"ABSENT" end
    -- A readable zero *capacity* is metadata, not a current-resource threshold.
    -- Never inspect restricted capacity or normalize an error into zero.
    if not S:InCombat() then
        local maximum,known=S:Public(UnitPowerMax,"number","player",kind)
        if known=="KNOWN" and maximum==0 then return nil,"ABSENT" end
    end
    return kind,"PRESENT"
end
function D:Power(bar,kind,copy)
    if not S:Number(kind) or type(UnitPower)~="function" or type(UnitPowerMax)~="function" then return false,"UNSUPPORTED" end
    local ok=pcall(function()
        local maximum,value=UnitPowerMax("player",kind),UnitPower("player",kind)
        bar:SetMinMaxValues(0,maximum);bar:SetValue(value)
        if copy then copy:SetMinMaxValues(0,maximum);copy:SetValue(value) end
    end)
    return ok,ok and "NATIVE_DISPLAY_SUBMITTED" or "DISPLAY_UNAVAILABLE"
end
function D:Cast(bar,kind)
    local fn
    if kind=="channel" or kind=="empower" then fn=UnitChannelDuration else fn=UnitCastingDuration end
    if type(fn)~="function" or type(bar.SetTimerDuration)~="function" then return false,"UNSUPPORTED" end
    local ok,d=pcall(fn,"player")
    if not ok then return false,"DURATION_UNAVAILABLE" end
    if S:Readable(d) and d==nil then return false,"NO_ACTIVE_DURATION" end
    local interpolation=Enum and Enum.StatusBarInterpolation and Enum.StatusBarInterpolation.Immediate
    local directions=Enum and Enum.StatusBarTimerDirection
    local direction
    if directions then if kind=="channel" then direction=directions.RemainingTime else direction=directions.ElapsedTime end end
    if (kind=="channel" or kind=="empower") and direction==nil then return false,"CHANNEL_DIRECTION_UNSUPPORTED" end
    local sent=pcall(bar.SetTimerDuration,bar,d,interpolation,direction)
    return sent,sent and "NATIVE_DURATION_SUBMITTED" or "DURATION_DISPLAY_UNAVAILABLE"
end
function D:CastName(font,kind)
    local fn=(kind=="channel" or kind=="empower") and UnitChannelInfo or UnitCastingInfo
    if type(fn)~="function" or not font or type(font.SetText)~="function" then return false end
    -- Restricted spell text goes directly into its supported native sink.
    -- Never inspect, format, measure, concatenate, or retain the payload.
    local ok=pcall(function() local name=fn("player");font:SetText(name) end)
    if not ok then pcall(font.SetText,font,"") end
    return ok
end
function D:CastPresence(kind)
    local fn=(kind=="channel" or kind=="empower") and UnitChannelInfo or UnitCastingInfo
    if type(fn)~="function" then return nil end
    local channel=kind=="channel" or kind=="empower"
    local ok,name,key=pcall(function()
        local name,display,texture,startTime,endTime,trade,identity,interrupt,spell,key10,key11=fn("player")
        if channel then return name,key11 end
        return name,key10
    end)
    if not ok then return nil end
    if S:Readable(key) and (S:Number(key) or S:Text(key)) then return true,key end
    if not S:Readable(name) then return nil end
    if name==nil then return false end
    return S:Text(name) and true or nil
end
function D:CastKey(kind)
    local fn=(kind=="channel" or kind=="empower") and UnitChannelInfo or UnitCastingInfo
    if type(fn)~="function" then return nil end
    local index=(kind=="channel" or kind=="empower") and 11 or 10
    local ok,key=pcall(function() return select(index,fn("player")) end)
    -- The pinned API declares only castBarID NeverSecret. GUIDs, spell IDs,
    -- timestamps and duration handles are never used for lifecycle equality.
    if ok and S:Readable(key) and (S:Number(key) or S:Text(key)) then return key end
end
function D:Overlap()
    local get=C_CVar and C_CVar.GetCVarBool or GetCVarBool
    local value,status=S:Public(get,"boolean","nameplateShowSelf")
    if status~="KNOWN" then return "Native Personal Resource Display status is unavailable. Check the game's interface settings for duplicate bars." end
    if value then return "Blizzard's Personal Resource Display is enabled. Choose which display to keep in the game's settings; MirageUI does not change it." end
    return "Blizzard's Personal Resource Display is off. Other player-frame and HUD add-ons may still overlap. No external setting is changed."
end

function D:Percent(font,key,kind)
    font:SetText("")
    if not M.Client.allowed then return false,"CLIENT_UNAVAILABLE" end
    local curve=S:Field(CurveConstants,"ScaleTo100")
    local api
    if key=="health" then api=UnitHealthPercent elseif key=="resource" then api=UnitPowerPercent end
    if not curve or type(api)~="function" or type(font.SetFormattedText)~="function" then return false,"UNSUPPORTED" end
    if key~="health" and (key~="resource" or not S:Number(kind)) then return false,"UNAVAILABLE" end
    local ok,value
    if key=="health" then ok,value=pcall(api,"player",true,curve)
    else ok,value=pcall(api,"player",kind,false,curve) end
    if not ok then return false,"SOURCE_UNAVAILABLE" end
    if S:Readable(value) and value==nil then return false,"SOURCE_UNAVAILABLE" end
    -- No arithmetic, type/threshold decisions, persistence or string.format of
    -- the payload. Only the documented native formatting sink sees this value.
    local sent=pcall(font.SetFormattedText,font,"%.0f%%",value)
    if not sent then font:SetText("") end
    return sent,sent and "NATIVE_TEXT_SUBMITTED" or "TEXT_UNAVAILABLE"
end

-- 70938 UnitHealth is AlwaysSecret, including out of combat. A public Lua
-- comparison therefore cannot implement an injured-player display. Public
-- curve points are legal from addon code. The resulting opaque percentages go
-- only to SetAlpha (AllowedWhenTainted), never to a Lua decision, a curve point,
-- or an Alpha animation endpoint (both accept secrets only while untainted).
function D:RecoveryCurve()
    if self.recoveryCurve then return self.recoveryCurve end
    if not C_CurveUtil or type(C_CurveUtil.CreateCurve)~="function"
        or not Enum or not Enum.LuaCurveType or Enum.LuaCurveType.Step==nil then return nil end
    local ok,curve=pcall(function()
        local curve=C_CurveUtil.CreateCurve();curve:SetType(Enum.LuaCurveType.Step)
        curve:AddPoint(0,.25);curve:AddPoint(1,0)
        return curve
    end)
    if ok then self.recoveryCurve=curve;return curve end
end
function D:RecoveryAlpha(view,health,power,kind)
    if not view then return false,"RECOVERY_SOURCE_UNAVAILABLE" end
    local profile=M.profile;local generation=view.recoveryGeneration or 0
    local controller=M.UnderCharacterHUD;local lifecycle=controller.presentationGeneration
    local request={};view.recoveryRequest=request
    local function current()
        return view.recoveryRequest==request and (view.recoveryGeneration or 0)==generation
            and M.profile==profile and not M.state.safe and controller.view==view and controller.presentationGeneration==lifecycle
    end
    local curve=self:RecoveryCurve()
    local rows=view and view.recoveryRows
    if not curve or not rows or health and type(UnitHealthPercent)~="function"
      or power and (not S:Number(kind) or type(UnitPowerPercent)~="function") then return false,"RECOVERY_SOURCE_UNAVAILABLE" end
    if not current() then return false,"RECOVERY_SUPERSEDED" end
    local now=S:Now()
    local outgoing=view.recoveryFront or 1
    local rootAlpha,known=S:Public(view.root.GetAlpha,"number",view.root)
    local animate=view.root:IsShown() and known=="KNOWN" and rootAlpha>0
    local incoming=animate and (outgoing==1 and 2 or 1) or outgoing
    if not current() then return false,"RECOVERY_SUPERSEDED" end
    local function active() return current() and view.recoveryActive==true end
    local ok,submitted=pcall(function()
        -- All curve points and all transition weights are public constants.
        -- The prior native alpha remains on the outgoing copy, without ever
        -- reading it. The incoming gate receives the new opaque submission.
        local alpha=0
        if health then alpha=UnitHealthPercent("player",false,curve) end
        if not current() then return false end
        rows.health.slots[incoming].gate:SetAlpha(alpha)
        if not current() then return false end
        alpha=0
        if power then alpha=UnitPowerPercent("player",kind,false,curve) end
        if not current() then return false end
        rows.resource.slots[incoming].gate:SetAlpha(alpha)
        if not current() then return false end
        view.recoveryActive=true
        for _,row in pairs(rows) do
            if animate then
                assert(M.Effects:Transition(row,row.slots[outgoing].weight,false,{duration=.22,now=now,guard=active,adaptive=false}))
                if not current() then return false end
                assert(M.Effects:Transition(row,row.slots[incoming].weight,true,{duration=.22,now=now,guard=active,adaptive=false}))
                if not current() then return false end
            else
                for i,slot in ipairs(row.slots) do
                    M.Effects:CancelTransition(row,slot.weight,false)
                    if not current() then return false end
                    slot.weight:SetAlpha(i==incoming and 1 or 0)
                    if not current() then return false end
                    slot.weight:SetShown(i==incoming)
                    if not current() then return false end
                end
            end
        end
        return true
    end)
    if not current() then return false,"RECOVERY_SUPERSEDED" end
    ok=ok and submitted==true
    if ok then view.recoveryFront=incoming;view.recoveryUntil=animate and now+.22 or nil end
    return ok,ok and "NATIVE_ROW_PERCENT_CURVES" or "RECOVERY_NATIVE_SUBMISSION_FAILED"
end
function D:ResetRecovery(view)
    if not view then return end
    view.recoveryGeneration=(view.recoveryGeneration or 0)+1;view.recoveryRequest=nil
    local generation,profile=view.recoveryGeneration,M.profile
    local function current() return view.recoveryGeneration==generation and view.recoveryRequest==nil and M.profile==profile end
    view.recoveryActive=nil;view.recoveryUntil=nil;view.recoveryFront=1
    for _,row in pairs(view.recoveryRows or {}) do for i,slot in ipairs(row.slots) do
        M.Effects:CancelTransition(row,slot.weight,false)
        if not current() then return end
        pcall(slot.gate.SetAlpha,slot.gate,1)
        if not current() then return end
        slot.weight:SetAlpha(i==1 and 1 or 0)
        if not current() then return end
        slot.weight:SetShown(i==1)
        if not current() then return end
    end end
end
