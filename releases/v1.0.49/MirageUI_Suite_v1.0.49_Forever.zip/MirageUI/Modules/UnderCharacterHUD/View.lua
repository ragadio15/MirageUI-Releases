local _, M = ...
-- Three independent translucent tracks. UIParent/CENTER uses UI units only;
-- a fixed cast footer never moves the health/resource anchors during a cast.
M.HUDView = {}
local V = M.HUDView
local keys = {"health", "resource", "cast"}
local castFirst = {"cast", "health", "resource"}
function V:Create(parent)
    local root = CreateFrame("Frame", nil, parent or UIParent)
    root:Hide(); M.Safety:Passive(root)
    local content = CreateFrame("Frame", nil, root)
    content:SetPoint("CENTER", root, "CENTER", 0, 0); M.Safety:Passive(content)
    -- Two fixed copies of each data row permit a public 0/1 crossfade between
    -- native opacity submissions. Opaque alpha remains on each inner gate;
    -- only the outer weights are interpolated by Lua. Casts are independent.
    local view = {root=root, content=content, recoveryRows={}, rows={}, copies={}}
    view.backdrop = content:CreateTexture(nil, "BACKGROUND")
    view.backdrop:SetAllPoints()
    for _, key in ipairs(keys) do
        local recovery=key~="cast" and {slots={}} or nil
        if recovery then view.recoveryRows[key]=recovery end
        for i=1,recovery and 2 or 1 do
            local parent=content
            local slot
            if recovery then
                local weight=CreateFrame("Frame",nil,content);weight:SetAllPoints(content);M.Safety:Passive(weight)
                weight:SetAlpha(i==1 and 1 or 0);weight:SetShown(i==1)
                local gate=CreateFrame("Frame",nil,weight);gate:SetAllPoints(content);M.Safety:Passive(gate)
                slot={weight=weight,gate=gate};recovery.slots[i]=slot;parent=gate
            end
            local bar=M.UI:Bar(parent,0,0,205,7)
            M.UI:Beam(bar);M.Safety:Passive(bar);bar:Hide()
            if slot then slot.bar=bar end
            if i==1 then view.rows[key]=bar else view.copies[key]=bar end
        end
    end
    view.castName=view.rows.cast:CreateFontString(nil,"OVERLAY")
    view.castName:SetFont(M.Visual.font or "Fonts\\FRIZQT__.TTF",11,"")
    view.castName:SetTextColor(.9,.94,.96,.92);view.castName:SetJustifyH("LEFT")
    view.castState=view.rows.cast:CreateFontString(nil,"OVERLAY")
    view.castState:SetFont(M.Visual.font or "Fonts\\FRIZQT__.TTF",9,"")
    view.castState:SetJustifyH("RIGHT")
    for _,text in ipairs({view.castName,view.castState}) do
        text:SetWordWrap(false);text:SetNonSpaceWrap(false);text:SetMaxLines(1)
    end
    return view
end
function V:Geometry(cfg)
    -- Reserve the entire possible stack. A cast starting/stopping never changes
    -- root height or the health/resource anchors, even with manual scaling.
    local pitch=self:RowPitch(cfg)
    return cfg.width+(cfg.castWidthExtra or 0), pitch*2+cfg.castHeight+16
end
function V:RowPitch(cfg)
    -- Equal lane pitch, with enough clearance for any authored row height.
    -- Lanes are reserved even when one row is contextually absent.
    return math.max(cfg.rowPitch or 14,cfg.healthHeight+4,cfg.resourceHeight+4,cfg.castHeight+4)
end
function V:Color(cfg, key, powerType)
    local source = cfg[key.."Color"] or 1
    if source == 2 then
        local c,kind = M.Visual:ClassColor("player")
        if kind == "CLASS" then return c end
    elseif source == 3 then
        return {cfg[key.."R"]/255,cfg[key.."G"]/255,cfg[key.."B"]/255}
    end
    if key == "health" then return M.Visual.health end
    if key == "cast" then return M.Visual.cast end
    if M.Safety:Number(powerType) then
        if powerType == 0 then return M.Visual.mana end
        local native = M.Safety:Field(PowerBarColor, powerType)
        local r,g,b = M.Safety:Field(native,"r"),M.Safety:Field(native,"g"),M.Safety:Field(native,"b")
        if M.Safety:Number(r) and M.Safety:Number(g) and M.Safety:Number(b) then return {r,g,b} end
    end
    return {.62,.68,.71}
end
function V:Layout(view, cfg, preview, textScale)
    local width,height = self:Geometry(cfg)
    local scale = cfg.hudScale/100
    -- The unscaled root keeps X/Y in UIParent units. Only its child scales.
    view.root:SetSize(width*scale,height*scale)
    if not preview then
        view.root:ClearAllPoints(); view.root:SetPoint("CENTER",UIParent,"CENTER",cfg.x,cfg.y)
    end
    view.content:SetSize(width,height); view.content:SetScale(scale)
    view.content:SetAlpha(cfg.opacity/100)
    -- The old spanning slab is intentionally absent; opacity belongs to each
    -- individual dark track and the global context fade, never a gray panel.
    view.backdrop:SetColorTexture(0,0,0,0)
    local y,pitch = 0,self:RowPitch(cfg)
    for _,key in ipairs(cfg.layoutOrder==2 and castFirst or keys) do
        local h=cfg[key.."Height"]
        local rowWidth=cfg.width+(key=="cast" and (cfg.castWidthExtra or 0) or 0)
        local c=self:Color(cfg,key,view.powerType)
        for _,bar in ipairs({view.rows[key],view.copies[key]}) do
            bar:ClearAllPoints();bar:SetPoint("TOPLEFT",view.content,"TOPLEFT",(width-rowWidth)/2,-y);bar:SetSize(rowWidth,h)
            M.UI:BeamColor(bar,c[1],c[2],c[3],(cfg[key.."FillOpacity"] or 100)/100)
            M.UI:BeamTrack(bar,.30,.30,.30,cfg.trackOpacity/100)
            -- Health used a taller black backing than the resource lane even
            -- though both use the same two-pixel beam. Match their visible
            -- rectangular tracks without moving the saved HUD/cast anchors.
            -- The lane envelopes remain authoritative for layout and labels.
            local trackHeight=key=="health" and math.min(h,cfg.resourceHeight) or h
            if bar.mirageTrack then
                bar.mirageTrack:ClearAllPoints()
                bar.mirageTrack:SetPoint("LEFT",bar,"LEFT",0,0)
                bar.mirageTrack:SetPoint("RIGHT",bar,"RIGHT",0,0)
                bar.mirageTrack:SetHeight(trackHeight)
            end
            if bar.mirageCurrentTick then bar.mirageCurrentTick:SetHeight(trackHeight) end
        end
        y=y+pitch
    end
    view.castName:ClearAllPoints();view.castName:SetPoint("BOTTOMLEFT",view.content,"BOTTOMLEFT",(width-cfg.width)/2,0)
    local stateWidth=math.min(80,math.floor(cfg.width*.38))
    view.castName:SetWidth(cfg.width-stateWidth-8);view.castName:SetHeight(13)
    view.castState:ClearAllPoints();view.castState:SetPoint("BOTTOMRIGHT",view.content,"BOTTOMRIGHT",-(width-cfg.width)/2,0)
    view.castState:SetWidth(stateWidth);view.castState:SetHeight(11)
    M.HUDPercent:Layout(view,cfg,textScale)
end
function V:ResourceLayout(view,cfg,absent)
    -- All three lanes remain reserved, including when a resource is absent.
    -- Native value/type changes never collapse the stack or move the cast.
end
local castStates={
    CASTING={"Casting",1,.74,.24},CHANNELING={"Channeling",.92,.64,1},EMPOWERING={"Empowering",.69,.49,.98},
    SUCCESS={"Complete",.26,.86,.61},CANCELLED={"Cancelled",.58,.65,.72},
    INTERRUPTED={"Interrupted",.98,.35,.34},FAILED={"Failed",.98,.54,.26},STOPPED={"Stopped",.58,.65,.72},
}
function V:CastState(view,state,cfg)
    local style=castStates[state]
    if not style then view.castState:SetText("");view.castPhase=nil;return end
    M.UI:BeamColor(view.rows.cast,style[2],style[3],style[4],(cfg.castFillOpacity or 100)/100)
    view.castState:SetTextColor(style[2],style[3],style[4],.9)
    view.castState:SetText(style[1]);view.castPhase=state
end
function V:Sample(view,cfg,cast,textScale)
    self:Layout(view,cfg,true,textScale)
    self:ResourceLayout(view,cfg,not cfg.resource)
    for _,key in ipairs(keys) do
        local b=view.rows[key]; b:SetMinMaxValues(0,1)
        b:SetValue(key=="health" and .78 or key=="resource" and .62 or .46)
        b:SetShown(cfg[key] and (key~="cast" or cast~=false))
        M.HUDPercent:Sample(view,cfg,key)
    end
    view.castName:SetText("Spell name");self:CastState(view,"CASTING",cfg)
    view.root:Show()
end
function V:Clear(view)
    M.HUDData:ResetRecovery(view)
    M.HUDPercent:Invalidate(view,"SUSPENDED")
    for _,bar in pairs(view.rows) do
        bar.mirageRequestedShown=false;bar:Hide()
        if type(bar.ClearTimerDuration)=="function" then pcall(bar.ClearTimerDuration,bar) end
    end
    for _,bar in pairs(view.copies or {}) do bar:Hide() end
    if view.castName then view.castName:SetText("") end
    if view.castState then view.castState:SetText("") end
    view.root:Hide()
end
