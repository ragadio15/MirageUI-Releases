local _,M=...
local S=M.Safety
local H={events={PLAYER_ENTERING_WORLD=true,PLAYER_LEAVING_WORLD=true,PLAYER_REGEN_DISABLED=true,PLAYER_REGEN_ENABLED=true,
    PLAYER_DEAD=true,PLAYER_ALIVE=true,PLAYER_UNGHOST=true,
    CINEMATIC_START=true,CINEMATIC_STOP=true,PET_BATTLE_OPENING_START=true,PET_BATTLE_CLOSE=true,UI_SCALE_CHANGED=true,DISPLAY_SIZE_CHANGED=true,
    PLAYER_TARGET_CHANGED=true,UNIT_HEALTH=true,UNIT_MAXHEALTH=true,UNIT_POWER_UPDATE=true,UNIT_MAXPOWER=true,UNIT_DISPLAYPOWER=true,
    UPDATE_SHAPESHIFT_FORM=true,UNIT_ENTERED_VEHICLE=true,UNIT_EXITED_VEHICLE=true,
    UNIT_SPELLCAST_START=true,UNIT_SPELLCAST_STOP=true,UNIT_SPELLCAST_SUCCEEDED=true,UNIT_SPELLCAST_DELAYED=true,UNIT_SPELLCAST_FAILED=true,UNIT_SPELLCAST_INTERRUPTED=true,
    UNIT_SPELLCAST_CHANNEL_START=true,UNIT_SPELLCAST_CHANNEL_UPDATE=true,UNIT_SPELLCAST_CHANNEL_STOP=true,
    UNIT_SPELLCAST_EMPOWER_START=true,UNIT_SPELLCAST_EMPOWER_UPDATE=true,UNIT_SPELLCAST_EMPOWER_STOP=true},rowStatus={},rowFaults={}}
M.UnderCharacterHUD=H
-- A companion may borrow the cast lane's presentation, never its data or
-- native input custody. Keep every saved profile choice and live cast sink
-- intact so ordinary HUD visibility resumes as soon as the card leaves.
function H:FishingReplacementAvailable()
    if not self.view or not self.view.content or not self.view.rows or not self.view.rows.cast or self.suspended or self.unavailableWorld
      or self.vehicle or self.petBattle or self.playerDead or (M.state and (M.state.safe or M.state.keybindWorkspace)) then return false end
    if type(M.ModuleConfig)~="function" then return false end
    local c=M:ModuleConfig(self.id)
    if not c or not c.enabled or not c.cast then return false end
    local casts=M.Rework and M.Rework.CombatCasts
    return casts and type(casts.OwnsPlayerCast)=="function" and casts:OwnsPlayerCast()==true or false
end
function H:GetFishingAnchor()
    if not self:FishingReplacementAvailable() then return nil,"HUD_REPLACEMENT_UNAVAILABLE" end
    local parentScale=S:Public(S:Field(UIParent,"GetEffectiveScale"),"number",UIParent)
    if not parentScale or parentScale<=0 then return nil,"HUD_GEOMETRY_PENDING" end
    local bounds
    -- The reserved lane has stable geometry even when a cast is idle or this
    -- content is borrowed. Include its labels; ignore visibility deliberately.
    for _,frame in ipairs({self.view.rows.cast,self.view.castName,self.view.castState}) do
        if S:Frame(frame,false) then
            local scale=S:Public(S:Field(frame,"GetEffectiveScale"),"number",frame)
            local left=S:Public(S:Field(frame,"GetLeft"),"number",frame)
            local right=S:Public(S:Field(frame,"GetRight"),"number",frame)
            local bottom=S:Public(S:Field(frame,"GetBottom"),"number",frame)
            local top=S:Public(S:Field(frame,"GetTop"),"number",frame)
            if scale and scale>0 and left and right and bottom and top and right>left and top>bottom then
                local ratio=scale/parentScale
                left,right,bottom,top=left*ratio,right*ratio,bottom*ratio,top*ratio
                if bounds then
                    bounds.left=math.min(bounds.left,left);bounds.right=math.max(bounds.right,right)
                    bounds.bottom=math.min(bounds.bottom,bottom);bounds.top=math.max(bounds.top,top)
                else bounds={left=left,right=right,bottom=bottom,top=top,space="UIParent",version=1} end
            elseif frame==self.view.rows.cast then return nil,"HUD_GEOMETRY_PENDING" end
        end
    end
    return bounds,bounds and "HUD_CAST_LANE" or "HUD_GEOMETRY_PENDING"
end
function H:PresentationSuppressed()
    if M.state and M.state.keybindWorkspace then return true,"KEYBIND_WORKSPACE" end
    local owner=self.fishingPresentation
    if owner and S:Public(S:Field(owner,"IsVisible"),"boolean",owner)==true and self:FishingReplacementAvailable() then
        return true,"FISHING_ASSISTANT"
    end
    return false
end
function H:RefreshPresentation()
    local suppressed,reason=self:PresentationSuppressed()
    local content=self.view and self.view.content
    if not content then return end
    if suppressed and not self.presentationSuppressed then content:Hide();M.state.forceEvaluate=true
    elseif not suppressed and self.presentationSuppressed then content:Show();M.state.forceEvaluate=true end
    self.presentationSuppressed=suppressed;self.presentationSuppressionReason=reason
    if not suppressed and self.fishingPresentation then self.fishingPresentation=nil end
end
function H:SetFishingPresentation(owner,active)
    if active then
        if not S:Frame(owner,false) or S:Public(S:Field(owner,"IsVisible"),"boolean",owner)~=true
          or not self:FishingReplacementAvailable() then return false end
        self.fishingPresentation=owner
    elseif owner==self.fishingPresentation then self.fishingPresentation=nil
    else return false end
    self:RefreshPresentation()
    return active~=true or self.presentationSuppressionReason=="FISHING_ASSISTANT"
end
-- Read-only layout integration for companion displays. Coordinates are in
-- UIParent units, including the cast labels below the bar and child scaling.
-- Consumers move only their own presentation; this does not grant custody of
-- the cast, its secure native backing, or the user's saved HUD position.
function H:GetDisplayBounds()
    local view=self.view
    if not view or self.suspended or (M.state and M.state.safe) then return nil,"HUD_INACTIVE" end
    if self:PresentationSuppressed() then return nil,"HUD_PRESENTATION_BORROWED" end
    local root=view.root
    if not S:Frame(root,false) or S:Public(S:Field(root,"IsVisible"),"boolean",root)~=true then
        return nil,"HUD_HIDDEN"
    end
    local parentScale=S:Public(S:Field(UIParent,"GetEffectiveScale"),"number",UIParent)
    if not parentScale or parentScale<=0 then return nil,"HUD_GEOMETRY_PENDING" end
    local bounds
    for _,frame in ipairs({root,view.castName,view.castState}) do
        if S:Frame(frame,false) and S:Public(S:Field(frame,"IsVisible"),"boolean",frame)==true then
            local scale=S:Public(S:Field(frame,"GetEffectiveScale"),"number",frame)
            local left=S:Public(S:Field(frame,"GetLeft"),"number",frame)
            local right=S:Public(S:Field(frame,"GetRight"),"number",frame)
            local bottom=S:Public(S:Field(frame,"GetBottom"),"number",frame)
            local top=S:Public(S:Field(frame,"GetTop"),"number",frame)
            if scale and scale>0 and left and right and bottom and top and right>left and top>bottom then
                local ratio=scale/parentScale
                left,right,bottom,top=left*ratio,right*ratio,bottom*ratio,top*ratio
                if bounds then
                    bounds.left=math.min(bounds.left,left);bounds.right=math.max(bounds.right,right)
                    bounds.bottom=math.min(bounds.bottom,bottom);bounds.top=math.max(bounds.top,top)
                else bounds={left=left,right=right,bottom=bottom,top=top,space="UIParent",version=1} end
            elseif frame==root then return nil,"HUD_GEOMETRY_PENDING" end
        end
    end
    return bounds,bounds and "HUD_VISIBLE_BOUNDS" or "HUD_GEOMETRY_PENDING"
end
local castEvents={UNIT_SPELLCAST_START=true,UNIT_SPELLCAST_STOP=true,UNIT_SPELLCAST_SUCCEEDED=true,UNIT_SPELLCAST_DELAYED=true,UNIT_SPELLCAST_FAILED=true,UNIT_SPELLCAST_INTERRUPTED=true,
 UNIT_SPELLCAST_CHANNEL_START=true,UNIT_SPELLCAST_CHANNEL_UPDATE=true,UNIT_SPELLCAST_CHANNEL_STOP=true,UNIT_SPELLCAST_EMPOWER_START=true,UNIT_SPELLCAST_EMPOWER_UPDATE=true,UNIT_SPELLCAST_EMPOWER_STOP=true}
function H:WantsEvent(event)
    local c=M:ModuleConfig(self.id)
    if not c or not c.enabled then return false end
    if event=="UNIT_HEALTH" or event=="UNIT_MAXHEALTH" then return c.health end
    if event=="UNIT_POWER_UPDATE" or event=="UNIT_MAXPOWER" or event=="UNIT_DISPLAYPOWER" or event=="UPDATE_SHAPESHIFT_FORM" then return c.resource end
    if castEvents[event] then return c.cast end
    return true
end
function H:Initialize()
    self.view=M.HUDView:Create(UIParent)
    M:TrackRoot(self.id,self.view.root)
    self.surface={id="UnderCharacterHUD.player",module=self.id,frame=self.view.root,security="OWNED_VISUAL",groups={combat=true},fallback="VISIBLE",editable=false}
    self.surface.Intent=function(_,snapshot)
        local c=M:ModuleConfig(self.id)
        if self:PresentationSuppressed() then return "HIDDEN","HUD_PRESENTATION_BORROWED",0 end
        if self.petBattle or self.vehicle or self.unavailableWorld then return "HIDDEN","HUD_INCOMPATIBLE_UI",0 end
        if self.activity or self.castFeedbackUntil then return "VISIBLE","HUD_CAST_LOCAL",1 end
        if self:ExplicitRows(snapshot) then return "VISIBLE","HUD_EXPLICIT_INSPECTION",0 end
        local shown,reason=self:CombatDemand(snapshot)
        if not shown and self:RecoveryDemand() then shown,reason=true,"HUD_RECOVERY" end
        return shown and "VISIBLE" or "HIDDEN",reason,2
    end
    M.CVE:Register(self.surface)
    self.status="HUD_IMPLEMENTED_NATIVE_NOT_RUN"
    self:ApplyConfig()
end
function H:CombatDemand(snapshot)
    if M.ScopedActivity then
        local show,reason=M.ScopedActivity:Demand("COMBAT",snapshot,S:Now())
        local groups=M.PresentationGroups
        if groups and groups:Enabled() then
            if self.combatDemandProfile~=M.profile or self.combatDemandGeneration~=groups.generation then
                self.combatDemandKnown=nil
                self.combatDemandProfile=M.profile;self.combatDemandGeneration=groups.generation
            end
            if show~=nil then self.combatDemandKnown=show==true
            elseif self.combatDemandKnown~=nil then
                -- A currently exposed enemy can have an unreadable target
                -- relation. Retain only the last known COMBAT decision in this
                -- scope; recovery, casts and hover never seed this memory.
                return self.combatDemandKnown,"HUD_COMBAT_OBSERVATION_PENDING"
            end
        else
            self.combatDemandKnown=nil;self.combatDemandProfile=nil;self.combatDemandGeneration=nil
        end
        return show==true,reason or "HUD_QUIET"
    end
    local value=M.Store and M.Store:Value("PLAYER_IN_COMBAT")
    return value==true,"HUD_COMBAT_CONTEXT"
end
-- Readable values retain an ordinary local transition. On Forever, current
-- health is always restricted: keep a passive display channel available and
-- let native percentage curves alone decide its actual opacity. "Demand" is
-- channel admission in that case, never a claim that the player is injured.
function H:ResetRecoveryGate()
    if self.recoveryUsesNative then
        local profile,view,generation=M.profile,self.view,self.presentationGeneration
        M.HUDData:ResetRecovery(self.view)
        if M.profile~=profile or self.view~=view or self.presentationGeneration~=generation then return end
        self.recoveryUsesNative=nil;self.recoveryAt=nil
    end
end
function H:RecoveryDemand()
    if not M.PresentationGroups or not M.PresentationGroups:Enabled() or self.playerDead
        or self.vehicle or self.petBattle or self.unavailableWorld then
        self:ResetRecoveryGate();self.recoveryStatus="INACTIVE";return false
    end
    local now=S:Now()
    -- Keep two fixed copies; rapid value events only mark one pending refresh
    -- while their public weights crossfade. Never read an inner secret alpha
    -- to interrupt/rebase the animation. The common HUD tick consumes the
    -- latest values when the bounded .22-second crossfade finishes.
    if self.recoveryUsesNative and self.recoveryProfile==M.profile and self.view.recoveryUntil and now<self.view.recoveryUntil then return self.recovery==true end
    -- Value events invalidate this cache. A native alpha result is never
    -- inspected or polled to obtain a public injury/visibility decision.
    if self.recoveryProfile==M.profile and self.recoveryAt and not self.recoveryDirty then return self.recovery==true end
    local profile,view,generation=M.profile,self.view,self.presentationGeneration
    local function current()
        return M.profile==profile and self.view==view and self.presentationGeneration==generation and not M.state.safe
    end
    local c=M:ModuleConfig(self.id)
    local function below(fn,maximum,...)
        local actual,a=S:Public(fn,"number",...)
        local capacity,b=S:Public(maximum,"number",...)
        if b=="KNOWN" and capacity==0 then return false end
        if a~="KNOWN" or b~="KNOWN" or capacity<=0 or actual<0 then return nil end
        return actual<capacity
    end
    local hp,mp=false,false
    if c.health then hp=below(UnitHealth,UnitHealthMax,"player") end
    local hasPower=c.resource and self.powerType~=nil
    if hasPower then mp=below(UnitPower,UnitPowerMax,"player",self.powerType) end
    if not current() then return false end
    local low=hp==true or mp==true
    if hp==nil or mp==nil then
        local okay,why=M.HUDData:RecoveryAlpha(self.view,c.health==true,hasPower,self.powerType)
        if not current() or why=="RECOVERY_SUPERSEDED" then return false end
        self.recoveryUsesNative=okay==true or nil;self.recoveryStatus=why
        -- This boolean reports successful native sink submission only. It
        -- reveals neither an opaque health value nor the native alpha result.
        low=okay==true
        if not okay then M.HUDData:ResetRecovery(self.view) end
    elseif low then
        self:ResetRecoveryGate();if not current() then return false end;self.recoveryStatus="PUBLIC_BELOW_MAX"
    else self:ResetRecoveryGate();if not current() then return false end;self.recoveryStatus="PUBLIC_FULL" end
    if not current() then return false end
    self.recoveryDirty=nil
    if self.recovery~=low then M.state.forceEvaluate=true end
    self.recovery,self.recoveryAt,self.recoveryProfile=low,now,M.profile
    return low
end
function H:HoverDemand()
    return M.PresentationGroups and M.PresentationGroups:Enabled() and self.surface
        and M.PresentationGroups:Hover(self.surface,self.view.root,S:Now())==true or false
end
function H:RowAlpha()
    if self:ExplicitRows() or self:CombatDemand() or self:HoverDemand() then self:ResetRecoveryGate();return 1 end
    local admitted=self:RecoveryDemand()
    return admitted and not self.recoveryUsesNative and .25 or 1
end
function H:ExplicitRows(snapshot)
    local c=M:ModuleConfig(self.id)
    if c.policy==1 or c.visibility=="Always" or M.state.edit or S:Now()<(M.state.revealUntil or 0) then return true end
    snapshot=snapshot or M.Store and M.Store:Snapshot()
    return M.ElementRules and M.ElementRules:Preference("UnderCharacterHUD.player",snapshot)=="SHOW" or false
end
function H:RowContext(key)
    if self.vehicle or self.petBattle or self.unavailableWorld or self:PresentationSuppressed() then return false end
    local c=M:ModuleConfig(self.id)
    if key=="cast" then return not self.playerDead and (self.activity~=nil or self.castFeedbackUntil~=nil and not self.castFeedbackFading) end
    return self:ExplicitRows() or self:CombatDemand() or self:RecoveryDemand() or self:HoverDemand()
end
function H:RefreshRowVisibility(key,current)
    self:RefreshPresentation()
    local row=self.view and self.view.rows[key];if not row then return end
    local allowed,ownerReason=M.Presentation:Allows("UnderCharacterHUD",key)
    local context=self:RowContext(key)
    local grouped=key~="cast" and M.PresentationGroups and M.PresentationGroups:Enabled()
    -- The root owns the shared context fade. Enabled health/resource rows stay
    -- resident beneath it; fading their context a second time would square the
    -- effective opacity and desynchronize this HUD from its sibling displays.
    local castOnly=not context and (self.activity~=nil or self.castFeedbackUntil~=nil)
    local localAvailable=grouped and not self.vehicle and not self.petBattle and not self.unavailableWorld
    local shown=row.mirageRequestedShown==true and (grouped and localAvailable and not castOnly or not grouped and context) and allowed
    if current and not current() then return end
    local profile=M.profile
    local guard=current or function() return self.view and self.view.rows[key]==row and M.profile==profile and not M.state.safe end
    -- Releasing cast custody is immediate: fading an old custom receipt while
    -- native access resumes would briefly duplicate the sole player cast.
    if key=="cast" and not allowed then
        if M.Effects.CancelTransition then M.Effects:CancelTransition(self,row,false) end
        row:Hide();return
    end
    -- A passive refresh may occur while the final receipt is fading. Renew its
    -- own cleanup callback rather than reversing the fade or replacing that
    -- callback with a generic row-visibility request.
    if key=="cast" and self.castFeedbackFading then self:FadeCastFeedback();return end
    if M.Effects.Transition then
        local alpha=key=="cast" and 1 or self:RowAlpha()
        local transitionDuration
        if grouped then
            local root=self.view.root
            local rootShown,rootKnown=S:Public(root.IsShown,"boolean",root)
            local rootAlpha,alphaKnown=S:Public(root.GetAlpha,"number",root)
            if not context and not castOnly then
                -- Preserve the current local intensity while the parent fades
                -- out, including an interrupted recovery-opacity transition.
                local present,known=S:Public(row.GetAlpha,"number",row)
                if known=="KNOWN" then alpha=present end
                M.Effects:CancelTransition(self,row,false)
                transitionDuration=0
            elseif castOnly and alphaKnown=="KNOWN" and rootAlpha<((M:ModuleConfig(self.id).alpha or 1)-.00001) then
                -- A cast can reverse a nearly finished parent conceal. Retire
                -- these unrelated rows before that reversal can brighten them.
                transitionDuration=0
            elseif rootKnown=="KNOWN" and not rootShown or alphaKnown=="KNOWN" and rootAlpha<=0 then
                -- Prime the local recovery/full opacity before a hidden parent
                -- reveals; there is only one zero-to-visible group ramp.
                transitionDuration=0
            elseif self:HoverDemand() or row.mirageRecoveryHover then
                transitionDuration=M.PresentationGroups.hoverFade
            end
            row.mirageRecoveryHover=self:HoverDemand()
        end
        for _,paint in ipairs({row,self.view.copies and self.view.copies[key]}) do
            -- These children change health/resource/cast emphasis inside one
            -- contextual root. Their independent data changes must not count
            -- as repeated user movement or delay the next readable value.
            local accepted=M.Effects:Transition(self,paint,shown,{guard=guard,alpha=alpha,duration=transitionDuration,adaptive=false})
            if not accepted and guard() then paint:SetShown(shown) end
        end
    else
        row:SetShown(shown)
        if self.view.copies and self.view.copies[key] then self.view.copies[key]:SetShown(shown) end
    end
    M.HUDPercent:Refresh(self.view,M:ModuleConfig(self.id),key,shown,self.powerType)
end
function H:PresentRow(key,ok,reason,current)
    if current and not current() then return end
    local c=M:ModuleConfig(self.id)
    self.rowStatus[key]=reason
    if reason=="DISPLAY_UNAVAILABLE" or reason=="DURATION_DISPLAY_UNAVAILABLE" then self.rowFaults[key]=(self.rowFaults[key] or 0)+1 end
    self.view.rows[key].mirageRequestedShown=ok and c[key]==true
    self:RefreshRowVisibility(key,current)
end
function H:CastAvailable()
    local bar=self.view and self.view.rows.cast
    if not bar then return false,"CAST_ROW_UNAVAILABLE" end
    if (self.rowFaults.cast or 0)>0 then return false,"CAST_ROW_FAILED" end
    if type(bar.SetTimerDuration)~="function" or type(UnitCastingDuration)~="function" or type(UnitChannelDuration)~="function"
      or type(UnitCastingInfo)~="function" or type(UnitChannelInfo)~="function" then return false,"CAST_API_UNAVAILABLE" end
    -- Expected absence is not a broken display. Keep native custody in these
    -- contexts and disclose the cause separately from widget/API failures.
    -- The prepared widget contract above is still required while inactive.
    if self.unavailableWorld then return false,"WORLD_UNAVAILABLE" end
    if self.playerDead then return false,"PLAYER_DEAD" end
    if self.vehicle then return false,"VEHICLE" end
    if self.petBattle then return false,"PET_BATTLE" end
    if self.activity then
        local ready=self.castLifecycleKnown==true and self.rowStatus.cast=="NATIVE_DURATION_SUBMITTED" and self.castNameOK==true
        return ready,ready and "ACTIVE_CAST" or "CAST_CONTENT_UNAVAILABLE"
    end
    if self.castFeedbackUntil then return self.castNameOK==true,self.castNameOK==true and "CAST_FEEDBACK" or "CAST_NAME_UNAVAILABLE" end
    local ready=self.castPresenceKnown==true and self.rowStatus.cast=="IDLE"
    return ready,ready and "IDLE" or "CAST_PRESENCE_UNAVAILABLE"
end
function H:RefreshHealth()
    self.recoveryAt=nil;self.recoveryDirty=true
    local c=M:ModuleConfig(self.id)
    if not c.health then self:PresentRow("health",false,"DISABLED");return end
    if (self.rowFaults.health or 0)>=3 then self:PresentRow("health",false,"ROW_QUARANTINED");return end
    self:PresentRow("health",M.HUDData:Health(self.view.rows.health,self.view.copies and self.view.copies.health))
end
function H:RefreshPower(changeType)
    self.recoveryAt=nil;self.recoveryDirty=true
    local c=M:ModuleConfig(self.id)
    if changeType then
        self.powerType,self.powerState=M.HUDData:PrimaryType();self.view.powerType=self.powerType
        M.HUDView:ResourceLayout(self.view,c,self.powerType==nil or not c.resource)
        local color=M.HUDView:Color(c,"resource",self.powerType)
        M.UI:BeamColor(self.view.rows.resource,color[1],color[2],color[3],(c.resourceFillOpacity or 100)/100)
        if self.view.copies and self.view.copies.resource then M.UI:BeamColor(self.view.copies.resource,color[1],color[2],color[3],(c.resourceFillOpacity or 100)/100) end
    end
    if not c.resource then self:PresentRow("resource",false,"DISABLED");return end
    if not self.powerType then self:PresentRow("resource",false,self.powerState or "UNAVAILABLE");return end
    if (self.rowFaults.resource or 0)>=3 then self:PresentRow("resource",false,"ROW_QUARANTINED");return end
    self:PresentRow("resource",M.HUDData:Power(self.view.rows.resource,self.powerType,self.view.copies and self.view.copies.resource))
end
function H:ClearCast(reason)
    self.castDelivery={}
    self.castPublicKey=nil;self.castEventKey=nil;self.lastCastKey=nil;self.castFeedbackUntil=nil;self.castFeedbackFading=nil;self.castEventObserved=nil
    self.activity=nil;self.empowered=false;self.castPresenceKnown=true;self.castLifecycleKnown=nil
    local bar=self.view.rows.cast;bar.mirageRequestedShown=false;bar:Hide()
    if M.Effects.CancelTransition then M.Effects:CancelTransition(self,bar,false) end
    if type(bar.ClearTimerDuration)=="function" then pcall(bar.ClearTimerDuration,bar) end
    if self.view.castName then self.view.castName:SetText("") end
    if self.view.castState then self.view.castState:SetText("") end
    self.view.castPhase=nil
    self.rowStatus.cast=reason or "IDLE";M.state.forceEvaluate=true
end
function H:BindCast(kind)
    local ticket={};self.castDelivery=ticket
    local profile=M.profile
    local function current() return self.castDelivery==ticket and not self.castPending and M.profile==profile end
    if M.state.safe or not M:ModuleConfig(self.id).enabled then self:ClearCast("DISABLED");return end
    if self.playerDead or self.unavailableWorld then self:ClearCast("PLAYER_UNAVAILABLE");return end
    self.activity=kind;self.castPresenceKnown=true;M.state.forceEvaluate=true
    if kind=="channel" and M.DurationDisplay:IsEmpowered("player")==true then kind="empower" end
    if not current() then return end
    self.activity=kind;self.empowered=kind=="empower"
    self.lastCastKey=nil;self.castFeedbackUntil=nil;self.castFeedbackFading=nil
    local c=M:ModuleConfig(self.id)
    if not c.cast then self:PresentRow("cast",false,"DISABLED");return end
    if (self.rowFaults.cast or 0)>=3 then self:PresentRow("cast",false,"ROW_QUARANTINED");return end
    local bar=self.view.rows.cast
    local key=M.HUDData:CastKey(kind)
    if not current() then return end
    self.castPublicKey=key or self.castEventKey or self.castPublicKey
    self.castEventKey=nil
    self.castLifecycleKnown=self.castPublicKey~=nil or self.castEventObserved==true
    local ok,reason=M.HUDData:Cast(bar,kind)
    if not current() then return end
    if reason=="NO_ACTIVE_DURATION" then self.activity=nil end
    if ok then
        self.castNameOK=M.HUDData:CastName(self.view.castName,kind)
        if not current() then return end
        if not self.castNameOK then ok=false;reason="CAST_NAME_UNAVAILABLE" end
        M.HUDView:CastState(self.view,kind=="channel" and "CHANNELING" or kind=="empower" and "EMPOWERING" or "CASTING",c)
    end
    self:PresentRow("cast",ok,reason,current)
end
function H:FinishCast(state)
    local ticket={};self.castDelivery=ticket
    local profile=M.profile
    local function current() return self.castDelivery==ticket and not self.castPending and M.profile==profile and not M.state.safe end
    local bar=self.view.rows.cast
    self.lastCastKey=self.castPublicKey or self.lastCastKey;self.castPublicKey=nil
    self.lastCastKind=self.activity or self.lastCastKind
    self.activity=nil;self.empowered=false
    if type(bar.ClearTimerDuration)=="function" then pcall(bar.ClearTimerDuration,bar) end
    if not current() then return end
    local c=M:ModuleConfig(self.id)
    if state=="SUCCESS" then
        -- A completed, correlated event paints an authored completion receipt,
        -- not a fabricated time value or an inspected native duration.
        bar:SetMinMaxValues(0,1);bar:SetValue(1)
    end
    M.HUDView:CastState(self.view,state,c)
    if not current() then return end
    local hold=state=="SUCCESS" and .20 or (state=="INTERRUPTED" or state=="FAILED") and .75 or .35
    self.castFeedbackUntil=S:Now()+hold;self.castFeedbackFading=nil
    self.rowStatus.cast=state and "CAST_FEEDBACK_"..state or "CAST_ENDED"
    self.castPresenceKnown=true
    bar.mirageRequestedShown=c.cast==true and self.castNameOK==true
    if not bar.mirageRequestedShown or not M.Presentation:Allows("UnderCharacterHUD","cast") then self:ClearCast("IDLE");return end
    if M.Effects.Transition then M.Effects:Transition(self,bar,true,{guard=current,adaptive=false}) end
    M.state.forceEvaluate=true
end
-- A native duration setter may synchronously deliver STOP or disable/recovery.
-- Serialize only cast work, so the most recent lifecycle request wins after an
-- in-flight sink returns. No spell ID, GUID or duration payload is a key.
local clearCastBody,bindCastBody,finishCastBody=H.ClearCast,H.BindCast,H.FinishCast
local function castWork(self,kind,value)
    if self.castDiscard then return end
    self.castPending={kind=kind,value=value};self.castDelivery=nil
    if self.castBusy then return end
    self.castBusy=true
    for attempt=1,2 do
        local request=self.castPending;if not request then break end
        self.castPending=nil
        local body=request.kind=="clear" and clearCastBody or request.kind=="finish" and finishCastBody or bindCastBody
        local ok=pcall(body,self,request.value)
        if not ok and not self.castPending then self.castPending={kind="clear",value="CAST_DISPLAY_UNAVAILABLE"} end
    end
    if self.castPending then
        self.castPending=nil;self.castDiscard=true;pcall(clearCastBody,self,"CAST_REENTRY_LIMIT");self.castDiscard=nil
    end
    self.castPending=nil;self.castBusy=nil
end
function H:ClearCast(reason) return castWork(self,"clear",reason) end
function H:BindCast(kind) return castWork(self,"bind",kind) end
function H:FinishCast(state) return castWork(self,"finish",state) end
function H:ResyncCast()
    self:ClearCast()
    if self.playerDead or self.unavailableWorld or not self:WantsEvent("UNIT_SPELLCAST_START") then return end
    -- Public castBarID reconciles an ongoing cast while opaque duration/name
    -- payloads stay at native sinks. A secret duration is never an absence test.
    local known=true
    for _,kind in ipairs({"channel","cast"}) do
        local present,key=M.HUDData:CastPresence(kind)
        if present==nil then known=false
        elseif present then
            if kind=="channel" then
                local empower=M.DurationDisplay:IsEmpowered("player")
                if empower==nil then
                    self.castPresenceKnown=false;self.rowStatus.cast="CHANNEL_CLASSIFICATION_UNAVAILABLE";return
                end
                if empower then kind="empower" end
            end
            -- The API explicitly confirmed public presence. Its nullable ID
            -- is not required to reconstruct this local display generation.
            self.castEventObserved=true;self.castEventKey=key;self:BindCast(kind);return
        end
    end
    self.castPresenceKnown=known
end
function H:RefreshUIState()
    local vehicle,status=S:Public(UnitInVehicle,"boolean","player")
    self.vehicle=status=="KNOWN" and vehicle==true
    local battle=C_PetBattles and C_PetBattles.IsInBattle
    local active,known=S:Public(battle,"boolean")
    self.petBattle=known=="KNOWN" and active==true or self.petBattle==true
    local dead,deathState=S:Public(UnitIsDeadOrGhost,"boolean","player")
    if deathState=="KNOWN" then self.playerDead=dead end
end
function H:ApplyConfig()
    self.presentationGeneration=(self.presentationGeneration or 0)+1
    local c=M:ModuleConfig(self.id)
    self.viewportPending=nil
    self:ResetRecoveryGate();self.recoveryDirty=true
    self.rowFaults={};M.HUDView:Layout(self.view,c,false)
    self:RefreshUIState();self:RefreshPower(true);self:RefreshHealth();self:ResyncCast()
    self.surface.disabled=not (c.health or c.resource or c.cast)
    self:RefreshPresentation()
    M.state.forceEvaluate=true
end
function H:RepairViewport()
    local request=self.viewportPending
    if not request then return end
    if request.view~=self.view or request.profile~=M.profile or M.state.safe or self.suspended then
        self.viewportPending=nil;return
    end
    if S:InCombat() then return end
    local c=M:ModuleConfig(self.id)
    if not c or not c.enabled then self.viewportPending=nil;return end
    -- A viewport event in combat invalidates the old typography seal. Combat
    -- ending is intentionally not a full profile apply, so this one local
    -- request must repair the fit. Keep cast identity/timing and fault history.
    self.viewportPending=nil
    M.HUDView:Layout(self.view,c,false)
    if request.view~=self.view or request.profile~=M.profile or M.state.safe or self.suspended then return end
    self:RefreshPower(true)
    if request.view~=self.view or request.profile~=M.profile or M.state.safe or self.suspended then return end
    self:RefreshHealth()
end
local function eventKey(event,...)
    local index=(event=="UNIT_SPELLCAST_EMPOWER_STOP") and 5
        or (event=="UNIT_SPELLCAST_INTERRUPTED" or event=="UNIT_SPELLCAST_CHANNEL_STOP") and 4 or 3
    local key=select(index,...)
    if S:Readable(key) and (S:Number(key) or S:Text(key)) then return key end
end
function H:CastEndEvent(event,...)
    local key=eventKey(event,...)
    local current=self.castPublicKey
    if event=="UNIT_SPELLCAST_SUCCEEDED" and key and key==self.lastCastKey
        and self.lastCastKind=="cast" and (self.castFeedbackUntil or 0)>=S:Now() then
        self:FinishCast("SUCCESS");return
    end
    if key and current and key~=current then return end -- late event belongs to another public cast lifetime
    if not key or not current then
        if not self.activity then return end
        -- castBarID is nullable. The current public start event still owns a
        -- local generation. Reconcile a publicly readable ongoing cast before
        -- accepting a nil-ID stop; never compare opaque names or spell IDs.
        local present,newKey=M.HUDData:CastPresence(self.activity)
        if present==true then
            if newKey and current and newKey~=current then self:ResyncCast() end
            return
        end
        if present==nil then self:ClearCast("CAST_END_UNCORRELATED");self.castPresenceKnown=false;return end
        self:FinishCast("STOPPED");return
    end
    if event=="UNIT_SPELLCAST_SUCCEEDED" then
        if self.activity=="cast" then self:FinishCast("SUCCESS") end -- channel success can occur at its start
    elseif event=="UNIT_SPELLCAST_FAILED" then self:FinishCast("FAILED")
    elseif event=="UNIT_SPELLCAST_INTERRUPTED" then
        local by=select(3,...)
        self:FinishCast(S:Readable(by) and by==nil and "CANCELLED" or "INTERRUPTED")
    elseif event=="UNIT_SPELLCAST_CHANNEL_STOP" and (self.activity=="channel" or self.activity=="empower") then
        local by=select(3,...)
        self:FinishCast(S:Readable(by) and by~=nil and "INTERRUPTED" or "STOPPED")
    elseif event=="UNIT_SPELLCAST_EMPOWER_STOP" and self.activity=="empower" then
        local complete,by=select(3,...)
        local state
        if S:Readable(complete) and type(complete)=="boolean" then
            if complete then state="SUCCESS"
            elseif S:Readable(by) then state=by==nil and "CANCELLED" or "INTERRUPTED" end
        end
        self:FinishCast(state)
    elseif event=="UNIT_SPELLCAST_STOP" and self.activity=="cast" then self:FinishCast("STOPPED") end
end
function H:OnEvent(event,unit,...)
    if event:sub(1,5)=="UNIT_" and (not S:Text(unit) or unit~="player") then return end
    if not self:WantsEvent(event) then return end
    if castEvents[event] and (self.playerDead or self.unavailableWorld) then return end
    -- Value-only updates can change the local recovery gate. Avoid re-evaluating
    -- unrelated CVE surfaces for every health or resource event.
    if event=="PLAYER_TARGET_CHANGED" then M.Signals:Observe()
    elseif event=="UNIT_HEALTH" or event=="UNIT_MAXHEALTH" then self:RefreshHealth();return
    elseif event=="UNIT_POWER_UPDATE" then self:RefreshPower(false);return
    elseif event=="UNIT_DISPLAYPOWER" or event=="UNIT_MAXPOWER" or event=="UPDATE_SHAPESHIFT_FORM" then self:RefreshPower(true)
    elseif event=="UNIT_SPELLCAST_EMPOWER_START" then self:ClearCast("EMPOWER_START");self.castEventObserved=true;self.castEventKey=eventKey(event,...);self:BindCast("empower")
    elseif event=="UNIT_SPELLCAST_EMPOWER_UPDATE" then if self.activity=="empower" then self:BindCast("empower") end
    elseif event=="UNIT_SPELLCAST_START" then self.castPublicKey=nil;self.castEventObserved=true;self.castEventKey=eventKey(event,...);self.empowered=false;self:BindCast("cast")
    elseif event=="UNIT_SPELLCAST_CHANNEL_START" then self.castPublicKey=nil;self.castEventObserved=true;self.castEventKey=eventKey(event,...);self:BindCast("channel")
    elseif event=="UNIT_SPELLCAST_DELAYED" then if self.activity=="cast" then self:BindCast("cast") end
    elseif event=="UNIT_SPELLCAST_CHANNEL_UPDATE" then if self.activity=="channel" or self.activity=="empower" then self:BindCast(self.activity) end
    elseif castEvents[event] then self:CastEndEvent(event,...)
    elseif event=="PET_BATTLE_OPENING_START" then self.petBattle=true;self:ClearCast("PET_BATTLE")
    elseif event=="PET_BATTLE_CLOSE" then self.petBattle=false;self:RefreshHealth();self:RefreshPower(true);self:ResyncCast()
    elseif event=="UNIT_ENTERED_VEHICLE" or event=="UNIT_EXITED_VEHICLE" then self:RefreshUIState();self:RefreshPower(true);self:ResyncCast()
    elseif event=="PLAYER_LEAVING_WORLD" then self.unavailableWorld=true;self:ClearCast("WORLD_LEFT")
    elseif event=="PLAYER_ENTERING_WORLD" then self.unavailableWorld=false;self.petBattle=false;self:ApplyConfig()
    elseif event=="PLAYER_DEAD" then self.playerDead=true;self:ClearCast("PLAYER_DEAD")
    elseif event=="PLAYER_ALIVE" or event=="PLAYER_UNGHOST" then
        self:ClearCast("PLAYER_RECOVERY");self:RefreshUIState();self:RefreshHealth();self:RefreshPower(true);self:ResyncCast()
    elseif event=="UI_SCALE_CHANGED" or event=="DISPLAY_SIZE_CHANGED" then
        M.HUDPercent:Invalidate(self.view,"SCALE_PENDING")
        self.viewportPending={view=self.view,profile=M.profile}
        self:RepairViewport()
    elseif event=="PLAYER_REGEN_ENABLED" then self:RepairViewport()
    end
    for _,key in ipairs({"health","resource","cast"}) do self:RefreshRowVisibility(key) end
    M.state.forceEvaluate=true
    -- No private polling loop: every visibility request goes through CVE.
    -- Core handles the combat edge. Local rows above are already current;
    -- other cast changes coalesce into the regular visibility observation.
    if event~="PLAYER_REGEN_DISABLED" and event~="PLAYER_REGEN_ENABLED" and not castEvents[event] then
        M.CVE:Tick(true)
    end
end
function H:FadeCastFeedback()
    self.castFeedbackFading=true
    local ticket,profile=self.castDelivery,M.profile
    local function current() return self.castDelivery==ticket and M.profile==profile and not self.activity and not M.state.safe end
    local bar=self.view.rows.cast
    local ok=M.Effects.Transition and M.Effects:Transition(self,bar,false,{guard=current,adaptive=false,onFinished=function()
        if current() then self:ClearCast("IDLE") end
    end})
    if not ok and current() then self:ClearCast("IDLE") end
end
function H:Tick(now)
    self:RefreshPresentation()
    self:RepairViewport()
    if self.castFeedbackUntil and not self.castFeedbackFading and now>=self.castFeedbackUntil then self:FadeCastFeedback() end
    local visible=self:RowContext("health")
    local alpha=self:RowAlpha()
    local castOnly=not visible and (self.activity~=nil or self.castFeedbackUntil~=nil)
    if visible~=self.contextRows or alpha~=self.contextAlpha or castOnly~=self.contextCastOnly then
        self.contextRows=visible;self.contextAlpha=alpha;self.contextCastOnly=castOnly
        for _,key in ipairs({"health","resource"}) do self:RefreshRowVisibility(key) end
    end
end
function H:Suspend()
    self.fishingPresentation=nil
    if self.view and self.view.content and self.presentationSuppressed then self.view.content:Show() end
    self.presentationSuppressed=nil;self.presentationSuppressionReason=nil
    self.presentationGeneration=(self.presentationGeneration or 0)+1
    self.viewportPending=nil
    self:ResetRecoveryGate();self.recovery=nil;self.recoveryAt=nil;self.recoveryStatus="SUSPENDED"
    -- /safe also runs in combat. Return the exact public native cast switch
    -- before generic HUD cleanup clears the only active player cast row.
    local casts=M.Rework and M.Rework.CombatCasts
    if casts and type(casts.ReturnNativePlayerCast)=="function" then casts:ReturnNativePlayerCast() end
    -- Row submission status is current controller work, not a retained success
    -- from the last active profile. A throwing cleanup keeps the pending label.
    for _,key in ipairs({"health","resource","cast"}) do self.rowStatus[key]="SUSPEND_PENDING" end
    if self.view then self:ClearCast("SUSPEND_PENDING");M.HUDView:Clear(self.view);M.Effects:Stop(self.surface) end
    for _,key in ipairs({"health","resource","cast"}) do self.rowStatus[key]="SUSPENDED" end
    self.status="DISABLED"
end
function H:Resume() self.unavailableWorld=false;self.status="HUD_IMPLEMENTED_NATIVE_NOT_RUN" end
function H:Report()
    return "hud=OPTIONAL_SCREEN_ANCHORED;health="..(self.rowStatus.health or "NOT_RUN")..";resource="..(self.rowStatus.resource or "NOT_RUN")..";cast="..(self.rowStatus.cast or "NOT_RUN")..";healthPercent="..M.HUDPercent:Status(self.view,"health")..";resourcePercent="..M.HUDPercent:Status(self.view,"resource")..";recovery="..(self.recoveryStatus or "NOT_RUN")..";recovery_opacity=25_PERCENT_NORMAL;recovery_truth=NATIVE_ALPHA_UNINSPECTED;activity="..(M:IsModuleActive(self.id) and "ACTIVE" or "INACTIVE")..";native=NOT_RUN"
end
M:RegisterModule("UnderCharacterHUD",H)
