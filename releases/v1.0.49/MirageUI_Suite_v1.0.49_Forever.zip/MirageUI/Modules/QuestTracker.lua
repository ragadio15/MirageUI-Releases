local _, M = ...
-- Optional compact watched-quest panel; native tracker, quest-item buttons and reward UI stay untouched.
local Q=M.modules.QuestTracker
local nativeInitialize,nativeRefresh,nativeSuspend,nativeResume,nativeApply=Q.Initialize,Q.Refresh,Q.Suspend,Q.Resume,Q.ApplyConfig
local questEvents={QUEST_LOG_UPDATE=true,QUEST_WATCH_UPDATE=true,QUEST_WATCH_LIST_CHANGED=true,QUEST_ACCEPTED=true,QUEST_REMOVED=true,QUEST_TURNED_IN=true,QUEST_DATA_LOAD_RESULT=true}
for event in pairs(questEvents) do Q.events[event]=true end
Q.events.PLAYER_LEAVING_WORLD=true
function Q:WantsEvent(event)
    return not questEvents[event] or M:ModuleConfig(self.id).compactPanel==true
end
function Q:CanInteract()
    return M:IsModuleActive(self.id) and M:ModuleConfig(self.id).compactPanel==true
        and M.CVE:InputVisible(self.panelSurface) and not M.Safety:InCombat()
end
function Q:CreatePanel()
    if self.panel then return end
    local f=M.UI:Card(UIParent,320,370);self.panel=f;f:Hide();f:SetClipsChildren(true)
    M:TrackRoot(self.id,f)
    self.heading=M.UI:Text(f,"Objectives",12,-10,14,220)
    self.footer=M.UI:Text(f,"",12,-335,10,290)
    self.rows={};self.collapsed={}
    for i=1,8 do
        local row={};self.rows[i]=row
        row.frame=CreateFrame("Frame",nil,f);row.frame:SetSize(296,80);M.Safety:Passive(row.frame)
        row.title=M.UI:Button(row.frame,"",0,0,296,function()
            if not Q:CanInteract() then row.pressedQuestID=nil;return end
            local pressed=row.pressedQuestID;row.pressedQuestID=nil
            if pressed and pressed~=row.questID then return end
            if row.questID then Q.collapsed[row.questID]=not Q.collapsed[row.questID];Q:Draw() end
            M.CVE:Hold(Q.panelSurface,.4)
        end)
        row.title.label:SetJustifyH("LEFT")
        row.title:SetScript("OnMouseDown",function(_,button) row.pressedQuestID=nil;if button=="LeftButton" and Q:CanInteract() then row.pressedQuestID=row.questID end end)
        row.title:HookScript("OnEnter",function() if Q:CanInteract() then M.CVE:Hold(Q.panelSurface,.4) end end)
        row.title:HookScript("OnLeave",function() if Q:CanInteract() then M.CVE:Hold(Q.panelSurface,.4) end end)
        row.status=M.UI:Text(row.frame,"",6,-30,10,285)
        row.lines={};for j=1,4 do row.lines[j]=M.UI:Text(row.frame,"",8,-48-(j-1)*28,11,280);row.lines[j]:SetHeight(26) end
    end
    self.openLog=M.UI:Button(f,"Quest log",212,-332,96,function()
        if not Q:CanInteract() then return end
        if type(ToggleQuestLog)=="function" then M:Guard(Q.id,ToggleQuestLog) end
        M.CVE:Hold(Q.panelSurface,.4)
    end)
    self.openLog:HookScript("OnEnter",function() if Q:CanInteract() then M.CVE:Hold(Q.panelSurface,.4) end end)
    local surface={id="QuestTracker.compact",module=self.id,frame=f,security="OWNED_VISUAL",editable=true,
        groups={objectives=true,compactObjectives=true},holdOnHover=true,fallback="HIDDEN",minWidth=240,minHeight=180,
        layout={x=.30,y=.05,width=320,height=370,scale=1}}
    self.panelSurface=surface
    surface.OnLayout=function(_,layout) Q:Size(layout.width,layout.height);Q.dirty=true end
    M.CVE:Register(surface);M.Layout:Apply(surface)
    f:SetScript("OnShow",function() Q.dirty=true end)
end
function Q:Size(width,height)
    self.width,self.height=width,height
    self.heading:SetWidth(width-24)
    self.footer:ClearAllPoints();self.footer:SetPoint("BOTTOMLEFT",12,12);self.footer:SetWidth(math.max(100,width-136));self.footer:SetHeight(26)
    self.openLog:ClearAllPoints();self.openLog:SetPoint("BOTTOMRIGHT",-12,12)
    for _,row in ipairs(self.rows) do
        row.frame:SetWidth(width-24);row.title:SetWidth(width-24);row.title.label:SetWidth(width-40);row.title.label:SetHeight(15)
        row.status:SetWidth(width-36)
        for _,line in ipairs(row.lines) do line:SetWidth(width-40) end
    end
    if self.snapshot then self:Draw() end
end
function Q:Draw()
    if not self.panel then return end
    local cfg=M:ModuleConfig(self.id);local data=self.snapshot
    if not data then return end
    local y=38;local displayed=0;local fitOmitted=0
    for _,row in ipairs(self.rows) do row.frame:Hide();row.questID=nil;row.title:SetText("");row.status:SetText("");for _,line in ipairs(row.lines) do line:SetText("") end end
    for i,item in ipairs(data.rows) do
        local row=self.rows[i];local collapsed=self.collapsed[item.id]==true
        local n=cfg.showObjectives and not collapsed and #item.objectives or 0
        local height=48+n*28+8
        if y+height>self.height-52 then fitOmitted=fitOmitted+1
        else
            row.questID=item.id;row.frame:ClearAllPoints();row.frame:SetPoint("TOPLEFT",12,-y);row.frame:SetHeight(height)
            row.title:SetText((collapsed and "+ " or "- ")..item.title)
            local text=({FAILED="Failed",COMPLETE="Complete",ACTIVE="In progress",UNKNOWN="Status unavailable"})[item.status]
            if item.partial then text=text.." · Details unavailable" elseif item.moreObjectives then text=text.." · More in quest log" end
            row.status:SetText(text)
            for j=1,n do
                local objective=item.objectives[j];row.lines[j]:SetText((objective.finished==true and "✓ " or "• ")..objective.text)
            end
            row.frame:Show();displayed=displayed+1;y=y+height+6
        end
    end
    local omitted=data.omitted+fitOmitted+data.missing
    if data.status=="UNSUPPORTED" or data.status=="RESTRICTED" then self.footer:SetText("Quest data unavailable")
    elseif #data.rows==0 then self.footer:SetText(data.status=="AVAILABLE" and "No tracked quests" or "Quest data unavailable")
    elseif omitted>0 then self.footer:SetText("More in quest log") else self.footer:SetText("Tracked quests") end
    self.displayed=displayed;self.providerStatus=data.status
end
function Q:RefreshPanel()
    if not self.panel or not M:ModuleConfig(self.id).compactPanel then return end
    local cfg=M:ModuleConfig(self.id)
    self.snapshot=M.Quests:Read(cfg.questLimit,cfg.objectiveLines,cfg.worldQuests)
    local retained={};for _,row in ipairs(self.snapshot.rows) do if self.collapsed[row.id] then retained[row.id]=true end end
    self.collapsed=retained -- Runtime-only, bounded to this snapshot; never persisted.
    self:Draw();self.dirty=false
end
function Q:Initialize()
    nativeInitialize(self)
    if M:ModuleConfig(self.id).compactPanel then self:CreatePanel() end
end
function Q:ApplyConfig()
    nativeApply(self)
    if M:ModuleConfig(self.id).compactPanel then
        self:CreatePanel();self.panelSurface.disabled=nil;M.Layout:Apply(self.panelSurface);self.dirty=true;self:RefreshPanel()
    elseif self.panel then
        self.panelSurface.disabled=true;M.Effects:Stop(self.panelSurface);self.snapshot=nil;self.collapsed={}
    end
end
function Q:OnEvent(event)
    if event=="PLAYER_LEAVING_WORLD" then
        self.snapshot=nil;self.collapsed={};self.providerStatus="STALE";self.dirty=true
        if self.panel then M.Effects:Stop(self.panelSurface) end
    elseif questEvents[event] then self.dirty=true
    else nativeRefresh(self);self.dirty=true end
end
function Q:Tick(now)
    if not self.panel or not M:ModuleConfig(self.id).compactPanel or not self.dirty then return end
    if not self.panel:IsVisible() then return end
    if M.Safety:Public(self.panel.IsMouseOver,"boolean",self.panel)==true then
        local left=M.Safety:Public(IsMouseButtonDown,"boolean","LeftButton")
        local right=M.Safety:Public(IsMouseButtonDown,"boolean","RightButton")
        if left==true or right==true then return end -- do not rearrange a pressed hit region.
    end
    if now<(self.nextRead or 0) then return end
    self.nextRead=now+.25;self:RefreshPanel()
end
function Q:Suspend()
    nativeSuspend(self);for _,row in ipairs(self.rows or {}) do row.pressedQuestID=nil end;self.snapshot=nil;self.collapsed={};self.providerStatus="SUSPENDED";self.dirty=true
    if self.panel then self.panelSurface.disabled=true;M.Effects:Stop(self.panelSurface) end
end
function Q:Resume() nativeResume(self);self.dirty=true end
