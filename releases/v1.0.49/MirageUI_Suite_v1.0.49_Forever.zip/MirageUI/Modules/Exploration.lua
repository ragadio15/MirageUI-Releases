-- Attach only after native/quest extensions have installed their own lifecycle methods.
local _, M = ...
for _,id in ipairs({"Minimap","Chat","QuestTracker"}) do
    local mod=M.modules[id]
    local apply,suspend,event=mod.ApplyConfig,mod.Suspend,mod.OnEvent
    function mod:ApplyConfig()
        if apply then apply(self) end
        M.NativeQuiet:Configure(id);M.NativeLayout:Configure(id)
    end
    function mod:Suspend()
        for _,s in pairs(M.Native.records) do if s.module==id then M.NativeQuiet:Release(s) end end
        M.NativeLayout:Restore(id)
        if suspend then suspend(self) end
    end
    function mod:OnEvent(name,...)
        if event then event(self,name,...) end
        if name=="ADDON_LOADED" or name=="PLAYER_ENTERING_WORLD" or name=="PLAYER_REGEN_ENABLED" then
            M.NativeQuiet:Configure(id);M.NativeLayout:Configure(id)
        end
    end
end
