local _,M=...
-- Extends an eligible native plate. Health/name/cast/aura providers and click
-- regions remain Blizzard-owned. No enemy existence or distance is fabricated.
M.NameplateDetails={records=setmetatable({},{__mode="k"}),count=0,limit=80}
local D,S=M.NameplateDetails,M.Safety
local function field(object,key)
 if not S:Frame(object,false) then return nil end
 local ok,value=pcall(function() return object[key] end)
 if ok and S:Readable(value) then return value end
end
local function clear(record)
 record.unit=nil
 record.level:SetText("");record.healthPercent:SetText("");record.powerPercent:SetText("")
 record.power:SetStatusBarColor(0,0,0,0)
 if record.power.mirageTrack then record.power.mirageTrack:SetColorTexture(0,0,0,0) end
end
local function percent(fs,api,unit,...)
 fs:SetText("")
 if type(api)~="function" or type(fs.SetFormattedText)~="function" then return end
 local ok,value=pcall(api,unit,...)
 if not ok or (S:Readable(value) and value==nil) then return end
 if not pcall(fs.SetFormattedText,fs,"%.0f%%",value) then fs:SetText("") end
end
local function matches(row)
 local uf=field(row.plate,"UnitFrame")
 return uf==row.uf
  and (field(field(uf,"HealthBarsContainer"),"healthBar") or field(uf,"healthBar"))==row.health
  and (field(field(uf,"CastBarsContainer"),"castBar") or field(uf,"castBar"))==row.cast
  and field(uf,"name")==row.name
end
function D:Retire(row)
 clear(row);row.stale=true;self.status="NATIVE_TREE_CHANGED_RELOAD_REQUIRED"
 if not S:InCombat() then
  M.StyleLease:Restore("NameplateDetails",row.cast)
  if S:Frame(row.frame,true) then row.frame:Hide() end
 end
end
function D:Prepare(plate,unit)
 if S:InCombat() or M.Native:Conflict() or not S:Frame(plate,true) then return false end
 local cfg=M:ModuleConfig("Nameplates")
 if not cfg.extended then return false end
 local uf=field(plate,"UnitFrame");local hc=field(uf,"HealthBarsContainer")
 local health=field(hc,"healthBar") or field(uf,"healthBar")
 local cast=field(field(uf,"CastBarsContainer"),"castBar") or field(uf,"castBar")
 local name=field(uf,"name")
 if not S:Frame(uf,true) or not S:Frame(health,true) or not S:Frame(cast,true) or not S:Frame(name,true) then return false end
 local width,status=S:Public(health.GetWidth,"number",health)
 if status~="KNOWN" or width<20 or width>600 then return false end
 local row=self.records[plate]
 if row and (row.stale or not matches(row)) then self:Retire(row);return false end
 if row and row.failed then return false end
 if not row then
  if self.count>=self.limit then return false end
  local f=CreateFrame("Frame",nil,uf);S:Passive(f)
  local power=M.UI:Bar(f,0,0,width,6,unpack(M.Visual.mana));S:Passive(power)
  power:ClearAllPoints();power:SetPoint("TOPLEFT",health,"BOTTOMLEFT",0,-5)
  row={frame=f,power=power,health=health,cast=cast,name=name,plate=plate,uf=uf}
  row.level=M.UI:Text(f,"",0,0,11,32);row.level.mirageSemanticColor=true;row.level:SetTextColor(unpack(M.Visual.level))
  row.level:ClearAllPoints();row.level:SetPoint("RIGHT",name,"LEFT",-5,0)
  row.healthPercent=M.UI:Text(f,"",0,0,11,42);row.healthPercent:SetJustifyH("LEFT");row.healthPercent.mirageSemanticColor=true;row.healthPercent:SetTextColor(unpack(M.Visual.health))
  row.healthPercent:ClearAllPoints();row.healthPercent:SetPoint("LEFT",health,"RIGHT",6,0)
  row.powerPercent=M.UI:Text(f,"",0,0,11,42);row.powerPercent:SetJustifyH("LEFT");row.powerPercent.mirageSemanticColor=true
  row.powerPercent:ClearAllPoints();row.powerPercent:SetPoint("LEFT",power,"RIGHT",6,0)
  self.records[plate]=row;self.count=self.count+1
 end
 row.power:SetWidth(width);row.unit=unit
 -- Do not introduce a second row that collides with the native cast row.
 if not M.StyleLease:Points("NameplateDetails",cast,"castBelowPower",row.hasPower==false and health or row.power,"TOPLEFT","BOTTOMLEFT",0,-5) then
  clear(row);row.failed=true;row.frame:Hide();self.status="NATIVE_ANCHOR_FALLBACK";return false
 end
 row.frame:Show();self:Update(row,true);self.status="NATIVE_PLATE_DETAILS_CANDIDATE"
 return true
end
function D:Update(row,metadata)
 if row.stale or not matches(row) then self:Retire(row);return end
 if row.failed then clear(row);return end
 local unit=row.unit;local cfg=M:ModuleConfig("Nameplates")
 if not S:Text(unit) or not cfg.extended then clear(row);return end
 local kind,access=S:Public(UnitPowerType,"number",unit)
 local hasPower,known=true,"UNKNOWN"
 if access=="KNOWN" then
  local value,state=S:Public(UnitHasPowerType,"boolean",unit,kind)
  if state=="KNOWN" then hasPower,known=value,state end
  if hasPower and not S:InCombat() then
   local capacity,public=S:Public(UnitPowerMax,"number",unit)
   if public=="KNOWN" and capacity==0 then hasPower,known=false,"KNOWN" end
  end
 end
 local sent=pcall(function() row.power:SetMinMaxValues(0,UnitPowerMax(unit));row.power:SetValue(UnitPower(unit)) end)
 local c=M.Visual.mana
 if access~="KNOWN" then c=M.Visual.neutral
 elseif kind~=0 then
  local color=S:Field(PowerBarColor,kind);local r,g,b=S:Field(color,"r"),S:Field(color,"g"),S:Field(color,"b")
  c=(S:Number(r) and S:Number(g) and S:Number(b)) and {r,g,b} or M.Visual.neutral
 end
 row.power:SetStatusBarColor(c[1],c[2],c[3],sent and hasPower and 1 or 0)
 if row.power.mirageTrack then
  if known=="KNOWN" and not hasPower then row.power.mirageTrack:SetColorTexture(0,0,0,0)
  else row.power.mirageTrack:SetColorTexture(unpack(M.Visual.track)) end
 end
 row.powerPercent:SetTextColor(c[1],c[2],c[3],1)
 local curve=CurveConstants and CurveConstants.ScaleTo100
 row.healthPercent:SetText("");row.powerPercent:SetText("")
 if cfg.showPercent and curve then
  percent(row.healthPercent,UnitHealthPercent,unit,true,curve)
  if hasPower then percent(row.powerPercent,UnitPowerPercent,unit,nil,false,curve) end
 end
 if metadata then
  local level,status=S:Public(UnitLevel,"number",unit)
  row.level:SetText(cfg.showLevel and status=="KNOWN" and level>0 and tostring(level).." |" or "")
 end
 if row.hasPower~=hasPower or row.anchorPending then
  row.hasPower=hasPower
  if S:InCombat() then row.anchorPending=true
  else
   row.anchorPending=nil
   local relative=hasPower and row.power or row.health
   if not M.StyleLease:Points("NameplateDetails",row.cast,"castBelowPower",relative,"TOPLEFT","BOTTOMLEFT",0,-5) then self.status="NATIVE_ANCHOR_FALLBACK" end
  end
 end
end
function D:Assign(plate,unit)
 local row=self.records[plate]
 if row then clear(row);row.unit=unit
  if M:IsModuleActive("Nameplates") and M:ModuleConfig("Nameplates").extended then self:Update(row,true) end
 end
 if not S:InCombat() then self:Prepare(plate,unit) end
end
function D:Remove(unit)
 for _,row in pairs(self.records) do if row.unit==unit then clear(row) end end
end
function D:Event(event,unit)
 if not M:IsModuleActive("Nameplates") then return end
 for _,row in pairs(self.records) do
  if row.unit and (not S:Text(unit) or row.unit==unit) then self:Update(row,event~="UNIT_HEALTH" and event~="UNIT_POWER_UPDATE") end
 end
end
function D:Suspend()
 for _,row in pairs(self.records) do clear(row);row.failed=nil;if not S:InCombat() and S:Frame(row.frame,true) then row.frame:Hide() end end
 M.StyleLease:Restore("NameplateDetails")
end
