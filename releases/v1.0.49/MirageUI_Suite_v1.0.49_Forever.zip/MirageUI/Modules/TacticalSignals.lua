local _,M=...
local T={commands={
 {id="TOGGLEPINGLISTENER",label="Native ping wheel"},
 {id="PINGATTACK",label="Attack — focus pressure"},
 {id="PINGASSIST",label="Assist — aid requested"},
 {id="PINGWARNING",label="Warning — danger"},
 {id="PINGONMYWAY",label="On my way — reinforcement"}}}
T.markers={"Star","Circle","Diamond","Triangle","Moon","Square","Cross","Skull"}
T.meanings={[0]="Unassigned",[1]="Primary damage",[2]="Crowd control",[3]="Danger",[4]="Aid requested",[5]="Rally",[6]="Avoid"}
for i,name in ipairs(T.markers) do T.commands[#T.commands+1]={id="RAIDTARGET"..i,label=name.." — native target marker",marker=i} end
local labels={};for _,row in ipairs(T.commands) do labels[row.id]=row.label end
-- Reuse the guarded single-key transaction, not a second binding implementation.
local K=setmetatable({history={},revision=0,status="IDLE"},{__index=M.ActionKeys});M.TacticalKeys=K
function K:IsAction(command)
 if not M.Safety:Text(command) or not labels[command] then return false end
 if command:match("^RAIDTARGET[1-8]$") then return type(SetRaidTargetIcon)=="function" or type(SetRaidTarget)=="function" end
 return C_Ping and type(C_Ping.TogglePingListener)=="function" or false
end
function K:Allowed()
 if not M:IsModuleActive("TacticalSignals") or M.Profiles.readOnly or M.Safety:InCombat() or M.state.cinematic then return false,"Enable Tactical signals and edit shortcuts outside combat." end

 for _,name in ipairs({"GetCurrentBindingSet","GetBindingAction","GetBindingKey","SetBinding","SaveBindings"}) do
  if type(_G[name])~="function" then return false,"Native keybinding functions are unavailable." end
 end
 return true
end
function K:ActionLabel(command) return labels[command] or M.ActionKeys.ActionLabel(self,command) end
function T:ConventionText(profile)
 local cfg=profile and profile.modules.TacticalSignals or M:ModuleConfig(self.id)
 local lines={"MirageUI tactical conventions", "Attack: focus pressure | Assist: aid", "Warning: danger | On my way: support"}
 for i,name in ipairs(self.markers) do local meaning=self.meanings[cfg["marker"..i] or 0];if meaning~="Unassigned" then lines[#lines+1]=name..": "..meaning end end
 lines[#lines+1]="Conventions only. No action, message, or binding was sent."
 return table.concat(lines,"\n")
end
function T:Initialize() self:ApplyConfig() end
function T:ApplyConfig()
 local native=C_Ping and type(C_Ping.TogglePingListener)=="function"
 self.status=native and "NATIVE_BINDINGS_AVAILABLE_NOT_TESTED" or "NATIVE_PING_UNSUPPORTED"
 if M:ModuleConfig(self.id).legend and not self.frame and not M.Safety:InCombat() then
  self.frame=M:TrackRoot(self.id,M.UI:Card(UIParent,300,210));self.frame:Hide()
  M.UI:Text(self.frame,"Tactical conventions · Manual",10,-10,12,230)
  self.legendText=M.UI:Text(self.frame,"",10,-33,11,230)
  self.surface={id="TacticalSignals.legend",module=self.id,frame=self.frame,security="OWNED_VISUAL",groups={},fallback="HIDDEN",userOpened=true,
   outOfCombatOnly=true,editable=true,layout={x=.30,y=.08,width=300,height=210,scale=1},minWidth=260,minHeight=180}
  M.CVE:Register(self.surface)
 end
 if self.legendText then self.legendText:SetText(self:ConventionText()) end
 if self.surface then self.surface.disabled=not M:ModuleConfig(self.id).legend;M.Layout:Apply(self.surface) end
end
function T:Suspend() K:Cancel();if self.surface then M.Effects:Stop(self.surface) end;self.status="DISABLED" end
function T:Resume() self:ApplyConfig() end
M:RegisterModule("TacticalSignals",T)
-- Intentionally no ping transmission, target changes, automatic marking, or
-- combat-time shortcut writes. Once assigned, the game owns the chosen command.
