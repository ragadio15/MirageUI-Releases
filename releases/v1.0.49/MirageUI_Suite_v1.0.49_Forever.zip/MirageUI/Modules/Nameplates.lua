local _, M = ...
-- Native health/cast/aura providers and hit regions remain authoritative. No
-- secret-value inspection, hidden threat ordering, or new nameplate click controls.
local N={events={UNIT_SPELLCAST_START=true,UNIT_SPELLCAST_STOP=true,UNIT_SPELLCAST_DELAYED=true,UNIT_SPELLCAST_FAILED=true,UNIT_SPELLCAST_INTERRUPTED=true,UNIT_SPELLCAST_CHANNEL_START=true,UNIT_SPELLCAST_CHANNEL_STOP=true,UNIT_SPELLCAST_CHANNEL_UPDATE=true,UNIT_SPELLCAST_EMPOWER_START=true,UNIT_SPELLCAST_EMPOWER_STOP=true,UNIT_HEALTH=true,UNIT_MAXHEALTH=true,UNIT_POWER_UPDATE=true,UNIT_MAXPOWER=true,UNIT_DISPLAYPOWER=true,UNIT_LEVEL=true,NAME_PLATE_UNIT_ADDED=true,NAME_PLATE_UNIT_REMOVED=true,PLAYER_REGEN_ENABLED=true,PLAYER_ENTERING_WORLD=true,UNIT_NAME_UPDATE=true,PLAYER_TARGET_CHANGED=true},plates=setmetatable({},{__mode="k"}),units={},attachQueue={}}
local function field(object,key)
 if not M.Safety:Frame(object,false) then return nil end
 local ok,v=pcall(function() return object[key] end)
 if ok and M.Safety:Readable(v) then return v end
end
local function plateUnit(plate)
 local getter=field(plate,"GetUnit")
 local unit=type(getter)=="function" and M.Safety:Public(getter,"string",plate) or nil
 if not M.Safety:Text(unit) then unit=field(plate,"unitToken") end
 if not M.Safety:Text(unit) then unit=field(plate,"namePlateUnitToken") or field(field(plate,"UnitFrame"),"unit") end
 return unit
end
function N:QueueAttach(unit,plate,profile)
 if not M.Safety:Text(unit) or not unit:match("^nameplate%d+$") then return end
 local reason=M.NameplateCards.lastRefusal
 local token=M.NameplateCards.metadataRetry
 local metadata=reason=="NAME_UNAVAILABLE" and token and M.NameplateCards:CanRetryMetadata(token,unit,plate,profile)
 if reason~="NATIVE_TREE_FALLBACK" and reason~="NATIVE_ATTACH_IN_PROGRESS" and not metadata then return end
 local row=self.attachQueue[unit]
 if row and row.plate==plate and row.profile==profile then return end
 local count=0;for _ in pairs(self.attachQueue) do count=count+1 end
 if count<80 then self.attachQueue[unit]={plate=plate,profile=profile,attempts=0,metadata=metadata and token or nil} end
end
-- The public plate field is a compatibility reference. It does not establish
-- that this module created the referenced frame or owns its new parent.
local function ownsBacking(row)
 if not row or not M.Safety:Frame(row.frame,true) then return false end
 local parent,state=M.Safety:Public(row.frame.GetParent,nil,row.frame)
 return state=="KNOWN" and parent==row.parent
end
local function hideBacking(row)
 if row and row.active and ownsBacking(row) and (not M.Safety:InCombat() or M.Safety:ChildTreePublic(row.frame)) then
  row.frame:Hide();row.active=false
 end
end
function N:Initialize() self.status="NATIVE_PLATES_PRESERVED";M.NameplateCards:Prepare();self:Refresh() end
function N:Style(plate,unit)
 local allowed,reason=M.Safety:Frame(plate,true)
 if not allowed then M.NameplateCards:Refuse(reason);self.status=M.NameplateCards.lastRefusal;return false end
 local row=self.plates[plate]
 local profile=M.profile
 local cfg=M:ModuleConfig(self.id)
 if cfg.cards then
  if M.NameplateCards:Assign(unit,plate) then
   self.attachQueue[unit]=nil;self.status=M.NameplateCards.status;hideBacking(row);return true
  end
  self.status=M.NameplateCards.lastRefusal;self:QueueAttach(unit,plate,profile)
  if M.NameplateCards.lastRefusal=="UNQUALIFIED_CLIENT_OR_OWNER" then return false end
 end
 -- A native callback can stop/reconfigure the module during initial card work.
 if M.profile~=profile or M.state.safe or not M.Client.allowed then return false end
 if M.NameplateCards:IsRestoring(plate) or M.Native:Conflict() or M.Safety:InCombat() then return false end
 if cfg.style then M.Native:Decorate(self.id,plate) end
 if not cfg.subtle then hideBacking(row) end
 if not cfg.compact and not cfg.subtle then return true end
 local uf=field(plate,"UnitFrame");if not M.Safety:Frame(uf,true) then return false end
 local healthContainer=field(uf,"HealthBarsContainer")
 local health=field(healthContainer,"healthBar") or field(uf,"healthBar")
 local castContainer=field(uf,"CastBarsContainer")
 local cast=field(castContainer,"castBar") or field(uf,"castBar")
 local name=field(uf,"name")
 if cfg.subtle then
  -- A passive substrate behind existing native regions: the native health/cast/aura
  -- hierarchy and hitbox are never hidden, reparented or replaced.
  local attached,access=M.Safety:FieldAccess(plate,"mirageSubtle")
  if not row and access=="ABSENT" and M.Safety:Frame(health,true) then
   local card=CreateFrame("Frame",nil,uf)
   M.Safety:Passive(card);card:SetPoint("BOTTOMLEFT",health,"BOTTOMLEFT",-6,-14)
   card:SetPoint("TOPRIGHT",health,"TOPRIGHT",6,24)
   if card.SetFrameLevel and uf.GetFrameLevel then
    local level=M.Safety:Public(uf.GetFrameLevel,"number",uf)
    if level then card:SetFrameLevel(math.max(0,level-1)) end
   end
   row={frame=card,parent=uf,health=health};self.plates[plate]=row
   plate.mirageSubtle=card;attached=card
  end
  if row and row.frame==attached and row.parent==uf and row.health==health and ownsBacking(row) then
   M.Visual:Panel(row.frame,(cfg.panelOpacity or 10)/100);row.frame:Show();row.active=true;row.unit=unit
  else hideBacking(row) end
  if name then M.StyleLease:Name(self.id,name,unit,cfg.nameSize) end
  if health then M.StyleLease:Color(self.id,health,"healthTint","GetStatusBarColor","SetStatusBarColor",M.Visual.health) end
  if cast then M.StyleLease:Color(self.id,cast,"castTint","GetStatusBarColor","SetStatusBarColor",M.Visual.cast) end
 end
 if not cfg.compact then return true end
 if M.Safety:Frame(healthContainer,true) then M.StyleLease:Height(self.id,healthContainer,cfg.healthHeight) end
 if M.Safety:Frame(cast,true) then M.StyleLease:Height(self.id,cast,cfg.castHeight) end
 if name and not cfg.subtle then M.StyleLease:Name(self.id,name,unit,cfg.nameSize) end
 if cfg.flatBars then if health then M.StyleLease:Bar(self.id,health) end;if cast then M.StyleLease:Bar(self.id,cast) end end
 self.status="NATIVE_HEALTH_CAST_AURA_PRESENTATION"
 return true
end
function N:Refresh(excludedUnit)
 if M.Native:Conflict() then self:Suspend();self.status="CONFLICT_NATIVE_OWNER";return end
 if M.Safety:InCombat() and not M:ModuleConfig(self.id).cards then self.status="NATIVE_COMBAT_FALLBACK";return end
 if C_NamePlate and type(C_NamePlate.GetNamePlates)=="function" then
  local list,status=M.Safety:Public(C_NamePlate.GetNamePlates,"table")
  if status=="KNOWN" then
   for i=1,80 do
    local plate,access=M.Safety:Field(list,i);if access~="KNOWN" then break end
    local unit=plateUnit(plate)
    if excludedUnit==nil or unit~=excludedUnit then self:Style(plate,unit) end
    if unit~=excludedUnit and M.Safety:Text(unit) and unit:match("^nameplate%d+$") then self.units[unit]=plate;if not M.NameplateCards.byUnit[unit] and not M.NameplateCards:IsRestoring(plate) then M.NameplateDetails:Assign(plate,unit) end end
   end
  end
 end
 for unit,plate in pairs(self.units) do if not M.NameplateCards.byUnit[unit] and not M.NameplateCards:IsRestoring(plate) then M.NameplateDetails:Prepare(plate,unit) end end
end
function N:OnEvent(event,unit)
 M.NameplateCards:Event(event,unit)
 if event:find("SPELLCAST",1,true) then return end
 if M.Safety:Text(unit) and M.NameplateCards.byUnit[unit] and event~="NAME_PLATE_UNIT_ADDED" then return end
 if event=="UNIT_HEALTH" or event=="UNIT_MAXHEALTH" or event=="UNIT_POWER_UPDATE" or event=="UNIT_MAXPOWER" or event=="UNIT_DISPLAYPOWER" or event=="UNIT_LEVEL" then M.NameplateDetails:Event(event,unit);return end
 if event=="NAME_PLATE_UNIT_REMOVED" then
  if M.Safety:Text(unit) then
   self.attachQueue[unit]=nil
   local row=self.plates[self.units[unit]]
   if row and row.unit==unit then hideBacking(row) end
   M.NameplateDetails:Remove(unit);self.units[unit]=nil
  end
  -- Native pools can reuse regions. Restore only properties still bearing our write.
  if not M.Safety:InCombat() then M.StyleLease:Restore(self.id);self:Refresh(unit) end
 elseif event=="NAME_PLATE_UNIT_ADDED" and M.Safety:Text(unit) and unit:match("^nameplate%d+$") and C_NamePlate then
  local plate=M.Safety:Public(C_NamePlate.GetNamePlateForUnit,nil,unit)
  if M.Safety:Frame(plate,false) then self.units[unit]=plate;self:Style(plate,unit);if not M.NameplateCards.byUnit[unit] and not M.NameplateCards:IsRestoring(plate) then M.NameplateDetails:Assign(plate,unit) end end
 else self:Refresh() end
end
function N:Suspend()
 self.attachQueue={}
 M.NameplateCards:Suspend()
 M.NameplateDetails:Suspend()
 M.Native:Restore(self.id);M.StyleLease:Restore(self.id);self.units={}
 for _,row in pairs(self.plates) do hideBacking(row) end
end
function N:Resume() self:Refresh();for unit,plate in pairs(self.units) do if not M.NameplateCards.byUnit[unit] and not M.NameplateCards:IsRestoring(plate) then M.NameplateDetails:Assign(plate,unit) end end end
function N:ApplyConfig()
 self.attachQueue={}
 M.NameplateCards:Suspend();M.NameplateCards:Prepare()
 M.NameplateDetails:Suspend()
 M.StyleLease:Restore(self.id)
 if not M:ModuleConfig(self.id).style then M.Native:Undecorate(self.id) end
 self:Refresh();for unit,plate in pairs(self.units) do if not M.NameplateCards.byUnit[unit] and not M.NameplateCards:IsRestoring(plate) then M.NameplateDetails:Assign(plate,unit) end end
end
function N:Tick(now)
 if M:ModuleConfig(self.id).cards and now>=(self.checkAt or 0) then
  self.checkAt=now+.25;M.NameplateCards:Tick()
  -- Incomplete native children and initial unavailable public names receive
  -- at most three attempts. Metadata retries retain the original public
  -- alpha/input/parent witness; another owner's changes cancel the retry.
  for unit,row in pairs(self.attachQueue) do
   local plate=M.Safety:Public(C_NamePlate and C_NamePlate.GetNamePlateForUnit,nil,unit)
   if self.attachQueue[unit]==row then
    if row.profile~=M.profile or M.state.safe or not M.Client.allowed or plate~=row.plate or row.attempts>=3
      or (row.metadata and not M.NameplateCards:CanRetryMetadata(row.metadata,unit,plate,row.profile)) then
     self.attachQueue[unit]=nil
    else
     row.attempts=row.attempts+1
     self:Style(plate,unit)
     local reason=M.NameplateCards.lastRefusal
     local retry=reason=="NATIVE_TREE_FALLBACK" or reason=="NATIVE_ATTACH_IN_PROGRESS" or (row.metadata and reason=="NAME_UNAVAILABLE")
     if self.attachQueue[unit]==row and (row.attempts>=3 or not retry) then self.attachQueue[unit]=nil end
    end
   end
  end
 end
end
M:RegisterModule("Nameplates",N)
