local _, M = ...
local C=M:CreateNativeModule("Cooldowns",{"EssentialCooldownViewer","UtilityCooldownViewer","BuffIconCooldownViewer","BuffBarCooldownViewer"},{combat=true},false)
local nativeRefresh,nativeApply=C.Refresh,C.ApplyConfig
local S=M.Safety
local trackerEvents={SPELL_UPDATE_COOLDOWN=true,SPELL_UPDATE_CHARGES=true,SPELLS_CHANGED=true,
    PLAYER_SPECIALIZATION_CHANGED=true,PLAYER_TALENT_UPDATE=true,SPELL_DATA_LOAD_RESULT=true,PLAYER_LEAVING_WORLD=true}
for event in pairs(trackerEvents) do C.events[event]=true end
C.slots={}
function C:WantsEvent(event)
    return not trackerEvents[event] or M:ModuleConfig(self.id).tracker
end
function C:EndHover(tile,attempt)
    if not self.hoverTile or (tile and tile~=self.hoverTile) or (attempt and attempt~=self.hoverAttempt) then return end
    local old,tip,epoch=self.hoverTile,self.hoverTip,self.hoverEpoch
    self.hoverTile,self.hoverTip,self.hoverAttempt=nil,nil,nil
    if S:Frame(tip,false) and S:Public(tip.GetOwner,nil,tip)==old and self.hoverEpoch==epoch then pcall(tip.Hide,tip) end
end
function C:Hover(tile)
    if not M.CVE:InputVisible(self.surface) then return end
    local meta=tile.metadata
    self.hoverEpoch=(self.hoverEpoch or 0)+1
    local epoch=self.hoverEpoch
    local function current()
        if self.hoverEpoch~=epoch or self.metadataPending or not meta or meta~=tile.metadata or not meta.ready or not M:IsModuleActive(self.id) then return false end
        local cfg=M:ModuleConfig(self.id)
        local entry=cfg.spells[tile.index]
        return cfg.tracker and entry and entry.id==meta.id and entry.mode==tile.mode and tile:IsVisible()
    end
    local tip=GameTooltip
    if not current() or not S:Frame(tip,false) or type(tip.GetOwner)~="function" or type(tip.SetSpellByID)~="function" then return end
    local previous=self.hoverTile
    local readable,owner=pcall(tip.GetOwner,tip)
    if not readable or not S:Readable(owner) or not current() then return end
    self:EndHover()
    local read,now=pcall(tip.GetOwner,tip)
    if not read or not S:Readable(now) or not current() then return end
    if now~=owner and not (previous==owner and now==nil) then return end
    local attempt={}
    self.hoverTile,self.hoverTip,self.hoverAttempt=tile,tip,attempt
    local function owns()
        return S:Public(tip.GetOwner,nil,tip)==tile and self.hoverAttempt==attempt and current()
    end
    if not pcall(tip.SetOwner,tip,tile,"ANCHOR_TOP") or not owns() or not pcall(tip.SetSpellByID,tip,meta.id)
        or not owns() or not pcall(tip.AddLine,tip,meta.reason,1,1,1,true)
        or not owns() or not pcall(tip.AddLine,tip,"Display only. An empty sweep does not mean this spell can be cast.",.8,.8,.8,true)
        or not owns() or not pcall(tip.Show,tip) or not owns() then self:EndHover(tile,attempt);return end
    M.CVE:Hold(self.surface,.4)
end
function C:CreateTracker()
    if self.frame or S:InCombat() then return end
    self.frame=M:TrackRoot(self.id,M.UI:Card(UIParent,268,64));self.frame:Hide()
    self.frame:SetScript("OnHide",function()
        self:EndHover();self.wasVisible=false
        if M:IsModuleActive(self.id) and M:ModuleConfig(self.id).tracker then self:Invalidate() end
    end)
    for i=1,12 do
        local tile=M.UI:Card(self.frame,36,36);tile:Hide();tile.index=i
        tile.icon=tile:CreateTexture(nil,"ARTWORK");tile.icon:SetPoint("TOPLEFT",2,-2);tile.icon:SetPoint("BOTTOMRIGHT",-2,2)
        tile.timer=CreateFrame("Cooldown",nil,tile,"CooldownFrameTemplate");tile.timer:SetAllPoints(tile.icon)
        S:Passive(tile.timer)
        tile.label=M.UI:Text(tile,"",0,-40,10,60);tile.label:SetJustifyH("CENTER")
        tile.badge=M.UI:Text(tile,"",3,-3,11,28)
        if tile.SetMouseClickEnabled and tile.SetMouseMotionEnabled then tile:SetMouseClickEnabled(false);tile:SetMouseMotionEnabled(true) end
        tile:SetScript("OnEnter",function() self:Hover(tile) end)
        tile:SetScript("OnLeave",function() self:EndHover(tile) end)
        self.slots[i]=tile
    end
    self.surface={id="Cooldowns.tracked",module=self.id,frame=self.frame,security="OWNED_VISUAL",groups={combat=true},fallback="HIDDEN",editable=true,holdOnHover=true,
        minWidth=24,minHeight=16,layout={x=0,y=-.30,width=268,height=64,scale=1}}
    self.surface.OnLayout=function(_,layout) self:LayoutTiles(layout) end
    M.CVE:Register(self.surface)
end
local function labelFit(tile,cfg)
    tile.label:Hide()
    if not cfg.showNames or not tile.metadata then tile.labelStatus="WITHHELD";return end
    local f=tile.label
    local width=S:Public(f.GetUnboundedStringWidth,"number",f)
    local height=S:Public(f.GetStringHeight,"number",f)
    local truncated,access=S:Public(f.IsTruncated,"boolean",f)
    if not width or width<=0 or not height or height<=0 or access~="KNOWN" then tile.labelStatus="FIT_UNKNOWN";return end
    if truncated or width>cfg.iconSize or height>18 then tile.labelStatus="TEXT_DOES_NOT_FIT";return end
    f:Show();tile.labelStatus="FITS"
end
local function dimensions(cfg)
    -- This retired optional panel has twelve physical slots. The current row
    -- supports the complete 160-entry profile without changing this capacity.
    local count=math.min(12,#cfg.spells)
    local cols=math.min(cfg.columns,math.max(1,count))
    local rows=math.max(1,math.ceil(count/cols))
    local label=cfg.showNames and 20 or 0
    return 12+cols*cfg.iconSize+(cols-1)*cfg.gap,12+rows*(cfg.iconSize+label)+(rows-1)*cfg.gap,cols,label
end
function C:LayoutTiles(layout)
    local cfg=M:ModuleConfig(self.id)
    local width,height,cols,label=dimensions(cfg)
    self.layoutFits=layout.width>=width and layout.height>=height
    self.surface.disabled=not cfg.tracker or #cfg.spells==0 or not self.layoutFits
    if self.surface.disabled then
        self:EndHover();M.Effects:Stop(self.surface)
        if not self.layoutFits then self.trackerStatus="LAYOUT_DOES_NOT_FIT" end
        return
    end
    for i,tile in ipairs(self.slots) do
        local size=cfg.iconSize
        tile:SetSize(size,size);tile:ClearAllPoints();tile:SetPoint("TOPLEFT",6+((i-1)%cols)*(size+cfg.gap),-6-math.floor((i-1)/cols)*(size+cfg.gap+label))
        tile.label:ClearAllPoints();tile.label:SetPoint("TOP",tile,"BOTTOM",0,-3);tile.label:SetWidth(size);tile.label:SetHeight(18)
        labelFit(tile,cfg)
        if tile.timer.SetHideCountdownNumbers then tile.timer:SetHideCountdownNumbers(not cfg.showNumbers) end
    end
    self.dirty=true
end
local function resetTile(tile,entry)
    tile.spellID=entry and entry.id;tile.mode=entry and entry.mode
    tile.metadata=nil;tile.failures=0;tile.timerStatus="NOT_RUN"
    tile.timer:Hide()
    if tile.timer.Clear then pcall(tile.timer.Clear,tile.timer) end
    tile.icon:SetTexture(nil);tile.label:SetText("");tile.label:Hide()
    tile.badge:SetText(entry and "?" or "");tile:SetShown(entry~=nil)
end
function C:Invalidate(force)
    self.revision=(self.revision or 0)+1
    self:EndHover()
    local cfg=M:ModuleConfig(self.id)
    if force or not self.metadataPending then
        for i,tile in ipairs(self.slots) do resetTile(tile,cfg.tracker and cfg.spells[i] or nil) end
    end
    self.metadataPending=true;self.dirty=true
    if self.surface and not self.surface.disabled then self.trackerStatus="METADATA_PENDING" end
end
function C:Configure()
    local cfg=M:ModuleConfig(self.id)
    if S:InCombat() then self:Invalidate();return end
    if cfg.tracker then self:CreateTracker() end
    if not self.frame then return end
    self:Invalidate(true)
    self.surface.layout.width,self.surface.layout.height=dimensions(cfg)
    self.nextRefresh=0
    M.Layout:Apply(self.surface)
    if not cfg.tracker then self.trackerStatus="DISABLED" elseif #cfg.spells==0 then self.trackerStatus="EMPTY_LIST" end
end
function C:Initialize() nativeRefresh(self);self:Configure() end
function C:ApplyConfig() nativeApply(self);self:Configure() end
function C:ResolveMetadata(cfg)
    local revision=self.revision
    self.metadataPending=false
    -- Bounded by the validated, ordered legacy list. Never resolve hidden tiles or accept
    -- the identity in an asynchronous result as a replacement for the configured identity.
    for i,entry in ipairs(cfg.spells) do
        local tile=self.slots[i]
        if not tile then break end
        local meta
        if entry.mode~="Cooldown" and entry.mode~="Recharge" then
            -- Item and aura identities must never be passed to a spell
            -- cooldown query by the legacy panel's ability-only adapter.
            meta={ready=false,status="Tracked row required",reason="Use Displays > Cooldowns > Tracked cooldown row for buffs, debuffs and item timers."}
        else meta=M.Spells:Resolve(tostring(entry.id)) end
        if self.revision~=revision then return end
        if meta.id and meta.id~=entry.id then
            meta={ready=false,status="Unavailable",reason="Spell information returned a different identity."}
        end
        tile.metadata=meta
        tile.icon:SetTexture(meta.icon or 134400)
        tile.label:SetText(meta.name or ("Spell "..entry.id))
        labelFit(tile,cfg)
    end
end
function C:RefreshTimers()
    local cfg=M:ModuleConfig(self.id);local limited=false
    local revision=self.revision
    if not cfg.tracker or self.surface.disabled or not self.frame:IsVisible() then return end
    for _,tile in ipairs(self.slots) do
        if tile.spellID then
            if tile.mode~="Cooldown" and tile.mode~="Recharge" then
                tile.timer:Hide();if tile.timer.Clear then pcall(tile.timer.Clear,tile.timer) end
                tile.timerStatus="TRACKED_ROW_REQUIRED"
            elseif not self.metadataPending and tile.metadata and tile.metadata.ready and tile.failures<3 then
                local ok,result
                if tile.mode=="Recharge" then
                    ok,result=pcall(M.Display.Cooldown,M.Display,tile.timer,C_Spell and C_Spell.GetSpellChargeDuration,tile.spellID)
                else
                    ok,result=pcall(M.Display.Cooldown,M.Display,tile.timer,C_Spell and C_Spell.GetSpellCooldownDuration,tile.spellID,cfg.ignoreGCD)
                end
                if revision~=self.revision then tile.timer:Hide();return end
                tile.timerStatus=ok and result or "UNAVAILABLE"
                tile.timer:SetShown(tile.timerStatus=="NATIVE_WIDGET_DISPATCH")
                tile.failures=tile.timerStatus=="UNAVAILABLE" and tile.failures+1 or 0
                if tile.failures==3 then tile.timerStatus="SOURCE_PAUSED" end
            elseif tile.failures<3 then
                tile.timer:Hide()
                if tile.timer.Clear then pcall(tile.timer.Clear,tile.timer) end
                tile.timerStatus="METADATA_UNAVAILABLE"
            end
            local unknown=tile.timerStatus~="NATIVE_WIDGET_DISPATCH"
            tile.badge:SetText(unknown and "?" or "");limited=limited or unknown
        end
    end
    self.trackerStatus=limited and "PARTIAL_UNAVAILABLE" or "NATIVE_DURATION_PRESENTATION"
end
function C:OnEvent(event,value)
    if event=="SPELL_UPDATE_COOLDOWN" or event=="SPELL_UPDATE_CHARGES" then self.dirty=true;return end
    if event=="PLAYER_SPECIALIZATION_CHANGED" and S:Text(value) and value~="player" then return end
    if event=="SPELL_DATA_LOAD_RESULT" then
        if not S:Number(value) then self:Invalidate();return end
        local selected=false
        for _,entry in ipairs(M:ModuleConfig(self.id).spells) do
            if entry.id==value then selected=true;break end
        end
        if not selected then return end
    elseif not trackerEvents[event] then
        nativeRefresh(self)
        if event=="ADDON_LOADED" then return end
    end
    if M:ModuleConfig(self.id).tracker then self:Invalidate() end
end
function C:Tick(now)
    if not self.frame or self.surface.disabled or not M:ModuleConfig(self.id).tracker then return end
    if not self.frame:IsVisible() then self.wasVisible=false;self.dirty=true;return end
    if (self.dirty or not self.wasVisible) and now>=(self.nextRefresh or 0) then
        local revision=self.revision
        self.nextRefresh=now+.10;self.dirty=false
        if self.metadataPending and not S:InCombat() then self:ResolveMetadata(M:ModuleConfig(self.id)) end
        if self.revision==revision then self:RefreshTimers() end
    end
    self.wasVisible=true
end
function C:Suspend()
    self.revision=(self.revision or 0)+1
    self:EndHover()
    M.Native:Restore(self.id)
    if self.surface then M.Effects:Stop(self.surface) end
    for _,tile in ipairs(self.slots) do resetTile(tile,nil) end
    self.wasVisible=false;self.dirty=true;self.metadataPending=true;self.trackerStatus="SUSPENDED"
end
function C:Resume() nativeRefresh(self);self:Configure() end
