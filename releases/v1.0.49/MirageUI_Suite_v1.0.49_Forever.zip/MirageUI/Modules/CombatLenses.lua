local _,M=...
-- A manual presentation choice. It never infers unseen enemies, combat odds,
-- cooldowns, DR, class mechanics or battleground objectives.
local P={events={GROUP_ROSTER_UPDATE=true,ZONE_CHANGED_NEW_AREA=true,PLAYER_ENTERING_WORLD=true,PLAYER_LEAVING_WORLD=true,NAME_PLATE_UNIT_ADDED=true,NAME_PLATE_UNIT_REMOVED=true,PLAYER_TARGET_CHANGED=true,PLAYER_FOCUS_CHANGED=true,UPDATE_MOUSEOVER_UNIT=true,UNIT_NAME_UPDATE=true},names={"Duel","Roaming","Skirmish","Warband","Battleground"}}
M.CombatLenses=P
local contextEvents={GROUP_ROSTER_UPDATE=true,ZONE_CHANGED=true,ZONE_CHANGED_INDOORS=true,ZONE_CHANGED_NEW_AREA=true,PLAYER_ENTERING_WORLD=true,PLAYER_LEAVING_WORLD=true,PLAYER_REGEN_DISABLED=true,PLAYER_REGEN_ENABLED=true,CINEMATIC_START=true,CINEMATIC_STOP=true}
for event in pairs(contextEvents) do P.events[event]=true end
local badgeOrigins={Manual="manual",["Manual fallback"]="fallback",["Native instance"]="instance",["Native raid"]="raid",["Native group"]="group",["Context unavailable; retained lens"]="unknown"}
local emphasis={
 {UnitFrames=true,ResourceBars=true,Cursor=true},
 {Nameplates=true,UnitFrames=true,Cursor=true},
 {PartyRaid=true,UnitFrames=true,Cooldowns=true},
 {PartyRaid=true,Nameplates=true},
 {PartyRaid=true,UnitFrames=true,ResourceBars=true},
}
function P:WantsEvent(event)
 local cfg=M:ModuleConfig(self.id)
 if event=="NAME_PLATE_UNIT_ADDED" or event=="NAME_PLATE_UNIT_REMOVED" or event=="PLAYER_TARGET_CHANGED" or event=="PLAYER_FOCUS_CHANGED" or event=="UPDATE_MOUSEOVER_UNIT" or event=="UNIT_NAME_UPDATE" then return cfg.contacts end
 return cfg.automaticLens or (event=="ZONE_CHANGED_NEW_AREA" and cfg.contacts) or event=="PLAYER_LEAVING_WORLD" or event=="PLAYER_ENTERING_WORLD"
end
-- Provisional cosmetic policy, NOT source freshness or native timing acceptance.
P.candidateDelay=.30;P.autoInterval=1.00
local function owner(self)
 local c=M.Client;local p=M.Policy;local a=M.adapter;local cfg=M:ModuleConfig(self.id)
 return {profile=M.profile,cfg=cfg,lens=cfg.lens,automatic=cfg.automaticLens,
  client=c,key=c.key,allowed=c.allowed,adapter=a,source=a.sourceCommit,matched=c.sourceMatched,experimental=c.experimental,
  context=p.contextEpoch,capability=p.capabilityEpoch,scope=p.scopeEpoch}
end
local function same(a,b)
 if not a or not b then return false end
 for k,v in pairs(a) do if b[k]~=v then return false end end
 for k,v in pairs(b) do if a[k]~=v then return false end end
 return true
end
function P:Eligible()
 return M:IsModuleActive(self.id) and not M.state.cinematic
end
function P:Paint()
 local suffix=badgeOrigins[self.origin] or (self.pending and "pending" or "unknown")
 if self.label then self.label:SetText(self.names[self.lens].." · "..suffix) end
 local prefix=self.pending and "CONTEXT_PENDING_HELD_" or self.origin=="Manual" and "MANUAL_" or self.origin=="Manual fallback" and "MANUAL_FALLBACK_" or self.origin=="Context unavailable; retained lens" and "CONTEXT_UNKNOWN_RETAINED_" or "PUBLIC_CONTEXT_"
 self.status=prefix..string.upper(self.names[self.lens]);M.state.forceEvaluate=true
end
function P:CancelTransition(reason,resetClock,skipPaint)
 self.generation=(self.generation or 0)+1;self.pending=nil
 if resetClock then self.lastClock=nil;self.lastAutoCommitAt=nil;self.vitals=nil;self.owner=nil end
 self.cancelReason=reason
 if self.lens then self.origin="Context unavailable; retained lens";if not skipPaint then self:Paint() end end
end
function P:Clock()
 local generation=self.generation
 local now,status=M.Safety:Public(GetTime,"number")
 if generation~=self.generation then return nil end
 if status~="KNOWN" or now<0 or (self.lastClock and now<self.lastClock) then return nil end
 self.lastClock=now -- retain every observed high-water, even if a later read fails
 return now
end
function P:Vitals(now)
 local out={}
 for _,id in ipairs({"PLAYER_DEAD","PLAYER_GHOST"}) do
  local row=M.Store:Get(id,now)
  out[id]=tostring(row.version)..":"..tostring(row.status)..":"..tostring(row.contextEpoch)
 end
 return out
end
function P:SelectLens()
 local cfg=M:ModuleConfig(self.id)
 if not cfg.automaticLens then
  self:CancelTransition("MANUAL",true);self.lens=cfg.lens;self.origin="Manual";self:Paint();return
 end
 if self.sampling then self:CancelTransition("REENTRANT_SAMPLE");return end
 if not self:Eligible() then self:CancelTransition("INACTIVE",true);return end
 local captured=owner(self)
 if not same(self.owner,captured) then self:CancelTransition("OWNER_CHANGED");self.owner=captured end
 self.generation=(self.generation or 0)+1;local generation=self.generation
 self.sampling=true
 local instanceAPI,raidAPI,groupAPI,clockAPI=IsInInstance,IsInRaid,IsInGroup,GetTime
 local function current() return self.generation==generation and self:Eligible() and same(captured,owner(self)) and instanceAPI==IsInInstance and raidAPI==IsInRaid and groupAPI==IsInGroup and clockAPI==GetTime end
 local now=self:Clock()
 local instance,kind,known,raid,rs,group,gs
 if now and current() and type(IsInInstance)=="function" then
  local ok,a,b=pcall(IsInInstance)
  if ok and M.Safety:Readable(a) and type(a)=="boolean" and M.Safety:Text(b) then instance,kind,known=a,b,true end
 end
 if now and current() then raid,rs=M.Safety:Public(IsInRaid,"boolean") end
 if now and current() then group,gs=M.Safety:Public(IsInGroup,"boolean") end
 -- The last provider can consume time or change lifecycle. A final readable
 -- clock and pure owner check precede publication; never renew a cancelled sample.
 local finish
 if now and current() then finish=self:Clock() end
 local valid=current();self.sampling=false
 if not valid then
  if self.generation==generation then self:CancelTransition("SAMPLE_OWNER_CHANGED") end
  return
 end
 if not now or not finish or finish<now then self:CancelTransition("CLOCK_UNKNOWN");self.retryClock=true;return end
 self.retryClock=nil;self.lastClock=finish;self.vitals=self:Vitals(finish)
 if not known or rs~="KNOWN" or gs~="KNOWN" then self:CancelTransition("CONTEXT_UNKNOWN");return end
 local lens,origin=cfg.lens,"Manual fallback"
 if instance and kind=="pvp" then lens,origin=5,"Native instance"
 elseif raid then lens,origin=4,"Native raid"
 elseif group then lens,origin=3,"Native group" end
 if lens==self.lens then self.pending=nil;self.origin=origin
 else
  local pending=self.pending
  if not pending or pending.lens~=lens or pending.origin~=origin then
   pending={lens=lens,origin=origin,firstObservedAt=finish,due=math.max(finish+self.candidateDelay,(self.lastAutoCommitAt or -math.huge)+self.autoInterval)}
   self.pending=pending
  elseif finish>=pending.due then
   self.lens=lens;self.origin=origin;self.lastAutoCommitAt=finish;self.pending=nil
  end
  if self.pending then self.origin="Context pending; retained lens" end
 end
 self:Paint()
end
function P:OnEvent(event,unit)
 -- Contact notifications do not sample context. Lifecycle invalidation is not
 -- an assertion of a new lens; known context still passes the cosmetic debounce.
 if contextEvents[event] then
  if event~="GROUP_ROSTER_UPDATE" then self:CancelTransition(event,event=="PLAYER_LEAVING_WORLD") end
  self:SelectLens()
 end
 M.ObservedContacts:OnEvent(event,unit)
end
function P:Tick(now)
 if self.ticking or self.sampling then self:CancelTransition("REENTRANT_TICK");return end
 self.ticking=true;local generation=self.generation
 local ok,failure=pcall(function()
  M.ObservedContacts:Tick(now) -- independent even when lens timing is unavailable
  if generation==self.generation then self:TickLens(now) end
 end)
 self.ticking=false -- release only when the owning operation unwinds
 if not ok then error(failure,0) end -- retain existing M:Guard fault classification
end
function P:TickLens(now)
 local cfg=M:ModuleConfig(self.id)
 if not cfg.automaticLens then return end
 if not self:Eligible() then self:CancelTransition("INACTIVE",true);return end
 if self.sampling then self:CancelTransition("REENTRANT_TICK");return end
 local captured=owner(self);local generation=self.generation
 local clock=self:Clock()
 if generation~=self.generation then return end
 if not same(captured,owner(self)) or not self:Eligible() then self:CancelTransition("TICK_OWNER_CHANGED");return end
 if not clock then self:CancelTransition("CLOCK_UNKNOWN");self.retryClock=true;return end
 self.lastClock=clock
 local vitals=self:Vitals(clock)
 local changed=self.retryClock or not same(self.owner,captured) or (self.vitals and not same(self.vitals,vitals))
 self.vitals=vitals
 if changed then self:CancelTransition("CONTEXT_CHANGED");self:SelectLens()
 elseif self.pending and clock>=self.pending.due then self:SelectLens() end
end
function P:Initialize() self:ApplyConfig() end
function P:ApplyConfig()
 local cfg=M:ModuleConfig(self.id)
 if self.preferenceLens~=cfg.lens or self.preferenceAuto~=cfg.automaticLens or not self.lens then
  self:CancelTransition("PREFERENCE_CHANGED",true);self.lens=cfg.lens;self.origin="Manual"
  self.preferenceLens=cfg.lens;self.preferenceAuto=cfg.automaticLens
 end
 if cfg.badge and not self.frame and not M.Safety:InCombat() then
  self.frame=M:TrackRoot(self.id,M.UI:Card(UIParent,210,28));self.frame:Hide()
  self.label=M.UI:Text(self.frame,"",8,-8,11,194)
  self.surface={id="PvP.lens",module=self.id,frame=self.frame,security="OWNED_VISUAL",groups={combat=true},fallback="HIDDEN",activeCombatOnly=true,editable=true,
    layout={x=.32,y=.30,width=210,height=28,scale=1},minWidth=150,minHeight=28}
  self.surface.OnLayout=function(_,layout) self.label:SetWidth(layout.width-16) end
  M.CVE:Register(self.surface)
 end
 if self.surface then
  self.surface.disabled=not cfg.badge;self.label:SetText(self.names[self.lens].." · Manual")
  M.Layout:Apply(self.surface)
 end
 self:SelectLens();M.ObservedContacts:Configure()
 M.state.forceEvaluate=true
end
function P:Intent(surface,snapshot)
 if not M:IsModuleActive(self.id) then return end
 local row=snapshot and snapshot.PLAYER_IN_COMBAT
 if not row or row.status~="KNOWN" or not row.decisionEligible or not M.Safety:Readable(row.value) or row.value~=true then return end
 if surface.id=="PvP.lens" then return "VISIBLE" end
 local lens=emphasis[self.lens]
 if lens and lens[surface.module] then return "EMPHASIZED" end
end
function P:Suspend()
 -- Retire state without repainting a badge that is being stopped. A cosmetic
 -- native text failure must never prevent contact purging or effect cleanup.
 self:CancelTransition("SUSPENDED",true,true);M.ObservedContacts:Clear()
 if M.ObservedContacts.surface then M.Effects:Stop(M.ObservedContacts.surface) end
 if self.surface then M.Effects:Stop(self.surface) end
 self.status="DISABLED"
end
function P:Resume() self:ApplyConfig() end
M:RegisterModule("PvP",P)
