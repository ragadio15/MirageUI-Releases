local _,M=...
-- Current explicitly exposed units only. This is NOT an enemy detector, combat
-- log, target selector, complete opponent count or persistent identity history.
M.ObservedContacts={records={},sequence=0,limit=80,notes=0,status="DISABLED"}
local O,S=M.ObservedContacts,M.Safety
local aliases={target=true,focus=true,mouseover=true}
function O:Eligible(unit)
    if not S:Text(unit) or not (aliases[unit] or unit:match("^nameplate%d+$")) then return nil end
    -- Bracket the public metadata with identity observations. A recycled token
    -- cannot combine one subject's eligibility with another subject's name.
    local id,status=S:Public(UnitGUID,"string",unit)
    if status~="KNOWN" or id=="" then return nil end
    if S:Public(UnitExists,"boolean",unit)~=true or S:Public(UnitIsPlayer,"boolean",unit)~=true or S:Public(UnitCanAttack,"boolean","player",unit)~=true then return nil end
    local name,known=S:Public(UnitName,"string",unit)
    if known~="KNOWN" or name=="" then return nil end
    local current,access=S:Public(UnitGUID,"string",unit)
    if access~="KNOWN" or current~=id then return nil end
    return id,name
end
function O:Refresh(unit)
    if not S:Text(unit) then return end
    if not M:IsModuleActive("PvP") or not M:ModuleConfig("PvP").contacts then self.records[unit]=nil;return end
    local id,name=self:Eligible(unit)
    if not id then self.records[unit]=nil;return end
    if unit:match("^nameplate") then
        local plate=S:Public(C_NamePlate and C_NamePlate.GetNamePlateForUnit,nil,unit)
        if not S:Frame(plate,false) then self.records[unit]=nil;return end
    end
    local row=self.records[unit]
    if not row then local count=0;for _ in pairs(self.records) do count=count+1 end;if count>=self.limit then self.status="OBSERVED_POOL_LIMIT";return end end
    if not row or row.id~=id then
        self.sequence=self.sequence+1;row={unit=unit,id=id,revision=self.sequence};self.records[unit]=row
    end
    row.name=name;row.updatedAt=S:Now();self.status="CURRENT_OBSERVATIONS_ONLY";return row
end
function O:Remove(unit) self.records[unit]=nil end
local function clearRow(row)
    row.frame:Hide();row.name:SetText("");row.detail:SetText("")
end
function O:ClearRows()
    if self.rows then for _,row in ipairs(self.rows) do clearRow(row) end end
    self.wasVisible=false;self.recheckAt=nil;self.textAt=nil;self.dirty=true
end
function O:Clear()
    self.records={};self.sequence=self.sequence+1;self.notes=0;self.status="DISABLED_OR_CONTEXT_CHANGED"
    self:ClearRows()
end
function O:Create()
    if self.frame or S:InCombat() then return end
    self.frame=M:TrackRoot("PvP",M.UI:Card(UIParent,260,290));S:Passive(self.frame)
    self.title=M.UI:Text(self.frame,"Observed now · not all opponents",8,-8,11,244);self.rows={}
    for i=1,8 do
        local f=CreateFrame("Frame",nil,self.frame);S:Passive(f);f:SetSize(244,28);f:SetPoint("TOPLEFT",8,-28-(i-1)*31)
        local name=M.UI:Text(f,"",0,0,11,244);M.Visual:PlainName(name,11);name.mirageSemanticColor=true
        local detail=M.UI:Text(f,"",0,-13,10,244)
        self.rows[i]={frame=f,name=name,detail=detail};f:Hide()
    end
    self.surface={id="PvP.observed",module="PvP",frame=self.frame,security="OWNED_PASSIVE_VISUAL",groups={combat=true},fallback="HIDDEN",activeCombatOnly=true,editable=true,minWidth=200,minHeight=90,layout={x=.32,y=.08,width=260,height=290,scale=1}}
    self.surface.OnLayout=function(_,l)
        self.title:SetWidth(l.width-16)
        for _,row in ipairs(self.rows) do row.frame:SetWidth(l.width-16);row.name:SetWidth(l.width-16);row.detail:SetWidth(l.width-16) end
    end
    -- Owned passive callbacks clear paint only; they never poll units. A newly
    -- visible panel stays blank until its normal visible refresh verifies data.
    self.frame:SetScript("OnHide",function() self:ClearRows() end)
    self.frame:SetScript("OnShow",function() self:ClearRows() end)
    M.CVE:Register(self.surface);self.frame:Hide()
end
function O:Configure()
    local cfg=M:ModuleConfig("PvP")
    if cfg.contacts then self:Create() else self:Clear() end
    if self.surface then self.surface.disabled=not cfg.contacts;M.Layout:Apply(self.surface);if not cfg.contacts then M.Effects:Stop(self.surface) end end
    if not cfg.manualNotes then for _,row in pairs(self.records) do row.note=nil end end
    if cfg.contacts then
        for unit in pairs(aliases) do self:Refresh(unit) end
        local plates,status=S:Public(C_NamePlate and C_NamePlate.GetNamePlates,"table")
        if status=="KNOWN" then for i=1,80 do
            local plate,known=S:Field(plates,i);if known~="KNOWN" then break end
            local ok,unit=pcall(function() return plate.namePlateUnitToken end)
            if ok and S:Text(unit) then self:Refresh(unit) end
        end end
    end
    self.dirty=true
end
function O:ManualNote(kind,seconds)
    local cfg=M:ModuleConfig("PvP")
    if not M:IsModuleActive("PvP") or not cfg.contacts or not cfg.manualNotes then return false,"Enable observed contacts and manual notes first." end
    if kind~="cooldown" and kind~="cc" then return false,"Use cooldown or cc." end
    if not S:Number(seconds) or seconds%1~=0 or seconds<1 or seconds>600 then return false,"Choose 1 to 600 seconds." end
    -- The selected target is explicit user input for a note, never a replacement
    -- for an earlier mouseover subject or a request to perform a game action.
    local target=self:Refresh("target")
    if not target then return false,"No current readable target contact. No note was added." end
    local id,revision=target.id,target.revision
    local units={};for unit,entry in pairs(self.records) do if entry.id==id then units[#units+1]=unit end end
    local staged={}
    for _,unit in ipairs(units) do
        local entry=unit=="target" and target or self:Refresh(unit)
        if entry and entry.id==id then staged[#staged+1]={unit=unit,row=entry,revision=entry.revision} end
    end
    -- Recheck staged bindings before the selected target's final check. Commit
    -- below performs only owned-table writes, not another native lookup.
    for _,entry in ipairs(staged) do
        local current,status=S:Public(UnitGUID,"string",entry.unit)
        entry.valid=status=="KNOWN" and current==id and self.records[entry.unit]==entry.row and entry.row.revision==entry.revision
        if not entry.valid and self.records[entry.unit]==entry.row then self.records[entry.unit]=nil end
    end
    local now=S:Now()
    local current=self:Refresh("target")
    if current~=target or current.id~=id or current.revision~=revision then
        return false,"The subject changed. No note was added."
    end
    for _,entry in ipairs(staged) do
        if entry.valid and self.records[entry.unit]==entry.row and entry.row.revision==entry.revision then
            entry.row.note={kind=kind,started=now,expires=now+seconds,origin="MANUAL_ESTIMATE",subjectID=id,revision=entry.revision}
        end
    end
    self.dirty=true;return true,"Manual estimate recorded. Expiry means unknown, never ready."
end
function O:ForgetNotes()
    for _,row in pairs(self.records) do row.note=nil end;self.dirty=true
end
local function rank(unit)
    if unit=="target" then return 1 elseif unit=="focus" then return 2 elseif unit=="mouseover" then return 3 end
    return 10+(tonumber(unit:match("%d+$")) or 100)
end
function O:Render(now)
    if not self.rows then return end
    if not self.frame:IsVisible() then self:ClearRows();return end
    local list={};for unit in pairs(self.records) do list[#list+1]=unit end
    table.sort(list,function(a,b) return rank(a)<rank(b) end)
    local seen,index={},0;local cfg=M:ModuleConfig("PvP")
    for _,unit in ipairs(list) do
        if index>=cfg.contactRows then break end
        -- Validate before deduplication: two formerly identical aliases may now
        -- expose different people. Stop at the selected prefix, not a full scan.
        local record=self:Refresh(unit)
        if record and not seen[record.id] then
            local row=self.rows[index+1];clearRow(row)
            local revision=record.revision
            M.Visual:Name(row.name,unit,record.name,11)
            -- Class-color lookup also consults the current token. Refuse mixed
            -- metadata if that lookup exposes an identity change or restriction.
            local current,status=S:Public(UnitGUID,"string",unit)
            if status=="KNOWN" and current==record.id and self.records[unit]==record and record.revision==revision then
                local detail=aliases[unit] and (unit=="mouseover" and "Under pointer" or unit=="focus" and "Focus" or "Target") or "Visible nameplate"
                local note=record.note
                if note and (note.subjectID~=record.id or note.revision~=revision) then record.note=nil;note=nil end
                if note and cfg.manualNotes then
                    if now<note.expires then detail="~ Manual "..(note.kind=="cc" and "CC" or "cooldown")..": "..math.ceil(note.expires-now).."s · estimate"
                    else detail="? Manual timer expired · availability unknown" end
                end
                seen[record.id]=true;index=index+1
                row.detail:SetText(detail);row.frame:Show()
            else
                clearRow(row)
                if self.records[unit]==record then self.records[unit]=nil end
            end
        end
    end
    for i=index+1,8 do clearRow(self.rows[i]) end
    self.dirty=false
end
function O:Tick(now)
    if not M:IsModuleActive("PvP") or not M:ModuleConfig("PvP").contacts then return end
    if not self.frame or not self.frame:IsVisible() then self.wasVisible=false;return end
    if not self.wasVisible then self.recheckAt=nil;self.wasVisible=true end
    if now>=(self.recheckAt or 0) then
        self.recheckAt=now+.5
        for unit in pairs(self.records) do self:Refresh(unit) end
        -- A full pool may have rejected an earlier alias event. Once cleanup
        -- frees space, retry only these three explicit current unit references.
        for _,unit in ipairs({"target","focus","mouseover"}) do if not self.records[unit] then self:Refresh(unit) end end
        -- No retained list of disappeared players: removal and identity changes
        -- delete the associated state instead of extending tracking off-screen.
        self.dirty=true
    end
    if self.frame and self.frame:IsVisible() and (self.dirty or now>=(self.textAt or 0)) then self.textAt=now+.25;self:Render(now) end
end
function O:OnEvent(event,unit)
    if event=="PLAYER_ENTERING_WORLD" or event=="PLAYER_LEAVING_WORLD" or event=="ZONE_CHANGED_NEW_AREA" then self:Clear();if event~="PLAYER_LEAVING_WORLD" and M.state.world then self:Configure() end;return end
    if event=="NAME_PLATE_UNIT_REMOVED" then if S:Text(unit) then self:Remove(unit) end
    elseif event=="NAME_PLATE_UNIT_ADDED" then self:Refresh(unit)
    elseif event=="PLAYER_TARGET_CHANGED" then self:Refresh("target")
    elseif event=="PLAYER_FOCUS_CHANGED" then self:Refresh("focus")
    elseif event=="UPDATE_MOUSEOVER_UNIT" then self:Refresh("mouseover")
    elseif event=="UNIT_NAME_UPDATE" and S:Text(unit) and self.records[unit] then self:Refresh(unit) end
    self.dirty=true
end
