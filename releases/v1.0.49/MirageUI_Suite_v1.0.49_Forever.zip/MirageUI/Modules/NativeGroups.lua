local _,M=...
-- Eight native secure subgroup headers. Native code owns unit assignment and
-- in-combat roster changes; ordinary Lua only updates the prepared artwork.
M.NativeGroups={headers={},views={},active=false}
local N,S=M.NativeGroups,M.Safety
local INIT=[[self:SetWidth(150); self:SetHeight(34); self:SetAttribute("type1","target"); self:SetAttribute("type2","togglemenu"); self:SetAttribute("useOnKeyDown",false);]]
local function raidToken(unit)
    if not S:Text(unit) then return false end
    local n=unit:match("^raid([1-9]%d?)$")
    return n and tonumber(n)<=40
end
local function ownsRow(row)
    local surface=row.surface
    return surface and rawequal(surface.frame,row.frame) and rawequal(M.surfaces[surface.id],surface) and rawequal(M.Policy.owners[surface.id],surface)
end
local function ownedChild(header,child,key)
    if not S:Frame(child,false) then return false end
    local ok,parent=pcall(child.GetParent,child)
    if not ok or not S:Readable(parent) or not rawequal(parent,header) then return false end
    local read,assigned=pcall(header.GetAttribute,header,key)
    return read and S:Readable(assigned) and rawequal(assigned,child)
end
function N:OwnsChild(view)
    local row=self.headers[view.nativeGroup]
    if row and ownsRow(row) and ownedChild(row.frame,view.frame,view.childKey) then return true end
    -- Retire only our cached binding. The newer owner controls its artwork.
    view.unit=nil;view.assignmentStatus="OWNER_UNAVAILABLE"
    return false
end
function N:Rebind(view,newRoster)
    if not self.active or not self:OwnsChild(view) then return end
    local operating=M:IsModuleActive("PartyRaid") and not M.modules.PartyRaid.pendingDisable
    if not operating and not M:IsSecureCleanupActive("PartyRaid") then return end
    -- A successfully read empty slot is normal. A failed/restricted read is not
    -- evidence of emptiness and cannot authorize hiding the native raid fallback.
    local ok,unit=pcall(view.frame.GetAttribute,view.frame,"unit")
    if not ok then view.assignmentStatus="UNKNOWN"
    elseif not S:Readable(unit) then view.assignmentStatus="RESTRICTED"
    elseif unit==nil then view.assignmentStatus="EMPTY"
    elseif raidToken(unit) then view.assignmentStatus="KNOWN"
    else view.assignmentStatus="INVALID" end
    if view.assignmentStatus~="KNOWN" then
        view.unit=nil;M.Display:ClearUnit(view);return
    end
    -- A new roster can reuse the same raid token for a different subject.
    -- Release the old rails, cast history and text before the first new paint.
    if newRoster or view.unit~=unit then M.Display:ClearUnit(view) end
    M.Display:UnitBars(view,unit,true)
    if operating then M.UnitExtras:RefreshCast(view);view.extraAuraDirty=true end
end
function N:LayoutHeader(row,layout)
    if S:InCombat() or not ownsRow(row) then return false end
    for _,view in ipairs(row.children) do if not self:OwnsChild(view) then return false end end
    local cfg=M:ModuleConfig("PartyRaid")
    local gap=cfg.cellGap
    -- The editor changes the full five-cell group rectangle, not a hidden fixed
    -- roster slot. Derive cell geometry only from validated user layout values.
    local width=layout.width
    local height=(layout.height-4*gap)/5
    if not S:Number(width) or not S:Number(height) or width<100 or height<24 then return false end
    local h=row.frame
    h:SetAttribute("_ignore",true)
    h:SetAttribute("yOffset",-gap);h:SetAttribute("xOffset",0)
    for _,view in ipairs(row.children) do
        view.frame:SetSize(width,height);M.Display:SizeUnit(view,width,height)
    end
    h:SetAttribute("_ignore",nil)
    -- Fixed top-left anchor keeps joins/leaves from shifting the first cell.
    local sw,sh=UIParent:GetWidth(),UIParent:GetHeight()
    if not S:Number(sw) or not S:Number(sh) then return false end
    h:ClearAllPoints();h:SetPoint("TOPLEFT",UIParent,"CENTER",layout.x*sw-layout.width*layout.scale/2,layout.y*sh+layout.height*layout.scale/2)
    row.title:SetShown(cfg.groupTitles==true)
    return true
end
-- These tokens describe ordinary producer calls only. They are not secure-engine
-- leases. Even a rejected/reentrant request retires the prior source lifetime.
local lifetime={}
local running
local controlledRows={}
function N:CaptureLifetime() return lifetime end
function N:IsLifetimeCurrent(token) return rawequal(self,N) and rawequal(M.NativeGroups,N) and rawequal(token,lifetime) end
local function beginAttempt()
    lifetime={}
    if running then
        N.pending=true;N.cleanupPending=true;N.status="GROUP_TRANSITION_PENDING"
        return nil
    end
    local group=M.modules and M.modules.PartyRaid
    local capture=group and group.CaptureLifetime
    local op={token=lifetime,headers=N.headers,views=N.views,surfaces=M.surfaces,policy=M.Policy,owners=M.Policy.owners,
        modules=M.modules,group=group,groupCapture=capture,groupToken=type(capture)=="function" and capture(group) or nil,
        combat=S.InCombat,unregister=UnregisterStateDriver,register=RegisterStateDriver,
        display=M.Display,clear=M.Display.ClearUnit}
    running=op
    return op
end
local function current(op)
    return rawequal(M.NativeGroups,N) and rawequal(lifetime,op.token) and rawequal(N.headers,op.headers) and rawequal(N.views,op.views) and rawequal(M.Safety,S) and S.InCombat==op.combat
        and rawequal(M.surfaces,op.surfaces) and rawequal(M.Policy,op.policy) and rawequal(op.policy.owners,op.owners)
        and rawequal(M.modules,op.modules) and (not op.modules or rawequal(op.modules.PartyRaid,op.group))
        and (not op.groupCapture or (op.group.CaptureLifetime==op.groupCapture and rawequal(op.groupCapture(op.group),op.groupToken)))
        and UnregisterStateDriver==op.unregister and RegisterStateDriver==op.register
        and rawequal(M.Display,op.display) and op.display.ClearUnit==op.clear
end
local function writable(op,custody)
    if not current(op) or (custody and not custody()) then return false,"GROUP_PRODUCER_CHANGED" end
    local ok,combat=pcall(op.combat,S)
    if not current(op) or (custody and not custody()) then return false,"GROUP_PRODUCER_CHANGED" end
    if not ok or combat~=false then return false,"GROUP_LAYOUT_AFTER_COMBAT" end
    return true
end
local function effect(op,custody,fn,tries,...)
    for _=1,tries or 1 do
        local legal,why=writable(op,custody)
        if not legal then return false,why end
        local ok=type(fn)=="function" and pcall(fn,...)
        legal,why=writable(op,custody)
        if not legal then return false,why end
        if ok then return true end
    end
    return false,"GROUP_CONTROL_UNCONFIRMED"
end
local function finish(op,ok,why)
    if rawequal(running,op) then running=nil end
    if not current(op) then return false,"GROUP_TRANSITION_SUPERSEDED" end
    N.pending=not ok or nil
    if why then N.status=why end
    return ok,why
end
local function partialOwner(row,frame,surface,op)
    if surface and not rawequal(surface.frame,frame) then return false end
    local id="PartyRaid.group"..row.index
    local registered,owner=op.surfaces[id],op.owners[id]
    return (registered==nil or (surface and rawequal(registered,surface)))
        and (owner==nil or (surface and rawequal(owner,surface)))
end
local function snapshotRows(op)
    local rows,allViews={},{}
    local expectedViewCount=0
    for i,view in ipairs(op.views) do allViews[i]=view end
    for i=1,8 do
        local row=op.headers[i]
        if row then
            local control=controlledRows[i]
            if not control or not rawequal(row,control.row) or not rawequal(row.frame,control.frame) or not rawequal(row.surface,control.surface) or not rawequal(row.children,control.children) then return nil end
            rows[i]={row=row,frame=row.frame,surface=row.surface,children=row.children,index=row.index,
                control=control,hide=row.frame and row.frame.Hide,registered=op.surfaces["PartyRaid.group"..i],owner=op.owners["PartyRaid.group"..i],childViews={}}
            for j,view in ipairs(row.children) do
                rows[i].childViews[j]={view=view,frame=view.frame,key=view.childKey,group=view.nativeGroup}
                expectedViewCount=expectedViewCount+1
                if not rawequal(op.views[expectedViewCount],view) then return nil end
            end
        elseif N.ready or controlledRows[i] then return nil end
    end
    if #allViews~=expectedViewCount then return nil end
    local function custody()
        if #op.views~=#allViews then return false end
        for i,view in ipairs(allViews) do if not rawequal(op.views[i],view) then return false end end
        for i=1,8 do
            local saved=rows[i];local row=op.headers[i]
            if saved then
                if not rawequal(controlledRows[i],saved.control) or saved.index~=i or not rawequal(row,saved.row) or not rawequal(row.frame,saved.frame) or not rawequal(row.surface,saved.surface) or not rawequal(row.children,saved.children) or row.index~=saved.index
                    or not saved.frame or saved.frame.Hide~=saved.hide or not rawequal(op.surfaces["PartyRaid.group"..i],saved.registered)
                    or not rawequal(op.owners["PartyRaid.group"..i],saved.owner) then return false end
                if #saved.children~=#saved.childViews or #saved.children~=#saved.control.childViews then return false end
                for j,child in ipairs(saved.childViews) do
                    local view=child.view
                    local owned=saved.control.childViews[j]
                    if not rawequal(saved.children[j],view) or not rawequal(view.frame,child.frame) or view.childKey~=child.key or view.nativeGroup~=child.group
                        or not rawequal(view,owned.view) or not rawequal(view.frame,owned.frame) or view.childKey~=owned.key or view.nativeGroup~=owned.group then return false end
                end
                if not ownsRow(row) and not (N.failed and not N.ready and partialOwner(row,saved.frame,saved.surface,op)) then return false end
            elseif row then return false end
        end
        return true
    end
    return rows,custody
end
local function cleanup(op)
    -- Keep active selection while an old driver may still be live. The caller
    -- must not restore the fixed raid provider until this returns true.
    N.cleanupPending=true
    local rows,custody=snapshotRows(op)
    if not rows then return false,"GROUP_PRODUCER_CHANGED" end
    local legal,why=writable(op,custody)
    if not legal then return false,why end
    for i=1,8 do
        local saved=rows[i]
        if saved then
            -- Unregister and Hide are separate commits. A successful callback
            -- can change combat/owner/lifetime just as a throwing one can.
            local ok
            ok,why=effect(op,custody,op.unregister,2,saved.frame,"visibility")
            if not ok then return false,why end
            ok,why=effect(op,custody,saved.hide,2,saved.frame)
            if not ok then return false,why end
        end
    end
    for i=1,8 do
        local saved=rows[i]
        if saved then
            for index,view in ipairs(saved.children) do
                local frame,key=view.frame,view.childKey
                local function childCustody()
                    return custody() and rawequal(saved.children[index],view) and rawequal(view.frame,frame) and view.childKey==key and view.nativeGroup==i
                end
                legal,why=writable(op,childCustody)
                if not legal then return false,why end
                local ok,owned=pcall(ownedChild,saved.frame,frame,key)
                legal,why=writable(op,childCustody)
                if not legal then return false,why end
                if not ok or not owned then return false,"GROUP_PRODUCER_CHANGED" end
                view.unit=nil;view.assignmentStatus=nil
                ok,why=effect(op,childCustody,op.clear,2,op.display,view)
                if not ok then return false,why end
            end
        end
    end
    legal,why=writable(op,custody)
    if not legal then return false,why end
    N.active=false;N.cleanupPending=nil
    return true
end
local function prepare(op)
    if N.failed then return false,"GROUP_HEADER_RELOAD_REQUIRED" end
    if N.ready and N.cleanupPending then return false,"GROUP_CONTROL_UNCONFIRMED" end
    local legal,why=writable(op)
    if not legal then return false,why end
    if type(SecureGroupHeader_Update)~="function" or type(op.register)~="function" or type(op.unregister)~="function" then return false,"NATIVE_GROUP_HEADER_UNAVAILABLE" end
    for group=1,8 do
        local row=op.headers[group]
        local expected=N.ready and row and row.surface or nil
        if (N.ready and not expected) or not rawequal(op.surfaces["PartyRaid.group"..group],expected) or not rawequal(op.owners["PartyRaid.group"..group],expected) then
            return false,"NATIVE_GROUP_SURFACE_CONFLICT"
        end
    end
    if N.ready then
        local rows,custody=snapshotRows(op)
        if not rows or not custody() then return false,"GROUP_PRODUCER_CHANGED" end
        return true
    end
    -- A partial prewarm is never resumable. Latch before callbacks, including a
    -- reentrant request, and clear the latch only after complete publication.
    N.failed=true;N.cleanupPending=true
    local built={}
    local function custody()
        for i,saved in pairs(built) do
            local row=op.headers[i]
            if not rawequal(row,saved.row) or not rawequal(row.frame,saved.frame) or not rawequal(row.surface,saved.surface) or not rawequal(row.children,saved.children)
                or row.index~=i or not partialOwner(row,saved.frame,saved.surface,op) then return false end
        end
        return true
    end
    local function call(fn,...)
        local ok,reason=effect(op,custody,fn,1,...)
        assert(ok,reason)
    end
    local ok=pcall(function()
        local prepared={}
        for group=1,8 do
            assert(not op.headers[group],"Unexpected partial subgroup")
            local row={index=group,children={}};op.headers[group]=row
            local saved={row=row,children=row.children,childViews={}};built[group]=saved;controlledRows[group]=saved
            local legal,reason=writable(op,custody);assert(legal,reason)
            local h=CreateFrame("Frame","MirageUISubgroup"..group,UIParent,"SecureGroupHeaderTemplate")
            -- Retain a just-created local control for later cleanup even when
            -- CreateFrame's callback revoked this attempt. Never replace a row.
            if rawequal(op.headers[group],row) and not row.frame then row.frame=h;saved.frame=h end
            legal,reason=writable(op,custody);assert(legal,reason)
            call(M.TrackRoot,M,"PartyRaid",h);call(h.Hide,h)
            call(h.SetAttribute,h,"_ignore",true)
            call(h.SetAttribute,h,"template","SecureUnitButtonTemplate,BackdropTemplate")
            call(h.SetAttribute,h,"initialConfigFunction",INIT)
            call(h.SetAttribute,h,"showRaid",true);call(h.SetAttribute,h,"showParty",false)
            call(h.SetAttribute,h,"showPlayer",true);call(h.SetAttribute,h,"showSolo",true)
            call(h.SetAttribute,h,"groupFilter",tostring(group));call(h.SetAttribute,h,"groupBy","GROUP")
            call(h.SetAttribute,h,"groupingOrder",tostring(group));call(h.SetAttribute,h,"sortMethod","INDEX")
            call(h.SetAttribute,h,"sortDir","ASC");call(h.SetAttribute,h,"point","TOP")
            call(h.SetAttribute,h,"unitsPerColumn",5);call(h.SetAttribute,h,"maxColumns",1)
            call(h.SetAttribute,h,"startingIndex",-4);call(h.SetAttribute,h,"_ignore",nil)
            call(h.Show,h);call(SecureGroupHeader_Update,h)
            for i=1,5 do
                local key="child"..i
                local child=h:GetAttribute(key)
                assert(ownedChild(h,child,key) and type(child.HookScript)=="function" and not prepared[child],"Native subgroup prewarm failed")
                legal,reason=writable(op,custody);assert(legal,reason)
                prepared[child]=true
                call(child.RegisterForClicks,child,"AnyUp")
                local view=M.Display:DecorateUnit(child,"raid"..((group-1)*5+i),"Raid member","PartyRaid",false)
                legal,reason=writable(op,custody);assert(legal,reason)
                view.unit=nil;view.isRaid=true;view.nativeGroup=group;view.childKey=key
                call(child.HookScript,child,"OnAttributeChanged",function(_,attribute)
                    if S:Text(attribute) and attribute=="unit" then N:Rebind(view,true) end
                end)
                row.children[i]=view;op.views[#op.views+1]=view
                saved.childViews[i]={view=view,frame=child,key=key,group=group}
                call(op.clear,op.display,view)
            end
            call(h.SetAttribute,h,"_ignore",true);call(h.SetAttribute,h,"startingIndex",1)
            call(h.SetAttribute,h,"showPlayer",false);call(h.SetAttribute,h,"showSolo",false);call(h.SetAttribute,h,"_ignore",nil);call(h.Hide,h)
            row.title=M.UI:Text(h,"Group "..group,0,17,10,150)
            legal,reason=writable(op,custody);assert(legal,reason)
            local col=(group-1)%4;local line=math.floor((group-1)/4)
            local surface={id="PartyRaid.group"..group,module="PartyRaid",frame=h,security="SECURE_PREDECLARED",floor=true,
                groups={group=true},editable=true,minWidth=100,minHeight=170,
                layout={x=-.34+col*.10,y=.20-line*.28,width=150,height=194,scale=1}}
            row.surface=surface;saved.surface=surface
            surface.OnLayout=function(_,l)
                local token=N:CaptureLifetime()
                if N.active and N.ready then
                    local applied=N:LayoutHeader(row,l)
                    if N:IsLifetimeCurrent(token) and ownsRow(row) then row.layoutReady=applied end
                end
            end
        end
        -- Publish only after all forty controls and decorations exist.
        for _,row in ipairs(op.headers) do call(M.CVE.Register,M.CVE,row.surface) end
    end)
    if not current(op) then return false,"GROUP_TRANSITION_SUPERSEDED" end
    if not ok then
        legal,why=writable(op,custody)
        if not legal then return false,why end
        local cleaned,reason=cleanup(op)
        return false,cleaned and "NATIVE_GROUP_HEADER_SETUP_FAILED" or reason
    end
    legal,why=writable(op,custody)
    if not legal then return false,why end
    N.failed=nil;N.cleanupPending=nil;N.ready=true
    return true
end
function N:Prepare()
    if not rawequal(self,N) or not rawequal(M.NativeGroups,N) then return false,"GROUP_PRODUCER_CHANGED" end
    local op=beginAttempt();if not op then return false,"GROUP_TRANSITION_PENDING" end
    local ok,result,why=pcall(prepare,op)
    if not ok and current(op) then N.cleanupPending=true;result=false;why="NATIVE_GROUP_HEADER_SETUP_FAILED" end
    return finish(op,result,why)
end
function N:SetActive(enabled)
    if not rawequal(self,N) or not rawequal(M.NativeGroups,N) then return false,"GROUP_PRODUCER_CHANGED" end
    local op=beginAttempt();if not op then return false,"GROUP_TRANSITION_PENDING" end
    local completed,result,reason=pcall(function()
        if not enabled and N.active then N.cleanupPending=true end
        local legal,why=writable(op)
        if not legal then return false,why end
        if N.cleanupPending then
            local ok;ok,why=cleanup(op)
            if not ok then return false,why end
        end
        if not enabled then
            if N.active then
                local ok;ok,why=cleanup(op)
                if not ok then return false,why end
            end
            return true,"DISABLED"
        end
        local ready;ready,why=prepare(op)
        if not ready then return false,why end
        N.active=true;N.cleanupPending=true
        local rows,custody=snapshotRows(op)
        if not rows then return false,"GROUP_PRODUCER_CHANGED" end
        local activated=true
        for i=1,8 do
            local saved=rows[i];local row=saved.row
            row.layoutReady=false
            activated,why=effect(op,custody,M.Layout.Apply,1,M.Layout,saved.surface)
            if not activated or not row.layoutReady then activated=false;break end
            for _,view in ipairs(saved.children) do
                activated,why=effect(op,custody,M.UnitExtras.Configure,1,M.UnitExtras,view)
                if not activated then break end
            end
            if not activated then break end
            activated,why=effect(op,custody,op.register,1,saved.frame,"visibility","[group:raid] show; hide")
            if not activated then break end
            for _,view in ipairs(saved.children) do
                activated,why=effect(op,custody,N.Rebind,1,N,view)
                if not activated then break end
            end
            if not activated then break end
        end
        if not current(op) then return false,"GROUP_TRANSITION_SUPERSEDED" end
        if not activated then
            local cleaned,cleanupWhy=cleanup(op)
            return false,cleaned and "NATIVE_GROUP_HEADER_ACTIVATION_FAILED" or cleanupWhy
        end
        legal,why=writable(op,custody)
        if not legal then return false,why end
        N.cleanupPending=nil
        return true,"NATIVE_SUBGROUP_CANDIDATE"
    end)
    if not completed and current(op) then
        N.cleanupPending=true;result=false;reason="GROUP_CONTROL_UNCONFIRMED"
    end
    return finish(op,result,reason)
end
function N:Refresh(newRoster)
    if not self.active then return end
    for _,view in ipairs(self.views) do self:Rebind(view,newRoster) end
end
function N:Event(event,unit,refreshInfo)
    if not self.active then return end
    if event=="GROUP_ROSTER_UPDATE" or event=="PLAYER_ENTERING_WORLD" then self:Refresh(true);return end
    local info=event=="READY_CHECK" or event=="READY_CHECK_FINISHED" or event=="READY_CHECK_CONFIRM" or event=="PLAYER_ROLES_ASSIGNED"
    if not info and not raidToken(unit) then return end
    for _,view in ipairs(self.views) do
        if view.unit and (info or unit==view.unit) and self:OwnsChild(view) then
            if info then M.Display:UnitInfo(view)
            elseif event=="UNIT_AURA" or M.UnitExtras.events[event] then M.UnitExtras:Event(view,event)
            else M.Display:UnitBars(view,view.unit,refreshInfo) end
        end
    end
end
function N:Tick(now)
    if not self.active then return end
    local cfg=M:ModuleConfig("PartyRaid")
    local mayLayout
    for _,view in ipairs(self.views) do
        if view.unit then
            local pending=view.powerLayoutPending or view.extraLayoutPending
            if pending and mayLayout==nil then mayLayout=not S:InCombat() end
            local due=(pending and mayLayout)
                or (cfg.showCast and view.castTrack and now>=(view.extraTextNext or 0))
                or ((cfg.showAuras or cfg.showBuffs) and view.extraAuras and view.extraAuraDirty and now>=(view.extraAuraNext or 0))
            if due and self:OwnsChild(view) then M.UnitExtras:Tick(view,now) end
        end
    end
end
