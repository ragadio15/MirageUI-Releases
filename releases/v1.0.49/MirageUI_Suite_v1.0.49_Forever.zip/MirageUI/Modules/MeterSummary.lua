local _, M = ...
local D=M.modules.DamageMeters
local priorApply,priorSuspend,priorResume=D.ApplyConfig,D.Suspend,D.Resume
D.events.DAMAGE_METER_COMBAT_SESSION_UPDATED=true;D.events.DAMAGE_METER_CURRENT_SESSION_UPDATED=true;D.events.DAMAGE_METER_RESET=true
D.events.PLAYER_REGEN_DISABLED=true
function D:CreateSummary()
 if self.summaryFrame or M.Safety:InCombat() then return end
 self.summaryFrame=M:TrackRoot(self.id,M.UI:Card(UIParent,290,260));self.summaryFrame:Hide()
 self.summaryTitle=M.UI:Text(self.summaryFrame,"Native meter",8,-6,12,270)
 self.summaryFooter=M.UI:Text(self.summaryFrame,"",8,-240,10,270)
 self.summaryRows={}
 for i=1,15 do
  local bar=M.UI:Bar(self.summaryFrame,8,-28-(i-1)*24,274,20,.25,.50,.52)
  bar.name=M.UI:Text(bar,"",4,-3,10,160)
  bar.amount=M.UI:Text(bar,"",168,-3,10,98);bar.amount:SetJustifyH("RIGHT")
  self.summaryRows[i]=bar
 end
 self.summarySurface={id="DamageMeters.summary",module=self.id,frame=self.summaryFrame,security="OWNED_VISUAL",groups={combat=true},fallback="HIDDEN",editable=true,
  minWidth=220,minHeight=150,layout={x=.34,y=-.25,width=290,height=260,scale=1}}
 self.summarySurface.OnLayout=function(_,l) self:LayoutSummary(l) end
 M.CVE:Register(self.summarySurface);M.Layout:Apply(self.summarySurface)
end
function D:LayoutSummary(l)
 local cfg=M:ModuleConfig(self.id);local h=math.max(12,(l.height-60)/cfg.rows)
 self.summaryTitle:SetWidth(l.width-16);self.summaryFooter:SetWidth(l.width-16)
 self.summaryFooter:ClearAllPoints();self.summaryFooter:SetPoint("BOTTOMLEFT",8,8)
 for i,bar in ipairs(self.summaryRows) do
  bar:ClearAllPoints();bar:SetPoint("TOPLEFT",8,-28-(i-1)*h);bar:SetSize(l.width-16,h-3)
  bar.name:SetWidth(math.max(70,l.width-126));bar.amount:ClearAllPoints();bar.amount:SetPoint("TOPRIGHT",-4,-3);bar.amount:SetWidth(100)
  bar:SetShown(i<=cfg.rows)
 end
end
function D:ClearSummary(message)
 for _,bar in ipairs(self.summaryRows or {}) do bar:SetStatusBarColor(.25,.5,.52,0);bar.name:SetText("");bar.amount:SetText("") end
 if self.summaryFooter then self.summaryFooter:SetText(message or "") end
end
function D:ConfigureSummary()
 if self:UsesMirageMeters() then
  if self.summarySurface then self.summarySurface.disabled=true;M.Effects:Stop(self.summarySurface) end
  self.summaryDirty=nil;self.summaryWasVisible=false;self.summaryState="DELEGATED_TO_MIRAGE_METERS"
  return
 end
 if M.Safety:InCombat() then return end
 local cfg=M:ModuleConfig(self.id)
 if cfg.summary then self:CreateSummary() end
 if not self.summaryFrame then return end
 self.summarySurface.disabled=not cfg.summary
 self.summarySurface.layout.height=60+cfg.rows*24
 M.Layout:Apply(self.summarySurface);self:ClearSummary();self.summaryDirty=true
 self.summaryTitle:SetText((cfg.meterType==1 and "Healing" or "Damage").." · "..({[0]="Overall",[1]="Current",[2]="Previous"})[cfg.sessionType])
 if not cfg.summary then M.Effects:Stop(self.summarySurface) end
end
function D:RefreshSummary()
 local data=M.MeterData:Read(M:ModuleConfig(self.id));self:ClearSummary()
 for i,row in ipairs(data.rows) do
  local bar=self.summaryRows[i]
  if row.unavailable then bar.name:SetText("Data unavailable")
  else
   bar:SetMinMaxValues(0,row.maximum);bar:SetValue(row.amount);bar:SetStatusBarColor(.25,.50,.52,.85)
   bar.name:SetText(row.name);bar.amount:SetText(string.format("%.0f · %.0f/s",row.amount,row.rate))
  end
 end
 self.summaryState=data.state
 self.summaryFooter:SetText(data.state=="PUBLIC_NATIVE_SESSION" and "Native order · display only" or "Some readings unavailable; native meter retained")
end
function D:Tick(now)
 if self:UsesMirageMeters() then return end
 if not self.summaryFrame or not M:ModuleConfig(self.id).summary then return end
 if not self.summaryFrame:IsVisible() then self.summaryWasVisible=false;self.summaryDirty=true;return end
 if (self.summaryDirty or not self.summaryWasVisible) and now>=(self.summaryNext or 0) then
  self:RefreshSummary();self.summaryDirty=false;self.summaryNext=now+.5
 end
 self.summaryWasVisible=true
end
function D:OnEvent(event)
 if self:DelegateMeters() then self:ConfigureSummary();return end
 if event=="PLAYER_REGEN_DISABLED" then self:ClearSummary("Refreshing native session");self.summaryDirty=true
 elseif event:find("DAMAGE_METER",1,true) then self.summaryDirty=true
 else self:Refresh();self.summaryDirty=true end
end
function D:WantsEvent(event)
 if self:UsesMirageMeters() then return false end
 if event:find("DAMAGE_METER",1,true) then return M:ModuleConfig(self.id).summary end
 return true
end
function D:ApplyConfig() priorApply(self);self:ConfigureSummary() end
function D:Resume() priorResume(self);self:ConfigureSummary() end
function D:Suspend() priorSuspend(self);self:ClearSummary();if self.summarySurface then M.Effects:Stop(self.summarySurface) end end
