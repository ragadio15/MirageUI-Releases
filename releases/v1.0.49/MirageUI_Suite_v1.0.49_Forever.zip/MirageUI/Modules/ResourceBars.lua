local _, M = ...
local R={events={UNIT_HEALTH=true,UNIT_MAXHEALTH=true,UNIT_POWER_UPDATE=true,UNIT_MAXPOWER=true,UNIT_DISPLAYPOWER=true,PLAYER_SPECIALIZATION_CHANGED=true,PLAYER_TALENT_UPDATE=true,UPDATE_SHAPESHIFT_FORM=true,UNIT_ENTERED_VEHICLE=true,UNIT_EXITED_VEHICLE=true,
    UNIT_SPELLCAST_START=true,UNIT_SPELLCAST_STOP=true,UNIT_SPELLCAST_DELAYED=true,UNIT_SPELLCAST_FAILED=true,UNIT_SPELLCAST_INTERRUPTED=true,
    UNIT_SPELLCAST_CHANNEL_START=true,UNIT_SPELLCAST_CHANNEL_UPDATE=true,UNIT_SPELLCAST_CHANNEL_STOP=true,
    UNIT_SPELLCAST_EMPOWER_START=true,UNIT_SPELLCAST_EMPOWER_STOP=true,SPELL_UPDATE_COOLDOWN=true,PLAYER_ENTERING_WORLD=true}}
-- Only public identity events may retire a configured optional resource. Rune
-- and summon updates have their own bounded handlers and never query unit bars.
local identityEvents = {
    PLAYER_ENTERING_WORLD=true, PLAYER_SPECIALIZATION_CHANGED=true, PLAYER_TALENT_UPDATE=true,
    UPDATE_SHAPESHIFT_FORM=true, UNIT_ENTERED_VEHICLE=true, UNIT_EXITED_VEHICLE=true,
    UNIT_DISPLAYPOWER=true,
}
local vitalEvents = {UNIT_HEALTH=true, UNIT_MAXHEALTH=true, UNIT_POWER_UPDATE=true}
function R:ResourceContext()
    local vehicle, status=M.Safety:Public(UnitInVehicle,"boolean","player")
    if status~="KNOWN" then return false,"VEHICLE_STATE_UNAVAILABLE" end
    if vehicle then return false,"VEHICLE_ACTIVE" end
    return true
end
-- Only immutable addon-authored optional section headings use this measure.
-- Never measure a live character name, class value, aura or timer text.
function R:FitResourceHeading(label, expected, width)
    label:SetWidth(width)
    local current=M.Safety:Public(label.GetText,"string",label)
    local fits=false
    if current==expected then
        local w=M.Safety:Public(label.GetUnboundedStringWidth,"number",label)
        local h=M.Safety:Public(label.GetStringHeight,"number",label)
        fits=w~=nil and h~=nil and w>0 and h>0 and w<=width and h<=18
    end
    label:SetShown(fits)
    return fits and "FITS" or "HEADING_WITHHELD"
end
-- The shared layout engine uses these surfaces' 24 x 16 schema bounds.
-- A smaller legal saved envelope must not be expanded to fit authored content.
function R:FitResourceSurface(surface,layout,width,height,eligible)
    local fits=layout.width>=width and layout.height>=height
    surface.resourceLayoutStatus=fits and "FITS" or "LAYOUT_DOES_NOT_FIT"
    surface.disabled=not fits or not eligible
    if surface.disabled then M.Effects:Stop(surface) end
    M.state.forceEvaluate=true
    return fits
end
function R:WithdrawClass(reason)
    self.classPower=nil
    self.classSegmentCount=nil
    self.classProfileReason=reason
    self.secondaryStatus=reason
    if self.classSurface then
        self.classSurface.disabled=true
        M.Effects:Stop(self.classSurface)
    end
end
local function invalidateResources(self,event)
    local cfg=M:ModuleConfig(self.id)
    if cfg.classResource and not self.classNeedsConfigure then
        self:WithdrawClass("CONFIGURATION_PENDING")
        self.classNeedsConfigure=true
    end
    if event=="UNIT_MAXPOWER" then return end
    if cfg.runes and not self.runesPending then self:InvalidateRunes() end
    if cfg.totems and not self.totemsPending then self:InvalidateTotems() end
end
function R:Initialize()
    self.frame=M:TrackRoot(self.id,M.UI:Card(UIParent,280,78),true)
    self.frame:Hide()
    self.view={health=M.UI:Bar(self.frame,8,-8,220,15,.28,.67,.65),power=M.UI:Bar(self.frame,8,-28,220,12,.39,.48,.78),name=M.UI:Text(self.frame,"Player",8,-49,11,210),unitLabel="Player"}
    M.UI:Beam(self.view.health);M.UI:Beam(self.view.power)
    for _,bar in ipairs({self.view.health,self.view.power}) do M.UI:BeamTrack(bar,unpack(M.Visual.track)) end
    self.cast=M.UI:Bar(self.frame,8,-63,220,7,.55,.81,.83)
    self.gcd=CreateFrame("Cooldown",nil,self.frame,"CooldownFrameTemplate");self.gcd:SetPoint("TOPRIGHT",-8,-10);self.gcd:SetSize(32,32)
    if self.gcd.SetHideCountdownNumbers then self.gcd:SetHideCountdownNumbers(true) end
    self.gcdLabel=M.UI:Text(self.frame,"GCD",0,-49,9,36)
    self.gcdLabel:ClearAllPoints()
    self.gcdLabel:SetPoint("TOPRIGHT",self.frame,"TOPRIGHT",-8,-49)
    self.surface={id="ResourceBars.player",module=self.id,frame=self.frame,security="OWNED_VISUAL",groups={combat=true},fallback="AMBIENT",editable=true,minWidth=24,minHeight=16,
        layout={x=0,y=-.22,width=280,height=78,scale=1}}
    self.surface.OnLayout=function(surface,l)
        local previouslyRefused=surface.resourceLayoutStatus=="LAYOUT_DOES_NOT_FIT"
        if not self:FitResourceSurface(surface,l,180,78,true) then
            self.view.healthOK=false;self.view.powerOK=false
            self:HideCast("LAYOUT_DOES_NOT_FIT")
            return
        end
        self.view.health:SetWidth(l.width-60);self.view.power:SetWidth(l.width-60);self.cast:SetWidth(l.width-60);self.view.name:SetWidth(l.width-60)
        if previouslyRefused then self:Refresh() end
    end
    self.surface.presentationHidden=M.Presentation:LegacyAggregateRetired()
    self.centralRetired=self.surface.presentationHidden
    M.CVE:Register(self.surface);M.Layout:Apply(self.surface)
    self:EndCast("WAITING_FOR_START");self:Refresh();self.status="NATIVE_WIDGET_CANDIDATE"
end
function R:RefreshVitals(refresh)
    if self.surface.disabled or M.Presentation:LegacyAggregateRetired() then return end
    M.Display:UnitBars(self.view,"player",refresh)
end
function R:Refresh()
    self:RefreshVitals(true)
    self:RefreshGCD()
end
function R:OnPresentationChanged(hidden)
    -- Retire only this redundant lower card. Class resources, runes and
    -- temporary summon displays keep their independent native data/lifetimes.
    self.centralRetired=hidden==true
    self.presentationStatus=hidden and "LEGACY_AGGREGATE_RETIRED" or "FALLBACK_PRESENTATION_AVAILABLE"
    if hidden then
        self.frame:Hide()
        self.gcdLabel:Hide()
    end
end
function R:RefreshGCD()
    if M.Presentation:LegacyAggregateRetired() then
        if not self.gcdRetired and self.gcd.Clear then pcall(self.gcd.Clear,self.gcd) end
        self.gcdRetired=true;self.gcdStatus="LEGACY_AGGREGATE_RETIRED";return
    end
    self.gcdRetired=nil
    if self.surface.disabled then
        if self.gcd.Clear then pcall(self.gcd.Clear,self.gcd) end
        self.gcdStatus="LAYOUT_DOES_NOT_FIT";return
    end
    self.gcdStatus=M.Display:Cooldown(self.gcd,C_Spell and C_Spell.GetSpellCooldownDuration,61304,false)
end
-- Only event family and the public channel classification belong to this lane.
-- Cast GUIDs, spell IDs, timestamps and native duration payloads are never keys.
function R:HideCast(reason)
    self.castStatus=reason
    self.cast.mirageRequestedShown=false
    self.cast:Hide()
    if type(self.cast.ClearTimerDuration)=="function" then pcall(self.cast.ClearTimerDuration,self.cast) end
end
function R:NextCastRevision()
    self.castRevision=(self.castRevision or 0)+1
    return self.castRevision
end
function R:EndCast(reason)
    self:NextCastRevision()
    self.castKind=nil
    self.empower=false
    self.awaitStart=true
    self:HideCast(reason)
end
function R:BindCast()
    if self.awaitStart then return end
    if M.state.safe or not M:ModuleConfig(self.id).enabled then self:EndCast("DISABLED");return end
    local revision=self:NextCastRevision()
    if self.castKind=="channel" then
        local empowered=M.DurationDisplay:IsEmpowered("player")
        if revision~=self.castRevision then return end
        if empowered==nil then self:HideCast("CHANNEL_KIND_UNAVAILABLE");return end
        if empowered then
            self.castKind="empower";self.empower=true
        end
    end
    if self.castKind=="empower" and M.EmpoweredCast and M.EmpoweredCast.active and M:ModuleConfig(self.id).empoweredStages then
        self:HideCast("OWNED_EMPOWER_STAGES");return
    end
    -- HUDData selects the exact native source, verifies channel direction and
    -- submits the object unchanged. Presentation remains the single owner policy.
    if self.surface.disabled then self:HideCast("LAYOUT_DOES_NOT_FIT");return end
    local allowed=M.Presentation:Allows("ResourceBars","cast")
    if revision~=self.castRevision then return end
    if not allowed then self:HideCast("OWNED_ELSEWHERE");return end
    local sent,reason=M.HUDData:Cast(self.cast,self.castKind)
    -- Native getters/setters can synchronously stop, replace or disable the
    -- lifetime. A submitted object from the superseded call cannot own the row.
    if revision~=self.castRevision then self:HideCast("CAST_DISPATCH_SUPERSEDED");return end
    if not sent then self:HideCast(reason);return end
    self.cast.mirageRequestedShown=true
    self.cast:SetShown(true)
    self.castStatus="NATIVE_WIDGET_DISPATCH"
end
local ending={UNIT_SPELLCAST_STOP="cast",UNIT_SPELLCAST_CHANNEL_STOP="channel",UNIT_SPELLCAST_EMPOWER_STOP="empower"}
function R:OnEvent(event,unit)
    if event:sub(1,5)=="UNIT_" and (not M.Safety:Text(unit) or unit~="player") then return end
    if event=="UNIT_SPELLCAST_EMPOWER_START" then
        self:NextCastRevision()
        self.castKind="empower";self.empower=true;self.awaitStart=false;self:BindCast()
    elseif event=="UNIT_SPELLCAST_START" or event=="UNIT_SPELLCAST_CHANNEL_START" then
        self.castKind=event=="UNIT_SPELLCAST_START" and "cast" or "channel"
        self.awaitStart=false;self.empower=false
        self:BindCast();self.surface.interactingUntil=M.Safety:Now()+1
    elseif event=="UNIT_SPELLCAST_DELAYED" or event=="UNIT_SPELLCAST_CHANNEL_UPDATE" then
        if (event=="UNIT_SPELLCAST_DELAYED" and self.castKind=="cast")
            or (event=="UNIT_SPELLCAST_CHANNEL_UPDATE" and (self.castKind=="channel" or self.castKind=="empower")) then self:BindCast() end
    elseif ending[event] then
        -- A cross-family stop cannot end an ordinary cast/channel. A same-family
        -- stop can be late; withdraw instead of comparing inaccessible cast IDs.
        if ending[event]==self.castKind or (ending[event]=="channel" and self.empower) then self:EndCast("END_UNCORRELATED") end
    elseif event=="UNIT_SPELLCAST_FAILED" or event=="UNIT_SPELLCAST_INTERRUPTED" then
        self:EndCast("END_UNCORRELATED")
    elseif event=="UNIT_SPELLCAST_EMPOWER_UPDATE" then
        if self.castKind=="empower" then self:BindCast() end
    elseif event=="SPELL_UPDATE_COOLDOWN" then self:RefreshGCD()
    elseif identityEvents[event] or event=="UNIT_MAXPOWER" then
        if event=="PLAYER_SPECIALIZATION_CHANGED" and (not M.Safety:Text(unit) or unit~="player") then return end
        invalidateResources(self,event)
        self:RefreshVitals(true)
    elseif vitalEvents[event] then
        self:RefreshVitals(false)
        if event=="UNIT_POWER_UPDATE" then self:RefreshClass() end
    end
end
function R:ApplyConfig() M.Layout:Apply(self.surface);self:ConfigureClass() end
function R:Suspend()
    self:EndCast("DISABLED");if self.gcd.Clear then self.gcd:Clear() end;M.Effects:Stop(self.surface)
    self.classNeedsConfigure=false
    self:WithdrawClass("DISABLED")
end
function R:Resume() self:EndCast("WAITING_FOR_START");self:Refresh() end
-- Static class-to-power mapping uses public metadata outside combat, never secret resource thresholds.
function R:ConfigureClass()
    if M.Safety:InCombat() then
        self:WithdrawClass("CONFIGURATION_PENDING")
        self.classNeedsConfigure=true
        return
    end
    self.classNeedsConfigure=false
    local cfg=M:ModuleConfig(self.id)
    local choice,reason
    if cfg.classResource then
        local eligible
        eligible,reason=self:ResourceContext()
        if eligible then choice,reason=M.ClassResourceProfile:Resolve() end
        if choice and cfg.classSegments and not (choice.maximum%1==0 and choice.maximum<=10) then
            -- Ten authored clamps. Do not silently replace selected pips with a bar.
            choice,reason=nil,"SEGMENT_CAPACITY_UNSUPPORTED"
        end
    else reason="DISABLED" end
    local power=choice and choice.power
    local maximum=choice and choice.maximum
    local allowed=cfg.classResource and choice~=nil
    self.classProfileReason=reason
    if allowed and not self.classFrame then
        self.classFrame=M:TrackRoot(self.id,M.UI:Card(UIParent,280,42),true);self.classFrame:Hide()
        self.classLabel=M.UI:Text(self.classFrame,"Class resource",7,-4,10,264)
        self.classBar=M.UI:Bar(self.classFrame,7,-22,266,12,.62,.58,.84)
        self.classSurface={id="ResourceBars.class",module=self.id,frame=self.classFrame,security="OWNED_VISUAL",groups={combat=true},fallback="AMBIENT",editable=true,
            minWidth=24,minHeight=16,layout={x=0,y=-.145,width=280,height=42,scale=1}}
        self.classSurface.OnLayout=function(surface,l)
            if not self:FitResourceSurface(surface,l,130,42,self.classPower~=nil) then
                if self.classPower then self.secondaryStatus="LAYOUT_DOES_NOT_FIT" end
                return
            end
            self.classBar:SetWidth(l.width-14);self.classLabel:SetWidth(l.width-14);self:LayoutClass()
        end
        M.CVE:Register(self.classSurface)
    end
    self.classPower=allowed and power or nil;self.classTitle=choice and choice.label or "Class resource"
    self.classSegmentCount=allowed and cfg.classSegments and maximum or nil
    if self.classFrame then
        if self.classSegmentCount and not self.classSegments then
            self.classSegments={}
            for i=1,10 do self.classSegments[i]=M.UI:Bar(self.classFrame,7,-22,20,12,.62,.58,.84);M.Safety:Passive(self.classSegments[i]) end
        end
        self.classBar:SetShown(self.classSegmentCount==nil)
        for i,bar in ipairs(self.classSegments or {}) do bar:SetShown(self.classSegmentCount~=nil and i<=self.classSegmentCount) end
    end
    self.secondaryStatus=allowed and "NATIVE_WIDGET_CANDIDATE" or cfg.classResource and "UNAVAILABLE_FOR_CURRENT_CLASS" or "DISABLED"
    if self.classSurface then
        self.classSurface.disabled=not allowed;M.Layout:Apply(self.classSurface)
        if not allowed then M.Effects:Stop(self.classSurface) else self:RefreshClass() end
    end
end
function R:LayoutClass()
    if not self.classFrame or M.Safety:InCombat() then return end
    local count=self.classSegmentCount
    if not count then return end
    local width=(self.classFrame:GetWidth()-14-(count-1)*3)/count
    for i,bar in ipairs(self.classSegments or {}) do
        bar:ClearAllPoints();bar:SetPoint("TOPLEFT",self.classFrame,"TOPLEFT",7+(i-1)*(width+3),-22);bar:SetSize(width,12)
        -- Segment boundaries are public fixed geometry. Every value is passed
        -- unchanged to the native clamp; no arithmetic on current power.
        bar:SetMinMaxValues(i-1,i)
    end
end
function R:RefreshClass()
    if not self.classPower or not self.classBar or self.classSurface.disabled then return end
    local power=self.classPower
    local ok,submitted=pcall(function()
        local value=UnitPower("player",power)
        if M.Safety:Readable(value) and value==nil then return false end
        if self.classSegmentCount then
            for i=1,self.classSegmentCount do self.classSegments[i]:SetValue(value) end
        else
            local maximum=UnitPowerMax("player",power)
            if M.Safety:Readable(maximum) and maximum==nil then return false end
            self.classBar:SetMinMaxValues(0,maximum)
            self.classBar:SetValue(value)
        end
        return true
    end)
    if self.classPower~=power or self.classSurface.disabled then return end
    ok=ok and submitted
    self.classBar:SetAlpha(ok and 1 or 0)
    for _,bar in ipairs(self.classSegments or {}) do bar:SetAlpha(ok and 1 or 0) end
    self.classLabel:SetText(ok and self.classTitle or (self.classTitle.." — unavailable"))
    self.secondaryStatus=ok and "NATIVE_WIDGET_DISPATCH" or "UNAVAILABLE"
end
function R:Tick()
    if self.classNeedsConfigure and not M.Safety:InCombat() then self:ConfigureClass();M.state.forceEvaluate=true end
end
M:RegisterModule("ResourceBars",R)
