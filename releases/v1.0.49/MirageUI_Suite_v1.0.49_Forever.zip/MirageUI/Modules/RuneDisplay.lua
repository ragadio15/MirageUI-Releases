-- Six static rune slots; no rotation recommendation, predictive ordering or target selection.
local _, M = ...
local R=M.modules.ResourceBars
local S=M.Safety
local apply,suspend,tick,event,wants=R.ApplyConfig,R.Suspend,R.Tick,R.OnEvent,R.WantsEvent
R.events.RUNE_POWER_UPDATE=true
function R:ClearRunes(reason)
    self.runeRevision=(self.runeRevision or 0)+1
    self.runeState=reason or "DISABLED"
    for _,tile in ipairs(self.runeTiles or {}) do
        tile.timer:Hide()
        if tile.timer.Clear then pcall(tile.timer.Clear,tile.timer) end
        tile.label:SetText("—");tile:SetAlpha(.4)
    end
end
function R:InvalidateRunes()
    self.runesPending=true
    self.runeEligible=false
    self.runeDirty=false
    if self.runeSurface then
        self.runeSurface.disabled=true
        M.Effects:Stop(self.runeSurface)
    end
    self:ClearRunes("CONFIGURATION_PENDING")
end
function R:ConfigureRunes()
    if S:InCombat() then self:InvalidateRunes();return end
    self.runesPending=nil
    local cfg=M:ModuleConfig(self.id)
    local usable=false
    local reason="DISABLED"
    if cfg.runes then
        local eligible
        eligible,reason=self:ResourceContext()
        if eligible then
            local ok,_,class=pcall(UnitClass,"player")
            if not ok or not S:Text(class) then reason="CLASS_UNAVAILABLE"
            elseif class~="DEATHKNIGHT" then reason="UNAVAILABLE_FOR_CLASS"
            elseif type(GetRuneCooldown)~="function" then reason="RUNE_SOURCE_UNAVAILABLE"
            else usable=true;reason="WAITING" end
        end
    end
    self.runeEligible=usable
    if usable and not self.runeFrame then
        self.runeFrame=M:TrackRoot(self.id,M.UI:Card(UIParent,250,62));self.runeFrame:Hide()
        self.runeTiles={};self.runeTitle=M.UI:Text(self.runeFrame,"Runes",7,-5,10,230)
        for i=1,6 do
            local tile=M.UI:Card(self.runeFrame,32,32)
            tile:SetPoint("TOPLEFT",7+(i-1)*39,-24)
            tile.label=M.UI:Text(tile,tostring(i),8,-8,11,20)
            tile.timer=CreateFrame("Cooldown",nil,tile,"CooldownFrameTemplate");tile.timer:SetAllPoints();S:Passive(tile.timer)
            if tile.timer.SetHideCountdownNumbers then tile.timer:SetHideCountdownNumbers(true) end
            self.runeTiles[i]=tile
        end
        self.runeSurface={id="ResourceBars.runes",module=self.id,frame=self.runeFrame,security="OWNED_VISUAL",groups={combat=true},
            fallback="AMBIENT",editable=true,minWidth=24,minHeight=16,layout={x=0,y=-.12,width=250,height=62,scale=1}}
        self.runeSurface.OnLayout=function(surface,l)
            if not self:FitResourceSurface(surface,l,180,62,self.runeEligible) then
                if self.runeEligible then self.runeState="LAYOUT_DOES_NOT_FIT" end
                return
            end
            self.runeHeadingFit=self:FitResourceHeading(self.runeTitle,"Runes",l.width-14)
            local width=(l.width-14-5*6)/6
            for i,tile in ipairs(self.runeTiles) do tile:SetSize(width,math.min(34,l.height-28));tile:ClearAllPoints();tile:SetPoint("TOPLEFT",7+(i-1)*(width+6),-24) end
        end
        M.CVE:Register(self.runeSurface)
    end
    self:ClearRunes(reason)
    if self.runeSurface then
        self.runeSurface.disabled=not usable
        M.state.forceEvaluate=true
        M.Layout:Apply(self.runeSurface)
        if not usable then M.Effects:Stop(self.runeSurface) end
    end
    self.runeDirty=usable;self.runeNext=0
end
function R:RefreshRunes()
    if not self.runeSurface or self.runeSurface.disabled then return end
    local limited=false
    local revision=self.runeRevision
    for i,tile in ipairs(self.runeTiles) do
        local ok,start,duration,ready=pcall(GetRuneCooldown,i)
        if revision~=self.runeRevision then return end
        tile.timer:Hide()
        if tile.timer.Clear then pcall(tile.timer.Clear,tile.timer) end
        tile.label:SetText(tostring(i))
        if not ok or not S:Readable(ready) or type(ready)~="boolean" then
            tile.label:SetText("—");tile:SetAlpha(.4);limited=true
        elseif ready then tile:SetAlpha(1)
        elseif not S:Number(start) or not S:Number(duration) or start<0 or duration<=0 or duration>600 then
            tile.label:SetText("—");tile:SetAlpha(.4);limited=true
        else
            local rendered=pcall(tile.timer.SetCooldown,tile.timer,start,duration)
            if revision~=self.runeRevision then tile.timer:Hide();return end
            tile.timer:SetShown(rendered)
            tile:SetAlpha(rendered and 1 or .4)
            if not rendered then tile.label:SetText("—");limited=true end
        end
    end
    self.runeState=limited and "PARTIAL_UNAVAILABLE" or "PUBLIC_NATIVE_TIMERS"
end
function R:ApplyConfig() apply(self);self:ConfigureRunes() end
function R:Suspend()
    suspend(self)
    self.runesPending=nil
    self.runeEligible=false
    self.runeDirty=false
    if self.runeSurface then self.runeSurface.disabled=true;M.Effects:Stop(self.runeSurface) end
    self:ClearRunes("DISABLED")
end
function R:WantsEvent(name)
    if name=="RUNE_POWER_UPDATE" then return M:ModuleConfig(self.id).runes==true end
    return not wants or wants(self,name)
end
function R:OnEvent(name,unit,...)
    event(self,name,unit,...)
    if name=="RUNE_POWER_UPDATE" then
        if self.runeSurface and not self.runeSurface.disabled then self.runeDirty=true
        elseif self.runeState=="CLASS_UNAVAILABLE" or self.runeState=="RUNE_SOURCE_UNAVAILABLE" then
            self.runesPending=true
        end
    end
end
function R:Tick(now)
    tick(self,now)
    if self.runesPending and not S:InCombat() then self:ConfigureRunes() end
    if self.runeDirty and self.runeSurface and not self.runeSurface.disabled and self.runeFrame:IsVisible() and now>=(self.runeNext or 0) then
        self.runeDirty=false;self.runeNext=now+.1;self:RefreshRunes()
    end
end
