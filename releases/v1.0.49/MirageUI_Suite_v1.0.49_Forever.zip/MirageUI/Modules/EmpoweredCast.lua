local _, M = ...
local R, S = M.modules.ResourceBars, M.Safety
-- Separate from the three-row Under-Character HUD. Stage widths are equal UI
-- slots, not proportional duration estimates. Native widgets own every fill.
M.EmpoweredCast = {status="DISABLED", maximumStages=8}
local E=M.EmpoweredCast
local events={UNIT_SPELLCAST_EMPOWER_START=true,UNIT_SPELLCAST_EMPOWER_UPDATE=true,
 UNIT_SPELLCAST_EMPOWER_STOP=true,UNIT_SPELLCAST_INTERRUPTED=true,UNIT_SPELLCAST_FAILED=true,
 UNIT_SPELLCAST_START=true,UNIT_SPELLCAST_CHANNEL_START=true,UNIT_SPELLCAST_CHANNEL_UPDATE=true,UNIT_SPELLCAST_CHANNEL_STOP=true,
 PLAYER_ENTERING_WORLD=true}
for event in pairs(events) do R.events[event]=true end
function E:Clear(reason)
 local ticket={}
 self.delivery=ticket
 local function current() return self.delivery==ticket end
 -- Core withdraws world authority before module dispatch. This existing hook
 -- also releases the player-row timer even when the stage option is disabled.
 if reason=="WORLD_LEFT" and R.cast then R:EndCast(reason) end
 if not current() then return end
 self.active=false;self.status=reason or "IDLE"
 if not self.frame then self.delivery=nil;return end
 self.surface.disabled=true;M.state.forceEvaluate=true
 local failed=false
 for _,bar in ipairs(self.bars) do
  if type(bar.ClearTimerDuration)=="function" then
   local ok=pcall(bar.ClearTimerDuration,bar);failed=failed or not ok
  end
  if not current() then return end
  local ok=pcall(bar.Hide,bar);failed=failed or not ok
  if not current() then return end
 end
 local ok=pcall(self.frame.Hide,self.frame);failed=failed or not ok
 if not current() then return end
 self.surface.disabled=true;M.state.forceEvaluate=true
 if self.surface then
  local ok=pcall(M.Effects.Stop,M.Effects,self.surface,current);failed=failed or not ok
 end
 if current() then
  if failed then self.status="STAGE_CLEANUP_UNAVAILABLE" end
  self.delivery=nil
  if R.castKind=="empower" and not R.awaitStart and M:ModuleConfig("ResourceBars").enabled and not M.state.safe then R:BindCast() end
 end
end
local function fits(label,width,height)
 local w,ws=S:Public(label.GetUnboundedStringWidth,"number",label)
 local h,hs=S:Public(label.GetStringHeight,"number",label)
 return ws=="KNOWN" and hs=="KNOWN" and w>0 and h>0 and w<=width and h<=height
end
function E:Configure()
 local cfg=M:ModuleConfig("ResourceBars")
 if not cfg.empoweredStages then self:Clear("DISABLED");return end
 if type(UnitEmpoweredStageDurations)~="function" or type(UnitChannelInfo)~="function" then self:Clear("NATIVE_STAGE_PROVIDER_UNAVAILABLE");return end
 if not self.frame then
  if S:InCombat() then self.status="SETUP_REQUIRES_OUT_OF_COMBAT";return end
  self.frame=M:TrackRoot("ResourceBars",M.UI:Card(UIParent,280,54));self.frame:Hide();S:Passive(self.frame)
  self.title=M.UI:Text(self.frame,"Empowered cast",7,-5,10,266)
  self.bars={};self.labels={}
  for i=1,self.maximumStages+1 do
   local bar=M.UI:Bar(self.frame,7,-23,24,12,.68,.58,.88);S:Passive(bar);bar:Hide()
   self.bars[i]=bar;self.labels[i]=M.UI:Text(bar,i==self.maximumStages+1 and "Hold" or tostring(i),1,0,9,24)
  end
  self.surface={id="ResourceBars.empower",module="ResourceBars",frame=self.frame,security="OWNED_VISUAL",groups={combat=true},fallback="HIDDEN",disabled=true,editable=true,minWidth=24,minHeight=16,
   layout={x=0,y=-.29,width=280,height=54,scale=1}}
  self.surface.OnLayout=function(_,l)
   local width=(l.width-14-3*self.maximumStages)/(self.maximumStages+1)
   -- Generic imported rectangles start at 24 x 16. Even the empty
   -- one-unit text inset and the bottom of the slot at y=35 must fit.
   if width<=1 or l.height<35 then
    self.labelsFit=false
    self:Clear("STAGE_LABEL_FIT_UNAVAILABLE")
    return
   end
   self.title:SetWidth(l.width-14)
   self.labelsFit=fits(self.title,l.width-14,18)
   for i,bar in ipairs(self.bars) do
    bar:ClearAllPoints();bar:SetPoint("TOPLEFT",self.frame,"TOPLEFT",7+(i-1)*(width+3),-23);bar:SetSize(width,12)
    self.labels[i]:SetWidth(width-1)
    self.labelsFit=self.labelsFit and fits(self.labels[i],width-1,12)
   end
   if not self.labelsFit then self:Clear("STAGE_LABEL_FIT_UNAVAILABLE") end
  end
  self.surface.Intent=function()
   -- This is an explicit player cast lifecycle flag, never a decoded duration.
   -- A normal CAST_STOP cannot remove a still-active empowered display.
   if E.active then return "VISIBLE","PLAYER_EMPOWER_ACTIVITY",1 end
  end
  M.CVE:Register(self.surface)
 end
 if not S:InCombat() then M.Layout:Apply(self.surface) end
 if not self.active and self.labelsFit then self:Clear("IDLE") end
end
-- Current-delivery failures retire inside the same serialized operation.
local clearDelivery=E.Clear
function E:Refresh()
 if not M:IsModuleActive("ResourceBars") or not M:ModuleConfig("ResourceBars").empoweredStages or not self.frame then clearDelivery(self,"DISABLED");return false end
 if R.castKind~="empower" then clearDelivery(self,"WAITING_FOR_START");return false end
 -- A native getter or widget call may synchronously dispatch another event.
 -- Keep only a short-lived local ticket; no native identity is retained.
 local ticket={}
 local revision=R.castRevision
 self.delivery=ticket
 local function current() return self.delivery==ticket and R.castRevision==revision end
 local function retire(reason) if current() then clearDelivery(self,reason) end;return false end
 local allowed=M.Presentation:Allows("ResourceBars","cast")
 if not current() then return false end
 if not allowed then return retire("OWNED_ELSEWHERE") end
 if not self.labelsFit then return retire("STAGE_LABEL_FIT_UNAVAILABLE") end
 local ok,_,_,_,_,_,_,_,_,empowered,count=pcall(UnitChannelInfo,"player")
 if not current() then return false end
 if not ok or not S:Readable(empowered) or empowered~=true or not S:Number(count) or count%1~=0 or count<1 or count>self.maximumStages then
  return retire("STAGE_METADATA_UNAVAILABLE")
 end
 if not current() then return false end
 local good,vector=pcall(UnitEmpoweredStageDurations,"player")
 if not current() then return false end
 if not good or not S:Readable(vector) or type(vector)~="table" then return retire("STAGE_DURATIONS_UNAVAILABLE") end
 if not current() then return false end
 local access,allowed=pcall(canaccesstable,vector)
 if not current() then return false end
 if not access or not S:Readable(allowed) or allowed~=true then return retire("STAGE_DURATIONS_UNAVAILABLE") end
 if not current() then return false end
 local direction=Enum and Enum.StatusBarTimerDirection and Enum.StatusBarTimerDirection.ElapsedTime
 if not S:Number(direction) then return retire("STAGE_RENDERER_UNAVAILABLE") end
 if not current() then return false end
 -- Do not measure, format, compare, sum, or query these duration objects. Only
 -- the public stage count is used for geometry/labels; hold always uses slot 9.
 local success,complete=pcall(function()
  for i,bar in ipairs(self.bars) do
   if not current() then return false end
   local index=i<=count and i or i==self.maximumStages+1 and count+1 or nil
   if index then
    local duration=vector[index]
    if not current() then return false end
    local readable=S:Readable(duration)
    if not current() then return false end
    if readable and duration==nil then error("MISSING_STAGE_OBJECT") end
    if type(bar.SetTimerDuration)~="function" then error("MISSING_STAGE_SINK") end
    bar:SetTimerDuration(duration,Enum and Enum.StatusBarInterpolation and Enum.StatusBarInterpolation.Immediate,direction)
    if not current() then return false end
    bar:Show()
   else
    if type(bar.ClearTimerDuration)=="function" then bar:ClearTimerDuration() end
    if not current() then return false end
    bar:Hide()
   end
  end
  return current()
 end)
 if not success then return retire("STAGE_DISPATCH_UNAVAILABLE") end
 if not complete then return retire("STAGE_DISPATCH_SUPERSEDED") end
 if not current() then return false end
 self.active=true;self.status="NATIVE_STAGE_DISPATCH_NOT_CERTIFIED";self.surface.disabled=false
 R:HideCast("OWNED_EMPOWER_STAGES")
 self.frame:Show()
 if not current() then return false end
 M.state.forceEvaluate=true;self.delivery=nil
 return true
end
-- Native mutations may dispatch an event before their own write completes.
-- Serialize whole deliveries/retirements so a nested successor cannot be
-- overwritten by that returning write. Only request kind/reason is queued;
-- no native values or duration objects outlive their ordinary local call.
local clearBody,refreshBody=E.Clear,E.Refresh
local function work(self,kind,reason)
 if self.discardReentry then return false end
 if self.workBusy then
  if kind=="clear" and self.workKind=="refresh" and reason=="WAITING_FOR_START" then
   reason="STAGE_DISPATCH_SUPERSEDED"
  end
  self.pendingWork={kind=kind,reason=reason}
  self.delivery=nil;self.active=false
  return false
 end
 self.workBusy=true
 self.pendingWork={kind=kind,reason=reason}
 local result=false
 for attempt=1,2 do
  local request=self.pendingWork
  if not request then break end
  self.pendingWork=nil;self.workKind=request.kind
  local ok,done=pcall(request.kind=="clear" and clearBody or refreshBody,self,request.reason)
  result=ok and done==true
  -- A failed obsolete call cannot replace a newer queued request or expose
  -- its error payload. Current unexpected widget failures still retire.
  if not ok and not self.pendingWork then
   self.delivery=nil;self.active=false
   self.pendingWork={kind="clear",reason="STAGE_DISPATCH_UNAVAILABLE"}
  end
 end
 if self.pendingWork then
  -- Sustained callback churn is unavailable, never an unbounded drain. Do
  -- one terminal cleanup while refusing further nested rendering requests.
  -- No tick/retry is required for STOP, world exit or disabled modules.
  self.pendingWork=nil;self.discardReentry=true
  pcall(clearBody,self,"STAGE_REENTRY_LIMIT")
  self.discardReentry=nil;self.pendingWork=nil;result=false
 end
 self.workKind=nil;self.workBusy=nil
 return result
end
function E:Clear(reason) return work(self,"clear",reason) end
function E:Refresh() return work(self,"refresh") end
function E:OnEvent(event,unit)
 if not M:ModuleConfig("ResourceBars").empoweredStages then return end
 if event:sub(1,5)=="UNIT_" and (not S:Text(unit) or unit~="player") then return end
 if event=="PLAYER_ENTERING_WORLD" then self:Clear("WORLD_RESET");return end
 if R.castKind~="empower" then
  self:Clear(R.castKind and "OTHER_CAST_KIND" or "WAITING_FOR_START")
  return
 end
 if event=="UNIT_SPELLCAST_EMPOWER_START" or event=="UNIT_SPELLCAST_EMPOWER_UPDATE"
  or event=="UNIT_SPELLCAST_CHANNEL_START" or event=="UNIT_SPELLCAST_CHANNEL_UPDATE" then self:Refresh() end
end
local oldConfig,oldResume,oldSuspend,oldEvent,oldWants=R.ApplyConfig,R.Resume,R.Suspend,R.OnEvent,R.WantsEvent
function R:WantsEvent(event)
 -- Continuous empowered casting also consumes updates when the optional stage
 -- panel is disabled. The module enable flag remains the subscription gate.
 if event=="UNIT_SPELLCAST_EMPOWER_UPDATE" then return M:ModuleConfig("ResourceBars").enabled==true end
 return not oldWants or oldWants(self,event)
end
function R:ApplyConfig(...) oldConfig(self,...);E:Configure() end
function R:Resume(...) oldResume(self,...);E:Clear("RESUME");E:Configure() end
function R:Suspend(...) E:Clear("DISABLED");return oldSuspend(self,...) end
-- A context switch can remove a player spell before the expected stop arrives.
-- No amount/capacity or ordinary power update establishes such a switch.
local contextReset={
 PLAYER_ENTERING_WORLD=true,PLAYER_SPECIALIZATION_CHANGED=true,UPDATE_SHAPESHIFT_FORM=true,
 UNIT_ENTERED_VEHICLE=true,UNIT_EXITED_VEHICLE=true,
}
function R:OnEvent(event,unit,...)
 if contextReset[event] and self.castKind then
  local subjectEvent=event=="PLAYER_SPECIALIZATION_CHANGED" or event=="UNIT_ENTERED_VEHICLE" or event=="UNIT_EXITED_VEHICLE"
  if not subjectEvent or not S:Text(unit) or unit=="player" then
   self:EndCast("CAST_CONTEXT_CHANGED")
   if E.active then E:Clear("CAST_CONTEXT_CHANGED") end
  end
 end
 oldEvent(self,event,unit,...)
 if events[event] then E:OnEvent(event,unit) end
end
