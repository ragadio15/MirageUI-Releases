local _, M = ...
local B=M.modules.Bags
local nativeApply,nativeSuspend,nativeResume,nativeEvent=B.ApplyConfig,B.Suspend,B.Resume,B.OnEvent
B.events.BAG_UPDATE_DELAYED=true;B.events.GET_ITEM_INFO_RECEIVED=true;B.events.PLAYER_REGEN_DISABLED=true
for _,event in ipairs({"BANKFRAME_OPENED","BANKFRAME_CLOSED","BANK_TABS_CHANGED","PLAYER_ACCOUNT_BANK_TAB_SLOTS_CHANGED","PLAYER_LEAVING_WORLD"}) do B.events[event]=true end
local sourceLabels={carried="Carried items",character="Character bank",account="Account bank"}
function B:CreateBrowser()
 if self.browserFrame or M.Safety:InCombat() then return end
 local f=M:TrackRoot(self.id,M.UI:Panel("MirageUIInventoryBrowser",M.Icons and M.Icons:Label("inventory","Bags",22) or "Bags",560,500));self.browserFrame=f
 self.browserTiles={};self.browserPage=1;self.query="";self.sortOrder="slot";self.browserSource="carried"
 self.navStart=M.UI:Button(f,"Controller / F6",354,-54,190,function() M.DialogNavigation:Start(f,true) end)
 self.spaceText=M.UI:Text(f,"Carried space: not checked",16,-52,10,322)
 self.search=M.UI:Edit(f,16,-88,300,"",function(text) self.query=text:sub(1,80);self.browserPage=1;self.browserDirty=true end)
 self.search:SetScript("OnTextChanged",function(box,user)
  if user then self.query=box:GetText():sub(1,80);self.browserPage=1;self.browserDirty=true end
 end)
 self.sortButton=M.UI:Button(f,"Sort: bag order",326,-88,215,function()
  self.sortOrder=self.sortOrder=="slot" and "name" or "slot"
  self.sortButton:SetText(self.sortOrder=="slot" and "Sort: bag order" or "Sort: name")
  self.browserPage=1;self.browserDirty=true
 end)
 self.sourceButton=M.UI:Button(f,"Carried items",16,-124,220,function(button)
  M.UI:Choose(button,{{value="carried",label="Carried items"},{value="character",label="Character bank"},{value="account",label="Account bank"}},self.browserSource,function(source)
   if not self:BrowserActive() then return end
   self:ClearBrowserTooltip();if self.browserTooltipReceipt then return end;self:InvalidateSpace();self.browserSource=source;self.browserPage=1;self.browserData=nil;self.browserDirty=true;self.browserNext=0
   self.sourceButton:SetText(sourceLabels[source]);self:RenderBrowser()
  end)
 end)
 self.browserHint=M.UI:Text(f,"Read-only bank view.\nOpen the native bank window.",16,-162,10,520)
 for i=1,72 do
  local tile=CreateFrame("Button",nil,f,"BackdropTemplate");M.UI:Backdrop(tile,true)
  tile.icon=tile:CreateTexture(nil,"ARTWORK");tile.icon:SetPoint("TOPLEFT",2,-2);tile.icon:SetPoint("BOTTOMRIGHT",-2,2)
  tile.count=M.UI:Text(tile,"",3,-3,10,40);tile.count:SetJustifyH("RIGHT")
  tile:SetScript("OnEnter",function()
   if not self:BrowserActive() or not tile.item or not M.Inventory:SameSlot(tile.item) then return end
   self:ShowBrowserTooltip(tile)
  end)
  tile:SetScript("OnLeave",function() self:ClearBrowserTooltip(tile) end)
  -- Intentional absence of item-use or pickup handlers; no destructive command path.
  tile:SetScript("OnClick",function() if self:BrowserActive() then self:OpenNativeBags() end end)
  tile:Hide();self.browserTiles[i]=tile
 end
 self.previous=M.UI:Button(f,"Previous",16,-440,105,function() if self:BrowserActive() then self.browserPage=math.max(1,self.browserPage-1);self:RenderBrowser() end end)
 self.next=M.UI:Button(f,"Next",126,-440,105,function() if self:BrowserActive() then self.browserPage=math.min(self.browserPages or 1,self.browserPage+1);self:RenderBrowser() end end)
 self.nativeButton=M.UI:Button(f,"Open native bags",326,-440,215,function() if self:BrowserActive() then self:OpenNativeBags() end end)
 self.browserFooter=M.UI:Text(f,"",16,-477,10,520)
 self.browserSurface={id="Bags.browser",module=self.id,frame=f,security="OWNED_VISUAL",groups={tasks=true},fallback="HIDDEN",editable=true,disabled=true,
  minWidth=420,minHeight=400,layout={x=.12,y=0,width=560,height=500,scale=1}}
 self.browserSurface.OnLayout=function(_,l) self:LayoutBrowser(l) end
 M.CVE:Register(self.browserSurface);M.Layout:Apply(self.browserSurface)
 f:SetScript("OnHide",function()
  self.browserOpen=false;self.browserSurface.disabled=true;self.browserSurface.userOpened=false;self.browserPointerAwaitRelease=nil
  self.browserData=nil;self:InvalidateSpace();self:ClearBrowserTooltip();self.search:ClearFocus();M.UI:CloseChoices()
  for _,t in ipairs(self.browserTiles) do t.item=nil;t.icon:SetTexture(nil);t.count:SetText("") end
 end)
 M.DialogNavigation:Attach(f,{allowed=function() return self:BrowserActive() end,entries=function()
  local entries={{frame=self.navStart,key="navigation",kind="button"},{frame=self.search,key="search",kind="edit"},{frame=self.sortButton,key="sort",kind="button"},{frame=self.sourceButton,key="source",kind="button"}}
  for i,tile in ipairs(self.browserTiles) do entries[#entries+1]={frame=tile,key="item:"..i,kind="button",identity=tile.item,onFocus=function() self.navigationTile=tile;local enter=tile:GetScript("OnEnter");if enter then enter(tile) end end,onBlur=function() if self.navigationTile==tile then self.navigationTile=nil end;self:ClearBrowserTooltip(tile) end} end
  for _,row in ipairs({{self.previous,"previous"},{self.next,"next"},{self.nativeButton,"native"},{f.closeButton,"close"}}) do entries[#entries+1]={frame=row[1],key=row[2],kind="button"} end
  return entries
 end})
end
-- A dispatch result never establishes tooltip contents or native rendering. This
-- receipt owns only an observed tile/tooltip association and its cleanup debt.
local function receiptCurrent(self,r)
 return self.browserTooltipReceipt==r and M.modules[self.id]==self
end
local function tooltipMethod(self,r,name)
 if not receiptCurrent(self,r) or not M.Safety:Frame(r.tooltip,true) or not receiptCurrent(self,r) then return end
 local ok,fn=pcall(function() return r.tooltip[name] end)
 if not ok or not receiptCurrent(self,r) or not M.Safety:Readable(fn) or type(fn)~="function" then return end
 return fn
end
local function tooltipRead(self,r,name,kind)
 local fn=tooltipMethod(self,r,name);if not fn then return nil,false end
 local ok,value=pcall(fn,r.tooltip)
 if not ok or not receiptCurrent(self,r) or not M.Safety:Readable(value) or (kind and type(value)~=kind) then return nil,false end
 return value,true
end
local function forgetTooltip(self,r)
 if not receiptCurrent(self,r) then return end
 -- OnHide clears browserData; cache invalidations alone must not drop debt.
 local release=r.pointerRelease
 if release and self.browserOpen and self.browserData==release.data
  and self.browserSource==release.source and M.Inventory==release.inventory and M.profile==release.profile then
  self.browserPointerAwaitRelease=true
 end
 self.browserTooltipReceipt=nil
 if self.browserHoverToken==r then self.hoverTile=nil;self.browserHoverToken=nil end
end
function B:ClearBrowserTooltip(tile)
 local r=self.browserTooltipReceipt
 if not r or (tile and not rawequal(tile,r.tile)) then return end
 r.pending=true;if r.acquiring then r.cancelled=true end
 if r.cleaning then return end
 r.cleaning=true
 local ok=pcall(function()
  local shown,shownKnown=tooltipRead(self,r,"IsShown","boolean")
  if shownKnown and not shown then forgetTooltip(self,r);return end
  local hide=tooltipMethod(self,r,"Hide");if not hide then return end
  -- Read ownership after all method/safety probes and before the owned write.
  local owner,ownerKnown=tooltipRead(self,r,"GetOwner")
  if not ownerKnown then return end
  if not rawequal(owner,r.tile) then forgetTooltip(self,r);return end
  if not receiptCurrent(self,r) then return end
  pcall(hide,r.tooltip)
  if not receiptCurrent(self,r) then return end
  local afterShown,knownShown=tooltipRead(self,r,"IsShown","boolean")
  local afterOwner,knownOwner=tooltipRead(self,r,"GetOwner")
  if not receiptCurrent(self,r) then return end
  if (knownShown and not afterShown) or (knownOwner and not rawequal(afterOwner,r.tile)) then forgetTooltip(self,r) end
 end)
 r.cleaning=nil
 -- Unknown/failed cleanup retains the same receipt; only a public postcondition
 -- retires it. Inactive browser ticks and explicit lifecycle entry points retry.
 if not ok and receiptCurrent(self,r) then r.pending=true end
end
function B:RetryBrowserTooltip(now)
 local r=self.browserTooltipReceipt
 if not r or not r.pending or r.cleaning then return end
 if not M.Safety:Number(now) then now=M.Safety:Now() end
 if now<(r.retryAt or self.browserHoverNext or 0) then return end
 r.retryAt=now+.25
 self:ClearBrowserTooltip()
end
function B:ShowBrowserTooltip(tile)
 local tooltip=GameTooltip
 if not M.Safety:Readable(tooltip) or not tooltip or not self:BrowserActive() or not tile.item then return end
 local old=self.browserTooltipReceipt
 if old and (not rawequal(old.tooltip,tooltip) or (old.pending and not old.cleaning)) then
  self:ClearBrowserTooltip()
  if self.browserTooltipReceipt then return end
 end
 -- Same-object renewal supersedes the prior request, including a request whose
 -- cleanup callback is now running. Its old callback may not retire this one.
 local r={tooltip=tooltip,tile=tile,item=tile.item,pending=true,acquiring=true}
 if self.browserHoverToken==old then self.hoverTile=nil;self.browserHoverToken=nil end
 self.browserTooltipReceipt=r
 local function active()
  return not r.cancelled and receiptCurrent(self,r) and M.Safety:Readable(GameTooltip) and rawequal(GameTooltip,tooltip) and tile.item==r.item and self:BrowserActive() and receiptCurrent(self,r) and not r.cancelled
 end
 local function dispatch(name,...)
  local fn=tooltipMethod(self,r,name)
  if not fn or not active() then return false end
  local ok=pcall(fn,tooltip,...)
  return ok and active()
 end
 local ok=dispatch("SetOwner",tile,"ANCHOR_RIGHT")
 if ok then
  local owner,known=tooltipRead(self,r,"GetOwner")
  ok=known and rawequal(owner,tile) and active()
 end
 if ok then ok=dispatch("SetBagItem",r.item.bag,r.item.slot) end
 if ok then ok=dispatch("Show") end
 local shown,shownKnown=tooltipRead(self,r,"IsShown","boolean")
 local owner,ownerKnown=tooltipRead(self,r,"GetOwner")
 if ok and shownKnown and shown and ownerKnown and rawequal(owner,tile) and active() then
  r.acquiring=nil;r.pending=nil;self.hoverTile=tile;self.browserHoverToken=r;self.browserHoverNext=0
 elseif receiptCurrent(self,r) then
  self.browserDirty=true;self:ClearBrowserTooltip(tile)
 end
end
function B:BrowserActive()
 return self.browserOpen and self.browserFrame and self.browserFrame:IsVisible() and M:IsModuleActive(self.id) and not M.Safety:InCombat()
end
function B:LayoutBrowser(l)
 local cfg=M:ModuleConfig(self.id);local gap=5
 local textScale=M.profile.textScale or 1
 local textHeight=math.ceil(28*textScale)
 local searchY=88+textHeight+8;local sourceY=searchY+36
 local hintY=sourceY+36;local gridY=hintY+textHeight+8
 self.browserCols=math.min(cfg.columns,math.max(4,math.floor((l.width-32)/(cfg.iconSize+gap))))
 self.browserRows=math.max(1,math.min(12,math.floor((l.height-gridY-68)/(cfg.iconSize+gap))))
 self.browserCapacity=math.min(72,self.browserCols*self.browserRows)
 self.navStart:ClearAllPoints();self.navStart:SetPoint("TOPRIGHT",-16,-54);self.navStart:SetWidth(190);self.navStart.label:SetWidth(174)
 self.spaceText:ClearAllPoints();self.spaceText:SetPoint("TOPLEFT",16,-88);self.spaceText:SetWidth(l.width-32);self.spaceText:SetHeight(textHeight)
 self.search:ClearAllPoints();self.search:SetPoint("TOPLEFT",16,-searchY)
 self.sourceButton:ClearAllPoints();self.sourceButton:SetPoint("TOPLEFT",16,-sourceY)
 self.browserHint:ClearAllPoints();self.browserHint:SetPoint("TOPLEFT",16,-hintY);self.browserHint:SetHeight(textHeight)
 self.search:SetWidth(math.max(150,l.width-260));self.sortButton:ClearAllPoints();self.sortButton:SetPoint("TOPRIGHT",-16,-searchY)
 self.browserHint:SetWidth(l.width-32);self.browserFooter:SetWidth(l.width-32);self.browserFooter:SetHeight(math.ceil(14*textScale))
 for i,t in ipairs(self.browserTiles) do
  t:SetSize(cfg.iconSize,cfg.iconSize);t:ClearAllPoints()
  t:SetPoint("TOPLEFT",16+((i-1)%self.browserCols)*(cfg.iconSize+gap),-gridY-math.floor((i-1)/self.browserCols)*(cfg.iconSize+gap))
  t.count:SetWidth(cfg.iconSize-6)
 end
 self.previous:ClearAllPoints();self.previous:SetPoint("BOTTOMLEFT",16,34)
 self.next:ClearAllPoints();self.next:SetPoint("BOTTOMLEFT",126,34)
 self.nativeButton:ClearAllPoints();self.nativeButton:SetPoint("BOTTOMRIGHT",-16,34);self.nativeButton:SetWidth(math.min(215,l.width-252));self.nativeButton:SetText("Native bags");self.nativeButton.label:SetWidth(self.nativeButton:GetWidth()-16)
 self.sourceButton:SetWidth(math.min(220,l.width-32))
 self.browserFooter:ClearAllPoints();self.browserFooter:SetPoint("BOTTOMLEFT",16,12)
 self.browserPage=1;self.browserDirty=true
 if not self:BrowserFits(l) then self.browserFrame:Hide() end
end
function B:BrowserFits(l)
 local S=M.Safety
 -- Layout:Get also reads the viewport. Contain that existing read before the
 -- new fit calculation; unavailable dimensions must not quarantine the module.
 if l==nil then
  local surface=self.browserSurface or {id="Bags.browser",minWidth=420,minHeight=400,layout={x=.12,y=0,width=560,height=500,scale=1}}
  l=S:Public(M.Layout.Get,"table",M.Layout,surface)
 end
 local width,height=S:Field(l,"width"),S:Field(l,"height")
 local scale,scaleState=S:FieldAccess(l,"scale")
 if scaleState=="ABSENT" then scale=1 elseif scaleState~="KNOWN" then return false end
 local viewWidth=S:Public(UIParent and UIParent.GetWidth,"number",UIParent)
 local viewHeight=S:Public(UIParent and UIParent.GetHeight,"number",UIParent)
 for _,value in ipairs({width or false,height or false,scale,viewWidth or false,viewHeight or false}) do
  if not S:Number(value) or value<=0 then return false end
 end
 return width*scale+16<=viewWidth and height*scale+16<=viewHeight
end
function B:OpenNativeBags()
 if M.Safety:InCombat() then return false,"COMBAT_VETO" end
 if not M:IsModuleActive(self.id) then return false,"MODULE_DISABLED" end
 if type(OpenAllBags)~="function" then return false,"UNAVAILABLE" end
 if M.DialogNavigation.active==self.browserFrame then M.DialogNavigation:Stop() end
 local ok=pcall(OpenAllBags)
 -- This status reports dispatch only, never that native bags visibly opened.
 return ok,ok and "REQUEST_SENT" or "DISPATCH_FAILED"
end
function B:OpenBrowser()
 self:ClearBrowserTooltip()
 if M.Safety:InCombat() or not M:IsModuleActive(self.id) then return false,"Enable Bags outside combat first." end
 if not M:ModuleConfig(self.id).browser then return false,"Enable the inventory browser and Apply first." end
 if not self:BrowserFits() then if self.browserFrame then self.browserFrame:Hide() end;return false,"Inventory browser does not fit this viewport. Use native bags." end
 self:CreateBrowser();self:InvalidateSpace();self.browserSource="carried";self.sourceButton:SetText(sourceLabels.carried);self.browserSurface.disabled=false;self.browserSurface.userOpened=true;self.browserOpen=true
 if M.UI and type(M.UI.CloseChoices)=="function" then M.UI:CloseChoices() end
 if M.AccessibleInput and type(M.AccessibleInput.Stop)=="function" then M.AccessibleInput:Stop() end
 if M.OptionsNavigation and type(M.OptionsNavigation.Stop)=="function" then M.OptionsNavigation:Stop() end
 M.DialogNavigation:Shown(self.browserFrame)
 self.browserFrame:Show();self:RenderSpace();self.browserDirty=true;self.browserNext=0;M.CVE:Tick(true)
 return true,"Inventory browser opened. Item operations remain in native bags."
end
-- Space observations are independent of query and item ordering. Retire them
-- immediately on inventory invalidation, even while item/tooltip refresh waits.
function B:InvalidateSpace()
 self.spaceGeneration=(self.spaceGeneration or 0)+1;self.spaceInvalid=true
 if self.spaceText then self.spaceText:SetText("") end
end
function B:RenderSpace()
 if not self.spaceText then return end
 if self.browserSource~="carried" then
  self.spaceText:SetText("Carried space: not shown")
  self.browserHint:SetText("Read-only bank view.\nOpen the native bank window.")
  return
 end
 self.browserHint:SetText("Includes specialized bags.\nSnapshot only. Not item-fit.")
 local space=not self.spaceInvalid and self.browserData and self.browserData.space
 if not space or space.state=="INVALIDATED" then self.spaceText:SetText("Carried space: not checked");return end
 if space.state=="UNAVAILABLE" then self.spaceText:SetText("Carried space: unknown");return end
 if space.state=="COMPLETE" then
  self.spaceText:SetText("Empty "..space.empty.." / "..space.total.." slots\nOccupied "..space.occupied)
 else
  local total=space.total~=nil and tostring(space.total) or "?"
  self.spaceText:SetText("Empty "..space.observedEmpty.."+ / "..total.." slots\nOccupied "..space.observedOccupied.."+ (partial)")
 end
end
function B:RenderBrowser()
 if not self:BrowserActive() then return end
 local data=self.browserData or {items={},state="UNAVAILABLE"};local capacity=self.browserCapacity or 48
 self.browserPages=math.max(1,math.ceil(#data.items/capacity));self.browserPage=math.min(self.browserPage,self.browserPages)
 local offset=(self.browserPage-1)*capacity
 for i,t in ipairs(self.browserTiles) do
  local item=i<=capacity and data.items[offset+i] or nil
  t.item=item;t.icon:SetTexture(item and item.icon);t.count:SetText(item and item.count and item.count>1 and tostring(item.count) or "");t:SetShown(item~=nil)
 end
 self.browserFooter:SetText(self.browserPage.."/"..self.browserPages.." · "..#data.items.." matches"..(data.state=="PARTIAL_UNAVAILABLE" and " · partial" or ""))
 if data.state=="UNSUPPORTED" or data.state=="UNAVAILABLE" then
  self.browserFooter:SetText("Items unavailable · native bags")
 elseif data.state:find("BANK_",1,true) then
  self.browserFooter:SetText(data.state=="BANK_CLOSED" and "Bank closed · use native bank" or "Bank unavailable · native bank")
 end
 self.browserState=data.state;self:RenderSpace()
 M.DialogNavigation:Refresh(self.browserFrame)
end
function B:Tick(now)
 if self.browserHoverChecking then return end
 self:RetryBrowserTooltip(now)
 if self.browserTooltipReceipt and self.browserTooltipReceipt.pending then return end
 if not self:BrowserActive() then return end
 if not self:BrowserFits() then self.browserFrame:Hide();return end
 if self.browserSource~="carried" then
  local accessible,reason=M.Inventory:Access(self.browserSource)
  if not accessible then
   self:ClearBrowserTooltip()
   if not self.browserData or self.browserData.state~=reason then
    self.browserData={items={},state=reason};self:RenderBrowser()
   end
   self.browserAccessLost=true;return
  elseif self.browserAccessLost then
   self.browserAccessLost=false;self.browserDirty=true
  end
 end
 -- A pointer tooltip has the same slot-identity obligation as logical focus.
 -- Keep valid hover stable; dirty pointer holds revalidate at most four times a
 -- second instead of blocking fresh inventory forever after an item changes.
 local hover=self.hoverTile
 local logical=hover and self.navigationTile==hover
 if hover and hover.item and (logical or (self.browserDirty and now>=(self.browserHoverNext or 0))) then
  local item,data,generation,source=hover.item,self.browserData,self.spaceGeneration,self.browserSource
  local token=self.browserHoverToken
  local inventory,profile=M.Inventory,M.profile
  self.browserHoverNext=now+.25;self.browserHoverChecking=true
  local ok,same=pcall(inventory.SameSlot,inventory,item)
  self.browserHoverChecking=false
  -- A callback may dismiss/reopen, select another source, or acquire another
  -- tooltip. Never retire the successor from this old observation.
  if self.hoverTile~=hover or self.browserHoverToken~=token or hover.item~=item or self.browserData~=data or self.spaceGeneration~=generation
   or self.browserSource~=source or M.Inventory~=inventory or M.profile~=profile or M.modules[self.id]~=self or not self:BrowserActive() then return end
  if not ok or not same then
   self:ClearBrowserTooltip(hover)
   -- Hide/owner callbacks can close and reopen the browser. The retired
   -- operation cannot install a release latch into that successor lifecycle.
   if self.browserData~=data or self.spaceGeneration~=generation or self.browserSource~=source
    or M.Inventory~=inventory or M.profile~=profile or M.modules[self.id]~=self or not self:BrowserActive() then return end
   if self.hoverTile then
    -- Carry the pointer-release obligation through delayed cleanup, but never
    -- attach it to a successor receipt or a later browser lifecycle.
    if not logical and self.hoverTile==hover and self.browserTooltipReceipt==token and token.pending then
     token.pointerRelease={data=data,source=source,inventory=inventory,profile=profile}
    end
    return
   end
   if not logical then self.browserPointerAwaitRelease=true end
   if self.navigationTile==hover then self.navigationTile=nil end
   self.browserDirty=true
  end
 end
 -- Never remap a hovered/held row; its tooltip and identity remain stable.
 local down=M.Safety:Public(IsMouseButtonDown,"boolean","LeftButton")
 -- Retiring a pointer tooltip must not turn unknown input into a release.
 -- This latch applies only to the newly retired pointer path, not other scans.
 if self.browserPointerAwaitRelease then
  if down~=false then return end
  self.browserPointerAwaitRelease=nil
 end
 if self.hoverTile or down==true then return end
 if self.browserDirty and now>=(self.browserNext or 0) then
  local generation,source,query,order=self.spaceGeneration,self.browserSource,self.query,self.sortOrder
  local data=M.Inventory:Read(query,order,source);self.browserNext=now+.25
  if generation~=self.spaceGeneration or source~=self.browserSource or query~=self.query or order~=self.sortOrder or not self:BrowserActive() then self.browserDirty=true;return end
  self.browserData=data;self.spaceInvalid=false;self.browserDirty=false;self:RenderBrowser()
 end
end
function B:OnEvent(event,...)
 if event=="PLAYER_REGEN_DISABLED" or event=="PLAYER_LEAVING_WORLD" then if self.browserFrame then self.browserFrame:Hide() end
 elseif event=="BANKFRAME_CLOSED" then
  if self.browserSource~="carried" and self.browserFrame then self.browserFrame:Hide() end
 elseif event=="BANKFRAME_OPENED" or event=="BANK_TABS_CHANGED" or event=="PLAYER_ACCOUNT_BANK_TAB_SLOTS_CHANGED" then self.browserDirty=true
 elseif event=="BAG_UPDATE_DELAYED" or event=="GET_ITEM_INFO_RECEIVED" then
  if event=="BAG_UPDATE_DELAYED" then self:InvalidateSpace();if self:BrowserActive() then self:RenderSpace() end end
  self.browserDirty=true
 else nativeEvent(self,event,...) end
end
function B:WantsEvent(event)
 if event=="BAG_UPDATE_DELAYED" or event=="GET_ITEM_INFO_RECEIVED" then return M:ModuleConfig(self.id).browser end
 return true
end
function B:ApplyConfig()
 self:ClearBrowserTooltip()
 self:InvalidateSpace()
 nativeApply(self)
 if self.browserFrame then
  if not M:ModuleConfig(self.id).browser then self.browserFrame:Hide() else M.Layout:Apply(self.browserSurface) end
 end
end
function B:Resume() nativeResume(self);self:ApplyConfig() end
function B:Suspend() nativeSuspend(self);if self.browserFrame then self.browserFrame:Hide() end end
