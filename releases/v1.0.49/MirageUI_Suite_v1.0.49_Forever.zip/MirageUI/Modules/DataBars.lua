local _,M=...
-- b42 removes the six-fact sidebar card. Keep the module identity so existing
-- profiles/imports remain readable, but allocate no frame, surface, tooltip,
-- fact provider, event subscription or polling work for the retired display.
-- The native experience/reputation bars retain their independent owners.
local D={events={},retired=true,status="REMOVED_STATUS_PANEL"}
function D:Initialize() self.status="REMOVED_STATUS_PANEL" end
function D:ApplyConfig() self.status="REMOVED_STATUS_PANEL" end
function D:Refresh() end
function D:Suspend() end
function D:Resume() end
M:RegisterModule("DataBars",D)
