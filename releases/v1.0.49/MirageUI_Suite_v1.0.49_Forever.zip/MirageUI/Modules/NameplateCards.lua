local _,M=...
-- Independent Mirage artwork; Blizzard still owns nameplate existence and hitboxes.
-- Only exact, public nameplate visual regions are leased. No global nameplate CVars,
-- forbidden-plate enumeration, enemy scan, threat model or mouse-catching overlay.
M.NameplateCards={pool={},byUnit={},pending={},limit=80,status="DISABLED",attempts=0,lastRefusal="NONE"}
local N,S,V=M.NameplateCards,M.Safety,M.NameplateCard
local client,adapter=M.Client,M.adapter
local family,nativePending=adapter.family,adapter.nativePending
local runtimeClient=client.IsRuntimeClient
local function permitted(profile,config)
    local c=M:ModuleConfig("Nameplates")
    local conflict=M.Native:Conflict()
    local function current()
        return M.NameplateCards==N and M.NameplateCard==V and M.Safety==S
            and M.Client==client and M.adapter==adapter and client.allowed==true
            and type(runtimeClient)=="function" and client.IsRuntimeClient==runtimeClient
            and adapter.family==family and adapter.family==client.family and adapter.nativePending==nativePending
            and M.profile==profile and not M.state.safe and c and M:ModuleConfig("Nameplates")==c
            and (not config or c==config) and c.enabled==true and c.cards==true and not conflict
    end
    -- Build review is evidence, not permission. Public frame/input topology,
    -- original values and per-write readback still qualify every visual lease.
    return current() and runtimeClient(client)==true and current()
end
local refusals={NONE=true,DISABLED=true,UNQUALIFIED_CLIENT_OR_OWNER=true,INVALID_UNIT=true,
    PROTECTED_FRAME=true,FORBIDDEN_FRAME=true,FORBIDDEN_ANCESTOR=true,RESTRICTED_FRAME=true,
    RESTRICTED_ANCESTOR=true,UNKNOWN_PARENT=true,NATIVE_TREE_FALLBACK=true,NATIVE_ATTACH_IN_PROGRESS=true,
    DENSITY_LIMIT_NATIVE_FALLBACK=true,HEALTH_DISPLAY_UNAVAILABLE=true,NAME_UNAVAILABLE=true,
    NAME_DOES_NOT_FIT=true,NAME_FIT_UNKNOWN=true,SELECTION_UNAVAILABLE=true,ATTACHMENT_UNCONFIRMED=true,
    NATIVE_LEASE_UNCONFIRMED=true,MIRAGE_CARD_NATIVE_FALLBACK=true}
function N:Refuse(reason)
    self.lastRefusal=S:Text(reason) and refusals[reason] and reason or "MIRAGE_CARD_NATIVE_FALLBACK"
    if not next(self.pending) and not next(self.byUnit) then self.status=self.lastRefusal end
    return false
end
function N:Report()
    local active,pending,nativeAuras=0,0,0
    for _,v in ipairs(self.pool) do
        if v.unit and self.byUnit[v.unit]==v then active=active+1;if not v.leasedAuras then nativeAuras=nativeAuras+1 end end
        if self.pending[v] then pending=pending+1 end
    end
    return "scope=LOCAL_LEASE_READBACK_NOT_NATIVE_PAINT;active="..active..";pending="..pending
        ..";nativeAuras="..nativeAuras..";attempts="..self.attempts..";lastRefusal="..self.lastRefusal
end
local function field(object,key)
    if not S:Frame(object,false) then return nil end
    local ok,v=pcall(function() return object[key] end)
    if ok and S:Readable(v) then return v end
end
local function publicVisual(object)
    if not S:Frame(object,true) or type(object.GetAlpha)~="function" or type(object.SetAlpha)~="function" then return false end
    -- Inspect only public security/input topology, never aura payloads, displayed
    -- counts or private occurrence. Unreadable/protected descendants deny the lease.
    return S:ChildTreePublic(object)
end
-- Witness the original public parent chain up to this plate. A pooled visual
-- or mouse-enabled descendant can move with its immediate parent intact.
local function parentPath(node,plate)
    local path={}
    for _=1,32 do
        if node==plate then return path end
        local parent,state=S:Public(node.GetParent,nil,node)
        if state~="KNOWN" or not S:Frame(parent,false) then return nil end
        path[#path+1]=parent
        node=parent
    end
end
local function ownerState(lease)
    local node=lease.object
    if not S:Frame(node,true) then return "UNKNOWN" end
    for _,expected in ipairs(lease.path) do
        local parent,state=S:Public(node.GetParent,nil,node)
        if state~="KNOWN" then return "UNKNOWN" end
        if parent~=expected then return "MOVED" end
        node=parent
    end
    return "CURRENT"
end
local function inputLease(root,plate)
    local rows,seen,count={},{},0
    local function visit(node,depth)
        if not S:Frame(node,true) then return false end
        count=count+1
        if depth>12 or seen[node] or count>256 then return false end
        seen[node]=true
        if type(node.IsMouseEnabled)=="function" and type(node.EnableMouse)=="function" then
            local enabled,state=S:Public(node.IsMouseEnabled,"boolean",node)
            if state~="KNOWN" then return false end
            if enabled then
                local path=parentPath(node,plate)
                if not path then return false end
                rows[#rows+1]={object=node,original=true,path=path}
            end
        end
        if type(node.GetChildren)=="function" then
            local ok,children=pcall(function() return {node:GetChildren()} end)
            if not ok or #children>128 then return false end
            for _,child in ipairs(children) do if not visit(child,depth+1) then return false end end
        end
        return true
    end
    return visit(root,0) and rows or nil
end
local function components(plate,auras)
    local uf=field(plate,"UnitFrame")
    if not S:Frame(uf,true) then return nil end
    local health=field(uf,"HealthBarsContainer") or field(uf,"healthBar")
    local name=field(uf,"name")
    if not health or not name then return nil end
    local rows={health,name}
    local nativeAuras=field(uf,"AurasFrame")
    if auras then
        if not nativeAuras then return nil end
        for _,key in ipairs({"DebuffListFrame","BuffListFrame"}) do
            local f=field(nativeAuras,key);if not f then return nil end;rows[#rows+1]=f
        end
    end
    -- Raid target, classification, special widgets and native crowd-control cues
    -- are not leased or hidden. Their native input/access remains intact.
    return rows,uf
end
local retries=setmetatable({},{__mode="k"})
local function retryObservation(unit,plate,profile)
    if not permitted(profile) or not S:Frame(plate,true) then return nil end
    local actual,state=S:Public(C_NamePlate and C_NamePlate.GetNamePlateForUnit,nil,unit)
    if state~="KNOWN" or actual~=plate then return nil end
    local objects,native=components(plate,false);if not objects then return nil end
    local rows={}
    for _,object in ipairs(objects) do
        if not publicVisual(object) then return nil end
        local alpha,known=S:Public(object.GetAlpha,"number",object)
        local path=parentPath(object,plate);local inputs=inputLease(object,plate)
        if known~="KNOWN" or not path or not inputs then return nil end
        rows[#rows+1]={object=object,alpha=alpha,path=path,inputs=inputs,get=object.GetAlpha,set=object.SetAlpha}
    end
    if not permitted(profile) or field(plate,"UnitFrame")~=native then return nil end
    return {unit=unit,plate=plate,profile=profile,native=native,rows=rows}
end
local function samePath(a,b)
    if #a~=#b then return false end
    for i,node in ipairs(a) do if node~=b[i] then return false end end
    return true
end
function N:CanRetryMetadata(token,unit,plate,profile)
    local old=retries[token]
    if not old or old.unit~=unit or old.plate~=plate or old.profile~=profile then return false end
    local now=retryObservation(unit,plate,profile)
    if not now or now.native~=old.native or #now.rows~=#old.rows then return false end
    for i,row in ipairs(now.rows) do
        local prior=old.rows[i]
        if row.object~=prior.object or row.alpha~=prior.alpha or row.get~=prior.get or row.set~=prior.set or not samePath(row.path,prior.path) or #row.inputs~=#prior.inputs then return false end
        for j,input in ipairs(row.inputs) do
            if input.object~=prior.inputs[j].object or not samePath(input.path,prior.inputs[j].path) then return false end
        end
    end
    return permitted(profile)
end
function N:Prepare()
    if S:InCombat() or not permitted(M.profile) then return false end
    local c=M:ModuleConfig("Nameplates")
    if not c.cards then return false end
    M.ManagedAuraRails:Load()
    local count=math.min(self.limit,c.cardLimit)
    while #self.pool<count do
        local v=V:Create();v.index=#self.pool+1;V:Layout(v,c)
        self.pool[#self.pool+1]=v
    end
    for _,v in ipairs(self.pool) do if not v.unit then V:Layout(v,c) end end
    self.status="MIRAGE_CARD_POOL_PREPARED_NOT_VALIDATED";return true
end
local function allLeases(v)
    local rows={}
    for _,lease in ipairs(v.leases or {}) do rows[#rows+1]=lease end
    if v.castLease then rows[#rows+1]=v.castLease end
    return rows
end
local function clearAuras(v)
    local complete=true
    for _,rail in ipairs({v.harmful or false,v.helpful or false}) do
        if rail then
            local ok,cleared=pcall(M.ManagedAuraRails.Clear,M.ManagedAuraRails,rail)
            if not ok or not cleared then complete=false end
        end
    end
    v.auraCleanupPending=not complete or nil
    return complete
end
function N:Restore(v)
    local all=true
    for _,lease in ipairs(allLeases(v)) do
        if not lease.done then
            if not lease.alphaAttempted then
                -- Preflight-only regions were never ours to restore.
                lease.done=true
            else
                local owner=ownerState(lease)
                if owner=="MOVED" then lease.done=true
                elseif owner~="CURRENT" or not publicVisual(lease.object) then all=false
                else
                    local current,status=S:Public(lease.object.GetAlpha,"number",lease.object)
                    if status~="KNOWN" then all=false
                    elseif current~=0 then lease.done=true -- a newer owner's write wins
                    elseif ownerState(lease)~="CURRENT" then all=false
                    else
                        local ok=pcall(lease.object.SetAlpha,lease.object,lease.original)
                        local after,known=S:Public(lease.object.GetAlpha,"number",lease.object)
                        if ok and known=="KNOWN" and after==lease.original then lease.done=true
                        else all=false;lease.failures=(lease.failures or 0)+1 end
                    end
                end
            end
        end
        -- Restore only input we attempted to change, and only once that region's
        -- visual is recovered. A successful pcall alone is not confirmation.
        if lease.done then for _,mouse in ipairs(lease.mouse or {}) do
            if not mouse.done and mouse.attempted then
                local owner=ownerState(mouse)
                if owner=="MOVED" then mouse.done=true
                elseif owner~="CURRENT" then all=false
                else
                    local current,known=S:Public(mouse.object.IsMouseEnabled,"boolean",mouse.object)
                    if known~="KNOWN" then all=false
                    elseif current~=false then mouse.done=true
                    elseif ownerState(mouse)~="CURRENT" then all=false
                    else
                        local ok=pcall(mouse.object.EnableMouse,mouse.object,mouse.original)
                        local after,state=S:Public(mouse.object.IsMouseEnabled,"boolean",mouse.object)
                        if ok and state=="KNOWN" and after==mouse.original then mouse.done=true else all=false end
                    end
                end
            end
        end end
    end
    return all
end
local function release(self,v)
    if v.unit and self.byUnit[v.unit]==v then self.byUnit[v.unit]=nil end
    local restored=self:Restore(v)
    local public=S:Frame(v.frame,true)
    if not restored or not public then
        v.pending=true;self.pending[v]=true;self.status="NATIVE_RESTORE_PENDING"
        -- Keep the essential replacement until its native health visual is back.
        -- A stale/lost subject is cleared instead of showing the wrong unit.
        v.metadataReady=nil;v.selectionKnown=nil;v.cueClearPending=not public
        if public then
            v.selection:SetText("")
            if v.unit and (v.removed or not self:SameSubject(v)) then V:Clear(v) end
        end
        return false
    end
    V:Clear(v)
    -- Keep a receipt for a failed passive hide or optional native rail cleanup.
    -- A successful callback dispatch alone does not retire a visible overlay.
    local auras=clearAuras(v)
    local hidden,state=S:Public(v.frame.IsShown,"boolean",v.frame)
    if not S:Frame(v.frame,true) or not auras or state~="KNOWN" or hidden then
        self.status="NATIVE_RESTORE_PENDING";return false
    end
    v.frame:ClearAllPoints();v.frame:SetParent(UIParent)
    v.leases=nil;v.castLease=nil;v.castRestorePending=nil;v.plate=nil;v.native=nil;v.leasedAuras=nil;v.removed=nil;v.cueClearPending=nil
    v.profile=nil;v.config=nil;v.attachOffset=nil;v.auraStatus=nil;v.acquireReleaseRequested=nil
    self.pending[v]=nil;v.pending=nil
    return true
end
function N:Release(v)
    if not v then return true end
    if v.prepareBusy or v.leaseBusy then
        -- A setter can request safe mode before committing its write. Handback
        -- must run after that call unwinds, including our initial passive Show.
        v.acquireReleaseRequested=true;v.pending=true;self.pending[v]=true
        self.status="NATIVE_RESTORE_PENDING";return false
    end
    if v.castBusy then v.castReleaseRequested=true;return false end
    if v.releasing then return false end
    -- Native setters can synchronously invoke a new acquisition. Reserve this
    -- slot and plate until every restore, clear and detach operation finishes.
    v.releasing=true;v.pending=true;self.pending[v]=true
    local ok,restored=pcall(release,self,v)
    v.releasing=nil
    if not ok then
        v.metadataReady=nil;v.selectionKnown=nil;v.cueClearPending=true
        self.status="NATIVE_RESTORE_PENDING"
        return false
    end
    return restored
end
function N:IsRestoring(plate)
    for _,v in ipairs(self.pool) do
        if v.plate==plate and (v.prepareBusy or v.leaseBusy or v.releasing or v.castBusy) then return true end
    end
    for v in pairs(self.pending) do if v.plate==plate then return true end end
    return false
end
local function subjectCurrent(v)
    if not v.unit or not v.plate or not S:Frame(v.plate,true) or not C_NamePlate or type(C_NamePlate.GetNamePlateForUnit)~="function" then return false end
    local now,status=S:Public(C_NamePlate.GetNamePlateForUnit,nil,v.unit)
    return status=="KNOWN" and now==v.plate and field(v.plate,"UnitFrame")==v.native
end
function N:SameSubject(v)
    -- Physical custody remains observable during safe mode/profile changes so
    -- an unconfirmed native handback never discards its essential replacement.
    if not subjectCurrent(v) then return false end
    if v.leases and #v.leases>0 then
        local objects=components(v.plate,v.leasedAuras)
        if not objects or #objects~=#v.leases then return false end
        for i,object in ipairs(objects) do
            if object~=v.leases[i].object then return false end
            local parent,known=S:Public(object.GetParent,nil,object)
            if known~="KNOWN" or parent~=v.leases[i].parent then return false end
        end
    end
    if v.castLease then
        local cast=field(v.native,"CastBarsContainer") or field(v.native,"castBar")
        if cast~=v.castLease.object or ownerState(v.castLease)~="CURRENT" then return false end
    end
    return true
end
local function attachment(v)
    if not S:Frame(v.frame,true) or not S:Frame(v.native,true) then return false end
    local parent,ps=S:Public(v.frame.GetParent,nil,v.frame)
    local count,ns=S:Public(v.frame.GetNumPoints,"number",v.frame)
    local shown,vs=S:Public(v.frame.IsShown,"boolean",v.frame)
    if ps~="KNOWN" or parent~=v.native or ns~="KNOWN" or count~=1 or vs~="KNOWN" or not shown then return false end
    local ok,point,relative,relativePoint,x,y=pcall(v.frame.GetPoint,v.frame,1)
    if not ok or not S:Text(point) or not S:Readable(relative) or not S:Text(relativePoint) or not S:Number(x) or not S:Number(y)
        or point~="CENTER" or relative~=v.plate or relativePoint~="CENTER" or x~=0 or y~=v.attachOffset then return false end
    local level,ls=S:Public(v.frame.GetFrameLevel,"number",v.frame)
    local native,fs=S:Public(v.native.GetFrameLevel,"number",v.native)
    local plate,bs=S:Public(v.plate.GetFrameLevel,"number",v.plate)
    return ls=="KNOWN" and fs=="KNOWN" and bs=="KNOWN" and level>=math.max(native,plate)+10
end
local function admittedSubject(self,v)
    local profile=v.profile
    return permitted(profile,v.config) and self:SameSubject(v) and attachment(v) and V:FitCurrent(v) and permitted(profile,v.config)
end
local function acquireLeases(self,v,objects)
    local unit,generation,profile,plate,native=v.unit,v.generation,v.profile,v.plate,v.native
    local leases={};v.leases=leases
    local function sameSlot()
        return v.unit==unit and v.generation==generation and v.profile==profile and v.plate==plate and v.native==native and v.leases==leases
    end
    local function current()
        if not sameSlot() or v.acquireReleaseRequested or v.pending then return false end
        local allowed=permitted(profile,v.config) and subjectCurrent(v) and attachment(v) and V:FitCurrent(v)
        return allowed and permitted(profile,v.config) and sameSlot() and not v.acquireReleaseRequested and not v.pending
    end
    for _,object in ipairs(objects) do
        if not publicVisual(object) or not current() then return false end
        local alpha,status=S:Public(object.GetAlpha,"number",object)
        if status~="KNOWN" or alpha<0 or alpha>1 then return false end
        local path=parentPath(object,v.plate);if not path then return false end
        local mouse=inputLease(object,v.plate);if not mouse then return false end
        if not current() then return false end
        leases[#leases+1]={object=object,original=alpha,parent=path[1],path=path,mouse=mouse,failures=0}
    end
    for _,lease in ipairs(leases) do
        local parent,known=S:Public(lease.object.GetParent,nil,lease.object)
        local alpha,state=S:Public(lease.object.GetAlpha,"number",lease.object)
        if not publicVisual(lease.object) or not self:SameSubject(v) or known~="KNOWN" or parent~=lease.parent or state~="KNOWN" or alpha~=lease.original or not current() then
            return false
        end
        for _,mouse in ipairs(lease.mouse) do
            if not S:Frame(mouse.object,true) then return false end
            local before,access=S:Public(mouse.object.IsMouseEnabled,"boolean",mouse.object)
            if access~="KNOWN" or before~=mouse.original or ownerState(mouse)~="CURRENT" or not current() then return false end
            mouse.attempted=true -- includes calls that mutate before throwing
            local ok=pcall(mouse.object.EnableMouse,mouse.object,false)
            local after,verified=S:Public(mouse.object.IsMouseEnabled,"boolean",mouse.object)
            if not ok or verified~="KNOWN" or after~=false or not current() then return false end
            mouse.written=true
        end
        if ownerState(lease)~="CURRENT" or not current() then return false end
        lease.alphaAttempted=true
        local ok=pcall(lease.object.SetAlpha,lease.object,0)
        local after,verified=S:Public(lease.object.GetAlpha,"number",lease.object)
        if not ok or verified~="KNOWN" or after~=0 or not current() then return false end
        lease.written=true
    end
    return current()
end
function N:Lease(v,objects)
    if v.leaseBusy or v.releasing then return false end
    local unit,generation=v.unit,v.generation
    v.leaseBusy=true
    local ok,leased=pcall(acquireLeases,self,v,objects)
    v.leaseBusy=nil
    if not ok or not leased or v.acquireReleaseRequested then
        if v.unit==unit and v.generation==generation then self:Release(v) end
        return false
    end
    return v.unit==unit and v.generation==generation
end
local function bound(self,v,unit,generation)
    return v.generation==generation and v.unit==unit and self.byUnit[unit]==v
end
-- Cast custody is optional and generation-scoped; it is never part of the
-- positional health/name/aura lease. Hold lifecycle reentry until setters return.
local function finishCast(self,v)
    v.castBusy=nil
    if v.castReleaseRequested then
        v.castReleaseRequested=nil
        self:Release(v)
        return false
    end
    return true
end
function N:ReturnCast(v)
    if not v.castLease then return true end
    if v.castBusy then return false end
    local lease=v.castLease
    v.castBusy=true
    local ok,restored=pcall(self.Restore,self,{leases={lease}})
    if ok and restored then
        v.castLease=nil;v.castRestorePending=nil
    else
        v.castRestorePending=true
        self.status="NATIVE_RESTORE_PENDING"
    end
    local current=finishCast(self,v)
    return current and ok and restored
end
function N:AcquireCast(v,unit,generation)
    if not bound(self,v,unit,generation) or v.castBusy or v.pending then return false end
    v.castBusy=true
    local ok,acquired=pcall(function()
        if v.castLease then
            local lease=v.castLease
            local alpha,state=S:Public(lease.object.GetAlpha,"number",lease.object)
            local same=admittedSubject(self,v)
            return same and bound(self,v,unit,generation) and not v.castReleaseRequested and v.castLease==lease and not v.castRestorePending and state=="KNOWN" and alpha==0
        end
        local object=field(v.native,"CastBarsContainer") or field(v.native,"castBar")
        if not publicVisual(object) then return false end
        local alpha,status=S:Public(object.GetAlpha,"number",object)
        local path=parentPath(object,v.plate)
        local mouse=inputLease(object,v.plate)
        if not bound(self,v,unit,generation) or v.castReleaseRequested or status~="KNOWN" or alpha<0 or alpha>1 or not path or not mouse then return false end
        local lease={object=object,original=alpha,parent=path[1],path=path,mouse=mouse,failures=0}
        v.castLease=lease
        local function current()
            local same=admittedSubject(self,v)
            local owner=ownerState(lease)
            return same and owner=="CURRENT" and bound(self,v,unit,generation) and not v.castReleaseRequested and v.castLease==lease
        end
        local before,state=S:Public(object.GetAlpha,"number",object)
        if not publicVisual(object) or state~="KNOWN" or before~=alpha or not current() then return false end
        for _,row in ipairs(mouse) do
            local enabled,known=S:Public(row.object.IsMouseEnabled,"boolean",row.object)
            if not S:Frame(row.object,true) or ownerState(row)~="CURRENT" or known~="KNOWN" or enabled~=row.original or not current() then return false end
            row.attempted=true
            local wrote=pcall(row.object.EnableMouse,row.object,false)
            local after,access=S:Public(row.object.IsMouseEnabled,"boolean",row.object)
            if not wrote or access~="KNOWN" or after~=false or not current() then return false end
            row.written=true
        end
        if not current() then return false end
        lease.alphaAttempted=true
        local wrote=pcall(object.SetAlpha,object,0)
        local after,access=S:Public(object.GetAlpha,"number",object)
        if not wrote or access~="KNOWN" or after~=0 or not current() then return false end
        lease.written=true
        return true
    end)
    if not finishCast(self,v) or not bound(self,v,unit,generation) then return false end
    if not ok or not acquired then self:ReturnCast(v);return false end
    return true
end
function N:UpdateCast(v,kind)
    local unit,generation=v.unit,v.generation
    if not bound(self,v,unit,generation) or v.castBusy or not admittedSubject(self,v) or not bound(self,v,unit,generation) then return false end
    v.castBusy=true
    local ok,ready=pcall(V.Cast,V,v,kind)
    if not finishCast(self,v) or not bound(self,v,unit,generation) then return false end
    ready=ok and ready

    if ready and self:AcquireCast(v,unit,generation) then return true end
    if bound(self,v,unit,generation) then V:ClearCast(v) end
    if bound(self,v,unit,generation) and v.castRestorePending then self:Release(v) end
    return false
end
local function metadataFallback(self,v,unit,generation)
    if not bound(self,v,unit,generation) then return end
    local reason=v.selectionKnown and v.nameFitStatus or "SELECTION_UNAVAILABLE"
    -- Release owns restoration. A failed handback must not be labeled restored.
    local restored=self:Release(v)
    self.status=(not restored or next(self.pending)) and "NATIVE_RESTORE_PENDING" or reason
    self:Refuse(reason)
end
local function prepareCard(self,v,c,objects)
    local unit,generation,profile,plate,native=v.unit,v.generation,v.profile,v.plate,v.native
    local contentReady=false
    local function current()
        if v.generation~=generation or v.unit~=unit or v.acquireReleaseRequested or v.pending then return false end
        local allowed=permitted(profile,c) and subjectCurrent(v) and S:Frame(v.frame,true) and (not contentReady or V:FitCurrent(v))
        return allowed and permitted(profile,c) and v.generation==generation and v.unit==unit and v.profile==profile
            and v.plate==plate and v.native==native and not v.acquireReleaseRequested and not v.pending
    end
    if not current() then return false,"UNQUALIFIED_CLIENT_OR_OWNER" end
    -- Complete essential content and public fit while our card is still
    -- detached. Anchoring to a native plate may make derived metrics secret.
    if not V:Health(v) then return false,"HEALTH_DISPLAY_UNAVAILABLE" end
    if not current() then return false end
    V:Power(v,true)
    if not current() then return false end
    if not V:Metadata(v,true) then return false,v.selectionKnown and v.nameFitStatus or "SELECTION_UNAVAILABLE" end
    contentReady=true
    if not current() then return false end
    v.frame:SetParent(native)
    if not current() then return false end
    v.frame:ClearAllPoints()
    if not current() then return false end
    v.frame:SetPoint("CENTER",plate,"CENTER",0,v.attachOffset)
    if not current() then return false end
    local plateLevel,ps=S:Public(plate.GetFrameLevel,"number",plate)
    local nativeLevel,ns=S:Public(native.GetFrameLevel,"number",native)
    if ps~="KNOWN" or ns~="KNOWN" or not current() then return false,"ATTACHMENT_UNCONFIRMED" end
    v.frame:SetFrameLevel(math.max(plateLevel,nativeLevel)+10)
    if not current() then return false end
    -- Native aura replacement is optional. Its inability to load, construct,
    -- or dispatch must not suppress the native aura lists or the essential card.
    v.leasedAuras=false;v.auraStatus="NATIVE_AURAS_RETAINED"
    if c.cardAuras then
        local made,ready=pcall(V.EnsureAuras,V,v,c)
        if not current() then return false end
        local auraObjects=made and ready and components(plate,true)
        if auraObjects then
            for _,object in ipairs(auraObjects) do if not publicVisual(object) then auraObjects=nil;break end end
        end
        if not current() then return false end
        local harmful,helpful=false,false
        if auraObjects then
            harmful=M.ManagedAuraRails:Assign(v.harmful,unit,true)
            if not current() then return false end
            if harmful then helpful=M.ManagedAuraRails:Assign(v.helpful,unit,true) end
            if not current() then return false end
        end
        if harmful and helpful then
            objects=auraObjects;v.leasedAuras=true;v.auraStatus="NATIVE_AURAS_SUBMITTED"
        elseif not clearAuras(v) then return false,"MIRAGE_CARD_NATIVE_FALLBACK" end
    end
    if not current() then return false end
    -- Observe our complete, visible passive replacement before taking native
    -- alpha/input custody. The reservation includes callbacks before Show commits.
    v.frame:Show()
    if not current() or not attachment(v) or not current() then return false,"ATTACHMENT_UNCONFIRMED" end
    if not self:Lease(v,objects) then return false,"NATIVE_LEASE_UNCONFIRMED" end
    return current() and attachment(v) and current(),"NATIVE_LEASE_UNCONFIRMED"
end
function N:Assign(unit,plate)
    self.metadataRetry=nil
    self.attempts=math.min(1000000000,self.attempts+1)
    local profile,c=M.profile,M:ModuleConfig("Nameplates")
    if not c or not c.cards then return self:Refuse("DISABLED") end
    if not permitted(profile,c) then return self:Refuse("UNQUALIFIED_CLIENT_OR_OWNER") end
    if not S:Text(unit) or not unit:match("^nameplate%d+$") then return self:Refuse("INVALID_UNIT") end
    local allowed,reason=S:Frame(plate,true)
    if not allowed then return self:Refuse(reason) end
    if not permitted(profile,c) then return self:Refuse("UNQUALIFIED_CLIENT_OR_OWNER") end
    if self.byUnit[unit] then
        local old=self.byUnit[unit]
        if old.prepareBusy or old.leaseBusy or old.castBusy then return self:Refuse("NATIVE_ATTACH_IN_PROGRESS") end
        local generation=old.generation
        local current=old.plate==plate and admittedSubject(self,old)
        if not bound(self,old,unit,generation) then return false end
        if current and not (c.cardAuras and not old.leasedAuras and (old.auraSetupFailures or 0)<3 and M.ManagedAuraRails:Available()) then
            -- Active metadata refresh retains its established generation-aware
            -- reentry behavior; the preparation reservation is for new slots.
            V:Refresh(old,true)
            if not bound(self,old,unit,generation) then return false end
            if old.metadataReady and admittedSubject(self,old) and bound(self,old,unit,generation) then return true end
            metadataFallback(self,old,unit,generation);return false
        end
        if not self:Release(old) then return false end
    end
    for _,row in ipairs(self.pool) do
        if row.plate==plate then
            if row.prepareBusy or row.leaseBusy or row.castBusy or row.releasing then return self:Refuse("NATIVE_ATTACH_IN_PROGRESS") end
            if not self:Release(row) then return false end
        end
    end
    local objects,uf=components(plate,false)
    if not objects then return self:Refuse("NATIVE_TREE_FALLBACK") end
    if not permitted(profile,c) then return self:Refuse("UNQUALIFIED_CLIENT_OR_OWNER") end
    local v
    for i,row in ipairs(self.pool) do
        if i<=c.cardLimit and not row.unit and not row.pending and not row.prepareBusy and not row.leaseBusy and not row.releasing then v=row;break end
    end
    if not v then return self:Refuse("DENSITY_LIMIT_NATIVE_FALLBACK") end
    v.unit=unit;v.plate=plate;v.native=uf;v.profile=profile;v.config=c;v.attachOffset=c.cardOffsetY
    v.leasedAuras=false;v.generation=v.generation+1;v.faults=0;v.restoreAttempts=0;v.retryAt=nil;v.empower=false;v.acquireReleaseRequested=nil
    local generation=v.generation
    v.prepareBusy=true
    local ok,prepared,refusal=pcall(prepareCard,self,v,c,objects)
    v.prepareBusy=nil
    if v.generation~=generation or v.unit~=unit then return false end
    if not ok or not prepared or v.acquireReleaseRequested or not permitted(profile,c) then
        local restored=self:Release(v)
        self:Refuse(ok and refusal or "MIRAGE_CARD_NATIVE_FALLBACK")
        self.status=(not restored or next(self.pending)) and "NATIVE_RESTORE_PENDING" or self.lastRefusal
        -- Only a fully retired initial attempt with unavailable public text
        -- earns a bounded retry. No lease-loss or active-owner failure does.
        if restored and self.lastRefusal=="NAME_UNAVAILABLE" then
            local witness=retryObservation(unit,plate,profile)
            if witness then local token={};retries[token]=witness;self.metadataRetry=token end
        end
        return false
    end
    self.byUnit[unit]=v
    -- Recover already-active cast without reading any timing field. A channel is
    -- tried only through its own provider, never via a cast fallback.
    if not self:UpdateCast(v,"cast") and bound(self,v,unit,generation) then self:UpdateCast(v,"channel") end
    if not bound(self,v,unit,generation) then return false end
    self.lastRefusal="NONE";self.status="MIRAGE_CARDS_ACTIVE_NATIVE_NOT_RUN";return true
end
function N:Event(event,unit)
    -- A newly prepared slot is intentionally unpublished until native custody
    -- succeeds. Lifecycle callbacks must still revoke that in-flight attempt.
    local acquiring=false
    for _,row in ipairs(self.pool) do
        if (row.prepareBusy or row.leaseBusy) and ((S:Text(unit) and row.unit==unit) or event=="PLAYER_TARGET_CHANGED") then
            if event=="NAME_PLATE_UNIT_REMOVED" then row.removed=true end
            self:Release(row);acquiring=true
        end
    end
    if acquiring then return end
    local busy=S:Text(unit) and self.byUnit[unit]
    if busy and busy.castBusy then
        -- A reentrant event invalidates the in-flight rendering/lease decision.
        -- Do not silently discard STOP/EMPOWER or subject lifecycle changes.
        busy.castReleaseRequested=true
        if event=="NAME_PLATE_UNIT_REMOVED" then busy.removed=true end
        return
    end
    if event=="NAME_PLATE_UNIT_REMOVED" then
        local v=S:Text(unit) and self.byUnit[unit];if v then self:Release(v) end
        if S:Text(unit) then
            for row in pairs(self.pending) do
                if row.unit==unit then
                    row.removed=true
                    if not row.releasing and not row.prepareBusy and not row.leaseBusy and S:Frame(row.frame,true) then V:Clear(row) end
                end
            end
        end
        return
    end
    if event=="PLAYER_TARGET_CHANGED" then
        for _,v in ipairs(self.pool) do
            local token,generation=v.unit,v.generation
            if token and self.byUnit[token]==v and v.castBusy then
                v.castReleaseRequested=true
            elseif token and self.byUnit[token]==v then
                local current=admittedSubject(self,v)
                if bound(self,v,token,generation) then
                    if not current then self:Release(v)
                    elseif not V:Metadata(v) then metadataFallback(self,v,token,generation) end
                end
            end
        end
        return
    end
    local v=S:Text(unit) and self.byUnit[unit]
    if not v or v.castBusy then return end
    local generation=v.generation
    local current=admittedSubject(self,v)
    if not bound(self,v,unit,generation) then return end
    if not current then self:Release(v);return end
    local ok=pcall(function()
        if event=="UNIT_HEALTH" or event=="UNIT_MAXHEALTH" then if not V:Health(v) then error("HEALTH_CONSUMER_FAILED") end
        elseif event=="UNIT_POWER_UPDATE" then V:Power(v,false)
        elseif event=="UNIT_DISPLAYPOWER" or event=="UNIT_MAXPOWER" then V:Power(v,true)
        elseif event=="UNIT_NAME_UPDATE" or event=="UNIT_LEVEL" then if not V:Metadata(v) then metadataFallback(self,v,unit,generation) end
        elseif event=="UNIT_SPELLCAST_EMPOWER_START" then v.empower=true;V:ClearCast(v)
        elseif event=="UNIT_SPELLCAST_EMPOWER_STOP" then v.empower=false;V:ClearCast(v)
        elseif event=="UNIT_SPELLCAST_START" then v.empower=false;self:UpdateCast(v,"cast")
        elseif event=="UNIT_SPELLCAST_DELAYED" then self:UpdateCast(v,"cast")
        elseif event=="UNIT_SPELLCAST_CHANNEL_START" or event=="UNIT_SPELLCAST_CHANNEL_UPDATE" then self:UpdateCast(v,"channel")
        elseif event:find("SPELLCAST",1,true) then
            local other=(event=="UNIT_SPELLCAST_STOP" and v.castKind=="channel") or (event=="UNIT_SPELLCAST_CHANNEL_STOP" and v.castKind=="cast")
            if not other then V:ClearCast(v) end
        end
    end)
    if bound(self,v,unit,generation) and v.castRestorePending then self:Release(v);return end
    if not ok and bound(self,v,unit,generation) then
        v.faults=v.faults+1;self:Release(v)
        self.status=next(self.pending) and "NATIVE_RESTORE_PENDING" or "MIRAGE_CARD_FAULT_NATIVE_FALLBACK"
    end
end
function N:Maintain(now)
    if not next(self.pending) then return end
    -- Pending restoration is exceptional recovery work, not ordinary polling.
    for v in pairs(self.pending) do
        if not v.releasing and not v.prepareBusy and not v.leaseBusy and not S:InCombat() and (v.restoreAttempts or 0)<3 and now>=(v.retryAt or 0) then
            v.restoreAttempts=(v.restoreAttempts or 0)+1;v.retryAt=now+1
            self:Release(v)
        end
        if v.pending and not v.releasing and not v.prepareBusy and not v.leaseBusy and v.unit and S:Frame(v.frame,true) then
            if v.removed or not self:SameSubject(v) then V:Clear(v)
            elseif M.state.world then
                if v.cueClearPending then v.selection:SetText("");v.cueClearPending=nil end
                local ok=pcall(V.Refresh,V,v,false)
                if not ok then v.health:SetStatusBarColor(0,0,0,0);v.power:SetStatusBarColor(0,0,0,0) end
            end
        end
        if v.pending and (v.restoreAttempts or 0)>=3 then self.status="NATIVE_RESTORE_RELOAD_REQUIRED" end
    end
end
function N:Tick()
    -- Lifecycle recheck uses public frame identity and our own lease, not unit data.
    -- A native getter can reenter lifecycle dispatch. Iterate stable pool slots
    -- and only retire the generation whose ownership we actually sampled.
    for _,v in ipairs(self.pool) do
        local unit,generation=v.unit,v.generation
        if unit and self.byUnit[unit]==v and not v.castBusy and not v.prepareBusy and not v.leaseBusy then
            local current=admittedSubject(self,v)
            if current and v.leasedAuras then current=M.ManagedAuraRails:Ready(v.harmful) and M.ManagedAuraRails:Ready(v.helpful) end
            if current then for _,lease in ipairs(allLeases(v)) do
                local alpha,status=S:Public(lease.object.GetAlpha,"number",lease.object)
                if status~="KNOWN" or alpha~=0 then current=false;break end
            end end
            if not current and bound(self,v,unit,generation) then self:Release(v) end
        end
    end
end
function N:Suspend()
    for _,v in ipairs(self.pool) do if v.unit or v.leases then self:Release(v) end end
    self.status=next(self.pending) and "NATIVE_RESTORE_PENDING" or "DISABLED"
end
