local _, M = ...
-- Default-anchor placement only. Never change native owner, anchor type, contents,
-- clamp settings or combat visibility. A failed mutator may still have taken effect.
local T=M.modules.Tooltips
local priorApply,priorSuspend,priorResume=T.ApplyConfig,T.Suspend,T.Resume
-- A receipt belongs to one token and one tooltip. Callback-capable observations
-- are not atomic, but a suspended operation must not adopt a successor receipt.
local function sameReceipt(self,token,tooltip)
 return rawequal(rawget(self,"anchorToken"),token) and rawequal(rawget(self,"anchoredTooltip"),tooltip)
end
local function currentReceipt(self,token,tooltip)
 return token~=nil and tooltip~=nil and sameReceipt(self,token,tooltip)
end
local function forget(self,token,tooltip)
 if not sameReceipt(self,token,tooltip) then return false end
 self.savedPoints=nil;self.anchoredTooltip=nil;self.anchorExpected=nil;self.anchorMode=nil;self.anchorRestorePending=nil;self.anchorToken=nil;self.anchorRestoreRequested=nil;self.anchorOwner=nil;self.anchorCorner=nil
 return true
end
local function resolve(frame,method)
 local ok,fn=pcall(function() return frame[method] end)
 if ok and type(fn)=="function" then return fn end
end
local function points(frame)
 if not frame.GetNumPoints or not frame.GetPoint then return nil end
 local count=M.Safety:Public(frame.GetNumPoints,"number",frame)
 if not count or count<0 or count>6 or count%1~=0 then return nil end
 local out={}
 for i=1,count do
  local ok,a,b,c,x,y=pcall(frame.GetPoint,frame,i)
  if not ok or not M.Safety:Text(a) or not M.Safety:Text(c) or not M.Safety:Number(x) or not M.Safety:Number(y) or not M.Safety:Readable(b) then return nil end
  out[#out+1]={a,b,c,x,y}
 end
 return out
end
local function same(a,b)
 if not a or not b or #a~=#b then return false end
 for i,p in ipairs(a) do for j=1,5 do if not rawequal(p[j],b[i][j]) then return false end end end
 return true
end
local function legal(tooltip)
 return not M.Safety:InCombat() and M.Safety:Frame(tooltip,true) and M.Safety:ChildTreePublic(tooltip)
end
local function identity(tooltip,expectedOwner)
 local owner,ownerState=M.Safety:Public(tooltip.GetOwner,nil,tooltip)
 local kind,kindState=M.Safety:Public(tooltip.GetAnchorType,"string",tooltip)
 if ownerState~="KNOWN" or kindState~="KNOWN" then return nil end
 return rawequal(owner,expectedOwner or UIParent) and kind=="ANCHOR_NONE"
end
local function comparisonsClear()
 for _,name in ipairs({"ShoppingTooltip1","ShoppingTooltip2"}) do
  local frame=_G[name]
  if not M.Safety:Readable(frame) then return false end
  if frame and (not M.Safety:Frame(frame,true) or M.Safety:Public(frame.IsShown,"boolean",frame)~=false) then return false end
 end
 return true
end
function T:ForgetAnchor()
 return forget(self,self.anchorToken,self.anchoredTooltip)
end
function T:OwnsAnchor(token,tooltip)
 token=token or self.anchorToken;tooltip=tooltip or self.anchoredTooltip
 if not currentReceipt(self,token,tooltip) then return nil end
 local expectedPoints=self.anchorExpected
 if not tooltip or not M.Safety:Frame(tooltip,true) then return nil end
 if not currentReceipt(self,token,tooltip) then return nil end
 local owner=identity(tooltip,rawget(self,"anchorOwner"));if owner~=true then return owner end
 if not currentReceipt(self,token,tooltip) then return nil end
 local current=points(tooltip);if not current then return nil end
 if not currentReceipt(self,token,tooltip) then return nil end
 for _,expected in ipairs(expectedPoints or {}) do if same(current,expected) then return true,current end end
 return false
end
function T:AnchorWritable(token,tooltip)
 tooltip=tooltip or self.anchoredTooltip
 if not currentReceipt(self,token,tooltip) then return false end
 local owned,current=self:OwnsAnchor(token,tooltip)
 if not currentReceipt(self,token,tooltip) then return false end
 if owned==false then forget(self,token,tooltip);return false end
 if owned==nil then self.anchorRestorePending=true;return false end
 local allowed=legal(tooltip)
 if not currentReceipt(self,token,tooltip) then return false end
 if not allowed then self.anchorRestorePending=true;return false end
 return true,current
end
function T:WriteAnchor(token,method,args,after,tooltip)
 tooltip=tooltip or self.anchoredTooltip
 if not currentReceipt(self,token,tooltip) then return false end
 local fn=resolve(tooltip,method)
 if not currentReceipt(self,token,tooltip) then return false end
 if not fn then self.anchorRestorePending=true;return false end
 local values={unpack(args)}
 local ready,before=self:AnchorWritable(token,tooltip)
 if not ready or not currentReceipt(self,token,tooltip) then return false end
 -- An exception does not prove no mutation. Both attempted states remain a
 -- receipt until a public read distinguishes them; another value/owner wins.
 self.anchorExpected={before,after};self.anchorRestorePending=true
 local ok=pcall(fn,tooltip,unpack(values))
 if not currentReceipt(self,token,tooltip) then return false end
 local currentReady,current=self:AnchorWritable(token,tooltip)
 if not currentReady or not currentReceipt(self,token,tooltip) then return false end
 self.anchorExpected={current}
 return ok and same(current,after)
end
local function restore(self,token,tooltip)
 if not currentReceipt(self,token,tooltip) then return end
 local ready=self:AnchorWritable(token,tooltip)
 if not ready or not currentReceipt(self,token,tooltip) then return end
 local original=self.savedPoints
 if not self:WriteAnchor(token,"ClearAllPoints",{}, {},tooltip) or not currentReceipt(self,token,tooltip) then return end
 local restored={}
 for _,p in ipairs(original) do
  restored[#restored+1]=p
  local expected={};for i,v in ipairs(restored) do expected[i]=v end
  if not self:WriteAnchor(token,"SetPoint",p,expected,tooltip) or not currentReceipt(self,token,tooltip) then return end
 end
 if self:AnchorWritable(token,tooltip) then forget(self,token,tooltip) end
end
function T:RestoreAnchor()
 self.pendingDefaultAnchor=nil
 local token,tooltip=self.anchorToken,self.anchoredTooltip
 if not currentReceipt(self,token,tooltip) then return end
 if self.anchorBusy then self.anchorRestorePending=true;self.anchorRestoreRequested=true;return end
 local busy={};self.anchorBusy=busy
 local ok=pcall(restore,self,token,tooltip)
 if rawequal(self.anchorBusy,busy) then self.anchorBusy=nil end
 if not ok then
  if currentReceipt(self,token,tooltip) then self.anchorRestorePending=true end
  M:Fault(self.id,"ANCHOR_RESTORE_FAILED")
 end
end
function T:CursorPosition()
 if type(GetCursorPosition)~="function" or not M.Safety:Frame(UIParent,true) then return end
 local scale=M.Safety:Public(UIParent.GetEffectiveScale,"number",UIParent)
 local width=M.Safety:Public(UIParent.GetWidth,"number",UIParent)
 local height=M.Safety:Public(UIParent.GetHeight,"number",UIParent)
 if not scale or scale<.1 or scale>10 or not width or width<=0 or width>100000 or not height or height<=0 or height>100000 then return end
 local ok,x,y=pcall(GetCursorPosition)
 if not ok or not M.Safety:Number(x) or not M.Safety:Number(y) then return end
 local offset=M:ModuleConfig(self.id).cursorOffset
 if not M.Safety:Number(offset) or offset<0 or offset>200 then return end
 return math.max(0,math.min(width,x/scale+offset)),math.max(0,math.min(height,y/scale))
end
function T:CursorWritable(token,tip)
 tip=tip or self.anchoredTooltip
 if not currentReceipt(self,token,tip) then return false end
 if not tip or not M:IsModuleActive(self.id) or not M:ModuleConfig(self.id).cursorAnchor or M.Native:Conflict() then return false end
 if M.Safety:Public(tip.IsClampedToScreen,"boolean",tip)~=true or not comparisonsClear() then return false end
 if not currentReceipt(self,token,tip) then return false end
 local ready,current=self:AnchorWritable(token,tip)
 if not currentReceipt(self,token,tip) then return false end
 return ready,current
end
function T:MoveCursorAnchor(token,tip,anchor)
 tip=tip or self.anchoredTooltip;anchor=anchor or self.cursorAnchor
 local function current()
  return currentReceipt(self,token,tip) and anchor~=nil and rawequal(rawget(self,"cursorAnchor"),anchor)
 end
 if not current() then return false end
 local x,y=self:CursorPosition();if not x or not current() then return false end
 local function writable()
  return current() and self:CursorWritable(token,tip) and legal(anchor) and current()
 end
 local function write(method,args)
  local fn=resolve(anchor,method)
  if not fn or not current() then return false end
  local values={unpack(args)}
  if not writable() then return false end
  local ok=pcall(fn,anchor,unpack(values))
  return ok and current()
 end
 if not writable() then return false end
 local expected={{"BOTTOMLEFT",UIParent,"BOTTOMLEFT",x,y}}
 -- Re-read actual point, so an interrupted/throwing write cannot leave a stale
 -- position cache that suppresses the next legal repair.
 local observed=points(anchor)
 if not current() then return false end
 if not same(observed,expected) then
  if not write("ClearAllPoints",{}) or not writable() then return false end
  observed=points(anchor)
  if not current() or not same(observed,{}) then return false end
  if not write("SetPoint",expected[1]) or not writable() then return false end
  observed=points(anchor)
  if not current() or not same(observed,expected) then return false end
 end
 return current()
end
-- The reporting panel and world tooltip are independent surfaces. Read only
-- their public rectangles; never infer a tooltip owner from its text or unit.
function T:SmartPosition(tooltip)
 local cfg=M:ModuleConfig(self.id)
 if cfg.avoidMeters==false or cfg.fixedAnchor or cfg.cursorAnchor then return end
 local meters=M.Rework and M.Rework.CombatMeters
 if not meters or type(meters.GetMeterBounds)~="function" or not comparisonsClear() then return end
 local okay,bounds=pcall(meters.GetMeterBounds,meters)
 if not okay or not bounds or bounds.visible~=true then return end
 local width=M.Safety:Public(UIParent.GetWidth,"number",UIParent)
 local height=M.Safety:Public(UIParent.GetHeight,"number",UIParent)
 local tipWidth=M.Safety:Public(tooltip.GetWidth,"number",tooltip)
 local tipHeight=M.Safety:Public(tooltip.GetHeight,"number",tooltip)
 local tipScale=M.Safety:Public(tooltip.GetEffectiveScale,"number",tooltip)
 local uiScale=M.Safety:Public(UIParent.GetEffectiveScale,"number",UIParent)
 if not width or not height or not tipWidth or not tipHeight or not tipScale or not uiScale
  or width<=0 or height<=0 or tipScale<=0 or uiScale<=0 then return end
 if tipWidth<=0 or tipHeight<=0 then return nil,"TIP_SIZE_PENDING" end
 tipWidth,tipHeight=tipWidth*tipScale/uiScale,tipHeight*tipScale/uiScale
 local left,right,bottom,top=bounds.left,bounds.right,bounds.bottom,bounds.top
 if not M.Safety:Number(left) or not M.Safety:Number(right) or not M.Safety:Number(bottom) or not M.Safety:Number(top)
  or right<=left or top<=bottom then return end
 local gap=12
 -- Prefer above the panel. A tall report uses the space to its left. The
 -- native tooltip's own clamp remains authoritative for unusually long tips.
 if top+gap+tipHeight<=height-gap then
  return math.max(tipWidth+gap,math.min(width-gap,right)),top+gap
 elseif left-gap-tipWidth>=gap then
  return left-gap,math.max(gap,math.min(height-tipHeight-gap,bottom))
 end
 return nil
end
function T:MoveSmartAnchor(token,tooltip,anchor)
 local function current()
  return currentReceipt(self,token,tooltip) and self.anchorMode=="SMART" and rawequal(self.smartAnchor,anchor)
   and M:IsModuleActive(self.id) and not M.Native:Conflict()
 end
 if not current() then return false end
 local x,y=self:SmartPosition(tooltip)
 if not x or not current() or not legal(anchor) or not self:AnchorWritable(token,tooltip) or not current() then return false end
 local expected={{"BOTTOMRIGHT",UIParent,"BOTTOMLEFT",x,y}}
 if same(points(anchor),expected) then return current() end
 for _,step in ipairs({{"ClearAllPoints",{}},{"SetPoint",expected[1]}}) do
  local fn=resolve(anchor,step[1])
  if not fn or not current() or not legal(anchor) or not self:AnchorWritable(token,tooltip) then return false end
  local ok,result=pcall(fn,anchor,unpack(step[2]))
  if not ok or result==false or not current() then return false end
 end
 return same(points(anchor),expected) and current()
end
-- The pinned client calls its default-anchor helper with the hovered action
-- button as owner. Accept that route only while the tooltip still points at
-- the native default container. A control-specific or foreign point is not
-- permission to take over its placement. The owner itself is never mutated.
local corners={BOTTOMLEFT=true,BOTTOMRIGHT=true,TOPLEFT=true,TOPRIGHT=true}
local function nativeDefaultPlacement(self,tooltip,parent)
 if parent~=UIParent and not M.Safety:Frame(parent,false) then return false end
 local original=points(tooltip);if not original or #original==0 then return false end
 local nativePoint
 for _,p in ipairs(original) do
  for _,name in ipairs({"GameTooltipDefaultContainer","SharedTooltipDefaultContainer"}) do
   local container=_G[name]
   if M.Safety:Readable(container) and container and M.Safety:Frame(container,false)
    and rawequal(p[2],container) and corners[p[1]] and p[3]==p[1] and p[4]==0 and p[5]==0 then nativePoint=p end
  end
 end
 local saved={}
 for _,p in ipairs(original) do
  local residue=false
  -- The pinned native helper adds/replaces its named corner without clearing
  -- other points. If its corner changes, retire only our exact former point;
  -- never save that point as part of the native restore state.
  if nativePoint and self.anchoredTooltip==tooltip and (p[2]==self.anchor or p[2]==self.cursorAnchor or p[2]==self.smartAnchor) then
   for _,expected in ipairs(self.anchorExpected or {}) do if #expected==1 and same({p},expected) then residue=true;break end end
  end
  if not residue then saved[#saved+1]=p end
 end
 if #saved~=1 or parent~=UIParent and not nativePoint then return false end
 local corner=nativePoint and nativePoint[1] or original[1][1]
 if not corners[corner] then corner="BOTTOMLEFT" end
 return true,original,saved,corner
end
function T:AnchorPoint(token,tooltip)
 if not currentReceipt(self,token,tooltip) then return end
 local mode=self.anchorMode
 local target=mode=="CURSOR" and self.cursorAnchor or mode=="SMART" and self.smartAnchor or self.anchor
 local corner=self.anchorCorner
 if not target or not corners[corner] then return end
 local width=M.Safety:Public(tooltip.GetWidth,"number",tooltip)
 local height=M.Safety:Public(tooltip.GetHeight,"number",tooltip)
 if not width or not height or width<0 or height<0 or width>100000 or height>100000 then return end
 -- Keep the same native corner, so a later native default-anchor call replaces
 -- it even in combat. Offsets preserve the configured lower-left origin (or
 -- the smart placement's lower-right origin) as native content changes size.
 local x=corner:find("RIGHT",1,true) and width or 0
 if mode=="SMART" then x=x-width end
 local y=corner:find("TOP",1,true) and height or 0
 return {corner,target,mode=="SMART" and "BOTTOMRIGHT" or "BOTTOMLEFT",x,y}
end
function T:RefreshAnchorPoint(tooltip)
 if self.anchorBusy or tooltip~=self.anchoredTooltip or not M:IsModuleActive(self.id) or M.Native:Conflict() then return end
 local cfg=M:ModuleConfig(self.id);local mode=self.anchorMode
 if cfg.style==false or cfg.enabled==false or cfg.primaryPresentation==2
  or mode=="FIXED" and (not cfg.fixedAnchor or cfg.cursorAnchor)
  or mode=="CURSOR" and not cfg.cursorAnchor
  or mode=="SMART" and (cfg.fixedAnchor or cfg.cursorAnchor or cfg.avoidMeters==false) then return end
 local token=self.anchorToken
 local ready=self:AnchorWritable(token,tooltip)
 if not ready or not currentReceipt(self,token,tooltip) then return end
 local expected=self:AnchorPoint(token,tooltip)
 if not expected or not currentReceipt(self,token,tooltip) or same(points(tooltip),{expected}) then return end
 local busy={};self.anchorBusy=busy
 local okay,written=pcall(self.WriteAnchor,self,token,"SetPoint",expected,{expected},tooltip)
 if rawequal(self.anchorBusy,busy) then self.anchorBusy=nil end
 if currentReceipt(self,token,tooltip) then self.anchorRestorePending=not (okay and written) or nil end
end
function T:WatchAnchorSize(tooltip)
 self.anchorSizeHooks=self.anchorSizeHooks or setmetatable({},{__mode="k"})
 if self.anchorSizeHooks[tooltip] or not resolve(tooltip,"HookScript") then return end
 local okay=pcall(tooltip.HookScript,tooltip,"OnSizeChanged",function(tip)
  M:Guard(self.id,self.RefreshAnchorPoint,self,tip)
 end)
 if okay then self.anchorSizeHooks[tooltip]=true end
end
local function acquire(self,tooltip,parent,receipt)
 local function unchanged() return sameReceipt(self,receipt.token,receipt.tooltip) end
 if not M.Safety:Readable(tooltip) or not M.Safety:Readable(parent) then return end
 if tooltip~=GameTooltip or not M:IsModuleActive(self.id) then return end
 local cfg=M:ModuleConfig(self.id)
 if not cfg.fixedAnchor and not cfg.cursorAnchor and cfg.avoidMeters==false then return end
 if not legal(tooltip) or M.Native:Conflict() or identity(tooltip,parent)~=true then return end
 local permitted,original,saved,corner=nativeDefaultPlacement(self,tooltip,parent)
 if not permitted then
  if unchanged() and self:OwnsAnchor(receipt.token,receipt.tooltip)==false then forget(self,receipt.token,receipt.tooltip) end
  return
 end
 if not unchanged() then return end
 if self.anchoredTooltip then
  local owned=self:OwnsAnchor(receipt.token,receipt.tooltip)
  if not unchanged() then return end
  if owned==nil then return end
  if owned then
   restore(self,receipt.token,receipt.tooltip)
   if self.anchorToken~=nil or self.anchoredTooltip~=nil then return end
   permitted,original,saved,corner=nativeDefaultPlacement(self,tooltip,parent)
   if not permitted then return end
  else
   forget(self,receipt.token,receipt.tooltip)
  end
  receipt.token=nil;receipt.tooltip=nil
 end
 local mode=cfg.cursorAnchor and "CURSOR" or cfg.fixedAnchor and "FIXED" or "SMART"
 if mode=="SMART" then
  local x,why=self:SmartPosition(tooltip)
  if not x then
   if why=="TIP_SIZE_PENDING" and unchanged() then
    local original=points(tooltip)
    if original and #original>0 and identity(tooltip,parent)==true and unchanged() then
     self.pendingDefaultAnchor={tooltip=tooltip,parent=parent,points=original,profile=M.profile,cfg=cfg,created=M.Safety:Now(),tries=0}
    end
   end
   return
  end
 end
 local target=mode=="CURSOR" and self.cursorAnchor or mode=="SMART" and self.smartAnchor or self.anchor
 if not target then return end
 if not same(points(tooltip),original) then return end
 if not unchanged() or not rawequal(mode=="CURSOR" and self.cursorAnchor or mode=="SMART" and self.smartAnchor or self.anchor,target) then return end
 local token={};self.anchorToken=token;self.savedPoints=saved;self.anchoredTooltip=tooltip;self.anchorOwner=parent;self.anchorMode=mode;self.anchorExpected={original};self.anchorCorner=corner
 receipt.token=token;receipt.tooltip=tooltip
 local function current()
  local active=M:ModuleConfig(self.id)
  local allowed=M:IsModuleActive(self.id) and not M.Native:Conflict() and rawequal(active,cfg)
   and (mode=="CURSOR" and active.cursorAnchor or mode=="FIXED" and active.fixedAnchor and not active.cursorAnchor
    or mode=="SMART" and active.avoidMeters~=false and not active.fixedAnchor and not active.cursorAnchor)
  return allowed and currentReceipt(self,token,tooltip) and rawequal(mode=="CURSOR" and self.cursorAnchor or mode=="SMART" and self.smartAnchor or self.anchor,target)
 end
 if mode=="CURSOR" and not self:MoveCursorAnchor(token,tooltip,target)
  or mode=="SMART" and not self:MoveSmartAnchor(token,tooltip,target) or not current() then
  -- No native geometry has been attempted yet; do not manufacture a restore.
  forget(self,token,tooltip)
  return
 end
 if not self:WriteAnchor(token,"ClearAllPoints",{}, {},tooltip) then return end
 if not current() or mode=="CURSOR" and not self:CursorWritable(token) then return end
 local point=self:AnchorPoint(token,tooltip)
 if not point or not self:WriteAnchor(token,"SetPoint",point,{point},tooltip) then return end
 if not current() or self.anchorRestoreRequested or mode=="CURSOR" and not self:CursorWritable(token) then return end
 if not currentReceipt(self,token,tooltip) then return end
 self.anchorRestorePending=nil
 self:WatchAnchorSize(tooltip)
end
function T:DefaultAnchor(tooltip,parent)
 self.pendingDefaultAnchor=nil
 if M.NativeWindowPolicy and M.NativeWindowPolicy:ModuleNative(self.id) then self:RestoreAnchor();return end
 local cfg=M:ModuleConfig(self.id)
 if cfg.style==false or cfg.enabled==false or cfg.primaryPresentation==2 then self:RestoreAnchor();return end
 if self.anchorBusy then return end
 local busy={};self.anchorBusy=busy
 local receipt={token=self.anchorToken,tooltip=self.anchoredTooltip}
 local ok=pcall(acquire,self,tooltip,parent,receipt)
 if rawequal(self.anchorBusy,busy) then self.anchorBusy=nil end
 if currentReceipt(self,receipt.token,receipt.tooltip) then
  if not ok then self.anchorRestorePending=true end
  if self.anchorRestorePending then self:RestoreAnchor() end
 end
 if not ok then error("ANCHOR_CALLBACK_FAILED") end -- outer M:Guard classifies; no raw payload
end
function T:ApplyAnchorScale(surface)
 if surface~=self.anchorSurface or not self.anchor or M.Safety:InCombat() then return end
 local cfg=M:ModuleConfig(self.id)
 local l=M.Layout:Unfitted(surface,M.profile)
 l.scale=math.max(.7,math.min(1.6,(cfg.tooltipScale or 100)/100));M.Layout:Clamp(l)
 local w,h=M.Layout:Screen();if not w then return end
 local target=l.anchorTo and M.surfaces[l.anchorTo]
 target=target and target.frame or UIParent
 self.anchor:SetSize(l.width,l.height);self.anchor:SetScale(l.scale);self.anchor:ClearAllPoints()
 self.anchor:SetPoint("CENTER",target,"CENTER",l.x*w/l.scale,l.y*h/l.scale)
end
function T:CreateAnchor()
 if M.NativeWindowPolicy and M.NativeWindowPolicy:ModuleNative(self.id) then return end
 if M.Safety:InCombat() then return end
 local cfg=M:ModuleConfig(self.id)
 if not self.anchor then
  self.anchor=M:TrackRoot(self.id,CreateFrame("Frame",nil,UIParent));self.anchor:SetSize(1,1);M.Safety:Passive(self.anchor)
  self.anchorSurface={id="Tooltips.anchor",module=self.id,frame=self.anchor,security="OWNED_VISUAL",groups={},fallback="VISIBLE",editable=true,
   layout={x=.32,y=-.32,width=240,height=80,scale=1},minWidth=120,minHeight=40}
  self.anchorSurface.OnLayout=function(surface) self:ApplyAnchorScale(surface) end
  M.CVE:Register(self.anchorSurface);M.Layout:Apply(self.anchorSurface)
 end
 if cfg.cursorAnchor and not self.cursorAnchor then
  self.cursorAnchor=M:TrackRoot(self.id,CreateFrame("Frame",nil,UIParent));self.cursorAnchor:SetSize(1,1);M.Safety:Passive(self.cursorAnchor)
 end
 if cfg.avoidMeters~=false and not self.smartAnchor then
  self.smartAnchor=M:TrackRoot(self.id,CreateFrame("Frame",nil,UIParent));self.smartAnchor:SetSize(1,1);M.Safety:Passive(self.smartAnchor)
 end
 if not self.anchorHook and type(hooksecurefunc)=="function" and type(GameTooltip_SetDefaultAnchor)=="function" then
  hooksecurefunc("GameTooltip_SetDefaultAnchor",function(tooltip,parent) M:Guard(self.id,self.DefaultAnchor,self,tooltip,parent) end)
  self.anchorHook=true
 end
end
function T:ApplyConfig()
 self:RestoreAnchor();priorApply(self)
 if M.NativeWindowPolicy and M.NativeWindowPolicy:ModuleNative(self.id) then self.status="NATIVE_BY_DESIGN";return end
 local cfg=M:ModuleConfig(self.id)
 self:CreateAnchor();if self.anchorSurface then M.Layout:Apply(self.anchorSurface) end
end
function T:Resume() priorResume(self);self:ApplyConfig() end
function T:Suspend() priorSuspend(self);self:RestoreAnchor() end
function T:Tick()
 if M.NativeWindowPolicy and M.NativeWindowPolicy:ModuleNative(self.id) then
  if self.anchorRestorePending or self.anchoredTooltip then self:RestoreAnchor() end
  return
 end
 if self.anchorBusy then return end
 local pending=self.pendingDefaultAnchor
 if pending then
  local now=M.Safety:Now();local cfg=M:ModuleConfig(self.id)
  if M.Safety:InCombat() or now-pending.created>.65 or pending.tries>=5 or pending.profile~=M.profile or pending.cfg~=cfg
   or cfg.enabled==false or cfg.style==false or cfg.primaryPresentation==2 or cfg.fixedAnchor or cfg.cursorAnchor or cfg.avoidMeters==false
   or not M:IsModuleActive(self.id) or M.Native:Conflict() then self.pendingDefaultAnchor=nil
  elseif now>=(pending.nextRead or 0) then
   pending.nextRead=now+.1;pending.tries=pending.tries+1
   local tip=pending.tooltip
   local owned=legal(tip) and identity(tip,pending.parent)==true and same(points(tip),pending.points)
   if self.pendingDefaultAnchor~=pending then return end
   if not owned then self.pendingDefaultAnchor=nil
   elseif M.Safety:Public(tip.IsShown,"boolean",tip)==true then
    local x,why=self:SmartPosition(tip)
    if self.pendingDefaultAnchor~=pending then return end
    if x then self.pendingDefaultAnchor=nil;self:DefaultAnchor(tip,pending.parent)
    elseif why~="TIP_SIZE_PENDING" then self.pendingDefaultAnchor=nil end
   end
  end
 end
 local token,tooltip,cursor=self.anchorToken,self.anchoredTooltip,self.cursorAnchor
 if self.anchorRestorePending then self:RestoreAnchor() end
 if not sameReceipt(self,token,tooltip) then return end
 local cfg=M:ModuleConfig(self.id)
 if cfg.style==false or cfg.enabled==false or cfg.primaryPresentation==2 then self:RestoreAnchor();return end
 if not sameReceipt(self,token,tooltip) then return end
 if not self.anchorHook then
  local now=M.Safety:Now()
  if not sameReceipt(self,token,tooltip) then return end
  if now>=(self.anchorRetryAt or 0) then self.anchorRetryAt=now+1;self:CreateAnchor() end
 end
 if self.anchoredTooltip and self.anchorMode=="SMART" then
  if M.Safety:InCombat() then return end
  local now=M.Safety:Now()
  if now<(self.smartNextRead or 0) then return end;self.smartNextRead=now+.15
  if M.Safety:Public(tooltip.IsShown,"boolean",tooltip)~=true or not self:SmartPosition(tooltip) then self:RestoreAnchor();return end
  local busy={};self.anchorBusy=busy
  local ok,moved=pcall(self.MoveSmartAnchor,self,token,tooltip,self.smartAnchor)
  if rawequal(self.anchorBusy,busy) then self.anchorBusy=nil end
  if currentReceipt(self,token,tooltip) and (not ok or not moved) then self:RestoreAnchor() end
  if not ok then error("ANCHOR_CALLBACK_FAILED") end
  return
 end
 if not sameReceipt(self,token,tooltip) then return end
 if self.anchoredTooltip and self.anchorMode=="CURSOR" then
  if not self:AnchorWritable(token,tooltip) or not currentReceipt(self,token,tooltip) then return end
  local shown=M.Safety:Public(tooltip.IsShown,"boolean",tooltip)
  if not currentReceipt(self,token,tooltip) then return end
  if shown~=true then self:RestoreAnchor();return end
  local move=self.MoveCursorAnchor
  if not currentReceipt(self,token,tooltip) or not rawequal(self.cursorAnchor,cursor) then return end
  local busy={};self.anchorBusy=busy
  local ok,moved=pcall(move,self,token,tooltip,cursor)
  if rawequal(self.anchorBusy,busy) then self.anchorBusy=nil end
  if currentReceipt(self,token,tooltip) and (not ok or not moved or self.anchorRestorePending) then self:RestoreAnchor() end
  if not ok then error("ANCHOR_CALLBACK_FAILED") end -- outer module guard owns quarantine
 end
end
