local _, M = ...
local A={bars={},buttons={},events={ACTIONBAR_SLOT_CHANGED=true,ACTIONBAR_PAGE_CHANGED=true,UPDATE_BONUS_ACTIONBAR=true,UPDATE_SHAPESHIFT_FORM=true,ACTIONBAR_UPDATE_COOLDOWN=true,ACTIONBAR_UPDATE_STATE=true,UPDATE_BINDINGS=true,PLAYER_ENTERING_WORLD=true}}
local white="Interface\\Buttons\\WHITE8X8"
function A:Initialize()
    if M.Rework and M.Rework:Selected("main") then self.status="REWORK_CUSTOM_ACTION_FAMILIES";return end
    if M.Native:Conflict() then self.status="CONFLICT_NATIVE_OWNER";return end
    if M.Safety:InCombat() or type(RegisterStateDriver)~="function" or type(UnregisterStateDriver)~="function" or type(GetActionTexture)~="function" then self.status="SECURE_PATH_UNAVAILABLE";return end
    for barIndex=1,3 do
      if not (barIndex==1 and M.Rework and M.Rework:Selected("main")) then
        local bar=CreateFrame("Frame","MirageActionBar"..barIndex,UIParent,"SecureHandlerStateTemplate,BackdropTemplate")
        M:TrackRoot(self.id,bar);bar:Hide()
        if not M.Safety:InitializeSecureHandler(bar) then error("ACTION_HANDLER_UNAVAILABLE",0) end
        M.UI:Backdrop(bar,true);bar:SetSize(464,42);self.bars[barIndex]=bar;bar.buttons={}
        local first=barIndex==1 and 1 or barIndex==2 and 61 or 49
        for slot=1,12 do
            local b=CreateFrame("Button","MirageAction"..barIndex.."_"..slot,bar,"SecureActionButtonTemplate,BackdropTemplate")
            b:SetSize(34,34);b:SetPoint("TOPLEFT",6+(slot-1)*38,-4);M.UI:Backdrop(b,true)
            b:SetAttribute("type","action");b:SetAttribute("action",first+slot-1);b:SetAttribute("useOnKeyDown",false)
            b:RegisterForClicks("AnyUp")
            b.icon=b:CreateTexture(nil,"ARTWORK");b.icon:SetPoint("TOPLEFT",2,-2);b.icon:SetPoint("BOTTOMRIGHT",-2,2)
            b.cooldown=CreateFrame("Cooldown",nil,b,"CooldownFrameTemplate");b.cooldown:SetAllPoints(b.icon)
            if b.cooldown.SetHideCountdownNumbers then b.cooldown:SetHideCountdownNumbers(true) end
            b.hotkey=M.UI:Text(b,"",1,-1,9,32);b.hotkey:SetJustifyH("RIGHT")
            b.slot=slot;b.barIndex=barIndex;b.nativeCommand=M.ActionKeys:Command(barIndex,slot)
            b:RegisterForDrag("LeftButton")
            b:SetScript("OnDragStart",function(self,button) M.ActionEditing:Pickup(self,button) end)
            b:SetScript("OnReceiveDrag",function(self) M.ActionEditing:Drop(self) end)
            b:HookScript("OnAttributeChanged",function(_,key)
                if M.Safety:Text(key) and key=="action" then A.iconsDirty=true;A.cooldownsDirty=true end
            end)
            b:SetScript("OnEnter",function(self)
                if not M:ModuleConfig("ActionBars").showTooltips then return end
                local action=M.Safety:Public(self.GetAttribute,"number",self,"action")
                if action and GameTooltip then GameTooltip:SetOwner(self,"ANCHOR_TOP");GameTooltip:SetAction(action);GameTooltip:Show() end
            end)
            b:SetScript("OnLeave",function() if GameTooltip then GameTooltip:Hide() end end)
            bar.buttons[#bar.buttons+1]=b;self.buttons[#self.buttons+1]=b
            if barIndex==1 then bar:SetFrameRef("slot"..slot,b) end
        end
        if barIndex==1 then
            -- Fixed reviewed secure program. No user text, dynamic script or combat API decisions.
            bar:SetAttribute("_onstate-page",[[
                local page=tonumber(newstate) or 1
                for i=1,12 do
                    local button=self:GetFrameRef("slot"..i)
                    button:SetAttribute("action",(page-1)*12+i)
                end
            ]])
            self.pageDriver="[bar:2] 2; [bar:3] 3; [bar:4] 4; [bar:5] 5; [bar:6] 6; [bonusbar:5] 11; [bonusbar:4] 10; [bonusbar:3] 9; [bonusbar:2] 8; [bonusbar:1] 7; 1"
            RegisterStateDriver(bar,"page",self.pageDriver)
        end
        -- Native vehicle/override/possess controls remain the sole owner of special actions.
        self.visibleDriver="[vehicleui] hide; [overridebar] hide; [possessbar] hide; show"
        RegisterStateDriver(bar,"visibility",self.visibleDriver)
        local s={id="ActionBars.bar"..barIndex,module=self.id,frame=bar,security="SECURE_PREDECLARED",floor=true,editable=true,minWidth=300,minHeight=34,groups={combat=true},
            layout={x=0,y=-.41+(barIndex-1)*.047,width=464,height=42,scale=1}}
        s.OnLayout=function(_,l)
            local cfg=M:ModuleConfig(self.id);local cols=cfg.columns;local rows=math.ceil(12/cols)
            local size=math.max(12,math.min((l.width-12-(cols-1)*cfg.gap)/cols,(l.height-8-(rows-1)*cfg.gap)/rows))
            for i,b in ipairs(bar.buttons) do
                b:SetSize(size,size);b:ClearAllPoints();b:SetPoint("TOPLEFT",6+((i-1)%cols)*(size+cfg.gap),-4-math.floor((i-1)/cols)*(size+cfg.gap))
                b.hotkey:SetWidth(size-2);b.hotkey:SetShown(cfg.showHotkeys)
            end
        end
        bar.surface=s;M.CVE:Register(s);M.Layout:Apply(s)
      end
    end
    self:Refresh();self.status="SECURE_CLICK_BARS_NATIVE_RETAINED"
end
function A:Refresh(scope)
    local all=scope==nil
    for _,b in ipairs(self.buttons) do
        local action=M.Safety:Public(b.GetAttribute,"number",b,"action")
        if action then
            if all or scope=="icons" then
                local texture=M.Safety:Public(GetActionTexture,nil,action)
                b.icon:SetTexture(texture)
            end
            if all or scope=="cooldowns" then
                b.cooldownStatus=M.Display:Cooldown(b.cooldown,C_ActionBar and C_ActionBar.GetActionCooldownDuration,action)
            end
        elseif all or scope=="icons" or scope=="cooldowns" then
            b.icon:SetTexture(nil);if b.cooldown.Clear then b.cooldown:Clear() end
            b.cooldownStatus="UNAVAILABLE_SLOT"
        end
        if all or scope=="bindings" then
            local context,valid=M.ActionKeys:Context(b.nativeCommand)
            local key=valid and M.Safety:Public(GetBindingKey,"string",b.nativeCommand,nil,context)
            b.hotkey:SetText(key and key:gsub("SHIFT%-","S-"):gsub("CTRL%-","C-"):gsub("ALT%-","A-"):gsub("BUTTON","M"):gsub("MOUSEWHEELUP","WU"):gsub("MOUSEWHEELDOWN","WD") or "")
        end
    end
end
function A:OnEvent(event)
    if event=="UPDATE_BINDINGS" then self.bindingsDirty=true
    elseif event=="ACTIONBAR_UPDATE_COOLDOWN" then self.cooldownsDirty=true
    elseif event=="ACTIONBAR_UPDATE_STATE" then self.iconsDirty=true
    else self.dirty=true end
end
function A:Tick()
    if self.dirty then
        self.dirty=false;self.iconsDirty=false;self.cooldownsDirty=false;self.bindingsDirty=false;self:Refresh()
    else
        for _,kind in ipairs({"icons","cooldowns","bindings"}) do
            if self[kind.."Dirty"] then self[kind.."Dirty"]=false;self:Refresh(kind) end
        end
    end
end
function A:Suspend()
    if M.BindingEditor then M.BindingEditor:Close() end
    M.ActionKeys:Cancel();M.ActionEditing.status="DISABLED"
    if M.Safety:InCombat() then self.pendingDisable=true;return end
    for _,bar in pairs(self.bars) do
        if UnregisterStateDriver then UnregisterStateDriver(bar,"visibility");UnregisterStateDriver(bar,"page") end
        bar:Hide()
    end
    self.pendingDisable=nil
end
function A:Resume()
    if M.Safety:InCombat() then return end
    self.pendingDisable=nil;self.maintenanceFailed=nil
    for i,bar in pairs(self.bars) do RegisterStateDriver(bar,"visibility",self.visibleDriver);if i==1 then RegisterStateDriver(bar,"page",self.pageDriver) end end
    self:Refresh()
end
function A:ApplyConfig()
    if M.Safety:InCombat() then return end
    local cfg=M:ModuleConfig(self.id);local rows=math.ceil(12/cfg.columns)
    self.visibleDriver="[vehicleui] hide; [overridebar] hide; [possessbar] hide; "..
        (cfg.contextual and "[combat] show; [@target,exists] show; [@focus,exists] show; hide" or "show")
    for _,bar in pairs(self.bars) do
        bar.surface.minWidth=12+cfg.columns*16+(cfg.columns-1)*cfg.gap
        bar.surface.minHeight=8+rows*16+(rows-1)*cfg.gap
        bar.surface.layout.width=12+cfg.columns*34+(cfg.columns-1)*cfg.gap
        bar.surface.layout.height=8+rows*34+(rows-1)*cfg.gap
        RegisterStateDriver(bar,"visibility",self.visibleDriver);M.Layout:Apply(bar.surface)
    end
    self:Refresh()
end
A.maintenanceEvents=A.events
function A:MaintainSecure(event)
    if event=="TICK" then self:Tick() else self:OnEvent(event) end
end
function A:ClearSecureDisplay()
    for _,b in ipairs(self.buttons) do b.icon:SetTexture(nil);b.hotkey:SetText("?");if b.cooldown.Clear then b.cooldown:Clear() end end
end
M:RegisterModule("ActionBars",A)
