local _, M = ...
local U={views={},events={UNIT_HEALTH=true,UNIT_MAXHEALTH=true,UNIT_POWER_UPDATE=true,UNIT_MAXPOWER=true,UNIT_NAME_UPDATE=true,UNIT_CONNECTION=true,UNIT_FLAGS=true,UNIT_DISPLAYPOWER=true,PLAYER_ROLES_ASSIGNED=true,READY_CHECK=true,READY_CHECK_CONFIRM=true,READY_CHECK_FINISHED=true,PLAYER_TARGET_CHANGED=true,PLAYER_FOCUS_CHANGED=true,UNIT_PET=true,INSTANCE_ENCOUNTER_ENGAGE_UNIT=true,PLAYER_ENTERING_WORLD=true}}
for event in pairs(M.UnitExtras.events) do U.events[event]=true end
U.events.UNIT_AURA=true
function U:WantsEvent(event)
    if M.UnitExtras.events[event] then return M:ModuleConfig(self.id).showCast==true end
    if event=="UNIT_AURA" then local c=M:ModuleConfig(self.id);return c.showAuras==true or c.showBuffs==true end
    if event=="READY_CHECK" or event=="READY_CHECK_CONFIRM" or event=="READY_CHECK_FINISHED" then return M:ModuleConfig(self.id).showReady==true end
    return true
end
function U:Initialize()
    if M.Native:Conflict() then self.status="CONFLICT_NATIVE_OWNER";return end
    if type(RegisterUnitWatch)~="function" or type(UnregisterUnitWatch)~="function" then self.status="SECURE_PATH_UNAVAILABLE";return end
    if M.Safety:InCombat() then self.status="WAITING_FOR_OUT_OF_COMBAT";return end
    local units={{"player","Player",-.19,-.22},{"target","Target",.19,-.22},{"focus","Focus",.32,-.09},{"pet","Pet",-.19,-.28}}
    for i=1,5 do units[#units+1]={"boss"..i,"Boss "..i,.37,.20-(i-1)*.065} end
    for _,row in ipairs(units) do
        local unit,label,x,y=unpack(row)
        local reworked=M.Rework and M.Rework.Selected and M.Rework:Selected("units",M.profile)
        if not reworked then
        local view=M.Display:CreateUnit("MirageUnit_"..unit,unit,label);self.views[unit]=view
        local s={id="UnitFrames."..unit,module=self.id,frame=view.frame,security="SECURE_PREDECLARED",floor=true,
            editable=true,minWidth=130,minHeight=44,groups={combat=true},layout={x=x,y=y,width=300,height=55,scale=1}}
        s.OnLayout=function(_,l) M.Display:SizeUnit(view,l.width,l.height) end
        M.CVE:Register(s);view.surface=s;if M.UnitTypography then M.UnitExtras:Configure(view);M.UnitTypography:Attach(view,s) end;M.Layout:Apply(s)
        end
    end
    self:Refresh();self.status="SECURE_CANDIDATE_NATIVE_FALLBACK_RETAINED"
end
function U:Refresh()
    for _,v in pairs(self.views) do if not v.reworkProvider then M.Display:UnitBars(v,v.unit,true) end end
end
function U:OnEvent(event,unit)
    if M.UnitExtras.events[event] or event=="UNIT_AURA" then
        if M.Safety:Text(unit) and self.views[unit] and not self.views[unit].reworkProvider then M.UnitExtras:Event(self.views[unit],event) end
        return
    end
    if event=="PLAYER_TARGET_CHANGED" or event=="PLAYER_FOCUS_CHANGED" or event=="PLAYER_ENTERING_WORLD" or event=="GROUP_ROSTER_UPDATE" or event=="UNIT_PET" then
        for _,v in pairs(self.views) do if not v.reworkProvider then M.UnitExtras:Clear(v);M.UnitExtras:RefreshCast(v) end end
    end
    if event=="READY_CHECK" then
        self.readyActive=true
        local duration=M.Safety:Public(GetReadyCheckTimeLeft,"number")
        self.readyExpires=M.Safety:Now()+((duration and duration>0 and duration<=120) and duration or 40)
    elseif event=="READY_CHECK_FINISHED" or event=="PLAYER_ENTERING_WORLD" then self.readyActive=false;self.readyExpires=nil end
    if event=="UNIT_PET" then self:Refresh();return end
    if event=="READY_CHECK" or event=="READY_CHECK_CONFIRM" or event=="READY_CHECK_FINISHED" or event=="PLAYER_ROLES_ASSIGNED" then
        for _,v in pairs(self.views) do if not v.reworkProvider then M.Display:UnitInfo(v) end end;return
    end
    if event:sub(1,5)=="UNIT_" and M.Safety:Text(unit) then
        local view=self.views[unit];if view and not view.reworkProvider then M.Display:UnitBars(view,unit,event=="UNIT_NAME_UPDATE" or event=="UNIT_CONNECTION" or event=="UNIT_FLAGS" or event=="UNIT_DISPLAYPOWER" or event=="UNIT_MAXPOWER") end
    else self:Refresh() end
end
function U:Suspend()
    for _,v in pairs(self.views) do if not v.reworkProvider then if M.UnitTypography then M.UnitTypography:Suspend(v) end;M.UnitExtras:Clear(v) end end
    self.readyActive=false
    if M.Safety:InCombat() then self.pendingDisable=true;self.status="DISABLE_AFTER_COMBAT";return end
    for _,view in pairs(self.views) do
        if not view.reworkProvider then
        if UnregisterUnitWatch then UnregisterUnitWatch(view.frame) end
        view.frame:Hide()
        end
    end
    self.pendingDisable=nil
end
function U:Resume()
    if M.Safety:InCombat() then return end
    self.pendingDisable=nil;self.maintenanceFailed=nil
    for _,view in pairs(self.views) do if not view.reworkProvider then if M.UnitTypography then M.UnitExtras:Configure(view);M.UnitTypography:Configure(view) elseif RegisterUnitWatch then RegisterUnitWatch(view.frame) end end end
    self:Refresh()
end
function U:ApplyConfig() for _,v in pairs(self.views) do if not v.reworkProvider then M.UnitExtras:Configure(v);M.Layout:Apply(v.surface);M.UnitExtras:RefreshCast(v) end end;self:Refresh() end
function U:Tick(now)
    for _,v in pairs(self.views) do if not v.reworkProvider then M.UnitExtras:Tick(v,now) end end
    if self.readyActive and self.readyExpires and now>=self.readyExpires then
        self.readyActive=false;self.readyExpires=nil
        for _,view in pairs(self.views) do if not view.reworkProvider then M.Display:UnitInfo(view) end end
    end
end
U.maintenanceEvents={UNIT_HEALTH=true,UNIT_MAXHEALTH=true,UNIT_POWER_UPDATE=true,UNIT_MAXPOWER=true,UNIT_NAME_UPDATE=true,UNIT_CONNECTION=true,UNIT_FLAGS=true,UNIT_DISPLAYPOWER=true,PLAYER_TARGET_CHANGED=true,PLAYER_FOCUS_CHANGED=true,UNIT_PET=true,GROUP_ROSTER_UPDATE=true,INSTANCE_ENCOUNTER_ENGAGE_UNIT=true}
function U:MaintainSecure(event,unit)
    local custom=M.Rework and M.Rework.UnitFrames
    if custom and custom.initialized then custom:MaintainSecure(event,unit) end
    if event=="TICK" then return end
    for _,view in pairs(self.views) do
        if not view.reworkProvider and (not M.Safety:Text(unit) or view.unit==unit or event=="UNIT_PET" or event=="PLAYER_TARGET_CHANGED" or event=="PLAYER_FOCUS_CHANGED") then
            M.Display:UnitBars(view,view.unit,true)
        end
    end
end
function U:ClearSecureDisplay()
    for _,view in pairs(self.views) do if not view.reworkProvider then M.Display:ClearUnit(view) end end
end
M:RegisterModule("UnitFrames",U)
