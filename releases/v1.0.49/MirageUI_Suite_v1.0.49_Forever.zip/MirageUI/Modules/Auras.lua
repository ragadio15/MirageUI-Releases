local _, M = ...
local A=M:CreateNativeModule("Auras",{"BuffFrame","DebuffFrame"},{combat=true},false)
local nativeRefresh,nativeApply=A.Refresh,A.ApplyConfig
local S=M.Safety
A.events.UNIT_AURA=true
A.events.PLAYER_LEAVING_WORLD=true
A.rows={}
function A:WantsEvent(event)
    return event~="UNIT_AURA" or M:ModuleConfig(self.id).playerPanel
end
local filters={"HELPFUL","HARMFUL"}

function A:EndHover(tile,attempt)
    if not self.hoverTile or (tile and tile~=self.hoverTile) or (attempt and attempt~=self.hoverAttempt) then return end
    local old,tip,epoch=self.hoverTile,self.hoverTip,self.hoverEpoch
    self.hoverTile,self.hoverTip,self.hoverAttempt=nil,nil,nil
    if S:Frame(tip,false) and S:Public(tip.GetOwner,nil,tip)==old and self.hoverEpoch==epoch then pcall(tip.Hide,tip) end
end

local function validIcon(icon)
    return (S:Number(icon) and icon>0 and icon%1==0) or (S:Text(icon) and #icon>0)
end
local function currentAura(tile,expectedID,expectedIcon)
    local api=C_UnitAuras and C_UnitAuras.GetAuraDataByIndex
    local data=S:Public(api,"table","player",tile.index,tile.filter)
    local id=S:Field(data,"auraInstanceID")
    local icon=S:Field(data,"icon")
    return S:Number(id) and id==expectedID and validIcon(icon) and icon==expectedIcon
end

function A:Hover(tile)
    if not M.CVE:InputVisible(self.surface) then return end
    local revision,id,icon=self.revision,tile.auraID,tile.iconKey
    self.hoverEpoch=(self.hoverEpoch or 0)+1
    local epoch=self.hoverEpoch
    local function current()
        return self.hoverEpoch==epoch and self.revision==revision and not self.dirty and not self.readPaused
            and id and tile.auraID==id and tile.iconKey==icon and M:IsModuleActive(self.id)
            and M:ModuleConfig(self.id).playerPanel and tile:IsVisible()
    end
    local tip=GameTooltip
    if not current() or not S:Frame(tip,false) or type(tip.GetOwner)~="function" or type(tip.SetUnitAura)~="function" then return end
    local previous=self.hoverTile
    local ok,owner=pcall(tip.GetOwner,tip)
    if not ok or not S:Readable(owner) or not current() then return end
    self:EndHover()
    if not current() then return end
    if not currentAura(tile,id,icon) then
        if current() then self:Invalidate() end
        return
    end
    local read,now=pcall(tip.GetOwner,tip)
    if not read or not S:Readable(now) or not current() then return end
    if now~=owner and not (previous==owner and now==nil) then return end
    local attempt={}
    self.hoverTile,self.hoverTip,self.hoverAttempt=tile,tip,attempt
    local function owns()
        return S:Public(tip.GetOwner,nil,tip)==tile and self.hoverAttempt==attempt and current()
    end
    if not pcall(tip.SetOwner,tip,tile,"ANCHOR_TOP") or not owns() or not currentAura(tile,id,icon) or not owns()
        or not pcall(tip.SetUnitAura,tip,"player",tile.index,tile.filter) or not owns()
        or not currentAura(tile,id,icon) or not owns() or not pcall(tip.Show,tip)
        or not owns() or not currentAura(tile,id,icon) or not owns() then self:EndHover(tile,attempt);return end
    M.CVE:Hold(self.surface,.4)
end

function A:CreatePanel()
    if self.frame or S:InCombat() then return end
    self.frame=M:TrackRoot(self.id,M.UI:Card(UIParent,420,108));self.frame:Hide()
    self.frame:SetScript("OnHide",function() self.wasVisible=false;self:Invalidate() end)
    for g,filter in ipairs(filters) do
        local group={label=M.UI:Text(self.frame,g==1 and "Buffs" or "Debuffs",6,-6,10,100),slots={}}
        self.rows[g]=group
        for i=1,20 do
            local tile=M.UI:Card(self.frame,28,28);tile:Hide()
            tile.icon=tile:CreateTexture(nil,"ARTWORK");tile.icon:SetPoint("TOPLEFT",2,-2);tile.icon:SetPoint("BOTTOMRIGHT",-2,2)
            tile.timer=CreateFrame("Cooldown",nil,tile,"CooldownFrameTemplate");tile.timer:SetAllPoints(tile.icon);S:Passive(tile.timer)
            tile.count=M.UI:Text(tile,"",2,-2,10,24);tile.count:SetJustifyH("RIGHT")
            tile.filter=filter;tile.index=i
            if tile.SetMouseClickEnabled and tile.SetMouseMotionEnabled then tile:SetMouseClickEnabled(false);tile:SetMouseMotionEnabled(true) end
            tile:SetScript("OnEnter",function() self:Hover(tile) end)
            tile:SetScript("OnLeave",function() self:EndHover(tile) end)
            group.slots[i]=tile
        end
    end
    self.surface={id="Auras.player",module=self.id,frame=self.frame,security="OWNED_VISUAL",groups={combat=true},fallback="HIDDEN",editable=true,holdOnHover=true,
        minWidth=24,minHeight=16,layout={x=.30,y=.28,width=420,height=108,scale=1}}
    self.surface.OnLayout=function(_,l) self:LayoutSlots(l) end
    M.CVE:Register(self.surface)
end
function A:ClearTile(tile)
    self:EndHover(tile)
    tile.available=false;tile.countStatus="NOT_RUN";tile.auraID=nil;tile.iconKey=nil;tile.timerStatus="NOT_RUN"
    tile.icon:SetTexture(nil);tile.count:SetText("")
    tile.timer:Hide()
    if tile.timer.Clear then pcall(tile.timer.Clear,tile.timer) end
    tile:Hide()
end
function A:Invalidate()
    self.revision=(self.revision or 0)+1
    self:EndHover()
    if not self.dirty then
        for _,group in ipairs(self.rows) do
            for _,tile in ipairs(group.slots) do if tile.available then self:ClearTile(tile) end end
        end
    end
    self.dirty=true
    if self.layoutFits and not self.readPaused and self.surface and not self.surface.disabled then self.panelStatus="WAITING_FOR_REFRESH" end
end
-- Sample public text on an owned, single-line FontString. Some clients expose
-- GetStringWidth only. Measure with no width constraint, then restore the chosen box.
local function textFit(font,width,height)
    local w
    if type(font.GetUnboundedStringWidth)=="function" then
        w=S:Public(font.GetUnboundedStringWidth,"number",font)
    else
        font:SetWidth(0)
        w=S:Public(font.GetStringWidth,"number",font)
        font:SetWidth(width)
    end
    local h=S:Public(font.GetStringHeight,"number",font)
    if not w or w<=0 or not h or h<=0 then return "FIT_UNKNOWN" end
    if w>width or h>height then return "TEXT_DOES_NOT_FIT" end
    if type(font.IsTruncated)=="function" then
        local cut,access=S:Public(font.IsTruncated,"boolean",font)
        if access~="KNOWN" then return "FIT_UNKNOWN" end
        if cut then return "TEXT_DOES_NOT_FIT" end
    end
    return "FITS"
end
function A:LayoutSlots(l)
    local cfg=M:ModuleConfig(self.id);local cols=math.min(cfg.columns,cfg.limit);local rows=math.ceil(cfg.limit/cols)
    local size=cfg.iconSize
    local groupHeight=20+rows*size+(rows-1)*4
    self.layoutFits=l.width>=12+cols*size+(cols-1)*4 and l.height>=4+2*groupHeight
    self.layoutStatus=self.layoutFits and "FITS" or "LAYOUT_DOES_NOT_FIT"
    if self.layoutFits then
        local labelWidth=math.min(100,l.width-12)
        for _,group in ipairs(self.rows) do
            group.label:SetWidth(labelWidth);group.label:SetHeight(16)
            group.labelStatus=textFit(group.label,labelWidth,16)
            if group.labelStatus~="FITS" then self.layoutFits=false;self.layoutStatus="LANE_LABEL_"..group.labelStatus end
        end
    end
    for g,group in ipairs(self.rows) do
        group.label:SetShown(self.layoutFits)
        if self.layoutFits then
            local top=6+(g-1)*groupHeight
            group.label:ClearAllPoints();group.label:SetPoint("TOPLEFT",6,-top)
            for i,tile in ipairs(group.slots) do
                tile:SetSize(size,size);tile:ClearAllPoints();tile:SetPoint("TOPLEFT",6+((i-1)%cols)*(size+4),-top-16-math.floor((i-1)/cols)*(size+4))
                tile.count:SetWidth(size-4);tile.count:SetHeight(size-4)
                if tile.timer.SetHideCountdownNumbers then tile.timer:SetHideCountdownNumbers(not cfg.showNumbers) end
            end
        end
    end
    self.surface.disabled=not cfg.playerPanel or not self.layoutFits
    self:Invalidate()
    if not self.layoutFits then self.panelStatus=self.layoutStatus;M.Effects:Stop(self.surface) end
end
function A:Configure()
    if S:InCombat() then self:Invalidate();return end
    local cfg=M:ModuleConfig(self.id)
    if cfg.playerPanel then self:CreatePanel() end
    if not self.frame then self.panelStatus="DISABLED";return end
    self:Invalidate()
    local cols=math.min(cfg.columns,cfg.limit);local rows=math.ceil(cfg.limit/cols)
    self.surface.layout.width=12+cols*cfg.iconSize+(cols-1)*4
    self.surface.layout.height=44+2*rows*cfg.iconSize+2*(rows-1)*4
    self.readErrors=0;self.readPaused=false;self.nextRefresh=0
    M.Layout:Apply(self.surface)
    if self.surface.disabled then M.Effects:Stop(self.surface) end
    if not cfg.playerPanel then self.panelStatus="DISABLED" end
end
function A:Initialize() nativeRefresh(self);self:Configure() end
function A:ApplyConfig() nativeApply(self);self:Configure() end
local function refreshAuras(self)
    local cfg=M:ModuleConfig(self.id);local api=C_UnitAuras and C_UnitAuras.GetAuraDataByIndex
    if self.readPaused or not cfg.playerPanel or not self.layoutFits or not self.frame:IsVisible() then return end
    if type(api)~="function" then
        for _,g in ipairs(self.rows) do for _,tile in ipairs(g.slots) do self:ClearTile(tile) end end
        self.panelStatus="UNSUPPORTED";return
    end
    local limited=false;local failed=false
    local revision=self.revision
    for _,group in ipairs(self.rows) do
        local stop=false
        for i,tile in ipairs(group.slots) do
            if self.revision~=revision then return end
            if stop or i>cfg.limit then
                if tile.available then self:ClearTile(tile) end
            else
                local ok,data=pcall(api,"player",i,tile.filter)
                if revision~=self.revision then return end
                if not ok then failed=true;limited=true;stop=true;self:ClearTile(tile)
                elseif not S:Readable(data) then limited=true;stop=true;self:ClearTile(tile)
                elseif data==nil then stop=true;self:ClearTile(tile)
                else
                    local icon,status=S:Field(data,"icon")
                    if self.revision~=revision then return end
                    if status~="KNOWN" or not validIcon(icon) then limited=true;self:ClearTile(tile)
                    else
                        local id=S:Field(data,"auraInstanceID")
                        local identified=S:Number(id) and id>0 and id%1==0
                        if self.revision~=revision then return end
                        if not identified or tile.auraID~=id or tile.iconKey~=icon then self:EndHover(tile) end
                        if self.revision~=revision then return end
                        tile.icon:SetTexture(icon);tile.iconKey=icon;tile.available=true;tile:Show();tile.count:SetText("")
                        if identified then
                            tile.auraID=id
                            local sent,result=pcall(M.Display.Cooldown,M.Display,tile.timer,C_UnitAuras.GetAuraDuration,"player",id)
                            if revision~=self.revision then self:ClearTile(tile);return end
                            tile.timerStatus=sent and result or "UNAVAILABLE"
                            tile.timer:SetShown(tile.timerStatus=="NATIVE_WIDGET_DISPATCH")
                            local count,access=S:Public(C_UnitAuras.GetAuraApplicationDisplayCount,"string","player",id,2,999)
                            if revision~=self.revision then self:ClearTile(tile);return end
                            if access=="KNOWN" then
                                tile.count:SetText(count)
                                tile.countStatus=count=="" and "NO_TEXT" or textFit(tile.count,cfg.iconSize-4,cfg.iconSize-4)
                                if tile.countStatus~="FITS" and tile.countStatus~="NO_TEXT" then tile.count:SetText("");limited=true end
                            else tile.countStatus="UNAVAILABLE";limited=true end
                            if tile.timerStatus=="UNSUPPORTED" or tile.timerStatus=="UNAVAILABLE" then limited=true end
                        else
                            tile.auraID=nil;tile.countStatus="UNAVAILABLE"
                            tile.timer:Hide()
                            if tile.timer.Clear then pcall(tile.timer.Clear,tile.timer) end
                            tile.timerStatus="UNAVAILABLE";limited=true
                        end
                    end
                end
            end
        end
    end
    self.readErrors=failed and (self.readErrors+1) or 0
    if self.readErrors>=3 then
        self.readPaused=true
        for _,g in ipairs(self.rows) do for _,tile in ipairs(g.slots) do self:ClearTile(tile) end end
    end
    self.panelStatus=self.readPaused and "SOURCE_PAUSED" or limited and "PARTIAL_RESTRICTED" or "PUBLIC_PLAYER_AURA_PRESENTATION"
end
-- A duration getter/sink or count callback can invalidate this pass and request
-- another one before returning. Finish retiring the old writes first; the next
-- eligible tick paints the new generation into the same fixed pool.
function A:RefreshAuras()
    if self.refreshing then self.refreshAgain=true;return end
    self.refreshing=true
    local ok=pcall(refreshAuras,self)
    self.refreshing=nil
    if self.refreshAgain then self.refreshAgain=nil;self.dirty=true end
    if not ok then self:Invalidate();error("PLAYER_AURA_REFRESH_FAILED",0) end
end
function A:OnEvent(event,unit)
    if event=="UNIT_AURA" then
        if not S:Text(unit) or unit=="player" then self:Invalidate() end
    elseif event=="PLAYER_LEAVING_WORLD" then self:Invalidate()
    else nativeRefresh(self);self:Invalidate();if event=="PLAYER_REGEN_ENABLED" then self.readPaused=false;self.readErrors=0 end end
end
function A:Tick(now)
    if not self.frame or not M:ModuleConfig(self.id).playerPanel or not self.layoutFits then return end
    if not self.frame:IsVisible() then
        if self.wasVisible or not self.dirty then self:Invalidate() end
        self.wasVisible=false;return
    end
    if not self.readPaused and (self.dirty or not self.wasVisible) and now>=(self.nextRefresh or 0) then
        self.dirty=false;self.nextRefresh=now+.20;self:RefreshAuras()
    end
    self.wasVisible=true
end
function A:Suspend()
    self:Invalidate();self.wasVisible=false
    M.Native:Restore(self.id)
    if self.surface then M.Effects:Stop(self.surface) end
    self.panelStatus="SUSPENDED"
end
function A:Resume() nativeRefresh(self);self:Configure() end
