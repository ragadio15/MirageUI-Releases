-- Fixed native totem/temporary-summon slots. Display only; no target or dismiss path.
local _,M=...
local R,S=M.modules.ResourceBars,M.Safety
local apply,suspend,tick,event,wants=R.ApplyConfig,R.Suspend,R.Tick,R.OnEvent,R.WantsEvent
R.events.PLAYER_TOTEM_UPDATE=true
function R:ClearTotems(reason)
 self.totemRevision=(self.totemRevision or 0)+1
 self.totemState=reason or "DISABLED"
 for _,tile in ipairs(self.totemTiles or {}) do
  tile.icon:Hide();tile.icon:SetTexture(nil)
  tile.timer:Hide();if tile.timer.Clear then pcall(tile.timer.Clear,tile.timer) end
 end
end
function R:InvalidateTotems()
 self.totemsPending=true
 self.totemEligible=false
 self.totemDirty=false
 self.totemCount=nil
 if self.totemSurface then self.totemSurface.disabled=true;M.Effects:Stop(self.totemSurface) end
 self:ClearTotems("CONFIGURATION_PENDING")
end
function R:ConfigureTotems()
 if S:InCombat() then self:InvalidateTotems();return end
 self.totemsPending=nil
 local cfg=M:ModuleConfig(self.id)
 local count,state,reason
 if cfg.totems then
  local eligible
  eligible,reason=self:ResourceContext()
  if eligible then count,state=S:Public(GetNumTotemSlots,"number") end
 else reason="DISABLED" end
 local valid=state=="KNOWN" and count%1==0 and count>=0 and count<=8
 local supported=valid and count>0 and type(GetTotemDuration)=="function"
 self.totemEligible=supported
 self.totemCount=valid and count or nil
 if not reason then
  if supported then reason="WAITING"
  elseif valid and count==0 then reason="NO_NATIVE_SLOTS"
  else reason="NATIVE_SLOTS_UNAVAILABLE" end
 end
 if supported and not self.totemFrame then
  self.totemFrame=M:TrackRoot(self.id,M.UI:Card(UIParent,300,64));self.totemFrame:Hide();self.totemTiles={}
  self.totemTitle=M.UI:Text(self.totemFrame,"Totems / temporary summons",7,-5,10,286)
  for i=1,8 do
   local tile=M.UI:Card(self.totemFrame,32,32)
   tile.icon=tile:CreateTexture(nil,"ARTWORK");tile.icon:SetPoint("TOPLEFT",2,-2);tile.icon:SetPoint("BOTTOMRIGHT",-2,2)
   tile.label=M.UI:Text(tile,tostring(i),3,-3,9,22)
   tile.timer=CreateFrame("Cooldown",nil,tile,"CooldownFrameTemplate");tile.timer:SetAllPoints(tile.icon);S:Passive(tile.timer)
   if tile.timer.SetHideCountdownNumbers then tile.timer:SetHideCountdownNumbers(true) end
   self.totemTiles[i]=tile
  end
  self.totemSurface={id="ResourceBars.totems",module=self.id,frame=self.totemFrame,security="OWNED_VISUAL",groups={combat=true},
   fallback="AMBIENT",editable=true,minWidth=24,minHeight=16,layout={x=0,y=-.07,width=300,height=64,scale=1}}
  self.totemSurface.OnLayout=function(surface,l)
   if not self:FitResourceSurface(surface,l,180,64,self.totemEligible) then
    if self.totemEligible then self.totemState="LAYOUT_DOES_NOT_FIT" end
    return
   end
   if not self.totemCount or self.totemCount==0 then return end
   local n=self.totemCount;local size=math.min(36,(l.width-14-(n-1)*5)/n)
   self.totemHeadingFit=self:FitResourceHeading(self.totemTitle,"Totems / temporary summons",l.width-14)
   for i,tile in ipairs(self.totemTiles) do
    tile:SetSize(size,size);tile:ClearAllPoints();tile:SetPoint("TOPLEFT",7+(i-1)*(size+5),-24);tile:SetShown(i<=self.totemCount)
   end
  end
  M.CVE:Register(self.totemSurface)
 end
 self:ClearTotems(reason)
 if self.totemSurface then
  self.totemSurface.disabled=true;M.state.forceEvaluate=true;M.Layout:Apply(self.totemSurface)
  -- Layout establishes geometry, not evidence that a live summon occupies a slot.
  self.totemSurface.disabled=true;M.Effects:Stop(self.totemSurface)
 end
 self.totemDirty=supported;self.totemNext=0;self.totemWasVisible=false
end
local function submitTotem(tile,i)
 return M.Display:Cooldown(tile.timer,GetTotemDuration,i)
end
function R:RefreshTotems()
 if not self.totemSurface or not self.totemEligible or not self.totemCount then return end
 local limited=false;local available=0
 local revision=self.totemRevision
 for i=1,self.totemCount do
  local tile=self.totemTiles[i];local icon
  if type(GetTotemInfo)=="function" then
   local ok,_,_,_,_,nativeIcon=pcall(GetTotemInfo,i)
   -- Presence, names, spell identity, timestamps and durations are not inspected.
   if ok and S:Number(nativeIcon) and nativeIcon>0 then icon=nativeIcon end
  end
  if revision~=self.totemRevision then return end
  tile.icon:SetTexture(icon);tile.icon:SetShown(icon~=nil)
  tile:SetShown(icon~=nil);if icon then available=available+1 end
  tile.timer:Hide()
  local sent,status=pcall(submitTotem,tile,i)
  if revision~=self.totemRevision then tile.timer:Hide();return end
  tile.timer:SetShown(sent and status=="NATIVE_WIDGET_DISPATCH")
  if not sent or status=="UNSUPPORTED" or status=="UNAVAILABLE" then limited=true end
 end
 local fits=self.totemSurface.resourceLayoutStatus=="FITS"
 self.totemSurface.disabled=available==0 or not fits
 M.state.forceEvaluate=true
 self.totemState=not fits and "LAYOUT_DOES_NOT_FIT" or available==0 and "NO_PUBLIC_ACTIVE_SLOTS" or limited and "PARTIAL_UNAVAILABLE" or "NATIVE_DURATION_DISPATCH"
end
function R:ApplyConfig() apply(self);self:ConfigureTotems() end
function R:Suspend()
 suspend(self)
 self.totemsPending=nil
 self.totemEligible=false
 self.totemDirty=false
 self.totemCount=nil
 if self.totemSurface then self.totemSurface.disabled=true;M.Effects:Stop(self.totemSurface) end
 self:ClearTotems("DISABLED")
end
function R:WantsEvent(name)
 if name=="PLAYER_TOTEM_UPDATE" then return M:ModuleConfig(self.id).totems==true end
 return not wants or wants(self,name)
end
function R:OnEvent(name,...)
 event(self,name,...)
 if name=="PLAYER_TOTEM_UPDATE" then
  if self.totemSurface and self.totemEligible then self.totemDirty=true
  elseif self.totemState=="NATIVE_SLOTS_UNAVAILABLE" or self.totemState=="NO_NATIVE_SLOTS" then
   self.totemsPending=true
  end
 end
end
function R:Tick(now)
 tick(self,now)
 if self.totemsPending and not S:InCombat() then self:ConfigureTotems() end
 if not self.totemSurface or not self.totemEligible then return end
 if self.totemDirty and now>=(self.totemNext or 0) then self.totemDirty=false;self.totemNext=now+.1;self:RefreshTotems() end
 if self.totemSurface.disabled then return end
 if not self.totemFrame:IsVisible() then self.totemWasVisible=false;return end
 if (self.totemDirty or not self.totemWasVisible) and now>=(self.totemNext or 0) then
  self.totemDirty=false;self.totemWasVisible=true;self.totemNext=now+.1;self:RefreshTotems()
 end
end
