local _,M=...
-- Manual checks and explicitly refreshed own supply/equipment/Legacy observations.
-- Observations are snapshots, not atomic/current inventory or readiness guarantees.
-- Request guards seal the observed identity and provider methods. A source-review
-- mismatch does not veto an available provider; each provider checks its APIs.
local S=M.Safety
local P={events={CINEMATIC_START=true,UI_SCALE_CHANGED=true,DISPLAY_SIZE_CHANGED=true,PLAYER_REGEN_DISABLED=true,BAG_UPDATE_DELAYED=true,ZONE_CHANGED=true,ZONE_CHANGED_INDOORS=true,ZONE_CHANGED_NEW_AREA=true,PLAYER_LEAVING_WORLD=true,PLAYER_ENTERING_WORLD=true},checked={},rows={},generation=0}
local equipmentEvents={PLAYER_EQUIPMENT_CHANGED=true,UPDATE_INVENTORY_DURABILITY=true,UPDATE_INVENTORY_ALERTS=true}
for event in pairs(equipmentEvents) do P.events[event]=true end
local detailEvents={WEAPON_ENCHANT_CHANGED=true,WEAPON_SLOT_CHANGED=true,ITEM_CHANGED=true,ITEM_DATA_LOAD_RESULT=true}
for event in pairs(detailEvents) do P.events[event]=true end
local setEvents={EQUIPMENT_SETS_CHANGED=true,EQUIPMENT_SWAP_FINISHED=true}
for event in pairs(setEvents) do P.events[event]=true end
local legacyEvents={MAJOR_FACTION_RENOWN_LEVEL_CHANGED=true,MAJOR_FACTION_UNLOCKED=true,TRAIT_CONFIG_CREATED=true,TRAIT_CONFIG_DELETED=true,TRAIT_CONFIG_LIST_UPDATED=true,TRAIT_CONFIG_UPDATED=true,TRAIT_TREE_CHANGED=true,TRAIT_TREE_CURRENCY_INFO_UPDATED=true}
for event in pairs(legacyEvents) do P.events[event]=true end
local talentEvents={ACTIVE_COMBAT_CONFIG_CHANGED=true,SELECTED_LOADOUT_CHANGED=true,PLAYER_TALENT_UPDATE=true,ACTIVE_PLAYER_SPECIALIZATION_CHANGED=true,TRAIT_NODE_CHANGED=true,TRAIT_NODE_CHANGED_PARTIAL=true,TRAIT_NODE_ENTRY_UPDATED=true,TRAIT_SUB_TREE_CHANGED=true}
for event in pairs(talentEvents) do P.events[event]=true end
local petEvents={UNIT_PET=true,SPELLS_CHANGED=true}
for event in pairs(petEvents) do P.events[event]=true end
local views={{value="manual",label="Manual"},{value="supplies",label="Supplies"},{value="gear",label="Gear"},{value="legacy",label="Legacy"},{value="sets",label="Saved sets"},{value="details",label="Gear details"},{value="talents",label="Talents"},{value="builds",label="Build references"},{value="strategies",label="Manual strategies"},{value="entries",label="Reported selected entries"},{value="legacyEntries",label="Legacy entries"},{value="pet",label="Pet spellbook"}}
local legacyTrees={{value=1187,label="Professions"},{value=1188,label="Adventure"},{value=1189,label="Progression"}}
local legacyLabels={[1187]="Professions",[1188]="Adventure",[1189]="Progression"}
local function legacySourceCurrent(constants,values)
 local ok,result=pcall(function()
  return Constants==constants and type(constants)=="table" and getmetatable(constants)==nil and rawget(constants,"LegacyConsts")==values and type(values)=="table" and getmetatable(values)==nil and rawget(values,"LEGACY_REWARD_TRACK_FACTION_ID")==2802 and rawget(values,"LEGACY_POINTS_TRAIT_CURRENCY_ID")==4225 and rawget(values,"LEGACY_TREE_PROFESSIONS_ID")==1187 and rawget(values,"LEGACY_TREE_ADVENTURE_ID")==1188 and rawget(values,"LEGACY_TREE_PROGRESSION_ID")==1189
 end)
 return ok and result==true
end
local names={"Equipment reviewed","Consumables reviewed","Camping reviewed manually","Legacy reviewed manually"}
local MAX_EXACT=9007199254740991
local function selections(cfg)
 local ids,seen={},{}
 local list=S:Field(cfg,"supplyIDs")
 if not list or type(list)~="table" then return ids end
 for i=1,9 do
  local id,state=S:FieldAccess(list,i);if state=="ABSENT" then break end
  if state~="KNOWN" or i==9 then return nil end
  if not S:Number(id) or id%1~=0 or id<1 or id>2147483647 or seen[id] then return nil end
  ids[#ids+1]=id;seen[id]=true
 end
 return ids
end
local function equipmentRows(data)
 local state=S:Field(data,"state");local input=S:Field(data,"rows")
 if (state~="OBSERVED_SNAPSHOT" and state~="PARTIAL_UNAVAILABLE") or type(input)~="table" then return nil end
 local result={};local count=M.Client.family=="Forever" and 20 or 18;local partial=false
 for i=1,count+1 do
  local row,access=S:FieldAccess(input,i)
  if i==count+1 then if access~="ABSENT" then return nil end;break end
  if access~="KNOWN" or type(row)~="table" then return nil end
  local status=S:Field(row,"state");local label=S:Field(row,"label")
  if not S:Text(label) or #label>64 or (status~="EMPTY" and status~="UNKNOWN" and status~="OBSERVED") then return nil end
  local out={label=label,state=status}
  if status=="UNKNOWN" then partial=true end
  if status=="OBSERVED" then
   local id=S:Field(row,"id");local name=S:Field(row,"name");local d=S:Field(row,"durability");local ds=S:Field(d,"state")
   if not S:Number(id) or id%1~=0 or id<1 or id>2147483647 or not S:Text(name) or #name>64 then return nil end
   if ds~="OBSERVED" and ds~="UNKNOWN" and ds~="UNSUPPORTED" and ds~="NOT_REPORTED" then return nil end
   out.id=id;out.name=name;out.durability={state=ds}
   if ds=="OBSERVED" then
    local current,maximum=S:Field(d,"current"),S:Field(d,"maximum")
    if not S:Number(current) or not S:Number(maximum) or current%1~=0 or maximum%1~=0 or current<0 or maximum<1 or maximum>2147483647 or current>maximum then return nil end
    out.durability.current=current;out.durability.maximum=maximum
   end
  end
  result[i]=out
 end
 return result,partial and "PARTIAL_UNAVAILABLE" or "OBSERVED_SNAPSHOT"
end
local function legacyRows(data)
 local state=S:Field(data,"state")
 if state~="OBSERVED_SNAPSHOT" and state~="PARTIAL_UNAVAILABLE" then return nil end
 local partial=false
 local function number(field,optional)
  local status=S:Field(field,"state")
  if status=="UNKNOWN" then partial=true;return "Unknown" end
  if optional and status=="NOT_REPORTED" then partial=true;return "Not reported" end
  local value=S:Field(field,"value")
  if status=="OBSERVED" and S:Number(value) and value%1==0 and value>=0 and value<=MAX_EXACT then return string.format("%.0f",value) end
 end
 local renown=S:Field(data,"renown");local rs=S:Field(renown,"state");local level=S:Field(renown,"level");local text
 if rs=="LOCKED" then text="Observed locked" elseif rs=="UNKNOWN" then partial=true;text="Unknown"
 elseif rs=="OBSERVED" and S:Number(level) and level%1==0 and level>=0 and level<=2147483647 then text="Level "..string.format("%.0f",level) end
 if not text then return nil end
 local points=S:Field(data,"sharedPoints");local quantity=number(S:Field(points,"quantity"));local spent=number(S:Field(points,"spent"))
 if not quantity or not spent then return nil end
 local rows={{"Legacy renown",text,"Not a readiness verdict"},{"Applied shared points","Available: "..quantity,"Total spent: "..spent}}
 local trees=S:Field(data,"trees")
 for i,label in ipairs({"Professions","Adventure","Progression"}) do
  local tree=S:Field(trees,i);local value=number(S:Field(tree,"spentInTree"),true)
  if S:Field(tree,"treeID")~=1186+i or not value then return nil end
  rows[i+2]={label,"Applied in tree:",value}
 end
 local _,extra=S:FieldAccess(trees,4);if extra~="ABSENT" then return nil end
 return rows,partial and "PARTIAL_UNAVAILABLE" or "OBSERVED_SNAPSHOT"
end
local function setCards(data)
 local state=S:Field(data,"state");local rows=S:Field(data,"rows")
 if state~="OBSERVED_EMPTY" and state~="OBSERVED_SNAPSHOT" and state~="PARTIAL_UNAVAILABLE" then return nil end
 if not S:Readable(rows) or type(rows)~="table" then return nil end
 local ok,meta=pcall(getmetatable,rows);if not ok or not S:Readable(meta) or meta~=nil then return nil end
 local count,key=0
 for i=1,65 do
  local good,k=pcall(next,rows,key);if not good or not S:Readable(k) then return nil end
  if k==nil then break end
  if i==65 or not S:Number(k) or k%1~=0 or k<1 or k>64 then return nil end
  count=count+1;key=k
 end
 local cards,seen,partial={},{},false
 local function quantity(counts,field)
  local row=S:Field(counts,field);local status=S:Field(row,"state");local value=S:Field(row,"value")
  if status=="UNKNOWN" then partial=true;return "Unknown" end
  if status=="OBSERVED" and S:Number(value) and value%1==0 and value>=0 and value<=2147483647 then return string.format("%.0f",value) end
 end
 for i=1,count do
  local row=S:Field(rows,i);local id=S:Field(row,"id");local status=S:Field(row,"state")
  if not S:Number(id) or id%1~=0 or id<0 or id>2147483647 or seen[id] or (status~="OBSERVED" and status~="UNKNOWN") then return nil end
  seen[id]=true;local identity="Set #"..string.format("%.0f",id);local name=identity;local equipped="Unknown";local values={}
  if status=="UNKNOWN" then partial=true;for j=1,5 do values[j]="Unknown" end
  else
   name=S:Field(row,"name")
   if not S:Text(name) or #name>64 or name:find("[%c|]") then return nil end
   local e=S:Field(row,"equipped");local es=S:Field(e,"state");local value=S:Field(e,"value")
   if es=="OBSERVED" and type(value)=="boolean" then equipped=value and "Yes" or "No" elseif es=="UNKNOWN" then partial=true else return nil end
   local counts=S:Field(row,"counts")
   for j,field in ipairs({"numItems","numEquipped","numInInventory","numLost","numIgnored"}) do values[j]=quantity(counts,field);if not values[j] then return nil end end
  end
  cards[#cards+1]={identity,name,"Native equipped: "..equipped}
  cards[#cards+1]={identity.." · counts","Items: "..values[1],"Equipped: "..values[2]}
  cards[#cards+1]={identity.." · counts","Inventory: "..values[3],"Lost: "..values[4]}
  cards[#cards+1]={identity.." · counts","Ignored: "..values[5],"Sequential snapshot"}
 end
 if count==0 then if state~="OBSERVED_EMPTY" then return nil end;return cards,"OBSERVED_EMPTY" end
 if state=="OBSERVED_EMPTY" then return nil end
 return cards,partial and "PARTIAL_UNAVAILABLE" or "OBSERVED_SNAPSHOT"
end
local function detailCards(data)
 if S:Field(data,"details")~=true then return nil end
 local equipment,state=equipmentRows(data);if not equipment then return nil end
 local cards={};local input=S:Field(data,"rows")
 for i,row in ipairs(equipment) do
  if row.state=="UNKNOWN" then cards[#cards+1]={row.label,"Item identity unknown","No joined details observed"}
  elseif row.state=="EMPTY" then cards[#cards+1]={row.label,"Empty (observed)","No item details"}
  else
   local identity=row.label.." · Item #"..row.id;local d=row.durability
   local condition=d.state=="OBSERVED" and ("Durability "..d.current.." / "..d.maximum) or d.state=="NOT_REPORTED" and "Durability not reported" or d.state=="UNSUPPORTED" and "Durability unavailable here" or "Durability unknown"
   cards[#cards+1]={identity,row.name,condition}
   local source=S:Field(input,i);local spell=S:Field(source,"associatedSpell");local ss=S:Field(spell,"state")
   local label,description="Associated spell","Unknown"
   if ss=="OBSERVED" then
    local id,name=S:Field(spell,"id"),S:Field(spell,"name")
    if not S:Number(id) or id%1~=0 or id<1 or id>2147483647 or not S:Text(name) or #name>64 or name:find("[%c|]") then return nil end
    label="Associated spell #"..id;description=name
   elseif ss=="NOT_REPORTED" then description="Not reported"
   elseif ss=="UNSUPPORTED" then description="Unavailable";state="PARTIAL_UNAVAILABLE"
   elseif ss=="UNKNOWN" then state="PARTIAL_UNAVAILABLE" else return nil end
   cards[#cards+1]={identity,label,description}
   local enchant=S:Field(source,"temporaryEnchant");local es=S:Field(enchant,"state")
   label,description="Temporary enchant","Unknown"
   if es=="OBSERVED" then
    local id=S:Field(enchant,"id");if not S:Number(id) or id%1~=0 or id<1 or id>2147483647 then return nil end
    label="Temporary enchant #"..id;description="Observed; not a spell ID"
   elseif es=="ABSENT" then description="No active enchant reported"
   elseif es=="UNSUPPORTED" then
    local weapon=i==17 or i==18 or M.Client.family=="Forever" and i==19
    description=weapon and "Unavailable" or "Not inspected for this slot"
    if weapon then state="PARTIAL_UNAVAILABLE" end
   elseif es=="UNKNOWN" then state="PARTIAL_UNAVAILABLE" else return nil end
   cards[#cards+1]={identity,label,description}
  end
 end
 return cards,state
end
local function talentCards(data)
 local state=S:Field(data,"state")
 if state~="OBSERVED_SNAPSHOT" and state~="PARTIAL_UNAVAILABLE" then return nil end
 local partial=false
 local function config(input)
  local status=S:Field(input,"state");local out={state=status}
  if status=="NOT_REPORTED" then partial=true;out.label="Not reported";return out end
  if status=="UNKNOWN" or status=="UNSUPPORTED" then partial=true;out.label="Unknown";return out end
  if status~="OBSERVED" then return nil end
  local id=S:Field(input,"id")
  if not S:Number(id) or id%1~=0 or id<0 or id>2147483647 then return nil end
  out.id=id;out.label="Config #"..string.format("%.0f",id)
  local metadata=S:Field(input,"metadata");local ms=S:Field(metadata,"state")
  if ms=="OBSERVED" then
   local name=S:Field(metadata,"name")
   if not S:Text(name) or #name<1 or #name>64 or name:find("[%c|]") then return nil end
   out.name=name
  elseif ms=="UNKNOWN" then partial=true;out.name="Configuration name unavailable" else return nil end
  local staged=S:Field(input,"staged");local ss=S:Field(staged,"state")
  if ss=="OBSERVED" then
   local value=S:Field(staged,"value")
   if not S:Readable(value) or type(value)~="boolean" then return nil end
   out.staged=value and "Reported" or "None reported"
  elseif ss=="UNKNOWN" then partial=true;out.staged="Unknown" else return nil end
  return out
 end
 local common=config(S:Field(data,"common"));if not common then return nil end
 local group,gc,association
 if M.Client.family=="Forever" then
  group=S:Field(data,"group");local gs=S:Field(group,"state");local index=S:Field(group,"index")
  if gs=="OBSERVED" then if index~=1 and index~=2 then return nil end
  elseif gs=="UNKNOWN" or gs=="UNSUPPORTED" then partial=true;index=nil else return nil end
  gc=config(S:Field(group,"config"));if not gc then return nil end
  if not index and gc.state~="UNKNOWN" and gc.state~="UNSUPPORTED" then return nil end
  group=index==1 and "Primary" or index==2 and "Secondary" or "Unknown"
  association=common.id~=nil and gc.id~=nil and (common.id==gc.id and "MATCH" or "CONFLICT") or common.id==nil and gc.id~=nil and "COMMON_NOT_ESTABLISHED" or "UNKNOWN"
  if S:Field(data,"association")~=association then return nil end
 end
 local conflict=association=="CONFLICT";if conflict then partial=true end
 local cards={{"Active config (reported)",common.label,conflict and "Conflicting config observations" or common.name or "Common API snapshot only"}}
 if common.id~=nil and not conflict then cards[#cards+1]={common.label.." · staged edits",common.staged,"Snapshot; not applied-build proof"} end
 if group then
  cards[#cards+1]={"Active group: "..group,gc.id~=nil and "Group config #"..gc.id or gc.label,association=="MATCH" and "Matches common" or conflict and "Conflicting config observations" or association=="COMMON_NOT_ESTABLISHED" and "Common not established" or "Association unknown"}
  if gc.id~=nil and common.id==nil then
   local label="Group config #"..gc.id
   cards[#cards+1]={label,gc.name,"Active-group observation only"}
   cards[#cards+1]={label.." · staged edits",gc.staged,"Snapshot; not applied-build proof"}
  end
 end
 return cards,partial and "PARTIAL_UNAVAILABLE" or "OBSERVED_SNAPSHOT"
end
local function dimensions(gear,legacy,treeChoice)
 local scale=M.profile.textScale or 1
 local button=math.ceil(28*scale);local row=math.ceil((gear and 84 or 32)*scale)
 local action=legacy and button+8 or 0
 local hint=math.ceil(48*scale)+button+8+(treeChoice and button+8 or 0);local top=hint+math.ceil(34*scale)+6
 local w,ws=S:Public(UIParent.GetWidth,"number",UIParent);local h,hs=S:Public(UIParent.GetHeight,"number",UIParent)
 if ws~="KNOWN" or hs~="KNOWN" then return nil end
 w=math.min(430,w-30);h=math.min(treeChoice and 500 or gear and 430 or 310,h-30)
 if w<330 or h<top+row+8+12+button+action then return nil end
 return w,h,button,row,hint,top,action
end
function P:CanInteract(widget)
 return M:IsModuleActive(self.id) and not M.state.cinematic and not S:InCombat() and self.frame and self.frame:IsShown() and (not widget or widget:IsShown())
end
function P:Initialize() self.status="MANUAL_CHECKLIST_AVAILABLE" end
function P:CloseViewChoice()
 local popup=M.UI.choices;local token=self.viewChoiceToken;self.viewChoiceToken=nil
 if token and popup and popup.choiceToken==token and popup.dialogAnchor and popup.dialogAnchor.frame==self.viewChoice then popup:Hide() end
end
function P:CloseLegacyTreeChoice()
 local popup=M.UI.choices;local token=self.legacyTreeToken;self.legacyTreeToken=nil
 if token and popup and popup.choiceToken==token and popup.dialogAnchor and popup.dialogAnchor.frame==self.legacyTreeChoice then popup:Hide() end
end
function P:Invalidate(reason)
 self.petSpellbook=nil;self.petSpellbookStatus=reason or "NOT_CHECKED"
 if M.PetSpellbook then pcall(M.PetSpellbook.Invalidate,M.PetSpellbook) end
 self.inspectionRequest=nil;self.legacyTree=nil
 if M.ReferenceView then M.ReferenceView:Close() end
 self.generation=self.generation+1;self:CloseViewChoice();self:CloseLegacyTreeChoice();self.observations=nil;self.observationStatus=reason or "NOT_CHECKED"
 self.equipment=nil;self.equipmentStatus=reason or "NOT_CHECKED";M.Equipment:Invalidate()
 self.legacy=nil;self.legacyStatus=reason or "NOT_CHECKED";M.Legacy:Invalidate()
 self.sets=nil;self.setsStatus=reason or "NOT_CHECKED";M.EquipmentSets:Invalidate()
 self.details=nil;self.detailsStatus=reason or "NOT_CHECKED"
 self.talents=nil;self.talentsStatus=reason or "NOT_CHECKED";M.Talents:Invalidate()
 self.talentEntries=nil;self.talentEntriesStatus=reason or "NOT_CHECKED";M.TalentEntries:Invalidate()
 self.legacyEntries=nil;self.legacyEntriesStatus=reason or "NOT_CHECKED";M.LegacyEntries:Invalidate()
 for _,line in ipairs(self.gearRows or {}) do
  for _,cell in ipairs({line,line.nameText,line.conditionText}) do cell:SetText("");cell:Hide() end
 end
 for _,line in ipairs(self.supplyRows or {}) do line:SetText("");line:Hide() end
 if self.frame and self.frame:IsShown() then self:Render() end
end
function P:RefreshSupplies()
 if not M:IsModuleActive(self.id) or S:InCombat() or not self.frame or not self.frame:IsShown() then self:Invalidate("UNAVAILABLE");return false end
 self:Invalidate("NOT_CHECKED")
 local cfg=M:ModuleConfig(self.id);local ids=selections(cfg);local generation=self.generation
 if not ids or #ids==0 then self:Render();return false end
 local ok,data=pcall(M.Inventory.Read,M.Inventory,"",nil,"carried")
 local result={};for _,id in ipairs(ids) do result[id]={subtotal=0,valid=true} end
 local state=ok and S:Field(data,"state");local source=ok and S:Field(data,"source")
 local items=ok and S:Field(data,"items");local complete=state=="PUBLIC_INVENTORY" and source=="carried"
 if source~="carried" or (state~="PUBLIC_INVENTORY" and state~="PARTIAL_UNAVAILABLE") or not S:Readable(items) or type(items)~="table" then
  complete=false
 else
  for index=1,513 do
   local item,access=S:FieldAccess(items,index)
   if access=="ABSENT" then break end
   if access~="KNOWN" or index==513 then complete=false;break end
   local id=S:Field(item,"id")
   if not S:Number(id) or id%1~=0 or id<=0 then complete=false
   else
    local row=result[id]
    if row then
     local count=S:Field(item,"count")
     if not S:Number(count) or count%1~=0 or count<1 or count>MAX_EXACT or count>MAX_EXACT-row.subtotal then row.valid=false
     else row.subtotal=row.subtotal+count end
    end
   end
  end
 end
 -- Reentrant callbacks cannot publish into another visibility/configuration epoch.
 local eligible=M:IsModuleActive(self.id) and not S:InCombat() and self.frame and self.frame:IsShown()
 local current=selections(M:ModuleConfig(self.id));local same=current and #current==#ids
 if same then for i,id in ipairs(ids) do if current[i]~=id then same=false;break end end end
 -- Eligibility calls can themselves reenter: only the still-current owner may invalidate.
 if self.generation~=generation then return false end
 if cfg~=M:ModuleConfig(self.id) or not same or not eligible then
  self:Invalidate("NOT_CHECKED");return false
 end
 local allKnown=complete
 for _,row in pairs(result) do if complete and row.valid then row.count=row.subtotal else allKnown=false end;row.valid=nil end
 self.observations=result;self.observationStatus=allKnown and "OBSERVED_SNAPSHOT" or "PARTIAL_UNAVAILABLE";self:Render();return true
end
function P:InvalidateGear(reason,requestCurrent)
 local function current() return not requestCurrent or requestCurrent() end
 if not current() then return false end
 self.petSpellbook=nil;self.petSpellbookStatus=reason or "NOT_CHECKED"
 if M.ReferenceView then M.ReferenceView:Close() end
 if not current() then return false end
 self.generation=self.generation+1;self:CloseViewChoice();if not current() then return false end
 self:CloseLegacyTreeChoice();if not current() then return false end
 self.equipment=nil;self.equipmentStatus=reason or "NOT_CHECKED"
 self.legacy=nil;self.legacyStatus=reason or "NOT_CHECKED"
 self.sets=nil;self.setsStatus=reason or "NOT_CHECKED"
 self.details=nil;self.detailsStatus=reason or "NOT_CHECKED"
 self.talents=nil;self.talentsStatus=reason or "NOT_CHECKED"
 self.talentEntries=nil;self.talentEntriesStatus=reason or "NOT_CHECKED"
 self.legacyEntries=nil;self.legacyEntriesStatus=reason or "NOT_CHECKED"
 for _,provider in ipairs({M.Equipment,M.Legacy,M.EquipmentSets,M.Talents,M.TalentEntries,M.LegacyEntries,M.PetSpellbook}) do
  provider:Invalidate();if not current() then return false end
 end
 for _,line in ipairs(self.gearRows or {}) do
  for _,cell in ipairs({line,line.nameText,line.conditionText}) do
   cell:SetText("");if not current() then return false end
   cell:Hide();if not current() then return false end
  end
 end
 return true
end
function P:RefreshEquipment()
 if not self:CanInteract() or self.view~="gear" then return false end
 self:InvalidateGear("NOT_CHECKED");self:Render()
 if not self:CanInteract() or self.view~="gear" then return false end
 local generation,cfg,client=self.generation,M:ModuleConfig(self.id),M.Client.key
 local ok,data=pcall(M.Equipment.Read,M.Equipment)
 local rows,state;if ok then rows,state=equipmentRows(data) end
 local epoch,context,resultClient=S:Field(data,"epoch"),S:Field(data,"contextEpoch"),S:Field(data,"client")
 local valid=self:CanInteract();local allowed=M.Equipment:Allowed()
 if not allowed or not valid or not M:IsModuleActive(self.id) or self.generation~=generation or self.view~="gear" or cfg~=M:ModuleConfig(self.id) or client~=M.Client.key then return false end
 if not rows then self.equipmentStatus="UNAVAILABLE";self:Render();return false end
 if epoch~=M.Equipment.epoch or context~=M.Policy.contextEpoch or resultClient~=client then return false end
 self.equipment=rows;self.equipmentStatus=state;self:Render();return true
end
function P:RefreshLegacy()
 if not self:CanInteract() or self.view~="legacy" then return false end
 self:InvalidateGear("NOT_CHECKED");self:Render()
 if not self:CanInteract() or self.view~="legacy" then return false end
 local generation,cfg,client=self.generation,M:ModuleConfig(self.id),M.Client.key
 local function current()
  return self:CanInteract() and self.generation==generation and self.view=="legacy" and cfg==M:ModuleConfig(self.id) and client==M.Client.key
 end
 local ok,data=pcall(M.Legacy.Read,M.Legacy,current)
 local rows,state;if ok then rows,state=legacyRows(data) end
 local epoch,context,resultClient=S:Field(data,"epoch"),S:Field(data,"contextEpoch"),S:Field(data,"client")
 local valid=current();local allowed=M.Legacy:Allowed()
 if not valid or not M:IsModuleActive(self.id) or self.generation~=generation or self.view~="legacy" or cfg~=M:ModuleConfig(self.id) or client~=M.Client.key then return false end
 if not allowed then self.legacyStatus="UNAVAILABLE";self:Render();return false end
 if not rows then self.legacyStatus="UNAVAILABLE";self:Render();return false end
 if epoch~=M.Legacy.epoch or context~=M.Policy.contextEpoch or resultClient~=client then return false end
 self.legacy=rows;self.legacyStatus=state;self:Render();return true
end
function P:RefreshSets()
 if not self:CanInteract() or self.view~="sets" then return false end
 self:InvalidateGear("NOT_CHECKED");self:Render()
 if not self:CanInteract() or self.view~="sets" then return false end
 local generation,cfg,client=self.generation,M:ModuleConfig(self.id),M.Client.key
 local function current()
  return self:CanInteract() and self.generation==generation and self.view=="sets" and cfg==M:ModuleConfig(self.id) and client==M.Client.key
 end
 local ok,data=pcall(M.EquipmentSets.Read,M.EquipmentSets,current)
 local cards,state;if ok then cards,state=setCards(data) end
 local epoch,context,resultClient=S:Field(data,"epoch"),S:Field(data,"contextEpoch"),S:Field(data,"client")
 local valid=current();local allowed=M.EquipmentSets:Allowed()
 if not valid or not M:IsModuleActive(self.id) or self.generation~=generation or self.view~="sets" or cfg~=M:ModuleConfig(self.id) or client~=M.Client.key then return false end
 if not allowed or not cards then self.setsStatus="UNAVAILABLE";self:Render();return false end
 if epoch~=M.EquipmentSets.epoch or context~=M.Policy.contextEpoch or resultClient~=client then return false end
 self.sets=cards;self.setsStatus=state;self:Render();return true
end
function P:RefreshDetails()
 if not self:CanInteract() or self.view~="details" then return false end
 self:InvalidateGear("NOT_CHECKED");self:Render()
 if not self:CanInteract() or self.view~="details" then return false end
 local generation,cfg,client=self.generation,M:ModuleConfig(self.id),M.Client.key
 local function current()
  return self:CanInteract() and self.generation==generation and self.view=="details" and cfg==M:ModuleConfig(self.id) and client==M.Client.key
 end
 local ok,data=pcall(M.Equipment.ReadDetails,M.Equipment,current)
 local cards,state;if ok then cards,state=detailCards(data) end
 local epoch,context,resultClient=S:Field(data,"epoch"),S:Field(data,"contextEpoch"),S:Field(data,"client")
 local valid=current();local allowed=M.Equipment:Allowed()
 if not valid or not M:IsModuleActive(self.id) or self.generation~=generation or self.view~="details" or cfg~=M:ModuleConfig(self.id) or client~=M.Client.key then return false end
 if not allowed or not cards then self.detailsStatus="UNAVAILABLE";self:Render();return false end
 if epoch~=M.Equipment.epoch or context~=M.Policy.contextEpoch or resultClient~=client then return false end
 self.details=cards;self.detailsStatus=state;self:Render();return true
end
function P:RefreshTalents()
 if self.constructing then return false end
 if self.view~="talents" or not self.frame then return false end
 local token={};self.inspectionRequest=token;local preparing=true
 local generation,cfg,client,provider=self.generation+1,M:ModuleConfig(self.id),M.Client,M.Talents
 local providerEpoch=provider.epoch+1
 local providerAllowed=provider.Allowed
 local key,adapter,source,context=client.key,M.adapter,M.adapter.sourceCommit,M.Policy.contextEpoch
 local capability,scope=M.Policy.capabilityEpoch,M.Policy.scopeEpoch
 local frame,profile=self.frame,M.profile;local identity={client.family,client.patch,client.build,client.interface,client.experimental,adapter.family,adapter.patch,adapter.build,adapter.interface}
 local function pure()
  return self.inspectionRequest==token and provider.Allowed==providerAllowed and M:IsModuleActive(self.id) and not M.state.cinematic and not M.state.safe and M.state.world and M.profile==profile and self.frame==frame and (self.generation==generation or preparing and self.generation==generation-1) and self.view=="talents" and cfg==M:ModuleConfig(self.id) and M.Client==client and client.key==key and client.allowed and M.adapter==adapter and adapter.sourceCommit==source and M.Policy.contextEpoch==context and M.Policy.capabilityEpoch==capability and M.Policy.scopeEpoch==scope and M.Talents==provider and (provider.epoch==providerEpoch or preparing and provider.epoch==providerEpoch-1) and client.family==identity[1] and client.patch==identity[2] and client.build==identity[3] and client.interface==identity[4] and client.experimental==identity[5] and adapter.family==identity[6] and adapter.patch==identity[7] and adapter.build==identity[8] and adapter.interface==identity[9]
 end
 local function current()
  if not pure() then return false end
  local shown=frame:IsShown();if not shown or not pure() then return false end
  local combat=S:InCombat();return not combat and pure()
 end
 if not current() then return false end
 if not self:InvalidateGear("NOT_CHECKED",pure) then return false end
 preparing=false
 if not pure() or not self:Render(pure) or not current() then return false end
 local ok,data=pcall(provider.Read,provider,current)
 local cards,state;if ok then cards,state=talentCards(data) end
 local epoch,resultContext,resultClient=S:Field(data,"epoch"),S:Field(data,"contextEpoch"),S:Field(data,"client")
 local valid=current();local gateOK,gateValue=pcall(providerAllowed,provider)
 local allowed=gateOK and type(gateValue)=="boolean" and gateValue==true
 if not valid or not pure() then return false end
 if not allowed or not cards then self.talentsStatus="UNAVAILABLE";self:Render(pure);return false end
 if epoch~=provider.epoch or resultContext~=context or resultClient~=key then return false end
 self.talents=cards;self.talentsStatus=state;return self:Render(pure)
end
function P:RefreshTalentEntries()
 if self.constructing then return false end
 if self.view~="entries" or not self.frame then return false end
 local token={};self.inspectionRequest=token;local preparing=true
 local generation,cfg,client,provider=self.generation+1,M:ModuleConfig(self.id),M.Client,M.TalentEntries
 local baseProvider,baseEpoch,providerEpoch=M.Talents,M.Talents.epoch+1,provider.epoch+1
 local providerAllowed=provider.Allowed
 local key,adapter,source,context=client.key,M.adapter,M.adapter.sourceCommit,M.Policy.contextEpoch
 local capability,scope=M.Policy.capabilityEpoch,M.Policy.scopeEpoch
 local frame,profile=self.frame,M.profile;local identity={client.family,client.patch,client.build,client.interface,client.experimental,adapter.family,adapter.patch,adapter.build,adapter.interface}
 local function pure()
  return self.inspectionRequest==token and provider.Allowed==providerAllowed and M:IsModuleActive(self.id) and not M.state.cinematic and not M.state.safe and M.state.world and M.profile==profile and self.frame==frame and (self.generation==generation or preparing and self.generation==generation-1) and self.view=="entries" and cfg==M:ModuleConfig(self.id) and M.Client==client and client.key==key and client.allowed and M.adapter==adapter and adapter.sourceCommit==source and M.Policy.contextEpoch==context and M.Policy.capabilityEpoch==capability and M.Policy.scopeEpoch==scope and M.TalentEntries==provider and (provider.epoch==providerEpoch or preparing and provider.epoch==providerEpoch-1) and M.Talents==baseProvider and (baseProvider.epoch==baseEpoch or preparing and baseProvider.epoch==baseEpoch-1) and client.family==identity[1] and client.patch==identity[2] and client.build==identity[3] and client.interface==identity[4] and client.experimental==identity[5] and adapter.family==identity[6] and adapter.patch==identity[7] and adapter.build==identity[8] and adapter.interface==identity[9]
 end
 local function current()
  if not pure() then return false end
  local shown=frame:IsShown();if not shown or not pure() then return false end
  local combat=S:InCombat();return not combat and pure()
 end
 if not current() then return false end
 if not self:InvalidateGear("NOT_CHECKED",pure) then return false end
 preparing=false
 if not pure() or not self:Render(pure) or not current() then return false end
 local ok,data=pcall(provider.Read,provider,current)
 local cards,state,unchanged
 if ok then
  local intake,a,b,c=pcall(M.TalentEntryCards,M,data,pure)
  if intake then cards,state,unchanged=a,b,c end
 end
 local epoch,resultContext,resultClient=S:Field(data,"epoch"),S:Field(data,"contextEpoch"),S:Field(data,"client")
 local valid=current();local gateOK,gateValue=pcall(providerAllowed,provider)
 local allowed=gateOK and type(gateValue)=="boolean" and gateValue==true
 if not valid or not pure() then return false end
 if not allowed or not cards or not unchanged() then self.talentEntriesStatus="UNAVAILABLE";self:Render(pure);return false end
 if epoch~=provider.epoch or resultContext~=context or resultClient~=key then return false end
 self.talentEntries=cards;self.talentEntriesStatus=state;return self:Render(pure) and state~="UNAVAILABLE"
end
function P:RefreshLegacyEntries()
 if self.constructing then return false end
 local treeID=self.legacyTree
 if self.view~="legacyEntries" or not self.frame or not legacyLabels[treeID] then return false end
 local token={};self.inspectionRequest=token;local preparing=true
 local generation,cfg,client,provider=self.generation+1,M:ModuleConfig(self.id),M.Client,M.LegacyEntries
 local providerAllowed=provider.Allowed
 local baseProvider,baseEpoch,providerEpoch=M.Legacy,M.Legacy.epoch+1,provider.epoch+1
 local baseAllowed,baseConstants=baseProvider.Allowed,baseProvider.ConstantsValid
 local constants,values=Constants,Constants and Constants.LegacyConsts
 local key,adapter,source,context=client.key,M.adapter,M.adapter.sourceCommit,M.Policy.contextEpoch
 local capability,scope=M.Policy.capabilityEpoch,M.Policy.scopeEpoch
 local frame,profile=self.frame,M.profile;local identity={client.family,client.patch,client.build,client.interface,client.experimental,adapter.family,adapter.patch,adapter.build,adapter.interface}
 local function pure()
  return self.inspectionRequest==token and M:IsModuleActive(self.id) and not M.state.cinematic and not M.state.safe and M.state.world and M.profile==profile and self.frame==frame and (self.generation==generation or preparing and self.generation==generation-1) and self.view=="legacyEntries" and cfg==M:ModuleConfig(self.id) and M.Client==client and client.key==key and client.allowed and M.adapter==adapter and adapter.sourceCommit==source and M.Policy.contextEpoch==context and M.Policy.capabilityEpoch==capability and M.Policy.scopeEpoch==scope and M.LegacyEntries==provider and provider.Allowed==providerAllowed and (provider.epoch==providerEpoch or preparing and provider.epoch==providerEpoch-1) and M.Legacy==baseProvider and (baseProvider.epoch==baseEpoch or preparing and baseProvider.epoch==baseEpoch-1) and baseProvider.Allowed==baseAllowed and baseProvider.ConstantsValid==baseConstants and self.legacyTree==treeID and legacySourceCurrent(constants,values) and client.family==identity[1] and client.patch==identity[2] and client.build==identity[3] and client.interface==identity[4] and client.experimental==identity[5] and adapter.family==identity[6] and adapter.patch==identity[7] and adapter.build==identity[8] and adapter.interface==identity[9]
 end
 local function current()
  if not pure() then return false end
  local shown=frame:IsShown();if not shown or not pure() then return false end
  local combat=S:InCombat();return not combat and pure()
 end
 if not current() then return false end
 if not self:InvalidateGear("NOT_CHECKED",pure) then return false end
 preparing=false
 if not pure() or not self:Render(pure) or not current() then return false end
 local ok,data=pcall(provider.Read,provider,treeID,current)
 local cards,state,unchanged
 if ok then
  local intake,a,b,c=pcall(M.LegacyEntryCards,M,data,pure,treeID)
  if intake then cards,state,unchanged=a,b,c end
 end
 local epoch,resultContext,resultClient=S:Field(data,"epoch"),S:Field(data,"contextEpoch"),S:Field(data,"client")
 local valid=current();local gateOK,gateValue=pcall(providerAllowed,provider)
 local allowed=gateOK and type(gateValue)=="boolean" and gateValue==true
 if not valid or not pure() then return false end
 if not allowed or not cards or not unchanged() then self.legacyEntriesStatus="UNAVAILABLE";self:Render(pure);return false end
 if epoch~=provider.epoch or resultContext~=context or resultClient~=key then return false end
 self.legacyEntries=cards;self.legacyEntriesStatus=state;return self:Render(pure) and state~="UNAVAILABLE"
end
function P:RefreshPetSpellbook()
 if self.constructing then return false end
 if self.view~="pet" or not self.frame then return false end
 local token={};self.inspectionRequest=token;local preparing=true
 local profile,frame,client,adapter=M.profile,self.frame,M.Client,M.adapter
 local cfg=profile and profile.modules and profile.modules[self.id]
 local provider=M.PetSpellbook;local allowed,read=provider.Allowed,provider.Read
 local cardsMethod=M.PetSpellbookCards
 local generation,epoch=self.generation+1,provider.epoch+1
 local context,capability,scope=M.Policy.contextEpoch,M.Policy.capabilityEpoch,M.Policy.scopeEpoch
 local identity={client.key,client.family,client.patch,client.build,client.interface,client.experimental,adapter.family,adapter.patch,adapter.build,adapter.interface,adapter.sourceCommit}
 -- Pure request callback: no visibility, security or combat/native probes here.
 local function pure()
  local ok,value=pcall(function()
   return self.inspectionRequest==token and M.modules.Preparations==self and self.initialized and not self.suspended and not self.quarantined and M.state.initialized and M.state.world and not M.state.safe and not M.state.cinematic and M.profile==profile and profile.enabled and profile.modules[self.id]==cfg and cfg.enabled==true and self.frame==frame and self.view=="pet" and M.DialogNavigation.top==frame and (self.generation==generation or preparing and self.generation==generation-1) and M.PetSpellbook==provider and provider.Allowed==allowed and provider.Read==read and M.PetSpellbookCards==cardsMethod and (provider.epoch==epoch or preparing and provider.epoch==epoch-1) and M.Client==client and M.adapter==adapter and client.allowed and client.key==identity[1] and client.family==identity[2] and client.patch==identity[3] and client.build==identity[4] and client.interface==identity[5] and client.experimental==identity[6] and adapter.family==identity[7] and adapter.patch==identity[8] and adapter.build==identity[9] and adapter.interface==identity[10] and adapter.sourceCommit==identity[11] and M.Policy.contextEpoch==context and M.Policy.capabilityEpoch==capability and M.Policy.scopeEpoch==scope
  end)
  return ok and value==true
 end
 local function retire()
  local function owned() return self.inspectionRequest==token and self.frame==frame and self.view=="pet" end
  if not owned() then return false end
  self.petSpellbook=nil;self.petSpellbookStatus="UNAVAILABLE"
  for _,row in ipairs(self.gearRows or {}) do for _,cell in ipairs({row,row.nameText,row.conditionText}) do
   if not owned() then return false end
   pcall(cell.SetText,cell,"");if not owned() then return false end
   pcall(cell.Hide,cell)
  end end
  return false
 end
 self.petSpellbook=nil;self.petSpellbookStatus="NOT_CHECKED"
 local function eligible()
  if not pure() then return false end
  local ok,value=pcall(frame.IsShown,frame);if not ok or value~=true or not pure() then return false end
  if S:Typing() or not pure() then return false end
  local gate,result=pcall(allowed,provider)
  if not gate or type(result)~="boolean" or not result or not pure() then return false end
  local combat=S:InCombat();return not combat and pure()
 end
 if not eligible() then return retire() end
 local clean,result=pcall(self.InvalidateGear,self,"NOT_CHECKED",pure)
 if not clean or not result then return retire() end
 preparing=false
 if not pure() or not self:Render(pure) or not eligible() then return retire() end
 local ok,data=pcall(read,provider,pure)
 local cards,state,unchanged,snapshot
 if ok then local intake,a,b,c,d=pcall(cardsMethod,M,data,pure);if intake then cards,state,unchanged,snapshot=a,b,c,d end end
 if not eligible() or not pure() then return retire() end
 if not cards or not unchanged() then self.petSpellbookStatus="UNAVAILABLE";self:Render(pure);return false end
 if snapshot.epoch~=epoch or snapshot.contextEpoch~=context or snapshot.client~=identity[1] then return retire() end
 self.petSpellbook=cards;self.petSpellbookStatus=state
 if not self:Render(pure) then return retire() end
 return (state=="OBSERVED_SCOPED_SNAPSHOT" or state=="PARTIAL_UNAVAILABLE" or state=="OBSERVED_SCOPED_EMPTY" or state=="PET_BOOK_NOT_REPORTED")
end
function P:SetLegacyTree(treeID)
 if self.view~="legacyEntries" or not legacyLabels[treeID] then return false end
 local generation,profile,frame,previous=self.generation,M.profile,self.frame,self.legacyTree
 local client,adapter,context,capability,scope=M.Client,M.adapter,M.Policy.contextEpoch,M.Policy.capabilityEpoch,M.Policy.scopeEpoch
 if not self:CanInteract() or self.generation~=generation or M.profile~=profile or self.frame~=frame or self.view~="legacyEntries" or self.legacyTree~=previous or M.Client~=client or M.adapter~=adapter or M.Policy.contextEpoch~=context or M.Policy.capabilityEpoch~=capability or M.Policy.scopeEpoch~=scope then return false end
 self.legacyTree=treeID;self.page=1
 return self:RefreshLegacyEntries()
end
function P:InspectTalents(widget)
 if widget~=self.nativeTalents or not self:CanInteract(widget) or not widget:IsVisible() or (self.view~="talents" and self.view~="entries") or not M.Talents:Allowed() then return false end
 local view=self.view
 local frame,button,provider,router=self.frame,self.nativeTalents,M.Talents,M.ClientUI
 local cfg,profile,client,adapter=M:ModuleConfig(self.id),M.profile,M.Client,M.adapter
 local key,source,context,generation=client.key,adapter.sourceCommit,M.Policy.contextEpoch,self.generation
 local capability,scope=M.Policy.capabilityEpoch,M.Policy.scopeEpoch
 local route=router and router.Route;local util=PlayerSpellsUtil
 local identity={client.family,client.patch,client.build,client.interface,client.experimental,adapter.family,adapter.patch,adapter.build,adapter.interface}
 local function sourceCurrent()
  return client.family==identity[1] and client.patch==identity[2] and client.build==identity[3] and client.interface==identity[4] and client.experimental==identity[5] and adapter.family==identity[6] and adapter.patch==identity[7] and adapter.build==identity[8] and adapter.interface==identity[9]
 end
 local function pure()
  return M:IsModuleActive(self.id) and not M.state.safe and not M.state.cinematic and M.profile==profile and M:ModuleConfig(self.id)==cfg and M.Client==client and client.key==key and client.allowed and M.adapter==adapter and adapter.sourceCommit==source and M.Policy.contextEpoch==context and M.Policy.capabilityEpoch==capability and M.Policy.scopeEpoch==scope and self.frame==frame and self.nativeTalents==button and self.view==view and self.generation==generation and M.Talents==provider and M.ClientUI==router and router.Route==route and PlayerSpellsUtil==util and sourceCurrent()
 end
 local function resolve()
  if type(route)~="function" or not pure() then return nil end
  local ok,fn,arg,kind=pcall(route,router,"talents")
  if not ok or not S:Readable(fn) or type(fn)~="function" or not S:Readable(arg) or (arg~=nil and not S:Number(arg)) or not S:Text(kind) or not pure() then return nil end
  return fn,arg,kind
 end
 local fn,arg,kind=resolve()
 local tabs
 local function plain(value)
  if not S:Readable(value) or type(value)~="table" then return false end
  local ok,meta=pcall(getmetatable,value)
  return ok and S:Readable(meta) and meta==nil
 end
 if not plain(util) then fn=nil end
 if fn and kind=="TALENTS_NATIVE_TAB" then
  tabs=S:Field(util,"FrameTabs")
  if not plain(tabs) then fn=nil end
 elseif kind~="TALENTS_NATIVE_HELPER" then fn=nil end
 -- Only the existing source-backed plain Lua helper/tab route is supported.
 -- These raw identity checks cannot invoke a getter or select a replacement route.
 local function sameRoute()
  if not fn or PlayerSpellsUtil~=util or router.Route~=route then return false end
  local helper=rawget(util,"ToggleClassTalentOrSpecFrame")
  if kind=="TALENTS_NATIVE_HELPER" then
   if type(helper)=="function" and helper==fn and arg==nil then return true end
  else
   local toggle=rawget(util,"TogglePlayerSpellsFrame");local currentTabs=rawget(util,"FrameTabs")
   if type(helper)=="nil" and type(toggle)=="function" and toggle==fn and currentTabs==tabs and rawget(tabs,"ClassTalents")==arg then return true end
  end
  return false
 end
 local function routeCurrent()
  -- Refuse an opaque/restricted replacement that faults during identity checking.
  -- sameRoute returns literal booleans only; no native comparison value is exposed.
  local ok,value=pcall(sameRoute);return ok and value==true
 end
 if not fn or not pure() or not routeCurrent() then self.nativeTalentsStatus="UNAVAILABLE";M:Print("Native talents unavailable. Use the game native menu.");return false end
 M.UI:CloseChoices();M.DialogNavigation:Stop()
 if M.AccessibleInput and type(M.AccessibleInput.Stop)=="function" then M.AccessibleInput:Stop() end
 if M.OptionsNavigation and type(M.OptionsNavigation.Stop)=="function" then M.OptionsNavigation:Stop() end
 local visible=self:CanInteract(widget) and widget:IsVisible()
 if not visible or not pure() then return false end
 frame:Hide();generation=generation+1
 local hidden=not frame:IsShown();local allowed=provider:Allowed()
 if not allowed or not hidden or not pure() then return false end
 -- Final eligibility can reenter. Everything after it is a pure ownership/route
 -- comparison; no new helper resolution is allowed to adopt a substituted route.
 if not routeCurrent() or not pure() then return false end
 local ok,result
 if arg~=nil then ok,result=pcall(fn,arg) else ok,result=pcall(fn) end
 local readable=S:Readable(result)
 if not pure() then return false end
 self.nativeTalentsStatus=not ok and "FAILED" or not readable and "UNKNOWN" or result==false and "DECLINED" or "REQUEST_SENT"
 M:Print(self.nativeTalentsStatus=="REQUEST_SENT" and "Native talent inspection requested; opening is not confirmed. The game controls availability." or "Native talent inspection was not confirmed. Use the native menu; Mirage navigation remains released.")
 return ok and readable and result~=false
end
function P:InspectEquipment(widget)
 if widget~=self.nativeEquipment or not self:CanInteract(widget) or not widget:IsVisible() or (self.view~="gear" and self.view~="sets" and self.view~="details") or not M.Equipment:Allowed() then return false end
 local fn=ToggleCharacter
 if type(fn)~="function" then self.nativeEquipmentStatus="UNAVAILABLE";M:Print("Native equipment inspection unavailable. Use the game character menu.");return false end
 local cfg,client,generation=M:ModuleConfig(self.id),M.Client.key,self.generation
 local frame,button,view=self.frame,self.nativeEquipment,self.view
 M.UI:CloseChoices();M.DialogNavigation:Stop()
 if M.AccessibleInput and type(M.AccessibleInput.Stop)=="function" then M.AccessibleInput:Stop() end
 if M.OptionsNavigation and type(M.OptionsNavigation.Stop)=="function" then M.OptionsNavigation:Stop() end
 if not self:CanInteract(widget) or not widget:IsVisible() or self.frame~=frame or self.nativeEquipment~=button or self.view~=view or self.generation~=generation or cfg~=M:ModuleConfig(self.id) or client~=M.Client.key then return false end
 frame:Hide();generation=generation+1
 if not M.Equipment:Allowed() or not M:IsModuleActive(self.id) or self.frame~=frame or self.nativeEquipment~=button or self.generation~=generation or cfg~=M:ModuleConfig(self.id) or client~=M.Client.key or ToggleCharacter~=fn then return false end
 local ok,result=pcall(fn,"PaperDollFrame",true)
 if self.frame~=frame or self.nativeEquipment~=button or self.generation~=generation or cfg~=M:ModuleConfig(self.id) or client~=M.Client.key then return false end
 self.nativeEquipmentStatus=not ok and "FAILED" or not S:Readable(result) and "UNKNOWN" or result==false and "DECLINED" or "REQUEST_SENT"
 M:Print(self.nativeEquipmentStatus=="REQUEST_SENT" and "Native equipment inspection requested; opening and sidebar selection are not confirmed." or "Native equipment inspection was not confirmed. Use the native menu; Mirage navigation remains released.")
 return ok and S:Readable(result) and result~=false
end
function P:ToggleLegacy(widget)
 if widget~=self.nativeLegacy or (self.view~="legacy" and self.view~="legacyEntries") then return false end
 local frame,button,view,treeID=self.frame,self.nativeLegacy,self.view,self.legacyTree
 local profile,cfg,client,adapter=M.profile,M:ModuleConfig(self.id),M.Client,M.adapter
 local base,named=M.Legacy,M.LegacyEntries;local allowed,constantsValid=base.Allowed,base.ConstantsValid
 local generation,baseEpoch,namedEpoch=self.generation,base.epoch,named.epoch
 local context,capability,scope=M.Policy.contextEpoch,M.Policy.capabilityEpoch,M.Policy.scopeEpoch
 local constants,values=Constants,Constants and Constants.LegacyConsts
 local fn=ToggleLegacySystemUI
 local identity={client.key,client.family,client.patch,client.build,client.interface,client.experimental,adapter.family,adapter.patch,adapter.build,adapter.interface,adapter.sourceCommit}
 local expectedTree=treeID
 local function pure()
  local ok,result=pcall(function()
   return M:IsModuleActive(self.id) and M.state.world and not M.state.safe and not M.state.cinematic and self.frame==frame and self.nativeLegacy==button and self.view==view and self.legacyTree==expectedTree and self.generation==generation and M.profile==profile and M:ModuleConfig(self.id)==cfg and M.Client==client and M.adapter==adapter and client.allowed and client.key==identity[1] and client.family==identity[2] and client.patch==identity[3] and client.build==identity[4] and client.interface==identity[5] and client.experimental==identity[6] and adapter.family==identity[7] and adapter.patch==identity[8] and adapter.build==identity[9] and adapter.interface==identity[10] and adapter.sourceCommit==identity[11] and M.Policy.contextEpoch==context and M.Policy.capabilityEpoch==capability and M.Policy.scopeEpoch==scope and M.Legacy==base and base.Allowed==allowed and base.ConstantsValid==constantsValid and base.epoch==baseEpoch and M.LegacyEntries==named and named.epoch==namedEpoch and ToggleLegacySystemUI==fn and legacySourceCurrent(constants,values)
  end)
  return ok and result==true
 end
 local function eligible(hidden)
  if not pure() then return false end
  local shown=frame:IsShown();local visible=not hidden and widget:IsVisible()
  if not pure() or hidden and shown or not hidden and (not shown or not visible) then return false end
  local ok,value=pcall(allowed,base)
  return ok and type(value)=="boolean" and value==true and pure()
 end
 if not pure() or S:Typing() or not pure() or not eligible(false) then return false end
 if type(fn)~="function" then self.nativeLegacyStatus="UNAVAILABLE";M:Print("Native Legacy toggle unavailable. Use the game native menu.");return false end
 M.UI:CloseChoices();if not pure() then return false end
 M.DialogNavigation:Stop();if not pure() then return false end
 if M.AccessibleInput and type(M.AccessibleInput.Stop)=="function" then M.AccessibleInput:Stop();if not pure() then return false end end
 if M.OptionsNavigation and type(M.OptionsNavigation.Stop)=="function" then M.OptionsNavigation:Stop();if not pure() then return false end end
 if not eligible(false) then return false end
 -- The known OnHide invalidation retires selection and increments each epoch once.
 -- Expected successor values are derived before Hide, never adopted from callbacks.
 expectedTree=nil;generation=generation+1;baseEpoch=baseEpoch+1;namedEpoch=namedEpoch+1
 local hiddenOK=pcall(frame.Hide,frame)
 if not hiddenOK or not eligible(true) then return false end
 local ok,result=pcall(fn)
 local readable=S:Readable(result)
 if not pure() then return false end
 self.nativeLegacyStatus=not ok and "FAILED" or not readable and "UNKNOWN" or result==false and "DECLINED" or "REQUEST_SENT"
 M:Print(self.nativeLegacyStatus=="REQUEST_SENT" and "Native Legacy toggle requested; opening is not confirmed. The game controls availability." or "Native Legacy toggle was not confirmed. Use the native menu; Mirage navigation remains released.")
 return ok and readable and result~=false
end
function P:SetView(view)
 if self.constructing then return false end
 if view~="manual" and view~="supplies" and view~="gear" and view~="legacy" and view~="sets" and view~="details" and view~="talents" and view~="builds" and view~="strategies" and view~="entries" and view~="legacyEntries" and view~="pet" then return false end
  local token={};self.inspectionRequest=token
  local frame,profile,previous,generation=self.frame,M.profile,self.view,self.generation
  local client,adapter,provider=M.Client,M.adapter,M.PetSpellbook
  local allowed,read=provider.Allowed,provider.Read
  local cfg=profile.modules[self.id];local policy=M.Policy
  local context,capability,scope=policy.contextEpoch,policy.capabilityEpoch,policy.scopeEpoch
  local source={client.key,client.family,client.patch,client.build,client.interface,client.experimental,adapter.family,adapter.patch,adapter.build,adapter.interface,adapter.sourceCommit,client.allowed,client.sourceMatched}
  local function current()
   local ok,value=pcall(function()
    return self.inspectionRequest==token and M.modules.Preparations==self and self.frame==frame and M.profile==profile and profile.modules[self.id]==cfg and self.view==previous and (self.generation==generation or self.generation==generation+1) and M.Client==client and M.adapter==adapter and client.allowed==source[12] and client.sourceMatched==source[13] and client.key==source[1] and client.family==source[2] and client.patch==source[3] and client.build==source[4] and client.interface==source[5] and client.experimental==source[6] and adapter.family==source[7] and adapter.patch==source[8] and adapter.build==source[9] and adapter.interface==source[10] and adapter.sourceCommit==source[11] and M.PetSpellbook==provider and provider.Allowed==allowed and provider.Read==read and M.Policy==policy and policy.contextEpoch==context and policy.capabilityEpoch==capability and policy.scopeEpoch==scope
   end)
   return ok and value==true
  end
  if not self:CanInteract() or not current() then return false end
  local ok,result=pcall(self.InvalidateGear,self,"NOT_CHECKED",current)
  if not ok or not result or not current() then return false end
  self.legacyTree=nil;self.view=view;previous=view;self.page=1
  if not self:Render(current) or not current() then return false end
  if view=="pet" then return self:RefreshPetSpellbook() end
  if view=="gear" then return self:RefreshEquipment() end
  if view=="legacy" then return self:RefreshLegacy() end
  if view=="sets" then return self:RefreshSets() end
  if view=="details" then return self:RefreshDetails() end
  if view=="talents" then return self:RefreshTalents() end
  if view=="entries" then return self:RefreshTalentEntries() end
  return current()
end
function P:Render(requestCurrent)
 local function render()
 local function call(widget,method,...)
  if requestCurrent and not requestCurrent() then error("Retired preparation render",0) end
  widget[method](widget,...)
  if requestCurrent and not requestCurrent() then error("Retired preparation render",0) end
 end
 if not self.frame then return end
 local f=self.frame;local gear=self.view=="gear";local legacy=self.view=="legacy";local sets=self.view=="sets";local details=self.view=="details";local talents=self.view=="talents";local entries=self.view=="entries";local legacyEntries=self.view=="legacyEntries";local pet=self.view=="pet";local refs=self.view=="builds" or self.view=="strategies";local w,h,buttonH,rowH,hintY,top,actionH=dimensions(gear or legacy or sets or details or talents or entries or legacyEntries or pet or refs,gear or legacy or sets or details or talents or entries or legacyEntries or refs,legacyEntries)
 if not w then call(f,"Hide");self.status="PANEL_SPACE_UNAVAILABLE";return end
 call(f,"SetSize",w,h)
 local body=math.floor((h-12-buttonH-top-8-actionH)/rowH)
 local ids=selections(M:ModuleConfig(self.id)) or {};local supplies=self.view=="supplies"
 if requestCurrent and not requestCurrent() then return false end
 local total=refs and 1 or pet and #(self.petSpellbook or {}) or legacyEntries and #(self.legacyEntries or {}) or entries and #(self.talentEntries or {}) or talents and #(self.talents or {}) or details and #(self.details or {}) or sets and #(self.sets or {}) or legacy and #(self.legacy or {}) or gear and #(self.equipment or {}) or supplies and #ids or #names;local pages=math.max(1,math.ceil(total/body));self.page=math.max(1,math.min(self.page or 1,pages));self.capacity=body
 local function place(widget,x,y,width)
  call(widget,"ClearAllPoints");call(widget,"SetPoint","TOPLEFT",x,y);call(widget,"SetWidth",width)
  if widget.label then call(widget.label,"SetWidth",math.max(1,width-16));call(widget,"SetHeight",buttonH) end
 end
 place(f.closeButton,w-42,-12,28);call(f.closeButton,"SetHeight",28);call(f.heading,"SetWidth",w-190)
 local navY=math.ceil(48*(M.profile.textScale or 1))
 place(self.navStart,w-160,-12,110)
 place(self.viewChoice,18,-navY,w-36);call(self.viewChoice,"SetText","View: "..({manual="Manual",supplies="Supplies",gear="Gear",legacy="Legacy",sets="Saved sets",details="Gear details",talents="Talents",builds="Build references",strategies="Manual strategies",entries="Reported selected entries",legacyEntries="Legacy entries",pet="Pet spellbook"})[self.view or "manual"])
 place(self.legacyTreeChoice,18,-navY-buttonH-8,w-36);call(self.legacyTreeChoice,"SetShown",legacyEntries);call(self.legacyTreeChoice,"SetText",self.legacyTree and ("Tree: "..legacyLabels[self.legacyTree]) or "Choose a Legacy tree")
 place(self.hint,18,-hintY,w-36);call(self.hint,"SetHeight",top-hintY-6)
 call(self.hint,"SetText",pet and (self.petSpellbook and ("Pet-bank cards "..self.page.." / "..pages..".\nSequential; not current or readiness.") or self.petSpellbookStatus=="UNAVAILABLE" and "Pet sample unavailable.\nNo absence or readiness verdict." or "Pet spellbook not checked.\nRefresh explicitly outside combat.") or legacyEntries and (M.Client.family~="Forever" and "Legacy entries: Forever only.\nNo source-qualified sample." or self.legacyEntries and ((legacyLabels[self.legacyTree] or "Legacy")..": "..(self.legacyEntriesStatus=="PARTIAL_UNAVAILABLE" and "partial" or self.legacyEntriesStatus=="UNAVAILABLE" and "unavailable" or "scoped").." "..self.page.." / "..pages..".\nNot an applied build.") or self.legacyTree and "Legacy entries not checked. Refresh." or "Choose one tree explicitly.\nForever only; no automatic scan.") or entries and (self.talentEntries and ((self.talentEntriesStatus=="PARTIAL_UNAVAILABLE" and "Partial cards " or self.talentEntriesStatus=="UNAVAILABLE" and "Unavailable cards " or "Scoped cards ")..((self.page-1)*body+1).."-"..math.min(self.page*body,total).." / "..total..".\nNot an applied build.") or self.talentEntriesStatus=="UNAVAILABLE" and "Named entries unavailable. Use native inspection." or "Entries not checked. Refresh outside combat.") or refs and "User-authored, unverified.\nOpen to select and read." or talents and (self.talents and ("Snapshot: cards "..((self.page-1)*body+1).."-"..math.min(self.page*body,total).." of "..total..".\nNot an applied build.") or self.talentsStatus=="UNAVAILABLE" and "Talents unavailable. Use native inspection." or "Talents not checked. Refresh outside combat.") or details and (self.details and ("Details: cards "..((self.page-1)*body+1).."-"..math.min(self.page*body,total).." of "..total..".\nNot current or ready.") or self.detailsStatus=="UNAVAILABLE" and "Gear details unavailable. Use native inspection." or "Details not checked. Refresh outside combat.") or sets and (self.setsStatus=="OBSERVED_EMPTY" and "No saved sets observed. Snapshot only." or self.sets and ("Snapshot: cards "..((self.page-1)*body+1).."-"..math.min(self.page*body,total).." of "..total..".\nNot current or ready.") or self.setsStatus=="UNAVAILABLE" and "Saved sets unavailable. Use native inspection." or "Saved sets not checked. Refresh outside combat.") or legacy and (self.legacy and "Applied snapshot; sequential, not current." or self.legacyStatus=="UNAVAILABLE" and "Legacy unavailable on this source/client." or "Legacy not checked. Refresh outside combat.") or gear and (self.equipment and "Equipment snapshot. Not current or ready." or self.equipmentStatus=="UNAVAILABLE" and "Equipment unavailable. Use native inspection." or "Equipment not checked. Refresh outside combat.") or supplies and (#ids==0 and "Select item IDs in settings, then Apply." or self.observations and "Snapshot only. Not current stock or readiness." or "Not checked. Refresh outside combat.") or "Manual checks only. Camping not detected. F6: keyboard.")
 for i,b in ipairs(self.rows) do
  local visible=not supplies and not gear and not legacy and not sets and not details and not talents and not entries and not legacyEntries and not pet and not refs and i>(self.page-1)*body and i<=self.page*body
  call(b,"SetShown",visible);if visible then place(b,18,-top-((i-1)%body)*rowH,w-36);call(b,"Refresh") end
 end
 for i,line in ipairs(self.supplyRows) do
  local index=(self.page-1)*body+i;local id=(supplies and i<=body) and ids[index] or nil
  call(line,"SetText","");call(line,"SetShown",id~=nil)
  if id then
   local observed=self.observations and self.observations[id];local text="Not checked"
   if observed then text=observed.count~=nil and ("Observed "..string.format("%.0f",observed.count)) or (observed.subtotal>0 and ("Unknown ("..string.format("%.0f",observed.subtotal).." observed)") or "Total unknown") end
   place(line,18,-top-4-(i-1)*rowH,w-36);call(line,"SetHeight",rowH-4);call(line,"SetText","Item #"..id..": "..text)
  end
 end
 for i,line in ipairs(self.gearRows) do
  local row=i<=body and (gear and self.equipment and self.equipment[(self.page-1)*body+i] or legacy and self.legacy and self.legacy[(self.page-1)*body+i] or sets and self.sets and self.sets[(self.page-1)*body+i] or details and self.details and self.details[(self.page-1)*body+i] or talents and self.talents and self.talents[(self.page-1)*body+i] or entries and self.talentEntries and self.talentEntries[(self.page-1)*body+i] or legacyEntries and self.legacyEntries and self.legacyEntries[(self.page-1)*body+i] or pet and self.petSpellbook and self.petSpellbook[(self.page-1)*body+i] or refs and i==1 and {self.view=="builds" and "Saved build references" or "Manual strategy references","Select from your applied profile","Not verified or applied"}) or nil
  for _,cell in ipairs({line,line.nameText,line.conditionText}) do call(cell,"SetText","");call(cell,"SetShown",row~=nil) end
  if row then
   local text=(legacy or sets or details or talents or entries or legacyEntries or pet or refs) and "" or row.label..": Unknown";local name,condition="",""
   if legacy or sets or details or talents or entries or legacyEntries or pet or refs then text,name,condition=row[1],row[2],row[3]
   elseif row.state=="EMPTY" then text=row.label..": Empty (observed)"
   elseif row.state=="OBSERVED" then
    local d=row.durability
    condition=d.state=="OBSERVED" and ("Durability "..d.current.." / "..d.maximum) or d.state=="NOT_REPORTED" and "Durability not reported" or d.state=="UNSUPPORTED" and "Durability unavailable here" or "Durability unknown"
    text=row.label.." · Item #"..row.id;name=row.name
   end
   local scale=M.profile.textScale or 1;local y=-top-4-(i-1)*rowH
   for j,cell in ipairs({line,line.nameText,line.conditionText}) do place(cell,18,y-math.ceil((j-1)*24*scale),w-36);call(cell,"SetHeight",math.ceil(22*scale)) end
   call(line,"SetText",text);call(line.nameText,"SetText",name);call(line.conditionText,"SetText",condition)
  end
 end
 place(self.nativeEquipment,18,-h+12+buttonH+actionH,w-36);call(self.nativeEquipment,"SetShown",gear or sets or details)
 place(self.nativeLegacy,18,-h+12+buttonH+actionH,w-36);call(self.nativeLegacy,"SetShown",legacy or legacyEntries)
 place(self.nativeTalents,18,-h+12+buttonH+actionH,w-36);call(self.nativeTalents,"SetShown",talents or entries)
 place(self.referenceOpen,18,-h+12+buttonH+actionH,w-36);call(self.referenceOpen,"SetShown",refs);call(self.referenceOpen,"SetText",self.view=="builds" and "Open build references" or "Open manual strategies")
 place(self.refresh,18,-h+12+buttonH,math.max(62,w-166));call(self.refresh,"SetShown",pet or legacyEntries and self.legacyTree~=nil or entries or talents or details or sets or legacy or gear or supplies and #ids>0)
 place(self.prev,w-140,-h+12+buttonH,56);place(self.next,w-78,-h+12+buttonH,60);call(self.prev,"SetShown",pages>1);call(self.next,"SetShown",pages>1)
 call(self.next,"SetText","Next");call(self.prev,"SetText","Back")
 M.DialogNavigation:Refresh(f)
 return not requestCurrent or requestCurrent()
 end
 if requestCurrent then local ok,value=pcall(render);return ok and value==true end
 return render()
end
function P:Open()
 if self.constructing then return false end
  local token={};self.inspectionRequest=token
  local frame,profile,previous,generation=self.frame,M.profile,self.view,self.generation
  local constructed=frame~=nil
  local maximumGeneration=generation;local supplyRetirement=false
  local client,adapter,provider=M.Client,M.adapter,M.PetSpellbook
  local allowed,read=provider.Allowed,provider.Read
  local petEpoch,maximumPetEpoch=provider.epoch,provider.epoch
  local ui,nav,input,options=M.UI,M.DialogNavigation,M.AccessibleInput,M.OptionsNavigation
  local shown,stopInput,stopOptions,closeChoices=nav.Shown,input and input.Stop,options and options.Stop,ui.CloseChoices
  local openMethod,renderMethod,invalidateMethod=self.Open,self.Render,self.InvalidateGear
  local cfg=profile.modules[self.id];local policy=M.Policy
  local context,capability,scope=policy.contextEpoch,policy.capabilityEpoch,policy.scopeEpoch
  local source={client.key,client.family,client.patch,client.build,client.interface,client.experimental,adapter.family,adapter.patch,adapter.build,adapter.interface,adapter.sourceCommit,client.allowed,client.sourceMatched}
  local function current()
   local ok,value=pcall(function()
    return self.initialized and not self.suspended and not self.quarantined and M.state.initialized and M.state.world and not M.state.safe and not M.state.cinematic and profile.enabled and cfg.enabled==true and M.UI==ui and M.DialogNavigation==nav and M.AccessibleInput==input and M.OptionsNavigation==options and nav.Shown==shown and (not input or input.Stop==stopInput) and (not options or options.Stop==stopOptions) and ui.CloseChoices==closeChoices and self.Open==openMethod and self.Render==renderMethod and self.InvalidateGear==invalidateMethod and (provider.epoch==petEpoch or provider.epoch==maximumPetEpoch) and (self.inspectionRequest==token or supplyRetirement and self.inspectionRequest==nil) and M.modules.Preparations==self and self.frame==frame and M.profile==profile and profile.modules[self.id]==cfg and self.view==previous and (self.generation==generation or self.generation==maximumGeneration) and M.Client==client and M.adapter==adapter and client.allowed==source[12] and client.sourceMatched==source[13] and client.key==source[1] and client.family==source[2] and client.patch==source[3] and client.build==source[4] and client.interface==source[5] and client.experimental==source[6] and adapter.family==source[7] and adapter.patch==source[8] and adapter.build==source[9] and adapter.interface==source[10] and adapter.sourceCommit==source[11] and M.PetSpellbook==provider and provider.Allowed==allowed and provider.Read==read and M.Policy==policy and policy.contextEpoch==context and policy.capabilityEpoch==capability and policy.scopeEpoch==scope
   end)
   return ok and value==true
  end
 local created={}
 local function retireControls(root,controls)
  local clean=true
  local function owned() return self.constructing and self.frame==nil and self.pendingFrame==root end
  for _,widget in ipairs(controls or {}) do
   for _,method in ipairs({"Disable","EnableMouse","SetScript","Hide"}) do
    if not owned() then return false end
    if type(widget[method])=="function" then
     local ok
     if method=="EnableMouse" then ok=pcall(widget[method],widget,false)
     elseif method=="SetScript" then ok=pcall(widget[method],widget,"OnClick",nil)
     else ok=pcall(widget[method],widget) end
     if not ok then clean=false end
     if not owned() then return false end
    end
   end
   if not owned() then return false end
   local ok,shown=pcall(function() return widget:IsShown() end)
   local readable,value=pcall(S.Readable,S,shown)
   if not owned() then return false end
   if not ok or not readable or value~=true or type(shown)~="boolean" or shown~=false then clean=false end
  end
  return clean and owned()
 end
 local function open()
 local function call(object,method,...)
  if not current() then error("Retired preparation open",0) end
  local value=object[method](object,...)
  -- Keep even the control returned by a callback that retires this request.
  if self.constructing and object==ui and (method=="Text" or method=="Button" or method=="Check") and value then created[#created+1]=value end
  if not current() then error("Retired preparation open",0) end
  return value
 end
 if not M:IsModuleActive(self.id) or M.state.cinematic or S:InCombat() or not current() then return false,"Enable Preparations, then open it outside combat." end
 self.legacyTree=nil
 local width,height=dimensions(self.view=="gear" or self.view=="legacy" or self.view=="sets" or self.view=="details" or self.view=="talents" or self.view=="builds" or self.view=="strategies" or self.view=="entries" or self.view=="legacyEntries" or self.view=="pet",self.view=="gear" or self.view=="legacy" or self.view=="sets" or self.view=="details" or self.view=="talents" or self.view=="builds" or self.view=="strategies" or self.view=="entries" or self.view=="legacyEntries",self.view=="legacyEntries")
 if not current() then return false end
 if not width then if self.frame then call(self.frame,"Hide") end;if not current() then return false end;self:Invalidate("PANEL_SPACE_UNAVAILABLE");return false,"More screen space is needed for Preparations. Reduce UI/text scale or use a larger window." end
 if not self.frame then
  self.constructing=true
  if self.pendingControls then
   if not retireControls(self.pendingFrame,self.pendingControls) or not current() then return false end
   self.pendingControls=nil
  end
  local f=self.pendingFrame or M.UI:Panel("MiragePreparations","Preparations",430,310)
  if not current() then if self.frame==nil then self.pendingFrame=f end;return false end
  self.pendingFrame=nil;self.frame=f;frame=f
  local tracked=false;for _,root in ipairs(M.ownedRoots[self.id] or {}) do if root==f then tracked=true;break end end
  if not tracked then call(M,"TrackRoot",self.id,f) end
  if not current() then return false end
  self.hint=call(M.UI,"Text",f,"",18,-82,11,390);self.supplyRows={};self.gearRows={}
  self.navStart=call(M.UI,"Button",f,"Controller",270,-12,110,function() M.DialogNavigation:Start(f,true) end)
  self.viewChoice=call(M.UI,"Button",f,"View: Manual",18,-48,394,function(b)
   if not self:CanInteract(b) then return end
   local generation,cfg=self.generation,M:ModuleConfig(self.id)
   M.UI:Choose(b,views,self.view or "manual",function(view)
    if self:CanInteract(b) and self.generation==generation and cfg==M:ModuleConfig(self.id) then self:SetView(view) end
   end)
   local popup=M.UI.choices
   if popup and popup.dialogAnchor and popup.dialogAnchor.frame==b then self.viewChoiceToken=popup.choiceToken end
  end)
  self.legacyTreeChoice=call(M.UI,"Button",f,"Choose a Legacy tree",18,-84,394,function(b)
   if b~=self.legacyTreeChoice or not self:CanInteract(b) or self.view~="legacyEntries" then return end
   local generation,profile,cfg=self.generation,M.profile,M:ModuleConfig(self.id)
   M.UI:Choose(b,legacyTrees,self.legacyTree,function(treeID)
    if self:CanInteract(b) and self.view=="legacyEntries" and self.generation==generation and M.profile==profile and cfg==M:ModuleConfig(self.id) then self:SetLegacyTree(treeID) end
   end)
   local popup=M.UI.choices
   if popup and popup.dialogAnchor and popup.dialogAnchor.frame==b then self.legacyTreeToken=popup.choiceToken end
  end)
  self.nativeEquipment=call(M.UI,"Button",f,"Native equipment",18,-230,394,function(b) self:InspectEquipment(b) end)
  self.referenceOpen=call(M.UI,"Button",f,"Open references",18,-230,394,function(b)
   if b~=self.referenceOpen or not self:CanInteract(b) or M.DialogNavigation.top~=self.frame then return end
   local ok,why=M.ReferenceView:Open(self,self.view);if not ok and why then M:Print(why) end
  end)
  self.nativeTalents=call(M.UI,"Button",f,"Native talents",18,-230,394,function(b) self:InspectTalents(b) end)
  self.nativeLegacy=call(M.UI,"Button",f,"Toggle native Legacy",18,-230,394,function(b) self:ToggleLegacy(b) end)
  for i,name in ipairs(names) do
   self.rows[i]=call(M.UI,"Check",f,name,18,-120-(i-1)*32,function() return self.checked[i]==true end,function(value)
    if not self:CanInteract(self.rows[i]) or (self.view and self.view~="manual") or i<=(self.page-1)*self.capacity or i>self.page*self.capacity then return end
    self.checked[i]=value==true
   end,390)
  end
  for i=1,8 do self.supplyRows[i]=call(M.UI,"Text",f,"",18,-124,11,390) end
  for i=1,20 do
   local line=call(M.UI,"Text",f,"",18,-124,11,390);line.nameText=call(M.UI,"Text",f,"",18,-148,11,390);line.conditionText=call(M.UI,"Text",f,"",18,-172,11,390);self.gearRows[i]=line
  end
  self.refresh=call(M.UI,"Button",f,"Refresh",18,-270,240,function(b) if self.view=="pet" then self:RefreshPetSpellbook();return end;if self:CanInteract(b) then if self.view=="legacyEntries" then self:RefreshLegacyEntries() elseif self.view=="entries" then self:RefreshTalentEntries() elseif self.view=="talents" then self:RefreshTalents() elseif self.view=="details" then self:RefreshDetails() elseif self.view=="sets" then self:RefreshSets() elseif self.view=="legacy" then self:RefreshLegacy() elseif self.view=="gear" then self:RefreshEquipment() elseif self.view=="supplies" then self:RefreshSupplies() end end end)
  self.prev=call(M.UI,"Button",f,"Back",290,-270,56,function(b) if not self:CanInteract(b) then return end;self.page=(self.page or 1)-1;self:Render() end)
  self.next=call(M.UI,"Button",f,"Next",352,-270,60,function(b) if not self:CanInteract(b) then return end;self.page=(self.page or 1)+1;self:Render() end)
  call(f,"SetScript","OnHide",function() if self.frame==f then self:Invalidate("NOT_CHECKED") end end)
  call(M.DialogNavigation,"Attach",f,{allowed=function() return self:CanInteract() end,entries=function()
   local entries={{frame=self.navStart,key="navigation",kind="button"},{frame=self.viewChoice,key="view",kind="button"},{frame=self.legacyTreeChoice,key="legacyTree",kind="button"},{frame=self.nativeLegacy,key="nativeLegacy",kind="button"},{frame=self.nativeEquipment,key="nativeEquipment",kind="button"},{frame=self.nativeTalents,key="nativeTalents",kind="button"},{frame=self.referenceOpen,key="references",kind="button"}}
   for i,b in ipairs(self.rows) do entries[#entries+1]={frame=b,key="check:"..i,kind="button"} end
   for _,row in ipairs({{self.refresh,"refresh"},{self.prev,"previous"},{self.next,"next"},{f.closeButton,"close"}}) do entries[#entries+1]={frame=row[1],key=row[2],kind="button"} end
   return entries
  end})
  constructed=true;self.constructing=nil
 end
 maximumGeneration=generation+1;maximumPetEpoch=petEpoch+1
 if not current() or not self:InvalidateGear("NOT_CHECKED",current) or not current() then return false end
 generation=generation+1;petEpoch=maximumPetEpoch
 call(frame,"SetSize",width,height)
 if M.UI and type(M.UI.CloseChoices)=="function" then call(M.UI,"CloseChoices") end
 if M.AccessibleInput and type(M.AccessibleInput.Stop)=="function" then call(M.AccessibleInput,"Stop") end
 if M.OptionsNavigation and type(M.OptionsNavigation.Stop)=="function" then call(M.OptionsNavigation,"Stop") end
 call(M.DialogNavigation,"Shown",frame)
 call(frame,"Show");if not self:Render(current) or not current() then return false end;if self.view~="gear" and self.view~="legacy" and self.view~="sets" and self.view~="details" and self.view~="talents" and self.view~="builds" and self.view~="strategies" and self.view~="entries" and self.view~="legacyEntries" and self.view~="pet" then supplyRetirement=true;maximumGeneration=generation+1;maximumPetEpoch=petEpoch+1;call(self,"RefreshSupplies");generation=maximumGeneration end;if not current() then return false end;self.status="PREPARATIONS_OPEN";return true
 end
 local ok,value,why=pcall(open)
 if not constructed and self.frame==frame and frame then
  self.frame=nil;self.pendingFrame=frame
  self.pendingControls=created
  if retireControls(frame,created) then self.pendingControls=nil end
  pcall(frame.Hide,frame)
 end
 self.constructing=nil
 if not ok then return false end;return value,why
end
function P:OnEvent(event)
 self:Invalidate(event=="BAG_UPDATE_DELAYED" and "INVENTORY_CHANGED" or "NOT_CHECKED")
 if event~="BAG_UPDATE_DELAYED" and not equipmentEvents[event] and not legacyEvents[event] and not setEvents[event] and not detailEvents[event] and not talentEvents[event] and not petEvents[event] and self.frame then self.frame:Hide() end
 if event=="PLAYER_REGEN_DISABLED" then self.status="COMBAT_PAUSED" end
end
function P:Suspend() if self.frame then self.frame:Hide() end;self:Invalidate("DISABLED");self.checked={};self.status="DISABLED" end
function P:Resume() self.status="MANUAL_CHECKLIST_AVAILABLE" end
function P:ApplyConfig() self:Invalidate("NOT_CHECKED") end
M:RegisterModule("Preparations",P)
