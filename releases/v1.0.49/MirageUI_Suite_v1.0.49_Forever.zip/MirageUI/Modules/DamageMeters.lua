local _, M = ...
local D=M:CreateNativeModule("DamageMeters",{"DamageMeter"},{combat=true},false)
-- Native session contents remain inside the game. The contextual parent controls
-- presentation only; it cannot make an unavailable meter API or frame exist.
D.visibilityStatus="CONTEXTUAL_NATIVE_WHEN_ENABLED"
function D:UsesMirageMeters()
    local rework=M.Rework
    return rework and type(rework.Selected)=="function" and rework:Selected("meters")==true
end
function D:DelegateMeters()
    if not self:UsesMirageMeters() then self.mirageDelegated=nil;return false end
    -- The custom provider consumes C_DamageMeter data and owns its own frame.
    -- Its native UI handoff uses a CVar; the retired native skin/summary must
    -- not acquire the same root or manufacture an acquisition failure.
    if not self.mirageDelegated then M.Native:Restore(self.id);self.mirageDelegated=true end
    self.nativeSurfaces=0;self.styledSurfaces=0
    self.status="REWORK_CUSTOM_PROVIDER";self.visibilityStatus="MIRAGE_CUSTOM_CONTEXT_NATIVE_CVAR_HANDOFF"
    return true
end
local refreshing=false
local function refresh(self)
    if self:DelegateMeters() then return end
    self.visibilityStatus="CONTEXTUAL_NATIVE_WHEN_ENABLED"
    local profile,state,native=M.profile,M.state,M.Native
    local api,frame=C_DamageMeter,_G.DamageMeter
    local cfg=M:ModuleConfig(self.id);local style=cfg and cfg.style
    local function current()
        return M.modules[self.id]==self and M.profile==profile and M.state==state and M.Native==native
            and C_DamageMeter==api and _G.DamageMeter==frame
            and profile and profile.enabled and cfg and profile.modules[self.id]==cfg and cfg.enabled and cfg.style==style
            and M.Client.allowed and not state.safe and not self.suspended and not self.quarantined
    end
    local function reject(reason)
        if M.Native==native and M.modules[self.id]==self then native:Restore(self.id) end
        self.status=reason;return true
    end
    local function revoked()
        if not current() then return reject("NATIVE_METER_AUTHORITY_CHANGED") end
        local conflict=native:Conflict()
        -- Conflict observation can itself reenter profile/native code. The pure
        -- identity/config check is last, immediately before continuing work.
        if not current() then return reject("NATIVE_METER_AUTHORITY_CHANGED") end
        if conflict then return reject("CONFLICT_NATIVE_OWNER") end
        return false
    end
    if revoked() then return end
    if not api then M.Native:Restore(self.id);self.status="UNAVAILABLE_NATIVE_API";return end
    local readable=M.Safety:Frame(frame,false)
    if revoked() then return end
    if not readable then M.Native:Restore(self.id);self.status="NATIVE_METER_UNAVAILABLE";return end
    local prior=self.surfaces.DamageMeter
    if not prior or prior.frame~=frame or native.records[frame]~=prior or M.surfaces["DamageMeters.native"]~=prior then
        -- Do not install hooks or decorate a replacement until a legal exact-frame
        -- acquisition succeeds. Keep the old binding for deferred handback/retry.
        local combat=M.Safety:InCombat()
        if revoked() then return end
        if combat then self.status="NATIVE_METER_ACQUIRE_DEFERRED";return end
        local surface=M.Native:Acquire(self.id,"DamageMeters.native",frame,{combat=true},false)
        if revoked() then return end
        if not surface then self.status="NATIVE_METER_ACQUIRE_UNAVAILABLE";return end
        M.Native:Undecorate(self.id)
        if revoked() then return end
        self.surfaces.DamageMeter=surface
    end
    if style then M.Native:Decorate(self.id,frame) end
    if revoked() then return end
    -- Session data, combat identities and ranking remain entirely inside Blizzard's meter.
    self.status="NATIVE_METER_PRESERVED"
end
function D:Refresh()
    if refreshing then return end
    refreshing=true
    local ok,why=pcall(refresh,self)
    refreshing=false
    if not ok then error(why,0) end
end
function D:OpenSettings()
    if M.Safety:InCombat() then return end
    if self:UsesMirageMeters() and M.Rework.MirageMeters then M.Rework.MirageMeters:Open();return end
    M:Print("Enable the game’s Damage Meter first. MirageUI can show it for combat, targeting, interaction or manual reveal, then hide it between activities. Its data and existing controls remain unchanged.")
end
