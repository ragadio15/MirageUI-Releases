local _, M = ...
local G={views={},events={GROUP_ROSTER_UPDATE=true,UNIT_HEALTH=true,UNIT_MAXHEALTH=true,UNIT_POWER_UPDATE=true,UNIT_MAXPOWER=true,UNIT_NAME_UPDATE=true,UNIT_CONNECTION=true,UNIT_FLAGS=true,UNIT_DISPLAYPOWER=true,PLAYER_ROLES_ASSIGNED=true,READY_CHECK=true,READY_CHECK_CONFIRM=true,READY_CHECK_FINISHED=true,PLAYER_ENTERING_WORLD=true}}
for event in pairs(M.UnitExtras.events) do G.events[event]=true end
G.events.UNIT_AURA=true
function G:WantsEvent(event)
    if M.UnitExtras.events[event] then return M:ModuleConfig(self.id).showCast==true end
    if event=="UNIT_AURA" then local c=M:ModuleConfig(self.id);return c.showAuras==true or c.showBuffs==true end
    if event=="READY_CHECK" or event=="READY_CHECK_CONFIRM" or event=="READY_CHECK_FINISHED" then return M:ModuleConfig(self.id).showReady==true end
    return true
end
local function ownsFixed(view)
    local surface=view.surface
    return surface and rawequal(surface.frame,view.frame) and rawequal(M.surfaces[surface.id],surface) and rawequal(M.Policy.owners[surface.id],surface)
end
-- Pure ordinary-call lifetimes for ManagedNative source receipts. A reentrant
-- lifecycle request retires its predecessor and is retried by a later apply.
local lifetime={}
local running
local controlledViews={}
function G:CaptureLifetime() return lifetime end
function G:IsLifetimeCurrent(token) return rawequal(self,G) and M.modules~=nil and rawequal(M.modules.PartyRaid,G) and rawequal(token,lifetime) end
local function adoptNative(op)
    op.nativeToken=op.nativeCapture(op.native)
    op.nativeActive=op.native.active;op.nativeReady=op.native.ready
    op.nativeFailed=op.native.failed;op.nativeCleanup=op.native.cleanupPending
end
local function beginAttempt()
    lifetime={}
    if running then
        G.cleanupPending=true;G.status="GROUP_TRANSITION_PENDING"
        return nil
    end
    local native=M.NativeGroups
    local op={token=lifetime,views=G.views,modules=M.modules,surfaces=M.surfaces,policy=M.Policy,owners=M.Policy.owners,
        safety=M.Safety,combat=M.Safety.InCombat,native=native,nativeCapture=native.CaptureLifetime,nativeCurrent=native.IsLifetimeCurrent,
        nativePrepare=native.Prepare,nativeSetActive=native.SetActive,unregister=UnregisterStateDriver,register=RegisterStateDriver,
        display=M.Display,clear=M.Display.ClearUnit}
    if type(op.nativeCapture)~="function" or type(op.nativeCurrent)~="function" then return nil end
    adoptNative(op);running=op
    return op
end
local function baseCurrent(op)
    return rawequal(lifetime,op.token) and rawequal(M.modules,op.modules) and rawequal(op.modules.PartyRaid,G) and rawequal(G.views,op.views) and rawequal(M.NativeGroups,op.native)
        and rawequal(M.surfaces,op.surfaces) and rawequal(M.Policy,op.policy) and rawequal(op.policy.owners,op.owners)
        and rawequal(M.Safety,op.safety) and op.safety.InCombat==op.combat
        and op.native.CaptureLifetime==op.nativeCapture and op.native.IsLifetimeCurrent==op.nativeCurrent
        and op.native.Prepare==op.nativePrepare and op.native.SetActive==op.nativeSetActive
        and UnregisterStateDriver==op.unregister and RegisterStateDriver==op.register
        and rawequal(M.Display,op.display) and op.display.ClearUnit==op.clear
end
local function current(op)
    return baseCurrent(op) and op.nativeCurrent(op.native,op.nativeToken)
        and op.native.active==op.nativeActive and op.native.ready==op.nativeReady
        and op.native.failed==op.nativeFailed and op.native.cleanupPending==op.nativeCleanup
end
local function writable(op,custody)
    if not current(op) or (custody and not custody()) then return false,"GROUP_PRODUCER_CHANGED" end
    local ok,combat=pcall(op.combat,op.safety)
    if not current(op) or (custody and not custody()) then return false,"GROUP_PRODUCER_CHANGED" end
    if not ok or combat~=false then return false,"GROUP_LAYOUT_AFTER_COMBAT" end
    return true
end
local function effect(op,custody,fn,tries,...)
    for _=1,tries or 1 do
        local legal,why=writable(op,custody)
        if not legal then return false,why end
        local ok=type(fn)=="function" and pcall(fn,...)
        legal,why=writable(op,custody)
        if not legal then return false,why end
        if ok then return true end
    end
    return false,"GROUP_CONTROL_UNCONFIRMED"
end
local function finish(op,ok,why)
    if rawequal(running,op) then running=nil end
    if not current(op) then return false,"GROUP_TRANSITION_SUPERSEDED" end
    if why then G.status=why end
    return ok,why
end
local function snapshotViews(op)
    local rows={};local count=0
    for key,view in pairs(op.views) do
        count=count+1
        rows[#rows+1]={key=key,view=view,frame=view.frame,surface=view.surface,unit=view.unit,isRaid=view.isRaid,driver=view.driver,
            hide=view.frame and view.frame.Hide}
    end
    local function custody()
        local seen=0;for _ in pairs(op.views) do seen=seen+1 end
        if seen~=count then return false end
        local controlled=0
        for key,control in pairs(controlledViews) do
            controlled=controlled+1
            if not rawequal(op.views[key],control.view) then return false end
        end
        if controlled~=count then return false end
        for _,row in ipairs(rows) do
            local view=row.view
            local control=controlledViews[row.key]
            if not control or not rawequal(control.view,view) or not rawequal(control.frame,row.frame) or not rawequal(control.surface,row.surface) then return false end
            if not rawequal(op.views[row.key],view) or not rawequal(view.frame,row.frame) or not rawequal(view.surface,row.surface) or view.unit~=row.unit
                or view.isRaid~=row.isRaid or view.driver~=row.driver or not row.frame or row.frame.Hide~=row.hide or not ownsFixed(view) then return false end
        end
        return true
    end
    return rows,custody
end
local function nativeCall(op,custody,fn,...)
    local legal,why=writable(op,custody)
    if not legal then return false,false,why end
    local called,result,reason=pcall(fn,op.native,...)
    -- This call deliberately opens a native lifetime. Only this caller may
    -- adopt it, after confirming its own lifetime and any supplied custody survived.
    if not baseCurrent(op) or (custody and not custody()) then return false,false,"GROUP_TRANSITION_SUPERSEDED" end
    adoptNative(op)
    legal,why=writable(op,custody)
    if not legal then return false,false,why end
    if not called then return false,false,"GROUP_CONTROL_UNCONFIRMED" end
    if reason=="GROUP_TRANSITION_SUPERSEDED" or reason=="GROUP_TRANSITION_PENDING" or reason=="GROUP_PRODUCER_CHANGED" then
        return false,false,reason
    end
    return true,result,reason
end
local function retireRows(op,rows,custody,raidOnly)
    for _,row in ipairs(rows) do
        if not raidOnly or row.isRaid then
            local ok,why=effect(op,custody,op.unregister,2,row.frame,"visibility")
            if not ok then return false,why end
            ok,why=effect(op,custody,row.hide,2,row.frame)
            if not ok then return false,why end
            ok,why=effect(op,custody,op.clear,2,op.display,row.view)
            if not ok then return false,why end
        end
    end
    return true
end
function G:Initialize()
    if not rawequal(self,G) or not rawequal(M.modules.PartyRaid,G) then return false,"GROUP_PRODUCER_CHANGED" end
    lifetime={}
    if running then self.cleanupPending=true;return false,"GROUP_TRANSITION_PENDING" end
    if self.fixedReady then return end
    if M.Native:Conflict() then self.status="CONFLICT_NATIVE_OWNER";return end
    if M.Safety:InCombat() or type(RegisterStateDriver)~="function" or type(UnregisterStateDriver)~="function" or type(RegisterUnitWatch)~="function" or type(UnregisterUnitWatch)~="function" then self.status="SECURE_PATH_UNAVAILABLE";return end
    local units={}
    for i=1,4 do units[#units+1]={unit="party"..i,x=-.38,y=.18-(i-1)*.065,w=240,h=50,driver="[group:raid] hide; [@party"..i..",exists] show; hide"} end
    for i=1,40 do
        units[#units+1]={unit="raid"..i,x=-.36+math.floor((i-1)/8)*.072,y=.23-((i-1)%8)*.047,w=128,h=40,
            driver="[group:raid,@raid"..i..",exists] show; hide"}
    end
    for _,row in ipairs(units) do
        local view=M.Display:CreateUnit("MirageGroup_"..row.unit,row.unit,row.unit,nil,self.id);self.views[row.unit]=view
        if UnregisterUnitWatch then UnregisterUnitWatch(view.frame) end
        view.driver=row.driver;RegisterStateDriver(view.frame,"visibility",row.driver)
        local s={id="PartyRaid."..row.unit,module=self.id,frame=view.frame,security="SECURE_PREDECLARED",floor=true,editable=true,minWidth=90,minHeight=32,groups={group=true},
            layout={x=row.x,y=row.y,width=row.w,height=row.h,scale=1}}
        s.OnLayout=function(_,l) if ownsFixed(view) then M.Display:SizeUnit(view,l.width,l.height) end end
        view.surface=s;controlledViews[row.unit]={view=view,frame=view.frame,surface=s};M.CVE:Register(s);M.Layout:Apply(s)
    end
    self.fixedReady=true
    self:Refresh();self.status="FIXED_SLOT_SECURE_CANDIDATE"
end
local function selected(view)
    return view and (not view.isRaid or not M.NativeGroups.active) and ownsFixed(view)
end
local function refreshFixed(view,newRoster,maintenance)
    if newRoster then M.Display:ClearUnit(view) end
    M.Display:UnitBars(view,view.unit,true)
    if newRoster and not maintenance then M.UnitExtras:RefreshCast(view) end
end
function G:Refresh(newRoster,maintenance)
    for _,view in pairs(self.views) do
        if selected(view) then refreshFixed(view,newRoster,maintenance) end
    end
    M.NativeGroups:Refresh(newRoster)
end
local function refreshDetails(views)
    for _,view in pairs(views) do if selected(view) then M.Display:UnitInfo(view) end end
end
local metadataEvents={UNIT_NAME_UPDATE=true,UNIT_CONNECTION=true,UNIT_FLAGS=true,UNIT_DISPLAYPOWER=true,UNIT_MAXPOWER=true}
function G:OnEvent(event,unit)
    if event=="PLAYER_ENTERING_WORLD" or event=="GROUP_ROSTER_UPDATE" then
        if event=="PLAYER_ENTERING_WORLD" then self.readyActive=false;self.readyExpires=nil end
        self:Refresh(true)
        return
    end
    if event=="READY_CHECK" or event=="READY_CHECK_CONFIRM" or event=="READY_CHECK_FINISHED" or event=="PLAYER_ROLES_ASSIGNED" then
        if event=="READY_CHECK" then
            self.readyActive=true
            local duration=M.Safety:Public(GetReadyCheckTimeLeft,"number")
            self.readyExpires=M.Safety:Now()+((duration and duration>0 and duration<=120) and duration or 40)
        elseif event=="READY_CHECK_FINISHED" then self.readyActive=false;self.readyExpires=nil end
        refreshDetails(self.views);M.NativeGroups:Event(event,unit)
        return
    end
    -- Missing/restricted unit arguments never turn a unit event into a broadcast.
    if not M.Safety:Text(unit) then return end
    local view=self.views[unit]
    if not view then return end
    if selected(view) then
        if M.UnitExtras.events[event] or event=="UNIT_AURA" then M.UnitExtras:Event(view,event)
        else M.Display:UnitBars(view,unit,metadataEvents[event]) end
    else M.NativeGroups:Event(event,unit,metadataEvents[event]) end
end
function G:Suspend()
    if not rawequal(self,G) or not rawequal(M.modules.PartyRaid,G) then return false,"GROUP_PRODUCER_CHANGED" end
    self.pendingDisable=true;self.cleanupPending=true
    local op=beginAttempt();if not op then return false,"GROUP_TRANSITION_PENDING" end
    local completed,result,reason=pcall(function()
        self.readyActive=false;self.readyExpires=nil
        local rows,custody=snapshotViews(op)
        local legal,why=writable(op)
        if not legal then
            -- In lockdown the surviving secure provider keeps essential bars.
            -- Cosmetic clearing below is ordinary artwork, never frame hiding.
            if why=="GROUP_LAYOUT_AFTER_COMBAT" and current(op) and custody() then
                for _,row in ipairs(rows) do
                    if not current(op) or not custody() then break end
                    if selected(row.view) then
                        M.UnitExtras:Clear(row.view)
                        if not current(op) or not custody() then break end
                        M.Display:UnitInfo(row.view)
                    end
                end
                if current(op) and custody() and op.native.active then
                    for _,view in ipairs(op.native.views) do
                        if not current(op) or not custody() then break end
                        if view.unit and op.native:OwnsChild(view) then
                            if not current(op) or not custody() then break end
                            M.UnitExtras:Clear(view)
                            if not current(op) or not custody() then break end
                            M.Display:UnitInfo(view)
                        end
                    end
                end
            end
            return false,why
        end
        local called,disabled
        -- Header retirement owns separate controls. Its own custody guards and
        -- this outer lifetime/combat guard remain required even when a fixed
        -- slot moved to another owner. Fixed cleanup still needs its full seal.
        called,disabled,why=nativeCall(op,nil,op.nativeSetActive,false)
        if not called or not disabled or op.native.cleanupPending then return false,why or "GROUP_CONTROL_UNCONFIRMED" end
        legal,why=writable(op,custody)
        if not legal then return false,why end
        local retired;retired,why=retireRows(op,rows,custody,false)
        if not retired then return false,why end
        legal,why=writable(op,custody)
        if not legal then return false,why end
        self.pendingDisable=nil;self.cleanupPending=nil
        return true,"DISABLED"
    end)
    if not completed then result=false;reason="GROUP_CONTROL_UNCONFIRMED" end
    return finish(op,result,reason)
end
function G:Resume()
    if not rawequal(self,G) or not rawequal(M.modules.PartyRaid,G) then return false,"GROUP_PRODUCER_CHANGED" end
    local op=beginAttempt();if not op then return false,"GROUP_TRANSITION_PENDING" end
    local legal,why=writable(op)
    if legal then self.maintenanceFailed=nil end
    local ok,reason=finish(op,legal,why)
    if not ok then return false,reason end
    -- ApplyProfile follows Resume with ApplyConfig. Direct callers open one
    -- fresh apply; cleanup debt is cleared only by its completed transition.
    if not M.applying then return self:ApplyConfig() end
    return true
end
local function restoreSelectedDrivers(op,rows,custody)
    for _,row in ipairs(rows) do
        if selected(row.view) then
            local ok,why=effect(op,custody,op.register,2,row.frame,"visibility",row.driver)
            if not ok then return false,why end
        end
    end
    return true
end
function G:ApplyConfig()
    if not rawequal(self,G) or not rawequal(M.modules.PartyRaid,G) then return false,"GROUP_PRODUCER_CHANGED" end
    local op=beginAttempt();if not op then return false,"GROUP_TRANSITION_PENDING" end
    local completed,result,reason=pcall(function()
        local rows,custody=snapshotViews(op)
        local legal,why=writable(op,custody)
        if not legal then
            if why=="GROUP_LAYOUT_AFTER_COMBAT" and current(op) then self.cleanupPending=true end
            return false,why
        end
        local requested=M:ModuleConfig(self.id).nativeGroups==true
        legal,why=writable(op,custody)
        if not legal then
            if why=="GROUP_LAYOUT_AFTER_COMBAT" and current(op) then self.cleanupPending=true end
            return false,why
        end
        -- A refused preflight has not entered a producer effect. Preserve any
        -- old/reentrant debt, but do not strand a healthy unchanged provider by
        -- inventing new cleanup work when its temporarily lost custody returns.
        self.cleanupPending=true
        self.pendingDisable=nil
        local native=op.native
        local prepared,selectionReason,called
        -- Finish any previous header handback before changing fixed drivers.
        if native.cleanupPending then
            local cleaned
            called,cleaned,why=nativeCall(op,custody,op.nativeSetActive,false)
            if not called or not cleaned or native.cleanupPending then return false,why or "GROUP_CONTROL_UNCONFIRMED" end
        end
        if requested then
            called,prepared,selectionReason=nativeCall(op,custody,op.nativePrepare)
            if not called then return false,selectionReason end
            if native.cleanupPending then return false,selectionReason or "GROUP_CONTROL_UNCONFIRMED" end
        end
        if prepared and not native.active then
            local retired
            retired,why=retireRows(op,rows,custody,true)
            if not retired then
                legal=writable(op,custody)
                if not legal then return false,why end
                prepared=false;selectionReason="FIXED_ROSTER_RETIRE_FAILED"
            end
        end
        local activated
        called,activated,why=nativeCall(op,custody,op.nativeSetActive,prepared==true)
        if not called or native.cleanupPending then return false,why or "GROUP_CONTROL_UNCONFIRMED" end
        if prepared and not activated then selectionReason=why end
        if selectionReason then native.status=selectionReason end
        local restored
        restored,why=restoreSelectedDrivers(op,rows,custody)
        if not restored then return false,why end
        for _,row in ipairs(rows) do
            if selected(row.view) then
                local view=row.view
                local ok
                ok,why=effect(op,custody,M.UnitExtras.Configure,1,M.UnitExtras,view)
                if not ok then return false,why end
                ok,why=effect(op,custody,M.Layout.Apply,1,M.Layout,row.surface)
                if not ok then return false,why end
                ok,why=effect(op,custody,M.Display.UnitBars,1,M.Display,view,view.unit,true)
                if not ok then return false,why end
                ok,why=effect(op,custody,M.UnitExtras.RefreshCast,1,M.UnitExtras,view)
                if not ok then return false,why end
            end
        end
        legal,why=writable(op,custody)
        if not legal then return false,why end
        self.cleanupPending=nil;self.pendingDisable=nil
        return true,native.active and "NATIVE_SUBGROUP_CANDIDATE" or requested and "FIXED_ROSTER_FALLBACK" or "FIXED_SLOT_SECURE_CANDIDATE"
    end)
    if not completed then result=false;reason="GROUP_CONTROL_UNCONFIRMED" end
    return finish(op,result,reason)
end
function G:Tick(now)
    M.NativeGroups:Tick(now)
    for _,view in pairs(self.views) do if selected(view) then M.UnitExtras:Tick(view,now) end end
    if self.readyActive and self.readyExpires and now>=self.readyExpires then
        self.readyActive=false;self.readyExpires=nil
        refreshDetails(self.views);M.NativeGroups:Event("READY_CHECK_FINISHED")
    end
end
G.maintenanceEvents={UNIT_HEALTH=true,UNIT_MAXHEALTH=true,UNIT_POWER_UPDATE=true,UNIT_MAXPOWER=true,UNIT_NAME_UPDATE=true,UNIT_CONNECTION=true,UNIT_FLAGS=true,UNIT_DISPLAYPOWER=true,GROUP_ROSTER_UPDATE=true}
function G:MaintainSecure(event,unit)
    if event=="GROUP_ROSTER_UPDATE" then self:Refresh(true,true);return end
    if not self.maintenanceEvents[event] or not M.Safety:Text(unit) then return end
    local view=self.views[unit]
    if not view then return end
    if selected(view) then M.Display:UnitBars(view,unit,metadataEvents[event])
    else M.NativeGroups:Event(event,unit,metadataEvents[event]) end
end
function G:ClearSecureDisplay()
    for _,view in pairs(self.views) do if ownsFixed(view) then M.Display:ClearUnit(view) end end
    for _,view in ipairs(M.NativeGroups.views) do if M.NativeGroups:OwnsChild(view) then M.Display:ClearUnit(view) end end
end
-- The M02 provider owns its fixed controls and subgroup headers. Retain this
-- module as the suite lifecycle endpoint, but never run the legacy producer
-- against the new views or let it reacquire the retired native group roots.
local function reworked()
    local r=M.Rework
    return r and r.UnitGroups and (r.UnitGroups.initialized or r:Selected("groups",M.profile))
end
for _,name in ipairs({"Initialize","Refresh","OnEvent","Resume","ApplyConfig","Tick","ClearSecureDisplay"}) do
    local prior=G[name]
    G[name]=function(self,...)
        if reworked() then self.status="REWORK_CUSTOM_PROVIDER";return true end
        return prior(self,...)
    end
end
local suspend=G.Suspend
function G:Suspend(...)
    if reworked() then
        -- The suite verifies TrackRoot custody immediately after this method.
        -- Retire our temporary subgroup parenting before that immutable check;
        -- the rework lifecycle's subsequent Suspend is safely idempotent.
        return M.Rework.UnitGroups:Suspend(...)
    end
    return suspend(self,...)
end
local maintain=G.MaintainSecure
function G:MaintainSecure(event,unit)
    if reworked() then return M.Rework.UnitGroups:MaintainSecure(event,unit) end
    return maintain(self,event,unit)
end
M:RegisterModule("PartyRaid",G)
