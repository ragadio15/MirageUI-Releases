local _, M = ...
M.CVE={holds={},last={}}
local V=M.CVE
-- Hover is a continuation of a visible display, never an invisible activation
-- region. Public effective opacity also catches hidden/transparent ancestors.
function V:InputVisible(surface)
    local frame=surface and surface.frame
    if not frame or not M.Safety:Frame(frame,true) then return false end
    if M.Safety:Public(frame.IsVisible,"boolean",frame)~=true then return false end
    local alpha=M.Safety:Public(type(frame.GetEffectiveAlpha)=="function" and frame.GetEffectiveAlpha or frame.GetAlpha,"number",frame)
    return alpha and alpha>0 or false
end
local function matches(surface,rule)
    for _,group in ipairs(rule.groups or {}) do
        if group=="all" or surface.groups[group] then return true end
    end
end
function V:Register(surface)
    assert(type(surface.id)=="string" and not M.surfaces[surface.id],"Duplicate MirageUI surface")
    assert(M.modules[surface.module],"Unknown surface owner")
    surface.groups=surface.groups or {};surface.fallback=surface.fallback or "VISIBLE"
    assert(M.Policy:Register(surface),"Duplicate policy surface")
    surface.actual="UNINITIALIZED";surface.desired="VISIBLE";surface.revision=0
    surface.bindings={}
    for _,rule in ipairs(M.RuleBindings) do if matches(surface,rule) then surface.bindings[#surface.bindings+1]=rule end end
    M.surfaces[surface.id]=surface
    M.Policy:AttachInteraction(surface)
    M.state.forceEvaluate=true
end
function V:Tick(immediate)
    if not M.profile then return end
    local now=M.Safety:Now()
    M.Policy:RefreshAuthority(now)
    -- A cached resolution does not renew its admitted execution authority.
    for _,surface in pairs(M.surfaces) do
        if surface.admittedTicket and not M.Policy:TicketCurrent(surface,surface.admittedTicket,now) then M.Policy:CancelTicket(surface) end
    end
    local snapshot=M.Store:Snapshot()
    if not immediate and not M.state.forceEvaluate and self.lastRevision==snapshot.revision and self.lastProfile==M.profile and now<(self.nextDeadline or 0) then return end
    M.state.forceEvaluate=nil
    local admitted,controlled=M.Policy:RuntimeIntents(snapshot,now)
    local deadline=now+1
    if M.Policy.nextDeadline and M.Policy.nextDeadline>now and M.Policy.nextDeadline<deadline then deadline=M.Policy.nextDeadline end
    self.compiledUser=self.lastProfile==M.profile and (self.compiledUser or {}) or {}
    self.lastRevision=snapshot.revision;self.lastProfile=M.profile
    local function nextDeadline(value) if value and value>now and value<deadline then deadline=value end end
    for id,surface in pairs(M.surfaces) do
        local cfg=M:ModuleConfig(surface.module);local mod=M.modules[surface.module]
        local primary=M.Rework and M.Rework.SurfaceActive and M.Rework:SurfaceActive(surface)
        local moduleRunning=cfg and cfg.enabled and mod and not mod.suspended
        if surface.reworkProvider then moduleRunning=primary==true end
        local state,reason,priority,ticket
        local combatRow=snapshot.PLAYER_IN_COMBAT
        local activeCombat=combatRow and combatRow.status=="KNOWN" and combatRow.decisionEligible and M.Safety:Readable(combatRow.value) and combatRow.value==true
        local stopped=M.state.safe or not M.state.world or not M.profile.enabled or not cfg or not moduleRunning
            or (mod and mod.quarantined) or surface.disabled
        local activityEnded=(surface.activeCombatOnly and not activeCombat) or (surface.outOfCombatOnly and M.Safety:InCombat())
        local hiddenUI=snapshot.NATIVE_UI_HIDDEN
        local nativeHidden=hiddenUI and hiddenUI.status=="KNOWN" and hiddenUI.decisionEligible and M.Safety:Readable(hiddenUI.value) and hiddenUI.value==true
        if stopped or activityEnded or M.state.cinematic or nativeHidden or surface.presentationHidden then
            reason=stopped and "MODULE_STOPPED" or surface.presentationHidden and "DUPLICATE_OPTIONAL_PRESENTATION"
                or M.state.cinematic and "CINEMATIC_CONTEXT" or nativeHidden and "NATIVE_UI_HIDDEN" or "ACTIVITY_ENDED"
            state,priority="HIDDEN",0
            if surface.native then state,reason="VISIBLE","NATIVE_RESTORE" end
        elseif M.state.trackerWorkspace and not surface.native and surface.module~="Chat" then
            state,reason,priority="HIDDEN","TRACKER_WORKSPACE",0
        elseif M.state.keybindWorkspace and not surface.native and surface.module~="ActionBars"
            and surface.module~="Inventory" and surface.module~="Chat" and surface.module~="Tooltips" then
            state,reason,priority="HIDDEN","KEYBIND_WORKSPACE",0
        elseif M.StartupPresentation and M.StartupPresentation:IsQuiet() and not surface.userOpened then
            state,reason,priority="HIDDEN","STARTUP_QUIET",0
        else
            local intents=admitted[id] or {}
            if M.Experience and not controlled[id] then
                local intention,due=M.Experience:Intent(surface,snapshot,now)
                if intention then intents[#intents+1]=intention end
                nextDeadline(due)
            end
            if M.PresentationGroups and not controlled[id] then
                local hover,due=M.PresentationGroups:HoverIntent(surface,now)
                if hover then intents[#intents+1]=hover end
                nextDeadline(due)
            end
            if M.PresentationGroups then
                local combat=M.PresentationGroups:CombatIntent(surface,snapshot)
                if combat then intents[#intents+1]=combat end
            end
            if M.ElementRules and not controlled[id] then
                local preference=M.ElementRules:Intent(surface,snapshot)
                if preference then intents[#intents+1]=preference end
            end
            if surface.Intent and not controlled[id] then
                local good,requested,why,rank=M:Guard(surface.module,surface.Intent,surface,snapshot)
                if good and M.States[requested] then
                    intents[#intents+1]={id=why or "MODULE_POLICY",state=requested,priority=rank or 2,tieRank=45,eligible=true}
                end
            end
            local lensState=M.CombatLenses and M.CombatLenses:Intent(surface,snapshot)
            if lensState then intents[#intents+1]={id="MANUAL_PVP_LENS",state=lensState,priority=1,tieRank=0,eligible=true} end
            if surface.outOfCombatOnly and surface.checklistNeedsAttention and not M.Safety:InCombat() then
                intents[#intents+1]={id="PREPARATION_PUBLIC_REVIEW",state="VISIBLE",priority=3,tieRank=10,eligible=true}
            end
            if M.Policy:HasInteraction(surface,now) then intents[#intents+1]={id="INTERACTION_LEASE",state="VISIBLE",priority=0,tieRank=61,eligible=true} end
            nextDeadline(M.Policy:NextLeaseDeadline(surface,now))
            if surface.userOpened then intents[#intents+1]={id="GOV-006",state="VISIBLE",priority=0,tieRank=59,eligible=true} end
            if M.DisplayOcclusion then
                local overlap=M.DisplayOcclusion:Intent(surface)
                if overlap then intents[#intents+1]=overlap end
            end
            if (surface.native or surface.holdOnHover) and self:InputVisible(surface) then
                local hovered=M.Safety:Public(surface.frame.IsMouseOver,"boolean",surface.frame)
                if hovered and not surface.occlusionReason then surface.interactingUntil=now+.4 end
            end
            if not controlled[id] then
            for _,rule in ipairs(surface.bindings) do
                M.stats.evaluations=M.stats.evaluations+1
                rule.compiled=rule.compiled or M.Predicate:Compile(rule.when)
                local verdict=M.Predicate:EvaluateCompiled(rule.compiled,snapshot)
                local key=id..":"..rule.id
                local dwell=rule.dwell=="idle" and M.profile.idle or rule.dwell
                if verdict=="TRUE" then
                    self.holds[key]=self.holds[key] or now
                    nextDeadline(self.holds[key]+dwell)
                    if now-self.holds[key]>=dwell then
                        intents[#intents+1]={id=rule.id,state=rule.state,priority=rule.priority,tieRank=rule.tieRank,eligible=true}
                    end
                else self.holds[key]=nil end
            end
            for _,rule in ipairs(M.profile.rules) do
                if rule.enabled and rule.module==surface.module then
                    local key=id..":"..rule.id
                    self.compiledUser[rule.id]=self.compiledUser[rule.id] or M.Predicate:Compile(rule.when)
                    local verdict=M.Predicate:EvaluateCompiled(self.compiledUser[rule.id],snapshot)
                    if verdict=="TRUE" then
                        self.holds[key]=self.holds[key] or now
                        nextDeadline(self.holds[key]+rule.dwell)
                        if now-self.holds[key]>=rule.dwell then intents[#intents+1]={id=rule.id,state=rule.state,priority=2,tieRank=20,eligible=true} end
                    else self.holds[key]=nil end
                end
            end
            end -- admitted surfaces never also run unreviewed factory/user predicates
            nextDeadline(surface.interactingUntil)
            if surface.interactingUntil and surface.interactingUntil>now then
                intents[#intents+1]={id="GOV-020",state="VISIBLE",priority=0,tieRank=60,eligible=true}
            end
            state,reason,priority,ticket=M.Resolver:Resolve(surface,intents,cfg.visibility)
            if not ticket and state=="HIDDEN" and reason=="PRS-001" and M.profile.preset=="Balanced" then state="AMBIENT" end
        end
        local targetChanged=state~=surface.desired or (ticket~=nil)~=(surface.admittedTicket~=nil)
        local explanationChanged=reason~=surface.reason
        local urgentReveal=priority==0 and surface.resolvedPriority~=0 and (state=="VISIBLE" or state=="PROTECTED_FLOOR")
        -- Global UI withdrawal cancels even an already-running contextual
        -- conceal. A changed explanation can therefore need a write while
        -- the resolved target remains HIDDEN.
        local snap=reason=="MODULE_STOPPED" or reason=="NATIVE_RESTORE" or reason=="KEYBIND_WORKSPACE" or reason=="TRACKER_WORKSPACE"
            or reason=="NATIVE_UI_HIDDEN" or reason=="CINEMATIC_CONTEXT" or reason=="STARTUP_QUIET"
            or reason=="DUPLICATE_OPTIONAL_PRESENTATION" or state=="PROTECTED_FLOOR"
        surface.resolvedPriority=priority
        if targetChanged or explanationChanged or immediate or ticket or urgentReveal then
            surface.desired=state;surface.reason=reason
            -- An explanation is not a new presentation generation. Keeping the
            -- revision stable lets an identical in-flight target finish.
            if targetChanged then surface.revision=surface.revision+1 end
            if targetChanged or immediate or ticket or urgentReveal or (snap and explanationChanged) then
                -- "immediate" requests a fresh decision, not an opacity jump.
                -- Ordinary event/hover/reveal transitions share the fade; only
                -- withdrawal, native restoration and access floors must snap.
                if surface.contextDelegate then
                    -- A native child inherits the manager's secure gate; it
                    -- is not an independently writable visibility surface.
                    M.Effects.active[id]=nil
                    if M.Policy:TicketCurrent(surface,ticket,now) then
                        surface.admittedTicket=nil
                        surface.actual="SECURE_NATIVE";surface.appliedReason="DELEGATED_GROUP_VISIBILITY"
                        surface.effectStatus="SUBMITTED";surface.confirmed=false
                    else M.Policy:CancelTicket(surface) end
                    if M.VisibilityTrace then M.VisibilityTrace:Record(surface) end
                else M.Effects:Apply(surface,state,reason,snap,ticket,urgentReveal) end
            elseif M.Effects.active[id] then
                M.Effects.active[id].reason=reason
            elseif M.VisibilityTrace then M.VisibilityTrace:Record(surface) end
        end
    end
    if M.Experience then M.Experience:UpdateLauncher(snapshot,now) end
    self.nextDeadline=deadline
    M.stats.batches=M.stats.batches+1
end
function V:Hold(surface,seconds)
    if not self:InputVisible(surface) then return false end
    surface.interactingUntil=M.Safety:Now()+(seconds or .4);self:Tick(true)
    return true
end
function V:Reveal(seconds)
    M.state.revealUntil=M.Safety:Now()+(seconds or 10)
    if M.Signals then M.Signals:Observe() end
    self:Tick(true)
end
