local _,M=...
-- b42 groups share public activity observations, never gameplay payloads or
-- native input authority. A passive rectangle probe reveals one display; it
-- does not install invisible mouse buttons or forward a click.
local S=M.Safety
local P={hoverFade=.22,hoverMinimum=.25,motionGrace=.75,hoverMaximum=5,taxiReleaseDelay=.8,plates={}}
M.PresentationGroups=P
-- Physical screen pixels of net travel from the last accepted position.
local travelRadius=16
local navigation={NAV=true,TRACKER=true,PROGRESS=true,STATUS=true}
local combat={COMBAT=true,PLAYER=true,PET=true,TARGET=true,FOCUS=true,HUD=true}
local function value(snapshot,key)
 local row=snapshot and snapshot[key]
 if row and row.status=="KNOWN" and row.decisionEligible==true and S:Readable(row.value) then return row.value end
end
function P:Enabled()
 local p=M.profile
 return p and p.managed==true and p.preset=="Immersive" and p.enabled~=false
  and M.state.world==true and not M.state.safe and not M.state.cinematic or false
end
function P:Reset(keepFlight)
 -- A zone scope retires activity receipts, but does not prove that a flight
 -- ended. Keep only this cosmetic continuity observation across that boundary;
 -- no native lease, hover hold or gameplay signal survives the reset.
 local flight=keepFlight and self.flight or nil
 self.generation=(self.generation or 0)+1
 self.profile=M.profile;self.world=M.state.world;self.context=M.Policy and M.Policy.contextEpoch
 self.scope=M.Policy and M.Policy.scopeEpoch;self.clock=nil;self.x=nil;self.y=nil
 self.travelX,self.travelY,self.travelUntil,self.pointerChangedAt=nil,nil,0,nil
 self.motionUntil=0;self.targeted=false;self.targetingStatus="NOT_OBSERVED"
 self.plates={};self.hovers=setmetatable({},{__mode="k"});self.sample=nil;self.lastState=nil
 self.rosterCycle=nil;self.rosterReading=nil;self.rosterRevision=(self.rosterRevision or 0)+1
 self.flight=flight
end
function P:Current(now)
 if not S:Number(now) then return false end
 if self.profile~=M.profile or self.world~=M.state.world or self.context~=(M.Policy and M.Policy.contextEpoch)
  or self.scope~=(M.Policy and M.Policy.scopeEpoch) or self.clock and now<self.clock then
  local zoneOnly=self.profile==M.profile and self.world==M.state.world and M.state.world==true
   and self.scope~=(M.Policy and M.Policy.scopeEpoch) and (not self.clock or now>=self.clock)
  self:Reset(zoneOnly)
 end
 self.clock=now
 return self:Enabled()
end
function P:OnEvent(event,unit)
 if event=="PLAYER_LEAVING_WORLD" or event=="PLAYER_ENTERING_WORLD" then self:Reset();return end
 if event=="ZONE_CHANGED" or event=="ZONE_CHANGED_NEW_AREA" or event=="ZONE_CHANGED_INDOORS" then
  local flight=self.flight
  if flight and flight.profile==M.profile and flight.world==M.state.world then
   flight.quietUntil=S:Now()+self.taxiReleaseDelay;flight.falseSince=nil
  end
  return
 end
 if event=="GROUP_ROSTER_UPDATE" then
  self.rosterRevision=(self.rosterRevision or 0)+1
  if self.rosterCycle then self.rosterCycle.sample=nil end
  M.state.forceEvaluate=true;return
 end
 if not S:Text(unit) or not unit:match("^nameplate%d+$") then return end
 if event=="NAME_PLATE_UNIT_ADDED" then
  local count=0;for _ in pairs(self.plates) do count=count+1 end
  if count<80 then self.plates[unit]=true end
 elseif event=="NAME_PLATE_UNIT_REMOVED" then self.plates[unit]=nil end
end
function P:ObserveFlight(snapshot,now)
 local observed=value(snapshot,"TAXI_TRAVEL_ACTIVE")
 if observed==true then
  self.flight={profile=M.profile,world=M.state.world,lastTrue=now}
 elseif self.flight then
  local flight=self.flight
  if flight.profile~=M.profile or flight.world~=M.state.world or now<flight.lastTrue then self.flight=nil
  elseif observed==false then
   -- A single false/missing sample while zoning is not a landing receipt.
   -- Only continuously public false samples over a short settling interval
   -- release the previous flight presentation. Unknown samples restart it.
   flight.falseSince=flight.falseSince or now
   if now-flight.falseSince>=self.taxiReleaseDelay and now>=(flight.quietUntil or 0) then self.flight=nil end
  else flight.falseSince=nil end
 end
end
function P:TaxiActive(snapshot)
 local flight=self.flight
 return value(snapshot,"TAXI_TRAVEL_ACTIVE")==true
  or flight~=nil and flight.profile==M.profile and flight.world==M.state.world
end
local function pointer()
 if type(GetCursorPosition)~="function" then return nil end
 local ok,x,y=pcall(GetCursorPosition)
 if ok and S:Number(x) and S:Number(y) and x>=0 and y>=0 then return x,y end
end
function P:Contains(frame,x,y)
 if not x or not S:Frame(frame,false) then return false end
 local rect=S:Field(frame,"GetRect");local getScale=S:Field(frame,"GetEffectiveScale")
 if type(rect)~="function" or type(getScale)~="function" then return false end
 local ok,left,bottom,width,height=pcall(rect,frame)
 local scale,known=S:Public(getScale,"number",frame)
 if not ok or known~="KNOWN" or not S:Number(left) or not S:Number(bottom) or not S:Number(width)
  or not S:Number(height) or width<=0 or height<=0 or scale<=0 then return false end
 local over=x>=left*scale and x<=(left+width)*scale and y>=bottom*scale and y<=(bottom+height)*scale
 if over and M.DisplayOcclusion and M.DisplayOcclusion:Blocks(frame,true) then return false end
 return over
end
function P:HoverEligible(surface)
 if not surface or surface.disabled or surface.userOpened or surface.presentationHidden then return false end
 if M.state.keybindWorkspace and surface.module~="ActionBars" and surface.module~="Chat" then return false end
 local module=surface.module
 if module=="Nameplates" or module=="Cursor" or module=="BlizzardSkin"
  or module=="Notifications" and not (surface.id=="Notifications.durability" and surface.activityRecipient=="TRACKER") then return false end
 if not M.Experience then return false end
 local recipient=M.Experience:Recipient(surface)
 return navigation[recipient] or combat[recipient] or recipient=="CHAT" or recipient=="GROUP" or recipient=="LAUNCH" or false
end
function P:OverDisplay(x,y)
 for _,surface in pairs(M.surfaces or {}) do
  if self:HoverEligible(surface) and (not M.IsModuleActive or M:IsModuleActive(surface.module))
   and self:Contains(surface.hoverFrame or surface.frame,x,y) then return true end
 end
 for _,row in pairs(M.ContextualNative and M.ContextualNative.rows or {}) do
  local frame=M.ContextualNative.HoverFrame and M.ContextualNative:HoverFrame(row) or row.frame
  if row.active and not row.pending and self:Contains(frame,x,y) then return true end
 end
 return false
end
function P:ObserveTargeting()
 -- Only currently observed native units can prove hostile targeting. Absence
 -- of these units is not a claim about off-screen or unexposed enemies.
 local checked,uncertain=0,false
 local function targetsPlayer(unit)
  local exists,es=S:Public(UnitExists,"boolean",unit)
  if es~="KNOWN" then uncertain=true;return false end
  if not exists then return false end
  local hostile,hs=S:Public(UnitCanAttack,"boolean","player",unit)
  if hs~="KNOWN" then uncertain=true;return false end
  if not hostile then return false end
  local same,ss=S:Public(UnitIsUnit,"boolean",unit.."target","player")
  if ss=="KNOWN" then checked=checked+1;return same==true end
  uncertain=true
  return false
 end
 for _,unit in ipairs({"target","focus","mouseover"}) do if targetsPlayer(unit) then return true,"OBSERVED_HOSTILE_TARGET" end end
 local seen={}
 local provider=M.Rework and M.Rework.Nameplates
 -- Profile/scope retirement clears local event history, but a live native
 -- plate does not necessarily emit NAME_PLATE_UNIT_ADDED again. Reconcile the
 -- existing provider's bounded observations against the current native map;
 -- stale or recycled handles cannot create a targeting observation.
 for _,set in ipairs({self.plates,provider and provider.observed or {}}) do
  local scanned=0
  for unit,plate in pairs(set) do
   scanned=scanned+1;if scanned>80 then break end
   if S:Text(unit) and unit:match("^nameplate%d+$") and not seen[unit] then
    local current=set==self.plates or S:Frame(plate,false)
     and S:Public(C_NamePlate and C_NamePlate.GetNamePlateForUnit,nil,unit)==plate
    if current then
     seen[unit]=true
     if targetsPlayer(unit) then return true,"OBSERVED_HOSTILE_TARGET" end
    end
   end
  end
 end
 if uncertain then return nil,"OBSERVED_TARGETING_UNKNOWN" end
 return false,checked>0 and "OBSERVED_UNITS_CLEAR" or "NO_PUBLIC_HOSTILE_TARGET"
end
-- A CVE decision fans the same roster fact out to many surfaces. Reuse only
-- the value sampled in that synchronous decision, never a cross-frame cache.
-- Direct State calls remain fresh. No native permissions or eligibility
-- checks are cached; they still run at each existing mutation boundary.
function P:BeginRosterCycle(now)
 local valid=S:Number(now)
 self.rosterCycleSerial=(self.rosterCycleSerial or 0)+1
 local cycle={serial=self.rosterCycleSerial,previous=self.rosterCycle,now=valid and now or nil,valid=valid}
 self.rosterCycle=cycle
 return cycle
end
function P:EndRosterCycle(cycle)
 if not cycle then return end
 cycle.closed=true;cycle.sample=nil
 if self.rosterCycle==cycle then self.rosterCycle=cycle.previous end
end
function P:ReadRoster(now)
 local cycle=self.rosterCycle
 local function cycleCurrent()
  return not cycle or self.rosterCycle==cycle and not cycle.closed and cycle.serial==self.rosterCycleSerial
   and cycle.valid==true and now>=cycle.now
 end
 if not cycleCurrent() then return nil,"UNKNOWN",true end
 local sample=cycle and cycle.sample
 if sample and sample.current() then return sample.count,sample.status,false end
 -- A getter may synchronously re-enter a decision or retire its context.
 -- Invalidate the interrupted read rather than publishing its old count.
 if self.rosterReading then
  self.rosterRevision=(self.rosterRevision or 0)+1
  if cycle then cycle.sample=nil end
  return nil,"UNKNOWN",true
 end
 local profile,state,policy,safety=M.profile,M.state,M.Policy,M.Safety
 local generation,revision=self.generation,self.rosterRevision
 local world,context,scope,capability=state.world,policy.contextEpoch,policy.scopeEpoch,policy.capabilityEpoch
 local getter,public,number,readable=GetNumGroupMembers,S.Public,S.Number,S.Readable
 local secret,access=issecretvalue,canaccessvalue
 local function current()
  return M.PresentationGroups==self and self.generation==generation and self.rosterRevision==revision
   and M.profile==profile and M.state==state and state.world==world and M.Policy==policy and M.Safety==safety and safety==S
   and policy.contextEpoch==context and policy.scopeEpoch==scope and policy.capabilityEpoch==capability
   and GetNumGroupMembers==getter and S.Public==public and S.Number==number and S.Readable==readable
   and issecretvalue==secret and canaccessvalue==access and self:Enabled() and cycleCurrent()
 end
 local token={};self.rosterReading=token
 local ok,count,status=pcall(public,S,getter,"number")
 if self.rosterReading==token then self.rosterReading=nil end
 if not ok then error(count,0) end
 if not current() then return nil,"UNKNOWN",true end
 if cycle then cycle.sample={count=count,status=status,current=current} end
 return count,status,false
end
function P:Observe(snapshot,now)
 now=now or S:Now()
 if not self:Current(now) then self.sample=nil;return end
 local x,y=pointer()
 if M.StartupPresentation and M.StartupPresentation.ObserveActivity then M.StartupPresentation:ObserveActivity(snapshot,x,y,now) end
 self.hoverFade=M.Effects and M.Effects.ContextDuration and M.Effects:ContextDuration() or M.profile and M.profile.fade or .22
 local moved=x and self.x and (math.abs(x-self.x)>1 or math.abs(y-self.y)>1)
 if x~=self.x or y~=self.y then self.pointerChangedAt=now
 elseif x and self.pointerChangedAt and now-self.pointerChangedAt>=self.motionGrace then
  -- Start the next gesture at the actual resting point, including the
  -- sub-threshold remainder left over at the end of a deliberate movement.
  self.travelX,self.travelY=x,y;self.pointerChangedAt=nil
 end
 self.x,self.y=x,y
 self:ObserveFlight(snapshot,now)
 local taxi=self:TaxiActive(snapshot)
 local moving=value(snapshot,"PLAYER_MOVING")
 -- Inspection motion is local; moving over a hidden chat panel must not wake
 -- the navigation group. World pointer motion remains travel activity.
 local dx=x and self.travelX and x-self.travelX
 local dy=y and self.travelY and y-self.travelY
 local traveled=dx and dx*dx+dy*dy>=travelRadius*travelRadius
 local inspect=(moved or traveled) and self:OverDisplay(x,y)
 local afk=value(snapshot,"PLAYER_AFK")==true
 local grace=math.max(self.motionGrace,M.profile.idle or 0)
 if taxi or afk then self.motionUntil=0
 elseif moving==true or moved and not inspect then self.motionUntil=now+grace end
 -- Keep the anchor through small steps. Oscillation close to it is quiet,
 -- while even slow movement in one direction eventually crosses the radius.
 if taxi or afk then self.travelUntil=0
 elseif moving==true or traveled and not inspect then self.travelUntil=now+grace end
 if not dx or taxi or afk or inspect or traveled or moving==true then
  self.travelX,self.travelY=x,y
 end
 self.targeted,self.targetingStatus=self:ObserveTargeting()
 self.sample=nil
 local state=self:State(snapshot,now)
 local previous=self.lastState
 if not previous or previous.navigation~=state.navigation or previous.combat~=state.combat or previous.idle~=state.idle
  or previous.grouped~=state.grouped or previous.taxi~=state.taxi or moved and inspect then M.state.forceEvaluate=true end
 self.lastState=state
end
function P:State(snapshot,now)
 snapshot=snapshot or M.Store and M.Store:Snapshot() or {}
 now=now or S:Now()
 if not self:Current(now) then return {enabled=false} end
 local actual=value(snapshot,"PLAYER_IN_COMBAT")
 local target=value(snapshot,"TARGET_EXISTS");local focus=value(snapshot,"FOCUS_EXISTS")
 local engaged=actual==true or target==true or focus==true or self.targeted==true
 if not engaged and (actual==nil or target==nil or focus==nil or self.targeted==nil) then engaged=nil end
 local taxi=self:TaxiActive(snapshot)
 -- Flight defaults to quiet even with an old selected target. Actual combat
 -- or a publicly observed hostile target still establishes active combat;
 -- unavailable observations must not authorize a flight concealment.
 if taxi then
  if actual==true or self.targeted==true then engaged=true
  elseif actual==nil or self.targeted==nil then engaged=nil
  else engaged=false end
 end
 local moving=value(snapshot,"PLAYER_MOVING")
 local motion=moving==true or now<(self.motionUntil or 0)
 local afk=value(snapshot,"PLAYER_AFK")==true
 local motionKnown=moving~=nil or motion
 if taxi or afk then motion=false;motionKnown=true end
 local idle
 if engaged==true or motion then idle=false
 elseif engaged==nil or not motionKnown then idle=nil
 else idle=true end
 local count,known,retired=self:ReadRoster(now)
 if retired then return {enabled=false} end
 local grouped
 if known=="KNOWN" and count>=0 then grouped=count>1
 else
  local kind=value(snapshot,"GROUP_TYPE")
  if kind=="SOLO" then grouped=false elseif kind=="PARTY" or kind=="RAID" then grouped=true end
 end
 if value(snapshot,"TEMP_REVEAL")==true or value(snapshot,"EDIT_MODE")==true then idle=false end
 local navigating=not taxi and not afk and (moving==true or now<(self.travelUntil or 0))
 if not taxi and not afk and moving==nil and not navigating then navigating=nil end
 return {enabled=true,combat=engaged,actualCombat=actual,
  idle=idle,navigation=navigating,taxi=taxi,grouped=grouped,
  targeted=self.targeted,targetingStatus=self.targetingStatus,deadline=self.travelUntil}
end
function P:Demand(recipient,snapshot,now)
 if M.state.keybindWorkspace and recipient~="CHAT" then return false,"KEYBIND_WORKSPACE" end
 if M.StartupPresentation and M.StartupPresentation:IsQuiet() then return false,"STARTUP_IDLE" end
 snapshot=snapshot or M.Store and M.Store:Snapshot() or {}
 local state=self:State(snapshot,now)
 if not state.enabled then return nil,"GROUPS_DISABLED" end
 if navigation[recipient] then
  -- Combat is an explicit sidebar policy, including when a recent XP/quest
  -- event, hover, or movement would otherwise retain a navigation hold.
  if state.actualCombat==true or S:InCombat() then
   return recipient=="NAV",recipient=="NAV" and "NAV_COMBAT_DIM" or "NAV_COMBAT_CONCEALED"
  end
  if value(snapshot,"MAP_OPEN")==true then return false,"NATIVE_MAP_CONTEXT" end
  if not state.taxi and M.NavigationPin and M.NavigationPin:Active()==true then return true,"GROUP_USER_WAYPOINT" end
  -- Quest/XP/zone receipts still provide useful local context, but all three
  -- sidebar members consume one maximum hold instead of separate deadlines.
  local activity=M.ScopedActivity
  if not state.taxi and value(snapshot,"PLAYER_AFK")~=true and activity then
   local active,deadline=false,state.deadline
   for _,key in ipairs({"NAV","TRACKER","PROGRESS","STATUS"}) do
    local yes,due=activity:Active(key,now)
    if yes then active=true;if due and (not deadline or due>deadline) then deadline=due end end
   end
   if active then return true,"GROUP_NAVIGATION_CUE",deadline end
  end
  return state.navigation,"GROUP_NAVIGATION",state.deadline
 end
 if combat[recipient] then return state.combat,"GROUP_COMBAT" end
 if recipient=="GROUP" then
  if state.grouped==false then return false,"GROUP_SOLO" end
  if state.grouped==nil then return nil,"GROUP_ROSTER_UNKNOWN" end
  if state.idle==nil then return nil,"GROUP_ACTIVITY_UNKNOWN" end
  return not state.idle,"GROUP_ROSTER"
 end
 if recipient=="PLATES" then
  if state.combat then return true,"GROUP_COMBAT" end
  if state.idle==nil then return nil,"GROUP_ACTIVITY_UNKNOWN" end
  return not state.idle,state.taxi and "GROUP_FLIGHT_IDLE" or "GROUP_NAMEPLATES"
 end
 if recipient=="CURSOR" then
  if state.idle==nil then return nil,"GROUP_ACTIVITY_UNKNOWN" end
  return state.idle==false,"GROUP_CURSOR"
 end
 return nil,"NO_PRESENTATION_GROUP"
end
function P:IsNavigation(recipient) return navigation[recipient]==true end
-- A protected action button cannot be revealed by an ordinary combat timer.
-- The action owner consumes this shared duration in its prebuilt secure dwell
-- controller; other displays retain their existing inspection behavior.
function P:MinimumHoverTime() return self.hoverMinimum end
function P:ActionDemand(snapshot,now,profile)
 if M.state.keybindWorkspace then return true,"KEYBIND_WORKSPACE" end
 if M.StartupPresentation and M.StartupPresentation:IsQuiet() then return false,"STARTUP_IDLE" end
 profile=profile or M.profile
 local cfg=profile and profile.modules and profile.modules.ActionBars
 if not cfg or not cfg.enabled or profile.enabled==false or M.state.safe or not M.state.world then return false,"ACTION_INACTIVE" end
 snapshot=snapshot or M.Store and M.Store:Snapshot() or {}
 if value(snapshot,"TEMP_REVEAL")==true or value(snapshot,"EDIT_MODE")==true then return true,"ACTION_INSPECTION" end
 local preference=M.ElementRules and M.ElementRules:Preference("ActionBars.interface",snapshot,profile)
 if preference then return preference=="SHOW","ELEMENT_CONTEXT_"..preference end
 if cfg.visibility=="Manual" then return false,"ACTION_MANUAL" end
 if cfg.visibility=="Always" then return true,"ACTION_ALWAYS" end
 local demand,why=self:Demand("COMBAT",snapshot,now)
 if why~="GROUPS_DISABLED" then return demand,why end
 local actual=value(snapshot,"PLAYER_IN_COMBAT")
 local target=value(snapshot,"TARGET_EXISTS");local focus=value(snapshot,"FOCUS_EXISTS")
 if actual==true or target==true or focus==true then return true,"ACTION_COMBAT_CONTEXT" end
 if actual==false and target==false and focus==false then return false,"ACTION_QUIET_CONTEXT" end
 return nil,"ACTION_CONTEXT_UNKNOWN"
end
function P:CombatIntent(surface,snapshot)
 if not self:Enabled() or not M.Experience then return end
 local recipient=M.Experience:Recipient(surface)
 if not navigation[recipient] or not (value(snapshot,"PLAYER_IN_COMBAT")==true or S:InCombat()) then return end
 return {id=recipient=="NAV" and "NAV_COMBAT_DIM" or "NAV_COMBAT_CONCEALED",
  state=recipient=="NAV" and "VISIBLE" or "HIDDEN",priority=0,tieRank=100,eligible=true}
end
function P:TransitionClock(recipient)
 if self:Enabled() and (navigation[recipient] or combat[recipient] or recipient=="GROUP" or recipient=="PLATES" or recipient=="CURSOR")
  and self.cycleProfile==M.profile and S:Number(self.cycleNow) then return self.cycleNow end
 return S:Now()
end
function P:FlushNavigation()
 -- These providers used to wait for separate .25s work ticks after CVE had
 -- already decided the same cohort. Submit their visibility in the decision
 -- cycle; later provider ticks simply renew the same animation target.
 if not self:Enabled() then return end
 local r=M.Rework
 for _,name in ipairs({"Minimap","Objectives"}) do
  local provider=r and r[name]
  if provider and provider.active and provider.surface and not provider.surface.disabled and type(provider.Visibility)=="function" then
   M:Guard(provider.module or name,provider.Visibility,provider)
  end
 end
end
function P:FlushCombat()
 -- Passive combat surfaces were resolved by CVE above and native unit/aura
 -- gates by ContextualNative. The compact action interface has a separate
 -- secure controller: refresh its ordinary demand in this same cycle rather
 -- than waiting for its independent 0.2 second maintenance window.
 if not self:Enabled() then return end
 local actions=M.ActionInterface
 if actions and actions.active and type(actions.RefreshContext)=="function" then
  M:Guard("ActionBars",actions.RefreshContext,actions)
 end
end
function P:Report()
 return "presentation_groups=SHARED_DECISION_CYCLE_AND_FADE_RATE; combat_cohort=UNIT_AURA_HUD_METERS_COOLDOWNS_ACTIONS\nsidebar_combat=MINIMAP_HALF_OPACITY_XP_AND_QUESTS_HIDDEN\nsidebar_visibility_evidence=PUBLIC_POLICY_AND_NATIVE_DRIVER_SUBMISSION_NOT_RENDER_CERTIFICATION"
end
function P:ActionOwnsHover(owner,x,y)
 if not owner or owner.module=="ActionBars" or not self:Enabled() then return false end
 local recipient=M.Experience and M.Experience:Recipient(owner)
 -- Native cooldown/aura rows have a module but no ordinary surface groups.
 -- Navigation, chat and other independent inspection contexts keep their own
 -- hover behavior, including the explicit navigation override during flight.
 if not combat[recipient] and recipient~="GROUP" and owner.module~="Cooldowns" and owner.module~="Auras"
  and owner.module~="DamageMeters" and owner.module~="PartyRaid" then return false end
 local action=M.ActionInterface
 if not action or type(action.OwnsHoverAt)~="function" then return false end
 if x==nil then x,y=pointer() end
 return x~=nil and action:OwnsHoverAt(x,y)==true or false
end
function P:Hover(owner,frame,now)
 if M.StartupPresentation and M.StartupPresentation:IsQuiet() then return false end
 now=now or S:Now()
 if not self:Current(now) or not owner or not frame then return false end
 self.hovers=self.hovers or setmetatable({},{__mode="k"})
 local row=self.hovers[owner]
 if row and row.frame~=frame then row=nil;self.hovers[owner]=nil end
 local x,y=pointer()
 if self:ActionOwnsHover(owner,x,y) then
  self.hovers[owner]=nil
  return false,nil,true
 end
 local look,known=S:Public(IsMouselooking,"boolean")
 local over=known=="KNOWN" and look==false and self:Contains(frame,x,y)
 if over then
  row=row or {frame=frame,start=now};self.hovers[owner]=row
  if not row.over then row.start=now end
  row.over=true
  -- While inspected, remain visible. Dwell earns an after-leave reading hold
  -- capped at five seconds; re-entry starts a new bounded hold.
  row.expires=now+math.min(self.hoverMaximum,math.max(.25,now-row.start))
  return true,row.expires
 end
 if row then
  row.over=false
  if now<row.expires then return true,row.expires end
  self.hovers[owner]=nil
 end
 return false
end
function P:HoverIntent(surface,now)
 if not self:Enabled() or not self:HoverEligible(surface) then return nil end
 -- The passive durability follower uses the Quest display's exact inspection
 -- receipt and deadline. It adds no invisible click target or independent hold.
 local owner=surface
 if surface.id=="Notifications.durability" and surface.hoverOwnerID then
  local quest=M.surfaces and M.surfaces[surface.hoverOwnerID]
  if self:HoverEligible(quest) then owner=quest end
 end
 local yes,due=self:Hover(owner,owner.hoverFrame or owner.frame,now)
 surface.localHover=yes==true
 if yes then return {id="LOCAL_HOVER_INSPECTION",state="VISIBLE",priority=0,tieRank=60,eligible=true},due end
end
