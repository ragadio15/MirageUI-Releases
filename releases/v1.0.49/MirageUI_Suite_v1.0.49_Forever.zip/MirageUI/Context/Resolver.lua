local _, M = ...
M.Resolver={}
function M.Resolver:Resolve(surface,intents,manual)
    if surface.floor then return "PROTECTED_FLOOR","NATIVE_ACCESS_FLOOR",0 end
    local candidates={}
    for _,intent in ipairs(intents or {}) do
        if intent.eligible and M.States[intent.state] then candidates[#candidates+1]=intent end
    end
    table.sort(candidates,function(a,b)
        if a.priority~=b.priority then return a.priority<b.priority end
        if (a.tieRank or 0)~=(b.tieRank or 0) then return (a.tieRank or 0)>(b.tieRank or 0) end
        return a.id<b.id
    end)
    local best=candidates[1]
    -- Mandatory/native safety intents outrank both pin and manual-hide preferences.
    if not best or (best.priority>0 and best.id~="ELEMENT_CONTEXT_SHOW" and best.id~="ELEMENT_CONTEXT_HIDE") then
        if manual=="Always" then return "VISIBLE","USER_PIN",1 end
        if manual=="Manual" and not M.state.edit and (M.state.revealUntil or 0)<=M.Safety:Now() then return "HIDDEN","USER_MANUAL",2 end
    end
    if not best then return surface.fallback or "VISIBLE","NO_ELIGIBLE_RULE",3 end
    for i=2,#candidates do
        local other=candidates[i]
        if other.priority==best.priority and (other.tieRank or 0)==(best.tieRank or 0) and other.state~=best.state then
            return surface.fallback or "VISIBLE","UNRESOLVED_TIE",best.priority
        end
    end
    return best.state,best.id,best.priority,best.ticket
end
