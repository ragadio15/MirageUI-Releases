local _,M=...
-- Twelve source-linked BINDING CANDIDATES. No native approval, provider
-- permission, game frame or active policy is created by this file.
M.FirstTranche={version=1,native='NOT_RUN',status='SOURCE_IMPLEMENTED_REVIEW_REQUIRED'}
local T=M.FirstTranche
local function eq(k,v) return {op='eq',signal=k,value=v} end
local function all(...) return {op='all',args={...}} end
local function hold(n,a) return {op='hold',seconds=n,arg=a} end
local function build()
 return {
  {'GOV-007','VISIBLE',1,70,eq('MODULE_PINNED',true),'Explicit display pin'},
  {'GOV-009','VISIBLE',0,65,eq('TEMP_REVEAL',true),'Temporary reveal'},
  {'GOV-020','VISIBLE',0,80,eq('INTERACTION_LEASE_ACTIVE',true),'Active interaction hold'},
  {'GOV-025','HIDDEN',0,90,eq('SAFE_MODE_REQUESTED',true),'Stop passive optional art in SAFE; retain native access'},
  {'PRS-001','HIDDEN',3,1,{op='dwell',seconds=2.5,arg=all(eq('PLAYER_STATIONARY',true),eq('PLAYER_IN_COMBAT',false),eq('INPUT_FOCUSED',false),eq('DIALOG_OPEN',false),eq('MODULE_OPEN',false),eq('MAP_OPEN',false),eq('TARGET_EXISTS',false),eq('PLAYER_CASTING',false),eq('PLAYER_CHANNELING',false))},'Quiet idle after a bounded dwell'},
  {'PRS-002','VISIBLE',2,30,all(eq('PLAYER_MOVING',true),eq('PLAYER_IN_COMBAT',false),eq('MAP_OPEN',false)),'Movement navigation'},
  {'PRS-003','VISIBLE',2,20,all(hold(1.5,eq('PLAYER_MOVING',true)),eq('PLAYER_IN_COMBAT',false),eq('MAP_OPEN',false)),'Brief navigation hold'},
  {'CBT-001','VISIBLE',1,60,eq('PLAYER_IN_COMBAT',true),'Combat information'},
  {'CBT-006','VISIBLE',1,55,eq('PLAYER_CASTING',true),'Player casting'},
  {'CBT-007','VISIBLE',1,55,eq('PLAYER_CHANNELING',true),'Player channeling'},
  {'TGT-001','VISIBLE',2,40,eq('TARGET_EXISTS',true),'Selected target'},
  {'GRP-001','VISIBLE',2,35,eq('GROUP_TYPE','PARTY'),'Party context'},
 }
end
function T:Build(surfaceID,selection)
 if surfaceID~="DEMO.passive" then
  local surface=M.Policy.owners[surfaceID]
  if not surface or surface.security~="OWNED_VISUAL" or surface.native or surface.floor then return nil,"PASSIVE_OWNED_SCOPE_REQUIRED" end
  if type(selection)~="table" or not next(selection) then return nil,"EXPLICIT_RULE_SELECTION_REQUIRED" end
 end
 local valid={};for _,r in ipairs(build()) do valid[r[1]]=true end
 for id,value in pairs(selection or {}) do if not valid[id] or value~=true then return nil,"INVALID_RULE_SELECTION" end end
 local out={registryDigest=M.Authority.digest,derived={},rules={}}
 for _,r in ipairs(build()) do
  if not selection or selection[r[1]] then
   local source=M.Authority.rules[r[1]]
   if not source then return nil,'SOURCE_MISSING' end
   out.rules[#out.rules+1]={id=r[1],sourceDigest=source.digest,surface=surfaceID,state=r[2],priority=r[3],tieRank=r[4],when=r[5]}
  end
 end
 return out
end
function T:Manifest()
 local rows={}
 for _,r in ipairs(build()) do local s=M.Authority.rules[r[1]]
  rows[#rows+1]={id=r[1],sourceDigest=s and s.digest or 'MISSING',priority=r[3],tieRank=r[4],label=r[6],state=r[2],status=self.status,native='NOT_RUN',enabled=false}
 end
 return rows
end
function T:Rehearsal()
 -- Isolated policy instance and synthetic surface. Never touches the active
 -- registry, live observations, frames, settings, approvals or native APIs.
 local policy=setmetatable({owners={},leases={},approvals={},permissions={},contextEpoch=1,capabilityEpoch=1,rulesetEpoch=0}, {__index=M.Policy})
 local surface={id='DEMO.passive',module='Context',security='OWNED_VISUAL',ownerEpoch=1,fallback='VISIBLE'}
 policy.owners[surface.id]=surface
 local candidate=self:Build(surface.id)
 local graph,why=policy:Compile(candidate,true)
 if not graph then return 'DEMO unavailable: '..tostring(why) end
 local base={MODULE_PINNED=false,TEMP_REVEAL=false,INTERACTION_LEASE_ACTIVE=false,SAFE_MODE_REQUESTED=false,PLAYER_MOVING=false,PLAYER_STATIONARY=true,PLAYER_IN_COMBAT=false,INPUT_FOCUSED=false,DIALOG_OPEN=false,MODULE_OPEN=false,MAP_OPEN=false,TARGET_EXISTS=false,PLAYER_CASTING=false,PLAYER_CHANNELING=false,GROUP_TYPE='SOLO'}
 local scenes={
  {'Quiet after idle',{}}, {'Moving',{PLAYER_MOVING=true,PLAYER_STATIONARY=false}},
  {'Combat',{PLAYER_IN_COMBAT=true}}, {'Casting',{PLAYER_CASTING=true}}, {'Channeling',{PLAYER_CHANNELING=true}},
  {'Target selected',{TARGET_EXISTS=true}}, {'Party',{GROUP_TYPE='PARTY'}}, {'Pinned',{MODULE_PINNED=true}},
  {'Nested interaction',{INTERACTION_LEASE_ACTIVE=true}}, {'SAFE',{SAFE_MODE_REQUESTED=true,MODULE_PINNED=true}},
  {'Unknown observations',{},'UNKNOWN'}, {'Restricted observations',{},'RESTRICTED'},
 }
 local lines={'DEMO — fabricated context; not an in-game test.','Twelve scoped candidate bindings, not twelve approved or enabled rules.','This isolated rehearsal cannot change your interface.',''}
 for _,scene in ipairs(scenes) do
  local observations={}
  for key,value in pairs(base) do
   if scene[2][key]~=nil then value=scene[2][key] end
   local public=value;if scene[3] then public=nil end
   observations[key]={status=scene[3] or 'KNOWN',value=public,decisionEligible=true,contextEpoch=1,capabilityEpoch=1,expiresAt=100}
  end
  graph.cache={};graph.temporal={}
  policy:Evaluate(graph,observations,0)
  local result=policy:Evaluate(graph,observations,3)
  local state,reason=policy:Resolve(graph,result,surface,'VISIBLE')
  lines[#lines+1]=scene[1]..': '..state..' — '..reason
 end
 lines[#lines+1]='\nLive use requires choosing relevant rules per owned surface, reviewing priorities and exact-build provider/effect permissions, recording native tests, and explicit owner approval. This screen grants none of them.'
 return table.concat(lines,'\n')
end
