local _,M=...
-- N11: a real native user waypoint is an explicit local navigation demand.
-- Reviewed C_Map.HasUserWaypoint / USER_WAYPOINT_UPDATED contracts are identical
-- on Forever 70862, 70888, 70938, 70959 and 71037 (MapDocumentation.lua). No destination, coordinate,
-- range, proximity, super-tracking payload, or native mutator is used here.
local P={status="NOT_OBSERVED",reason="WAYPOINT_NOT_OBSERVED",dirty=true,revision=0,reads=0}
M.NavigationPin=P
local S=M.Safety
local sourcePin=M.Client:NewSourcePinLookup()
local events={"USER_WAYPOINT_UPDATED","PLAYER_MAP_CHANGED","PLAYER_ENTERING_WORLD","PLAYER_LEAVING_WORLD",
 "PLAYER_REGEN_DISABLED","PLAYER_REGEN_ENABLED"}
local eventSet={};for _,event in ipairs(events) do eventSet[event]=true end
local function qualified()
 local c=M.Client;local runtime=c and (c.IsRuntimeClient or c.IsReviewedPresentationClient)
 return c and type(runtime)=="function" and runtime(c)==true or false
end
local function enabled()
 local p=M.profile;local modules=p and p.modules
 return p and p.enabled==true and modules
  and ((modules.Minimap and modules.Minimap.enabled==true) or (modules.QuestTracker and modules.QuestTracker.enabled==true))
  and M.state.world==true and not M.state.safe and not M.state.cinematic or false
end
function P:Invalidate()
 self.active=nil;self.dirty=true;self.status="STALE";self.reason="WAYPOINT_INVALIDATED"
 self.revision=math.min(2147483647,self.revision+1)
 M.state.forceEvaluate=true
end
function P:Event(event)
 if not eventSet[event] then return end
 if event=="PLAYER_LEAVING_WORLD" then self.worldLeaving=true
 elseif event=="PLAYER_ENTERING_WORLD" then self.worldLeaving=nil end
 self:Invalidate()
end
function P:Stop()
 if self.frame and self.listening then
  for _,event in ipairs(events) do pcall(self.frame.UnregisterEvent,self.frame,event) end
 end
 self.listening=nil;self.attempted=nil
 self.active=nil;self.dirty=true
end
function P:Listen()
 if self.listening then return true end
 if self.attempted then return false end
 self.attempted=true
 if not self.frame then
  if type(CreateFrame)~="function" then return false end
  local ok,frame=pcall(CreateFrame,"Frame")
  if not ok or not S:Frame(frame,false) then return false end
  self.frame=frame
  local installed=pcall(frame.SetScript,frame,"OnEvent",function(_,event)
   self:Event(event)
   -- Disabled/safe profiles retain no optional observer subscription.
   if not enabled() or not qualified() then self:Stop() end
  end)
  if not installed then self.frame=nil;return false end
 end
 for _,event in ipairs(events) do
  local ok,value=pcall(self.frame.RegisterEvent,self.frame,event)
  local registered,state=S:Public(self.frame.IsEventRegistered,"boolean",self.frame,event)
  if not ok or value==false or state~="KNOWN" or registered~=true then
   for _,remove in ipairs(events) do pcall(self.frame.UnregisterEvent,self.frame,remove) end
   return false
  end
 end
 self.listening=true
 return true
end
function P:SameGeneration(api,fn)
 local policy=M.Policy or {};local c=M.Client
 return self.profile==M.profile and self.context==policy.contextEpoch and self.scope==policy.scopeEpoch
  and self.capability==policy.capabilityEpoch and self.client==c and self.clientKey==c.key
  and self.api==api and self.fn==fn and self.world==M.state.world
  and self.safe==M.state.safe and self.cinematic==M.state.cinematic
end
function P:Unavailable(status,reason,stop)
 if stop then self:Stop() end
 self.active=nil;self.status=status;self.reason=reason
 return false,reason,status
end
function P:Active()
 if not qualified() then return self:Unavailable("UNSUPPORTED","WAYPOINT_SOURCE_UNAVAILABLE",true) end
 if not enabled() then return self:Unavailable("INACTIVE","WAYPOINT_INACTIVE",true) end
 local api=C_Map;local fn,state=S:FieldAccess(api,"HasUserWaypoint")
 if state~="KNOWN" or type(fn)~="function" then
  return self:Unavailable(state=="RESTRICTED" and "RESTRICTED" or "UNSUPPORTED","WAYPOINT_API_UNAVAILABLE",true)
 end
 if not self:SameGeneration(api,fn) then
  self:Invalidate()
  local policy=M.Policy or {}
  self.profile=M.profile;self.context=policy.contextEpoch;self.scope=policy.scopeEpoch;self.capability=policy.capabilityEpoch
  self.client=M.Client;self.clientKey=M.Client.key;self.api=api;self.fn=fn
  self.world=M.state.world;self.safe=M.state.safe;self.cinematic=M.state.cinematic
  -- Native world entry may have occurred while the disabled observer was absent.
  self.worldLeaving=nil
  self.attempted=nil
 end
 if not self:Listen() then return self:Unavailable("UNSUPPORTED","WAYPOINT_EVENTS_UNAVAILABLE") end
 if self.worldLeaving then return self:Unavailable("STALE","WAYPOINT_WORLD_TRANSITION") end
 if not self.dirty then return self.active==true,self.reason,self.status end
 local revision=self.revision
 self.reads=math.min(2147483647,self.reads+1)
 local value,known=S:Public(fn,"boolean")
 local currentApi=C_Map;local currentFn,currentState=S:FieldAccess(currentApi,"HasUserWaypoint")
 -- Public probes can invoke callbacks. A prior profile/world/API generation
 -- cannot publish into the replacement, even when the returned boolean is true.
 if revision~=self.revision or not self:SameGeneration(api,fn) or currentState~="KNOWN" or currentApi~=api or currentFn~=fn
  or not enabled() or not qualified() or self.worldLeaving then
  self.dirty=true
  return self:Unavailable("STALE","WAYPOINT_GENERATION_CHANGED")
 end
 self.dirty=false
 self.status=known
 if known=="KNOWN" then
  self.active=value;self.reason=value and "NATIVE_USER_WAYPOINT" or "NO_NATIVE_USER_WAYPOINT"
 else
  self.active=nil;self.reason=known=="RESTRICTED" and "WAYPOINT_VALUE_RESTRICTED" or "WAYPOINT_VALUE_UNAVAILABLE"
 end
 return self.active==true,self.reason,self.status
end
function P:Report()
 self:Active()
 return "navigation_pin="..self.status..";reason="..self.reason..";reads="..self.reads..";revision="..self.revision
  ..";scope=NATIVE_USER_WAYPOINT_PRESENCE_ONLY;native=NOT_RUN"
end
