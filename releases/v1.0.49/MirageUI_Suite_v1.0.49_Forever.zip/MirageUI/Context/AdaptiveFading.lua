local _,M=...
-- Retain the existing caller interface while every contextual transition uses
-- the saved duration. Repeated motion and hover no longer accumulate pressure
-- that changes the speed of the same presentation action.
local S=M.Safety
local A={}
M.AdaptiveFading=A
function A:Reset()
 self.frames=setmetatable({},{__mode="k"});self.groups={}
 self.profile=M.profile;self.world=M.state.world;self.scope=M.Policy and M.Policy.scopeEpoch
 self.clock=nil
end
function A:Recipient(owner,options)
 if options and options.recipient then return options.recipient end
 if owner.navigationRecipient then return owner.navigationRecipient end
 local surface=owner.surface or owner
 if surface.module and M.Experience then return M.Experience:Recipient(surface) end
 if owner.name and M.ContextualNative and M.ContextualNative.Recipient then
  return M.ContextualNative:Recipient(owner.name,owner.module)
 end
 if owner.id and M.modules and M.modules[owner.id] and M.Experience then
  return M.Experience:Recipient({module=owner.id})
 end
end
function A:Urgent(owner,shown,options)
 options=options or {}
 if options.urgent==true or S:InCombat() then return true end
 if not shown then return false end
 local state=M.state or {};local now=S:Now()
 local surface=owner.surface or owner
 if state.edit==true or S:Number(state.revealUntil) and state.revealUntil>now
  or owner.userOpened==true or surface.userOpened==true or owner.inputHeld==true then return true end
 local reason=options.reason or surface.reason or owner.reason
 return surface.module=="UnderCharacterHUD" and (reason=="HUD_CAST_LOCAL" or reason=="LOCAL_PLAYER_CAST") or false
end
-- Contextual transitions now keep one saved duration. Frequent movement,
-- local hover and combat no longer lengthen/shorten the same visual action.
-- Keep this entry point for existing callers; no history or per-frame table
-- allocation is needed to standardize the timing.
function A:Duration(owner,frame,shown,baseline,options)
 return baseline
end
function A:Forget(frame)
 if self.frames then self.frames[frame]=nil end
end
function A:Report()
 local effects=M.Effects
 local value=effects and effects.ContextDuration and effects:ContextDuration() or M.profile and M.profile.fade or .22
 return string.format("adaptive_fading=STANDARDIZED; duration=%.3f; easing=LINEAR; reversal=CONTINUOUS_CONSTANT_RATE; hover=SAME_DURATION; history=DISABLED; protected_deadline_completions=%d",
  value,effects and effects.deadlineCompletions or 0)
end
