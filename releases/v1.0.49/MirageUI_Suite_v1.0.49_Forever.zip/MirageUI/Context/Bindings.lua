local _, M = ...
-- Reviewed binding definitions, not generated interpretations of registry prose.
-- Execution is explicitly candidate-scoped. Native acceptance remains NOT_RUN.
M.RuleBindings={}
local function eq(id,value) return {op="eq",signal=id,value=value} end
local function all(...) return {op="all",args={...}} end
local function any(...) return {op="any",args={...}} end
local function add(id,groups,when,state,priority,tie,dwell)
    M.RuleBindings[#M.RuleBindings+1]={id=id,groups=groups,when=when,state=state,priority=priority,tieRank=tie or 0,dwell=dwell or 0}
end
add("GOV-009",{"all"},eq("TEMP_REVEAL",true),"VISIBLE",0,20)
add("GOV-011",{"all"},eq("EDIT_MODE",true),"VISIBLE",0,25)
add("CBT-001",{"combat","group"},eq("PLAYER_IN_COMBAT",true),"VISIBLE",1,30)
add("CBT-003",{"combat","group"},eq("COMBAT_RECOVERY",true),"VISIBLE",1,25)
add("PRS-002",{"navigation"},all(eq("PLAYER_MOVING",true),eq("MAP_OPEN",false)),"VISIBLE",2,10)
add("PRS-003",{"navigation"},all(eq("NAVIGATION_HOLD",true),eq("MAP_OPEN",false)),"VISIBLE",2,9)
add("PRS-001",{"navigation","ambient"},all(eq("PLAYER_STATIONARY",true),eq("PLAYER_IN_COMBAT",false)),"HIDDEN",3,1,"idle")
add("NAV-015",{"navigation"},eq("MAP_OPEN",true),"HIDDEN",1,80)
add("NAV-005",{"navigation"},eq("TAXI_TRAVEL_ACTIVE",true),"VISIBLE",2,10)
add("NAV-013",{"location"},eq("ZONE_CHANGED",true),"VISIBLE",2,10)
add("SOC-002",{"chat"},eq("RECENT_CHAT",true),"VISIBLE",2,10)
add("QST-001",{"objectives"},eq("QUEST_ACCEPTED",true),"VISIBLE",2,20)
add("QST-004",{"objectives"},eq("QUEST_OBJECTIVE_CHANGED",true),"VISIBLE",2,20)
add("QST-012",{"progress"},eq("XP_GAINED",true),"VISIBLE",2,15)
add("QST-013",{"progress"},eq("LEVEL_GAINED",true),"EMPHASIZED",2,20)
add("ECO-001",{"bags"},eq("BAGS_OPEN",true),"VISIBLE",1,30)
add("ECO-003",{"bags"},eq("BANK_OPEN",true),"VISIBLE",1,30)
add("ECO-004",{"tasks"},eq("VENDOR_OPEN",true),"VISIBLE",1,30)
add("ECO-006",{"tasks"},eq("TRADE_OPEN",true),"VISIBLE",0,30)
add("GOV-005",{"tasks"},eq("DIALOG_OPEN",true),"VISIBLE",0,40)
add("GOV-022",{"ambient","navigation"},eq("WORLD_LOAD_OR_TELEPORT",true),"HIDDEN",0,50)
-- b35 local recipients supersede former scene-wide target/group/mount/cast/
-- task holds. Presence alone never implies current inspection. Chat typing and
-- accepted messages are resolved against each native recipient window.
-- Cursor rendering remains under its versioned facade. No two independent fade controllers.

-- Beta.2 bindings remain candidates. The source registry text and flags are unchanged.
add("ECO-007",{"tasks"},eq("MAIL_OPEN",true),"VISIBLE",1,30)
add("ECO-008",{"tasks"},eq("AUCTION_OPEN",true),"VISIBLE",1,30)
add("ECO-014",{"tasks"},eq("PROFESSION_OPEN",true),"VISIBLE",1,30)
add("SOC-007",{"tasks"},eq("SOCIAL_OPEN",true),"VISIBLE",1,30)
add("PVP-009",{"combat","group"},eq("ENCOUNTER_ACTIVE",true),"EMPHASIZED",1,35)

-- Beta.3: the opt-in compact quest panel is revealed on travel when a public watch count exists.
add("QST-002",{"compactObjectives"},all(eq("OBJECTIVE_TRACKED",true),eq("PLAYER_MOVING",true)),"VISIBLE",2,18)
add("QST-003",{"compactObjectives"},eq("OBJECTIVE_TRACKED",false),"HIDDEN",3,2)
