local _, M = ...
M.Effects={active={},transitions={},transitionState=setmetatable({},{__mode="k"}),protectedState=setmetatable({},{__mode="k"}),protectedPreparing=setmetatable({},{__mode="k"}),protectedActive={}}
local E=M.Effects
local S=M.Safety
local function duration(value)
    if not S:Number(value) then value=M.profile and M.profile.fade or .22 end
    return math.min(.4,math.max(0,value or .22))
end
-- Every contextual owner uses the same saved duration. Explicit zero-duration
-- priming of children under a hidden parent remains a layout operation, not a
-- second visible fade. Reversals retain the common opacity-change rate.
function E:ContextDuration() return duration() end
-- A synchronous visibility decision uses one start time for every member of
-- its presentation cohort. Provider order and native readback work must not
-- stagger otherwise identical combat/sidebar fades.
function E:ContextClock(owner,options)
    local groups=M.PresentationGroups
    if groups and type(groups.TransitionClock)=="function" then
        local recipient=options and options.recipient or owner and (owner.contextRecipient or owner.navigationRecipient)
        if not recipient and owner and M.AdaptiveFading and M.AdaptiveFading.Recipient then
            recipient=M.AdaptiveFading:Recipient(owner,options)
        end
        return groups:TransitionClock(recipient)
    end
    return S:Now()
end
local function alive(record)
    if record.profile~=M.profile then return false end
    if record.guard then
        local ok,value=pcall(record.guard)
        if not ok or value~=true then return false end
    end
    return record.profile==M.profile
end
local function progress(record,now)
    if S:Number(record.stoppedAlpha) then return record.stoppedAlpha,0 end
    if record.duration<=0 then return record.to,1 end
    -- GetTime can be unavailable during a client boundary (Safety:Now then
    -- returns zero). An authored fade must not rewind or wait for an old
    -- timeline to catch up. Its current owner still guards every setter.
    if not S:Number(now) then return record.from,0 end
    if now<record.start then return record.to,1 end
    local f=math.min(1,math.max(0,(now-record.start)/record.duration))
    return record.from+(record.to-record.from)*f,f
end
-- Authored scalar consumers (for example the independent readable aura
-- foreground) can share the same clock/reversal interpolation without gaining
-- any frame, native visibility, input or timer-data authority.
function E:ContextProgress(record,now) return progress(record,now or S:Now()) end
function E:Pending()
    if next(self.active)~=nil or next(self.transitions)~=nil then return true end
    if next(self.protectedActive)==nil then return false end
    local combat=S:InCombat()
    for _,record in pairs(self.protectedActive) do
        if record.active and not record.active.settleExhausted and not record.active.stopRetryExhausted and not record.active.observationExhausted
            and (not combat or not record.active.finishPending) then return true end
    end
    return false
end
-- Passive presentation uses the existing common clock. A repeated request
-- renews custody without resetting time; a reversal starts at current opacity.
-- Native/secure ancestry is deliberately refused by this ordinary route.
function E:Transition(owner,frame,shown,options)
    options=options or {}
    if not owner or type(shown)~="boolean" or not S:Frame(frame,true) then return false,"PROTECTED_OR_FORBIDDEN" end
    local old=self.transitionState[frame]
    local profile=M.profile
    local function retained() return self.transitionState[frame]==old and M.profile==profile end
    if old and old.owner~=owner then return false,"TRANSITION_OWNER_RETAINED" end
    if options.alpha~=nil and not S:Number(options.alpha) then return false,"ALPHA_UNAVAILABLE" end
    local target=shown and math.min(1,math.max(0,options.alpha or 1)) or 0
    local now=S:Number(options.now) and options.now or self:ContextClock(owner,options)
    local baseline=duration(options.duration)
    local urgent=M.AdaptiveFading and M.AdaptiveFading:Urgent(owner,shown,options) or S:InCombat()
    if not retained() then return false,"STALE_TRANSITION" end
    local preempted=false
    if old and old.profile==M.profile and old.to==target and old.shown==shown then
        old.guard=options.guard;old.onFinished=options.onFinished
        if alive(old) and self.transitionState[frame]==old then
            if self.transitions[frame]==old then
                -- Explicit withdrawal must finish a same-target conceal;
                -- urgency only describes reveals and cannot authorize it.
                preempted=baseline<=0 or urgent and (old.fullDuration or old.duration)>baseline+.000001
                if not preempted then return true,"TRANSITION_PENDING" end
            end
            local visible,known=S:Public(frame.IsShown,"boolean",frame)
            local alpha,alphaKnown=S:Public(frame.GetAlpha,"number",frame)
            -- A retired guard can stop a fade at any intermediate opacity.
            -- Shown state alone does not prove completion when a new canvas
            -- renews this same request. Resume from the observed alpha.
            if not preempted and known=="KNOWN" and visible==shown and alphaKnown=="KNOWN"
                and math.abs(alpha-target)<=.000001 and alive(old) and retained() then
                return true,"TRANSITION_SETTLED"
            end
        end
    end
    local from
    if old and self.transitions[frame]==old and old.profile==M.profile then from=progress(old,now)
    else
        local visible,known=S:Public(frame.IsShown,"boolean",frame)
        if known~="KNOWN" then return false,"VISIBILITY_UNAVAILABLE" end
        if not visible then from=0 else from=S:Public(frame.GetAlpha,"number",frame) end
    end
    if not S:Number(from) then return false,"ALPHA_UNAVAILABLE" end
    if not retained() then return false,"STALE_TRANSITION" end
    local span=baseline
    if M.AdaptiveFading and not urgent then span=M.AdaptiveFading:Duration(owner,frame,shown,span,options) end
    -- Clock/urgency/recipient sampling can synchronously retire the old
    -- receipt. Never replace a successor or acquire a newly protected tree.
    if not retained() or not S:Frame(frame,true) or not retained() then return false,"STALE_TRANSITION" end
    local ceiling=S:Number(options.ceiling) and options.ceiling>0 and math.min(1,options.ceiling)
        or S:Number(options.alpha) and options.alpha>0 and math.min(1,options.alpha)
        or shown and target>0 and target
        or old and old.profile==profile and S:Number(old.ceiling) and old.ceiling>0 and old.ceiling
        or from>0 and math.min(1,from) or 1
    local record={owner=owner,frame=frame,profile=profile,guard=options.guard,onFinished=options.onFinished,
        from=math.min(1,math.max(0,from)),to=target,shown=shown,start=now,duration=span,fullDuration=span,ceiling=ceiling}
    if options.constantRate~=false or preempted then
        -- Match the prebuilt secure alpha animation's rate on reversal. A
        -- half-finished .22s reveal takes .11s to return to zero, not .22s.
        record.duration=record.duration*math.min(1,math.abs(target-record.from)/ceiling)
    end
    self.transitionState[frame]=record;self.transitions[frame]=nil
    local function current()
        return self.transitionState[frame]==record and alive(record) and S:Frame(frame,true)
            and self.transitionState[frame]==record and M.profile==profile
    end
    if not current() then return false,"STALE_TRANSITION" end
    if shown then
        local ok=pcall(frame.SetAlpha,frame,record.from)
        if not ok or not current() then return false,"TRANSITION_UNAVAILABLE" end
        if not pcall(frame.Show,frame) or not current() then return false,"TRANSITION_UNAVAILABLE" end
    end
    if record.duration<=0 or record.from==target then
        local ok=pcall(frame.SetAlpha,frame,target)
        if not ok or not current() then return false,"TRANSITION_UNAVAILABLE" end
        if not pcall(frame.SetShown,frame,shown) or not current() then return false,"TRANSITION_UNAVAILABLE" end
        if record.onFinished then pcall(record.onFinished,shown) end
        return true,"TRANSITION_SETTLED"
    end
    self.transitions[frame]=record
    return true,"TRANSITION_PENDING"
end
function E:CancelTransition(owner,frame,restore)
    local record=self.transitionState[frame]
    if not record or record.owner~=owner then return false end
    local guard=record.guard
    self.transitions[frame]=nil;self.transitionState[frame]=nil
    if M.AdaptiveFading then M.AdaptiveFading:Forget(frame) end
    -- Guard/frame inspection may synchronously acquire a replacement. The
    -- retired request's baseline restore must not repaint that new owner.
    local function released()
        return self.transitionState[frame]==nil and self.transitions[frame]==nil and record.guard==guard and record.profile==M.profile
    end
    if restore and released() and alive(record) and S:Frame(frame,true) and released() then pcall(frame.SetAlpha,frame,1) end
    return true
end
-- AnimationGroup alpha is an engine presentation route. Creation/configuration
-- happens outside combat. Combat playback never calls frame setters or alters
-- protected visibility; the caller's predeclared secure driver owns that edge.
function E:PrepareProtected(owner,frame,guard,ceiling,options)
    options=options or {}
    if not owner or S:InCombat() or not S:Frame(frame,false) then return false,"COMBAT_OR_FRAME_UNAVAILABLE" end
    if ceiling~=nil and not S:Number(ceiling) then return false,"ALPHA_UNAVAILABLE" end
    ceiling=math.min(1,math.max(0,ceiling or 1))
    local preparing=self.protectedPreparing[frame]
    if preparing then return false,preparing.owner==owner and "ANIMATION_PREPARING" or "TRANSITION_OWNER_RETAINED" end
    local old=self.protectedState[frame]
    if old and old.owner~=owner then return false,"TRANSITION_OWNER_RETAINED" end
    if old and old.profile==M.profile and old.presentationOnly==(options.presentationOnly==true) then
        old.guard=guard;old.alphaGuard=options.alphaGuard;old.settle=options.settle
        old.presentationLease=options.presentationLease;old.presentationSerial=options.presentationSerial
        local baseline=duration()
        if old.ceiling==ceiling and old.urgentDuration==baseline then return true end
        local normalDuration=old.urgentDuration~=baseline and baseline or old.duration
        -- Changed opacity or minimum duration reuses the prepared groups.
        -- Configure only outside combat; the next request resumes from the
        -- current presentation instead of replaying a full fade.
        local priorSequence=old.sequence
        local function retained()
            return self.protectedState[frame]==old and old.sequence==priorSequence and old.profile==M.profile
        end
        local from=old.active and progress(old.active,S:Now()) or old.alpha
        if not retained() then return false,"STALE_TRANSITION" end
        if not S:Number(from) then from=S:Public(frame.GetAlpha,"number",frame) end
        if not retained() then return false,"STALE_TRANSITION" end
        if not S:Number(from) then return false,"ALPHA_UNAVAILABLE" end
        old.sequence=(old.sequence or 0)+1
        local sequence=old.sequence;local previous=old.active
        old.active=nil;self.protectedActive[frame]=nil
        if previous then pcall(previous.group.Stop,previous.group) end
        local function current()
            return not S:InCombat() and self.protectedState[frame]==old and old.sequence==sequence
                and alive(old) and self.protectedState[frame]==old and old.sequence==sequence
        end
        local function retire()
            -- A setter/Stop callback may have installed a successor. Retire
            -- only this attempted configuration, never the newer custody.
            if self.protectedState[frame]==old and old.sequence==sequence then self:CancelProtected(owner,frame,false) end
        end
        if not current() then retire();return false,"STALE_TRANSITION" end
        local ok=pcall(function()
            old.revealAlpha:SetFromAlpha(0);assert(current())
            old.revealAlpha:SetToAlpha(ceiling);assert(current())
            old.revealAlpha:SetDuration(math.max(.001,normalDuration));assert(current())
            old.urgentRevealAlpha:SetFromAlpha(0);assert(current())
            old.urgentRevealAlpha:SetToAlpha(ceiling);assert(current())
            old.urgentRevealAlpha:SetDuration(math.max(.001,baseline));assert(current())
            old.concealAlpha:SetFromAlpha(ceiling);assert(current())
            old.concealAlpha:SetToAlpha(0);assert(current())
            old.concealAlpha:SetDuration(math.max(.001,normalDuration));assert(current())
        end)
        if not ok or not current() then retire();return false,"ANIMATION_UNAVAILABLE" end
        old.ceiling=ceiling;old.duration=normalDuration;old.urgentDuration=baseline;old.alpha=math.min(ceiling,math.max(0,from))
        return true
    end
    if old then
        self:CancelProtected(owner,frame,true)
        if self.protectedState[frame] or self.protectedPreparing[frame] then return false,"ANIMATION_SUPERSEDED" end
    end
    -- Reserve this first preparation before any native getter/allocation can
    -- reenter. The reservation is cancellable but never a playable receipt.
    -- A nested prepare cannot overwrite it or perform a visibility fallback.
    local record={owner=owner,frame=frame,profile=M.profile,guard=guard,duration=duration(),urgentDuration=duration(),ceiling=ceiling,
        presentationOnly=options.presentationOnly==true,alphaGuard=options.alphaGuard,settle=options.settle,
        presentationLease=options.presentationLease,presentationSerial=options.presentationSerial}
    self.protectedPreparing[frame]=record
    local function current()
        if self.protectedPreparing[frame]~=record or self.protectedState[frame]~=nil then return false end
        local valid=alive(record);local combat=S:InCombat()
        return valid and not combat and record.profile==M.profile and self.protectedPreparing[frame]==record
            and self.protectedState[frame]==nil
    end
    local function retire(reason)
        if self.protectedPreparing[frame]==record then self.protectedPreparing[frame]=nil end
        -- These groups were created by this request and were never admitted to
        -- playback. Retiring them cannot stop a successor's animation record.
        for _,name in ipairs({"reveal","conceal","urgentReveal"}) do
            local group=record[name];if group then pcall(group.Stop,group) end
        end
        return false,reason
    end
    if not current() then return retire("STALE_TRANSITION") end
    local visible,known=S:Public(frame.IsShown,"boolean",frame)
    if not current() then return retire("ANIMATION_SUPERSEDED") end
    if known~="KNOWN" then return retire("VISIBILITY_UNAVAILABLE") end
    local initial=0
    if visible then initial=S:Public(frame.GetAlpha,"number",frame) end
    if not current() then return retire("ANIMATION_SUPERSEDED") end
    if not S:Number(initial) then return retire("ALPHA_UNAVAILABLE") end
    record.alpha=math.min(ceiling,math.max(0,initial))
    local ok=pcall(function()
        for _,name in ipairs({"reveal","conceal","urgentReveal"}) do
            local group=frame:CreateAnimationGroup()
            record[name]=group;assert(current())
            local alpha=group:CreateAnimation("Alpha")
            record[name.."Alpha"]=alpha;assert(current())
            alpha:SetFromAlpha(name~="conceal" and 0 or ceiling);assert(current())
            alpha:SetToAlpha(name~="conceal" and ceiling or 0);assert(current())
            alpha:SetDuration(math.max(.001,record.duration));assert(current())
            alpha:SetOrder(1);assert(current())
            -- Presentation-only roots retain their secure base-alpha journal
            -- and native lifetime. Playback never commits a second base alpha.
            group:SetToFinalAlpha(not record.presentationOnly);assert(current())
            group:SetScript("OnFinished",function()
                local active=record.active
                if not active or active.group~=group or self.protectedState[frame]~=record
                    or not alive(record) or S:Now()+.001<active.finish then return end
                self:CompleteProtected(record,active,false)
            end)
            assert(current())
            group:SetScript("OnStop",function()
                local active=record.active
                if not active or active.group~=group or self.protectedState[frame]~=record then return end
                -- Cancel/reversal/secure OnHide already retire active before
                -- stopping a group. An unexpected native stop (for example a
                -- hidden ancestor) instead owes its guarded endpoint; dropping
                -- it here strands partial opacity until another mouseover.
                local sequence,target,shown,alphaGuard=record.sequence,active.to,active.shown,record.alphaGuard
                local lease,serial,settle=record.presentationLease,record.presentationSerial,record.settle
                local function current()
                    if self.protectedState[frame]~=record or record.active~=active or active.group~=group
                        or record.sequence~=sequence or active.to~=target or active.shown~=shown or record.alphaGuard~=alphaGuard
                        or record.presentationLease~=lease or record.presentationSerial~=serial or record.settle~=settle or not alive(record) then return false end
                    if alphaGuard then local okay,owned=pcall(alphaGuard);if not okay or owned~=true then return false end end
                    return self.protectedState[frame]==record and record.active==active and active.group==group
                        and record.sequence==sequence and active.to==target and active.shown==shown and record.alphaGuard==alphaGuard
                        and record.presentationLease==lease and record.presentationSerial==serial and record.settle==settle
                end
                local now=S:Now()
                if not current() then return end
                local alpha=S:Public(frame.GetAlpha,"number",frame)
                if not current() then return end
                active.stoppedAlpha=S:Number(alpha) and math.min(record.ceiling,math.max(0,alpha)) or progress(active,now)
                active.finish=math.min(active.finish,now)
                if record.presentationOnly then
                    -- The callback identifies our group, but does not prove
                    -- arbitrary stopped opacity. Require the exact public
                    -- native animation progress (or secure endpoint) too.
                    active.nativeStopped=true
                    local owned=self:PresentationAlphaCurrent(record.owner,frame,alpha,target)
                    if not owned or not current() or active.nativeStopped~=true then return end
                    active.stopped=true;active.settleDebt=alpha
                end
            end)
            assert(current())
        end
    end)
    if not ok or not current() then return retire("ANIMATION_UNAVAILABLE") end
    self.protectedPreparing[frame]=nil
    self.protectedState[frame]=record
    return true
end
-- Native GetAlpha can expose an active Alpha animation's current value. It is
-- not a second base-only accessor. Recognize only our exact live animation,
-- its public engine progress and its unchanged setter/owner receipt. A broad
-- 0..ceiling range would conceal a real foreign alpha writer.
function E:PresentationAlphaCurrent(owner,frame,observed,target)
    if not S:Number(observed) or not S:Number(target) then return false,"ALPHA_UNAVAILABLE" end
    local record=self.protectedState[frame]
    local alphaGuard=record and record.alphaGuard
    if record and record.owner==owner and record.presentationOnly and record.alphaGuard then
        local okay,owned=pcall(alphaGuard)
        if not okay or owned~=true or self.protectedState[frame]~=record or record.alphaGuard~=alphaGuard then return false,"ANIMATION_RECEIPT_SUPERSEDED" end
    end
    if math.abs(observed-target)<=.00001 then return true,"SECURE_ENDPOINT" end
    local active=record and record.active
    if not record or record.owner~=owner or not record.presentationOnly or not active or not record.alphaGuard
        or active.to~=target then return false,"ANIMATION_RECEIPT_UNAVAILABLE" end
    local sequence,group,shown,ceiling=record.sequence,active.group,active.shown,record.ceiling
    local stopped,debt,nativeStopped=active.stopped,active.settleDebt,active.nativeStopped
    local animation=group==record.reveal and record.revealAlpha or group==record.conceal and record.concealAlpha
        or group==record.urgentReveal and record.urgentRevealAlpha
    if not animation then return false,"ANIMATION_IDENTITY_CHANGED" end
    local function animationCurrent()
        return active.group==group and active.to==target and active.shown==shown and record.ceiling==ceiling
            and active.stopped==stopped and active.settleDebt==debt and active.nativeStopped==nativeStopped
            and (group==record.reveal and record.revealAlpha==animation or group==record.conceal and record.concealAlpha==animation
                or group==record.urgentReveal and record.urgentRevealAlpha==animation)
    end
    local function current()
        if self.protectedState[frame]~=record or record.alphaGuard~=alphaGuard or record.sequence~=sequence or record.active~=active
            or self.protectedActive[frame]~=record or not animationCurrent() then return false end
        local okay,owned=pcall(alphaGuard)
        return okay and owned==true and alive(record) and self.protectedState[frame]==record
            and record.alphaGuard==alphaGuard and record.sequence==sequence and record.active==active and self.protectedActive[frame]==record and animationCurrent()
    end
    if not current() then return false,"ANIMATION_RECEIPT_SUPERSEDED" end
    if active.settleExhausted then return false,"ANIMATION_SETTLEMENT_EXHAUSTED" end
    if stopped and S:Number(debt) and math.abs(observed-debt)<=.00001 then
        return current(),"OWNED_STOPPED_ALPHA_SETTLEMENT_PENDING"
    end
    local playing,playingState=S:Public(group.IsPlaying,"boolean",group)
    if not current() or playingState~="KNOWN" or not playing and nativeStopped~=true then return false,"ANIMATION_NOT_PLAYING" end
    local nativeTarget,targetState=S:Public(animation.GetTarget,nil,animation)
    if not current() or targetState~="KNOWN" or nativeTarget~=frame then return false,"ANIMATION_TARGET_CHANGED" end
    local from,fromState=S:Public(animation.GetFromAlpha,"number",animation)
    if not current() or fromState~="KNOWN" then return false,"ANIMATION_VALUE_UNAVAILABLE" end
    local to,toState=S:Public(animation.GetToAlpha,"number",animation)
    if not current() or toState~="KNOWN" or from~=(active.shown and 0 or record.ceiling) or to~=target then return false,"ANIMATION_VALUE_CHANGED" end
    local fraction,known=S:Public(animation.GetProgress,"number",animation)
    if not current() or known~="KNOWN" or fraction<0 or fraction>1 then return false,"ANIMATION_PROGRESS_UNAVAILABLE" end
    local expected=from+(to-from)*fraction
    local matches=math.abs(observed-expected)<=.00001
    -- SingleColorValue can use native byte storage. Reuse the established
    -- property-specific conversion check; unrelated values remain foreign.
    local leases=M.Rework and M.Rework.CombatLeases
    if not matches and leases and type(leases.ColorEqual)=="function" then matches=leases:ColorEqual(observed,expected) end
    if not current() then return false,"ANIMATION_RECEIPT_SUPERSEDED" end
    return matches,matches and (playing and "OWNED_ANIMATION_PUBLIC_PROGRESS" or "OWNED_NATIVE_STOP_PUBLIC_PROGRESS") or "ANIMATION_VALUE_MISMATCH"
end
-- Inverse-only proof for explicit safe/disable/retirement. That transaction
-- has already retired forward context admission, so its old native lease is
-- checked against the exact animation plus the caller's current retirement
-- guard. This value can restore the original property; it cannot reveal,
-- conceal, renew a forward lease or authorize a secure endpoint refresh.
function E:RetiringPresentationAlpha(owner,frame,lease,target,retiringCurrent)
    local record=self.protectedState[frame]
    local active=record and record.active
    if not lease or not S:Number(target) or type(retiringCurrent)~="function" or not record or not active then return nil end
    local sequence,group,shown,ceiling=record.sequence,active.group,active.shown,record.ceiling
    local profile,serial=lease.profile,lease.serial
    local stopped,debt,nativeStopped=active.stopped,active.settleDebt,active.nativeStopped
    local animation=group==record.reveal and record.revealAlpha or group==record.conceal and record.concealAlpha
        or group==record.urgentReveal and record.urgentRevealAlpha
    if not animation then return nil end
    local function same()
        return self.protectedState[frame]==record and self.protectedActive[frame]==record and record.frame==frame
            and record.owner==owner and record.presentationOnly and record.presentationLease==lease
            and record.profile==profile and lease.profile==profile and record.presentationSerial==serial and lease.serial==serial and not lease.alphaForeign
            and record.sequence==sequence and record.active==active and active.group==group and active.to==target
            and active.shown==shown and record.ceiling==ceiling and active.stopped==stopped and active.settleDebt==debt
            and active.nativeStopped==nativeStopped
            and (group==record.reveal and record.revealAlpha==animation or group==record.conceal and record.concealAlpha==animation
                or group==record.urgentReveal and record.urgentRevealAlpha==animation)
    end
    local function current()
        if not same() then return false end
        local okay,owned=pcall(retiringCurrent)
        return okay and owned==true and same()
    end
    if not current() then return nil end
    local value,known=S:Public(frame.GetAlpha,"number",frame)
    if known~="KNOWN" or not current() then return nil end
    if math.abs(value-target)<=.00001 or stopped and S:Number(debt) and math.abs(value-debt)<=.00001 then
        if current() then return value end;return nil
    end
    local playing,state=S:Public(group.IsPlaying,"boolean",group)
    if not current() or state~="KNOWN" or not playing and nativeStopped~=true then return nil end
    local nativeTarget,targetState=S:Public(animation.GetTarget,nil,animation)
    if not current() or targetState~="KNOWN" or nativeTarget~=frame then return nil end
    local from,fromState=S:Public(animation.GetFromAlpha,"number",animation)
    if not current() or fromState~="KNOWN" then return nil end
    local to,toState=S:Public(animation.GetToAlpha,"number",animation)
    if not current() or toState~="KNOWN" or from~=(shown and 0 or ceiling) or to~=target then return nil end
    local fraction,progressState=S:Public(animation.GetProgress,"number",animation)
    if not current() or progressState~="KNOWN" or fraction<0 or fraction>1 then return nil end
    local expected=from+(to-from)*fraction
    local matches=math.abs(value-expected)<=.00001
    local leases=M.Rework and M.Rework.CombatLeases
    if not matches and leases and type(leases.ColorEqual)=="function" then matches=leases:ColorEqual(value,expected) end
    if matches and current() then return value end
end
function E:BeforePresentationCommit(owner,frame,shown)
    local record=self.protectedState[frame]
    if not record or record.owner~=owner or not record.presentationOnly or type(shown)~="boolean"
        or not alive(record) or self.protectedState[frame]~=record then return false end
    local active=record.active
    if not active or active.shown==shown then return true end
    -- A native animation can restore its captured properties when stopped.
    -- Retire a reversing animation BEFORE the secure input owner commits its
    -- new base alpha. Stopping it afterwards can overwrite that new journal
    -- value and make our own fade look like an external native-frame owner.
    -- Preserve the common interpolation point for a continuous reversal.
    local from=progress(active,S:Now())
    if not alive(record) or self.protectedState[frame]~=record or record.active~=active then return false end
    self:StopProtected(owner,frame,from)
    return self.protectedState[frame]==record and record.active==nil and alive(record)
end
function E:TransitionProtected(owner,frame,shown)
    local record=self.protectedState[frame]
    if not record or record.owner~=owner or type(shown)~="boolean" or not alive(record)
        or self.protectedState[frame]~=record or not S:Frame(frame,false) then return false,"ANIMATION_UNAVAILABLE" end
    if not shown and S:InCombat() and not record.presentationOnly then return false,"SECURE_CONCEAL_REQUIRED" end
    if not S:InCombat() and record.urgentDuration~=duration() then
        if not self:PrepareProtected(owner,frame,record.guard,record.ceiling,{presentationOnly=record.presentationOnly,alphaGuard=record.alphaGuard,
            settle=record.settle,presentationLease=record.presentationLease,presentationSerial=record.presentationSerial}) or self.protectedState[frame]~=record then return false,"ANIMATION_UNAVAILABLE" end
    end
    local ceiling=record.ceiling or 1
    local target=shown and ceiling or 0
    if record.presentationOnly then
        -- The predeclared input owner must have committed the target first.
        -- This route never manufactures input or base-alpha authority.
        local base,status=S:Public(frame.GetAlpha,"number",frame)
        if status~="KNOWN" or not self:PresentationAlphaCurrent(owner,frame,base,target) then return false,"SECURE_PRESENTATION_REQUIRED" end
        if not alive(record) or self.protectedState[frame]~=record then return false,"STALE_TRANSITION" end
    end
    local urgent=M.AdaptiveFading and M.AdaptiveFading:Urgent(owner,shown) or S:InCombat()
    if record.active and record.active.to==target and record.active.shown==shown
        and not (urgent and (record.active.fullDuration or record.duration)>record.urgentDuration+.000001) then return true,"TRANSITION_PENDING" end
    if not record.active and record.alpha==target then
        local visible,known=S:Public(frame.IsShown,"boolean",frame)
        local alpha,alphaKnown=S:Public(frame.GetAlpha,"number",frame)
        if known=="KNOWN" and (record.presentationOnly or visible==shown) and alphaKnown=="KNOWN" and alpha==target
            and alive(record) and self.protectedState[frame]==record then
            return true,"TRANSITION_SETTLED"
        end
    end
    record.sequence=(record.sequence or 0)+1
    local sequence=record.sequence
    local function current()
        return self.protectedState[frame]==record and record.sequence==sequence and alive(record)
            and self.protectedState[frame]==record and record.sequence==sequence
    end
    if not current() then return false,"STALE_TRANSITION" end
    local now=self:ContextClock(owner)
    local from=record.active and progress(record.active,now) or record.alpha
    if from==nil then
        local visible,known=S:Public(frame.IsShown,"boolean",frame)
        if known~="KNOWN" then return false,"VISIBILITY_UNAVAILABLE" end
        from=visible and ceiling or 0
    end
    from=math.min(ceiling,math.max(0,from))
    local previous=record.active
    record.active=nil;self.protectedActive[frame]=nil
    if previous then pcall(previous.group.Stop,previous.group) end
    if not current() then return false,"STALE_TRANSITION" end
    if not S:InCombat() and not record.presentationOnly then
        if not current() then return false,"STALE_TRANSITION" end
        if shown and not pcall(frame.Show,frame) then return false,"VISIBILITY_UNAVAILABLE" end
        if not current() then return false,"STALE_TRANSITION" end
        if not S:InCombat() and (ceiling==0 or (urgent and record.urgentDuration or record.duration)<=0 or from==target) then
            if not current() or not pcall(frame.SetAlpha,frame,target) or not current() then return false,"TRANSITION_UNAVAILABLE" end
            if not shown then
                if S:InCombat() or not current() then return false,"SECURE_CONCEAL_REQUIRED" end
                if not pcall(frame.Hide,frame) or not current() then return false,"VISIBILITY_UNAVAILABLE" end
            end
            record.alpha=target;return true,"TRANSITION_SETTLED"
        end
    end
    if record.presentationOnly then
        if record.urgentDuration<=0 or from==target then record.alpha=target;return true,"TRANSITION_SETTLED" end
        if S:Public(frame.IsShown,"boolean",frame)~=true then record.alpha=target;return true,"NATIVE_LIFETIME_HIDDEN" end
    elseif S:InCombat() then
        if not shown then return false,"SECURE_CONCEAL_REQUIRED" end
        if S:Public(frame.IsShown,"boolean",frame)~=true then return false,"SECURE_REVEAL_REQUIRED" end
    end
    if not current() then return false,"STALE_TRANSITION" end
    local combat=S:InCombat()
    local group=urgent and shown and record.urgentReveal or shown and record.reveal or record.conceal
    if not S:InCombat() and not urgent and M.PresentationGroups and M.PresentationGroups:Enabled() then
        local requested=duration()
        if M.AdaptiveFading then requested=M.AdaptiveFading:Duration(owner,frame,shown,requested,{now=now}) end
        if record.duration~=requested then
            if not current() then return false,"STALE_TRANSITION" end
            local ok=pcall(function()
                assert(not S:InCombat() and current())
                record.revealAlpha:SetDuration(math.max(.001,requested))
                assert(not S:InCombat() and current())
                record.concealAlpha:SetDuration(math.max(.001,requested))
            end)
            if not ok or not current() then return false,"ANIMATION_UNAVAILABLE" end
            record.duration=requested
        end
    end
    -- A separate baseline animation is prepared before lockdown. Repeated
    -- travel can never leave a slow reveal configured for urgent combat.
    combat=S:InCombat()
    if not current() then return false,"STALE_TRANSITION" end
    if combat and not record.presentationOnly then
        if not shown then return false,"SECURE_CONCEAL_REQUIRED" end
        if S:Public(frame.IsShown,"boolean",frame)~=true or not current() then return false,"SECURE_REVEAL_REQUIRED" end
        group=record.urgentReveal
        urgent=true
    end
    local span=math.max(.001,urgent and record.urgentDuration or record.duration)
    local fraction=ceiling>0 and from/ceiling or 0
    local offset=(shown and fraction or 1-fraction)*span
    local active={group=group,from=from,to=target,shown=shown,start=now,duration=math.max(.001,span-offset),fullDuration=span,finish=now+span-offset}
    record.active=active;self.protectedActive[frame]=record
    -- Alpha playback starts at the native call time. Account for work already
    -- performed in this shared decision so the engine and passive clock agree.
    local submitted=S:Now()
    if not current() then return false,"STALE_TRANSITION" end
    local elapsed=S:Number(submitted) and math.max(0,submitted-now) or 0
    local played=pcall(group.Play,group,false,math.min(span,offset+elapsed))
    if not current() then return false,"STALE_TRANSITION" end
    if not played then
        record.active=nil;self.protectedActive[frame]=nil;return false,"ANIMATION_UNAVAILABLE"
    end
    return true,"TRANSITION_PENDING"
end
-- Engine callbacks are a completion signal, not the sole cleanup clock. A
-- hidden ancestor or missed/stopped completion must not strand a sidebar at
-- intermediate opacity until a mouseover happens to submit another request.
function E:CompletePresentation(record,active,deadline)
    local frame,sequence,alphaGuard,settle=record.frame,record.sequence,record.alphaGuard,record.settle
    local group,target,from,shown=active.group,active.to,active.from,active.shown
    local debt,stopped,nativeStopped=active.settleDebt,active.stopped,active.nativeStopped
    local lease,serial=record.presentationLease,record.presentationSerial
    local function retained(wanted)
        if self.protectedState[frame]~=record or record.sequence~=sequence or record.active~=wanted or record.alphaGuard~=alphaGuard
            or record.frame~=frame or record.settle~=settle or record.presentationLease~=lease or record.presentationSerial~=serial
            or active.group~=group or active.to~=target or active.from~=from or active.shown~=shown
            or active.settleDebt~=debt or active.stopped~=stopped or active.nativeStopped~=nativeStopped or not alive(record) then return false end
        if alphaGuard then local okay,owned=pcall(alphaGuard);if not okay or owned~=true then return false end end
        return self.protectedState[frame]==record and record.sequence==sequence and record.active==wanted
            and record.frame==frame and record.alphaGuard==alphaGuard and record.settle==settle
            and record.presentationLease==lease and record.presentationSerial==serial
            and active.group==group and active.to==target and active.from==from and active.shown==shown
            and active.settleDebt==debt and active.stopped==stopped and active.nativeStopped==nativeStopped
    end
    if not retained(active) then return false end
    local before,known=S:Public(frame.GetAlpha,"number",frame)
    if not retained(active) then return false end
    local endpoint=known=="KNOWN" and math.abs(before-active.to)<=.00001
    local owned=endpoint or known=="KNOWN" and self:PresentationAlphaCurrent(record.owner,frame,before,active.to)
    if not retained(active) then return false end
    local function pending(reason)
        local now=S:Now()
        if not retained(active) then return false end
        active.finishPending=true;active.nextCompletionReview=now+.1
        record.completionStatus=reason
        return false
    end
    if not owned then
        -- Missing public animation evidence is an observation gap, not a
        -- foreign-writer receipt. Keep the exact record for native completion
        -- or explicit recovery, but do not poll an unprovable endpoint forever.
        active.observationAttempts=(active.observationAttempts or 0)+1
        if active.observationAttempts>=3 then active.observationExhausted=true end
        return pending(active.observationExhausted and "NATIVE_ALPHA_OBSERVATION_REQUIRED" or "NATIVE_ALPHA_UNCONFIRMED")
    end
    local combat=S:InCombat()
    if not retained(active) then return false end
    if combat then
        -- A Lua deadline cannot stop a native fade and assume its endpoint.
        -- In combat only native completion may finish this visual record;
        -- the existing secure driver continues to own alpha and click input.
        local playing,state=S:Public(active.group.IsPlaying,"boolean",active.group)
        if not retained(active) then return false end
        if not endpoint or deadline and (state~="KNOWN" or playing) then return pending("NATIVE_COMPLETION_PENDING_COMBAT") end
    end
    record.active=nil;self.protectedActive[frame]=nil
    if deadline and not stopped and not combat then
        active.stopAttempts=(active.stopAttempts or 0)+1
        local okay,result=pcall(group.Stop,group)
        if not retained(nil) then return false end
        local playing,state=S:Public(group.IsPlaying,"boolean",group)
        if not retained(nil) then return false end
        if not okay or result==false or state~="KNOWN" or playing then
            record.active=active;self.protectedActive[frame]=record
            if active.stopAttempts>=3 then active.stopRetryExhausted=true end
            return pending(active.stopRetryExhausted and "NATIVE_STOP_UNCONFIRMED_RETRY_EXHAUSTED" or "NATIVE_STOP_UNCONFIRMED")
        end
        stopped=true;active.stopped=true
    end
    if not retained(nil) then return false end
    local actual,status=S:Public(frame.GetAlpha,"number",frame)
    if not retained(nil) then return false end
    local settled=status=="KNOWN" and math.abs(actual-active.to)<=.00001
    if not settled and not S:InCombat() and status=="KNOWN" and type(settle)=="function"
        and (math.abs(actual-before)<=.00001
            or S:Number(active.settleDebt) and math.abs(actual-active.settleDebt)<=.00001) then
        -- Stop can preserve the last animated value instead of the secure
        -- base. Only that exact owned value can authorize the existing secure
        -- owner's endpoint refresh; it never authorizes a new visibility.
        stopped=true;debt=actual;active.stopped=true;active.settleDebt=actual
        active.settleAttempts=(active.settleAttempts or 0)+1
        local okay,done=pcall(settle,active,actual,function() return retained(nil) end)
        if not retained(nil) then return false end
        actual,status=S:Public(frame.GetAlpha,"number",frame)
        if not retained(nil) then return false end
        settled=okay and done==true and status=="KNOWN" and math.abs(actual-active.to)<=.00001
    end
    if not settled then
        record.active=active;self.protectedActive[frame]=record
        if (active.settleAttempts or 0)>=3 then active.settleExhausted=true end
        return pending(active.settleExhausted and "SECURE_ENDPOINT_REFRESH_EXHAUSTED" or "SECURE_ENDPOINT_REFRESH_PENDING")
    end
    record.alpha=active.to;record.completionStatus="NATIVE_ENDPOINT_VERIFIED"
    self.completed=(self.completed or 0)+1
    if deadline then self.deadlineCompletions=(self.deadlineCompletions or 0)+1 end
    return true
end
function E:CompleteProtected(record,active,deadline)
    if record.presentationOnly then return self:CompletePresentation(record,active,deadline) end
    local frame=record.frame
    local sequence=record.sequence
    local function current()
        return self.protectedState[frame]==record and record.sequence==sequence and record.active==active
            and alive(record) and self.protectedState[frame]==record and record.sequence==sequence and record.active==active
    end
    if not current() or not S:Frame(frame,false) or not current() then return false end
    local combat=S:InCombat()
    if combat and not record.presentationOnly then
        local alpha,known=S:Public(frame.GetAlpha,"number",frame)
        if known~="KNOWN" or math.abs(alpha-active.to)>.000001 or not current() then
            -- Frame setters remain forbidden here. Keep one owed completion
            -- until combat ends; native secure visibility continues to own it.
            active.finishPending=true
            return false
        end
    end
    -- Retire before Stop: its callback may reenter, renew, or transfer custody.
    record.active=nil;self.protectedActive[frame]=nil
    local function retained()
        return self.protectedState[frame]==record and record.sequence==sequence and record.active==nil
            and alive(record) and self.protectedState[frame]==record and record.sequence==sequence and record.active==nil
    end
    if deadline then pcall(active.group.Stop,active.group) end
    if not retained() then return false end
    if not record.presentationOnly and not S:InCombat() then
        if not S:Frame(frame,false) or not retained() then return false end
        local okay=pcall(frame.SetAlpha,frame,active.to)
        if not retained() then return false end
        if not okay then record.alpha=nil;return false end
        if not active.shown then
            if not retained() then return false end
            if S:InCombat() then record.alpha=nil;return false end
            local hidden=pcall(frame.Hide,frame)
            -- The secure input owner may publish its definitive hidden state
            -- from OnHide (StopProtected). That newer sequence owns the cached
            -- zero; an older completion must not replace it with unknown.
            if not retained() then return false end
            if not hidden then record.alpha=nil;return false end
        end
    end
    if not retained() then return false end
    record.alpha=active.to
    self.completed=(self.completed or 0)+1
    if deadline then self.deadlineCompletions=(self.deadlineCompletions or 0)+1 end
    return true
end
function E:CancelProtected(owner,frame,restore)
    local preparing=self.protectedPreparing[frame]
    local cancelled=preparing and preparing.owner==owner
    if cancelled then self.protectedPreparing[frame]=nil end
    local record=self.protectedState[frame]
    if not record or record.owner~=owner then return cancelled==true end
    record.sequence=(record.sequence or 0)+1
    local sequence,guard=record.sequence,record.guard
    local active=record.active;record.active=nil
    self.protectedActive[frame]=nil;self.protectedState[frame]=nil
    if M.AdaptiveFading then M.AdaptiveFading:Forget(frame) end
    if active then pcall(active.group.Stop,active.group) end
    local function released()
        return self.protectedState[frame]==nil and self.protectedPreparing[frame]==nil and self.protectedActive[frame]==nil
            and record.sequence==sequence and record.guard==guard and record.profile==M.profile
    end
    -- Stop delivers native callbacks. A replacement prepared or played by a
    -- callback already owns the opacity; only a still-vacant frame is restored.
    if restore and not record.presentationOnly and released() and not S:InCombat()
        and alive(record) and S:Frame(frame,false) and released() and not S:InCombat() and released() then pcall(frame.SetAlpha,frame,1) end
    return true
end
function E:StopProtected(owner,frame,alpha)
    local record=self.protectedState[frame]
    if not record or record.owner~=owner then return false end
    record.sequence=(record.sequence or 0)+1
    local active=record.active;record.active=nil;record.alpha=S:Number(alpha) and alpha or record.ceiling or 1
    self.protectedActive[frame]=nil
    if active then pcall(active.group.Stop,active.group) end
    return true
end
function E:ObserveProtectedHidden(owner,frame)
    local record=self.protectedState[frame]
    if not record or record.owner~=owner or not alive(record)
        or S:Public(frame.IsShown,"boolean",frame)~=false or self.protectedState[frame]~=record then return false end
    self:StopProtected(owner,frame)
    if self.protectedState[frame]~=record or not alive(record) then return false end
    record.alpha=0
    return true
end
E.visibilityProgram=[=[
self:SetAttribute("mirage-owned-state",newstate)
if newstate == "show" then
 self:SetAlpha(1)
 self:Show()
 self:CallMethod("MirageOwnedFade",true)
elseif newstate == "quiet" then
 self:CallMethod("MirageOwnedFade",false)
else
 self:CallMethod("MirageOwnedStopFade")
 self:Hide()
 self:CallMethod("MirageOwnedHidden")
end
]=]
function E:RegisterVisibility(owner,frame,driver,guard)
    if S:InCombat() or not S:Text(driver) or not S:Frame(frame,false) then return false,"VISIBILITY_UNAVAILABLE" end
    local previous=self.protectedState[frame]
    if previous and previous.owner~=owner then return false,"TRANSITION_OWNER_RETAINED" end
    local custody={owner=owner,profile=M.profile,guard=guard}
    if not owner or not alive(custody) then return false,"STALE_TRANSITION" end
    local prepared=self:PrepareProtected(owner,frame,guard)
    if not prepared then
        if self.protectedState[frame] or self.protectedPreparing[frame] or not alive(custody) or S:InCombat() then return false,"ANIMATION_UNAVAILABLE" end
        -- A retired profile may have left a completed alpha0 behind. The new
        -- owner retires the old custom driver and restores ordinary opacity
        -- before delegating native visibility.
        local retired,result=pcall(UnregisterStateDriver,frame,"muivisibility")
        if not retired or result==false or not alive(custody) or self.protectedState[frame] or S:InCombat() then return false,"ANIMATION_UNAVAILABLE" end
        local restored,result=pcall(frame.SetAlpha,frame,1)
        if not restored or result==false or not alive(custody) or self.protectedState[frame] or S:InCombat() then return false,"ANIMATION_UNAVAILABLE" end
        local ok,result=pcall(RegisterStateDriver,frame,"visibility",driver)
        return ok and result~=false and alive(custody),"NATIVE_VISIBILITY_FALLBACK"
    end
    local record=self.protectedState[frame]
    frame.MirageOwnedFade=function(_,shown)
        if not alive(record) or self.protectedState[frame]~=record then return end
        local ok=self:TransitionProtected(owner,frame,shown)
        if not ok and not S:InCombat() and alive(record) and self.protectedState[frame]==record then frame:SetAlpha(1);frame:SetShown(shown) end
    end
    frame.MirageOwnedStopFade=function() self:StopProtected(owner,frame) end
    frame.MirageOwnedHidden=function() self:ObserveProtectedHidden(owner,frame) end
    -- Only the trailing ordinary hide becomes a deferred fade. Conditional
    -- vehicle/override/manual-combat hides retain their secure immediate edge.
    local contextual=driver:gsub("hide%s*$","quiet")
    local ok=pcall(function()
        UnregisterStateDriver(frame,"visibility")
        frame:SetAttribute("_onstate-muivisibility",self.visibilityProgram)
        frame:SetAttribute("state-muivisibility",nil)
        frame:SetAttribute("mirage-owned-state",nil)
        assert(RegisterStateDriver(frame,"muivisibility",contextual)~=false)
    end)
    local state=S:Public(frame.GetAttribute,"string",frame,"mirage-owned-state")
    if not ok or not alive(record) or self.protectedState[frame]~=record
        or (state~="quiet" and state~="show" and state~="hide") then
        self:UnregisterVisibility(owner,frame)
        return false,"VISIBILITY_DRIVER_UNAVAILABLE"
    end
    record.visibilityDriver=contextual
    return true,"SECURE_TRANSITION_READY"
end
function E:UnregisterVisibility(owner,frame)
    if S:InCombat() then return false end
    local record=self.protectedState[frame]
    if record and record.owner~=owner then return false end
    self:CancelProtected(owner,frame,false)
    if self.protectedState[frame] then return false end
    if S:Frame(frame,false) and not S:InCombat() and not self.protectedState[frame] then
        pcall(UnregisterStateDriver,frame,"muivisibility")
        if self.protectedState[frame] or S:InCombat() then return false end
        pcall(UnregisterStateDriver,frame,"visibility")
        if self.protectedState[frame] or S:InCombat() then return false end
        pcall(frame.SetAlpha,frame,1)
    end
    return true
end
local function queuedTransition(e,frame,record,guard)
    return e.transitions[frame]==record and e.transitionState[frame]==record and record.guard==guard
end
local function retireQueuedTransition(e,frame,record,guard)
    -- A failed guard or setter can install a new fade before returning.
    -- Retire only the queued receipt inspected by this iteration.
    if e.transitions[frame]==record and record.guard==guard then e.transitions[frame]=nil end
end
local function queuedProtected(e,frame,record,active,sequence,guard)
    return e.protectedState[frame]==record and e.protectedActive[frame]==record
        and record.active==active and record.sequence==sequence and record.guard==guard
end
function E:TickTransitions(now)
    for frame,record in pairs(self.transitions) do
        local guard=record.guard
        if not queuedTransition(self,frame,record,guard) or not alive(record) or not S:Frame(frame,true) then retireQueuedTransition(self,frame,record,guard)
        else
            local alpha,f=progress(record,now)
            if queuedTransition(self,frame,record,guard) and alive(record) and queuedTransition(self,frame,record,guard) then
                local ok=pcall(frame.SetAlpha,frame,alpha)
                if not ok then retireQueuedTransition(self,frame,record,guard)
                elseif f>=1 and queuedTransition(self,frame,record,guard) and alive(record) and queuedTransition(self,frame,record,guard) then
                    self.transitions[frame]=nil
                    if not record.shown then pcall(frame.Hide,frame) end
                    if self.transitionState[frame]==record and record.guard==guard and alive(record)
                        and self.transitionState[frame]==record and record.guard==guard and record.onFinished then pcall(record.onFinished,record.shown) end
                end
            end
        end
    end
    for frame,record in pairs(self.protectedActive) do
        local active,sequence,guard=record.active,record.sequence,record.guard
        if not queuedProtected(self,frame,record,active,sequence,guard) or not alive(record) or not S:Frame(frame,false) then
            if queuedProtected(self,frame,record,active,sequence,guard) then self:CancelProtected(record.owner,frame,false)
            elseif self.protectedActive[frame]==record and self.protectedState[frame]~=record then self.protectedActive[frame]=nil end
        else
            if queuedProtected(self,frame,record,active,sequence,guard) and active and not active.settleExhausted and not active.stopRetryExhausted and not active.observationExhausted and (not active.nextCompletionReview or now>=active.nextCompletionReview)
                and (now>=active.finish+.02 or now<active.start)
                and (not active.finishPending or not S:InCombat()) then
                self:CompleteProtected(record,active,true)
            end
        end
    end
end
local function current(surface,stamp,ticket)
    -- Current inspects frame topology through callback-capable getters. The
    -- pure ticket check must be last, immediately before the effect boundary.
    local stampOK=M.Policy:Current(surface,stamp)
    local now=M.Safety:Now()
    local ticketOK=M.Policy:TicketCurrent(surface,ticket,now)
    if stampOK and ticketOK and M.Policy:StampGenerationCurrent(surface,stamp) then return true end
    M.Policy:CancelTicket(surface)
    M.Policy:RefreshAuthority(now)
    return false
end
function E:Apply(surface,state,reason,immediate,ticket,urgentReveal)
    local now=M.Safety:Now()
    M.Policy:RefreshAuthority(now)
    -- Check before even NativeQuiet/custom effect paths; never restamp an old
    -- admitted request after live maintenance has retired its qualification.
    if not M.Policy:TicketCurrent(surface,ticket,now) then M.Policy:CancelTicket(surface);return end
    surface.admittedTicket=ticket
    local priorStatus,priorConfirmed=surface.effectStatus,surface.confirmed
    surface.effectStatus="PLANNED";surface.confirmed=false
    local frame=surface.frame
    if not frame then surface.actual="UNAVAILABLE";surface.appliedReason="NO_SURFACE";surface.effectStatus="DENIED";return end
    if surface.native and M.Native and M.Native:Conflict() then
        self.active[surface.id]=nil;surface.actual="NATIVE";surface.appliedReason="OTHER_UI_OWNER";surface.effectStatus="DENIED";return
    end
    -- These routes do not have ordinary alpha authority. In particular, an
    -- acquired native context gate makes the old ordinary scope invalid by
    -- design. Retire its old fade before reporting the secure owner's work;
    -- do not try to authorize that receipt through NativeQuiet's setter scope.
    if surface.security=="SECURE_PREDECLARED" or surface.security=="NATIVE_PROTECTED" then
        self.active[surface.id]=nil
        if not M.Policy:TicketCurrent(surface,ticket,M.Safety:Now()) then M.Policy:CancelTicket(surface);return end
        surface.actual="SECURE_NATIVE";surface.appliedReason="SECURE_DRIVER_OWNS_VISIBILITY";surface.effectStatus="SUBMITTED";return
    end
    if surface.security=="NATIVE_READ_ONLY" or surface.security=="UNVERIFIED" then
        self.active[surface.id]=nil
        surface.actual="NATIVE";surface.appliedReason="NATIVE_OWNS_PRESENTATION";surface.effectStatus="DENIED";return
    end
    local stamp=M.Policy:Stamp(surface)
    local wasQuiet=surface.native and surface.quietHidden==true
    if surface.native and M.NativeQuiet then
        if not current(surface,stamp,ticket) then return end
        if M.NativeQuiet:Apply(surface,state,ticket and function() return current(surface,stamp,ticket) end or nil) then
            if current(surface,stamp,ticket) then surface.effectStatus="SUBMITTED" end
            return
        end
    end
    if not M.Safety:Frame(frame,true) then
        surface.actual="PRESERVED";surface.appliedReason="PROTECTED_OR_FORBIDDEN";surface.effectStatus="DENIED";M.stats.denied=M.stats.denied+1;return
    end
    if surface.native and not M.Safety:ChildTreePublic(frame) then
        surface.actual="PRESERVED";surface.appliedReason="NATIVE_CHILD_PROTECTED";surface.effectStatus="DENIED";return
    end
    if surface.native and M.Safety:InCombat() then
        -- Native surfaces are never hidden by this adapter; only bounded low-emphasis alpha
        -- was used outside combat. Where legal, restore the original opacity, not a queued hide.
        state="VISIBLE";reason="NATIVE_COMBAT_FLOOR";immediate=true
    end
    local cfg=M:ModuleConfig(surface.module) or {}
    local target=(state=="HIDDEN" and 0) or (state=="AMBIENT" and .25) or 1
    target=target*(cfg.alpha or 1)
    local appliedState=state
    if surface.native then
        local original=surface.originalAlpha or 1
        local factor=math.max(surface.minAlpha or .35,math.min(1,target))
        if state=="VISIBLE" or state=="PROTECTED_FLOOR" then factor=1 end
        target=original*factor
        appliedState=factor<1 and "NATIVE_DIMMED" or "NATIVE"
        reason=factor<1 and "NATIVE_OPACITY_ONLY" or reason
    end
    if not current(surface,stamp,ticket) then return end
    if surface.Apply then
        local ok,applied=M:Guard(surface.module,surface.Apply,surface,target,state,{immediate=immediate==true or surface.instant==true,reason=reason,urgent=urgentReveal==true})
        if not current(surface,stamp,ticket) then return end
        surface.actual=ok and (applied or state) or "PRESERVED";surface.appliedReason=reason;surface.effectStatus=ok and "SUBMITTED" or "DENIED";return
    end
    local duration=(immediate or surface.instant or not M.profile) and 0 or self:ContextDuration()
    surface.lastLocalHover=surface.localHover==true or reason=="LOCAL_HOVER_INSPECTION"
    local urgent=M.AdaptiveFading and M.AdaptiveFading:Urgent(surface,target>0,{urgent=urgentReveal==true,reason=reason}) or S:InCombat()
    if not current(surface,stamp,ticket) then return end
    if wasQuiet and not surface.quietHidden and surface.module=="Minimap" and state=="VISIBLE"
        and reason=="EXPERIENCE_NAVIGATING" and duration>0 and not M.Safety:InCombat() then
        if not current(surface,stamp,ticket) then return end
        surface.currentAlpha=0;surface.lastWrittenAlpha=0;surface.confirmed=false
        if not pcall(frame.SetAlpha,frame,0) then
            self.active[surface.id]=nil;M.Native:RestoreSurface(frame,surface)
            surface.effectStatus="DENIED";surface.appliedReason="FADE_START_UNAVAILABLE";return
        end
        if not current(surface,stamp,ticket) then return end
    end
    local transition=self.active[surface.id]
    local preempted=false
    if transition and transition.to==target and transition.state==appliedState
        and M.Policy:Current(surface,transition.stamp) and current(surface,stamp,ticket) then
        -- Renew the admitted authority and explanation, never the timeline.
        -- Real target or owner/generation changes still take the normal path.
        preempted=duration<=0 or urgent and (transition.fullDuration or transition.duration)>duration+.000001
        if not preempted then
            transition.reason=reason;transition.stamp=stamp;transition.ticket=ticket
            surface.effectStatus=priorStatus;surface.confirmed=priorConfirmed
            surface.appliedReason=reason
            return
        end
    end
    if not preempted and target==surface.targetAlpha and surface.actual==appliedState and priorConfirmed then
        local alpha,alphaKnown=S:Public(frame.GetAlpha,"number",frame)
        local shown,shownKnown=S:Public(frame.IsShown,"boolean",frame)
        if alphaKnown=="KNOWN" and math.abs(alpha-target)<=.000001
            and (surface.native or shownKnown=="KNOWN" and shown==(target>0)) and current(surface,stamp,ticket) then
            surface.effectStatus=priorStatus;surface.confirmed=priorConfirmed;surface.appliedReason=reason;return
        end
        if not current(surface,stamp,ticket) then return end
        if alphaKnown=="KNOWN" then surface.currentAlpha=alpha end
    end
    if M.AdaptiveFading then
        duration=M.AdaptiveFading:Duration(surface,frame,target>0,duration,{now=now,urgent=urgent,reason=reason})
    end
    if not current(surface,stamp,ticket) or not S:Frame(frame,true) or not M.Policy:StampGenerationCurrent(surface,stamp) then return end
    surface.targetAlpha=target
    if duration<=0 then
        frame:SetAlpha(target);surface.currentAlpha=target
        if surface.native then surface.lastWrittenAlpha=target end
        if not surface.native then
            if not current(surface,stamp,ticket) then return end
            frame:SetShown(target>0)
        end
        if not current(surface,stamp,ticket) then return end
        self.active[surface.id]=nil;surface.actual=appliedState;surface.appliedReason=reason
        M.Policy:Acknowledge(surface,target,appliedState)
        if not current(surface,stamp,ticket) then return end
    else
        local wasShown=M.Safety:Public(frame.IsShown,"boolean",frame)
        if not surface.native and target>0 then frame:Show() end
        local started=self:ContextClock(surface)
        if not current(surface,stamp,ticket) then return end
        local from=surface.currentAlpha
        if transition and transition.stamp and transition.stamp.contextEpoch==stamp.contextEpoch
            and transition.stamp.scopeEpoch==stamp.scopeEpoch and transition.stamp.ownerEpoch==stamp.ownerEpoch
            and transition.stamp.userRevision==stamp.userRevision then from=progress(transition,started) end
        if not surface.native and wasShown==false then from=0 end
        if not S:Number(from) then
            local shown,known=S:Public(frame.IsShown,"boolean",frame)
            from=known=="KNOWN" and not shown and 0 or 1
        end
        local fullDuration=duration
        if duration>0 then
            local ceiling=S:Number(cfg.alpha) and cfg.alpha>0 and cfg.alpha or 1
            duration=duration*math.min(1,math.abs(target-from)/ceiling)
        end
        self.active[surface.id]={surface=surface,from=from,to=target,start=started,duration=duration,fullDuration=fullDuration,state=appliedState,reason=reason,revision=surface.revision,stamp=stamp,ticket=ticket}
        surface.effectStatus="SUBMITTED"
    end
    M.stats.effects=M.stats.effects+1
end
function E:Tick(now)
    self:TickTransitions(now)
    if next(self.active)==nil then return end
    M.Policy:RefreshAuthority(now)
    for id,transition in pairs(self.active) do
        local s=transition.surface
        if not M.Policy:TicketCurrent(s,transition.ticket,now) then M.Policy:CancelTicket(s)
        elseif s.native and M.Native:Conflict() then
            self.active[id]=nil;M.Native:RestoreSurface(s.frame,s);s.appliedReason="OTHER_UI_OWNER";s.effectStatus="DENIED"
        elseif s.security=="SECURE_PREDECLARED" or s.security=="NATIVE_PROTECTED" or s.security=="NATIVE_READ_ONLY" or s.security=="UNVERIFIED" then
            self.active[id]=nil;self:Apply(s,s.desired or "VISIBLE",s.reason,true,transition.ticket)
        elseif not M.Policy:Current(s,transition.stamp) or not M.Safety:Frame(s.frame,true) then self.active[id]=nil;s.effectStatus="DENIED";s.appliedReason="STALE_EFFECT"
        elseif s.native and not M.Safety:ChildTreePublic(s.frame) then
            self.active[id]=nil;M.Native:RestoreSurface(s.frame,s);s.appliedReason="NATIVE_CHILD_PROTECTED";s.effectStatus="DENIED"
        elseif s.native and M.Safety:InCombat() then
            self.active[id]=nil;self:Apply(s,"VISIBLE","NATIVE_COMBAT_FLOOR",true)
        elseif current(s,transition.stamp,transition.ticket) then
            local alpha,f=progress(transition,now)
            s.frame:SetAlpha(alpha);s.currentAlpha=alpha
            if s.native then s.lastWrittenAlpha=alpha end
            if f>=1 and current(s,transition.stamp,transition.ticket) then
                if not s.native and alpha<=0 then s.frame:Hide() end
                if current(s,transition.stamp,transition.ticket) then
                    s.actual=transition.state;s.appliedReason=transition.reason;self.active[id]=nil
                    M.Policy:Acknowledge(s,alpha,transition.state)
                    current(s,transition.stamp,transition.ticket)
                end
            end
        end
    end
end
function E:Stop(surface,owns)
    -- Optional internal pure custody predicate, never a native-value provider.
    -- Legacy callers keep their existing stop semantics. A revoked or failed
    -- predicate must not retire a successor during callback-capable cleanup.
    local function current()
        if owns==nil then return true end
        local ok,allowed=pcall(function()
            if owns()==true then return true end
            return false
        end)
        return ok and allowed==true
    end
    if not current() then return end
    surface.admittedTicket=nil
    self.active[surface.id]=nil
    if surface.native then return end
    local safe=M.Safety:Frame(surface.frame,true)
    if not current() then return end
    if safe then
        surface.frame:Hide()
        if not current() then return end
        surface.actual="HIDDEN";surface.targetAlpha=nil;surface.confirmed=false;surface.effectStatus="SUBMITTED"
    end
end
