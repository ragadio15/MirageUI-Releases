local _, M = ...
M.SignalIndex={}
for _,id in ipairs(M.SignalNames) do M.SignalIndex[id]=true end
-- Explicit implementation extensions: source registry vocabulary remains unchanged.
for _,id in ipairs({"ACTIVE_TASK","RECENT_CHAT","COMBAT_RECOVERY","NAVIGATION_HOLD","OPTIONS_OPEN","MAIL_OPEN","SOCIAL_OPEN"}) do M.SignalIndex[id]=true end
M.Store={values={},revision=0}
local T=M.Store
local statuses={KNOWN=true,UNKNOWN=true,RESTRICTED=true,UNSUPPORTED=true,STALE=true}
function T:Publish(id,status,value,ttl,source,observedAt,current)
    if not M.SignalIndex[id] or not statuses[status] then return false end
    if status=="KNOWN" then
        if not M.Safety:Readable(value) then status="RESTRICTED";value=nil
        elseif type(value)~="boolean" and type(value)~="string" and not M.Safety:Number(value) then status="UNKNOWN";value=nil end
    else value=nil end
    -- A sampled provider may supply its already validated read timestamp,
    -- avoiding a callback-capable clock read after its final generation check.
    if observedAt~=nil and not M.Safety:Number(observedAt) then return false end
    local now=observedAt~=nil and observedAt or M.Safety:Now()
    -- Opt-in sampled custody. Safety validation above can invoke native probes;
    -- perform the caller's callback-free final fence before any store mutation.
    if current and not current() then return false end
    local old=self.values[id];local policy=M.Policy or {}
    if not old or old.status~=status or old.value~=value or old.source~=(source or "PUBLIC_ADAPTER") or old.client~=M.Client.key or old.contextEpoch~=policy.contextEpoch or old.scopeEpoch~=policy.scopeEpoch or old.capabilityEpoch~=policy.capabilityEpoch then self.revision=self.revision+1;old=nil end
    local row=old or {}
    row.version=row.version or self.revision;row.contextEpoch=policy.contextEpoch;row.scopeEpoch=policy.scopeEpoch;row.capabilityEpoch=policy.capabilityEpoch
    -- An unchanged observation renews only freshness. The existing immutable
    -- snapshot can remain until its conservative earlier expiry; no decision
    -- gains a longer lifetime without a new validated snapshot.
    if not old then self.cached=nil end
    row.status=status;row.value=value;row.observedAt=now;row.expires=now+(ttl or .4)
    row.decisionEligible=status=="KNOWN";row.source=source or "PUBLIC_ADAPTER";row.client=M.Client.key
    self.values[id]=row
    return true
end
function T:Get(id,now)
    local v=self.values[id]
    if not v then return {status="UNSUPPORTED",decisionEligible=false} end
    if v.status=="KNOWN" and (now or M.Safety:Now())>v.expires then
        v.status="STALE";v.value=nil;v.decisionEligible=false
        self.revision=self.revision+1;v.version=self.revision;self.cached=nil
        return v
    end
    return v
end
function T:Value(id)
    local row=self:Get(id)
    if row.status=="KNOWN" and row.decisionEligible then return row.value end
end
-- Retire one internal signal without querying time or native safety probes.
-- Absence is ineligible UNSUPPORTED, never an observed false value.
function T:Withdraw(id)
    if self.values[id] then self.values[id]=nil;self.revision=self.revision+1;self.cached=nil end
end
function T:Clear()
    self.values={};self.revision=self.revision+1;self.cached=nil
end
function T:Snapshot()
    local now=M.Safety:Now()
    if self.cached and self.cached.revision==self.revision and now<(self.cachedUntil or 0) then return self.cached end
    local out={};local expiry=now+1
    for id in pairs(M.SignalIndex) do
        local v=self:Get(id,now)
        out[id]={status=v.status,value=v.value,decisionEligible=v.decisionEligible,source=v.source,client=v.client,expiresAt=v.expires,version=v.version,contextEpoch=v.contextEpoch,scopeEpoch=v.scopeEpoch,capabilityEpoch=v.capabilityEpoch}
        if v.status=="KNOWN" and v.expires<expiry then expiry=v.expires end
    end
    out.revision=self.revision;self.cached=out;self.cachedUntil=expiry
    return out
end
