local _,M=...
-- Capture only public static parent/anchor topology. Sealed/protected geometry
-- is never measured to manufacture authority or an applied-state confirmation.
M.EffectScope={limit=64,depth=16,points=8}
local C,S=M.EffectScope,M.Safety
local sharedUIParent,sharedWorldFrame=UIParent,WorldFrame
function C:Capture(frame)
    local result={nodes={},index={}};local visiting={}
    local function walk(node,depth)
        if not S:Readable(node) then return false,"RESTRICTED_SCOPE" end
        if node==nil then return true end
        if depth>self.depth then return false,"UNVERIFIED_SCOPE" end
        if visiting[node] then return false,"SCOPE_CYCLE" end
        if result.index[node] then return true end
        -- Shared roots are reference boundaries, not effect targets. Do not
        -- inspect their protected anchor geometry to certify an ordinary child.
        -- Keep exact identity/parent observations and forbidden-state checks.
        local shared=depth>0 and (rawequal(node,sharedUIParent) or
            (sharedWorldFrame~=nil and rawequal(node,sharedWorldFrame)))
        if shared then
            if not S:Frame(node,false) or type(node.GetParent)~="function" then return false,"UNVERIFIED_ROOT" end
            local ok,parent=pcall(node.GetParent,node)
            if not ok or not S:Readable(parent) or (parent~=nil and not rawequal(parent,sharedWorldFrame)) or rawequal(parent,node) then return false,"UNVERIFIED_ROOT_PARENT" end
            if #result.nodes>=self.limit then return false,"SCOPE_LIMIT" end
            local record={object=node,parent=parent,points={},sharedRoot=true}
            result.nodes[#result.nodes+1]=record;result.index[node]=record
            return true
        end
        if not S:Frame(node,true) then return false,"UNVERIFIED_SCOPE" end
        if #result.nodes>=self.limit then return false,"SCOPE_LIMIT" end
        visiting[node]=true
        local ok,parent=pcall(node.GetParent,node)
        if not ok or not S:Readable(parent) then return false,"PARENT_UNAVAILABLE" end
        if type(node.GetNumPoints)~="function" or type(node.GetPoint)~="function" then return false,"ANCHOR_API_UNAVAILABLE" end
        local count,access=S:Public(node.GetNumPoints,"number",node)
        if access~="KNOWN" or count<0 or count%1~=0 or count>self.points then return false,"ANCHOR_LIMIT_OR_RESTRICTED" end
        local record={object=node,parent=parent,points={}}
        result.nodes[#result.nodes+1]=record;result.index[node]=record
        for i=1,count do
            local good,point,relative,relativePoint,x,y=pcall(node.GetPoint,node,i)
            if not good or not S:Text(point) or not S:Readable(relative) or not S:Text(relativePoint) or not S:Number(x) or not S:Number(y) then return false,"ANCHOR_UNAVAILABLE" end
            record.points[i]={point=point,relative=relative,relativePoint=relativePoint,x=x,y=y}
        end
        local valid,why=walk(parent,depth+1);if not valid then return false,why end
        for _,p in ipairs(record.points) do if p.relative~=node then local valid,why=walk(p.relative,depth+1);if not valid then return false,why end end end
        visiting[node]=nil;return true
    end
    local ok,why=walk(frame,0)
    if not ok then return nil,why end
    return result,"PUBLIC_STATIC_SCOPE"
end
function C:Matches(frame,old)
    if not old then return false end
    local current=self:Capture(frame);if not current or #current.nodes~=#old.nodes then return false end
    for _,a in ipairs(old.nodes) do
        local b=current.index[a.object]
        if not b or a.parent~=b.parent or a.sharedRoot~=b.sharedRoot or #a.points~=#b.points then return false end
        for i,p in ipairs(a.points) do local q=b.points[i]
            if p.point~=q.point or p.relative~=q.relative or p.relativePoint~=q.relativePoint or p.x~=q.x or p.y~=q.y then return false end
        end
    end
    return true
end
