local _, M = ...
M.Signals={pulses={},tasks={},chatUntil=0,motionUntil=0,combatUntil=0}
local G=M.Signals
M.ChatCueEvents={CHAT_MSG_WHISPER=true,CHAT_MSG_BN_WHISPER=true,
 CHAT_MSG_PARTY=true,CHAT_MSG_PARTY_LEADER=true,CHAT_MSG_RAID=true,CHAT_MSG_RAID_LEADER=true,CHAT_MSG_RAID_WARNING=true,
 CHAT_MSG_INSTANCE_CHAT=true,CHAT_MSG_INSTANCE_CHAT_LEADER=true,CHAT_MSG_SYSTEM=true}
-- Ordinary public chat stays quiet unless the player selects its category.
-- CHANNEL deliberately covers all ordinary channels: no channel-name, message
-- text, sender or language parsing is needed to distinguish individual channels.
M.ChatCueOptionalEvents={CHAT_MSG_SAY="cueSay",CHAT_MSG_YELL="cueYell",
 CHAT_MSG_GUILD="cueGuild",CHAT_MSG_OFFICER="cueGuild",CHAT_MSG_EMOTE="cueEmote",CHAT_MSG_TEXT_EMOTE="cueEmote",
 CHAT_MSG_CHANNEL="cueChannels"}
M.ChatCueKnownEvents={}
for event in pairs(M.ChatCueEvents) do M.ChatCueKnownEvents[event]=true end
for event in pairs(M.ChatCueOptionalEvents) do M.ChatCueKnownEvents[event]=true end
-- Eight seconds is an existing presentation budget, not native chat freshness.
local chatCueSeconds=8
function G:ResetChatCue()
 self.chatUntil=0;self.chatLastNotification=nil
 if M.ScopedActivity then M.ScopedActivity.chatWindows=setmetatable({},{__mode="k"});M.ScopedActivity.chatCount=0 end
end
function G:ChatCueClock(now,status)
    -- Keep a high-water mark: a regressed clock cannot renew the cue budget.
    if status~="KNOWN" or (self.chatClock and now<self.chatClock) then self:ResetChatCue();return false end
    self.chatClock=now;return true
end
function G:ChatCueEnabled(event)
    local cfg=M:ModuleConfig("Chat")
    if not (cfg and cfg.messageCue==true and M:IsModuleActive("Chat") and M.state.world and not M.state.cinematic) then return false end
    if event==nil then return true end
    if not M.Safety:Text(event) then return false end
    if M.ChatCueEvents[event] then return true end
    local option=M.ChatCueOptionalEvents[event]
    return option~=nil and cfg[option]==true or false
end
-- b35 local presentation activity. These are bounded UI inspection deadlines,
-- not gameplay facts or CVE/native permissions. No message or unit payload is
-- retained, and no passive event consumes an input interaction lease.
local A={records={},chatWindows=setmetatable({},{__mode="k"}),selection={target=0,focus=0,pet=0,group=0},revision=0,limit=32}
M.ScopedActivity=A
local recipients={NAV=true,STATUS=true,TRACKER=true,PLAYER=true,PET=true,TARGET=true,FOCUS=true,GROUP=true,
 COMBAT=true,CAST=true,CHAT=true,LAUNCH=true,PROGRESS=true,PLATES=true,BAGS=true,BANK=true,CURSOR=true}
local function observed(snapshot,key)
 local r=snapshot and snapshot[key]
 if r and r.status=="KNOWN" and r.decisionEligible==true and M.Safety:Readable(r.value) then return r.value end
end
function A:Reset()
 self.records={};self.chatWindows=setmetatable({},{__mode="k"});self.chatCount=0
 self.castSubjects=nil;self.afk=nil
 for role,generation in pairs(self.selection) do self.selection[role]=generation+1 end
 self.profile=M.profile;self.context=M.Policy and M.Policy.contextEpoch;self.scope=M.Policy and M.Policy.scopeEpoch
 self.world=M.state.world;self.clock=nil;self.revision=self.revision+1
 M.state.forceEvaluate=true
end
function A:Current(now)
 if not M.Safety:Number(now) then return false end
 local policy=M.Policy or {}
 if self.profile~=M.profile or self.context~=policy.contextEpoch or self.scope~=policy.scopeEpoch
  or self.world~=M.state.world or self.clock and now<self.clock then self:Reset() end
 self.clock=now
 return M.profile~=nil and M.state.world==true and not M.state.safe and not M.state.cinematic
end
function A:Enabled()
 return M.profile and M.profile.managed and M.profile.preset=="Immersive" or false
end
function A:Pulse(key,recipient,seconds,now)
 now=now or M.Safety:Now()
 if not self:Current(now) or not recipients[recipient] or type(key)~="string" or #key>40
  or not M.Safety:Number(seconds) then return false end
 local count=0;for k,r in pairs(self.records) do
  if r.expires<=now then self.records[k]=nil else count=count+1 end
 end
 if not self.records[key] and count>=self.limit then return false end
 self.records[key]={recipient=recipient,expires=now+math.max(0,math.min(10,seconds))}
 self.revision=self.revision+1;M.state.forceEvaluate=true
 return true
end
function A:Cancel(key)
 if self.records[key] then self.records[key]=nil;self.revision=self.revision+1;M.state.forceEvaluate=true end
end
function A:RetireTransient()
 -- Death/AFK are not chat-history or incoming-message cancellation events.
 -- Only transient gameplay inspections/receipts and their subjects retire.
 self.records={};self.castSubjects=nil
 for role,generation in pairs(self.selection) do self.selection[role]=generation+1 end
 self.revision=self.revision+1;M.state.forceEvaluate=true
end
function A:ObserveAFK(value)
 if not M.Safety:Readable(value) or type(value)~="boolean" then return end
 if self.afk~=value then
  if self.afk~=nil or value then self:RetireTransient() end
  self.afk=value
 end
end
function A:Active(recipient,now)
 now=now or M.Safety:Now();if not self:Current(now) then return false end
 local untilAt
 for key,r in pairs(self.records) do
  if r.expires<=now then self.records[key]=nil
  elseif r.recipient==recipient then untilAt=math.max(untilAt or 0,r.expires) end
 end
 return untilAt~=nil,untilAt
end
function A:Select(role,now)
 now=now or M.Safety:Now();if not self:Current(now) or self.selection[role]==nil then return false end
 self.selection[role]=self.selection[role]+1;self:Cancel("inspect:"..role)
 local exists,status
 if role=="group" then exists,status=M.Safety:Public(IsInGroup,"boolean")
 else exists,status=M.Safety:Public(UnitExists,"boolean",role) end
 if status=="KNOWN" and exists==true then return self:Pulse("inspect:"..role,role:upper(),3,now) end
 M.state.forceEvaluate=true;return false
end
function A:Inspect(role,now)
 now=now or M.Safety:Now();if not self:Current(now) then return false end
 local r=self.records["inspect:"..role]
 return r~=nil and r.expires>now,r and r.expires or nil
end
function A:SelectionGeneration(role)
 self:Current(M.Safety:Now());return self.selection[role] or 0
end
function A:EndCastInspection()
 if self.castSubjects then self.castSubjects=nil;self.revision=self.revision+1;M.state.forceEvaluate=true end
end
local castRoles={TARGET="target",FOCUS="focus",GROUP="group"}
function A:BeginCastInspection(now)
 now=now or M.Safety:Now();if not self:Current(now) then return end
 self.castSubjects={}
 local function capture(recipient,source,kind)
  local role=castRoles[recipient];if not role then return end
  if role~="group" and M.Safety:Public(UnitExists,"boolean",role)~=true then return end
  self.castSubjects[recipient]={generation=self.selection[role],source=source,kind=kind,
   ownerEpoch=source and source.ownerEpoch,userRevision=source and source.userRevision,serial=source and source.serial}
 end
 -- A player cast is not evidence of its destination. Preserve only an
 -- inspection that was explicitly current when this cast began.
 for _,role in ipairs({"target","focus"}) do
  if self:Inspect(role,now) then capture(role:upper(),nil,"inspection") end
 end
 for _,surface in pairs(M.surfaces or {}) do
  if surface.module=="UnitFrames" or surface.module=="PartyRaid" then
   local recipient=M.Experience and M.Experience:Recipient(surface)
   if castRoles[recipient] and M.Safety:Frame(surface.frame,false)
    and M.Safety:Public(surface.frame.IsVisible,"boolean",surface.frame)==true then
    local held=M.Policy and M.Policy:HasInteraction(surface,now)
     or M.Safety:Number(surface.interactingUntil) and surface.interactingUntil>now
    if held then capture(recipient,surface,"surface") end
   end
  end
 end
 local context=M.ContextualNative
 for name,recipient in pairs({TargetFrame="TARGET",FocusFrame="FOCUS",PartyFrame="GROUP",CompactRaidFrameContainer="GROUP"}) do
  local row=context and context.rows[name]
  if row and row.active and _G[name]==row.frame and (row.inputHeld or M.Safety:Number(row.hoverUntil) and row.hoverUntil>now)
   and M.Safety:Frame(row.frame,false) and M.Safety:Public(row.frame.IsVisible,"boolean",row.frame)==true then capture(recipient,row,"native") end
 end
 if not next(self.castSubjects) then self.castSubjects=nil end
 self.revision=self.revision+1;M.state.forceEvaluate=true
end
function A:CastInspection(recipient,now)
 now=now or M.Safety:Now();if not self:Current(now) then return false end
 local row=self.castSubjects and self.castSubjects[recipient];local role=castRoles[recipient]
 if not row or not role or self.selection[role]~=row.generation then return false end
 if row.kind=="surface" and (M.surfaces[row.source.id]~=row.source or row.source.ownerEpoch~=row.ownerEpoch
  or row.source.userRevision~=row.userRevision) then return false end
 if row.kind=="native" and (not M.ContextualNative or M.ContextualNative.rows[row.source.name]~=row.source
  or row.source.serial~=row.serial or not row.source.active or _G[row.source.name]~=row.source.frame) then return false end
 return true
end
function A:ChatTyping(frame)
 if not frame or not M.Safety:Frame(frame,false) then return false end
 local edit,status=M.Safety:FieldAccess(frame,"editBox")
 if status~="KNOWN" or not M.Safety:Frame(edit,false) then return false end
 local focused,known=M.Safety:Public(edit.HasFocus,"boolean",edit)
 if known=="KNOWN" then return focused end
 local active,access=M.Safety:Public(ChatEdit_GetActiveWindow,nil)
 return access=="KNOWN" and M.Safety:Readable(active) and active==edit or false
end
function A:NotifyChat(event,frame,now)
 now=now or M.Safety:Now()
 if not self:Current(now) or not M.Safety:Text(event) or not M.ChatCueKnownEvents[event] or not M.Signals:ChatCueEnabled(event)
  or not M.Safety:Frame(frame,false) then return false end
 local name,status=M.Safety:Public(frame.GetName,"string",frame)
 if status~="KNOWN" or not name:match("^ChatFrame%d+$") or _G[name]~=frame then return false end
 local n=tonumber(name:match("(%d+)$"));if not n or n<1 or n>128 then return false end
 local old=self.chatWindows[frame]
 if not old and (self.chatCount or 0)>=128 then
  local count=0;for f,r in pairs(self.chatWindows) do
   if r.expires<=now or _G[r.name]~=f then self.chatWindows[f]=nil else count=count+1 end
  end
  self.chatCount=count;if count>=128 then return false end
 end
 if not old then self.chatCount=(self.chatCount or 0)+1 end
 self.chatWindows[frame]={name=name,expires=now+8,
  importantExpires=M.ChatCueEvents[event] and now+8 or old and old.importantExpires}
 M.Signals.chatUntil=now+8;M.Signals.chatLastNotification=now
 self.revision=self.revision+1;M.state.forceEvaluate=true
 return true
end
function A:NotifyChatType(frame,typeID)
 if not M.Safety:Number(typeID) or not M.Signals:ChatCueEnabled() then return false end
 -- The native insertion's message-type identifier supplies routing evidence.
 -- Text, sender, channel, language and private-message identities are unused.
 for event in pairs(M.ChatCueKnownEvents) do
  if M.Signals:ChatCueEnabled(event) then
   local kind=event:sub(10)
   local info,known=M.Safety:FieldAccess(ChatTypeInfo,kind)
   if known=="KNOWN" then
    local id,state=M.Safety:FieldAccess(info,"id")
    if state=="KNOWN" and M.Safety:Number(id) and id==typeID then return self:NotifyChat(event,frame) end
   end
  end
 end
 return false
end
function A:ChatWindow(frame,now,importantOnly)
 now=now or M.Safety:Now();if not self:Current(now) then return false,"CHAT_SCOPE_RETIRED" end
 if self:ChatTyping(frame) then return true,"CHAT_OWN_INPUT" end
 local r=frame and self.chatWindows[frame]
 if r and _G[r.name]==frame and r.expires>now then
  if not importantOnly or r.importantExpires and r.importantExpires>now then
   return true,"CHAT_LOCAL_MESSAGE",importantOnly and r.importantExpires or r.expires
  end
  return false,"CHAT_QUIET"
 end
 if r then self.chatWindows[frame]=nil;self.chatCount=math.max(0,(self.chatCount or 0)-1) end
 return false,"CHAT_QUIET"
end
function A:AnyChat(now)
 now=now or M.Safety:Now();if not self:Current(now) then return false end
 local untilAt
 for frame,r in pairs(self.chatWindows) do
  if r.expires<=now or _G[r.name]~=frame then self.chatWindows[frame]=nil;self.chatCount=math.max(0,(self.chatCount or 0)-1)
  else untilAt=math.max(untilAt or 0,r.expires) end
 end
 return untilAt~=nil,untilAt
end
function A:ChatDockCue(frame,now,importantOnly)
 -- A hidden receiving tab can reveal the already selected native dock shell;
 -- it never selects that tab or wakes unrelated undocked chat windows.
 now=now or M.Safety:Now();if not self:Current(now) or not frame then return false end
 local docked=M.Safety:Field(frame,"isDocked")
 local shown,known=M.Safety:Public(frame.IsShown,"boolean",frame)
 if not M.Safety:Readable(docked) or not docked or known~="KNOWN" or not shown then return false end
 local untilAt
 for other,r in pairs(self.chatWindows) do
  local expires=importantOnly and (r.importantExpires or 0) or r.expires
  if other~=frame and expires>now and _G[r.name]==other then
   local d=M.Safety:Field(other,"isDocked")
   local visible,state=M.Safety:Public(other.IsShown,"boolean",other)
   if M.Safety:Readable(d) and d and state=="KNOWN" and not visible then untilAt=math.max(untilAt or 0,expires) end
  end
 end
 return untilAt~=nil,untilAt
end
function A:Demand(recipient,snapshot,now)
 snapshot=snapshot or (M.Store and M.Store:Snapshot()) or {}
 now=now or M.Safety:Now()
 if not self:Current(now) then return false,"LOCAL_SCOPE_RETIRED" end
 if not recipients[recipient] then return false,"NO_LOCAL_RECIPIENT" end
 if observed(snapshot,"NATIVE_UI_HIDDEN")==true or observed(snapshot,"WORLD_LOAD_OR_TELEPORT")==true then return false,"NATIVE_UI_HIDDEN" end
 if M.PresentationGroups and M.PresentationGroups:Enabled() and
  (recipient=="COMBAT" or recipient=="PLAYER" or recipient=="PET" or recipient=="TARGET" or recipient=="FOCUS" or recipient=="GROUP"
   or M.PresentationGroups:IsNavigation(recipient)) then
  return M.PresentationGroups:Demand(recipient,snapshot,now)
 end
 local active,due=self:Active(recipient,now)
 if active then return true,"LOCAL_"..recipient,due end
 if self:CastInspection(recipient,now) then return true,"LOCAL_CAST_INSPECTION" end
 -- Explicit native waypoints retain their established local navigation cue.
 -- They are user-created navigation, not inferred world movement.
 if (recipient=="NAV" or recipient=="TRACKER") and observed(snapshot,"MAP_OPEN")~=true
  and observed(snapshot,"TAXI_TRAVEL_ACTIVE")~=true and M.NavigationPin and M.NavigationPin:Active()==true then
  return true,"LOCAL_USER_WAYPOINT"
 end
 if M.PresentationGroups and M.PresentationGroups:Enabled() then
  local shown,why,deadline=M.PresentationGroups:Demand(recipient,snapshot,now)
  if why~="NO_PRESENTATION_GROUP" then return shown,why,deadline end
 end
 local combat=observed(snapshot,"PLAYER_IN_COMBAT")
 local moving=observed(snapshot,"PLAYER_MOVING")
 local encounter=observed(snapshot,"ENCOUNTER_ACTIVE")
 -- A user-created native waypoint is a deliberate local navigation pin. It
 -- does not reveal status, combat or plate recipients, or replace the full map.
 if (recipient=="NAV" or recipient=="TRACKER") and observed(snapshot,"MAP_OPEN")~=true
  and M.NavigationPin and M.NavigationPin:Active()==true then return true,"LOCAL_USER_WAYPOINT" end
 if observed(snapshot,"PLAYER_AFK")==true and combat~=true and encounter~=true
  and (recipient=="NAV" or recipient=="STATUS" or recipient=="TRACKER" or recipient=="PLATES" or recipient=="CURSOR") then
  return false,"LOCAL_AFK"
 end
 if recipient=="CHAT" then local yes,untilAt=self:AnyChat(now);return yes,yes and "CHAT_LOCAL_MESSAGE" or "CHAT_QUIET",untilAt end
 if recipient=="NAV" or recipient=="STATUS" or recipient=="TRACKER" or recipient=="PLATES" then
  if observed(snapshot,"MAP_OPEN")==true then return false,"NATIVE_MAP_CONTEXT" end
  if moving==true then return true,"LOCAL_MOVEMENT" end
  if (recipient=="NAV" or recipient=="STATUS") and observed(snapshot,"TAXI_TRAVEL_ACTIVE")==true then return true,"LOCAL_TAXI" end
  if recipient=="PLATES" and (combat==true or encounter==true) then return true,"LOCAL_COMBAT" end
  if moving==nil then return nil,"LOCAL_MOTION_UNKNOWN" end
  return false,"LOCAL_QUIET"
 end
 if recipient=="TARGET" or recipient=="FOCUS" then
  local exists=observed(snapshot,recipient.."_EXISTS")
  if exists==false then return false,"LOCAL_SUBJECT_ABSENT" end
  if exists==nil then return nil,"LOCAL_SUBJECT_UNKNOWN" end
  if combat==true or encounter==true then return true,"LOCAL_COMBAT" end
  return false,"LOCAL_QUIET"
 end
 if recipient=="CAST" then
  local casting,channeling=observed(snapshot,"PLAYER_CASTING"),observed(snapshot,"PLAYER_CHANNELING")
  if casting==true or channeling==true then return true,"LOCAL_PLAYER_CAST" end
  if casting==nil or channeling==nil then return nil,"LOCAL_CAST_UNKNOWN" end
  return false,"LOCAL_QUIET"
 end
 if recipient=="BAGS" then return observed(snapshot,"BAGS_OPEN")==true or observed(snapshot,"BANK_OPEN")==true,"LOCAL_INVENTORY" end
 if recipient=="BANK" then return observed(snapshot,"BANK_OPEN")==true,"LOCAL_BANK" end
 if recipient=="PROGRESS" then return false,"LOCAL_QUIET" end
 if recipient=="LAUNCH" then return observed(snapshot,"BAGS_OPEN")==true or observed(snapshot,"BANK_OPEN")==true,"LOCAL_INVENTORY_LAUNCH" end
 if combat==true or encounter==true then return true,"LOCAL_COMBAT" end
 if combat==nil then return nil,"LOCAL_COMBAT_UNKNOWN" end
 return false,"LOCAL_QUIET"
end

-- Exact-source sampled encounter state, not admitted authority or event history.
local encounterPin=M.Client:NewSourcePinLookup()
local encounterSource="INSTANCE_ENCOUNTER_SNAPSHOT"
function G:EncounterAllowed()
    local c=M.Client;local runtime=c and (c.IsRuntimeClient or c.IsReviewedPresentationClient)
    return c and type(runtime)=="function" and runtime(c)==true
        and M.state.world==true and not M.state.safe and M.profile and M.profile.enabled==true or false
end
function G:InvalidateEncounter()
    self.encounterEpoch=(self.encounterEpoch or 0)+1
    M.Store:Publish("ENCOUNTER_ACTIVE","UNKNOWN",nil,0,encounterSource)
    M.state.forceEvaluate=true
end
function G:ObserveEncounter()
    local function unavailable(status) M.Store:Publish("ENCOUNTER_ACTIVE",status or "UNKNOWN",nil,0,encounterSource,0) end
    if self.encounterReading or not self:EncounterAllowed() then unavailable();return end
    local epoch,context,capability=self.encounterEpoch,M.Policy.contextEpoch,M.Policy.capabilityEpoch
    local client,adapter,profile=M.Client.key,M.adapter,M.profile
    local namespace=C_InstanceEncounter
    local function current()
        return epoch==self.encounterEpoch and self:EncounterAllowed() and context==M.Policy.contextEpoch and capability==M.Policy.capabilityEpoch and
            client==M.Client.key and adapter==M.adapter and profile==M.profile and namespace==C_InstanceEncounter
    end
    self.encounterReading=true -- own even namespace/clock probes against nested events
    local function finish(status,value,observedAt)
        -- A newer invalidation owns the result; do not overwrite its observation.
        if epoch==self.encounterEpoch then M.Store:Publish("ENCOUNTER_ACTIVE",status,value,status=="KNOWN" and .45 or 0,encounterSource,observedAt or 0) end
        self.encounterReading=nil
    end
    local before,clock=M.Safety:Public(GetTime,"number")
    if not current() or clock~="KNOWN" or (self.encounterClock and before<self.encounterClock) then finish("UNKNOWN");return end
    local fn,access=M.Safety:FieldAccess(namespace,"IsEncounterInProgress")
    if not current() then finish("UNKNOWN");return end
    if access~="KNOWN" or type(fn)~="function" then finish(access=="RESTRICTED" and "RESTRICTED" or "UNKNOWN");return end
    local value,status=M.Safety:Public(fn,"boolean")
    if not current() then finish("UNKNOWN");return end
    local after,afterStatus=M.Safety:Public(GetTime,"number")
    if not current() or afterStatus~="KNOWN" or after<before then finish("UNKNOWN");return end
    local latest=M.Safety:Field(C_InstanceEncounter,"IsEncounterInProgress")
    if not current() or latest~=fn then finish("UNKNOWN");return end
    self.encounterClock=after
    -- .45 is only the existing engine observation-retirement budget. Pass the
    -- sampled timestamp: publication must not reread a callback-capable clock.
    if status=="KNOWN" then finish("KNOWN",value,after)
    else finish(status=="RESTRICTED" and "RESTRICTED" or "UNKNOWN",nil,after) end
end
-- Ordinary target existence only: not identity, a CVE grant or native acceptance.
local targetClientKeys={"key","allowed","sourceMatched","family","patch","build","interface"}
local targetAdapterKeys={"family","patch","build","interface","sourceCommit"}
local function targetCopy(object,keys)
    local out={};for _,key in ipairs(keys) do out[key]=object and object[key] end;return out
end
local function targetSame(object,values,keys)
    for _,key in ipairs(keys) do if object[key]~=values[key] then return false end end;return true
end
function G:InvalidateTarget()
    self.targetGeneration=(self.targetGeneration or 0)+1
    -- Withdrawal is callback-free: it cannot recursively sample a replacement.
    M.Store:Withdraw("TARGET_EXISTS");M.state.forceEvaluate=true
end
function G:ObserveTarget()
    self.targetGeneration=(self.targetGeneration or 0)+1
    local generation=self.targetGeneration
    local depth=self.targetDepth or 0
    -- Allow a fresh nested observation, but a repeated target reentry abstains.
    -- This does not bound unrelated callbacks elsewhere in the Observe batch.
    if depth>=2 then self:InvalidateTarget();return end
    self.targetDepth=depth+1
    local client,adapter,profile,state,policy,store,safety=M.Client,M.adapter,M.profile,M.state,M.Policy,M.Store,M.Safety
    local values=store.values
    local clientValues,adapterValues=targetCopy(client,targetClientKeys),targetCopy(adapter,targetAdapterKeys)
    local context,scope,capability,ruleset=policy.contextEpoch,policy.scopeEpoch,policy.capabilityEpoch,policy.rulesetEpoch
    local exists,clock=UnitExists,GetTime
    local public,readable,number=safety.Public,safety.Readable,safety.Number
    local secret,access=issecretvalue,canaccessvalue
    local publish=store.Publish
    local function latest() return M.Signals==self and generation==self.targetGeneration end
    local function current()
        -- Only owned internal state and function identities: no native callbacks.
        return latest() and M.Client==client and M.adapter==adapter and M.profile==profile and M.state==state and
            M.Policy==policy and M.Store==store and store.values==values and store.Publish==publish and M.Safety==safety and
            safety.Public==public and safety.Readable==readable and safety.Number==number and issecretvalue==secret and canaccessvalue==access and
            UnitExists==exists and GetTime==clock and client and adapter and profile and state and
            client.allowed==true and profile.enabled==true and state.world==true and not state.safe and
            targetSame(client,clientValues,targetClientKeys) and targetSame(adapter,adapterValues,targetAdapterKeys) and
            policy.contextEpoch==context and policy.scopeEpoch==scope and policy.capabilityEpoch==capability and policy.rulesetEpoch==ruleset
    end
    local function finish(status,value,observedAt)
        local committed=false
        if current() then committed=store:Publish("TARGET_EXISTS",status,value,.45,nil,observedAt or 0,current) end
        -- Validation inside Publish can itself replace the context. Never clear
        -- a newer generation, but do not leave old eligible truth behind either.
        if not committed and latest() then M.Store:Withdraw("TARGET_EXISTS") end
        if committed and observedAt then self.targetClock=observedAt end
        self.targetDepth=depth
    end
    if not current() then finish("UNKNOWN");return end
    local before,beforeStatus=safety:Public(clock,"number")
    if not current() or beforeStatus~="KNOWN" or (self.targetClock and before<self.targetClock) then finish("UNKNOWN");return end
    local value,status=safety:Public(exists,"boolean","target")
    if not current() then finish("UNKNOWN");return end
    local after,afterStatus=safety:Public(clock,"number")
    if not current() or afterStatus~="KNOWN" or after<before then finish("UNKNOWN");return end
    finish(status,value,after)
end
-- 70888's native CastingBarMixin reconciles presence from the first return of
-- UnitCastingInfo/UnitChannelInfo. These returns can be secret. Only a freshly
-- readable nil/string permits an ordinary presence observation. A non-nil
-- NeverSecret castBarID is also positive presence evidence. The text and key
-- are discarded here and never retained, classified, formatted, or logged.
function G:InvalidateCasting()
    self.castGeneration=(self.castGeneration or 0)+1
    M.Store:Withdraw("PLAYER_CASTING");M.Store:Withdraw("PLAYER_CHANNELING")
    M.state.forceEvaluate=true
end
function G:ObserveCasting()
    if self.castReading or not self:EncounterAllowed() then self:InvalidateCasting();return end
    self.castReading=true
    local generation=self.castGeneration or 0
    local profile,store,safety=M.profile,M.Store,M.Safety
    local casting,channeling=UnitCastingInfo,UnitChannelInfo
    local context,capability=M.Policy.contextEpoch,M.Policy.capabilityEpoch
    local function current()
        return M.Signals==self and (self.castGeneration or 0)==generation and M.profile==profile
            and M.Store==store and M.Safety==safety and UnitCastingInfo==casting and UnitChannelInfo==channeling
            and M.Policy.contextEpoch==context and M.Policy.capabilityEpoch==capability and self:EncounterAllowed()
    end
    local before,clock=safety:Public(GetTime,"number")
    if clock~="KNOWN" or (self.castClock and before<self.castClock) or not current() then
        self.castReading=nil;self:InvalidateCasting();return
    end
    local knownInactive=0
    for _,row in ipairs({{"PLAYER_CASTING",casting,10},{"PLAYER_CHANNELING",channeling,11}}) do
        local present,status=nil,"UNSUPPORTED"
        if type(row[2])=="function" then
            local ok,name,key=pcall(function()
                local name,display,texture,startTime,endTime,trade,identity,interrupt,spell,key10,key11=row[2]("player")
                if row[3]==10 then return name,key10 end
                return name,key11
            end)
            if not ok then status="UNKNOWN"
            elseif safety:Readable(key) and (safety:Number(key) or safety:Text(key)) then status="KNOWN";present=true
            elseif not safety:Readable(name) then status="RESTRICTED"
            elseif name==nil then status="KNOWN";present=false
            elseif type(name)=="string" then status="KNOWN";present=true
            else status="UNKNOWN" end
        end
        local after,known=safety:Public(GetTime,"number")
        if known~="KNOWN" or after<before or not current() then
            self.castReading=nil;self:InvalidateCasting();return
        end
        if not store:Publish(row[1],status,present,status=="KNOWN" and .45 or 0,"PUBLIC_CAST_PRESENCE",after,current) then
            self.castReading=nil;self:InvalidateCasting();return
        end
        self.castClock=after
        if status=="KNOWN" and present==false then knownInactive=knownInactive+1 end
    end
    if knownInactive==2 and current() then M.ScopedActivity:EndCastInspection() end
    self.castReading=nil
end
local function publish(id,fn,kind,...)
    local value,status=M.Safety:Public(fn,kind,...)
    M.Store:Publish(id,status,value,.45)
    return value,status
end
local function known(id,value) M.Store:Publish(id,"KNOWN",value,.45,"ENGINE_LOCAL") end
local function shown(frame)
    if not M.Safety:Frame(frame,false) or not frame.IsShown then return nil end
    local value,status=M.Safety:Public(frame.IsShown,"boolean",frame)
    if status~="KNOWN" then return nil end
    return value
end
local function anyShown(names)
    local unavailable=false
    for _,name in ipairs(names) do
        local frame=_G[name]
        if frame then local value=shown(frame);if value==true then return true elseif value==nil then unavailable=true end end
    end
    if unavailable then return nil end
    return false
end
local panels={
    MAP_OPEN={"WorldMapFrame"},QUEST_LOG_OPEN={"QuestLogFrame","QuestMapFrame"},
    BAGS_OPEN={"ContainerFrameCombinedBags","ContainerFrame1","ContainerFrame2","ContainerFrame3","ContainerFrame4","ContainerFrame5"},
    VENDOR_OPEN={"MerchantFrame"},BANK_OPEN={"BankFrame","GuildBankFrame"},
    AUCTION_OPEN={"AuctionHouseFrame","AuctionFrame"},TRADE_OPEN={"TradeFrame"},
    MAIL_OPEN={"MailFrame"},SOCIAL_OPEN={"FriendsFrame","GuildFrame","CommunitiesFrame"},
    PROFESSION_OPEN={"ProfessionsFrame","TradeSkillFrame","CraftFrame"},
    DIALOG_OPEN={"GossipFrame","QuestFrame","StaticPopup1","StaticPopup2","StaticPopup3","StaticPopup4","ReadyCheckFrame"},
}
function G:Pulse(id,seconds)
    if M.SignalIndex[id] then self.pulses[id]=M.Safety:Now()+(seconds or 4) end
end
-- Read-only presentation baselines distinguish repeated initialization notices
-- from a changed value. They confer no gameplay authority, retain no unit or
-- chat identity, and never retire a real activity record or start a timer.
function G:HydrationValue(kind)
    if kind=="xp" then
        local value,status=M.Safety:Public(UnitXP,"number","player")
        if status=="KNOWN" then return value end
    else
        local zone,zoneStatus=M.Safety:Public(GetZoneText,"string")
        local sub,subStatus=M.Safety:Public(GetSubZoneText,"string")
        if zoneStatus=="KNOWN" and subStatus=="KNOWN" then return {zone,sub} end
    end
end
function G:PrimeWorldBaseline()
    local generation,profile=self.targetGeneration,M.profile
    local xp,zone=self:HydrationValue("xp"),self:HydrationValue("zone")
    if generation==self.targetGeneration and profile==M.profile then self.hydration={xp=xp,zone=zone} end
end
function G:RepeatedHydration(event)
    local kind=event=="PLAYER_XP_UPDATE" and "xp" or
        (event=="ZONE_CHANGED" or event=="ZONE_CHANGED_NEW_AREA" or event=="ZONE_CHANGED_INDOORS") and "zone"
    if not kind or not self.hydration or not M.state.world then return false end
    local generation,profile,baseline=self.targetGeneration,M.profile,self.hydration
    local value=self:HydrationValue(kind)
    if generation~=self.targetGeneration or profile~=M.profile or self.hydration~=baseline then return false end
    local prior=baseline[kind];baseline[kind]=value
    if value==nil or prior==nil then return false end -- unknown is not proof of initialization noise
    local same=kind=="xp" and value==prior or kind=="zone" and value[1]==prior[1] and value[2]==prior[2]
    if same then self.hydrationSuppressed=math.min(99999,(self.hydrationSuppressed or 0)+1) end
    return same
end
function G:Event(event,...)
    -- Providers still receive the native event in Core.Events. This only
    -- avoids a visibility cue for a known unchanged public XP/location value.
    if self:RepeatedHydration(event) then return end
    if M.PresentationGroups then M.PresentationGroups:OnEvent(event,...) end
    if event=="PLAYER_TARGET_CHANGED" then self:InvalidateTarget() end
    if event:sub(1,15)=="UNIT_SPELLCAST_" then
        local unit=...
        if M.Safety:Text(unit) and unit=="player" then self:InvalidateCasting() end
    end
    if event=="ENCOUNTER_STATE_CHANGED" or event=="ENCOUNTER_START" or event=="ENCOUNTER_END" then self:InvalidateEncounter() end
    local clock,clockStatus=M.Safety:Public(GetTime,"number")
    local now=clock or 0;local cueClock=self:ChatCueClock(clock,clockStatus)
    local activity=M.ScopedActivity
    if event=="PLAYER_DEAD" or event=="PLAYER_ALIVE" or event=="PLAYER_UNGHOST" then
        activity:RetireTransient();self.pulses={};self.motionUntil=0;self.combatUntil=0;self:InvalidateCasting()
    elseif event=="UNIT_SPELLCAST_START" or event=="UNIT_SPELLCAST_CHANNEL_START" or event=="UNIT_SPELLCAST_EMPOWER_START" then
        local unit=...;if M.Safety:Text(unit) and unit=="player" then activity:BeginCastInspection(now) end
    elseif event=="UNIT_SPELLCAST_STOP" or event=="UNIT_SPELLCAST_CHANNEL_STOP" or event=="UNIT_SPELLCAST_EMPOWER_STOP"
        or event=="UNIT_SPELLCAST_FAILED" or event=="UNIT_SPELLCAST_FAILED_QUIET" or event=="UNIT_SPELLCAST_INTERRUPTED" then
        local unit=...;if M.Safety:Text(unit) and unit=="player" then activity:EndCastInspection() end
    elseif event=="PLAYER_TARGET_CHANGED" then activity:Select("target",now)
    elseif event=="PLAYER_FOCUS_CHANGED" then activity:Select("focus",now)
    elseif event=="UNIT_PET" then
        local unit=...;if M.Safety:Text(unit) and unit=="player" then activity:Select("pet",now) end
    elseif event=="GROUP_ROSTER_UPDATE" then activity:Select("group",now)
    elseif event=="PLAYER_REGEN_ENABLED" or event=="PLAYER_REGEN_DISABLED" then self.combatUntil=0
    elseif event=="QUEST_ACCEPTED" then self:Pulse("QUEST_ACCEPTED",8);activity:Pulse("quest:accept","TRACKER",8,now)
    elseif event=="QUEST_LOG_UPDATE" or event=="QUEST_WATCH_UPDATE" or event=="QUEST_WATCH_LIST_CHANGED" then
        self.questCountAt=nil
        -- QUEST_LOG_UPDATE also fires on opening/reading the full native log.
        -- Only watched objective notifications create a local tracker cue.
        if event~="QUEST_LOG_UPDATE" then self:Pulse("QUEST_OBJECTIVE_CHANGED",5);activity:Pulse("quest:watch","TRACKER",5,now) end
    elseif event=="PLAYER_XP_UPDATE" then self:Pulse("XP_GAINED",4);activity:Pulse("progress:xp","PROGRESS",4,now)
    elseif event=="PLAYER_LEVEL_UP" then self:Pulse("LEVEL_GAINED",8);activity:Pulse("progress:level","PROGRESS",8,now)
    elseif event=="UPDATE_FACTION" then activity:Pulse("progress:reputation","PROGRESS",4,now)
    elseif event=="ZONE_CHANGED" or event=="ZONE_CHANGED_NEW_AREA" then self:Pulse("ZONE_CHANGED",5);activity:Pulse("location","STATUS",5,now)
    elseif event=="ZONE_CHANGED_INDOORS" then self:Pulse("SUBZONE_CHANGED",5);activity:Pulse("location","STATUS",5,now)
    elseif M.ChatCueKnownEvents[event] then
        -- Delivery alone does not prove which chat window accepted the message.
        -- The native AddMessage post-hook calls NotifyChatType on its actual
        -- recipient. Filters, hidden tabs and restored history keep native roles.
        if not cueClock or not self:ChatCueEnabled() then self:ResetChatCue() end
    end
    -- Cast/encounter/prompt events still reach their native display modules.
    -- They do not establish an authoritative ongoing activity observation.
end
function G:Observe()
    if not M.Client.allowed then self:InvalidateTarget();self:InvalidateEncounter();return end
    local clock,clockStatus=M.Safety:Public(GetTime,"number")
    local now=clock or 0;local cueClock=self:ChatCueClock(clock,clockStatus)
    local lockdown=publish("COMBAT_LOCKDOWN",InCombatLockdown,"boolean")
    local combat,status=publish("PLAYER_IN_COMBAT",UnitAffectingCombat,"boolean","player")
    if lockdown==true then known("PLAYER_IN_COMBAT",true);combat=true end
    publish("PLAYER_DEAD",UnitIsDead,"boolean","player")
    publish("PLAYER_GHOST",UnitIsGhost,"boolean","player")
    local afk=publish("PLAYER_AFK",UnitIsAFK,"boolean","player")
    M.ScopedActivity:ObserveAFK(afk)
    local speed,ss=M.Safety:Public(GetUnitSpeed,"number","player")
    if ss=="KNOWN" then
        local moving=speed>0
        known("PLAYER_MOVING",moving);known("PLAYER_STATIONARY",not moving)
        self.motionUntil=0 -- movement has no blanket linger in b35
    else
        M.Store:Publish("PLAYER_MOVING",ss,nil,.45);M.Store:Publish("PLAYER_STATIONARY",ss,nil,.45)
        self.motionUntil=0
    end
    publish("PLAYER_MOUNTED",IsMounted,"boolean")
    publish("PLAYER_SWIMMING",IsSwimming,"boolean")
    publish("PLAYER_SUBMERGED",IsSubmerged,"boolean")
    publish("PLAYER_FALLING",IsFalling,"boolean")
    publish("PLAYER_RESTED_STATUS",IsResting,"boolean")
    publish("TAXI_TRAVEL_ACTIVE",UnitOnTaxi,"boolean","player")
    publish("PLAYER_IN_VEHICLE_OR_POSSESSION",UnitInVehicle,"boolean","player")
    publish("PLAYER_HAS_PET",UnitExists,"boolean","pet")
    local questCfg=M:ModuleConfig("QuestTracker")
    if questCfg and questCfg.compactPanel and M:IsModuleActive("QuestTracker") then
        if not self.questCountAt or now-self.questCountAt>=.5 or self.questCountWorld~=questCfg.worldQuests then
            self.questCount,self.questCountState=M.Safety:Public(C_QuestLog and C_QuestLog.GetNumQuestWatches,"number")
            if self.questCountState=="KNOWN" and (self.questCount<0 or self.questCount%1~=0) then self.questCountState="UNKNOWN";self.questCount=nil end
            if questCfg.worldQuests then
                local extra,access=M.Safety:Public(C_QuestLog and C_QuestLog.GetNumWorldQuestWatches,"number")
                if access=="KNOWN" and (extra<0 or extra%1~=0) then access="UNKNOWN" end
                if self.questCountState=="KNOWN" and access=="KNOWN" then self.questCount=self.questCount+extra
                else
                    self.questCount=nil
                    self.questCountState=(access=="RESTRICTED" or self.questCountState=="RESTRICTED") and "RESTRICTED" or "UNKNOWN"
                end
            end
            self.questCountAt=now;self.questCountWorld=questCfg.worldQuests
        end
        if self.questCountState=="KNOWN" then known("OBJECTIVE_TRACKED",self.questCount>0)
        else M.Store:Publish("OBJECTIVE_TRACKED",self.questCountState,nil,.45) end
    else
        self.questCount,self.questCountAt,self.questCountWorld=nil,nil,nil
        M.Store:Publish("OBJECTIVE_TRACKED","UNSUPPORTED",nil,.45)
    end
    self:ObserveTarget()
    publish("FOCUS_EXISTS",UnitExists,"boolean","focus")
    publish("MOUSEOVER_UNIT_KNOWN",UnitExists,"boolean","mouseover")
    publish("MOUSELOOK_ACTIVE",IsMouselooking,"boolean")
    local raid,rs=M.Safety:Public(IsInRaid,"boolean")
    local group,gs=M.Safety:Public(IsInGroup,"boolean")
    if rs=="KNOWN" and gs=="KNOWN" then known("GROUP_TYPE",raid and "RAID" or group and "PARTY" or "SOLO")
    else M.Store:Publish("GROUP_TYPE","UNKNOWN",nil,.45) end
    local instanceKnown,inside,kind
    if type(IsInInstance)=="function" then
        local ok,a,b=pcall(IsInInstance)
        if ok and M.Safety:Readable(a) and type(a)=="boolean" and M.Safety:Text(b) then instanceKnown,inside,kind=true,a,b end
    end
    if instanceKnown then
        known("IN_DUNGEON",inside and kind=="party");known("IN_RAID_INSTANCE",inside and kind=="raid");known("IN_BATTLEGROUND",inside and (kind=="pvp" or kind=="arena"))
    else
        for _,id in ipairs({"IN_DUNGEON","IN_RAID_INSTANCE","IN_BATTLEGROUND"}) do M.Store:Publish(id,"UNKNOWN",nil,.45) end
    end
    local focus,focusStatus=M.Safety:FocusState(GetCurrentKeyBoardFocus)
    M.Store:Publish("INPUT_FOCUSED",focusStatus,focus,.45)
    local chat,chatStatus=M.Safety:FocusState(ChatEdit_GetActiveWindow)
    M.Store:Publish("CHATTING",chatStatus,chat,.45)
    local active=false;local unknown=focusStatus~="KNOWN" or chatStatus~="KNOWN"
    for id,names in pairs(panels) do
        local value=anyShown(names)
        if value==nil then M.Store:Publish(id,"UNKNOWN",nil,.45);unknown=true
        else known(id,value);if value then active=true end end
    end
    if focus or M.state.edit then active=true end
    if unknown and not active then M.Store:Publish("ACTIVE_TASK","UNKNOWN",nil,.45) else known("ACTIVE_TASK",active) end
    -- ACTIVE_TASK remains diagnostic/legacy observation only. A modal or a
    -- different edit box cannot cancel, extend or broadcast a local chat cue.
    if not cueClock or not self:ChatCueEnabled() then self:ResetChatCue() end
    local recent,untilAt=M.ScopedActivity:AnyChat(now)
    self.chatUntil=untilAt or 0;known("RECENT_CHAT",recent)
    local settingsOpen=(M.Workspace and M.Workspace.frame and M.Workspace.frame:IsShown())
        or (M.Options and M.Options.frame and M.Options.frame:IsShown())
        or (M.PlayerSettings and M.PlayerSettings.frame and M.PlayerSettings.frame:IsShown())
        or (M.Experience and M.Experience.preview and M.Experience.preview:IsShown()) or false
    known("OPTIONS_OPEN",settingsOpen)
    known("EDIT_MODE",M.state.edit==true)
    known("TEMP_REVEAL",now<(M.state.revealUntil or 0))
    known("WORLD_LOAD_OR_TELEPORT",not M.state.world)
    if combat==nil then M.Store:Publish("COMBAT_RECOVERY","UNKNOWN",nil,.45) else known("COMBAT_RECOVERY",not combat and now<self.combatUntil) end
    known("NAVIGATION_HOLD",now<self.motionUntil)
    known("CLIENT_ID_MIDNIGHT",M.Client.family=="Midnight")
    known("CLIENT_ID_FOREVER",M.Client.family=="Forever")
    known("PROFILE_VALID",not M.Profiles.readOnly)
    local shown,status=M.Safety:Public(UIParent.IsShown,"boolean",UIParent)
    if status=="KNOWN" then known("NATIVE_UI_HIDDEN",not shown) else M.Store:Publish("NATIVE_UI_HIDDEN",status,nil,.45) end
    self:ObserveEncounter()
    self:ObserveCasting()
    -- These activities still have no verified public reconciliation contract.
    -- Never refresh an old event Boolean or treat silence/timer expiry as FALSE.
    -- A guessed TTL or probing opaque widget timers would not supply permission.
    for _,id in ipairs({"READY_CHECK_ACTIVE","RESURRECTION_OFFER"}) do
        M.Store:Publish(id,"UNKNOWN",nil,0,"EVENT_ACTIVITY_UNVERIFIED")
    end
    -- These are engine-owned recent-notification holds, not ongoing game state.
    for _,id in ipairs({"QUEST_ACCEPTED","QUEST_OBJECTIVE_CHANGED","LEVEL_GAINED","XP_GAINED","ZONE_CHANGED","SUBZONE_CHANGED"}) do
        known(id,now<(self.pulses[id] or 0))
    end
    if M.PresentationGroups then M.PresentationGroups:Observe(M.Store:Snapshot(),now) end
    -- No health, aura, opponent spell, chat content, camp proximity or identity enters CVE.
end
function G:Reset()
    if M.PresentationGroups then M.PresentationGroups:Reset() end
    if M.AdaptiveFading then M.AdaptiveFading:Reset() end
    self.targetGeneration=(self.targetGeneration or 0)+1;self.targetClock=nil
    self.encounterEpoch=(self.encounterEpoch or 0)+1;self.encounterClock=nil
    self.pulses={};self.tasks={};self:ResetChatCue();self.chatClock=nil;self.motionUntil=0;self.combatUntil=0;self.encounter=nil;self.casting=nil;self.channeling=nil
    self.castGeneration=(self.castGeneration or 0)+1;self.castClock=nil
    self.questCount,self.questCountState,self.questCountAt=nil,nil,nil
    self.hydration=nil
    if M.state.world then self:PrimeWorldBaseline() end
    M.Store:Clear()
    M.ScopedActivity:Reset()
    if M.ContextualNative then M.ContextualNative.selectionUntil=0;M.ContextualNative.threatUntil=0;M.ContextualNative.quietSince=nil end
end
