local _, M = ...
-- CVE v1.3 admission and interaction contracts. Source catalogue entries are NOT
-- executable permissions. There are deliberately no shipped native approvals.
M.Policy={contextEpoch=1,scopeEpoch=0,capabilityEpoch=1,rulesetEpoch=0,ownerSequence=0,sequence=0,
    owners={},leases={},plans={},approvals={},permissions={},graph=nil,limits={rules=491,derived=128,perSurface=24,leases=64,depth=8,nodes=64,fanIn=16}}
local P,S=M.Policy,M.Safety
local styles={HIDDEN=true,AMBIENT=true,VISIBLE=true,EMPHASIZED=true}
local statuses={KNOWN=true,UNKNOWN=true,STALE=true,UNSUPPORTED=true,RESTRICTED=true}
local function copy(v) return M:Copy(v) end
local function size(t) local n=0;for _ in pairs(t) do n=n+1 end;return n end
function P:Register(surface)
    if self.owners[surface.id] then return false,"DUPLICATE_OWNER" end
    self.ownerSequence=self.ownerSequence+1
    surface.ownerEpoch=self.ownerSequence;surface.userRevision=0
    self.owners[surface.id]=surface
    return true
end
function P:Release(surface)
    if self.owners[surface.id]~=surface then return false end
    self:Dismiss(surface);self.owners[surface.id]=nil
    return true
end
function P:Invalidate(reason)
    self.contextEpoch=self.contextEpoch+1
    self.leases={};self.plans={};self.lastReason=reason or "CONTEXT_CHANGED"
    self.nextDeadline=nil
    local graph=rawget(self,"graph")
    if graph then graph.cache={};graph.temporal={};graph.lastTime=nil end
    if self~=M.Policy then return end -- isolated preview policies never touch live presentation
    if M.Store then M.Store:Clear() end
    if M.CVE then M.CVE.holds={};M.CVE.lastRevision=nil;M.CVE.nextDeadline=nil end
    for id,surface in pairs(M.surfaces or {}) do
        if M.Effects then M.Effects.active[id]=nil end
        surface.revision=(surface.revision or 0)+1;surface.desired=nil
        surface.confirmed=false;surface.admittedTicket=nil;surface.effectStatus="UNCONFIRMED"
    end
    if M.state then M.state.forceEvaluate=true end
end
-- Qualification records are internal evidence, never inferred from available APIs.
local function token(v) return S:Text(v) and #v>0 and #v<=128 end
local function record(v,depth,budget)
    depth=depth or 0;budget=budget or {n=0}
    if depth>3 or not S:Readable(v) or type(v)~="table" or getmetatable(v)~=nil then return false end
    if type(canaccesstable)=="function" then local ok,yes=pcall(canaccesstable,v);if not ok or not S:Readable(yes) or yes~=true then return false end end
    for key,value in pairs(v) do
        budget.n=budget.n+1
        if budget.n>128 or not S:Text(key) or not S:Readable(value) then return false end
        if type(value)=="table" then if not record(value,depth+1,budget) then return false end
        elseif type(value)~="boolean" and not S:Number(value) and not (S:Text(value) and #value<=4096) then return false end
    end
    return true
end
local scopeFields={"schema","source","evidenceId","map","instance","restriction"}
local function scopeIdentity(a,b)
    if not record(a) or not record(b) or a.schema~=1 then return false end
    local allowed={schema=true,source=true,evidenceId=true,map=true,instance=true,restriction=true}
    for key in pairs(a) do if not allowed[key] then return false end end
    for _,key in ipairs(scopeFields) do if not S:Readable(a[key]) or a[key]~=b[key] then return false end end
    return true
end
function P:QualificationNow()
    local now,status=S:Public(GetTime,"number")
    if status=="KNOWN" and S:Number(now) then return now end
end
function P:ScopeCurrent(now)
    if now==nil then now=self:QualificationNow() end
    local q=self.scopeEvidence
    return record(q) and S:Number(now) and q.schema==1 and q.status=="KNOWN" and q.nativeResult=="PASS" and
        q.client==M.Client.key and q.capabilityEpoch==self.capabilityEpoch and
        S:Number(q.observedAt) and S:Number(q.expiresAt) and q.observedAt<=now and now<q.expiresAt and
        (not self.scopeLastTime or now>=self.scopeLastTime) and token(q.source) and token(q.evidenceId) and
        token(q.map) and token(q.instance) and token(q.restriction)
end
function P:RetireAuthority(reason,scopeLost)
    local graph=rawget(self,"graph")
    if graph then graph.retired=true;graph.cache={};graph.temporal={};graph.lastTime=nil;self.graph=nil;self.rulesetEpoch=self.rulesetEpoch+1 end
    if scopeLost then self.scopeEvidence=nil;self.scopeLastTime=nil;self.scopeEpoch=self.scopeEpoch+1 end
    self:Invalidate(reason or "AUTHORITY_RETIRED")
end
function P:InvalidateScope(reason)
    self:RetireAuthority(reason or "SCOPE_CHANGED",true)
end
function P:SetScopeEvidence(q)
    if not record(q) then return false end
    local allowed={schema=true,status=true,client=true,capabilityEpoch=true,nativeResult=true,source=true,evidenceId=true,observedAt=true,expiresAt=true,map=true,instance=true,restriction=true}
    for key,value in pairs(q) do if not allowed[key] or not S:Readable(value) or type(value)=="table" then return false end end
    local now=self:QualificationNow();if not now then return false end
    local test=setmetatable({scopeEvidence=q,scopeLastTime=false},{__index=self})
    if not test:ScopeCurrent(now) then return false end
    local identity={};for _,key in ipairs(scopeFields) do identity[key]=q[key] end
    local same=self:ScopeCurrent(now) and scopeIdentity(identity,self.scopeEvidence)
    if not same then self:RetireAuthority("SCOPE_CHANGED",true) end
    self.scopeEvidence=copy(q);self.scopeLastTime=now;return true
end
function P:RefreshScope(now)
    if self~=M.Policy then return self:ScopeCurrent(now) end
    local liveNow=self:QualificationNow()
    now=now or liveNow
    if self.scopeEvidence and (not liveNow or not self:ScopeCurrent(liveNow) or not self:ScopeCurrent(now)) then self:RetireAuthority("SCOPE_EXPIRED",true);return false end
    if self.scopeEvidence then self.scopeLastTime=now end
    return self:ScopeCurrent(now)
end
function P:RevokeCapabilities()
    self.capabilityEpoch=self.capabilityEpoch+1;self.approvals={};self.permissions={}
    self:RetireAuthority("CAPABILITY_REVOKED",true)
end
function P:BeginInteraction(surface,kind,parent)
    if self.owners[surface.id]~=surface or size(self.leases)>=self.limits.leases then return nil,"LEASE_LIMIT_OR_OWNER" end
    if kind~="FOCUS" and kind~="DRAG" and kind~="TASK" and kind~="PRESS" and kind~="GAMEPAD" then return nil,"INVALID_INTERACTION" end
    if parent and (not self.leases[parent] or self.leases[parent].surface~=surface.id or self.leases[parent].contextEpoch~=self.contextEpoch or self.leases[parent].userRevision~=surface.userRevision) then return nil,"PARENT_LEASE_LOST" end
    self.sequence=self.sequence+1;local token=self.sequence
    self.leases[token]={surface=surface.id,ownerEpoch=surface.ownerEpoch,userRevision=surface.userRevision,
        contextEpoch=self.contextEpoch,kind=kind,parent=parent,active=true}
    M.state.forceEvaluate=true
    return token
end
function P:EndInteraction(token,grace)
    local lease=self.leases[token];if not lease then return false end
    -- Ending a nested task does not end its parent. Active children retain the task.
    lease.active=false;lease.expiresAt=S:Now()+math.max(0,math.min(5,grace or 0))
    M.state.forceEvaluate=true;return true
end
function P:HasInteraction(surface,now)
    -- Logical IDs are reusable; a retired object cannot observe its successor.
    if self.owners[surface.id]~=surface then return false end
    local ownerEpoch=surface.ownerEpoch
    now=now or S:Now()
    -- The public clock can reenter registration, including reuse of this object.
    if self.owners[surface.id]~=surface or surface.ownerEpoch~=ownerEpoch then return false end
    local needed,visiting={},{}
    for token,l in pairs(self.leases) do
        local owner=self.owners[l.surface]
        if l.contextEpoch~=self.contextEpoch or not owner or owner.ownerEpoch~=l.ownerEpoch or owner.userRevision~=l.userRevision then self.leases[token]=nil end
    end
    local function keep(token)
        if needed[token]~=nil then return needed[token] end
        local l=self.leases[token];if not l or visiting[token] then return false end
        visiting[token]=true
        local yes=l.active or (l.expiresAt and now<l.expiresAt) or false
        for child,c in pairs(self.leases) do if c.parent==token and keep(child) then yes=true end end
        visiting[token]=nil;needed[token]=yes;return yes
    end
    for token in pairs(self.leases) do keep(token) end
    local active=false
    for token,l in pairs(self.leases) do
        if not needed[token] then self.leases[token]=nil elseif l.surface==surface.id then active=true end
    end
    return active
end
function P:NextLeaseDeadline(surface,now)
    if self.owners[surface.id]~=surface then return nil end
    local nextTime
    for _,lease in pairs(self.leases) do
        if lease.surface==surface.id and lease.ownerEpoch==surface.ownerEpoch and lease.userRevision==surface.userRevision and lease.contextEpoch==self.contextEpoch and not lease.active and lease.expiresAt and lease.expiresAt>now and (not nextTime or lease.expiresAt<nextTime) then nextTime=lease.expiresAt end
    end
    return nextTime
end
function P:Dismiss(surface)
    surface.userRevision=(surface.userRevision or 0)+1
    surface.userOpened=false;surface.interactingUntil=nil
    for token,l in pairs(self.leases) do if l.surface==surface.id then self.leases[token]=nil end end
    self.plans[surface.id]=nil
    if M.Effects then M.Effects.active[surface.id]=nil end
    M.state.forceEvaluate=true
end
-- Observations used by the v1.3 compiler are a separate public-data channel.
-- An explicit internal provider ledger. It is never populated from catalogue
-- prose, user rule text, API presence, or demo data. No approvals ship enabled.
function P:PermissionCurrent(permission,now)
 return record(permission) and self:ScopeCurrent(now) and scopeIdentity(permission.scope,self.scopeEvidence) and token(permission.source) and permission.publicDecision==true and permission.nativeResult=="PASS" and
  permission.client==M.Client.key and permission.capabilityEpoch==self.capabilityEpoch and
  token(permission.evidenceId) and
  (permission.kind=="boolean" or permission.kind=="number" or permission.kind=="string")
end
function P:Observation(signal,status,value,permission,ttl)
    local out={signalId=signal,status=statuses[status] and status or "UNKNOWN",decisionEligible=false,
        contextEpoch=self.contextEpoch,scopeEpoch=self.scopeEpoch,capabilityEpoch=self.capabilityEpoch,observedAt=S:Now(),expiresAt=S:Now()+(S:Number(ttl) and math.max(0,math.min(60,ttl)) or 0)}
    local validPermission=self:PermissionCurrent(permission)
    if not validPermission then out.status="UNSUPPORTED";out.reason="NO_EXACT_CLIENT_PERMISSION";return out end
    out.decisionEligible=true
    if out.status~="KNOWN" then return out end
    if not S:Readable(value) then out.status="RESTRICTED";out.decisionEligible=false;return out end
    if type(value)~=permission.kind or (permission.kind~="boolean" and permission.kind~="number" and permission.kind~="string") then out.status="UNKNOWN";return out end
    if permission.kind=="number" and not S:Number(value) then out.status="UNKNOWN";return out end
    if permission.kind=="string" and (#value>64 or not value:match("^[A-Z][A-Z0-9_]*$")) then out.status="UNKNOWN";return out end
    out.value=value;out.sourceEvidenceId=permission.evidenceId;return out
end
local function collect(ast,out,depth,budget,signals,derived,stack)
    depth=depth or 0;budget=budget or {n=0};out=out or {};stack=stack or {}
    budget.n=budget.n+1
    if type(ast)~="table" or depth>P.limits.depth or budget.n>P.limits.nodes or stack[ast] then return nil,"AST_LIMIT_OR_CYCLE" end
    stack[ast]=true
    local ok,why=true
    if ast.op=="all" or ast.op=="any" then
        if type(ast.args)~="table" or #ast.args<1 or #ast.args>P.limits.fanIn then return nil,"AST_FAN_IN" end
        local count=0;for key in pairs(ast.args) do count=count+1;if not S:Number(key) or key%1~=0 or key<1 or key>#ast.args then return nil,"AST_SEQUENCE" end end
        if count~=#ast.args then return nil,"AST_SEQUENCE" end
        for _,child in ipairs(ast.args) do ok,why=collect(child,out,depth+1,budget,signals,derived,stack);if not ok then return nil,why end end
    elseif ast.op=="not" then ok,why=collect(ast.arg,out,depth+1,budget,signals,derived,stack)
    elseif ast.op=="dwell" or ast.op=="hold" then
        if not S:Number(ast.seconds) or ast.seconds<0 or ast.seconds>30 then return nil,"TEMPORAL_BOUND" end
        ok,why=collect(ast.arg,out,depth+1,budget,signals,derived,stack)
    elseif ast.op=="in" then
        if not signals[ast.signal] and not derived[ast.signal] then return nil,"UNKNOWN_SIGNAL" end
        if type(ast.values)~="table" or #ast.values<1 or #ast.values>16 then return nil,"ENUM_SET_BOUND" end
        local n,seen=0,{}
        for key,value in pairs(ast.values) do
            n=n+1
            if not S:Number(key) or key%1~=0 or key<1 or key>#ast.values or not S:Text(value) or #value>64 or not value:match("^[A-Z][A-Z0-9_]*$") or seen[value] then return nil,"INVALID_ENUM_SET" end
            seen[value]=true
        end
        if n~=#ast.values then return nil,"ENUM_SET_SEQUENCE" end
        out[ast.signal]=true
    elseif ast.op=="eq" or ast.op=="gt" or ast.op=="gte" or ast.op=="lt" or ast.op=="lte" then
        if not signals[ast.signal] and not derived[ast.signal] then return nil,"UNKNOWN_SIGNAL" end
        if type(ast.value)~="boolean" and type(ast.value)~="string" and not S:Number(ast.value) then return nil,"INVALID_LITERAL" end
        if type(ast.value)=="string" and (#ast.value>64 or not ast.value:match("^[A-Z][A-Z0-9_]*$")) then return nil,"INVALID_ENUM" end
        if ast.op~="eq" and not S:Number(ast.value) then return nil,"INVALID_NUMERIC_COMPARISON" end
        out[ast.signal]=true
    else return nil,"UNKNOWN_OPERATOR" end
    local allowed={op=true}
    if ast.op=="all" or ast.op=="any" then allowed.args=true
    elseif ast.op=="not" then allowed.arg=true
    elseif ast.op=="dwell" or ast.op=="hold" then allowed.arg=true;allowed.seconds=true
    elseif ast.op=="in" then allowed.signal=true;allowed.values=true
    else allowed.signal=true;allowed.value=true end
    for key in pairs(ast) do if not allowed[key] then return nil,"UNKNOWN_AST_FIELD" end end
    stack[ast]=nil;return ok and out or nil,why
end
local function encode(ast)
 if ast.op=="all" or ast.op=="any" then local a={};for _,child in ipairs(ast.args) do a[#a+1]=encode(child) end;return ast.op.."("..table.concat(a,",")..")" end
 if ast.op=="not" then return "not("..encode(ast.arg)..")" end
 if ast.op=="dwell" or ast.op=="hold" then return ast.op.."("..tostring(ast.seconds)..","..encode(ast.arg)..")" end
 if ast.op=="in" then return "in("..ast.signal..","..table.concat(ast.values,",")..")" end
 return ast.op.."("..ast.signal..","..type(ast.value)..":"..tostring(ast.value)..")"
end
function P:BindingIdentity(rule,derived)
 local pieces={rule.id,rule.surface,rule.state,tostring(rule.priority),tostring(rule.tieRank),encode(rule.when)}
 local ids={};for id in pairs(derived or {}) do ids[#ids+1]=id end;table.sort(ids)
 for _,id in ipairs(ids) do pieces[#pieces+1]=id.."="..encode(derived[id]) end
 return table.concat(pieces,"|")
end
local approvalFields={"nativeResult","client","registryDigest","sourceDigest","ownerReviewed","surface","ownerEpoch","capabilityEpoch","priority","tieRank","state","effectClass","bindingIdentity"}
local permissionFields={"publicDecision","nativeResult","client","capabilityEpoch","evidenceId","kind","source"}
local function qualificationEqual(a,b,fields)
    if not record(a) or not record(b) or not scopeIdentity(a.scope,b.scope) then return false end
    for _,key in ipairs(fields) do if not S:Readable(a[key]) or a[key]~=b[key] then return false end end
    return true
end
function P:ApprovalCurrent(a,rule,surface,identity,now)
    return surface.Apply==nil and record(a) and self:ScopeCurrent(now) and scopeIdentity(a.scope,self.scopeEvidence) and
        a.nativeResult=="PASS" and a.client==M.Client.key and a.registryDigest==M.Authority.digest and
        a.sourceDigest==rule.sourceDigest and a.ownerReviewed==true and a.surface==rule.surface and
        a.ownerEpoch==surface.ownerEpoch and a.capabilityEpoch==self.capabilityEpoch and
        a.priority==rule.priority and a.tieRank==rule.tieRank and a.state==rule.state and
        a.effectClass==surface.security and a.bindingIdentity==identity
end
function P:GraphAuthorityCurrent(graph,now)
    if now==nil then now=self:QualificationNow() end
    if not graph or graph.preview or graph.retired or self.graph~=graph or graph.epoch~=self.rulesetEpoch or
        graph.scopeEpoch~=self.scopeEpoch or graph.capabilityEpoch~=self.capabilityEpoch or graph.client~=M.Client.key or
        graph.registryDigest~=M.Authority.digest or not self:ScopeCurrent(now) then return false end
    for _,r in ipairs(graph.rules) do
        local owner=self.owners[r.surface]
        if not owner or not self:ApprovalCurrent(self.approvals[r.id],r,owner,r.bindingIdentity,now) or
            not qualificationEqual(self.approvals[r.id],r.approval,approvalFields) then return false end
    end
    for id,pin in pairs(graph.permissions) do
        if not self:PermissionCurrent(self.permissions[id],now) or not qualificationEqual(self.permissions[id],pin,permissionFields) then return false end
    end
    return true
end
function P:RefreshAuthority(now)
    if self~=M.Policy then return false end
    self:RefreshScope(now)
    if self.graph and not self:GraphAuthorityCurrent(self.graph,now) then self:RetireAuthority("QUALIFICATION_CHANGED",false) end
    return self.graph~=nil
end
local function plainData(value,seen,budget,depth)
    if not S:Readable(value) then return false end
    budget.n=budget.n+1
    if budget.n>50000 or depth>24 then return false end
    if type(value)=="table" then
        if seen[value] or getmetatable(value)~=nil then return false end
        if type(canaccesstable)=="function" then
            local ok,allowed=pcall(canaccesstable,value)
            if not ok or not S:Readable(allowed) or allowed~=true then return false end
        end
        seen[value]=true
        for k,v in pairs(value) do
            if not S:Text(k) and not S:Number(k) then return false end
            if not plainData(v,seen,budget,depth+1) then return false end
        end
        seen[value]=nil;return true
    end
    return type(value)=="boolean" or (S:Text(value) and #value<=4096) or S:Number(value)
end
function P:Compile(candidate,preview)
    if not plainData(candidate,{},{n=0},0) then return nil,"INVALID_CANDIDATE_DATA" end
    if type(candidate)~="table" or candidate.registryDigest~=M.Authority.digest or type(candidate.rules)~="table" then return nil,"SOURCE_DIGEST_MISMATCH" end
    if #candidate.rules>self.limits.rules then return nil,"RULE_LIMIT" end
    local rc=0;for k in pairs(candidate.rules) do rc=rc+1;if not S:Number(k) or k%1~=0 or k<1 or k>#candidate.rules then return nil,"RULE_SEQUENCE" end end
    if rc~=#candidate.rules then return nil,"RULE_SEQUENCE" end
    local derived=candidate.derived or {};if type(derived)~="table" or size(derived)>self.limits.derived then return nil,"DERIVED_LIMIT" end
    local signals={};for _,id in ipairs(M.Authority.signals) do signals[id]=true end
    local graph={permissions={},scopeEpoch=self.scopeEpoch,rules={},derived=copy(derived),order={},reverse={},preview=preview==true,capabilityEpoch=self.capabilityEpoch,registryDigest=M.Authority.digest,client=M.Client.key}
    local dependencies={}
    for id,ast in pairs(derived) do
        if type(id)~="string" or not id:match("^DERIVED_[A-Z0-9_]+$") or signals[id] then return nil,"INVALID_DERIVED_ID" end
        local deps,why=collect(ast,{},0,nil,signals,derived);if not deps then return nil,why end;dependencies[id]=deps
    end
    local visiting,done={},{}
    local function visit(id)
        if visiting[id] then return false end
        if done[id] then return true end
        visiting[id]=true
        for dependency in pairs(dependencies[id] or {}) do if derived[dependency] and not visit(dependency) then return false end end
        visiting[id]=nil;done[id]=true;graph.order[#graph.order+1]=id;return true
    end
    local ids={};for id in pairs(derived) do ids[#ids+1]=id end;table.sort(ids)
    for _,id in ipairs(ids) do if not visit(id) then return nil,"DEPENDENCY_CYCLE" end end
    local seen,counts={},{}
    for _,rule in ipairs(candidate.rules) do
        local source=type(rule)=="table" and M.Authority.rules[rule.id]
        if not source or seen[rule.id] or source.digest~=rule.sourceDigest then return nil,"RULE_SOURCE_MISMATCH" end
        seen[rule.id]=true
        if not styles[rule.state] or not S:Number(rule.priority) or rule.priority%1~=0 or rule.priority<0 or rule.priority>3 or not S:Number(rule.tieRank) or rule.tieRank%1~=0 or rule.tieRank<0 or rule.tieRank>1000 then return nil,"UNREVIEWED_PRIORITY_OR_STYLE" end
        local surface=self.owners[rule.surface]
        if not surface or (surface.floor and rule.state=="HIDDEN") then return nil,"SURFACE_FLOOR_OR_OWNER" end
        if not preview and surface.Apply~=nil then return nil,"ADMITTED_CUSTOM_EFFECT_UNSUPPORTED" end
        counts[rule.surface]=(counts[rule.surface] or 0)+1;if counts[rule.surface]>self.limits.perSurface then return nil,"SURFACE_RULE_LIMIT" end
        local deps,why=collect(rule.when,{},0,nil,signals,derived);if not deps then return nil,why end
        local expanded={}
        local function expand(id,out)
            if expanded[id] then return end
            expanded[id]=true
            if derived[id] then for dep in pairs(dependencies[id]) do expand(dep,out) end else out[id]=true end
        end
        local transitive={};for id in pairs(deps) do expand(id,transitive) end
        if not preview then
            local a=self.approvals[rule.id]
            if not self:ApprovalCurrent(a,rule,surface,self:BindingIdentity(rule,derived)) then return nil,"RULE_NOT_APPROVED" end
        end
        if not preview then
            for id in pairs(transitive) do
                if not self:PermissionCurrent(self.permissions[id]) or not S:Text(self.permissions[id].source) or self.permissions[id].source=="" then return nil,"PROVIDER_NOT_APPROVED" end
            end
        end
        if not preview then
            local function typed(ast)
                if ast.op=="all" or ast.op=="any" then for _,child in ipairs(ast.args) do if not typed(child) then return false end end;return true end
                if ast.arg then return typed(ast.arg) end
                local expected=derived[ast.signal] and "boolean" or self.permissions[ast.signal].kind
                return expected==(ast.op=="in" and "string" or type(ast.value))
            end
            if not typed(rule.when) then return nil,"OPERAND_TYPE_MISMATCH" end
            for id in pairs(expanded) do if derived[id] and not typed(derived[id]) then return nil,"DERIVED_TYPE_MISMATCH" end end
        end
        local row=copy(rule);row.bindingIdentity=self:BindingIdentity(rule,derived)
        if not preview then row.approval=copy(self.approvals[rule.id]);for id in pairs(transitive) do graph.permissions[id]=copy(self.permissions[id]) end end
        row.dependencies=transitive;row.derivedDependencies=expanded;row.ownerEpoch=surface.ownerEpoch
        graph.rules[#graph.rules+1]=row
        for id in pairs(transitive) do graph.reverse[id]=graph.reverse[id] or {};graph.reverse[id][#graph.reverse[id]+1]=row.id end
    end
    table.sort(graph.rules,function(a,b) if a.priority~=b.priority then return a.priority<b.priority elseif a.tieRank~=b.tieRank then return a.tieRank>b.tieRank else return a.id<b.id end end)
    return graph
end
function P:Publish(candidate)
    local graph,reason=self:Compile(candidate,false)
    if not graph then self.lastAdmission=reason;return false,reason end
    local previous=rawget(self,"graph");if previous then previous.retired=true;previous.cache={};previous.temporal={};previous.lastTime=nil end
    self.rulesetEpoch=self.rulesetEpoch+1;graph.epoch=self.rulesetEpoch;self.graph=graph
    -- Once a surface enters the admitted path, revocation cannot silently drop it
    -- back onto a less restrictive factory prototype in the same session.
    for _,rule in ipairs(graph.rules) do self.owners[rule.surface].policyV13=true end
    self:Invalidate("RULESET_PUBLISHED");return true
end
local function eval(ast,values,clock,path)
    path=path or "root"
    if ast.op=="dwell" or ast.op=="hold" then
        local child=eval(ast.arg,values,clock,path..".arg")
        local memory=clock.memory[path] or {};clock.memory[path]=memory
        if child=="INDETERMINATE" then clock.memory[path]=nil;return child end
        if ast.op=="dwell" then
            if child=="FALSE" then memory.start=nil;return "FALSE" end
            memory.start=memory.start or clock.now
            local due=memory.start+ast.seconds
            if clock.now<due then clock.next=math.min(clock.next or due,due);return "FALSE" end
            return "TRUE"
        end
        if child=="TRUE" then memory.truth=true;memory.untilTime=nil;return "TRUE" end
        if memory.truth then memory.untilTime=clock.now+ast.seconds end
        memory.truth=false
        if memory.untilTime and clock.now<memory.untilTime then clock.next=math.min(clock.next or memory.untilTime,memory.untilTime);return "TRUE" end
        return "FALSE"
    end
    if ast.op=="not" then local v=eval(ast.arg,values,clock,path..".not");return v=="TRUE" and "FALSE" or v=="FALSE" and "TRUE" or v end
    if ast.op=="all" or ast.op=="any" then
        local unknown,decisive=false,false
        for i,a in ipairs(ast.args) do
            local v=eval(a,values,clock,path.."."..i);if v=="INDETERMINATE" then unknown=true end
            if ast.op=="all" and v=="FALSE" or ast.op=="any" and v=="TRUE" then decisive=true end
        end
        if decisive then return ast.op=="all" and "FALSE" or "TRUE" end
        return unknown and "INDETERMINATE" or ast.op=="all" and "TRUE" or "FALSE"
    end
    local row=values[ast.signal];if not row or row.status~="KNOWN" then return "INDETERMINATE" end
    local v=row.value
    if ast.op=="in" then if not S:Text(v) then return "INDETERMINATE" end;for _,value in ipairs(ast.values) do if value==v then return "TRUE" end end;return "FALSE" end
    if ast.op=="eq" then if type(v)~=type(ast.value) then return "INDETERMINATE" end;return v==ast.value and "TRUE" or "FALSE" end
    if not S:Number(v) then return "INDETERMINATE" end
    local yes=ast.op=="gt" and v>ast.value or ast.op=="gte" and v>=ast.value or ast.op=="lt" and v<ast.value or ast.op=="lte" and v<=ast.value
    return yes and "TRUE" or "FALSE"
end
function P:Evaluate(graph,observations,now)
    if graph and not graph.preview then self:RefreshAuthority(now);if not self:GraphAuthorityCurrent(graph,now) then return {},"AUTHORITY_RETIRED" end end
    if not graph or graph.client~=M.Client.key or graph.capabilityEpoch~=self.capabilityEpoch or (not graph.preview and graph.epoch~=self.rulesetEpoch) then return {},"CAPABILITY_EPOCH_CHANGED" end
    now=S:Number(now) and now or S:Now();local results={}
    local evaluatedContext,evaluatedScope,evaluatedCapability,evaluatedRuleset=self.contextEpoch,self.scopeEpoch,self.capabilityEpoch,self.rulesetEpoch
    if graph.contextEpoch~=self.contextEpoch or (graph.lastTime and now<graph.lastTime) then graph.cache={};graph.temporal={};graph.contextEpoch=self.contextEpoch end
    graph.lastTime=now;graph.cache=graph.cache or {};graph.temporal=graph.temporal or {};graph.predicateRuns=graph.predicateRuns or 0
    for _,rule in ipairs(graph.rules) do
        local owner=self.owners[rule.surface];local approval=self.approvals[rule.id]
        local blocked=not owner or owner.ownerEpoch~=rule.ownerEpoch
        if not graph.preview and not blocked then
            blocked=not self:ApprovalCurrent(approval,rule,owner,rule.bindingIdentity,now)
        end
        local values,signature={},{};local expiry
        -- Full transitive permission admission precedes every operand read.
        for id in pairs(rule.dependencies) do
            local row=S:Field(observations,id)
            local eligible=S:Field(row,"decisionEligible");local status=S:Field(row,"status")
            if eligible~=true or not statuses[status] or status=="RESTRICTED" or S:Field(row,"contextEpoch")~=self.contextEpoch or S:Field(row,"capabilityEpoch")~=self.capabilityEpoch or (not graph.preview and S:Field(row,"scopeEpoch")~=self.scopeEpoch) then blocked=true;break end
            if not graph.preview and (not self:PermissionCurrent(self.permissions[id],now) or S:Field(row,"sourceEvidenceId")~=self.permissions[id].evidenceId) then blocked=true;break end
        end
        if not blocked then
            local ids={};for id in pairs(rule.dependencies) do ids[#ids+1]=id end;table.sort(ids)
            for _,id in ipairs(ids) do
                local row=observations[id];local due=S:Field(row,"expiresAt");local status=S:Field(row,"status");local value
                if not S:Number(due) then blocked=true;break end
                if due<=now then status="STALE" elseif not expiry or due<expiry then expiry=due end
                if status=="KNOWN" then
                    value=S:Field(row,"value")
                    if type(value)~="boolean" and not S:Number(value) and not (S:Text(value) and #value<=64 and value:match("^[A-Z][A-Z0-9_]*$")) then blocked=true;break end
                    if not graph.preview and type(value)~=self.permissions[id].kind then blocked=true;break end
                end
                values[id]={status=status,value=value}
                signature[#signature+1]=id..":"..status..":"..type(value)..":"..tostring(value)
            end
        end
        if blocked then results[rule.id]="BLOCKED";graph.cache[rule.id]=nil;graph.temporal[rule.id]=nil
        else
            local key=table.concat(signature,"|");local previous=graph.cache[rule.id]
            if previous and previous.key==key and (not previous.temporalDue or now<previous.temporalDue) then
                results[rule.id]=previous.result
                previous.due=previous.temporalDue
                if expiry and (not previous.due or expiry<previous.due) then previous.due=expiry end
            else
                local clock={now=now,memory=graph.temporal[rule.id] or {}};graph.temporal[rule.id]=clock.memory
                for _,id in ipairs(graph.order) do
                    if rule.derivedDependencies[id] then
                        local v=eval(graph.derived[id],values,clock,"derived."..id)
                        values[id]={status=v=="INDETERMINATE" and "UNKNOWN" or "KNOWN",value=v=="TRUE"}
                    end
                end
                results[rule.id]=eval(rule.when,values,clock,"rule."..rule.id);graph.predicateRuns=graph.predicateRuns+1
                local due=clock.next;if expiry and (not due or expiry<due) then due=expiry end
                graph.cache[rule.id]={key=key,result=results[rule.id],due=due,temporalDue=clock.next}
            end
        end
    end
    if evaluatedContext~=self.contextEpoch or evaluatedScope~=self.scopeEpoch or evaluatedCapability~=self.capabilityEpoch or evaluatedRuleset~=self.rulesetEpoch then
        graph.cache={};graph.temporal={};return {},"EVALUATION_GENERATION_CHANGED"
    end
    if not graph.preview then
        self.nextDeadline=nil
        for _,row in pairs(graph.cache) do if row.due and row.due>now and (not self.nextDeadline or row.due<self.nextDeadline) then self.nextDeadline=row.due end end
    end
    if not graph.preview and not self:GraphAuthorityCurrent(graph,now) then self:RefreshAuthority(now);return {},"AUTHORITY_RETIRED" end
    return results,graph.preview and "PREVIEW_ONLY" or "ADMITTED_GRAPH"
end
function P:RuntimeIntents(snapshot,now)
    now=now or S:Now();self:RefreshAuthority(now)
    local intents,controlled={},{}
    for id,surface in pairs(self.owners) do if surface.policyV13 then controlled[id]=true end end
    local graph=self.graph
    if not graph or graph.preview then return intents,controlled end
    local observations={}
    for id in pairs(graph.reverse) do
        local row=snapshot[id]
        local permission=self.permissions[id]
        local sourceOK=record(row) and row.contextEpoch==self.contextEpoch and row.scopeEpoch==self.scopeEpoch and row.capabilityEpoch==self.capabilityEpoch and self:PermissionCurrent(permission) and
            S:Text(permission.source) and row.source==permission.source and row.client==M.Client.key
        if sourceOK then
            observations[id]=self:Observation(id,row.status,row.value,permission,0)
            observations[id].expiresAt=row.expiresAt or now
        else observations[id]=self:Observation(id,"UNSUPPORTED",nil,nil,0) end
    end
    local results=self:Evaluate(graph,observations,now)
    for _,rule in ipairs(graph.rules) do
        if results[rule.id]=="TRUE" then
            local list=intents[rule.surface] or {};intents[rule.surface]=list
            local versions={};for id in pairs(rule.dependencies) do versions[id]=snapshot[id].version end
            local ticket={graph=graph,rule=rule.id,surface=rule.surface,ownerEpoch=rule.ownerEpoch,contextEpoch=self.contextEpoch,scopeEpoch=self.scopeEpoch,capabilityEpoch=self.capabilityEpoch,rulesetEpoch=self.rulesetEpoch,versions=versions,expiresAt=graph.cache[rule.id].due}
            list[#list+1]={id=rule.id,state=rule.state,priority=rule.priority,tieRank=rule.tieRank,eligible=true,ticket=ticket}
        end
    end
    return intents,controlled
end
function P:TicketCurrent(surface,ticket,now)
    if not ticket then return true end
    local liveNow=self:QualificationNow();if not liveNow or not self:ScopeCurrent(liveNow) then return false end
    now=now or liveNow
    if liveNow>now then now=liveNow end
    if not self:GraphAuthorityCurrent(ticket.graph,now) or ticket.surface~=surface.id or ticket.ownerEpoch~=surface.ownerEpoch or
        ticket.contextEpoch~=self.contextEpoch or ticket.scopeEpoch~=self.scopeEpoch or ticket.capabilityEpoch~=self.capabilityEpoch or
        ticket.rulesetEpoch~=self.rulesetEpoch or not S:Number(ticket.expiresAt) or now>=ticket.expiresAt then return false end
    for id,version in pairs(ticket.versions) do
        local row=M.Store.values[id]
        if not row or row.version~=version or row.status~="KNOWN" or not S:Number(row.expires) or now>=row.expires then return false end
    end
    return true
end
function P:CancelTicket(surface)
    if M.Effects then M.Effects.active[surface.id]=nil end
    surface.revision=(surface.revision or 0)+1;surface.desired=nil;surface.confirmed=false;surface.admittedTicket=nil
    surface.effectStatus="DENIED";surface.appliedReason="STALE_EFFECT";M.state.forceEvaluate=true
end
function P:Resolve(graph,results,surface,fallback)
    if surface.floor then return "VISIBLE","PROTECTED_FLOOR" end
    if self:HasInteraction(surface) then return "VISIBLE","INTERACTION_LEASE" end
    local winner
    for _,r in ipairs(graph.rules) do
        if r.surface==surface.id and results[r.id]=="TRUE" then
            if not winner then winner=r
            elseif r.priority==winner.priority and r.tieRank==winner.tieRank and r.state~=winner.state then return fallback or "VISIBLE","UNRESOLVED_TIE" end
        end
    end
    return winner and winner.state or fallback or "VISIBLE",winner and winner.id or "SAFE_FALLBACK"
end
function P:Stamp(surface)
    local parent=S:Public(surface.frame and surface.frame.GetParent,nil,surface.frame)
    return {scopeEpoch=self.scopeEpoch,contextEpoch=self.contextEpoch,capabilityEpoch=self.capabilityEpoch,rulesetEpoch=self.rulesetEpoch,
        ownerEpoch=surface.ownerEpoch,userRevision=surface.userRevision,parent=parent,revision=surface.revision,
        scope=M.EffectScope and M.EffectScope:Capture(surface.frame)}
end
function P:StampGenerationCurrent(surface,stamp)
    return stamp and self.owners[surface.id]==surface and surface.ownerEpoch==stamp.ownerEpoch and surface.userRevision==stamp.userRevision and
        stamp.scopeEpoch==self.scopeEpoch and stamp.contextEpoch==self.contextEpoch and stamp.capabilityEpoch==self.capabilityEpoch and
        stamp.rulesetEpoch==self.rulesetEpoch and stamp.revision==surface.revision
end
function P:Current(surface,stamp)
    if not self:StampGenerationCurrent(surface,stamp) then return false end
    local parent,access=S:Public(surface.frame and surface.frame.GetParent,nil,surface.frame)
    local topology=access=="KNOWN" and parent==stamp.parent and (not M.EffectScope or M.EffectScope:Matches(surface.frame,stamp.scope))
    return topology and self:StampGenerationCurrent(surface,stamp)
end
function P:Acknowledge(surface,alpha,state)
    -- Only owned public tree geometry-free visibility reads may confirm presentation.
    if surface.native or not S:Frame(surface.frame,true) then surface.effectStatus="UNCONFIRMED";surface.confirmed=false;surface.actual="UNCONFIRMED";return false end
    local actual,ar=S:Public(surface.frame.GetAlpha,"number",surface.frame)
    local shown,sr=S:Public(surface.frame.IsVisible,"boolean",surface.frame)
    if ar~="KNOWN" or sr~="KNOWN" or math.abs(actual-alpha)>.001 or shown~=(alpha>0) then surface.effectStatus="UNCONFIRMED";surface.confirmed=false;surface.actual="UNCONFIRMED";return false end
    surface.effectStatus="APPLIED_CONFIRMED";surface.confirmed=true;surface.actual=state;return true
end

-- Observe only events already delivered to an eligible surface. Never enable
-- mouse/keyboard capture, install an overlay, or hook a protected frame in combat.
function P:AttachInteraction(surface)
    local frame=surface.frame
    if surface.interactionHooks or M.Safety:InCombat() or not S:Frame(frame,true) or type(frame.HookScript)~="function" then return false end
    if surface.security~="OWNED_VISUAL" and surface.security~="OWNED_PASSIVE_VISUAL" and surface.security~="NATIVE_PUBLIC" then return false end
    if surface.native and not S:ChildTreePublic(frame) then return false end
    -- Passive overlays (especially MirageUICursor) must not gain mouse scripts.
    -- Observe interactions only on a surface that already accepts native mouse input.
    if S:Public(frame.IsMouseEnabled,"boolean",frame)~=true then return false end
    surface.interactionHooks={}
    local function active()
        local enabled=M:IsModuleActive(surface.module)
        if surface.reworkProvider then enabled=M.Rework and M.Rework.SurfaceActive and M.Rework:SurfaceActive(surface) end
        return self.owners[surface.id]==surface and enabled and not M.state.safe and not surface.disabled
    end
    local function begin(kind)
        if not active() then return end
        if kind=="FOCUS" and M.CVE and not M.CVE:InputVisible(surface) then return end
        local token=surface.interactionHooks[kind]
        if not token or not self.leases[token] then surface.interactionHooks[kind]=self:BeginInteraction(surface,kind) end
    end
    local function finish(kind)
        local token=surface.interactionHooks[kind]
        if token then self:EndInteraction(token,.4);surface.interactionHooks[kind]=nil end
    end
    local hooks={OnEnter=function() begin("FOCUS") end,OnLeave=function() finish("FOCUS") end,
        OnMouseDown=function() begin("PRESS") end,OnMouseUp=function() finish("PRESS") end,
        OnDragStart=function() begin("DRAG") end,OnDragStop=function() finish("DRAG") end,
        OnHide=function() finish("FOCUS");finish("PRESS");finish("DRAG") end}
    for event,fn in pairs(hooks) do
        local supported=true
        if type(frame.HasScript)=="function" then local ok,v=pcall(frame.HasScript,frame,event);supported=ok and S:Readable(v) and v==true end
        if supported then pcall(frame.HookScript,frame,event,fn) end
    end
    return true
end
