local _, M = ...
M.Predicate={}
local P=M.Predicate
local kinds={eq=true,gt=true,gte=true,lt=true,lte=true,all=true,any=true,["not"]=true}
function P:Validate(ast,depth,count)
    depth,count=depth or 0,count or {n=0}
    count.n=count.n+1
    if depth>8 or count.n>64 or type(ast)~="table" or not kinds[ast.op] then return false end
    for key in pairs(ast) do if key~="op" and key~="args" and key~="arg" and key~="signal" and key~="value" then return false end end
    if ast.op=="all" or ast.op=="any" then
        if type(ast.args)~="table" or #ast.args<1 or #ast.args>16 then return false end
        for _,child in ipairs(ast.args) do if not self:Validate(child,depth+1,count) then return false end end
        return true
    elseif ast.op=="not" then return self:Validate(ast.arg,depth+1,count) end
    if not M.SignalIndex[ast.signal] then return false end
    if ast.op=="eq" then return type(ast.value)=="boolean" or (type(ast.value)=="string" and #ast.value<=64) or M.Safety:Number(ast.value) end
    return M.Safety:Number(ast.value)
end
function P:Signals(ast,out)
    out=out or {}
    if ast.signal then out[ast.signal]=true end
    for _,child in ipairs(ast.args or {}) do self:Signals(child,out) end
    if ast.arg then self:Signals(ast.arg,out) end
    return out
end
local function evaluate(ast,snapshot)
    if ast.op=="not" then local v=evaluate(ast.arg,snapshot);return v=="TRUE" and "FALSE" or v=="FALSE" and "TRUE" or v end
    if ast.op=="all" or ast.op=="any" then
        local unknown=false;local decisive=false
        for _,child in ipairs(ast.args) do
            local result=evaluate(child,snapshot)
            if result=="BLOCKED" then return "BLOCKED" end
            if result=="INDETERMINATE" then unknown=true end
            if (ast.op=="all" and result=="FALSE") or (ast.op=="any" and result=="TRUE") then decisive=true end
        end
        if decisive then return ast.op=="all" and "FALSE" or "TRUE" end
        if unknown then return "INDETERMINATE" end
        return ast.op=="all" and "TRUE" or "FALSE"
    end
    local row=snapshot[ast.signal]
    if not row or row.status~="KNOWN" or not row.decisionEligible then return "INDETERMINATE" end
    local value=row.value
    local result
    if ast.op=="eq" then result=value==ast.value
    elseif not M.Safety:Number(value) then return "INDETERMINATE"
    elseif ast.op=="gt" then result=value>ast.value
    elseif ast.op=="gte" then result=value>=ast.value
    elseif ast.op=="lt" then result=value<ast.value
    elseif ast.op=="lte" then result=value<=ast.value end
    return result and "TRUE" or "FALSE"
end
function P:Evaluate(ast,snapshot)
    if not self:Validate(ast) then return "BLOCKED" end
    -- Preflight every operand before evaluation: no short circuit can launder a secret.
    for id in pairs(self:Signals(ast)) do
        local row=snapshot[id]
        if row and (row.status=="RESTRICTED" or (row.status=="KNOWN" and not M.Safety:Readable(row.value))) then return "BLOCKED" end
    end
    return evaluate(ast,snapshot)
end

function P:Compile(ast)
    if not self:Validate(ast) then return nil end
    local copy=M:Copy(ast)
    return {ast=copy,signals=self:Signals(copy)}
end
function P:EvaluateCompiled(compiled,snapshot)
    if not compiled then return "BLOCKED" end
    -- Signal rows carry an immutable version whenever their decision value or
    -- custody changes. Reuse the previous verdict while every dependency keeps
    -- the same version; this avoids repeatedly walking the AST during sampled
    -- observations that only renew freshness.
    local versions=compiled._versions or {};local unchanged=compiled._verdict~=nil
    for id in pairs(compiled.signals) do
        local row=snapshot[id];local version=row and row.version or -1
        if versions[id]~=version then unchanged=false end
        versions[id]=version
        if row and (row.status=="RESTRICTED" or (row.status=="KNOWN" and not M.Safety:Readable(row.value))) then
            compiled._versions=versions;compiled._verdict="BLOCKED";return "BLOCKED"
        end
    end
    compiled._versions=versions
    if unchanged then
        if M.stats then M.stats.predicateCacheHits=(M.stats.predicateCacheHits or 0)+1 end
        return compiled._verdict
    end
    local verdict=evaluate(compiled.ast,snapshot);compiled._verdict=verdict
    if M.stats then M.stats.predicateEvaluations=(M.stats.predicateEvaluations or 0)+1 end
    return verdict
end

-- Data-only profile grammar. This is never passed to Lua's evaluator or a secure snippet.
function P:Encode(ast)
    if not self:Validate(ast) then return nil end
    if ast.op=="all" or ast.op=="any" then
        local out={};for _,child in ipairs(ast.args) do local v=self:Encode(child);if not v then return nil end;out[#out+1]=v end
        return ast.op.."("..table.concat(out,",")..")"
    elseif ast.op=="not" then local v=self:Encode(ast.arg);return v and "not("..v..")" end
    local value
    if type(ast.value)=="boolean" then value=ast.value and "true" or "false"
    elseif type(ast.value)=="number" and M.Safety:Number(ast.value) then value=tostring(ast.value)
    elseif type(ast.value)=="string" and ast.value:match("^[A-Z][A-Z0-9_]*$") then value=ast.value
    else return nil end
    return ast.op.."("..ast.signal..","..value..")"
end
function P:Decode(text)
    if type(text)~="string" or #text>4096 or text:find("[^%w_%.%+%-%(%)%,]") then return nil end
    local at,nodes=1,0
    local function token()
        local start,finish=text:find("[%w_%.%+%-]+",at)
        if start~=at then return nil end
        at=finish+1;return text:sub(start,finish)
    end
    local function take(char)
        if text:sub(at,at)~=char then return false end;at=at+1;return true
    end
    local parse
    parse=function(depth)
        nodes=nodes+1;if depth>8 or nodes>64 then return nil end
        local op=token();if not op or not kinds[op] or not take("(") then return nil end
        local ast={op=op}
        if op=="all" or op=="any" then
            ast.args={}
            repeat
                if #ast.args>=16 then return nil end
                local child=parse(depth+1);if not child then return nil end
                ast.args[#ast.args+1]=child
                if text:sub(at,at)~="," then break end;at=at+1
            until false
        elseif op=="not" then ast.arg=parse(depth+1);if not ast.arg then return nil end
        else
            ast.signal=token();if not ast.signal or not take(",") then return nil end
            local raw=token();if not raw then return nil end
            if raw=="true" then ast.value=true elseif raw=="false" then ast.value=false
            elseif raw:match("^[A-Z][A-Z0-9_]*$") then ast.value=raw
            else ast.value=tonumber(raw);if not M.Safety:Number(ast.value) then return nil end end
        end
        if not take(")") then return nil end
        return ast
    end
    local ok,ast=pcall(parse,0)
    if not ok or not ast or at~=#text+1 or not self:Validate(ast) then return nil end
    return ast
end
M.UserSignalLabels={PLAYER_MOVING="moving",PLAYER_IN_COMBAT="in combat",TARGET_EXISTS="a target selected",MAP_OPEN="the world map open",CHATTING="typing in chat",BAGS_OPEN="bags open",IN_DUNGEON="inside a dungeon",GROUP_TYPE="group type",PLAYER_MOUNTED="mounted",PLAYER_HAS_PET="a pet present"}
function P:UserAllowed(ast)
    if not self:Validate(ast) then return false end
    for id in pairs(self:Signals(ast)) do if not M.UserSignalLabels[id] then return false end end
    return true
end
function P:Describe(ast)
    if not self:Validate(ast) then return "Invalid rule" end
    if ast.op=="all" or ast.op=="any" then
        local parts={};for _,child in ipairs(ast.args) do parts[#parts+1]=self:Describe(child) end
        return "("..table.concat(parts,ast.op=="all" and " and " or " or ")..")"
    elseif ast.op=="not" then return "not "..self:Describe(ast.arg) end
    local name=M.UserSignalLabels[ast.signal] or ast.signal
    if type(ast.value)=="boolean" then return (ast.value and "" or "not ")..name end
    local symbols={eq=" = ",gt=" > ",gte=" >= ",lt=" < ",lte=" <= "}
    return name..(symbols[ast.op] or " ")..tostring(ast.value)
end
