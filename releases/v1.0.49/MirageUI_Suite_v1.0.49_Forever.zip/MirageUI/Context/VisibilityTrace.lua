local _,M=...
-- Runtime-only reason history. It contains finite state labels and epochs only;
-- never unit data, native arguments, names, bindings or GUIDs. The timestamp
-- is the public monotonic capture clock, not a gameplay duration.
M.VisibilityTrace={capacity=24,maxSurfaces=192,rows={},count=0,sequence=0}
local T=M.VisibilityTrace
local function code(value,fallback)
 return type(value)=='string' and #value<=96 and value:match('^[A-Za-z0-9_.%-_]+$') and value or fallback
end
function T:Record(s)
 if not s or not M.CatalogByID[s.module] then return end
 local id=code(s.id);if not id then return end
 local requested,actual,effect=code(s.desired,'UNKNOWN'),code(s.actual,'UNKNOWN'),code(s.effectStatus,'UNCONFIRMED')
 local reason,rule=code(s.appliedReason or s.reason,'UNKNOWN'),code(s.reason,'UNKNOWN')
 local context,ruleset,owner=M.Policy.contextEpoch,M.Policy.rulesetEpoch,s.ownerEpoch or 0
 local row=self.rows[id]
 if row and row.requested==requested and row.actual==actual and row.effect==effect and row.reason==reason
     and row.rule==rule and row.context==context and row.ruleset==ruleset and row.owner==owner then return end
 if not row then
  if self.count>=self.maxSurfaces then return end
  row={entries={}};self.rows[id]=row;self.count=self.count+1
 end
 local entry={requested=requested,actual=actual,effect=effect,reason=reason,rule=rule,context=context,ruleset=ruleset,owner=owner,
     timestamp=M.Safety:Now(),settingsGeneration=M.state.settingsGeneration or 0}
 self.sequence=self.sequence+1;entry.sequence=self.sequence
 row.requested=requested;row.actual=actual;row.effect=effect;row.reason=reason;row.rule=rule
 row.context=context;row.ruleset=ruleset;row.owner=owner;row.entries[#row.entries+1]=entry
 if #row.entries>self.capacity then table.remove(row.entries,1) end
end
function T:History(id)
 local out={};local row=self.rows[id]
 for _,e in ipairs(row and row.entries or {}) do out[#out+1]=M:Copy(e) end
 return out
end
function T:Export()
 local records={}
 for id,row in pairs(self.rows) do
  for _,entry in ipairs(row.entries) do records[#records+1]={id=id,entry=entry} end
 end
 table.sort(records,function(a,b) return a.entry.sequence<b.entry.sequence end)
 local lines={"visibility_history_schema=2","visibility_clock=SESSION_MONOTONIC_SECONDS",
  "visibility_history_omitted="..math.max(0,#records-128),"visibility_history_payloads=STATE_AND_OWNER_CODES_ONLY"}
 for i=math.max(1,#records-127),#records do
  local row=records[i];local e=row.entry
  lines[#lines+1]="visibility_event="..table.concat({e.sequence,string.format("%.3f",e.timestamp),row.id,e.requested,e.actual,
   e.effect,e.rule,e.reason,e.context,e.ruleset,e.owner,e.settingsGeneration},"/")
 end
 return table.concat(lines,"\n")
end
local descriptions={
 USER_PIN='You pinned this display on.',USER_MANUAL='You chose manual-only visibility.',
 INTERACTION_LEASE='An active click, text field, drag or nested task is keeping it available.',
 ['GOV-006']='You opened this display.', ['GOV-009']='Temporary reveal is active.',
 ['GOV-011']='Layout editing is active.', ['GOV-020']='An interaction is still active or within its reading hold.',
 ['PRS-001']='The idle delay completed without another eligible demand.',
 ['PRS-002']='Player movement requested navigation.', ['PRS-003']='Navigation is held briefly after movement.',
 ['CBT-001']='Combat requested essential information.', ['CBT-003']='Combat ended recently; the recovery hold is active.',
 ['CBT-006']='A player cast requested this display.', ['CBT-007']='A player channel requested this display.',
 ['TGT-001']='A selected target requested this display.', ['TGT-008']='A focus target requested this display.',
 ['GRP-001']='Party context requested this display.', ['GRP-003']='Raid context requested this display.',
 HUD_ALWAYS='The HUD is set to Always.',HUD_ACTIVITY='The HUD is relevant to combat or current casting.',
 HUD_QUIET='The selected HUD visibility mode is quiet now.',HUD_INCOMPATIBLE_UI='The HUD yields during vehicle, pet-battle or world-transition handling.',
 HUD_COMBAT_UNKNOWN='Combat state is uncertain; information is retained.',HUD_ACTIVITY_UNKNOWN='Cast activity is uncertain; the safe display is retained.',
 DUPLICATE_OPTIONAL_PRESENTATION='A chosen primary display owns these facts; this optional mirror is suppressed.',
 MODULE_STOPPED='This module is off, suspended, outside its permitted context, or in SAFE mode.',
 NATIVE_RESTORE='Native presentation is being retained or restored.',NATIVE_ACCESS_FLOOR='Essential native or secure access has priority.',
 SECURE_DRIVER_OWNS_VISIBILITY='The game secure driver controls visibility; ordinary Lua did not prove its visible result.',
 NATIVE_OWNS_PRESENTATION='Blizzard owns this presentation.',NATIVE_COMBAT_FLOOR='Native information is retained during combat.',
 NATIVE_OPACITY_ONLY='Only the permitted native opacity was adjusted; native controls remain.',
 OTHER_UI_OWNER='A competing interface owner takes precedence.',PROTECTED_OR_FORBIDDEN='The surface is protected or inaccessible; the attempted cosmetic change was refused.',
 NATIVE_CHILD_PROTECTED='A native child is protected; native presentation is retained.',STALE_EFFECT='A newer context, owner or layout invalidated this request.',
 NO_ELIGIBLE_RULE='No eligible rule won. The surface uses its declared safe fallback.',UNRESOLVED_TIE='Conflicting equal-priority requests use the safe fallback.',
}
function T:Explain(s)
 local reason=s.reason or 'UNKNOWN';local applied=s.appliedReason or reason
 local line=descriptions[reason] or 'This display follows its module policy or an explicitly configured rule.'
 if applied~=reason and descriptions[applied] then line=line..' '..descriptions[applied] end
 if s.effectStatus=='APPLIED_CONFIRMED' then line=line..' Its permitted local state check confirmed the effect; this is not native release acceptance.'
 elseif s.effectStatus=='SUBMITTED' then line=line..' The request was submitted; visible success has not been independently confirmed.'
 elseif s.effectStatus=='DENIED' then line=line..' The requested effect was denied; do not assume the requested state occurred.'
 else line=line..' The visible result remains unconfirmed.' end
 return line
end
-- Instrument existing effect paths without another polling loop or actuation.
local apply=M.Effects.Apply
function M.Effects:Apply(s,...) apply(self,s,...);T:Record(s) end
local tick=M.Effects.Tick
function M.Effects:Tick(now)
 if next(self.active)==nil then return tick(self,now) end
 T.pending=T.pending or {};local pending=T.pending;local count=0
 for _,tr in pairs(self.active) do count=count+1;pending[count]=tr.surface end
 tick(self,now)
 for i=1,count do T:Record(pending[i]);pending[i]=nil end
end
local stop=M.Effects.Stop
function M.Effects:Stop(s,...) stop(self,s,...);T:Record(s) end
