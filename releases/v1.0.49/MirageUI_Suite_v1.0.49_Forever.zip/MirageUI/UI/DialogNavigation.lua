local _,M=...
local U,S=M.UI,M.Safety
-- Explicit owned descriptors only; no control discovery or private text probes.
-- Attempts, active navigation sessions, and shown panel lifetimes are distinct.
-- Callback operations carry explicit receipts; no ambient owner wraps user code.
local D={panels={},pressed={},shown={},_lives={},_tickets={},_revision={},_admission={}}
M.DialogNavigation=D
local helperKeys={'Allowed','Entries','Stop','Cleanup','Highlight','Refresh','HideCleanupAllowed','CurrentShown','Shown','Hidden','Start','PanelShown','OwnedShow','OwnedWrite','OwnedWriteGuarded','DrainCleanup','Restore','ChoiceOpened','Move','Activate','Adjust','FieldTab','Back','Key','SuspendDialogs'}
local safetyKeys={'Readable','InCombat','Typing','Passive'}
local outlineKeys={'Hide','Show','SetParent','ClearAllPoints','SetPoint','SetBackdrop','SetBackdropBorderColor'}
local panelKeys={'EnableGamePadButton','SetPropagateKeyboardInput','Hide','Show'}
local function bindings(object,keys)
 local ok,result=pcall(function() local values={};for _,key in ipairs(keys) do values[key]=object[key] end;return values end)
 return ok and result or nil
end
local function observe(panel,mandatory)
 local r={mandatory=mandatory,revision=D._revision,admission=D._admission,panel=panel,spec=panel and D.panels[panel],life=panel and D._lives[panel],outline=D.outline}
 r.bindings=bindings(D,helperKeys);r.safetyBindings=bindings(S,safetyKeys)
 r.panelBindings=panel and bindings(panel,panelKeys)
 r.outlineBindings=r.outline and bindings(r.outline,outlineKeys)
 return r
end
local function match(object,values,keys)
 if not values then return false end
 for _,key in ipairs(keys) do if object[key]~=values[key] then return false end end
 return true
end
local function current(r,retirement)
 if not r then return false end
 local ok,value=pcall(function()
  return M.DialogNavigation==D and M.UI==U and M.Safety==S and (D._revision==r.revision or (retirement and (D._admission==r.admission or retirement=="refresh"))) and
   match(D,r.bindings,helperKeys) and match(S,r.safetyBindings,safetyKeys) and
   (not r.panel or (D.panels[r.panel]==r.spec and D._lives[r.panel]==r.life and (r.mandatory or match(r.panel,r.panelBindings,panelKeys)))) and
   (r.mandatory or (D.outline==r.outline and (not r.outline or match(r.outline,r.outlineBindings,outlineKeys)))) and (D._revision==r.revision or (retirement and (D._admission==r.admission or retirement=="refresh")))
 end)
 return ok and value==true
end
local function begin(panel,mandatory)
 if (D._writing or D._suspending) and not mandatory then return nil end
 D._revision={};if not mandatory then D._admission={} end;return observe(panel,mandatory)
end
local function invoke(r,fn,...)
 if not current(r) or type(fn)~='function' then return false end
 local ok,value=pcall(fn,...)
 return ok and current(r),value
end
local function method(r,target,key,...)
 if not current(r) then return false end
 local bound,fn=pcall(function() return target[key] end)
 if not bound or type(fn)~='function' or not current(r) then return false end
 local ok,value=invoke(r,fn,target,...)
 local same,unchanged=pcall(function() return target[key]==fn end)
 return ok and same and unchanged and current(r),value
end
local function public(r,value,kind)
 local ok,readable=invoke(r,S.Readable,S,value)
 return ok and readable==true and (not kind or type(value)==kind) and current(r)
end
local function boolean(r,target,key)
 local ok,value=method(r,target,key)
 if not ok or not public(r,value,'boolean') then return nil end
 return value
end
local function visible(f,r)
 r=r or observe()
 if not f then return false end
 local shown=boolean(r,f,'IsVisible');if shown~=true then return false end
 local ok,enabled=pcall(function() return f.IsEnabled end)
 if not ok or not current(r) then return false end
 if enabled~=nil then return boolean(r,f,'IsEnabled')==true end
 return true
end
-- Actual mutation target must report unprotected. Context ancestors need only
-- public readable/nonforbidden ancestry; UIParent need not be unprotected.
local function targetOK(r,target)
 local node=target;local seen={}
 for depth=1,32 do
  if not public(r,node) or (type(node)~='table' and type(node)~='userdata') or seen[node] then return false end
  seen[node]=true
  if boolean(r,node,'IsForbidden')~=false then return false end
  if depth==1 and boolean(r,node,'IsProtected')~=false then return false end
  local ok,parent=method(r,node,'GetParent')
  if not ok or not public(r,parent) then return false end
  if parent==nil then return current(r) end
  node=parent
 end
 return false
end
-- Guarded cosmetic dispatch uses only a caller-owned PURE ordinary-state seal.
-- Never run another callback-bearing native/security lookup after this boundary.
local function writeGuardCurrent(r)
 local guard=r.writeGuard
 if not guard then return true end
 local ok,value=pcall(function() if guard()==true then return true end;return false end)
 if not ok or value~=true then return false end
 -- A contract-violating guard cannot retire the shared lifetime then dispatch.
 -- These are owned ordinary tables, not native frame/property lookups.
 return rawequal(rawget(M,"DialogNavigation"),D) and rawequal(rawget(M,"UI"),U) and rawequal(rawget(M,"Safety"),S)
  and rawequal(rawget(D,"_revision"),r.revision) and rawequal(rawget(D,"_admission"),r.admission)
  and rawequal(rawget(D,"_lives"),r.guardLives) and rawequal(rawget(r.guardLives,r.panel),r.life)
  and rawequal(rawget(D,"panels"),r.guardPanels) and rawequal(rawget(r.guardPanels,r.panel),r.spec)
end
local function write(r,target,key,...)
 if not current(r) then return false end
 local previous=D._writing;D._writing=true
 local ok,value,nativeResult=pcall(function(...)
  local bound,fn=pcall(function() return target[key] end)
  if not bound or type(fn)~='function' or not current(r) or not targetOK(r,target) then return false end
  local same,matched=pcall(function() return target[key]==fn end)
  if not same or not matched or not current(r) then return false end
  local unlocked,combat=invoke(r,S.InCombat,S)
  if not unlocked or combat~=false or not current(r) then return false end
  local finalBound,finalMatch=pcall(function() return target[key]==fn end)
  if not finalBound or not finalMatch or not current(r) then return false end
  if not writeGuardCurrent(r) then return false end
  local called,result=pcall(fn,target,...)
  return called and current(r),result
 end,...)
 D._writing=previous
 if not previous and r.bindings.DrainCleanup and D.DrainCleanup==r.bindings.DrainCleanup then pcall(r.bindings.DrainCleanup,D) end
 if ok and value==true and current(r) and writeGuardCurrent(r) then return true,nativeResult end
 return false,nil
end
function D:Allowed(panel,r)
 r=r or observe(panel);local spec=self.panels[panel]
 if not current(r) or not spec or self.top~=panel or not visible(panel,r) then return false end
 local ok,combat=invoke(r,S.InCombat,S)
 if not ok or combat~=false or M.state.cinematic or (M.state.safe and spec.allowWhileSafe~=true) then return false end
 local allowed=spec.allowed
 if allowed then local good,value=invoke(r,allowed);if not good or value~=true or spec.allowed~=allowed then return false end end
 local unlocked,locked=invoke(r,S.InCombat,S)
 return unlocked and locked==false and current(r) and self.top==panel and self.panels[panel]==spec and not M.state.cinematic and (not M.state.safe or spec.allowWhileSafe==true)
end
local function cleanupCurrent(ticket)
 return ticket and D._lives[ticket.panel]==ticket.life and D._session~=ticket.session and D.active~=ticket.panel and M.DialogNavigation==D
end
function D:Cleanup(panel,ticket)
 ticket=ticket or (self.pending and self.pending[panel])
 if not cleanupCurrent(ticket) then if self.pending and self.pending[panel]==ticket then self.pending[panel]=nil end;return false end
 if self.pending and self.pending[panel]==ticket then self.pending[panel]=nil end
 local ok,combat=pcall(S.InCombat,S)
 if not cleanupCurrent(ticket) then return false end
 if not ok or combat~=false or self._writing then self.pending=self.pending or {};self.pending[panel]=ticket;return false end
 ticket.failed=nil
 local complete=true
 for _,entry in ipairs({{'EnableGamePadButton',false},{'SetPropagateKeyboardInput',true}}) do
  if not cleanupCurrent(ticket) then return false end
  local r=observe(panel,true)
  local bound,fn=pcall(function() return panel[entry[1]] end)
  if not bound then complete=false
  elseif fn~=nil then
   if not cleanupCurrent(ticket) or not current(r) or not write(r,panel,entry[1],entry[2]) then complete=false end
  end
 end
 if not complete and cleanupCurrent(ticket) then ticket.failed=true;self.pending=self.pending or {};self.pending[panel]=ticket end
 return complete and cleanupCurrent(ticket)
end
function D:DrainCleanup()
 if self._writing or self._draining or not self.pending then return end
 self._draining=true
 local tickets={};for panel,ticket in pairs(self.pending) do tickets[#tickets+1]={panel,ticket};if #tickets>=128 then break end end
 for _,entry in ipairs(tickets) do if self.pending[entry[1]]==entry[2] and not entry[2].failed and self.Cleanup==entry[2].cleanup then pcall(entry[2].cleanup,self,entry[1],entry[2]) end end
 self._draining=nil
end
function D:Stop(r)
 r=r or begin(self.active,true);if not current(r) then return false end
 local panel,old,session=self.active,self.current,self._session
 local ticket=panel and {panel=panel,life=self._lives[panel],session=session,cleanup=r.bindings.Cleanup}
 self.active=nil;self._session=nil;self.controller=false;self.current=nil;self.returnFocus=nil
 if panel then self.pressed[panel]={} end
 local bound,blur=pcall(function() return old and old.onBlur end)
 if bound and type(blur)=='function' then invoke(r,blur) end
 local sameHide,hideMatches=pcall(function() return self.outline and self.outline==r.outline and r.outlineBindings and self.outline.Hide==r.outlineBindings.Hide end)
 if current(r) and sameHide and hideMatches then write(r,self.outline,'Hide') end
 -- A different successor panel does not prevent independent old-panel cleanup.
 if ticket and type(r.bindings.Cleanup)=="function" then pcall(r.bindings.Cleanup,self,panel,ticket) end
 return current(r)
end
function D:HideCleanupAllowed(panel,r)
 r=r or observe(panel);local spec=self.panels[panel];local policy=spec and spec.hideCleanupAllowed
 if not policy then return current(r) end
 local ok,value=invoke(r,policy)
 return ok and value==true and self.panels[panel]==spec and spec.hideCleanupAllowed==policy
end
function D:Hidden(panel,fromHide)
 local probe=observe(panel,true)
 if fromHide and not self:HideCleanupAllowed(panel,probe) then return false end
 if not current(probe) then return false end
 if (not self._lives[panel] or self._lives[panel].hidden) and self.active~=panel then return true end
 local r=begin(panel,true);local life=self._lives[panel]
 for i=#self.shown,1,-1 do if self.shown[i]==panel then table.remove(self.shown,i) end end
 self.shownGeneration={};self.top=self.shown[#self.shown]
 if life then life.hidden=true end
 if self.active==panel then self:Stop(r) end
 return current(r)
end
local function attempt(panel)
 if D._writing or D._suspending then return nil end
 local a=observe(panel);D._attempt=a;return a
end
local function attemptCurrent(a)
 return a and D._attempt==a and current(a)
end
function D:Shown(panel,a)
 a=a or attempt(panel)
 if self._writing or not attemptCurrent(a) then return false end
 local r=begin(panel);if not r then return false end
 local previous=self.top;local spec=previous and self.panels[previous];local callback=spec and spec.onSuperseded
 if previous~=panel and callback then
  local previousLife,previousSession=self._lives[previous],self._session
  local targetHidden=r.life and r.life.hidden
  local called=pcall(callback)
  if not called or self.panels[previous]~=spec or spec.onSuperseded~=callback then return false end
  if not current(r) then
   -- Closing the exact superseded owner is expected cleanup, not a new show or
   -- navigation admission. Do not mistake that retirement for a successor.
   local retired=(previousLife and previousLife.hidden) or (previousSession and self._session~=previousSession)
   if not retired or not current(r,true) or (r.life and r.life.hidden)~=targetHidden then return false end
   r=observe(panel)
  end
 end
 if not self:Stop(r) or not current(r) then return false end
 for i=#self.shown,1,-1 do if self.shown[i]==panel then table.remove(self.shown,i) end end
 if #self.shown>=128 then table.remove(self.shown,1) end
 local life={};self._lives[panel]=life;r.life=life
 self.shownGeneration={};self.shown[#self.shown+1]=panel;self.top=panel
 local receipt={service=self,panel=panel,life=life,generation=self.shownGeneration}
 return true,receipt
end
function D:CurrentShown(receipt)
 local ok,value=pcall(function()
  return type(receipt)=='table' and receipt.service==self and M.DialogNavigation==self and type(receipt.life)=='table' and
   self._lives[receipt.panel]==receipt.life and not receipt.life.hidden and self.top==receipt.panel
 end)
 return ok and value==true
end
function D:OwnedWrite(receipt,target,key,...)
 if self._suspending or not self:CurrentShown(receipt) then return false,nil end
 local r=observe(receipt.panel)
 local ok,nativeResult=write(r,target,key,...)
 if ok and current(r) and self:CurrentShown(receipt) then return true,nativeResult end
 return false,nil
end
-- Copy's optional chrome seal only; existing OwnedWrite callers are unchanged.
function D:OwnedWriteGuarded(receipt,guard,target,key,...)
 if type(guard)~="function" or self._suspending or not self:CurrentShown(receipt) then return false,nil end
 local r=observe(receipt.panel);r.writeGuard=guard;r.guardLives=self._lives;r.guardPanels=self.panels
 local ok,nativeResult=write(r,target,key,...)
 if ok and current(r) and self:CurrentShown(receipt) and writeGuardCurrent(r) then return true,nativeResult end
 return false,nil
end
function D:OwnedShow(panel,receipt)
 if self._writing or self._suspending or not self:CurrentShown(receipt) or receipt.panel~=panel then return false end
 local ticket={receipt=receipt,panel=panel,consumed=false};self._tickets[panel]=ticket
 local r=observe(panel)
 local ok=write(r,panel,'Show')
 if self._tickets[panel]==ticket then self._tickets[panel]=nil end
 return ok and (not ticket.consumed or ticket.accepted==true) and current(r) and self:CurrentShown(receipt)
end
function D:PanelShown(panel,before)
 local ticket=self._tickets[panel]
 if ticket then
  if ticket.consumed then return false end
  ticket.consumed=true
  if not self:CurrentShown(ticket.receipt) then return false end
  local r=observe(panel)
  if before and not invoke(r,before) then ticket.accepted=false;return false end
  ticket.accepted=current(r) and self:CurrentShown(ticket.receipt)
  return ticket.accepted,ticket.receipt
 end
 local a=attempt(panel);if not a then return false end
 if before and not invoke(a,before) then return false end
 if not attemptCurrent(a) then return false end
 return self:Shown(panel,a)
end
local function entries(self,panel,r)
 r=r or observe(panel);local result={};local spec=self.panels[panel]
 if not current(r) or not spec then return result end
 local popup=U.choices
 if popup then
  local shown=boolean(r,popup,'IsShown');if shown==nil then return result end
  if shown and popup.dialogOwner~=panel then return result end
  if shown then
   for i,row in ipairs(popup.rows) do
    if i>128 then break end
    if visible(row,r) then result[#result+1]={frame=row,key='choice:'..i,kind='button',scroll=popup.scroll,y=-(i-1)*30,token=popup.choiceToken} end
    if not current(r) or U.choices~=popup or popup.dialogOwner~=panel then return {} end
   end
   return result
  end
 end
 local getter=spec.entries;local ok,rows=invoke(r,getter)
 if not ok or spec.entries~=getter or type(rows)~='table' then return result end
 for i=1,128 do
  local entry=rows[i];if not entry then break end
  if type(entry)~='table' then return {} end
  local frame=entry.frame
  if visible(frame,r) then result[#result+1]=entry end
  if not current(r) or rows[i]~=entry or entry.frame~=frame then return {} end
 end
 return result
end
function D:Entries(panel,r)
 local ok,rows=pcall(entries,self,panel,r)
 return ok and rows or {}
end
local descriptorKeys={'frame','key','kind','identity','token','onBlur','onFocus','scroll','y','adjust','commit'}
local function seal(entry)
 if not entry then return nil end
 local ok,copy=pcall(function()
  local result={};for _,key in ipairs(descriptorKeys) do result[key]=entry[key] end;return result
 end)
 return ok and copy or nil
end
local function same(entry,copy)
 if not entry then return copy==nil end
 if not copy then return false end
 local ok,value=pcall(function()
  for _,key in ipairs(descriptorKeys) do if entry[key]~=copy[key] then return false end end
  return true
 end)
 return ok and value==true
end
function D:Highlight(entry,r)
 r=r or begin(self.active);if not r or not current(r) then return false end
 local old=self.current;local oldSeal=seal(old);local entrySeal=seal(entry)
 if (old and not oldSeal) or (entry and not entrySeal) or not current(r) then return false end
 local changed=not old or not entry or oldSeal.frame~=entrySeal.frame or oldSeal.key~=entrySeal.key or oldSeal.identity~=entrySeal.identity or oldSeal.token~=entrySeal.token
 self.current=entry
 local function owned() return current(r) and self.current==entry and same(entry,entrySeal) end
 if changed and old and oldSeal.onBlur then
  invoke(r,oldSeal.onBlur)
  if not owned() or not same(old,oldSeal) then return false end
 end
 if not self.outline then
  local ok,outline=invoke(r,CreateFrame,'Frame',nil,UIParent,'BackdropTemplate')
  if not ok or not owned() then return false end
  self.outline=outline;r.outline=outline;r.outlineBindings=bindings(outline,outlineKeys)
  if not current(r) or not invoke(r,S.Passive,S,outline) or not owned() then return false end
  if not write(r,outline,'SetBackdrop',{edgeFile='Interface\\Buttons\\WHITE8X8',edgeSize=2}) or not owned() then return false end
 end
 local outline=self.outline
 local function paint(key,...) return owned() and self.outline==outline and write(r,outline,key,...) and owned() and self.outline==outline end
 if not paint('Hide') then return false end
 if not entry then return owned() end
 if not paint('SetParent',entry.frame) or not paint('ClearAllPoints') or
  not paint('SetPoint','TOPLEFT',entry.frame,'TOPLEFT',-2,2) or not paint('SetPoint','BOTTOMRIGHT',entry.frame,'BOTTOMRIGHT',2,-2) or
  not paint('SetBackdropBorderColor',.96,.79,.36,1) or not paint('Show') then return false end
 if changed and entrySeal.onFocus then invoke(r,entrySeal.onFocus);if not owned() then return false end end
 if entrySeal.scroll then
  local scroll,y=entrySeal.scroll,entrySeal.y
  local a,pos=method(r,scroll,'GetVerticalScroll');local b,height=method(r,scroll,'GetHeight')
  if not a or not b or not owned() or not public(r,pos,'number') or not public(r,height,'number') or not public(r,y,'number') then return owned() end
  if not owned() then return false end
  if pos~=pos or height~=height or y~=y or height<=0 or math.abs(pos)>1000000 or height>1000000 or math.abs(y)>1000000 then return owned() end
  local top=-y
  if top<pos then if not write(r,scroll,'SetVerticalScroll',top) then return false end
  elseif top+30>pos+height then if not write(r,scroll,'SetVerticalScroll',math.max(0,top+30-height)) then return false end end
 end
 return owned()
end
function D:Refresh(panel,r)
 r=r or begin(panel);if not r or not current(r) or self.active~=panel then return false end
 if not self:Allowed(panel,r) then if current(r) then self:Stop(r) end;return false end
 local rows=self:Entries(panel,r);if not current(r) then return false end
 local old=self.current
 -- A choice callback may legitimately refresh its parent before returning. That
 -- new refresh owns restoration; the older Activate continuation does not.
 local target=self.returnFocus
 if old and old.token~=nil and target then
  for _,row in ipairs(rows) do
   if row.frame==target.frame and row.key==target.key and row.identity==target.identity and row.token==target.token then
    self.returnFocus=nil;return self:Highlight(row,r)
   end
  end
 end
 for _,row in ipairs(rows) do if old and row.key==old.key and row.frame==old.frame and row.token==old.token and row.identity==old.identity then return self:Highlight(row,r) end end
 return self:Highlight(rows[1],r)
end
function D:Restore(panel,target)
 local r=begin(panel);if not r or self.active~=panel then return false end
 if not self:Highlight(nil,r) then return false end
 local rows=self:Entries(panel,r);if not current(r) then return false end
 for _,row in ipairs(rows) do
  if target and row.frame==target.frame and row.key==target.key and row.identity==target.identity and row.token==target.token then return self:Highlight(row,r) end
 end
 return self:Refresh(panel,r)
end
function D:ChoiceOpened(popup,anchor)
 local r=begin(self.top);if not r then return false end
 popup.dialogOwner=nil
 local panel=self.top;local spec=self.panels[panel];local getter=spec and spec.entries
 local ok,rows=invoke(r,getter)
 if not ok or not spec or spec.entries~=getter or type(rows)~="table" or not current(r) then return false end
 for index,entry in ipairs(rows) do
  if index>128 then break end
  if entry.frame==anchor and visible(anchor,r) then
   if not current(r) then return false end
   popup.dialogOwner=panel;popup.dialogAnchor=entry
   if self.active==panel then self.returnFocus=entry;if not self:Highlight(nil,r) then return false end;return self:Refresh(panel,r) end
   return true
  end
 end
 return false
end
function D:Start(panel,controller)
 local a=attempt(panel);if not a then return false end
 if controller~=nil and type(controller)~='boolean' then return false end
 if not self:Allowed(panel,a) or not attemptCurrent(a) then return false end
 local ok,typing=invoke(a,S.Typing,S)
 if not ok or typing~=false or not attemptCurrent(a) then return false end
 local padFn
 if controller then
  local bound,fn=pcall(function() return panel.EnableGamePadButton end)
  if not bound or type(fn)~='function' or not attemptCurrent(a) then return false end
  padFn=fn
 end
 local unlocked,combat=invoke(a,S.InCombat,S)
 if not unlocked or combat~=false or not attemptCurrent(a) then return false end
 local r=begin(panel);if not r then return false end
 if not self:Stop(r) or not current(r) then return false end
 for _,other in ipairs({M.OptionsNavigation or false,M.AccessibleInput or false}) do
  if other and type(other.Stop)=='function' and not method(r,other,'Stop') then return false end
 end
 if not current(r) then return false end
 local session={panel=panel,life=self._lives[panel]};self._session=session;self.active=panel;self.controller=controller==true;self.pressed[panel]={}
 if controller and (panel.EnableGamePadButton~=padFn or not write(r,panel,'EnableGamePadButton',true)) then if current(r) and self._session==session then self:Stop(r) end;return false end
 local popup=U.choices
 if popup and boolean(r,popup,'IsShown')==true and popup.dialogOwner==panel then self.returnFocus=popup.dialogAnchor end
 if not current(r) or not self:Refresh(panel,r) then if current(r) and self._session==session then self:Stop(r) end;return false end
 return current(r) and self._session==session and self.active==panel
end
function D:Move(delta)
 local panel=self.active;local r=begin(panel);if not r then return false end
 local ok,typing=invoke(r,S.Typing,S);if not ok or typing~=false then return false end
 if not panel or not self:Allowed(panel,r) then if current(r) then self:Stop(r) end;return false end
 local rows=self:Entries(panel,r);if not current(r) or #rows==0 then return false end
 local index=delta>0 and 0 or 1
 for i,row in ipairs(rows) do if self.current and row.frame==self.current.frame and row.key==self.current.key then index=i;break end end
 return self:Highlight(rows[((index-1+delta)%#rows)+1],r)
end
function D:Activate()
 local panel=self.active;local r=begin(panel);if not r then return false end
 local ok,typing=invoke(r,S.Typing,S);if not ok or typing~=false then return false end
 if not panel or not self:Allowed(panel,r) then if current(r) then self:Stop(r) end;return false end
 local selected=self.current;if not selected then return false end
 local rows=self:Entries(panel,r);if not current(r) then return false end
 local found
 for _,row in ipairs(rows) do if row.frame==selected.frame and row.key==selected.key and row.token==selected.token and row.identity==selected.identity then found=row;break end end
 if not found then self:Refresh(panel,r);return false end
 local snapshot=seal(found);if not snapshot then return false end
 if found.kind=='edit' then
  if not write(r,found.frame,'SetFocus') or not current(r) or not same(found,snapshot) then return false end
  local bound,highlight=pcall(function() return found.frame.HighlightText end)
  if not bound or not current(r) then return false end
  return not highlight or write(r,found.frame,'HighlightText')
 end
 local got,click=method(r,found.frame,'GetScript','OnClick');if not got or type(click)~='function' or not same(found,snapshot) then return false end
 local wasChoice=found.token~=nil
 if not wasChoice then self.returnFocus=found end
 local called=invoke(r,click,found.frame,'LeftButton')
 if not called or not current(r) or self.active~=panel then return true end
 local popup=U.choices
 if popup and boolean(r,popup,'IsShown')==true then
  if not current(r) then return true end
  popup.dialogOwner=panel
  if not self:Highlight(nil,r) then return true end
  self:Refresh(panel,r)
 elseif current(r) and wasChoice then local target=self.returnFocus;self.returnFocus=nil;self:Restore(panel,target)
 elseif current(r) then self.returnFocus=nil;self:Refresh(panel,r) end
 return true
end
-- Numeric adjustment is an explicit descriptor capability, never widget discovery.
function D:Adjust(delta)
 if delta~=-1 and delta~=1 then return false end
 local panel=self.active;local r=observe(panel)
 local ok,typing=invoke(r,S.Typing,S);if not ok or typing~=false then return false end
 if not panel or not self:Allowed(panel,r) then if current(r) then self:Stop(r) end;return false end
 local selected=self.current;if not selected then return false end
 local rows=self:Entries(panel,r);if not current(r) then return false end
 for _,row in ipairs(rows) do
  if row.frame==selected.frame and row.key==selected.key and row.identity==selected.identity and row.token==selected.token then
   if type(row.adjust)~='function' then return false end
   local called,result=pcall(row.adjust,delta);return called and result~=false
  end
 end
 self:Refresh(panel,r);return false
end
function D:FieldTab(panel,box,key)
 local r=begin(panel);if not r or not self:Allowed(panel,r) then return false end
 local ok,focused=invoke(r,GetCurrentKeyBoardFocus)
 if not ok or not public(r,focused) or focused~=box then return false end
 local rows=self:Entries(panel,r);if not current(r) then return false end
 local entry
 for _,row in ipairs(rows) do if row.frame==box and row.key==key and row.kind=='edit' then entry=row;break end end
 if not entry then return false end
 local snapshot=seal(entry)
 if entry.commit then
  local session,life,selected=self._session,self._lives[panel],self.current
  local good,value=pcall(entry.commit)
  if not good or value==false or not same(entry,snapshot) then return false end
  if not current(r) then
   -- A successful field commit may refresh that same descriptor. Preserve Tab
   -- only for the exact unchanged live session/lifetime and logical selection;
   -- a new Start/Shown or a moved selection is never adopted.
   local now=self.current
   local unchanged=now==selected or (now and selected and now.frame==selected.frame and now.key==selected.key and now.identity==selected.identity and now.token==selected.token)
   if self._session~=session or self._lives[panel]~=life or self.top~=panel or not unchanged or not current(r,"refresh") then return false end
   if self._session~=session or self._lives[panel]~=life or self.top~=panel or self.current~=now then return false end
   r=observe(panel)
   if not self:Allowed(panel,r) then return false end
  end
 end
 if not write(r,box,'ClearFocus') then return false end
 if self.active~=panel then if not self:Start(panel,false) then return false end;r=observe(panel) end
 if not self:Highlight(entry,r) then return false end
 local shifted,shift=invoke(r,IsShiftKeyDown)
 if not shifted or not public(r,shift,'boolean') then return false end
 return self:Move(shift and -1 or 1)
end
function D:SuspendDialogs(reason)
 local previous=self._suspending;self._suspending=true
 local targets={}
 for panel,spec in pairs(self.panels) do
  if spec.closeOnSuspend and (reason~="safe" or not spec.allowWhileSafe) then targets[#targets+1]={panel=panel,spec=spec,life=self._lives[panel]} end
 end
 local activeSpec=self.active and self.panels[self.active]
 if reason~="safe" or not activeSpec or not activeSpec.allowWhileSafe then self:Stop() end
 for _,target in ipairs(targets) do
  local panel=target.panel
  if self.panels[panel]==target.spec and self._lives[panel]==target.life then
   local r=observe(panel)
   if visible(panel,r) and current(r) then
    self:Hidden(panel,false)
    if self.panels[panel]==target.spec and self._lives[panel]==target.life then
     local cleanup=observe(panel);write(cleanup,panel,'Hide')
    end
   end
  end
 end
 self._suspending=previous
end
function D:Back(panel)
 local r=begin(panel);if not r then return false end
 local popup=U.choices
 if popup and boolean(r,popup,'IsShown')==true and popup.dialogOwner==panel then
  if not method(r,U,'CloseChoices') then return false end
  local target=self.returnFocus;self.returnFocus=nil;return self:Restore(panel,target)
 end
 if not current(r) then return false end
 local spec=self.panels[panel];local close=spec and spec.close
 if not self:Stop(r) then return false end
 local function retired() return current(r,true) and r.life and r.life.hidden and self.active~=panel end
 if close then local called=invoke(r,close);return called or retired() end
 local hidden=write(r,panel,'Hide');return hidden or retired()
end
function D:Key(panel,key,controller)
 local r=observe(panel)
 local textOK,known=invoke(r,S.Text,S,key);if not textOK or known~=true then return false end
 if not self:Allowed(panel,r) then if current(r) and self.active==panel then self:Stop(r) end;return false end
 local typed,typing=invoke(r,S.Typing,S);if not typed or typing~=false then return false end
 if not controller and key=='F6' then if self.active==panel then self:Stop();return true else return self:Start(panel,false) end end
 if self.active~=panel or (controller and not self.controller) then return false end
 if key=='TAB' then return self:Move(S:Public(IsShiftKeyDown,'boolean') and -1 or 1)
 elseif key=='PADDUP' then return self:Move(-1)
 elseif key=='PADDDOWN' then return self:Move(1)
 elseif key=='PADDLEFT' then return self:Adjust(-1)
 elseif key=='PADDRIGHT' then return self:Adjust(1)
 elseif key=='ENTER' or key=='SPACE' or key=='PAD1' then return self:Activate()
 elseif key=='ESCAPE' or key=='PAD2' then return self:Back(panel)
 elseif key=='PADBACK' then self:Stop();return true end
 return false
end
function D:Attach(panel,spec)
 if self.panels[panel] then return end
 self.panels[panel]=spec;self.pressed[panel]={}
 panel:EnableKeyboard(true);panel:SetPropagateKeyboardInput(true)
 local function down(f,key,controller)
  if not S:Text(key) then return end
  local once=key=="ENTER" or key=="SPACE" or key=="PAD1" or key=="ESCAPE" or key=="PAD2" or key=="F6" or key=="PADBACK"
  local handled
  if self:Allowed(f) and type(spec.inputDown)=='function' then handled=spec.inputDown(key,controller) end
  if handled==nil then
   local previous=self.dispatch;self.dispatch={panel=f,key=key,controller=controller}
   local ok,result=pcall(function() return once and self.pressed[f][key] or self:Key(f,key,controller) end)
   self.dispatch=previous;if not ok then error(result) end;handled=result
  end
  if handled then self.pressed[f][key]=true end
  if not S:InCombat() then f:SetPropagateKeyboardInput(not handled) end
 end
 local function up(f,key,controller)
  if not S:Text(key) then return end
  local routed
  if self:Allowed(f) and type(spec.inputUp)=='function' then routed=spec.inputUp(key,controller) end
  local handled=routed==true or self.pressed[f][key];self.pressed[f][key]=nil
  if not S:InCombat() then f:SetPropagateKeyboardInput(not handled) end
 end
 panel:SetScript('OnKeyDown',function(f,key) down(f,key,false) end);panel:SetScript('OnKeyUp',function(f,key) up(f,key,false) end)
 if type(panel.EnableGamePadButton)=='function' then
  panel:SetScript('OnGamePadButtonDown',function(f,key) down(f,key,true) end);panel:SetScript('OnGamePadButtonUp',function(f,key) up(f,key,true) end)
 end
 panel:HookScript('OnHide',function()
  local r=observe(panel,true)
  if boolean(r,panel,'IsShown')==false and current(r) then self:Hidden(panel,true) end
 end)
 -- Only explicit registered fields receive Tab behavior. Preserve Enter/Escape.
 for _,entry in ipairs(spec.entries() or {}) do if entry.kind=='edit' then
  entry.frame:SetScript('OnTabPressed',function(box) self:FieldTab(panel,box,entry.key) end)
 end end
end
local events=CreateFrame('Frame')
for _,event in ipairs({'PLAYER_REGEN_DISABLED','PLAYER_REGEN_ENABLED','CINEMATIC_START','PLAYER_LEAVING_WORLD'}) do events:RegisterEvent(event) end
events:SetScript('OnEvent',function(_,event)
 if event=='PLAYER_REGEN_ENABLED' then
  -- This event iterator retries only the exact debt present at entry; it
  -- never adds callback-created tickets. Bounded writer unwind is separate.
  local cleanup=D.Cleanup;local tickets={}
  for panel,ticket in pairs(D.pending or {}) do tickets[#tickets+1]={panel=panel,ticket=ticket};if #tickets>=128 then break end end
  for _,entry in ipairs(tickets) do
   if D.Cleanup~=cleanup then break end
   if D.pending and D.pending[entry.panel]==entry.ticket and entry.ticket.cleanup==cleanup then pcall(cleanup,D,entry.panel,entry.ticket) end
  end
 else D:SuspendDialogs() end
end)
events:SetScript('OnUpdate',function()
 local blocked=M.state.cinematic and "cinematic" or M.state.safe and "safe" or nil
 if blocked and blocked~=D.suspended then D:SuspendDialogs(blocked) end;D.suspended=blocked
 local panel,session=D.active,D._session
 if panel then
  local r=observe(panel)
  if not D:Allowed(panel,r) and current(r) and D.active==panel and D._session==session then D:Stop(r) end
 end
end)
