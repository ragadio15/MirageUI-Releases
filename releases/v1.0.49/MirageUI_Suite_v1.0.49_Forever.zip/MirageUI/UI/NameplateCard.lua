local _,M=...
M.NameplateCard={}
local V,S=M.NameplateCard,M.Safety
local auraGap=3
-- This is an authored display budget, not a claimed engine aura limit. Keep
-- six to eight readable icons per line; the native flow engine wraps extras
-- upward without exposing aura counts, payloads or positions to addon Lua.
local debuffCapacity=40
local debuffFont="Interface\\AddOns\\MirageUI\\Media\\Fonts\\OpenSans-CondBold.ttf"
local function debuffCount(cfg) return math.max(6,math.min(8,math.floor(cfg.cardAuraCount or 6))) end
local function debuffSize(cfg)
    -- Six complete icons must fit the actual authored card width, including
    -- all five gaps. The old doubled icon size silently overflowed that row.
    local count=debuffCount(cfg)
    return math.max(16,math.min(40,math.floor(((cfg.cardWidth or 240)-(count-1)*auraGap)/count)))
end
local function buffSize(cfg) return math.max(16,math.min(24,cfg.cardIconSize or 20)) end
function V:AuraGeometry(cfg) return debuffCount(cfg),debuffSize(cfg),3,buffSize(cfg) end
-- One body language for world plates and native-backed unit cards. These are
-- owned textures; only the narrow data tracks carry a strong dark backing.
function V:Panel(frame,opacity)
    M.Visual:Panel(frame,1)
    frame.miragePanel:SetColorTexture(.018,.018,.018,1)
    frame.miragePanel:SetAlpha(math.max(0,math.min(.85,opacity or .12)))
end
-- Local backings protect text on bright terrain while leaving the broad card
-- almost transparent. Background opacity never scales the foreground glyphs.
function V:TextBackings(view,percent)
 local frame=view.frame
 if not view.identityBacking then
  local t=frame:CreateTexture(nil,"BACKGROUND",nil,1);view.identityBacking=t
  t:SetPoint("TOPLEFT",frame,"TOPLEFT",3,-1);t:SetPoint("TOPRIGHT",frame,"TOPRIGHT",-3,-1);t:SetHeight(19)
  t:SetColorTexture(.012,.012,.012,.35)
 end
 local pairs={{"healthTextBacking",view.hp or view.healthPercent},{"powerTextBacking",view.pp or view.powerPercent}}
 for _,entry in ipairs(pairs) do
  local key,font=entry[1],entry[2]
  if font then
   if not view[key] then
    local t=frame:CreateTexture(nil,"BACKGROUND",nil,1);view[key]=t;t:SetAllPoints(font);t:SetColorTexture(.012,.012,.012,.68)
   end
   local shown=percent and not view.relativeLayout and (key~="powerTextBacking" or not view.powerAbsent and view.powerPresence~="ABSENT")
   view[key]:SetShown(shown==true)
  end
 end
end
-- One detached public probe per bounded pool slot. A plate's anchored string
-- metrics may become secret; never move such results across that boundary.
local probes,receipts,versions=setmetatable({},{__mode="k"}),setmetatable({},{__mode="k"}),setmetatable({},{__mode="k"})
local checking=setmetatable({},{__mode="k"})
local layoutRelativeBody,prepareRelativeBody
local fitMethods={"GetText","GetFont","GetWidth","GetHeight","GetUnboundedStringWidth","GetStringHeight","IsTruncated","SetText","SetFont","SetWidth","SetHeight","SetSize","GetParent","IsProtected","IsForbidden"}
local function revoke(v) versions[v]=(versions[v] or 0)+1;receipts[v]=nil end
local function watchName(v)
    -- These are exclusively our own ordinary FontStrings. Observe writes to
    -- our fit geometry without reading anchored dimensions. A repeated body
    -- height write is harmless; all other geometry changes require a new fit.
    for _,key in ipairs({"SetWidth","SetHeight","SetSize","SetFont","SetFontObject","SetPoint","ClearAllPoints","SetParent","SetWordWrap","SetNonSpaceWrap","SetIndentedWordWrap","SetMaxLines","SetSpacing"}) do
        local original=v.name[key]
        if type(original)=="function" then
            v.name[key]=function(font,...)
                local r=receipts[v];local first,second,third=...
                local same=r and ((key=="SetHeight" and S:Number(first) and first==r.requestedHeight)
                    or (key=="SetWidth" and S:Number(first) and first==r.requestedWidth)
                    or (key=="SetSize" and S:Number(first) and S:Number(second) and first==r.requestedWidth and second==r.requestedHeight)
                    or (key=="SetFont" and S:Text(first) and S:Number(second) and S:Text(third) and first==r.renderer.path and second==r.requestedSize and third==""))
                if not same then revoke(v) end
                return original(font,...)
            end
        end
    end
end
-- Keep the default rows stable; larger supported names grow only our passive
-- body and move both bar and percentage rows together. Native hitboxes are untouched.
local function layoutBody(v,cfg)
    if v.relativeLayout then return layoutRelativeBody(v,cfg) end
    local nameHeight=math.max(16,(cfg.nameSize or 12)+4)
    local extra=nameHeight-16
    v.name:SetHeight(nameHeight)
    v.health:ClearAllPoints();v.health:SetPoint("TOPLEFT",7,-25-extra)
    v.power:ClearAllPoints();v.power:SetPoint("TOPLEFT",7,-40-extra)
    v.hp:ClearAllPoints();v.hp:SetPoint("TOPRIGHT",-6,-23-extra)
    v.pp:ClearAllPoints();v.pp:SetPoint("TOPRIGHT",-6,-38-extra)
    v.frame:SetHeight((v.powerAbsent and 40 or 55)+extra)
end
local function text(parent,size,width,color)
    local f=parent:CreateFontString(nil,"OVERLAY")
    f:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",size,"");f:SetWidth(width);f:SetHeight(size+4);f:SetJustifyH("LEFT")
    if f.SetShadowColor then f:SetShadowColor(0,0,0,0);f:SetShadowOffset(0,0) end
    f:SetTextColor(unpack(color or M.Visual.neutral));f.mirageSemanticColor=true
    return f
end
function V:Create()
    local f=CreateFrame("Frame",nil,UIParent);S:Passive(f);f:Hide()
    local v={frame=f,owner="Nameplates",generation=0}
    V:Panel(f)
    v.level=text(f,11,25,M.Visual.level);v.level:SetPoint("TOPLEFT",7,-4)
    v.separator=text(f,11,8);v.separator:SetPoint("TOPLEFT",34,-4);v.separator:SetText("|")
    v.name=text(f,12,180);v.name:SetPoint("TOPLEFT",47,-4);M.Visual:PlainName(v.name,12)
    local holder=CreateFrame("Frame",nil,UIParent);S:Passive(holder);holder:Hide()
    local probe=text(holder,12,180);M.Visual:PlainName(probe,12)
    probes[v]={holder=holder,font=probe};v.nameProbe=probe;v.nameProbeHolder=holder
    watchName(v)
    v.nameBacking=f:CreateTexture(nil,"BORDER");v.nameBacking:SetPoint("TOPLEFT",v.name,"TOPLEFT",-2,1);v.nameBacking:SetPoint("BOTTOMRIGHT",v.name,"BOTTOMRIGHT",2,-1);v.nameBacking:SetColorTexture(.035,.04,.045,.78);v.nameBacking:Hide()
    v.health=M.UI:Bar(f,7,-25,186,5,unpack(M.Visual.health));S:Passive(v.health)
    v.power=M.UI:Bar(f,7,-40,186,5,unpack(M.Visual.mana));S:Passive(v.power)
    M.UI:Beam(v.health);M.UI:Beam(v.power)
    M.UI:BeamColor(v.health,unpack(M.Visual.health));M.UI:BeamColor(v.power,unpack(M.Visual.mana))
    M.UI:BeamTrack(v.health,unpack(M.Visual.track));M.UI:BeamTrack(v.power,unpack(M.Visual.track))
    v.hp=text(f,11,36,M.Visual.health);v.hp:SetJustifyH("RIGHT");v.hp:SetPoint("TOPRIGHT",-6,-23)
    v.pp=text(f,11,36,M.Visual.mana);v.pp:SetJustifyH("RIGHT");v.pp:SetPoint("TOPRIGHT",-6,-38)
    v.selection=text(f,15,12,{1,1,1,1});v.selection:SetPoint("RIGHT",f,"LEFT",-2,0)
    v.focus=text(f,10,12,{1,1,1,1});v.focus:SetPoint("TOPRIGHT",f,"TOPLEFT",-2,-2)
    v.focus:SetTextColor(.42,.82,.88,1)
    v.targetEdge=f:CreateTexture(nil,"OVERLAY");v.targetEdge:SetColorTexture(.96,.66,.24,1)
    v.targetEdge:SetPoint("TOPLEFT",f,"TOPLEFT",0,0);v.targetEdge:SetPoint("BOTTOMLEFT",f,"BOTTOMLEFT",0,0);v.targetEdge:SetWidth(2);v.targetEdge:Hide()
    v.focusEdge=f:CreateTexture(nil,"OVERLAY");v.focusEdge:SetColorTexture(.42,.82,.88,1)
    v.focusEdge:SetPoint("TOPRIGHT",f,"TOPRIGHT",0,0);v.focusEdge:SetPoint("BOTTOMRIGHT",f,"BOTTOMRIGHT",0,0);v.focusEdge:SetWidth(2);v.focusEdge:Hide()
    v.rangeTag=text(f,9,100,{.95,.69,.35,1});v.rangeTag:SetPoint("TOPLEFT",f,"TOPRIGHT",8,-31)
    v.status=text(f,9,100,M.Visual.neutral);v.status:SetPoint("TOPLEFT",f,"TOPRIGHT",8,-46)
    -- Retain empty compatibility strings, but threat has a quiet three-sided
    -- visual. The selected-target accent remains independently on the left.
    v.rangeTag:SetText("");v.status:SetText("")
    v.aggroEdges={}
    for _,side in ipairs({"TOP","RIGHT","BOTTOM"}) do
        local t=f:CreateTexture(nil,"OVERLAY",nil,7);t:SetColorTexture(1,0,0,.95)
        if side=="RIGHT" then
            t:SetPoint("TOPRIGHT",f,"TOPRIGHT",0,0);t:SetPoint("BOTTOMRIGHT",f,"BOTTOMRIGHT",0,0);t:SetWidth(1)
        else
            t:SetPoint(side.."LEFT",f,side.."LEFT",0,0);t:SetPoint(side.."RIGHT",f,side.."RIGHT",0,0);t:SetHeight(1)
        end
        t:Hide();v.aggroEdges[#v.aggroEdges+1]=t
    end
    self:TextBackings(v,true)
    v.cast=CreateFrame("Frame",nil,f);S:Passive(v.cast);v.cast:SetPoint("TOPLEFT",f,"BOTTOMLEFT",0,-3);v.cast:Hide()
    V:Panel(v.cast)
    v.castIcon=v.cast:CreateTexture(nil,"ARTWORK");v.castIcon:SetPoint("LEFT",v.cast,"LEFT",2,0);v.castIcon:SetSize(18,18)
    v.castBar=M.UI:Bar(v.cast,23,-14,210,5,unpack(M.Visual.cast));S:Passive(v.castBar)
    M.UI:Beam(v.castBar);M.UI:BeamColor(v.castBar,unpack(M.Visual.cast));M.UI:BeamTrack(v.castBar,unpack(M.Visual.track))
    v.castName=text(v.cast,10,126,{1,1,1,1});v.castName:SetPoint("BOTTOMLEFT",v.castBar,"TOPLEFT",0,1)
    v.castClock=text(v.cast,10,65,{1,1,1,1});v.castClock:SetJustifyH("RIGHT");v.castClock:SetPoint("BOTTOMRIGHT",v.castBar,"TOPRIGHT",0,1)
    v.upper=CreateFrame("Frame",nil,f);S:Passive(v.upper);v.upper:SetPoint("BOTTOMLEFT",f,"TOPLEFT",0,4);v.upper:SetSize(240,26)
    v.lower=CreateFrame("Frame",nil,f);S:Passive(v.lower);v.lower:SetPoint("TOPLEFT",f,"BOTTOMLEFT",0,-3);v.lower:SetSize(240,26)
    v.important=CreateFrame("Frame",nil,f);S:Passive(v.important);v.important:SetPoint("TOPLEFT",f,"TOPRIGHT",8,-2);v.important:SetSize(66,20)
    M.UI:BeamTrack(v.health,.30,.31,.33,.76);M.UI:BeamTrack(v.power,.30,.31,.33,.76);M.UI:BeamTrack(v.castBar,.30,.31,.33,.76)
    prepareRelativeBody(v)
    return v
end
function V:Layout(v,cfg)
    v.presentationScale=nil
    local prior=receipts[v]
    if not prior or prior.config~=cfg or prior.width~=cfg.cardWidth or prior.size~=cfg.nameSize or prior.scale~=cfg.cardScale then revoke(v) end
    local w,h=cfg.cardWidth or 240,55
    if not v.relativeLayout then v.frame:SetSize(w,h);v.frame:SetScale((cfg.cardScale or 100)/100) end
    local reserve=cfg.cardPercent and 43 or 7
    v.health:SetWidth(w-7-reserve);v.power:SetWidth(w-7-reserve)
    v.name:SetWidth(w-53);M.Visual:PlainName(v.name,cfg.nameSize or 12)
    layoutBody(v,cfg)
    local probe=probes[v]
    if probe then probe.font:SetWidth(w-53);probe.font:SetHeight(math.max(16,(cfg.nameSize or 12)+4));M.Visual:PlainName(probe.font,cfg.nameSize or 12) end
    v.nameBacking:SetShown(cfg.nameBacking==true);V:Panel(v.frame,(cfg.panelOpacity or 12)/100)
    V:Panel(v.cast,(cfg.panelOpacity or 12)/100)
    v.hp:SetShown(not v.relativeLayout and cfg.cardPercent==true);v.power:SetShown(not v.powerAbsent);v.pp:SetShown(not v.relativeLayout and not v.powerAbsent and cfg.cardPercent==true)
    v.cast:SetSize(w,20);v.castBar:SetWidth(w-26);v.castClock:SetWidth(math.min(80,w*.32));v.castName:SetWidth(math.max(40,w-116))
    v.upper:SetSize(w,debuffSize(cfg));v.lower:SetSize(w,cfg.cardIconSize or 24)
    v.important:SetSize(3*buffSize(cfg)+2*auraGap,buffSize(cfg))
    self:TextBackings(v,cfg.cardPercent==true)
    if v.harmful then M.ManagedAuraRails:Configure(v.harmful,debuffCapacity,debuffSize(cfg),auraGap,debuffCount(cfg)) end
    if v.helpful then M.ManagedAuraRails:Configure(v.helpful,3,buffSize(cfg),auraGap) end
end

-- Some nameplate anchors have protected screen positions. A passive visual
-- can inherit their engine layout without reading a rectangle, size or point.
-- The envelope has the exact native input corners; only body artwork is below
-- its clipping boundary. Cast/aura/selection decorations remain passive
-- siblings, so this compatibility layout does not discard those displays.
local relativeGeometryMethods={"SetParent","SetPoint","ClearAllPoints","SetAllPoints","SetSize","SetWidth","SetHeight","SetScale","SetIgnoreParentScale"}
local function relativeObject(object)
    -- The native engine base may be protected. It is an ancestry/reference
    -- anchor, never our mutation target. Match Rework's actual-target legality
    -- instead of rejecting an ordinary owned child for its native ancestry.
    if not S:Frame(object,false) then return false end
    if not S:InCombat() then return true end
    local protected,known=S:Public(object.IsProtected,"boolean",object)
    return known=="KNOWN" and protected==false
end
local function relativeMethodsCurrent(v,state)
    if v.relativeSource~=state then return false end
    for object,methods in pairs(state.methods) do
        if not S:Frame(object,false) then return false end
        for key,method in pairs(methods) do if object[key]~=method then return false end end
    end
    return true
end
local function relativeCurrent(v,state) return state.prepared and not state.invalidated and relativeMethodsCurrent(v,state) end
local function expectedWrite(expected,object,key,...)
    if not expected or expected.object~=object or expected.key~=key or expected.n~=select("#",...) then return false end
    for i=1,expected.n do
        local value=select(i,...)
        if not S:Readable(value) or value~=expected.args[i] then return false end
    end
    return true
end
local function relativePreparedGraph(state)
    -- Read owned parent/clip state only while detached. During a live lease,
    -- hooks and pinned method identities retain this preparation receipt.
    for _,entry in ipairs(state.graph) do
        local actual,known=S:Public(entry.object.GetParent,nil,entry.object)
        if known~="KNOWN" or actual~=entry.parent then return false,"RELATIVE_PREPARED_PARENT_"..entry.role.."_UNCONFIRMED" end
    end
    local clipped,known=S:Public(state.clip.DoesClipChildren,"boolean",state.clip)
    if known~="KNOWN" or clipped~=true then return false,"RELATIVE_PREPARED_CLIP_UNCONFIRMED" end
    return true
end
prepareRelativeBody=function(v)
    local frame=v.frame
    if type(hooksecurefunc)~="function" or type(frame.SetClipsChildren)~="function"
        or type(frame.DoesClipChildren)~="function" or type(frame.SetIgnoreParentScale)~="function" then
        v.relativePreparationFailure="RELATIVE_BODY_CAPABILITY_UNAVAILABLE";return
    end
    local state={methods={},serial=0,parents={},graph={},interior={},roles={[frame]="ENVELOPE"},preparing=true}
    local clip=CreateFrame("Frame",nil,frame);S:Passive(clip);clip:Hide()
    local body=CreateFrame("Frame",nil,clip);S:Passive(body)
    local data=CreateFrame("Frame",nil,body);S:Passive(data)
    state.clip,state.body,state.data=clip,body,data
    state.roles[clip],state.roles[body],state.roles[data]="CLIP","BODY","DATA"
    state.interior[clip],state.interior[body],state.interior[data]=true,true,true
    local function watch(object,key)
        if not relativeObject(object) or type(object[key])~="function" then return false end
        local okay=pcall(hooksecurefunc,object,key,function(changed,...)
            if changed~=object then return end
            state.serial=state.serial+1
            if state.preparing then return end
            if state.prepared and key=="SetParent" and object~=frame then
                local requested=...
                local expectedParent=state.expectedParents and state.expectedParents[object]
                if not S:Readable(requested) or requested~=expectedParent then
                    state.escaped=state.escaped or {}
                    if not state.escaped[object] then
                        local shown,known=S:Public(object.IsShown,"boolean",object)
                        state.escaped[object]={shown=shown,known=known=="KNOWN"}
                    end
                end
            end
            if state.writing then
                -- A supported setter can invoke more than one internal
                -- callback. Callback count is not an engine API contract.
                -- Conflicting writes still invalidate the submitted layout.
                if expectedWrite(state.expected,object,key,...) or state.layoutExpected and expectedWrite(state.layoutExpected[key],object,key,...) then return end
                state.invalidated=true;state.failure="RELATIVE_NESTED_LAYOUT_WRITE";return
            end
            if state.receipt or state.prepared and (state.interior[object] or object~=frame and key=="SetParent") then
                state.invalidated=true
                local invalidated=v.preparedInvalidated or v.relativeInvalidated
                if invalidated then invalidated() end
            end
        end)
        if not okay then return false end
        state.methods[object]=state.methods[object] or {}
        state.methods[object][key]=object[key]
        return true
    end
    local complete=true
    for _,object in ipairs({frame,clip,body,data}) do
        for _,key in ipairs(relativeGeometryMethods) do complete=watch(object,key) and complete end
        state.methods[object]=state.methods[object] or {};state.methods[object].GetParent=object.GetParent
    end
    complete=watch(clip,"SetClipsChildren") and complete
    state.methods[clip].DoesClipChildren=clip.DoesClipChildren
    local objects={{"LEVEL",v.level},{"SEPARATOR",v.separator},{"NAME",v.name},{"HEALTH",v.health},{"POWER",v.power},
        {"HEALTH_PERCENT",v.hp},{"POWER_PERCENT",v.pp},{"NAME_BACKING",v.nameBacking},{"IDENTITY_BACKING",v.identityBacking},
        {"HEALTH_BACKING",v.healthTextBacking},{"POWER_BACKING",v.powerTextBacking},{"PANEL",frame.miragePanel},
        {"TARGET_EDGE",v.targetEdge},{"FOCUS_EDGE",v.focusEdge}}
    for i,edge in ipairs(v.aggroEdges or {}) do objects[#objects+1]={"THREAT_EDGE_"..i,edge} end
    for _,row in ipairs(objects) do
        local role,object=row[1],row[2]
        if object then
            state.roles[object]=role
            local parent,known=S:Public(object.GetParent,nil,object)
            if known~="KNOWN" then complete=false
            else
                state.parents[#state.parents+1]={object=object,parent=parent,role=role}
                complete=watch(object,"SetParent") and complete
                state.methods[object]=state.methods[object] or {};state.methods[object].GetParent=object.GetParent
            end
        end
    end
    if not complete then
        state.preparing=nil;v.relativePreparationFailure="RELATIVE_BODY_OBSERVER_PREPARE_FAILED";return
    end
    local stage="RELATIVE_BODY_DETACHED_PREPARE"
    local okay,prepared,why=pcall(function()
        local parent,known=S:Public(frame.GetParent,nil,frame)
        if known~="KNOWN" or parent~=UIParent then return false,"RELATIVE_BODY_PREPARE_NOT_DETACHED" end
        for _,object in ipairs({frame,clip,body,data}) do
            stage="RELATIVE_PREPARE_"..state.roles[object].."_SCALE"
            object:SetIgnoreParentScale(false)
            if object~=frame then object:SetScale(1) end
        end
        stage="RELATIVE_PREPARE_CLIP_ANCHORS";clip:SetAllPoints(frame);clip:SetClipsChildren(true)
        stage="RELATIVE_PREPARE_BODY_ANCHORS";body:SetAllPoints(clip)
        stage="RELATIVE_PREPARE_DATA_ANCHORS";data:SetPoint("TOPLEFT",body,"LEFT",0,0);data:SetPoint("BOTTOMRIGHT",body,"BOTTOMRIGHT",0,0)
        state.graph={{object=clip,parent=frame,role="CLIP"},{object=body,parent=clip,role="BODY"},{object=data,parent=body,role="DATA"}}
        for _,entry in ipairs(state.parents) do
            stage="RELATIVE_PREPARE_PARENT_"..entry.role
            entry.object:SetParent(body)
            state.graph[#state.graph+1]={object=entry.object,parent=body,role=entry.role}
        end
        stage="RELATIVE_PREPARE_BODY_SHOW";body:Show();data:Show();clip:Show()
        return relativePreparedGraph(state)
    end)
    state.preparing=nil
    if not okay or prepared~=true then
        -- Preparation is still detached and hidden. Revert completed parent
        -- moves rather than letting an optional compatibility setup corrupt
        -- the existing authored/public-fit presentation.
        local restored=true
        state.preparing=true
        for _,entry in ipairs(state.parents) do
            local actual,known=S:Public(entry.object.GetParent,nil,entry.object)
            if known~="KNOWN" then restored=false
            elseif actual==body then
                local done=pcall(entry.object.SetParent,entry.object,entry.parent)
                local parent,access=S:Public(entry.object.GetParent,nil,entry.object)
                restored=done and access=="KNOWN" and parent==entry.parent and restored
            elseif actual~=entry.parent then restored=false end
        end
        pcall(clip.Hide,clip);state.preparing=nil
        v.relativePreparationUnsafe=not restored
        v.relativePreparationFailure=okay and why or stage.."_CALL_FAILED"
        return
    end
    state.expectedParents={}
    for _,entry in ipairs(state.graph) do state.expectedParents[entry.object]=entry.parent end
    state.prepared=true;state.invalidated=nil;v.relativeSource=state
end
local function relativeWrite(v,state,current,object,key,...)
    local role=state.roles[object] or "BODY"
    local stage="RELATIVE_"..role.."_"..key:upper()
    local function fail(reason) state.failure=stage.."_"..reason;return false end
    if not current() or v.relativeSource~=state or state.invalidated then return fail("CUSTODY_LOST") end
    if not relativeObject(object) then return fail("TARGET_UNAVAILABLE") end
    local fn=object[key];if type(fn)~="function" then return fail("METHOD_UNAVAILABLE") end
    local watched=state.methods[object] and state.methods[object][key]
    if watched and fn~=watched then return fail("METHOD_CHANGED") end
    state.expected={object=object,key=key,n=select("#",...),args={...}}
    local okay,result=pcall(fn,object,...)
    state.expected=nil
    if not okay then return fail("CALL_FAILED") end
    if not S:Readable(result) or result==false then return fail("SUBMISSION_UNCONFIRMED") end
    if not current() or v.relativeSource~=state or state.invalidated or object[key]~=fn then return fail("CUSTODY_LOST") end
    if not relativeObject(object) then return fail("TARGET_CHANGED") end
    return true
end
layoutRelativeBody=function(v,cfg)
    local state=v.relativeSource;if not state or not v.relativeLayout then return false end
    local body,data=state.body,state.data
    local nameSize=v.relativeInside and math.min(cfg.nameSize or 12,9) or (cfg.nameSize or 12)
    local numberSize=v.relativeInside and 7 or 9
    v.relativeNameSize=nameSize
    local function point(object,...)
        object:ClearAllPoints();object:SetPoint(...)
    end
    point(v.level,"TOPLEFT",body,"TOPLEFT",4,0);v.level:SetPoint("BOTTOMLEFT",body,"LEFT",4,0);v.level:SetWidth(25)
    point(v.separator,"TOPLEFT",body,"TOPLEFT",30,0);v.separator:SetPoint("BOTTOMLEFT",body,"LEFT",30,0);v.separator:SetWidth(8)
    point(v.name,"TOPLEFT",body,"TOPLEFT",40,0);v.name:SetPoint("BOTTOMRIGHT",body,"RIGHT",-3,0)
    M.Visual:PlainName(v.name,nameSize);M.Visual:PlainName(v.level,numberSize);M.Visual:PlainName(v.separator,numberSize)
    -- Compact native footprints cannot promise three readable text rows.
    -- Keep the identity plus thin health/resource tracks; numeric percentages
    -- are deliberately omitted, not squeezed into unknown quarter-heights.
    local reserve=4
    point(v.health,"TOPLEFT",data,"TOPLEFT",4,0)
    v.health:SetPoint("BOTTOMRIGHT",data,v.powerAbsent and "BOTTOMRIGHT" or "RIGHT",-reserve,0)
    point(v.power,"TOPLEFT",data,"LEFT",4,0);v.power:SetPoint("BOTTOMRIGHT",data,"BOTTOMRIGHT",-reserve,0)
    point(v.hp,"TOPRIGHT",data,"TOPRIGHT",-3,0)
    v.hp:SetPoint("BOTTOMRIGHT",data,v.powerAbsent and "BOTTOMRIGHT" or "RIGHT",-3,0);v.hp:SetWidth(30)
    point(v.pp,"TOPRIGHT",data,"RIGHT",-3,0);v.pp:SetPoint("BOTTOMRIGHT",data,"BOTTOMRIGHT",-3,0);v.pp:SetWidth(30)
    M.Visual:PlainName(v.hp,numberSize);M.Visual:PlainName(v.pp,numberSize)
    v.hp:Hide();v.pp:Hide()
    v.nameFitStatus="ENGINE_CONSTRAINED_TRUNCATION";v.metadataReady=nil
    return true
end
function V:PreparedBodyReady(v)
    if v.relativePreparationUnsafe or v.relativeResetPending then return false,"OWNED_BODY_PREPARATION_RESTORE_PENDING" end
    local state=v.relativeSource
    if state and not relativeCurrent(v,state) then return false,"OWNED_BODY_PREPARATION_CHANGED" end
    return true
end
function V:NativeAnchorsCurrent(v,nativeReceipt)
    local state=v.relativeSource;local receipt=state and state.receipt
    return receipt and v.relativeLayout and receipt.native==nativeReceipt and receipt.generation==v.generation
        and receipt.profile==M.profile and receipt.config==M:ModuleConfig("Nameplates") and receipt.serial==state.serial
        and relativeCurrent(v,state) or false
end
function V:FitNativeAnchors(v,parent,nativeReceipt,cfg,current)
    local state=v.relativeSource
    if not state then return false,v.relativePreparationFailure or "RELATIVE_BODY_CAPABILITY_UNAVAILABLE" end
    if not current() then return false,"RELATIVE_BODY_CUSTODY_LOST" end
    if self:NativeAnchorsCurrent(v,nativeReceipt) then return true end
    if not relativeCurrent(v,state) then return false,"RELATIVE_BODY_CUSTODY_LOST" end
    state.receipt=nil;state.writing=true;state.failure=nil
    v.relativeLayout=true
    local stage="RELATIVE_ENVELOPE_SUBMIT"
    local okay,result=pcall(function()
        local function write(object,key,...) return relativeWrite(v,state,current,object,key,...) end
        if not write(v.frame,"SetScale",1) or not write(v.frame,"ClearAllPoints") then return false end
        for _,point in ipairs(nativeReceipt.points) do
            stage="RELATIVE_ENVELOPE_"..point.point
            if not write(v.frame,"SetPoint",point.point,point.relativeTo,point.relativePoint,point.offsetX,point.offsetY) then return false end
        end
        -- Body hierarchy, clipping and internal scale were built while
        -- detached. Only the outer passive envelope follows native anchors.
        v.relativeInside=nativeReceipt.points[1].relativeTo==nativeReceipt.points[2].relativeTo
        stage="RELATIVE_BODY_LAYOUT"
        if not layoutRelativeBody(v,cfg) or not current() or not relativeCurrent(v,state) then return false end
        state.receipt={native=nativeReceipt,generation=v.generation,profile=M.profile,config=cfg,parent=parent,serial=state.serial}
        stage="RELATIVE_BODY_RECEIPT"
        return self:NativeAnchorsCurrent(v,nativeReceipt)
    end)
    state.expected=nil;state.writing=nil
    if not okay or result~=true then
        state.receipt=nil
        return false,state.failure or stage..(okay and "_UNCONFIRMED" or "_CALL_FAILED")
    end
    return true
end
function V:ConcealPreparedBody(v)
    local state=v.relativeSource
    if not state or not state.escaped then return true end
    local complete=true
    -- Escaped objects are exclusively our prebuilt artwork identities. Hide
    -- their old presentation without stealing their externally changed parent.
    for object in pairs(state.escaped) do
        if not relativeObject(object) or type(object.Hide)~="function" then complete=false
        else complete=pcall(object.Hide,object) and complete end
    end
    return complete
end
function V:ResetNativeAnchors(v,current)
    local state=v.relativeSource
    if not state then return not v.relativePreparationUnsafe end
    if not relativeMethodsCurrent(v,state) then return false end
    if not v.relativeLayout and not v.relativeResetPending and not state.invalidated then return true end
    -- Cleanup ownership survives a failed halfway reset. Clearing the display
    -- mode to lay out defaults is not permission to recycle this pool slot.
    v.relativeResetPending=true
    state.receipt=nil;v.relativeInvalidated=nil;state.writing=true;state.invalidated=nil;state.failure=nil
    local function write(object,key,...)
        if state.invalidated or not current() or not relativeMethodsCurrent(v,state) or not relativeObject(object) then return false end
        local fn=object[key]
        if type(fn)~="function" then return false end
        state.expected={object=object,key=key,n=select("#",...),args={...}}
        local okay,result=pcall(fn,object,...)
        state.expected=nil
        return okay and S:Readable(result) and result~=false and not state.invalidated and current() and relativeMethodsCurrent(v,state)
    end
    local okay,result=pcall(function()
        if not current() or not relativeObject(v.frame) then return false end
        local parent,known=S:Public(v.frame.GetParent,nil,v.frame)
        if known~="KNOWN" or parent~=UIParent then return false end
        for _,entry in ipairs(state.graph) do
            local actual,access=S:Public(entry.object.GetParent,nil,entry.object)
            if access~="KNOWN" or actual~=entry.parent then return false end
        end
        if not write(state.clip,"SetClipsChildren",true) then return false end
        -- Restore the whole owned constraint graph off the native ancestry.
        -- Parent identity is checked first: a foreign reparent remains debt.
        if not write(v.frame,"SetIgnoreParentScale",false) then return false end
        for _,object in ipairs({state.clip,state.body,state.data}) do
            if not write(object,"SetIgnoreParentScale",false) or not write(object,"SetScale",1)
                or not write(object,"ClearAllPoints") then return false end
        end
        if not write(state.clip,"SetAllPoints",v.frame) or not write(state.body,"SetAllPoints",state.clip)
            or not write(state.data,"SetPoint","TOPLEFT",state.body,"LEFT",0,0)
            or not write(state.data,"SetPoint","BOTTOMRIGHT",state.body,"BOTTOMRIGHT",0,0) then return false end
        v.relativeLayout=nil;v.relativeInside=nil;v.relativeNameSize=nil
        if not write(v.frame,"ClearAllPoints") then return false end
        v.level:ClearAllPoints();v.level:SetPoint("TOPLEFT",v.frame,"TOPLEFT",7,-4);v.level:SetSize(25,15)
        v.separator:ClearAllPoints();v.separator:SetPoint("TOPLEFT",v.frame,"TOPLEFT",34,-4);v.separator:SetSize(8,15)
        v.name:ClearAllPoints();v.name:SetPoint("TOPLEFT",v.frame,"TOPLEFT",47,-4)
        M.Visual:PlainName(v.level,11);M.Visual:PlainName(v.separator,11);M.Visual:PlainName(v.hp,11);M.Visual:PlainName(v.pp,11)
        v.hp:SetSize(36,15);v.pp:SetSize(36,15)
        local cfg=M:ModuleConfig("Nameplates")
        local width=cfg.cardWidth or 240
        local height=(v.powerAbsent and 40 or 55)+math.max(16,(cfg.nameSize or 12)+4)-16
        state.layoutExpected={
            SetSize={object=v.frame,key="SetSize",n=2,args={width,55}},
            SetHeight={object=v.frame,key="SetHeight",n=1,args={height}},
            SetScale={object=v.frame,key="SetScale",n=1,args={(cfg.cardScale or 100)/100}}}
        self:Layout(v,cfg)
        state.layoutExpected=nil
        if state.invalidated or not current() or not relativeMethodsCurrent(v,state) or not relativePreparedGraph(state) then return false end
        for object,visibility in pairs(state.escaped or {}) do
            if not visibility.known or not write(object,"SetShown",visibility.shown) then return false end
        end
        for _,object in ipairs({state.clip,state.body,state.data}) do if not write(object,"Show") then return false end end
        state.escaped=nil;state.invalidated=nil;state.failure=nil;v.relativeResetPending=nil
        return true
    end)
    state.expected=nil;state.layoutExpected=nil;state.writing=nil
    if not okay or result~=true then
        state.invalidated=true
        -- A reentrant writer can move a private child after Release's first
        -- conceal pass. Do not expose that orphan while reset debt is pending.
        self:ConcealPreparedBody(v)
    end
    return okay and result==true
end
function V:EnsureAuras(v,cfg)
    if not cfg.cardAuras then return true end
    if (v.auraSetupFailures or 0)>=3 then return false end
    local count,size=debuffCount(cfg),buffSize(cfg)
    if not v.harmful then
        local enlarged=debuffSize(cfg)
        v.harmful=M.ManagedAuraRails:Create(v.upper,"HARMFUL|INCLUDE_NAME_PLATE_ONLY",{count=debuffCapacity,columns=count,upward=true,size=enlarged,gap=auraGap,
            fontSize=math.max(12,math.floor(enlarged*.53)),fontRatio=.53,fontFile=debuffFont,fontFlags="OUTLINE",compactDuration=true,durationForeground=true,stableHolder=true})
    end
    -- Blizzard performs the important-buff selection. Ordinary long buffs no
    -- longer occupy a second row below a world nameplate.
    if not v.helpful then v.helpful=M.ManagedAuraRails:Create(v.important,"HELPFUL|IMPORTANT",{count=3,size=size,gap=auraGap,stableHolder=true}) end
    -- Layout can precede lazy creation. Match the holder to its submitted
    -- group footprint on first assignment, including public in-combat plates.
    for _,rail in ipairs({v.harmful or false,v.helpful or false}) do
        if rail then
            if not S:Frame(rail.holder,true) then return false end
            rail.holder:SetSize(rail.holderWidth,rail.holderHeight)
            rail.holder:SetPoint("TOPLEFT",rail==v.harmful and v.upper or v.important,"TOPLEFT",0,0)
        end
    end
    local ready=v.harmful~=nil and v.helpful~=nil
    if not ready then v.auraSetupFailures=(v.auraSetupFailures or 0)+1 end
    return ready
end
local function methods(font,prior)
    local result={}
    for _,key in ipairs(fitMethods) do
        local ok,fn=pcall(function() return font[key] end)
        if not ok or not S:Readable(fn) or type(fn)~="function" or (prior and fn~=prior[key]) then return nil end
        result[key]=fn
    end
    return result
end
local function near(actual,wanted) return S:Number(actual) and S:Number(wanted) and math.abs(actual-wanted)<=.001 end
local function fontState(font,size,current,previous)
    if not current() or not S:Frame(font,true) or not current() then return nil end
    local bound=methods(font,previous and previous.methods)
    if not bound or not current() then return nil end
    local ok,path,actual,flags=pcall(bound.GetFont,font)
    if not current() or not ok or not S:Text(path) or path=="" or not near(actual,size) or not S:Text(flags) or flags~="" then return nil end
    if previous and (path~=previous.path or actual~=previous.actual or flags~=previous.flags) then return nil end
    return {path=path,actual=actual,flags=flags,methods=bound}
end
local function nameFit(font,name,cfg,current,previous)
    local observed=fontState(font,cfg.nameSize or 12,current,previous)
    if not observed then return "NAME_FIT_UNKNOWN" end
    local values={}
    for _,spec in ipairs({{"GetText","string"},{"GetWidth","number"},{"GetHeight","number"},{"GetUnboundedStringWidth","number"},{"GetStringHeight","number"},{"IsTruncated","boolean"}}) do
        if not current() then return "NAME_FIT_UNKNOWN" end
        local value,status=S:Public(observed.methods[spec[1]],spec[2],font)
        if status~="KNOWN" or not current() then return "NAME_FIT_UNKNOWN" end
        values[spec[1]]=value
    end
    local width,height=values.GetWidth,values.GetHeight
    if values.GetText~=name or not near(width,(cfg.cardWidth or 240)-53) or not near(height,math.max(16,(cfg.nameSize or 12)+4))
        or (previous and (width~=previous.width or height~=previous.height))
        or width<=0 or height<=0 or values.GetUnboundedStringWidth<=0 or values.GetStringHeight<=0 then return "NAME_FIT_UNKNOWN" end
    if values.IsTruncated or values.GetUnboundedStringWidth>width or values.GetStringHeight>height then return "NAME_DOES_NOT_FIT" end
    if not fontState(font,cfg.nameSize or 12,current,observed) then return "NAME_FIT_UNKNOWN" end
    local finalWidth,fw=S:Public(observed.methods.GetWidth,"number",font)
    if fw~="KNOWN" or finalWidth~=width or not current() then return "NAME_FIT_UNKNOWN" end
    local finalHeight,fh=S:Public(observed.methods.GetHeight,"number",font)
    if fh~="KNOWN" or finalHeight~=height or not current() then return "NAME_FIT_UNKNOWN" end
    observed.width=width;observed.height=height
    return "NAME_FIT_SAMPLED",observed
end
local function fitted(v,literal,cfg,detached,current)
    if #literal>1024 then return "NAME_DOES_NOT_FIT" end
    local probe=probes[v];local version=versions[v]
    local function publicProbe()
        if not current() or probes[v]~=probe or not probe or v.nameProbe~=probe.font or v.nameProbeHolder~=probe.holder then return false end
        if not S:Frame(probe.holder,true) or not S:Frame(probe.font,true) or not current() then return false end
        local holderParent,hs=S:Public(probe.holder.GetParent,nil,probe.holder)
        local fontParent,fs=S:Public(probe.font.GetParent,nil,probe.font)
        return hs=="KNOWN" and fs=="KNOWN" and holderParent==UIParent and fontParent==probe.holder and current()
    end
    local function unchanged() return versions[v]==version and current() and publicProbe() end
    if not unchanged() then return "NAME_FIT_UNKNOWN" end
    local old=receipts[v]
    local renderer
    if detached then
        local function unanchored()
            if not unchanged() then return false end
            local parent,status=S:Public(v.frame.GetParent,nil,v.frame)
            return status=="KNOWN" and parent==UIParent and unchanged()
        end
        local fit
        fit,renderer=nameFit(v.name,literal,cfg,unanchored)
        if fit~="NAME_FIT_SAMPLED" then return fit end
        probe.font:SetFont(renderer.path,cfg.nameSize or 12,"")
        if not unanchored() then return "NAME_FIT_UNKNOWN" end
    else
        if not old or old.generation~=v.generation or old.unit~=v.unit or old.profile~=M.profile or old.config~=cfg
            or old.width~=cfg.cardWidth or old.size~=cfg.nameSize or old.scale~=cfg.cardScale or not unchanged() then return "NAME_FIT_UNKNOWN" end
        -- GetFont is a public style property. No attached width/height/string
        -- metrics are read; exact observed font/method identity stays sealed.
        renderer=fontState(v.name,cfg.nameSize or 12,unchanged,old.renderer)
        if not renderer then return "NAME_FIT_UNKNOWN" end
    end
    probe.font:SetText(literal)
    if not unchanged() then return "NAME_FIT_UNKNOWN" end
    local fit,sample=nameFit(probe.font,literal,cfg,unchanged,not detached and old.probe or nil)
    if fit~="NAME_FIT_SAMPLED" then return fit end
    local shown,read=S:Public(v.name.GetText,"string",v.name)
    if read~="KNOWN" or shown~=literal or not unchanged() then return "NAME_FIT_UNKNOWN" end
    receipts[v]={unit=v.unit,generation=v.generation,profile=M.profile,config=cfg,width=cfg.cardWidth,size=cfg.nameSize,scale=cfg.cardScale,
        font=v.name,literal=literal,version=versions[v],requestedWidth=(cfg.cardWidth or 240)-53,requestedHeight=math.max(16,(cfg.nameSize or 12)+4),requestedSize=cfg.nameSize or 12,renderer=renderer,probe=sample}
    return "NAME_FIT_SAMPLED"
end
function V:FitCurrent(v)
    local r=receipts[v]
    if not r or checking[v] then return false end
    local function current()
        local cfg=M:ModuleConfig("Nameplates")
        return receipts[v]==r and versions[v]==r.version and M.NameplateCard==V and M.Safety==S
            and v.name==r.font and v.unit==r.unit and v.generation==r.generation and M.profile==r.profile
            and cfg==r.config and cfg.cardWidth==r.width and cfg.nameSize==r.size and cfg.cardScale==r.scale
            and not M.state.safe and not v.pending and not v.acquireReleaseRequested
    end
    if not current() then return false end
    checking[v]=true
    local ok,valid=pcall(function()
        -- Public style and text only. Never sample attached name dimensions.
        if not fontState(v.name,r.requestedSize,current,r.renderer) then return false end
        local text,status=S:Public(r.renderer.methods.GetText,"string",v.name)
        return status=="KNOWN" and text==r.literal and current()
    end)
    checking[v]=nil
    return ok and valid==true and current()
end
function V:Metadata(v,detached)
    local unit,generation,profile=v.unit,v.generation,M.profile
    local cfg=M:ModuleConfig("Nameplates")
    local function current()
        return v.unit==unit and v.generation==generation and not v.pending and not v.acquireReleaseRequested
            and M.NameplateCard==V and M.Safety==S and M.profile==profile and M:ModuleConfig("Nameplates")==cfg and not M.state.safe
    end
    -- Native providers may reenter removal and assignment. Gather their results
    -- before painting, then commit only to the generation that requested them.
    local name,known=S:Public(UnitName,"string",unit)
    local color=(M.Visual.NameplateNameColor or M.Visual.ClassColor)(M.Visual,unit)
    local level,status=S:Public(UnitLevel,"number",unit)
    local levelColor=M.Visual.NameplateLevelColor and M.Visual:NameplateLevelColor(unit,level) or M.Visual.level
    local selected,access=S:Public(UnitIsUnit,"boolean",unit,"target")
    local combat=S:InCombat()
    if not current() then return false end
    local publicName=known=="KNOWN" and name~=""
    -- FontStrings interpret pipe escapes. Preserve literal text as UnitState
    -- does, so an embedded color/icon sequence cannot override the class RGB.
    local literal=publicName and name:gsub("|","||") or ""
    if detached and not combat then M.Visual:PlainName(v.name,cfg.nameSize) end
    if not current() then return false end
    v.name:SetTextColor(color[1],color[2],color[3],1)
    if not current() then return false end
    v.name:SetText(literal)
    if not current() then return false end
    local fit=publicName and fitted(v,literal,cfg,detached==true,current) or "NAME_UNAVAILABLE"
    if not current() then return false end
    v.level:SetText(status=="KNOWN" and level>0 and tostring(level) or "")
    if not current() then return false end
    v.level:SetTextColor(levelColor[1],levelColor[2],levelColor[3],1)
    if not current() then return false end
    v.separator:SetText(status=="KNOWN" and level>0 and "|" or "")
    if not current() then return false end
    v.selection:SetText(access=="KNOWN" and selected and ">" or "")
    if not current() then return false end
    if fit=="NAME_FIT_SAMPLED" and not self:FitCurrent(v) then fit="NAME_FIT_UNKNOWN" end
    if not current() then return false end
    v.nameFitStatus=fit
    v.selectionKnown=access=="KNOWN"
    v.metadataReady=v.selectionKnown and fit=="NAME_FIT_SAMPLED"
    return v.metadataReady
end
local function percent(font,fn,unit,...)
    font:SetText("")
    if type(fn)~="function" or type(font.SetFormattedText)~="function" then return end
    local ok,value=pcall(fn,unit,...)
    if not ok or (S:Readable(value) and value==nil) then return end
    if not pcall(font.SetFormattedText,font,"%.0f%%",value) then font:SetText("") end
end
function V:Health(v)
    local ok=pcall(function() v.health:SetMinMaxValues(0,UnitHealthMax(v.unit));v.health:SetValue(UnitHealth(v.unit)) end)
    local c=M.Visual.health;M.UI:BeamColor(v.health,c[1],c[2],c[3],ok and 1 or 0)
    if M:ModuleConfig("Nameplates").cardPercent and CurveConstants and CurveConstants.ScaleTo100 then percent(v.hp,UnitHealthPercent,v.unit,true,CurveConstants.ScaleTo100) else v.hp:SetText("") end
    v.healthOK=ok;return ok
end
function V:Power(v,metadata)
    if metadata then
        local kind,status=S:Public(UnitPowerType,"number",v.unit)
        v.powerType=status=="KNOWN" and kind or nil
        local has,access=S:Public(UnitHasPowerType,"boolean",v.unit,kind)
        v.powerAbsent=v.powerType==nil or (access=="KNOWN" and has==false)
        if not S:InCombat() and kind~=nil then
            local maximum,ms=S:Public(UnitPowerMax,"number",v.unit,kind)
            if ms=="KNOWN" and maximum==0 then v.powerAbsent=true end
        end
        local cfg=M:ModuleConfig("Nameplates")
        -- Our ordinary passive geometry only; no native hit-region resizing.
        -- Geometry is prepared before lockdown. A power-type update in combat
        -- is a data repaint, never a SetSize/SetPoint call on a native ancestry.
        if not S:InCombat() then
            layoutBody(v,cfg);v.power:SetShown(not v.powerAbsent);v.pp:SetShown(not v.relativeLayout and not v.powerAbsent and cfg.cardPercent);self:TextBackings(v,cfg.cardPercent==true)
            v.powerLayoutPending=nil
        else v.powerLayoutPending=true end
        local color=M.Visual.mana
        if status~="KNOWN" then color=M.Visual.neutral
        elseif kind~=0 then
            local native=S:Field(PowerBarColor,kind)
            local r,g,b=S:Field(native,"r"),S:Field(native,"g"),S:Field(native,"b")
            color=S:Number(r) and S:Number(g) and S:Number(b) and {r,g,b} or M.Visual.neutral
        end
        v.powerColor=color;v.pp:SetTextColor(color[1],color[2],color[3],1)
    end
    if v.powerAbsent then
        v.pp:SetText("")
        local color=v.powerColor or M.Visual.neutral
        M.UI:BeamColor(v.power,color[1],color[2],color[3],0)
        return true
    end
    local ok=pcall(function() v.power:SetMinMaxValues(0,UnitPowerMax(v.unit,v.powerType));v.power:SetValue(UnitPower(v.unit,v.powerType)) end)
    local c=v.powerColor or M.Visual.neutral;M.UI:BeamColor(v.power,c[1],c[2],c[3],ok and 1 or 0)
    if M:ModuleConfig("Nameplates").cardPercent and CurveConstants and CurveConstants.ScaleTo100 then percent(v.pp,UnitPowerPercent,v.unit,v.powerType,false,CurveConstants.ScaleTo100) else v.pp:SetText("") end
    return ok
end
function V:SetCastVisible(v,shown)
    v.castSequence=(v.castSequence or 0)+1
    local sequence,generation=v.castSequence,v.generation
    local function current() return v.castSequence==sequence and v.generation==generation end
    local function cleared()
        if not current() then return end
        v.castIcon:SetTexture(nil);v.castName:SetText("");M.DurationDisplay:Clear(v,v.castClock)
        if v.castBar.ClearTimerDuration then pcall(v.castBar.ClearTimerDuration,v.castBar) end
    end
    if M.Effects and M.Effects.Transition and M.Effects:Transition(V,v.cast,shown,{guard=current,onFinished=not shown and cleared or nil}) then return true end
    if shown then v.cast:SetAlpha(1);v.cast:Show() else v.cast:Hide();cleared() end
    return false
end
function V:ClearCast(v,immediate)
    -- Native duration/icon sinks retain the outgoing row only through its fade.
    -- Reuse invalidates the callback before a successor can inherit old content.
    local generation=v.generation
    if M.NameplateCards then M.NameplateCards:ReturnCast(v) end
    if v.generation~=generation then return end
    v.castKind=nil
    if immediate then
        v.castSequence=(v.castSequence or 0)+1
        if M.Effects and M.Effects.CancelTransition then M.Effects:CancelTransition(V,v.cast,false) end
        v.cast:Hide();v.castIcon:SetTexture(nil);v.castName:SetText("");M.DurationDisplay:Clear(v,v.castClock)
        if v.castBar.ClearTimerDuration then pcall(v.castBar.ClearTimerDuration,v.castBar) end
    else self:SetCastVisible(v,false) end
    -- Important buffs have a fixed side holder; ending a cast does not move
    -- any aura geometry and performs no anchor mutation during lockdown.
end
function V:Cast(v,kind)
    local cfg=M:ModuleConfig("Nameplates")
    if kind=="channel" and M.DurationDisplay:IsEmpowered(v.unit)==true then v.empower=true end
    if not cfg.cardCast or v.empower then self:ClearCast(v);return false end
    local fn=kind=="channel" and UnitChannelDuration or UnitCastingDuration
    if kind=="channel" and type(UnitChannelDuration)~="function" then self:ClearCast(v);return false end
    if type(fn)~="function" or type(v.castBar.SetTimerDuration)~="function" then self:ClearCast(v);return false end
    local ok,d=pcall(fn,v.unit)
    if not ok or (S:Readable(d) and d==nil) then self:ClearCast(v);return false end
    local directions=Enum and Enum.StatusBarTimerDirection
    local direction=kind=="channel" and directions and directions.RemainingTime or directions and directions.ElapsedTime
    if kind=="channel" and (not directions or directions.RemainingTime==nil) then self:ClearCast(v);return false end
    if not pcall(v.castBar.SetTimerDuration,v.castBar,d,Enum and Enum.StatusBarInterpolation and Enum.StatusBarInterpolation.Immediate,direction) then self:ClearCast(v);return false end
    v.castKind=kind;self:SetCastVisible(v,true)
    local info
    if kind=="channel" then info=UnitChannelInfo else info=UnitCastingInfo end
    local good,name,_,icon=false,nil,nil,nil
    if type(info)=="function" then good,name,_,icon=pcall(info,v.unit) end
    v.castName:SetText(good and S:Text(name) and name or kind=="channel" and "Channeling" or "Casting")
    v.castIcon:SetTexture(good and (S:Number(icon) or S:Text(icon)) and icon or nil)
    M.DurationDisplay:Bind(v,v.castClock,d,kind)
    return true
end
function V:Refresh(v,metadata)
    if metadata then self:Metadata(v) end
    return self:Health(v),self:Power(v,metadata)
end
function V:Clear(v)
    revoke(v)
    self:ClearCast(v,true);v.frame:Hide();v.unit=nil;v.empower=false;v.generation=v.generation+1
    v.metadataReady=nil;v.selectionKnown=nil;v.nameFitStatus=nil
    v.name:SetText("");v.level:SetText("");v.separator:SetText("");v.hp:SetText("");v.pp:SetText("");v.selection:SetText("");if v.focus then v.focus:SetText("") end
    if v.rangeTag then v.rangeTag:SetText("") end
    if v.targetEdge then v.targetEdge:Hide() end
    if v.focusEdge then v.focusEdge:Hide() end
    for _,edge in ipairs(v.aggroEdges or {}) do edge:Hide() end
    if v.status then v.status:SetText("") end
    v.aggro=nil
    v.selectedTarget=nil;v.selectedFocus=nil;v.admitted=nil;v.visibleDemand=nil;v.visibilityStatus=nil;v.castDemand=nil
    v.rangeStatus=nil;v.rangeReason=nil;v.presentationScale=nil
    M.ManagedAuraRails:Clear(v.harmful);M.ManagedAuraRails:Clear(v.helpful)
end
