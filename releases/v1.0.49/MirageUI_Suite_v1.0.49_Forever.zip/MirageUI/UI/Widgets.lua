local _, M = ...
M.UI={fonts={},backdrops=setmetatable({},{__mode="k"}),buttons=setmetatable({},{__mode="k"}),sliders=setmetatable({},{__mode="k"})}
local U=M.UI
local white="Interface\\Buttons\\WHITE8X8"
local media="Interface\\AddOns\\MirageUI\\Media\\"
local function crisp(texture)
    if type(texture.SetSnapToPixelGrid)=="function" then pcall(texture.SetSnapToPixelGrid,texture,true) end
    if type(texture.SetTexelSnappingBias)=="function" then pcall(texture.SetTexelSnappingBias,texture,0) end
end
local function panelArt(frame,quiet)
    -- The same authored artwork/tints as Cursor Companion. Regions are owned,
    -- created once, and never attached to protected or native control trees.
    if not quiet and not frame.miragePanelShine and type(frame.CreateTexture)=="function" then
        local shine=frame:CreateTexture(nil,"BACKGROUND");shine:SetAllPoints(frame);shine:SetTexture(media.."PanelShine.tga")
        shine:SetVertexColor(.82,.53,.29,.17);crisp(shine);frame.miragePanelShine=shine
        local glass=frame:CreateTexture(nil,"BACKGROUND");glass:SetAllPoints(frame);glass:SetTexture(media.."PanelGlass.tga")
        glass:SetVertexColor(.72,.53,.33,.23);crisp(glass);frame.miragePanelGlass=glass
        local line=frame:CreateTexture(nil,"BORDER");line:SetPoint("TOPLEFT",frame,"TOPLEFT",1,-1);line:SetPoint("TOPRIGHT",frame,"TOPRIGHT",-1,-1)
        line:SetHeight(2);line:SetColorTexture(.91,.55,.18,.70);crisp(line);frame.miragePanelLine=line
    end
    for _,region in pairs({frame.miragePanelShine,frame.miragePanelGlass,frame.miragePanelLine}) do region:SetShown(not quiet) end
end
function U:Backdrop(frame,quiet)
    if frame.SetBackdrop then
        self.backdrops[frame]=quiet and "panel" or "background"
        frame:SetBackdrop({bgFile=white,edgeFile=white,edgeSize=1})
        frame:SetBackdropColor(unpack(quiet and M.Theme.panel or M.Theme.background))
        frame:SetBackdropBorderColor(unpack(M.Theme.edge))
        panelArt(frame,quiet)
    end
end
local roles={text="text",heading="accent",accent="accent",secondary="secondary",muted="muted"}
function U:SetTextRole(font,role)
    if not roles[role] then return false end
    font.mirageTextRole=role
    if not font.mirageSemanticColor then font:SetTextColor(unpack(M.Theme[roles[role]])) end
    return true
end
-- Cosmetics only: native state changes happen first and retain their own errors
-- and return values. A nested paint retires the old pass, never nesting setters.
local function paintButton(b)
    b.miragePaintGeneration=(b.miragePaintGeneration or 0)+1
    if b.miragePainting then return false end
    b.miragePainting=true
    local done=false
    for attempt=1,2 do
        local generation=b.miragePaintGeneration
        local ok,value=pcall(function()
            local enabled=b:IsEnabled()==true
            local hovered,selected=b.mirageHovered==true,b.selected==true
            local theme,label,gloss,stripe=M.Theme,b.label,b.mirageGloss,b.mirageAccent
            local background=enabled and ((hovered or selected) and theme.hover or theme.panel) or theme.disabledPanel or theme.panel
            local border=enabled and (hovered or selected) and theme.accent or theme.edge
            if not enabled then border=theme.disabledEdge or theme.edge end
            local text=enabled and (theme[b.mirageLabelRole or "text"] or theme.text) or theme.muted
            local function current()
                return b.miragePaintGeneration==generation and b.label==label and b.mirageGloss==gloss and b.mirageAccent==stripe and M.Theme==theme and
                    b.mirageHovered==hovered and (b.selected==true)==selected and
                    (enabled and ((hovered or selected) and theme.hover or theme.panel) or theme.disabledPanel or theme.panel)==background and
                    (not enabled and (theme.disabledEdge or theme.edge) or (hovered or selected) and theme.accent or theme.edge)==border and
                    (enabled and (theme[b.mirageLabelRole or "text"] or theme.text) or theme.muted)==text
            end
            if current() then b:SetBackdropColor(unpack(background)) end
            if current() then b:SetBackdropBorderColor(unpack(border)) end
            if current() then label:SetTextColor(unpack(text)) end
            if current() and stripe then stripe:SetShown(enabled and (hovered or selected)) end
            if current() and gloss then gloss:SetVertexColor(.96,.79,.36,enabled and (hovered and .58 or selected and .45 or .22) or .1) end
            return current()
        end)
        if ok and value==true then done=true;break end
        -- A state callback can throw after retiring this pass. Give its newer
        -- state one bounded cosmetic repair, without replaying any native action.
        if not ok and b.miragePaintGeneration==generation then break end
    end
    b.miragePainting=nil
    return done
end
function U:PaintButton(button)
    if not self.buttons[button] then return false end
    return paintButton(button)
end
local function afterButtonState(button,...)
    paintButton(button)
    return ...
end
function U:Text(parent,text,x,y,size,width)
    local fs=parent:CreateFontString(nil,"OVERLAY")
    fs:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",(size or 12)*(M.profile and M.profile.textScale or 1),"")
    self:SetTextRole(fs,"text");fs:SetJustifyH("LEFT");fs:SetJustifyV("TOP")
    fs:SetPoint("TOPLEFT",x or 0,y or 0);if width then fs:SetWidth(width) end
    M.UI.fonts[#M.UI.fonts+1]={font=fs,size=size or 12};fs:SetText(text or "");return fs
end
function U:Scroll(parent)
 local sc=CreateFrame("ScrollFrame",nil,parent)
 sc:EnableMouseWheel(true)
 local bar=CreateFrame("Slider",nil,parent);sc.scrollBar=bar
 bar:SetOrientation("VERTICAL")
 local track=bar:CreateTexture(nil,"BACKGROUND")
 track:SetColorTexture(.20,.20,.20,1);track:SetWidth(3);track:SetPoint("TOP");track:SetPoint("BOTTOM")
 bar:SetThumbTexture(media.."SliderThumb.tga")
 local thumb=bar:GetThumbTexture();thumb:SetSize(8,25);thumb:SetVertexColor(.96,.79,.36,1);crisp(thumb)
 bar:SetWidth(8);bar:SetPoint("TOPLEFT",sc,"TOPRIGHT",5,0);bar:SetPoint("BOTTOMLEFT",sc,"BOTTOMRIGHT",5,0)
 bar:SetMinMaxValues(0,0);bar:SetValueStep(1);bar:Hide()
 sc.range=0
 bar:SetScript("OnValueChanged",function(_,v) if not sc.syncing then sc:SetVerticalScroll(v) end end)
 sc:SetScript("OnScrollRangeChanged",function(_,_,yrange)
  sc.range=math.max(0,yrange or 0);bar:SetMinMaxValues(0,sc.range);bar:SetShown(sc.range>1 and sc:IsShown())
  if sc:GetVerticalScroll()>sc.range then sc:SetVerticalScroll(sc.range) end
 end)
 sc:SetScript("OnVerticalScroll",function(_,v) sc.syncing=true;bar:SetValue(v);sc.syncing=false end)
 sc:SetScript("OnMouseWheel",function(_,delta)
  sc:SetVerticalScroll(math.max(0,math.min(sc.range,sc:GetVerticalScroll()-delta*32)))
 end)
 sc:SetScript("OnHide",function() bar:Hide() end)
 sc:SetScript("OnShow",function() bar:SetShown(sc.range>1) end)
 return sc
end
function U:Button(parent,text,x,y,width,callback)
    local b=CreateFrame("Button",nil,parent,"BackdropTemplate")
    b:SetSize(width or 150,28);b:SetPoint("TOPLEFT",x,y);self:Backdrop(b,true)
    b.label=self:Text(b,text,8,-7,12,(width or 150)-16);b.label:SetJustifyH("CENTER")
    if type(b.CreateTexture)=="function" then
        local gloss=b:CreateTexture(nil,"BORDER");gloss:SetAllPoints(b);gloss:SetTexture(media.."ButtonGloss.tga")
        gloss:SetVertexColor(.96,.79,.36,.22);crisp(gloss);b.mirageGloss=gloss
        local stripe=b:CreateTexture(nil,"OVERLAY");stripe:SetColorTexture(.91,.55,.18,1)
        stripe:SetPoint("TOPLEFT",b,"TOPLEFT",1,-3);stripe:SetPoint("BOTTOMLEFT",b,"BOTTOMLEFT",1,3);stripe:SetWidth(2);stripe:Hide();crisp(stripe);b.mirageAccent=stripe
    end
    function b:SetText(value) self.label:SetText(value) end
    self.buttons[b]=true;b.mirageHovered=false;b.label.mirageButtonText=true
    local enable,disable,setEnabled=b.Enable,b.Disable,b.SetEnabled
    function b:Enable(...) return afterButtonState(self,enable(self,...)) end
    function b:Disable(...) return afterButtonState(self,disable(self,...)) end
    function b:SetEnabled(...) return afterButtonState(self,setEnabled(self,...)) end
    b:SetScript("OnEnter",function(self) self.mirageHovered=true;paintButton(self) end)
    b:SetScript("OnLeave",function(self) self.mirageHovered=false;paintButton(self) end)
    b:HookScript("OnHide",function(self)
        -- A caller's hide script may already have shown/reused the same control.
        local generation=self.miragePaintGeneration
        local ok,visible=pcall(self.IsVisible,self)
        if self.miragePaintGeneration~=generation or not ok or type(visible)~="boolean" or visible~=false then return end
        self.mirageHovered=false;paintButton(self)
    end)
    b:SetScript("OnClick",function(self,button) if callback then callback(self,button) end end)
    return b
end
function U:Check(parent,text,x,y,get,set,width)
    local b=self:Button(parent,"",x,y,width or 390,nil)
    -- Refresh is explicitly called by the host after changing a draft.
    function b:Refresh() self:SetText((get() and "[x] " or "[ ] ")..text) end
    b:SetScript("OnClick",function() set(not get());b:Refresh() end);b:Refresh();return b
end
function U:Edit(parent,x,y,width,text,onCommit)
    local e=CreateFrame("EditBox",nil,parent,"BackdropTemplate");e:SetSize(width,28);e:SetPoint("TOPLEFT",x,y)
    self:Backdrop(e,true);self.backdrops[e]="input";e:SetBackdropColor(unpack(M.Theme.input or {.028,.028,.030,.95}));e:SetAutoFocus(false);e:SetMaxLetters(160)
    e:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",12*(M.profile and M.profile.textScale or 1),"");self.fonts[#self.fonts+1]={font=e,size=12,fontOnly=true};e:SetTextInsets(8,8,4,4);e:SetText(text or "")
    e:SetScript("OnEnterPressed",function(self) if onCommit then onCommit(self:GetText()) end;self:ClearFocus() end)
    e:SetScript("OnEscapePressed",function(self) self:ClearFocus() end)
    return e
end
local function sliderPlan(width,scale)
    if type(width)~="number" or width~=width or width==math.huge or type(scale)~="number" or scale~=scale or scale<=0 or scale==math.huge then return end
    local reserve=16+49*math.max(1,scale)
    if width<=reserve+13 then return end
    return reserve,width-reserve-5,width-reserve-13
end
function U:Slider(parent,label,x,y,width,value,lo,hi,step,onChange)
    local reserve,labelWidth,trackWidth=sliderPlan(width,M.profile and M.profile.textScale or 1)
    if not reserve then return nil,"SLIDER_SPACE_UNAVAILABLE" end
    local f=CreateFrame("Frame",nil,parent);f:SetSize(width,55);f:SetPoint("TOPLEFT",x,y)
    f.label=self:Text(f,label,0,0,12,labelWidth)
    local edit=self:Edit(f,width-reserve,4,reserve,tostring(value))
    local s=CreateFrame("Slider",nil,f);s:SetPoint("TOPLEFT",0,-26);s:SetSize(trackWidth,15);s:SetOrientation("HORIZONTAL")
    s:SetMinMaxValues(lo,hi);s:SetValueStep(step);if s.SetObeyStepOnDrag then s:SetObeyStepOnDrag(true) end
    local track=s:CreateTexture(nil,"BACKGROUND");track:SetPoint("LEFT",0,0);track:SetPoint("RIGHT",0,0);track:SetHeight(3);track:SetColorTexture(.20,.20,.20,1)
    s:SetThumbTexture(media.."SliderThumb.tga");local thumb=s:GetThumbTexture();thumb:SetSize(12,15);thumb:SetVertexColor(unpack(M.Theme.secondary or M.Theme.accent));crisp(thumb)
    local busy=false
    local lastText=edit:GetText()
    local function apply(v)
        v=tonumber(v);if not M.Safety:Number(v) then return end
        v=math.max(lo,math.min(hi,math.floor(v/step+.5)*step))
        busy=true;s:SetValue(v);lastText=string.format("%.2f",v);edit:SetText(lastText);busy=false
        onChange(v)
    end
    s:SetValue(value);s:SetScript("OnValueChanged",function(_,v) if not busy then apply(v) end end)
    edit:SetScript("OnEnterPressed",function(self) apply(self:GetText());self:ClearFocus() end)
    f.slider=s;f.edit=edit;f.setValue=function(v,requestCurrent)
        if not requestCurrent then busy=true;s:SetValue(v);lastText=string.format("%.2f",v);edit:SetText(lastText);busy=false;return end
        local function current() local ok,value=pcall(requestCurrent);return ok and value==true end
        if not current() then return false end
        busy=true
        local ok,result=pcall(function()
            s:SetValue(v);if not current() then return false end
            local text=string.format("%.2f",v);edit:SetText(text);if not current() then return false end
            lastText=text;return true
        end)
        busy=false
        return ok and result==true
    end
    function f:Pending() return edit:GetText()~=lastText end
    function f:CaptureInput() return {text=edit:GetText(),last=lastText,value=s:GetValue()} end
    function f:RestoreInput(state)
        busy=true;s:SetValue(state.value);edit:SetText(state.text);lastText=state.last;busy=false
    end
    function f:Validate()
        if not self:Pending() or M.Safety:Number(tonumber(edit:GetText())) then return true end
        return false,"Enter a valid number for "..label.."."
    end
    function f:Commit()
        local entered=edit:GetText()
        -- Only a pending user edit belongs to this flush. An unchanged widget
        -- must not overwrite a value staged by another control or preset.
        if entered==lastText then return true end
        local valid,why=self:Validate();if not valid then return false,why end
        apply(entered);return true
    end
    self.sliders[f]=true;f.label.mirageSliderOwner=f;edit.mirageSliderOwner=f
    function f:Relayout(w,requestCurrent)
        local profile=M.profile;local scale=profile and profile.textScale or 1
        if not sliderPlan(w,scale) then return false,"SLIDER_SPACE_UNAVAILABLE" end
        self.layoutGeneration=(self.layoutGeneration or 0)+1
        local requestGeneration=self.layoutGeneration
        self.layoutWidth=w;self.layoutProfile=profile;self.layoutScale=scale;self.layoutCurrent=requestCurrent
        if self.relayoutActive then return false end
        self.relayoutActive=true
        local done=false
        for attempt=1,2 do
            local generation,width,owner,fontScale,guard=self.layoutGeneration,self.layoutWidth,self.layoutProfile,self.layoutScale,self.layoutCurrent
            local title=self.label
            local reserve,labelWidth,trackWidth=sliderPlan(width,fontScale)
            local function current()
                return M.UI==U and U.sliders[self] and self.layoutGeneration==generation and self.label==title and self.edit==edit and self.slider==s and title.mirageSliderOwner==self and edit.mirageSliderOwner==self and
                    M.profile==owner and (owner and owner.textScale or 1)==fontScale and (not guard or guard())
            end
            local function call(widget,method,...)
                if not current() then error("Retired slider layout",0) end
                widget[method](widget,...)
                if not current() then error("Retired slider layout",0) end
            end
            local ok=pcall(function()
                if not reserve or not current() then error("Slider layout unavailable",0) end
                call(self,"SetWidth",width);call(title,"SetWidth",labelWidth)
                call(edit,"SetWidth",reserve);call(edit,"ClearAllPoints");call(edit,"SetPoint","TOPLEFT",self,"TOPLEFT",width-reserve,4)
                call(s,"SetWidth",trackWidth)
            end)
            if ok and current() then done=true;break end
            if self.layoutGeneration==generation then break end
        end
        self.relayoutActive=nil;self.layoutWidth=nil;self.layoutProfile=nil;self.layoutScale=nil;self.layoutCurrent=nil
        done=done and self.layoutGeneration==requestGeneration
        return done,not done and "SLIDER_SPACE_UNAVAILABLE" or nil
    end
    return f
end
function U:Panel(name,title,width,height)
    local f=CreateFrame("Frame",name,UIParent,"BackdropTemplate")
    f:SetSize(math.min(width,UIParent:GetWidth()-30),math.min(height,UIParent:GetHeight()-30));f:SetPoint("CENTER")
    self:Backdrop(f);f:SetFrameStrata("DIALOG");f:SetClampedToScreen(true);f:EnableMouse(true);f:SetMovable(true)
    local heading=self:Text(f,title,22,-19,18,width-80);self:SetTextRole(heading,"heading");f.heading=heading
    local drag=CreateFrame("Frame",nil,f);drag:SetPoint("TOPLEFT",0,0);drag:SetPoint("TOPRIGHT",-50,0);drag:SetHeight(42)
    drag:EnableMouse(true);drag:RegisterForDrag("LeftButton");drag:SetScript("OnDragStart",function() f:StartMoving() end);drag:SetScript("OnDragStop",function() f:StopMovingOrSizing() end)
    f.closeButton=self:Button(f,"x",f:GetWidth()-42,-12,28,function() f:Hide() end)
    if name and UISpecialFrames then table.insert(UISpecialFrames,name) end
    -- Choices are parented to UIParent, not their opener. A new owned dialog
    -- must dismiss them rather than leave an actionable old popup above it.
    f:HookScript("OnShow",function()
        local D=M.DialogNavigation
        if D then return D:PanelShown(f,function() U:CloseChoices() end) end
        U:CloseChoices()
    end)
    f:HookScript("OnHide",function() if M.DialogNavigation then M.DialogNavigation:Hidden(f,true) end end)
    f:Hide();return f
end
function U:Card(parent,width,height)
    local f=CreateFrame("Frame",nil,parent or UIParent,"BackdropTemplate");f:SetSize(width,height);self:Backdrop(f,true)
    M.Safety:Passive(f);return f
end
function U:Bar(parent,x,y,width,height,r,g,b)
    local s=CreateFrame("StatusBar",nil,parent);s:SetPoint("TOPLEFT",x,y);s:SetSize(width,height)
    s:SetStatusBarTexture(white);s:SetStatusBarColor(r or .45,g or .80,b or .78)
    local bg=s:CreateTexture(nil,"BACKGROUND");bg:SetAllPoints();bg:SetColorTexture(.07,.12,.14,.9)
    s.mirageTrack=bg
    return s
end
-- A native fill rectangle supplies the current endpoint. Thin owned axes and
-- a perpendicular marker follow that rectangle without reading health, power,
-- percentages or attached dimensions. No size/value arithmetic touches payloads.
function U:Beam(bar)
    if bar.mirageBeam then return bar.mirageBeam end
    if M.Safety:InCombat() or type(bar.GetStatusBarTexture)~="function" then return nil end
    local ok,fill=pcall(bar.GetStatusBarTexture,bar)
    if not ok or not M.Safety:Frame(fill,false) or type(fill.SetAlpha)~="function" then return nil end
    local beam=bar:CreateTexture(nil,"ARTWORK")
    local marker=bar:CreateTexture(nil,"OVERLAY")
    local axis=bar:CreateTexture(nil,"BORDER")
    local built=pcall(function()
        beam:SetTexture(white);beam:SetPoint("LEFT",fill,"LEFT",0,0);beam:SetPoint("RIGHT",fill,"RIGHT",0,0);beam:SetHeight(2)
        beam:SetVertexColor(1,1,1,0)
        marker:SetTexture(white);marker:SetSize(1,7);marker:SetPoint("CENTER",fill,"RIGHT",0,0);marker:SetVertexColor(1,1,1,0)
        axis:SetTexture(white);axis:SetPoint("LEFT",bar,"LEFT",0,0);axis:SetPoint("RIGHT",bar,"RIGHT",0,0);axis:SetHeight(1);axis:SetVertexColor(.3,.3,.3,0)
    end)
    if not built then beam:Hide();marker:Hide();axis:Hide();return nil end
    -- Native recoloring cannot expose a second filled bar. The native texture
    -- keeps its layout authority and transparent texels remain its only art.
    if type(fill.SetTexture)~="function" then beam:Hide();marker:Hide();axis:Hide();return nil end
    local replaced,result=pcall(fill.SetTexture,fill,"Interface\\AddOns\\MirageUI\\Media\\Transparent.tga")
    if not replaced or result==false then beam:Hide();marker:Hide();axis:Hide();return nil end
    pcall(fill.SetAlpha,fill,0)
    bar.mirageBeam=beam;bar.mirageCurrentTick=marker;bar.mirageAxis=axis
    return beam
end
function U:BeamColor(bar,r,g,b,a)
    a=a==nil and 1 or a
    bar:SetStatusBarColor(r,g,b,a)
    if bar.mirageBeam then bar.mirageBeam:SetVertexColor(r,g,b,a) end
    if bar.mirageCurrentTick then bar.mirageCurrentTick:SetVertexColor(r,g,b,a) end
end
function U:BeamTrack(bar,r,g,b,a)
    local track=bar.mirageTrack;if not track then return end
    a=a==nil and .76 or a
    if bar.mirageBeam then
        track:SetColorTexture(.012,.012,.012,a)
        bar.mirageAxis:SetVertexColor(r,g,b,a)
    else track:SetColorTexture(r,g,b,a) end
end
function U:CopyWindow(title,text)
    -- A shared native writer may finish after its callback. Refuse nested same
    -- dialog requests before publishing ownership, rather than queue private text.
    if self.copyWriting or self.copyBuilding or self.copyBroken then return false end
    local request={};local ownerRequest=self.copyRequest
    local S,D=M.Safety,M.DialogNavigation
    local shown,currentShown,ownedShow,ownedWrite,ownedWriteGuarded=D and D.Shown,D and D.CurrentShown,D and D.OwnedShow,D and D.OwnedWrite,D and D.OwnedWriteGuarded
    local openingTop,openingShown=D and D.top,D and D.shownGeneration
    local preHandoff=true
    local function navigationCurrent() return not preHandoff or not D or (D.top==openingTop and D.shownGeneration==openingShown) end
    local function current() return self.copyRequest==ownerRequest and M.UI==self and M.Safety==S and M.DialogNavigation==D
        and (not D or (D.Shown==shown and D.CurrentShown==currentShown and D.OwnedShow==ownedShow and D.OwnedWrite==ownedWrite and D.OwnedWriteGuarded==ownedWriteGuarded)) end
    local function eligible()
        local ok,locked=pcall(S.InCombat,S)
        return ok and locked==false and not M.state.cinematic and current() and navigationCurrent()
    end
    local function write(fn,...)
        local previous=self.copyWriting;self.copyWriting=true
        local ok,value,nativeResult=pcall(fn,...);self.copyWriting=previous
        return ok,value,nativeResult
    end
    local function cleanup(object,key,valid,...)
        if not valid() then return false end
        -- Lookup itself may call a resolver or throw. It belongs inside the
        -- independently protected writer boundary, before the last owner check.
        return write(function(...)
            local fn=object[key]
            if valid() and type(fn)=="function" then return fn(object,...) end
        end,...)
    end
    if not eligible() then return false end
    if not self.copy then
        self.copyBuilding=true
        local ok=pcall(function()
            local f=self:Panel("MirageUICopyWindow",title,660,450);self.copy=f
            local scroll=self:Scroll(f);scroll:SetPoint("TOPLEFT",20,-92);scroll:SetPoint("BOTTOMRIGHT",-40,25);self.copyScroll=scroll
            -- Optional numeric chrome provenance cannot make essential Copy fail.
            pcall(function() self.copyChromeBaseline={width=f:GetWidth(),height=f:GetHeight(),headingWidth=580} end)
            local e=CreateFrame("EditBox",nil,scroll);e:SetMultiLine(true);e:SetAutoFocus(false);e:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",12,"")
            e:SetWidth(f:GetWidth()-70);e:SetHeight(1200);scroll:SetScrollChild(e);self.copyBox=e
            self.copyNavigation=self:Button(f,"Controller navigation / Tab leaves text",20,-54,f:GetWidth()-40,function() end)
            f:SetScript("OnHide",function()
                -- Retire logical ownership before independent best-effort cleanup.
                local generation=self.copyRequest
                self.copyToken=nil
                local function owned() return self.copy==f and self.copyBox==e and self.copyRequest==generation and self.copyToken==nil end
                if owned() then cleanup(e,"ClearFocus",owned) end
                if owned() then cleanup(e,"SetText",owned,"") end
            end)
            if D then D:Attach(f,{closeOnSuspend=true,allowWhileSafe=true,
                hideCleanupAllowed=function() return self.copy==f and self.copyToken==nil end,
                entries=function() return {
                    {frame=e,key="copyText",kind="edit",identity=self.copyToken},
                    {frame=self.copyNavigation,key="navigation",kind="button",identity=self.copyToken},
                    {frame=f.closeButton,key="close",kind="button",identity=self.copyToken}}
                end}) end
            self.copyKeyScripts={}
            for _,event in ipairs({"OnKeyDown","OnKeyUp","OnGamePadButtonDown","OnGamePadButtonUp"}) do
                self.copyKeyScripts[event]=f:GetScript(event)
            end
        end)
        self.copyBuilding=nil
        if not ok then
            -- Do not recreate a possibly already named partial root or use its
            -- incomplete controls. No private payload has been written yet.
            self.copyBroken=true;self.copyToken=nil
            local partial=self.copy
            if partial then cleanup(partial,"Hide",function() return self.copy==partial and self.copyBroken and self.copyToken==nil end) end
            return false
        end
    end
    if not eligible() then return false end
    -- A refused request must not strand an existing live session's handlers.
    -- Publish only after both admission probes; a callback-admitted successor
    -- changes ownerRequest and is never restored over by this older attempt.
    self.copyRequest=request;ownerRequest=request
    local f,e,navigation=self.copy,self.copyBox,self.copyNavigation
    local token={};self.copyToken=token
    local function exact() return current() and self.copy==f and self.copyBox==e and self.copyNavigation==navigation and self.copyToken==token end
    local function owned() return exact() and navigationCurrent() end
    local function step(fn,...)
        if not owned() then return false end
        local ok=write(fn,...)
        return ok and owned()
    end
    local function close()
        if not owned() then return false end
        return step(f.Hide,f)
    end
    local function navigate()
        if not owned() or not D then return false end
        local ok,allowed=pcall(D.Allowed,D,f)
        if not ok or allowed~=true or not owned() then return false end
        local focus=S:Public(GetCurrentKeyBoardFocus,nil)
        if not owned() then return false end
        if focus==e and not step(e.ClearFocus,e) then return false end
        if not owned() then return false end
        return step(D.Start,D,f,true)
    end
    local receipt
    local function receiptCurrent()
        if not owned() then return false end
        if not D then return true end
        local ok,value=pcall(currentShown,D,receipt)
        return ok and value==true and owned()
    end
    local function receiptWrite(target,method,...)
        if not receiptCurrent() then return false,nil end
        if not D then
            local ok,nativeResult=write(function(...) return target[method](target,...) end,...)
            if ok and receiptCurrent() then return true,nativeResult end
            return false,nil
        end
        local ok,success,nativeResult=write(ownedWrite,D,receipt,target,method,...)
        if ok and success==true and receiptCurrent() then return true,nativeResult end
        return false,nil
    end
    local function receiptWriteGuarded(guard,target,method,...)
        if not receiptCurrent() or not D or type(ownedWriteGuarded)~="function" then return false,nil end
        local ok,success,nativeResult=write(ownedWriteGuarded,D,receipt,guard,target,method,...)
        if ok and success==true and receiptCurrent() then
            local checked,value=pcall(function() if guard()==true then return true end;return false end)
            if checked and value==true then return true,nativeResult end
        end
        return false,nil
    end
    local completed=false
    local ok=pcall(function()
        for event,handler in pairs(self.copyKeyScripts or {}) do
            local captured=handler
            if not step(f.SetScript,f,event,function(...)
                if owned() then return step(captured,...) end
                return false
            end) then return end
        end
        if not step(e.SetScript,e,"OnEscapePressed",close) then return end
        if not step(f.closeButton.SetScript,f.closeButton,"OnClick",close) then return end
        if not step(navigation.SetScript,navigation,"OnClick",navigate) then return end
        if not step(e.SetScript,e,"OnTabPressed",function()
            if owned() and D then return step(D.FieldTab,D,f,e,"copyText") end
            return false
        end) then return end
        self:CloseChoices();if not owned() then return end
        if M.AccessibleInput and type(M.AccessibleInput.Stop)=="function" then M.AccessibleInput:Stop();if not owned() then return end end
        if M.OptionsNavigation and type(M.OptionsNavigation.Stop)=="function" then M.OptionsNavigation:Stop();if not owned() then return end end
        if not eligible() or not owned() then return end
        if not step(f.heading.SetText,f.heading,title) then return end
        if not owned() then return end
        preHandoff=false
        if D then
            local admitted
            local ok=write(function() admitted,receipt=shown(D,f) end)
            if not ok or admitted~=true or not receiptCurrent() then return end
            local called,success=write(ownedShow,D,f,receipt)
            if not called or success~=true or not receiptCurrent() then return end
        elseif not step(f.Show,f) then return end
        -- These writers share the lifecycle admission guard: an old native
        -- focus/selection write cannot finish after an admitted newer dialog.
        if not receiptWrite(e,"SetText",text) then return end
        if not receiptWrite(e,"HighlightText") then return end
        if not receiptWrite(e,"SetFocus") then return end
        completed=true
    end)
    if not ok or not completed or not owned() then
        if exact() then
            self.copyToken=nil
            local function retired() return current() and self.copyToken==nil and self.copy==f and self.copyBox==e end
            if retired() then cleanup(e,"ClearFocus",retired) end
            if retired() then cleanup(e,"SetText",retired,"") end
            if retired() then cleanup(f,"Hide",retired) end
        end
        return false
    end
    -- Cosmetic refusal is outside the essential opening/cleanup transaction.
    -- Neither retained closure captures the supplied title or private buffer.
    pcall(function()
        local chrome=M.CopyChrome
        local open=chrome and chrome.Open
        if type(open)~="function" or not receiptCurrent() or M.CopyChrome~=chrome or chrome.Open~=open then return end
        local heading,label,scroll,closeButton=f.heading,navigation.label,self.copyScroll,f.closeButton
        local function chromeCurrent()
            local function widgets()
                return rawequal(self.copyScroll,scroll) and rawequal(f.heading,heading) and
                    rawequal(navigation.label,label) and rawequal(f.closeButton,closeButton)
            end
            return widgets() and receiptCurrent() and widgets()
        end
        if not chromeCurrent() then return end
        open(chrome,{root=f,heading=heading,nav=navigation,navLabel=label,
            scroll=scroll,close=closeButton,baseline=self.copyChromeBaseline,current=chromeCurrent,write=receiptWrite,writeGuarded=receiptWriteGuarded},title)
    end)
    return true
end

function U:RefreshTheme()
    if M.Safety:InCombat() then return end
    local high=M.profile and M.profile.contrast
    local source=M.VisualTokens and M.VisualTokens.options
    if source then for key,value in pairs(source) do if type(value)=="table" then M.Theme[key]={unpack(value)} end end end
    -- Contrast is a neutral accessibility adjustment to the shared palette;
    -- it must never reinstall the retired blue/cyan options theme.
    if high then
        M.Theme.text={1,1,1,1};M.Theme.muted={.82,.81,.79,1}
        M.Theme.background={.015,.015,.017,1};M.Theme.panel={.025,.025,.028,1};M.Theme.edge={.47,.47,.47,1}
    end
    for frame,kind in pairs(self.backdrops) do
        pcall(function()
            if not self.buttons[frame] and M.Safety:Frame(frame,false) then
                frame:SetBackdropColor(unpack(M.Theme[kind] or M.Theme.panel));frame:SetBackdropBorderColor(unpack(M.Theme.edge))
            end
        end)
    end
    for _,row in ipairs(self.fonts) do
        pcall(function()
            if (not row.fontOnly or roles[row.font.mirageTextRole]) and not row.font.mirageSemanticColor and not row.font.mirageButtonText then row.font:SetTextColor(unpack(M.Theme[roles[row.font.mirageTextRole] or "text"])) end
        end)
    end
    for button in pairs(self.buttons) do paintButton(button) end
    -- Existing exact preview lease only; optional faults cannot block theme work.
    pcall(function()
    end)
end
function U:RefreshFonts()
    self.fontRefreshGeneration=(self.fontRefreshGeneration or 0)+1
    self.fontRefreshProfile=M.profile;self.fontRefreshScale=M.profile and M.profile.textScale or 1
    if self.refreshingFonts then return false end
    self.refreshingFonts=true
    local done=false
    for attempt=1,2 do
        local generation,profile,scale,fonts=self.fontRefreshGeneration,self.fontRefreshProfile,self.fontRefreshScale,self.fonts
        local function current()
            return self.fontRefreshGeneration==generation and M.UI==self and self.fonts==fonts and
                M.profile==profile and (profile and profile.textScale or 1)==scale
        end
        if M.Safety:InCombat() or not current() then break end
        local retired,layoutReady=false,true
        for _,row in ipairs(fonts) do
            if not current() then break end
            local font,size=row.font,row.size
            local manual=font.mirageManualFont
            pcall(function()
                if current() and row.font==font and not font.mirageManualFont then
                    local slider=font.mirageSliderOwner
                    if slider then
                        if not self.sliders[slider] or (slider.edit~=font and slider.label~=font) then layoutReady=false;return end
                        local priorLayoutReady=layoutReady;layoutReady=false
                        local width=slider:GetWidth()
                        if not current() then return end
                        if not slider:Relayout(width,current) or not current() or font.mirageSliderOwner~=slider then return end
                        layoutReady=priorLayoutReady
                    end
                    if not current() or row.font~=font or row.size~=size or font.mirageManualFont~=manual then return end
                    font:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",size*scale,"")
                end
            end)
            if row.font~=font or row.size~=size or font.mirageManualFont~=manual then retired=true;break end
            if not current() then break end
        end
        if retired then break end
        -- One optional owned Copy pass; no recursion or reopening covered panels.
        if current() then pcall(function()
            local chrome=M.CopyChrome;local refresh=chrome and chrome.Refresh
            if type(refresh)=="function" and current() and M.CopyChrome==chrome and chrome.Refresh==refresh then refresh(chrome,current) end
        end) end
        if current() then done=layoutReady;break end
        -- Only an explicit newer refresh may request a repair pass. A changed
        -- profile/scale without that request retires this cosmetic continuation.
        if self.fontRefreshGeneration==generation then break end
    end
    self.refreshingFonts=nil;self.fontRefreshProfile=nil;self.fontRefreshScale=nil
    return done
end
function U:Choose(anchor,values,current,callback)
    self:CloseChoices()
    if not self.choices then
        local f=CreateFrame("Frame",nil,UIParent,"BackdropTemplate");self.choices=f
        self:Backdrop(f);f:SetFrameStrata("FULLSCREEN_DIALOG");f:EnableMouse(true);f:SetClampedToScreen(true)
        f.rows={}
        f.scroll=self:Scroll(f)
        f.scroll:SetPoint("TOPLEFT",5,-5);f.scroll:SetPoint("BOTTOMRIGHT",-28,5)
        f.child=CreateFrame("Frame",nil,f.scroll);f.child:SetWidth(290);f.scroll:SetScrollChild(f.child)
        f:SetScript("OnHide",function() f.choiceToken=nil;f.dialogOwner=nil;f.dialogAnchor=nil end)
        f:Hide()
    end
    local f=self.choices;local token={};f.choiceToken=token
    f.dialogOwner=M.DialogNavigation and M.DialogNavigation.active or nil
    f:ClearAllPoints();f:SetPoint("TOPLEFT",anchor,"BOTTOMLEFT",0,-3)
    f:SetSize(330,math.min(390,#values*30+12));f.child:SetHeight(math.max(30,#values*30))
    for _,row in ipairs(f.rows) do row:Hide() end
    for i,v in ipairs(values) do
        local value=type(v)=="table" and v.value or v
        local label=type(v)=="table" and v.label or tostring(v)
        local b=f.rows[i]
        if not b then b=self:Button(f.child,"",0,-(i-1)*30,290,nil);f.rows[i]=b end
        local icon=anchor.controlIcon and anchor.controlIcon:IsShown() and anchor.controlIcon:GetTexture()
        b.label:SetJustifyH(icon and "LEFT" or "CENTER")
        b:SetText((icon and "|T"..icon..":20:20|t " or "")..(value==current and "• " or "")..label);b:Show()
        b:SetScript("OnClick",function()
            -- A dismissed or replaced popup cannot dispatch a retained row
            -- callback into another dialog/draft epoch.
            if f.choiceToken~=token or not f:IsShown() then return end
            if not anchor:IsVisible() or (anchor.IsEnabled and not anchor:IsEnabled()) then f:Hide();return end
            f:Hide();callback(value)
        end)
    end
    f.scroll:SetVerticalScroll(0);f:Show()
    if M.DialogNavigation then M.DialogNavigation:ChoiceOpened(f,anchor) end
end
function U:CloseChoices()
    if self.choices then self.choices:Hide() end
end
