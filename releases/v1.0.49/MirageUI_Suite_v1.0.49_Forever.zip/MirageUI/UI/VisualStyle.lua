local _, M = ...
-- Visual Spec v1.0 (corrected). These are display constants, never CVE observations.
M.Visual=M:Copy(M.VisualTokens.world)
local V,S=M.Visual,M.Safety
function V:PlainName(font,size)
    if not font then return false end
    local path=STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"
    if type(font.GetFont)=="function" then
        local ok,p=pcall(font.GetFont,font);if ok and S:Text(p) and p~="" then path=p end
    end
    if type(font.SetFont)=="function" then font:SetFont(path,size or 12,"") end
    if font.SetShadowColor then font:SetShadowColor(0,0,0,0) end
    if font.SetShadowOffset then font:SetShadowOffset(0,0) end
    return true
end
function V:ClassColor(unit)
    local isPlayer,status=S:Public(UnitIsPlayer,"boolean",unit)
    if status~="KNOWN" or not isPlayer or type(UnitClass)~="function" then return self.neutral,"NEUTRAL" end
    local ok,_,class=pcall(UnitClass,unit)
    if not ok or not S:Text(class) then return self.neutral,"NEUTRAL" end
    local color
    if C_ClassColor and type(C_ClassColor.GetClassColor)=="function" then
        local good,c=pcall(C_ClassColor.GetClassColor,class);if good then color=c end
    end
    local r,g,b=S:Field(color,"r"),S:Field(color,"g"),S:Field(color,"b")
    if not S:Number(r) or not S:Number(g) or not S:Number(b) then
        color=S:Field(RAID_CLASS_COLORS,class);r,g,b=S:Field(color,"r"),S:Field(color,"g"),S:Field(color,"b")
    end
    if S:Number(r) and S:Number(g) and S:Number(b) and r>=0 and r<=1 and g>=0 and g<=1 and b>=0 and b<=1 then return {r,g,b},"CLASS" end
    return self.neutral,"NEUTRAL"
end
local function publicColor(color)
    local r,g,b=S:Field(color,"r"),S:Field(color,"g"),S:Field(color,"b")
    if S:Number(r) and S:Number(g) and S:Number(b) and r>=0 and r<=1 and g>=0 and g<=1 and b>=0 and b<=1 then return {r,g,b} end
end
-- Native reaction and difficulty colors belong to world NPC identity. Player
-- names retain Blizzard class colors; primary grayscale cards override later.
function V:NameplateNameColor(unit)
    local player,known=S:Public(UnitIsPlayer,"boolean",unit)
    if known~="KNOWN" then return self.neutral,"REACTION_UNAVAILABLE" end
    if player then return self:ClassColor(unit) end
    local reaction,status=S:Public(UnitReaction,"number",unit,"player")
    if status=="KNOWN" and reaction>=1 and reaction<=8 and reaction%1==0 then
        local color=publicColor(S:Field(UnitReactionColor,reaction))
        if color then return color,"NATIVE_REACTION" end
    end
    -- UnitSelectionColor is the native alternative when the client does not
    -- export the public reaction palette. Restricted components are not read.
    if type(UnitSelectionColor)=="function" then
        local okay,r,g,b=pcall(UnitSelectionColor,unit)
        if okay and S:Number(r) and S:Number(g) and S:Number(b) and r>=0 and r<=1 and g>=0 and g<=1 and b>=0 and b<=1 then
            return {r,g,b},"NATIVE_SELECTION_COLOR"
        end
    end
    return self.neutral,"REACTION_UNAVAILABLE"
end
function V:NameplateLevelColor(unit,level)
    local player,known=S:Public(UnitIsPlayer,"boolean",unit)
    if known~="KNOWN" then return self.neutral,"DIFFICULTY_UNAVAILABLE" end
    if player then return self.level,"PLAYER_LEVEL" end
    if not S:Number(level) then return self.neutral,"DIFFICULTY_UNAVAILABLE" end
    -- The reviewed native TargetFrame uses the client difficulty enum; this
    -- respects its XP/level rules without maintaining addon cut-off tables.
    local difficulty,state=S:Public(C_PlayerInfo and C_PlayerInfo.GetContentDifficultyCreatureForPlayer,"number",unit)
    if state=="KNOWN" and type(GetDifficultyColor)=="function" then
        local okay,native=pcall(GetDifficultyColor,difficulty)
        local color=okay and publicColor(native)
        if color then return color,"NATIVE_CONTENT_DIFFICULTY" end
    end
    if level<0 then
        local color=publicColor(S:Field(QuestDifficultyColors,"impossible")) or publicColor(RED_FONT_COLOR)
        return color or self.neutral,color and "NATIVE_SKULL_DIFFICULTY" or "DIFFICULTY_UNAVAILABLE"
    end
    local own,status=S:Public(UnitLevel,"number","player")
    if level>0 and status=="KNOWN" and own>0 and type(GetRelativeDifficultyColor)=="function" then
        local okay,native=pcall(GetRelativeDifficultyColor,own,level)
        local color=okay and publicColor(native)
        if color then return color,"NATIVE_RELATIVE_DIFFICULTY" end
    end
    return self.neutral,"DIFFICULTY_UNAVAILABLE"
end
-- Separate from aura/category accents: those can be cleared without removing
-- the minimap-matched permanent frame. All geometry is prepared out of combat.
function V:GoldBorder(view)
    if view.goldEdges then return true end
    if S:InCombat() then return false end
    local f=view.frame;view.goldEdges={}
    for _,side in ipairs({"TOP","BOTTOM","LEFT","RIGHT"}) do
        local t=f:CreateTexture(nil,"OVERLAY");t:SetColorTexture(.91,.55,.18,.9)
        if side=="TOP" or side=="BOTTOM" then
            t:SetPoint(side.."LEFT",f,side.."LEFT",0,0);t:SetPoint(side.."RIGHT",f,side.."RIGHT",0,0);t:SetHeight(1)
        else
            t:SetPoint("TOP"..side,f,"TOP"..side,0,0);t:SetPoint("BOTTOM"..side,f,"BOTTOM"..side,0,0);t:SetWidth(1)
        end
        view.goldEdges[#view.goldEdges+1]=t
    end
    return true
end
function V:Name(font,unit,text,size)
    if not S:InCombat() then self:PlainName(font,size) end
    local c,source=self:ClassColor(unit)
    font:SetTextColor(c[1],c[2],c[3],1)
    -- Never emit inline color markup. The string comes from a verified public UnitName.
    font:SetText(S:Text(text) and text or "")
    return source
end
function V:Panel(frame,opacity)
    if not frame.miragePanel then
        local t=frame:CreateTexture(nil,"BACKGROUND");t:SetAllPoints();t:SetTexture("Interface\\AddOns\\MirageUI\\Media\\SubtlePanel.tga")
        frame.miragePanel=t
    end
    frame.miragePanel:SetAlpha(math.max(0,math.min(1,opacity or .10)))
end
function V:Accent(view,category)
    -- The caller must supply a public, unambiguous display category. Nil is neutral.
    local c=S:Text(category) and self.accents[category] or nil
    for _,edge in ipairs(view.accentEdges or {}) do
        if c then edge:SetColorTexture(c[1],c[2],c[3],.75) else edge:SetColorTexture(0,0,0,0) end
    end
    view.accentCategory=c and category or "NONE"
end
function V:CreateEdges(view)
    view.accentEdges={}
    local f=view.frame
    for _,side in ipairs({"TOP","BOTTOM","LEFT","RIGHT"}) do
        local t=f:CreateTexture(nil,"OVERLAY");t:SetColorTexture(0,0,0,0)
        if side=="TOP" or side=="BOTTOM" then
            t:SetPoint(side.."LEFT",f,side.."LEFT",0,0);t:SetPoint(side.."RIGHT",f,side.."RIGHT",0,0);t:SetHeight(2)
        else
            t:SetPoint("TOP"..side,f,"TOP"..side,0,0);t:SetPoint("BOTTOM"..side,f,"BOTTOM"..side,0,0);t:SetWidth(2)
        end
        view.accentEdges[#view.accentEdges+1]=t
    end
end

-- Optional backing changes the surface only; official class glyph color is untouched.
function V:NameBacking(view,enabled)
    if S:InCombat() then return end
    if not view.nameBacking then
        view.nameBacking=view.frame:CreateTexture(nil,"BORDER")
        view.nameBacking:SetPoint("TOPLEFT",view.name,"TOPLEFT",-2,1)
        view.nameBacking:SetPoint("BOTTOMRIGHT",view.name,"BOTTOMRIGHT",2,-1)
        view.nameBacking:SetColorTexture(.04,.045,.05,.72)
    end
    view.nameBacking:SetShown(enabled==true)
end
