local _,M=...
local U,S,D=M.UI,M.Safety,M.DialogNavigation
local V={};M.ReferenceView=V
-- Deterministic codepoint wrapping, not a claim about native font measurements.
-- Input has already passed the strict UTF-8 literal reference schema.
function V:Pages(text,columns,lines)
 columns=math.max(1,math.min(64,columns or 16));lines=math.max(1,math.min(32,lines or 8))
 local rows,current,count={},"",0
 for ch in text:gmatch('[%z\1-\127\194-\244][\128-\191]*') do
  if ch=='\n' then rows[#rows+1]=current;current="";count=0
  else
   if count==columns then rows[#rows+1]=current;current="";count=0 end
   current=current..ch;count=count+1
  end
 end
 rows[#rows+1]=current
 local pages={}
 for i=1,#rows,lines do local out={};for j=i,math.min(i+lines-1,#rows) do out[#out+1]=rows[j] end;pages[#pages+1]=table.concat(out,'\n') end
 return pages
end
local function same(a,b)
 if type(a)~=type(b) then return false end
 if type(a)~='table' then return a==b end
 if getmetatable(a) or getmetatable(b) then return false end
 for k,v in next,a do if not same(v,rawget(b,k)) then return false end end
 for k in next,b do if rawget(a,k)==nil then return false end end
 return true
end
local function dimensions()
 local scale=M.profile.textScale or 1
 local w,ws=S:Public(UIParent.GetWidth,'number',UIParent);local h,hs=S:Public(UIParent.GetHeight,'number',UIParent)
 if ws~='KNOWN' or hs~='KNOWN' then return nil end
 w=math.min(600,w-30);h=math.min(650,h-30)
 local button=math.ceil(28*scale);local header=math.ceil(48*scale);local warning=math.ceil(40*scale);local line=math.ceil(20*scale)
 local top=header+button+warning+16;local body=h-top-3*button-28-math.ceil(18*scale)-6
 local lines=math.min(16,math.floor(body/line))
 if w<330 or lines<4 then return nil end
 return {w=w,h=h,button=button,header=header,top=top,line=line,lines=lines,scale=scale}
end
function V:Base(s)
 local ok,value=pcall(function()
 local c,a=M.Client,M.adapter
 return s and self.session==s and not s.invalidated and self.frame==s.frame and M.modules.Preparations==s.parent and s.parent.frame==s.parentFrame and s.parent.generation==s.generation and s.parent.view==s.kind and M.profile==s.profile and s.profile.preparationReferences==s.root and same(s.root,s.original) and (not s.root or s.root[s.kind]==s.collection) and (not s.index or s.collection[s.index]==s.record) and s.profile.textScale==s.scale and not M.Profiles.readOnly and M:IsModuleActive('Preparations') and not M.state.safe and not M.state.cinematic and M.state.world and c==s.client and a==s.adapter and c.key==s.key and c.family==s.family and c.build==s.build and c.interface==s.interface and c.patch==s.patch and c.sourceMatched==s.sourceMatched and c.experimental==s.experimental and a.sourceCommit==s.source and a.family==s.adapterFamily and a.patch==s.adapterPatch and a.build==s.adapterBuild and a.interface==s.adapterInterface and M.Policy.contextEpoch==s.context and M.Policy.capabilityEpoch==s.capability and M.Policy.scopeEpoch==s.scope and (D.top==s.frame or s.opening and D.top==s.parentFrame)
 end)
 return ok and value==true
end
function V:Current(s,action)
 if not self:Base(s) then return false end
 if s.checking then s.invalidated=true;return false end
 s.checking=true
 local ok,valid=pcall(function()
  local shown=s.parentFrame:IsShown() and s.frame:IsShown()
  if not shown or not self:Base(s) then return false end
  if action and S:Typing() then return false end
  if not self:Base(s) then return false end
  local copy=M.References:Validate(s.root)
  if not copy or not same(copy,s.snapshot) or not self:Base(s) then return false end
  if s.root and s.root[s.kind]~=s.collection then return false end
  if s.index and s.collection[s.index]~=s.record then return false end
  local combat=S:InCombat()
  return not combat and self:Base(s)
 end)
 s.checking=false
 return ok and valid==true
end
function V:Close(expected)
 local s=self.session
 if not s or expected and s~=expected then return false end
 self.session=nil;s.review=nil;s.record=nil;s.index=nil;s.pages=nil
 s.snapshot=nil;s.original=nil;s.root=nil;s.collection=nil;s.profile=nil
 local function retired() return self.session==nil end
 if U.choices and U.choices.dialogOwner==s.frame then pcall(U.CloseChoices,U) end
 if not retired() then return true end
 if D.active==s.frame then pcall(D.Stop,D) end
 if not retired() then return true end
 for _,widget in ipairs({self.body,self.warning,self.progress,self.choice}) do pcall(widget.SetText,widget,'');if not retired() then return true end end
 pcall(s.frame.Hide,s.frame);return true
end
function V:Action(s)
 if self:Current(s,true) then return true end
 -- Foreign typing refuses the action without taking or clearing that focus.
 if not self:Current(s,false) then self:Close(s) end
 return false
end
function V:Document(s)
 if not s.index then return s.kind=='builds' and 'No build reference selected.\nSelect a saved reference.\nCreate or edit in settings.' or 'No strategy selected.\nSelect a saved strategy.\nCreate or edit in settings.' end
 local r=s.snapshot[s.kind][s.index];local c=r.createdClient
 local current=M.Client
 local identityKnown=current and type(current.family)=='string' and type(current.build)=='string' and type(current.interface)=='number'
 local stale=not identityKnown and 'Current client identity unknown; compatibility unverified.' or (c.family~=current.family or c.build~=current.build or c.interface~=current.interface) and 'Different client/build - compatibility unverified.' or 'Not validated against your current talents or this activity.'
 return 'Name\n'..r.name..'\n\n'..(s.kind=='builds' and 'User-authored reference - not your current/applied talents.' or 'Manual reference; not verified safe, recommended or applied.')..'\n\nReference text\n'..r.text..'\n\nSource note (user supplied)\n'..(r.source~='' and r.source or 'None supplied')..'\n\nCreated under '..c.family..' / '..c.build..' / interface '..c.interface..'\nProvenance is user-supplied, not validation.\n'..stale
end
function V:Write(s,widget,method,...)
 if not self:Base(s) then error('Retired reference view',0) end
 widget[method](widget,...)
 if not self:Base(s) then error('Retired reference view',0) end
end
function V:Render(s)
 if not self:Current(s,false) then self:Close(s);return false end
 local ok=pcall(function()
 local text=self:Document(s);s.pages=self:Pages(text,16,s.geometry.lines);s.page=math.max(1,math.min(s.page or 1,#s.pages))
 if not self:Base(s) then return false end
 self:Write(s,self.body,'SetText',s.pages[s.page]);if not self:Base(s) then return false end
 self:Write(s,self.progress,'SetText','Page '..s.page..' / '..#s.pages)
 self:Write(s,self.choice,'SetText',s.index and s.snapshot[s.kind][s.index].name or (s.kind=='builds' and 'Select a build reference' or 'Select a strategy'))
 self:Write(s,self.choice,'SetShown',not s.review)
 self:Write(s,self.warning,'SetText',s.review and (s.review.confirmed and 'Reviewed manually in this session.\nNot verified or applied.' or 'Manual strategy review.\nNot verified or applied.') or s.index and s.kind=='strategies' and 'Selected - not confirmed.\nUser-authored; unverified.' or 'User-authored; unverified.\nFull content is paged below.')
 self:Write(s,self.action,'SetShown',s.kind=='strategies' and s.index~=nil and not (s.review and s.review.confirmed))
 self:Write(s,self.action,'SetText',s.review and 'Confirm manual review' or 'Review selected strategy')
 self:Write(s,self.exit,'SetText',s.review and (s.review.confirmed and 'Close review' or 'Cancel review') or 'Close')
 self:Write(s,self.previous,'SetShown',s.page>1);self:Write(s,self.next,'SetShown',s.page<#s.pages)
 local review=s.review
 self:Write(s,self.action,'SetScript','OnClick',function()
  if not self:Action(s) or s.review~=review or review and review.confirmed then return end
  if review then review.confirmed=true else s.review={record=s.record};s.page=1 end
  self:Render(s)
 end)
 self:Write(s,self.exit,'SetScript','OnClick',function()
  if not self:Action(s) or s.review~=review then return end
  if review then s.review=nil;s.page=1;self:Render(s) else self:Close(s) end
 end)
 D:Refresh(s.frame)
 end)
 if not ok then self:Close(s);return false end
 return self:Current(s,false)
end
function V:Select(s,index)
 if not self:Action(s) or s.review or type(index)~='number' or index%1~=0 then return false end
 local record=s.snapshot[s.kind][index];if not record then return false end
 local original=s.root[s.kind][index]
 if not self:Base(s) then return false end
 s.index=index;s.record=original;s.page=1;s.review=nil
 return self:Render(s)
end
function V:Create()
 if self.frame then return end
 local f=U:Panel('MiragePreparationReferenceView','References',600,650);self.frame=f
 self.navigation=U:Button(f,'Controller',0,0,110,nil)
 self.choice=U:Button(f,'Select a reference',0,0,300,nil)
 self.warning=U:Text(f,'',18,-100,11,300)
 self.body=U:Text(f,'',18,-160,12,300)
 self.progress=U:Text(f,'',18,-480,11,300)
 self.previous=U:Button(f,'Previous page',0,0,140,nil);self.next=U:Button(f,'Next page',0,0,140,nil)
 self.action=U:Button(f,'Review selected strategy',0,0,300,nil);self.exit=U:Button(f,'Close',0,0,300,nil)
 f:SetScript('OnHide',function()
  local s=self.session;if s and s.frame==f then self:Close(s) end
 end)
 f:SetScript('OnUpdate',function(_,elapsed)
  local s=self.session;if not s then return end
  s.elapsed=(s.elapsed or 0)+(S:Number(elapsed) and elapsed or .1)
  if s.elapsed>=.1 then s.elapsed=0;if not self:Current(s,false) then self:Close(s) end end
 end)
 D:Attach(f,{closeOnSuspend=true,allowed=function() return self:Current(self.session,false) end,
  close=function() self:Close(self.session) end,onSuperseded=function() self:Close(self.session) end,
  entries=function()
   local s=self.session;return {{frame=self.navigation,key='navigation',kind='button',identity=s},{frame=self.choice,key='selection',kind='button',identity=s},{frame=self.previous,key='previous',kind='button',identity=s},{frame=self.next,key='next',kind='button',identity=s},{frame=self.action,key='review',kind='button',identity=s and (s.review or s)},{frame=self.exit,key='close',kind='button',identity=s},{frame=f.closeButton,key='closeAll',kind='button',identity=s}}
  end})
end
function V:Open(parent,kind)
 if (kind~='builds' and kind~='strategies') or not parent or parent~=M.modules.Preparations or parent.view~=kind or not parent:CanInteract() or D.top~=parent.frame or M.Profiles.readOnly or S:Typing() then return false end
 local request={};self.openRequest=request
 local profile,root,generation,frame=M.profile,M.profile.preparationReferences,parent.generation,parent.frame
 local c,a=M.Client,M.adapter
 local owner={client=c,adapter=a,key=c.key,family=c.family,build=c.build,interface=c.interface,patch=c.patch,sourceMatched=c.sourceMatched,experimental=c.experimental,source=a.sourceCommit,adapterFamily=a.family,adapterPatch=a.patch,adapterBuild=a.build,adapterInterface=a.interface,context=M.Policy.contextEpoch,capability=M.Policy.capabilityEpoch,scope=M.Policy.scopeEpoch}
 local snapshot,why=M.References:Validate(root);if not snapshot then return false,why end
 local geometry=dimensions();if not geometry then return false,'More screen space is needed for references.' end
 if profile~=M.profile or profile.preparationReferences~=root or generation~=parent.generation or parent.view~=kind or not parent:CanInteract() or S:Typing() then return false end
 self:Close();if self.openRequest~=request then return false end
 self:Create();if self.openRequest~=request then return false end
 local s={frame=self.frame,parent=parent,parentFrame=frame,generation=generation,kind=kind,profile=profile,root=root,collection=root and root[kind],snapshot=snapshot,original=M:Copy(root),scale=profile.textScale,client=c,adapter=a,key=c.key,family=c.family,build=c.build,interface=c.interface,patch=c.patch,sourceMatched=c.sourceMatched,experimental=c.experimental,source=a.sourceCommit,adapterFamily=a.family,adapterPatch=a.patch,adapterBuild=a.build,adapterInterface=a.interface,context=M.Policy.contextEpoch,capability=M.Policy.capabilityEpoch,scope=M.Policy.scopeEpoch,geometry=geometry,page=1}
 for k,v in pairs(owner) do s[k]=v end
 self.session=s;s.opening=true;local f=self.frame;local g=geometry
 if not self:Base(s) then self:Close(s);return false end
 local ok=pcall(function()
 self:Write(s,f,'SetSize',g.w,g.h);self:Write(s,f.heading,'SetWidth',g.w-190)
 local function place(widget,x,y,w,h) self:Write(s,widget,'ClearAllPoints');self:Write(s,widget,'SetPoint','TOPLEFT',x,-y);self:Write(s,widget,'SetWidth',w);self:Write(s,widget,'SetHeight',h);if widget.label then self:Write(s,widget.label,'SetWidth',w-16);self:Write(s,widget.label,'SetFont',STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",11*g.scale,"") end end
 place(f.closeButton,g.w-42,12,28,28);place(self.navigation,g.w-160,12,110,g.button)
 place(self.choice,18,g.header,g.w-36,g.button);place(self.warning,18,g.header+g.button+8,g.w-36,math.ceil(40*g.scale))
 place(self.body,18,g.top,g.w-36,g.lines*g.line)
 local pageY=g.h-3*g.button-28;place(self.progress,18,pageY-18*g.scale,g.w-36,math.ceil(16*g.scale))
 local half=(g.w-44)/2;place(self.previous,18,pageY,half,g.button);place(self.next,26+half,pageY,half,g.button)
 place(self.action,18,g.h-2*g.button-20,g.w-36,g.button);place(self.exit,18,g.h-g.button-12,g.w-36,g.button)
 for _,spec in ipairs({{self.body,12},{self.warning,11},{self.progress,11}}) do self:Write(s,spec[1],'SetFont',STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",spec[2]*g.scale,"") end
 end)
 if not ok then self:Close(s);return false end
 local bound=pcall(function()
 self:Write(s,self.navigation,'SetScript','OnClick',function() if self:Action(s) then D:Start(f,true) end end)
 self:Write(s,self.choice,'SetScript','OnClick',function(b)
  if not self:Action(s) or s.review then return end
  local choices={};for i,r in ipairs(s.snapshot[kind]) do choices[#choices+1]={value=i,label=r.name} end
  if #choices==0 then return end
  U:Choose(b,choices,s.index,function(index) self:Select(s,index) end)
 end)
 self:Write(s,self.previous,'SetScript','OnClick',function() if self:Action(s) then s.page=s.page-1;self:Render(s) end end)
 self:Write(s,self.next,'SetScript','OnClick',function() if self:Action(s) then s.page=s.page+1;self:Render(s) end end)
 self:Write(s,f.closeButton,'SetScript','OnClick',function() if self.session==s then self:Close(s) end end)
 end)
 if not bound then self:Close(s);return false end
 U:CloseChoices();if not self:Base(s) then self:Close(s);return false end
 if M.AccessibleInput then M.AccessibleInput:Stop();if not self:Base(s) then self:Close(s);return false end end
 if M.OptionsNavigation then M.OptionsNavigation:Stop();if not self:Base(s) then self:Close(s);return false end end
 D:Shown(f);if not self:Base(s) then self:Close(s);return false end
 f:Show();if not self:Base(s) then self:Close(s);return false end
 s.opening=nil
 if not self:Current(s,false) then self:Close(s);return false end
 return self:Render(s)
end
