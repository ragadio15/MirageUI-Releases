local _, M = ...
-- Fixed, passive regions beneath a secured unit button. No geometry/attributes are
-- changed in combat. Opaque timing objects never enter the contextual engine.
M.UnitExtras={}
local X=M.UnitExtras
local function config(view) return view.extraConfig or M:ModuleConfig(view.owner) or {} end
local castEvents={UNIT_SPELLCAST_START=true,UNIT_SPELLCAST_STOP=true,UNIT_SPELLCAST_DELAYED=true,
 UNIT_SPELLCAST_FAILED=true,UNIT_SPELLCAST_INTERRUPTED=true,UNIT_SPELLCAST_CHANNEL_START=true,
 UNIT_SPELLCAST_CHANNEL_UPDATE=true,UNIT_SPELLCAST_CHANNEL_STOP=true,
 UNIT_SPELLCAST_EMPOWER_START=true,UNIT_SPELLCAST_EMPOWER_STOP=true,UNIT_SPELLCAST_EMPOWER_UPDATE=true,
 UNIT_SPELLCAST_INTERRUPTIBLE=true,UNIT_SPELLCAST_NOT_INTERRUPTIBLE=true}
X.events=castEvents
local function transparent(bar)
 if M.DurationDisplay then M.DurationDisplay:Clear(bar,bar.clock) end
 if type(bar.ClearTimerDuration)=="function" then pcall(bar.ClearTimerDuration,bar) end
 M.UI:BeamColor(bar,.42,.75,.80,0)
 M.UI:BeamTrack(bar,.16,.18,.21,0)
 if bar.caption then bar.caption:SetText("") end
 if bar.icon then bar.icon:SetTexture(nil) end
 if bar.clock then bar.clock:SetText("") end
 bar.mirageDuration=nil;bar.nativeTextActive=false
end
local function timer(parent,grayscale)
 local b=CreateFrame("StatusBar",nil,parent)
 b:SetStatusBarTexture("Interface\\Buttons\\WHITE8X8")
 b.mirageTrack=b:CreateTexture(nil,"BACKGROUND");b.mirageTrack:SetAllPoints()
 M.UI:Beam(b);M.UI:BeamColor(b,.42,.75,.80,0);M.UI:BeamTrack(b,.16,.18,.21,0)
 b.caption=M.UI:Text(b,"",0,11,10,180)
 b.caption.mirageSemanticColor=true;b.caption:SetTextColor(unpack(M.Visual.neutral))
 b.icon=b:CreateTexture(nil,"ARTWORK");b.icon:SetSize(18,18);b.icon:SetTexCoord(.06,.94,.06,.94)
 b.grayscale=grayscale==true
 if b.grayscale then
  local okay,result=false,nil
  if type(b.icon.SetDesaturated)=="function" then okay,result=pcall(b.icon.SetDesaturated,b.icon,true) end
  b.grayIconReady=okay and result~=false
 end
 b.clock=M.UI:Text(b,"",0,11,10,90);b.clock:SetJustifyH("RIGHT")
 b.clock.mirageSemanticColor=true;b.clock:SetTextColor(unpack(M.Visual.neutral))
 M.Safety:Passive(b)
 return b
end
function X:Configure(view)
 if M.Safety:InCombat() then return false end
 local cfg=config(view)
 if cfg.showCast and not view.castTrack then
  view.castTrack=timer(view.frame,view.grayscale);view.channelTrack=timer(view.frame,view.grayscale)
 end
 if not cfg.nativeAuras and (cfg.showAuras or cfg.showBuffs) and not view.extraAuras then
  view.extraAuras={}
  for i=1,8 do
   local f=CreateFrame("Frame",nil,view.frame);f:SetSize(16,16);M.Safety:Passive(f)
   f.icon=f:CreateTexture(nil,"ARTWORK");f.icon:SetAllPoints()
   f.count=M.UI:Text(f,"",0,0,9,16)
   f.timer=CreateFrame("Cooldown",nil,f,"CooldownFrameTemplate");f.timer:SetAllPoints()
   if f.timer.SetHideCountdownNumbers then f.timer:SetHideCountdownNumbers(true) end
   M.Safety:Passive(f.timer);view.extraAuras[i]=f
  end
 end
 if not cfg.nativeAuras and cfg.showBuffs and not view.extraBuffs then
  view.extraBuffs={}
  for i=1,8 do
   local f=CreateFrame("Frame",nil,view.frame);f:SetSize(16,16);M.Safety:Passive(f)
   f.icon=f:CreateTexture(nil,"ARTWORK");f.icon:SetAllPoints()
   view.extraBuffs[i]=f
  end
 end
 if cfg.nativeAuras and (cfg.showAuras or cfg.showBuffs) and M.ManagedAuraRails then
  if (view.nativeAuraCreateFailures or 0)<3 then
   if cfg.showAuras and not view.nativeHarmful then view.nativeHarmful=M.ManagedAuraRails:Create(view.frame,"HARMFUL",{count=cfg.auraSlots,size=cfg.auraSize or 18,fontSize=12,grayscale=view.grayscale==true}) end
   if cfg.showBuffs and not view.nativeHelpful then view.nativeHelpful=M.ManagedAuraRails:Create(view.frame,cfg.majorBuffs and "HELPFUL|IMPORTANT" or "HELPFUL",{count=cfg.auraSlots,size=cfg.auraSize or 18,grayscale=view.grayscale==true}) end
   if (cfg.showAuras and not view.nativeHarmful) or (cfg.showBuffs and not view.nativeHelpful) then view.nativeAuraCreateFailures=(view.nativeAuraCreateFailures or 0)+1 end
  end
 end
 self:Layout(view)
 self:Clear(view)
 return true
end
function X:Layout(view,writer,preparedWidth)
 local safety=M.Safety
 if safety:InCombat() then view.extraLayoutPending=true;return false end
 local profile,frame=M.profile,view.frame
 local cfg=config(view);local width=preparedWidth or safety:Public(frame.GetWidth,"number",frame)
 if not safety:Number(width) then view.extraLayoutPending=true;return false end
 -- Typography supplies its own exact-object journal writer. Other callers
 -- must recheck between native callbacks: an anchor setter can enter combat
 -- before the next size call on a child of the native secure unit control.
 local bindings,targets,token,parent,parentState
 local function defer() view.extraLayoutPending=true;return false end
 if not writer then
  bindings,targets,token={},{},{};view.extraLayoutToken=token
  local function remember(owner,key)
   local object=owner[key];bindings[#bindings+1]={owner=owner,key=key,value=object}
   if object then targets[object]=true end
   return object
  end
  remember(view,"frame")
  for _,key in ipairs({"castTrack","channelTrack"}) do
   local bar=remember(view,key)
   if bar then for _,field in ipairs({"caption","icon","clock"}) do remember(bar,field) end end
  end
  for _,key in ipairs({"extraAuras","extraBuffs"}) do
   local tiles=remember(view,key)
   for i in ipairs(tiles or {}) do remember(tiles,i) end
  end
  for _,key in ipairs({"nativeHarmful","nativeHelpful"}) do
   local rail=remember(view,key);if rail then remember(rail,"holder") end
  end
  parent,parentState=safety:Public(frame.GetParent,nil,frame)
 end
 local function identities()
  if M.profile~=profile or M.Safety~=safety or view.frame~=frame or view.extraLayoutToken~=token then return false end
  for _,binding in ipairs(bindings) do if binding.owner[binding.key]~=binding.value then return false end end
  return true
 end
 local function current(object)
  if not targets[object] or not identities() or not safety:Frame(object,false) then return false end
  local currentParent,state=safety:Public(frame.GetParent,nil,frame)
  if parentState~="KNOWN" or state~="KNOWN" or currentParent~=parent or safety:InCombat() then return false end
  return identities()
 end
 local function put(object,key,...)
  if writer then return writer(object,key,...) end
  if not current(object) then return defer() end
  object[key](object,...)
  if not current(object) then return defer() end
  return true
 end
 -- Controlled ordinary units supply a captured-width, exact-object writer. The
 -- other paths retain their prepared artwork and defer interrupted geometry.
 local helpfulOffset=cfg.showCast and -26 or -3
 for _,bar in ipairs({view.castTrack,view.channelTrack}) do
  if not put(bar,"ClearAllPoints") or not put(bar,"SetPoint","TOPLEFT",view.frame,"BOTTOMLEFT",23,-17) or not put(bar,"SetSize",math.max(30,width-27),5)
   or not put(bar.caption,"ClearAllPoints") or not put(bar.caption,"SetPoint","BOTTOMLEFT",bar,"TOPLEFT",0,1) or not put(bar.caption,"SetWidth",math.max(30,width-126))
   or not put(bar.icon,"ClearAllPoints") or not put(bar.icon,"SetPoint","BOTTOMRIGHT",bar,"BOTTOMLEFT",-3,0)
   or not put(bar.clock,"ClearAllPoints") or not put(bar.clock,"SetPoint","BOTTOMRIGHT",bar,"TOPRIGHT",0,1) or not put(bar.clock,"SetWidth",85) then return false end
 end
 for i,tile in ipairs(view.extraAuras or {}) do
  if not put(tile,"ClearAllPoints") or not put(tile,"SetPoint","BOTTOMLEFT",view.frame,"TOPLEFT",4+(i-1)*19,3)
   or not put(tile,"SetShown",not cfg.nativeAuras and cfg.showAuras==true and i<=cfg.auraSlots) then return false end
 end
 for i,tile in ipairs(view.extraBuffs or {}) do
  if not put(tile,"ClearAllPoints") or not put(tile,"SetPoint","TOPLEFT",view.frame,"BOTTOMLEFT",4+(i-1)*19,helpfulOffset)
   or not put(tile,"SetShown",not cfg.nativeAuras and cfg.showBuffs==true and i<=cfg.auraSlots) then return false end
 end
 for _,entry in ipairs({{view.nativeHarmful,"BOTTOMLEFT","TOPLEFT",3},{view.nativeHelpful,"TOPLEFT","BOTTOMLEFT",helpfulOffset}}) do
  local rail=entry[1]
  if rail then
   -- Configure already prepared these rails before ordinary admission; a pure
   -- root/variant change only needs the captured holder anchor, not reconfigure.
   if not writer then
    if not current(rail.holder) then return defer() end
    M.ManagedAuraRails:Configure(rail,cfg.auraSlots,cfg.auraSize or 18,3)
   end
   if not put(rail.holder,"ClearAllPoints") or not put(rail.holder,"SetPoint",entry[2],view.frame,entry[3],4,entry[4]) then return false end
  end
 end
 if not writer and not current(frame) then return defer() end
 view.extraLayoutPending=nil
 return true
end
function X:ClearCast(view)
 if view.castTrack then transparent(view.castTrack);transparent(view.channelTrack) end
 view.extraCastState="EMPTY";view.castState="EMPTY";view.channelState="EMPTY"
 if not M.Safety:InCombat() then self:Layout(view) else view.extraLayoutPending=true end
end
function X:ClearAuras(view)
 if M.ManagedAuraRails then M.ManagedAuraRails:Clear(view.nativeHarmful);M.ManagedAuraRails:Clear(view.nativeHelpful) end
 for _,tile in ipairs(view.extraAuras or {}) do
  tile.icon:SetTexture(nil);tile.count:SetText("")
  if tile.timer.Clear then tile.timer:Clear() end
 end
 for _,tile in ipairs(view.extraBuffs or {}) do tile.icon:SetTexture(nil) end
 view.auraCategory=nil
 if view.accentEdges then M.Visual:Accent(view,nil) end
 view.extraAuraState="EMPTY"
 if view.detail then M.Display:UnitText(view) end
end
function X:Clear(view)
 self:ClearCast(view);self:ClearAuras(view);view.extraAuraDirty=true;view.extraEmpower=false;view.explicitChannel=false
end
local function send(bar,fn,unit,label)
 if bar.icon then bar.icon:SetTexture(nil) end
 if bar.clock then bar.clock:SetText("") end
 if type(fn)~="function" or type(bar.SetTimerDuration)~="function" then transparent(bar);return "UNSUPPORTED" end
 local ok,d=pcall(fn,unit)
 if not ok then transparent(bar);return "UNAVAILABLE" end
 if M.Safety:Readable(d) and d==nil then transparent(bar);return "EMPTY" end
 local interpolation=Enum and Enum.StatusBarInterpolation and Enum.StatusBarInterpolation.Immediate
 local directions=Enum and Enum.StatusBarTimerDirection
 local direction=directions and (label=="Channeling" and directions.RemainingTime or directions.ElapsedTime)
 if label=="Channeling" and directions and directions.RemainingTime==nil then transparent(bar);return "UNSUPPORTED" end
 local sent
 if interpolation~=nil and direction~=nil then sent=pcall(bar.SetTimerDuration,bar,d,interpolation,direction)
 else sent=pcall(bar.SetTimerDuration,bar,d) end
 if sent then bar.nativeTextActive=false;bar.mirageDuration=d;bar.mirageKind=label=="Channeling" and "channel" or label=="Empowering" and "empower" or "cast";local c=bar.grayscale and {.83,.83,.83} or M.Visual.cast;M.UI:BeamColor(bar,c[1],c[2],c[3],1);M.UI:BeamTrack(bar,.30,.30,.30,.76);bar.caption:SetText(label)
 else transparent(bar) end
 return sent and "NATIVE_DURATION" or "UNAVAILABLE"
end
-- Only native display consumers see timing results. No duration arithmetic,
-- comparison, logging, prediction or CVE publication occurs here.
function X:TimerText(bar)
 if not bar or not bar.clock then return end
 if bar.nativeTextBinding and bar.nativeTextActive then return end
 if M.DurationDisplay and (not M.Safety:Readable(bar.mirageDuration) or bar.mirageDuration~=nil) then
  if M.DurationDisplay:Bind(bar,bar.clock,bar.mirageDuration,bar.mirageKind) then bar.nativeTextActive=true;return end
 end
 bar.clock:SetText("")
 local d=bar.mirageDuration
 if not M.Safety:Readable(d) or d==nil then return end
 local ok=pcall(function()
  local current=bar.mirageKind=="channel" and d.GetRemainingDuration or d.GetElapsedDuration
  if type(current)~="function" or type(d.GetTotalDuration)~="function" then return end
  bar.clock:SetFormattedText("%.1f / %.1f",current(d),d:GetTotalDuration())
 end)
 if not ok then bar.clock:SetText("") end
end
local function castMetadata(bar,fn,unit,fallback)
 if M.Safety:Readable(bar.mirageDuration) and bar.mirageDuration==nil then return end
 if type(fn)~="function" then return end
 local ok,name,_,icon=pcall(fn,unit)
 if not ok then return end
 -- These native display sinks accept opaque payloads. Secret cast metadata is
 -- neither a missing spell nor permission to inspect/format its identity.
 local text=name;if M.Safety:Text(name) then text=name:gsub("|","||") end
 if not pcall(bar.caption.SetText,bar.caption,text) then bar.caption:SetText(fallback) end
 if not pcall(bar.icon.SetTexture,bar.icon,icon) then bar.icon:SetTexture(nil) end
end
function X:ReconcileCast(view)
 local previous=view.extraCastState
 local a,b=view.castState or "EMPTY",view.channelState or "EMPTY"
 view.extraCastState=(a=="NATIVE_DURATION" or b=="NATIVE_DURATION") and "NATIVE_DURATION" or
  (a=="EMPTY" and b=="EMPTY") and "EMPTY" or "UNAVAILABLE"
 if previous~=view.extraCastState then
  if not M.Safety:InCombat() then self:Layout(view) else view.extraLayoutPending=true end
 end
end
function X:RefreshCast(view)
 local cfg=config(view)
 if not cfg.showCast or not view.castTrack then self:ClearCast(view);return end
 local empowered=M.DurationDisplay and M.DurationDisplay:IsEmpowered(view.unit)
 view.extraEmpower=empowered==true or nil
 view.castState=send(view.castTrack,UnitCastingDuration,view.unit,"Casting")
 -- A public ordinary channel-start event is acceptable for older clients lacking
 -- the non-secret empower flag. Reload/retarget cannot assume that same history.
 if empowered==true or empowered==false or view.explicitChannel then
  view.channelState=send(view.channelTrack,UnitChannelDuration,view.unit,empowered==true and "Empowering" or "Channeling")
 else transparent(view.channelTrack);view.channelState="EMPTY" end
 castMetadata(view.castTrack,UnitCastingInfo,view.unit,"Casting")
 castMetadata(view.channelTrack,UnitChannelInfo,view.unit,"Channeling")
 self:TimerText(view.castTrack);self:TimerText(view.channelTrack)
 self:ReconcileCast(view)
end
function X:RefreshAuras(view)
 local cfg=config(view)
 if (not cfg.showAuras and not cfg.showBuffs) or (not view.extraAuras and not cfg.nativeAuras) then self:ClearAuras(view);return end
 if cfg.nativeAuras then
  -- No aura-list scan or sealed-output read occurs in this path. Native frames
  -- own the occurrence, filtering, icon and countdown presentation.
  local ok=true
  if cfg.showAuras then ok=M.ManagedAuraRails:Assign(view.nativeHarmful,view.unit or "none",true) and ok else M.ManagedAuraRails:Clear(view.nativeHarmful) end
  if cfg.showBuffs then ok=M.ManagedAuraRails:Assign(view.nativeHelpful,view.unit or "none",true) and ok else M.ManagedAuraRails:Clear(view.nativeHelpful) end
  view.auraCategory=nil;if view.accentEdges then M.Visual:Accent(view,nil) end
  view.extraAuraState=ok and "NATIVE_CONTAINER_SUBMITTED" or "NATIVE_CONTAINER_UNAVAILABLE_KEEP_NATIVE"
  view.extraAuraDirty=false;return
 end
 local api=C_UnitAuras and C_UnitAuras.GetAuraDataByIndex
 local unavailable=type(api)~="function"
 -- Fixed native harmful-aura order. No dispel classification, duration sorting or
 -- health-derived priority, and no omission interpreted as absence.
 -- Clear every old slot before a native end-of-list / unavailable result can
 -- terminate the bounded scan. Empty lists cost one query, not eight per unit.
 for _,tile in ipairs(view.extraAuras) do
  tile.icon:SetTexture(nil);tile.count:SetText("");if tile.timer.Clear then tile.timer:Clear() end
 end
 for i,tile in ipairs(view.extraAuras) do
  if cfg.showAuras and i<=cfg.auraSlots and type(api)=="function" then
   local ok,data=pcall(api,view.unit,i,"HARMFUL")
   if not ok then unavailable=true;break
   elseif not M.Safety:Readable(data) then unavailable=true;break
   elseif data==nil then break
   else
    local icon=M.Safety:Field(data,"icon")
    if M.Safety:Number(icon) or M.Safety:Text(icon) then
     tile.icon:SetTexture(icon)
     local id=M.Safety:Field(data,"auraInstanceID")
     if M.Safety:Number(id) and id>0 and id%1==0 then
      M.Display:Cooldown(tile.timer,C_UnitAuras.GetAuraDuration,view.unit,id)
      local count=M.Safety:Public(C_UnitAuras.GetAuraApplicationDisplayCount,"string",view.unit,id,2,99)
      tile.count:SetText(count or "")
     else unavailable=true end
    else unavailable=true end
   end
  elseif cfg.showAuras and i<=cfg.auraSlots then unavailable=true end
 end
 -- Helpful icons have no text/count overlays. Unknown or missing fields stay empty.
 for _,tile in ipairs(view.extraBuffs or {}) do tile.icon:SetTexture(nil) end
 if cfg.showBuffs and type(api)=="function" then
  for i,tile in ipairs(view.extraBuffs or {}) do
   if i>cfg.auraSlots then break end
   local ok,data=pcall(api,view.unit,i,"HELPFUL")
   if not ok or not M.Safety:Readable(data) then unavailable=true;break end
   if data==nil then break end
   local icon=M.Safety:Field(data,"icon")
   if M.Safety:Number(icon) or M.Safety:Text(icon) then tile.icon:SetTexture(icon) else unavailable=true end
  end
 end
 view.auraCategory=nil
 -- Accent is an explicit candidate display setting. Only one completely public
 -- category across a complete bounded scan is accepted. No duration/priority sort.
 if cfg.debuffAccent and cfg.showAuras and type(api)=="function" then
  local category,complete,ambiguous=nil,false,false
  for i=1,32 do
   local ok,aura=pcall(api,view.unit,i,"HARMFUL")
   if not ok or not M.Safety:Readable(aura) then ambiguous=true;break end
   if aura==nil then complete=true;break end
   local kind=M.Safety:Field(aura,"dispelName")
   -- Empty dispel type is NOT evidence of Bleed/Physical.
   if not M.Safety:Text(kind) or not M.Visual.accents[kind] or kind=="Bleed" then ambiguous=true;break end
   if category and category~=kind then ambiguous=true;break end
   category=kind
  end
  if complete and not ambiguous and not unavailable then view.auraCategory=category end
 end
 if view.accentEdges then M.Visual:Accent(view,view.auraCategory) end
 if view.detail then M.Display:UnitText(view) end
 view.extraAuraState=unavailable and "PARTIAL_UNAVAILABLE" or "PUBLIC_NATIVE_ORDER"
 view.extraAuraDirty=false
end
function X:Event(view,event)
 if event=="UNIT_AURA" then view.extraAuraDirty=true;return end
 if view.plateRole then
  -- A terminal event can belong to the previous cast. Refresh the incumbent
  -- native duration instead of clearing a successor by spell/GUID identity.
  if event=="UNIT_SPELLCAST_CHANNEL_START" then view.explicitChannel=true end
  if event=="UNIT_SPELLCAST_CHANNEL_STOP" or event=="UNIT_SPELLCAST_EMPOWER_STOP" then view.explicitChannel=false end
  if castEvents[event] then self:RefreshCast(view) end
  return
 end
 if event=="UNIT_SPELLCAST_EMPOWER_START" then view.extraEmpower=true;view.explicitChannel=false;self:RefreshCast(view)
 elseif event=="UNIT_SPELLCAST_EMPOWER_STOP" then view.extraEmpower=false;view.explicitChannel=false;self:ClearCast(view)
 elseif event=="UNIT_SPELLCAST_INTERRUPTED" or event=="UNIT_SPELLCAST_FAILED" then view.explicitChannel=false;self:ClearCast(view)
 elseif event=="UNIT_SPELLCAST_STOP" then
  if view.castTrack then transparent(view.castTrack) end;view.castState="EMPTY";self:ReconcileCast(view)
 elseif event=="UNIT_SPELLCAST_CHANNEL_STOP" then
  if view.channelTrack then transparent(view.channelTrack) end;view.channelState="EMPTY";view.explicitChannel=false;self:ReconcileCast(view)
 elseif event=="UNIT_SPELLCAST_CHANNEL_START" then view.explicitChannel=true;self:RefreshCast(view)
 elseif castEvents[event] then self:RefreshCast(view) end
end
function X:Tick(view,now)
 local cfg=config(view)
 if view.powerLayoutPending and not view.nativeBacked and not M.Safety:InCombat() then M.Display:SizeUnit(view,view.layoutWidth or 300,view.layoutHeight or 55) end
 if view.extraLayoutPending and not M.Safety:InCombat() then
  if self:Layout(view) then view.extraLayoutPending=nil end
 end
 if view.castTrack and view.frame:IsVisible() and now>=(view.extraTextNext or 0) then
  self:TimerText(view.castTrack);self:TimerText(view.channelTrack);view.extraTextNext=now+.10
 end
 if (not cfg.showAuras and not cfg.showBuffs) or (not cfg.nativeAuras and not view.extraAuras) or not view.frame:IsVisible() then return end
 if view.extraAuraDirty and now>=(view.extraAuraNext or 0) then self:RefreshAuras(view);view.extraAuraNext=now+.20 end
end

function X:Ready(view)
 local cfg=config(view)
 if cfg.showCast and (not view.castTrack or type(UnitCastingDuration)~="function" or type(UnitChannelDuration)~="function"
  or type(view.castTrack.SetTimerDuration)~="function" or type(view.channelTrack.SetTimerDuration)~="function") then return false,"CAST_CHANNEL_UNAVAILABLE" end
 if cfg.showCast and view.grayscale and (not view.castTrack.grayIconReady or not view.channelTrack.grayIconReady) then return false,"CAST_GRAYSCALE_UNAVAILABLE" end
 if cfg.nativeAuras then
  if cfg.showAuras and not M.ManagedAuraRails:Ready(view.nativeHarmful) then return false,"AURA_CHANNEL_UNAVAILABLE" end
  if cfg.showBuffs and not M.ManagedAuraRails:Ready(view.nativeHelpful) then return false,"AURA_CHANNEL_UNAVAILABLE" end
 end
 return true,"NATIVE_CHANNELS_PREPARED"
end
