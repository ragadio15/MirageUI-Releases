local _, M = ...
-- Canonical static Copy chrome only. Native rendering/hidden metrics are NOT_RUN.
-- A declined enhancement never owns the transfer buffer or its input lifecycle.
local C={};M.CopyChrome=C
local lives=setmetatable({},{__mode="k"})
local probeFrame,probeFont,frameAttempted,fontAttempted,busy
local titles={
 profile="Profile includes saved reference text — review before sharing",
 nativeReview="Display and native-settings review",worksheet="User-reported validation worksheet",
 demoInformation="DEMO — not live game information",decisions="Current presentation decisions",
 supportInformation="MirageUI support information",demoRehearsal="DEMO — contextual rehearsal",
 installation="MirageUI installation check",validation="User-reported validation",clientSupport="MirageUI client support",
 visibility="Visibility explanations",performance="MirageUI performance",conventions="Tactical conventions",
 localPerformance="Local performance",support="MirageUI support",hud="HUD visibility",
}
local moduleNames={Cursor="Cursor",Minimap="Minimap",Chat="Chat",Tooltips="Tooltips",QuestTracker="Objectives",UnitFrames="Unit frames",Nameplates="Nameplates",ActionBars="Action bars",UnderCharacterHUD="Under-Character HUD",ResourceBars="Resources and casts",Auras="Auras",Cooldowns="Cooldowns",PartyRaid="Party and raid",BlizzardSkin="Blizzard windows",Bags="Bags and bank",DataBars="Travel and progress",DamageMeters="Damage meter",PvP="PvP combat lenses",TacticalSignals="Tactical signals",Preparations="Preparations"}
for key,name in pairs(moduleNames) do titles["module:"..key]=name.." — presentation" end
local navText="Controller navigation / Tab leaves text"
local clientKeys={'key','family','patch','build','interface','sourceMatched','allowed','IsRuntimeClient','RuntimeAvailable'}
local adapterKeys={'family','patch','build','interface','sourceCommit'}
local function finite(v) return type(v)=="number" and v==v and v~=math.huge and v~=-math.huge end
local function positive(v) return finite(v) and v>0 and v<=16384 end
local function resolveTitle(self,title)
 local S=M.Safety;local read=S and S.Readable
 if type(read)~="function" then return nil end
 local ok,value=pcall(read,S,title)
 if not ok or value~=true or M.Safety~=S or S.Readable~=read or type(title)~="string" then return nil end
 for key,literal in pairs(titles) do if title==literal then return key end end
end
C.ResolveTitle=resolveTitle
local open,refresh
local function run(record,refreshCurrent)
 local r=record;local state=lives[r.root]
 local shape={root=r.root,heading=r.heading,nav=r.nav,navLabel=r.navLabel,scroll=r.scroll,close=r.close,baseline=r.baseline,current=r.current,write=r.write,writeGuarded=r.writeGuarded,key=r.key}
 local function shapeCurrent() for k,v in pairs(shape) do if not rawequal(rawget(r,k),v) then return false end end;return rawequal(rawget(r,"key"),shape.key) end
 local S,profile,client,adapter,parent=M.Safety,M.profile,M.Client,M.adapter,UIParent
 local UI=M.UI
 local hostSlots={}
 for _,entry in ipairs({{r.root,"heading",r.heading},{r.nav,"label",r.navLabel},{r.root,"closeButton",r.close}}) do
  local object,key,expected=entry[1],entry[2],entry[3]
  -- Native proxy representations need not expose a raw slot. The caller's
  -- qualified current check covers those; an exposed slot adds a pure seal.
  if type(object)=="table" and rawget(object,key)~=nil then hostSlots[#hostSlots+1]={object=object,key=key,expected=expected} end
 end
 local function hostSealed()
  if not rawequal(rawget(M,"UI"),UI) or type(UI)~="table" or not rawequal(rawget(UI,"copy"),shape.root)
   or not rawequal(rawget(UI,"copyNavigation"),shape.nav) or not rawequal(rawget(UI,"copyScroll"),shape.scroll) then return false end
  for _,slot in ipairs(hostSlots) do if not rawequal(rawget(slot.object,slot.key),slot.expected) then return false end end
  return true
 end
 local readable,combat=S and S.Readable,S and S.InCombat
 local secret,access,combatNative=issecretvalue,canaccessvalue,InCombatLockdown
 local create,fontGlobal=CreateFrame,STANDARD_TEXT_FONT
 local openMethod,refreshMethod,resolveMethod=open,refresh,resolveTitle
 local retired=false;local bindings={};local bindingMap={};local clientFields,adapterFields
 local function methodSeal(b)
  for _,part in ipairs(b.route or {}) do
   if not rawequal(rawget(part.object,b.key),part.slot) or not rawequal(getmetatable(part.object),part.meta)
    or (part.indexKnown and not rawequal(rawget(part.meta,"__index"),part.index)) then return false end
  end
  return true
 end
 local function routesSealed()
  for _,b in ipairs(bindings) do if not methodSeal(b) then return false end end
  if state and state.bindings then for _,b in ipairs(state.bindings) do if not methodSeal(b) then return false end end end
  return true
 end
 local function sourceSealed()
  if clientFields then
   if type(client)~="table" or type(adapter)~="table" then return false end
   for _,k in ipairs(clientKeys) do if not rawequal(rawget(client,k),clientFields[k]) then return false end end
   for _,k in ipairs(adapterKeys) do if not rawequal(rawget(adapter,k),adapterFields[k]) then return false end end
  end
  return true
 end
 local requestedScale=profile and profile.textScale
 local workLimit,workCount=32768,0
 local work={total=0,request=0,qualification=0,lookup=0,native=0,bindings=0,limit=workLimit};r.work=work
 local function spend(kind)
  if workCount>=workLimit then retired=true;return false end
  workCount=workCount+1;work.total=workCount;work[kind]=work[kind]+1;return true
 end
 local function lifetimeSeal()
  if not state then return true end
  local b=state.baseline
  if type(b)~="table" or rawget(b,"width")~=state.baseWidth or rawget(b,"height")~=state.baseHeight or rawget(b,"headingWidth")~=state.baseHeadingWidth then return false end
  if state.manual then
   for _,slot in ipairs(state.markerSlots or {}) do
    if not rawequal(rawget(slot.object,slot.key),slot.expected) then return false end
   end
  end
  return true
 end
 -- This final-dispatch seal is intentionally callback-free: only ordinary
 -- owned Lua state and raw method routes. Native/lifecycle legality is supplied
 -- independently by DialogNavigation's guarded writer immediately around dispatch.
 local function pureBase()
  return not retired and shapeCurrent() and hostSealed() and rawequal(rawget(M,"CopyChrome"),C) and rawequal(rawget(C,"current"),r)
   and rawequal(rawget(C,"Open"),openMethod) and rawequal(rawget(C,"Refresh"),refreshMethod) and rawequal(rawget(C,"ResolveTitle"),resolveMethod)
   and rawequal(rawget(M,"Safety"),S) and rawequal(rawget(S,"Readable"),readable) and rawequal(rawget(S,"InCombat"),combat)
   and rawequal(rawget(_G,"issecretvalue"),secret) and rawequal(rawget(_G,"canaccessvalue"),access) and rawequal(rawget(_G,"InCombatLockdown"),combatNative)
   and rawequal(rawget(_G,"CreateFrame"),create) and rawequal(rawget(_G,"STANDARD_TEXT_FONT"),fontGlobal) and rawequal(rawget(_G,"UIParent"),parent)
   and rawequal(rawget(M,"profile"),profile) and rawget(profile,"textScale")==requestedScale and rawequal(rawget(M,"Client"),client) and rawequal(rawget(M,"adapter"),adapter)
   and rawequal(rawget(lives,shape.root),state) and sourceSealed() and lifetimeSeal()
 end
 local function pureOwner() return pureBase() and routesSealed() end
 local function owner()
  if retired then return false end
  local ok,value=pcall(pureBase)
  if not ok or value~=true then retired=true end
  return not retired
 end
 local function current()
  if not owner() then return false end
  if not spend("request") then return false end
  local ok,value=pcall(shape.current)
  if not owner() or not ok or value~=true then retired=true;return false end
  if refreshCurrent then
   if not spend("request") then return false end
   ok,value=pcall(refreshCurrent)
   if not owner() or not ok or value~=true then retired=true;return false end
  end
  return true
 end
 local function public(v)
  if not owner() then return false end
  if not spend("qualification") then return false end
  local ok,value=pcall(readable,S,v)
  return current() and ok and value==true
 end
 local function lookup(object,key)
  if not public(object) then return nil end
  if not spend("lookup") then return nil end
  local ok,value=pcall(function() return object[key] end)
  if not owner() or not ok or not public(value) then return nil end
  return value
 end
 local function live(mutation)
  if not current() then return false end
  for _,b in ipairs(bindings) do
   if not b.complete and (lookup(b.object,b.key)~=b.fn or not current()) then return false end
  end
  if not mutation then return owner() end
  if not routesSealed() then retired=true;return false end
  if not spend("native") then return false end
  local ok,locked=pcall(combat,S)
  return current() and ok and locked==false and routesSealed()
 end
 local function bind(object,key)
  if not owner() then return nil end
  local known=bindingMap[object] and bindingMap[object][key]
  -- A complete raw route is checked directly below. Re-running its public
  -- resolver cannot add evidence, but would multiply synchronous native guards.
  if known and known.complete then return methodSeal(known) and known or nil end
  local fn=lookup(object,key);if type(fn)~="function" then return nil end
  if known then return known.fn==fn and known or nil end
  local route,node,seen,complete={},object,{},false
  for _=1,8 do
   if type(node)~="table" or seen[node] then break end;seen[node]=true
   local slot,meta=rawget(node,key),getmetatable(node)
   if not public(slot) or not public(meta) then return nil end
   local indexKnown=type(meta)=="table";local index=indexKnown and rawget(meta,"__index") or nil
   if not public(index) then return nil end
   route[#route+1]={object=node,slot=slot,meta=meta,indexKnown=indexKnown,index=index}
   if slot~=nil then complete=slot==fn;break end
   if type(index)~="table" then break end;node=index
  end
  if #bindings>=256 then retired=true;return nil end
  local b={object=object,key=key,fn=fn,route=route,complete=complete};bindings[#bindings+1]=b;bindingMap[object]=bindingMap[object] or {};bindingMap[object][key]=b;work.bindings=#bindings;return current() and b or nil
 end
 local security
 local mutations={Hide=true,EnableMouse=true,EnableKeyboard=true,SetFont=true,SetWordWrap=true,SetNonSpaceWrap=true,SetIndentedWordWrap=true,SetWidth=true,SetText=true}
 local function call(object,key,...)
  local b=bind(object,key);if not b or not live() then return nil end
  if mutations[key] and (not security(object,true) or not live(true)) then return nil end
  if not spend("native") then return nil end
  local result={pcall(b.fn,object,...)}
  if not live() or not methodSeal(b) or result[1]~=true then return nil end
  for i=2,#result do if not public(result[i]) then return nil end end
  return result
 end
 local function one(object,key,...)
  local result=call(object,key,...);return result and result[2],result~=nil
 end
 local function number(object,key,...)
  local value,ok=one(object,key,...)
  return ok and public(value) and finite(value) and value or nil
 end
 security=function(object,mutation)
  local seen={};local node=object
  for depth=1,32 do
   if not public(node) then return false end
   if node==nil then return depth>1 and live() end
   if (type(node)~="table" and type(node)~="userdata") or seen[node] then return false end
   seen[node]=true
   local forbidden,ok=one(node,"IsForbidden");if not ok or forbidden~=false then return false end
   if depth==1 and mutation then local protected,good=one(node,"IsProtected");if not good or protected~=false then return false end end
   local nextNode,good=one(node,"GetParent");if not good or not public(nextNode) then return false end
   node=nextNode
  end
  return false
 end
 local function source()
  if clientFields then return owner() end
  if not public(client) or not public(adapter) then return false end
  local cs,ads={},{}
  for _,k in ipairs(clientKeys) do cs[k]=lookup(client,k) end
  for _,k in ipairs(adapterKeys) do ads[k]=lookup(adapter,k) end
  clientFields,adapterFields=cs,ads
  local runtime=cs.IsRuntimeClient
  if type(runtime)~="function" or cs.allowed~=true or not current() then return false end
  local ok,value=pcall(runtime,client)
  return ok and value==true and current()
 end
 local function reject(status)
  if C.current==r then r.status=workCount>=workLimit and "WORK_LIMIT" or status;r.fit=false end
  return false
 end
 if type(readable)~="function" or type(combat)~="function" or type(r.current)~="function" or type(r.writeGuarded)~="function" or not current() then return reject("RETIRED") end
 if not public(requestedScale) or not finite(requestedScale) or requestedScale<.8 or requestedScale>1.5 then return reject("SCALE_UNAVAILABLE") end
 r.requestedScale=requestedScale
 if not source() then return reject("RUNTIME_UNAVAILABLE") end
 if not live(true) then return reject("RETIRED") end
 if not current() then return reject("RUNTIME_UNAVAILABLE") end
 if not public(fontGlobal) then return reject("FONT_UNAVAILABLE") end
 local font=fontGlobal or "Fonts\\FRIZQT__.TTF"
 if type(font)~="string" or #font==0 or #font>256 or font:find("[%c]") then return reject("FONT_UNAVAILABLE") end
 for _,widget in ipairs({r.root,r.heading,r.nav,r.navLabel,r.scroll,r.close}) do if not security(widget,true) then return reject("GEOMETRY_UNAVAILABLE") end end
 if not security(parent,false) then return reject("GEOMETRY_UNAVAILABLE") end
 if state and state.bindings then
  for _,b in ipairs(state.bindings) do
   if not methodSeal(b) or (not b.complete and not rawequal(lookup(b.object,b.key),b.fn)) or not current() then return reject("METHOD_OWNER_CHANGED") end
  end
 end
 local function point(object,index)
  local p=call(object,"GetPoint",index)
  if not p or not public(p[2]) or not public(p[3]) or not public(p[4]) or not public(p[5]) or not public(p[6]) then return nil end
  if type(p[2])~="string" or type(p[4])~="string" or not finite(p[5]) or not finite(p[6]) then return nil end
  return {p[2],p[3],p[4],p[5],p[6]}
 end
 local function same(a,b)
  if not a or not b then return false end
  for i=1,5 do if not rawequal(a[i],b[i]) then return false end end
  return true
 end
 local function anchored(object,expected,count)
  if number(object,"GetNumPoints")~=count then return false end
  return same(point(object,1),expected)
 end
 local function fontState(object)
  local values=call(object,"GetFont")
  if not values or not public(values[2]) or not public(values[3]) or not public(values[4]) or type(values[2])~="string" or not positive(values[3]) or type(values[4])~="string" then return nil end
  return {values[2],values[3],values[4]}
 end
 local function fontEqual(a,b) return a and b and a[1]==b[1] and a[2]==b[2] and a[3]==b[3] end
 local function rect(object)
  local values=call(object,"GetRect")
  if not values then return nil end
  local v={values[2],values[3],values[4],values[5]}
  for i=1,4 do if not public(v[i]) or not finite(v[i]) or math.abs(v[i])>32768 then return nil end end
  if not positive(v[3]) or not positive(v[4]) then return nil end
  return v
 end
 local baseline=r.baseline
 if not state then
  if type(baseline)~="table" or not public(baseline.width) or not positive(baseline.width) or not public(baseline.height) or not positive(baseline.height) or baseline.headingWidth~=580 then return reject("BASELINE_UNAVAILABLE") end
  local initial={root=r.root,heading=r.heading,nav=r.nav,navLabel=r.navLabel,scroll=r.scroll,close=r.close,baseline=baseline,
   marker={},baseWidth=baseline.width,baseHeight=baseline.height,baseHeadingWidth=580,width=baseline.width,height=baseline.height,headingWidth=580,navTop=54,navHeight=28,scrollTop=92,growth=0}
  -- Only construction-time numeric metadata is accepted; enhanced geometry is
  -- never recaptured as a new baseline.
  if not current() then return reject("RETIRED") end
  lives[r.root]=initial;state=initial
 end
 local function stateCurrent()
  return current() and lives[r.root]==state and state.root==r.root and state.heading==r.heading and state.nav==r.nav
   and state.navLabel==r.navLabel and state.scroll==r.scroll and state.close==r.close and state.baseline==baseline and baseline.width==state.baseWidth and baseline.height==state.baseHeight and baseline.headingWidth==state.baseHeadingWidth
 end
 local function markers()
  if not stateCurrent() then return false end
  if state.manual then return rawequal(lookup(r.heading,"mirageCopyChromeOwner"),state.marker) and rawequal(lookup(r.navLabel,"mirageCopyChromeOwner"),state.marker)
   and lookup(r.heading,"mirageManualFont")==true and lookup(r.navLabel,"mirageManualFont")==true and stateCurrent() end
  return not lookup(r.heading,"mirageManualFont") and not lookup(r.navLabel,"mirageManualFont") and stateCurrent()
 end
 local function geometry()
  if not markers() or not source() then return nil end
  if not rawequal(one(r.root,"GetParent"),parent) or not rawequal(one(r.heading,"GetParent"),r.root) or not rawequal(one(r.nav,"GetParent"),r.root)
   or not rawequal(one(r.navLabel,"GetParent"),r.nav) or not rawequal(one(r.scroll,"GetParent"),r.root) or not rawequal(one(r.close,"GetParent"),r.root) then return nil end
  if number(r.root,"GetWidth")~=state.width or number(r.root,"GetHeight")~=state.height or number(r.heading,"GetWidth")~=state.headingWidth
   or number(r.nav,"GetWidth")~=state.width-40 or number(r.nav,"GetHeight")~=state.navHeight or number(r.navLabel,"GetWidth")~=state.width-56 then return nil end
  if not anchored(r.heading,{"TOPLEFT",r.root,"TOPLEFT",22,-19},1) or not anchored(r.nav,{"TOPLEFT",r.root,"TOPLEFT",20,-state.navTop},1)
   or not anchored(r.navLabel,{"TOPLEFT",r.nav,"TOPLEFT",8,-7},1) or not anchored(r.scroll,{"TOPLEFT",r.root,"TOPLEFT",20,-state.scrollTop},2)
   or not same(point(r.scroll,2),{"BOTTOMRIGHT",r.root,"BOTTOMRIGHT",-40,25}) then return nil end
  if number(r.scroll,"GetWidth")~=state.width-60 or number(r.scroll,"GetHeight")~=state.height-state.scrollTop-25 then return nil end
  if not anchored(r.close,{"TOPLEFT",r.root,"TOPLEFT",state.width-42,-12},1) then return nil end
  local cw,ch=number(r.close,"GetWidth"),number(r.close,"GetHeight")
  if not positive(cw) or not positive(ch) or cw+14>state.width or ch+12>state.height then return nil end
  if state.headingWrap and (one(r.heading,"CanWordWrap")~=state.headingWrap.wrap or one(r.heading,"CanNonSpaceWrap")~=state.headingWrap.nonspace or one(r.navLabel,"CanWordWrap")~=state.navWrap.wrap or one(r.navLabel,"CanNonSpaceWrap")~=state.navWrap.nonspace or one(r.heading,"GetIndentedWordWrap")~=state.headingWrap.indent or one(r.navLabel,"GetIndentedWordWrap")~=state.navWrap.indent) then return nil end
  if state.manual and (not fontEqual(fontState(r.heading),state.headingFont) or not fontEqual(fontState(r.navLabel),state.navFont)) then return nil end
  if number(r.root,"GetNumPoints")~=1 then return nil end
  local anchor=point(r.root,1)
  local vertical={TOPLEFT=1,TOP=1,TOPRIGHT=1,LEFT=.5,CENTER=.5,RIGHT=.5,BOTTOMLEFT=0,BOTTOM=0,BOTTOMRIGHT=0}
  if not anchor or not rawequal(anchor[2],parent) or vertical[anchor[1]]==nil or vertical[anchor[3]]==nil then return nil end
  local scale=number(r.root,"GetEffectiveScale");local parentScale=number(parent,"GetEffectiveScale")
  if not positive(scale) or scale~=parentScale then return nil end
  local rr,pr=rect(r.root),rect(parent)
  if not rr or not pr or rr[3]~=state.width or rr[4]~=state.height then return nil end
  if not stateCurrent() then return nil end
  return {anchor=anchor,a=vertical[anchor[1]],root=rr,parent=pr,scale=scale}
 end
 local g=geometry();if not g then return reject("GEOMETRY_UNAVAILABLE") end
 -- Native failures may leave only one viewport mutation completed. Retain
 -- exact per-property progress; do not order a later pass by aggregate growth.
 local baseBody=state.baseHeight-117
 local currentBody=state.height-state.scrollTop-25
 if not positive(currentBody) or currentBody>baseBody then return reject("PARTIAL_GEOMETRY") end
 local function bounds(height)
  local delta=height-state.height;local bottom=g.root[2]-g.a*delta;local top=bottom+height
  return g.root[1]>=g.parent[1]+15 and g.root[1]+state.width<=g.parent[1]+g.parent[3]-15
   and bottom>=g.parent[2]+15 and top<=g.parent[2]+g.parent[4]-15
 end
 local plan
 if not r.key then
  plan={height=state.baseHeight,headingWidth=state.baseHeadingWidth,navTop=54,navHeight=28,scrollTop=92,growth=0}
 else
  if busy then return reject("METRICS_BUSY") end
  if not titles[r.key] then return reject("TITLE_UNAVAILABLE") end
  busy=r
  local ok,measured=pcall(function()
   if not frameAttempted then
    if not live(true) then return nil end
    frameAttempted=true
    if not spend("native") then return nil end
    local good,value=pcall(create,"Frame",nil,parent)
    if good then probeFrame=value end
    if not good or not live() then return nil end
   end
   if not security(probeFrame,true) then return nil end
   if not call(probeFrame,"Hide") or not call(probeFrame,"EnableMouse",false) or not call(probeFrame,"EnableKeyboard",false) then return nil end
   if not fontAttempted then
    local b=bind(probeFrame,"CreateFontString");if not b or not security(probeFrame,true) or not live(true) then return nil end
    fontAttempted=true
    if not spend("native") then return nil end
    local good,value=pcall(b.fn,probeFrame,nil,"OVERLAY")
    if good then probeFont=value end
    if not good or not live() then return nil end
   end
   if not security(probeFont,true) or not call(probeFont,"Hide") then return nil end
   local function measure(target,text,size,width)
    local wrap,okWrap=one(target,"CanWordWrap");local nonspace,okNonspace=one(target,"CanNonSpaceWrap");local indent,okIndent=one(target,"GetIndentedWordWrap")
    if not okWrap or not okNonspace or type(wrap)~="boolean" or type(nonspace)~="boolean" or not okIndent or type(indent)~="boolean" then return nil end
    local success,good=one(probeFont,"SetFont",font,size,"")
    if not good or success~=true or not fontEqual(fontState(probeFont),{font,size,""}) then return nil end
    if not call(probeFont,"SetWordWrap",wrap) or not call(probeFont,"SetNonSpaceWrap",nonspace) or not call(probeFont,"SetIndentedWordWrap",indent) or not call(probeFont,"SetWidth",width) or not call(probeFont,"SetText",text) then return nil end
    if one(probeFont,"CanWordWrap")~=wrap or one(probeFont,"CanNonSpaceWrap")~=nonspace or one(probeFont,"GetIndentedWordWrap")~=indent then return nil end
    local height=number(probeFont,"GetStringHeight");local wrapped=number(probeFont,"GetWrappedWidth");local truncated,read=one(probeFont,"IsTruncated")
    if not positive(height) or not positive(wrapped) or wrapped>width or not read or truncated~=false then return nil end
    return {height=height,wrap=wrap,nonspace=nonspace,indent=indent}
   end
   local h=measure(r.heading,titles[r.key],18*requestedScale,state.width-80)
   local n=h and measure(r.navLabel,navText,12*requestedScale,state.width-56)
   if not h or not n or not live() then return nil end
   return {heading=h,nav=n}
  end)
  if busy==r then busy=nil end
  if not ok or not measured or not current() then return reject("METRICS_UNAVAILABLE") end
  local navTop=math.max(54,19+math.ceil(measured.heading.height)+8)
  local navHeight=math.max(28,math.ceil(measured.nav.height)+14)
  local scrollTop=math.max(92,navTop+navHeight+10)
  plan={height=state.baseHeight+scrollTop-92,headingWidth=state.width-80,navTop=navTop,navHeight=navHeight,scrollTop=scrollTop,growth=scrollTop-92,measured=measured}
 end
 local growing=plan.height>state.height
 local intermediate=growing and state.height-plan.scrollTop-25 or plan.height-state.scrollTop-25
 if not positive(plan.height) or not positive(plan.headingWidth) or not positive(baseBody) or not positive(intermediate)
  or intermediate>baseBody or plan.height-plan.scrollTop-25~=baseBody or not bounds(plan.height) then return reject("SPACE_UNAVAILABLE") end
 -- Requalify all owned geometry after the measurement callbacks, not only before.
 local check=geometry()
 if not check or not same(check.anchor,g.anchor) then return reject("GEOMETRY_UNAVAILABLE") end
 for i=1,4 do if check.root[i]~=g.root[i] or check.parent[i]~=g.parent[i] then return reject("GEOMETRY_UNAVAILABLE") end end
 local hf,nf
 if r.key then
  hf,nf=fontState(r.heading),fontState(r.navLabel)
  if not hf or not nf or hf[1]~=font or nf[1]~=font or hf[3]~="" or nf[3]~="" then return reject("FONT_UNAVAILABLE") end
  if one(r.heading,"CanWordWrap")~=plan.measured.heading.wrap or one(r.heading,"CanNonSpaceWrap")~=plan.measured.heading.nonspace
   or one(r.navLabel,"CanWordWrap")~=plan.measured.nav.wrap or one(r.navLabel,"CanNonSpaceWrap")~=plan.measured.nav.nonspace or one(r.heading,"GetIndentedWordWrap")~=plan.measured.heading.indent or one(r.navLabel,"GetIndentedWordWrap")~=plan.measured.nav.indent or not stateCurrent() then return reject("METRICS_UNAVAILABLE") end
 end
 local function ownedGeometry()
  local observed=geometry()
  if not observed or not same(observed.anchor,g.anchor) or observed.scale~=g.scale then return false end
  for i=1,4 do if observed.parent[i]~=g.parent[i] then return false end end
  return observed.root[1]==g.root[1] and observed.root[2]==g.root[2]-g.a*(state.height-g.root[4]) and stateCurrent()
 end
 if r.key then
  -- Seal every intended real writer even on a zero-growth first admission;
  -- otherwise a later growth could silently adopt a replaced unused setter.
  for _,entry in ipairs({{r.root,"SetHeight"},{r.heading,"SetWidth"},{r.heading,"SetFont"},{r.nav,"SetPoint"},{r.nav,"SetHeight"},{r.navLabel,"SetFont"},{r.scroll,"SetPoint"}}) do
   if not bind(entry[1],entry[2]) then return reject("METHOD_UNAVAILABLE") end
  end
  if not pureOwner() then return reject("METHOD_OWNER_CHANGED") end
 end
 if r.key then
  if not ownedGeometry() or not markers() or not pureOwner() then return reject("GEOMETRY_UNAVAILABLE") end
  if not state.bindings then
   state.bindings={}
   for _,b in ipairs(bindings) do
    if rawequal(b.object,r.root) or rawequal(b.object,r.heading) or rawequal(b.object,r.nav) or rawequal(b.object,r.navLabel)
     or rawequal(b.object,r.scroll) or rawequal(b.object,r.close) or rawequal(b.object,parent) then state.bindings[#state.bindings+1]=b end
   end
  end
  if not state.manual then
   state.headingFont=hf;state.navFont=nf
   r.heading.mirageCopyChromeOwner=state.marker;if not current() then return false end
   r.heading.mirageManualFont=true;if not current() then return false end
   r.navLabel.mirageCopyChromeOwner=state.marker;if not current() then return false end
   r.navLabel.mirageManualFont=true;if not current() then return false end
   state.markerSlots={}
   for _,target in ipairs({r.heading,r.navLabel}) do
    for _,field in ipairs({{"mirageCopyChromeOwner",state.marker},{"mirageManualFont",true}}) do
     if type(target)=="table" and rawget(target,field[1])~=nil then state.markerSlots[#state.markerSlots+1]={object=target,key=field[1],expected=field[2]} end
    end
   end
   state.manual=true
  end
  state.headingWrap=plan.measured.heading;state.navWrap=plan.measured.nav
 end
 r.status="PARTIAL_UNCONFIRMED";r.fit=false
 local function write(target,key,...)
  if not stateCurrent() or not ownedGeometry() or not live() then return false end
  local b=bind(target,key);if not b or not live() then return false end
  if not spend("native") then return false end
  local ok,success,native=pcall(shape.writeGuarded,pureOwner,target,key,...)
  if not ok or success~=true or not stateCurrent() or not live() then return false end
  if key=="SetFont" and (not public(native) or native~=true or not stateCurrent()) then return false end
  return true
 end
 local function property(target,key,field,value,...)
  if state[field]==value then return true end
  if not write(target,key,...) then return false end
  state[field]=value
  return ownedGeometry() and stateCurrent()
 end
 -- Never temporarily enlarge the body: native scroll-range clamping can lose
 -- position. This ordering mitigates that path; it promises no native offset.
 if growing then
  if not property(r.scroll,"SetPoint","scrollTop",plan.scrollTop,"TOPLEFT",r.root,"TOPLEFT",20,-plan.scrollTop) then return false end
  if not property(r.root,"SetHeight","height",plan.height,plan.height) then return false end
 else
  if not property(r.root,"SetHeight","height",plan.height,plan.height) then return false end
  if not property(r.scroll,"SetPoint","scrollTop",plan.scrollTop,"TOPLEFT",r.root,"TOPLEFT",20,-plan.scrollTop) then return false end
 end
 if not property(r.heading,"SetWidth","headingWidth",plan.headingWidth,plan.headingWidth)
  or not property(r.nav,"SetPoint","navTop",plan.navTop,"TOPLEFT",r.root,"TOPLEFT",20,-plan.navTop)
  or not property(r.nav,"SetHeight","navHeight",plan.navHeight,plan.navHeight) then return false end
 state.growth=plan.growth
 if r.key then
  local function applyFont(target,field,size,measurement)
   if one(target,"CanWordWrap")~=measurement.wrap or one(target,"CanNonSpaceWrap")~=measurement.nonspace or one(target,"GetIndentedWordWrap")~=measurement.indent then return false end
   if not write(target,"SetFont",font,size,"") then return false end
   local actual=fontState(target);if not fontEqual(actual,{font,size,""}) then return false end
   state[field]=actual;return ownedGeometry() and stateCurrent()
  end
  if not applyFont(r.heading,"headingFont",18*requestedScale,plan.measured.heading)
   or not applyFont(r.navLabel,"navFont",12*requestedScale,plan.measured.nav) then return false end
 end
 local final=geometry()
 if not final or not same(final.anchor,g.anchor) or final.scale~=g.scale then return false end
 if final.root[1]~=g.root[1] or final.root[2]~=g.root[2]-g.a*(plan.height-g.root[4]) then return false end
 if not stateCurrent() or not pureOwner() then return false end
 r.status=r.key and "QUALIFIED" or "LEGACY_UNVALIDATED";r.fit=r.key~=nil
 if r.key then state.admittedScale=requestedScale end
 r.admittedScale=state.admittedScale
 return r.fit
end
open=function(self,request,title)
 -- Publish only bounded cosmetic metadata, never incoming title/payload/history.
 local r={root=request.root,heading=request.heading,nav=request.nav,navLabel=request.navLabel,scroll=request.scroll,close=request.close,
  current=request.current,write=request.write,writeGuarded=request.writeGuarded,baseline=request.baseline,status="UNVALIDATED",fit=false}
 self.current=r
 local state=lives[r.root];r.admittedScale=state and state.admittedScale
 local resolver=self.ResolveTitle
 if resolver~=resolveTitle then return false end
 local resolved,key=pcall(resolver,self,title)
 if self.current~=r or M.CopyChrome~=self or self.ResolveTitle~=resolver then return false end
 if resolved and type(key)=="string" and titles[key] then r.key=key end
 local ok,value=pcall(run,r)
 if not ok and self.current==r then r.status="UNCONFIRMED";r.fit=false end
 return ok and value==true
end
refresh=function(self,refreshCurrent)
 local r=self.current;if not r then return false end
 r.fit=false;r.status="UNVALIDATED"
 local ok,value=pcall(run,r,refreshCurrent)
 if not ok and self.current==r then r.status="UNCONFIRMED";r.fit=false end
 return ok and value==true
end

C.Open=open;C.Refresh=refresh
