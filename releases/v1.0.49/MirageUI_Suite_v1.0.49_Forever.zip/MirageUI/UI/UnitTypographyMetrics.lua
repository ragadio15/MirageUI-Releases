local _,M=...
-- Static ordinary-unit literals only. Native glyph/hidden metrics acceptance NOT_RUN.
local T={cacheCount=0};M.UnitTypographyMetrics=T
local rawget,type,ipairs,pcall=rawget,type,ipairs,pcall
local eq=rawequal
local function raw(t,k) if type(t)=='table' then return rawget(t,k) end end
local function finite(v) return type(v)=='number' and v==v and v~=math.huge and v~=-math.huge end
-- Qualify native UI-unit conversion once, then seal the exact observed value.
local function uiEqual(v,wanted) return finite(v) and finite(wanted) and math.abs(v-wanted)<=.001 end
local function positive(v) return finite(v) and v>0 and v<=16384 end
local function plain(v) return type(v)=='table' and getmetatable(v)==nil end
local function pack(...) return {n=select('#',...),...} end
local function clone(t) local r={};for k,v in pairs(t) do r[k]=type(v)=='table' and clone(v) or v end;return r end
local configKeys={'showNames','showPercent','showPower','showRoles','showStatus','showReady','nativeAuras','showAuras','debuffAccent'}
local clientKeys={'key','family','patch','build','interface','sourceMatched','allowed','IsRuntimeClient','RuntimeAvailable'}
local adapterKeys={'family','patch','build','interface','sourceCommit'}
local levels={};for i=1,1000 do levels[i]=string.format('%d',i) end
local generation,batches={},setmetatable({},{__mode='k'})
local probeFrame,probeFont,frameAttempted,fontAttempted,busy
local cache,order={},{}
local begin,measure,current,finish,invalidate,solve,label,route
local function slots(t,keys) local r={};for _,k in ipairs(keys) do r[k]=raw(t,k) end;return r end
local function sameSlots(t,keys,s)
 if type(t)~='table' then return false end
 for _,k in ipairs(keys) do if not eq(rawget(t,k),s[k]) then return false end end;return true
end
local function base(s)
 -- Captured objects cannot change type. Qualify them once per seal, then use
 -- direct raw reads without redundant per-field type dispatch. All identities
 -- and scalar slots are still checked at every original callback boundary.
 return s and type(s.profile)=='table' and type(s.modules)=='table' and type(s.config)=='table'
  and type(s.client)=='table' and type(s.adapter)=='table' and type(s.safety)=='table' and not s.closed and eq(s.generation,generation) and eq(rawget(M,'UnitTypographyMetrics'),T)
  and eq(rawget(T,'Begin'),begin) and eq(rawget(T,'Measure'),measure) and eq(rawget(T,'Current'),current)
  and eq(rawget(T,'Finish'),finish) and eq(rawget(T,'Invalidate'),invalidate) and eq(rawget(T,'Solve'),solve) and eq(rawget(T,'LevelLabel'),label)
  and eq(rawget(M,'profile'),s.profile) and eq(rawget(s.profile,'modules'),s.modules) and eq(rawget(s.modules,'UnitFrames'),s.config)
  and eq(rawget(s.profile,'textScale'),s.scale) and sameSlots(s.config,configKeys,s.cfg)
  and eq(rawget(M,'Client'),s.client) and eq(rawget(M,'adapter'),s.adapter)
  and sameSlots(s.client,clientKeys,s.cs) and sameSlots(s.adapter,adapterKeys,s.ads)
  and eq(rawget(M,'Safety'),s.safety) and eq(rawget(s.safety,'Readable'),s.readable) and eq(rawget(s.safety,'InCombat'),s.combat)
  and eq(rawget(_G,'issecretvalue'),s.secret) and eq(rawget(_G,'canaccessvalue'),s.access)
  and eq(rawget(_G,'canaccesstable'),s.tableAccess) and eq(rawget(_G,'InCombatLockdown'),s.combatNative)
  and eq(rawget(_G,'CreateFrame'),s.create) and eq(rawget(_G,'STANDARD_TEXT_FONT'),s.fontGlobal) and eq(rawget(_G,'UIParent'),s.parent)
end
current=function(_,b)
 local s=batches[b];if not base(s) then return false end
 for _,binding in ipairs(s.bindings or {}) do if not route(binding) then return false end end
 return true
end
T.Current=current
local function live(s)
 if not base(s) then return false end
 local ok,v=pcall(s.request)
 if not ok or v~=true or not base(s) then s.closed=true;return false end
 return true
end
local function spend(s,kind)
 local w=s.work
 s.count=(s.count or 0)+1
 if s.count>2000000 then s.closed=true;return false end
 rawset(w,'total',s.count)
 local n=rawget(w,kind);rawset(w,kind,(type(n)=='number' and n or 0)+1);return true
end
local function public(s,v)
 if not live(s) or not spend(s,'qualificationCalls') then return false end
 local ok,r=pcall(s.readable,s.safety,v)
 return ok and r==true and live(s)
end
local function source(s)
 local runtime=s.cs.IsRuntimeClient
 if type(runtime)~='function' or s.cs.allowed~=true or not live(s) then return false end
 local ok,value=pcall(runtime,s.client)
 return ok and value==true and live(s)
end
local function normalized(c)
 return {showNames=c.showNames~=false,showPercent=c.showPercent==true,showPower=c.showPower~=false,
  showRoles=c.showRoles==true,showStatus=c.showStatus==true,showReady=c.showReady==true,
  statusAura=c.nativeAuras~=true and c.showAuras==true and c.debuffAccent==true}
end
local function domain(c)
 local roles=c.showRoles and {'','Tank','Healer','Damage'} or {''}
 local states=c.showStatus and {'','Offline','Ghost','Dead'} or {''}
 local ready=c.showReady and {'','Ready','Not ready','Waiting'} or {''}
 local baseTexts={}
 for _,r in ipairs(roles) do for _,s in ipairs(states) do for _,q in ipairs(ready) do
  local pieces={};for _,v in ipairs({r,s,q}) do if v~='' then pieces[#pieces+1]=v end end
  baseTexts[#baseTexts+1]=table.concat(pieces,' · ')
 end end end
 baseTexts[#baseTexts+1]='Unit unavailable';baseTexts[#baseTexts+1]='Data unavailable'
 local result={};local aura=c.statusAura and {'','Magic','Curse','Poison','Disease'} or {''}
 for _,text in ipairs(baseTexts) do for _,a in ipairs(aura) do result[#result+1]=text..(text~='' and a~='' and ' · ' or '')..a end end
 return result
end
begin=function(_,profile,config,request)
 if busy then return nil,'METRICS_BUSY' end
 local s={generation=generation,profile=profile,config=config,modules=raw(profile,'modules'),scale=raw(profile,'textScale'),
  client=raw(M,'Client'),adapter=raw(M,'adapter'),safety=raw(M,'Safety'),request=request,
  create=CreateFrame,fontGlobal=STANDARD_TEXT_FONT,parent=UIParent,secret=issecretvalue,access=canaccessvalue,tableAccess=canaccesstable,combatNative=InCombatLockdown}
 s.readable=raw(s.safety,'Readable');s.combat=raw(s.safety,'InCombat');s.cfg=slots(config,configKeys);s.cs=slots(s.client,clientKeys);s.ads=slots(s.adapter,adapterKeys)
 s.work={total=0,limit=2000000,statusMeasurements=0,levelMeasurements=0,fixedMeasurements=0,metricGetters=0,qualificationCalls=0,nativeCalls=0,cacheHits=0}
 local ok,valid=pcall(function()
  if type(request)~='function' or type(s.readable)~='function' or type(s.combat)~='function' or not live(s) then return false end
  for _,v in ipairs({profile,config,s.client,s.adapter,s.parent}) do if not public(s,v) then return false end end
  if not plain(profile) or not plain(config) or not public(s,s.scale) or not finite(s.scale) or s.scale<.8 or s.scale>1.5 then return false end
  for _,k in ipairs(configKeys) do local v=s.cfg[k];if not public(s,v) or (v~=nil and type(v)~='boolean') then return false end end
  for _,k in ipairs(clientKeys) do if not public(s,s.cs[k]) then return false end end
  for _,k in ipairs(adapterKeys) do if not public(s,s.ads[k]) then return false end end
  if not source(s) or not public(s,s.fontGlobal) then return false end
  s.font=s.fontGlobal or 'Fonts\\FRIZQT__.TTF'
  if type(s.font)~='string' or #s.font<1 or #s.font>256 or s.font:find('[%c]') then return false end
  s.normal=normalized(s.cfg);s.widths={};s.widthCount=0
  return live(s)
 end)
 if not ok or not valid then return nil,'INPUT_UNAVAILABLE' end
 local b={work=s.work};batches[b]=s;return b
end
T.Begin=begin
finish=function(_,b) local s=batches[b];if s then s.closed=true;s.request=nil;batches[b]=nil end end
T.Finish=finish
invalidate=function() generation={};cache={};order={};T.cacheCount=0 end
T.Invalidate=invalidate
label=function(_,v)
 local S=raw(M,'Safety');local r=raw(S,'Readable')
 if type(r)~='function' then return nil end
 local ok,yes=pcall(r,S,v)
 if not ok or yes~=true or not eq(raw(M,'Safety'),S) or not eq(raw(S,'Readable'),r) or not finite(v) or v<1 or v>1000 or v%1~=0 then return nil end
 return levels[v]
end
T.LevelLabel=label
route=function(b)
 for _,p in ipairs(b.route) do
  if not eq(rawget(p.object,b.key),p.slot) or not eq(getmetatable(p.object),p.meta)
   or (p.tableMeta and not eq(rawget(p.meta,'__index'),p.index)) then return false end
 end
 return true
end
local function observation(s,token)
 local x={bindings={},map={}}
 function x:seal(full)
  if not eq(busy,token) or not base(s) then return false end
  if full then for _,b in ipairs(self.bindings) do if not route(b) then return false end end end
  return true
 end
 function x:lookup(object,key)
  if not public(s,object) then return nil end
  local ok,v=pcall(function() return object[key] end)
  if not ok or not public(s,v) or not self:seal() then return nil end;return v
 end
 function x:bind(object,key)
  local old=self.map[object] and self.map[object][key]
  if old and old.complete then return route(old) and old or nil end
  local fn=self:lookup(object,key);if type(fn)~='function' then return nil end
  if old then return eq(fn,old.fn) and old or nil end
  if #self.bindings>=128 then return nil end
  local parts,node,seen,complete={},object,{},false
  for _=1,8 do
   if type(node)~='table' or seen[node] then break end;seen[node]=true
   local slot,meta=rawget(node,key),getmetatable(node)
   if not public(s,slot) or not public(s,meta) then return nil end
   local index=type(meta)=='table' and rawget(meta,'__index') or nil
   if not public(s,index) then return nil end
   parts[#parts+1]={object=node,slot=slot,meta=meta,tableMeta=type(meta)=='table',index=index}
   if slot~=nil then complete=eq(slot,fn);break end
   if type(index)~='table' then break end;node=index
  end
  local b={object=object,key=key,fn=fn,route=parts,complete=complete}
  self.bindings[#self.bindings+1]=b;self.map[object]=self.map[object] or {};self.map[object][key]=b
  return self:seal() and b or nil
 end
 function x:legal()
  if not live(s) or not self:seal() then return false end
  for _,b in ipairs(self.bindings) do if not b.complete and not eq(self:lookup(b.object,b.key),b.fn) then return false end end
  if not spend(s,'nativeCalls') then return false end
  local ok,v=pcall(s.combat,s.safety)
  return ok and v==false and live(s) and self:seal(true)
 end
 function x:call(object,key,...)
  local b=self:bind(object,key)
  if not b or not live(s) or not eq(busy,token) or not route(b) or not spend(s,'nativeCalls') then return nil end
  local r=pack(pcall(b.fn,object,...))
  if not r[1] or not route(b) then return nil end
  -- Each public result check includes the owner on both sides of its callback;
  -- repeating all raw seals again between those checks adds no new observation.
  if r.n==1 and not live(s) then return nil end
  for i=2,r.n do if not public(s,r[i]) then return nil end end
  return eq(busy,token) and route(b) and r or nil
 end
 function x:one(object,key,...) local r=self:call(object,key,...);return r and r[2],r~=nil end
 function x:security(object,mutationTarget)
  local node,seen=object,{}
  for depth=1,32 do
   if not public(s,node) then return false end
   if node==nil then return depth>1 end
   if (type(node)~='table' and type(node)~='userdata') or seen[node] then return false end;seen[node]=true
   local forbidden,ok=self:one(node,'IsForbidden');if not ok or forbidden~=false then return false end
   if depth==1 and mutationTarget~=false then local protected,p=self:one(node,'IsProtected');if not p or protected~=false then return false end end
   local parent,p=self:one(node,'GetParent');if not p then return false end;node=parent
  end
  return false
 end
 function x:write(object,key,...)
  local b=self:bind(object,key)
  if not b or not self:security(object) then return nil end
  if eq(object,probeFont) or eq(object,probeFrame) then
   local parent,ok=self:one(object,'GetParent')
   if not ok or not eq(parent,eq(object,probeFont) and probeFrame or s.parent) then return nil end
  end
  if not self:legal() or not spend(s,'nativeCalls') or not self:seal(true) then return nil end
  local r=pack(pcall(b.fn,object,...))
  if not r[1] or not route(b) or not live(s) or not self:seal() then return nil end
  for i=2,r.n do if not public(s,r[i]) then return nil end end
  return self:seal() and r or nil
 end
 return x
end
local probeMethods={'Hide','SetFont','GetFont','SetWidth','GetWidth','SetHeight','GetHeight','SetWordWrap','CanWordWrap','SetNonSpaceWrap','CanNonSpaceWrap','SetIndentedWordWrap','GetIndentedWordWrap','SetMaxLines','GetMaxLines','SetSpacing','GetSpacing','SetText','GetText','GetLineHeight','GetStringHeight','GetWrappedWidth','GetUnboundedStringWidth','IsTruncated','GetParent','IsForbidden','IsProtected'}
local stageSuffix={Hide='HIDE',SetFont='SET_FONT',GetFont='GET_FONT',SetWidth='SET_WIDTH',GetWidth='GET_WIDTH',SetHeight='SET_HEIGHT',GetHeight='GET_HEIGHT',
 SetWordWrap='SET_WORD_WRAP',CanWordWrap='CAN_WORD_WRAP',SetNonSpaceWrap='SET_NON_SPACE_WRAP',CanNonSpaceWrap='CAN_NON_SPACE_WRAP',
 SetIndentedWordWrap='SET_INDENTED_WORD_WRAP',GetIndentedWordWrap='GET_INDENTED_WORD_WRAP',SetMaxLines='SET_MAX_LINES',GetMaxLines='GET_MAX_LINES',
 SetSpacing='SET_SPACING',GetSpacing='GET_SPACING',SetText='SET_TEXT',GetText='GET_TEXT',GetLineHeight='GET_LINE_HEIGHT',GetStringHeight='GET_STRING_HEIGHT',
 GetWrappedWidth='GET_WRAPPED_WIDTH',GetUnboundedStringWidth='GET_UNBOUNDED_STRING_WIDTH',IsTruncated='IS_TRUNCATED',GetParent='GET_PARENT',IsForbidden='IS_FORBIDDEN',IsProtected='IS_PROTECTED'}
local function setup(s,x)
 if not frameAttempted then
  s.stage='PROBE_FRAME_CREATE'
  if type(s.create)~='function' or not x:security(s.parent,false) or not x:legal() or not spend(s,'nativeCalls') or not x:seal(true) then return false end
  frameAttempted=true
  local ok,f=pcall(s.create,'Frame',nil,s.parent);if ok then probeFrame=f;T.probeFrame=f end
  if not ok or not live(s) then return false end
 end
 s.stage='PROBE_FRAME_PARENT';local frameParent,frameParentOK=x:one(probeFrame,'GetParent')
 if not frameParentOK or not eq(frameParent,s.parent) then return false end
 s.stage='PROBE_FRAME_SECURITY';if not x:security(probeFrame) then return false end
 s.stage='PROBE_FRAME_HIDE';if not x:write(probeFrame,'Hide') then return false end
 s.stage='PROBE_FRAME_MOUSE';if not x:write(probeFrame,'EnableMouse',false) then return false end
 s.stage='PROBE_FRAME_KEYBOARD';if not x:write(probeFrame,'EnableKeyboard',false) then return false end
 if not fontAttempted then
  s.stage='PROBE_FONT_CREATE'
  local b=x:bind(probeFrame,'CreateFontString');if not b or not x:security(probeFrame) or not x:legal() then return false end
  if not spend(s,'nativeCalls') or not x:seal(true) then return false end
  fontAttempted=true;local ok,f=pcall(b.fn,probeFrame,nil,'OVERLAY');if ok then probeFont=f;T.probeFont=f end
  if not ok or not live(s) then return false end
 end
 s.stage='PROBE_FONT_PARENT';local parent,ok=x:one(probeFont,'GetParent');if not ok or not eq(parent,probeFrame) then return false end
 s.stage='PROBE_FONT_SECURITY';if not x:security(probeFont) then return false end
 s.stage='PROBE_FONT_HIDE';if not x:write(probeFont,'Hide') then return false end
 s.stage='PROBE_FRAME_PARENT_VERIFY'
 parent,ok=x:one(probeFrame,'GetParent');if not ok or not eq(parent,s.parent) then return false end
 s.stage='PROBE_VISIBILITY';local shown,a=x:one(probeFrame,'IsShown');local visible,b=x:one(probeFont,'IsShown')
 if not a or not b or shown~=false or visible~=false then return false end
 for _,key in ipairs(probeMethods) do s.stage='PROBE_METHOD_'..stageSuffix[key];if not x:bind(probeFont,key) then return false end end
 s.stage='PROBE_LEGAL'
 return x:legal()
end
local function configure(s,x,size,width,wrap)
 s.stage='FONT_SET_FONT'
 local result=x:write(probeFont,'SetFont',s.font,size,'');if not result or result[2]~=true then return false end
 local expected={values={}}
 for _,r in ipairs({{'SetWidth',width,'GetWidth'},{'SetHeight',16384,'GetHeight'},
  {'SetWordWrap',wrap,'CanWordWrap'},{'SetNonSpaceWrap',false,'CanNonSpaceWrap'},
  {'SetIndentedWordWrap',false,'GetIndentedWordWrap'},{'SetMaxLines',0,'GetMaxLines'},{'SetSpacing',0,'GetSpacing'}}) do
  s.stage='FONT_WRITE_'..stageSuffix[r[1]];if not x:write(probeFont,r[1],r[2]) then return false end
  s.stage='FONT_READ_'..stageSuffix[r[3]];local value,ok=x:one(probeFont,r[3])
  local numeric=r[3]=='GetWidth' or r[3]=='GetHeight' or r[3]=='GetSpacing'
  local equal=numeric and uiEqual(value,r[2]) or eq(value,r[2])
  if not ok or not equal then return false end
  expected.values[#expected.values+1]={r[3],value}
 end
 s.stage='FONT_GET_FONT'
 local font=x:call(probeFont,'GetFont')
 if not font or font[2]~=s.font or not uiEqual(font[3],size) or font[4]~='' then return false end
 s.stage='FONT_LEGAL';if not x:legal() then return false end
 expected.font={font[2],font[3],font[4]};x.expected=expected;return true
end
local function state(s,x,value)
 local expected=x.expected;if not expected then return false end
 s.stage='STATE_FONT_PARENT';local parent,ok=x:one(probeFont,'GetParent');if not ok or not eq(parent,probeFrame) then return false end
 s.stage='STATE_FRAME_PARENT'
 parent,ok=x:one(probeFrame,'GetParent');if not ok or not eq(parent,s.parent) then return false end
 s.stage='STATE_VISIBILITY';local shown,a=x:one(probeFrame,'IsShown');local visible,b=x:one(probeFont,'IsShown')
 if not a or not b or shown~=false or visible~=false then return false end
 s.stage='STATE_FONT';local font=x:call(probeFont,'GetFont')
 if not font or font[2]~=expected.font[1] or font[3]~=expected.font[2] or font[4]~=expected.font[3] then return false end
 for _,r in ipairs(expected.values) do
  s.stage='STATE_'..stageSuffix[r[1]]
  local v,ok=x:one(probeFont,r[1]);if not ok or not eq(v,r[2]) then return false end
 end
 if value~=nil then s.stage='STATE_TEXT';local v,ok=x:one(probeFont,'GetText');if not ok or v~=value then return false end end
 s.stage='STATE_SEAL'
 return x:seal(true)
end
local function text(s,x,value)
 s.stage='TEXT_SET_TEXT'
 if not x:write(probeFont,'SetText',value) then return false end
 x.expected.text=value
 return state(s,x,value)
end
local function metric(s,x,key)
 s.stage='METRIC_'..stageSuffix[key]
 if not spend(s,'metricGetters') then return nil end
 local v,ok=x:one(probeFont,key);return ok and positive(v) and v or nil
end
local function cacheKey(s,width)
 local c=s.normal;local bits=''
 for _,k in ipairs({'showRoles','showStatus','showReady','statusAura'}) do bits=bits..(c[k] and '1' or '0') end
 return s.font..'\0'..string.format('%.17g',s.scale)..'\0'..(width and bits..'\0'..string.format('%.17g',width) or 'font')
end
local function signature(s,x)
 local r={client=s.client,adapter=s.adapter,source=s.ads.sourceCommit,parent=s.parent,font=probeFont,bindings={}}
 for _,b in ipairs(x.bindings) do r.bindings[#r.bindings+1]={object=b.object,key=b.key,fn=b.fn} end
 return r
end
local function compatible(s,x,r)
 if not r or not eq(r.client,s.client) or not eq(r.adapter,s.adapter) or r.source~=s.ads.sourceCommit or not eq(r.parent,s.parent) or not eq(r.font,probeFont) then return false end
 for _,b in ipairs(r.bindings) do local now=x:bind(b.object,b.key);if not now or not eq(now.fn,b.fn) then return false end end
 return x:legal()
end
local function put(key,value,sig)
 if not cache[key] then
  if #order>=18 then cache[table.remove(order,1)]=nil end
  order[#order+1]=key
 end
 cache[key]={value=clone(value),signature=sig};T.cacheCount=#order
end
local function read(s,width,token)
 local x=observation(s,token)
 if not setup(s,x) then return nil,'PROBE_UNAVAILABLE' end
 local fk,sk=cacheKey(s),cacheKey(s,width);local fentry,sentry=s.fontEntry or cache[fk],cache[sk]
 local fm,sm
 if fentry and compatible(s,x,fentry.signature) then fm=clone(fentry.value);rawset(s.work,'cacheHits',(rawget(s.work,'cacheHits') or 0)+1) end
 if sentry and compatible(s,x,sentry.signature) then sm=clone(sentry.value);rawset(s.work,'cacheHits',(rawget(s.work,'cacheHits') or 0)+1) end
 if not fm then
  if s.fontAttempted then return nil,'FONT_UNAVAILABLE' end
  s.fontAttempted=true;fm={}
  for _,r in ipairs({{'nameLine',12},{'detailLine',9},{'otherLine',11}}) do
   if not configure(s,x,r[2]*s.scale,16384,false) then return nil,'FONT_UNAVAILABLE' end
   local h=metric(s,x,'GetLineHeight');if not h or not state(s,x) then return nil,'METRICS_UNAVAILABLE' end
   fm[r[1]]=h;rawset(s.work,'fixedMeasurements',(rawget(s.work,'fixedMeasurements') or 0)+1)
  end
  fm.levelWidth=0;fm.levelHeight=0
  for i=1,1000 do
   if not text(s,x,levels[i]) then return nil,'TEXT_UNAVAILABLE' end
   local w,h=metric(s,x,'GetUnboundedStringWidth'),metric(s,x,'GetStringHeight')
   if not w or not h or not state(s,x,levels[i]) then return nil,'METRICS_UNAVAILABLE' end
   fm.levelWidth=math.max(fm.levelWidth,w);fm.levelHeight=math.max(fm.levelHeight,h);rawset(s.work,'levelMeasurements',(rawget(s.work,'levelMeasurements') or 0)+1)
  end
  if not text(s,x,'|') then return nil,'TEXT_UNAVAILABLE' end
  fm.separatorWidth=metric(s,x,'GetUnboundedStringWidth');if not fm.separatorWidth or not state(s,x,'|') then return nil,'METRICS_UNAVAILABLE' end
  rawset(s.work,'fixedMeasurements',(rawget(s.work,'fixedMeasurements') or 0)+1)
 end
 if not x:legal() then return nil,'REQUEST_RETIRED' end
 -- A complete font aggregate may be reused within this batch after a narrow
 -- status-width refusal; never repeat the 1000-label loop or publish a partial
 -- width into the global cache. Failed font preparation is one attempt/batch.
 s.fontEntry={value=clone(fm),signature=signature(s,x)}
 if not sm then
  if not configure(s,x,9*s.scale,width,true) then return nil,'FONT_UNAVAILABLE' end
  sm={statusHeight=0,statusWidth=0,statusCount=0}
  for _,v in ipairs(domain(s.normal)) do if v~='' then
   if not text(s,x,v) then return nil,'TEXT_UNAVAILABLE' end
   local h,w=metric(s,x,'GetStringHeight'),metric(s,x,'GetWrappedWidth')
   if not spend(s,'metricGetters') then return nil,'WORK_LIMIT' end
   s.stage='STATUS_TRUNCATION';local truncated,ok=x:one(probeFont,'IsTruncated')
   if not h or not w or w>width or not ok or truncated~=false or not state(s,x,v) then return nil,'STATUS_UNAVAILABLE' end
   sm.statusHeight=math.max(sm.statusHeight,h);sm.statusWidth=math.max(sm.statusWidth,w);sm.statusCount=sm.statusCount+1
   rawset(s.work,'statusMeasurements',(rawget(s.work,'statusMeasurements') or 0)+1)
  end end
 end
 if not x:legal() then return nil,'REQUEST_RETIRED' end
 local sig=signature(s,x)
 -- Publish only after the whole width observation succeeds and its owner survives.
 if not fm or not sm or not x:seal() then return nil,'REQUEST_RETIRED' end
 put(fk,fm,sig);put(sk,sm,sig);s.bindings=x.bindings
 local a={schema=1,scale=s.scale,font={path=s.font,flags='',nameSize=12*s.scale,detailSize=9*s.scale,otherSize=11*s.scale},config=clone(s.normal),detailWidth=width}
 for k,v in pairs(fm) do a[k]=v end;for k,v in pairs(sm) do a[k]=v end
 return a
end
measure=function(_,b,width)
 if busy then return nil,'METRICS_BUSY' end
 local s=batches[b]
 if not s then return nil,'REQUEST_RETIRED' end
 local token={};busy=token
 local good,value,reason,where=pcall(function()
  if not public(s,width) or not positive(width) or not live(s) then return nil,'INPUT_UNAVAILABLE' end
  local prior=s.widths[width];if prior and prior.reason then return nil,prior.reason,prior.stage end
  if not prior then if s.widthCount>=9 then return nil,'WIDTH_LIMIT' end;s.widthCount=s.widthCount+1;s.widths[width]={} end
  return read(s,width,token)
 end)
 if eq(busy,token) then busy=nil end
 if not good then value=nil;reason='METRICS_UNAVAILABLE' end
 where=not value and (where or s.stage) or nil
 if not value and finite(width) and s.widths and s.widths[width] then s.widths[width]={reason=reason or 'METRICS_UNAVAILABLE',stage=where} end
 return value,reason,where
end
T.Measure=measure
local function solveImpl(width,height,a)
 if not positive(width) or not positive(height) or not plain(a) or a.schema~=1 or not plain(a.font) or not plain(a.config) then return nil,'INVALID_METRICS' end
 if not finite(a.scale) or a.scale<.8 or a.scale>1.5 or a.detailWidth~=width-16 then return nil,'INVALID_METRICS' end
 for _,k in ipairs({'nameLine','detailLine','otherLine','statusHeight','statusWidth','levelWidth','levelHeight','separatorWidth'}) do if not positive(raw(a,k)) then return nil,'INVALID_METRICS' end end
 if a.statusWidth>a.detailWidth or not finite(a.statusCount) or a.statusCount<2 or a.statusCount>329 or a.statusCount%1~=0 then return nil,'INVALID_METRICS' end
 for _,k in ipairs({'showNames','showPercent','showPower','showRoles','showStatus','showReady','statusAura'}) do if type(raw(a.config,k))~='boolean' then return nil,'INVALID_METRICS' end end
 local font=a.font
 if type(font.path)~='string' or #font.path<1 or #font.path>256 or font.path:find('[%c]') or font.flags~='' or font.nameSize~=12*a.scale or font.detailSize~=9*a.scale or font.otherSize~=11*a.scale then return nil,'INVALID_METRICS' end
 local c=a.config;local nameH=a.nameLine+1;local otherH=a.otherLine+1;local levelH=math.max(a.otherLine,a.levelHeight)+1
 local header=math.max(c.showNames and nameH or 0,levelH)
 local detailH=math.max(a.detailLine,a.statusHeight)+1
 local band=math.max(11,c.showPercent and otherH or 0)
 local percentW=36*a.scale;local reserve=c.showPercent and 42*a.scale or 0
 local track=width-16-reserve;local nameW=width-16-a.levelWidth-a.separatorWidth-8
 if track<20 or a.levelWidth>width-16 or (c.showNames and nameW<=0) then return nil,'WIDTH_UNFIT' end
 local required=4+header+detailH+band+(c.showPower and band or 0)+(c.showPower and 3 or 2)
 if required>height then return nil,'HEIGHT_UNFIT',required end
 local function rect(x,y,w,h) return {x=x,y=y,width=w,height=h} end
 local function variant(power)
  local detailY=2+header+1;local healthY=detailY+detailH+1;local powerY=power and healthY+band+1 or healthY
  local boxes={name=rect(8,2,math.max(1,nameW),nameH),level=rect(width-8-a.levelWidth,2,a.levelWidth,levelH),
   separator=rect(width-8-a.levelWidth-4-a.separatorWidth,2,a.separatorWidth,otherH),detail=rect(8,detailY,width-16,detailH),
   health=rect(8,healthY+(band-5)/2,track,5),power=rect(8,powerY+(band-5)/2,track,5),
   healthPercent=rect(width-8-percentW,healthY+(band-otherH)/2,percentW,otherH),
   powerPercent=rect(width-8-percentW,powerY+(band-otherH)/2,percentW,otherH)}
  return {boxes=boxes,powerShown=power}
 end
 return {schema=1,width=width,height=height,scale=a.scale,font=clone(font),requiredHeight=required,present=variant(c.showPower),absent=variant(false)}
end
solve=function(_,width,height,a)
 local ok,p,why,needed=pcall(solveImpl,width,height,a)
 if not ok then return nil,'INVALID_METRICS' end;return p,why,needed
end
T.Solve=solve
