local _,M=...
local S=M.Safety
-- Private bounded presentation intake, never pet ability ownership/readiness.
local function same(a,b)
 if type(a)~=type(b) then return false end
 if type(a)~='table' then return a==b end
 if getmetatable(a) or getmetatable(b) then return false end
 for k,v in next,a do if not same(v,rawget(b,k)) then return false end end
 for k in next,b do if rawget(a,k)==nil then return false end end
 return true
end
local function copy(data,valid)
 local remaining,seen=2048,{}
 local function visit(value,depth)
  if not valid() or not S:Readable(value) or not valid() then error('Retired intake',0) end
  local t=type(value)
  if t~='table' then if t~='nil' and t~='string' and t~='number' and t~='boolean' then error('Invalid intake',0) end;return value end
  if depth>5 or getmetatable(value) or seen[value] then error('Invalid graph',0) end
  seen[value]=true;local result={};local key
  while true do
   remaining=remaining-1;if remaining<0 then error('Intake limit',0) end
   local k=next(value,key)
   if not S:Readable(k) or not valid() then error('Retired key',0) end
   if k==nil then break end
   if type(k)~='string' and (type(k)~='number' or k%1~=0 or k<1 or k>128) then error('Invalid key',0) end
   result[k]=visit(rawget(value,k),depth+1);key=k
  end
  return result
 end
 return visit(data,0)
end
local function integer(v,max) return type(v)=='number' and v==v and v%1==0 and v>=0 and v<=max end
local function keys(value,allowed)
 if type(value)~='table' then return false end
 for k in pairs(value) do if not allowed[k] then return false end end
 return true
end
local reasons={SOURCE_UNAVAILABLE='Source/client unavailable',ELIGIBILITY_UNAVAILABLE='Inspection unavailable',ENUM_UNAVAILABLE='Pet bank metadata unavailable',PET_UNAVAILABLE='Pet sample unavailable',BOOK_UNAVAILABLE='Pet spellbook unavailable',SLOT_LIMIT='Reported slot limit exceeded',PET_CHANGED='Pet guard changed',BOOK_CHANGED='Spellbook report changed',OBSERVATION_CHANGED='Sampled observation changed',CALL_BUDGET='Inspection work limit reached',REQUEST_RETIRED='Inspection retired'}
local failures={UNAVAILABLE=true,PET_SAMPLE_UNAVAILABLE=true,LIMIT_UNAVAILABLE=true}
local samples={OBSERVED_SCOPED_EMPTY=true,OBSERVED_SCOPED_SNAPSHOT=true,PARTIAL_UNAVAILABLE=true,PET_BOOK_NOT_REPORTED=true}
function M:PetSpellbookCards(data,valid)
 local references,pages=M.References,M.ReferenceView;local textMethod,pageMethod=references.Text,pages.Pages
 local ok,d=pcall(copy,data,valid)
 if not ok or type(d)~='table' or not keys(d,{state=true,reason=true,bank=true,client=true,epoch=true,contextEpoch=true,callCount=true,observationCalls=true,counts=true,rows=true}) then return nil end
 local state=d.state;local failure=failures[state]
 if not failure and not samples[state] then return nil end
 if d.bank~='PET' or type(d.client)~='string' or #d.client>64 or not integer(d.epoch,2147483647) or not integer(d.contextEpoch,2147483647) or not integer(d.callCount,1024) or not integer(d.observationCalls,265) or d.callCount<d.observationCalls then return nil end
 if d.reason~=nil and not reasons[d.reason] then return nil end
 local c,rows=d.counts,d.rows
 if not keys(c,{reportedSlots=true,inspectedSlots=true,shownSpells=true,nonSpellSlots=true,unknownSlots=true,changedSlots=true}) or type(rows)~='table' then return nil end
 for _,key in ipairs({'inspectedSlots','shownSpells','nonSpellSlots','unknownSlots','changedSlots'}) do if not integer(c[key],128) then return nil end end
 local count=0;for k in pairs(rows) do if not integer(k,128) or k<1 then return nil end;count=count+1 end
 if c.shownSpells~=count then return nil end
 if failure or state=='PET_BOOK_NOT_REPORTED' then
  if c.reportedSlots~=nil or count~=0 or c.inspectedSlots~=0 or c.nonSpellSlots~=0 or c.unknownSlots~=0 or c.changedSlots~=0 then return nil end
 else
  if not integer(c.reportedSlots,128) or c.inspectedSlots~=c.reportedSlots or c.shownSpells+c.nonSpellSlots+c.unknownSlots+c.changedSlots~=c.reportedSlots then return nil end
  if state=='OBSERVED_SCOPED_EMPTY' then if c.reportedSlots~=0 then return nil end
  elseif c.reportedSlots==0 then return nil end
  if state=='OBSERVED_SCOPED_SNAPSHOT' and count~=c.reportedSlots or state=='PARTIAL_UNAVAILABLE' and count==c.reportedSlots then return nil end
 end
 local cards={}
 local function add(a,b,c) if #cards>=1536 then error('Card limit',0) end;cards[#cards+1]={a,b,c} end
 if state=='PET_BOOK_NOT_REPORTED' then add('Pet spellbook not reported','Successful API report only','Not a missing-pet verdict')
 elseif state=='OBSERVED_SCOPED_EMPTY' then add('No Pet-bank entries reported','In this scoped sample','Not an ability absence claim')
 elseif failure then add(state=='LIMIT_UNAVAILABLE' and 'Pet spellbook limit exceeded' or 'Pet sample unavailable',reasons[d.reason] or 'No qualified sample retained','Reported slot count unknown')
 else add('Reported Pet-bank entries',state=='PARTIAL_UNAVAILABLE' and 'Partial scoped sample' or 'Scoped sequential sample','Not current or readiness') end
 add('Scope and limits','Not a learned/usable verdict','No atomic pet-owner guarantee')
 add('Reported slot counts',c.reportedSlots~=nil and 'Reported slots: '..c.reportedSlots or 'Reported slots: Unknown','Inspected slots: '..c.inspectedSlots)
 add('Slot projection','Shown Spell slots: '..c.shownSpells,'Non-Spell omitted: '..c.nonSpellSlots)
 add('Uncertain slots','Unknown slots: '..c.unknownSlots,'Changed/unavailable: '..c.changedSlots)
 local previous=0
 for i=1,count do
  local r=rows[i]
  if not keys(r,{slot=true,actionID=true,spellID=true,name=true,subName=true,passive=true}) or not integer(r.slot,128) or r.slot<=previous or r.slot>c.reportedSlots or not integer(r.actionID,2147483647) or r.actionID==0 or not integer(r.spellID,2147483647) or r.spellID==0 or type(r.passive)~='boolean' then return nil end
  previous=r.slot
  if not textMethod(references,r.name,64,false,false) or not valid() or not textMethod(references,r.subName,64,false,true) or not valid() then return nil end
  add('Pet bank - slot '..r.slot,'Reported Spell entry','Reported passive: '..(r.passive and 'true' or 'false'))
  local nameChunks=pageMethod(pages,r.name,16,1)
  for j=1,#nameChunks,2 do add('Slot '..r.slot..' - name',nameChunks[j],nameChunks[j+1] or '') end
  if r.subName~='' then
   local chunks=pageMethod(pages,r.subName,16,1)
   for j=1,#chunks,2 do add('Slot '..r.slot..' - native text',chunks[j],chunks[j+1] or '') end
  else add('Slot '..r.slot..' - native text','No subName text reported','No rank inference') end
 end
 local function unchanged()
  local intact,value=pcall(same,data,d)
  return intact and value==true and M.References==references and references.Text==textMethod and M.ReferenceView==pages and pages.Pages==pageMethod and valid()
 end
 if not unchanged() then return nil end
 return cards,state,unchanged,d
end
