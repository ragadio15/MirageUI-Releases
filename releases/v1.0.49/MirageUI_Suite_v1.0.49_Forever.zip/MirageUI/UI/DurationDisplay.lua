local _,M=...
-- Native automatic text binding. Duration values never return to MirageUI Lua.
M.DurationDisplay={}
local D=M.DurationDisplay
function D:Create(font)
    if not C_DurationUtil or type(C_DurationUtil.CreateDurationTextBinding)~="function" or not C_StringUtil or type(C_StringUtil.CreateSecondsFormatter)~="function" then return nil end
    local ok,binding=pcall(function()
        local b=C_DurationUtil.CreateDurationTextBinding()
        b:SetFontString(font);b:SetEnabled(false);b:SetUpdateInterval(.1)
        b:SetExpiredText("");b:SetZeroDurationText("")
        return b
    end)
    return ok and binding or nil
end
function D:Bind(record,font,duration,kind)
    if not record.nativeTextBinding and (record.nativeTextAttempts or 0)<3 then
        record.nativeTextAttempts=(record.nativeTextAttempts or 0)+1
        record.nativeTextBinding=self:Create(font)
    end
    local b=record.nativeTextBinding;local p=Enum and Enum.DurationTextBindingProperty
    if not b or not p then font:SetText("");return false end
    local ok=pcall(function()
        local f=record.nativeTextFormatter
        if not f then f=C_StringUtil.CreateSecondsFormatter();record.nativeTextFormatter=f end
        b:SetTextFormat("{} / {}",{{property=kind=="channel" and p.RemainingDuration or p.ElapsedDuration,formatter=f},{property=p.TotalDuration,formatter=f}})
        b:SetDuration(duration);b:SetEnabled(true)
    end)
    if not ok then self:Clear(record,font) end
    return ok
end
function D:Clear(record,font)
    if record.nativeTextBinding then pcall(record.nativeTextBinding.SetEnabled,record.nativeTextBinding,false) end
    -- Do not call GetFormattedText, read the FontString, or sample time properties.
    if font then pcall(font.SetText,font,"") end
end

function D:IsEmpowered(unit)
    -- Return 9 is documented as a non-secret categorical flag. No spell identity,
    -- stage duration or cast timestamps are inspected or retained here.
    if type(UnitChannelInfo)~="function" then return nil end
    local ok,flag=pcall(function() return select(9,UnitChannelInfo(unit)) end)
    if not ok or not M.Safety:Readable(flag) or type(flag)~="boolean" then return nil end
    return flag
end
