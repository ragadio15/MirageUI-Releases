local _,M=...
-- Ordinary secure units only. Observed logical geometry, never native pixel proof.
local T={};M.UnitTypography=T
local Metrics=M.UnitTypographyMetrics
local metricBegin,metricMeasure,metricSolve,metricCurrent,metricFinish,metricInvalidate,levelLabel=
 Metrics.Begin,Metrics.Measure,Metrics.Solve,Metrics.Current,Metrics.Finish,Metrics.Invalidate,Metrics.LevelLabel
local lives=setmetatable({},{__mode='k'})
local receipts=setmetatable({},{__mode='k'})
local request
local released={}
local qualifySource
local units={'player','target','focus','pet','boss1','boss2','boss3','boss4','boss5'}
local unitSet={};for _,u in ipairs(units) do unitSet[u]=true end
local fontKeys={'name','level','separator','detail','healthPercent','powerPercent'}
local boxKeys={'name','level','separator','detail','health','power','healthPercent','powerPercent'}
local configKeys={'showNames','showPercent','showPower','showRoles','showStatus','showReady','nativeAuras','showAuras','debuffAccent','showCast','showBuffs','auraSlots','panelOpacity','nameBacking','enabled'}
local layoutKeys={'x','y','width','height','scale','anchorTo'}
local globalKeys={'issecretvalue','canaccessvalue','canaccesstable','InCombatLockdown','RegisterUnitWatch','UnregisterUnitWatch','UnitWatchRegistered','RegisterStateDriver','UnregisterStateDriver'}
local function pack(...) return {n=select('#',...),...} end
local clientKeys={'family','key','patch','build','interface','sourceMatched','allowed','IsRuntimeClient','RuntimeAvailable'}
local function finite(x) return type(x)=='number' and x==x and x~=math.huge and x~=-math.huge end
local function eq(a,b) return rawequal(a,b) end
local function copyFields(t,keys) local r={};for _,k in ipairs(keys) do r[k]=rawget(t,k) end;return r end
local function fieldsSame(t,s,keys) if type(t)~='table' then return false end;for _,k in ipairs(keys) do if not eq(rawget(t,k),s[k]) then return false end end;return true end
local function requestCurrent(r)
 if not r or r.retired or not eq(request,r) or not eq(rawget(M,'UnitTypography'),T) or not eq(rawget(M,'profile'),r.profile)
  or not eq(rawget(M,'Client'),r.client) or not eq(rawget(M,'adapter'),r.adapter) or not eq(rawget(M,'Safety'),r.safety)
  or not eq(rawget(_G,'UIParent'),r.parent) or not eq(rawget(_G,'STANDARD_TEXT_FONT'),r.fontGlobal)
  or not eq(rawget(r.profile,'layouts'),r.layouts) or rawget(r.profile,'textScale')~=r.scale or rawget(r.profile,'managed')~=r.managed
  or rawget(r.profile,'enabled')~=r.enabled or not eq(rawget(r.profile,'modules'),r.modules)
  or not eq(rawget(r.modules,'UnitFrames'),r.config) or not fieldsSame(r.config,r.flags,configKeys)
  or not eq(rawget(M,'UnitTypographyMetrics'),Metrics) or rawget(Metrics,'Begin')~=metricBegin or rawget(Metrics,'Measure')~=metricMeasure or rawget(Metrics,'Solve')~=metricSolve or rawget(Metrics,'Current')~=metricCurrent or rawget(Metrics,'Finish')~=metricFinish or rawget(Metrics,'Invalidate')~=metricInvalidate or rawget(Metrics,'LevelLabel')~=levelLabel or not eq(rawget(M,'state'),r.state) or rawget(r.state,'safe')~=r.safe then return false end
 for _,k in ipairs(clientKeys) do if not eq(rawget(r.client,k),r.clientFields[k]) then return false end end
 for _,k in ipairs({'family','patch','build','interface','sourceCommit'}) do if not eq(rawget(r.adapter,k),r.adapterFields[k]) then return false end end
 for _,k in ipairs({'Readable','InCombat'}) do if not eq(rawget(r.safety,k),r.safetyMethods[k]) then return false end end
 for _,k in ipairs(globalKeys) do if not eq(rawget(_G,k),r.globals[k]) then return false end end
 for _,u in ipairs(units) do local id='UnitFrames.'..u;local l=rawget(r.layouts,id);local old=r.saved[u]
  if not eq(l,old.object) or (l and not fieldsSame(l,old.fields,layoutKeys)) then return false end
 end
 return true
end
local function configurable(r,view,unit)
 local mod=r.module
 return eq(rawget(M,'modules'),r.moduleRegistry) and eq(rawget(r.moduleRegistry,'UnitFrames'),mod)
  and eq(rawget(mod,'views'),r.moduleViews) and eq(rawget(r.moduleViews,unit),view)
  and rawget(r.state,'initialized')==true and rawget(r.state,'world')==true and rawget(r.client,'allowed')==true
  and rawget(r.profile,'enabled')==true and not rawget(r.state,'safe') and rawget(r.config,'enabled')==true
  and not rawget(mod,'quarantined') and not rawget(mod,'suspended') and not rawget(mod,'maintenanceFailed')
end
local function pure(q,intermediate,common)
 if not q or q.retired or not eq(q.request,request) or not configurable(q.request,q.view,q.unit) or (not common and not requestCurrent(q.request)) or not eq(lives[q.view],q.life) or not eq(q.life.op,q)
  or rawget(q.view,'unit')~=q.unit or (not q.fallback and rawget(q.view,'powerPresence')~=q.presence)
  or not eq(rawget(q.view,'frame'),q.frame) or not eq(rawget(q.view,'surface'),q.surface)
  or not eq(rawget(q.surface,'frame'),q.frame) or not eq(rawget(q.surface,'unitTypographyView'),q.view)
  or not eq(rawget(M,'surfaces'),q.surfaceRegistry) or rawget(q.surface,'id')~=q.surfaceID
  or not eq(rawget(q.surfaceRegistry,q.surfaceID),q.surface)
  or (q.anchorID and not eq(rawget(q.surfaceRegistry,q.anchorID),q.anchorTarget))
  or (q.anchorTarget and q.anchorTarget~=q.surface and not eq(rawget(q.anchorTarget,'frame'),q.anchor)) then return false end
 for k,v in pairs(q.slots) do if not eq(rawget(q.view,k),v) then return false end end
 for _,slot in ipairs(q.extraSeals) do if not eq(rawget(slot.object,slot.key),slot.value) then return false end end
 if not intermediate then for _,p in ipairs(q.routeObjects) do
  if not eq(getmetatable(p.object),p.meta) or (p.meta and not eq(rawget(p.meta,'__index'),p.index)) then return false end
  for key,slot in pairs(p.slots) do if not eq(rawget(p.object,key),slot.value) then return false end end
 end end
 if q.life.marker then for _,k in ipairs(fontKeys) do if not eq(rawget(q.slots[k],'mirageManualFont'),q.life.marker) then return false end end end
 if q.release and (not eq(M.ManagedNative,q.native) or not eq(rawget(q.native,'ReleaseCurrent'),q.releaseCurrent)) then return false end
 return true
end
local function current(q,intermediate)
 if not pure(q,intermediate) then return false end
 if q.release then local ok,yes=pcall(q.releaseCurrent,q.native,q.release);if not ok or yes~=true or not pure(q,intermediate) then return false end end
 return true
end
local function public(q,v)
 if not pure(q,true) then return false end
 q.work=q.work+1;if q.work>200000 then q.retired=true;return false end
 local ok,yes=pcall(q.request.safetyMethods.Readable,q.request.safety,v)
 return ok and yes==true and current(q,true)
end
local function bind(q,o,k)
 if not public(q,o) then return nil end
 local found=q.methods[o] and q.methods[o][k]
 local ok,fn=pcall(function() return o[k] end)
 if not ok or not public(q,fn) or type(fn)~='function' then return nil end
 if found then return eq(found.fn,fn) and found or nil end
 if #q.bindings>=512 then return nil end
 local route,node,seen,complete={},o,{},false
 for _=1,8 do
  if type(node)~='table' or seen[node] then break end;seen[node]=true
  local slot,meta=rawget(node,k),getmetatable(node)
  if meta~=nil and type(meta)~='table' then break end
  local index=meta and rawget(meta,'__index')
  route[#route+1]={object=node,slot=slot,meta=meta,index=index}
  if slot~=nil then complete=eq(slot,fn);break end
  if type(index)~='table' then break end;node=index
 end
 for _,part in ipairs(route) do
  local group=q.routeMap[part.object]
  if group then
   if not eq(group.meta,part.meta) or not eq(group.index,part.index) then return nil end
   if group.slots[k] and not eq(group.slots[k].value,part.slot) then return nil end
  else group={object=part.object,meta=part.meta,index=part.index,slots={}};q.routeMap[part.object]=group;q.routeObjects[#q.routeObjects+1]=group end
  group.slots[k]={value=part.slot}
 end
 local b={object=o,key=k,fn=fn,route=route,complete=complete}
 q.bindings[#q.bindings+1]=b;q.methods[o]=q.methods[o] or {};q.methods[o][k]=b
 return current(q,true) and b or nil
end
local function read(q,o,k,...)
 local b=bind(q,o,k);if not b or not current(q,true) then return nil end
 local result=pack(pcall(b.fn,o,...));local count=result.n
 if not result[1] or not current(q,true) then return nil end
 for i=2,count do if not public(q,result[i]) then return nil end end
 local values={};for i=2,count do values[i-1]=result[i] end;return values
end
local function safeTree(q,o)
 local seen={}
 for _=1,32 do
  if o==nil then return true end
  if seen[o] or not public(q,o) then return false end;seen[o]=true
  local f=read(q,o,'IsForbidden');if not f or f[1]~=false then return false end
  local p=read(q,o,'GetParent');if not p then return false end;o=p[1]
 end
 return o==nil
end
local function legal(q,o)
 if not current(q) or not safeTree(q,o) or not safeTree(q,q.anchor) then return false end
 -- Opaque routes are observed before nearest combat and pure ownership seal.
 for _,b in ipairs(q.bindings) do if not b.complete then
  local ok,fn=pcall(function() return b.object[b.key] end)
  if not ok or not eq(fn,b.fn) or not current(q) then return false end
 end end
 local ok,locked=pcall(q.request.safetyMethods.InCombat,q.request.safety)
 return ok and locked==false and current(q)
end
local function dispatch(q,o,key,...)
 local b=bind(q,o,key);if not b or not legal(q,o) then return false end
 local ok,answer=pcall(b.fn,o,...)
 return ok and current(q),answer
end
local function sameValues(a,b,tolerance)
 if not a or not b or #a~=#b then return false end
 for i=1,#a do if not eq(a[i],b[i]) then
  if not tolerance or not finite(a[i]) or not finite(b[i]) or math.abs(a[i]-b[i])>tolerance then return false end
 end end;return true
end
local function propertyTolerance(get)
 if get=='GetFont' or get=='GetSpacing' or get=='GetShadowOffset' then return .001 end
 if get=='GetScale' or get=='GetAlpha' or get=='GetShadowColor' then return .00001 end
end
local function remember(q,o,key,value)
 q.observed[o]=q.observed[o] or {};q.observed[o][key]=value
end
local function property(q,o,set,get,values,font)
 local old=read(q,o,get);if not old then return false end
 local b=bind(q,o,set);if not b then return false end
 local tolerance=propertyTolerance(get)
 if sameValues(old,values,tolerance) then remember(q,o,get,old);return true end
 local journal={object=o,set=set,get=get,old=old,written=values,font=font};q.journal[#q.journal+1]=journal
 local ok,result=dispatch(q,o,set,unpack(values));local observed=read(q,o,get)
 journal.observed=observed
 local accepted=ok and (not font or result==true) and sameValues(observed,values,tolerance)
 -- Rollback still compares the exact observed write, not a fuzzy owner seal.
 if accepted then journal.written=observed;remember(q,o,get,observed) end
 return accepted
end
local function sizeRead(q,o)
 local w=read(q,o,'GetWidth');local h=read(q,o,'GetHeight')
 if not w or not h or not finite(w[1]) or not finite(h[1]) or w[1]<0 or h[1]<0 then return nil end
 return {w[1],h[1]}
end
local function size(q,o,w,h)
 local old=sizeRead(q,o);if not old then return false end
 local expected={w,h};if sameValues(old,expected,.001) then remember(q,o,'size',old);return true end
 local journal={object=o,set='SetSize',old=old,written=expected,size=true};q.journal[#q.journal+1]=journal
 local ok=dispatch(q,o,'SetSize',w,h);local observed=sizeRead(q,o)
 local accepted=ok and sameValues(observed,expected,.001)
 if accepted then journal.written=observed;remember(q,o,'size',observed) end
 return accepted
end
local function pointRead(q,o)
 local n=read(q,o,'GetNumPoints');if not n or not finite(n[1]) or n[1]<0 or n[1]>8 or n[1]%1~=0 then return nil end
 local rows={};for i=1,n[1] do local p=read(q,o,'GetPoint',i)
  if not p or #p~=5 or type(p[1])~='string' or type(p[3])~='string' or not finite(p[4]) or not finite(p[5]) then return nil end;rows[i]=p
 end;return rows
end
local function samePoints(a,b,tolerance)
 if not a or not b or #a~=#b then return false end
 for i=1,#a do
  if not a[i] or not b[i] or #a[i]~=5 or #b[i]~=5 then return false end
  -- Anchor enums and frame identity always match exactly. Only pixel offsets
  -- allow the bounded floating-point conversion of native layout readback.
  for k=1,3 do if not eq(a[i][k],b[i][k]) then return false end end
  if not sameValues({a[i][4],a[i][5]},{b[i][4],b[i][5]},tolerance) then return false end
 end
 return true
end
local function points(q,o,list)
 local old=pointRead(q,o);if not old then return false end
 if samePoints(old,list,.001) then remember(q,o,'points',old);return true end
 local j={object=o,points=true,old=old,written={}};q.journal[#q.journal+1]=j
 if not dispatch(q,o,'ClearAllPoints') or not samePoints(pointRead(q,o),{}) then return false end
 for i,p in ipairs(list) do
  j.written[i]=p
  if not dispatch(q,o,'SetPoint',unpack(p)) then return false end
  local observed=pointRead(q,o);if not samePoints(observed,j.written,.001) then return false end
  j.written=observed
 end
 remember(q,o,'points',j.written);return true
end
local function rollback(q)
 for i=#q.journal,1,-1 do
  if not current(q) then return false end
  local j=q.journal[i];local value=j.points and pointRead(q,j.object) or j.size and sizeRead(q,j.object) or read(q,j.object,j.get)
  local same=j.points and samePoints(value,j.written) or not j.points and sameValues(value,j.written)
  if same then
   if j.points then
    if not dispatch(q,j.object,'ClearAllPoints') then return false end
    for _,p in ipairs(j.old) do if not dispatch(q,j.object,'SetPoint',unpack(p)) then return false end end
   else if not dispatch(q,j.object,j.set,unpack(j.old)) then return false end end
  end
 end
 return true
end
local function captureExtras(q)
 q.extraSeals={};q.extraObjects={}
 local function slot(object,key)
  local value=rawget(object,key);q.extraSeals[#q.extraSeals+1]={object=object,key=key,value=value};return value
 end
 q.panel=slot(q.frame,'miragePanel');q.backing=slot(q.view,'nameBacking')
 for _,key in ipairs({'castTrack','channelTrack'}) do
  local bar=slot(q.view,key)
  if bar then
   q.extraObjects[bar]=true
   for _,part in ipairs({'caption','icon','clock'}) do local object=slot(bar,part);if object then q.extraObjects[object]=true end end
  end
 end
 for _,key in ipairs({'extraAuras','extraBuffs'}) do
  local list=slot(q.view,key)
  if list then for i=1,8 do local object=slot(list,i);if object then q.extraObjects[object]=true end end end
 end
 for _,key in ipairs({'nativeHarmful','nativeHelpful'}) do
  local rail=slot(q.view,key)
  if rail then local holder=slot(rail,'holder');if holder then q.extraObjects[holder]=true end end
 end
 q.extras=M.UnitExtras;q.extraLayout=q.extras and q.extras.Layout
 q.extraSeals[#q.extraSeals+1]={object=M,key='UnitExtras',value=q.extras}
 if q.extras then q.extraSeals[#q.extraSeals+1]={object=q.extras,key='Layout',value=q.extraLayout} end
end
local function newOp(r,view,surface,layout)
 local life=lives[view];if not life or life.busy then return nil end
 local q={request=r,view=view,frame=view.frame,unit=view.unit,presence=view.powerPresence,surface=surface,life=life,layout=layout,slots={},bindings={},methods={},routeObjects={},routeMap={},journal={},observed={},work=0}
 q.surfaceRegistry=M.surfaces;q.surfaceID=surface.id;q.anchorID=layout.anchorTo
 q.anchorTarget=q.anchorID and rawget(q.surfaceRegistry,q.anchorID) or nil
 q.anchor=q.anchorTarget and q.anchorTarget~=surface and rawget(q.anchorTarget,'frame') or r.parent
 for _,k in ipairs(boxKeys) do q.slots[k]=rawget(view,k) end
 captureExtras(q)
 life.op=q;life.ready=nil;view.typographyReady=nil;view.typographyStatus='PREPARING'
 view.typographyRequested=copyFields(layout,layoutKeys);view.typographyRequestedScale=r.scale
 return q
end
local function captureRequest()
 local p,c,a,s=M.profile,M.Client,M.adapter,M.Safety
 if type(p)~='table' or type(p.modules)~='table' or type(p.modules.UnitFrames)~='table' or type(p.layouts)~='table' or type(c)~='table' or type(a)~='table' or type(s)~='table' then return nil end
 local cfg=p.modules.UnitFrames
 local r={profile=p,modules=p.modules,config=cfg,flags=copyFields(cfg,configKeys),client=c,adapter=a,safety=s,parent=UIParent,fontGlobal=STANDARD_TEXT_FONT,
 moduleRegistry=M.modules,module=M.modules.UnitFrames,moduleViews=M.modules.UnitFrames.views,state=M.state,safe=M.state.safe,layouts=p.layouts,scale=p.textScale,managed=p.managed,enabled=p.enabled,saved={},plans={},failures={},globals={},clientFields={},adapterFields={},safetyMethods={}}
 for _,k in ipairs(clientKeys) do r.clientFields[k]=rawget(c,k) end
 for _,k in ipairs({'family','patch','build','interface','sourceCommit'}) do r.adapterFields[k]=rawget(a,k) end
 for _,k in ipairs({'Readable','InCombat'}) do r.safetyMethods[k]=rawget(s,k) end
 for _,k in ipairs(globalKeys) do r.globals[k]=rawget(_G,k) end
 for _,u in ipairs(units) do local l=rawget(p.layouts,'UnitFrames.'..u);r.saved[u]={object=l,fields=l and copyFields(l,layoutKeys) or {}} end
 return r
end
function T:Begin(cause)
 for _,life in pairs(lives) do if life.busy then return false end end
 local retained=request;local stable=requestCurrent(retained)
 if stable then
  for view,life in pairs(lives) do
   local q=life.op
   if not q or not pure(q) or not ((life.ready==q and q.admitted) or
    (view.typographyStatus=='NATIVE_OWNERSHIP_RETAINED' and (view.typographyReason=='HEIGHT_UNFIT' or view.typographyReason=='WIDTH_UNFIT'))) then stable=false;break end
  end
 end
 if stable then retained.active=true;retained.cause=cause;return true end
 local old=request;if old then old.retired=true;if old.batch then pcall(metricFinish,Metrics,old.batch) end end
 local r=captureRequest();request=r
 for v,life in pairs(lives) do life.ready=nil;v.typographyReady=nil end
 if not r then return false end
 -- Probe capabilities once at this explicit layout boundary. All later
 -- dispatch guards retain the exact owner/identity/method snapshot and remain
 -- callback-free; a build number alone never supplies or denies permission.
 local runtime=r.clientFields.IsRuntimeClient
 local admitted,value=false,false
 if type(runtime)=='function' then admitted,value=pcall(runtime,r.client) end
 r.runtimeAvailable=admitted and value==true and requestCurrent(r) or false
 local ok,b,why=pcall(metricBegin,Metrics,r.profile,r.config,function() return requestCurrent(r) end)
 if ok and b and requestCurrent(r) then r.batch=b else r.batchReason=ok and why or 'METRICS_UNAVAILABLE' end
 r.active=true;r.cause=cause;self.lastWork=r.batch and r.batch.work or nil;return true
end
function T:End()
 local r=request;if not r then return end;r.active=false
 -- Keep the batch open for precomputed explicit layout consumption only; no
 -- event/Tick path calls Measure. A new explicit boundary closes it in Begin.
end
function T:Invalidate(reason)
 local r=request;if r then r.retired=true;if r.batch then pcall(metricFinish,Metrics,r.batch) end end
 pcall(metricInvalidate,Metrics,reason)
 for v,life in pairs(lives) do life.ready=nil;v.typographyReady=nil end
end
function T:Attach(view,surface)
 if not view or view.owner~='UnitFrames' or not unitSet[view.unit] or lives[view] then return false end
 lives[view]={};surface.unitTypographyView=view;view.surface=surface;view.typographyStatus='LEGACY_ACCESS_UNQUALIFIED';return true
end
function T:Owns(view) return lives[view]~=nil end
function T:OwnsFont(view) local l=lives[view];return l and l.marker and eq(rawget(view.name,'mirageManualFont'),l.marker) or false end
function T:LevelLabel(value) local ok,label=pcall(levelLabel,Metrics,value);return ok and label or nil end
local function admitted(q) return pure(q) and q.admitted==true and eq(q.life.ready,q) end
function T:Current(receipt) return admitted(receipts[receipt]) end
function T:GeometryReady(view) local l=lives[view];return l and admitted(l.ready) or false end
local function active(q)
 local r=q.request;local mod=r.module
 return eq(rawget(M,'modules'),r.moduleRegistry) and eq(rawget(r.moduleRegistry,'UnitFrames'),mod)
  and eq(rawget(mod,'views'),r.moduleViews) and eq(rawget(r.moduleViews,q.unit),q.view)
  and rawget(r.state,'initialized')==true and rawget(r.state,'world')==true and rawget(r.client,'allowed')==true
  and rawget(r.profile,'enabled')==true and not rawget(r.state,'safe') and rawget(mod,'initialized')==true
  and not rawget(mod,'quarantined') and not rawget(mod,'suspended') and rawget(r.config,'enabled')==true
  and rawget(q.view,'healthOK')==true and not rawget(mod,'maintenanceFailed')
end
function T:NativeReplacementReceipt(view)
 local l=lives[view];local q=l and l.ready
 if not q or not admitted(q) or not active(q) then return nil end
 return q.receipt
end
function T:ReplacementSignature()
 local r=request;local bits={};local live=requestCurrent(r)
 for _,unit in ipairs(units) do
  local view=live and rawget(r.moduleViews,unit);local life=view and lives[view];local q=life and life.ready
  bits[#bits+1]=q and q.admitted and pure(q,false,true) and active(q) and '1' or '0'
 end
 return table.concat(bits)
end
function T:PresentationAvailable(view,fact) return self:NativeReplacementReceipt(view)~=nil end
function T:Retire(view,reason)
 local life=lives[view];if not life then return end
 if life.op then life.op.retired=true end;life.ready=nil;view.typographyReady=nil;view.typographyStatus=reason or 'RETIRED'
end
local expressions={player='[petbattle] hide; [vehicleui] hide; [overridebar] hide; [combat] show; [@target,exists] show; [@focus,exists] show; hide',pet='[petbattle] hide; [vehicleui] hide; [@pet,noexists] hide; [combat] show; [@target,exists] show; [@focus,exists] show; hide'}
local function globalWrite(q,key,...)
 local fn=q.request.globals[key]
 if type(fn)~='function' or not eq(rawget(_G,key),fn) or not legal(q,q.frame) then return false end
 local ok=pcall(fn,...);return ok and current(q)
end
local function watch(q,wanted)
 local api=q.request.globals.UnitWatchRegistered
 if not qualifySource(q.request) or type(api)~='function' then return false end
 if not globalWrite(q,wanted and 'RegisterUnitWatch' or 'UnregisterUnitWatch',q.frame) then return false end
 local ok,value=pcall(api,q.frame)
 return ok and public(q,value) and value==wanted
end
local function registration(q,enable)
 local v=q.view
 if not enable then
  if v.managedVisibility then if not globalWrite(q,'UnregisterStateDriver',q.frame,'visibility') then return false end;v.managedVisibility=nil end
  if not watch(q,false) then return false end
  if not dispatch(q,q.frame,'Hide') then return false end
  local shown=read(q,q.frame,'IsShown');return shown and shown[1]==false
 end
 local expression=q.request.managed and expressions[v.unit]
 if expression then
  if not watch(q,false) then return false end
  if not globalWrite(q,'RegisterStateDriver',q.frame,'visibility',expression) then return false end
  v.managedVisibility=true;q.registration='DRIVER_SUBMITTED';return true
 end
 if v.managedVisibility then if not globalWrite(q,'UnregisterStateDriver',q.frame,'visibility') then return false end;v.managedVisibility=nil end
 if not watch(q,true) then return false end;q.registration='UNIT_WATCH_OBSERVED';return true
end
local function rootLayout(q)
 local l=q.layout;local anchor=q.anchor
 if not safeTree(q,anchor) then return false end
 local w=read(q,q.request.parent,'GetWidth');local h=read(q,q.request.parent,'GetHeight')
 if not w or not h or not finite(w[1]) or not finite(h[1]) then return false end
 local scale=(q.request.managed and l.scale) or 1
 local x,y=l.x*w[1],l.y*h[1];if anchor==q.request.parent then x=x/scale;y=y/scale end
 if not size(q,q.frame,l.width,l.height) or not property(q,q.frame,'SetScale','GetScale',{l.scale or 1}) then return false end
 q.rootPoint={'CENTER',anchor,'CENTER',x,y}
 return points(q,q.frame,{q.rootPoint})
end
local function installPlan(q,plan)
 local life=q.life
 if not life.marker then
  -- Exact widget-lifetime font owner survives revoked/pending requests.
  for _,k in ipairs(fontKeys) do if rawget(q.slots[k],'mirageManualFont')~=nil then return false end end
  life.marker={}
  for _,k in ipairs(fontKeys) do rawset(q.slots[k],'mirageManualFont',life.marker) end
 end
 if not rootLayout(q) then return false end
 local variant=q.view.powerPresence=='ABSENT' and plan.absent or plan.present
 for _,k in ipairs(fontKeys) do
  local o=q.slots[k];local n=k=='name' and plan.font.nameSize or k=='detail' and plan.font.detailSize or plan.font.otherSize
  if not property(q,o,'SetFont','GetFont',{plan.font.path,n,plan.font.flags},true)
   or not property(q,o,'SetWordWrap','CanWordWrap',{k=='detail'})
   or not property(q,o,'SetNonSpaceWrap','CanNonSpaceWrap',{false})
   or not property(q,o,'SetIndentedWordWrap','GetIndentedWordWrap',{false})
   or not property(q,o,'SetMaxLines','GetMaxLines',{0})
   or not property(q,o,'SetSpacing','GetSpacing',{0}) then return false end
 end
 if not property(q,q.slots.name,'SetShadowColor','GetShadowColor',{0,0,0,0}) or not property(q,q.slots.name,'SetShadowOffset','GetShadowOffset',{0,0}) then return false end
 for _,k in ipairs(boxKeys) do local b=variant.boxes[k];local o=q.slots[k]
  if not b or not points(q,o,{{'TOPLEFT',q.frame,'TOPLEFT',b.x,-b.y}}) or not size(q,o,b.width,b.height) then return false end
 end
 if not dispatch(q,q.slots.power,variant.powerShown and 'Show' or 'Hide') then return false end
 local shown=read(q,q.slots.power,'IsShown');if not shown or shown[1]~=variant.powerShown then return false end
 q.variant=q.view.powerPresence=='ABSENT' and 'absent' or 'present'
 return current(q)
end
local function appearance(q)
 if not q.panel or not q.backing or not property(q,q.panel,'SetAlpha','GetAlpha',{math.max(0,math.min(1,(q.request.flags.panelOpacity or 10)/100))}) then return false end
 local shown=q.request.flags.nameBacking==true
 if not dispatch(q,q.backing,shown and 'Show' or 'Hide') or not sameValues(read(q,q.backing,'IsShown'),{shown}) then return false end
 if type(q.extraLayout)~='function' then return false end
 local function write(object,key,...)
  if not q.extraObjects[object] or not current(q) then return false end
  return dispatch(q,object,key,...)
 end
 local ok,laid=pcall(q.extraLayout,q.extras,q.view,write,q.layout.width)
 return ok and laid==true and current(q)
end
local function finalState(q,plan)
 if not current(q) then return false end
 -- Numeric conversion is accepted only at the writer's readback. Every later
 -- property/point observation must match that exact captured value, including
 -- the observation after visibility registration callbacks.
 for object,properties in pairs(q.observed) do for key,written in pairs(properties) do
  if key=='points' then
   if not samePoints(pointRead(q,object),written) then return false end
  elseif key=='size' then
   if not sameValues(sizeRead(q,object),written) then return false end
  elseif not sameValues(read(q,object,key),written) then return false end
 end end
 local variant=q.view.powerPresence=='ABSENT' and plan.absent or plan.present
 if not sameValues(read(q,q.slots.power,'IsShown'),{variant.powerShown}) then return false end
 if q.registration=='UNIT_WATCH_OBSERVED' then
  local api=q.request.globals.UnitWatchRegistered;local ok,value=pcall(api,q.frame)
  if not ok or not public(q,value) or value~=true then return false end
 end
 return current(q)
end
qualifySource=function(r)
 return r.runtimeAvailable==true and r.clientFields.allowed==true and requestCurrent(r)
end
local function legacyAccess(q)
 -- Never-admitted initial controls keep the prior source access path when a
 -- native root cannot be established. This is explicitly not a fit certificate.
 if q.life.ever or not current(q) then return end
 if globalWrite(q,'RegisterUnitWatch',q.frame) then q.life.legacy=true end
end
local function run(q,plan,reason,stage)
 local v,life=q.view,q.life
 q.native=M.ManagedNative;q.releaseCurrent=q.native and q.native.ReleaseCurrent
 local release=q.native and q.native.ReleaseUnit
 if type(release)~='function' or type(q.releaseCurrent)~='function' then v.typographyStatus='HANDOFF_PENDING';legacyAccess(q);return false end
 local ok,receipt=pcall(release,q.native,v.unit,function() return pure(q) end)
 if not ok or not receipt or not pure(q) then
  if pure(q) then v.typographyStatus=life.ever and 'HANDOFF_PENDING' or 'LEGACY_ACCESS_UNQUALIFIED';legacyAccess(q) end
  return false
 end
 q.release=receipt
 if not current(q) then return false end
 if not plan then
  if registration(q,false) and rootLayout(q) then
   v.typographyStatus='NATIVE_OWNERSHIP_RETAINED';v.typographyReason=reason;v.typographyStage=stage;v.typographyRequested=copyFields(q.layout,layoutKeys);v.typographyRetained=copyFields(q.layout,layoutKeys)
   q.fallback=true;q.surface.layoutPending=nil;return true
  end
  v.typographyStatus='PARTIAL_UNCONFIRMED';return false
 end
 if not installPlan(q,plan) or not appearance(q) or not finalState(q,plan) or not registration(q,true) or not finalState(q,plan) then
  if current(q) then rollback(q);v.typographyStatus='PARTIAL_UNCONFIRMED' end
  return false
 end
 if not current(q) then return false end
 q.plan=plan;q.receipt={};receipts[q.receipt]=q;q.admitted=true;life.ready=q;life.ever=true;life.plan=plan;life.layout=q.layout;life.legacy=nil
 v.typographyRetainedScale=plan.scale;v.typographyReady=true;v.typographyStatus='CUSTOM_ADMITTED';v.typographyReason=nil;v.typographyStage=nil;v.typographyRequested=copyFields(q.layout,layoutKeys);v.typographyRetained=copyFields(q.layout,layoutKeys)
 v.layoutWidth=q.layout.width;v.layoutHeight=q.layout.height;v.powerLayoutPending=nil;q.surface.layoutPending=nil
 -- All callback-bearing cosmetic/layout work precedes the final observation;
 -- no callback occurs between that observation and this admission.
 return true
end
local function configure(r,view,surface,layout,plan,reason,stage)
 local q=newOp(r,view,surface,layout);if not q then return false end
 local life=q.life;life.busy=true
 local ok,result=pcall(run,q,plan,reason,stage)
 life.busy=nil
 if not ok and pure(q) then view.typographyStatus='PARTIAL_UNCONFIRMED';life.ready=nil;view.typographyReady=nil end
 if not result then surface.layoutPending=true end
 return ok and result==true
end
function T:Layout(surface,layout)
 local view=surface.unitTypographyView;local life=view and lives[view]
 if not life or life.busy then return false end
 local mod=M.modules.UnitFrames;local cfg=M.profile.modules.UnitFrames
 if mod.suspended or mod.quarantined or mod.maintenanceFailed or not cfg.enabled or not M.profile.enabled or M.state.safe or not M.state.world then self:Retire(view,'RETIRED');return false end
 local r=request
 if not requestCurrent(r) or not r.active then
  -- Repeated final layout passes consume the same exact admitted geometry.
  if r and requestCurrent(r) and life.op and fieldsSame(layout,life.op.layout,layoutKeys) then return self:GeometryReady(view) or view.typographyStatus=='NATIVE_OWNERSHIP_RETAINED' end
  if not self:Begin('LAYOUT') then return false end;r=request
 end
 if not requestCurrent(r) or not configurable(r,view,view.unit) then self:Retire(view,'RETIRED');return false end
 local key=view.unit;local cached=r.plans[key]
 if cached and fieldsSame(layout,cached.layout,layoutKeys) and life.op and life.op.request==r then return self:GeometryReady(view) or view.typographyStatus=='NATIVE_OWNERSHIP_RETAINED' end
 local plan,reason,needed,measured,stage
 if r.batchReason then reason=r.batchReason;stage='METRICS_BEGIN' end
 if qualifySource(r) and r.batch then
  local ok,aggregate,why,where=pcall(metricMeasure,Metrics,r.batch,layout.width-16)
  if ok and aggregate and requestCurrent(r) and metricCurrent(Metrics,r.batch) then
   local good,p,whyPlan,minimum=pcall(metricSolve,Metrics,layout.width,layout.height,aggregate)
   if good then plan=p;reason=whyPlan;needed=minimum;measured=true end
  else reason=ok and why or 'METRICS_UNAVAILABLE';stage=ok and where or 'METRICS_CALL' end
 end
 reason=reason or 'METRICS_UNAVAILABLE';if not requestCurrent(r) then return false end
 r.plans[key]={layout=copyFields(layout,layoutKeys),plan=plan,reason=reason,stage=stage,requiredHeight=needed,measured=measured}
 return configure(r,view,surface,copyFields(layout,layoutKeys),plan,reason,stage)
end
-- Read-only editor information from an already completed, source-qualified
-- static measurement. These APIs do not measure text, resize a live frame,
-- change a profile or grant a replacement receipt. A different draft width,
-- font size or text option needs an explicit Apply and fresh qualification.
local function fitDiagnostic(id,profile,layout)
 if type(id)~='string' then return nil,'FIT_UNAVAILABLE' end
 local unit=id:match('^UnitFrames%.(.+)$')
 if not unitSet[unit] then return nil,'FIT_UNAVAILABLE' end
 local r=request
 if not requestCurrent(r) or not qualifySource(r) then return nil,'FIT_STALE' end
 local view=rawget(r.moduleViews,unit);local life=view and lives[view];local q=life and life.op
 local cached=r.plans[unit]
 if not cached or not cached.measured or not q or not q.fallback or
  (cached.reason~='HEIGHT_UNFIT' and cached.reason~='WIDTH_UNFIT') then return nil,'FIT_UNAVAILABLE' end
 if not eq(q.request,r) or not current(q) or not fieldsSame(q.layout,cached.layout,layoutKeys) or
  rawget(view,'typographyStatus')~='NATIVE_OWNERSHIP_RETAINED' or rawget(view,'typographyReason')~=cached.reason then return nil,'FIT_STALE' end
 profile=profile or r.profile;layout=layout or (eq(profile,r.profile) and cached.layout)
 if type(profile)~='table' or getmetatable(profile)~=nil or type(layout)~='table' or getmetatable(layout)~=nil then return nil,'INVALID_FIT_LAYOUT' end
 local modules=rawget(profile,'modules');local config=type(modules)=='table' and rawget(modules,'UnitFrames')
 if rawget(profile,'enabled')~=true or type(config)~='table' or rawget(config,'enabled')~=true then return nil,'FIT_DISABLED' end
 if getmetatable(modules)~=nil or getmetatable(config)~=nil or rawget(profile,'textScale')~=r.scale or rawget(profile,'managed')~=r.managed or
  not fieldsSame(config,r.flags,configKeys) or rawget(layout,'width')~=cached.layout.width then return nil,'FIT_DRAFT_CHANGED' end
 local proposed=copyFields(layout,layoutKeys)
 for _,key in ipairs({'x','y','width','height','scale'}) do if not finite(proposed[key]) then return nil,'INVALID_FIT_LAYOUT' end end
 if proposed.width<24 or proposed.width>1200 or proposed.height<16 or proposed.height>800 or proposed.scale<.6 or proposed.scale>1.6 or
  (proposed.anchorTo~=nil and type(proposed.anchorTo)~='string') then return nil,'INVALID_FIT_LAYOUT' end
 local function valid()
  if not requestCurrent(r) or not eq(r.plans[unit],cached) or not current(q) or not qualifySource(r) or
   not eq(rawget(profile,'modules'),modules) or not eq(rawget(modules,'UnitFrames'),config) or
   rawget(profile,'enabled')~=true or rawget(profile,'textScale')~=r.scale or rawget(profile,'managed')~=r.managed or
   not fieldsSame(config,r.flags,configKeys) or not fieldsSame(layout,proposed,layoutKeys) or
   not r.batch then return false end
  local ok,yes=pcall(metricCurrent,Metrics,r.batch)
  return ok and yes==true and requestCurrent(r) and current(q)
 end
 -- Use only the already captured public frame-method routes. Reading this
 -- diagnostic must not spend or invalidate a live typography operation's budget.
 local function observe(object,key)
  local binding=q.methods[object] and q.methods[object][key]
  if not binding or not valid() then return nil,false end
  if not binding.complete then
   local observed,fn=pcall(function() return object[key] end)
   if not observed or not eq(fn,binding.fn) or not valid() then return nil,false end
  end
  local ok,value=pcall(binding.fn,object)
  if not ok or not valid() then return nil,false end
  local allowed,yes=pcall(r.safetyMethods.Readable,r.safety,value)
  return value,allowed and yes==true and valid()
 end
 local function tree(frame)
  local seen={}
  for _=1,32 do
   if frame==nil then return true end
   if seen[frame] then return false end;seen[frame]=true
   local forbidden,ok=observe(frame,'IsForbidden');if not ok or forbidden~=false then return false end
   local parent,public=observe(frame,'GetParent');if not public then return false end;frame=parent
  end
  return false
 end
 if not valid() then return nil,'FIT_STALE' end
 local ok,locked=pcall(r.safetyMethods.InCombat,r.safety)
 if not ok or locked~=false then return nil,'COMBAT_LOCKDOWN' end
 if not tree(q.frame) or not tree(q.anchor) or not valid() then return nil,'FIT_STALE' end
 -- This is the last callback. A callback entering combat or replacing any
 -- captured request/configuration invalidates the informational proposal too.
 ok,locked=pcall(r.safetyMethods.InCombat,r.safety)
 if not ok or locked~=false then return nil,'COMBAT_LOCKDOWN' end
 if not valid() then return nil,'FIT_STALE' end
 local required=cached.requiredHeight
 if cached.reason=='HEIGHT_UNFIT' and (not finite(required) or required<=cached.layout.height or required>16384) then return nil,'FIT_UNAVAILABLE' end
 return {id=id,reason=cached.reason,requiredHeight=cached.reason=='HEIGHT_UNFIT' and required or nil,
  measuredWidth=cached.layout.width,textScale=r.scale,layout=proposed,scope='STATIC_STATUS_AND_LOGICAL_BOXES'}
end
function T:FitDiagnostic(id,profile,layout)
 return fitDiagnostic(id,profile,layout)
end
function T:FitProposal(id,profile,layout)
 local diagnostic,reason=fitDiagnostic(id,profile,layout)
 if not diagnostic then return nil,reason end
 if diagnostic.reason~='HEIGHT_UNFIT' then return nil,'WIDTH_UNFIT' end
 local height=math.ceil(diagnostic.requiredHeight)
 if height>800 then return nil,'HEIGHT_LIMIT' end
 if diagnostic.layout.height>=height then return nil,'HEIGHT_ALREADY_SUFFICIENT' end
 diagnostic.layout.height=height
 return diagnostic
end
function T:SelectPowerVariant(view,presence)
 local life=lives[view];local q=life and life.ready
 if not q or life.busy then return false end
 local old=q.presence;q.presence=view.powerPresence
 local valid=admitted(q);q.presence=old
 if not valid then return false end
 local desired=presence=='ABSENT' and 'absent' or 'present';if q.variant==desired then q.presence=presence;return true end
 local ok,locked=pcall(q.request.safetyMethods.InCombat,q.request.safety)
 if not ok or locked~=false then view.powerLayoutPending=true;return false end
 return configure(q.request,view,q.surface,q.layout,q.plan,'POWER_VARIANT')
end
function T:Configure(view)
 local life=lives[view];if not life then return false end
 return M.Layout:Apply(view.surface)
end
function T:Suspend(view)
 self:Retire(view,'RETIRED')
end

function T:NativeReleased(unit,root)
 if not unitSet[unit] then return end
 local mod=M.modules.UnitFrames;local v=mod and mod.views and mod.views[unit];local life=v and lives[v]
 local r=request;local cached=r and r.plans[unit]
 if not life or not cached or not requestCurrent(r) or life.ready or life.busy then return end
 local status=v.typographyStatus
 if status~='HANDOFF_PENDING' and status~='LEGACY_ACCESS_UNQUALIFIED' then return end
 released[unit]={view=v,life=life,op=life.op,request=r,root=root,cached=cached}
end
function T:DrainReleased()
 if self.draining then return end;self.draining=true
 local snapshot=released;released={}
 for _,unit in ipairs(units) do
  local row=snapshot[unit]
  if row and requestCurrent(row.request) and lives[row.view]==row.life and row.life.op==row.op and not row.life.busy then
   configure(row.request,row.view,row.view.surface,row.cached.layout,row.cached.plan,row.cached.reason,row.cached.stage)
  end
 end
 self.draining=nil
end

function T:Report()
 local states={PREPARING=true,CUSTOM_ADMITTED=true,NATIVE_OWNERSHIP_RETAINED=true,HANDOFF_PENDING=true,LEGACY_ACCESS_UNQUALIFIED=true,PARTIAL_UNCONFIRMED=true,RETIRED=true}
 local reasons={HEIGHT_UNFIT=true,WIDTH_UNFIT=true,METRICS_UNAVAILABLE=true,INPUT_UNAVAILABLE=true,INVALID_METRICS=true,REQUEST_RETIRED=true,WIDTH_LIMIT=true,METRICS_BUSY=true,
  PROBE_UNAVAILABLE=true,FONT_UNAVAILABLE=true,TEXT_UNAVAILABLE=true,STATUS_UNAVAILABLE=true,WORK_LIMIT=true}
 local stages={METRICS_BEGIN=true,METRICS_CALL=true,PROBE_FRAME_CREATE=true,PROBE_FRAME_PARENT=true,PROBE_FRAME_SECURITY=true,PROBE_FRAME_HIDE=true,PROBE_FRAME_MOUSE=true,PROBE_FRAME_KEYBOARD=true,
  PROBE_FONT_CREATE=true,PROBE_FONT_PARENT=true,PROBE_FONT_SECURITY=true,PROBE_FONT_HIDE=true,PROBE_FRAME_PARENT_VERIFY=true,PROBE_VISIBILITY=true,PROBE_LEGAL=true,
  FONT_SET_FONT=true,FONT_GET_FONT=true,FONT_LEGAL=true,STATE_FONT_PARENT=true,STATE_FRAME_PARENT=true,STATE_VISIBILITY=true,STATE_FONT=true,STATE_TEXT=true,STATE_SEAL=true,TEXT_SET_TEXT=true,STATUS_TRUNCATION=true}
 for _,suffix in ipairs({'HIDE','SET_FONT','GET_FONT','SET_WIDTH','GET_WIDTH','SET_HEIGHT','GET_HEIGHT','SET_WORD_WRAP','CAN_WORD_WRAP','SET_NON_SPACE_WRAP','CAN_NON_SPACE_WRAP',
  'SET_INDENTED_WORD_WRAP','GET_INDENTED_WORD_WRAP','SET_MAX_LINES','GET_MAX_LINES','SET_SPACING','GET_SPACING','SET_TEXT','GET_TEXT','GET_LINE_HEIGHT','GET_STRING_HEIGHT',
  'GET_WRAPPED_WIDTH','GET_UNBOUNDED_STRING_WIDTH','IS_TRUNCATED','GET_PARENT','IS_FORBIDDEN','IS_PROTECTED'}) do stages['PROBE_METHOD_'..suffix]=true end
 for _,suffix in ipairs({'SET_WIDTH','SET_HEIGHT','SET_WORD_WRAP','SET_NON_SPACE_WRAP','SET_INDENTED_WORD_WRAP','SET_MAX_LINES','SET_SPACING'}) do stages['FONT_WRITE_'..suffix]=true end
 for _,suffix in ipairs({'GET_WIDTH','GET_HEIGHT','CAN_WORD_WRAP','CAN_NON_SPACE_WRAP','GET_INDENTED_WORD_WRAP','GET_MAX_LINES','GET_SPACING'}) do stages['FONT_READ_'..suffix]=true;stages['STATE_'..suffix]=true end
 for _,suffix in ipairs({'GET_LINE_HEIGHT','GET_STRING_HEIGHT','GET_WRAPPED_WIDTH','GET_UNBOUNDED_STRING_WIDTH'}) do stages['METRIC_'..suffix]=true end
 local function number(v) return finite(v) and v>=0 and v<=16384 and tostring(v) or 'UNKNOWN' end
 local function dimensions(l) return type(l)=='table' and number(rawget(l,'width'))..'x'..number(rawget(l,'height')) or 'UNKNOWN' end
 local lines={'unit_typography_scope=ORDINARY_UNITS_ONLY','unit_typography_native=NOT_RUN','unit_typography_fit=STATIC_STATUS_AND_LOGICAL_BOXES_NOT_ARBITRARY_GLYPHS'}
 local mod=M.modules.UnitFrames
 for _,unit in ipairs(units) do local v=mod and mod.views and mod.views[unit]
  if v and lives[v] then
   local state=rawget(v,'typographyStatus');local reason=rawget(v,'typographyReason');local stage=rawget(v,'typographyStage')
   lines[#lines+1]='unit_typography.'..unit..'='..(states[state] and state or 'UNKNOWN')..
    ';reason='..(reasons[reason] and reason or 'NONE_OR_UNAVAILABLE')..
    ';stage='..(stages[stage] and stage or 'NONE_OR_UNAVAILABLE')..
    ';requested='..dimensions(rawget(v,'typographyRequested'))..'@'..number(rawget(v,'typographyRequestedScale'))..
    ';retained='..dimensions(rawget(v,'typographyRetained'))..'@'..number(rawget(v,'typographyRetainedScale'))
   local diagnostic=self:FitDiagnostic('UnitFrames.'..unit)
   if diagnostic and diagnostic.requiredHeight then lines[#lines+1]='unit_typography.'..unit..'.minimum_height='..number(diagnostic.requiredHeight)..';measured_width='..number(diagnostic.measuredWidth)..';scope=STATIC_STATUS_AND_LOGICAL_BOXES' end
  end
 end
 lines[#lines+1]='unit_typography_pending=Missing metrics or an unfit layout retain native controls; requested settings remain saved. Use the explicit measured Fit action for a height refusal, or retry unavailable metrics after native access is available. Native handback refusals remain pending.'
 return table.concat(lines,'\n')
end
