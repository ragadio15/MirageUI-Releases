local _, M = ...
M.Display={}
local D=M.Display
local function semanticText(parent,size,width)
    local f=M.UI:Text(parent,"",0,0,size,width)
    f.mirageSemanticColor=true
    return f
end
function D:UnitInfo(view,unavailable)
    -- Standalone resource widgets retain their minimal label path.
    if not view.detail then
        local name=M.Safety:Public(UnitName,"string",view.unit)
        if unavailable==nil then unavailable=view.healthOK==false or view.powerOK==false end
        view.name.mirageSemanticColor=true
        M.Visual:Name(view.name,view.unit,unavailable and ((view.unitLabel or "Unit").." — data unavailable") or (name and name:gsub("|","||") or view.unitLabel or "Unit"),12*(M.profile.textScale or 1))
        return
    end
    local cfg=M:ModuleConfig(view.owner) or {}
    local owner=M.modules[view.owner]
    local data=M.UnitState:Read(view.unit,cfg.showReady and owner and owner.readyActive)
    view.meta=data
    view.healthColor=M.Visual.health
    local compact=view.isRaid and not view.headerRole and (view.previewCompact or cfg.compactRaid~=false)
    view.compactRaid=compact
    view.nameText=not compact and cfg.showNames~=false and (data.name or "") or ""
    if M.UnitTypography and M.UnitTypography:OwnsFont(view) then
        local color,source=M.Visual:ClassColor(view.unit)
        view.name:SetTextColor(color[1],color[2],color[3],1);view.name:SetText(view.nameText)
        view.nameColorSource=source
    else view.nameColorSource=M.Visual:Name(view.name,view.unit,view.nameText,12*(M.profile.textScale or 1)) end
    local level=not compact and data.level and tostring(data.level) or ""
    if M.UnitTypography and M.UnitTypography:Owns(view) then level=not compact and M.UnitTypography:LevelLabel(data.level) or "" end
    view.level:SetText(level or "")
    view.separator:SetText(view.nameText~="" and data.level and "|" or "")
    local status={}
    if cfg.showRoles and data.role~="" then status[#status+1]=data.role end
    if cfg.showStatus and data.state~="" then status[#status+1]=data.state end
    if cfg.showReady and data.ready~="" then status[#status+1]=data.ready end
    if data.availability=="UNKNOWN" then status={"Unit unavailable"} end
    view.detailText=table.concat(status," · ")
    self:UnitText(view,unavailable)
end
function D:UnitText(view,unavailable)
    if unavailable==nil then unavailable=view.healthOK==false or view.powerOK==false end
    local detail=unavailable and "Data unavailable" or (view.detailText or "")
    if view.auraCategory then detail=detail..(detail~="" and " · " or "")..view.auraCategory end
    -- Status text never becomes part of the character-name FontString.
    view.name:SetText(view.compactRaid and "" or (view.nameText or ""))
    view.detail:SetText(detail)
    if view.compactRaid then
        view.level:SetText("");view.separator:SetText("")
        view.healthPercent:SetText("");view.powerPercent:SetText("")
    end
end
local function percent(fs,api,unit,...)
    fs:SetText("")
    if type(api)~="function" or type(fs.SetFormattedText)~="function" then return end
    -- Percent is already scaled by a native curve: no numeric inspection or arithmetic.
    local ok,value=pcall(api,unit,...)
    if not ok then return end
    if M.Safety:Readable(value) and value==nil then return end
    if not pcall(fs.SetFormattedText,fs,"%.0f%%",value) then fs:SetText("") end
end
function D:PowerPresence(view,unit)
    local kind,known=M.Safety:Public(UnitPowerType,"number",unit)
    local presence="UNKNOWN"
    if known=="KNOWN" then
        local has,status=M.Safety:Public(UnitHasPowerType,"boolean",unit,kind)
        if status=="KNOWN" then presence=has and "PRESENT" or "ABSENT" end
        -- Zero public capacity is absence of a resource track, not a combat-health rule.
        -- Restricted capacity is never inspected or normalized to zero.
        if presence~="ABSENT" and not M.Safety:InCombat() then
            local maximum,access=M.Safety:Public(UnitPowerMax,"number",unit,kind)
            if access=="KNOWN" and maximum==0 then presence="ABSENT"
            elseif access=="KNOWN" and maximum>0 then presence="PRESENT" end
        end
    end
    if view.powerPresence~=presence then
        view.powerPresence=presence
        if view.detail then
            if not M.Safety:InCombat() then self:SizeUnit(view,view.layoutWidth or 300,view.layoutHeight or 55)
            else view.powerLayoutPending=true end
        end
    end
end
local function clearUnit(view)
    view.meta=nil;view.nameText="";view.detailText="";view.powerPresence="UNKNOWN"
    M.UI:BeamColor(view.health,0,0,0,0);M.UI:BeamColor(view.power,0,0,0,0)
    for _,key in ipairs({"name","level","separator","detail","healthPercent","powerPercent"}) do if view[key] then view[key]:SetText("") end end
    if M.UnitExtras then M.UnitExtras:Clear(view) end
end
local function paintUnit(view,unit,refreshInfo)
    if not M.Client.allowed then return end
    view.unit=unit
    if not M.Safety:Text(unit) or unit=="" then clearUnit(view);return end
    if refreshInfo or view.powerPresence==nil then D:PowerPresence(view,unit) end
    local healthOK=pcall(function()
        view.health:SetMinMaxValues(0,UnitHealthMax(unit));view.health:SetValue(UnitHealth(unit))
    end)
    local powerOK=pcall(function()
        view.power:SetMinMaxValues(0,UnitPowerMax(unit));view.power:SetValue(UnitPower(unit))
    end)
    local powerReady=view.powerPresence=="ABSENT" or powerOK
    local hc=M.Visual.health
    view.healthColor=hc
    M.UI:BeamColor(view.health,hc[1],hc[2],hc[3],healthOK and 1 or 0)
    local pc=M.Visual.mana
    local powerType,access=M.Safety:Public(UnitPowerType,"number",unit)
    if access=="KNOWN" and powerType~=0 then
        local native=M.Safety:Field(PowerBarColor,powerType)
        local rr,gg,bb=M.Safety:Field(native,"r"),M.Safety:Field(native,"g"),M.Safety:Field(native,"b")
        if M.Safety:Number(rr) and M.Safety:Number(gg) and M.Safety:Number(bb) then pc={rr,gg,bb}
        else pc=M.Visual.neutral end
    elseif access~="KNOWN" then pc=M.Visual.neutral end
    M.UI:BeamColor(view.power,pc[1],pc[2],pc[3],(powerOK and view.powerPresence~="ABSENT") and 1 or 0)
    if view.powerPercent then view.powerPercent:SetTextColor(pc[1],pc[2],pc[3],1) end
    if refreshInfo or not view.meta or not view.detail then D:UnitInfo(view,not healthOK or not powerReady) else D:UnitText(view,not healthOK or not powerReady) end
    if view.healthPercent then
        local cfg=M:ModuleConfig(view.owner) or {}
        view.healthPercent:SetText("");view.powerPercent:SetText("")
        local curve=CurveConstants and CurveConstants.ScaleTo100
        if cfg.showPercent and not view.compactRaid and curve then
            percent(view.healthPercent,UnitHealthPercent,unit,true,curve)
            if cfg.showPower~=false and view.powerPresence~="ABSENT" then percent(view.powerPercent,UnitPowerPercent,unit,nil,false,curve) end
        end
    end
    return healthOK,powerReady,powerOK
end
-- Readiness is withheld throughout an interleaved paint/clear transaction.
-- This is producer dispatch freshness, not native pixels, custody or input proof.
local unitWrites=setmetatable({},{__mode="k"})
-- A generation describes only this source's group paint/clear dispatch lifetime.
-- It does not inspect native values or certify pixels, clicks or foreign writers.
local groupGenerations={party={},raid={}}
local viewGenerations=setmetatable({},{__mode="k"})
function D:GroupGeneration(kind)
    if not rawequal(self,D) or not rawequal(M.Display,D) then return nil end
    return groupGenerations[kind]
end
function D:ViewGeneration(view)
    if not rawequal(self,D) or not rawequal(M.Display,D) then return nil end
    return viewGenerations[view]
end
local function writeUnit(view,unit,work,refreshInfo)
    -- Seal the actual dispatched view independently of mutable owner/kind labels.
    viewGenerations[view]={}
    if view.owner=="PartyRaid" then groupGenerations[view.isRaid and "raid" or "party"]={} end
    local state=unitWrites[view]
    if not state then state={depth=0};unitWrites[view]=state end
    local token={};state.token=token;state.depth=state.depth+1
    local frame,health,power=view.frame,view.health,view.power
    view.healthOK=false;view.powerOK=false;view.providerStatus="NATIVE_DISPLAY_UNAVAILABLE"
    local ok,healthOK,powerOK,rawPowerOK=pcall(work,view,unit,refreshInfo)
    local checked,current=pcall(function()
        return ok and healthOK~=nil and M.Safety:Text(view.unit)
            and view.frame==frame and view.health==health and view.power==power and view.unit==unit
            and M.Client.allowed==true and state.depth==1 and state.token==token
    end)
    if not checked then ok=false;healthOK=current end
    state.depth=state.depth-1
    -- Nested writers never publish provisional success. A suspended outer writer
    -- may still finish existing art operations, but cannot renew invalidated readiness.
    if state.depth==0 then unitWrites[view]=nil end
    view.healthOK=false;view.powerOK=false;view.providerStatus="NATIVE_DISPLAY_UNAVAILABLE"
    if ok and current and healthOK~=nil then
        view.healthOK=healthOK;view.powerOK=powerOK
        view.providerStatus=(healthOK and rawPowerOK) and "NATIVE_WIDGET_DISPATCH" or "NATIVE_DISPLAY_UNAVAILABLE"
    end
    if not ok then error(healthOK,0) end
end
function D:ClearUnit(view)
    return writeUnit(view,view.unit,clearUnit)
end
function D:UnitBars(view,unit,refreshInfo)
    return writeUnit(view,unit,paintUnit,refreshInfo)
end
function D:Cooldown(widget,fn,...)
    if type(fn)~="function" or type(widget.SetCooldownFromDurationObject)~="function" then if widget.Clear then widget:Clear() end;return "UNSUPPORTED" end
    local ok,duration=pcall(fn,...)
    if not ok then if widget.Clear then widget:Clear() end;return "UNAVAILABLE" end
    if M.Safety:Readable(duration) and duration==nil then
        if widget.Clear then widget:Clear() end
        return "NO_OBJECT"
    end
    -- Opaque duration goes directly to its documented consumer, not to CVE.
    local sent=pcall(widget.SetCooldownFromDurationObject,widget,duration,true)
    if not sent and widget.Clear then widget:Clear() end
    return sent and "NATIVE_WIDGET_DISPATCH" or "UNAVAILABLE"
end
function D:CreateUnit(name,unit,label,parent,owner,passive)
    assert(not M.Safety:InCombat(),"Secure units must be prepared outside combat")
    local f=CreateFrame(passive and "Frame" or "Button",name,parent or UIParent,passive and "BackdropTemplate" or "SecureUnitButtonTemplate,BackdropTemplate")
    f:Hide()
    if not passive then
        f:SetAttribute("unit",unit);f:SetAttribute("type1","target");f:SetAttribute("type2","togglemenu")
        f:RegisterForClicks("AnyUp");f:SetAttribute("useOnKeyDown",false)
    else M.Safety:Passive(f) end
    local view=self:DecorateUnit(f,unit,label,owner,passive)
    if not passive and (owner~=nil and owner~="UnitFrames" or not M.UnitTypography) and type(RegisterUnitWatch)=="function" then RegisterUnitWatch(f) end
    return view
end
function D:DecorateUnit(f,unit,label,owner,passive)
    assert(not M.Safety:InCombat(),"Unit artwork must be prepared outside combat")
    M:TrackRoot(owner or "UnitFrames",f,passive==true);f:SetSize(300,55)
    local view={frame=f,unit=unit,unitLabel=label,owner=owner or "UnitFrames",isRaid=type(unit)=="string" and unit:match("^raid%d+$")~=nil}
    local cfg=M:ModuleConfig(view.owner) or {}
    M.Visual:Panel(f,(cfg.panelOpacity or 10)/100)
    view.health=M.UI:Bar(f,8,-29,245,5,unpack(M.Visual.health))
    view.power=M.UI:Bar(f,8,-42,245,5,unpack(M.Visual.mana))
    M.UI:Beam(view.health);M.UI:Beam(view.power)
    M.UI:BeamColor(view.health,unpack(M.Visual.health));M.UI:BeamColor(view.power,unpack(M.Visual.mana))
    for _,bar in ipairs({view.health,view.power}) do
        M.UI:BeamTrack(bar,unpack(M.Visual.track))
    end
    view.name=semanticText(f,12,200);view.name:SetHeight(16)
    view.level=semanticText(f,11,30);view.level:SetTextColor(unpack(M.Visual.level));view.level:SetJustifyH("RIGHT")
    view.separator=semanticText(f,11,8);view.separator:SetTextColor(unpack(M.Visual.neutral))
    view.detail=semanticText(f,9,200);view.detail:SetHeight(13);view.detail:SetTextColor(unpack(M.Visual.neutral))
    view.healthPercent=semanticText(f,11,36);view.healthPercent:SetJustifyH("RIGHT");view.healthPercent:SetTextColor(unpack(M.Visual.health))
    view.powerPercent=semanticText(f,11,36);view.powerPercent:SetJustifyH("RIGHT");view.powerPercent:SetTextColor(unpack(M.Visual.mana))
    M.Visual:PlainName(view.name,12);M.Visual:CreateEdges(view)
    self:SizeUnit(view,300,55)
    f:SetScript("OnEnter",function(self)
        if passive then return end
        if GameTooltip and M.Safety:Frame(GameTooltip,false) and M.Safety:Text(view.unit) and view.unit~="" then
            GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
            local ok=pcall(GameTooltip.SetUnit,GameTooltip,view.unit)
            if ok then GameTooltip:Show() else GameTooltip:Hide() end
        end
    end)
    f:SetScript("OnLeave",function() if GameTooltip then GameTooltip:Hide() end end)
    return view
end
-- Layout callbacks can synchronously change combat state, native custody or
-- the selected profile. Checking only at entry does not authorize the next
-- geometry write on a passive child of a secure unit control.
function D:WithUnitGeometry(view,work)
    local S=M.Safety
    local keys={"frame","health","power","name","separator","level","detail","healthPercent","powerPercent"}
    local refs,objects={},{}
    for _,key in ipairs(keys) do refs[key]=view[key];if refs[key] then objects[refs[key]]=true end end
    local profile=M.profile;local frame=refs.frame
    local parent,parentState=S:Public(frame and frame.GetParent,nil,frame)
    local deferred={}
    local function postpone(reason)
        view.unitGeometryStatus=reason;error(deferred,0)
    end
    local function current()
        if M.profile~=profile then postpone("PROFILE_SUPERSEDED") end
        for _,key in ipairs(keys) do if view[key]~=refs[key] then postpone("UNIT_ARTWORK_SUPERSEDED") end end
        local currentParent,state=S:Public(frame and frame.GetParent,nil,frame)
        if parentState~="KNOWN" or state~="KNOWN" or currentParent~=parent then postpone("NATIVE_PARENT_UNAVAILABLE") end
        if S:InCombat() then postpone("COMBAT_GEOMETRY_DEFERRED") end
        -- The combat getter and native parent getter are callbacks too.
        if M.profile~=profile then postpone("UNIT_ARTWORK_SUPERSEDED") end
        for _,key in ipairs(keys) do if view[key]~=refs[key] then postpone("UNIT_ARTWORK_SUPERSEDED") end end
    end
    local function write(object,method,...)
        if not objects[object] or not S:Frame(object,false) then postpone("UNIT_GEOMETRY_TARGET_UNAVAILABLE") end
        current()
        object[method](object,...)
        current()
    end
    local okay,result=pcall(work,write)
    if not okay then
        view.powerLayoutPending=true
        if view.surface then view.surface.layoutPending=true end
        if result==deferred then return false end
        error(result,0)
    end
    view.unitGeometryStatus="AUTHORED_GEOMETRY_APPLIED"
    return result
end
function D:SizeUnit(view,width,height)
    if M.UnitTypography and M.UnitTypography:Owns(view) then
        return M.UnitTypography:SelectPowerVariant(view,view.powerPresence)
    end
    if M.Safety:InCombat() then return false end
    return self:WithUnitGeometry(view,function(write)
    local cfg=M:ModuleConfig(view.owner) or {}
    view.layoutWidth,view.layoutHeight=width,height;view.powerLayoutPending=nil
    local compact=view.isRaid and not view.headerRole and (view.previewCompact or cfg.compactRaid~=false)
    view.compactRaid=compact
    local hasPower=cfg.showPower~=false and view.powerPresence~="ABSENT"
    local inset=compact and 5 or 8
    local reserve=(cfg.showPercent and not compact) and 42 or 0
    local trackWidth=math.max(20,width-inset*2-reserve)
    local healthY=compact and -12 or -math.max(30,height-23)
    if not hasPower then healthY=compact and -math.floor(height/2) or -math.max(29,height-16) end
    local powerY=compact and -24 or healthY-12
    write(view.health,"ClearAllPoints");write(view.health,"SetPoint","TOPLEFT",inset,healthY);write(view.health,"SetSize",trackWidth,compact and 6 or 5)
    write(view.power,"ClearAllPoints");write(view.power,"SetPoint","TOPLEFT",inset,powerY);write(view.power,"SetSize",trackWidth,compact and 4 or 5)
    view.power:SetShown(hasPower)
    write(view.name,"ClearAllPoints");write(view.name,"SetPoint","TOPLEFT",inset,-4);write(view.name,"SetWidth",math.max(30,width-62));write(view.name,"SetHeight",14)
    write(view.separator,"ClearAllPoints");write(view.separator,"SetPoint","TOPRIGHT",-42,-7)
    write(view.level,"ClearAllPoints");write(view.level,"SetPoint","TOPRIGHT",-inset,-7)
    write(view.detail,"ClearAllPoints");write(view.detail,"SetPoint","TOPLEFT",inset,compact and -2 or -18);write(view.detail,"SetWidth",width-inset*2);write(view.detail,"SetHeight",compact and 8 or 10)
    write(view.healthPercent,"ClearAllPoints");write(view.healthPercent,"SetPoint","TOPRIGHT",-inset,healthY+4)
    write(view.powerPercent,"ClearAllPoints");write(view.powerPercent,"SetPoint","TOPRIGHT",-inset,powerY+4)
    M.Visual:Panel(view.frame,(cfg.panelOpacity or 10)/100)
    M.Visual:NameBacking(view,cfg.nameBacking==true and not compact)
    self:UnitText(view)
    if M.UnitExtras then M.UnitExtras:Layout(view) end
    return true
    end)
end
