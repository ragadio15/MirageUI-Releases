local _,M=...
-- The native container owns aura payloads, ordering, slot visibility and timers.
M.ManagedAuraRails={created=0,limit=320,status="NOT_RUN"}
local A,S=M.ManagedAuraRails,M.Safety
-- The pinned native group provider constructs ten frames synchronously using
-- isolated callbacks. Outer AddAuraGroup success cannot acknowledge our work.
-- These receipts count only our own initializer completion, never aura slots.
local initializers=setmetatable({},{__mode="k"})
local initialBatch=10
local maximumGroupCount=40
local function initializerLimit(count) return math.max(initialBatch*2,math.ceil(count/initialBatch)*initialBatch) end
-- A missing native container must not trigger one LoadAddOn attempt for every
-- unit/rail. Retain only the attempted client/loader identity, never a native
-- error or aura value. Available() is still checked first so a delayed export
-- immediately becomes usable without resetting or rebuilding profile data.
local loadAttempt,loadBusy,loadWatcher
local function watchLoadLifecycle()
    if loadWatcher or type(CreateFrame)~="function" then return end
    local f=CreateFrame("Frame");loadWatcher=f
    f:SetScript("OnEvent",function(_,event,name)
        if event=="PLAYER_ENTERING_WORLD" or event=="ADDON_LOADED" and S:Text(name) and name=="Blizzard_AuraContainer" then
            loadAttempt=nil
        end
    end)
    pcall(f.RegisterEvent,f,"ADDON_LOADED")
    pcall(f.RegisterEvent,f,"PLAYER_ENTERING_WORLD")
end
local function publicMethod(object,key)
    -- Public inbound methods are readable on the exported frame handle even
    -- when the native implementation's table/mixin is private.
    local ok,value=pcall(function() return object[key] end)
    return ok and S:Readable(value) and type(value)=="function"
end
function A:Available()
    -- The source-pinned template exports its options, not its secure mixin.
    return S:Readable(CustomAuraContainerGroupDefaultOptions)
        and type(CustomAuraContainerGroupDefaultOptions)=="table"
        and S:Readable(C_AuraContainerUtil) and type(C_AuraContainerUtil)=="table"
end
function A:Load()
    if self:Available() then return true end
    if S:InCombat() or loadBusy then return false end
    local load=C_AddOns and C_AddOns.LoadAddOn
    if type(load)~="function" then return false end
    local client=M.Client;local key=client and client.key
    if loadAttempt and loadAttempt.loader==load and loadAttempt.client==client and loadAttempt.key==key then return false end
    watchLoadLifecycle()
    loadAttempt={loader=load,client=client,key=key};loadBusy=true
    pcall(load,"Blizzard_AuraContainer")
    loadBusy=nil
    return self:Available()
end
-- Explicit recovery may retry a failed native load. Ordinary view configuration
-- uses Load(), which shares the bounded failed-attempt cache above.
function A:RetryLoad()
    if S:InCombat() or loadBusy then return false end
    loadAttempt=nil
    return self:Load()
end

local function bounded(value,low,high)
    return S:Number(value) and value%1==0 and value>=low and value<=high
end
local function validLayout(count,size,gap,columns)
    return bounded(count,1,maximumGroupCount) and bounded(columns,1,8) and columns<=count and bounded(size,16,72) and bounded(gap,0,36)
end
local function setting(settings,key,default)
    local value,state=S:FieldAccess(settings,key)
    if state=="ABSENT" then return default end
    return value
end
local function layout(size,gap)
    return {elementWidth=size,elementHeight=size,elementSpacing=gap,lineSpacing=gap,forceNewLine=false}
end
local function width(count,size,gap)
    return count*size+(count-1)*gap
end

-- Native breakpoint rules keep countdown values and interval selection inside
-- the duration binding. Seconds have no suffix; every longer duration remains
-- in minutes. No live duration or formatted native text is read by the addon.
local compactFormatter,compactFactory
local function durationOptions(compact)
    if not compact then return {},false end
    local factory=C_StringUtil and C_StringUtil.CreateNumericRuleFormatter
    if compactFormatter and compactFactory==factory then return {textFormatter=compactFormatter},true end
    if type(factory)~="function" or not Enum or not Enum.NumericRuleFormatRounding then return {},false end
    local ok,formatter=pcall(function()
        local up=Enum.NumericRuleFormatRounding.Up
        local f=factory()
        f:SetBreakpoints({
            {threshold=0,step=1,rounding=up,min=0,format="%d"},
            -- First representable double above 60: exactly 60 still displays
            -- as seconds. The native binding chooses the rule before rounding.
            {threshold=60.00000000000001,format="%dm",components={{div=60,step=1,rounding=up}}},
        })
        return f
    end)
    if not ok or not S:Readable(formatter) then return {},false end
    compactFormatter=formatter;compactFactory=factory
    return {textFormatter=formatter},true
end

-- Inspect security and parent identity only. A protected ancestor (ordinary
-- secure unit buttons) permits the incumbent native display submissions, never
-- a change to holder visibility or geometry in lockdown.
local function ancestry(frame,rail,button)
    local protected,foundContainer=false,false
    for depth=1,32 do
        if not S:Readable(frame) or (type(frame)~="table" and type(frame)~="userdata") then return false end
        if S:Public(frame.IsForbidden,"boolean",frame)~=false then return false end
        local locked=S:Public(frame.IsProtected,"boolean",frame)
        if locked==nil then return false end
        protected=protected or locked
        local ok,parent=pcall(frame.GetParent,frame)
        if not ok or not S:Readable(parent) then return false end
        if button then
            if frame==rail.originalContainer then foundContainer=true end
        elseif rail then
            if depth==1 and parent~=rail.originalHolder then return false end
            if depth==2 and parent~=rail.parent then return false end
        end
        if parent==nil then return not button or foundContainer,protected end
        frame=parent
    end
    return false
end
local function access(rail)
    if not S:Readable(rail.container) or not S:Readable(rail.holder)
        or rail.container~=rail.originalContainer or rail.holder~=rail.originalHolder then return false end
    return ancestry(rail.container,rail)
end
-- Nameplate aura buttons become access-restricted after their native
-- initializer returns (DenyTaintedAccessWhenAurasAreSecret). Never inspect or
-- restyle those descendants to maintain opacity. The public owned holder is
-- the only foreground target; the native container keeps icon, text, expiry,
-- ordering and per-aura Show/Hide under its own control.
local foregroundWatches=setmetatable({},{__mode="k"})
local function unwatchForeground(rail)
    for object in pairs(rail.foregroundWatched or {}) do
        local watch=foregroundWatches[object]
        if watch then watch.rails[rail]=nil end
    end
    rail.foregroundWatched=nil;rail.foregroundPolling=nil
end
local function foregroundWrite(rail,alpha,independent,guard)
    local generation=rail.generation
    local function current() return rail.generation==generation and (not guard or guard()) end
    if not current() then rail.foregroundReason="SUPERSEDED";return false end
    local holder=rail.originalHolder
    local allowed=holder==rail.holder and access(rail)
    if not allowed or not current() then rail.foregroundReason="RAIL_CUSTODY_UNAVAILABLE";return false end
    local entry=rail.foregroundTarget
    if not entry then entry={alpha=1,independent=false};rail.foregroundTarget=entry end
    -- Forever 70938 SimpleFrameAPI marks these two opacity setters as
    -- non-protected. The holder is ours and its exact public ancestry was
    -- checked above; a protected ancestor does not forbid these authored
    -- opacity writes. Keep the stronger geometry/visibility gates elsewhere.
    -- Read back the holder itself, never restricted native aura descendants.
    if not S:Frame(holder,false) then rail.foregroundReason="HOLDER_PUBLIC_ACCESS_UNAVAILABLE";return false end
    local actualAlpha=S:Public(holder.GetAlpha,"number",holder)
    local actualIndependent=S:Public(holder.IsIgnoringParentAlpha,"boolean",holder)
    if not current() or not access(rail) then rail.foregroundReason="RAIL_CUSTODY_UNAVAILABLE";return false end
    if not S:Number(actualAlpha) or actualAlpha<0 or actualAlpha>1 or actualIndependent==nil then
        rail.foregroundReason="HOLDER_STATE_UNAVAILABLE";return false
    end
    if actualIndependent==independent and math.abs(actualAlpha-alpha)<.00001 then
        entry.alpha=alpha;entry.independent=independent;return true
    end
    local ok=pcall(function()
        assert(current() and access(rail),"NATIVE_AURA_FOREGROUND_SUPERSEDED")
        if actualIndependent~=independent then holder:SetIgnoreParentAlpha(independent) end
        assert(current() and access(rail),"NATIVE_AURA_FOREGROUND_SUPERSEDED")
        if actualAlpha~=alpha then holder:SetAlpha(alpha) end
        assert(current() and access(rail),"NATIVE_AURA_FOREGROUND_SUPERSEDED")
    end)
    if not current() or not access(rail) then rail.foregroundReason="RAIL_CUSTODY_UNAVAILABLE";return false end
    local afterAlpha=S:Public(holder.GetAlpha,"number",holder)
    local afterIndependent=S:Public(holder.IsIgnoringParentAlpha,"boolean",holder)
    local confirmed=ok and current() and access(rail) and S:Number(afterAlpha)
        and math.abs(afterAlpha-alpha)<.00001 and afterIndependent==independent
    if confirmed then entry.alpha=alpha;entry.independent=independent
    else rail.foregroundReason="FOREGROUND_WRITE_UNCONFIRMED" end
    return confirmed
end
local function foregroundWatch(object,rail)
    if not S:Frame(object,false) then return false end
    local watch=foregroundWatches[object]
    if not watch then
        watch={rails=setmetatable({},{__mode="k"})};foregroundWatches[object]=watch
        for _,method in ipairs({"SetAlpha","SetIgnoreParentAlpha","SetParent"}) do
            if type(hooksecurefunc)=="function" and publicMethod(object,method) then
                local ok=pcall(hooksecurefunc,object,method,function()
                    for current in pairs(watch.rails) do
                        if current.foreground then A:RefreshDurationForeground(current,true) end
                    end
                end)
                if not ok then watch.failed=true end
            else watch.failed=true end
        end
    end
    if not rail.foreground then return false end
    watch.rails[rail]=true
    rail.foregroundWatched=rail.foregroundWatched or setmetatable({},{__mode="k"})
    rail.foregroundWatched[object]=true
    if watch.failed then rail.foregroundPolling=true end
    return true
end
local function foregroundAlpha(policy,now)
    local effects=M.Effects
    if policy.fade and effects and effects.ContextProgress then return effects:ContextProgress(policy.fade,now) end
    return policy.alpha,1
end
local function foregroundPrefix(rail,policy,nativeAlpha,contextAlpha)
    local frame=rail.parent;local opacity=contextAlpha*nativeAlpha;local found=false
    for _=1,16 do
        if frame==policy.nativeRoot then return found and opacity or nil end
        if not S:Frame(frame,false) then return nil end
        if frame==policy.presentation then found=true
        else
            local alpha=S:Public(frame.GetAlpha,"number",frame)
            local ignores=S:Public(frame.IsIgnoringParentAlpha,"boolean",frame)
            if not S:Number(alpha) or alpha<0 or alpha>1 or ignores~=false or not foregroundWatch(frame,rail) then return nil end
            opacity=opacity*alpha
        end
        frame=S:Public(frame.GetParent,nil,frame)
    end
end
local function foregroundPass(rail,policy,generation,force)
    local function current() return rail.generation==generation and rail.foreground==policy end
    if not access(rail) then rail.foregroundReason="RAIL_CUSTODY_UNAVAILABLE";return false end
    if not current() then return true end
    local good,live=pcall(policy.current)
    if not current() then return true end
    if not good or live~=true then
        rail.foreground=nil;rail.foregroundReason="ASSIGNMENT_REVOKED";unwatchForeground(rail)
        foregroundWrite(rail,1,false,function() return rail.generation==generation and rail.foreground==nil end)
        return false
    end
    local nativeAlpha=S:Public(policy.nativeRoot.GetEffectiveAlpha,"number",policy.nativeRoot)
    if not current() then return true end
    if not S:Number(nativeAlpha) or nativeAlpha<0 or nativeAlpha>1 then nativeAlpha=nil end
    local contextAlpha,progress=foregroundAlpha(policy,S:Now())
    if not current() then return true end
    if not force and policy.sampled and nativeAlpha==policy.nativeAlpha and contextAlpha==policy.sampledAlpha then return true end
    -- Preserve the native world-root opacity. If that public observation is
    -- unavailable, inherit it normally. Never infer visibility from aura data.
    local prefix=nativeAlpha~=nil and foregroundPrefix(rail,policy,nativeAlpha,contextAlpha) or nil
    if not current() then return true end
    local okay=foregroundWrite(rail,prefix or 1,prefix~=nil,current)
    if not current() then return true end
    policy.sampled=okay;policy.nativeAlpha=nativeAlpha;policy.sampledAlpha=contextAlpha
    if okay and progress>=1 then policy.fade=nil end
    if okay then rail.foregroundReason=prefix==nil and "NATIVE_ALPHA_INHERITED" or rail.foregroundPolling and "OWNED_HOLDER_ALPHA_POLLED" or "OWNED_HOLDER_ALPHA_HOOKED" end
    return okay
end
function A:RefreshDurationForeground(rail,force)
    if not rail or not rail.durationForeground or not rail.foreground then return true end
    if rail.foregroundBusy then if force then rail.foregroundQueued=true end;return true end
    -- A persistent unavailable optional opacity observation must not retry at
    -- frame rate. Only failed work is delayed; healthy native fades remain
    -- immediate, and a new policy or assignment never inherits old retry debt.
    if rail.foregroundRetryPolicy==rail.foreground and rail.foregroundRetryGeneration==rail.generation
        and S:Now()<(rail.foregroundRetryAt or 0) then return false end
    for _=1,8 do
        local policy,generation=rail.foreground,rail.generation
        if not policy then rail.foregroundQueued=nil;return true end
        rail.foregroundBusy=true;rail.foregroundQueued=nil
        local called,okay=pcall(foregroundPass,rail,policy,generation,force)
        rail.foregroundBusy=nil
        local superseded=rail.generation~=generation or rail.foreground~=policy
        if not called then rail.foregroundReason="FOREGROUND_CALLBACK_FAILED" end
        if not superseded then
            if not called or not okay then
                rail.foregroundRetryPolicy=policy;rail.foregroundRetryGeneration=generation
                rail.foregroundRetryAt=S:Now()+.25
                return false
            end
            rail.foregroundRetryPolicy=nil;rail.foregroundRetryGeneration=nil;rail.foregroundRetryAt=nil
        end
        if not superseded and not rail.foregroundQueued then return called and okay end
        if not rail.foreground then rail.foregroundQueued=nil;return called and okay end
        force=true
    end
    return true
end
function A:SetDurationForeground(rail,presentation,nativeRoot,alpha,current)
    if not rail or not rail.durationForeground then return true end
    -- A failed native disable/detach has independent visual containment. An
    -- ordinary nameplate visibility pass must not undo that containment.
    if rail.wrapperQuarantined then
        rail.foregroundReason=rail.cleanupPending and "NATIVE_AURA_CLEANUP_PENDING" or "QUARANTINED_DISABLED"
        return rail.cleanupPending~=true
    end
    if not S:Frame(presentation,false) or not S:Frame(nativeRoot,false) or not S:Number(alpha)
        or alpha<0 or alpha>1 or type(current)~="function" then rail.foregroundReason="INVALID_FOREGROUND_POLICY";return false end
    local policy=rail.foreground
    if policy and policy.presentation==presentation and policy.nativeRoot==nativeRoot and policy.alpha==alpha and policy.current==current and policy.unit==rail.unit then
        return self:RefreshDurationForeground(rail,rail.foregroundQueued==true)
    end
    if policy and (policy.nativeRoot~=nativeRoot or policy.presentation~=presentation) then unwatchForeground(rail) end
    local previous=policy
    policy={presentation=presentation,nativeRoot=nativeRoot,alpha=alpha,current=current,unit=rail.unit};rail.foreground=policy
    local effects=M.Effects
    if effects and effects.ContextDuration and effects.ContextProgress then
        local now=S:Now()
        local same=previous and previous.presentation==presentation and previous.nativeRoot==nativeRoot and previous.unit==rail.unit
        local from=same and foregroundAlpha(previous,now) or 0
        local ceiling=math.max(alpha,same and previous.alpha or 0)
        local duration=ceiling>0 and effects:ContextDuration()*math.min(1,math.abs(alpha-from)/ceiling) or 0
        -- Only the public authored scalar fades. The stable native aura holder
        -- stays shown and subscribed, and its native source/timers are never
        -- read or reconfigured. Clear/reassignment discards this policy.
        if duration>0 then policy.fade={from=from,to=alpha,start=now,duration=duration} end
    end
    rail.foregroundRetryPolicy=nil;rail.foregroundRetryGeneration=nil;rail.foregroundRetryAt=nil
    local watched=foregroundWatch(nativeRoot,rail)
    if rail.foreground~=policy then return true end
    if not watched then rail.foregroundReason="NATIVE_ROOT_UNAVAILABLE";return false end
    return self:RefreshDurationForeground(rail,true)
end
local function begin(rail)
    rail.generation=rail.generation+1
    return rail.generation
end
-- Check the exact allocation before each native call, then check that a
-- synchronous handler did not clear or reassign this rail during the call.
local function submit(rail,generation,object,method,...)
    if rail.generation~=generation then return false end
    local allowed,protected=access(rail)
    if not allowed or rail.generation~=generation then return false end
    if S:InCombat() then
        if method=="Hide" or method=="SetShown" then
            if protected then rail.visibilityPending=true;return true end
        elseif method=="SetSize" or method=="SetScale" or method=="SetAuraGroupLayout" or method=="SetAuraGroupMaxFrameCount" or method=="SetFlowLayoutMaximumLineSize" then
            return false
        end
    end
    if rail.generation~=generation then return false end
    local ok=pcall(object[method],object,...)
    if rail.generation~=generation then return false end
    if ok and (method=="Hide" or method=="SetShown") then rail.visibilityPending=nil end
    return ok
end

local geometryMethods={SetSize=true,SetWidth=true,SetHeight=true,SetPoint=true,SetAllPoints=true,ClearAllPoints=true}
local function initialize(rail,tooltip)
    return function(button)
        -- A failed preparation can leave a retained native initializer. It no
        -- longer has an authority to touch even a subsequently supplied button.
        local receipt=initializers[rail]
        if not receipt then return end
        -- A later source-owned batch may initialize synchronously during a
        -- layout call. Qualify each fresh public child in that creation window
        -- too; duplicate or excessive callbacks revoke readiness.
        if rail.retired or receipt.failed or receipt.busy or receipt.started>=receipt.limit then receipt.failed=true;return end
        receipt.started=receipt.started+1;receipt.busy=true
        local generation=rail.generation
        local function current()
            return initializers[rail]==receipt and not receipt.failed and not rail.retired and rail.generation==generation
        end
        local function call(object,key,...)
            assert(current(),"NATIVE_AURA_INITIALIZER_SUPERSEDED")
            -- A retained native initializer may run during a later callback.
            -- Check the exact write again after every synchronous native call.
            if geometryMethods[key] then
                local allowed,protected=ancestry(object,rail,true)
                assert(allowed and (not S:InCombat() or not protected),"NATIVE_AURA_GEOMETRY_DEFERRED")
            end
            local result=object[key](object,...)
            assert(current(),"NATIVE_AURA_INITIALIZER_SUPERSEDED")
            return result
        end
        local ok=pcall(function()
        local allowed,protected=ancestry(button,rail,true)
        if not allowed or (protected and S:InCombat()) or not access(rail) then error("NATIVE_AURA_BUTTON_UNAVAILABLE") end
        assert(current() and not receipt.seen[button],"NATIVE_AURA_INITIALIZER_DUPLICATE")
        receipt.seen[button]=true
        call(button,"SetSize",rail.buttonSize,rail.buttonSize)
        S:Passive(button)
        assert(current(),"NATIVE_AURA_INITIALIZER_SUPERSEDED")
        if tooltip and type(button.SetMouseMotionEnabled)=="function" then call(button,"SetMouseMotionEnabled",true) end
        -- The pinned native parser rejects an empty string. Nil is its explicit
        -- no-click contract; otherwise every initializer aborts before icon setup.
        if button.SetCancelAuraButtons then call(button,"SetCancelAuraButtons",nil) end
        local backing=call(button,"CreateTexture",nil,"BACKGROUND")
        call(backing,"SetAllPoints");call(backing,"SetColorTexture",.015,.018,.022,.78)
        local icon=call(button,"CreateTexture",nil,"ARTWORK");call(icon,"SetAllPoints");call(icon,"SetTexCoord",.06,.94,.06,.94)
        if rail.grayscale then
            assert(type(icon.SetDesaturated)=="function","NATIVE_GRAY_ICON_UNAVAILABLE")
            assert(call(icon,"SetDesaturated",true)~=false,"NATIVE_GRAY_ICON_UNAVAILABLE")
        end
        call(button,"SetIcon",icon)
        if rail.grayscale then
            -- Fixed unit cards use an owned neutral outline. Registering this
            -- texture as a dispel consumer would let the engine recolor it.
            for _,edge in ipairs({{"TOPLEFT","TOPRIGHT",true},{"BOTTOMLEFT","BOTTOMRIGHT",true},{"TOPLEFT","BOTTOMLEFT",false},{"TOPRIGHT","BOTTOMRIGHT",false}}) do
                local border=call(button,"CreateTexture",nil,"OVERLAY")
                call(border,"SetColorTexture",.55,.55,.55,.8)
                call(border,"SetPoint",edge[1],button,edge[1],0,0);call(border,"SetPoint",edge[2],button,edge[2],0,0)
                if edge[3] then call(border,"SetHeight",1) else call(border,"SetWidth",1) end
            end
        elseif type(button.AddDispelTypeTexture)=="function" then
            local border=call(button,"CreateTexture",nil,"OVERLAY")
            call(border,"SetPoint","TOPLEFT",button,"TOPLEFT",-1,1)
            call(border,"SetPoint","BOTTOMRIGHT",button,"BOTTOMRIGHT",1,-1)
            -- The engine selects the documented border/icon style and tint;
            -- neither dispel type nor aura identity is returned to addon Lua.
            call(button,"AddDispelTypeTexture",border,{showWhenHelpful=true,showWhenHarmful=true})
        end
        local cooldown=CreateFrame("Cooldown",nil,button,"CooldownFrameTemplate")
        call(cooldown,"SetAllPoints");S:Passive(cooldown)
        assert(current(),"NATIVE_AURA_INITIALIZER_SUPERSEDED")
        if cooldown.SetHideCountdownNumbers then call(cooldown,"SetHideCountdownNumbers",true) end
        if cooldown.SetDrawEdge then call(cooldown,"SetDrawEdge",false) end
        call(button,"SetDurationCooldown",cooldown)
        -- Draw layers only order regions within one frame. A Cooldown child
        -- renders above the button's OVERLAY regions, so the old duration and
        -- stack text were shaded by its swipe. Keep a separate passive sibling
        -- above that child. It is still a descendant of the native aura button:
        -- the native text binding owns the payload/expiry, and hiding or
        -- recycling the aura/plate hides this layer with it.
        local textLayer=CreateFrame("Frame",nil,button)
        call(textLayer,"SetAllPoints",button)
        local cooldownLevel=call(cooldown,"GetFrameLevel")
        assert(S:Number(cooldownLevel),"NATIVE_AURA_COOLDOWN_LAYER_UNAVAILABLE")
        call(textLayer,"SetFrameLevel",cooldownLevel+1)
        S:Passive(textLayer)
        assert(current(),"NATIVE_AURA_INITIALIZER_SUPERSEDED")
        if type(button.SetApplicationCount)=="function" then
            local countText=call(textLayer,"CreateFontString",nil,"OVERLAY")
            call(countText,"SetFont",STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",10,"")
            call(countText,"SetPoint","BOTTOMRIGHT",button,"BOTTOMRIGHT",-1,1)
            call(countText,"SetTextColor",1,1,1,1)
            call(button,"SetApplicationCount",countText,{})
        end
        if rail.harmful and type(button.SetDurationText)=="function" then
            local text=call(textLayer,"CreateFontString",nil,"OVERLAY")
            call(text,"SetFont",rail.fontFile or STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",rail.fontSize,rail.fontFlags or "")
            call(text,"SetPoint","CENTER",button,"CENTER",0,0);call(text,"SetTextColor",1,1,1,1)
            if rail.fontRatio then
                call(text,"SetSize",rail.buttonSize-2,rail.buttonSize)
                call(text,"SetJustifyH","CENTER");call(text,"SetJustifyV","MIDDLE")
            end
            if text.SetShadowColor then call(text,"SetShadowColor",0,0,0,1);call(text,"SetShadowOffset",1,-1) end
            call(button,"SetDurationText",text,rail.durationOptions)
            rail.durationTexts[text]=button
            if rail.durationForeground then
                rail.durationLayers[button]={layer=textLayer,alpha=1,independent=false}
                if rail.foreground then rail.foreground.sampled=nil end
            end
        end
        assert(current(),"NATIVE_AURA_INITIALIZER_SUPERSEDED")
        end)
        receipt.busy=nil
        if not ok or not current() then receipt.failed=true;error("NATIVE_AURA_INITIALIZER_FAILED") end
        receipt.completed=receipt.completed+1
    end
end
function A:Ready(rail)
    local receipt=rail and initializers[rail]
    return receipt~=nil and not receipt.open and not receipt.failed and not receipt.busy and not rail.retired
        and receipt.started>=initialBatch and receipt.started<=receipt.limit and receipt.completed==receipt.started
end
function A:Create(parent,filter,settings)
    if not S:Readable(settings) or (settings~=nil and type(settings)~="table") then return nil,"INVALID_NATIVE_LAYOUT" end
    settings=settings or {}
    if self.created>=self.limit or not self:Load() then self.status="NATIVE_AURA_CONTAINER_UNAVAILABLE";return nil,self.status end
    -- Filter strings are fixed source-reviewed native policies, never a spell
    -- list or an addon-side test of restricted aura contents.
    local filters={HELPFUL=true,HARMFUL=true,["HELPFUL|IMPORTANT"]=true,
        ["HELPFUL|INCLUDE_NAME_PLATE_ONLY"]=true,["HARMFUL|INCLUDE_NAME_PLATE_ONLY"]=true}
    if not S:Text(filter) or not filters[filter] then return nil,"INVALID_NATIVE_FILTER" end
    local count,size,gap=setting(settings,"count",4),setting(settings,"size",24),setting(settings,"gap",3)
    local columns=setting(settings,"columns",count)
    local upward=setting(settings,"upward",false)==true
    local fontSize=setting(settings,"fontSize",15)
    local fontFile=setting(settings,"fontFile",nil)
    local fontFlags=setting(settings,"fontFlags","")
    local fontRatio=setting(settings,"fontRatio",nil)
    if not validLayout(count,size,gap,columns) or not S:Number(fontSize) or fontSize<=0 then return nil,"INVALID_NATIVE_LAYOUT" end
    if fontFile~=nil and (not S:Text(fontFile) or #fontFile>256) then return nil,"INVALID_NATIVE_LAYOUT" end
    if fontFlags~="" and fontFlags~="OUTLINE" and fontFlags~="THICKOUTLINE" then return nil,"INVALID_NATIVE_LAYOUT" end
    if fontRatio~=nil and (not S:Number(fontRatio) or fontRatio<=0 or fontRatio>1) then return nil,"INVALID_NATIVE_LAYOUT" end
    local options,compacted=durationOptions(setting(settings,"compactDuration",false)==true)
    if setting(settings,"compactDuration",false)==true and fontRatio and not compacted then
        -- Older/missing formatter contracts retain Blizzard's default binding
        -- with a smaller authored face; no text is read to choose this fallback.
        fontRatio=math.min(fontRatio,.44);fontSize=math.max(12,math.floor(size*fontRatio))
    end
    local allowed,protected=ancestry(parent)
    if not allowed or (protected and S:InCombat()) then return nil,"NATIVE_AURA_PARENT_UNAVAILABLE" end
    self.created=self.created+1 -- failed native allocations also consume the budget
    local rail={parent=parent,filter=filter,harmful=filter:sub(1,7)=="HARMFUL",failures=0,generation=0,state="PREPARING",
        stableHolder=setting(settings,"stableHolder",false)==true,
        count=count,columns=columns,upward=upward,size=size,gap=gap,buttonSize=size,layoutScale=1,holderWidth=width(columns,size,gap),holderHeight=size,
        fontSize=fontSize,fontFile=fontFile,fontFlags=fontFlags,fontRatio=fontRatio,
        durationTexts={},durationLayers={},durationForeground=filter=="HARMFUL|INCLUDE_NAME_PLATE_ONLY" and setting(settings,"durationForeground",false)==true,
        durationOptions=options,compactDuration=compacted,grayscale=setting(settings,"grayscale",false)==true}
    local receipt={open=true,started=0,completed=0,seen={},limit=initializerLimit(count)}
    initializers[rail]=receipt
    local ok=pcall(function()
        local holder=CreateFrame("Frame",nil,parent)
        rail.holder=holder;rail.originalHolder=holder
        S:Passive(holder);holder:SetSize(width(columns,size,gap),size)
        -- World plates reuse these containers while combat is already active.
        -- Native AuraContainer registers events and runs its dirty phases only
        -- while visible. Keep this passive wrapper prepared and shown; native
        -- SetEnabled/SetUnit owns content, and the enclosing card owns visibility.
        -- A Clear/Show wrapper cycle can strand a recycled plate in lockdown.
        if rail.stableHolder then holder:Show();rail.wrapperStatus="PREPARED_VISIBLE" end
        if rail.durationForeground then
            holder:SetScript("OnUpdate",function(_,elapsed)
                local policy,generation=rail.foreground,rail.generation
                -- The short authored context scalar shares this existing
                -- native-opacity observer; settled policies have no scalar
                -- work or added update/timer. No alpha groups are allocated.
                -- If a public native setter cannot be hooked, sample admitted
                -- ancestry at most 10 Hz; root changes/hooks remain immediate.
                -- Never poll native timer text, aura payloads or secret shown
                -- state to choose which of the preallocated slots to inspect.
                rail.foregroundElapsed=rail.foregroundPolling and (rail.foregroundElapsed or 0)+(S:Number(elapsed) and math.max(0,elapsed) or 0) or 0
                local force=rail.foregroundQueued==true or rail.foregroundPolling and rail.foregroundElapsed>=.10
                if force then rail.foregroundElapsed=0 end
                if policy and not A:RefreshDurationForeground(rail,force)
                    and rail.foreground==policy and rail.generation==generation then
                    -- Foreground opacity is an optional improvement. A combat
                    -- deferral must not disable the native aura subscription
                    -- and, in turn, hand the entire nameplate back to stock.
                    -- Its opacity observer is never the authority to clear
                    -- a native subscription. Explicit assignment/removal owns
                    -- that lifetime even when public opacity becomes unknown.
                    rail.foregroundPolling=true
                end
            end)
        end
        local container=CreateFrame("AuraContainer",nil,holder,"CustomAuraContainerTemplate")
        rail.container=container;rail.originalContainer=container
        assert(access(rail),"NATIVE_AURA_CONTRACT_MISSING")
        for _,method in ipairs({"SetEnabled","SetUnit","AddAuraGroup","SetAuraGroupEnabled","SetAuraGroupMaxFrameCount","SetAuraGroupLayout"}) do
            assert(publicMethod(container,method),"NATIVE_AURA_CONTRACT_MISSING")
        end
        container:SetEnabled(false)
        container:SetPoint(upward and "BOTTOMLEFT" or "TOPLEFT",holder,upward and "BOTTOMLEFT" or "TOPLEFT",0,0)
        -- A small own rect lets the native visible-update/layout pump start;
        -- the native container subsequently owns its actual group dimensions.
        container:SetSize(1,1)
        S:Passive(container)
        if count>columns or upward then
            rail.flowLayout=true
            for _,method in ipairs({"SetFlowLayoutMaximumLineSize","SetFlowLayoutAnchorPoint","SetFlowLayoutGrowthDirection"}) do
                assert(publicMethod(container,method),"NATIVE_AURA_FLOW_UNAVAILABLE")
            end
            assert(AnchorUtil and AnchorUtil.FlowDirection,"NATIVE_AURA_FLOW_UNAVAILABLE")
            container:SetFlowLayoutMaximumLineSize(width(columns,size,gap))
            container:SetFlowLayoutAnchorPoint(upward and "BOTTOMLEFT" or "TOPLEFT")
            container:SetFlowLayoutGrowthDirection(AnchorUtil.FlowDirection.Right,upward and AnchorUtil.FlowDirection.Up or AnchorUtil.FlowDirection.Down)
        end
        container:AddAuraGroup("Mirage",filter,{
            maxFrameCount=count,
            initializeFrame=initialize(rail,setting(settings,"tooltip",false)==true),
            layout=layout(size,gap),
        })
        receipt.open=false
        assert(receipt.started==initialBatch and receipt.completed==initialBatch and self:Ready(rail),"NATIVE_AURA_INITIALIZER_INCOMPLETE")
        rail.state="NATIVE_CONTAINER_PREPARED_NOT_VALIDATED"
    end)
    receipt.open=false
    if not ok then
        rail.retired=true
        if rail.container then self:Clear(rail)
        elseif rail.holder and S:CanEdit(rail.holder) then pcall(rail.holder.Hide,rail.holder) end
        self.status="NATIVE_AURA_PREPARATION_FAILED";return nil,self.status
    end
    self.status=rail.state;return rail
end
local function containStableHolder(rail,generation)
    local function current() return rail.generation==generation and rail.wrapperQuarantined==true end
    if rail.generation~=generation then return false end
    rail.wrapperQuarantined=true;rail.wrapperStatus="QUARANTINE_PENDING"
    local allowed,protected=access(rail)
    if not allowed or not current() then return false end
    local shown=S:Public(rail.originalHolder.IsShown,"boolean",rail.originalHolder)
    if not current() then return false end
    if shown~=false and (not S:InCombat() or not protected) then
        submit(rail,generation,rail.originalHolder,"Hide")
        if not current() then return false end
        shown=S:Public(rail.originalHolder.IsShown,"boolean",rail.originalHolder)
    end
    if not current() then return false end
    if shown==false then rail.wrapperStatus="QUARANTINED_HIDDEN";return true end
    -- Opacity on this authored wrapper is nonprotected in the reviewed client.
    -- It safely contains a failed native cleanup when combat forbids Hide; no
    -- secret native button or content-dependent shown state is inspected.
    local faded=foregroundWrite(rail,0,false,current)
    if not current() then return false end
    rail.wrapperStatus=faded and "QUARANTINED_TRANSPARENT" or "QUARANTINE_PENDING"
    return faded
end
local function clear(rail,generation)
    rail.unit=nil;rail.enabled=false
    rail.foreground=nil;rail.foregroundQueued=nil;rail.foregroundElapsed=nil;unwatchForeground(rail)
    rail.foregroundRetryPolicy=nil;rail.foregroundRetryGeneration=nil;rail.foregroundRetryAt=nil
    foregroundWrite(rail,rail.wrapperQuarantined and 0 or 1,false,function() return rail.generation==generation end)
    rail.foregroundReason="NOT_ACTIVE"
    -- A failed disable must not skip the independent detach. A queued
    -- successor is applied only after the currently executing setter returns.
    local disabled=submit(rail,generation,rail.originalContainer,"SetEnabled",false)
    local detached=submit(rail,generation,rail.originalContainer,"SetUnit","none")
    local hidden=rail.stableHolder or submit(rail,generation,rail.originalHolder,"Hide")
    if generation~=rail.generation then return false,"NATIVE_AURA_SUPERSEDED" end
    if rail.stableHolder and (not disabled or not detached) then
        containStableHolder(rail,generation)
        if generation~=rail.generation then return false,"NATIVE_AURA_SUPERSEDED" end
    end
    local ok=disabled and detached and hidden and access(rail)
    if generation~=rail.generation then return false,"NATIVE_AURA_SUPERSEDED" end
    rail.cleanupPending=not ok or nil
    rail.state=ok and "DISABLED" or "NATIVE_AURA_CLEANUP_UNCONFIRMED"
    return ok,rail.state
end
local function restoreStableHolder(rail,generation)
    local function current() return rail.generation==generation and rail.wrapperQuarantined==true and not rail.cleanupPending end
    if not current() or not access(rail) or not current() then return false end
    local shown=S:Public(rail.originalHolder.IsShown,"boolean",rail.originalHolder)
    if not current() then return false end
    if shown~=true then
        if S:InCombat() then return false end
        if not submit(rail,generation,rail.originalHolder,"SetShown",true) or not current() then return false end
        shown=S:Public(rail.originalHolder.IsShown,"boolean",rail.originalHolder)
    end
    if shown~=true or not current() or not access(rail) or not current() then return false end
    if not foregroundWrite(rail,1,false,current) or not current() then return false end
    rail.wrapperQuarantined=nil;rail.wrapperStatus="PREPARED_VISIBLE";rail.visibilityPending=nil
    return true
end

local function assign(rail,generation,unit,enabled)
    local same=rail.unit==unit and rail.enabled==enabled
    if not access(rail) then
        rail.unit=nil;rail.enabled=false
        return false,"NATIVE_AURA_OWNER_UNAVAILABLE"
    end
    if generation~=rail.generation then return false,"NATIVE_AURA_SUPERSEDED" end
    if not A:Ready(rail) then
        local cleaned,reason=clear(rail,generation)
        return false,cleaned and "NATIVE_AURA_PREPARATION_FAILED" or reason
    end
    if rail.stableHolder and rail.wrapperQuarantined then
        -- Re-establish native cleanup before making an exceptional quarantine
        -- visible again. The normal recycled-plate path never enters here.
        local cleaned,reason=clear(rail,generation)
        if not cleaned then return false,reason end
        if not restoreStableHolder(rail,generation) then return false,"NATIVE_AURA_WRAPPER_RECOVERY_DEFERRED" end
        same=false
    end
    if same and not rail.visibilityPending then
        if not rail.stableHolder then return true,rail.state end
        local shown=S:Public(rail.originalHolder.IsShown,"boolean",rail.originalHolder)==true
        if generation~=rail.generation then return false,"NATIVE_AURA_SUPERSEDED" end
        rail.wrapperStatus=shown and "PREPARED_VISIBLE" or "HIDDEN_OR_UNREADABLE"
        if shown then
            local allowed=access(rail)
            if generation~=rail.generation then return false,"NATIVE_AURA_SUPERSEDED" end
            if allowed then return true,rail.state end
            return false,"NATIVE_AURA_OWNER_UNAVAILABLE"
        end
    end
    local ok=true
    if not same then
        rail.unit=nil;rail.enabled=false
        local container=rail.container
        ok=submit(rail,generation,container,"SetEnabled",false)
            and submit(rail,generation,container,"SetUnit",unit)
            and submit(rail,generation,container,"SetAuraGroupEnabled","Mirage",enabled)
            and submit(rail,generation,container,"SetEnabled",enabled)
    end
    local shown
    if rail.stableHolder then
        -- This is our own static wrapper, never a restricted aura child or a
        -- native content-visibility observation. A hidden wrapper cannot claim
        -- an operational event subscription merely because SetUnit succeeded.
        shown=S:Public(rail.originalHolder.IsShown,"boolean",rail.originalHolder)==true
        if generation~=rail.generation then return false,"NATIVE_AURA_SUPERSEDED" end
        rail.wrapperStatus=shown and "PREPARED_VISIBLE" or "HIDDEN_OR_UNREADABLE"
        rail.visibilityPending=nil
    else shown=submit(rail,generation,rail.holder,"SetShown",enabled) end
    ok=ok and shown and access(rail) and A:Ready(rail)
    if generation~=rail.generation then return false,"NATIVE_AURA_SUPERSEDED" end
    if not ok then
        rail.failures=rail.failures+1
        local cleaned,reason=clear(rail,generation)
        return false,cleaned and "NATIVE_AURA_DISPATCH_FAILED" or reason
    end
    rail.unit=unit;rail.enabled=enabled;rail.state=enabled and "NATIVE_AURA_SUBMITTED" or "DISABLED"
    return true,rail.state
end

-- A native setter can run callbacks before *or* after it commits. The current
-- call must unwind before applying a newer request. Nested callers cannot
-- claim completion. Coalesce duplicate requests; bound alternating callbacks.
local function dispatch(rail,unit,enabled)
    local request={unit=unit,enabled=enabled}
    if rail.dispatch then
        local latest=rail.nextRequest or rail.dispatch
        if not rail.quarantining and (latest.unit~=unit or latest.enabled~=enabled) then
            rail.nextRequest=request;begin(rail)
        end
        return false,"NATIVE_AURA_DISPATCH_PENDING"
    end
    for pass=1,8 do
        rail.dispatch=request
        local generation=begin(rail)
        local ok,state
        if request.unit then
            ok,state=assign(rail,generation,request.unit,request.enabled)
        else
            ok,state=clear(rail,generation)
        end
        request=rail.nextRequest;rail.nextRequest=nil
        if not request then
            rail.dispatch=nil
            if pass>1 then return false,"NATIVE_AURA_SUPERSEDED" end
            return ok,state
        end
    end
    rail.failures=3;rail.quarantining=true
    local cleaned,state=clear(rail,begin(rail))
    rail.dispatch=nil;rail.quarantining=nil
    return false,cleaned and "NATIVE_AURA_QUARANTINED" or state
end
function A:Assign(rail,unit,enabled)
    if not rail or rail.retired or rail.failures>=3 then return false,"NATIVE_AURA_QUARANTINED" end
    if not self:Ready(rail) then self:Clear(rail);return false,"NATIVE_AURA_PREPARATION_FAILED" end
    if not S:Readable(enabled) then self:Clear(rail);return false,"INVALID_ENABLED" end
    if not S:Text(unit) or unit=="" or (enabled==true and unit=="none") then
        self:Clear(rail);return false,"INVALID_UNIT"
    end
    if not self:Available() then self:Clear(rail);return false,"NATIVE_AURA_CONTAINER_UNAVAILABLE" end
    if rail.layoutPending then return false,"NATIVE_AURA_LAYOUT_UNCONFIRMED" end
    return dispatch(rail,unit,enabled==true)
end
function A:Refresh(rail,unit,current)
    -- Refresh only the exact existing subscription. SetUnit is intentionally
    -- a no-op for an unchanged token in Blizzard's shared mixin, so resubmitting
    -- that token cannot reconcile a missed update or a reused native handle.
    -- This public inbound method asks Blizzard to parse its current aura data;
    -- Mirage never receives or caches an aura payload, ID, expiry or cast result.
    if not rail or rail.retired or not S:Text(unit) or rail.unit~=unit or rail.enabled~=true
        or not self:Ready(rail) then return false,"NATIVE_AURA_REFRESH_OWNER_UNAVAILABLE" end
    if type(current)~="function" then return false,"NATIVE_AURA_REFRESH_OWNER_UNAVAILABLE" end
    if rail.dispatch or rail.configuring or rail.refreshing then return false,"NATIVE_AURA_REFRESH_BUSY" end
    local generation=rail.generation
    local function owned()
        if rail.generation~=generation or rail.unit~=unit or rail.enabled~=true or rail.retired then return false end
        local okay,valid=pcall(current)
        return okay and valid==true and rail.generation==generation and rail.unit==unit and rail.enabled==true and not rail.retired
    end
    if not owned() or not access(rail) or not owned() then return false,"NATIVE_AURA_REFRESH_OWNER_UNAVAILABLE" end
    if rail.stableHolder then
        local shown=S:Public(rail.originalHolder.IsShown,"boolean",rail.originalHolder)==true
        if not owned() then return false,"NATIVE_AURA_REFRESH_SUPERSEDED" end
        rail.wrapperStatus=shown and "PREPARED_VISIBLE" or "HIDDEN_OR_UNREADABLE"
        if not shown then
            rail.refreshStatus="NATIVE_AURA_WRAPPER_HIDDEN"
            return false,rail.refreshStatus
        end
    end
    if not owned() then return false,"NATIVE_AURA_REFRESH_SUPERSEDED" end
    if not publicMethod(rail.originalContainer,"UpdateAllAuras") then return false,"NATIVE_AURA_REFRESH_UNAVAILABLE" end
    rail.refreshing=true
    rail.refreshRequests=(rail.refreshRequests or 0)+1
    local okay=submit(rail,generation,rail.originalContainer,"UpdateAllAuras")
    rail.refreshing=nil
    if not owned() then return false,"NATIVE_AURA_REFRESH_SUPERSEDED" end
    if not access(rail) or not owned() then return false,"NATIVE_AURA_REFRESH_OWNER_UNAVAILABLE" end
    if not okay then
        -- Optional reconciliation cannot disable the native event subscription
        -- or quarantine all of this nameplate's current aura contents.
        rail.refreshStatus="NATIVE_AURA_REFRESH_FAILED"
        return false,rail.refreshStatus
    end
    rail.refreshStatus="NATIVE_AURA_REFRESH_SUBMITTED"
    return true,rail.refreshStatus
end
function A:Configure(rail,count,size,gap,columns)
    if not rail or rail.retired or rail.configuring or rail.dispatch or S:InCombat() or rail.failures>=3 then return false end
    if not self:Ready(rail) then self:Clear(rail);return false end
    columns=columns or count
    if not validLayout(count,size,gap,columns) or not self:Available() then
        rail.layoutPending=true;self:Clear(rail);return false
    end
    local generation=rail.generation
    if not access(rail) or generation~=rail.generation then return false end
    if not rail.layoutPending and rail.count==count and rail.columns==columns and rail.size==size and rail.gap==gap then return true end
    generation=begin(rail)
    rail.configuring=true;rail.layoutPending=true
    -- The pinned flow engine applies points, not AuraButton:SetSize. Keep one
    -- immutable initializer geometry for every native batch and resize only
    -- our public holder. This also avoids restyling secret-bearing children.
    local scale=size/rail.buttonSize
    local nativeGap=gap/scale
    local extent=width(columns,rail.buttonSize,nativeGap)
    local receipt=initializers[rail];receipt.limit=math.max(receipt.limit,initializerLimit(count))
    local ok=submit(rail,generation,rail.container,"SetAuraGroupMaxFrameCount","Mirage",count)
        and submit(rail,generation,rail.container,"SetAuraGroupLayout","Mirage",layout(rail.buttonSize,nativeGap))
        -- A fractional scaled gap can accumulate a last-bit error when the
        -- native flow sums a line. This subpixel admission tolerance cannot
        -- admit an extra icon, and does not change any rendered coordinates.
        and (count==columns and not rail.flowLayout or submit(rail,generation,rail.container,"SetFlowLayoutMaximumLineSize",extent+.0001))
        and submit(rail,generation,rail.holder,"SetScale",scale)
        and submit(rail,generation,rail.holder,"SetSize",extent,rail.buttonSize) and access(rail) and self:Ready(rail)
    rail.configuring=nil
    if generation~=rail.generation then return false end
    if not ok then rail.failures=rail.failures+1;self:Clear(rail);return false end
    rail.count=count;rail.columns=columns;rail.flowLayout=rail.flowLayout or count>columns;rail.size=size;rail.gap=gap;rail.layoutPending=nil
    rail.layoutScale=scale;rail.holderWidth=extent;rail.holderHeight=rail.buttonSize
    return true
end
function A:Clear(rail)
    if not rail then return end
    local receipt=initializers[rail]
    if receipt and receipt.open then receipt.failed=true end
    return dispatch(rail,nil,false)
end
