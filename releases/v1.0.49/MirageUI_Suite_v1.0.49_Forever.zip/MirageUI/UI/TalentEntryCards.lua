local _,M=...
local S=M.Safety
-- This is presentation intake, not another native provider or an applied-build model.
local function same(a,b)
 if type(a)~=type(b) then return false end
 if type(a)~='table' then return a==b end
 if getmetatable(a) or getmetatable(b) then return false end
 for k,v in next,a do if not same(v,rawget(b,k)) then return false end end
 for k in next,b do if rawget(a,k)==nil then return false end end
 return true
end
local function copy(data,valid)
 local remaining,seen=2048,{}
 local function visit(value,depth)
  if not valid() or not S:Readable(value) or not valid() then error('Retired intake',0) end
  local t=type(value)
  if t~='table' then if t~='nil' and t~='string' and t~='number' and t~='boolean' then error('Invalid intake',0) end;return value end
  if depth>5 or getmetatable(value) or seen[value] then error('Invalid graph',0) end
  seen[value]=true;local result={};local key
  while true do
   remaining=remaining-1;if remaining<0 then error('Intake limit',0) end
   local k=next(value,key)
   if not S:Readable(k) or not valid() then error('Retired key',0) end
   if k==nil then break end
   if type(k)~='string' and (type(k)~='number' or k%1~=0 or k<1 or k>128) then error('Invalid key',0) end
   result[k]=visit(rawget(value,k),depth+1);key=k
  end
  return result
 end
 return visit(data,0)
end
local function integer(v,max) return type(v)=='number' and v==v and v%1==0 and v>=0 and v<=max end
local function keys(value,allowed)
 if type(value)~='table' then return false end
 for k in pairs(value) do if not allowed[k] then return false end end
 return true
end
local reasons={SOURCE_UNAVAILABLE='Source/client unavailable',GROUP_UNAVAILABLE='Group association unavailable',CONFIG_CONFLICT='Config observations conflict',CONFIG_UNAVAILABLE='Config identity unavailable',STAGED_OR_UNKNOWN='Staged edits reported/unknown',NODE_TYPES_UNAVAILABLE='Node type metadata unavailable',TREE_MEMBERSHIP_UNAVAILABLE='Tree membership unavailable',MEMBERSHIP_CHANGED='Tree membership changed',IDENTITY_CHANGED='Config identity changed',TYPE_CHANGED='Config type changed',OBSERVATION_CHANGED='Sampled observation changed',CHOICE_UNAVAILABLE='Legacy tree choice unavailable',CONFIG_TYPES_UNAVAILABLE='Config type metadata unavailable'}
local function reason(value) return value==nil or reasons[value]~=nil end
local legacyTrees={[1187]={key='PROFESSIONS',label='Professions'},[1188]={key='ADVENTURE',label='Adventure'},[1189]={key='PROGRESSION',label='Progression'}}
function M:TalentEntryCards(data,valid,legacyTree)
 local legacy=legacyTree~=nil
 local treeSpec=legacy and legacyTrees[legacyTree]
 if legacy and not treeSpec then return nil end
 local ok,snapshot=pcall(copy,data,valid)
 if not ok or type(snapshot)~='table' then return nil end
 local state=snapshot.state
 if state~='OBSERVED_SCOPED_SNAPSHOT' and state~='PARTIAL_UNAVAILABLE' and state~='UNAVAILABLE' then return nil end
 if not keys(snapshot,{state=true,reason=true,client=true,epoch=true,contextEpoch=true,config=true,tree=legacy,rows=true,counts=true,membershipKnown=true,limitReached=true,callCount=true}) or not reason(snapshot.reason) or state=='UNAVAILABLE' and snapshot.reason==nil or state~='UNAVAILABLE' and snapshot.reason~=nil then return nil end
 if type(snapshot.client)~='string' or #snapshot.client>64 or not integer(snapshot.epoch,2147483647) or not integer(snapshot.contextEpoch,2147483647) or not integer(snapshot.callCount,4096) or type(snapshot.membershipKnown)~='boolean' or type(snapshot.limitReached)~='boolean' then return nil end
 local rows,c=snapshot.rows,snapshot.counts
 if type(rows)~='table' or not keys(c,{shown=true,inspected=true,zeroRank=true,unknown=true,positiveOmitted=true,tiered=true,nameUnavailable=true,changed=true,treeFailures=true,uniqueNodes=true,memberships=true,uninspected=true}) then return nil end
 local limits={shown=128,inspected=512,zeroRank=512,unknown=512,positiveOmitted=512,tiered=512,nameUnavailable=512,changed=512,treeFailures=8,uniqueNodes=legacy and 1024 or 2048,memberships=legacy and 1024 or 2048}
 for key,maximum in pairs(limits) do if not integer(c[key],maximum) then return nil end end
 if snapshot.membershipKnown then if not integer(c.uninspected,2048) then return nil end elseif c.uninspected~=nil then return nil end
 local count=0;for k in pairs(rows) do if not integer(k,128) or k<1 then return nil end;count=count+1 end
 if count~=c.shown or count>128 or c.shown>c.inspected or c.inspected>c.uniqueNodes then return nil end
 if snapshot.membershipKnown and c.uninspected~=c.uniqueNodes-c.inspected then return nil end
 if state=='UNAVAILABLE' and count~=0 then return nil end
 local cfg=snapshot.config
 if legacy then
  local tree=snapshot.tree
  if tree~=nil then
   if not keys(tree,{id=true,key=true}) or tree.id~=legacyTree or tree.key~=treeSpec.key then return nil end
  elseif state~='UNAVAILABLE' then return nil end
  if cfg~=nil then
   if not keys(cfg,{id=true,origin=true}) or not integer(cfg.id,2147483647) or cfg.origin~='LEGACY_TREE' or not tree then return nil end
  elseif state~='UNAVAILABLE' then return nil end
  if M.Client.family~='Forever' and state~='UNAVAILABLE' then return nil end
 elseif cfg~=nil then
  if not keys(cfg,{id=true,origin=true,group=true}) or not integer(cfg.id,2147483647) or cfg.origin~='COMMON' and cfg.origin~='GROUP' or cfg.group~=nil and cfg.group~=1 and cfg.group~=2 then return nil end
  if cfg.origin=='GROUP' and M.Client.family~='Forever' or M.Client.family=='Forever' and cfg.group~=1 and cfg.group~=2 or M.Client.family~='Forever' and cfg.group~=nil then return nil end
 elseif state~='UNAVAILABLE' then return nil end
 if state=='OBSERVED_SCOPED_SNAPSHOT' and (snapshot.limitReached or not snapshot.membershipKnown or c.unknown>0 or c.positiveOmitted>0 or c.tiered>0 or c.treeFailures>0 or c.uninspected>0 or c.changed>0 or c.nameUnavailable>0) then return nil end
 local cards={}
 if state=='UNAVAILABLE' then
  cards[1]={'Named entries unavailable',reasons[snapshot.reason] or 'No named sample retained',legacy and 'Legacy summary is separate' or 'Use Talents for config summary'}
 else
  cards[1]={legacy and 'Reported Legacy entries' or 'Reported selected entries',state=='PARTIAL_UNAVAILABLE' and 'Partial scoped sample' or 'Scoped snapshot only','Not an applied-build guarantee'}
  cards[#cards+1]={'Staging bracket','No staged changes reported','Sequential; not atomic/current'}
  if legacy then cards[#cards+1]={treeSpec.label..' tree (reported)','Tree #'..legacyTree,'Config #'..cfg.id}
  else cards[#cards+1]={cfg.origin=='GROUP' and 'Active-group config' or 'Common config (reported)','Config #'..cfg.id,cfg.origin=='GROUP' and 'Common identity not established' or 'Selected-entry identities only'} end
  if count==0 then cards[#cards+1]={'No named positive-rank entries','Observed in this scoped sample',state=='PARTIAL_UNAVAILABLE' and 'Omissions/limits remain' or 'Not an empty-build claim'} end
 end
 cards[#cards+1]={'Sample counts','Named rows: '..c.shown,'Inspected nodes: '..c.inspected}
 cards[#cards+1]={'Omitted / outside scope','Positive-rank omitted: '..c.positiveOmitted,'Zero-rank outside: '..c.zeroRank}
 cards[#cards+1]={'Unknown observations','Unknown nodes: '..c.unknown,'Names unavailable: '..c.nameUnavailable}
 cards[#cards+1]={'Special / changed nodes','Tiered not included: '..c.tiered,'Changed rows omitted: '..c.changed}
 cards[#cards+1]={'Membership / work limits','Tree failures: '..c.treeFailures,snapshot.membershipKnown and 'Uninspected: '..c.uninspected or 'Uninspected count unknown'}
 cards[#cards+1]={'Bounded scope',snapshot.limitReached and 'Work/output limit reached' or 'Within request work limits','No ability/readiness inference'}
 local seen={}
 for i=1,count do
  local r=rows[i]
  if not keys(r,{nodeID=true,entryID=true,name=true,rank=true,maximum=true,kind=true,subtreeAssociated=true}) or not integer(r.nodeID,2147483647) or seen[r.nodeID] or not integer(r.entryID,2147483647) or not integer(r.rank,2147483647) or r.rank==0 or not integer(r.maximum,2147483647) or r.kind~='ENTRY' and r.kind~='SUBTREE_CHOICE' or type(r.subtreeAssociated)~='boolean' then return nil end
  seen[r.nodeID]=true
  if not M.References:Text(r.name,64,false,false) or not valid() then return nil end
  cards[#cards+1]={'Node #'..r.nodeID,'Selected entry #'..r.entryID,r.kind=='SUBTREE_CHOICE' and 'Reported subtree choice' or r.subtreeAssociated and 'Subtree-associated' or 'Reported selected entry'}
  local chunks=M.ReferenceView:Pages(r.name,16,1)
  for j=1,#chunks,2 do cards[#cards+1]={r.kind=='SUBTREE_CHOICE' and 'Reported subtree choice' or 'Reported entry name',chunks[j],chunks[j+1] or ''} end
  cards[#cards+1]={'Reported node quantities','Rank: '..r.rank,'Maximum: '..r.maximum}
 end
 local function unchanged()
  local intact,value=pcall(same,data,snapshot)
  return intact and value==true and valid()
 end
 if not unchanged() then return nil end
 return cards,state,unchanged,snapshot
end

function M:LegacyEntryCards(data,valid,treeID)
 return self:TalentEntryCards(data,valid,treeID)
end
