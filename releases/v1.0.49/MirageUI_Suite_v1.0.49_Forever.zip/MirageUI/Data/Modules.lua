local _, M = ...
M.Catalog={
 {id="Core",name="MirageUI Core",gate="G2",system=true},
 {id="Context",name="Contextual visibility",gate="G2",system=true},
 {id="Options",name="Settings",gate="G3",system=true},
 {id="EditMode",name="Unlock Mode",gate="G3",system=true},
 {id="Minimap",name="Minimap",gate="G5",default=true,kind="native",note="On the qualified Forever client, a custom square minimap and controls use the game's live map canvas and pins. Saved geometry and context preferences remain shared."},
 {id="Chat",name="Chat",gate="G5",default=true,kind="native",note="Custom message canvases retain native routing, links, input and tabs. Bounded local history stays out of support and profile exports."},
 {id="Tooltips",name="Tooltips",gate="G5",default=true,kind="native",note="Mirage tooltips use a charcoal surface, warm accents and clear typography. Insight adds item, unit and profession context; game data, comparisons and input remain available."},
 {id="QuestTracker",name="Objectives",gate="G5",default=true,kind="native",note="Complete native objective content in a custom scrolling view. Compact objectives remain an independent optional panel."},
 {id="UnitFrames",name="Unit frames",gate="G6",default=true,kind="secure",note="Mirage player, pet, target, Target's Target, focus and boss frames with native targeting and click-casting access."},
 {id="Nameplates",name="Nameplates",gate="G6",default=true,kind="native",note="Custom enemy, neutral, friendly and pet nameplates use the approved thin health, resource, cast and aura designs. Native world positioning is retained."},
 {id="ActionBars",name="Action bars",gate="G7",default=true,kind="secure",note="One readable section with three horizontal action rows, a pet row and a More Actions banner. Stance and available native totem controls share the layout; existing reserve slots and shortcuts stay accessible."},
 {id="UnderCharacterHUD",name="Under-Character HUD",gate="G7",default=false,kind="owned",note="Player health, primary resource and activity-only cast bars at a configurable screen anchor. No camera tracking."},
 {id="ResourceBars",name="Resources and casts",gate="G7",default=false,kind="owned",note="Player health/power, cast/channel, GCD and an optional native class-resource bar."},
 {id="Auras",name="Auras",gate="G8",default=true,kind="native",note="Mirage presentation for primary buffs and debuffs. Player panels, reminders and private anchors remain separate optional features."},
 {id="Cooldowns",name="Cooldown Manager",gate="G8",default=true,kind="native",note="One ordered row below the character HUD tracks ability and item cooldowns, charges, player buffs and player or target debuffs. Add a separate item-buff timer to follow an on-use effect. Native durations and public item timing stay authoritative."},
 {id="PartyRaid",name="Party and raid",gate="G9",default=true,kind="secure",note="Custom secure group frames and eight subgroup layouts preserve native targeting, menus and click-casting."},
 {id="BlizzardSkin",name="Game windows",gate="G10",default=true,kind="native",note="Native by design. Task, character, progression, social, system and full map/quest windows open in their original game presentation. Mirage bags, bank and objective tracker retain their separate custom displays."},
 {id="Bags",name="Bags and bank",gate="G10",default=true,kind="native",note="Interactive Mirage item grid with native item, bank, search, sorting and transaction behavior. The optional offline browser remains separate."},
 {id="DataBars",name="Travel and progress",gate="G10",default=true,kind="owned",note="Optional location, XP, money and clock. No predicted travel times."},
 {id="DamageMeters",name="Meters",gate="G10",default=true,kind="native",note="Automatic combat sessions, damage and healing rates, useful combat categories and spell breakdowns in a custom Mirage panel."},
 {id="PvP",name="PvP combat lenses",gate="G9",default=false,kind="owned",note="Manual encounter emphasis or guarded public group/instance context through existing surfaces. No enemy inference, objectives or predictions."},
 {id="TacticalSignals",name="Tactical signals",gate="G9",default=false,kind="owned",note="Separate native ping shortcuts and local conventions. Never automatically sends a ping or marker."},
 {id="Preparations",name="Preparations",gate="G10",default=false,kind="owned",note="Manual, carried-supply, own-equipment details, saved-set and own-talent config/named-entry snapshots, not readiness or usage advice and not an applied build. Guarded Forever durability and own Legacy snapshots/native inspection; Camping remains manual."},
 {id="Notifications",name="Activity notifications",gate="G10",default=true,kind="owned",note="Quiet self-loot, money, profession, level and reputation receipts. Custom hit text above supported nameplates, with native fallback for uncovered targets and healing."},
 {id="Forever",name="Forever compatibility",gate="G12",system=true,note="Separate adapter and capability record. Source-pinned Legacy observations; Camping unimplemented. Native acceptance remains pending."},
}
M.CatalogByID={}
for _,entry in ipairs(M.Catalog) do M.CatalogByID[entry.id]=entry end
M.PresetNames={"Balanced","Immersive","Always Informed","Accessibility"}
M.States={HIDDEN=true,AMBIENT=true,VISIBLE=true,EMPHASIZED=true,PROTECTED_FLOOR=true}
M.Theme=M:Copy(M.VisualTokens.options)
