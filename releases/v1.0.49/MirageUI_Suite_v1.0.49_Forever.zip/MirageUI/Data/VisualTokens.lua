local _,M=...
-- Sole shared palette authority for runtime surfaces. Options chrome and world
-- cards are intentionally different contexts, not competing world-frame themes.
-- beta.14 neutral text is brighter for the user-approved 10% background; class authority remains native.
M.VisualTokens={version="1.0-beta35",world={version="1.0",surface={207/255,209/255,211/255},stroke={143/255,150/255,156/255},
 health={0,251/255,170/255},mana={0,200/255,254/255},track={80/255,83/255,89/255},
 neutral={228/255,235/255,239/255},level={249/255,230/255,27/255},cast={1,186/255,43/255},
 accents={Magic={50/255,150/255,1},Curse={150/255,0,1},Poison={0,150/255,0},Disease={150/255,100/255,0},Bleed={232/255,93/255,98/255}}},options={hover={.15,.12,.08,.98},background={.035,.035,.038,.98},panel={.060,.060,.065,.97},edge={.26,.26,.26,1},accent={.91,.55,.18,1},secondary={.96,.79,.36,1},text={.90,.89,.87,1},muted={.63,.62,.60,1},violet={.96,.79,.36,1}},
 name={flags="",shadowAlpha=0,shadowX=0,shadowY=0},
 geometry={nameplate={width=220,height=55},unit={width=300,height=55},hud={width=205,x=0,y=-185,health=10,resource=7,cast=7,gap=3}},
}
-- Cursor Companion's quiet edit fields and disabled controls are shared by
-- every options/workspace surface, independently of gameplay color semantics.
M.VisualTokens.options.input={.028,.028,.030,.95}
M.VisualTokens.options.disabledPanel={.063,.063,.065,.7}
M.VisualTokens.options.disabledEdge={.16,.16,.16,.8}
