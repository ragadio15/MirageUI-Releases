local _, M = ...
-- Supplied v2.0 borderless addon identities; functional module glyphs retain
-- their 1.1.1 designs. Live spell/item/unit artwork remains game-owned.
local I={version="2.0",moduleVersion="1.1.1",root="Interface\\AddOns\\MirageUI\\Media\\Icons\\"}
M.Icons=I
I.catalog={
 ["mirageui"]={label="MirageUI",group="suite"},
 ["mirageui-options"]={label="MirageUI Options",group="suite"},
 ["cursor-companion"]={label="Cursor Companion",group="suite"},
 ["sanctuary"]={label="MirageUI Sanctuary",group="suite"},
 ["wealthcraft"]={label="WealthCraft",group="suite"},
 ["utility-core"]={label="Utility Core",group="utility"},
 ["utility-map"]={label="Map+ Ultra",group="utility"},
 ["utility-navigate"]={label="Wayfinder",group="utility"},
 ["utility-gather"]={label="Gather Mate",group="utility"},
 ["utility-insight"]={label="Insight",group="utility"},
 ["action-bars"]={label="Action Bars",group="modules"},
 ["unit-frames"]={label="Unit Frames",group="modules"},
 ["group-frames"]={label="Group Frames",group="modules"},
 ["minimap"]={label="Minimap",group="modules"},
 ["nameplates"]={label="Nameplates",group="modules"},
 ["buffs-debuffs"]={label="Buffs & Debuffs",group="modules"},
 ["cooldowns"]={label="Cooldowns",group="modules"},
 ["damage-meters"]={label="Damage Meters",group="modules"},
 ["casts-resources"]={label="Casts & Resources",group="modules"},
 ["notifications"]={label="Notifications",group="modules"},
 ["task-windows"]={label="Task Windows",group="modules"},
 ["maps"]={label="Maps",group="modules"},
 ["objectives"]={label="Objectives",group="modules"},
 ["chat"]={label="Chat",group="modules"},
 ["tooltips-menus"]={label="Tooltips & Menus",group="modules"},
 ["inventory"]={label="Inventory",group="modules"},
 ["character-progression"]={label="Character & Progression",group="modules"},
 ["system-windows"]={label="System Windows",group="modules"},
 ["experience"]={label="Experience Bar",group="modules"},
 ["bags-launcher"]={label="Bags Launcher",group="modules"},
 ["micro-menu"]={label="System Menu Launcher",group="modules"},
 ["hud"]={label="Under-character HUD",group="modules"},
 ["pvp"]={label="PvP / Combat lenses",group="modules"},
 ["tactical-signals"]={label="Tactical signals",group="modules"},
 ["preparations"]={label="Preparations",group="modules"},
 ["travel-data"]={label="Travel / Data bars",group="modules"},
 ["visibility"]={label="Contextual visibility",group="modules"},
 ["layout"]={label="Unlock Mode",group="modules"},
 ["compatibility"]={label="Forever compatibility",group="modules"},
 ["addons-launcher"]={label="AddOns launcher",group="modules"},
 ["resource-bars"]={label="Resource bars",group="modules"},
}
I.modules={Core="mirageui",Options="mirageui-options",EditMode="layout",Context="visibility",Forever="compatibility",
 ActionBars="action-bars",UnitFrames="unit-frames",PartyRaid="group-frames",Minimap="minimap",Nameplates="nameplates",
 Auras="buffs-debuffs",Cooldowns="cooldowns",DamageMeters="damage-meters",ResourceBars="casts-resources",
 Notifications="notifications",BlizzardSkin="task-windows",QuestTracker="objectives",Chat="chat",Tooltips="tooltips-menus",
 Bags="inventory",DataBars="travel-data",UnderCharacterHUD="hud",PvP="pvp",TacticalSignals="tactical-signals",Preparations="preparations",
 Cursor="cursor-companion"}
I.elements={
 ["NativeControls.BagsBar"]="bags-launcher",["NativeControls.MicroMenuContainer"]="micro-menu",
 ["NativeControls.MainStatusTrackingBarContainer"]="experience",["NativeControls.SecondaryStatusTrackingBarContainer"]="experience",
 ["NativeControls.progression"]="experience",["DataBars.xp"]="experience",
 ["BlizzardSkin.windows"]="task-windows",["BlizzardSkin.character"]="character-progression",["BlizzardSkin.system"]="system-windows",
 ["ResourceBars.class"]="resource-bars",["ResourceBars.runes"]="resource-bars",["ResourceBars.totems"]="resource-bars",
 ["ResourceBars.empower"]="casts-resources",["UnderCharacterHUD.nativeCast"]="casts-resources"}
I.addons={MirageUI="mirageui",MirageUIOptions="mirageui-options",CursorCompanion="cursor-companion",MirageUISanctuary="sanctuary",Wealthcraft="wealthcraft",
 MirageIntel_Core="utility-core",MirageIntel_Map="utility-map",MirageIntel_Navigate="utility-navigate",MirageIntel_Gather="utility-gather",MirageIntel_Insight="utility-insight"}
function I:Path(id)
 return type(id)=="string" and self.catalog[id] and self.root..id..".tga" or nil
end
function I:ForModule(id) return self.modules[id] end
function I:ForElement(row)
 local id=type(row)=="table" and row.id or row
 if type(id)~="string" then return nil end
 return self.elements[id] or self.modules[type(row)=="table" and row.module or id:match("^([^%.]+)")]
end
function I:ForAddon(id) return self.addons[id] end
function I:Label(id,text,size)
 local path=self:Path(id)
 if not path or type(text)~="string" then return text end
 size=type(size)=="number" and size==size and math.max(12,math.min(32,math.floor(size))) or 18
 return "|T"..path..":"..size..":"..size..":0:0|t "..text
end
