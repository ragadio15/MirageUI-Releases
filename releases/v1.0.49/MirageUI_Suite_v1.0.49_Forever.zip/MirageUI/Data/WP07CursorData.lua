-- Explicitly admitted WP07 DATA ONLY registration; no profile/native authority.
-- The two embedded chunks are byte-exact archival donors. Their original
-- staging comments describe those donor files, not this registered wrapper.
-- No consumers are activated here. Mutable service data is not a permission.
local addonName, M = ...
local globals = _G
local function ownsEmptySlot()
    return addonName == "MirageUI" and type(M) == "table" and getmetatable(M) == nil
        and rawget(M, "name") == "MirageUI" and rawequal(_G, globals)
        and type(globals) == "table" and rawequal(rawget(globals, "MirageUI"), M)
        and rawget(M, "CursorPreferenceData") == nil
end
if not ownsEmptySlot() then return end
local ok, service = pcall(function()
    local schema = (function()
-- BEGIN EXACT DONOR schema
-- WP07 isolated candidate. Not in any TOC; no runtime, saved-root or suite writes.
-- Schema and bounds adapted from the source-qualified CursorCompanion/Data/Defaults.lua
-- and Core/SavedData.lua, archive SHA-256 115dc7aef17bc801aa444fb8a9ec30853da13f3debc21cf96cd3387896ef32b1.
-- Unlike source normalization, strict validation never fills or coerces a field.
local S = {contract = "WP07_CURSOR_PROFILE_SCHEMA/1", schemaVersion = 1}
local styles = {"Ring", "Segments", "Circle", "FourDash", "EightDash", "Plus", "Diagonal", "Corners", "Precision", "Orbit", "Ticks", "Compass", "Constellation", "Circuit"}
local roles = {"Decorative", "Spell range", "Relationship", "Cast / channel", "GCD", "Health", "Resource"}
local fields, ordered, tree = {}, {}, {}
local function field(path, kind, low, high, enum, integer)
  local spec = {path = path, kind = kind, low = low, high = high, enum = enum, integer = integer}
  fields[path] = spec; ordered[#ordered + 1] = path
  local node, parts = tree, {}
  for part in path:gmatch("[^.]+") do parts[#parts + 1] = part end
  for i = 1, #parts - 1 do node[parts[i]] = node[parts[i]] or {}; node = node[parts[i]] end
  node[parts[#parts]] = spec
end
field("enabled", "boolean"); field("hideOnMouseDown", "boolean")
field("offsetX", "number", -96, 96); field("offsetY", "number", -96, 96)
field("idleHideSeconds", "number", 0, 15); field("advanced.contrast", "boolean")
field("launcher.show", "boolean"); field("launcher.angle", "number", 0, 360)
for _, key in ipairs({"inner", "outer", "outer2"}) do
  local p = "rings." .. key .. "."
  field(p .. "enabled", "boolean"); field(p .. "glow", "boolean")
  field(p .. "style", "string", nil, nil, styles); field(p .. "role", "string", nil, nil, roles)
  field(p .. "size", "number", key == "outer" and 24 or 20, key == "inner" and 100 or key == "outer" and 128 or 176)
  field(p .. "stroke", "number", 1, 3, nil, true); field(p .. "opacity", "number", .1, 1)
  field(p .. "speed", "number", 0, 90)
  field(p .. "direction", "string", nil, nil, {"Clockwise", "Counterclockwise"})
  field(p .. "colorMode", "string", nil, nil, {"Manual", "Class", "Neutral"})
  for _, color in ipairs({"r", "g", "b"}) do field(p .. color, "number", 0, 1) end
end
for _, key in ipairs({"enabled", "playerHealth", "playerResource", "targetHealth", "focusCasting"}) do field("alerts." .. key, "boolean") end
for _, key in ipairs({"healthThreshold", "resourceThreshold", "executeThreshold"}) do field("alerts." .. key, "number", 1, 99) end
field("alerts.style", "string", nil, nil, {"Pulse", "Glow", "Burst", "Sparks", "Ripple", "Beacon"})
field("alerts.size", "number", 32, 240); field("alerts.duration", "number", .25, 2.5)
field("alerts.repeatSeconds", "number", 1, 15); field("alerts.opacity", "number", .1, 1)
for _, color in ipairs({"r", "g", "b"}) do field("alerts.color." .. color, "number", 0, 1) end
field("motion.enabled", "boolean")
field("motion.kind", "string", nil, nil, {"Ribbon", "Dots", "Comet", "Glints", "Mist", "Needles", "Stardust"})
field("motion.colorMode", "string", nil, nil, {"Manual", "Class", "Neutral"})
for _, color in ipairs({"r", "g", "b"}) do field("motion." .. color, "number", 0, 1) end
field("motion.length", "number", 20, 240); field("motion.lifetime", "number", .05, .6)
field("motion.width", "number", 1, 16); field("motion.density", "number", 2, 24)
field("motion.opacity", "number", .05, .6); field("motion.quality", "string", nil, nil, {"Low", "Balanced", "High"})
field("info.reference", "string"); field("info.probes", "string"); field("info.brackets", "boolean")
field("info.source", "string", nil, nil, {"mouseover", "target"})
tree.info.tracked = {trackedArray = true}
for _, key in ipairs({"enabled", "experimental", "confirmDuel", "whisper", "invite", "trade", "follow", "inspect", "questlog", "groupfinder", "professions", "duel", "mark", "ping", "focus", "signalIcons", "signalFeedback", "actionIcons"}) do field("palette." .. key, "boolean") end
field("palette.closeMode", "string", nil, nil, {"Click and Escape", "Escape only"})
field("palette.radius", "number", 96, 144); field("palette.offsetX", "number", -200, 200); field("palette.offsetY", "number", -200, 200)
field("palette.signalStyle", "string", nil, nil, {"Chromatic", "Tactical", "Monochrome"})
field("palette.signalLabels", "string", nil, nil, {"Contextual", "Always"})
field("palette.signalScale", "number", .75, 1.4); field("palette.actionScale", "number", .75, 1.4)
table.sort(ordered)

local function copy(v)
  if type(v) ~= "table" then return v end
  local out = {}; for k, item in next, v do out[k] = copy(item) end; return out
end
local function number(v) return type(v) == "number" and v == v and v ~= math.huge and v ~= -math.huge end
local function scalar(value, spec)
  if type(value) ~= spec.kind then return false, "TYPE: " .. spec.path end
  if spec.kind == "number" then
    if not number(value) then return false, "FINITE: " .. spec.path end
    if spec.low and (value < spec.low or value > spec.high) then return false, "BOUNDS: " .. spec.path end
    if spec.integer and value % 1 ~= 0 then return false, "INTEGER: " .. spec.path end
  elseif spec.kind == "string" then
    if #value > 512 or value:find("[%z\1-\8\11\12\14-\31\127]") then return false, "TEXT: " .. spec.path end
    if spec.enum then
      local found = false; for _, item in ipairs(spec.enum) do if value == item then found = true; break end end
      if not found then return false, "ENUM: " .. spec.path end
    end
  end
  return true
end
local function walk(input, shape, path, visited)
  if type(input) ~= "table" or getmetatable(input) ~= nil then return nil, "PLAIN_TABLE: " .. path end
  if visited[input] then return nil, "REPEATED_TABLE: " .. path end
  visited[input] = true
  local out = {}
  if shape.trackedArray then
    local count = 0
    for key, value in next, input do
      if not number(key) or key % 1 ~= 0 or key < 1 or key > 8 then return nil, "TRACKED_INDEX" end
      if type(value) ~= "string" or #value > 200 or value:find("[%z\1-\8\11\12\14-\31\127]") then return nil, "TRACKED_TEXT" end
      count = count + 1; out[key] = value
    end
    if count < 1 or count > 8 then return nil, "TRACKED_COUNT" end
    for i = 1, count do if rawget(input, i) == nil then return nil, "TRACKED_HOLE" end end
    return out
  end
  for key in next, input do if type(key) ~= "string" or rawget(shape, key) == nil then return nil, "UNEXPECTED_FIELD: " .. path end end
  for key, child in next, shape do
    local full = path == "" and key or path .. "." .. key
    local value = rawget(input, key)
    if value == nil then return nil, "MISSING_FIELD: " .. full end
    if type(child.path) == "string" then
      local ok, reason = scalar(value, child); if not ok then return nil, reason end; out[key] = value
    else
      local result, reason = walk(value, child, full, visited); if not result then return nil, reason end; out[key] = result
    end
  end
  return out
end
function S.CheckGeometry(rings)
  -- Call after validating ring records. Dormant records do not change active geometry.
  for _, pair in ipairs({{"inner", "outer"}, {"outer", "outer2"}, {"inner", "outer2"}}) do
    local small, big = rings[pair[1]], rings[pair[2]]
    local intermediate = pair[1] == "inner" and pair[2] == "outer2" and rings.outer.enabled
    if small.enabled and big.enabled and not intermediate and (big.size - small.size) / 2 < 3 + math.max(big.stroke, small.stroke) then
      return false, "RING_GAP: " .. pair[1] .. "/" .. pair[2]
    end
  end
  return true
end
function S.Validate(profile)
  local clean, reason = walk(profile, tree, "", {}); if not clean then return nil, reason end
  local ok, why = S.CheckGeometry(clean.rings); if not ok then return nil, why end
  return clean
end
function S.Copy(profile) local clean, reason = S.Validate(profile); return clean, reason end
function S.Specs() return copy(fields) end
function S.OrderedPaths() return copy(ordered) end
function S.IsFinite(value) return number(value) end
function S.Get(profile, path)
  local node = profile; for part in path:gmatch("[^.]+") do
    if type(node) ~= "table" then return nil end
    node = rawget(node, tonumber(part) or part)
  end
  return node
end
function S.Flatten(profile)
  local clean, reason = S.Validate(profile); if not clean then return nil, reason end
  local rows = {}
  for _, path in ipairs(ordered) do rows[#rows + 1] = {key = path, type = fields[path].kind, value = S.Get(clean, path)} end
  rows[#rows + 1] = {key = "info.tracked.count", type = "number", value = #clean.info.tracked}
  for i, value in ipairs(clean.info.tracked) do rows[#rows + 1] = {key = "info.tracked." .. i, type = "string", value = value} end
  table.sort(rows, function(a, b) return a.key < b.key end)
  return rows
end
function S.Inflate(values)
  if type(values) ~= "table" or getmetatable(values) ~= nil then return nil, "PLAIN_FIELDS" end
  local out, seen = {}, {}
  for key, value in next, values do
    if type(key) ~= "string" then return nil, "FIELD_NAME" end
    local spec = fields[key]
    if spec then
      local ok, reason = scalar(value, spec); if not ok then return nil, reason end
      local node, parts = out, {}; for part in key:gmatch("[^.]+") do parts[#parts + 1] = part end
      for i = 1, #parts - 1 do node[parts[i]] = node[parts[i]] or {}; node = node[parts[i]] end
      node[parts[#parts]] = value; seen[key] = true
    elseif key ~= "info.tracked.count" and not key:match("^info%.tracked%.[1-8]$") then return nil, "UNEXPECTED_FIELD: " .. key:sub(1, 80) end
  end
  for _, key in ipairs(ordered) do if not seen[key] then return nil, "MISSING_FIELD: " .. key end end
  local count = rawget(values, "info.tracked.count")
  if not number(count) or count % 1 ~= 0 or count < 1 or count > 8 then return nil, "TRACKED_COUNT" end
  out.info.tracked = {}
  for i = 1, 8 do
    local value = rawget(values, "info.tracked." .. i)
    if i <= count then if value == nil then return nil, "TRACKED_HOLE" end; out.info.tracked[i] = value
    elseif value ~= nil then return nil, "TRACKED_EXTRA" end
  end
  return S.Validate(out)
end
function S.Equal(a, b)
  local left, right = S.Flatten(a), S.Flatten(b); if not left or not right or #left ~= #right then return false end
  for i, row in ipairs(left) do if row.key ~= right[i].key or row.value ~= right[i].value or row.type ~= right[i].type then return false end end
  return true
end
function S.Describe(profile)
  local clean, reason = S.Validate(profile); if not clean then return nil, reason end
  local rows = assert(S.Flatten(clean))
  local rangeActive = false
  for _, ring in pairs(clean.rings) do if clean.enabled and ring.enabled and (ring.role == "Spell range" or ring.role == "Relationship") then rangeActive = true end end
  local alertSources = {}
  for _, source in ipairs({{"playerHealth", "player health"}, {"playerResource", "player resource"}, {"targetHealth", "target health"}, {"focusCasting", "focus casting"}}) do
    if clean.alerts[source[1]] then alertSources[#alertSources + 1] = source[2] end
  end
  for _, row in ipairs(rows) do
    local path, status, why = row.key, "active", "Stored preference; actual runtime admission is Atlas-owned."
    local ringKey, leaf = path:match("^rings%.([^.]+)%.(.+)$")
    if ringKey then
      local ring = clean.rings[ringKey]
      if not clean.enabled or not ring.enabled then status, why = "dormant", "Cursor or ring disabled; every saved field is retained."
      elseif (leaf == "r" or leaf == "g" or leaf == "b") and ring.colorMode ~= "Manual" then status, why = "dormant", "Manual RGB retained under selected " .. ring.colorMode .. " tint."
      elseif (leaf == "speed" or leaf == "direction") and (ring.role == "Health" or ring.role == "Resource") then status, why = "dormant", "Vital progress remains angle-stable; saved rotation retained."
      elseif ring.role ~= "Decorative" then status, why = "conditional", "Display needs a qualified source and presentation owner." end
    elseif path:match("^info%.") then status, why = rangeActive and "conditional" or "dormant", "Spell catalog is client-qualified; no range ring is enabled by preservation."
    elseif path == "advanced.contrast" then status, why = rangeActive and "conditional" or "dormant", "Source contrast palette affects range tint; retained with no active range role."
    elseif path:match("^motion%.") then
      if not clean.enabled or not clean.motion.enabled then status, why = "dormant", "Cursor or motion disabled."
      elseif path:match("^motion%.[rgb]$") and clean.motion.colorMode ~= "Manual" then status, why = "dormant", "Manual RGB retained under selected tint." end
    elseif path:match("^alerts%.") then
      status, why = "conditional", "Selected alert sources: " .. table.concat(alertSources, ", ") .. ". Qualified readable samples only; combat/restricted/unknown suppress evaluation."
      if not clean.enabled or not clean.alerts.enabled or #alertSources == 0 or
        (path == "alerts.healthThreshold" and not clean.alerts.playerHealth) or
        (path == "alerts.resourceThreshold" and not clean.alerts.playerResource) or
        (path == "alerts.executeThreshold" and not clean.alerts.targetHealth) or
        ((path == "alerts.playerHealth" or path == "alerts.playerResource" or path == "alerts.targetHealth" or path == "alerts.focusCasting") and row.value == false) then
        status, why = "dormant", "Disabled cursor/alert condition or its dormant threshold; never fires from retention."
      end
    elseif path == "palette.signalLabels" then status, why = "legacy", "Retained compatibility field; icons suppress duplicate perimeter labels."
    elseif path:match("^palette%.") then
      status, why = "conditional", "Explicit supported out-of-combat shortcut and native action permission required."
      if not clean.enabled or not clean.palette.enabled then status, why = "dormant", "Cursor or quick menu disabled; settings retained." end
    elseif path:match("^launcher%.") then status, why = "conditional", "Launcher ownership and suite wiring remain Atlas-owned." end
    row.classification, row.reason = status, why
  end
  return rows
end
return S
-- END EXACT DONOR schema
    end)()
    local codecFactory = (function()
-- BEGIN EXACT DONOR codecFactory
-- WP07 data-only CCP25 codec, isolated and inactive until Atlas admits it.
-- Adapted wire grammar/Adler/base64 from CursorCompanion/Core/Profiles.lua in
-- archive 115dc7aef17bc801aa444fb8a9ec30853da13f3debc21cf96cd3387896ef32b1.
-- No dynamic execution, saved globals, native observations, names or bindings.
local C = {contract = "WP07_CCP25_ADAPTER/1", maxCode = 28000, maxData = 18000, maxRecords = 180}
local alphabet, mapping = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", {}
for i = 1, #alphabet do mapping[alphabet:sub(i, i)] = i - 1 end
local function checksum(data)
  local a, b = 1, 0
  for i = 1, #data do a = (a + data:byte(i)) % 65521; b = (b + a) % 65521 end
  return string.format("%04X%04X", b, a)
end
local function encode64(data)
  local out = {}
  for i = 1, #data, 3 do
    local a, b, c = data:byte(i, i + 2)
    local n = a * 65536 + (b or 0) * 256 + (c or 0)
    local i1, i2, i3, i4 = math.floor(n / 262144) % 64 + 1, math.floor(n / 4096) % 64 + 1, math.floor(n / 64) % 64 + 1, n % 64 + 1
    out[#out + 1] = alphabet:sub(i1, i1) .. alphabet:sub(i2, i2) .. (b and alphabet:sub(i3, i3) or "=") .. (c and alphabet:sub(i4, i4) or "=")
  end
  return table.concat(out)
end
local function decode64(code)
  if #code == 0 or #code % 4 ~= 0 or not code:match("^[A-Za-z0-9+/]+=?=?$") then return nil end
  local out = {}
  for i = 1, #code, 4 do
    local a, b, c, d = code:sub(i, i + 3):match("(.)(.)(.)(.)")
    local av, bv, cv, dv = mapping[a], mapping[b], mapping[c], mapping[d]
    if av == nil or bv == nil or (c ~= "=" and cv == nil) or (d ~= "=" and dv == nil) then return nil end
    if c == "=" and (d ~= "=" or i ~= #code - 3 or bv % 16 ~= 0) then return nil end
    if d == "=" and (i ~= #code - 3 or (c ~= "=" and cv % 4 ~= 0)) then return nil end
    local n = av * 262144 + bv * 4096 + (cv or 0) * 64 + (dv or 0)
    out[#out + 1] = string.char(math.floor(n / 65536) % 256)
    if c ~= "=" then out[#out + 1] = string.char(math.floor(n / 256) % 256) end
    if d ~= "=" then out[#out + 1] = string.char(n % 256) end
  end
  return table.concat(out)
end
local function valueEncode(value)
  if type(value) == "boolean" then return value and "B1" or "B0" end
  if type(value) == "number" then
    -- Keep source-canonical output when exact; never round a representable preference.
    local text = string.format("%.14g", value)
    if tonumber(text) ~= value then
      for precision = 15, 17 do
        text = string.format("%." .. precision .. "g", value)
        if tonumber(text) == value then break end
      end
    end
    if #text > 22 or tonumber(text) ~= value then return nil, "NUMBER_WIRE_PRECISION" end
    return "N" .. text
  end
  return "S" .. (value:gsub(".", function(ch) return string.format("%02X", ch:byte()) end))
end
local function valueDecode(text, kind, schema)
  if type(text) ~= "string" then return nil, false end
  if kind == "boolean" then
    if text == "B0" then return false, true end
    if text == "B1" then return true, true end
    return nil, false
  end
  local tag, payload = text:sub(1, 1), text:sub(2)
  if kind == "number" then
    if tag ~= "N" or #payload == 0 or #payload > 22 or not payload:match("^[%d%.%+%-eE]+$") then return nil, false end
    local value = tonumber(payload); return value, schema.IsFinite(value)
  end
  if kind == "string" then
    if tag ~= "S" or #payload % 2 ~= 0 or #payload > 1024 or not payload:match("^%x*$") then return nil, false end
    return (payload:gsub("..", function(hex) return string.char(tonumber(hex, 16)) end)), true
  end
  return nil, false
end
function C.New(schema, expectedFlavor)
  if type(schema) ~= "table" or schema.contract ~= "WP07_CURSOR_PROFILE_SCHEMA/1" then return nil, "SCHEMA_CONTRACT" end
  -- Literal flavors from the supplied adapters, not a claim of native admission.
  local flavors = {Midnight = true, Forever = true, ["Classic Hardcore"] = true}
  if type(expectedFlavor) ~= "string" or not flavors[expectedFlavor] then return nil, "EXPECTED_SOURCE_FLAVOR_REQUIRED" end
  local P = {contract = C.contract, flavor = expectedFlavor, maxCode = C.maxCode}
  local specs = schema.Specs()
  function P:Decode(raw)
    if type(raw) ~= "string" or #raw > C.maxCode + 100 then return nil, "CODE_SIZE" end
    local code = raw:match("^%s*(.-)%s*$")
    local digest, encoded = code:match("^CCP25:([0-9A-F]+):([A-Za-z0-9+/=]+)$")
    if not digest or #digest ~= 8 or #code > C.maxCode then return nil, "CODE_ENVELOPE" end
    local data = decode64(encoded)
    if not data or #data > C.maxData then return nil, "CODE_ENCODING_OR_SIZE" end
    if checksum(data) ~= digest then return nil, "CODE_CHECKSUM" end
    local rawFields, records, count = {}, {}, 0
    for line in (data .. "\n"):gmatch("(.-)\n") do
      count = count + 1; if count > C.maxRecords then return nil, "RECORD_LIMIT" end
      local key, value = line:match("^([A-Za-z0-9%.]+)=(.*)$")
      if not key or rawFields[key] ~= nil then return nil, "MALFORMED_OR_DUPLICATE_FIELD" end
      if #key > 80 then return nil, "FIELD_NAME_LENGTH" end
      rawFields[key] = value; records[#records + 1] = {key = key, token = value}
    end
    if rawFields.format ~= "1" then return nil, "UNSUPPORTED_FORMAT" end
    if rawFields.flavor ~= expectedFlavor then return nil, "FLAVOR_MISMATCH" end
    local values = {}
    for key, rawValue in pairs(rawFields) do
      if key ~= "format" and key ~= "flavor" then
        local kind = specs[key] and specs[key].kind
        if key == "info.tracked.count" then kind = "number"
        elseif key:match("^info%.tracked%.[1-8]$") then kind = "string" end
        if not kind then return nil, "UNEXPECTED_FIELD: " .. key end
        local value, valid = valueDecode(rawValue, kind, schema)
        if not valid then return nil, "INVALID_FIELD: " .. key end
        values[key] = value
      end
    end
    local profile, reason = schema.Inflate(values); if not profile then return nil, reason end
    return profile, nil, {format = 1, flavor = expectedFlavor, checksum = digest, payloadBytes = #data, recordCount = count, preferenceCount = count - 2, records = records}
  end
  function P:Encode(profile)
    local rows, reason = schema.Flatten(profile); if not rows then return nil, reason end
    -- Source exporter puts the tracked count before its numbered entries.
    table.sort(rows, function(a, b)
      local ak = a.key == "info.tracked.count" and "info.tracked.0" or a.key
      local bk = b.key == "info.tracked.count" and "info.tracked.0" or b.key
      return ak < bk
    end)
    local lines = {"format=1", "flavor=" .. expectedFlavor}
    for _, row in ipairs(rows) do
      local encoded, why = valueEncode(row.value); if not encoded then return nil, why end
      lines[#lines + 1] = row.key .. "=" .. encoded
    end
    local data = table.concat(lines, "\n")
    if #data > C.maxData or #lines > C.maxRecords then return nil, "PAYLOAD_SIZE" end
    local code = "CCP25:" .. checksum(data) .. ":" .. encode64(data)
    if #code > C.maxCode then return nil, "CODE_SIZE" end
    return code
  end
  return P
end
return C
-- END EXACT DONOR codecFactory
    end)()
    return {
        contract = "MIRAGE_CURSOR_PREFERENCE_DATA/1",
        schema = schema,
        codecFactory = codecFactory,
    }
end)
if not ok or not ownsEmptySlot() then return end
rawset(M, "CursorPreferenceData", service)
