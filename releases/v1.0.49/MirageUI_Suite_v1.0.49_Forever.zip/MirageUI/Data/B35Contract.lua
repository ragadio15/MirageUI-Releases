local _,M=...
-- Approved b35 product defaults and scope. The executable policy lives in the
-- owning modules; this manifest is a stable support/review identity, not native
-- qualification or a claim that every historical research rule is implemented.
M.B35Contract={revision=1,version="0.1.0-beta.35",contextCatalogueEntries=113,
 nativeQualification="NOT_RUN",profileRevision=1,
 timing={fade=.22,idleDwell=0,movementHold=0,combatHold=0,chat=8,selection=3,
  roster=3,hoverLeave=.4,reveal=10,receipt=4,receiptRows=3,blockedReceiptRows=1,
  questUpdate=5,questAccepted=8,zone=5,level=8,castSuccess=.20,castStopped=.35,castInterrupted=.75},
 geometry={sidebarWidth=300,objectiveMaxHeight=420,hudDownwardMigration=40,hudRowPitch=14,
  nameplateWidth=220,nameplateHeight=55,plateBackingPercent=12,auraIcons=4,auraIconSize=20},
 nativeProviders={tasks=true,maps=true,character=true,system=true,tooltips=true},
 selectedOnlyCategories={friendlyPlayer=true,friendlyNPC=true,neutralNPC=true,pet=true,guardian=true,totem=true,critter=true},
 grayscaleRoles={player=true,pet=true,target=true,focus=true},
 boundaries={protectedCombat="NATIVE_ACCESS_FLOOR",unknownPlate="NATIVE_CLASSIFICATION_FALLBACK",
  playerCast="CONFIRMED_NATIVE_YIELD_BEFORE_CUSTOM",worldText="SUPPORTED_DISPLAYED_UNIT_EVENTS",
  nativeTasks="ORIGINAL_FROM_FIRST_FRAME",historicalResearch="NOT_A_B35_COMPLETION_CLAIM"}}
