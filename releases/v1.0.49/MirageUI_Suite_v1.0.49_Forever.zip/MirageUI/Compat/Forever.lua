local _, M = ...
assert(not M.adapter,"Multiple MirageUI client adapters")
-- Exact source candidate selected for this installation package. Other tuples
-- remain separately listed in Client.lua. Unknown builds use API-guarded runtime
-- admission and remain explicitly unreviewed in support reports.
-- Source review is not native rendering/input/taint qualification.
M.adapter={family="Forever",patch="1.60.1",build="71037",interface=16001,
 sourceCommit="734f065329cff4992835b01a84f210a297db91b6",nativePending=true}
