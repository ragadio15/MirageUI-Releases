local _, M = ...
assert(not M.adapter,"Multiple MirageUI client adapters")
M.adapter={family="Midnight",patch="12.1.5",build="70575",interface=120105,
    sourceCommit="15881d522c44cd106d3d8660106ec9f9d2f44167"}
