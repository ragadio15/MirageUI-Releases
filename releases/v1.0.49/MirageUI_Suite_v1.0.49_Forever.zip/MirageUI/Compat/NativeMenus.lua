local _,M=...
local S=M.Safety
M.ClientUI={status="NOT_RUN"}
local N=M.ClientUI
-- Native menu entry points are selected per available modern-client contract.
-- No talent tree or Classic-era schema is inferred from the client's name.
function N:Route(id)
 local util=PlayerSpellsUtil
 if id=="spellbook" then
  if util and type(util.ToggleSpellBookFrame)=="function" then return util.ToggleSpellBookFrame,nil,"SPELLBOOK_NATIVE_HELPER" end
  local tab=S:Field(util and util.FrameTabs,"SpellBook")
  if util and type(util.TogglePlayerSpellsFrame)=="function" and S:Number(tab) then return util.TogglePlayerSpellsFrame,tab,"SPELLBOOK_NATIVE_TAB" end
 elseif id=="talents" then
  if util and type(util.ToggleClassTalentOrSpecFrame)=="function" then return util.ToggleClassTalentOrSpecFrame,nil,"TALENTS_NATIVE_HELPER" end
  local tab=S:Field(util and util.FrameTabs,"ClassTalents")
  if util and type(util.TogglePlayerSpellsFrame)=="function" and S:Number(tab) then return util.TogglePlayerSpellsFrame,tab,"TALENTS_NATIVE_TAB" end
 end
 return nil,nil,"NATIVE_MENU_UNAVAILABLE"
end
function N:Available(id)
 if not M.Client.allowed then return false,"This client has not been enabled for the source-pinned candidate." end
 if S:InCombat() then return false,"Open this menu outside combat." end
 local fn=self:Route(id)
 return fn~=nil,fn and "Native menu available; behavior still needs client verification." or "Use the game's native menu; this entry point is unavailable."
end
function N:Open(id)
 local allowed,reason=self:Available(id)
 if not allowed then self.status="UNAVAILABLE";return false,reason end
 local fn,arg,route=self:Route(id)
 if not fn then self.status="UNAVAILABLE";return false,"Native menu unavailable." end
 local ok,result
 if arg~=nil then ok,result=pcall(fn,arg) else ok,result=pcall(fn) end
 if not ok then self.status="NATIVE_MENU_FAILED";return false,"The game did not open this menu. Its native controls remain available." end
 if not S:Readable(result) or result==false then self.status="NATIVE_MENU_DECLINED";return false,"The game declined this menu request." end
 self.status=route.."_DISPATCHED"
 return true,"Native menu request sent. Availability and unlock requirements are controlled by the game."
end
function N:Report()
 local lines={"Client: "..M.Client.family.." / "..M.Client.patch.." / "..M.Client.build,
  "Interface: "..M.Client.interface,"Gate: "..M.Client.reason,
  "Function availability is not a native PASS. No results are inherited from another client.",""}
 for _,id in ipairs({"spellbook","talents"}) do
  local fn,_,route=self:Route(id);lines[#lines+1]=id..": "..(fn and route or "Unavailable; native UI retained")
 end
 local ids={};for id in pairs(M.Capabilities.rows) do ids[#ids+1]=id end;table.sort(ids)
 for _,id in ipairs(ids) do
  local row=M.Capabilities.rows[id]
  lines[#lines+1]=id..": "..(row.present and "Provider found" or "Unavailable / gated").." | "..row.permission.." | native "..row.native
 end
 return table.concat(lines,"\n")
end
