-- Compatibility is capability-driven. Retain the old command as a deliberate
-- on/off choice; fresh and previously enabled installs need no build opt-in.
local _,M=...
function M.Client:RefreshCandidatePermission()
    local account=M.Profiles and M.Profiles.account
    local prior=account and account.candidateClient
    local paused=prior==false
    local boundary=M.Safety:BoundaryReady()
    self.allowed=not paused and self:RuntimeAvailable() or false
    self.experimental=self.allowed and M.adapter.nativePending==true or false
    self.candidateConsent=paused and "USER_PAUSED" or
        (M.Safety:Text(prior) and (prior==self.key and "EXACT_CLIENT" or "SAVED_CHOICE_CONTINUED") or "AUTOMATIC_CAPABILITY_MODE")
    self.reason=not boundary and "SECRET_BOUNDARY_UNAVAILABLE" or paused and "USER_COMPATIBILITY_PAUSED" or
        (self.allowed and (self.sourceMatched and "REVIEWED_SOURCE_API_GUARDED" or "UNREVIEWED_CLIENT_API_GUARDED") or "RUNTIME_CAPABILITY_UNAVAILABLE")
end
function M.Client:SetCandidate(enabled,deferApply)
    if enabled and not self:RuntimeAvailable() then return false,"Required runtime checks are unavailable. Available native controls remain accessible." end
    if M.Safety:InCombat() or M.Profiles.readOnly or not M.Profiles.account then return false,"Leave combat and use a writable profile before changing client mode." end
    M.Profiles.account.candidateClient=enabled and self.key or false
    self:RefreshCandidatePermission();M.Capabilities:Probe()
    if not enabled then
        local original=M.db.safe;M:SafeMode("FOREVER_CANDIDATE_DISABLED");M.db.safe=original
    elseif not deferApply then
        M.state.safe=M.db.safe==true
        M:ApplyProfile(nil,"CANDIDATE_OPT_IN")
    end
    return true,enabled and "Capability mode enabled. Each display uses its available APIs; native acceptance remains pending." or "MirageUI paused. Native interface preserved."
end
