local _, M = ...
M.Diagnostics={}
local sourcePin=M.Client:NewSourcePinLookup()
local function sourceIdentity()
    local c,a=M.Client,M.adapter
    local pin=a and sourcePin(a.family,a.build)
    if not pin or a.patch~=pin[1] or a.interface~=pin[3] or a.sourceCommit~=pin[4] then return "UNQUALIFIED",false end
    return pin[4],c.sourceMatched==true and c.family==a.family and c.patch==pin[1] and c.build==pin[2] and c.interface==pin[3]
end
local function runtimeSnapshot()
    return M.RuntimeSnapshot and M:RuntimeSnapshot() or {safeReason="UNKNOWN",apply={},cleanup={}}
end
local function observeBoolean(fn,object,...)
    if type(fn)~="function" then return nil,false end
    local ok,value=pcall(fn,object,...)
    if ok and type(value)=="boolean" then return value,true end
    return nil,false
end
-- This narrow exemption is evidence-based and fail-closed: it applies only
-- to the known 71091 native-mask inverse refusal with *zero mask writes*.
-- Generic PARTIAL, unknown client, and genuine minimap faults remain actionable.
local function intendedNativeMinimapFallback(id,row)
    if id~="minimap" or type(row)~="table" or row.readiness~="PARTIAL"
        or row.state~="ACTIVE" or not row.started or row.failed then return false end
    if row.readinessReason~="NATIVE_MINIMAP_RETAINED_UNREVIEWED"
        and row.reason~="NATIVE_MINIMAP_RETAINED_UNREVIEWED" then return false end
    local obj=row.object
    if type(obj)~="table" or obj.nativeMaskFallback~=true
        or obj.maskSubmission~="NO_MASK_WRITE" or obj.record~=nil then return false end
    local c=M.Client
    return c and c.family=="Forever" and c.patch=="1.60.1"
        and c.build=="71091" and c.sourceMatched~=true
end
local function appendFieldEvidence(lines,key,owner,method)
    if not owner or type(owner[method])~="function" then return end
    local okay,report=pcall(owner[method],owner)
    if not okay or not M.Safety:Text(report) or #report>8192 then
        lines[#lines+1]=key.."=EVIDENCE_UNAVAILABLE";return
    end
    -- Bounded complete fields, never a mid-field substring. The producers
    -- retain only public stage tags and session counts, not native payloads.
    local part,chunk=1,""
    for field in report:gmatch("[^;]+") do
        field=field:gsub("^%s+","")
        if #field>1024 then field="OVERSIZED_FIELD_WITHHELD" end
        if #chunk+#field+2>1024 and #chunk>0 then
            lines[#lines+1]=key.."_"..part.."="..chunk;part=part+1;chunk=""
        end
        chunk=chunk..(#chunk>0 and "; " or "")..field
    end
    if #chunk>0 then lines[#lines+1]=key.."_"..part.."="..chunk end
end
-- One read-only presentation model for chat, both settings views and setup.
-- This reports admission and work already recorded by Core; it grants nothing.
function M.Diagnostics:ActivationState()
    local runtime=runtimeSnapshot()
    local cleanup,apply=runtime.cleanup or {},runtime.apply or {}
    local failure=runtime.lastFailure
    local failedApply=failure and M.Safety:Number(failure.id) and M.Safety:Number(runtime.lastSuccessfulApply) and failure.id>runtime.lastSuccessfulApply
    local _,matched=sourceIdentity()
    local presentationMatched,presentationObserved=true,true
    if M.Rework and type(M.Rework.TargetMatched)=="function" then
        presentationMatched,presentationObserved=observeBoolean(M.Rework.TargetMatched,M.Rework)
    end
    local code,title,message,help,blocked="RUNNING","MirageUI is running","MirageUI is running with the enabled features in your current profile.","Formal native qualification is still pending. Your in-game observations are recorded separately.",false
    if not M.Client.allowed and M.Client.reason=="SECRET_BOUNDARY_UNAVAILABLE" then
        code,title,message,help,blocked="CAPABILITY_REFUSED","Required safety checks are unavailable","MirageUI cannot activate because the client's restricted-value checks are unavailable.","Keep using the Blizzard interface. Setup and Resume cannot bypass these checks; share /mirage export for support.",true
    elseif M.Profiles.readOnly and M.Profiles.readOnlyReason=="ROLLBACK_CODE_REPLACEMENT_REQUIRED" then
        code,title,message,help,blocked="ROLLBACK_STOPPED","Complete the b34 rollback","Your exact pre-b35 settings are restored and preserved. b35 remains paused.","Exit the game and replace all three addon folders with b34 before playing again. Reloading b35 does not reactivate or migrate the restored settings.",true
    elseif M.Profiles.readOnly then
        code,title,message,help,blocked="READ_ONLY","Saved settings need recovery","MirageUI is in read-only recovery mode. Your saved data has been preserved.","Use Help and recovery to inspect or recover saved settings before setup or resume.",true
    elseif cleanup.status=="BLOCKED" then
        code,title,message,help,blocked="CLEANUP_BLOCKED","Cleanup needs attention","MirageUI is stopped, but some display cleanup could not be confirmed.","Keep the native controls available. Use /mirage recover outside combat to retry cleanup; export diagnostics if it remains blocked.",true
    elseif cleanup.status=="PENDING" or M.state.safeCleanupPending then
        code,title,message,help,blocked="CLEANUP_PENDING","Display cleanup is pending","MirageUI has stopped new optional work. Some displays are still awaiting cleanup.","Cleanup retries when allowed. Use /mirage recover outside combat to retry; /mirage export lists the steps that remain pending.",true
    elseif not M.Client.allowed then
        blocked=true
        if M.Client.reason=="USER_COMPATIBILITY_PAUSED" then
            code,title,message,help="USER_STOPPED","MirageUI is paused","MirageUI is paused by your saved client-mode choice.","Use /mirage candidate on outside combat to resume capability mode."
        else
            code,title,message,help="CAPABILITY_UNAVAILABLE","Required runtime support is unavailable","MirageUI could not establish its required runtime checks.","Available native controls remain accessible. Copy /mirage export so the missing capability can be reviewed."
        end
    elseif not presentationObserved then
        code,title,message,help,blocked="OBSERVATION_UNAVAILABLE","Presentation status needs attention","The current presentation check is temporarily unavailable. Existing display ownership has been retained.","Use /mirage recover outside combat to retry the observation, or copy /mirage export for the recorded lifecycle state.",true
    elseif not presentationMatched then
        code,title,message,help,blocked="PRESENTATION_UNSUPPORTED","Presentation capabilities are unavailable","MirageUI could not establish the current presentation capability contract.","Copy /mirage export for the unavailable capability. Unreviewed build numbers alone do not prevent activation.",true
    elseif M.Rework and not M.Rework.storageReady then
        code,title,message,help,blocked="STORAGE_UNAVAILABLE","Presentation storage needs attention","MirageUI could not initialize its recoverable presentation settings. Custom providers have not started.","Your existing saved data is retained. Copy /mirage export so the migration status can be reviewed; do not reset WTF.",true
    elseif M.Rework and (M.Rework.rolledBack or M.Rework.rollbackPendingReload) then
        code,title,message,help,blocked="ROLLBACK_STOPPED","Profile rollback is active","The custom presentation remains paused after profile rollback.","Complete the reported rollback and reload before activating this package. Your checkpoint remains available.",true
    elseif apply.result=="FAILED" and not M.state.safe then
        code,title,message,help,blocked="APPLY_FAILED","Settings activation was not confirmed","The most recent settings application failed. Current optional presentation requires review.","Use /mirage recover outside combat to retry the current profile, or share /mirage export before making further settings changes.",true
    elseif M.state.safe then
        blocked=true
        if runtime.safeReason=="CORE_FAULT" then
            if runtime.safeReasonScope=="PERSISTED_RECORD" and runtime.historicalPatch=="P19_KEY_LABEL_FONT_ORDER"
                and (runtime.historicalPatchedResume=="PENDING" or runtime.historicalPatchedResume=="WAITING_COMBAT") then
                code,title,message,help="HISTORICAL_STOPPED","The previous P19 failure left MirageUI stopped","The saved stop matches the P19 action-label initialization defect repaired in this release.",
                    (runtime.historicalPatchedResume=="PENDING" or runtime.historicalPatchedResume=="WAITING_COMBAT")
                    and "Startup will retry your saved display choices outside combat. The original failure remains in /mirage export."
                    or "Use /mirage recover outside combat, or share /mirage export if the saved stop cannot be retired."
            else
                code,title,message,help=failedApply and "APPLY_FAILED" or "RUNTIME_FAILED","MirageUI stopped after a runtime failure","MirageUI stopped after a runtime operation failed. The current profile has not been confirmed as active.","Use /mirage recover outside combat to retry activation. If it fails again, share /mirage export; it includes recorded failure categories without raw error text."
            end
        elseif runtime.safeReason=="NATIVE_ACTION_BLOCKED" then
            if runtime.safeReasonScope=="PERSISTED_RECORD" then
                code,title,message,help="HISTORICAL_STOPPED","A previous session left MirageUI stopped","MirageUI loaded an automatic stop recorded in an earlier session.",
                    (runtime.historicalNativeResume=="PENDING" or runtime.historicalNativeResume=="WAITING_COMBAT")
                    and "Startup will retry your saved display choices outside combat. The earlier incident remains in /mirage export."
                    or "Use /mirage recover outside combat, or share /mirage export if the saved stop cannot be retired."
            else
                code,title,message,help="NATIVE_BLOCKED","The game blocked an interface action","MirageUI stopped after the game blocked an interface action.","Share /mirage export for support. Resume outside combat only after cleanup completes; formal native qualification remains pending."
            end
        elseif runtime.safeReason=="SAVED_SAFE_MODE" then
            code,title,message,help="SAVED_STOPPED","MirageUI remains stopped","MirageUI remains stopped from a previous session. The original stop cause is unavailable in this session.","Review your previous support report if available, or use /mirage recover outside combat to retry activation. Current source and cleanup checks still apply."
        elseif runtime.safeReason=="USER_REQUEST" or runtime.safeReason=="USER_SETTINGS" or runtime.safeReason=="USER_BINDING" then
            code,title,message,help="USER_STOPPED","MirageUI is paused","MirageUI is paused by your saved stop request.","Use Resume MirageUI or /mirage recover outside combat when you are ready. Your saved appearance settings are unchanged."
        else
            code,title,message,help="SAFE_STOPPED","MirageUI is stopped","MirageUI is stopped. Its optional presentation is not currently active.","Use /mirage recover outside combat to retry activation. The source and cleanup checks still apply."
        end
    elseif M.state.applyPending or apply.result=="DEFERRED" or apply.result=="RUNNING" then
        code,title,message,help,blocked="APPLY_PENDING","Settings activation is pending","MirageUI has not finished applying the current profile.","Leave combat and allow the current operation to finish before running setup again.",true
    elseif not M.profile or not M.profile.enabled then
        code,title,message,help="DISABLED","MirageUI presentation is disabled","MirageUI presentation is disabled in the current profile.","Enable presentation in Settings or run setup to choose the coordinated interface."
    elseif not M.state.world then
        code,title,message,help="READY","MirageUI is ready to enter the world","The current client is admitted. Optional presentation will be applied after entering the world.","Formal native qualification remains pending."
    end
    local failedModules,failedProviders,partialProviders,waitingProviders=0,0,0,0
    local selectedProviders,activeProviders,handoffProviders,startingProviders=0,0,0,0
    local lifecycleFailed=M.Rework and M.Rework.lastError=="LIFECYCLE_FAILED" or false
    if code=="RUNNING" then
        for _,id in ipairs(M.order) do
            local mod=M.modules[id];local cfg=M.profile.modules[id]
            local nativePolicy=M.NativeWindowPolicy and M.NativeWindowPolicy:ModuleNative(id)
            if not nativePolicy and cfg and cfg.enabled and mod and (mod.initializationFailed or mod.quarantined or mod.maintenanceFailed) then failedModules=failedModules+1 end
        end
        local rework=M.Rework
        if rework and type(rework.Selected)=="function" then
            for _,id in ipairs(rework.order or {}) do
                local row=rework.providers[id]
                local ok,selected=pcall(rework.Selected,rework,id)
                if ok and selected==true and row then
                    selectedProviders=selectedProviders+1
                    if row.state=="ACTIVE" and row.started then activeProviders=activeProviders+1
                    else startingProviders=startingProviders+1 end
                    if row.pending or row.readiness=="DEFERRED_HANDOFF"
                        or (row.state~="ACTIVE" or not row.started) and
                            (row.reason=="HANDOFF" or row.reason=="WORLD_LEFT" or row.reason=="NATIVE_EDIT") then
                        handoffProviders=handoffProviders+1
                    end
                end
                -- Waiting for a closed/empty game window is ordinary ACTIVE
                -- provider state, not a failed display. Native editing/combat
                -- deferrals are handled by their own lifecycle, too.
                if ok and selected==true and row and (row.failed==true or row.state=="RECOVERY"
                    or row.readiness=="FAULT" or row.readiness=="CONFLICT"
                    or row.state=="ACTIVE" and row.started and row.readiness=="READY" and row.object and row.object.active==false) then
                    failedProviders=failedProviders+1
                elseif ok and selected==true and row and row.readiness=="PARTIAL"
                    and not intendedNativeMinimapFallback(id,row) then
                    partialProviders=partialProviders+1
                elseif ok and selected==true and row and (row.readiness=="WAITING" or row.readiness=="EMPTY" or row.state~="ACTIVE" or not row.started) then
                    waitingProviders=waitingProviders+1
                end
            end
        end
        if failedModules>0 or failedProviders>0 or partialProviders>0 then
            code,title="RUNNING_PARTIAL","Some displays need attention"
            message="MirageUI is running, but some selected displays need recovery."
            help="Open Help to retry the affected display outside combat, or copy the report. Healthy displays continue running."
        elseif lifecycleFailed then
            code,title="RUNNING_PARTIAL","Display updates need attention"
            message="MirageUI retained its current displays after a shared lifecycle failure. Some display updates are paused."
            help="Use /mirage recover outside combat to resume updates, or copy /mirage export for the recorded failure phase."
        elseif rework and rework.editorObservation=="OPEN" then
            code,title="NATIVE_EDIT","Blizzard Edit Mode is open"
            message="MirageUI has handed its displays back to Blizzard while you edit the native interface."
            help="After Edit Mode closes, MirageUI resumes the selected displays when their native controls are ready."
            blocked=true
        elseif handoffProviders>0 or selectedProviders>0 and activeProviders==0 and startingProviders>0 then
            code,title="RECOVERING","MirageUI is restoring its displays"
            message=activeProviders>0 and "Some selected displays are still being restored. Healthy displays continue running."
                or "The selected displays are waiting for their native controls to finish restoring. MirageUI has not resumed them yet."
            help="Recovery retries after travel, Edit Mode and combat end. If this status persists, use /mirage recover outside combat and copy /mirage export."
        end
    end
    if not matched and (code=="RUNNING" or code=="RUNNING_PARTIAL" or code=="READY") then
        help=help.." This client is unreviewed; available features run with API checks. /miragecompat opens the compatibility report."
    end
    local mm=M.Rework and M.Rework.providers and M.Rework.providers.minimap
    if intendedNativeMinimapFallback("minimap",mm) and code=="RUNNING" then
        help=help.." Blizzard's minimap is active. MirageUI could not establish which mask to restore in this session."
    end
    return {code=code,title=title,message=message,help=help,setupBlocked=blocked,failedModules=failedModules,failedProviders=failedProviders,partialProviders=partialProviders,waitingProviders=waitingProviders,
        selectedProviders=selectedProviders,activeProviders=activeProviders,handoffProviders=handoffProviders,startingProviders=startingProviders,
        canRecover=M.Client.allowed==true and not M.Profiles.readOnly and code~="PRESENTATION_UNSUPPORTED" and code~="STORAGE_UNAVAILABLE" and code~="ROLLBACK_STOPPED"
            and code~="NATIVE_EDIT"
            and (M.state.safe==true or cleanup.status=="PENDING" or cleanup.status=="BLOCKED" or apply.result=="FAILED" or failedProviders>0 or partialProviders>0 or lifecycleFailed or not presentationObserved or code=="RECOVERING"),
        runtime=runtime}
end
local function enum(words)
    local out={};for word in words:gmatch("%S+") do out[word]=true end;return out
end
local function token(value,allowed,fallback)
    return M.Safety:Text(value) and allowed[value] and value or (fallback or "UNKNOWN")
end
local function count(value)
    return M.Safety:Number(value) and value>=0 and value<=2147483647 and value==math.floor(value) and value or 0
end
local applyTriggers=enum("PROFILE PROFILE_COMMIT SETUP PROFILE_ROLLBACK RECOVER CANDIDATE_OPT_IN WORLD_ENTERED COMBAT_ENDED OWNER_CHANGED RESIZE")
local applyPhases=enum("PRECHECK RECOVERY_RESET NATIVE_RELEASE ADAPTIVE_LAYOUT TYPOGRAPHY_BEGIN POLICY MODULE_INITIALIZE MODULE_RESUME MODULE_CONFIG MODULE_SUSPEND MODULE_CLEANUP THEME FONTS LAYOUT EVENTS SIGNALS PRESENTATION CVE MANAGED_CONFIGURE RESOURCE_PREFERENCE TYPOGRAPHY_END COMPLETE")
local applyResults=enum("NOT_RUN RUNNING COMPLETE FAILED DEFERRED BLOCKED STOPPED")
local applyCategories=enum("NONE PROFILE_APPLY_FAILED MODULE_CALL_FAILED FINALIZE_FAILED OWNERSHIP_CHANGED RECOVERY_RESET_FAILED")
local safeReasons=enum("NONE USER_REQUEST USER_BINDING USER_SETTINGS SAVED_SAFE_MODE CORE_FAULT NATIVE_ACTION_BLOCKED FOREVER_CANDIDATE_DISABLED")
local cleanupResults=enum("NOT_RUN COMPLETE PENDING BLOCKED")
local cleanupReasons=enum("NONE REQUESTED USER_REQUEST USER_BINDING USER_SETTINGS SAVED_SAFE_MODE CORE_FAULT NATIVE_ACTION_BLOCKED FOREVER_CANDIDATE_DISABLED COMBAT_LOCKDOWN FRAME_UNAVAILABLE OWNERSHIP_CHANGED STOP_UNCONFIRMED CALLBACK_FAILED CALLBACK_UNAVAILABLE NATIVE_RELEASE_PENDING PROFILE_BUSY")
local cleanupSteps=enum("NONE REQUESTED COMPLETE OWNERSHIP_CHANGED SAFE_INTENT NATIVE_RESTORE NATIVE_RETRY MANAGED_RESTORE CONTEXTUAL_NATIVE_RESTORE NAVIGATION_STYLE_RESTORE NATIVE_PRESENTATION_RESTORE RESOURCE_PREFERENCE WORLD_COMBAT_TEXT_RESTORE EVENTS POLICY EDITOR HUD_EDITOR VISUAL_PREVIEW SOURCE_LIBRARY BINDING_EDITOR ACTION_KEYS CURSOR CVE")
local modules={Core=true};for _,entry in ipairs(M.Catalog) do
    modules[entry.id]=true;cleanupSteps["ROOTS_"..entry.id]=true;cleanupSteps["SUSPEND_"..entry.id]=true
end
local faultReasons=enum("NONE RECOVERED CALL_FAILED PROFILE_APPLY_FAILED VIEWPORT_LAYOUT_FAILED EVENT_FAILED CLEANUP_FAILED EFFECT_FAILED BATCH_FAILED SECURE_DISPLAY_UNAVAILABLE PRIVATE_ANCHOR_CLEANUP_FAILED ART_RESTORE_FAILED HOVER_RESTORE_FAILED CARD_RESTORE_FAILED ANCHOR_RESTORE_FAILED")
local surfaceStates=enum("UNKNOWN VISIBLE HIDDEN AMBIENT EMPHASIZED PROTECTED_FLOOR NATIVE NATIVE_DIMMED SECURE_NATIVE UNAVAILABLE PRESERVED")
local effectStates=enum("UNCONFIRMED PLANNED SUBMITTED APPLIED_CONFIRMED DENIED")
local surfaceReasons=enum("NONE UNKNOWN NO_DECISION NO_SURFACE MODULE_POLICY USER_PIN USER_MANUAL INTERACTION_LEASE MANUAL_PVP_LENS PREPARATION_PUBLIC_REVIEW PLAYER_EMPOWER_ACTIVITY HUD_ALWAYS HUD_ACTIVITY HUD_QUIET HUD_INCOMPATIBLE_UI HUD_COMBAT_UNKNOWN HUD_ACTIVITY_UNKNOWN HUD_TARGET_UNKNOWN HUD_COMBAT_OR_TARGET DUPLICATE_OPTIONAL_PRESENTATION MODULE_STOPPED NATIVE_RESTORE NATIVE_ACCESS_FLOOR SECURE_DRIVER_OWNS_VISIBILITY NATIVE_OWNS_PRESENTATION NATIVE_COMBAT_FLOOR NATIVE_OPACITY_ONLY OTHER_UI_OWNER PROTECTED_OR_FORBIDDEN NATIVE_CHILD_PROTECTED STALE_EFFECT NO_ELIGIBLE_RULE UNRESOLVED_TIE")
-- Source catalogue rule IDs are authored constants. Custom rule IDs/free text
-- are deliberately not added to the export allowlist.
for id in pairs(M.Authority.rules) do surfaceReasons[id]=true end
local function applyLine(row)
    row=row or {}
    return table.concat({count(row.id),count(row.parent),token(row.trigger,applyTriggers),token(row.phase,applyPhases),
        token(row.module,modules),token(row.result,applyResults,"NOT_RUN"),token(row.category,applyCategories,"NONE")},"/")
end
local function appendRuntime(lines,activation)
    local runtime=activation.runtime;local cleanup=runtime.cleanup or {}
    lines[#lines+1]="runtime_schema=1"
    lines[#lines+1]="activation_state="..activation.code
    lines[#lines+1]="selected_module_failures="..count(activation.failedModules)
    lines[#lines+1]="selected_provider_failures="..count(activation.failedProviders)
    lines[#lines+1]="selected_provider_partial="..count(activation.partialProviders)
    lines[#lines+1]="selected_provider_waiting_or_empty="..count(activation.waitingProviders)
    lines[#lines+1]="selected_provider_handoff="..count(activation.handoffProviders)
    lines[#lines+1]="selected_provider_started="..count(activation.activeProviders)
    lines[#lines+1]="whole_profile_apply_count="..count(M.stats.profileApplies)
    lines[#lines+1]="activation_scope=PROFILE_RUNTIME_NOT_ALL_LIVE_DISPLAY_CONFIRMATION"
    lines[#lines+1]="safe_reason="..token(runtime.safeReason,safeReasons)
    lines[#lines+1]="safe_reason_scope="..token(runtime.safeReasonScope,{NONE=true,CURRENT_SESSION=true,PERSISTED_RECORD=true})
    lines[#lines+1]="historical_native_stop_resume="..token(runtime.historicalNativeResume,{NONE=true,PENDING=true,WAITING_COMBAT=true,RESUMED=true,CANCELLED=true,WRITE_BLOCKED=true})
    lines[#lines+1]="historical_patched_stop_resume="..token(runtime.historicalPatchedResume,{NONE=true,PENDING=true,WAITING_COMBAT=true,RESUMED=true,CANCELLED=true,WRITE_BLOCKED=true})
    lines[#lines+1]="historical_stop_patch="..token(runtime.historicalPatch,{NONE=true,P19_KEY_LABEL_FONT_ORDER=true})
    lines[#lines+1]="apply_fields=ID/PARENT/TRIGGER/PHASE/MODULE/RESULT/CATEGORY"
    lines[#lines+1]="apply_current="..applyLine(runtime.apply)
    lines[#lines+1]="apply_last_success_id="..count(runtime.lastSuccessfulApply)
    lines[#lines+1]="apply_first_failure="..(runtime.firstFailure and applyLine(runtime.firstFailure) or "NONE")
    lines[#lines+1]="apply_latest_failure="..(runtime.lastFailure and applyLine(runtime.lastFailure) or "NONE")
    for i,row in ipairs(runtime.history or {}) do
        if i>8 then break end
        lines[#lines+1]="apply_history_"..i.."="..applyLine(row)
    end
    for _,key in ipairs({"id","requested","completed","pending","blocked","attempts"}) do lines[#lines+1]="cleanup_"..key.."="..count(cleanup[key]) end
    lines[#lines+1]="cleanup_status="..token(cleanup.status,cleanupResults,"NOT_RUN")
    lines[#lines+1]="cleanup_reason="..token(cleanup.reason,cleanupReasons,"NONE")
    lines[#lines+1]="cleanup_phase="..token(cleanup.phase,cleanupSteps,"NONE")
    for i,row in ipairs(cleanup.steps or {}) do
        if i>96 then break end
        local id=token(row.id,cleanupSteps)
        if id~="UNKNOWN" then lines[#lines+1]="cleanup_step_"..id.."="..token(row.status,cleanupResults).."/"..token(row.reason,cleanupReasons).."/"..count(row.attempts) end
    end
    if M.EventSubscriptionSnapshot then
        local events=M:EventSubscriptionSnapshot()
        lines[#lines+1]="event_subscriptions="..events.status
        lines[#lines+1]="event_subscription_counts="..count(events.registered).."/"..count(events.rejected).."/"..count(events.failed)
        lines[#lines+1]="event_subscription_fields=REGISTERED/UNSUPPORTED_OR_REJECTED/FAILED"
        lines[#lines+1]="event_subscription_phase="..events.phase.."/"..events.event
        if events.lastFailure then
            local last=events.lastFailure
            lines[#lines+1]="event_subscription_last_failure="..last.operation.."/"..last.event.."/"..last.reason
        end
        for i,row in ipairs(events.rows) do
            lines[#lines+1]="event_subscription_issue_"..i.."="..row.event.."/"..row.reason
        end
        lines[#lines+1]="event_subscription_issues_omitted="..count(math.max(0,events.total-#events.rows))
    end
end
local function appendPackage(lines)
    if not M.BuildInfo then lines[#lines+1]="package_status=UNAVAILABLE";return end
    local package=M.BuildInfo:Inspect()
    lines[#lines+1]="package_build="..package.id
    lines[#lines+1]="package_status="..package.status
    lines[#lines+1]="package_target="..package.target
    lines[#lines+1]="cursor_source_version="..package.cursorSource
    lines[#lines+1]="package_identity_scope=RELEASE_LABEL_NOT_INSTALLED_BYTE_ATTESTATION"
    for _,component in ipairs(package.components) do
        lines[#lines+1]="package_component_"..component.name.."="..component.version.."/"..component.build.."/"..component.status
    end
    if M.BuildInfo.Report then lines[#lines+1]=M.BuildInfo:Report() end
    lines[#lines+1]="settings_entry_routes=SHARED_SETUP_CURSOR_AND_SUITE_SHELL"
end
function M.Diagnostics:Why(id)
    local ids={};for sid,s in pairs(M.surfaces) do
        if not id or s.module:lower()==id:lower() or sid:lower()==id:lower() then ids[#ids+1]=sid end
    end
    table.sort(ids)
    local lines={}
    for _,sid in ipairs(ids) do
        local s=M.surfaces[sid]
        lines[#lines+1]=sid.."\n"..M.VisibilityTrace:Explain(s)
        lines[#lines+1]="Requested: "..(s.desired or "UNKNOWN").." | Actual: "..(s.actual or "UNKNOWN").." | Effect: "..(s.effectStatus or "UNCONFIRMED")
        lines[#lines+1]="Reason: "..(s.appliedReason or s.reason or "NO_DECISION").." | Rule path: "..(s.policyV13 and "V1.3 ADMISSION" or "ENGINEERING CANDIDATE")
        if s.nativeBoundary=="NATIVE_COMBAT_ACCESS_FLOOR" or s.occlusionReason=="NATIVE_COMBAT_ACCESS_FLOOR" then
            lines[#lines+1]="Native boundary: protected combat controls retain their predeclared access."
        end
        if id then for _,row in ipairs(M.VisibilityTrace:History(sid)) do
            lines[#lines+1]="  #"..row.sequence.." "..row.requested.." -> "..row.actual.." / "..row.effect.." / "..row.reason
        end end
        lines[#lines+1]=""
    end
    return #ids>0 and table.concat(lines,"\n") or "No registered surfaces for that module. Enable it or review its compatibility status."
end
-- Utilities own their displays independently of MirageUI's native-by-design
-- providers. Include bounded codes/counts so one support export shows both.
function M.Diagnostics:UtilityReport()
    local api=_G.MirageIntelCoreAPI
    if not M.Safety:Readable(api) or type(api)~="table" or type(api.GetUtilitySupport)~="function" then
        return "utility_suite=NOT_LOADED"
    end
    local ok,summary=pcall(api.GetUtilitySupport)
    if not ok or not M.Safety:Readable(summary) or type(summary)~="table" then return "utility_suite=UNAVAILABLE" end
    local function scalar(value)
        if not M.Safety:Readable(value) then return nil end
        if type(value)=="boolean" then return value and "true" or "false" end
        if M.Safety:Number(value) and math.abs(value)<=1e12 then return tostring(value) end
        if M.Safety:Text(value) and #value<=80 and value:match("^[%w_%.%-]+$") then return value end
    end
    local fields={"status","version","initialized","clientAllowed","errors","lastError",
        "mode","registered","tooltipPolicy","hookStrategy","hookFailures","activeContexts","captures","captureAttempts","prepared","surfacePasses","lastCaptureReason","lastRenderReason","lastPresentationReason",
        "scanCount","scanPending","recipeCount","professionCount","automatic",
        "navigationRevision","destinationPresent","destinationKind","kind","selectionTier","renderer","routeStopCount","guidanceStatus","guidanceSamples",
        "running","managed","source","reason","revision","guidance",
        "mapPins","gatherPins","placeCatalog","placeMapID","catalogPlaces","nativeMarkersStyled","routeSegments","zoneCard","iconSize","nativeIconSize","pins","route","shape","radius","historyStatus",
        "historyQueries","paintPasses","idlePaints","publication","published","frameReady",
        "queued","active","capacity","continued","queueFull","ownerLimit","peakQueued","failed"}
    local lines={"utility_suite="..(scalar(summary.release) or "UNKNOWN")}
    for _,name in ipairs({"core","tasks","minimap","map","gather","insight","navigation","cursor"}) do
        local row=M.Safety:Field(summary,name)
        if type(row)=="table" then
            for _,key in ipairs(fields) do
                local value=scalar(M.Safety:Field(row,key))
                if value then lines[#lines+1]="utility_"..name.."_"..key.."="..value end
            end
        end
    end
    return table.concat(lines,"\n")
end
function M.Diagnostics:Export()
    local sourceCommit,sourceMatched=sourceIdentity()
    local activation=self:ActivationState()
    local lines={"MIRAGEDIAG=1","addon="..M.version,"client="..M.Client.family,"patch="..M.Client.patch,
        "build="..M.Client.build,"interface="..M.Client.interface,"compatibility="..M.Client.reason,
        "adapter_source_commit="..sourceCommit,"client_source_matched="..tostring(sourceMatched),
        "compatibility_runtime_policy=CAPABILITY_GUARDED; build_allowlist=DIAGNOSTIC_ONLY; optional_failure=FEATURE_LOCAL",
        "compatibility_review="..(sourceMatched and "REVIEWED_SOURCE" or "UNREVIEWED_CLIENT"),
        "native_midnight=NOT_RUN","native_forever=NOT_RUN","native_qualification_scope=FORMAL_RELEASE_ACCEPTANCE_NOT_SESSION_ACTIVITY","rule_execution=CANDIDATE_NOT_APPROVED",
        "registry_version="..M.Authority.version,"source_rules="..M.Authority.count,"source_signals="..#M.Authority.signals,"source_scenarios="..M.Authority.scenarios,"factory_candidate_definitions="..#M.RuleBindings,
        "source_bindings_native_approved=0","review_ready_binding_candidates=12","source_catalogue="..M.Authority.digest,"cve_native_status=NOT_RUN",
        "safe_mode="..tostring(M.state.safe),"world="..tostring(M.state.world),"profile_read_only="..tostring(M.Profiles.readOnly),
        "batches="..M.stats.batches,"predicate_evaluations="..M.stats.evaluations,"predicate_cache_hits="..(M.stats.predicateCacheHits or 0),"predicate_ast_evaluations="..(M.stats.predicateEvaluations or 0),"effects="..M.stats.effects,
        "denied="..M.stats.denied,"faults="..M.stats.faults,"privacy=NO_NAMES_GUIDS_CHAT_IDENTITIES_OR_RAW_NATIVE_ERRORS"}
    appendPackage(lines);appendRuntime(lines,activation)
    local utilityOK,utilityReport=pcall(self.UtilityReport,self)
    lines[#lines+1]=utilityOK and utilityReport or "utility_suite=UNAVAILABLE"
    -- A shared viewport can defer several otherwise healthy providers. Keep
    -- its recorded measurements near the front of the support export; this
    -- read-only report must not sample or publish layout while exporting.
    if M.Managed and type(M.Managed.ViewportReport)=="function" then
        local ok,report=pcall(M.Managed.ViewportReport,M.Managed)
        lines[#lines+1]=ok and M.Safety:Text(report) and report or "viewport=VIEWPORT_DIAGNOSTIC_UNAVAILABLE"
    else lines[#lines+1]="viewport=VIEWPORT_OBSERVER_UNAVAILABLE" end
    local contract=M.B35Contract or {}
    lines[#lines+1]="b35_contract="..count(contract.revision).."; context_catalogue_entries="..count(contract.contextCatalogueEntries).."; native_qualification=NOT_RUN"
    lines[#lines+1]="b35_profile_revision="..count(M.profile and M.profile.b35Revision)
    if M.DisplayOcclusion then lines[#lines+1]=M.DisplayOcclusion:Report() end
    local objectives=M.Rework and M.Rework.Objectives
    lines[#lines+1]="objective_native_access="..(objectives and objectives.visibilityBoundary=="NATIVE_COMBAT_ACCESS_FLOOR" and "NATIVE_COMBAT_ACCESS_FLOOR" or "PREDECLARED_COMBAT_INPUT_RETAINED")
    lines[#lines+1]="settings_workspace=UNIFIED_PROFILES_MODULES_CUSTOMIZE_HELP"
    lines[#lines+1]="editor_panels=CONTEXT_TOP_ADVANCED_LEFT_SEARCH_RIGHT"
    lines[#lines+1]="editor_draft="..(M.WorkspaceModel and M.WorkspaceModel.dirty and "UNAPPLIED" or "CLEAN")
    lines[#lines+1]="editor_context_scope=PREVIEW_NOT_NATIVE_COMBAT_SHARED_GEOMETRY"
    local elementCount=0
    if M.Elements then
        local observed,list=pcall(M.Elements.List,M.Elements)
        elementCount=observed and type(list)=="table" and #list or "UNKNOWN"
    end
    lines[#lines+1]="element_registry_count="..elementCount
    local notify=M.modules.Notifications
    lines[#lines+1]="notifications_scope=LOCALIZED_SELF_RECEIPTS_AND_CONFIRMED_PROFESSIONS"
    lines[#lines+1]="notifications_delivered="..count(notify and notify.delivered)
    lines[#lines+1]="notifications_dropped="..count(notify and notify.dropped)
    lines[#lines+1]="combat_text_scope=NATIVE_SCROLLING_FONT_NOT_ALL_WORLD_NUMBERS"
    lines[#lines+1]="combat_text_style="..token(notify and notify.combatTextStatus,enum("NATIVE_SCROLLING_FONT_STYLED WAITING_FOR_NATIVE_SCROLLING_TEXT RESTORED"),"NOT_RUN")
    local world=M.WorldCombatText
    lines[#lines+1]="world_text_scope=NATIVE_GLOBAL_START_HEIGHT_NOT_PER_PLATE"
    lines[#lines+1]="world_text_height="..token(world and world.status,enum("NOT_RUN NATIVE_WORLD_TEXT_HEIGHT_RAISED EXISTING_HIGHER_HEIGHT_PRESERVED NATIVE_WORLD_TEXT_MODE_UNAVAILABLE CVAR_API_UNAVAILABLE NATIVE_HEIGHT_UNAVAILABLE RECOVERY_RECEIPT_UNAVAILABLE APPLY_DEFERRED_COMBAT RESTORE_DEFERRED_COMBAT RESTORE_AUTHORITY_UNAVAILABLE RESTORE_PENDING WRITE_NOT_CONFIRMED FOREIGN_VALUE_PRESERVED RESTORED"),"NOT_RUN")
    lines[#lines+1]="world_text_requested_minimum=0.06/0.075"
    lines[#lines+1]="world_text_native_visual=NOT_RUN"
    -- Keep the three current failure boundaries separate from the capped
    -- nameplate coverage paragraph. These reports use cached authored state;
    -- exporting never enumerates native aura children or reads hit amounts.
    for _,entry in ipairs({
        {world,"PlateReport","world_plate_evidence"},
        {M.Rework and M.Rework.Nameplates,"AuraEvidenceReport","nameplate_aura_evidence"},
        {M.Rework and M.Rework.Nameplates,"EvidenceReport","nameplate_selection_evidence"},
    }) do
        local owner,method,key=entry[1],entry[2],entry[3]
        if owner and type(owner[method])=="function" then
            local okay,report=pcall(owner[method],owner)
            lines[#lines+1]=key.."="..(okay and M.Safety:Text(report) and #report<=2048 and report or "EVIDENCE_UNAVAILABLE")
        end
    end
    appendFieldEvidence(lines,"nameplate_input",M.Rework and M.Rework.Nameplates,"InputReport")
    appendFieldEvidence(lines,"nameplate_presentation",M.Rework and M.Rework.Nameplates,"PresentationReport")
    appendFieldEvidence(lines,"nameplate_aura_dependency",M.Rework and M.Rework.Nameplates,"AuraDependencyReport")
    lines[#lines+1]="native_action_reflow="..token(M.NativeActionLayout and M.NativeActionLayout.status,enum("NOT_INSTALLED NATIVE_REFLOW_OBSERVED NATIVE_REFLOW_RECONCILED NATIVE_REFLOW_DEFERRED NATIVE_WRITER_CHANGED NATIVE_WRITER_UNAVAILABLE NATIVE_OUTPUT_UNAVAILABLE"),"NOT_RUN")
    local presentation=M.NativePresentation and M.NativePresentation.status
    local artStates=enum("MIRAGE_ART_NATIVE_CONTROLS MIRAGE_ART_PARTIAL NATIVE_CONTENT_PRESERVED NATIVE_PRESENTATION_RELEASED NATIVE_PRESENTATION_RELEASE_PENDING NATIVE_PRESENTATION_RELOAD_REQUIRED")
    lines[#lines+1]="native_presentation_scope=OWN_ART_AND_DECORATION_READBACK_NATIVE_FUNCTIONAL_CONTROLS_RETAINED"
    lines[#lines+1]="native_presentation_fields=CONTROLS_COMPLETED/CONTROLS_EXPECTED/ART_COMPLETED/ART_EXPECTED/LAST_ATTEMPT_COMPLETE"
    for _,name in ipairs({"MainActionBar","MultiBarBottomLeft","MultiBarBottomRight","MultiBarRight","MultiBarLeft","MultiBar5","MultiBar6","MultiBar7","PetActionBar","StanceBar","BagsBar","MicroMenuContainer","MainStatusTrackingBarContainer","SecondaryStatusTrackingBarContainer","PlayerCastingBarFrame"}) do
        lines[#lines+1]="native_presentation_"..name.."="..token(presentation and presentation[name],artStates,"NOT_RUN")
        local detail=M.NativePresentation and M.NativePresentation.details and M.NativePresentation.details[name]
        if detail then lines[#lines+1]="native_presentation_counts_"..name.."="..table.concat({count(detail.controlsCompleted),count(detail.controlsExpected),count(detail.artCompleted),count(detail.artExpected),tostring(detail.complete==true)},"/") end
    end
    local panelStates=enum("MIRAGE_PANEL_NATIVE_CONTENT NATIVE_CONTENT_PRESERVED NATIVE_PANEL_UNAVAILABLE NATIVE_PANEL_RELEASED NATIVE_PANEL_RELEASE_PENDING")
    for _,id in ipairs({"Chat","Tooltips","QuestTracker","BlizzardSkin","Bags"}) do
        local mod=M.modules[id]
        for _,name in ipairs(mod and mod.names or {}) do
            local surface=mod.surfaces and mod.surfaces[name]
            if surface then lines[#lines+1]="native_panel_"..name.."="..token(M.Native and M.Native.SkinState and M.Native:SkinState(surface.frame),panelStates,"NATIVE_CONTENT_PRESERVED") end
        end
    end
    lines[#lines+1]="aura_dissipation=DEFERRED_NATIVE_EXPIRY_AND_PERFORMANCE_EVIDENCE"
    lines[#lines+1]="effects_scope=ORDINARY_EFFECT_DISPATCH_COUNT_NOT_ALL_NATIVE_WRITES"
    lines[#lines+1]="denied_scope=ORDINARY_COSMETIC_FRAME_GUARD_REFUSALS_NOT_NATIVE_ERRORS"
    lines[#lines+1]="faults_scope=SESSION_CUMULATIVE"
    lines[#lines+1]="fault_owner_scope=CORE_CUMULATIVE_MODULES_RESET_ON_RECOVERY_WITH_LATEST_CATEGORY"
    local worksheet=M.NativeEvidence
    lines[#lines+1]="user_test_worksheet="..token(worksheet and worksheet.state,enum("NOT_STARTED USER_REPORTED_SESSION STALE_VERSION_CLIENT_OR_SETTINGS"),"NOT_STARTED")
    lines[#lines+1]="user_test_scope=EXPLICIT_WORKSHEET_ONLY_NOT_ALL_OBSERVED_TESTING"
    for _,entry in ipairs(M.Catalog) do
        local mod=M.modules[entry.id]
        local status=mod and mod.status or entry.id=="Forever" and "NATIVE_VALIDATION_PENDING" or "ENGINEERING_IMPLEMENTED"
        lines[#lines+1]="module_"..entry.id.."="..status
        lines[#lines+1]="module_activity_"..entry.id.."="..(M:IsModuleActive(entry.id) and "ACTIVE" or mod and mod.pendingDisable and "CLEANUP_PENDING" or "INACTIVE")
    end
    if M.UnderCharacterHUD then lines[#lines+1]=M.UnderCharacterHUD:Report() end
    if M.UnitTypography then lines[#lines+1]=M.UnitTypography:Report() end
    if M.Experience then lines[#lines+1]=M.Experience:Report() end
    if M.ContextualNative then lines[#lines+1]=M.ContextualNative:Report() end
    if M.PresentationGroups and M.PresentationGroups.Report then lines[#lines+1]=M.PresentationGroups:Report() end
    if M.StartupPresentation and M.StartupPresentation.Report then lines[#lines+1]=M.StartupPresentation:Report() end
    lines[#lines+1]="initial_activity_policy=PUBLIC_UNCHANGED_XP_ZONE_FILTER_ONLY; blanket_cue_reset=NONE; unchanged_notices="..(M.Signals and M.Signals.hydrationSuppressed or 0)
    if M.AdaptiveFading then lines[#lines+1]=M.AdaptiveFading:Report() end
    if M.NavigationPin then lines[#lines+1]=M.NavigationPin:Report() end
    if M.ManagedNative and M.ManagedNative.OwnershipReport then lines[#lines+1]=M.ManagedNative:OwnershipReport() end
    if M.NavigationStyle then lines[#lines+1]=M.NavigationStyle:Report() end
    lines[#lines+1]="independent_nameplates="..(M.NameplateCards and M.NameplateCards.status or "NOT_RUN")
    lines[#lines+1]="independent_nameplates_role=LEGACY_SUBSYSTEM_COUNTERS_NOT_ACTIVE_REWORK_HEALTH"
    local cvar=C_CVar and C_CVar.GetCVar or GetCVar
    for _,key in ipairs({"nameplateShowEnemies","nameplateShowFriends","nameplateShowAll"}) do
        local value,known=M.Safety:Public(cvar,"string",key)
        lines[#lines+1]="native_nameplate_"..key.."="..(known=="KNOWN" and (value=="0" or value=="1") and value or "UNAVAILABLE")
    end
    lines[#lines+1]="nameplate_visibility_scope=GAME_CVARS_OBSERVED_NOT_CHANGED"
    if M.NameplateCards and M.NameplateCards.Report then lines[#lines+1]="nameplate_cards="..M.NameplateCards:Report() end
    lines[#lines+1]="native_aura_rails="..(M.ManagedAuraRails and M.ManagedAuraRails.status or "NOT_RUN")
    lines[#lines+1]="notification_reputation_route="..token(M.modules.Notifications and M.modules.Notifications.reputationRoute,enum("CUSTOM_PUBLIC_RECEIPT NATIVE_REPUTATION_FALLBACK"),"NOT_RUN")
    lines[#lines+1]="policy_context_epoch="..M.Policy.contextEpoch
    lines[#lines+1]="policy_ruleset_epoch="..M.Policy.rulesetEpoch
    lines[#lines+1]="tactical_shortcut_editor="..(M.TacticalKeys and M.TacticalKeys.status or "NOT_RUN")
    lines[#lines+1]="prediction_models=NONE_QUALIFIED_NONE_ENABLED"
    lines[#lines+1]="action_shortcut_editor="..(M.ActionKeys and M.ActionKeys.status or "NOT_RUN")
    lines[#lines+1]="action_rearrangement="..(M.ActionEditing and M.ActionEditing.status or "NOT_RUN")
    lines[#lines+1]="native_click_cast_setup="..(M.ClickCasting and M.ClickCasting.status or "NOT_RUN")
    -- Binding commands, keys and undo records are deliberately excluded.
    local cooldown=M.modules.Cooldowns;local auras=M.modules.Auras;local bars=M.modules.ResourceBars
    lines[#lines+1]="cooldown_tracker="..(cooldown and cooldown.trackerStatus or "NOT_RUN")
    lines[#lines+1]="aura_panel="..(auras and auras.panelStatus or "NOT_RUN")
    lines[#lines+1]="class_resource="..(bars and bars.secondaryStatus or "NOT_RUN")
    local quests=M.modules.QuestTracker
    lines[#lines+1]="compact_objectives="..(quests and quests.providerStatus or "NOT_RUN")
    lines[#lines+1]="compact_objective_rows="..tostring(quests and quests.displayed or 0)
    local inventory=self and M.modules.Bags
    local meter=M.modules.DamageMeters
    local customMeter=M.Rework and M.Rework.MirageMeters
    local customMeterSelected=meter and type(meter.UsesMirageMeters)=="function" and meter:UsesMirageMeters()
    lines[#lines+1]="inventory_browser="..(inventory and inventory.browserState or "NOT_RUN")
    lines[#lines+1]="native_meter_summary="..(customMeterSelected and "DELEGATED_TO_MIRAGE_METERS" or meter and meter.summaryState or "NOT_RUN")
    lines[#lines+1]="native_meter_visibility="..(customMeterSelected and "MIRAGE_CUSTOM_CONTEXT_NATIVE_CVAR_HANDOFF" or meter and meter.visibilityStatus or "NOT_RUN")
    lines[#lines+1]="mirage_meter_visibility="..(customMeterSelected and customMeter and customMeter.surface and customMeter.surface.desired or "NOT_RUNNING")
    lines[#lines+1]="mirage_meter_read_interval="..(customMeterSelected and customMeter and tostring(customMeter.runtimeInterval or .20) or "NOT_RUNNING")
    lines[#lines+1]="cursor_mode=STANDALONE_OPTIONAL"
    lines[#lines+1]="cursor_addon="..(M.Safety:Loaded("CursorCompanion") and "LOADED" or "NOT_LOADED")
    lines[#lines+1]="preparation="..(auras and auras.preparationState or "NOT_RUN")
    lines[#lines+1]="private_aura_registration="..(M.PrivateAuras and M.PrivateAuras.status or "NOT_RUN")
    lines[#lines+1]="totem_display="..(bars and bars.totemState or "NOT_RUN")
    lines[#lines+1]="rune_display="..(bars and bars.runeState or "NOT_RUN")
    lines[#lines+1]="quiet_native="..(M.NativeQuiet and M.NativeQuiet.status or "NOT_RUN")
    lines[#lines+1]="performance_capture="..(M.Profiler and M.Profiler.status or "NOT_RUN")
    if M.Incidents then lines[#lines+1]=M.Incidents:Export() end
    if M.SurfaceContracts then lines[#lines+1]=M.SurfaceContracts:Report() end
    if M.VisibilityTrace and M.VisibilityTrace.Export then lines[#lines+1]=M.VisibilityTrace:Export() end
    if M.RuntimeScheduler then
        local data=M.RuntimeScheduler:Snapshot();local keys={};for key in pairs(data) do keys[#keys+1]=key end;table.sort(keys)
        for _,key in ipairs(keys) do lines[#lines+1]="scheduler_"..key.."="..tostring(data[key]) end
    end
    lines[#lines+1]="native_menu_route="..(M.ClientUI and M.ClientUI.status or "NOT_RUN")
    lines[#lines+1]="spellbook_lookup="..(M.SpellBook and M.SpellBook.lastState or "NOT_RUN")
    lines[#lines+1]="explicit_forever_candidate="..tostring(M.Client.experimental==true)
    for _,id in ipairs({"Minimap","Chat","QuestTracker"}) do
        local row=M.NativeLayout and M.NativeLayout.rows[id]
        lines[#lines+1]="native_position_"..id.."="..(row and row.status or "NOT_RUN")
    end
    -- Counts and reason codes only. Quest titles, IDs, progress text and unit metadata stay out.
    local ids={};for id in pairs(M.surfaces) do ids[#ids+1]=id end;table.sort(ids)
    lines[#lines+1]="surface_fields=DESIRED/LAST_ACTUAL/DECISION_REASON/EFFECT_STATUS"
    lines[#lines+1]="surface_actual_scope=LAST_LOCAL_EFFECT_OBSERVATION_NOT_CURRENT_NATIVE_PAINT"
    for _,id in ipairs(ids) do
        local s=M.surfaces[id]
        lines[#lines+1]="surface_"..id.."="..token(s.desired,surfaceStates).."/"..token(s.actual,surfaceStates).."/"..token(s.reason,surfaceReasons,"NONE").."/"..token(s.effectStatus,effectStates,"UNCONFIRMED")
        lines[#lines+1]="surface_applied_reason_"..id.."="..token(s.appliedReason,surfaceReasons,"NONE")
        lines[#lines+1]="surface_confirmed_"..id.."="..tostring(s.confirmed==true)
    end
    for id in pairs(modules) do
        local row=M.faults[id]
        if row then lines[#lines+1]="fault_"..id.."="..token(row.reason,faultReasons)..":"..count(row.count) end
    end
    if #M.samples>0 then
        local list={};for _,v in ipairs(M.samples) do list[#list+1]=v end;table.sort(list)
        lines[#lines+1]="measured_batch_p50_ms="..string.format("%.4f",list[math.max(1,math.ceil(#list*.5))])
        lines[#lines+1]="measured_batch_p95_ms="..string.format("%.4f",list[math.max(1,math.ceil(#list*.95))])
        lines[#lines+1]="measurement=BATCH_ONLY_NOT_TOTAL_ADDON_COST"
    end
    return table.concat(lines,"\n")
end
-- Build fields below were admitted by Client:Detect; never inspect gameplay values.
-- "Qualified" is the source pin only, not a native acceptance claim.
function M.Diagnostics:BuildSummary()
    local c,a=M.Client,M.adapter
    local sourceCommit,sourceMatched=sourceIdentity()
    return "Detected: patch "..c.patch.." / build "..c.build.." / interface "..c.interface..
        "\nSource-qualified: patch "..a.patch.." / build "..a.build.." / interface "..a.interface..
        "\nAdapter source: "..sourceCommit.." / client source matched: "..tostring(sourceMatched)..
        "\nGate: "..c.reason..". Formal native qualification: NOT_RUN."
end
function M.Diagnostics:ActivationMessage()
    return self:ActivationState().message
end
-- A compact, read-only startup check for the player. It describes actual
-- provider state without treating creation of a frame as visual acceptance.
function M.Diagnostics:Check()
    local activation=self:ActivationState()
    local package=M.BuildInfo and M.BuildInfo:Inspect()
    local c,r=M.Client,M.Rework
    local storage=r and r.storageReady and "READY" or
        "UNAVAILABLE"
    local lines={"MirageUI "..M.version.." - current session",
        "Client: "..c.family.." "..c.patch.." / build "..c.build.." / interface "..c.interface,
        "Reviewed presentation builds: Forever 1.60.1 / 70862, 70888, 70938, 70959 and 71037 / 16001",
        "Installation: "..(package and package.status or "UNAVAILABLE"),
        "Client source: "..(c.sourceMatched and "MATCHED" or "UNREVIEWED — available features continue"),
        "Compatibility: CAPABILITY_GUARDED (build number does not block activation)",
        "Activation: "..activation.code,
        "Saved runtime choice: "..(c.candidateConsent or "AUTOMATIC_CAPABILITY_MODE"),
        "Presentation storage: "..storage,
        "Release qualification: STABILIZATION_CANDIDATE; native acceptance NOT_RUN",
        "",activation.message,activation.help,"",
        "Displays (runtime state; confirm the visible result in game):"}
    local labels={main="Action bars",units="Player / pet / target / target's target / focus / boss",groups="Party / raid",minimap="Minimap",
        nameplates="Nameplates",auras="Buffs / debuffs",cooldowns="Cooldowns",meters="Meters",
        casts="Casts / resources",alerts="Notifications",chat="Chat",tooltips="Tooltips / menus",maps="Maps",
        objectives="Objectives",inventory="Inventory",tasks="Task windows",character="Character / progression",system="System windows"}
    local counts={running=0,waiting=0,attention=0,disabled=0,blocked=0,native=0}
    for _,id in ipairs(r and r.order or {}) do
        local row=r.providers[id]
        local selected,selectionObserved=observeBoolean(r.Selected,r,id)
        local choice,choiceReason=r:PrimaryChoice(id,M.profile)
        local state
        if choiceReason=="NATIVE_BY_DESIGN" and not row.pending then
            state="NATIVE BY DESIGN";counts.native=counts.native+1
        elseif choiceReason=="NATIVE_BY_DESIGN" and row.pending then
            state="RESTORE PENDING: "..(row.reason or "NATIVE_HANDOFF_PENDING");counts.attention=counts.attention+1
        elseif not choice and not selected then state="PROFILE CHOICE: "..(choiceReason or "DISABLED");counts.disabled=counts.disabled+1
        elseif not c.allowed or M.state.safe or not r.storageReady or r.rolledBack or not M.profile.enabled then state="PAUSED: "..activation.code;counts.blocked=counts.blocked+1
        elseif row.failed or row.state=="RECOVERY" or row.readiness=="FAULT" or row.readiness=="CONFLICT" then
            state="NEEDS ATTENTION: "..(row.failureReason or row.readinessReason or row.reason);counts.attention=counts.attention+1
        elseif not selectionObserved then
            state="STATUS UNAVAILABLE: SELECTION_OBSERVATION";counts.attention=counts.attention+1
        elseif not selected then
            state="UNAVAILABLE: "..(M.modules[row.module] and M.modules[row.module].status or "MODULE_UNAVAILABLE");counts.attention=counts.attention+1
        elseif r.lastError=="LIFECYCLE_FAILED" then
            state="UPDATES PAUSED: LIFECYCLE_FAILED";counts.attention=counts.attention+1
        elseif row.state=="ACTIVE" and row.started and row.readiness=="READY" and row.object and row.object.active==false then
            state="NEEDS ATTENTION: PROVIDER_STOPPED";counts.attention=counts.attention+1
        elseif intendedNativeMinimapFallback(id,row) then
            state="NATIVE FALLBACK: original mask unavailable";counts.native=counts.native+1
        elseif row.readiness=="PARTIAL" then
            state="PARTIAL: "..(row.readinessReason or row.reason);counts.attention=counts.attention+1
        elseif row.state~="ACTIVE" or not row.started then
            state="PENDING: "..(row.reason or "NOT_STARTED");counts.waiting=counts.waiting+1
        elseif row.readiness=="WAITING" or row.readiness=="EMPTY" then
            state="READY FOR CONTENT: "..(row.readinessReason or row.readiness);counts.waiting=counts.waiting+1
        elseif row.readiness=="DEFERRED_COMBAT" or row.readiness=="DEFERRED_HANDOFF" then
            state="DEFERRED: "..(row.readinessReason or row.readiness);counts.waiting=counts.waiting+1
        elseif id=="minimap" and row.readiness=="READY" and row.object and row.object.active
            and row.object.record and row.object.record.canvasCommitted then
            state="RUNNING (custom square)";counts.running=counts.running+1
        else state="RUNNING";counts.running=counts.running+1 end
        lines[#lines+1]=(labels[id] or id)..": "..state
    end
    lines[#lines+1]=""
    lines[#lines+1]="Totals: "..counts.running.." running; "..counts.waiting.." waiting/deferred; "..counts.attention.." need attention; "..counts.native.." native by design; "..counts.disabled.." profile choices; "..counts.blocked.." paused."
    local plates=r and r.Nameplates
    if plates and type(plates.InputSummary)=="function" then
        local okay,summary=pcall(plates.InputSummary,plates)
        if okay and M.Safety:Text(summary) and #summary<=2048 then lines[#lines+1]="Nameplate input: "..summary end
    end
    if plates and type(plates.PresentationReport)=="function" then
        local okay,summary=pcall(plates.PresentationReport,plates)
        if okay and M.Safety:Text(summary) and #summary<=2048 then lines[#lines+1]="Nameplate presentation: "..summary
        else lines[#lines+1]="Nameplate presentation: STATUS_UNAVAILABLE" end
    end
    local world=M.WorldCombatText
    if world and type(world.PlateSummary)=="function" then
        local okay,summary=pcall(world.PlateSummary,world)
        if okay and M.Safety:Text(summary) and #summary<=2048 then lines[#lines+1]="Plate combat text: "..summary
        else lines[#lines+1]="Plate combat text: STATUS_UNAVAILABLE" end
    end
    local drawers=M.UtilityDrawers
    if drawers and type(drawers.StateSummary)=="function" then
        local okay,summary=pcall(drawers.StateSummary,drawers)
        if okay and M.Safety:Text(summary) and #summary<=2048 then lines[#lines+1]="Utility drawers: "..summary
        else lines[#lines+1]="Utility drawers: STATUS_UNAVAILABLE" end
    end
    local units=r and r.UnitFrames
    if units and type(units.CapabilitySummary)=="function" then
        local okay,summary=pcall(units.CapabilitySummary,units)
        if okay and M.Safety:Text(summary) and #summary<=2048 then lines[#lines+1]="Unit capabilities: "..summary end
    end
    if r and type(r.NativeBlockSummary)=="function" then
        local okay,summary=pcall(r.NativeBlockSummary,r)
        if okay and M.Safety:Text(summary) and #summary<=2048 then lines[#lines+1]="Native blocked actions: "..summary end
    end
    lines[#lines+1]="Installation MATCHED checks release metadata; Client source MATCHED checks the reviewed build list. Neither attests installed file bytes or native rendering."
    lines[#lines+1]="Contextual hiding, absent targets and closed game windows are normal. /mirage reveal temporarily reveals eligible displays."
    lines[#lines+1]="Native unit/group input is retained. Customize moves/resizes the pet and whole party/raid controls; internal group arrangement remains native."
    lines[#lines+1]="Custom hit text follows supported displayed units; uncovered targets and healing retain native fallback. Off-screen combat-log completeness is not claimed."
    lines[#lines+1]="Native rendering, secure input and gameplay performance require in-game checks; this report does not certify them."
    lines[#lines+1]="Commands: /mirage activate resumes saved choices; /mirage recover retries failures; /mirage export copies full support details; /mirage safe restores native access."
    return table.concat(lines,"\n")
end
function M.Diagnostics:Status()
    local activation=self:ActivationState()
    local package=M.BuildInfo and M.BuildInfo:Inspect()
    return M.version.." | "..M.Client.family.." | "..activation.code..
        "\n"..activation.message.."\n"..activation.help..
        (package and "\nPackage: "..package.id.." / "..package.status or "")..
        "\n"..self:BuildSummary().."\n/mirage check for a short display report; /mirage export for full support"
end
