local _, M = ...
-- Edits exactly one native key at a time. No override bindings, simulated clicks,
-- profile-carried shortcuts, automatic assignment, or combat-time writes.
M.ActionKeys={history={},status="IDLE",revision=0}
local K,S=M.ActionKeys,M.Safety
local prefixes={"ACTIONBUTTON","MULTIACTIONBAR1BUTTON","MULTIACTIONBAR2BUTTON","MULTIACTIONBAR3BUTTON","MULTIACTIONBAR4BUTTON","MULTIACTIONBAR5BUTTON","MULTIACTIONBAR6BUTTON","MULTIACTIONBAR7BUTTON"}
local actionLabels={}
for bar=1,8 do for slot=1,12 do
    actionLabels[prefixes[bar]..slot]=(bar==1 and "Main bar" or "Action bar "..bar).." — button "..slot
end end
local ignored={LSHIFT=true,RSHIFT=true,SHIFT=true,LCTRL=true,RCTRL=true,CTRL=true,LALT=true,RALT=true,ALT=true,LMETA=true,RMETA=true,UNKNOWN=true}
local mouse={MiddleButton="BUTTON3",Button4="BUTTON4",Button5="BUTTON5",Button6="BUTTON6",Button7="BUTTON7",Button8="BUTTON8"}
function K:Command(bar,slot)
    if not S:Number(bar) or not S:Number(slot) or bar%1~=0 or slot%1~=0 or bar<1 or bar>8 or slot<1 or slot>12 then return nil end
    return prefixes[bar]..slot
end
function K:IsAction(command)
    return S:Text(command) and actionLabels[command]~=nil
end
function K:Allowed()
    if not M.state.initialized or not M.state.world or not M.Client.allowed or M.state.safe or not M.profile or not M.profile.enabled or M.Profiles.readOnly then
        return false,"Open shortcut editing in an active, supported MirageUI session."
    end
    if S:InCombat() then return false,"Change shortcuts after combat." end
    if M.state.cinematic then return false,"Close the cinematic before editing shortcuts." end
    if M.Native:Conflict() or not M:IsModuleActive("ActionBars") then return false,"Apply and enable the MirageUI action bars first, without another action-bar owner." end
    for _,fn in ipairs({"GetCurrentBindingSet","GetBindingAction","GetBindingKey","SetBinding","SaveBindings"}) do
        if type(_G[fn])~="function" then return false,"The native shortcut editor is unavailable on this client." end
    end
    return true
end
function K:Context(command)
    if not self:IsAction(command) then return nil,false end
    if C_KeyBindings then
        local fn=C_KeyBindings.GetBindingContextForAction
        if type(fn)~="function" then return nil,false end
        -- The native API explicitly permits nil for the default context. A
        -- successfully observed absence is distinct from a failed/secret read.
        local ok,context=pcall(fn,command)
        if not ok or not S:Readable(context) then return nil,false end
        if context~=nil and (not S:Number(context) or context<0 or context%1~=0) then return nil,false end
        return context,true
    end
    return nil,true -- older native interface; never use a binding-set number as a context
end
function K:BindingSet()
    local set,status=S:Public(GetCurrentBindingSet,"number")
    if status=="KNOWN" and (set==1 or set==2) then return set end
end
function K:Owner(key,context,overrides)
    local owner,status=S:Public(GetBindingAction,"string",key,overrides==true,context)
    if status~="KNOWN" or #owner>512 then return nil end
    return owner
end
function K:KeyValid(key)
    if not S:Text(key) or #key<1 or #key>80 or key:find("[%c| ]") then return false end
    local rest=key
    for _,prefix in ipairs({"ALT-","CTRL-","SHIFT-"}) do if rest:sub(1,#prefix)==prefix then rest=rest:sub(#prefix+1) end end
    if rest=="ESCAPE" or rest=="BUTTON1" or rest=="BUTTON2" or ignored[rest] or rest=="" then return false end
    return rest:match("^[A-Z0-9]+$")~=nil or (#rest==1 and rest:match("^[%p]$")~=nil and rest~="|")
end
function K:Capture(input)
    if not S:Text(input) then return nil end
    if input=="ESCAPE" then return nil,"CANCEL" end
    if ignored[input] or input=="LeftButton" or input=="RightButton" then return nil end
    local base=mouse[input] or input
    if base:match("^Button%d+$") then base="BUTTON"..base:match("%d+$") end
    if type(GetConvertedKeyOrButton)=="function" then
        local value,status=S:Public(GetConvertedKeyOrButton,"string",base)
        if status~="KNOWN" then return nil end;base=value
    end
    if ignored[base] then return nil end
    local key=""
    for _,row in ipairs({{"IsAltKeyDown","ALT-"},{"IsControlKeyDown","CTRL-"},{"IsShiftKeyDown","SHIFT-"}}) do
        local held,status=S:Public(_G[row[1]],"boolean")
        if status~="KNOWN" then return nil end
        if held then key=key..row[2] end
    end
    key=key..base
    if self:KeyValid(key) then return key end
end
function K:Keys(command)
    local context,valid=self:Context(command)
    if not valid or type(GetBindingKey)~="function" then return nil,"Shortcut context unavailable." end
    local values={pcall(GetBindingKey,command,nil,context)}
    if not values[1] then return nil,"Assigned shortcuts are unavailable." end
    local result={}
    for i=2,math.min(#values,33) do
        if not S:Text(values[i]) or not self:KeyValid(values[i]) then return nil,"An assigned shortcut cannot be edited here. Use the game's settings." end
        result[#result+1]=values[i]
    end
    return result
end
function K:Label(value)
    if value==nil or value=="" then return "Unassigned" end
    local names={BUTTON3="Middle mouse",BUTTON4="Mouse button 4",BUTTON5="Mouse button 5",MOUSEWHEELUP="Wheel up",MOUSEWHEELDOWN="Wheel down"}
    return names[value] or value:gsub("ALT%-","Alt-"):gsub("CTRL%-","Ctrl-"):gsub("SHIFT%-","Shift-")
end
function K:ActionLabel(command)
    if command=="" then return "Unassigned" end
    if actionLabels[command] then return actionLabels[command] end
    -- Native command labels are displayed locally only, never included in support exports.
    local label=_G["BINDING_NAME_"..command]
    return S:Text(label) and label or "Another game or add-on command"
end
function K:Cancel()
    if self.plan then self.status="REVIEW_CANCELLED" end
    self.plan=nil;self.revision=self.revision+1
end
function K:Prepare(command,key,remove)
    self:Cancel()
    local revision=self.revision
    local function replaced() return self.revision~=revision end
    local stale="The shortcut review changed. Review the current shortcut again."
    local allowed,why=self:Allowed();if replaced() then return false,stale end
    if not allowed then return false,why end
    if not self:IsAction(command) or not self:KeyValid(key) then return false,"Choose an action button and a valid keyboard or mouse shortcut." end
    local context,valid=self:Context(command);if replaced() then return false,stale end
    local set=self:BindingSet();if replaced() then return false,stale end
    if not valid or not set then return false,"The native shortcut context or binding set is unavailable." end
    local old=self:Owner(key,context,false);if replaced() then return false,stale end
    local effective=self:Owner(key,context,true);if replaced() then return false,stale end
    if old==nil or effective==nil then return false,"This shortcut could not be inspected safely." end
    if effective~=old then return false,"A temporary override controls that shortcut. Leave that mode before editing it." end
    if remove and old~=command then return false,"That key is no longer assigned to this action. Refresh the list." end
    local intended=remove and "" or command
    if old==intended then return false,"That shortcut is already assigned to this action." end
    self.plan={key=key,command=command,before=old,after=intended,context=context,bindingSet=set,revision=self.revision}
    self.status="REVIEW_REQUIRED"
    return true,remove and "Remove this key from the selected action?" or old~="" and "This key already has an assignment. Replacing it requires confirmation." or "Save this additional shortcut? Existing keys for the action are preserved."
end
function K:StillValid(plan)
    local allowed,why=self:Allowed();if not allowed then return false,why end
    local context,valid=self:Context(plan.command)
    if not valid or context~=plan.context or self:BindingSet()~=plan.bindingSet then return false,"The binding context changed. Review the shortcut again." end
    if self:Owner(plan.key,context,false)~=plan.before or self:Owner(plan.key,context,true)~=plan.before then
        return false,"The key changed after review. Nothing was overwritten; review it again."
    end
    return true
end
function K:Write(key,command,context)
    local revision=self.revision
    if S:InCombat() or self.revision~=revision then return false end
    local ok,result=pcall(SetBinding,key,command~="" and command or nil,context)
    return ok and S:Readable(result) and (result==true or result==1)
end
function K:Save(set)
    local revision=self.revision
    if S:InCombat() or self:BindingSet()~=set or S:InCombat() or self.revision~=revision then return false end
    local ok,value=pcall(SaveBindings,set)
    -- Some client versions return nothing. This verifies call delivery, not disk persistence.
    return ok and S:Readable(value) and (value==nil or value==true or value==1)
end
function K:Rollback(plan)
    -- Never undo someone else's subsequent write or a binding-set switch.
    if S:InCombat() or self:BindingSet()~=plan.bindingSet then return false end
    local current=self:Owner(plan.key,plan.context,false)
    if current==plan.before then return true end
    if current~=plan.after then return false end
    return self:Write(plan.key,plan.before,plan.context) and self:Owner(plan.key,plan.context,false)==plan.before and self:Save(plan.bindingSet)
end
function K:Commit(confirmReplacement)
    local plan=self.plan
    if not plan then return false,"Capture and review a shortcut first." end
    local revision=self.revision
    local valid,why=self:StillValid(plan)
    if self.plan~=plan or self.revision~=revision then return false,"The shortcut review changed. Nothing was saved." end
    if not valid then self:Cancel();self.status="STALE_REVIEW";return false,why end
    if plan.before~="" and not confirmReplacement then return false,"Confirm replacing or removing the current assignment." end
    self.plan=nil
    local wrote=self:Write(plan.key,plan.after,plan.context)
    local matched=self:Owner(plan.key,plan.context,false)==plan.after
    if not wrote or not matched or not self:Save(plan.bindingSet) or self:BindingSet()~=plan.bindingSet or self:Owner(plan.key,plan.context,false)~=plan.after then
        local restored=self:Rollback(plan);self.status=restored and "FAILED_ROLLED_BACK" or "RECOVERY_REQUIRED"
        return false,restored and "The change failed; the previous assignment was restored." or "The native change could not be verified. Check this key in the game's Key Bindings before continuing."
    end
    self.history[#self.history+1]=plan;if #self.history>10 then table.remove(self.history,1) end
    self.status="SAVED_NATIVE_SHORTCUT"
    if M.modules.ActionBars then M.modules.ActionBars.bindingsDirty=true end
    return true,"Saved in the current game binding set. Other keys were not changed."
end
function K:Restore()
    self:Cancel()
    local plan=self.history[#self.history];if not plan then return false,"No shortcut changes from this session to restore." end
    local revision=self.revision
    local inverse={key=plan.key,command=plan.command,before=plan.after,after=plan.before,context=plan.context,bindingSet=plan.bindingSet}
    local valid,why=self:StillValid(inverse)
    if self.revision~=revision or self.history[#self.history]~=plan then return false,"The shortcut review changed. Nothing was restored." end
    if not valid then return false,why end
    local wrote=self:Write(inverse.key,inverse.after,inverse.context)
    if not wrote or self:Owner(inverse.key,inverse.context,false)~=inverse.after or not self:Save(inverse.bindingSet) or self:BindingSet()~=inverse.bindingSet or self:Owner(inverse.key,inverse.context,false)~=inverse.after then
        local restored=self:Rollback(inverse);self.status=restored and "RESTORE_FAILED" or "RECOVERY_REQUIRED"
        return false,"The restoration could not be saved. Check the key in the game's Key Bindings."
    end
    table.remove(self.history);self.status="RESTORED_NATIVE_SHORTCUT"
    if M.modules.ActionBars then M.modules.ActionBars.bindingsDirty=true end
    return true,"Previous assignment restored. Restore history lasts for this session only."
end
