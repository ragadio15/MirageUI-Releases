local _,M=...
-- A small separate journal; no profile, unit, chat, binding or native error
-- payload is copied here. Only bounded allowlisted source paths/line numbers
-- may accompany authored failure codes. Future storage stays read-only.
M.Incidents={capacity=16,session=0,status="NOT_RUN",history={}}
local I=M.Incidents
local stopReasons={USER_REQUEST=true,USER_SETTINGS=true,USER_BINDING=true,CORE_FAULT=true,
    NATIVE_ACTION_BLOCKED=true,FOREVER_CANDIDATE_DISABLED=true,SAVED_SAFE_MODE=true}
local kinds={FAULT=true,CONFLICT=true,PARTIAL=true,RECOVERY=true,USER_PAUSED=true,FAULT_STOPPED=true}
local sourceOrigins={PROFILE=true,VIEWPORT=true,PROVIDER=true}
local sourcePhases={}
for phase in ("PRECHECK RECOVERY_RESET NATIVE_RELEASE ADAPTIVE_LAYOUT TYPOGRAPHY_BEGIN POLICY MODULE_INITIALIZE MODULE_RESUME MODULE_CONFIG MODULE_SUSPEND MODULE_CLEANUP THEME FONTS LAYOUT EVENTS SIGNALS PRESENTATION CVE MANAGED_CONFIGURE RESOURCE_PREFERENCE TYPOGRAPHY_END COMPLETE"):gmatch("%S+") do sourcePhases[phase]=true end
local sourceUnavailable="SOURCE_LOCATIONS_UNAVAILABLE"
local function sourcePath(path,line)
    if #path>160 or #line>7 then return nil end
    local addon=path:match("^([^/]+)/")
    if addon=="MirageUI" or addon=="MirageUIOptions" or addon and addon:match("^Blizzard_[%w_]+$") then
        return path..":"..line
    end
end
local function sourceLocations(value)
    if not M.Safety:Text(value) or #value>3000 then return sourceUnavailable end
    if value==sourceUnavailable then return value end
    local out,seen={},{}
    for part in value:gmatch("[^;]+") do
        local path,line=part:match("^([%w_/%-]+%.lua):(%d+)$")
        local location=path and sourcePath(path,line)
        if not location then return sourceUnavailable end
        if not seen[location] then out[#out+1]=location;seen[location]=true end
        if #out>16 then return sourceUnavailable end
    end
    return #out>0 and table.concat(out,";") or sourceUnavailable
end
local function copySource(source)
    if not M.Safety:Readable(source) or type(source)~="table" or getmetatable(source)~=nil then return nil end
    local origin,phase=rawget(source,"origin"),rawget(source,"phase")
    if not M.Safety:Text(origin) or not sourceOrigins[origin] then return nil end
    return {origin=origin,phase=M.Safety:Text(phase) and sourcePhases[phase] and phase or "UNKNOWN",locations=sourceLocations(rawget(source,"locations"))}
end
function I:CaptureFailure(origin,phase)
    -- Called by an xpcall handler while the original failing stack is alive.
    -- It intentionally receives no error argument and never reads that payload.
    local evidence={origin=M.Safety:Text(origin) and sourceOrigins[origin] and origin or nil,
        phase=M.Safety:Text(phase) and sourcePhases[phase] and phase or "UNKNOWN",locations=sourceUnavailable}
    if not evidence.origin then return nil end
    local stack,state=M.Safety:Public(debugstack,"string",2,32,0)
    if state~="KNOWN" or #stack>32768 then return evidence end
    local out,seen={},{}
    for line in stack:gmatch("[^\r\n]+") do
        local path,number=line:gsub("\\","/"):match('Interface/AddOns/([%w_/%-]+%.lua)["%]]*:(%d+)')
        local location=path and sourcePath(path,number)
        if location and not seen[location] then out[#out+1]=location;seen[location]=true end
        if #out>=16 then break end
    end
    if #out>0 then evidence.locations=table.concat(out,";") end
    return evidence
end
local function token(v,fallback)
    return type(v)=="string" and #v<=128 and v:match("^[%w_.:%-]+$") and v or fallback
end
local function integer(v)
    return M.Safety:Number(v) and v>=0 and v%1==0 and v<=2147483647 and v or 0
end
local function copyRow(row)
    if type(row)~="table" or getmetatable(row)~=nil or not kinds[row.kind] then return nil end
    local out={kind=row.kind,owner=token(row.owner,"Core"),phase=token(row.phase,"UNKNOWN"),reason=token(row.reason,"UNKNOWN"),
        surface=token(row.surface,"NONE"),build=token(row.build,"UNKNOWN"),client=token(row.client,"UNKNOWN"),
        generation=integer(row.generation),session=integer(row.session),sequence=integer(row.sequence),count=integer(row.count)}
    out.at=M.Safety:Number(row.at) and math.max(0,row.at) or 0
    out.source=copySource(row.source)
    return out
end
-- P19's new measurement string could receive SetText before SetFont. Its
-- escaped recovery layout produced this exact retained source chain. Only the
-- final causal fault/stop pair from that release qualifies for the P20 repair;
-- an older matching row cannot authorize resuming a different Core failure.
local patchedBuild="mirageui-1.0.14-rc.1-20261122-p19"
local patchedClient="Forever:1.60.1:71037:16001"
local patchedLocations={"MirageUI/Rework/ActionBar.lua:203","MirageUI/Rework/ActionBar.lua:234",
    "MirageUI/Rework/ActionBar.lua:238","MirageUI/Rework/ActionInterface.lua:937",
    "MirageUI/Rework/ActionInterface.lua:912","MirageUI/Core/Layout.lua:119"}
local function patchedStateSeal(store)
    -- Capture the original plain-data fields before any readability API can
    -- dispatch callbacks. The final comparison performs no native observations.
    local function plain(value) return type(value)=="table" and getmetatable(value)==nil end
    if not plain(store) then return nil end
    local history,stop=rawget(store,"history"),rawget(store,"stop")
    if not plain(history) or not plain(stop) or #history<2 or #history>16 then return nil end
    local size=#history;local fault,receipt=rawget(history,size-1),rawget(history,size)
    if not plain(fault) or not plain(receipt) or not plain(rawget(fault,"source")) then return nil end
    local source=rawget(fault,"source");local slots,objects={},{}
    local function pin(object,keys)
        objects[#objects+1]=object
        for key in keys:gmatch("%S+") do slots[#slots+1]={object=object,key=key,value=rawget(object,key)} end
    end
    pin(store,"schema session sequence stop history");pin(stop,"kind reason session at p19LabelRepair")
    pin(fault,"kind owner phase reason surface build client generation session sequence count at source")
    pin(receipt,"kind owner phase reason surface build client generation session sequence count at source")
    pin(source,"origin phase locations")
    return function()
        for _,object in ipairs(objects) do if getmetatable(object)~=nil then return false end end
        if getmetatable(history)~=nil or #history~=size or not rawequal(rawget(history,size-1),fault)
            or not rawequal(rawget(history,size),receipt) then return false end
        for _,slot in ipairs(slots) do if not rawequal(rawget(slot.object,slot.key),slot.value) then return false end end
        return true
    end
end
local function patchedStopPair(store)
    local seal=patchedStateSeal(store);if not seal then return nil end
    local stop,history=store and store.stop,store and store.history
    if type(stop)~="table" or getmetatable(stop)~=nil or stop.kind~="FAULT_STOPPED" or stop.reason~="CORE_FAULT"
        or stop.p19LabelRepair~=nil and stop.p19LabelRepair~=true
        or not M.Safety:Number(stop.session) or stop.session<1 or not M.Safety:Number(stop.at)
        or type(history)~="table" or getmetatable(history)~=nil or #history<2 or #history>16 then return nil end
    local stopped,fault=history[#history],history[#history-1]
    if type(stopped)~="table" or type(fault)~="table" or getmetatable(stopped)~=nil or getmetatable(fault)~=nil then return nil end
    if stopped.kind~="FAULT_STOPPED" or stopped.owner~="Core" or stopped.phase~="STOP" or stopped.reason~="CORE_FAULT"
        or fault.kind~="FAULT" or fault.owner~="Core" or fault.phase~="LAYOUT" or fault.reason~="PROFILE_APPLY_FAILED"
        or stopped.build~=patchedBuild or fault.build~=patchedBuild or stopped.client~=patchedClient or fault.client~=patchedClient
        or stopped.session~=stop.session or fault.session~=stop.session or fault.generation~=stopped.generation
        or not M.Safety:Number(fault.generation) or fault.generation<1
        or not M.Safety:Number(fault.sequence) or not M.Safety:Number(stopped.sequence)
        or fault.sequence<1 or fault.sequence+1~=stopped.sequence or stopped.sequence~=store.sequence
        or not M.Safety:Number(fault.at) or not M.Safety:Number(stopped.at)
        or fault.at>stop.at or stop.at>stopped.at then return nil end
    local source=fault.source
    if type(source)~="table" or getmetatable(source)~=nil or source.origin~="PROFILE" or source.phase~="LAYOUT"
        or not M.Safety:Text(source.locations) or sourceLocations(source.locations)~=source.locations then return nil end
    local locations=";"..source.locations..";";local cursor=1
    for _,location in ipairs(patchedLocations) do
        local first,last=locations:find(";"..location..";",cursor,true)
        if not first then return nil end
        cursor=last -- retain the separator shared by consecutive locations.
    end
    if not seal() then return nil end
    return fault,stopped
end
function I:Initialize()
    self.priorNativeStop=nil;self.priorPatchedStop=nil;self.priorPatchedFault=nil;self.priorPatchedReceipt=nil
    local saved=MirageUIRuntimeDB
    if saved~=nil and (type(saved)~="table" or getmetatable(saved)~=nil or saved.schema~=1) then
        self.status="UNKNOWN_JOURNAL_PRESERVED";self.readOnly=true;return false
    end
    -- Qualification must hold in the raw record too. Sanitization may replace
    -- an absent owner with Core or drop an unknown trailing row for reporting;
    -- those repairs cannot manufacture permission to clear a saved fault.
    local originalSeal=patchedStateSeal(saved)
    local originalFault=originalSeal and patchedStopPair(saved)
    local out={schema=1,session=integer(saved and saved.session)+1,history={},sequence=integer(saved and saved.sequence)}
    if saved then
        out.first=copyRow(saved.first)
        if type(saved.history)=="table" and getmetatable(saved.history)==nil then
            for n=math.max(1,#saved.history-self.capacity+1),math.min(#saved.history,1024) do
                local row=copyRow(saved.history[n]);if row then out.history[#out.history+1]=row end
            end
        end
        if type(saved.stop)=="table" and getmetatable(saved.stop)==nil and stopReasons[saved.stop.reason] then
            out.stop={reason=saved.stop.reason,kind=saved.stop.kind=="USER_PAUSED" and "USER_PAUSED" or saved.stop.kind=="FAULT_STOPPED" and "FAULT_STOPPED" or "UNKNOWN",
                session=integer(saved.stop.session),at=M.Safety:Number(saved.stop.at) and saved.stop.at or 0}
            -- Only a positively identified automatic stop from an earlier
            -- process may be retired at startup. Unknown records and an
            -- intentional user pause never acquire this permission.
            if saved.stop.kind=="FAULT_STOPPED" and saved.stop.reason=="NATIVE_ACTION_BLOCKED"
                and out.stop.session>0 and out.stop.session<out.session then self.priorNativeStop=out.stop end
        end
    end
    local originalQualified=originalFault~=nil and originalSeal() and rawequal(saved,MirageUIRuntimeDB)
    if out.stop and out.stop.reason=="CORE_FAULT" then
        -- Retain a rejected raw proof across reloads. Otherwise normalization
        -- of a missing owner or dropped tail could qualify on the second load.
        out.stop.p19LabelRepair=originalQualified and true or false
    end
    if originalQualified
        and out.stop and out.stop.session>0 and out.stop.session<out.session then
        local fault,stopped=patchedStopPair(out)
        if fault then self.priorPatchedStop=out.stop;self.priorPatchedFault=fault;self.priorPatchedReceipt=stopped end
    end
    MirageUIRuntimeDB=out;self.store=out;self.history=out.history;self.session=out.session
    self.status="READY";self.readOnly=false;return true
end
function I:Record(kind,owner,phase,reason,surface,evidence)
    if not kinds[kind] then return false end
    owner=token(owner,"Core");phase=token(phase,"UNKNOWN");reason=token(reason,"UNKNOWN");surface=token(surface,"NONE")
    local source=copySource(evidence)
    local history=self.history;local previous=history[#history]
    local previousSource=previous and previous.source
    local sameSource=not source and not previousSource or source and previousSource
        and source.origin==previousSource.origin and source.phase==previousSource.phase and source.locations==previousSource.locations
    if previous and previous.kind==kind and previous.owner==owner and previous.phase==phase and previous.reason==reason
        and previous.surface==surface and previous.session==self.session and sameSource then
        previous.count=math.min(2147483647,previous.count+1);return true
    end
    local store=self.store;local sequence=math.min(2147483647,(store and store.sequence or self.sequence or 0)+1)
    local row={kind=kind,owner=owner,phase=phase,reason=reason,surface=surface,
        build=token(M.BuildInfo and M.BuildInfo.id or M.version,"UNKNOWN"),client=token(M.Client and M.Client.key,"UNKNOWN"),
        generation=M.state.settingsGeneration or 0,session=self.session,sequence=sequence,count=1,at=M.Safety:Now(),source=source}
    history[#history+1]=row;if #history>self.capacity then table.remove(history,1) end
    self.sequence=sequence
    if store and rawequal(store,MirageUIRuntimeDB) and not self.readOnly then
        store.sequence=sequence
        if (kind=="FAULT" or kind=="CONFLICT" or kind=="FAULT_STOPPED") and not store.first then store.first=copyRow(row) end
    end
    return true
end
function I:SetStop(reason)
    local store=self.store
    if not store or self.readOnly or not rawequal(store,MirageUIRuntimeDB) then return false end
    if reason==false then store.stop=nil;return true end
    if not stopReasons[reason] then reason="SAVED_SAFE_MODE" end
    local user=reason=="USER_REQUEST" or reason=="USER_SETTINGS" or reason=="USER_BINDING"
    local kind=user and "USER_PAUSED" or "FAULT_STOPPED"
    if store.stop and store.stop.reason==reason and store.stop.kind==kind and store.stop.session==self.session then return true end
    store.stop={kind=kind,reason=reason,session=self.session,at=M.Safety:Now()}
    return self:Record(kind,"Core","STOP",reason)
end
function I:StopReason()
    local row=self.store and self.store.stop
    return row and stopReasons[row.reason] and row.reason or nil
end
function I:HistoricalNativeStop()
    local store=self.store
    local row=store and store.stop
    return self.status=="READY" and not self.readOnly and rawequal(store,MirageUIRuntimeDB)
        and row~=nil and rawequal(row,self.priorNativeStop) and row.kind=="FAULT_STOPPED"
        and row.reason=="NATIVE_ACTION_BLOCKED" and row.session>0 and row.session<self.session
end
function I:HistoricalPatchedStop()
    local store=self.store;local stop=store and store.stop
    if self.status~="READY" or self.readOnly or not rawequal(store,MirageUIRuntimeDB)
        or not rawequal(self.history,store.history) or not stop or not rawequal(stop,self.priorPatchedStop)
        or not M.Safety:Number(stop.session) or stop.session<1 or stop.session>=self.session then return false end
    local fault,stopped=patchedStopPair(store)
    return fault~=nil and rawequal(fault,self.priorPatchedFault) and rawequal(stopped,self.priorPatchedReceipt)
end
function I:StopScope()
    local row=self.store and self.store.stop
    if not row then return "NONE" end
    return row.session==self.session and "CURRENT_SESSION" or "PERSISTED_RECORD"
end
function I:Snapshot()
    local history={};for i,row in ipairs(self.history) do history[i]=copyRow(row) end
    return {schema=1,status=self.status,session=self.session,first=copyRow(self.store and self.store.first),
        stopReason=self:StopReason(),stopScope=self:StopScope(),history=history}
end
function I:Export()
    local s=self:Snapshot();local lines={"incident_schema=1","incident_storage="..s.status,"incident_session="..s.session,
        "incident_stop="..(s.stopReason or "NONE"),"incident_stop_scope="..s.stopScope,"incident_payloads=AUTHORED_CODES_AND_SOURCE_LOCATIONS"}
    local function add(label,row)
        if not row then return end
        lines[#lines+1]=label.."="..table.concat({row.kind,row.owner,row.phase,row.reason,row.surface,row.build,row.client,
            row.generation,row.session,row.sequence,string.format("%.3f",row.at),row.count},"/")
        if row.source then
            lines[#lines+1]=label.."_source="..row.source.origin.."/"..row.source.phase
            lines[#lines+1]=label.."_source_scope="..(row.session==s.session and "CURRENT_SESSION" or "PERSISTED_RECORD")
            lines[#lines+1]=label.."_source_locations="..row.source.locations
        end
    end
    add("incident_first",s.first)
    for i,row in ipairs(s.history) do add("incident_"..i,row) end
    return table.concat(lines,"\n")
end
