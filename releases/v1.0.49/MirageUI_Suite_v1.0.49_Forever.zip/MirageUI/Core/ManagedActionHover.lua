local _,M=...
-- Default-off, source-bound SECONDARY action hover. This is not full UI04.
-- Native buttons/scripts/bindings stay native. Owned hotspots never click,
-- and optional hiding has exactly one out-of-combat writer below.
M.ManagedActionHover={status="OFF",grace=.4}
local H,S,N=M.ManagedActionHover,M.Safety,M.ManagedNative
local names={"MultiBarBottomLeft","MultiBarBottomRight","MultiBarRight","MultiBarLeft"}
local actionNames={"MainActionBar","MultiBarBottomLeft","MultiBarBottomRight","MultiBarRight","MultiBarLeft","MultiBar5","MultiBar6","MultiBar7"}
local secondary={};for _,name in ipairs(names) do secondary[name]=true end
local vetoNames={"SpellFlyout","SpellBookFrame","PlayerSpellsFrame","EditModeManagerFrame"}
local slots,policies={},setmetatable({},{__mode="k"})
local policyWriting=setmetatable({},{__mode="k"})
local busy,configuring,serial=false,false,0
local function pack(...) return {n=select("#",...),...} end
local function report(status) H.status=status;N.status.ActionHover=status end
H.program=[=[
self:SetAttribute("mirage-state",newstate)
if newstate == "show" or self:GetAttribute("mirage-emergency") then self:Show() end
]=]
H.driver="[vehicleui] show; [overridebar] show; [possessbar] show; [petbattle] show; [combat] show; hide"
-- Deferred opt-out must record ordinary target/quiet states without either
-- showing or hiding. Distinct force labels retain secure combat/special access.
H.handoffDriver="[vehicleui] forced; [overridebar] forced; [possessbar] forced; [petbattle] forced; [combat] forced; hide"
H.handoffProgram=[=[
self:SetAttribute("mirage-state",newstate == "forced" and "show" or newstate)
if newstate == "forced" or self:GetAttribute("mirage-emergency") then
    self:Show()
elseif not self:GetAttribute("mirage-handoff") then
    if newstate == "show" or self:GetAttribute("mirage-held") then self:Show() else self:Hide() end
end
]=]
local hotspotState=[=[
self:SetAttribute("mirage-phase",newstate)
self:SetAttribute("mirage-inside",false)
if newstate == "quiet" and self:GetAttribute("mirage-live") then self:Show() else self:Hide() end
]=]
local enter=[=[
if self:GetAttribute("mirage-live") and self:GetAttribute("mirage-phase") == "quiet" then
    self:SetAttribute("mirage-inside",true)
    self:CallMethod("MirageMotion","enter")
end
]=]
local leave=[=[
self:SetAttribute("mirage-inside",false)
self:CallMethod("MirageMotion","leave")
]=]
local hotspotDriver="[vehicleui] locked; [overridebar] locked; [possessbar] locked; [petbattle] locked; [combat] locked; quiet"
function H:Requested()
    local p=M.profile;local c=p and p.modules and p.modules.ActionBars
    -- b35 immersion never installs invisible acquisition hotspots. Preserve
    -- the historical opt-in setting as dormant for other presentation presets.
    return p and p.preset~="Immersive" and p.managed==true and c and c.secondaryHover==true and M.Client.allowed==true and
        M.adapter.family=="Midnight" or false
end
function H:InputReleased()
    local down,ds=S:Public(IsMouseButtonDown,"boolean")
    local look,ls=S:Public(IsMouselooking,"boolean")
    if ds~="KNOWN" or ls~="KNOWN" then return nil end
    return down==false and look==false
end
function H:ResetFailures()
    if S:InCombat() then return false end
    -- Deliberate Resume only: renew bounded retry budgets, not visibility or
    -- input permission. Configure/Tick must still qualify every current sink.
    self.failedProfile=nil;self.untilTime=nil;self.deferAcquisition=true
    for _,slot in pairs(slots) do slot.failures=0;slot.retireFailures=0 end
    return true
end
local function rowCurrent(g)
    if M.ManagedActionHover~=H or M.ManagedNative~=N or M.Safety~=S or M.profile~=g.profile or
        N.rows~=g.rows or M.state~=g.state or M.Client~=g.client or M.modules~=g.modules or
        M.profile.modules~=g.configs or g.configs.ActionBars~=g.config or g.config.secondaryHover~=g.selected or
        M.Native~=g.native or M.Managed~=g.managed or S.Readable~=g.readable or S.InCombat~=g.combat or
        rawget(_G,"issecretvalue")~=g.secret or rawget(_G,"canaccessvalue")~=g.access or rawget(_G,"canaccesstable")~=g.tableAccess or
        not g.profile.enabled or not g.profile.managed or g.state.safe or not g.state.world or
        not g.client.allowed or not g.config.enabled or M.modules.ActionBars~=g.module or
        g.module.quarantined or g.module.suspended then return false end
    for _,key in ipairs(vetoNames) do if rawget(_G,key)~=g.vetoFrames[key] then return false end end
    if M.Options~=g.options or (g.options and g.options.frame)~=g.optionsFrame then return false end
    for _,e in ipairs(g.entries) do
        local r=e.row
        if g.rows[e.name]~=r or rawget(_G,e.name)~=e.root or r.frame~=e.root or r.gate~=e.gate or
            not r.active or r.failed or r.contested or r.restorePending or
            (g.requireHover and r.hoverMode~=true) then return false end
    end
    if g.slots then for _,e in ipairs(g.slots) do
        if slots[e.name]~=e.slot or e.slot.serial~=e.serial or not e.slot.live or
            e.slot.profile~=g.profile or e.slot.hotspot~=e.hotspot then return false end
    end end
    return true
end
local function current(g)
    if not rowCurrent(g) then return false end
    for _,b in ipairs(g.bindings) do
        local ok,value=pcall(function() return b.object[b.key] end)
        if not ok or value~=b.fn then return false end
    end
    return rowCurrent(g)
end
local function request(row,requireHover)
    local p=M.profile
    if not p or not p.modules or not M.modules or not M.modules.ActionBars then return nil end
    local g={profile=p,rows=N.rows,state=M.state,client=M.Client,modules=M.modules,module=M.modules.ActionBars,
        configs=p.modules,config=p.modules.ActionBars,selected=p.modules.ActionBars.secondaryHover,entries={},bindings={},requireHover=requireHover,
        native=M.Native,managed=M.Managed,readable=S.Readable,combat=S.InCombat,
        secret=rawget(_G,"issecretvalue"),access=rawget(_G,"canaccessvalue"),tableAccess=rawget(_G,"canaccesstable")}
    g.vetoFrames={};for _,key in ipairs(vetoNames) do g.vetoFrames[key]=rawget(_G,key) end
    g.options=M.Options;g.optionsFrame=M.Options and M.Options.frame
    if row then g.entries[1]={name=row.name,row=row,root=row.frame,gate=row.gate}
    else for _,name in ipairs(actionNames) do
        local r=N.rows[name]
        if r and r.active and r.hoverMode then g.entries[#g.entries+1]={name=name,row=r,root=r.frame,gate=r.gate} end
    end end
    if not current(g) then return nil end
    return g
end
local function invoke(g,object,key,global,...)
    if not current(g) then return false end
    local good,fn=pcall(function() return object[key] end)
    if not good or type(fn)~="function" or not current(g) then return false end
    local found
    for _,b in ipairs(g.bindings) do if b.object==object and b.key==key then found=b;break end end
    if found then if found.fn~=fn then return false end
    else g.bindings[#g.bindings+1]={object=object,key=key,fn=fn} end
    local result=global and pack(pcall(fn,...)) or pack(pcall(fn,object,...))
    if not current(g) then return false end
    return unpack(result,1,result.n)
end
local function readable(g,value,kind)
    local ok,allowed=pcall(S.Readable,S,value)
    if not ok or allowed~=true or not current(g) then return false end
    if kind=="number" then return type(value)=="number" and value==value and value~=math.huge and value~=-math.huge end
    return not kind or type(value)==kind
end
local function read(g,object,key,kind,...)
    local ok,value=invoke(g,object,key,false,...)
    if ok and readable(g,value,kind) then return value,true end
    return nil,false
end
local function global(g,key,kind,...)
    local ok,value=invoke(g,_G,key,true,...)
    if ok and readable(g,value,kind) then return value,true end
    return nil,false
end
local function unlocked(g)
    local combat,known=global(g,"InCombatLockdown","boolean")
    local ok,conflict=invoke(g,g.native,"Conflict",false)
    local enabled,active=invoke(g,g.managed,"Enabled",false)
    return known and combat==false and ok and conflict==false and enabled and active==true and current(g)
end
local function write(g,object,key,...)
    if not unlocked(g) then return false end
    return invoke(g,object,key,false,...)
end
local function register(g,frame,id,driver)
    if not unlocked(g) then return false end
    return invoke(g,_G,"RegisterStateDriver",true,frame,id,driver)
end
local function released(g)
    local down,dk=global(g,"IsMouseButtonDown","boolean")
    local look,lk=global(g,"IsMouselooking","boolean")
    return dk and lk and down==false and look==false and current(g)
end
local function closed(g,frame,required)
    if frame==nil then return not required end
    if not readable(g,frame) then return false end
    local shown,known=read(g,frame,"IsShown","boolean")
    return known and shown==false
end
local function quietInput(g)
    if not released(g) then return false end
    local focus,fk=global(g,"GetCurrentKeyBoardFocus")
    local cursor,ck=global(g,"GetCursorInfo")
    -- Verified nil is empty. Missing/error/restricted is not an empty cursor.
    if not fk or focus~=nil or not ck or cursor~=nil then return false end
    if not closed(g,rawget(_G,"SpellFlyout"),true) then return false end
    for _,name in ipairs({"SpellBookFrame","PlayerSpellsFrame","EditModeManagerFrame"}) do
        if not closed(g,rawget(_G,name),false) then return false end
    end
    if M.state.edit or not closed(g,M.Options and M.Options.frame,false) then return false end
    local now,nk=global(g,"GetTime","number")
    local reveal=M.state.revealUntil
    if reveal~=nil and (not readable(g,reveal,"number") or not nk or reveal>now) then return false end
    return current(g)
end
local function visibility(g,gate,hide)
    -- Authority callbacks and geometry reads precede the FINAL input/veto read.
    -- Do not call write() here: its later authority callbacks could stale that
    -- admission. invoke() only reseals this same request before the native sink.
    if not unlocked(g) or (hide and not quietInput(g)) or not released(g) then return false end
    return invoke(g,gate,hide and "Hide" or "Show",false)
end
local function gateState(g,e)
    local state,sk=read(g,e.gate,"GetAttribute","string","mirage-state")
    local emergency,ek=read(g,e.gate,"GetAttribute","boolean","mirage-emergency")
    local program,pk=read(g,e.gate,"GetAttribute","string","_onstate-mirage")
    return sk and ek and pk and state=="hide" and emergency==false and program==H.program
end
local function rect(g,frame)
    local ok,l,b,w,h=invoke(g,frame,"GetRect",false)
    if not ok then return nil end
    for _,v in ipairs({l,b,w,h}) do if not readable(g,v,"number") then return nil end end
    -- The explicit checks also reject holes in a multi-return list.
    if not readable(g,l,"number") or not readable(g,b,"number") or not readable(g,w,"number") or not readable(g,h,"number") or w<=0 or h<=0 then return nil end
    local scale,known=read(g,frame,"GetEffectiveScale","number")
    if not known or scale<=0 then return nil end
    return {left=l,bottom=b,width=w,height=h,scale=scale}
end
local function box(g,frame)
    local native=rect(g,frame);local parent=rect(g,UIParent)
    if not native or not parent or parent.width<960 or parent.height<600 then return nil end
    local ratio=native.scale/parent.scale
    if not readable(g,ratio,"number") or ratio<=0 then return nil end
    local x=native.left*ratio-parent.left;local y=native.bottom*ratio-parent.bottom
    local w,h=native.width*ratio,native.height*ratio
    for _,v in ipairs({x,y,w,h}) do if not readable(g,v,"number") then return nil end end
    if w<=0 or h<=0 or math.max(w,h)>600 or math.min(w,h)>64 or
        w*h>parent.width*parent.height*.035 or x<0 or y<0 or x+w>parent.width or y+h>parent.height then return nil end
    return {left=x,bottom=y,width=w,height=h,parentScale=parent.scale,parentLeft=parent.left,parentBottom=parent.bottom,
        screenW=parent.width,screenH=parent.height}
end
local function sameBox(a,b)
    if not a or not b then return false end
    for _,key in ipairs({"left","bottom","width","height","parentScale","parentLeft","parentBottom","screenW","screenH"}) do
        if a[key]~=b[key] then return false end
    end
    return true
end
local strata={MEDIUM=true,HIGH=true,DIALOG=true,FULLSCREEN=true,FULLSCREEN_DIALOG=true,TOOLTIP=true}
local function eligible(g,e)
    if e.row.originalParent~=UIParent or read(g,e.root,"GetParent")~=e.gate or read(g,e.gate,"GetParent")~=UIParent or
        read(g,UIParent,"IsVisible","boolean")~=true or read(g,e.root,"IsShown","boolean")~=true then return nil end
    local forbidden,fk=read(g,e.root,"IsForbidden","boolean")
    local level,lk=read(g,e.root,"GetFrameStrata","string")
    if not fk or forbidden~=false or not lk or not strata[level] then return nil end
    return box(g,e.root)
end
local function inputFlags(g,f,motion)
    return read(g,f,"IsMouseClickEnabled","boolean")==false and read(g,f,"IsMouseMotionEnabled","boolean")==motion and
        read(g,f,"IsMouseWheelEnabled","boolean")==false and read(g,f,"IsKeyboardEnabled","boolean")==false and
        read(g,f,"IsGamePadButtonEnabled","boolean")==false and read(g,f,"IsGamePadStickEnabled","boolean")==false and
        read(g,f,"CanPropagateMouseMotion","boolean")==true and read(g,f,"GetFrameStrata","string")=="LOW" and
        read(g,f,"GetParent")==UIParent and read(g,f,"GetScale","number")==1
end
function H:Retire(row)
    local slot=row and slots[row.name]
    if not slot or slot.row~=row then return true end
    slot.live=false;self.untilTime=nil
    if S:InCombat() then slot.retirePending=true;return false end
    if slot.retireProfile~=M.profile then slot.retireFailures=0;slot.retireProfile=M.profile end
    if (slot.retireFailures or 0)>=3 then return false end
    local f,ops=slot.hotspot,slot.ops
    if slot.retired and S:Public(ops.IsShown,"boolean",f)==false and
        S:Public(ops.IsMouseClickEnabled,"boolean",f)==false and S:Public(ops.IsMouseMotionEnabled,"boolean",f)==false and
        S:Public(ops.GetAttribute,"boolean",f,"mirage-live")==false and S:Public(ops.GetAttribute,"boolean",f,"mirage-inside")==false then return true end
    slot.serial=slot.serial+1;slot.retired=nil
    -- Only our own exact object uses saved cleanup methods. A replaced global
    -- name or public method cannot redirect cleanup to somebody else's frame.
    local ok=true
    for _,item in ipairs({{"SetAttribute","mirage-live",false},{"SetAttribute","mirage-inside",false},{"EnableMouse",false},{"EnableMouseMotion",false},{"Hide"}}) do
        local fn=ops[item[1]]
        if type(fn)~="function" or not pcall(fn,f,unpack(item,2,#item)) then ok=false end
        if S:InCombat() then ok=false;break end
    end
    for _,key in ipairs({"IsShown","IsMouseClickEnabled","IsMouseMotionEnabled"}) do
        if S:Public(ops[key],"boolean",f)~=false then ok=false end
    end
    for _,key in ipairs({"mirage-live","mirage-inside"}) do
        if S:Public(ops.GetAttribute,"boolean",f,key)~=false then ok=false end
    end
    slot.retireFailures=ok and 0 or (slot.retireFailures or 0)+1
    slot.retired=ok or nil
    slot.retirePending=not ok or nil
    return ok
end
local function retireAll()
    local ok=true;for _,name in ipairs(names) do local slot=slots[name];if slot and not H:Retire(slot.row) then ok=false end end
    return ok
end
local function configurePolicy(self,row,legacyProgram,legacyDriver)
    policies[row]={program=legacyProgram,driver=legacyDriver}
    local wanted=self:Requested()
    if not wanted and not row.hoverMode then return true end
    local g=request(row,false)
    if not g or not unlocked(g) then return false end
    local cold=row.parentAttempt==row.gate
    if cold and not wanted and row.hoverMode then
        -- Restore unregisters the gate driver. A deferred opt-out must first
        -- regain its reveal-only combat fallback, not trust a cached row.driver.
        if not write(g,row.gate,"SetAttribute","_onstate-mirage",self.program) or
            not register(g,row.gate,"mirage",self.driver) then return false end
        row.driver=self.driver
    end
    if not wanted then
        if not self:Retire(row) then
            row.hoverPendingOptOut=true
            visibility(g,row.gate,false)
            report("OPT_OUT_RETIRE_UNCONFIRMED");return true
        end
        if not quietInput(g) then row.hoverPendingOptOut=true;report("OPT_OUT_AFTER_INPUT");return true end
    end
    if not wanted then
        -- Ordinary legacy states are record-only until handoff commits.
        -- A target appearing inside registration cannot reveal under a press;
        -- distinct forced combat/special states retain secure native fallback.
        if not write(g,row.gate,"SetAttribute","mirage-handoff",true) or
            read(g,row.gate,"GetAttribute","boolean","mirage-handoff")~=true or
            not write(g,row.gate,"SetAttribute","_onstate-mirage",self.handoffProgram) or
            read(g,row.gate,"GetAttribute","string","_onstate-mirage")~=self.handoffProgram then return false end
        if not unlocked(g) or not quietInput(g) or not released(g) then
            row.hoverPendingOptOut=true;report("OPT_OUT_AFTER_INPUT");return true
        end
        if not invoke(g,_G,"RegisterStateDriver",true,row.gate,"mirage",self.handoffDriver) then return false end
        row.driver=self.handoffDriver
        local state,sk=read(g,row.gate,"GetAttribute","string","mirage-state")
        local emergency,ek=read(g,row.gate,"GetAttribute","boolean","mirage-emergency")
        if not sk or not ek or (state~="show" and state~="hide") then return false end
        if not quietInput(g) or not released(g) then
            row.hoverPendingOptOut=true;report("OPT_OUT_AFTER_INPUT");return true
        end
        local hide=state=="hide" and not emergency
        if not visibility(g,row.gate,hide) or read(g,row.gate,"IsShown","boolean")~=not hide then return false end
        -- Clearing this flag does not dispatch a state handler. Ordinary
        -- future state transitions now use the original legacy semantics.
        if not unlocked(g) or not quietInput(g) or not released(g) then
            row.hoverPendingOptOut=true;report("OPT_OUT_AFTER_INPUT");return true
        end
        if not invoke(g,row.gate,"SetAttribute",false,"mirage-handoff",false) or
            read(g,row.gate,"GetAttribute","boolean","mirage-handoff")~=false then return false end
        row.hoverMode=nil;row.hoverPendingOptOut=nil;row.hoverUncertain=nil;row.held=false
        self.untilTime=nil
        return true
    end
    -- Reconfigure the secure snippet before registering the driver. Quiet
    -- transitions in the opted-in program record state but never hide.
    if cold or read(g,row.gate,"GetAttribute","string","_onstate-mirage")~=self.program or row.driver~=self.driver or not row.hoverMode then
        row.hoverMode=true
        if not write(g,row.gate,"SetAttribute","_onstate-mirage",self.program) or
            read(g,row.gate,"GetAttribute","string","_onstate-mirage")~=self.program or
            not write(g,row.gate,"SetAttribute","mirage-held",false) or not register(g,row.gate,"mirage",self.driver) then
            row.hoverUncertain=true;report("POLICY_UNCONFIRMED")
            return false -- Caller must not restore a replacement row/profile.
        end
        row.driver=self.driver;row.held=nil
    end
    row.hoverMode=true;row.hoverPendingOptOut=nil;row.hoverUncertain=nil
    return true
end
function H:ConfigurePolicy(row,legacyProgram,legacyDriver)
    -- A native callback may reenter configuration while driver registration is
    -- still on the stack. It cannot create a second hiding admission.
    if policyWriting[row] then return true end
    policyWriting[row]=true;row.hoverPolicyPending=true
    local ok,result=pcall(configurePolicy,self,row,legacyProgram,legacyDriver)
    policyWriting[row]=nil
    if ok and result==true then row.hoverPolicyPending=nil else row.hoverUncertain=true end
    return ok and result==true
end
local function show(g,e)
    if not released(g) then return false end
    if read(g,e.gate,"IsShown","boolean")==true then return current(g) end
    if not visibility(g,e.gate,false) then return false end
    return read(g,e.gate,"IsShown","boolean")==true and current(g)
end
local function actualHotspot(g,slot)
    local f=slot.hotspot
    if rawget(_G,"MirageActionHover_"..slot.name)~=f or not inputFlags(g,f,true) or
        -- Flags and geometry survive Hide; require observable acquisition
        -- visibility before accepting Show or optionally hiding native gates.
        read(g,f,"IsShown","boolean")~=true or read(g,f,"IsVisible","boolean")~=true or
        read(g,f,"GetAttribute","boolean","mirage-live")~=true or
        read(g,f,"GetAttribute","string","mirage-phase")~="quiet" then return false end
    local got=box(g,f)
    return sameBox(got,slot.box)
end
local function makeHotspot(g,e,b)
    local slot=slots[e.name]
    if slot and slot.profile~=g.profile then slot.failures=0 end
    if slot and (slot.failures or 0)>=3 then return false end
    if not slot then
        local globalName="MirageActionHover_"..e.name
        if rawget(_G,globalName)~=nil then return false end
        if not unlocked(g) then return false end
        local ok,f=invoke(g,_G,"CreateFrame",true,"Frame",globalName,UIParent,"SecureHandlerStateTemplate,SecureHandlerEnterLeaveTemplate")
        if not ok or not f then return false end
        serial=serial+1
        slot={name=e.name,hotspot=f,row=e.row,serial=serial,ops={}}
        slots[e.name]=slot
        for _,key in ipairs({"SetAttribute","GetAttribute","EnableMouse","EnableMouseMotion","Hide","IsShown","IsMouseClickEnabled","IsMouseMotionEnabled"}) do slot.ops[key]=f[key] end
        -- Enter is synchronous but insecure; leave NEVER hides synchronously.
        f.MirageMotion=function(self,kind)
            if slot.hotspot~=self or not slot.live or slot.profile~=M.profile or not H:Requested() then return end
            if kind=="leave" then H.untilTime=math.max(H.untilTime or 0,S:Now()+H.grace);return end
            if kind=="enter" and not busy and not configuring then H:Tick() end
        end
    end
    if not H:Retire(slot.row) then return false end
    slot.row=e.row;slot.root=e.root;slot.gate=e.gate;slot.profile=g.profile;slot.box=b
    local f=slot.hotspot;local ok=true
    for _,op in ipairs({{"Hide"},{"EnableMouse",false},{"EnableMouseMotion",true},{"EnableMouseWheel",false},
        {"EnableKeyboard",false},{"EnableGamePadButton",false},{"EnableGamePadStick",false},
        {"SetPropagateMouseMotion",true},{"SetFrameStrata","LOW"},{"SetFrameLevel",0},{"SetScale",1},{"ClearAllPoints"},
        {"SetSize",b.width,b.height},{"SetPoint","BOTTOMLEFT",UIParent,"BOTTOMLEFT",b.left,b.bottom},
        {"SetAttribute","mirage-live",false},{"SetAttribute","mirage-inside",false},
        {"SetAttribute","_onstate-hover",hotspotState},{"SetAttribute","_onenter",enter},{"SetAttribute","_onleave",leave}}) do
        if not write(g,f,op[1],unpack(op,2,#op)) then ok=false;break end
    end
    if ok then ok=inputFlags(g,f,true) and sameBox(box(g,f),b) and register(g,f,"hover",hotspotDriver) end
    local quiet=ok and read(g,f,"GetAttribute","string","mirage-phase")=="quiet"
    if ok and not quiet then
        slot.waitingPhase=true;H.deferAcquisition=true
        H:Retire(e.row);return false -- A known special/locked phase is not a failed setter.
    end
    if quiet and current(g) and released(g) then
        slot.live=true;slot.retired=nil
        ok=write(g,f,"SetAttribute","mirage-live",true) and write(g,f,"Show") and actualHotspot(g,slot)
    else ok=false end
    if not ok then slot.failures=(slot.failures or 0)+1;H:Retire(e.row);return false end
    slot.failures=0;slot.retirePending=nil;slot.waitingPhase=nil;return true
end
function H:Configure()
    if configuring or busy then self.deferAcquisition=true;N.reconcilePending=true;return false end
    if S:InCombat() then self.untilTime=nil;report("LOCKDOWN_OR_UNKNOWN_NO_INSECURE_WRITE");return false end
    configuring=true
    local ok,result=pcall(function()
        if not self:Requested() then retireAll();return true end
        local g=request(nil,true)
        if not g or not unlocked(g) or not closed(g,rawget(_G,"EditModeManagerFrame"),false) then
            retireAll();report("AUTHORITY_REQUALIFICATION_REQUIRED");return false
        end
        if not released(g) then self.deferAcquisition=true;report("INPUT_TRANSITION_DEFERRED");return false end
        local ready=true;self.untilTime=nil
        for _,name in ipairs(names) do
            local e
            for _,entry in ipairs(g.entries) do if entry.name==name then e=entry;break end end
            local b=e and eligible(g,e)
            if b and current(g) then
                local slot=slots[name]
                if not slot or not slot.live or slot.row~=e.row or slot.profile~=g.profile or not sameBox(slot.box,b) or not actualHotspot(g,slot) then
                    if not makeHotspot(g,e,b) then ready=false end
                end
            else
                local slot=slots[name];if slot then self:Retire(slot.row) end
                if e and read(g,e.root,"IsShown","boolean")==true then ready=false end
            end
        end
        report(ready and "SECONDARY_HOVER_CANDIDATE_NATIVE_NOT_RUN" or "HOTSPOT_QUALIFICATION_INCOMPLETE")
        self.deferAcquisition=nil
        return ready
    end)
    configuring=false
    if not ok then retireAll();report("CONFIGURATION_FAILED_RECOVERY_REQUIRED");return false end
    self:Tick()
    return result
end
function H:Tick()
    if busy or configuring then return false end
    local has=false;for _,name in ipairs(actionNames) do local r=N.rows[name];if r and r.active and r.hoverMode then has=true;break end end
    if not has then if next(slots) then retireAll() end;report(self:Requested() and "REQUESTED_NO_ACTIVE_NATIVE_ROWS" or "OFF");return true end
    if S:InCombat() then self.untilTime=nil;report("LOCKDOWN_OR_UNKNOWN_NO_INSECURE_WRITE");return false end
    busy=true
    local ok,result=pcall(function()
        local g=request(nil,true)
        if not g or not unlocked(g) or not closed(g,rawget(_G,"EditModeManagerFrame"),false) then
            retireAll();N.reconcilePending=true;report("OWNER_REQUALIFICATION_REQUIRED");return false
        end
        if not self:Requested() then
            for _,e in ipairs(g.entries) do local p=policies[e.row];if p then self:ConfigurePolicy(e.row,p.program,p.driver) end end
            return true
        end
        if not released(g) then report("INPUT_TRANSITION_DEFERRED");return false end
        local now,nk=global(g,"GetTime","number")
        if not nk then report("CLOCK_UNAVAILABLE");return false end
        local group,ready,hover={},self.failedProfile~=g.profile,false
        g.slots={}
        for _,name in ipairs(names) do
            local slot=slots[name]
            if slot and slot.waitingPhase and read(g,slot.hotspot,"GetAttribute","string","mirage-phase")=="quiet" then
                slot.waitingPhase=nil;self.deferAcquisition=true
            end
        end
        for _,e in ipairs(g.entries) do
            if not secondary[e.name] then
                if not show(g,e) then
                    self.failedProfile=g.profile
                    if current(g) then e.row.failed=true;e.row.restorePending=true end
                    report("PARTIAL_NATIVE_ACCESS");return false
                end
            else
                local ownShown,known=read(g,e.root,"IsShown","boolean")
                local slot=slots[e.name]
                if known and ownShown==false then
                    if slot then self:Retire(e.row) end
                    if not show(g,e) then report("PARTIAL_NATIVE_ACCESS");return false end
                else
                    group[#group+1]=e
                    local b=eligible(g,e)
                    if e.row.hoverUncertain or e.row.hoverPolicyPending or not b or not slot or not slot.live or slot.row~=e.row or
                        slot.profile~=g.profile or not sameBox(slot.box,b) or not actualHotspot(g,slot) then ready=false
                    else
                        g.slots[#g.slots+1]={name=e.name,slot=slot,serial=slot.serial,hotspot=slot.hotspot}
                        local inside,ik=read(g,slot.hotspot,"GetAttribute","boolean","mirage-inside")
                        local over,ok2=read(g,e.root,"IsMouseOver","boolean")
                        if not ik or not ok2 then ready=false elseif inside or over then hover=true end
                    end
                end
            end
        end
        if not current(g) then report("OWNER_REQUALIFICATION_REQUIRED");return false end
        if hover then self.untilTime=now+self.grace end
        local quiet=ready and quietInput(g) and not hover and (not self.untilTime or now>=self.untilTime)
        for _,e in ipairs(group) do if not gateState(g,e) then quiet=false end end
        if not ready then
            -- Never leave stale acquisition regions after a geometry/owner/input
            -- qualification loss. Native parents are revealed only with fresh
            -- released input and still-current row ownership.
            local wasLive=false;for _,name in ipairs(names) do if slots[name] and slots[name].live then wasLive=true end end
            g.slots=nil;retireAll()
            if wasLive or self.deferAcquisition then N.reconcilePending=true;self.deferAcquisition=nil end
        end
        local changed=0
        for _,e in ipairs(group) do
            if not current(g) or not released(g) then report(changed>0 and "PARTIAL_NATIVE_ACCESS" or "INPUT_TRANSITION_DEFERRED");return false end
            if quiet then
                local shown,known=read(g,e.gate,"IsShown","boolean")
                if not known then self.failedProfile=g.profile;report("GATE_VISIBILITY_UNCONFIRMED");return false end
                if shown then
                -- No arbitrary native action reads. Final public vetoes and
                -- request identities are checked again at every hiding sink.
                local qualified=quietInput(g)
                for _,member in ipairs(group) do
                    local slot=slots[member.name]
                    if not slot or not sameBox(eligible(g,member),slot.box) or not actualHotspot(g,slot) or
                        read(g,slot.hotspot,"GetAttribute","boolean","mirage-inside")~=false or
                        read(g,member.root,"IsMouseOver","boolean")~=false or not gateState(g,member) then qualified=false end
                end
                qualified=qualified and quietInput(g)
                if not qualified or not current(g) then
                    if changed>0 then self.failedProfile=g.profile end
                    report(changed>0 and "PARTIAL_NATIVE_ACCESS" or "HIDE_REVALIDATION_FAILED");return false
                end
                if not visibility(g,e.gate,true) or read(g,e.gate,"IsShown","boolean")~=false then
                    self.failedProfile=g.profile;self.untilTime=now+self.grace
                    if current(g) then e.row.failed=true;e.row.restorePending=true end
                    report("PARTIAL_NATIVE_ACCESS");return false
                end
                end
            elseif not show(g,e) then
                self.failedProfile=g.profile
                if current(g) then e.row.failed=true;e.row.restorePending=true end
                report("PARTIAL_NATIVE_ACCESS");return false
            end
            changed=changed+1
        end
        report(#group==0 and "NO_NATIVE_SHOWN_SECONDARIES" or not ready and "QUALIFICATION_PARENT_GATES_OPEN" or quiet and "SECONDARY_QUIET_NATIVE_NOT_RUN" or "SECONDARY_REVEALED_NATIVE_NOT_RUN")
        return true
    end)
    busy=false
    if not ok then retireAll();report("CONTROLLER_FAILED_RECOVERY_REQUIRED");return false end
    return result
end
