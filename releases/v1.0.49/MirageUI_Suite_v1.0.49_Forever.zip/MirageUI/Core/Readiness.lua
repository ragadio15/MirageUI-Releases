local _, M = ...
-- An installation/preflight report, NOT a native test or permission certificate.
M.Readiness={}
local R=M.Readiness
function R:Inspect(draft)
    local p=draft or M.profile
    local row={version=M.version,client=M.Client.family,patch=M.Client.patch,build=M.Client.build,
        interface=M.Client.interface,sourceMatched=M.Client.sourceMatched==true,
        clientEnabled=M.Client.allowed==true,native="NOT_RUN",issues={},selected=0,enabled=0}
    local function issue(code,text,blocking) row.issues[#row.issues+1]={code=code,text=text,blocking=blocking==true} end
    local activation=M.Diagnostics:ActivationState()
    row.activation=activation.code
    if not M.Client.allowed then issue(activation.code,activation.message.." "..activation.help,true) end
    if M.Profiles.readOnly then issue("PROFILE_READ_ONLY",activation.message.." "..activation.help,true) end
    if M.Safety:InCombat() then issue("LOCKDOWN","Finish setup outside combat.",true) end
    if M.state.safe then issue(activation.code,activation.message.." "..activation.help) end
    local ok,why=M.Profiles:CheckTransaction(p)
    row.profileValid=ok==true
    if not ok then issue("PROFILE_INVALID",why or "Settings are invalid.",true) end
    for _,entry in ipairs(M.Catalog) do
        if not entry.system and p and p.modules and p.modules[entry.id] and p.modules[entry.id].enabled then
            row.selected=row.selected+1
            if M:IsModuleActive(entry.id) then row.enabled=row.enabled+1 end
        end
    end
    if M.Native:Conflict() then issue("UI_OWNER","Another UI suite owns overlapping surfaces. Those MirageUI modules remain suspended.") end
    local package=M.BuildInfo:Inspect()
    M.BuildInfo:RecordReadiness(package)
    row.packageBuild=package.id;row.packageStatus=package.status;row.packages=package.components
    for _,component in ipairs(row.packages) do
        local v=component.version
        if component.status=="MISMATCH" or v~="UNAVAILABLE" and v~=M.version then
            issue("MIXED_PACKAGE","The "..component.name.." folder is from another release. Replace MirageUI and MirageUIOptions together.",true)
        elseif package.available and component.status=="UNAVAILABLE" then
            issue("MISSING_PACKAGE","The "..component.name.." release could not be verified. Install MirageUI and MirageUIOptions together.",true)
        end
    end
    if not package.available then issue("PACKAGE_METADATA_UNAVAILABLE","Installed release metadata is unavailable. Setup cannot verify both core package folders.",true) end
    row.canFinish=true
    for _,v in ipairs(row.issues) do if v.blocking then row.canFinish=false end end
    return row
end
function R:Summary(draft)
    local r=self:Inspect(draft)
    local lines={"MirageUI preflight: "..r.version,"Package: "..r.packageBuild.." / "..r.packageStatus,"Detected: "..r.client.." / "..r.patch.." / "..r.build.." / "..r.interface,
        "Selected modules: "..r.selected,"Native qualification: NOT_RUN (recorded session observations remain separate)"}
    for _,v in ipairs(r.issues) do lines[#lines+1]=v.text end
    return table.concat(lines,"\n"),r
end
function R:Export()
    local r=self:Inspect()
    local lines={"MIRAGE_PREFLIGHT=1","addon="..M.version,"client="..r.client,"patch="..r.patch,"build="..r.build,"interface="..r.interface,
        "profile_valid="..tostring(r.profileValid),"source_matched="..tostring(r.sourceMatched),"activation="..r.activation,"package_build="..r.packageBuild,"package_status="..r.packageStatus,"native=NOT_RUN"}
    for _,v in ipairs(r.packages) do
        lines[#lines+1]="package."..v.name.."="..v.version
        lines[#lines+1]="package_build."..v.name.."="..v.build
        lines[#lines+1]="package_status."..v.name.."="..v.status
    end
    for _,v in ipairs(r.issues) do lines[#lines+1]="issue="..v.code end
    return table.concat(lines,"\n")
end
