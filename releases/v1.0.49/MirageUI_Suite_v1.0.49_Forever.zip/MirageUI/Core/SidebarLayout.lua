local _,M=...
-- One runtime navigation column. Authored rectangles remain in saved storage;
-- these presentation rectangles and the conditional durability strip share width.
local S=M.Safety
local B={revision=10,defaultWidth=225,minWidth=195,maxWidth=315,ids={ ["Minimap.nativePosition"]=true,["QuestTracker.nativePosition"]=true }}
M.SidebarLayout=B
local function number(value,fallback) return S:Number(value) and value or fallback end
local function clamp(value,low,high) return math.max(low,math.min(high,value)) end
local function raw(profile,id,default)
 local layouts=profile and profile.layouts
 local stored=layouts and layouts[id]
 return type(stored)=="table" and stored or default
end
local progressNames={"MainStatusTrackingBarContainer","SecondaryStatusTrackingBarContainer"}
function B:ProgressRows(textScale)
 local height=math.max(20,12*textScale+8)
 local rows,total={},0
 local alerts=M.Rework and M.Rework.CombatAlerts
 for i,name in ipairs(progressNames) do
  local contents
  if alerts and type(alerts.ProgressContents)=="function" and _G[name] then contents=alerts:ProgressContents(_G[name]) end
  -- The native manager selects the live or pending bar, including during its
  -- transition. Its hidden preallocated templates do not reserve screen space.
  local track=0
  if contents then
   for _,bar in ipairs(contents) do
    local isXP,known=S:FieldAccess(bar,"isExpBar")
    track=math.max(track,known=="KNOWN" and isXP==true and math.min(10,height-2) or height-2)
   end
  elseif i==1 then
   -- The manager may load after the minimap. Keep the normal XP location until
   -- a public native selection can distinguish occupied and empty content.
   track=math.min(10,height-2)
  end
  if track>0 and total>0 then total=total+4 end
  rows[i]={height=height,trackHeight=track,center=total+(track>0 and track or 10)/2}
  if track>0 then total=total+track end
 end
 return rows,total,height
end
function B:Plan(profile)
 profile=profile or M.profile
 if not profile or not UIParent then return nil end
 local screenW,screenH
 if M.Layout and M.Layout.Screen then screenW,screenH=M.Layout:Screen()
 elseif M.Managed and M.Managed.Viewport then screenW,screenH=M.Managed:Viewport()
 else screenW=S:Public(UIParent.GetWidth,"number",UIParent);screenH=S:Public(UIParent.GetHeight,"number",UIParent) end
 if not screenW or not screenH or screenW<400 or screenH<300 then return nil end
 local authored=profile.layouts and profile.layouts["Minimap.nativePosition"]
 local original=raw(profile,"Minimap.nativePosition",{width=self.defaultWidth,height=self.defaultWidth,scale=1})
 local width=clamp(number(original.width,self.defaultWidth),self.minWidth,self.maxWidth)
 local scale=clamp(number(original.scale,1),.5,2)
 local textScale=clamp(number(profile.textScale,1),.65,2)
 local compact=M.Layout and M.Layout.CompactViewport and M.Layout:CompactViewport(profile)~=nil
 if compact then
  -- Narrow the column without shrinking its text or changing its authored
  -- dimensions. A chosen larger scale retains the existing readable minimum.
  width=math.min(width,math.max(self.minWidth,math.min(self.defaultWidth,screenW*.11/scale)))
 end
 local gap=8
 -- Map status and controls overlay the terrain. They reserve no exterior
 -- banner height, so one square root defines its full visible footprint.
 local header,footer=0,0
 local mapHeight=width
 -- Native row envelopes retain their tooltip/click height. Spacing follows
 -- the painted tracks instead: XP is 10 units high inside a 20-unit envelope.
 local progressRows,progressHeight,progressRowHeight=self:ProgressRows(textScale)
 local columnGaps=progressHeight>0 and gap*2 or gap
 local minimumTracker=math.max(160,120*textScale)
 local warning=M.Rework and M.Rework.DurabilityDisplay
 local warningHeight=warning and warning:ReserveHeight(profile) or 0
 local warningSpace=warningHeight>0 and warningHeight+gap or 0
 -- Screen units already include native UI scale. Reduce the common scale only
 -- when the column cannot contain a usable scroll viewport at that scale.
 scale=math.min(scale,(screenH-32)/(mapHeight+progressHeight+minimumTracker+columnGaps+warningSpace))
 scale=math.max(.25,math.min(scale,(screenW-32)/width))
 local margin=16
 local mapX=number(authored and original.x,.5-(width*scale/2+margin)/screenW)
 local mapY=number(authored and original.y,.5-(mapHeight*scale/2+margin)/screenH)
 if original.anchorTo and M.Layout and M.Layout.Position and M.surfaces[original.anchorTo] then
  -- The sidebar itself never links its children independently. A linked map
  -- position is resolved once so the saved link cannot accumulate three offsets.
  if not self.resolvingAnchor and not self.ids[original.anchorTo] then
   self.resolvingAnchor=true
   local ok,x,y=pcall(M.Layout.Position,M.Layout,original.anchorTo,profile)
   self.resolvingAnchor=nil
   if ok and S:Number(x) and S:Number(y) then mapX=mapX+x;mapY=mapY+y end
  end
 end
 local centerX=clamp(mapX*screenW,-screenW/2+margin+width*scale/2,screenW/2-margin-width*scale/2)
 local top=clamp(mapY*screenH+mapHeight*scale/2,-screenH/2+margin+(mapHeight+progressHeight+minimumTracker+columnGaps+warningSpace)*scale,screenH/2-margin)
 local trackerSource=raw(profile,"QuestTracker.nativePosition",{height=420})
 local available=(top+screenH/2-margin)/scale-mapHeight-progressHeight-columnGaps-warningSpace
 local desiredHeight=math.min(420,number(trackerSource.height,420))
 if compact then desiredHeight=math.min(desiredHeight,screenH*.48/scale) end
 local trackerHeight=clamp(desiredHeight,minimumTracker,math.max(minimumTracker,available))
 -- Meters belongs to the combat group and has its own bottom-right layout.
 -- Its selection, dimensions and visibility never resize this navigation set.
 local function rectangle(height,offset)
  return {x=centerX/screenW,y=(top-(offset+height/2)*scale)/screenH,width=width,height=height,scale=scale}
 end
 local rows={}
 for i,row in ipairs(progressRows) do
  rows[i]=rectangle(row.height,mapHeight+gap+row.center-row.height/2)
  rows[i].trackHeight=row.trackHeight
 end
 return {map=rectangle(mapHeight,0),
  progression=rectangle(math.max(1,progressHeight),mapHeight+gap),progressRows=rows,progressVisibleHeight=progressHeight,
  objectives=rectangle(trackerHeight,mapHeight+progressHeight+columnGaps),width=width,scale=scale,gap=gap,header=header,footer=footer,
  progressRowHeight=progressRowHeight,textScale=textScale,screenWidth=screenW,screenHeight=screenH,durabilityHeight=warningHeight}
end
function B:ProgressLayout(id,profile)
 local plan=self:Plan(profile);if not plan then return nil end
 local secondary=id=="NativeControls.SecondaryStatusTrackingBarContainer"
 local r=M:Copy(plan.progressRows[secondary and 2 or 1]);r.trackHeight=nil
 return r
end
function B:RefreshProgression(source)
 if S:InCombat() then return false end
 local alerts=M.Rework and M.Rework.CombatAlerts
 if not alerts or not alerts.active then return false end
 local profile,generation=M.profile,alerts.generation
 local plan=self:Plan(profile);if not plan then return false end
 if M.profile~=profile or not alerts.active or alerts.generation~=generation or S:InCombat() then return false end
 local key=table.concat({plan.map.x,plan.map.y,plan.width,plan.scale,plan.progressRowHeight,plan.progressVisibleHeight,
  plan.progressRows[1].y,plan.progressRows[2].y,plan.objectives.y,plan.objectives.height},":")
 if self.progressionKey==key and self.progressionProfile==profile and self.progressionGeneration==generation then return true end
 self.progressionKey=key;self.progressionProfile=profile;self.progressionGeneration=generation
 -- Coalesce through the existing provider queues. A native bar-selection
 -- callback never recursively paints another root or reapplies the profile.
 local objectives=M.Rework.Objectives
 if objectives and objectives.active then objectives.layoutDirty=true end
 if type(alerts.MarkRoot)=="function" then
  for _,name in ipairs({progressNames[1],progressNames[2],"StatusTrackingBarManager","DurabilityFrame"}) do
   local row=alerts.roots and alerts.roots[name]
   if row and row.frame~=source then alerts:MarkRoot(row,"geometry") end
  end
 end
 return true
end
function B:Resolve(id,fallback,profile)
 if not self.ids[id] then return fallback end
 local plan=self:Plan(profile)
 if not plan then return fallback end
 local row=id=="Minimap.nativePosition" and plan.map or plan.objectives
 return M:Copy(row)
end
function B:RefreshFollowers()
 if self.refreshing or S:InCombat() then return false end
 self.refreshing=true
 for _,id in ipairs({"QuestTracker.nativePosition"}) do
  local surface=M.surfaces and M.surfaces[id]
  if surface and surface.frame and not surface.disabled then
   local ok,applied=pcall(M.Layout.Apply,M.Layout,surface)
   if not ok or applied==false then surface.layoutPending=true end
  end
 end
 -- The passive warning follows the actual collapsed/content-fitted Quest
 -- bottom. It never moves or restores the native equipment diagram.
 local warning=M.Rework and M.Rework.DurabilityDisplay
 if warning and warning.frame and warning.provider and warning.provider.active then
  local okay,applied=pcall(warning.ApplyLayout,warning)
  if not okay or applied==false then warning.layoutDirty=true end
 end
 self.refreshing=nil
 return true
end
local get=M.Layout.Get
function M.Layout:Get(surface,profile)
 local result=get(self,surface,profile)
 if surface and B.ids[surface.id] then return B:Resolve(surface.id,result,profile or M.profile) end
    profile=profile or M.profile
    local extra=surface and (surface.id=="ActionBars.bar4" and 0 or surface.id=="ActionBars.bar5" and 1)
    if extra~=nil and extra~=false and profile and profile.managed and not (profile.layouts and profile.layouts[surface.id]) then
        -- Unauthored vertical utility bars used to occupy the objective column.
        -- Keep their button geometry and slot order; place the default lanes
        -- just to the left of the shared column. Authored bar anchors win.
        local plan=B:Plan(profile)
        if plan then
            local width=result.width*(result.scale or 1)
            local left=plan.map.x*plan.screenWidth-plan.map.width*plan.scale/2
            result.x=(left-10-width/2-extra*(width+6))/plan.screenWidth
            return self:Clamp(result)
        end
    end
 return result
end
