local _, M = ...
M.ActionEditing={status="DISABLED"}
local E,S=M.ActionEditing,M.Safety
local accepted={spell=true,item=true,macro=true,flyout=true,action=true}
function E:Allowed(button,dropping)
    if not M:IsModuleActive("ActionBars") or M.Native:Conflict() or (not M.profile.modules.ActionBars.allowRearrange and not M.state.keybindWorkspace) then return false,"DISABLED" end
    if M.Profiles.readOnly or S:InCombat() or M.state.cinematic or not M.state.world then return false,"EDIT_LOCKED" end
    local frameOK=S:Frame(button,false)
    if not frameOK then return false,"UNAVAILABLE_BUTTON" end
    local visible,known=S:Public(button.IsVisible,"boolean",button)
    if known~="KNOWN" or not visible then return false,"HIDDEN_BUTTON" end
    if not dropping and not M.state.keybindWorkspace then
        local modifier,ms=S:Public(IsModifiedClick,"boolean","PICKUPACTION")
        if ms~="KNOWN" or not modifier then return false,"HOLD_PICKUP_MODIFIER" end
    end
    local slot,ss=S:Public(button.GetAttribute,"number",button,"action")
    if ss~="KNOWN" or slot<1 or slot>180 or slot%1~=0 then return false,"UNAVAILABLE_SLOT" end
    return true,slot
end
function E:CursorKind()
    if type(GetCursorInfo)~="function" then return nil,false end
    local ok,kind=pcall(GetCursorInfo)
    if not ok or not S:Readable(kind) or (kind~=nil and type(kind)~="string") then return nil,false end
    return kind,true
end
function E:Pickup(button,mouseButton)
    if mouseButton~="LeftButton" then return false end
    local allowed,slot=self:Allowed(button)
    if not allowed then self.status=slot;return false end
    local kind,readable=self:CursorKind()
    if not readable or kind~=nil then self.status="CURSOR_OCCUPIED_OR_UNAVAILABLE";return false end
    if type(PickupAction)~="function" then self.status="UNSUPPORTED";return false end
    local ok=pcall(PickupAction,slot)
    self.status=ok and "NATIVE_PICKUP_REQUESTED" or "NATIVE_EDIT_FAILED"
    if ok then
        M.modules.ActionBars.iconsDirty=true;M.modules.ActionBars.cooldownsDirty=true
        if M.KeybindWorkspace then M.KeybindWorkspace:PlacementChanged(slot) end
    end
    return ok
end
function E:Drop(button)
    local allowed,slot=self:Allowed(button,true)
    if not allowed then self.status=slot;return false end
    local kind,readable=self:CursorKind()
    if not readable or not accepted[kind or ""] then self.status="UNSUPPORTED_CURSOR_CONTENT";return false end
    if type(PlaceAction)~="function" then self.status="UNSUPPORTED";return false end
    local ok=pcall(PlaceAction,slot)
    -- Never clear or discard the displaced action left on the native cursor.
    self.status=ok and "NATIVE_PLACE_REQUESTED" or "NATIVE_EDIT_FAILED"
    if ok then
        M.modules.ActionBars.iconsDirty=true;M.modules.ActionBars.cooldownsDirty=true
        if M.KeybindWorkspace then M.KeybindWorkspace:PlacementChanged(slot) end
    end
    return ok
end
