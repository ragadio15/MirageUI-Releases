-- Reversible native geometry. Managed mode uses the ManagedNative lease;
-- legacy mode retains the original three-root positional adapter.
local _, M = ...
local S=M.Safety
M.NativeLayout={roots={Minimap="MinimapCluster",Chat="ChatFrame1",QuestTracker="ObjectiveTrackerFrame"},rows={}}
local L=M.NativeLayout
local actionRoots={ ["ActionBars.bar1"]="MainActionBar",["ActionBars.bar2"]="MultiBarBottomLeft",["ActionBars.bar3"]="MultiBarBottomRight",
 ["ActionBars.bar4"]="MultiBarRight",["ActionBars.bar5"]="MultiBarLeft",["ActionBars.bar6"]="MultiBar5",["ActionBars.bar7"]="MultiBar6",["ActionBars.bar8"]="MultiBar7" }
local rootIDs={MainActionBar="ActionBars.bar1",MultiBarBottomLeft="ActionBars.bar2",MultiBarBottomRight="ActionBars.bar3",MinimapCluster="Minimap.nativePosition",ChatFrame1="Chat.nativePosition",ObjectiveTrackerFrame="QuestTracker.nativePosition"}
local rootModules={MainActionBar="ActionBars",MultiBarBottomLeft="ActionBars",MultiBarBottomRight="ActionBars",MinimapCluster="Minimap",ChatFrame1="Chat",ObjectiveTrackerFrame="QuestTracker"}
actionRoots["UnderCharacterHUD.nativeCast"]="PlayerCastingBarFrame"
local navigation={Minimap=true,Chat=true,QuestTracker=true}
for id,name in pairs(actionRoots) do rootIDs[name]=id;rootModules[name]="ActionBars" end
for _,name in ipairs({"PetActionBar","StanceBar","BagsBar","MicroMenuContainer","MainStatusTrackingBarContainer","SecondaryStatusTrackingBarContainer"}) do
 actionRoots["NativeControls."..name]=name;rootIDs[name]="NativeControls."..name;rootModules[name]="ActionBars"
end
rootModules.PlayerCastingBarFrame="UnderCharacterHUD"
L.rootIDs=rootIDs
-- Property ownership is independent of custom presentation and visibility.
-- These two native systems must never enter a Mirage geometry writer, including
-- automatic-plan fallback, imported dormant layouts, or native reflow retries.
local delegated={BagsBar=true,MicroMenuContainer=true,MicroMenu=true}
function L:IsDelegated(idOrRoot)
 return delegated[idOrRoot]==true or delegated[actionRoots[idOrRoot]]==true
end
local function screen()
 local w,ws=S:Public(UIParent.GetWidth,"number",UIParent)
 local h,hs=S:Public(UIParent.GetHeight,"number",UIParent)
 if ws=="KNOWN" and hs=="KNOWN" and w>32 and h>32 then return w,h end
end
local function legal(layout)
 return type(layout)=="table" and S:Number(layout.x) and S:Number(layout.y) and
  S:Number(layout.width) and S:Number(layout.height) and S:Number(layout.scale) and
  layout.width>0 and layout.height>0 and layout.scale>0
end
local function observedControl(name)
 local observed=M.Elements and M.Elements:Measure(_G[name])
 if not observed then return nil end
 local width,height=observed.width*observed.scale,observed.height*observed.scale
 -- Saved Layout envelopes have finite bounds, but a native progress row can be
 -- thinner or wider. Use a legal fitting envelope for a deliberate edit; the
 -- runtime/preview still preserve the native row's actual aspect and footprint.
 local scale=math.max(.6,math.min(1.6,observed.scale),width/1200,height/800)
 if scale>1.6 then return nil end
 return {x=observed.x,y=observed.y,width=math.max(24,width/scale),height=math.max(16,height/scale),scale=scale}
end
function L:RootFor(id)
 if actionRoots[id] then return actionRoots[id] end
 for module,name in pairs(self.roots) do if id==module..".nativePosition" then return name end end
end
function L:RequiresMoveOption(id)
 local name=self:RootFor(id)
 return name and navigation[rootModules[name]]==true or false
end
-- The automatic native plan is also the editing origin. This prevents the
-- first drag from starting at unrelated catalog defaults. Return an authored
-- envelope in the shared Layout units; PreviewGeometry applies native aspect fit.
function L:DraftLayout(id,profile)
 if self:IsDelegated(id) then return nil,"BLIZZARD_GEOMETRY" end
 profile=profile or M.profile
 local name=self:RootFor(id);local module=name and rootModules[name]
 if not name or not profile or not profile.managed then return nil end
 local cfg=profile.modules and profile.modules[module]
 if not cfg or cfg.enabled==false or (navigation[module] and cfg.moveNative~=true) then return nil end
 -- Newly exposed native controls have no authored Mirage position. Their public
 -- current bounds are the draft origin until a deliberate edit saves a layout;
 -- merely opening Customize never invents or writes a placement preference.
 if not profile.autoLayout then
  if navigation[module] or legal(profile.layouts and profile.layouts[id]) then return nil end
  local observed=observedControl(name)
  if observed then return observed,"OBSERVED_NATIVE_CONTROL" end
  return nil,"NATIVE_CONTROL_UNAVAILABLE"
 end
 -- The optional matched tracker has a distinct reversible style owner. Capture
 -- its public current center, rather than resurrecting an older inactive manual
 -- layout when an unrelated display switches the draft out of automatic mode.
 if name=="ObjectiveTrackerFrame" and cfg.style and cfg.matchMinimap and profile.modules.Minimap.square then
  local observed=M.Elements and M.Elements:Measure(_G[name])
  if observed then
   local pw,ph=observed.width*observed.scale,observed.height*observed.scale
   local scale=math.max(.6,math.min(1.6,observed.scale),pw/1200,ph/800)
   if scale<=1.6 and pw/scale>=24 and ph/scale>=16 then
    return {x=observed.x,y=observed.y,width=pw/scale,height=ph/scale,scale=scale},"OBSERVED_MATCHED_MINIMAP_COLUMN"
   end
  end
  return nil,"MATCHED_MINIMAP_COLUMN_UNAVAILABLE"
 end
 local w,h=screen();if not w then return nil end
 local hud=profile.modules.UnderCharacterHUD
 local central=profile.modules.Cooldowns.centralGroup==true and hud.layoutOrder==2
 local reference=profile.modules.UnitFrames.referenceLayout
 local signature=M.AdaptiveLayout:Signature(w,h,hud,central,reference)
 local plan
 if self.draftProfile==profile and self.draftSignature==signature then plan=self.draftPlan end
 if not plan then
  plan=M.AdaptiveLayout:Plan(w,h,hud,central,reference)
  self.draftProfile=profile;self.draftSignature=signature;self.draftPlan=plan
 end
 local geometry=plan and plan.native[name]
 if not geometry then
  if not navigation[module] then
   local observed=observedControl(name)
   if observed then return observed,"OBSERVED_NATIVE_CONTROL" end
  end
  return nil
 end
 return {x=geometry.x/w,y=geometry.y/h,width=geometry.width or geometry.maxW,height=geometry.height or geometry.maxH,scale=1},"AUTOMATIC_NATIVE_PLAN"
end
-- Call inside the editor's single draft transaction before autoLayout becomes
-- false. Seeding the other mapped roots preserves their automatic positions when
-- one display is moved. Deliberately disabled movement/modules remain untouched.
function L:SeedManualLayouts(profile)
 if not profile or not profile.managed or not profile.autoLayout then return false end
 local layouts={}
 for name,id in pairs(rootIDs) do
  local layout,reason=self:DraftLayout(id,profile)
  if reason=="MATCHED_MINIMAP_COLUMN_UNAVAILABLE" then
   return false,"The matched quest tracker cannot be measured safely. Keep this draft and retry after its native display is available."
  end
  -- The player cast remains attached to the HUD-authored slot until its own
  -- entry is deliberately edited. Seeding it during an unrelated HUD movement
  -- would turn that shared placement into a stale independent override.
  if layout and reason~="OBSERVED_NATIVE_CONTROL" and id~="UnderCharacterHUD.nativeCast" then layouts[id]=layout end
 end
 for id,layout in pairs(layouts) do profile.layouts[id]=M:Copy(layout) end
 return true
end
-- A pure projection of a proposed layout through the same public root-size
-- constraints used by ManagedNative:Position. It never substitutes live anchors
-- for draft coordinates or changes a saved profile. A native root is an envelope;
-- child artwork/content can extend beyond it and remains Blizzard-owned.
function L:PreviewGeometry(id,layout,profile)
 if self:IsDelegated(id) then return nil,"BLIZZARD_GEOMETRY" end
 local name=self:RootFor(id)
 if not name or not legal(layout) then return nil,"NO_NATIVE_GEOMETRY" end
 if S:InCombat() then return nil,"NATIVE_GEOMETRY_DEFERRED" end
 profile=profile or M.profile
 if not profile or not profile.managed then return nil,"LEGACY_GEOMETRY" end
 local f=_G[name]
 if not S:Frame(f,false) then return nil,"NATIVE_GEOMETRY_UNAVAILABLE" end
 local w,ws=S:Public(f.GetWidth,"number",f);local h,hs=S:Public(f.GetHeight,"number",f)
 if ws~="KNOWN" or hs~="KNOWN" or w<=0 or h<=0 then return nil,"NATIVE_GEOMETRY_UNAVAILABLE" end
 if name=="ChatFrame1" then
  return {x=layout.x,y=layout.y,width=layout.width,height=layout.height,scale=layout.scale},"RESIZABLE_NATIVE_ROOT"
 end
 local scale=math.min(layout.width*layout.scale/w,layout.height*layout.scale/h,1.2)
 if scale<.45 then return nil,"NATIVE_LAYOUT_FALLBACK" end
 return {x=layout.x,y=layout.y,width=w,height=h,scale=scale},"NATIVE_ASPECT_FIT"
end
-- Automatic placement is explicit. Manual mode consumes the corresponding saved
-- editor layout; a missing layout leaves the native root in its current location.
-- Turning off moveNative never gives the automatic planner permission to move it.
function L:Geometry(name,profile,fallback)
 if self:IsDelegated(name) then return nil end
 profile=profile or M.profile
 local id=rootIDs[name];local module=rootModules[name]
 if not id or not profile then return fallback end
 local cfg=profile.modules and profile.modules[module]
 if navigation[module] and (not cfg or cfg.moveNative~=true) then return nil end
 if profile.autoLayout then return fallback end
 local layout=profile.layouts and profile.layouts[id]
 if not legal(layout) then return name=="PlayerCastingBarFrame" and fallback or nil end
 local w,h=screen();if not w then return nil end
 layout=M.Layout:Clamp(M:Copy(layout))
 if layout.anchorTo and M.surfaces[layout.anchorTo] then
  local ax,ay=M.Layout:Position(layout.anchorTo,profile);layout.x,layout.y=layout.x+ax,layout.y+ay
 end
 local result={x=layout.x*w,y=layout.y*h,maxW=layout.width*layout.scale,maxH=layout.height*layout.scale,group=module=="ActionBars" and "actions" or module}
 -- Chat has a public resizable root. Other native roots retain native child
 -- arrangements and aspect ratio; their saved dimensions are a fitting envelope.
 if name=="ChatFrame1" then result.width=result.maxW;result.height=result.maxH end
 return result
end
local function snapshot(f)
    local count,status=S:Public(f.GetNumPoints,"number",f)
    if status~="KNOWN" or count<0 or count>8 or count%1~=0 then return nil end
    local points={}
    for i=1,count do
        local ok,a,b,c,d,e=pcall(f.GetPoint,f,i)
        if not ok or not S:Text(a) or not S:Readable(b) or not S:Text(c) or not S:Number(d) or not S:Number(e) then return nil end
        points[i]={a,b,c,d,e}
    end
    return points
end
local function same(a,b)
    if not a or not b or #a~=#b then return false end
    for i,p in ipairs(a) do for j=1,5 do if p[j]~=b[i][j] then return false end end end
    return true
end
-- Record only readback-confirmed intermediate writes. An outstanding intended
-- value may be recognized later after an opaque read; arbitrary divergence is
-- never adopted as our own mutation.
local function observe(row)
    local current=snapshot(row.native)
    if current then
        if row.attempted and same(current,row.attempted) then row.written=current end
        row.attempted=nil
    end
    return current
end
local function writePoints(row,target)
    row.attempted={}
    local fn=M.Rework and M.Rework.NativeMethod and M.Rework.NativeMethod(row.native,"ClearAllPoints")
    local ok=pcall(fn or row.native.ClearAllPoints,row.native)
    local current=observe(row)
    if not ok or not same(current,{}) then return false end
    local prefix={}
    for i,point in ipairs(target) do
        prefix[i]=point;row.attempted=prefix
        fn=M.Rework and M.Rework.NativeMethod and M.Rework.NativeMethod(row.native,"SetPoint")
        ok=pcall(fn or row.native.SetPoint,row.native,unpack(point,1,5))
        current=observe(row)
        if not ok or not same(current,prefix) then return false end
    end
    return true
end
function L:Restore(module,automatic)
    local row=self.rows[module]
    if not row or not row.original then return true end
    if automatic and (row.restoreFailures or 0)>=3 then return false end
    if S:InCombat() then row.pending=true;return false end
    local function pending(reason)
        row.pending=true;row.restoreFailures=(row.restoreFailures or 0)+1
        row.status=row.restoreFailures>=3 and "RESTORE_RELOAD_REQUIRED" or reason
        return false
    end
    if not S:Frame(row.native,true) or not S:ChildTreePublic(row.native) then return pending("ANCHOR_UNAVAILABLE") end
    local current=observe(row)
    if not current then return pending("ANCHOR_UNAVAILABLE") end
    if not same(current,row.original) and same(current,row.written) then
        writePoints(row,row.original)
        current=observe(row)
        if not current then return pending("ANCHOR_UNAVAILABLE") end
        if not same(current,row.original) and same(current,row.written) then return pending("ANCHOR_RESTORE_UNCONFIRMED") end
    end
    -- Confirmed original or readable divergence belongs to native/newer owners.
    if not same(current,row.original) then row.changedElsewhere=true end
    row.original=nil;row.written=nil;row.attempted=nil;row.pending=nil;row.restoreFailures=0
    row.status="RESTORED_OR_NEWER_OWNER_PRESERVED"
    return true
end
function L:Place(module)
    local row=self.rows[module];local cfg=M:ModuleConfig(module)
    if not row or row.pending or row.positionFailed or not cfg or not cfg.moveNative or not M:IsModuleActive(module) or S:InCombat() or M.Native:Conflict() then return false end
    if M.profile and M.profile.managed then
        -- Module ApplyConfig runs before ManagedNative:Configure. Keep only one
        -- reversible writer for a native root, otherwise each adapter mistakes
        -- the other's position for an external owner and manual placement loses.
        if not self:Restore(module) then return false end
        row.status="MANAGED_NATIVE_GEOMETRY";return true
    end
    if not S:Frame(row.native,true) or not S:ChildTreePublic(row.native) then row.status="NATIVE_GEOMETRY_PRESERVED";return false end
    local before=observe(row)
    if not before or #before==0 then row.status="ANCHOR_UNAVAILABLE";return false end
    if row.written and not same(before,row.written) then
        row.status="NEWER_OWNER_PRESERVED";row.changedElsewhere=true;return false
    end
    if row.changedElsewhere then return false end
    row.original=row.original or before
    local target={{"CENTER",row.anchor,"CENTER",0,0}}
    if not writePoints(row,target) then
        row.pending=true;row.positionFailed=true
        self:Restore(module)
        if not row.pending then row.status="POSITION_FAILED_TOGGLE_OPTION_TO_RETRY" end
        return false
    end
    row.status="EXPLICIT_NATIVE_POSITION";return true
end
function L:Configure(module)
    local root=self.roots[module];local cfg=M:ModuleConfig(module)
    if not root then return end
    if not cfg.moveNative or not M:IsModuleActive(module) then
        self:Restore(module)
        local r=self.rows[module];if r then r.surface.editable=false;r.changedElsewhere=nil;r.positionFailed=nil end
        return
    end
    if S:InCombat() or M.Native:Conflict() then return end
    local native=_G[root]
    if not S:Frame(native,true) or not S:ChildTreePublic(native) then return end
    local row=self.rows[module]
    if row and row.native~=native then
        if not self:Restore(module) then return end
        row.native=native;row.changedElsewhere=nil
    end
    if not row then
        local w=S:Public(native.GetWidth,"number",native);local h=S:Public(native.GetHeight,"number",native)
        if not w or not h or w<=0 or h<=0 then return end
        local x,y
        if type(native.GetCenter)=="function" then local ok,a,b=pcall(native.GetCenter,native);if ok and S:Number(a) and S:Number(b) then x,y=a,b end end
        if not x or not y then return end
        local ns=S:Public(native.GetEffectiveScale,"number",native)
        local us=S:Public(UIParent.GetEffectiveScale,"number",UIParent)
        if not ns or not us or ns<=0 or us<=0 then return end
        x,y=x*ns/us,y*ns/us;w,h=w*ns/us,h*ns/us
        local sw,sh=UIParent:GetWidth(),UIParent:GetHeight()
        if w>sw-16 or h>sh-16 then return end
        local a=CreateFrame("Frame",nil,UIParent);S:Passive(a);a:Hide()
        row={native=native,anchor=a,status="WAITING"};self.rows[module]=row
        row.surface={id=module..".nativePosition",module=module,frame=a,security="OWNED_VISUAL",groups={},fallback="HIDDEN",disabled=true,editable=true,
            minWidth=M.profile.managed and 24 or math.max(24,w),minHeight=M.profile.managed and 16 or math.max(16,h),layout={x=x and x/sw-.5 or 0,y=y and y/sh-.5 or 0,width=w,height=h,scale=1}}
        row.surface.OnLayout=function() self:Place(module) end
        M.CVE:Register(row.surface)
    end
    row.surface.editable=true;M.Layout:Apply(row.surface)
end
function L:Retry()
    if S:InCombat() then return end
    for module,row in pairs(self.rows) do if row.pending then self:Restore(module,true) end end
end
