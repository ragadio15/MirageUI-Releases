local _, M = ...
-- Explicit native-property leases. Not a global skin hook; no health/identity reads.
-- Only restore a property when it still equals our last write. Native/newer owners win.
M.StyleLease={rows={}}
local L=M.StyleLease
local utilityProperties={utilityGlyphAlpha=true,utilityHighlightSource=true,utilityHighlightTint=true}
local function admitted(owner,object,key)
 if M.Safety:Frame(object,true) then return true end
 -- The utility presenter privately registers exact native cosmetic regions
 -- beneath its reviewed context gate. All other keys retain public-tree
 -- admission; this never admits a protected frame, input or layout mutation.
 local presenter=M.NativePresentation
 return utilityProperties[key]==true and presenter and type(presenter.UtilityLeaseAdmission)=="function"
  and presenter:UtilityLeaseAdmission(owner,object,key)==true or false
end
local function utilityCurrent(owner,object,key)
 if not utilityProperties[key] then return true end
 local presenter=M.NativePresentation
 return presenter and type(presenter.UtilityLeaseAdmission)=="function"
  and presenter:UtilityLeaseAdmission(owner,object,key)==true or false
end
local function same(a,b,key)
 if type(a)~="table" or type(b)~="table" or #a~=#b then return false end
 local shared=M.Rework and M.Rework.CombatLeases
 for i=1,#a do
  if not M.Safety:Readable(a[i]) or not M.Safety:Readable(b[i]) then return false end
  if type(a[i])=="number" and not M.Safety:Number(a[i]) or type(b[i])=="number" and not M.Safety:Number(b[i]) then return false end
  if shared and key=="texture" and i==1 then
   if not (a[2]~=false and a[2]==b[2]) and not shared:AssetEqual(a[i],b[i]) then return false end
  elseif shared and key=="font" and i==1 then
   if not shared:AssetEqual(a[i],b[i]) then return false end
  elseif shared and (key=="height" or key=="shadowOffset" or key=="font" and i==2 or key=="points" and (i%5==4 or i%5==0)) then
   if not shared:GeometryEqual(a[i],b[i]) then return false end
  elseif key=="color" and M.Safety:Number(a[i]) and M.Safety:Number(b[i]) then
   if shared and shared.ColorEqual then
    if not shared:ColorEqual(a[i],b[i]) then return false end
   elseif math.abs(a[i]-b[i])>.000001 then return false end
  elseif a[i]~=b[i] then return false end
 end
 return true
end
local function observe(getter,object)
 local ok,current=pcall(getter,object)
 if not ok or not M.Safety:Readable(current) or type(current)~="table" then return nil end
 local checked,readable=pcall(same,current,current)
 if checked and readable then return current end
end
function L:Write(owner,object,key,getter,setter,value,kind)
 if M.Safety:InCombat() or M.Native:Conflict() or not admitted(owner,object,key) then return false end
 local current=observe(getter,object)
 if not current or not M.Safety:Readable(value) or not utilityCurrent(owner,object,key) then return false end
 local checked,readable=pcall(same,value,value);if not checked or not readable then return false end
 local record
 for _,r in ipairs(self.rows) do if r.object==object and r.key==key then record=r;break end end
 if record and (record.owner~=owner or record.pending or record.reloadRequired or record.displaced) then return false end
 if not record then
  if #self.rows>=1280 then return false end
  record={owner=owner,object=object,key=key,kind=kind or key,get=getter,set=setter,original=current};self.rows[#self.rows+1]=record
 elseif record.written and not same(current,record.written,record.kind) then
  record.displaced=true;return false
 end
 if same(current,value,record.kind) then
  if not utilityCurrent(owner,object,key) then record.pending=true;return false end
  record.written=current;return true
 end
 -- An attempted mutation is not a confirmed lease. Opaque readback retains
 -- only the exact attempted target, never an inferred partial value.
 record.attempt=value
 if not utilityCurrent(owner,object,key) then record.pending=true;return false end
 local sent,result=pcall(setter,object,value)
 local observed=observe(getter,object)
 if not utilityCurrent(owner,object,key) then record.pending=true;self.status="RESTORE_REQUIRED";return false end
 if observed and same(observed,value,record.kind) then
  if not utilityCurrent(owner,object,key) then record.pending=true;return false end
  record.written=observed;record.attempt=nil
  if sent and result~=false then return true end
 elseif observed then
  record.attempt=nil
  if not sent or result==false then record.written=observed
  elseif not same(observed,current,record.kind) then record.displaced=true;return false end
 end
 record.pending=true;self.status="RESTORE_REQUIRED"
 -- Rollback is itself verified and bounded, using the normal handback path.
 if observed then self:Restore(owner,object) end
 return false
end
function L:Height(owner,object,height)
 if not M.Safety:Number(height) or type(object and object.GetHeight)~="function" or type(object.SetHeight)~="function" then return false end
 return self:Write(owner,object,"height",function(o)
  local v=M.Safety:Public(o.GetHeight,"number",o);if not v then return nil end;return {v}
 end,function(o,v) o:SetHeight(v[1]) end,{height})
end
function L:Font(owner,object,size,plain)
 if not M.Safety:Number(size) or size<=0 or type(object and object.GetFont)~="function" or type(object.SetFont)~="function" then return false end
 local function get(o)
  local ok,path,s,flags=pcall(o.GetFont,o)
  if not ok or not M.Safety:Text(path) or path=="" or not M.Safety:Number(s) or s<=0 or (flags~=nil and not M.Safety:Text(flags)) then return nil end
  return {path,s,flags or ""}
 end
 local current=get(object);if not current then return false end
 return self:Write(owner,object,"font",get,function(o,v) return o:SetFont(v[1],v[2],v[3]) end,{current[1],size,plain and "" or current[3]})
end
function L:Bar(owner,bar)
 if not bar or type(bar.GetStatusBarTexture)~="function" or type(bar.SetStatusBarTexture)~="function" then return false end
 local function get(o)
  local t=M.Safety:Public(o.GetStatusBarTexture,nil,o)
  if not M.Safety:Frame(t,true) then return nil end
  local shared=M.Rework and M.Rework.CombatLeases
  if shared and shared.TextureSource then
   local path,atlas=shared:TextureSource(t)
   if path==nil or path==false and atlas==false then return nil end
   return {path,atlas}
  end
  local texture=M.Safety:Public(t.GetTexture,nil,t)
  local atlas=M.Safety:Public(t.GetAtlas,"string",t)
  if texture==nil and atlas==nil then return nil end
  if texture~=nil and not M.Safety:Text(texture) and not M.Safety:Number(texture) then return nil end
  return {texture or false,atlas or false}
 end
 local function set(o,v)
  return o:SetStatusBarTexture(v[2]~=false and v[2] or v[1])
 end
 local shared=M.Rework and M.Rework.CombatLeases
 if shared and shared.PrepareAsset then shared:PrepareAsset("Interface\\Buttons\\WHITE8X8") end
 return self:Write(owner,bar,"texture",get,set,{"Interface\\Buttons\\WHITE8X8",false})
end
-- Public scalar appearance leases; no field reflects combat health or aura contents.
function L:Color(owner,object,key,getName,setName,color)
 if type(object and object[getName])~="function" or type(object[setName])~="function" then return false end
 return self:Write(owner,object,key,function(o)
  local ok,a,b,c,d=pcall(o[getName],o)
  if not ok or not M.Safety:Number(a) or not M.Safety:Number(b) or not M.Safety:Number(c) or (d~=nil and not M.Safety:Number(d)) then return nil end
  return {a,b,c,d or 1}
 end,function(o,v) return o[setName](o,unpack(v)) end,{color[1],color[2],color[3],color[4] or 1},"color")
end
function L:Name(owner,font,unit,size)
 if not self:Font(owner,font,size,true) then return false end
 local c=M.Visual:ClassColor(unit)
 self:Color(owner,font,"nameColor","GetTextColor","SetTextColor",c)
 self:Color(owner,font,"nameShadow","GetShadowColor","SetShadowColor",{0,0,0,0})
 if type(font.GetShadowOffset)=="function" and type(font.SetShadowOffset)=="function" then
  self:Write(owner,font,"shadowOffset",function(o)
   local ok,x,y=pcall(o.GetShadowOffset,o)
   if ok and M.Safety:Number(x) and M.Safety:Number(y) then return {x,y} end
  end,function(o,v) o:SetShadowOffset(v[1],v[2]) end,{0,0})
 end
 return true
end
function L:Restore(owner,object)
 local retained={}
 local function pending(r)
  r.retries=(r.retries or 0)+1
  if r.retries>=3 then r.pending=nil;r.reloadRequired=true;self.status="RELOAD_REQUIRED"
  else r.pending=true end
  retained[#retained+1]=r
 end
 for _,r in ipairs(self.rows) do
  local retainedBefore=#retained
  if (owner and r.owner~=owner) or (object and r.object~=object) then retained[#retained+1]=r
  elseif M.Safety:InCombat() then
   r.pending=not r.reloadRequired or nil;retained[#retained+1]=r
  elseif not admitted(r.owner,r.object,r.key) then
   if (r.retries or 0)>=3 then r.pending=nil;r.reloadRequired=true;retained[#retained+1]=r;self.status="RELOAD_REQUIRED"
   else pending(r) end
  else
   local current=observe(r.get,r.object)
   if not r.displaced then
    if not current then
     if (r.retries or 0)>=3 then r.pending=nil;r.reloadRequired=true;retained[#retained+1]=r;self.status="RELOAD_REQUIRED"
     else pending(r) end
    elseif same(current,r.original,r.kind) then
     -- Already restored, including an earlier setter whose readback failed.
    elseif r.attempt and not same(current,r.attempt,r.kind) and not same(current,r.written,r.kind) then
     -- The opaque attempt may have partially changed the value; a later
     -- arbitrary value proves neither ownership nor a newer writer.
     if (r.retries or 0)>=3 then r.pending=nil;r.reloadRequired=true;retained[#retained+1]=r;self.status="RELOAD_REQUIRED"
     else pending(r) end
    elseif same(current,r.written,r.kind) or (r.attempt and same(current,r.attempt,r.kind)) then
    r.written=current;r.attempt=nil
    if (r.retries or 0)>=3 then r.pending=nil;r.reloadRequired=true;retained[#retained+1]=r;self.status="RELOAD_REQUIRED"
    else
     local restored,result=pcall(r.set,r.object,r.original)
     local observed=observe(r.get,r.object)
     if not restored or result==false or not observed or not same(observed,r.original,r.kind) then
      -- A failed multi-point restoration can have cleared some anchors. Retain
      -- our own partial result for a bounded retry, not as a later owner's edit.
      if (not restored or result==false) and observed then r.written=observed end
      if not observed then r.attempt=r.original end
      pending(r)
     end
    end
    end
    -- Only a readable value different from both original and last write proves
    -- displacement. Leave that newer writer untouched and release our lease.
   end
  end
  -- Utility source comparisons may invoke a native asset alias lookup. Keep
  -- the exact receipt if that callback retires custody before success is
  -- published; ordinary style-property behavior is unchanged.
  if #retained==retainedBefore and utilityProperties[r.key] and not utilityCurrent(r.owner,r.object,r.key) then pending(r) end
 end
 self.rows=retained
end
function L:Retry()
 if M.Safety:InCombat() then return end
 local owners={};for _,r in ipairs(self.rows) do if r.pending then owners[r.owner]=true end end
 for owner in pairs(owners) do self:Restore(owner) end
end
-- Fixed public anchors, with no reparenting or combat-time layout mutation.
function L:Points(owner,frame,key,relative,point,relativePoint,x,y)
 if not M.Safety:Frame(relative,true) or not M.Safety:Number(x) or not M.Safety:Number(y) then return false end
 if type(frame.GetNumPoints)~="function" or type(frame.GetPoint)~="function" then return false end
 local function get(o)
  local count,status=M.Safety:Public(o.GetNumPoints,"number",o)
  if status~="KNOWN" or count<0 or count>8 or count%1~=0 then return nil end
  local result={}
  for i=1,count do
   local ok,p,r,rp,px,py=pcall(o.GetPoint,o,i)
   if not ok or not M.Safety:Text(p) or not M.Safety:Frame(r,true) or not M.Safety:Text(rp) or not M.Safety:Number(px) or not M.Safety:Number(py) then return nil end
   for _,v in ipairs({p,r,rp,px,py}) do result[#result+1]=v end
  end
  return result
 end
 local original=get(frame)
 if not original or #original==0 then return false end
 return self:Write(owner,frame,key,get,function(o,v)
  o:ClearAllPoints();for i=1,#v,5 do o:SetPoint(v[i],v[i+1],v[i+2],v[i+3],v[i+4]) end
  if not same(get(o),v,"points") then error("ANCHOR_WRITE_UNCONFIRMED") end
 end,{point,relative,relativePoint,x,y},"points")
end
