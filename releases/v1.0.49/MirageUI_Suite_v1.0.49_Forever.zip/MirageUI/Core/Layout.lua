local _, M = ...
M.Layout={}
local L=M.Layout
function L:Screen()
    local managed=M.Managed
    if managed and type(managed.Viewport)=="function" then
        local w,h,scale=managed:Viewport()
        if M.Safety:Number(w) and M.Safety:Number(h) and w>0 and h>0 then return w,h,scale end
        -- A settling first viewport has no usable coordinate space. Never
        -- substitute transient native dimensions or an invented desktop size.
        return nil,nil,nil,"VIEWPORT_PENDING"
    end
    if not UIParent then return nil,nil,nil,"VIEWPORT_PENDING" end
    local w,ws=M.Safety:Public(UIParent.GetWidth,"number",UIParent)
    local h,hs=M.Safety:Public(UIParent.GetHeight,"number",UIParent)
    if ws~="KNOWN" or hs~="KNOWN" or w<=0 or h<=0 then return nil,nil,nil,"VIEWPORT_PENDING" end
    local scale=M.Safety:Public(UIParent.GetEffectiveScale,"number",UIParent)
    return w,h,scale
end
function L:Clamp(layout)
    local w,h=self:Screen()
    if not w then return layout,"VIEWPORT_PENDING" end
    local scale=layout.scale or 1
    local halfX=math.min(.48,math.max(0,.5-(layout.width*scale/2+8)/w))
    local halfY=math.min(.48,math.max(0,.5-(layout.height*scale/2+8)/h))
    layout.x=math.max(-halfX,math.min(halfX,layout.x))
    layout.y=math.max(-halfY,math.min(halfY,layout.y))
    return layout
end
-- Fit only presentation envelopes on a settled, smaller game viewport. Pixel
-- resolution is not a physical screen size; native UI scale stays authoritative.
-- These are temporary copies, so switching computers never scales saved values.
function L:CompactViewport(profile)
    profile=profile or M.profile
    if not profile or profile.managed~=true then return nil end
    local w,h=self:Screen()
    if w and (w<1600 or h<900 or (w/h<1.7 and w<2200)) then return w,h end
end
local independentGeometry={ActionBars=true,NativeControls=true,UnderCharacterHUD=true,UnitFrames=true,
    PartyRaid=true,Nameplates=true,Cursor=true,Cooldowns=true}
function L:CanFit(surface)
    local id=surface and surface.id
    if type(id)~="string" then return false end
    -- Native input envelopes, physical-pixel rows and the shared sidebar have
    -- their own fitting authority. Never scale their passive artwork alone.
    return not independentGeometry[id:match("^([^.]+)")]
        and id~="Minimap.nativePosition" and id~="QuestTracker.nativePosition"
end
function L:Fit(surface,layout,profile)
    profile=profile or M.profile
    local w,h=self:CompactViewport(profile)
    if not w or not self:CanFit(surface) then return layout end
    local scale=layout.scale or 1
    if not M.Safety:Number(scale) or scale<=0 then return layout end
    if surface.id=="Chat.nativePosition" then
        local text=profile.textScale
        if not M.Safety:Number(text) then text=1 end
        text=math.max(.65,math.min(2,text))
        local minimumHeight=math.max(140,33+32+3*(13*text+3))
        -- Reflow the chat canvas before considering scale. Keep the current
        -- font size, header, input row and at least three readable message rows.
        layout.width=math.min(math.max(220,layout.width),math.max(220,w*.34/scale))
        layout.height=math.min(math.max(minimumHeight,layout.height),math.max(minimumHeight,h*.28/scale))
    end
    layout.scale=math.min(scale,math.max(1,w-32)/layout.width,math.max(1,h-32)/layout.height)
    return layout
end
function L:Unfitted(surface,profile)
    profile=profile or M.profile
    local cfg=M:Copy(profile.layouts[surface.id] or surface.layout or {x=0,y=0,width=220,height=50,scale=1})
    cfg.width=math.max(surface.minWidth or 24,cfg.width)
    cfg.height=math.max(surface.minHeight or 16,cfg.height)
    return cfg
end
function L:Get(surface,profile)
    return self:Clamp(self:Fit(surface,self:Unfitted(surface,profile),profile))
end
function L:Position(id,profile,seen)
    profile=profile or M.profile;seen=seen or {}
    if seen[id] then return 0,0 end;seen[id]=true
    local surface=M.surfaces[id]
    local l=profile.layouts[id] or (surface and surface.layout)
    if not l then return 0,0 end
    -- Runtime applies clamped copies. Resolve linked previews through those
    -- same copies without rewriting the player's authored positions.
    local provider=M.Rework and M.Rework:ProviderForLayout(id,profile)
    if provider and type(provider.object.ResolveLayout)=="function" then l=provider.object:ResolveLayout(surface or {id=id,layout=l},profile)
    else l=self:Get(surface or {id=id,layout=l},profile) end
    local x,y=l.x or 0,l.y or 0
    if l.anchorTo and M.surfaces[l.anchorTo] then
        local ax,ay=self:Position(l.anchorTo,profile,seen);x=x+ax;y=y+ay
    end
    return x,y
end
function L:Apply(surface)
    if not surface.editable or not surface.frame then return end
    if M.Safety:InCombat() then surface.layoutPending=true;return end
    if not M.Safety:Frame(surface.frame,false) then return end
    local w,h=self:Screen()
    if not w then surface.layoutPending=true;return false,"VIEWPORT_PENDING" end
    local provider=surface.reworkProvider
    if provider and type(provider.ApplyLayout)=="function" then
        -- Provider surfaces survive local handback so they can be reused on
        -- recovery. Their presence is not permission to re-enter an inactive
        -- renderer during the core profile-layout pass.
        if M.Rework and type(M.Rework.ApplySurfaceLayout)=="function" then
            return M.Rework:ApplySurfaceLayout(surface)
        end
        return provider:ApplyLayout(surface)
    end
    local l=self:Get(surface);local f=surface.frame
    if surface.unitTypographyView and M.UnitTypography then return M.UnitTypography:Layout(surface,l) end
    f:SetSize(l.width,l.height);f:SetScale(l.scale or 1);f:ClearAllPoints()
    local target=l.anchorTo and M.surfaces[l.anchorTo]
    if target and target.frame and target~=surface and M.Safety:Frame(target.frame,false) then
        local scale=(M.profile.managed and l.scale) or 1
        f:SetPoint("CENTER",target.frame,"CENTER",l.x*w/scale,l.y*h/scale)
    else
        local scale=(M.profile.managed and l.scale) or 1
        f:SetPoint("CENTER",UIParent,"CENTER",l.x*w/scale,l.y*h/scale)
    end
    surface.layoutPending=nil
    if surface.OnLayout then M:Guard(surface.module,surface.OnLayout,surface,l) end
end
function L:ApplyAll()
    if M.Safety:InCombat() then return end
    for _,surface in pairs(M.surfaces) do self:Apply(surface) end
end
function L:Snap(id,x,y,width,height,draft,scale)
    local w,h=self:Screen();if not w then return x,y end
    local grid=draft.grid or 8
    scale=scale or (draft.layouts[id] and draft.layouts[id].scale) or 1
    local shownWidth,shownHeight=width*scale,height*scale
    if M.NativeLayout then
        local projected=M.NativeLayout:PreviewGeometry(id,{x=x,y=y,width=width,height=height,scale=scale},draft)
        if projected then shownWidth,shownHeight=projected.width*projected.scale,projected.height*projected.scale end
    end
    if id=="UnderCharacterHUD.player" and draft.modules and draft.modules.UnderCharacterHUD then
        shownWidth=(width+(draft.modules.UnderCharacterHUD.castWidthExtra or 0))*scale
    end
    local px,py=x*w,y*h
    px=math.floor(px/grid+.5)*grid;py=math.floor(py/grid+.5)*grid
    local threshold=8
    for other,s in pairs(M.surfaces) do
        if other~=id and s.editable then
            local row=M.Elements and M.Elements:Get(other)
            local l=row and M.Elements:BoxLayout(row,draft) or self:Get(s,draft)
            local nx,ny=l.x,l.y
            if not row and l.anchorTo then local ax,ay=self:Position(l.anchorTo,draft);nx,ny=nx+ax,ny+ay end
            local ox,oy=nx*w,ny*h;local targetScale=l.scale or 1
            for _,cx in ipairs({ox,ox-l.width*targetScale/2-shownWidth/2,ox+l.width*targetScale/2+shownWidth/2}) do if math.abs(px-cx)<threshold then px=cx;break end end
            for _,cy in ipairs({oy,oy-l.height*targetScale/2-shownHeight/2,oy+l.height*targetScale/2+shownHeight/2}) do if math.abs(py-cy)<threshold then py=cy;break end end
        end
    end
    return px/w,py/h
end
function L:Rescue()
    if M.Safety:InCombat() then return false end
    local draft=M:Copy(M.profile)
    for id,l in pairs(draft.layouts) do
        local x,y=self:Position(id,M.profile)
        l.x,l.y=x,y;l.anchorTo=nil -- explicit rescue returns the layout to screen anchors.
        draft.layouts[id]=self:Clamp(l)
    end
    return M.Profiles:Commit(draft)
end
