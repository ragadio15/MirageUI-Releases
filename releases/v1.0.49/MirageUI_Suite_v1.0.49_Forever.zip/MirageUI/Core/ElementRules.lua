local _,M=...
-- Authored preference data only. Preview context is never written into native
-- combat state. Mandatory native access, active interactions and unknown inputs
-- retain their existing authority over these ordinary visibility preferences.
local R={contexts={Idle=true,Moving=true,Combat=true}}
R.aliases={['Minimap.MinimapCluster']='Minimap.nativePosition',['QuestTracker.ObjectiveTrackerFrame']='QuestTracker.nativePosition'}
for i=1,7 do R.aliases['Chat.ChatFrame'..i]='Chat.nativePosition' end
M.ElementRules=R
function R:Validate(input)
 if input==nil then return {} end
 if type(input)~="table" or getmetatable(input)~=nil then return nil,"Invalid context preferences; original settings were retained." end
 local result,count={},0
 for id,row in pairs(input) do
  count=count+1
  if count>256 or not M.Safety:Readable(id) or type(id)~="string" or #id>89 or not id:match("^[%w_%.]+$") or type(row)~="table" or getmetatable(row)~=nil then return nil,"Invalid element context entry." end
  local clean={}
  for context,value in pairs(row) do
   if not M.Safety:Readable(context) or not M.Safety:Readable(value) or not self.contexts[context] or (value~="SHOW" and value~="HIDE") then return nil,"Unknown context preference." end
   clean[context]=value
  end
  result[id]=clean
 end
 return result
end
local function known(snapshot,id)
 local row=snapshot and snapshot[id]
 if row and row.status=="KNOWN" and row.decisionEligible==true and M.Safety:Readable(row.value) then return row.value end
end
function R:Context(snapshot)
 if M.PresentationGroups and M.PresentationGroups:Enabled() then
  local state=M.PresentationGroups:State(snapshot)
  if state.combat then return "Combat" end
  if state.navigation then return "Moving" end
  if state.idle then return "Idle" end
  return nil
 end
 local combat,moving=known(snapshot,"PLAYER_IN_COMBAT"),known(snapshot,"PLAYER_MOVING")
 if combat==true then return "Combat" end
 if combat==false and moving==true then return "Moving" end
 if combat==false and moving==false then return "Idle" end
 return nil
end
function R:Preference(id,snapshot,profile)
 profile=profile or M.profile
 local rows=profile and profile.elementContexts
 if not rows or not next(rows) then return nil end
 id=self.aliases[id] or id
 local explicit=rows[id]
 local inherited
 -- Fixed roster slots use the same five-slot blocks as the editor. Keep each
 -- member's explicit context choice; AUTO inherits its block's preference.
 local member=tonumber(id:match("^PartyRaid%.raid(%d+)$"))
 local cfg=profile.modules and profile.modules.PartyRaid
 local native=M.NativeGroups and M.NativeGroups.active and cfg and cfg.nativeGroups
 if member and member>=1 and member<=40 and not native then
  local group="PartyRaid.group"..(math.floor((member-1)/5)+1)
  inherited=rows[group]
 end
 if not explicit and not inherited then return nil end
 local context=type(snapshot)=="string" and snapshot or self:Context(snapshot)
 return explicit and explicit[context] or inherited and inherited[context] or nil
end
function R:Intent(surface,snapshot)
 if surface.floor or surface.userOpened or surface.disabled or surface.presentationHidden then return nil end
 local value=self:Preference(surface.id,snapshot)
 if not value then return nil end
 if known(snapshot,"TEMP_REVEAL")==true or known(snapshot,"EDIT_MODE")==true then return nil end
 -- Required native access and actual held-input leases are resolver floors.
 -- A stale target, open chat editor or unrelated native task is not one.
 return {id="ELEMENT_CONTEXT_"..value,state=value=="SHOW" and "VISIBLE" or "HIDDEN",priority=1,tieRank=85,eligible=true}
end
