local _, M = ...
local S=M.Safety
local sourcePin=M.Client:NewSourcePinLookup()
-- A session-only, explicit USER-REPORTED test worksheet. It is NOT permission
-- admission, automated testing, an independent review, or a release signature.
M.NativeEvidence={state="NOT_STARTED",results={}}
local E=M.NativeEvidence
local tests={};for _,row in ipairs(M.AcceptanceTests) do tests[row.id]=row end
local allowed={PASS=true,PARTIAL=true,FAIL=true,BLOCKED=true,NOT_RUN=true,NA=true}
function E:Fingerprint()
 local ok,patch,build,_,interface=pcall(GetBuildInfo)
 if not ok or not S:Text(patch) or not S:Text(build) or not S:Number(interface) then return nil end
 local c,a=M.Client,M.adapter
 local pin=a and sourcePin(a.family,a.build)
 local sourceCommit=pin and a.patch==pin[1] and a.interface==pin[3] and a.sourceCommit==pin[4] and pin[4] or "UNQUALIFIED"
 local sourceMatched=sourceCommit~="UNQUALIFIED" and c.sourceMatched==true and c.family==a.family and
  patch==pin[1] and build==pin[2] and interface==pin[3] and c.patch==patch and c.build==build and c.interface==interface
 -- Keep the original tuple as the first return; the revision and match state
 -- are separate fingerprint fields, never permission or native acceptance.
 return c.family..":"..patch..":"..build..":"..interface,sourceCommit,sourceMatched
end
function E:Begin()
 if S:InCombat() then return false,"Begin the worksheet outside combat." end
 if self.started and next(self.results) then return false,"Export the current worksheet first. Clear it explicitly before starting another." end
 local fingerprint,sourceCommit,sourceMatched=self:Fingerprint();if not fingerprint then return false,"Client identity is unavailable." end
 local ok,profile=pcall(M.Profiles.Export,M.Profiles)
 if not ok or not S:Text(profile) then return false,"The current settings could not be scoped." end
 self.started=true;self.version=M.version;self.client=fingerprint;self.profile=profile
 self.sourceCommit=sourceCommit;self.sourceMatched=sourceMatched
 self.results={};self.state="USER_REPORTED_SESSION";self.settingsChanged=false
 return true,"Worksheet started for this version, client, adapter source and settings. No test has passed automatically. Export before reload."
end
function E:Current()
 if not self.started then return false,"Start a worksheet before recording a result." end
 if self.settingsChanged then return false,"This worksheet is stale. Export it, then clear and begin a new worksheet." end
 local fingerprint,sourceCommit,sourceMatched=self:Fingerprint()
 local ok,profile=pcall(M.Profiles.Export,M.Profiles)
 if fingerprint~=self.client or sourceCommit~=self.sourceCommit or sourceMatched~=self.sourceMatched or M.version~=self.version or not ok or not S:Text(profile) or profile~=self.profile then
  self.state="STALE_VERSION_CLIENT_OR_SETTINGS";self.settingsChanged=true
  return false,"Version, client, adapter source or settings changed. Export this stale worksheet, then clear and start again."
 end
 return true
end
function E:Record(id,result)
 if not S:Text(id) or not tests[id] or not S:Text(result) or not allowed[result] then return false,"Choose an existing test and PASS, PARTIAL, FAIL, BLOCKED, NOT_RUN or NA." end
 local valid,why=self:Current();if not valid then return false,why end
 self.results[id]=result
 return true,id.." recorded as "..result.." (your report, not an automatic approval)."
end
function E:Clear()
 self.started=false;self.state="NOT_STARTED";self.results={};self.version=nil;self.client=nil;self.profile=nil;self.settingsChanged=false
 self.sourceCommit=nil;self.sourceMatched=nil
 return true,"Session worksheet cleared. No settings, game state or permissions changed."
end
function E:Export()
 if self.started then self:Current() end
 local fingerprint,sourceCommit,sourceMatched=self:Fingerprint()
 if self.started then fingerprint,sourceCommit,sourceMatched=self.client,self.sourceCommit,self.sourceMatched end
 local lines={"MIRAGE_USER_TEST_REPORT=1","addon="..(self.version or M.version),"client="..(fingerprint or M.Client.key),"state="..self.state,
  "adapter_source_commit="..(sourceCommit or "UNAVAILABLE"),"client_source_matched="..tostring(sourceMatched==true),
  "source=EXPLICIT_USER_REPORTED_NOT_AUTOMATIC","scope=ONE_VERSION_CLIENT_SETTINGS_SNAPSHOT",
  "native_permission_granted=false","release_acceptance_granted=false","identities_or_free_text=NOT_COLLECTED"}
 for _,row in ipairs(M.AcceptanceTests) do lines[#lines+1]=row.id.."="..(self.results[row.id] or "NOT_RUN") end
 local total,passed=0,0
 for _,row in ipairs(M.AcceptanceTests) do
  if row.milestone=="M06" then total=total+1;if self.results[row.id]=="PASS" then passed=passed+1 end end
 end
 lines[#lines+1]="m06_targeted_cases="..total
 lines[#lines+1]="m06_user_reported_passes="..passed
 lines[#lines+1]="m06_unresolved_cases="..(total-passed)
 lines[#lines+1]="m06_scope=M06_REQUIREMENTS_PLUS_RETAINED_FUNCTIONAL_CONTRACTS"
 lines[#lines+1]="m06_worksheet="..(self.settingsChanged and "STALE" or passed==total and total>0 and "COMPLETE_USER_REPORT_ONLY" or "INCOMPLETE")
 return table.concat(lines,"\n")
end
