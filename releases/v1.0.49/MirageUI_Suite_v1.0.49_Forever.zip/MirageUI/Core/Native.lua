local _, M = ...
M.Native={records={},decorations={},decorationStatus=setmetatable({},{__mode="k"})}
local N=M.Native
function N:Conflict()
    return M.Safety:Loaded("ElvUI") or M.Safety:Loaded("EllesmereUI")
end
function N:Acquire(module,id,frame,groups,allowDim)
    if self:Conflict() then M.modules[module].status="CONFLICT_NATIVE_OWNER";return nil end
    if not M.Safety:Frame(frame,false) then return nil end
    local alpha,alphaState=M.Safety:Public(frame.GetAlpha,"number",frame)
    if alphaState~="KNOWN" or alpha<0 or alpha>1 then return nil end
    local reusedController,reusedReady
    local prior=M.surfaces[id]
    if prior and prior.native and prior.frame~=frame then
        if M.Safety:InCombat() then return nil end
        local old=prior.frame
        self:RestoreSurface(old,prior)
        if not self:HideDecoration(old) then return nil end
        if prior.quietRestorePending or prior.restorePending then return nil end
        if M.NativeQuiet then M.NativeQuiet:Release(prior) end
        reusedController,reusedReady=prior.revealController,prior.guardReady
        self.records[old]=nil
        -- Old native callbacks cannot authorize interaction with the replacement frame.
        M.Effects.active[id]=nil
        if M.Policy then M.Policy:Release(M.surfaces[id]) end
        M.surfaces[id]=nil
    end
    local existing=self.records[frame]
    if existing and existing.module~=module then return nil end
    local security=allowDim and M.Safety:Frame(frame,true) and "NATIVE_PUBLIC" or "NATIVE_READ_ONLY"
    local s={id=id,module=module,frame=frame,native=true,security=security,groups=groups or {},
        fallback="VISIBLE",originalAlpha=alpha,currentAlpha=alpha,minAlpha=.35,editable=false}
    if reusedController then s.revealController=reusedController;s.guardReady=reusedReady;s.controllerDormant=true end
    if not M.surfaces[id] then M.CVE:Register(s) else s=M.surfaces[id] end
    self.records[frame]=s
    if frame.HookScript and not s.hoverHook then
        s.hoverHook=true
        pcall(frame.HookScript,frame,"OnEnter",function() if s.frame==frame and self.records[frame]==s and M:ModuleConfig(module).enabled then M.CVE:Hold(s,.4) end end)
        pcall(frame.HookScript,frame,"OnMouseWheel",function() if s.frame==frame and self.records[frame]==s and M:ModuleConfig(module).enabled then M.CVE:Hold(s,.4) end end)
    end
    return s
end
-- These panels retain native content and controls. Nameplates and the minimap
-- have dedicated renderers; they must never receive an extra enclosing box.
local panelModules={Chat=true,Tooltips=true,QuestTracker=true,BlizzardSkin=true,Bags=true,DamageMeters=true}
local reviewedClient=M.Client.RuntimeAvailable or M.Client.IsReviewedPresentationClient
local function presentationClient()
    local c=M.Client
    return c and c.allowed==true and type(reviewedClient)=="function" and reviewedClient(c) and M.Safety:BoundaryReady() or false
end
function N:SkinState(frame) return self.decorationStatus[frame] or "NATIVE_CONTENT_PRESERVED" end
function N:HideDecoration(frame)
    local row=self.decorations[frame]
    if not row then return true end
    row.pending=true
    self.decorationStatus[frame]="NATIVE_PANEL_RELEASE_PENDING"
    if M.Safety:InCombat() or not M.Safety:Frame(row.frame,false) then return false end
    local sent=pcall(row.frame.Hide,row.frame)
    local shown,state=M.Safety:Public(row.frame.IsShown,"boolean",row.frame)
    if sent and state=="KNOWN" and shown==false then
        row.pending=nil;self.decorationStatus[frame]="NATIVE_PANEL_RELEASED";return true
    end
    self.decorationStatus[frame]="NATIVE_PANEL_RELEASE_PENDING";return false
end
function N:Decorate(module,frame)
    local profile,surface=M.profile,self.records[frame]
    local function current()
        return M.Native==self and M.profile==profile and presentationClient() and panelModules[module] and M:IsModuleActive(module)
            and M:ModuleConfig(module).style==true and not self:Conflict() and not M.Safety:InCombat()
            and surface and self.records[frame]==surface and M.surfaces[surface.id]==surface and surface.frame==frame and surface.module==module
            and M.Safety:Frame(frame,true) and M.profile==profile
    end
    if not current() then
        if self.decorations[frame] then self:HideDecoration(frame) end
        return nil
    end
    local row=self.decorations[frame]
    if row and (row.module~=module or row.pending) then return nil end
    if not row then
        local ok=pcall(function()
            local edge=CreateFrame("Frame",nil,frame,"BackdropTemplate")
            row={frame=edge,module=module};self.decorations[frame]=row
            edge:Hide();M.Safety:Passive(edge)
            if not current() then error("PANEL_RETIRED") end
            edge:SetPoint("TOPLEFT",-2,2);edge:SetPoint("BOTTOMRIGHT",2,-2)
            -- A low frame level keeps the passive backing behind the native
            -- labels and buttons. Only our own frame receives these writes.
            local level=M.Safety:Public(frame.GetFrameLevel,"number",frame)
            if not level then error("PANEL_LEVEL_UNAVAILABLE") end
            edge:SetFrameLevel(math.max(0,level-1))
            edge:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
            local v=M.VisualTokens.world
            edge:SetBackdropColor(v.surface[1],v.surface[2],v.surface[3],.08)
            edge:SetBackdropBorderColor(v.stroke[1],v.stroke[2],v.stroke[3],.32)
            row.ready=true
        end)
        if not ok then self:HideDecoration(frame);self.decorationStatus[frame]="NATIVE_PANEL_UNAVAILABLE";return nil end
    end
    if not row.ready or not current() then self:HideDecoration(frame);return nil end
    local sent=pcall(row.frame.Show,row.frame)
    local shown,state=M.Safety:Public(row.frame.IsShown,"boolean",row.frame)
    if not sent or state~="KNOWN" or shown~=true or not current() then
        self:HideDecoration(frame);self.decorationStatus[frame]="NATIVE_PANEL_UNAVAILABLE";return nil
    end
    self.decorationStatus[frame]="MIRAGE_PANEL_NATIVE_CONTENT"
    return row.frame
end
function N:Undecorate(module)
    for frame,row in pairs(self.decorations) do
        if row.module==module then self:HideDecoration(frame) end
    end
end
function N:RestoreSurface(frame,s,automatic)
    M.Effects.active[s.id]=nil
    if M.NativeQuiet and not M.NativeQuiet:Restore(s,automatic) then
        s.restorePending=true
        s.appliedReason=(s.quietRestoreAttempts or 0)>=3 and "QUIET_RESTORE_RELOAD_REQUIRED" or "QUIET_RESTORE_DEFERRED"
        return false
    end
    if s.lastWrittenAlpha==nil then s.restorePending=nil;s.actual="NATIVE";return true end
    local legal=(not M.Safety:InCombat() and M.Safety:Frame(frame,false)) or
        (M.Safety:Frame(frame,true) and M.Safety:ChildTreePublic(frame))
    if not legal then s.restorePending=true;return end
    local current,status=M.Safety:Public(frame.GetAlpha,"number",frame)
    if status~="KNOWN" then
        -- An opaque/missing observation is not evidence of a newer owner.
        s.restorePending=true;s.appliedReason="ALPHA_RESTORE_UNOBSERVED";return false
    end
    if math.abs(current-s.lastWrittenAlpha)<.001 then
        local restored=pcall(frame.SetAlpha,frame,s.originalAlpha or 1)
        local observed,known=M.Safety:Public(frame.GetAlpha,"number",frame)
        if not restored or known~="KNOWN" or math.abs(observed-(s.originalAlpha or 1))>=.001 then
            s.restorePending=true;s.appliedReason="ALPHA_RESTORE_DEFERRED";return false
        end
    end
    -- A changed value belongs to its newer writer; do not overwrite another UI owner.
    s.lastWrittenAlpha=nil;s.targetAlpha=nil;s.currentAlpha=s.originalAlpha or 1;s.restorePending=nil;s.actual="NATIVE"
end
function N:Restore(module)
    if M.StyleLease then M.StyleLease:Restore(module) end
    if M.NativeLayout then
        if module then M.NativeLayout:Restore(module) else for id in pairs(M.NativeLayout.rows) do M.NativeLayout:Restore(id) end end
    end
    for frame,s in pairs(self.records) do if not module or s.module==module then
        local ok=pcall(self.RestoreSurface,self,frame,s)
        if not ok then s.restorePending=true;s.appliedReason="NATIVE_RESTORE_DEFERRED" end
    end end
    for frame,row in pairs(self.decorations) do
        if not module or row.module==module then
            self:HideDecoration(frame)
        end
    end
end
function N:RestoreAll() self:Restore(nil) end
function N:RetryRestores()
    if M.Safety:InCombat() then return end
    if M.PrivateAuras then M.PrivateAuras:Retry() end
    if M.NativeQuiet then M.NativeQuiet:Retry() end
    if M.NativeLayout then M.NativeLayout:Retry() end
    if M.StyleLease then M.StyleLease:Retry() end
    local tooltips=M.modules.Tooltips
    if tooltips and tooltips.anchorRestorePending and tooltips.RestoreAnchor then tooltips:RestoreAnchor() end
    for frame,s in pairs(self.records) do if s.restorePending then self:RestoreSurface(frame,s,true) end end
    for frame,row in pairs(self.decorations) do
        if row.pending then self:HideDecoration(frame) end
    end
end
