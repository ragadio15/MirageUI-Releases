local _, M = ...
-- Each consumer receives an independent private lookup. A caller cannot mutate
-- a returned record to widen another consumer's or Detect's source authority.
-- These are reviewed source tuples, never native acceptance or runtime allowlists.
local function newSourcePinLookup()
    local pins={
        Midnight={['70575']={'12.1.5','70575',120105,'15881d522c44cd106d3d8660106ec9f9d2f44167'}},
        Forever={
            ['70532']={'1.60.1','70532',16001,'ca8368f2f2380cbe696854f7f2646387c278a61b'},
            ['70790']={'1.60.1','70790',16001,'eac30af597e5aaa43a60f6675ef5fdcea100375f'},
            ['70862']={'1.60.1','70862',16001,'9dc84f0d3bbae1768ac3405b3716000bd93eda06'},
            ['70888']={'1.60.1','70888',16001,'4cd0ab752a77164f654ccbca9d0c1fe8dafceebe'},
            ['70938']={'1.60.1','70938',16001,'bebcb6bf309cf41b41bd74f8ca651e6a105b2676'},
            ['70959']={'1.60.1','70959',16001,'3d8abb1da73acd38e412e24fb3f99454a6392346'},
            ['71037']={'1.60.1','71037',16001,'734f065329cff4992835b01a84f210a297db91b6'},
        },
    }
    return function(family,build)
        if type(family)~='string' or type(build)~='string' then return nil end
        local familyPins=pins[family]
        return familyPins and familyPins[build] or nil
    end
end
M.Client={allowed=false,NewSourcePinLookup=newSourcePinLookup}
local sourcePin=newSourcePinLookup()
local adapter=M.adapter
local family,nativePending=adapter.family,adapter.nativePending
local function adapterCurrent()
    local pin=sourcePin(adapter.family,adapter.build)
    return M.adapter==adapter and adapter.family==family and adapter.nativePending==nativePending and pin
        and adapter.patch==pin[1] and adapter.interface==pin[3] and adapter.sourceCommit==pin[4]
end
-- Source review is evidence only. Runtime admission follows capabilities and
-- the user's saved stop choice; an unfamiliar patch/build does not disable UI.
local observation
function M.Client:IsReviewedPresentationClient()
    local pin=sourcePin(self.family,self.build)
    return M.Client==self and self.sourceMatched==true and self.family=="Forever"
        and (self.build=="70862" or self.build=="70888" or self.build=="70938" or self.build=="70959" or self.build=="71037") and pin
        and self.patch==pin[1] and self.interface==pin[3]
        and self.key=="Forever:"..pin[1]..":"..pin[2]..":"..pin[3]
        and adapterCurrent() and adapter.build==pin[2] or false
end
function M.Client:RuntimeAvailable()
    -- Recheck the observed owner and the capability implementation after every
    -- potentially reentrant probe. This predicate also permits legal cleanup
    -- after the user's runtime acquisition choice has been paused.
    local saved=observation
    local safety=M.Safety
    local boundary=safety and safety.BoundaryReady
    local readable=safety and safety.Readable
    local secret,access=issecretvalue,canaccessvalue
    local function current()
        return M.Client==self and saved and observation==saved and adapterCurrent()
            and M.Safety==safety and safety.BoundaryReady==boundary and safety.Readable==readable
            and issecretvalue==secret and canaccessvalue==access
            and self.key==saved.key and self.family==saved.family
            and self.patch==saved.patch and self.build==saved.build and self.interface==saved.interface
    end
    if type(boundary)~="function" or not current() then return false end
    local ok,ready=pcall(boundary,safety)
    return ok and ready==true and current() or false
end
function M.Client:IsRuntimeClient()
    return self.allowed==true and self:RuntimeAvailable() and self.allowed==true or false
end
function M.Client:Detect()
    local ok,patch,build,_,interface=pcall(GetBuildInfo)
    self.family=family;self.patch="unknown";self.build="unknown";self.interface=0;self.experimental=false
    if ok and M.Safety:Text(patch) and M.Safety:Text(build) and M.Safety:Number(interface) then
        self.patch,self.build,self.interface=patch,build,interface
    end
    local boundary=M.Safety:BoundaryReady()
    local pin=sourcePin(self.family,self.build)
    local exact=pin and self.patch==pin[1] and self.interface==pin[3]
    if boundary and exact and self.family=='Forever' and nativePending==true and
        M.Client==self and adapterCurrent() then
        adapter.patch,adapter.build,adapter.interface,adapter.sourceCommit=pin[1],pin[2],pin[3],pin[4]
    end
    self.sourceMatched=exact and M.Client==self and adapterCurrent() and self.patch==adapter.patch
        and self.build==adapter.build and self.interface==adapter.interface and adapter.sourceCommit==pin[4] or false
    self.key=self.family..":"..self.patch..":"..self.build..":"..self.interface
    observation={key=self.key,family=self.family,patch=self.patch,build=self.build,interface=self.interface}
    self.runtimePolicy="CAPABILITY_GUARDED"
    self.reviewStatus=self.sourceMatched and "REVIEWED_SOURCE" or "UNREVIEWED_CLIENT"
    self.allowed=self:RuntimeAvailable()
    self.experimental=self.allowed and nativePending==true or false
    self.reason=not boundary and "SECRET_BOUNDARY_UNAVAILABLE" or
        (self.allowed and (self.sourceMatched and "REVIEWED_SOURCE_API_GUARDED" or "UNREVIEWED_CLIENT_API_GUARDED") or "RUNTIME_CAPABILITY_UNAVAILABLE")
end
-- Runtime availability is separate from native acceptance. Nothing is self-certified.
M.Capabilities={rows={}}
function M.Capabilities:Set(id,present,permission)
    self.rows[id]={present=present==true,permission=permission or "UNKNOWN",native="NOT_RUN",client=M.Client.key}
end
function M.Capabilities:Probe()
    self:Set("publicSignals",M.Client.allowed,"CANDIDATE_READABLE_ONLY")
    self:Set("statusBars",M.Client.allowed and type(UnitHealth)=="function","NATIVE_WIDGET_ONLY")
    self:Set("unitWatch",M.Client.allowed and type(RegisterUnitWatch)=="function","SECURE_CANDIDATE")
    self:Set("stateDrivers",M.Client.allowed and type(RegisterStateDriver)=="function","SECURE_CANDIDATE")
    self:Set("castDuration",M.Client.allowed and type(UnitCastingDuration)=="function","OPAQUE_DISPLAY_ONLY")
    self:Set("channelDuration",M.Client.allowed and type(UnitChannelDuration)=="function","OPAQUE_DISPLAY_ONLY")
    self:Set("gcdDuration",M.Client.allowed and C_Spell and type(C_Spell.GetSpellCooldownDuration)=="function","OPAQUE_DISPLAY_ONLY")
    self:Set("nativeCooldownViewer",C_CooldownViewer~=nil,"NATIVE_OWNED")
    self:Set("nativeDamageMeter",C_DamageMeter~=nil,"NATIVE_OWNED")
    self:Set("trackedCooldowns",M.Client.allowed and C_Spell and type(C_Spell.GetSpellCooldownDuration)=="function","OPAQUE_DISPLAY_ONLY")
    self:Set("playerAuraPanel",M.Client.allowed and C_UnitAuras and type(C_UnitAuras.GetAuraDataByIndex)=="function","PUBLIC_FIELDS_ONLY")
    self:Set("totemDuration",M.Client.allowed and type(GetNumTotemSlots)=="function" and type(GetTotemDuration)=="function","OPAQUE_DISPLAY_ONLY")
    self:Set("classResource",M.Client.allowed and type(UnitPower)=="function" and Enum and Enum.PowerType~=nil,"NATIVE_WIDGET_ONLY")
    self:Set("actionRearrangement",M.Client.allowed and type(PickupAction)=="function" and type(PlaceAction)=="function","EXPLICIT_OUT_OF_COMBAT_INPUT")
    self:Set("nativeClickCasting",M.Client.allowed and C_ClickBindings and type(C_ClickBindings.GetBindingType)=="function","INHERITED_SECURE_UNIT_ROUTE")
    self:Set("unitExtraCasts",M.Client.allowed and type(UnitCastingDuration)=="function","OPAQUE_DISPLAY_ONLY")
    self:Set("unitExtraAuras",M.Client.allowed and C_UnitAuras and type(C_UnitAuras.GetAuraDataByIndex)=="function","PUBLIC_FIELDS_ONLY")
    self:Set("inventoryBrowser",M.Client.allowed and C_Container and type(C_Container.GetContainerItemInfo)=="function","PUBLIC_FIELDS_READ_ONLY")
    self:Set("bankBrowser",M.Client.allowed and C_Bank and type(C_Bank.CanViewBank)=="function" and type(C_Bank.FetchPurchasedBankTabIDs)=="function","EXPLICIT_OPEN_BANK_READ_ONLY")
    self:Set("meterSummary",M.Client.allowed and C_DamageMeter and type(C_DamageMeter.GetCombatSessionFromType)=="function","PUBLIC_FIELDS_READ_ONLY")
    self:Set("defaultTooltipAnchor",M.Client.allowed and type(GameTooltip_SetDefaultAnchor)=="function","OUT_OF_COMBAT_PUBLIC_FRAME_ONLY")
    self:Set("learnedSpellPicker",M.Client.allowed and C_SpellBook and type(C_SpellBook.GetSpellBookItemInfo)=="function" and type(C_SpellBook.IsSpellKnown)=="function","EXPLICIT_LEARNED_ID_SELECTION")
    self:Set("empoweredStageDurations",M.Client.allowed and type(UnitEmpoweredStageDurations)=="function","OPAQUE_DISPLAY_ONLY")
    self:Set("nativeSpeech",C_VoiceChat and type(C_VoiceChat.SpeakText)=="function","EXPLICIT_STATIC_SETTINGS_LABELS_ONLY")
    self:Set("nativeMemory",type(UpdateAddOnMemoryUsage)=="function" and type(GetAddOnMemoryUsage)=="function","EXPLICIT_LOCAL_MEASUREMENT_ONLY")
    self:Set("foreverCamp",false,"UNKNOWN")
    self:Set("foreverLegacy",false,"UNKNOWN")
end
