local _, M = ...
local f=CreateFrame("Frame");M.eventFrame=f
M.eventSupport={}
M.eventListeners={};M.maintenanceListeners={}
-- Only authored subscription names enter this session journal. Rejected probes
-- are not subscriptions and must never be passed to UnregisterEvent. Native
-- error strings and event payloads are deliberately not retained.
local eventReasons,knownEvents={},{}
local eventState={phase="NOT_RUN",event="NONE",status="NOT_RUN",lastFailure=nil}
local function eventStep(phase,event)
    eventState.phase=phase;eventState.event=knownEvents[event] and event or "NONE"
end
local function eventFailure(event,reason)
    eventReasons[event]=reason
    eventState.lastFailure={event=knownEvents[event] and event or "NONE",operation=eventState.phase,reason=reason}
end
local function eventValid(event)
    if C_EventUtils and type(C_EventUtils.IsEventValid)=="function" then
        local ok,value=pcall(C_EventUtils.IsEventValid,event)
        if ok and M.Safety:Readable(value) and type(value)=="boolean" then return value end
    end
end
local function eventRegistered(event)
    if type(f.IsEventRegistered)=="function" then
        local ok,value=pcall(f.IsEventRegistered,f,event)
        if ok and M.Safety:Readable(value) and type(value)=="boolean" then return value end
    end
end
function M:EventSubscriptionSnapshot()
    local rows,registered,rejected,failed={},0,0,0
    for event,value in pairs(self.eventSupport) do
        if value==true then registered=registered+1 elseif value==false then rejected=rejected+1 end
    end
    local names={};for event in pairs(eventReasons) do if knownEvents[event] then names[#names+1]=event end end
    table.sort(names)
    for _,event in ipairs(names) do
        local reason=eventReasons[event]
        if reason~="UNSUPPORTED" and reason~="REGISTER_REJECTED" then failed=failed+1 end
        if #rows<32 then rows[#rows+1]={event=event,reason=reason} end
    end
    local last=eventState.lastFailure
    return {status=eventState.status,phase=eventState.phase,event=eventState.event,registered=registered,rejected=rejected,
        failed=failed,total=#names,rows=rows,lastFailure=last and {event=last.event,operation=last.operation,reason=last.reason} or nil}
end
local baseEvents={"ADDON_LOADED","PLAYER_LOGIN","PLAYER_LOGOUT","PLAYER_ENTERING_WORLD","PLAYER_LEAVING_WORLD","PLAYER_REGEN_DISABLED","PLAYER_REGEN_ENABLED",
    "PLAYER_DEAD","PLAYER_ALIVE","PLAYER_UNGHOST","PLAYER_FLAGS_CHANGED",
    "NAME_PLATE_UNIT_ADDED","NAME_PLATE_UNIT_REMOVED","UNIT_TARGET",
    "PLAYER_TARGET_CHANGED","PLAYER_FOCUS_CHANGED","UPDATE_MOUSEOVER_UNIT","GROUP_ROSTER_UPDATE","UNIT_PET","UPDATE_FACTION","ZONE_CHANGED","ZONE_CHANGED_NEW_AREA","ZONE_CHANGED_INDOORS",
    "QUEST_ACCEPTED","QUEST_LOG_UPDATE","QUEST_WATCH_UPDATE","PLAYER_XP_UPDATE","PLAYER_LEVEL_UP","READY_CHECK","READY_CHECK_FINISHED","RESURRECT_REQUEST",
    "ENCOUNTER_START","ENCOUNTER_END","ENCOUNTER_STATE_CHANGED","UNIT_SPELLCAST_START","UNIT_SPELLCAST_STOP","UNIT_SPELLCAST_CHANNEL_START","UNIT_SPELLCAST_CHANNEL_STOP",
    "UNIT_SPELLCAST_FAILED","UNIT_SPELLCAST_FAILED_QUIET","UNIT_SPELLCAST_INTERRUPTED","UNIT_SPELLCAST_EMPOWER_START","UNIT_SPELLCAST_EMPOWER_STOP","UI_SCALE_CHANGED","DISPLAY_SIZE_CHANGED","CINEMATIC_START","CINEMATIC_STOP","ADDON_ACTION_BLOCKED","ADDON_ACTION_FORBIDDEN","BANKFRAME_OPENED","BANKFRAME_CLOSED"}
local requiredEvents={ADDON_LOADED=true,PLAYER_LOGIN=true,PLAYER_LOGOUT=true,PLAYER_ENTERING_WORLD=true,
    PLAYER_LEAVING_WORLD=true,PLAYER_REGEN_DISABLED=true,PLAYER_REGEN_ENABLED=true,ADDON_ACTION_BLOCKED=true,ADDON_ACTION_FORBIDDEN=true}
function M:RefreshEvents()
    eventState.status="RUNNING";eventStep("COLLECT","NONE")
    local wanted,normal,maintenance={}, {}, {}
    for _,event in ipairs(baseEvents) do wanted[event]=true end
    if self.StartupPresentation then for event in pairs(self.StartupPresentation.events or {}) do wanted[event]=true end end
    self.Signals:ResetChatCue() -- configuration/subscription revision retires old UI cues.
    local chat=self:ModuleConfig("Chat")
    if self:IsModuleActive("Chat") and chat.messageCue==true then
        for event in pairs(self.ChatCueEvents) do wanted[event]=true end
        for event,option in pairs(self.ChatCueOptionalEvents) do if chat[option]==true then wanted[event]=true end end
    end
    for _,id in ipairs(self.order) do
        local mod=self.modules[id]
        if self:IsSecureCleanupActive(id) then
            for event in pairs(mod.maintenanceEvents or {}) do
                wanted[event]=true;maintenance[event]=maintenance[event] or {};maintenance[event][#maintenance[event]+1]=id
            end
        end
        if self:IsModuleActive(id) then for event in pairs(mod.events or {}) do
            if not mod.WantsEvent or mod:WantsEvent(event) then
                wanted[event]=true;normal[event]=normal[event] or {};normal[event][#normal[event]+1]=id
            end
        end end
    end
    self.eventListeners=normal;self.maintenanceListeners=maintenance
    -- All owners contribute before reconciliation. A provider event may still
    -- be required even when no legacy module subscribes to it.
    if self.CollectProviderEvents then self:CollectProviderEvents(wanted) end
    for event in pairs(wanted) do knownEvents[event]=true end
    local complete=true
    for event,registered in pairs(self.eventSupport) do
        if registered==true and not wanted[event] then
            eventStep("UNREGISTER",event)
            local ok,value=pcall(f.UnregisterEvent,f,event)
            local observed=ok and eventRegistered(event)
            if ok and observed~=true and (observed==false or value~=false) then
                self.eventSupport[event]=nil;eventReasons[event]=nil
            else
                complete=false;eventFailure(event,ok and "UNREGISTER_UNCONFIRMED" or "UNREGISTER_FAILED")
            end
        end
    end
    for event in pairs(wanted) do
        if self.eventSupport[event]==nil then
            eventStep("REGISTER",event)
            local valid=eventValid(event)
            if valid==false then
                self.eventSupport[event]=false
                if requiredEvents[event] then complete=false;eventFailure(event,"REQUIRED_EVENT_UNAVAILABLE")
                else eventFailure(event,"UNSUPPORTED") end
            else
                local ok,value=pcall(f.RegisterEvent,f,event)
                local observed=ok and eventRegistered(event)
                if ok and (observed==true or observed==nil and value~=false) then
                    self.eventSupport[event]=true;eventReasons[event]=nil
                elseif valid==true or requiredEvents[event] then
                    -- A known valid event failing to register is real debt,
                    -- not evidence that this client lacks the capability.
                    complete=false;eventFailure(event,"REGISTER_FAILED")
                else
                    self.eventSupport[event]=false;eventFailure(event,"REGISTER_REJECTED")
                end
            end
        elseif self.eventSupport[event]==false and requiredEvents[event] then
            complete=false;eventFailure(event,"REQUIRED_EVENT_UNAVAILABLE")
        end
    end
    eventState.status=complete and "COMPLETE" or "FAILED";eventStep("COMPLETE","NONE")
    if not complete then error("EVENT_SUBSCRIPTIONS_INCOMPLETE",0) end
    return true
end
function M:ApplyProfile(forceLayout,trigger,parent)
    if self.KeybindWorkspace and self.KeybindWorkspace.session and
        (self.KeybindWorkspace.session.profile~=self.profile or self.state.safe or not self.profile or not self.profile.enabled or not self.profile.modules.ActionBars.enabled) then
        self.KeybindWorkspace:StopForLifecycle()
    end
    local attempt=self:BeginApplyAttempt(trigger,parent)
    if not attempt then return false end
    local function finish(result,category)
        local id=self:FinishApplyAttempt(attempt,result,category)
        return result=="COMPLETE" or result=="STOPPED",id
    end
    if self.applying or not self.state.initialized then return finish("BLOCKED") end
    -- Consent changes may re-enter Apply before the queued stop has drained.
    -- Admission cannot turn unresolved cleanup into a fresh visual activation.
    if self.state.safeCleanupPending and not self.state.safe then self.state.safe=true;return finish("BLOCKED") end
    local legal,combat=pcall(self.Safety.InCombat,self.Safety)
    if not legal then self:RecordApplyFailure(attempt,"PROFILE_APPLY_FAILED");self:Fault("Core","PROFILE_APPLY_FAILED");return finish("FAILED","PROFILE_APPLY_FAILED") end
    if combat then self.state.applyPending=true;self.state.applyPendingForce=forceLayout;self.state.applyPendingTrigger=trigger;return finish("DEFERRED") end
    -- A publication of byte-identical authored preferences is not a runtime
    -- reconfiguration request. Keep the transaction receipt, but do not churn
    -- modules, layout, fonts, events or providers for a no-op Apply.
    if trigger=="PROFILE_COMMIT" and not forceLayout and self.Profiles and type(self.Profiles.Export)=="function" and not self.state.safe then
        local ok,wire=pcall(self.Profiles.Export,self.Profiles)
        if ok and type(wire)=="string" and self.state.appliedProfileWire==wire then
            self:ApplyPhase(attempt,"NOOP","Core")
            return finish("COMPLETE")
        end
    end
    if self.StartupPresentation and self.StartupPresentation.BeforeApply then
        local prepared=pcall(self.StartupPresentation.BeforeApply,self.StartupPresentation)
        if not prepared then pcall(self.StartupPresentation.Cancel,self.StartupPresentation,"STARTUP_CALLBACK_FAILED") end
    end
    self.state.settingsGeneration=(self.state.settingsGeneration or 0)+1
    self.stats.profileApplies=(self.stats.profileApplies or 0)+1
    if self.RuntimeScheduler then self.RuntimeScheduler:Invalidate() end
    local state,profile,modules=self.state,self.profile,self.modules
    local typography=self.UnitTypography;local typographyAttempted=false
    local adaptiveFitComplete=true
    local typographyBegin,typographyEnd=typography and typography.Begin,typography and typography.End
    local stage,owner="PRECHECK","Core"
    local failureCategory="PROFILE_APPLY_FAILED"
    local failureEvidence
    local function captureFailure(failedPhase)
        -- Ignore the xpcall error argument. Only the first live source stack
        -- accompanies this transaction, even if finalization also throws.
        if not failureEvidence then
            failureEvidence={origin="PROFILE",phase=failedPhase,locations="SOURCE_LOCATIONS_UNAVAILABLE"}
            local incidents=self.Incidents
            if incidents and type(incidents.CaptureFailure)=="function" then
                local ok,evidence=pcall(incidents.CaptureFailure,incidents,"PROFILE",failedPhase)
                if ok and type(evidence)=="table" then failureEvidence=evidence end
            end
        end
        return false
    end
    local function current()
        return rawequal(self.state,state) and rawequal(self.profile,profile) and rawequal(self.modules,modules)
    end
    local function phase(name,module)
        if not current() then failureCategory="OWNERSHIP_CHANGED";error("APPLY_OWNERSHIP_CHANGED",0) end
        stage,owner=name,module or "Core";self:ApplyPhase(attempt,stage,owner)
    end
    self.applying=true
    local applied=xpcall(function()
        if trigger=="RECOVER" and self.ManagedNative then
            phase("RECOVERY_RESET")
            if self.ManagedNative:ResetEmergency()~=true then failureCategory="RECOVERY_RESET_FAILED";error("RECOVERY_RESET_FAILED",0) end
        end
        phase("NATIVE_RELEASE")
        if self.ManagedNative and (not self.Managed:Enabled() or self.Native:Conflict()) then self.ManagedNative:RestoreAll();self.ManagedNative:ResourcePreference(false) end
        phase("ADAPTIVE_LAYOUT")
        if self.AdaptiveLayout then
            local fitted,detail=self.AdaptiveLayout:Refresh(self.profile,forceLayout)
            if fitted==false and detail~=nil then adaptiveFitComplete=false end
        end
        phase("TYPOGRAPHY_BEGIN")
        if typography then
            if not rawequal(self.UnitTypography,typography) or not rawequal(typography.Begin,typographyBegin) then failureCategory="OWNERSHIP_CHANGED";error("APPLY_OWNERSHIP_CHANGED",0) end
            typographyAttempted=true;typographyBegin(typography,"PROFILE")
        end
        phase("POLICY");self.Policy:Invalidate("PROFILE_CHANGED")
        self.CVE.holds={} -- profile revision invalidates every previous temporal rule winner.
        for _,id in ipairs(self.order) do
            local mod=modules[id];local cfg=self:ModuleConfig(id)
            local conflict=self.Native:Conflict() and (self.CatalogByID[id].kind=="native" or self.CatalogByID[id].kind=="secure")
            local run=cfg and cfg.enabled and self.profile.enabled and self.Client.allowed and not self.state.safe and not mod.quarantined and not conflict
            if run then
                mod.suspended=false
                if not mod.initialized then
                    phase("MODULE_INITIALIZE",id)
                    local ok,value=self:Guard(id,mod.Initialize,mod)
                    phase("MODULE_INITIALIZE",id)
                    -- A deliberate refusal is native fallback, not a completed
                    -- initializer. Contained module exceptions retain the
                    -- established optional-module quarantine semantics.
                    mod.initialized=ok and value~=false and mod.status~="WAITING_FOR_OUT_OF_COMBAT" and mod.status~="SECURE_PATH_UNAVAILABLE" and mod.status~="CONFLICT_NATIVE_OWNER"
                    if not ok then
                        mod.initializationFailed=true;mod.quarantined=true;mod.status="INITIALIZATION_FAILED_RELOAD_REQUIRED"
                        phase("MODULE_CLEANUP",id);self:CleanupOwned(id);self.Native:Restore(id)
                    end
                elseif mod.Resume then phase("MODULE_RESUME",id);self:Guard(id,mod.Resume,mod) end
                if mod.initialized and mod.ApplyConfig then phase("MODULE_CONFIG",id);self:Guard(id,mod.ApplyConfig,mod) end
            else
                mod.suspended=true
                if mod.initialized and mod.Suspend then phase("MODULE_SUSPEND",id);self:Guard(id,mod.Suspend,mod) end
                if mod.initializationFailed then phase("MODULE_CLEANUP",id);self:CleanupOwned(id) end
                if not mod.quarantined then mod.status=self.state.safe and "SAFE_MODE" or conflict and "CONFLICT_NATIVE_OWNER" or "DISABLED" end
            end
        end
        phase("THEME");self.UI:RefreshTheme()
        phase("FONTS");self.UI:RefreshFonts()
        phase("LAYOUT");self.Layout:ApplyAll()
        phase("EVENTS");self:RefreshEvents()
        phase("SIGNALS");self.Signals:Observe()
        phase("PRESENTATION");self.Presentation:Refresh()
        phase("CVE");self.CVE:Tick(true)
        if self.ManagedNative then
            phase("MANAGED_CONFIGURE");self.ManagedNative:Configure()
            phase("RESOURCE_PREFERENCE")
            if self.Managed:Enabled() then self.ManagedNative:ResourcePreference(true) end
        end
        if not current() then failureCategory="OWNERSHIP_CHANGED";error("APPLY_OWNERSHIP_CHANGED",0) end
    end,function() return captureFailure(stage) end)
    local failedStage,failedOwner=stage,owner
    if not applied then self:RecordApplyFailure(attempt,failureCategory) end
    -- Finalization is protected too. A throwing End must never strand the
    -- applying latch or erase an earlier failed stage during rollback.
    if typographyAttempted then
        self:ApplyPhase(attempt,"TYPOGRAPHY_END","Core")
        local owned=rawequal(self.UnitTypography,typography) and rawequal(typography.End,typographyEnd)
        local finalized=owned and xpcall(function() return typographyEnd(typography) end,function() return captureFailure("TYPOGRAPHY_END") end)
        if not finalized then
            applied=false;failureCategory=owned and "FINALIZE_FAILED" or "OWNERSHIP_CHANGED";self:RecordApplyFailure(attempt,failureCategory)
        elseif not applied then self:ApplyPhase(attempt,failedStage,failedOwner) end
    end
    self.applying=false
    if applied and current() then
        self.state.applyPending=nil;self.state.applyPendingForce=nil;self.state.applyPendingTrigger=nil;self:ApplyPhase(attempt,"COMPLETE","Core")
        if self.Managed and self.Managed.ProfileApplied then self.Managed:ProfileApplied(adaptiveFitComplete) end
        if self.Profiles and type(self.Profiles.Export)=="function" then
            local ok,wire=pcall(self.Profiles.Export,self.Profiles);if ok and type(wire)=="string" then self.state.appliedProfileWire=wire end
        end
        return finish((self.state.safe or not self.profile.enabled or not self.Client.allowed) and "STOPPED" or "COMPLETE")
    end
    if current() then self:Fault("Core","PROFILE_APPLY_FAILED",failureEvidence) end
    return finish("FAILED",failureCategory)
end
function M:CreateLauncher()
    if self.launcher then return end
    local b=CreateFrame("Button","MirageUILauncher",UIParent,"BackdropTemplate");self.launcher=b
    b:SetSize(28,28);b:SetPoint("TOPRIGHT",UIParent,"TOPRIGHT",-22,-22);b:SetFrameStrata("MEDIUM")
    self.UI:Backdrop(b,true)
    local icon=b:CreateTexture(nil,"ARTWORK");b.icon=icon;icon:SetAllPoints();icon:SetTexture("Interface\\AddOns\\MirageUI\\Media\\MirageUIBadge.tga")
    b:SetScript("OnClick",function() self:LoadOptions() end)
    if self.SuiteLauncher then self.SuiteLauncher:BindButton(b) end
    b:RegisterForClicks("LeftButtonUp","RightButtonUp")
    b:SetScript("OnEnter",function()
        if GameTooltip then GameTooltip:SetOwner(b,"ANCHOR_LEFT");GameTooltip:SetText("MirageUI");GameTooltip:AddLine("Left click: addon menu. Right click: MirageUI settings.",1,1,1);GameTooltip:Show() end
    end)
    b:SetScript("OnLeave",function() if GameTooltip then GameTooltip:Hide() end end)
end
function M:MaybeOfferSetup()
    if not self.state.initialized or not self.state.world or not self.profile or not self.Experience then return false end
    if self.Experience:Offered() or self.Profiles.readOnly then self.state.setupPending=nil;return false end
    if self.Safety:InCombat() or self.state.cinematic then self.state.setupPending=true;return false end
    if self.StartupPresentation then self.StartupPresentation:Cancel("SETUP_WINDOW") end
    self:LoadOptions(true)
    if self.PlayerSettings then
        local opened=self.PlayerSettings:Open("welcome")
        if opened==true then self.state.setupPending=nil;self.state.setupAttempts=nil;self.state.setupNextAttempt=nil;self.Experience.offered=true;return true end
    end
    self.state.setupPending=true
    return false
end
function M:Initialize()
    if self.state.initialized then return end
    self.Client:Detect();self.Capabilities:Probe();self.Profiles:Initialize()
    local objectives=self.Rework and self.Rework.Objectives
    if objectives and objectives.events and self.Client.family=="Forever" then
        local monthly=eventValid("MONTHLY_ACTIVITIES_UPDATED")
        -- Both field reports identified this optional event as unavailable.
        -- Prefer the live API's answer, including on either recorded build.
        local knownAbsent=self.Client.patch=="1.60.1" and self.Client.interface==16001
            and (self.Client.build=="71091" or self.Client.build=="71139")
        if monthly==false or (monthly==nil and knownAbsent) then
            objectives.events.MONTHLY_ACTIVITIES_UPDATED=nil
        end
    end
    if self.Incidents then self.Incidents:Initialize() end
    if not self.Profiles.readOnly then
        self.Client:RefreshCandidatePermission();self.Capabilities:Probe()
        self.state.safe=self.db.safe==true or not self.Client.allowed
        self:RestoreSafeIntent()
    end
    if self.WorldCombatText then self.WorldCombatText:Initialize() end
    self.Commands:Register();self:CreateLauncher();self.state.initialized=true
    if self.StartupPresentation then self.StartupPresentation:Initialize() end
    if self.BuildInfo then self.BuildInfo:CaptureStartup() end
    self:RefreshEvents()
    -- Routine load completion belongs in /mirage check. Actionable failures
    -- below still appear immediately; ordinary startup does not create chat.
    if self.state.safe or not self.Client.allowed then self:Print(self.Diagnostics:Status()) end
end
function M:Event(event,...)
    local arg1=...
    if event=="ADDON_LOADED" and arg1==self.name then self:Initialize() end
    if not self.state.initialized then return end
    -- A protected operation reports its rejection synchronously, inside the
    -- original native callback. Do not run presentation, signal observers or
    -- whole-suite cleanup recursively from that stack. Record the source and
    -- queue the affected display's handback; healthy combat displays keep
    -- their current cast and hit-text ownership.
    if event=="ADDON_ACTION_BLOCKED" or event=="ADDON_ACTION_FORBIDDEN" then
        if arg1==self.name or arg1=="MirageUIOptions" or arg1=="MirageUICursor" then
            local r=self.Rework
            local operation=select(2,...)
            local okay=pcall(function()
                if r and r.RecordNativeBlock then
                    local entry=r:RecordNativeBlock(event,arg1,operation)
                    if r.HandleNativeBlock then r:HandleNativeBlock(entry) end
                end
            end)
            if not okay then self.state.nativeBlockReportFailures=math.min(9999,(self.state.nativeBlockReportFailures or 0)+1) end
        end
        return
    end
    if self.StartupPresentation then self.StartupPresentation:BeforeEvent(event) end
    if self.DisplayOcclusion then self.DisplayOcclusion:Event(event) end
    if self.Inventory then self.Inventory:BankEvent(event) end
    -- Revoke former-zone activity before admitting this zone's local status cue.
    local zoneChanged=event=="ZONE_CHANGED" or event=="ZONE_CHANGED_NEW_AREA" or event=="ZONE_CHANGED_INDOORS"
    if zoneChanged then self.Policy:InvalidateScope("ZONE_CHANGED") end
    self.Signals:Event(event,...)
    if zoneChanged and self.state.world then
        -- Scope retirement clears every desired state. Re-observe and resolve
        -- in this event turn before provider callbacks queue rendering work;
        -- otherwise the sidebar can consume the empty decision for a frame.
        self.Signals:Observe();self.state.forceEvaluate=true;self.CVE:Tick(true)
    end
    if event=="PLAYER_ENTERING_WORLD" then
        self:ResumeHistoricalNativeStop()
        self.state.world=true;self.Policy:InvalidateScope("WORLD_ENTERED");self.Signals:Reset();self:ApplyProfile(nil,"WORLD_ENTERED")
        self:MaybeOfferSetup()
        if self.KeybindWorkspace then self.KeybindWorkspace:AnnounceRecovered() end
    elseif event=="ADDON_LOADED" and (arg1=="ElvUI" or arg1=="EllesmereUI") then
        self:ApplyProfile(nil,"OWNER_CHANGED")
    elseif event=="PLAYER_LOGOUT" then
        if self.KeybindWorkspace and self.KeybindWorkspace.session then self.KeybindWorkspace:Persist() end
        if self.WorldCombatText then self.WorldCombatText:Restore() end
    elseif event=="PLAYER_LEAVING_WORLD" then
        if self.WorldCombatText then self.WorldCombatText:Restore() end
        if self.CombatLenses then self:Guard("PvP",self.CombatLenses.CancelTransition,self.CombatLenses,"WORLD_LEFT",true) end
        local preparations=self.modules.Preparations
        if preparations and preparations.initialized then self:Guard("Preparations",preparations.OnEvent,preparations,event) end
        if self.Profiler then self.Profiler:Stop() end
        if self.BindingEditor then self.BindingEditor:Close() end
        if self.ActionKeys then self.ActionKeys:Cancel() end
        if self.HUDEditor then self.HUDEditor:Close() end
        if self.NameplateCards then self.NameplateCards:Suspend() end
        if self.ObservedContacts then self.ObservedContacts:Clear() end
        if self.EmpoweredCast then self.EmpoweredCast:Clear("WORLD_LEFT") end
        if self.AccessibleInput then self.AccessibleInput:Stop() end
        if self.UnderCharacterHUD and self.UnderCharacterHUD.view then self:Guard("UnderCharacterHUD",self.UnderCharacterHUD.Suspend,self.UnderCharacterHUD) end
        self.state.world=false;self.Policy:InvalidateScope("WORLD_LEFT");self.Signals:Reset();self.CVE.holds={}
        if self.Cursor then self.Cursor:Stop() end
        for _,surface in pairs(self.surfaces) do self.Effects:Stop(surface) end
        self.Native:RestoreAll();self.CVE:Tick(true)
    elseif event=="ENCOUNTER_STATE_CHANGED" or event=="ENCOUNTER_START" or event=="ENCOUNTER_END" then
        -- Invalidation happened in Signals.Event; payload never establishes truth.
        -- Reconcile before the next Effects.Tick, not only the periodic batch.
        if self.profile then
            if self.Signals:EncounterAllowed() then self.Signals:Observe() end
            self.CVE:Tick(true) -- withdrawal also reconciles when a source is no longer allowed
        end
    elseif event=="PLAYER_REGEN_DISABLED" then
        if self.ElementMap then self.ElementMap:PauseForCombat() end
        if self.Workspace then self.Workspace:HidePreserve() end
        if self.Experience then self.Experience:ClosePreview() end
        if self.PlayerSettings then self.PlayerSettings:Close() end
        if self.VisualPreview and self.VisualPreview.frame then self.VisualPreview.frame:Hide() end
        if self.SourceLibrary and self.SourceLibrary.frame then self.SourceLibrary.frame:Hide() end
        if self.BindingEditor then self.BindingEditor:Close() end
        if self.ActionKeys then self.ActionKeys:Cancel() end
        if self.HUDEditor then self.HUDEditor:Close() end
        if self.Editor then self.Editor:Close() end
        if self.Options and self.Options.frame then self.Options.frame:Hide() end
        self.Signals:Observe();self.CVE:Tick(true)
    elseif event=="PLAYER_REGEN_ENABLED" then
        local historicalResume=self:ResumeHistoricalNativeStop()
        if self.AccessibleInput and self.AccessibleInput.cleanupPending then self.AccessibleInput:Stop() end
        if self.state.safeCleanupPending then self:ProcessSafeCleanup(true) end
        self.Native:RetryRestores();if self.Managed.pendingResize then self.Managed:Resize() end
        -- Combat ending is not a settings revision. Only an actual deferred
        -- user change may take the full profile path. Provider cleanup and
        -- deferred geometry are reconciled by their own keyed requests.
        if self.state.applyPending then self:ApplyProfile(self.state.applyPendingForce,self.state.applyPendingTrigger or "PROFILE")
        elseif historicalResume and self.state.world then self:ApplyProfile(nil,"COMBAT_ENDED") end
        self.state.forceEvaluate=true;self.state.combatExitObservation=true;self:MaybeOfferSetup()
    elseif event=="CINEMATIC_START" then if self.AccessibleInput then self.AccessibleInput:Stop() end;if self.HUDEditor then self.HUDEditor:Close() end;self.state.cinematic=true;self.CVE:Tick(true)
    elseif event=="CINEMATIC_STOP" then self.state.cinematic=false;self.CVE:Tick(true);self:MaybeOfferSetup()
    elseif event=="UI_SCALE_CHANGED" or event=="DISPLAY_SIZE_CHANGED" then
        if self.Managed then self.Managed:Resize() end
    end
    for _,id in ipairs(self.maintenanceListeners[event] or {}) do self:MaintainSecure(id,event,...) end
    for _,id in ipairs(self.eventListeners[event] or {}) do
        local mod=self.modules[id]
        if mod and self:IsModuleActive(id) and mod.OnEvent then self:Guard(id,mod.OnEvent,mod,event,...) end
    end
    if self.ManagedNative and self.profile.managed then
        if event=="ADDON_LOADED" and self.ManagedNative.OnNativeAddonLoaded then self.ManagedNative:OnNativeAddonLoaded()
        elseif event=="ADDON_LOADED" or event=="GROUP_ROSTER_UPDATE" then self.ManagedNative.reconcilePending=true end
    end
    if self.ContextualNative and self.ContextualNative.OnNativeLifecycle and (event=="ADDON_LOADED" or event=="PLAYER_ENTERING_WORLD") then
        self.ContextualNative:OnNativeLifecycle(event)
    end
    if self.Presentation:RelevantEvent(event,arg1) then self.Presentation:Refresh() end
    self.state.dirty=true
end
f:RegisterEvent("ADDON_LOADED")
f:SetScript("OnEvent",function(_,event,...) local ok=pcall(M.Event,M,event,...);if not ok then M:Fault("Core","EVENT_FAILED") end end)
-- Main event-frame clock. Every optional provider uses this same queue; fades
-- remain frame-synchronous and necessary safety work is ahead of cosmetics.
local elapsed,observationElapsed,maintenanceElapsed=0,0,0
local moduleJobs={}
local function secureMaintenanceNeeded()
    for _,id in ipairs({"UnitFrames","PartyRaid","ActionBars"}) do if M:IsSecureCleanupActive(id) then return true end end
    return false
end
local function fontMaintenanceNeeded(now,combat)
    local notices=M.modules.Notifications
    return not combat and notices and notices.fontRestorePending and (notices.fontRetryCount or 0)<3
        and now>=(notices.fontRetryAt or 0) and type(notices.RetryFonts)=="function"
end
local function worldTextMaintenanceNeeded(now,combat)
    local world=M.WorldCombatText
    return not combat and world and type(world.Pending)=="function" and world:Pending()
        and now>=(world.retryAt or 0) and (not world.restorePending or (world.retryCount or 0)<3)
end
local function artMaintenanceNeeded(_,combat)
    if combat or not M.ManagedNative then return false end
    if M.NativePresentation and M.NativePresentation:Pending() then return true end
    for _,row in pairs(M.ManagedNative.rows or {}) do
        for _,receipt in pairs(row.art or {}) do
            if receipt.pending and not receipt.reloadRequired and (receipt.retries or 0)<3 then return true end
        end
    end
    return false
end
local function hoverMaintenanceNeeded(_,combat)
    if combat or not M.ManagedNative or not M.ManagedNative.RetryHoverRestore then return false end
    for _,row in pairs(M.ManagedNative.rows or {}) do
        if row.active and row.hoverMode and row.restorePending and (row.restoreFailures or 0)<3 then return true end
    end
    return false
end
local function cardMaintenanceNeeded()
    -- Pending cards can still supply essential data while their native-body
    -- handback waits. This is the actual journal, including during combat.
    return M.NameplateCards and next(M.NameplateCards.pending or {})~=nil
end
local function activeGame()
    return M.state.initialized and M.profile and M.Client.allowed and M.state.world
        and not M.state.safe and M.profile.enabled
end
local function observe()
    if not activeGame() then return end
    local queue=M.RuntimeScheduler
    local start=queue and queue.StageClock and queue:StageClock()
    M.Signals:Observe()
    if start then queue:RecordObservationStage("Signals",start,queue:StageClock()) end
    M.CVE:Tick()
end
local function managed()
    if activeGame() and M.ManagedNative then M.ManagedNative:Tick() end
end
local function reworkNeeded()
    local r=M.Rework
    if not r or not r.Tick then return false end
    -- Live ownership and retained cleanup must still reach their legal
    -- handback. Once both settle, an inactive/refused session has no provider
    -- work to schedule. Active sessions keep the ordinary editor observation,
    -- discovery, visibility and provider liveness paths.
    return r.live or r.pendingStop or activeGame() and r.storageReady and not r.rolledBack or false
end
local function rework(now)
    if reworkNeeded() then M.Rework:Tick(now) end
end
local function maintainFonts(now)
    local notices=M.modules.Notifications
    if fontMaintenanceNeeded(now,M.Safety:InCombat()) then
        local good=pcall(notices.RetryFonts,notices,now)
        if not good then notices.fontRetryCount=3;M:Fault("Notifications","NATIVE_RESTORE_FAILED") end
    end
end
local function maintainWorldText(now)
    if worldTextMaintenanceNeeded(now,M.Safety:InCombat()) then
        local good=pcall(M.WorldCombatText.Retry,M.WorldCombatText,now)
        if not good then M.WorldCombatText.retryCount=3;M:Fault("Notifications","NATIVE_RESTORE_FAILED") end
    end
end
local function maintainArt(now)
    if artMaintenanceNeeded(now,M.Safety:InCombat()) then
        local good=pcall(M.ManagedNative.RetryArt,M.ManagedNative)
        if not good then M:Fault("ActionBars","ART_RESTORE_FAILED") end
    end
end
local function maintainHover(now)
    if hoverMaintenanceNeeded(now,M.Safety:InCombat()) then
        local good=pcall(M.ManagedNative.RetryHoverRestore,M.ManagedNative)
        if not good then M:Fault("ActionBars","HOVER_RESTORE_FAILED") end
    end
end
local function maintainCards(now)
    if cardMaintenanceNeeded() then
        local good=pcall(M.NameplateCards.Maintain,M.NameplateCards,now)
        if not good then M:Fault("Nameplates","CARD_RESTORE_FAILED") end
    end
end
local maintenanceJobs={
    {key="Core.Maintenance.Fonts",needed=fontMaintenanceNeeded,run=maintainFonts,combat="defer"},
    {key="Core.Maintenance.WorldText",needed=worldTextMaintenanceNeeded,run=maintainWorldText,combat="defer"},
    {key="Core.Maintenance.Art",needed=artMaintenanceNeeded,run=maintainArt,combat="defer"},
    {key="Core.Maintenance.Hover",needed=hoverMaintenanceNeeded,run=maintainHover,combat="defer"},
    {key="Core.Maintenance.Cards",needed=cardMaintenanceNeeded,run=maintainCards,combat="allow"},
}
local function secureMaintenance(now)
    for _,id in ipairs({"UnitFrames","PartyRaid","ActionBars"}) do M:MaintainSecure(id,"TICK",now) end
end
f:SetScript("OnUpdate",function(_,dt)
    if not M.state.initialized or not M.profile or not M.Safety:Number(dt) then return end
    local now=M.Safety:Now();local q=M.RuntimeScheduler
    M.state.captureFrame=(M.state.captureFrame or 0)+1
    -- The observer owns its read/notification budgets. It also watches for a
    -- missed native display event and drains startup wake debt after a sample
    -- was published, when pendingResize is already false.
    if M.Managed then M.Managed:TickViewport(now) end
    if M.state.setupPending and M.state.world and not M.Safety:InCombat() and not M.state.cinematic
        and now>=(M.state.setupNextAttempt or 0) then
        M.state.setupNextAttempt=now+1;M.state.setupAttempts=(M.state.setupAttempts or 0)+1
        M:MaybeOfferSetup()
        if M.state.setupPending and (M.state.setupAttempts or 0)>=5 then
            M.state.setupPending=nil;M:Print("Setup is available from /mirage setup. Your saved choices have been retained.")
        end
    end
    if M.state.safeCleanupPending then
        local safe=pcall(M.ProcessSafeCleanup,M)
        if not safe then M.state.safe=true;M.state.safeCleanupPending=true end
    end
    if next(M.cleanupModules) then
        local clean=pcall(M.ProcessQuarantines,M);if not clean then M:Fault("Core","CLEANUP_FAILED") end
    end
    if M.PrivateAuras and M.PrivateAuras.pending and (M.PrivateAuras.removeFailures or 0)<3 and now>=(M.PrivateAuras.retryAt or 0) and not M.Safety:InCombat() then
        local clean=pcall(M.PrivateAuras.Retry,M.PrivateAuras)
        if not clean then M:Fault("Auras","PRIVATE_ANCHOR_CLEANUP_FAILED") end
    end
    if next(M.Effects.active) or (M.Effects.Pending and M.Effects:Pending()) then
        local token=M.Profiler and M.Profiler:BeginPhase("Visibility.Fade")
        local effectsOK=pcall(M.Effects.Tick,M.Effects,now)
        if token then M.Profiler:EndPhase(token,effectsOK) end
        if not effectsOK then M:Fault("Core","EFFECT_FAILED") end
    end
    maintenanceElapsed=maintenanceElapsed+math.min(dt,.25)
    observationElapsed=observationElapsed+math.min(dt,.25)
    elapsed=elapsed+math.min(dt,.25)
    if maintenanceElapsed>=.50 then
        maintenanceElapsed=0
        -- A live receipt in one service never starts unrelated restore scans.
        -- Separate jobs also let the scheduler yield between independent work.
        local combat=M.Safety:InCombat()
        for _,job in ipairs(maintenanceJobs) do
            if job.needed(now,combat) then q:Request(job.key,job.run,{combat=job.combat,generation=false,priority=2,owner="Core"}) end
        end
    end
    if observationElapsed>=.10 or M.state.combatExitObservation then
        M.state.combatExitObservation=nil;observationElapsed=0
        if activeGame() then q:Request("Core.Observation",observe,{combat="allow",priority=0,owner="Core",critical=true}) end
    end
    if elapsed>=.20 then
        elapsed=0
        if secureMaintenanceNeeded() then q:Request("Core.SecureMaintenance",secureMaintenance,{combat="allow",generation=false,priority=0,owner="Core",critical=true}) end
        if reworkNeeded() then q:Request("Core.Rework",rework,{combat="allow",generation=false,priority=1,owner="Rework"}) end
        if activeGame() then
            q:Request("Core.Managed",managed,{combat="allow",priority=2,owner="Core",critical=true})
            for _,id in ipairs(M.order) do
                local mod=M.modules[id]
                if M:IsModuleActive(id) and mod.Tick then
                    local row=moduleJobs[id]
                    if not row or row.module~=mod then
                        local owner,instance=id,mod
                        row={module=instance,fn=function(t) M:Guard(owner,instance.Tick,instance,t) end,
                            guard=function() return activeGame() and M.modules[owner]==instance and M:IsModuleActive(owner) end}
                        moduleJobs[id]=row
                    end
                    q:Request("Module."..id,row.fn,{combat="allow",priority=3,owner=id,guard=row.guard})
                end
            end
        end
    end
    local ok=pcall(q.Tick,q)
    if not ok then q.running=false;M:Fault("Core","SCHEDULER_FAILED") end
end)
