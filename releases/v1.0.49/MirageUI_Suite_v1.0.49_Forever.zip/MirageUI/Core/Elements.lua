local _,M=...
-- Shared inventory used by search, the editor and context preferences. Live
-- registrations augment the catalogue; absence never fabricates a live frame.
local E={definitions={}}
M.Elements=E
local combat={Combat=true};local travel={Moving=true};local all={Idle=true,Moving=true,Combat=true}
E.contextColors={All={1,.61,.23},Idle={.68,.70,.77},Moving={.30,.79,.91},Combat={1,.41,.23}}
local function add(id,name,module,x,y,w,h,contexts,kind,keywords)
 E.definitions[id]={id=id,name=name,module=module,layout={x=x,y=y,width=w,height=h,scale=1},contexts=contexts or all,kind=kind or "layout",keywords=keywords or ""}
end
add("UnitFrames.player","Player","UnitFrames",-.19,-.24,240,55,combat)
add("UnitFrames.target","Target","UnitFrames",.19,-.24,240,55,combat)
add("UnitFrames.focus","Focus","UnitFrames",.30,.1,220,55,combat)
add("UnitFrames.pet","Pet","UnitFrames",-.19,-.32,190,44,combat)
add("UnitFrames.targettarget","Target's Target","UnitFrames",.19,-.32,190,44,combat,"layout","targettarget target of target pet grayscale")
add("PartyRaid.partyFrame","Party frame","PartyRaid",-.40,.15,200,280,combat,"layout","party group whole move resize scale")
add("PartyRaid.raidFrame","Raid frames","PartyRaid",-.35,.15,320,300,combat,"layout","raid group whole move resize scale")
for i=1,5 do add("UnitFrames.boss"..i,"Boss "..i,"UnitFrames",.30,.32-i*.075,210,50,combat) end
for i=1,4 do add("PartyRaid.party"..i,"Party member "..i,"PartyRaid",-.40,.35-i*.09,182,50,combat) end
for i=1,40 do add("PartyRaid.raid"..i,"Raid member "..i,"PartyRaid",-.43+math.floor((i-1)/8)*.08,.36-((i-1)%8)*.055,90,36,combat) end
for i=1,8 do add("PartyRaid.group"..i,"Raid subgroup "..i,"PartyRaid",-.38+((i-1)%4)*.12,.30-math.floor((i-1)/4)*.24,160,200,combat,"group") end
for i=1,3 do add("ActionBars.bar"..i,"Action bar "..i,"ActionBars",0,-.43+(i-1)*.05,420,38,combat) end
for i=4,8 do
 local vertical=i<=5
 add("ActionBars.bar"..i,"Action bar "..i,"ActionBars",vertical and (.46-(i-4)*.03) or 0,vertical and 0 or (-.28+(i-6)*.05),vertical and 38 or 420,vertical and 420 or 38,combat,"nativePosition","extra action buttons side bar")
end
add("ActionBars.interface","Action bar interface","ActionBars",0,-.36,468,252,all,"layout","action buttons three rows fixed layout pet stance totem more actions scale")
add("Minimap.nativePosition","Minimap","Minimap",.40,.34,220,220,travel,"nativePosition","map navigation square")
add("QuestTracker.nativePosition","Quest list","QuestTracker",.40,.06,220,360,travel,"nativePosition","objectives quests tracker")
add("Chat.nativePosition","Chat","Chat",-.37,-.29,380,170,all,"nativePosition","messages communication")
add("Auras.BuffFrame","Buffs","Auras",.25,.41,300,64,combat,"native","beneficial auras buffs")
add("Auras.DebuffFrame","Debuffs","Auras",.25,.32,300,64,combat,"native","harmful auras debuffs")
add("Auras.player","Player aura panel","Auras",.1,.38,320,108,combat)
add("Auras.preparation","Aura reminders","Auras",-.35,.06,280,118,all)
add("Auras.private","Private aura anchors","Auras",0,.40,152,44,combat)
add("UnderCharacterHUD.player","Under-character bars","UnderCharacterHUD",0,-.16,205,36,combat,"hud","health power cast")
add("UnderCharacterHUD.nativeCast","Player cast bar","UnderCharacterHUD",0,-.25,280,32,combat,"nativePosition","cast channel spell progress native")
add("ResourceBars.player","Resources & casts","ResourceBars",0,-.25,220,78,combat)
add("ResourceBars.class","Class resource","ResourceBars",0,-.08,200,42,combat)
add("ResourceBars.runes","Runes","ResourceBars",0,-.08,200,62,combat)
add("ResourceBars.totems","Totems & temporary summons","ResourceBars",0,.05,230,64,combat)
add("ResourceBars.empower","Empowered cast stages","ResourceBars",0,-.27,240,54,combat)
add("Cooldowns.tracked","Tracked cooldowns","Cooldowns",0,-.35,400,44,combat)
add("Cooldowns.row","Tracked cooldown row","Cooldowns",0,-.22,421,50,all,"layout","cooldown manager tracked spells charges aura order under character HUD")
add("QuestTracker.compact","Compact objectives","QuestTracker",.38,.1,270,300,travel)
add("DamageMeters.summary","Damage summary","DamageMeters",.36,-.32,250,180,combat)
add("DamageMeters.native","Game damage meter","DamageMeters",.36,-.32,250,180,combat,"native")
add("DamageMeters.mirage","Meters","DamageMeters",.36,-.32,320,310,all,"layout","damage healing dps hps absorbs interrupts dispels deaths combat meters")
add("Tooltips.anchor","Tooltips","Tooltips",.32,-.32,240,80,all,"layout","tooltip insight anchor mouse cursor move size scale placement")
add("Bags.browser","Inventory browser","Bags",.12,0,560,500,all)
add("Bags.inventory","Bags","Bags",.12,0,420,450,all,"layout","inventory items slots backpack bank bags")
add("PvP.lens","PvP emphasis","PvP",0,.43,200,24,combat)
add("PvP.observed","Observed group contacts","PvP",.32,.08,260,290,combat)
add("TacticalSignals.legend","Tactical conventions","TacticalSignals",.34,.15,260,200,all)
add("Notifications.durability","Durability alert","Notifications",.4,-.3,225,30,travel,"layout","equipment repair low durability warning sidebar")
add("Notifications.feed","Activity notifications","Notifications",.13,-.15,340,144,all,"layout","loot gold profession receipts")
add("Notifications.combatText","Floating combat text","Notifications",0,.12,300,220,combat,"world","damage healing numbers")
add("Nameplates.world","World nameplates","Nameplates",0,.25,240,50,combat,"world","enemy friendly health cast bars")
for _,row in ipairs({{"PetActionBar","Pet action bar"},{"StanceBar","Stance bar"},{"BagsBar","Bag buttons"},{"MicroMenuContainer","Menu buttons"}}) do
 add("NativeControls."..row[1],row[2],"ActionBars",-.35,-.39,230,36,combat,"nativePosition","action control system menu inventory")
end
for _,row in ipairs({{"PossessActionBar","Possession controls"},{"OverrideActionBar","Vehicle / override actions"},{"MainMenuBarVehicleLeaveButton","Leave vehicle"},{"ExtraAbilityContainer","Extra / zone ability"}}) do
 add("NativeControls."..row[1],row[2],"ActionBars",0,-.34,row[1]=="MainMenuBarVehicleLeaveButton" and 36 or 320,42,combat,"nativePosition","special actions vehicle override possession zone")
end
for i,name in ipairs({"EssentialCooldownViewer","UtilityCooldownViewer","BuffIconCooldownViewer","BuffBarCooldownViewer"}) do
 add("Cooldowns."..name,({"Essential cooldowns","Utility cooldowns","Buff cooldowns","Buff duration bars"})[i],"Cooldowns",0,-.20+(i-1)*.06,300,40,combat,"native","cooldowns duration spells buffs")
end
add("NativeControls.MainStatusTrackingBarContainer","Experience / reputation bar","ActionBars",0,-.47,500,16,combat,"nativePosition","experience xp reputation honor progress")
add("NativeControls.SecondaryStatusTrackingBarContainer","Secondary progress bar","ActionBars",0,-.45,500,16,combat,"nativePosition","experience xp reputation honor progress")
add("Preparations.overview","Preparations workspace","Preparations",-.29,.05,340,400,all,"window")
add("BlizzardSkin.windows","Game task windows","BlizzardSkin",-.30,.15,360,420,all,"window")
add("BlizzardSkin.character","Character, progression & professions","BlizzardSkin",-.30,.15,360,420,all,"window","equipment inspect spells talents macros auction trainer profession")
add("BlizzardSkin.system","Social, system & collections","BlizzardSkin",-.30,.15,360,420,all,"window","friends guild groups pvp settings bindings addon achievements calendar collections help")
local aliases={MinimapCluster="Minimap",ObjectiveTrackerFrame="Quest list",summary="Summary",player="Player",target="Target",focus="Focus",overlay="Cursor effects"}
-- Optional renderers remain optional even when their parent module is enabled.
-- The inventory is a settings catalogue, not evidence that a renderer is live.
local featureSwitches={
 ["Auras.player"]="playerPanel",["Auras.preparation"]="preparation",["Auras.private"]="privateAuras",
 ["Cooldowns.tracked"]="tracker",["QuestTracker.compact"]="compactPanel",["DamageMeters.summary"]="summary",
 ["DamageMeters.mirage"]="metersEnabled",
 ["PvP.lens"]="badge",["PvP.observed"]="contacts",["TacticalSignals.legend"]="legend",["Bags.browser"]="browser",
 ["ResourceBars.class"]="classResource",["ResourceBars.runes"]="runes",["ResourceBars.totems"]="totems",
 ["ResourceBars.empower"]="empoweredStages",["Notifications.combatText"]="combatText",
}
-- Provider descriptors are read-only. They connect catalogue entries to a real
-- layout consumer without treating allocation, a sample or a native lease as
-- proof that the game painted the requested presentation.
local S=M.Safety
local nativeUnits={player="PlayerFrame",target="TargetFrame",targettarget="TargetFrameToT",focus="FocusFrame",pet="PetFrame"}
for i=1,5 do nativeUnits["boss"..i]="Boss"..i.."TargetFrame" end
local nativeNames={ ["DamageMeters.native"]="DamageMeter" }
local actionSettings={actionExperience=true,interfaceScale=true,columns=true,buttonCount=true,vertical=true,gap=true,showHotkeys=true,centerHotkeys=true,hotkeySize=true,hideMacroText=true,showTooltips=true,allowRearrange=true,scale=true,alpha=true}
local layoutRefusals={ANCHOR_UNAVAILABLE=true,NATIVE_SIZE_UNAVAILABLE=true,NATIVE_LAYOUT_FALLBACK=true,NEWER_LAYOUT_PRESERVED=true,
 POSITION_FAILED_NATIVE_RESTORED=true,LAYOUT_REQUEST_RETIRED=true}
local function code(value)
 if S:Text(value) and #value<=96 and value:match("^[A-Z][A-Z0-9_]*$") then return value end
 return "UNAVAILABLE"
end
local function public(frame,key,kind,...)
 if not S:Frame(frame,false) then return nil,"UNAVAILABLE" end
 local ok,fn=pcall(function() return frame[key] end)
 if not ok or not S:Readable(fn) then return nil,"UNAVAILABLE" end
 return S:Public(fn,kind,frame,...)
end
local function frameAvailable(frame) return frame~=nil and S:Frame(frame,false)==true end
local function presence(unit)
 if not S:Text(unit) then return nil end
 local value,status=S:Public(UnitExists,"boolean",unit)
 if status=="KNOWN" then return value end
end
-- One authoritative, read-only native editor observation for every adapter.
-- UNKNOWN is a hold, not an OPEN/CLOSED transition and never a cleanup request.
function E:NativeEditorState()
 local frame=_G.EditModeManagerFrame
 if not S:Readable(frame) then return "UNKNOWN","NATIVE_EDIT_UNREADABLE" end
 if frame==nil then return "CLOSED","NATIVE_EDIT_ABSENT" end
 local shown,status=public(frame,"IsShown","boolean")
 if status~="KNOWN" then return "UNKNOWN","NATIVE_EDIT_UNREADABLE" end
 return shown and "OPEN" or "CLOSED",shown and "NATIVE_EDIT_ACTIVE" or "NATIVE_EDIT_CLOSED"
end
function E:IsNativeGeometry(idOrRoot,profile)
 if M.NativeLayout and M.NativeLayout:IsDelegated(idOrRoot)==true then return true end
 if type(idOrRoot)=="string" and (idOrRoot:match("^UnitFrames%.") or idOrRoot:match("^PartyRaid%.")) then
  local owner=M.Rework and M.Rework:ProviderForLayout(idOrRoot,profile or M.profile)
  if owner and type(owner.object.OwnsGeometry)=="function" and owner.object:OwnsGeometry(idOrRoot,profile or M.profile) then return false end
  if owner and type(owner.object.OwnsPosition)=="function" and owner.object:OwnsPosition(idOrRoot,profile or M.profile) then return false end
  return owner and owner.object and owner.object.nativeBacked==true or false
 end
 return false
end
function E:EditingAllowed()
 local state=self:NativeEditorState()
 if state=="UNKNOWN" then return false,"Blizzard Edit HUD cannot be checked safely. Mirage editing is paused; your draft is retained.","NATIVE_EDIT_UNKNOWN" end
 if state=="OPEN" then return false,"Finish Blizzard Edit HUD using its own Save or Cancel controls, then reopen MirageUI. Your Mirage draft is retained.","NATIVE_EDIT_ACTIVE" end
 return true
end
function E:SettingSupported(module,key,profile)
 profile=profile or M.profile
 if M.NativeWindowPolicy and M.NativeWindowPolicy:ModuleNative(module) then
  return false,"Native by design. The game owns these windows, tooltips, placement and appearance. Earlier Mirage preferences remain saved but inactive."
 end
 local rework=M.Rework
 local unitID=module=="UnitFrames" and "UnitFrames.player" or module=="PartyRaid" and "PartyRaid.group1"
 local nativeOwner=unitID and rework and rework:ProviderForLayout(unitID,profile)
 if nativeOwner and nativeOwner.object.nativeBacked==true then
  local geometry={scale=true,referenceLayout=true,nativeGroups=true,raidColumns=true,cellWidth=true,cellHeight=true,cellGap=true}
  local visibility={visibility=true,contextualNative=true,alpha=true}
  local formerPresentation={style=true,classColors=true,nativeAuras=true,showCast=true,showAuras=true,showBuffs=true,auraSlots=true,debuffAccent=true,groupTitles=true,compactRaid=true}
  if geometry[key] or key:match("^group%dGrowth$") or key:match("^group%dGap$") then
   if module=="UnitFrames" and key=="referenceLayout" and type(nativeOwner.object.OwnsPosition)=="function" then return true end
   if module=="UnitFrames" and type(nativeOwner.object.OwnsPosition)=="function" then
    return false,"Player, target and focus use their saved Customize positions. Their width and scale remain native; this previous whole-module geometry preference stays saved but inactive."
   end
   return false,"Position, size, scale and group arrangement follow the original native controls. Use Blizzard Edit HUD; the authored Mirage preference remains saved but inactive."
  elseif visibility[key] then
   return false,"The original native unit controls own presence and visibility. Mirage artwork follows their visible input area; this earlier hide/opacity preference remains saved but inactive."
  elseif formerPresentation[key] then
   return false,"This earlier renderer preference remains saved but inactive. The Mirage card uses supported appearance settings; managed aura and cast channels take over only when ready. Unavailable routes and subgroup-title controls retain their native display."
  end
 end
 if rework and rework:Selected("minimap",profile) and module=="Minimap" then
  local legacy={style=true,scale=true,moveNative=true,hideWhenQuiet=true,squareSize=true,square=true}
  if legacy[key] then return false,"The sidebar map is square. Its Customize position, width and scale place the map, status strip and quest list together. This previous-renderer value is retained for recovery." end
 elseif rework and rework:Selected("nameplates",profile) and module=="Nameplates" then
  local legacy={cards=true,style=true,scale=true,extended=true,showPercent=true,subtle=true,compact=true,flatBars=true,healthHeight=true,castHeight=true}
  if legacy[key] then return false,"Enabled nameplate categories use the custom Mirage design. Use the card size, text, cast, aura and category settings for this display; this previous-renderer value is retained for recovery." end
 end
 local combatOwner=({Auras="auras",Cooldowns="cooldowns",DamageMeters="meters"})[module]
 if rework and combatOwner and rework:Selected(combatOwner,profile) then
  if key=="style" then return false,"This module's primary displays use Mirage artwork. The previous renderer's style switch is retained for recovery." end
  if module=="Auras" and key=="scale" then return false,"Buff and debuff size supplies the scale until an explicit shared Customize scale is saved. The previous generic scale is retained." end
  if module=="Cooldowns" and ({tracker=true,centralGroup=true,columns=true,showNames=true,scale=true,alpha=true,visibility=true})[key] then
   return false,"The tracked row uses its own visibility, icon size, spacing, opacity and scale. Earlier separate-row settings remain saved for recovery."
  end
 end
 if rework and module=="Chat" and rework:Selected("chat",profile) then
  local legacy={style=true,scale=true,hideWhenQuiet=true,moveNative=true}
  if legacy[key] then return false,"Chat uses its Customize rectangle and context rules. This previous-renderer value stays saved for recovery." end
 elseif rework and module=="QuestTracker" and rework:Selected("objectives",profile) then
  local legacy={style=true,scale=true,hideWhenQuiet=true,moveNative=true,matchMinimap=true}
  if legacy[key] then return false,"The full quest list follows the minimap sidebar width, position and scale. Customize can change its viewport height. Compact objectives remain a separate optional display. This previous-renderer value stays saved for recovery." end
 elseif rework and module=="Tooltips" and rework:Selected("tooltips",profile) then
  if key=="scale" or key=="alpha" then
   return false,"Tooltips use Mirage presentation and the selected game, fixed or cursor anchor. This previous-renderer value stays saved for recovery."
  end
 end
 if module=="ActionBars" then
  local fixed={scale=true,columns=true,buttonCount=true,vertical=true,gap=true,secondaryHover=true,contextual=true}
  if rework and rework:Selected("main",profile) and fixed[key] then return false,"The action interface has three horizontal rows, a pet row and a More Actions banner. Use Interface scale or its single Customize rectangle; previous individual-bar geometry stays saved." end
  if M.Rework and M.Rework:Selected("main",profile) and key~="scale" and actionSettings[key] then return true end
  if profile and profile.managed and actionSettings[key] then
   return false,"This preference belongs to supplemental Mirage bars. Native actions keep their own content, labels and interaction; use the selected control's shared layout envelope for supported size changes. The saved value is retained."
  end
  if profile and not profile.managed and (key=="secondaryHover" or key=="utilityContext") then
   return false,"This option belongs to managed native controls. Its saved value is retained while supplemental bars are selected."
  end
 end
 return true
end
function E:Provider(row,profile)
 profile=profile or M.profile or {};local cfg=profile.modules and profile.modules[row.module] or {}
 local surface=row.surface;local mod=M.modules[row.module]
 local p={backend="custom",name="Mirage display",geometry="frame",move=true,resize=true,scale=true,context=true,
  frame=surface and surface.frame,registered=surface~=nil,available=surface~=nil,reference=false}
 if M.NativeWindowPolicy and M.NativeWindowPolicy:ModuleNative(row.module) then
  p.nativeByDesign=true;p.backend="native";p.geometry="reference";p.reference=true
  p.name=row.module=="Tooltips" and "Native tooltips" or "Native game windows"
  p.move=false;p.resize=false;p.scale=false;p.context=false;p.registered=false;p.available=true
  p.frame=row.module=="Tooltips" and _G.GameTooltip or nil
  p.capabilityNote="Native by design. Open this content through its normal game control. The game retains appearance, placement, input and lifetime; earlier Mirage preferences remain saved but inactive."
  p.shown,p.shownState=public(p.frame,"IsVisible","boolean")
  return p
 end
 if row.id=="UnderCharacterHUD.nativeCast" then
  p.nativeCastFallback=true;p.backend="native";p.geometry="reference";p.reference=true
  p.name="Native player-cast fallback";p.move=false;p.resize=false;p.scale=false;p.context=false
  p.frame=_G.PlayerCastingBarFrame;p.registered=false;p.available=frameAvailable(p.frame)
  p.capabilityNote="The upper under-character HUD owns Mirage's player cast design and placement. This game cast controller is a functional fallback only when the custom handoff is unavailable. Its earlier saved rectangle remains inactive; select Under-character bars to arrange the cast display."
  p.shown,p.shownState=public(p.frame,"IsVisible","boolean")
  return p
 end
 local unit=row.id:match("^UnitFrames%.(.+)$")
 local party=row.id:match("^PartyRaid%.(party%d+)$") or row.id:match("^PartyRaid%.(raid%d+)$")
 local group=tonumber(row.id:match("^PartyRaid%.group(%d+)$"))
 local root=M.NativeLayout and M.NativeLayout:RootFor(row.id)
 local bar=tonumber(row.id:match("^ActionBars%.bar(%d+)$"))
 local rework=M.Rework and M.Rework:ProviderForLayout(row.id,profile)
 if M.NativeLayout and M.NativeLayout:IsDelegated(row.id) then
  p.backend="native";p.name="Mirage-styled game control";p.nativeRoot=root;p.frame=_G[root]
  p.available=frameAvailable(p.frame);p.geometry="nativeObserved";p.nativeEdit=true
  p.move=false;p.resize=false;p.scale=false;p.context=false
  p.capabilityNote="Position and size in Blizzard Edit HUD. Mirage supplies passive appearance; the game retains visibility and original controls. Saved hide preferences stay inactive until a native visibility contract is qualified."
 elseif rework then
  p.rework=rework;p.crossModule=true;p.name="Mirage custom display";p.frame=surface and surface.frame
  p.available=surface~=nil and rework.object.active==true
  p.capabilityNote="Shared position, width, height and scale are consumed by the custom runtime display."
  if unit then
   p.name="Mirage unit frame";p.unit=unit;p.view=rework.object:GetView(unit)
   p.frame=p.view and p.view.frame or p.frame;p.content=presence(unit)
   p.available=rework.object:IsReady(unit)
  elseif party then
   p.name="Mirage roster member";p.unit=party;p.view=rework.object:GetView(party)
   p.frame=p.view and p.view.frame or p.frame;p.content=presence(party);p.available=rework.object:IsReady(party)
   local memberSurface=p.view and p.view.surface or surface
   local index=tonumber(party:match("^raid(%d+)$"))
   local groupID=index and ("PartyRaid.group"..math.floor((index-1)/5+1))
   if memberSurface and memberSurface.grouped or groupID and profile.layouts and profile.layouts[groupID] then
    p.move=false;p.resize=false;p.scale=false
    p.capabilityNote="This member follows its raid-group envelope. Move or resize the group; individual appearance, content and context preferences remain available."
   end
  elseif group then
   local block=rework.object:GetGroup(group)
   p.geometry="group";p.name="Mirage raid subgroup";p.frame=block and block.frame or p.frame
   p.available=block~=nil and rework.object.active==true
   p.capabilityNote=cfg.nativeGroups and "Secure subgroup membership follows the game. The shared envelope, growth and gap place the member controls." or "This block keeps five fixed roster slots. Shared group geometry controls their placement once the group is edited; individual member settings remain available."
  elseif row.id=="ActionBars.interface" then
   p.geometry="actionInterface";p.name="Mirage action interface"
   p.minWidth=240;p.maxWidth=1200;p.minHeight=129
   p.context=cfg.actionExperience==1
   p.capabilityNote="Move or uniformly resize the whole action interface. Width and height stay proportional; the display also fits your screen."
   if not p.context then p.capabilityNote=p.capabilityNote.." Mouseover uses the shared minimum hover time; Idle, Moving and Combat preferences apply only in Combat data context mode." end
  elseif row.id=="Cooldowns.row" then
   p.geometry="cooldownRow";p.name="Mirage tracked cooldown row";p.resize=false;p.move=true;p.scale=true;p.context=false
   p.capabilityNote="The row follows the under-character HUD until you move it here. Icon size and spacing determine its width; scale changes the whole row. Visibility is set in Cooldown Manager."
  elseif bar then p.name="Mirage action bar "..bar
  elseif row.id=="Minimap.nativePosition" then p.name="Mirage minimap" end
  if type(rework.object.GetFrame)=="function" then p.frame=rework.object:GetFrame(row.id) or p.frame;p.available=frameAvailable(p.frame) and rework.object.active==true end
  if rework.id=="casts" then
   p.crossModule=true;p.context=false
   p.capabilityNote="Mirage styles this native cast controller when it owns the central cast role. The selected cast display and casting activity control visibility; the shared rectangle controls this cast bar's placement."
  end
  if rework.id=="inventory" then
   p.context=false;p.transient=true;p.name="Mirage inventory";p.move=false;p.resize=false;p.scale=false;p.geometry="nativeFlow"
   p.capabilityNote="A minimal Mirage frame surrounds the game's bag grid. Use the game's bag controls to choose combined or separate bags. Window size and placement follow the native bag layout."
  end
  local flow=row.module=="Auras" and row.kind=="native" or row.module=="Cooldowns" and row.kind=="native"
   or row.id=="NativeControls.MainStatusTrackingBarContainer" or row.id=="NativeControls.SecondaryStatusTrackingBarContainer"
  if flow then
   p.geometry="nativeFlow";p.resize=false
   p.capabilityNote="Mirage supplies the design and shared position/scale. The native flow controller sizes this content; its actual bounds are shown, and width/height are not editable here."
  end
  local authoredControl=type(rework.object.OwnsGeometry)=="function" and rework.object:OwnsGeometry(row.id,profile)
  local wholeControl=rework.object.geometryRoots and rework.object.geometryRoots[row.id]
  if rework.object.nativeBacked==true and (unit or party or group or wholeControl) then
   p.nativeBacked=true;p.nativeEdit=true;p.geometry="nativeObserved"
   p.move=false;p.resize=false;p.scale=false;p.context=false
   p.name=group and "Mirage-styled native subgroup" or "Mirage-styled native unit"
   p.capabilityNote="Position and size in Blizzard Edit HUD. Mirage artwork follows the original unit control so targeting and menus keep their native hit areas. The game owns presence, visibility and placement; your authored Mirage layout stays saved but inactive."
   if type(rework.object.OwnsPosition)=="function" and rework.object:OwnsPosition(row.id,profile) then
    p.geometry="nativeAnchor";p.move=true;p.nativeEdit=false
    p.capabilityNote="The saved Mirage position moves the original player, target or focus control together with its artwork outside combat. Width, scale, targeting and menus stay native. Blizzard Edit HUD and safe mode first return the native position."
   end
   if authoredControl then
    p.geometry="unitEnvelope";p.move=true;p.resize=true;p.scale=true;p.nativeEdit=false
    p.name=row.id=='UnitFrames.pet' and 'Mirage pet frame' or row.id=='UnitFrames.targettarget' and "Mirage Target's Target frame" or row.id=='PartyRaid.partyFrame' and 'Mirage party frame' or 'Mirage raid frames'
    p.capabilityNote="Move or resize this whole control in Mirage Customize. Resizing fits it uniformly inside the requested width and height, preserving its aspect ratio and native targeting area. Party/raid membership and internal arrangement remain native. Apply changes it outside combat; native Edit HUD and safe mode first return its native geometry."
    if row.id=='PartyRaid.partyFrame' or row.id=='PartyRaid.raidFrame' then
     p.capabilityNote="Move or resize the space available to this group. Party member size uses the full party layout, so leaving members do not make the remaining frames grow. Raid frames shrink to fit and do not exceed your chosen scale. Membership, arrangement and targeting remain native. Apply changes outside combat."
    elseif row.id=='UnitFrames.targettarget' then
     p.capabilityNote="Mirrors the pet frame's size and its position beneath the player, beneath your target instead. A saved Customize edit overrides this automatic placement. Targeting, menus and unit presence remain native."
    end
   end
   if type(rework.object.Bounds)=="function" then
    local ok,bounds=pcall(rework.object.Bounds,rework.object,row.id,profile)
    if ok and type(bounds)=="table" and bounds.source=="NATIVE_BACKED_GEOMETRY" then p.frame=bounds.frame or p.frame end
   end
   if type(rework.object.Customization)=="function" then
    local okay,control=pcall(rework.object.Customization,rework.object,row.id,profile)
    if okay and type(control)=="table" and control.authorable==true then
     p.customizeTarget=control.target;p.customization=control
     if control.target==row.id then
      p.configuration=true;p.geometry="unitEnvelope";p.move=true;p.resize=true;p.scale=true;p.nativeEdit=false;p.context=false
     else
      p.nativeEdit=false
      p.capabilityNote="This subgroup is arranged by the native raid container. Select Raid frames below to move or resize the whole group; membership, subgroup order, targeting and menus stay with the game."
     end
    end
   end
  end
 elseif unit then
  p.name="Mirage unit frame";p.unit=unit;p.view=mod and mod.views and mod.views[unit];p.nativeFallback=nativeUnits[unit]
  p.frame=p.view and p.view.frame or p.frame;p.available=p.view~=nil;p.content=presence(unit)
 elseif party then
  p.name="Mirage roster slot";p.unit=party;p.view=mod and mod.views and mod.views[party];p.content=presence(party)
  p.frame=p.view and p.view.frame or p.frame;p.available=p.view~=nil
 elseif group then
  p.geometry="group";p.name="Mirage roster block";p.content=false;p.available=mod and mod.fixedReady==true or false
  local header=M.NativeGroups and M.NativeGroups.active and cfg.nativeGroups and M.NativeGroups.headers and M.NativeGroups.headers[group]
  if header then p.name="Native subgroup header";p.frame=header.frame;p.available=M.NativeGroups.ready==true end
  local unknown=false
  for i=1,5 do
   local member=header and header.children and header.children[i]
   local exists=presence(header and member and member.unit or not header and ("raid"..((group-1)*5+i)) or nil)
   if exists==true then p.content=true elseif exists==nil then unknown=true end
  end
  if not p.content and unknown then p.content=nil end
 elseif root and (not bar or profile.managed or bar>3) then
  p.backend="native";p.name="Game control";p.nativeRoot=root;p.frame=_G[root];p.available=frameAvailable(p.frame)
  p.geometry="nativeEnvelope"
  local navigation=M.NativeLayout:RequiresMoveOption(row.id)
  if navigation then
   if cfg.moveNative~=true then
    p.move=false;p.resize=false;p.scale=false;p.geometry="nativeObserved"
    p.capabilityNote="Position follows the game. Enable Use the shared layout position explicitly to edit it here; opening this entry never enables movement."
   elseif not profile.managed then
    p.resize=false;p.scale=false;p.geometry="anchor"
    p.capabilityNote="This backend moves the native root only. Its content size and scale remain with the game."
   elseif root=="ChatFrame1" then p.geometry="nativeRectangle" end
  elseif not profile.managed then
   p.move=false;p.resize=false;p.scale=false;p.geometry="nativeObserved"
   p.capabilityNote="This control has no layout consumer in supplemental-bar mode. Its position remains with the game."
  end
  if row.id=="UnderCharacterHUD.nativeCast" then
   p.context=false;p.capabilityNote="Casting activity and the selected cast provider control visibility. This entry edits native placement only."
  end
 elseif row.id=="Auras.private" then
  p.backend="native";p.name="Native private-aura anchors";p.geometry="anchor";p.nativeAnchor=true;p.resize=false;p.context=false
  p.capabilityNote="The native aura service owns content and visibility. Shared position and scale affect its parent; icon count and size use the private-aura options, not a resized empty rectangle."
 elseif row.kind=="native" or surface and surface.native then
  p.backend="native";p.name="Game content";p.geometry="nativeObserved";p.move=false;p.resize=false;p.scale=false
  p.nativeRoot=nativeNames[row.id] or row.id:match("^[^.]+%.(.+)$")
  p.frame=surface and surface.frame or p.nativeRoot and _G[p.nativeRoot];p.available=frameAvailable(p.frame)
  p.capabilityNote="The game owns this content and its placement. Mirage can use only the supported appearance and visibility settings below."
  p.transient=row.module=="Tooltips" or row.module=="Bags" or row.module=="BlizzardSkin"
 elseif row.kind=="world" or row.kind=="cursor" or row.kind=="window" then
  p.reference=true;p.move=false;p.resize=false;p.scale=false;p.geometry="reference";p.backend="reference"
  p.available=mod and mod.initialized==true or false
  p.context=row.id=="Cursor.overlay" or row.id=="Cursor.compass"
  if row.kind=="cursor" then
   local cc=M.Cursor and M.Cursor.impl
   p.name="Cursor Companion";p.available=cc~=nil
   if cc then
    if row.id=="Cursor.compass" then p.frame=cc.CompanionFrame and cc.CompanionFrame.compassLayer and cc.CompanionFrame.compassLayer.root
    elseif row.id=="Cursor.palette" then p.frame=cc.Palette and cc.Palette.root
    elseif row.id=="Cursor.notes" then p.frame=cc.QuestNotes and cc.QuestNotes.frame end
   end
   p.capabilityNote="Reference entry: this feature follows the cursor or opens on demand. Use its own offsets, size and appearance controls; it is not a fixed screen rectangle."
  elseif row.kind=="world" then
   p.name="Game-positioned display"
   p.capabilityNote="Reference entry: the game positions world text and nameplates. These controls do not move a global world rectangle."
  else
   p.name=row.id=="Preparations.overview" and "Preparations window" or row.name or "Game windows"
   p.frame=row.id=="Preparations.overview" and mod and mod.frame or nil
   p.capabilityNote="Reference entry: open this window through its normal game control. Its native window manager owns placement and hit areas; Mirage styles the accessible contents. This entry has no movable or resizable screen rectangle."
   local packID=({["BlizzardSkin.windows"]="tasks",["BlizzardSkin.character"]="character",["BlizzardSkin.system"]="system"})[row.id]
   if packID and M.Rework then
    local pack=M.Rework.providers[packID]
    p.available=pack and pack.state=="ACTIVE" and pack.object.active==true or false
   end
  end
 elseif row.kind=="hud" then
  p.name="Mirage under-character HUD";p.geometry="hud"
 elseif row.id=="Tooltips.anchor" then
  p.name="Tooltip placement and size";p.geometry="tooltipAnchor";p.resize=false;p.scale=true;p.context=false;p.move=true;p.configuration=true;p.minScale=.7
  p.capabilityNote="Move this anchor to choose a fixed world-tooltip position. Tooltip size scales native text and artwork together; content controls the final width and height. Default placement can avoid Meters. Item comparisons and control-specific anchors retain their native placement."
 elseif not self.definitions[row.id] then
  p.move=surface and surface.editable==true or false;p.resize=p.move;p.scale=p.move
 end
 if row.id=="Bags.browser" or row.id=="TacticalSignals.legend" then
  p.context=false;p.capabilityNote="This display is opened explicitly. Context hide/show preferences do not replace that action."
 end
 if row.id=="DamageMeters.native" and M.Rework and M.Rework:Selected("meters",profile) then
  p.reference=true;p.current=false;p.move=false;p.resize=false;p.scale=false;p.context=false;p.available=false
  p.name="Game meter source";p.capabilityNote="Meters displays the game's combat sessions. Move and resize the Meters entry."
 elseif row.id=="DamageMeters.mirage" then
  p.name="Meters";p.minWidth=240;p.maxWidth=700;p.minHeight=195;p.maxHeight=600;p.context=true
  p.capabilityNote="Damage, healing and other combat views update automatically. Move or resize this panel; its default anchor is the bottom-right corner."
 end
 if row.id=="Notifications.durability" then
  p.name="Durability alert";p.move=false;p.resize=false;p.scale=false;p.context=false;p.geometry="sidebarFollower";p.sidebar="ALERT"
  p.capabilityNote="Low equipment durability follows the client's alert thresholds. This strip shares the minimap column's width, scale and travel context and sits immediately below the Quest list. Move or resize Minimap to adjust the complete column."
 end
 if M.SidebarLayout then
  if row.id=="Minimap.nativePosition" and rework and rework.id=="minimap" then
   p.sidebar="MAP";p.geometry="sidebarMap";p.resizeWidth=true;p.resizeHeight=false;p.minWidth=M.SidebarLayout.minWidth;p.maxWidth=M.SidebarLayout.maxWidth
   p.capabilityNote="Move this map to place the sidebar. Width controls the square map, experience bars, quest list and durability alert together; scale is shared and reduced only when needed to fit the screen."
  elseif row.id=="QuestTracker.nativePosition" and rework and rework.id=="objectives" then
   p.sidebar="OBJECTIVES";p.geometry="sidebarHeight";p.move=false;p.resize=true;p.scale=false;p.resizeWidth=false;p.resizeHeight=true
   p.minHeight=math.max(160,120*math.max(.65,math.min(2,S:Number(profile.textScale) and profile.textScale or 1)))
   p.capabilityNote="The quest list follows the minimap width, position and scale. Change viewport height here; it is capped to the available screen space. Select Minimap to move or resize the whole sidebar."
  end
 end
 if p.available and p.frame and not frameAvailable(p.frame) then p.available=false end
 if p.geometry=="nativeEnvelope" then p.capabilityNote=p.capabilityNote or "Width and height define a fitting envelope. The native root keeps its aspect ratio; its child layout stays with the game." end
 if p.geometry=="nativeRectangle" then p.capabilityNote="This public chat root supports a requested rectangle. Native content and input remain with the game." end
 p.shown,p.shownState=public(p.frame,"IsVisible","boolean")
 if p.geometry=="nativeObserved" or p.geometry=="nativeAnchor" or p.geometry=="unitEnvelope" then p.bounds=self:Measure(p.frame) end
 return p
end
function E:State(row,profile)
 profile=profile or M.profile or {};local cfg=profile.modules and profile.modules[row.module]
 local p=self:Provider(row,profile);local mod=M.modules[row.module]
 local r={enabled=cfg and cfg.enabled==true or false,registered=p.registered,fallback=false,provider=p,
  backend=p.backend,available=p.available,reference=p.reference,current=false,visibility=p.shownState=="KNOWN" and (p.shown and "Shown" or "Hidden") or "Unobserved"}
 if p.crossModule then r.enabled=M.Rework:Selected(p.rework.id,profile) end
 local function result(id,label,note,current)
  r.code=id;r.label=label;r.note=note;r.current=current==true
  return r
 end
 if p.nativeByDesign then
  r.enabled=false
  for _,owner in pairs(M.Rework and M.Rework.providers or {}) do
   if owner.module==row.module and owner.pending then
    return result("RESTORE_PENDING","Native restoration pending","A previous Mirage receipt still needs to hand back. Help retains the recovery action until restoration is confirmed.")
   end
  end
  return result("NATIVE_BY_DESIGN","Native by design",p.capabilityNote)
 end
 if p.nativeCastFallback then return result("REFERENCE","Native player-cast fallback",p.capabilityNote) end
 if not r.enabled then return result("MODULE_OFF","Module off","This module is off in the draft. Layout preferences remain saved; editing does not enable it.") end
 local key=featureSwitches[row.id]
 if key and cfg[key]~=true then
  r.enabled=false;return result("FEATURE_OFF","Feature off","This optional feature is off in the draft. Its preferences remain saved; enable it explicitly when wanted.")
 end
 if row.id=="Tooltips.anchor" then
  local mode=cfg.cursorAnchor and "Cursor placement" or cfg.fixedAnchor and "Fixed placement" or cfg.avoidMeters~=false and "Default placement · avoids Meters" or "Game placement"
  return result("CONFIGURATION",mode,"This sample is a placement and size control. Move it to stage a fixed position, or choose another placement mode below. Insight details remain in Insight settings.",true)
 end
 if row.kind=="cursor" and profile.cursorProfile then
  local c=profile.cursorProfile;local f=row.id=="Cursor.compass" and c.compass or row.id=="Cursor.palette" and c.palette or row.id=="Cursor.notes" and c.questNotes
  if c.enabled==false or f and f.enabled==false then r.enabled=false;return result("FEATURE_OFF","Feature off","This Cursor feature is off in the draft; its saved options remain intact.") end
 end
 if M.state.safe or not M.profile or not M.profile.enabled or profile.enabled==false then
  return result("PAUSED","Suite paused","Saved preferences and native access are retained. Resume the suite before checking gameplay presentation.")
 end
 if not M.Client.allowed then return result("UNAVAILABLE","Waiting for qualification","The current client has not qualified for gameplay changes. This entry remains available as a saved preference.") end
 local editor=self:NativeEditorState()
 if editor=="UNKNOWN" then return result("EDITOR_OBSERVATION_WAIT","Waiting for editor state","The native editor cannot currently be observed. Contested work is held and your draft is retained.") end
 if editor=="OPEN" then return result("EDITOR_SUSPENDED","Blizzard Edit HUD","Native editing has priority. The Mirage draft is retained without changing native unsaved work.") end
 local live=M.profile.modules and M.profile.modules[row.module]
 if (not p.crossModule and (not live or live.enabled~=true) or p.crossModule and not M.Rework:Selected(p.rework.id,M.profile)) or key and live[key]~=cfg[key]
  or profile.managed~=M.profile.managed and (row.module=="ActionBars" or p.nativeRoot)
  or p.nativeRoot and M.NativeLayout:RequiresMoveOption(row.id) and live.moveNative~=cfg.moveNative then
  return result("DRAFT_ONLY","Pending Apply","This selection is a draft. Apply publishes it; a preview does not activate its provider.")
 end
 if not p.crossModule and mod and (mod.quarantined or mod.initializationFailed or mod.maintenanceFailed) then
  return result("UNAVAILABLE","Provider needs attention","This module could not continue safely. The Help report retains its diagnostic; native access is kept.")
 end
 if p.rework then
  local owner=p.rework
  if owner.pending then return result("RESTORE_PENDING","Recovery pending","The custom provider is retaining unfinished native restoration until it is legal.") end
  if p.configuration and p.customization and p.customization.target==row.id then
   local ready=p.customization.contentReady and p.bounds
   return result(ready and "NATIVE_BACKED_READY" or "CONFIGURATION",ready and "Native group with Mirage artwork" or "Group layout · waiting for roster",
    ready and p.capabilityNote or "Prepare this whole-group layout now. Saved placement and size apply to the original native group when a roster becomes available, outside combat. This sample does not create raid members.",true)
  end
  if owner.state~="ACTIVE" or not p.available then
   r.fallback=true;return result("PENDING","Custom provider pending","This gameplay provider is not active. Its saved geometry is retained; Help includes the rework status.")
  end
  if owner.id=="casts" and owner.object.role=="DECLARED_OTHER_CAST_OWNER" then
   return result("CONTENT_PENDING","Another cast display selected","This saved rectangle belongs to the central native cast controller. The selected Mirage cast display currently presents casting; its own rectangle is available separately.")
  end
  if p.nativeBacked then
   if not p.bounds then return result("CONTENT_PENDING","Waiting for native bounds","The original unit or subgroup control is not currently measurable. Its settings and saved Mirage layouts remain available.") end
   return result("NATIVE_BACKED_READY","Native control with Mirage artwork",p.capabilityNote,true)
  end
  if p.unit and p.content~=true then
   return result("CONTENT_PENDING","Waiting for unit","The custom control owns this slot. It has no confirmed current unit; native presentation stays suppressed.",true)
  end
  local quiet=row.surface and row.surface.actual=="HIDDEN"
  return result("CUSTOM_READY",quiet and "Custom display · quiet" or "Custom display",
   "This is the real custom provider's shared geometry. Contextual hiding retains presentation ownership; native-client validation is pending.",true)
 end
 if p.reference then
  return result("REFERENCE",p.name.." reference",p.capabilityNote..(p.available and " Its implementation is loaded; live content still depends on the current game state." or " Its provider has not loaded yet."))
 end
 if p.nativeAnchor then
  local anchor=M.PrivateAuras;r.runtime=code(anchor and anchor.status)
  if anchor and anchor.pending then return result("RESTORE_PENDING","Aura anchor restoration pending","The native anchor service has not completed removal. Saved preferences remain intact.") end
  if r.runtime=="NATIVE_ANCHORS_REGISTERED_NOT_CERTIFIED" then
   return result("NATIVE_READY","Native aura anchors registered",p.capabilityNote.." Registration does not confirm which private aura content the game currently displays.",true)
  end
  return result("PENDING","Native aura anchors pending",p.capabilityNote.." Current registration is unavailable or deferred.")
 end
 if p.backend=="native" then
  local n=p.nativeRoot;local owner=M.ManagedNative and M.ManagedNative.rows[n]
  if owner and owner.frame~=p.frame then owner=nil end
  local fallback=M.ContextualNative and M.ContextualNative.rows[n]
  if fallback and fallback.frame~=p.frame then fallback=nil end
  r.nativeStatus=code(M.ManagedNative and M.ManagedNative.status[n]);r.presentation=code(M.NativePresentation and M.NativePresentation.status[n])
  r.panel=M.Native and M.Native.SkinState and p.frame and M.Native:SkinState(p.frame) or "NATIVE_CONTENT_PRESERVED"
  if owner and owner.editSuspended or r.nativeStatus=="NATIVE_EDIT_SUSPENDED" or r.nativeStatus=="NATIVE_EDIT_REACQUIRE_PENDING" or r.nativeStatus=="NATIVE_EDIT_OUTPUT_OBSERVED" then
   return result("EDITOR_SUSPENDED","Native placement handoff","Native editing changed this control. Mirage is waiting for a safe ownership handoff; its saved layout remains intact.")
  end
  if owner and (owner.restorePending or owner.parentAttempt) or fallback and (fallback.pending or fallback.busy) or r.nativeStatus=="NATIVE_EDIT_RELEASE_PENDING" or r.panel=="NATIVE_PANEL_RELEASE_PENDING" then
   return result("RESTORE_PENDING","Native restoration pending","The original control is being restored when legal. The draft is retained; no completed handoff is implied.")
  end
  if owner and (owner.contested or owner.failed) or fallback and fallback.contested or r.nativeStatus=="NATIVE_EDIT_OWNER_CHANGED" then
   r.fallback=true;return result("REFUSED","Native control retained","Mirage could not safely own this control. Its original or newer owner is preserved. Layout changes are requests, not a successful replacement.")
  end
  if layoutRefusals[r.nativeStatus] then
   r.fallback=true;return result("REFUSED","Native layout retained","The requested geometry could not be applied safely. Current native access and newer placement are retained; the shared draft is still a request.")
  end
  if not p.available then return result("UNAVAILABLE","Native control unavailable","The native root is absent or unreadable. Its stored preferences remain available without creating a placeholder control.") end
  if p.geometry=="nativeObserved" and not p.bounds then return result("PENDING","Native bounds unavailable","The native root exists, but public geometry cannot be observed. Its settings remain searchable without drawing guessed bounds.") end
  if p.transient and p.shown~=true then return result("CONTENT_PENDING","Window closed","This native content opens on demand. Search retains its settings while the window is closed.") end
  local active=owner and owner.active or fallback and fallback.active
  local note=p.capabilityNote or "The original game renderer owns content and input. The editor changes only the supported native layout envelope."
  if r.presentation=="MIRAGE_ART_PARTIAL" then note=note.." Some Mirage artwork is available; the native treatment is only partially replaced."
  elseif r.presentation=="MIRAGE_ART_NATIVE_CONTROLS" then note=note.." Mirage's cosmetic owner reports applied artwork; original actions and data remain native."
  elseif r.panel=="MIRAGE_PANEL_NATIVE_CONTENT" then note=note.." A passive Mirage backing is applied; text, data and controls remain native."
  elseif r.panel=="NATIVE_PANEL_UNAVAILABLE" then note=note.." The passive backing is unavailable; native content is preserved."
  elseif cfg.style==false then note=note.." Mirage styling is off by preference."
  end
  if p.geometry=="nativeObserved" then return result("NATIVE_RETAINED","Native placement",note,true) end
  return result(active and "NATIVE_READY" or "NATIVE_RETAINED",active and "Managed native control" or "Native control retained",note,true)
 end
 if p.view and row.module=="UnitFrames" then
  local v=p.view;r.runtime=code(v.typographyStatus);r.reason=code(v.typographyReason)
  if v.typographyStatus=="NATIVE_OWNERSHIP_RETAINED" then
   r.fallback=true
   return result("REFUSED","Native fallback retained",v.typographyReason=="HEIGHT_UNFIT" and "The requested text does not fit this frame height. Native access remains; a current measured Fit action may be available below."
    or v.typographyReason=="WIDTH_UNFIT" and "The requested text does not fit this width. Native access remains; adjust the authored width or text options before Apply."
    or "The custom frame has not qualified for replacement. Its original native control remains available.")
  end
  local receipt=M.UnitTypography and M.UnitTypography.NativeReplacementReceipt and M.UnitTypography:NativeReplacementReceipt(v)
  if v.typographyStatus~="CUSTOM_ADMITTED" or v.typographyReady~=true or not receipt then
   return result("PENDING","Custom frame pending","A custom frame exists, but its current admission is not confirmed. You can still prepare its authored geometry.")
  end
 end
 if p.unit or row.kind=="group" then
  if p.content~=true then return result("CONTENT_PENDING",p.content==false and "Waiting for unit" or "Unit presence unobserved","This implemented control has no confirmed current unit. Its draft layout remains editable without inventing sample gameplay.") end
 end
 if not p.available or not mod or not mod.initialized or mod.suspended then
  return result("PENDING","Provider pending","The implementation is not currently available. Stored layout can be prepared where a real consumer exists; no live display is fabricated.")
 end
 local surface=row.surface
 if surface and surface.presentationHidden then return result("OTHER_PROVIDER","Other provider selected","Your primary display choice hides this duplicate presentation. Editing its layout does not change that choice.") end
 if surface and surface.disabled then return result("CONTENT_PENDING","Waiting for content","The provider is loaded but has no eligible content or an explicitly opened window. Its preferences remain editable.") end
 local quiet=surface and surface.actual=="HIDDEN"
 return result("CUSTOM_READY",quiet and "Custom display · quiet" or "Custom display",quiet and "The implemented display is hidden by its current activity/context policy. This is its shared draft geometry."
  or "This entry has an implemented Mirage display. The rectangle is draft geometry; it does not certify native paint.",true)
end
function E:InCatalogue(row,profile,filters,selected)
 local state=self:State(row,profile);filters=filters or {}
 local communication=M.Rework and M.Rework.Communication
 if row.module=="Chat" and row.surface and communication and communication.CustomizeVisible
  and communication:CustomizeVisible(row.surface)==false then return false,state end
 local cooldowns=M.Rework and M.Rework.CombatCooldowns
 if row.module=="Cooldowns" and M.Rework:Selected("cooldowns",profile)
  and profile.modules.Cooldowns.rowEnabled~=false and cooldowns and cooldowns.CustomizeVisible
  and cooldowns:CustomizeVisible(row.surface or row)==false then return false,state end
 local actionInterface=M.ActionInterface
 local unified=actionInterface and actionInterface.active==true and actionInterface:Requested(profile)
 if unified and (row.id:match("^ActionBars%.bar%d+$") or row.id=="NativeControls.PetActionBar"
  or row.id=="NativeControls.StanceBar" or row.id=="NativeControls.PossessActionBar"
  or row.id=="NativeControls.MultiCastActionBarFrame" or row.id=="NativeControls.OverrideActionBar"
  or row.id=="NativeControls.MainMenuBarVehicleLeaveButton") then return false,state end
 if selected then return true,state end
 if row.id=="Tooltips.anchor" then return true,state end
 if state.reference then return filters.references==true,state end
 return state.current or filters.unavailable==true,state
end
function E:OnCanvas(row,context,profile,filters,selected)
 local included,state=self:InCatalogue(row,profile,filters,selected)
 if state.reference or row.id:match("^PartyRaid%.raid%d+$") or state.provider.geometry=="nativeObserved" and not state.provider.bounds then return false,state end
 return included and (self:Visible(row,context,profile) or selected),state
end
function E:Get(id,profile)
 local definition=self.definitions[id];local surface=M.surfaces[id]
 if not surface then for alias,canonical in pairs(M.ElementRules.aliases) do if canonical==id and M.surfaces[alias] then surface=M.surfaces[alias];break end end end
 if not definition and not surface then return nil end
 local row=M:Copy(definition or {id=id,module=surface.module,name=id:gsub("%."," / "),contexts=all,kind="native"})
 row.surface=surface
 if surface then
  if not definition and S:Text(surface.label) and #surface.label<=100 then row.name=surface.label end
  row.layout=M:Copy(surface.layout or row.layout)
  row.editable=surface.editable==true
  if not definition and surface.editable then row.kind="layout" end
  if surface.groups and surface.groups.combat and not definition then row.contexts=combat end
 end
 row.layout=row.layout or {x=0,y=0,width=220,height=50,scale=1}
 -- Static authored layouts are staged even before their provider exists.
 if row.kind=="layout" or row.kind=="group" or row.kind=="nativePosition" then row.editable=true end
 if row.kind=="hud" then row.editable=true end
 -- This rectangle is an anchor region, not the native tooltip's content size.
 -- Keep its saved dimensions intact and expose only the supported movement.
 if id=="Tooltips.anchor" then row.resizable=false;row.scalable=true end
 row.contextSupported=not (row.kind=="world" or row.kind=="window" or id=="Cursor.palette" or id=="Cursor.notes" or id=="UnderCharacterHUD.nativeCast")
 row.contextNote=row.kind=="world" and "World-attached visibility is controlled by the game. This entry exposes appearance, not a global hide override." or "This is opened explicitly. It follows your direct action and its safety rules, not automatic context concealment."
 if id=="UnderCharacterHUD.nativeCast" then row.contextNote="The selected cast provider and casting activity control visibility. This control changes placement only." end
 local provider=self:Provider(row,profile)
 row.provider=provider;row.editable=provider.move or provider.resize or provider.scale;row.movable=provider.move
 row.resizable=provider.resize;row.scalable=provider.scale;row.resizeWidth=provider.resizeWidth;row.resizeHeight=provider.resizeHeight
 row.minWidth=provider.minWidth;row.maxWidth=provider.maxWidth;row.minHeight=provider.minHeight;row.sidebar=provider.sidebar
 row.minScale=provider.minScale
 row.contextSupported=provider.context;row.contextNote=provider.capabilityNote or row.contextNote
 row.available=provider.available
 local mod=M.modules[row.module]
 row.status=mod and mod.status or "NOT_LOADED"
 return row
end
function E:List(query,profile)
 local ids={};for id in pairs(self.definitions) do ids[id]=true end
 for id in pairs(M.surfaces) do if not M.ElementRules.aliases[id] then ids[id]=true end end
 local rows={};query=(query or ""):lower()
 for id in pairs(ids) do
  local row=self:Get(id,profile);local catalog=M.CatalogByID[row.module]
  local terms={row.name,id,row.keywords or "",catalog and catalog.name or "","opacity scale visibility size"}
  for key in pairs(M.FeatureSettings[row.module] or {}) do terms[#terms+1]=key:gsub("(%l)(%u)","%1 %2") end
  if row.module=="Cursor" and M.Cursor and M.Cursor.impl then for _,descriptor in ipairs(M.Cursor.impl.Settings.descriptors) do terms[#terms+1]=descriptor.label or descriptor.path end end
  local hay=table.concat(terms," "):lower()
  if query=="" or hay:find(query,1,true) then rows[#rows+1]=row end
 end
 table.sort(rows,function(a,b) if a.module==b.module then return a.name<b.name end;return a.module<b.module end)
 return rows
end
function E:Visible(row,context,profile)
 if context=="All" then return true end
 if not self:State(row,profile).enabled then return false end
 local preference=row.contextSupported~=false and M.ElementRules:Preference(row.id,context,profile)
 if preference then return preference=="SHOW" end
 return row.contexts[context]==true
end
function E:Layout(row,profile)
 profile=profile or M.profile
 if row.id=="Tooltips.anchor" then
  local saved=profile.layouts and profile.layouts[row.id]
  local l=M:Copy(saved or row.layout)
  l.scale=(profile.modules.Tooltips.tooltipScale or 100)/100
  return M.Layout:Clamp(l)
 end
 if self:IsNativeGeometry(row.id,profile) then
  -- Imported/archived Mirage values remain recoverable, but are never the origin
  -- for an observed native outline and never authorize a geometry write.
  local provider=self:Provider(row,profile)
  return provider.bounds or {x=0,y=0,width=24,height=16,scale=1}
 end
 local owner=M.Rework and M.Rework:ProviderForLayout(row.id,profile)
 if owner then
  if type(owner.object.ResolveLayout)=="function" then return owner.object:ResolveLayout(row.surface or row,profile) end
  return M.Layout:Get(row.surface or row,profile)
 end
 local automatic=M.NativeLayout and M.NativeLayout:DraftLayout(row.id,profile)
 if automatic then return automatic end
 if row.kind=="hud" then
  local c=profile.modules.UnderCharacterHUD;local w,h=UIParent:GetWidth(),UIParent:GetHeight()
  local _,height=M.HUDView:Geometry(c)
  return {x=c.x/w,y=c.y/h,width=c.width,height=height,scale=c.hudScale/100}
 end
 if row.kind=="nativePosition" then return M.Layout:Get(row,profile) end
 return M.Layout:Get(row.surface or row,profile)
end
-- Display geometry may include screen fitting or a module-wide size choice.
-- Editing must retain the user's independent dimensions/scale, never feed
-- those effective factors back into the next runtime layout calculation.
function E:EditLayout(row,profile)
 local interface=M.ActionInterface
 if row.id=="ActionBars.interface" and interface and interface.AuthoredLayout and interface:Requested(profile) then
  return interface:AuthoredLayout(profile)
 end
 return self:Layout(row,profile)
end

-- Read-only measurements are limited to public geometry. They never become a
-- saved preference or replace the geometry of an editable draft.
function E:Measure(frame)
 local S=M.Safety
 if S:InCombat() or not S:Frame(frame,false) then return nil end
 local w=S:Public(frame.GetWidth,"number",frame);local h=S:Public(frame.GetHeight,"number",frame)
 local fs=S:Public(frame.GetEffectiveScale,"number",frame);local us=S:Public(UIParent.GetEffectiveScale,"number",UIParent)
 local sw=S:Public(UIParent.GetWidth,"number",UIParent);local sh=S:Public(UIParent.GetHeight,"number",UIParent)
 if not w or not h or not fs or not us or not sw or not sh or w<=0 or h<=0 or fs<=0 or us<=0 or sw<=0 or sh<=0 then return nil end
 if type(frame.GetCenter)~="function" then return nil end
 local ok,x,y=pcall(frame.GetCenter,frame)
 if not ok or not S:Number(x) or not S:Number(y) or S:InCombat() then return nil end
 local ratio=fs/us
 if w*ratio>sw*4 or h*ratio>sh*4 then return nil end
 return {x=x*ratio/sw-.5,y=y*ratio/sh-.5,width=w,height=h,scale=ratio}
end
function E:OptionalBounds(row,profile)
 local owner=M.Rework and M.Rework:ProviderForLayout(row.id,profile)
 if not owner or type(owner.object.OptionalBounds)~="function" then return {} end
 local ok,parts=pcall(owner.object.OptionalBounds,owner.object,row.id,profile)
 if not ok or type(parts)~="table" then return {} end
 local result={}
 for i=1,math.min(4,#parts) do
  local p=parts[i]
  if type(p)=="table" and S:Text(p.label) and #p.label<=80 and S:Number(p.x) and S:Number(p.y)
   and S:Number(p.width) and S:Number(p.height) and S:Number(p.scale) and p.width>0 and p.height>0 and p.scale>0 then
   result[#result+1]=p
  end
 end
 return result
end
function E:BoxLayout(row,profile)
 profile=profile or M.profile
 local l=self:Layout(row,profile)
 if row.sidebar then return l,self:Provider(row,profile).capabilityNote end
 if self:IsNativeGeometry(row.id,profile) then
  return l,"Observed native bounds and effective scale. Position and size in Blizzard Edit HUD; authored Mirage geometry stays saved but inactive."
 end
 if l.anchorTo and M.surfaces[l.anchorTo] then
  local x,y=M.Layout:Position(l.anchorTo,profile)
  l=M:Copy(l);l.x,l.y=l.x+x,l.y+y
 end
 local owner=M.Rework and M.Rework:ProviderForLayout(row.id,profile)
 if owner then
  local p=self:Provider(row,profile)
  if p.geometry=="unitEnvelope" and type(owner.object.GeometryPreview)=="function" then
   local preview=owner.object:GeometryPreview(row.id,profile)
   return preview or l,p.capabilityNote
  end
  if p.geometry=="nativeAnchor" and type(owner.object.PositionBounds)=="function" then
   return owner.object:PositionBounds(row.surface or row,profile) or l,"Saved Mirage position with the original native control's current width and scale. Apply moves artwork and targeting together outside combat."
  end
  if p.geometry=="group" and type(owner.object.Bounds)=="function" then
   local ok,bounds=pcall(owner.object.Bounds,owner.object,row.id,profile)
   if ok and type(bounds)=="table" and S:Number(bounds.x) and S:Number(bounds.y) and S:Number(bounds.width)
    and S:Number(bounds.height) and S:Number(bounds.scale) and bounds.width>0 and bounds.height>0 and bounds.scale>0 then
    -- Provider bounds are absolute preview geometry, not editable preferences.
    -- Do not expose frame/source metadata or flatten the saved relative anchor.
    local shown={x=bounds.x,y=bounds.y,width=bounds.width,height=bounds.height,scale=bounds.scale}
    local authored=profile.layouts and profile.layouts[row.id]
    return shown,authored and "Shared raid-group envelope; growth and spacing place the member controls after Apply."
     or "Current member footprint. Editing this group creates a shared envelope and preserves individual preferences."
   end
  end
  if p.geometry=="nativeFlow" then
   local observed=self:Measure(p.frame)
   if observed then l.width,l.height=observed.width,observed.height end
   return l,"Actual native flow size with the shared draft position and scale. Icon count and flow remain with the supported native content controller."
  end
  return l,"Shared custom display bounds. Apply uses this exact envelope; the minimap canvas remains square within its surrounding controls."
 end
 if row.kind=="hud" then
  local width,height=M.HUDView:Geometry(profile.modules.UnderCharacterHUD)
  l.width,l.height=width,height
  return l,"Full reserved HUD footprint, including the cast width extension."
 end
 if row.id=="Tooltips.anchor" then
  return l,"Sample tooltip footprint. Its lower-left corner is the fixed anchor; actual text determines each tooltip's width and height. The size preference scales the complete tooltip, including Insight's additions."
 end
 if row.id=="Auras.private" then
  local c=profile.modules.Auras
  l.width=c.privateCount*c.privateSize+(c.privateCount-1)*6+8;l.height=c.privateSize+8
  return l,"Reserved native private-aura footprint, computed from configured icon count and size; no private aura contents are inspected."
 end
 if M.NativeLayout and M.NativeLayout:RootFor(row.id) then
  local cfg=profile.modules and profile.modules[row.module]
  local provider=self:Provider(row,profile)
  if provider.geometry=="nativeObserved" then
   local observed=self:Measure(provider.frame)
   if observed then return observed,provider.nativeEdit and "Observed native bounds and effective scale. Position and size in Blizzard Edit HUD; saved Mirage geometry is retained but inactive."
    or "Observed native bounds. Placement stays with the game until its supported Mirage placement option is explicitly enabled." end
   return l,"Native placement reference; public bounds are unavailable. This box does not authorize movement."
  end
  local unused,origin=M.NativeLayout:DraftLayout(row.id,profile)
  if origin=="MATCHED_MINIMAP_COLUMN_UNAVAILABLE" then
   return l,"Automatic matched-minimap column; this is a placement reference. A deliberate move switches the tracker to manual placement."
  end
  if origin=="OBSERVED_MATCHED_MINIMAP_COLUMN" then
   return l,"Observed matched-minimap column. Manual placement preserves its center and fits the native aspect ratio after Apply."
  end
  local proposed=M:Copy(l)
  local projected,reason=M.NativeLayout:PreviewGeometry(row.id,proposed,profile)
  if projected then
   return projected,reason=="RESIZABLE_NATIVE_ROOT" and "Requested native chat rectangle; Apply uses this public resizable root."
    or "Requested native footprint with uniform aspect fitting. Native child artwork may extend outside this root."
  end
  return proposed,reason=="NATIVE_LAYOUT_FALLBACK" and "The requested envelope is too small for the safe native scale. Native geometry remains in place."
   or "Requested native bounds; live geometry is unavailable or deferred. A preview does not certify native placement."
 end
 if row.kind=="native" or row.kind=="window" then
  local measured=row.surface and self:Measure(row.surface.frame)
  if measured then return measured,"Observed public bounds; content may extend outside the frame." end
  return l,"Representative bounds; current native geometry is unavailable."
 end
 if row.kind=="world" or row.kind=="cursor" then return l,"Representative only; this display follows the game or cursor." end
 return l,"Shared draft bounds; changes reach gameplay after Apply."
end
