local _,M=...
-- Suite 1.0.2: two contextual launchers backed by the original native bag
-- and menu controls. Native actions, OnClick handlers, bindings, dimensions
-- and scale remain intact. A reversible point journal places each bar to the
-- right of its launcher; the qualified native parent still owns visibility.
local S,C,D=M.Safety,M.ContextualNative,M.DelegatedNative
local U={rows={},attempts={},nativeQualification="NOT_RUN",pending=false,reconcileInterval=.25};M.UtilityDrawers=U
local specs={
 {name="BagsBar",key="Bags",label="Bags",hint="Click to expand or collapse your bag bar.",windows={"ContainerFrameCombinedBags","BankFrame","GuildBankFrame"}},
 {name="MicroMenuContainer",key="Systems",label="Systems",hint="Click to expand or collapse the game menu bar.",windows={
  "CharacterFrame","SpellBookFrame","PlayerSpellsFrame","PlayerTalentFrame","TalentFrame","ProfessionsFrame","TradeSkillFrame","CraftFrame",
  "AchievementFrame","QuestLogFrame","WorldMapFrame","FriendsFrame","PVEFrame","PVPUIFrame","LFGParentFrame","EncounterJournal",
  "CollectionsJournal","CommunitiesFrame","GuildFrame","StoreFrame","HelpFrame","GameMenuFrame","SettingsPanel",
  "VideoOptionsFrame","InterfaceOptionsFrame","KeyBindingFrame","MacroFrame","AddonList"}},
}
for i=1,32 do specs[1].windows[#specs[1].windows+1]="ContainerFrame"..i end
U.specs=specs
local function read(f,key,kind,...)
 if not f or not S:Readable(f) then return nil,"UNKNOWN" end
 local fn=S:Field(f,key)
 return S:Public(fn,kind,f,...)
end
local geometryCurrent
local function current(row)
 local native=C.rows[row.name]
 return U.rows[row.name]==row and row.active and D.active and native==row.context
  and native.active and not native.pending and not native.ownerHandback
  and native.ownedOwner==D and native.frame==row.native and native.gate==row.gate
  and native.serial==row.serial and M.profile==row.profile and _G[row.name]==row.native
  and read(row.native,"GetParent")==row.gate and (not geometryCurrent or geometryCurrent(row)) and not M.state.safe
end
-- The native bar and launcher occupy one contiguous passive hover envelope.
-- A collapsed launcher consumes the original contextual demand, not merely
-- permission to show. Secure combat policy is predeclared separately from the
-- click/window-open state, so an Always/Combat SHOW choice never opens a bar.
U.syncProgram=[=[
 if self:GetAttribute("mui-utility-busy") then return end
 local gate=self:GetFrameRef("mui-utility-gate")
 local native=self:GetFrameRef("mui-utility-native")
 local icon=self:GetFrameRef("mui-utility-icon")
 local combat=self:GetAttribute("state-muiutilitycombat")=="combat"
 local demand=self:GetAttribute("mui-utility-demand")
 local forced=self:GetAttribute("mui-utility-force")
 local mode=combat and self:GetAttribute("mui-utility-combat-mode") or "quiet"
 if mode=="show" then demand=true elseif mode=="hide" then demand=false end
 local allowed=(mode~="hide" or forced) and (combat or not self:GetAttribute("mui-utility-startup"))
 local nativeProtected,nativeExplicit=false,false
 if native then nativeProtected,nativeExplicit=native:IsProtected() end
 local iconSafe=icon and (not combat or icon:IsProtected())
 local gateLive=self:GetAttribute("mui-utility-active") and gate and (not combat or gate:IsProtected())
  and gate:GetAttribute("mirage-live")
  and not gate:GetAttribute("mirage-emergency")
 local valid=gateLive and native and iconSafe and (not combat or nativeProtected) and native:GetParent()==gate
 local nativeShown=valid and native:IsShown()
 local open,wanted=false,false
 local tasks,unknown,first=0,0,0
 local hover="NONE"
 local hold="INACTIVE"
 local flags=""
 local dismissed=self:GetAttribute("mui-utility-dismissed")==true
 if valid and nativeShown and allowed then
  local previous=self:GetAttribute("mui-utility-task-flags") or ""
  local newlyVisible=false
  for i=1,(self:GetAttribute("mui-utility-task-count") or 0) do
   local f=self:GetFrameRef("mui-utility-task"..i)
   local seen=false
   local known=true
   if self:GetAttribute("mui-utility-task-live"..i) and f then
    -- IsProtected uses GetUnprotectedHandleFrame. IsVisible uses the stricter
    -- GetHandleFrame and cannot be called on an unprotected window in combat.
    -- Unknown combat windows never become a stale positive visibility hold.
    if not combat or f:IsProtected() then seen=f:IsVisible()
    else known=false;unknown=unknown+1 end
   end
   -- Keep the last *known* transition marker while a combat task is unknown.
   -- It never contributes a hold, and unknown->visible is not a new action
   -- when the same window was already visible before combat.
   flags=flags..(seen and "1" or known and "0" or string.sub(previous,i,i)=="1" and "1" or "0")
   if seen then
    tasks=tasks+1;if first==0 then first=i end
    if string.sub(previous,i,i)~="1" then newlyVisible=true end
   end
  end
  if newlyVisible or forced then dismissed=false end
  -- Restricted IsUnderMouse checks a rectangle, including hidden rectangles.
  -- Only effectively visible controls may extend an already opened drawer.
  if native:IsVisible() and native:IsUnderMouse() then hover="BAR"
  elseif icon:IsVisible() and icon:IsUnderMouse() then hover="ICON"
  elseif self:IsVisible() and self:IsUnderMouse() then hover="BRIDGE" end
  if tasks==0 and unknown==0 and hover=="NONE" then dismissed=false end
  open=forced or (not dismissed and (tasks>0 or (self:GetAttribute("mui-utility-open") and hover~="NONE")))
  wanted=demand or tasks>0 or open
  hold=open and (forced and "REVEAL" or tasks>0 and "VISIBLE_WINDOW" or "POINTER")
   or dismissed and "CLICK_DISMISSED" or unknown>0 and "COMBAT_WINDOW_UNKNOWN" or "NONE"
 else
  if valid and nativeShown then flags=self:GetAttribute("mui-utility-task-flags") or ""
  else dismissed=false end
  if valid then hold=not nativeShown and "NATIVE_HIDDEN" or "CONTEXT_BLOCKED"
  elseif gateLive then hold="NATIVE_UNOBSERVABLE" end
 end
 -- Observe native references before taking the re-entry guard. An unsupported
 -- native getter must not leave this guard set and poison every later event.
 self:SetAttribute("mui-utility-busy",true)
 self:SetAttribute("mui-utility-task-flags",flags)
 self:SetAttribute("mui-utility-dismissed",dismissed)
 self:SetAttribute("mui-utility-open",open and true or false)
 if open then
  self:Show();gate:SetAttribute("mirage-held",true);gate:SetAlpha(1);gate:Show()
  if gate:GetAttribute("mirage-context-fade") then gate:CallMethod("MirageContextFade",true) end
  if tasks==0 and not forced then
   if not self:GetAttribute("mui-utility-autohide") then
    self:RegisterAutoHide(.25)
    -- The hub already covers the complete prepared icon/bar rectangle.
    -- AddToAutoHide requires an explicitly protected handle; an inherited
    -- protected root is readable, but is not a legal additional hover member.
    if nativeExplicit then self:AddToAutoHide(native) end
    self:SetAttribute("mui-utility-autohide",true)
   end
  elseif self:GetAttribute("mui-utility-autohide") then
   self:UnregisterAutoHide();self:SetAttribute("mui-utility-autohide",false)
  end
 else
  if self:GetAttribute("mui-utility-autohide") then self:UnregisterAutoHide();self:SetAttribute("mui-utility-autohide",false) end
  self:Hide()
  if gateLive then
   gate:SetAttribute("mirage-held",false)
   if valid and nativeShown and allowed and gate:GetAttribute("mirage-context-fade") and not combat then
    gate:CallMethod("MirageContextFade",false)
   else gate:Hide() end
  end
 end
 if iconSafe then
  if wanted then
   icon:SetAlpha(1);icon:Show()
   if icon:GetAttribute("mui-utility-fade") then icon:CallMethod("MirageUtilityFade",true) end
  elseif valid and allowed and icon:GetAttribute("mui-utility-fade") and not combat then
   icon:CallMethod("MirageUtilityFade",false)
  else
   icon:Hide()
   if icon:GetAttribute("mui-utility-fade") then icon:CallMethod("MirageUtilityHidden") end
  end
 end
 local context=not allowed and "BLOCKED" or forced and "REVEAL" or demand and "DEMAND" or "QUIET"
 local iconVisible,barVisible
 if iconSafe then iconVisible=icon:IsVisible() and true or false end
 if valid then barVisible=native:IsVisible() and true or false end
 local status=valid and "READY" or "UNAVAILABLE"
 local signature=status..":"..context..":"..tostring(open and true or false)..":"..hold..":"..tasks..":"..unknown..":"..first..":"..hover..":"..tostring(iconVisible)..":"..tostring(barVisible)..":"..mode
 if self:GetAttribute("mui-utility-report")~=signature then
  self:SetAttribute("mui-utility-report",signature)
 end
 self:SetAttribute("mui-utility-busy",false)
]=]
U.clickProgram=[=[
 local hub=self:GetFrameRef("mui-utility-hub")
 if hub and hub:GetAttribute("mui-utility-active") then
  local close=hub:GetAttribute("mui-utility-open")==true
  hub:SetAttribute("mui-utility-dismissed",close)
  hub:SetAttribute("mui-utility-open",not close)
  hub:RunAttribute("mui-utility-sync")
 end
]=]
U.hiddenProgram=[=[
 if self:GetAttribute("mui-utility-active") and not self:GetAttribute("mui-utility-busy") then
  self:SetAttribute("mui-utility-autohide",false)
  self:SetAttribute("mui-utility-open",false)
  self:RunAttribute("mui-utility-sync")
 end
]=]
U.observeProgram=[=[
 if control:GetAttribute("mui-utility-active") then control:RunAttribute("mui-utility-sync") end
]=]
U.enterProgram=[=[
 local gate=control:GetFrameRef("mui-utility-gate")
 if control:GetAttribute("mui-utility-active") and gate and gate:IsVisible()
  and not control:GetAttribute("mui-utility-dismissed") and not control:GetAttribute("mui-utility-open") then
  control:SetAttribute("mui-utility-open",true)
  control:RunAttribute("mui-utility-sync")
 end
]=]
U.leaveProgram=[=[
 if control:GetAttribute("mui-utility-active") then control:RunAttribute("mui-utility-sync") end
]=]
local launcherSize=40 -- P21: 125% of the original 32-unit launcher, including hit/hover bounds.
local function line(icon,x,y,w,h,gold,rotation,alpha)
 local scale=launcherSize/32;x=x*scale;y=y*scale;w=w*scale;h=h*scale
 local t=icon:CreateTexture(nil,"ARTWORK")
 t:SetColorTexture(gold and .91 or .89,gold and .55 or .86,gold and .18 or .78,alpha or 1)
 t:SetSize(w,h);t:SetPoint("CENTER",icon,"CENTER",x,y)
 if rotation and t.SetRotation then t:SetRotation(rotation) end
 return t
end
function U:DrawIcon(icon,key)
 local asset=M.Icons and M.Icons:Path(key=="Bags" and "bags-launcher" or "micro-menu")
 if asset then
  local art=icon:CreateTexture(nil,"ARTWORK");art:SetAllPoints(icon)
  local okay,result=pcall(art.SetTexture,art,asset)
  if okay and result~=false then
   local highlight=icon:CreateTexture(nil,"HIGHLIGHT");highlight:SetAllPoints(icon);highlight:SetColorTexture(.91,.55,.18,.12)
   return
  end
  art:Hide()
 end
 local bg=icon:CreateTexture(nil,"BACKGROUND");bg:SetAllPoints(icon);bg:SetColorTexture(.018,.025,.032,.90)
 -- Quiet charcoal tile, restrained gold corners, and a warm top highlight.
 -- All shapes are native textures; no extra asset load or icon-font dependency.
 for _,edge in ipairs({{-15,0,1,30},{15,0,1,30},{0,15,30,1},{0,-15,30,1}}) do line(icon,edge[1],edge[2],edge[3],edge[4],true,nil,.38) end
 for _,corner in ipairs({{-12.5,15,6,1},{-15,12.5,1,6},{12.5,-15,6,1},{15,-12.5,1,6}}) do line(icon,corner[1],corner[2],corner[3],corner[4],true,nil,.9) end
 line(icon,0,13,23,1,false,nil,.10)
 if key=="Bags" then
  -- Tailored travel satchel: handle, folded flap, inset pocket and gold clasp.
  line(icon,-7,-2,1.5,13);line(icon,7,-2,1.5,13);line(icon,0,-8,15,1.5)
  line(icon,0,4.5,15,1.5);line(icon,-3.5,8,1.5,5);line(icon,3.5,8,1.5,5);line(icon,0,10,8,1.5)
  line(icon,-3.8,2,8,1.3,false,-.44);line(icon,3.8,2,8,1.3,false,.44)
  line(icon,-4,-5,1,4,false,nil,.4);line(icon,4,-5,1,4,false,nil,.4);line(icon,0,-6.5,8,1,false,nil,.4)
  line(icon,0,.3,3.2,3.2,true,math.pi/4)
 else
  -- Balanced adjustment sliders with inset handles, distinct at small scale.
  for _,r in ipairs({{-4,7},{4,0},{-1,-7}}) do
   line(icon,0,r[2],18,1.4,false,nil,.75)
   line(icon,r[1],r[2],4,6,true);line(icon,r[1],r[2],1.2,3,false,nil,.75)
  end
 end
 local highlight=icon:CreateTexture(nil,"HIGHLIGHT");highlight:SetAllPoints(icon);highlight:SetColorTexture(.91,.55,.18,.12)
end
local function points(frame)
 local n,status=read(frame,"GetNumPoints","number")
 if status~="KNOWN" or n<0 or n>8 or n~=math.floor(n) then return nil end
 local out={}
 for i=1,n do
  local ok,point,relative,relativePoint,x,y=pcall(frame.GetPoint,frame,i)
  if not ok or not S:Text(point) or not S:Readable(relative) or not S:Text(relativePoint) or not S:Number(x) or not S:Number(y) then return nil end
  out[i]={point,relative,relativePoint,x,y}
 end
 return out
end
local function sameUnit(a,b)
 local leases=M.Rework and M.Rework.CombatLeases
 if leases and type(leases.GeometryEqual)=="function" then return leases:GeometryEqual(a,b) end
 -- Before the shared runtime is loaded, exact public values are the only
 -- available proof. Do not introduce a second, wider geometry tolerance.
 return S:Number(a) and S:Number(b) and a==b
end
local function samePoints(a,b)
 if not a or not b or #a~=#b then return false end
 for i,p in ipairs(a) do for j=1,5 do
  if j>=4 then if not sameUnit(p[j],b[i][j]) then return false end
  elseif p[j]~=b[i][j] then return false end
 end end
 return true
end
geometryCurrent=function(row)
 local g=row.geometry
 if not g or not g.prepared or g.native~=row.native or read(row.native,"GetNumPoints","number")~=1 then return false end
 local ok,point,relative,relativePoint,x,y=pcall(row.native.GetPoint,row.native,1)
 return ok and S:Text(point) and S:Readable(relative) and S:Text(relativePoint) and S:Number(x) and S:Number(y)
  and point=="LEFT" and relative==row.icon and relativePoint=="RIGHT" and sameUnit(x,2) and sameUnit(y,0)
  and U.rows[row.name]==row and row.native==g.native and _G[row.name]==g.native
  and row.context==g.context and C.rows[row.name]==g.context and g.context.serial==row.serial and M.profile==row.profile
end
local function geometryAuthority(g,parent)
 local context=g.context
 return context.ownedOwner==D or context.ownedOwner==nil and not context.active and not context.pending and parent==g.originalParent
end
local function geometryIdentity(row,g,serial,parent,profile)
 local observed=read(g.native,"GetParent")
 return observed==parent and not S:InCombat() and U.rows[row.name]==row and row.geometry==g and row.native==g.native
  and _G[row.name]==g.native and row.context==g.context and C.rows[row.name]==g.context
  and geometryAuthority(g,parent) and g.context.frame==g.native and g.context.serial==serial and M.profile==profile
end
function U:GeometryStep(row,g,nextPoints,profile,method,...)
 local serial,parent=g.context.serial,read(g.native,"GetParent")
 if (parent~=g.gate and parent~=g.originalParent) or not geometryIdentity(row,g,serial,parent,profile) then return false,"NATIVE_CUSTODY_CHANGED" end
 local present=points(g.native)
 if not present then return false,"ANCHOR_READBACK_UNAVAILABLE" end
 if not geometryIdentity(row,g,serial,parent,profile)
  or not (samePoints(present,g.expected) or samePoints(present,g.attempted)) then return false,"NATIVE_CUSTODY_CHANGED" end
 local fn=S:Field(g.native,method)
 local marker=method=="SetPoint" and "SetPointBase" or method=="ClearAllPoints" and "ClearAllPointsBase"
 local nativeBase=marker and S:Field(g.native,marker)
 if type(nativeBase)=="function" then
  -- These roots inherit EditModeSystemMixin. Its Lua overrides change saved
  -- snap/anchor bookkeeping; the established source-qualified helper returns
  -- the base widget method for our reversible presentation transaction.
  local helper=M.Rework and M.Rework.NativeMethod
  local okay,base=false,nil
  if type(helper)=="function" then okay,base=pcall(helper,g.native,method) end
  if not okay or type(base)~="function" then return false,"NATIVE_BASE_METHOD_UNAVAILABLE" end
  fn=base
 end
 if not geometryIdentity(row,g,serial,parent,profile) then return false,"NATIVE_CUSTODY_CHANGED" end
 if type(fn)~="function" then return false,"NATIVE_METHOD_UNAVAILABLE" end
 -- Keep the last confirmed and proposed states across a before/after rejection.
 g.expected=present;g.attempted=nextPoints
 local okay,result=pcall(fn,g.native,...)
 if not geometryIdentity(row,g,serial,parent,profile) then return false,"NATIVE_CUSTODY_CHANGED" end
 local after=points(g.native)
 if not geometryIdentity(row,g,serial,parent,profile) then return false,"NATIVE_CUSTODY_CHANGED" end
 if samePoints(after,nextPoints) then g.expected=after;g.attempted=nil
 elseif samePoints(after,present) then g.attempted=nil end
 if not okay then return false,"NATIVE_SETTER_CALL_FAILED" end
 if result==false then return false,"NATIVE_SETTER_REFUSED" end
 if not after then return false,"ANCHOR_READBACK_UNAVAILABLE" end
 if not samePoints(after,nextPoints) then return false,"ANCHOR_READBACK_MISMATCH" end
 return true
end
function U:RestoreGeometry(row)
 local g=row and row.geometry
 if not g then return true end
 if S:InCombat() then self.pending=true;return false end
 -- Retirement may legitimately run after a profile switch. Its authority is
 -- only to reverse this still-owned journal; it never admits new placement.
 local profile=M.profile
 local parent=read(g.native,"GetParent")
 local serial=g.context.serial
 local identity=U.rows[row.name]==row and row.native==g.native and _G[row.name]==g.native
  and row.context==g.context and C.rows[row.name]==g.context and geometryAuthority(g,parent) and g.context.frame==g.native
 if not identity or (parent~=g.gate and parent~=g.originalParent) then
  row.geometry=nil;row.geometryChanged=true;return true
 end
 local present=points(g.native)
 if not geometryIdentity(row,g,serial,parent,profile) or not present then return false end
 if samePoints(present,g.original) then row.geometry=nil;return true end
 if not samePoints(present,g.expected) and not samePoints(present,g.attempted) then
  -- A newer layout wins. Never restore its points or immediately recapture it.
  row.geometry=nil;row.geometryChanged=true;return true
 end
 if not self:GeometryStep(row,g,{},profile,"ClearAllPoints") then return false end
 local restored={}
 for i,p in ipairs(g.original) do
  if not geometryIdentity(row,g,serial,parent,profile) then return false end
  local nextPoints={};for j=1,i-1 do nextPoints[j]=restored[j] end;nextPoints[i]=p
  if not self:GeometryStep(row,g,nextPoints,profile,"SetPoint",unpack(p)) then return false end
  restored=nextPoints
 end
 if not geometryIdentity(row,g,serial,parent,profile) then return false end
 row.geometry=nil;return true
end
local function binding(row)
 return {row=row,context=row.context,native=row.native,gate=row.gate,serial=row.serial,profile=row.profile}
end
local function sameBinding(name,seal)
 local row=seal and seal.row;local context=seal and seal.context
 return row and context and U.rows[name]==row and row.context==context and row.native==seal.native
  and row.gate==seal.gate and row.serial==seal.serial and row.profile==seal.profile
  and C.rows[name]==context and context.frame==seal.native and context.gate==seal.gate
  and context.serial==seal.serial and context.ownedOwner==D and _G[name]==seal.native and M.profile==seal.profile
end
local function preparationCurrent(row,seal)
 local parent=read(seal.native,"GetParent")
 return parent==seal.gate and not S:InCombat() and sameBinding(row.name,seal)
  and D.active and not M.state.safe and seal.context.active and not seal.context.pending and not seal.context.ownerHandback
end
function U:PrepareGeometry(row)
 local seal=binding(row)
 if not preparationCurrent(row,seal) then return false,"NATIVE_CUSTODY_CHANGED" end
 row.preparePhase="GEOMETRY_RESTORE"
 if not self:RestoreGeometry(row) then return false,"GEOMETRY_RESTORE_PENDING" end
 if row.geometryChanged then return false,"FOREIGN_GEOMETRY_RETAINED" end
 if not preparationCurrent(row,seal) then return false,"NATIVE_CUSTODY_CHANGED" end
 row.preparePhase="GEOMETRY_MEASURE"
 local nativeScale=read(row.native,"GetEffectiveScale","number")
 local uiScale=read(UIParent,"GetEffectiveScale","number")
 if not S:Number(nativeScale) or nativeScale<=0 or not S:Number(uiScale) or uiScale<=0 then return false,"NATIVE_SCALE_UNAVAILABLE" end
 local w,h
 if M.Layout and M.Layout.Screen then w,h=M.Layout:Screen()
 else w=read(UIParent,"GetWidth","number");h=read(UIParent,"GetHeight","number") end
 if not S:Number(w) or not S:Number(h) or w<=0 or h<=0 then return false,"VIEWPORT_PENDING" end
 local original=points(row.native)
 if not original then return false,"NATIVE_ANCHORS_UNAVAILABLE" end
 if #original==0 then return false,"NATIVE_ANCHORS_PENDING" end
 local ok,left,bottom,width,height=pcall(row.native.GetRect,row.native)
 if not ok then return false,"NATIVE_RECT_QUERY_FAILED" end
 -- GetRect may return nothing after ClearAllPoints invalidates native layout.
 -- This is not a rejected anchor receipt. No placement writes occur until a
 -- later ordinary update observes a settled public rectangle for this owner.
 if not S:Readable(left) or not S:Readable(bottom) or not S:Readable(width) or not S:Readable(height) then return false,"NATIVE_RECT_UNREADABLE" end
 if not preparationCurrent(row,seal) then return false,"NATIVE_CUSTODY_CHANGED" end
 if left==nil and bottom==nil and width==nil and height==nil then return false,"NATIVE_RECT_PENDING" end
 if not S:Number(left) or not S:Number(bottom) or not S:Number(width) or not S:Number(height) then return false,"NATIVE_RECT_UNREADABLE" end
 if width<=0 or height<=0 then return false,"NATIVE_RECT_PENDING" end
 local ratio=nativeScale/uiScale
 local gap=2;local total=(launcherSize+gap+width)*ratio;local tall=math.max(launcherSize,height)*ratio
 if total>w-8 or tall>h-8 then return false,"NATIVE_BAR_DOES_NOT_FIT" end
 local x=math.max(4,math.min(w-total-4,(left-launcherSize-gap)*ratio))
 local y=math.max(4+tall/2,math.min(h-4-tall/2,(bottom+height/2)*ratio))
 row.preparePhase="OWNED_LAUNCHER_LAYOUT"
 row.icon:SetScale(ratio);row.icon:ClearAllPoints();row.icon:SetPoint("LEFT",UIParent,"BOTTOMLEFT",x/ratio,y/ratio)
 row.hub:SetScale(ratio);row.hub:ClearAllPoints();row.hub:SetSize(launcherSize+gap+width,math.max(launcherSize,height))
 row.hub:SetPoint("LEFT",row.icon,"LEFT",0,0)
 row.hub:SetAttribute("mui-utility-autohide",false)
 if not preparationCurrent(row,seal) then return false,"NATIVE_CUSTODY_CHANGED" end
 local g={native=row.native,gate=row.gate,context=row.context,originalParent=row.context.originalParent,original=original,expected=original}
 row.geometry=g
 row.preparePhase="NATIVE_CLEAR_ANCHORS"
 local clear,why=self:GeometryStep(row,g,{},seal.profile,"ClearAllPoints")
 if not clear then return false,why end
 row.preparePhase="NATIVE_SET_ANCHOR"
 local ready,reason=self:GeometryStep(row,g,{{"LEFT",row.icon,"RIGHT",gap,0}},seal.profile,"SetPoint","LEFT",row.icon,"RIGHT",gap,0)
 g.prepared=ready==true;return ready,reason
end
function U:PrepareIconFade(row)
 local icon=row.icon;local effects=M.Effects
 local ready=effects and effects.PrepareProtected and effects:PrepareProtected(row,icon,function() return current(row) end)==true
 icon.MirageUtilityFade=function(_,shown)
  if not current(row) then return end
  local okay=effects and effects:TransitionProtected(row,icon,shown)
  if not okay and not S:InCombat() and current(row) then icon:SetAlpha(1);icon:SetShown(shown) end
 end
 icon.MirageUtilityHidden=function() if effects then effects:ObserveProtectedHidden(row,icon) end end
 icon:SetAttribute("mui-utility-fade",ready==true)
end
function U:Dispatch(row)
 if S:InCombat() or not row.hub then self.pending=true;return false end
 row.nextReconcile=S:Now()+self.reconcileInterval
 row.revision=((row.revision or 0)%100000)+1
 row.hub:SetAttribute("state-muiutilityrefresh",tostring(row.revision))
 return true
end
local stateValues={READY=true,UNAVAILABLE=true,INACTIVE=true,UNKNOWN=true}
local contextValues={BLOCKED=true,REVEAL=true,DEMAND=true,QUIET=true,UNKNOWN=true}
local holdValues={INACTIVE=true,VISIBLE_WINDOW=true,POINTER=true,REVEAL=true,CLICK_DISMISSED=true,
 COMBAT_WINDOW_UNKNOWN=true,NATIVE_HIDDEN=true,NATIVE_UNOBSERVABLE=true,CONTEXT_BLOCKED=true,NONE=true,UNKNOWN=true}
local hoverValues={NONE=true,BAR=true,ICON=true,BRIDGE=true,UNKNOWN=true}
local modeValues={show=true,hide=true,quiet=true,UNKNOWN=true}
local function choice(value,values) return S:Text(value) and values[value]==true and value or "UNKNOWN" end
function U:RecordState(row,status,context,open,hold,tasks,unknown,first,hover,iconVisible,barVisible,mode)
 if self.rows[row.name]~=row then return end
 local function flag(value) return S:Readable(value) and type(value)=="boolean" and (value and "YES" or "NO") or "UNKNOWN" end
 local function count(value) return S:Number(value) and value>=0 and value<=#row.spec.windows and value==math.floor(value) and value or nil end
 local index=count(first)
 row.runtime={current=choice(status,stateValues),context=choice(context,contextValues),open=flag(open),hold=choice(hold,holdValues),
  tasks=count(tasks),unknown=count(unknown),window=index and (index==0 and "NONE" or row.spec.windows[index]) or "UNKNOWN",
  hover=choice(hover,hoverValues),icon=flag(iconVisible),bar=flag(barVisible),mode=choice(mode,modeValues)}
 row.runtimeRevision=math.min(999999,(row.runtimeRevision or 0)+1)
end
function U:RecordReceipt(row,value)
 if not S:Text(value) or #value>256 then return end
 local status,context,opened,hold,tasks,unknown,first,hover,icon,bar,mode=value:match(
  "^([A-Z_]+):([A-Z_]+):(%a+):([A-Z_]+):(%d+):(%d+):(%d+):([A-Z_]+):(%a+):(%a+):(%a+)$")
 local function boolean(v) if v=="true" then return true elseif v=="false" then return false end end
 self:RecordState(row,status,context,boolean(opened),hold,tonumber(tasks),tonumber(unknown),tonumber(first),hover,boolean(icon),boolean(bar),mode)
end
function U:StateSummary()
 -- Support output consumes only our last completed secure state receipt. It
 -- never calls a widget getter, dispatches a controller or extends its life.
 local out={}
 for _,spec in ipairs(specs) do
  local row=self.rows[spec.name];local state=row and row.runtime
  out[#out+1]=spec.key.."=current:"..(state and state.current or "UNKNOWN")
   .."/context:"..(state and state.context or "UNKNOWN").."/open:"..(state and state.open or "UNKNOWN")
   .."/hold:"..(state and state.hold or "UNKNOWN").."/windows:"..tostring(state and state.tasks or "UNKNOWN")
   .."/unobserved:"..tostring(state and state.unknown or "UNKNOWN")
 end
 return (table.concat(out,"; ").."; observation=CACHED_SECURE_STATE; native_input=NOT_QUALIFIED"):sub(1,2048)
end
function U:Observe(row,frame,scripts,program)
 if not S:Frame(frame,false) then return true end
 row.hooked=row.hooked or setmetatable({},{__mode="k"})
 local tracked=row.hooked[frame] or {};row.hooked[frame]=tracked
 for _,script in ipairs(scripts) do
  if not tracked[script] then
   if type(frame.HasScript)=="function" and frame:HasScript(script)==false then tracked[script]="ABSENT"
   else
    local okay=pcall(SecureHandlerWrapScript,frame,script,row.hub,[[ return "mui-utility",true ]],program)
    if not okay then row.hookFailures=(row.hookFailures or 0)+1;return false end
    tracked[script]=true
   end
  end
 end
 return true
end
function U:ObserveInputs(row)
 local count,seen=0,{}
 local function visit(f,depth)
  if not S:Frame(f,false) or seen[f] then return true end
  if depth>6 or count>=128 then return false end
  seen[f]=true;count=count+1
  -- Native Wrapped_OnLeave executes only after Wrapped_OnEnter recorded a
  -- real motion entry. Both wrappers are required, even with no enter work.
  if not self:Observe(row,f,{"OnEnter"},self.enterProgram) or not self:Observe(row,f,{"OnLeave"},self.leaveProgram) then return false end
  local children=S:Field(f,"GetChildren")
  if type(children)=="function" then
   local ok,list=pcall(function() return {children(f)} end)
   if not ok or #list>128 then return false end
   for _,child in ipairs(list) do if not visit(child,depth+1) then return false end end
  end
  return true
 end
 return visit(row.native,0)
end
function U:ObserveGeometry(row)
 row.sizeHooked=row.sizeHooked or setmetatable({},{__mode="k"})
 if row.sizeHooked[row.native] then return true end
 local native=row.native
 if type(native.HookScript)~="function" or type(native.HasScript)=="function" and not native:HasScript("OnSizeChanged") then return false end
 local okay=pcall(native.HookScript,native,"OnSizeChanged",function(frame)
  if U.rows[row.name]~=row or not row.active or row.native~=frame or _G[row.name]~=frame then return end
  -- Native reflow can occur after a late menu button loads. Observe it only;
  -- the next existing ordinary context pass performs one legal envelope fit.
  row.layoutDirty=true;M.state.forceEvaluate=true
  if S:InCombat() then U.pending=true end
 end)
 if okay then row.sizeHooked[native]=true end
 return okay
end
function U:ObserveTask(row,frame,index)
 row.taskHooks=row.taskHooks or setmetatable({},{__mode="k"})
 local fn=S:Field(frame,"IsProtected")
 if type(fn)~="function" then return false end
 local okay,protected,explicit=pcall(fn,frame)
 if not okay or not S:Readable(protected) or not S:Readable(explicit)
  or type(protected)~="boolean" or (explicit~=nil and type(explicit)~="boolean") then return false end
 local _,visibleState=read(frame,"IsVisible","boolean")
 if visibleState~="KNOWN" then return false end
 if explicit then return self:Observe(row,frame,{"OnShow","OnHide"},self.observeProgram) end
 local hook=S:Field(frame,"HookScript")
 if type(hook)~="function" then return false end
 local record=row.taskHooks[frame]
 if not record then
  record={slots={},scripts={}};row.taskHooks[frame]=record
  record.changed=function()
   if U.rows[row.name]~=row or not row.active then return end
   local live=false;for slot in pairs(record.slots) do if row.tasks[slot]==frame then live=true;break end end
   if not live then return end
   row.taskDirty=true
   -- An ordinary native window callback cannot author a protected drawer in
   -- combat. The secure controller independently marks that task unknown;
   -- the next legal ordinary update observes its current effective visibility.
   if S:InCombat() then U.pending=true;return end
   if current(row) then
    local okay,done=pcall(U.Dispatch,U,row)
    if okay and done then row.taskDirty=nil
    else U:Fallback(row.name,"DRAWER_WINDOW_REFRESH_FAILED_NATIVE_RETAINED") end
   end
  end
 end
 record.slots[index]=true
 for _,script in ipairs({"OnShow","OnHide"}) do
  if not record.scripts[script] then
   if read(frame,"HasScript","boolean",script)~=true or not pcall(hook,frame,script,record.changed) then return false end
   record.scripts[script]=true
  end
 end
 return true
end
function U:DiscoverTasks(row)
 if S:InCombat() then self.pending=true;return false end
 local changed=false
 -- Slots are keyed by public global identity, so re-created native windows
 -- replace their own reference instead of consuming an ever-growing list.
 for i,name in ipairs(row.spec.windows) do
  local f=_G[name]
  if S:Frame(f,false) and row.tasks[i]~=f then
   if not self:ObserveTask(row,f,i) then return false end
   row.hub:SetFrameRef("mui-utility-task"..i,f);row.tasks[i]=f;changed=true
   row.hub:SetAttribute("mui-utility-task-live"..i,true)
   local flags=read(row.hub,"GetAttribute","string","mui-utility-task-flags") or ""
   row.hub:SetAttribute("mui-utility-task-flags",#flags==#row.spec.windows and flags:sub(1,i-1).."0"..flags:sub(i+1) or "")
  elseif not S:Frame(f,false) and row.tasks[i]~=nil then
   -- Native SetFrameRef cannot clear a reference. Retire its live bit so a
   -- removed global cannot leave an old shown window holding this drawer.
   row.hub:SetAttribute("mui-utility-task-live"..i,false);row.tasks[i]=nil;changed=true
  end
 end
 row.hub:SetAttribute("mui-utility-task-count",#row.spec.windows)
 return true,changed
end
function U:Create(spec)
 local row=self.rows[spec.name]
 if row and row.created then return row end
 if S:InCombat() then return nil end
 if row and not self:Stop(row) then return nil end
 if (self.attempts[spec.name] or 0)>=3 then return nil end
 self.attempts[spec.name]=(self.attempts[spec.name] or 0)+1
 row={name=spec.name,spec=spec,tasks={},active=false};self.rows[spec.name]=row
 -- Failed named secure widgets cannot be destroyed. Anonymous, retired
 -- attempts can be retried within the fixed three-attempt preparation budget.
 local hub=CreateFrame("Frame",nil,UIParent,"SecureHandlerStateTemplate")
 row.hub=hub;hub:Hide();hub:EnableMouse(false)
 assert(S:InitializeSecureHandler(hub),"UTILITY_HANDLER_UNAVAILABLE")
 hub:HookScript("OnAttributeChanged",function(_,name,value)
  if S:Text(name) and name=="mui-utility-report" then U:RecordReceipt(row,value) end
 end)
 hub:SetAttribute("mui-utility-sync",self.syncProgram)
 hub:SetAttribute("_onstate-muiutilityrefresh",[[ self:RunAttribute("mui-utility-sync") ]])
 hub:SetAttribute("_onstate-muiutilitycombat",[[ self:RunAttribute("mui-utility-sync") ]])
 hub:SetAttribute("mui-utility-active",false)
 SecureHandlerWrapScript(hub,"OnHide",hub,self.hiddenProgram)
 local icon=CreateFrame("Button",nil,UIParent,"SecureHandlerClickTemplate")
 row.icon=icon;icon:Hide();icon:SetSize(launcherSize,launcherSize);icon:EnableMouse(true)
 assert(S:InitializeSecureHandler(icon),"UTILITY_ICON_HANDLER_UNAVAILABLE")
 icon:RegisterForClicks("LeftButtonUp");icon:SetFrameRef("mui-utility-hub",hub)
 icon:SetAttribute("_onclick",self.clickProgram);hub:SetFrameRef("mui-utility-icon",icon)
 self:DrawIcon(icon,spec.key)
 icon:SetScript("OnEnter",function(f)
  if GameTooltip then
   GameTooltip:SetOwner(f,"ANCHOR_TOP");GameTooltip:SetText(spec.label)
   GameTooltip:AddLine(spec.hint,.89,.86,.78,true)
   GameTooltip:AddLine("Closes after leaving when its windows are closed. Click again to collapse.",.7,.72,.74,true)
   GameTooltip:Show()
  end
 end)
 icon:SetScript("OnLeave",function() if GameTooltip then GameTooltip:Hide() end end)
 assert(self:Observe(row,icon,{"OnEnter"},self.observeProgram) and self:Observe(row,icon,{"OnLeave"},self.leaveProgram),"UTILITY_ICON_HOVER_UNAVAILABLE")
 RegisterStateDriver(hub,"muiutilitycombat","[combat] combat; clear")
 if M.TrackRoot then M:TrackRoot("ActionBars",hub,false);M:TrackRoot("ActionBars",icon,false) end
 row.created=true
 return row
end
function U:Stop(row)
 if not row then return true end
 if S:InCombat() then self.pending=true;return false end
 row.active=false
 row.taskDirty=nil;row.nextReconcile=nil
 local complete=true
 local function attempt(f,method,...)
  if not f then return end
  local fn=S:Field(f,method)
  if type(fn)~="function" then complete=false;return end
  local okay,result=pcall(fn,f,...)
  if not okay or result==false then complete=false end
 end
 -- Attempt each owned cleanup independently. A half-created handler or one
 -- failing callback must not prevent the native context owner's handback.
 attempt(row.hub,"SetAttribute","mui-utility-active",false)
 attempt(row.hub,"SetAttribute","mui-utility-busy",false)
 if row.created then local okay,result=pcall(self.Dispatch,self,row);if not okay or not result then complete=false end end
 if M.Effects and row.icon then pcall(M.Effects.StopProtected,M.Effects,row,row.icon,1) end
 attempt(row.hub,"Hide");attempt(row.icon,"Hide");attempt(row.icon,"SetAlpha",1)
 local okay,restored=pcall(self.RestoreGeometry,self,row)
 if not okay or not restored then complete=false end
 self:RecordState(row,"INACTIVE","UNKNOWN",nil,"INACTIVE",nil,nil,nil,"UNKNOWN",nil,nil,"UNKNOWN")
 return complete
end
function U:Suspend()
 if S:InCombat() then self.pending=true;return false end
 for _,row in pairs(self.rows) do
  -- A whole-owner lifecycle starts a new admission. Retire its old measurement
  -- receipt before native context serials or profile identity can be renewed.
  row.geometryWait=nil;self:Stop(row)
 end
 return true
end
function U:Fallback(name,reason,seal)
 local row=self.rows[name]
 seal=seal or row and binding(row)
 -- Failure of a retired wait must never release a successor selected only by
 -- its public name. Each handback is scoped to the exact admitted generation.
 local sameRow=row and seal and seal.row==row and row.context==seal.context and row.native==seal.native
  and row.gate==seal.gate and row.serial==seal.serial and row.profile==seal.profile
 if sameRow then pcall(self.Stop,self,row);row.failure=reason end
 if not S:InCombat() and sameBinding(name,seal) then
  local okay,restored=pcall(C.ReleaseOwned,C,D,name)
  if sameRow and (not okay or not restored) then row.failure=reason..":RESTORE_PENDING" end
 end
 if sameRow and row.geometry then row.failure=reason..":GEOMETRY_RESTORE_PENDING" end
 self.ready=false
end
local settlingReasons={NATIVE_RECT_PENDING=true}
function U:PendingCurrent(row,wait)
 if not wait or row.geometryWait~=wait or not sameBinding(row.name,wait) then return false,"PENDING_CONTEXT_SUPERSEDED" end
 local enabled=M.Managed:Enabled()
 local parent=read(wait.native,"GetParent")
 local observed=points(wait.native)
 local scale=read(wait.native,"GetScale","number")
 local sameAnchors,sameScale=samePoints(observed,wait.points),sameUnit(scale,wait.scale)
 if row.geometryWait~=wait or not sameBinding(row.name,wait) then return false,"PENDING_CONTEXT_SUPERSEDED" end
 if not enabled or not D.active or M.state.safe or S:InCombat() or not wait.context.active
  or wait.context.pending or wait.context.ownerHandback then return false,"PENDING_CONTEXT_INACTIVE" end
 if parent~=wait.gate then return false,"PENDING_PARENT_CHANGED" end
 if not observed then return false,"PENDING_ANCHOR_READBACK_UNAVAILABLE" end
 if not sameAnchors then return false,"PENDING_ANCHORS_CHANGED" end
 if not sameScale then return false,"PENDING_SCALE_CHANGED" end
 return true
end
local function retainPendingGeometry(row,wait,reason)
 if sameBinding(row.name,wait) and (reason=="PENDING_PARENT_CHANGED" or reason=="PENDING_ANCHORS_CHANGED" or reason=="PENDING_SCALE_CHANGED") then
  row.geometryChanged=true
 end
end
function U:WaitForGeometry(row,reason)
 if not settlingReasons[reason] or row.geometry or row.geometryChanged then return false end
 local wait=row.geometryWait
 if wait then
  if wait.exhausted or not self:PendingCurrent(row,wait) then return false end
 else
  local observed=points(row.native);local scale=read(row.native,"GetScale","number")
  if not observed or not S:Number(scale) or scale<=0 then return false end
  wait={row=row,native=row.native,context=row.context,gate=row.gate,serial=row.serial,profile=row.profile,
   points=observed,scale=scale,attempts=0}
  row.geometryWait=wait
  if not self:PendingCurrent(row,wait) then row.geometryWait=nil;return false end
 end
 wait.attempts=wait.attempts+1;row.settleAttempts=wait.attempts
 if wait.attempts>=3 then wait.exhausted=true;return false end
 -- Stop only owned widgets. Keep the already-admitted native contextual parent
 -- and its original policy until either measured preparation or bounded handback.
 if not self:Stop(row) or not self:PendingCurrent(row,wait) then return false end
 wait.reason=reason;wait.nextAt=S:Now()+.2
 row.failure="DRAWER_GEOMETRY_PENDING";self.ready=false
 return true
end
function U:Configure(onlyName)
 if S:InCombat() then self.pending=true;return false end
 self.pending=false
 if not D.active then self:Suspend();return true end
 local editor=M.Elements and M.Elements.NativeEditorState and M.Elements:NativeEditorState()
 if editor and editor~="CLOSED" then
  for _,spec in ipairs(specs) do
   local row=self.rows[spec.name];if row then row.geometryWait=nil end
   self:Fallback(spec.name,"NATIVE_EDIT_MODE")
   if editor=="OPEN" and row then row.nativeEditReleased=true end
  end
  return false
 end
 if editor=="CLOSED" then for _,row in pairs(self.rows) do
  if row.nativeEditReleased then row.geometryChanged=nil;row.nativeEditReleased=nil end
 end end
 local complete=true
 for _,spec in ipairs(specs) do if not onlyName or onlyName==spec.name then
  local context=C.rows[spec.name]
  local profile=M.profile;local serial=context and context.serial
  if C:OwnedReady(D,spec.name) and context and context.active then
   local okay,row=pcall(self.Create,self,spec)
   if okay and row and row.created then
    local seal={row=row,context=context,native=context.frame,gate=context.gate,serial=serial,profile=profile}
    local failureReason="PREPARATION_CALL_FAILED"
    local function requireReady(ready,why)
     if not ready then failureReason=why or "PREPARATION_UNCONFIRMED";error("UTILITY_PREPARATION_REFUSED",0) end
    end
    local success=pcall(function()
     if row.geometryWait then
      local pending,why=self:PendingCurrent(row,row.geometryWait)
      if not pending then retainPendingGeometry(row,row.geometryWait,why) end
      requireReady(pending,why)
     end
     requireReady(C.rows[spec.name]==context and context.serial==serial and M.profile==profile,"NATIVE_CUSTODY_CHANGED")
     row.preparePhase="NATIVE_REFERENCES"
     row.context=context;row.native=seal.native;row.gate=seal.gate;row.serial=serial;row.profile=profile
     row.hub:SetFrameRef("mui-utility-gate",row.gate);row.hub:SetFrameRef("mui-utility-native",row.native)
     local ready,why=self:PrepareGeometry(row);requireReady(ready,why)
     row.layoutDirty=nil
     row.icon:SetFrameLevel(math.max(1,(read(row.native,"GetFrameLevel","number") or 1)+6))
     row.preparePhase="NATIVE_LIFETIME_HOOKS"
     requireReady(self:Observe(row,row.native,{"OnShow","OnHide"},self.observeProgram),"UTILITY_LIFETIME_OBSERVATION_UNAVAILABLE")
     row.preparePhase="NATIVE_INPUT_HOOKS"
     requireReady(self:ObserveInputs(row),"UTILITY_HOVER_OBSERVATION_UNAVAILABLE")
     row.preparePhase="NATIVE_REFLOW_HOOK"
     requireReady(self:ObserveGeometry(row),"UTILITY_REFLOW_OBSERVATION_UNAVAILABLE")
     row.preparePhase="NATIVE_WINDOW_HOOKS"
     requireReady(self:DiscoverTasks(row),"UTILITY_WINDOW_OBSERVATION_UNAVAILABLE")
     requireReady(preparationCurrent(row,seal),"NATIVE_CUSTODY_CHANGED")
     local pending=row.geometryWait;row.geometryWait=nil
     if pending then
      -- Reinstall the collapsed-bar driver before publishing a ready launcher.
      -- The measurements are settled; this pass does not clear native anchors.
      C:Update(M.Store and M.Store:Snapshot(),S:Now())
      requireReady(C:OwnedReady(D,row.name) and preparationCurrent(row,seal),"PENDING_NATIVE_CUSTODY_CHANGED")
     end
     row.active=true
     row.preparePhase="LAUNCHER_FADE"
     self:PrepareIconFade(row)
     row.hub:SetAttribute("mui-utility-open",false);row.hub:SetAttribute("mui-utility-dismissed",false)
     row.hub:SetAttribute("mui-utility-busy",false);row.hub:SetAttribute("mui-utility-active",true)
     row.hub:SetAttribute("mui-utility-report",nil);row.taskDirty=nil
     row.preparePhase="CONTEXT_POLICY"
     self:RefreshPolicy(row,M.Store and M.Store.Snapshot and M.Store:Snapshot(),S:Now(),nil,true)
     row.preparePhase="SECURE_INITIAL_STATE"
     requireReady(self:Dispatch(row),"UTILITY_INITIAL_STATE_UNAVAILABLE")
     requireReady(preparationCurrent(row,seal),"NATIVE_CUSTODY_CHANGED")
    end)
    if not success then
     row.lastPreparationPhase=row.preparePhase or "NATIVE_REFERENCES";row.lastPreparationIssue=failureReason
     local held=self:WaitForGeometry(row,failureReason)
     if held then
      -- Pending roots retain native contextual behavior, including their secure
      -- combat preference, while a fixed later measurement is outstanding.
      C:Update(M.Store and M.Store:Snapshot(),S:Now())
     else
      local exhausted=row.geometryWait and row.geometryWait.exhausted
      if row.geometryWait then row.geometryWait.exhausted=true end
      self:Fallback(spec.name,exhausted and "DRAWER_GEOMETRY_WAIT_EXHAUSTED_NATIVE_RETAINED" or "DRAWER_PREPARATION_FAILED_NATIVE_RETAINED",seal)
     end
     complete=false
    else row.failure=nil;row.preparePhase="READY" end
   else
    complete=false;row=self.rows[spec.name]
    if row then
     row.context=context;row.native=context.frame;row.gate=context.gate;row.serial=serial;row.profile=profile
     self:Fallback(spec.name,"DRAWER_CREATION_FAILED_NATIVE_RETAINED",binding(row))
     row.lastPreparationPhase="WIDGET_CREATION";row.lastPreparationIssue="UTILITY_WIDGET_CONSTRUCTION_FAILED"
    end
   end
  else
   self:Stop(self.rows[spec.name])
   if _G[spec.name]~=nil then complete=false end
  end
 end end
 for _,spec in ipairs(specs) do if _G[spec.name]~=nil and not (self.rows[spec.name] and current(self.rows[spec.name])) then complete=false end end
 self.ready=complete
 return complete
end
function U:RetrySettling(now)
 if self.retrying or self.configuring or S:InCombat() or not D.active then return end
 now=now or S:Now()
 for _,spec in ipairs(specs) do
  local row=self.rows[spec.name];local wait=row and row.geometryWait
  if wait and not wait.exhausted and now>=(wait.nextAt or math.huge) then
   self.retrying=true
   local editor=M.Elements and M.Elements.NativeEditorState and M.Elements:NativeEditorState()
   local owned,why=self:PendingCurrent(row,wait)
   if editor and editor~="CLOSED" or not owned then
    retainPendingGeometry(row,wait,why)
    wait.exhausted=true;row.lastPreparationPhase="GEOMETRY_SETTLE";row.lastPreparationIssue=editor and editor~="CLOSED" and "NATIVE_EDIT_MODE" or why
    if editor=="OPEN" then row.nativeEditReleased=true end
    self:Fallback(spec.name,"DRAWER_PENDING_NATIVE_HANDOFF",wait)
   else
    local okay=pcall(self.Configure,self,spec.name)
    if not okay then wait.exhausted=true;self:Fallback(spec.name,"DRAWER_SETTLE_CALL_FAILED_NATIVE_RETAINED",wait) end
   end
   self.retrying=false
  end
 end
end
-- Keep the native bar driver quiet: its independent launcher consumes the
-- original combat policy. This override is installed before acquisition so
-- an immediate combat transition cannot expand the bar behind the drawer.
local nativeDriver=C.DriverFor
local policy=C.OwnedPolicy
local function utilityRoot(row) return row.ownedOwner==D and (row.name=="BagsBar" or row.name=="MicroMenuContainer") end
local function combatMode(row,profile)
 return nativeDriver(C,row,profile):match("%[combat%] (%w+)") or "quiet"
end
local function utilityDriver(row,profile)
 local drawer=U.rows[row.name];local wait=drawer and drawer.geometryWait
 if wait and not wait.exhausted and wait.context==row then return nativeDriver(C,row,profile) end
 return combatMode(row,profile)=="hide" and "[combat] hide; quiet" or "[combat] quiet; quiet"
end
function C:DriverFor(row,profile)
 if utilityRoot(row) then return utilityDriver(row,profile) end
 return nativeDriver(self,row,profile)
end
function U:RefreshPolicy(row,snapshot,now,force,initial)
 if S:InCombat() then self.pending=true;return end
 if force==nil then force=read(row.gate,"GetAttribute","boolean","mirage-force")==true end
 local held,forced=policy(C,row.context,snapshot,now,force,false)
 local startup=M.StartupPresentation and M.StartupPresentation:IsQuiet()==true or false
 local mode=combatMode(row.context,M.profile)
 local changed=initial or row.demand~=held or row.forced~=forced or row.combatMode~=mode or row.startup~=startup
 if changed then
  row.demand=held;row.forced=forced;row.combatMode=mode;row.startup=startup
  row.hub:SetAttribute("mui-utility-demand",held);row.hub:SetAttribute("mui-utility-force",forced)
  row.hub:SetAttribute("mui-utility-combat-mode",mode);row.hub:SetAttribute("mui-utility-startup",startup)
  if not initial then self:Dispatch(row) end
 end
 return held,forced
end
function C:OwnedPolicy(row,snapshot,now,show,uncertain)
 local drawer=U.rows[row.name]
 if utilityRoot(row) and drawer and drawer.active and drawer.context==row and not geometryCurrent(drawer) and not S:InCombat() then
  U:Fallback(row.name,"UTILITY_GEOMETRY_CHANGED_NATIVE_RETAINED")
 end
 if not utilityRoot(row) or not drawer or not current(drawer) then
  local held,force,driver=policy(self,row,snapshot,now,show,uncertain)
  return held,force,utilityRoot(row) and utilityDriver(row,M.profile) or driver
 end
 local _,force=U:RefreshPolicy(drawer,snapshot,now,show==true)
 return not drawer.startup and read(drawer.hub,"GetAttribute","boolean","mui-utility-open")==true,
  not drawer.startup and force==true,utilityDriver(row,M.profile)
end
-- The existing presentation-group observer samples this passive rectangle
-- even while hidden. No invisible button is installed to capture clicks.
local hoverFrame=C.HoverFrame
function C:HoverFrame(row)
 local drawer=row and U.rows[row.name]
 if drawer and drawer.layoutDirty and current(drawer) and not S:InCombat() then
  drawer.layoutDirty=nil
  local seal=binding(drawer)
  local okay,ready,why=pcall(U.PrepareGeometry,U,drawer)
  if not okay or not ready then
   drawer.lastPreparationPhase=drawer.preparePhase or "GEOMETRY_MEASURE"
   drawer.lastPreparationIssue=okay and why or "PREPARATION_CALL_FAILED"
   if not U:WaitForGeometry(drawer,drawer.lastPreparationIssue) then
    U:Fallback(row.name,"UTILITY_REFLOW_UNAVAILABLE_NATIVE_RETAINED",seal)
   end
  else U:Dispatch(drawer) end
 end
 if drawer and current(drawer) then
  return read(drawer.hub,"GetAttribute","boolean","mui-utility-open")==true and drawer.hub or drawer.icon
 end
 return hoverFrame(self,row)
end
local occlusionFrame=C.OcclusionFrame
function C:OcclusionFrame(row)
 local drawer=row and U.rows[row.name]
 if drawer and current(drawer) then return self:HoverFrame(row) end
 return occlusionFrame(self,row)
end
local configure=D.Configure
function D:Configure(...)
 U.configuring=true
 local okay,why=pcall(function(...)
  U:Suspend();configure(self,...);U:Configure()
 end,...)
 U.configuring=false
 if not okay then error(why,0) end
 return self:ContextHealth()
end
local contextHealth=D.ContextHealth
function D:ContextHealth()
 local ready=contextHealth(self)
 for _,row in pairs(U.rows) do if not row.active and row.geometry then ready=false end end
 if self.active then for _,spec in ipairs(specs) do
  if _G[spec.name]~=nil and not (U.rows[spec.name] and current(U.rows[spec.name])) then ready=false end
 end end
 self.contextReady=ready
 return ready
end
local healthChanged=D.OnNativeContextHealthChanged
function D:OnNativeContextHealthChanged(...)
 if healthChanged then healthChanged(self,...) end
 if not S:InCombat() then
  for _,row in pairs(U.rows) do if not current(row) then U:Stop(row) end end
 else U.pending=true end
end
local retry=D.Retry
function D:Retry(...)
 if not S:InCombat() then
  U.attempts={}
  for _,row in pairs(U.rows) do row.geometryChanged=nil;row.geometryWait=nil;row.settleAttempts=0 end
 end
 return retry(self,...)
end
local report=D.Report
function D:Report(...)
 local lines={report(self,...),"native_utility.launchers=CUSTOM_BAG_AND_SYSTEM_ICONS",
  "native_utility.drawer_input=ORIGINAL_NATIVE_CONTROLS",
  "native_utility.drawer_geometry=RIGHT_OF_LAUNCHER_REVERSIBLE_POINTS_NATIVE_SIZE_SCALE",
  "native_utility.drawer_context=ORIGINAL_LAUNCH_DEMAND_AND_COMBAT_POLICY",
  "native_utility.drawer_windows=EFFECTIVE_VISIBILITY;CLICK_TOGGLE;NEW_VISIBLE_TASK_CLEARS_DISMISSAL",
  "native_utility.drawer_combat_windows=PROTECTED_HANDLES_ONLY;UNPROTECTED_VISIBILITY_UNKNOWN_UNTIL_COMBAT_EXIT;NATIVE_WINDOWS_UNCHANGED",
  "native_utility.drawer_work=EVENT_BOUND;OPEN_OR_DIRTY_RECONCILE_AT_MOST_4HZ_ON_EXISTING_CONTEXT_UPDATE;NO_OWN_ONUPDATE",
  "native_utility.drawer_state="..U:StateSummary()}
 for _,spec in ipairs(specs) do local row=U.rows[spec.name]
  lines[#lines+1]="native_utility."..spec.name..".drawer="..(row and row.active and "READY" or row and row.failure or "NATIVE_FALLBACK")
  lines[#lines+1]="native_utility."..spec.name..".drawer_preparation=phase:"..(row and row.preparePhase or "NOT_STARTED")
   ..";last_failure_phase:"..(row and row.lastPreparationPhase or "NONE")..";last_failure:"..(row and row.lastPreparationIssue or "NONE")
   ..";settle_attempts:"..tostring(row and row.settleAttempts or 0).."/3;geometry_readback:PUBLIC_ANCHOR_IDENTITIES_AND_SHARED_UIUNIT_BOUND"
  local state=row and row.runtime
  lines[#lines+1]="native_utility."..spec.name..".drawer_observation=current:"..(state and state.current or "UNKNOWN")
   ..";context:"..(state and state.context or "UNKNOWN")..";open:"..(state and state.open or "UNKNOWN")
   ..";hold:"..(state and state.hold or "UNKNOWN")..";visible_windows:"..tostring(state and state.tasks or "UNKNOWN")
   ..";unobserved_windows:"..tostring(state and state.unknown or "UNKNOWN")..";first_window:"..(state and state.window or "UNKNOWN")
   ..";pointer:"..(state and state.hover or "UNKNOWN")..";icon_visible:"..(state and state.icon or "UNKNOWN")
   ..";bar_visible:"..(state and state.bar or "UNKNOWN")..";combat_mode:"..(state and state.mode or "UNKNOWN")
   ..";receipt:"..tostring(row and row.runtimeRevision or 0)..";source:CACHED_COMPLETED_SECURE_SYNC"
 end
 return table.concat(lines,"\n")
end
local contextUpdate=C.Update
function U:ReconcileOpen(now)
 if self.configuring or self.retrying or not D.active or S:InCombat() then return end
 now=now or S:Now();if not S:Number(now) then return end
 for _,spec in ipairs(specs) do
  local row=self.rows[spec.name]
  -- Closed, settled drawers perform no task census. This bounded safety net
  -- only retires an opened/dirty row whose native leave or visibility callback
  -- was lost; it shares the existing context scheduler and fixed task slots.
  if row and row.active and (row.taskDirty or row.runtime and row.runtime.open=="YES")
   and now>=(row.nextReconcile or 0) and current(row) then
   local okay,done=pcall(self.Dispatch,self,row)
   if okay and done then row.taskDirty=nil
   else self:Fallback(row.name,"DRAWER_RECONCILE_FAILED_NATIVE_RETAINED") end
  end
 end
end
function C:Update(snapshot,now)
 local result=contextUpdate(self,snapshot,now)
 U:RetrySettling(now)
 U:ReconcileOpen(now)
 return result
end
local events=CreateFrame("Frame")
for _,event in ipairs({"ADDON_LOADED","PLAYER_REGEN_ENABLED","PLAYER_ENTERING_WORLD","DISPLAY_SIZE_CHANGED","UI_SCALE_CHANGED","EDIT_MODE_LAYOUTS_UPDATED"}) do events:RegisterEvent(event) end
events:SetScript("OnEvent",function(_,event)
 if not D.active then return end
 if S:InCombat() then U.pending=true;return end
 if event=="DISPLAY_SIZE_CHANGED" or event=="UI_SCALE_CHANGED" or event=="EDIT_MODE_LAYOUTS_UPDATED" then U:Configure();return end
 for _,row in pairs(U.rows) do if current(row) then
  local sent,okay,changed=pcall(U.DiscoverTasks,U,row)
  if not sent or not okay then U:Fallback(row.name,"DRAWER_WINDOW_OBSERVATION_FAILED_NATIVE_RETAINED")
  elseif changed or U.pending or event=="PLAYER_ENTERING_WORLD" or event=="PLAYER_REGEN_ENABLED" then
   local invoked,finished=pcall(U.Dispatch,U,row)
   if not invoked or not finished then U:Fallback(row.name,"DRAWER_REFRESH_FAILED_NATIVE_RETAINED") end
  end
 end end
 U.pending=false
end)
U.events=events
