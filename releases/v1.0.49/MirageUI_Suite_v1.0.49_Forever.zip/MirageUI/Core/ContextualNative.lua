local _,M=...
-- Reversible visibility for fallback controls and explicitly admitted native
-- backing. Native scripts, unit watches, action paging and keys are retained.
-- The ordinary CVE contributes reveal/task/hover holds OUTSIDE combat. Combat,
-- and special-gameplay changes use a predeclared secure controller. Fresh selection
-- is a brief ordinary hold; a stale target/focus does not defeat quiet idle.
local S,N=M.Safety,M.ManagedNative
local nativeEditPending=N.NativeEditPending
local C={rows={},nativeChildren={},status={},threatUntil=0}
M.ContextualNative=C
-- CVE owns the ordinary .10s contextual pass. The managed .20s job is a
-- fallback, not a second census of every native input subtree. This private
-- record skips work only; it never supplies native write/read authority.
local observationCycle,observationTick,observationSerial=nil,nil,0
-- Most admitted containers retain the existing contextual parent contract.
-- PLAYER instead keeps its native parent/lifetime and journals presentation and
-- click input, because its native Pet subtree performs managed layout on Show.
-- No native unit watch or event handler is replaced. The separately journalled
-- pet layout lease removes only its managed-container participation.
-- PLAYER source: Gethe/wow-ui-source bebcb6bf309cf41b41bd74f8ca651e6a105b2676.
local ownedContracts={PlayerFrame="UnitFrames",TargetFrame="UnitFrames",FocusFrame="UnitFrames",PetFrame="UnitFrames",
 BossTargetFrameContainer="UnitFrames",PartyFrame="PartyRaid",CompactRaidFrameContainer="PartyRaid",
 BagsBar="ActionBars",MicroMenuContainer="ActionBars",PetActionBar="ActionBars",StanceBar="ActionBars",PossessActionBar="ActionBars",
 BuffFrame="Auras",DebuffFrame="Auras",EssentialCooldownViewer="Cooldowns",UtilityCooldownViewer="Cooldowns",
 BuffIconCooldownViewer="Cooldowns",BuffBarCooldownViewer="Cooldowns",StatusTrackingBarManager="ActionBars"}
local reviewedClient=M.Client and (M.Client.RuntimeAvailable or M.Client.IsReviewedPresentationClient)
local units={PlayerFrame="player",TargetFrame="target",FocusFrame="focus",PetFrame="pet"}
local groupPresentationRoots={PartyFrame=true,CompactRaidFrameContainer=true}
local cooldowns={EssentialCooldownViewer=true,UtilityCooldownViewer=true,BuffIconCooldownViewer=true,BuffBarCooldownViewer=true}
local bottomManagedCooldowns={EssentialCooldownViewer=true,UtilityCooldownViewer=true,BuffIconCooldownViewer=true}
local controls={PetActionBar=true,StanceBar=true,BagsBar=true,MicroMenuContainer=true,MicroMenu=true,
 StatusTrackingBarManager=true,MainStatusTrackingBarContainer=true,SecondaryStatusTrackingBarContainer=true}
local base={
 {"PlayerFrame","UnitFrames"},{"TargetFrame","UnitFrames"},{"FocusFrame","UnitFrames"},{"PetFrame","UnitFrames"},
 {"MainActionBar","ActionBars"},{"MultiBarBottomLeft","ActionBars"},{"MultiBarBottomRight","ActionBars"},
 {"MultiBarRight","ActionBars"},{"MultiBarLeft","ActionBars"},{"MultiBar5","ActionBars"},{"MultiBar6","ActionBars"},{"MultiBar7","ActionBars"},
 {"PetActionBar","ActionBars"},{"StanceBar","ActionBars"},
 {"StatusTrackingBarManager","ActionBars"},{"MainStatusTrackingBarContainer","ActionBars"},{"SecondaryStatusTrackingBarContainer","ActionBars"},
 {"BuffFrame","Auras"},{"DebuffFrame","Auras"},{"DamageMeter","DamageMeters"},
 {"EssentialCooldownViewer","Cooldowns"},{"UtilityCooldownViewer","Cooldowns"},{"BuffIconCooldownViewer","Cooldowns"},{"BuffBarCooldownViewer","Cooldowns"},
}
C.driver="[vehicleui] show; [overridebar] show; [possessbar] show; [petbattle] show; [combat] show; quiet"
C.quietDriver="[vehicleui] show; [overridebar] show; [possessbar] show; [petbattle] show; [combat] show; quiet"
C.program=[=[
self:SetAttribute("mirage-state",newstate)
if self:GetAttribute("mirage-live") and not self:GetAttribute("mirage-emergency")
 and self:GetAttribute("mirage-sidebar-combat") and (newstate=="hide" or not self:GetAttribute("mirage-layout-ready")) then
 if newstate=="hide" then self:SetAttribute("mirage-layout-ready",false) end
 self:Hide()
elseif not self:GetAttribute("mirage-live") or self:GetAttribute("mirage-emergency") or self:GetAttribute("mirage-force")
 or (newstate ~= "quiet" and newstate ~= "hide") or (newstate == "quiet" and self:GetAttribute("mirage-held")) then
 self:Show()
else
 self:Hide()
end
]=]
C.fadeProgram=[=[
self:SetAttribute("mirage-state",newstate)
if self:GetAttribute("mirage-live") and not self:GetAttribute("mirage-emergency")
 and self:GetAttribute("mirage-sidebar-combat") and (newstate=="hide" or not self:GetAttribute("mirage-layout-ready")) then
 if newstate=="hide" then self:SetAttribute("mirage-layout-ready",false) end
 self:CallMethod("MirageContextStopFade")
 self:Hide()
 self:CallMethod("MirageContextHidden")
elseif not self:GetAttribute("mirage-live") or self:GetAttribute("mirage-emergency") or self:GetAttribute("mirage-force")
 or (newstate ~= "quiet" and newstate ~= "hide") or (newstate == "quiet" and self:GetAttribute("mirage-held")) then
 self:SetAlpha(1)
 self:Show()
 self:CallMethod("MirageContextFade",true)
elseif newstate == "hide" then
 self:CallMethod("MirageContextStopFade")
 self:Hide()
 self:CallMethod("MirageContextHidden")
else
 self:CallMethod("MirageContextFade",false)
end
]=]
-- PlayerFrame owns a native managed-layout subtree (including PetFrame).
-- Hide/Show of a contextual ancestor dispatches native managed OnShow/OnHide,
-- which calls Layout:SetSize even during combat. Keep that native lifetime and
-- parent intact. This controller changes only presentation and declared input.
-- The reviewed restricted API has EnableMouse, but no split mouse setters:
-- motion-only children remain native, and click-only controls refuse admission.
C.playerProgram=[=[
-- Metadata written below does not dispatch this attribute program. Do not
-- retain a latch that can disable emergency access after a native exception.
local wasCommitted=self:GetAttribute("mirage-player-committed")
self:SetAttribute("mirage-player-committed",false)
self:SetAttribute("mirage-player-applying",true)
local root=self:GetFrameRef("mirage-player")
local parent=self:GetFrameRef("mirage-player-parent")
if not root or not parent or root:GetParent()~=parent then
 self:SetAttribute("mirage-player-conflict",true)
 self:SetAttribute("mirage-player-ready",false)
 self:SetAttribute("mirage-player-applying",false)
 return
end
local conflict=self:GetAttribute("mirage-player-conflict")
local count=self:GetAttribute("mirage-player-count") or 0
for i=1,count do
 local f=self:GetFrameRef("mirage-player-node"..i)
 local node=f
 local native=false
 for depth=1,32 do
  if node==root then native=true;break end
  if not node then break end
  node=node:GetParent()
 end
 local click=f and f:IsMouseClickEnabled()
 local motion=f and f:IsMouseMotionEnabled()
 local owned=self:GetAttribute("mirage-player-input"..i)
 local pending=self:GetAttribute("mirage-player-pending"..i)
 if owned and pending~=nil and click==pending and motion==pending then
  self:SetAttribute("mirage-player-last"..i,pending)
  self:SetAttribute("mirage-player-pending"..i,nil)
 end
 if not native or (owned and (click~=self:GetAttribute("mirage-player-last"..i) or motion~=self:GetAttribute("mirage-player-last"..i)))
  or (not owned and click) then
  conflict=true
  self:SetAttribute("mirage-player-input"..i,false)
 end
end
if conflict then
 self:SetAttribute("mirage-player-conflict",true)
 self:SetAttribute("mirage-player-ready",false)
end
local state=self:GetAttribute("mirage-state")
local shown=not self:GetAttribute("mirage-player-ready") or not self:GetAttribute("mirage-live")
 or self:GetAttribute("mirage-emergency") or self:GetAttribute("mirage-force")
 or self:GetAttribute("mirage-group-pending")
 or (state~="quiet" and state~="hide") or (state=="quiet" and self:GetAttribute("mirage-held"))
shown=shown and true or false
if self:GetAttribute("mirage-context-fade") then
 local generation=self:GetAttribute("mirage-player-generation")
 self:CallMethod("MiragePlayerPrepareFade",shown)
 -- Stop callbacks may reenter handback or a successor acquisition. The old
 -- secure invocation must not commit over that newer contextual owner.
 if self:GetAttribute("mirage-player-generation")~=generation
  or not self:GetAttribute("mirage-player-apply")
  or not self:GetAttribute("mirage-player-applying")
  or self:GetFrameRef("mirage-player")~=root or root:GetParent()~=parent then return end
end
local alpha=shown and self:GetAttribute("mirage-player-alpha") or 0
-- A retained input review is not a new alpha request. Rewriting the same
-- endpoint while its Alpha animation is playing makes the native animation
-- and this secure owner compete over the same property.
local alphaChanged=not wasCommitted or self:GetAttribute("mirage-player-alpha-last")~=alpha
if shown and alphaChanged then
 self:SetAttribute("mirage-player-alpha-pending",alpha)
 root:SetAlpha(alpha)
 self:SetAttribute("mirage-player-alpha-last",alpha)
 self:SetAttribute("mirage-player-alpha-pending",nil)
end
local complete=true
for i=1,count do
 if self:GetAttribute("mirage-player-input"..i) then
  local f=self:GetFrameRef("mirage-player-node"..i)
  if self:GetAttribute("mirage-player-last"..i)~=shown then
   self:SetAttribute("mirage-player-pending"..i,shown)
   f:EnableMouse(shown)
  end
  if f:IsMouseClickEnabled()==shown and f:IsMouseMotionEnabled()==shown then
   self:SetAttribute("mirage-player-last"..i,shown)
   self:SetAttribute("mirage-player-pending"..i,nil)
  else complete=false end
 end
end
if not complete then
 -- Concealment may never leave a native click target invisible. Recover
 -- already-committed input changes; retain failures as an explicit debt.
 shown=true;alpha=self:GetAttribute("mirage-player-alpha")
 self:SetAttribute("mirage-player-ready",false)
 self:SetAttribute("mirage-player-conflict",true)
 self:SetAttribute("mirage-player-alpha-pending",alpha)
 root:SetAlpha(alpha)
 self:SetAttribute("mirage-player-alpha-last",alpha)
 self:SetAttribute("mirage-player-alpha-pending",nil)
 for i=1,count do
  if self:GetAttribute("mirage-player-input"..i) then
   local f=self:GetFrameRef("mirage-player-node"..i)
   local last=self:GetAttribute("mirage-player-last"..i)
   if f:IsMouseClickEnabled()==last and f:IsMouseMotionEnabled()==last then
    self:SetAttribute("mirage-player-pending"..i,true)
    f:EnableMouse(true)
    if f:IsMouseClickEnabled() and f:IsMouseMotionEnabled() then
     self:SetAttribute("mirage-player-last"..i,true)
     self:SetAttribute("mirage-player-pending"..i,nil)
    end
   end
  end
 end
end
if not shown and alphaChanged then
 self:SetAttribute("mirage-player-alpha-pending",0)
 root:SetAlpha(0)
 self:SetAttribute("mirage-player-alpha-last",0)
 self:SetAttribute("mirage-player-alpha-pending",nil)
end
self:SetAttribute("mirage-player-presented",shown)
self:SetAttribute("mirage-player-committed",complete)
self:SetAttribute("mirage-player-applying",false)
if self:GetAttribute("mirage-context-fade") then
 if complete and self:GetAttribute("mirage-player-ready") and self:GetAttribute("mirage-live")
  and not self:GetAttribute("mirage-emergency") and not self:GetAttribute("mirage-player-conflict") then
  self:CallMethod("MiragePlayerFade",shown)
 else
  self:CallMethod("MirageContextStopFade")
 end
end
]=]
-- Use the attribute template alone: stacking State and Attribute templates
-- would replace one OnAttributeChanged handler. Dispatch the state here.
C.playerAttributeProgram=[=[
if name=="state-miragecontext" then
 self:SetAttribute("mirage-state",value)
 -- Native roster/aura pools may grow during combat. Retain access after the
 -- secure combat floor until an ordinary, bounded input census can be renewed.
 if (self:GetAttribute("mirage-group") or self:GetAttribute("mirage-player-refresh-combat")) and value=="show" then
  self:SetAttribute("mirage-group-pending",true)
 end
 self:RunAttribute("mirage-player-apply")
elseif name=="mirage-player-alpha-refresh" then
 -- Ordinary completion may request this only outside combat. The request
 -- contains no alpha or visibility decision: replay the current secure
 -- endpoint only while this exact declared input controller remains ready.
 if self:GetAttribute("mirage-player-ready") and self:GetAttribute("mirage-live")
  and self:GetAttribute("mirage-player-committed") and not self:GetAttribute("mirage-player-applying")
  and not self:GetAttribute("mirage-player-conflict") then
  local root=self:GetFrameRef("mirage-player")
  local parent=self:GetFrameRef("mirage-player-parent")
  local alpha=self:GetAttribute("mirage-player-alpha-last")
  if root and parent and root:GetParent()==parent and alpha~=nil then
   self:SetAttribute("mirage-player-alpha-pending",alpha)
   self:SetAttribute("mirage-player-applying",true)
   root:SetAlpha(alpha)
   self:SetAttribute("mirage-player-alpha-pending",nil)
   self:SetAttribute("mirage-player-applying",false)
  end
 end
elseif name=="mirage-held" or name=="mirage-force" or name=="mirage-live" or name=="mirage-emergency"
 or name=="mirage-player-refresh" or name=="mirage-group-pending" then
 self:RunAttribute("mirage-player-apply")
end
]=]
C.groupShowProgram=[=[
-- The native root itself is becoming shown, not a Mirage visibility gate.
-- Open its input/alpha floor before native OnShow rebuilds the party pool.
if control:GetAttribute("mirage-group") and control:GetAttribute("mirage-live")
 and control:GetFrameRef("mirage-player")==self then
 control:SetAttribute("mirage-group-pending",true)
 control:CallMethod("MirageGroupInvalidated")
end
]=]
local function read(f,key,kind,...)
 if not f or not S:Readable(f) then return nil,"UNKNOWN" end
 local ok,fn=pcall(function() return f[key] end)
 if not ok then return nil,"UNKNOWN" end
 return S:Public(fn,kind,f,...)
end
local function editorState()
 if M.Elements and M.Elements.NativeEditorState then return M.Elements:NativeEditorState() end
 local f=_G.EditModeManagerFrame
 if not S:Readable(f) then return "UNKNOWN" end
 if f==nil then return "CLOSED" end
 local shown,status=read(f,"IsShown","boolean")
 if status~="KNOWN" then return "UNKNOWN" end
 return shown and "OPEN" or "CLOSED"
end
local function nativeEditing() return editorState()~="CLOSED" end
local function delegated(name,frame)
 if name=="BagsBar" or name=="MicroMenuContainer" or name=="MicroMenu" then return true end
 if not S:Readable(frame) then return true end
 if frame==nil then return false end
 for _,key in ipairs({"BagsBar","MicroMenuContainer","MicroMenu"}) do
  local native=_G[key]
  if S:Readable(native) and native~=nil and frame==native then return true end
 end
 return false
end
local function eligible(id,row)
 local p=M.profile;local cfg=p and p.modules[id]
 if not cfg or nativeEditing() or not M.Managed:Enabled() or not M:IsModuleActive(id) or M.Native:Conflict() then return false end
 if row and row.ownedOwner then
  local client=M.Client
  return ownedContracts[row.name]==id and row.ownedOwner.active==true and not M.state.safe
   and client and client.allowed==true and type(reviewedClient)=="function"
   and (client.RuntimeAvailable or client.IsReviewedPresentationClient)==reviewedClient and reviewedClient(client)==true
 end
 if id=="UnitFrames" or id=="DamageMeters" then return cfg.contextualNative==true end
 if id=="ActionBars" then return cfg.contextual and cfg.utilityContext end
 if id=="Cooldowns" then return true end -- visibility is independent of cosmetic styling
 return cfg.style==true
end
local function source(r)
 return C.rows[r.name]==r and M.ContextualNative==C and M.ManagedNative==N and M.Safety==S
end
local function valid(r,profile,serial)
 local function current()
  return source(r) and r.serial==serial and not r.cancelled and not r.pending and not r.ownerHandback and M.profile==profile
   and _G[r.name]==r.frame and M.ContextualNative==C
 end
 if not current() or not eligible(r.module,r) or not current() or S:InCombat() then return false end
 if not S:Frame(r.frame,false) or not current() or not S:Frame(r.gate,false) or not current() then return false end
 return not S:InCombat() and current()
end
-- Acquisition and inverse are separate transactions. A completed handback
-- must not erase why the new native input lease was refused. Keep one bounded
-- receipt per failed admission (never raw errors, native names or unit data).
-- Successful paths allocate no per-operation diagnostic objects.
local function acquireNote(row,phase,property,reason,index)
 if not row.acquiring or row.acquireCurrent then return end
 local receipt={phase=phase or row.acquirePhase or "ACQUIRE",property=property or "CALLBACK",reason=reason,index=index or 0}
 row.acquireCurrent=receipt
end
local function acquireWriteFailure(row,key,detail,reason)
 if row.acquiring and row.acquirePhase~="CONTEXT_STYLE_PREPARE" then
  local property,index=key,0
  if (key=="SetAttribute" or key=="SetFrameRef") and type(detail)=="string" then
   property=detail
   local prefix,suffix=detail:match("^([A-Za-z_%-]+)(%d+)$")
   if prefix then property=prefix;index=tonumber(suffix) or 0 end
  end
  acquireNote(row,nil,property,reason,index)
 end
 return false
end
local function acquireCheck(row,okay,property,reason)
 if not okay then
  acquireNote(row,nil,property,reason or "CONTRACT_UNCONFIRMED")
  error("NATIVE_CONTEXT_ACQUIRE_REFUSED",0)
 end
 return okay
end
local function request(r,profile,serial,f,key,...)
 if not valid(r,profile,serial) then return acquireWriteFailure(r,key,select(1,...),"CURRENTNESS_CHANGED") end
 local ok,fn=pcall(function() return f[key] end)
 if not ok then return acquireWriteFailure(r,key,select(1,...),"METHOD_READ_UNAVAILABLE") end
 if type(fn)~="function" then return acquireWriteFailure(r,key,select(1,...),"METHOD_UNAVAILABLE") end
 if not valid(r,profile,serial) then return acquireWriteFailure(r,key,select(1,...),"CURRENTNESS_CHANGED") end
 local base=M.Rework and M.Rework.NativeMethod and M.Rework.NativeMethod(f,key)
 local done,result=pcall(base or fn,f,...)
 if not done then return acquireWriteFailure(r,key,select(1,...),"CALL_FAILED") end
 if result==false then return acquireWriteFailure(r,key,select(1,...),"WRITE_REFUSED") end
 if not valid(r,profile,serial) then return acquireWriteFailure(r,key,select(1,...),"CURRENTNESS_CHANGED") end
 return true
end
local function expectedParent(row)
 return row.playerPresentation and row.originalParent or row.gate
end
local function playerDescendant(frame,root)
 local node=frame
 for _=1,32 do
  if node==root then return true end
  if not S:Frame(node,false) then return false end
  local parent,state=read(node,"GetParent")
  if state~="KNOWN" then return false end
  node=parent
 end
 return false
end
local function collectPlayerNodes(frame,group,admission,topologyOnly)
 local nodes,seen={},{}
 local function refused(property,reason,index)
  if admission then acquireNote(admission,"INPUT_CENSUS",property,reason,index or #nodes+1) end
  return false
 end
 local function visit(f,depth,parent)
  if depth>16 then return refused("TREE","DEPTH_LIMIT") end
  if #nodes>=(group and 2048 or 512) then return refused("TREE","NODE_LIMIT") end
  if seen[f] then return refused("TREE","REPEATED_NODE") end
  if not S:Frame(f,false) then return refused("FRAME","PUBLIC_FRAME_UNAVAILABLE") end
  if parent then
   local actual,state=read(f,"GetParent")
   if state~="KNOWN" then return refused("PARENT","READ_UNAVAILABLE") end
   if actual~=parent then return refused("PARENT","TREE_CHANGED") end
  end
  local click,motion
  -- Pool observation asks only whether the current topology still matches.
  -- The following presentation audit reads every input property once after
  -- that traversal. Acquiring a new lease still captures both input flags.
  if not topologyOnly then
   local clickState,motionState
   click,clickState=read(f,"IsMouseClickEnabled","boolean")
   motion,motionState=read(f,"IsMouseMotionEnabled","boolean")
   if clickState~="KNOWN" then return refused("CLICK_ENABLED","READ_UNAVAILABLE") end
   if motionState~="KNOWN" then return refused("MOTION_ENABLED","READ_UNAVAILABLE") end
   if click and not motion then return refused("CLICK_MOTION_ENABLED","CLICK_ONLY_UNSUPPORTED") end
  end
  seen[f]=true;nodes[#nodes+1]={frame=f,parent=parent,click=click,motion=motion}
  if type(f.GetChildren)~="function" then return refused("CHILDREN","METHOD_UNAVAILABLE",#nodes) end
  local ok,children=pcall(function() return {f:GetChildren()} end)
  if not ok then return refused("CHILDREN","READ_UNAVAILABLE",#nodes) end
  if #children>(group and 256 or 128) then return refused("CHILDREN","CHILD_LIMIT",#nodes) end
  for _,child in ipairs(children) do if not visit(child,depth+1,f) then return false end end
  return true
 end
 if not visit(frame,0) then return nil end
 return nodes,seen
end
-- Bounded, non-identifying receipts for existing inverse operations. Export
-- reads these cached tags only; it never probes native frames or retries work.
local function handbackNote(row,phase,property,reason,index)
 local receipt={phase=phase,property=property,reason=reason,index=index or 0}
 row.handbackCurrent=row.handbackCurrent or receipt
 row.handbackFirst=row.handbackFirst or receipt
 row.handbackLast=receipt
end
local function handbackResult(row,complete)
 row.handbackResult=complete and "COMPLETE" or "PENDING"
 if complete then row.handbackCurrent=nil
 elseif not row.handbackCurrent then handbackNote(row,"CURRENTNESS","ROW","OWNER_OR_LEGAL_STATE_CHANGED") end
 return complete
end
local function handbackConflict(row,phase,property,index)
 row.contested=true
 if row.recoveryBaseline then row.recoveryBaseline.conflict=true end
 row.handbackConflict=row.handbackConflict or {phase=phase,property=property,reason="NEWER_VALUE_PRESERVED",index=index or 0}
end
-- Capture public presentation facts at the first failed transaction. The
-- initial writer stays unknown unless a setter receipt actually observed it.
-- These cached, bounded facts are exported without probing the native frame.
function C:PresentationFailure(row,reason,alpha,last)
 local lease=row.playerLease
 local effects=M.Effects and M.Effects.protectedState and M.Effects.protectedState[row.frame]
 local active=effects and effects.owner==row and effects.active
 local receipt={reason=reason,generation=row.serial or 0,
  observed=S:Number(alpha) and alpha or nil,expected=S:Number(last) and last or nil,
  effective=select(1,read(row.frame,"GetEffectiveAlpha","number")),
  writer=lease and lease.alphaForeign and "OBSERVED_SETTER" or "UNIDENTIFIED",
  animation=active and "OWNED_ACTIVE" or "NO_ACTIVE_RECEIPT"}
 if not S:Number(receipt.effective) then receipt.effective=nil end
 row.presentationFirst=row.presentationFirst or receipt;row.presentationLast=receipt
end
local function rememberRecovery(row)
 local lease=row.playerLease
 if not lease or row.recoveryBaseline then return end
 row.recoveryBaseline={frame=row.frame,parent=row.originalParent,alpha=lease.alpha,nodes=lease.nodes,
  owner=row.ownedOwner,profile=M.profile,conflict=lease.alphaForeign==true}
 row.lastOwnedOwner=row.ownedOwner or row.lastOwnedOwner
end
function C:RevalidateRecovery(row,owner)
 local baseline=row.recoveryBaseline
 if not baseline then return not row.contested end
 if row.busy or row.pending or row.playerLease or row.handbackResult~="COMPLETE" or S:InCombat()
  or row.frame~=baseline.frame or _G[row.name]~=baseline.frame or baseline.owner~=owner then return false end
 if (row.contested or baseline.conflict) and not row.recoveryRequested then return false end
 if row.alphaUnverified and not row.recoveryRequested and (row.autoRecoveryAttempts or 0)>=1 then
  row.recoveryStatus="EXPLICIT_RECOVERY_REVIEW_REQUIRED";return false
 end
 local serial,profile=row.serial,M.profile
 local rowOwner,lastOwner=row.ownedOwner,row.lastOwnedOwner
 local ownerGeneration,ownerActive=owner and owner.generation,owner and owner.active
 local function current()
  return self.rows[row.name]==row and row.recoveryBaseline==baseline and row.serial==serial and M.profile==profile
   and row.frame==baseline.frame and _G[row.name]==baseline.frame and not row.playerLease and not row.busy and not row.pending
   and baseline.owner==owner and row.ownedOwner==rowOwner and row.lastOwnedOwner==lastOwner
   and (not owner or owner.generation==ownerGeneration and owner.active==ownerActive)
   and not S:InCombat()
 end
 if read(row.frame,"GetParent")~=baseline.parent or not current() then return false end
 local alpha,state=read(row.frame,"GetAlpha","number")
 -- Recovery does not overwrite a retained foreign value. Reacquire only
 -- after the original public baseline/input have actually returned.
 if state~="KNOWN" or not S:Number(baseline.alpha) or math.abs(alpha-baseline.alpha)>.00001 or not current() then
  row.recoveryStatus="BASELINE_ALPHA_NOT_RETURNED";return false
 end
 local skipped=0
 for index,node in ipairs(baseline.nodes or {}) do
  -- Only admitted click controls were changed by this lease. Passive and
  -- motion-only children stayed native throughout: pools may retire them,
  -- their tooltip motion may change, or they may become new click controls.
  -- Requiring those unowned flags to match a historic census strands a fully
  -- completed inverse. A fresh acquisition still checks the whole current
  -- tree, so new click-only, unreadable or unsafe controls cannot be admitted.
  if node.click then
   local property
   if not playerDescendant(node.frame,row.frame) then property="PARENT"
   elseif not current() then return false
   elseif read(node.frame,"IsMouseClickEnabled","boolean")~=node.click then property="CLICK_ENABLED"
   elseif not current() then return false
   elseif read(node.frame,"IsMouseMotionEnabled","boolean")~=node.motion then property="MOTION_ENABLED" end
   if not current() then return false end
   if property then
    row.recoveryStatus="BASELINE_INPUT_NOT_RETURNED"
    row.recoveryInput={phase="INPUT",property=property,reason="BASELINE_NOT_RETURNED",index=index}
    return false
   end
  else skipped=skipped+1 end
 end
 if not current() then return false end
 if row.alphaUnverified and not row.recoveryRequested then row.autoRecoveryAttempts=(row.autoRecoveryAttempts or 0)+1 end
 row.recoveryStatus="BASELINE_REVALIDATED";row.recoveryGeneration=(row.recoveryGeneration or 0)+1
 row.recoveryInput=nil;row.recoveryUnownedNodes=skipped
 row.recoveryBaseline=nil;row.recoveryRequested=nil;row.contested=nil;row.contextTerminal=nil;row.ownerHandback=nil
 row.failures=0;row.acquireFailures=0;row.playerHandbackAttempts=0
 return true
end
-- The reviewed CompactUnitFrame template has exactly these three branches
-- that bypass ancestor alpha. Lease only their inheritance flags; native
-- selection/ready-check Show/Hide, updates and input remain authoritative.
-- During this lease the markers follow the member's range/group opacity.
-- Public SimpleRegion APIs are used OOC; these setters are not HANDLE APIs.
local function groupMarkerCurrent(marker)
 local field,known=S:FieldAccess(marker.owner,marker.key)
 if known=="ABSENT" then return false end
 if known~="KNOWN" then return nil end
 if field~=marker.frame then return false end
 if not S:Frame(field,false) then return nil end
 local parent,state=read(field,"GetParent")
 if state~="KNOWN" then return nil end
 return parent==marker.owner
end
function C:PrepareGroupMarkers(row,profile,serial)
 if not row.groupPresentation then return true end
 local markers={};row.playerLease.groupMarkers=markers
 local function refused(property,reason,index)
  acquireNote(row,"GROUP_MARKERS",property,reason,index or #markers+1);return false
 end
 local function add(owner,key)
  local frame,known=S:FieldAccess(owner,key)
  if known=="ABSENT" then return true end
  if known~="KNOWN" then return refused(key,"FIELD_UNAVAILABLE") end
  if not S:Frame(frame,false) then return refused(key,"PUBLIC_FRAME_UNAVAILABLE") end
  local parent,parentState=read(frame,"GetParent")
  if parentState~="KNOWN" then return refused(key,"PARENT_READ_UNAVAILABLE") end
  if parent~=owner then return refused(key,"PARENT_CHANGED") end
  if type(frame.SetIgnoreParentAlpha)~="function" then return refused(key,"METHOD_UNAVAILABLE") end
  local original,status=read(frame,"IsIgnoringParentAlpha","boolean")
  if status~="KNOWN" then return refused(key,"INHERITANCE_READ_UNAVAILABLE") end
  markers[#markers+1]={owner=owner,key=key,frame=frame,original=original}
  return true,frame
 end
 for _,node in ipairs(row.playerLease.nodes) do
  if not add(node.frame,"selectionHighlight") then return false end
  local okay,ready=add(node.frame,"readyCheckIcon")
  if not okay or ready and not add(ready,"Icon") then return false end
 end
 for index,marker in ipairs(markers) do
  if not groupMarkerCurrent(marker) or not valid(row,profile,serial) then return refused(marker.key,"CURRENTNESS_CHANGED",index) end
  if marker.original then
   marker.attempted=true
   if not request(row,profile,serial,marker.frame,"SetIgnoreParentAlpha",false) then return false end
  end
  if not groupMarkerCurrent(marker) or read(marker.frame,"IsIgnoringParentAlpha","boolean")~=false
   or not valid(row,profile,serial) then return refused(marker.key,"READBACK_UNCONFIRMED",index) end
 end
 return true
end
function C:GroupMarkersCurrent(row)
 for _,marker in ipairs(row.playerLease and row.playerLease.groupMarkers or {}) do
  local field,known=S:FieldAccess(marker.owner,marker.key)
  if known~="KNOWN" or field~=marker.frame or not S:Frame(field,false) then return false end
  -- This is one fresh observation, not a retained readiness receipt. Combine
  -- the two pure getters after checking the exact marker identity once.
  local okay,parent,ignoring=pcall(function() return field:GetParent(),field:IsIgnoringParentAlpha() end)
  if not okay or not S:Readable(parent) or not S:Readable(ignoring)
   or parent~=marker.owner or ignoring~=false then return false end
 end
 return true
end
function C:RestoreGroupMarkers(row,current)
 local complete=true
 for index,marker in ipairs(row.playerLease and row.playerLease.groupMarkers or {}) do if not marker.restored then
  if not current() then return false end
  local custody=groupMarkerCurrent(marker)
  if custody==nil then handbackNote(row,"MARKER","IDENTITY_PARENT","UNAVAILABLE",index);complete=false
  elseif not custody then handbackConflict(row,"MARKER","IDENTITY_PARENT",index);marker.restored=true
  else
   local value,known=read(marker.frame,"IsIgnoringParentAlpha","boolean")
   if not current() then return false end
   if known~="KNOWN" then handbackNote(row,"MARKER","IGNORE_PARENT_ALPHA","READ_UNAVAILABLE",index);complete=false
   elseif value==marker.original then marker.restored=true
   elseif not marker.attempted or value~=false then handbackConflict(row,"MARKER","IGNORE_PARENT_ALPHA",index);marker.restored=true
   else
    -- Readback, field identity and ancestry seal each individual restoration.
    local okay,result=pcall(marker.frame.SetIgnoreParentAlpha,marker.frame,marker.original)
    if not current() then return false end
    if okay and result~=false and groupMarkerCurrent(marker)
     and read(marker.frame,"IsIgnoringParentAlpha","boolean")==marker.original then marker.restored=true
    else handbackNote(row,"MARKER","IGNORE_PARENT_ALPHA","RESTORE_UNCONFIRMED",index);complete=false end
   end
  end
 end end
 return complete and current()
end
function C:ObservePlayerAlpha(row)
 -- SetAlpha is observed, never replaced. Engine Alpha animation playback does
 -- not supply a Lua setter receipt; genuine native/addon setters do. The
 -- secure controller declares its attempted scalar before calling SetAlpha,
 -- so combat writes do not depend on an ordinary Lua mutation guard.
 if type(hooksecurefunc)~="function" then return false end
 self.playerAlphaHooks=self.playerAlphaHooks or setmetatable({},{__mode="k"})
 local frame,name=row.frame,row.name
 if self.playerAlphaHooks[frame] then return true end
 local okay=pcall(hooksecurefunc,frame,"SetAlpha",function(f,value)
  local r=C.rows[name];local lease=r and r.playerLease
  if not lease or r.frame~=f or f~=frame or _G[name]~=frame then return end
  local serial,profile,gate=r.serial,M.profile,r.gate
  lease.alphaObservationRevision=(lease.alphaObservationRevision or 0)+1
  local observation=lease.alphaObservationRevision
  local function current() return C.rows[name]==r and r.frame==frame and _G[name]==frame and r.playerLease==lease
   and r.serial==serial and r.gate==gate and M.profile==profile and lease.alphaObservationRevision==observation end
  local write=lease.alphaWrite
  local inverse=write and write.profile==M.profile and write.serial==serial and S:Number(value) and value==write.value
  local pending,pendingState=read(gate,"GetAttribute","number","mirage-player-alpha-pending")
  local applying=read(gate,"GetAttribute","boolean","mirage-player-applying")
  local generation=read(gate,"GetAttribute","number","mirage-player-generation")
  local last,lastState=read(gate,"GetAttribute","number","mirage-player-alpha-last")
  local committed=read(gate,"GetAttribute","boolean","mirage-player-committed")
  if not current() then return end
  local secure=lease.profile==M.profile and lease.serial==serial and applying==true and generation==serial
   and pendingState=="KNOWN" and S:Number(value) and value==pending
  if not current() then return end
  -- RestrictedFrames calls its copied base SetAlpha, bypassing this public
  -- per-instance post-hook. Its committed endpoint is the authoritative own
  -- scalar even when no public hook ran for that secure write.
  if not inverse and generation==serial and committed==true and applying==false and lastState=="KNOWN" then lease.alphaLast=last end
  if inverse or secure then lease.alphaLast=value
  elseif lease.alphaForeign or not S:Number(value) or not S:Number(lease.alphaLast) or math.abs(value-lease.alphaLast)>.00001 then
   lease.alphaForeign=true;lease.alphaForeignValue=S:Number(value) and value or nil
   lease.alphaForeignRevision=(lease.alphaForeignRevision or 0)+1
   lease.alphaRestored=nil
  end
 end)
 if okay then self.playerAlphaHooks[frame]=true end
 return okay
end
function C:PreparePlayerPresentation(row,profile,serial)
 local alpha,state=read(row.frame,"GetAlpha","number")
 if state~="KNOWN" then acquireNote(row,"INPUT_CENSUS","ROOT_ALPHA","READ_UNAVAILABLE")
 elseif alpha<0 or alpha>1 then acquireNote(row,"INPUT_CENSUS","ROOT_ALPHA","OUT_OF_RANGE") end
 local nodes,seen=collectPlayerNodes(row.frame,row.groupPresentation,row)
 if state~="KNOWN" or alpha<0 or alpha>1 or not nodes then
  self.status[row.name]="PLAYER_INPUT_CONTRACT_UNAVAILABLE";return false
 end
 local gate=row.gate
 row.playerLease={alpha=alpha,alphaLast=alpha,profile=profile,serial=serial,nodes=nodes,seen=seen};row.playerNextReview=0;row.playerHandbackAttempts=0
 row.playerLease.alphaObserved=self:ObservePlayerAlpha(row)
 row.handbackAttempts=0;row.handbackResult=nil;row.handbackCurrent=nil;row.handbackFirst=nil;row.handbackLast=nil;row.handbackConflict=nil
 row.acquirePhase="GROUP_MARKERS"
 if not self:PrepareGroupMarkers(row,profile,serial) then return false end
 row.acquirePhase="INPUT_LEASE"
 local function set(key,value) return request(row,profile,serial,gate,"SetAttribute",key,value) end
 if not request(row,profile,serial,gate,"SetFrameRef","mirage-player",row.frame)
  or not request(row,profile,serial,gate,"SetFrameRef","mirage-player-parent",row.originalParent)
  or not set("mirage-player-alpha",alpha) or not set("mirage-player-alpha-last",alpha)
  or not set("mirage-player-alpha-pending",nil)
  or not set("mirage-player-generation",serial)
  or not set("mirage-player-count",#nodes) or not set("mirage-player-conflict",false)
  or not set("mirage-player-applying",false) or not set("mirage-player-committed",true)
  or not set("mirage-player-presented",true) then return false end
 for i,node in ipairs(nodes) do
  if not request(row,profile,serial,gate,"SetFrameRef","mirage-player-node"..i,node.frame)
   or not set("mirage-player-input"..i,node.click)
   or not set("mirage-player-last"..i,node.click) or not set("mirage-player-pending"..i,nil) then return false end
 end
 local ready=set("mirage-player-apply",self.playerProgram) and set("mirage-player-ready",true)
  and set("_onattributechanged",self.playerAttributeProgram)
 if ready then row.playerLease.armed=true end
 return ready
end
-- These checks run only inside observeInputNode's single protected call.
-- Keep the same public-value contract as Safety:Readable, but do not nest two
-- more pcalls for every scalar of every native input node on each observation.
-- Nothing is cached: each node, forbidden flag, parent and input receipt is
-- freshly read and validated before the caller may use it.
local function inputValueReadable(value)
 local secret=issecretvalue(value)
 if type(secret)~="boolean" or secret~=false then return false end
 local allowed=canaccessvalue(value)
 return type(allowed)=="boolean" and allowed==true
end
local function observeInputNode(frame,root,gate,index,ownedClick)
 if type(issecretvalue)~="function" or type(canaccessvalue)~="function" then return false end
 if not inputValueReadable(frame) or not frame
  or (type(frame)~="table" and type(frame)~="userdata") then return false end
 if frame.IsForbidden then
  local forbidden=frame:IsForbidden()
  if not inputValueReadable(forbidden) or forbidden then return false end
 end
 local parent=root
 if frame~=root then parent=frame:GetParent() end
 local click,motion=frame:IsMouseClickEnabled(),frame:IsMouseMotionEnabled()
 local expected=false
 if ownedClick then expected=gate:GetAttribute("mirage-player-last"..index) end
 if not inputValueReadable(parent) or not inputValueReadable(click) or not inputValueReadable(motion)
  or type(click)~="boolean" or type(motion)~="boolean" or parent==nil then return false end
 if ownedClick and (not inputValueReadable(expected) or type(expected)~="boolean") then return false end
 return true,parent,click,motion,expected
end
local function currentInputNode(frame,root,gate,index,ownedClick)
 local okay,observed,parent,click,motion,expected=pcall(observeInputNode,frame,root,gate,index,ownedClick)
 if not okay then return false end
 return observed,parent,click,motion,expected
end
function C:PlayerPresentationCurrent(row,reviewTree,checkRootOnly)
 if not row.playerPresentation then return true end
 local lease=row.playerLease
 if row.contextTerminal or not lease then return false end
 if not checkRootOnly then self.presentationAudits=math.min(999999,(self.presentationAudits or 0)+1) end
 local frame,gate,serial,profile,revision=row.frame,row.gate,row.serial,M.profile,row.inputTreeRevision
 if not lease or read(row.frame,"GetParent")~=row.originalParent
  or read(row.gate,"GetAttribute","boolean","mirage-player-ready")~=true
  or read(row.gate,"GetAttribute","boolean","mirage-player-conflict")~=false
  or read(row.gate,"GetAttribute","boolean","mirage-player-applying")~=false
  or read(row.gate,"GetAttribute","boolean","mirage-player-committed")~=true then return false end
 if not checkRootOnly and not self:GroupMarkersCurrent(row) then return false end
 local alpha,alphaState=read(row.frame,"GetAlpha","number")
 local last,lastState=read(row.gate,"GetAttribute","number","mirage-player-alpha-last")
 if alphaState~="KNOWN" or lastState~="KNOWN" or lease.alphaForeign then
  self:PresentationFailure(row,lease.alphaForeign and "OBSERVED_ALPHA_SETTER" or "ALPHA_READ_UNAVAILABLE",alpha,last);return false
 end
 if math.abs(alpha-last)>.00001 then
  local effects=M.Effects
  local owned,why
  if effects and effects.PresentationAlphaCurrent then owned,why=effects:PresentationAlphaCurrent(row,row.frame,alpha,last) end
  row.alphaObservation=why or "SECURE_ENDPOINT_MISMATCH"
  if not owned or row.playerLease~=lease or lease.alphaForeign then
   self:PresentationFailure(row,row.alphaObservation,alpha,last);return false
  end
 else row.alphaObservation="SECURE_ENDPOINT" end
 if checkRootOnly then
  return source(row) and row.playerLease==lease and not lease.alphaForeign and row.serial==serial
   and row.frame==frame and row.gate==gate and M.profile==profile and _G[row.name]==frame and row.inputTreeRevision==revision
 end
 if reviewTree then
  self.topologyAudits=math.min(999999,(self.topologyAudits or 0)+1)
  local nodes=collectPlayerNodes(row.frame,row.groupPresentation,nil,true)
  if not nodes or #nodes~=#lease.nodes then return false end
  for _,node in ipairs(nodes) do if not lease.seen[node.frame] then return false end end
 end
 for i,node in ipairs(lease.nodes) do
  self.inputNodesAudited=math.min(9999999,(self.inputNodesAudited or 0)+1)
  -- Every captured parent is itself in this census. Checking each current
  -- edge once proves the retained ancestry without re-walking the same root
  -- path for every sibling. A native move inside the same root remains legal
  -- until the next census; a changed edge still takes the full public check.
  local observed,parent,click,motion,expected=currentInputNode(node.frame,row.frame,row.gate,i,node.click)
  if not observed then return false end
  if node.frame~=row.frame and parent~=node.parent and not playerDescendant(node.frame,row.frame) then return false end
  if node.click then
   if click~=expected or motion~=expected then return false end
  elseif click then return false end
 end
 -- Input/topology getters may synchronously expose a newer native writer.
 -- An earlier alpha observation cannot survive a changed lease or setter.
 return source(row) and row.playerLease==lease and not lease.alphaForeign and row.frame==frame and row.gate==gate
  and row.serial==serial and M.profile==profile and _G[row.name]==frame and row.inputTreeRevision==revision
end
function C:RestorePlayerPresentation(row,current)
 local gate,lease=row.gate,row.playerLease
 rememberRecovery(row)
 local effects=M.Effects
 local animation=effects and effects.protectedState and effects.protectedState[row.frame]
 local stoppedTarget=animation and animation.owner==row and animation.presentationOnly and animation.active and animation.active.to
 local residue
 local inverseProfile,inverseFrame,inverseSerial=M.profile,row.frame,row.serial
 local function residueCurrent()
  return current() and row.playerLease==lease and row.frame==inverseFrame and row.gate==gate
   and row.serial==inverseSerial and M.profile==inverseProfile and M.Effects==effects and lease and not lease.alphaForeign
 end
 if residueCurrent() and effects and effects.RetiringPresentationAlpha then
  local target,known=read(gate,"GetAttribute","number","mirage-player-alpha-last")
  if known=="KNOWN" and residueCurrent() then
   local observed=effects:RetiringPresentationAlpha(row,inverseFrame,lease,target,residueCurrent)
   if S:Number(observed) and residueCurrent() then residue=observed end
  end
 end
 if current() and M.Effects and M.Effects.CancelProtected then M.Effects:CancelProtected(row,row.frame,false) end
 row.handbackAttempts=math.min(9999,(row.handbackAttempts or 0)+1)
 row.handbackCurrent=nil;row.handbackResult="CHECKING"
 local phase,index="RETIRE",0
 local function write(frame,key,...)
  local property=key=="SetAttribute" and select(1,...) or key
  if not current() or not S:Frame(frame,false) or type(frame[key])~="function" then
   handbackNote(row,phase,property,"WRITE_UNAVAILABLE",index);return false
  end
  local alphaWrite
  if lease and frame==row.frame and key=="SetAlpha" then
   alphaWrite={value=select(1,...),profile=M.profile,serial=row.serial};lease.alphaWrite=alphaWrite
  end
  local ok,result=pcall(frame[key],frame,...)
  if alphaWrite and lease.alphaWrite==alphaWrite then lease.alphaWrite=nil end
  local complete=ok and result~=false and current()
  if not complete then handbackNote(row,phase,property,"WRITE_UNCONFIRMED",index) end
  return complete
 end
 local function cleared(key)
  if not current() or not gate or type(gate.GetAttribute)~="function" then
   handbackNote(row,"RETIRE",key,"READ_UNAVAILABLE");return false
  end
  local ok,value=pcall(gate.GetAttribute,gate,key)
  local complete=ok and S:Readable(value) and value==nil and current()
  if not complete then handbackNote(row,"RETIRE",key,"READBACK_UNCONFIRMED") end
  return complete
 end
 -- Retire every future writer before inspecting property receipts. Attribute
 -- changes during recovery must not repaint over a newer native/third-party
 -- alpha or input setting. Keep debt when any retirement readback is uncertain.
 local retired=true
 if gate then
  local attributes=write(gate,"SetAttribute","_onattributechanged",nil) and cleared("_onattributechanged")
  local program=write(gate,"SetAttribute","mirage-player-apply",nil) and cleared("mirage-player-apply")
  retired=attributes and program
  if not current() then return handbackResult(row,false) end
  if type(UnregisterStateDriver)=="function" then
   local ok,result=pcall(UnregisterStateDriver,gate,"miragecontext")
   retired=ok and result~=false and current() and retired
   if not ok or result==false then handbackNote(row,"RETIRE","STATE_DRIVER","WRITE_UNCONFIRMED") end
  else handbackNote(row,"RETIRE","STATE_DRIVER","API_UNAVAILABLE");retired=false end
  -- A failed retirement does not prevent independent native input handback.
  -- Future writer debt remains explicit until every retired callback is read.
  if attributes then
   retired=write(gate,"SetAttribute","mirage-live",false) and retired
   retired=write(gate,"SetAttribute","mirage-emergency",true) and retired
   retired=write(gate,"SetAttribute","mirage-player-ready",false) and retired
  end
  retired=write(gate,"Show") and retired
 end
 if not current() then return handbackResult(row,false) end
 if not lease then return handbackResult(row,retired) end
 if not lease.armed then
  local complete=self:RestoreGroupMarkers(row,current)
  if retired and complete then row.playerLease=nil end
  return handbackResult(row,retired and complete)
 end
 local parent,state=read(row.frame,"GetParent")
 if state~="KNOWN" or not current() then
  handbackNote(row,"ROOT","PARENT","READ_UNAVAILABLE");return handbackResult(row,false)
 end
 if parent~=row.originalParent then
  handbackConflict(row,"ROOT","PARENT");if retired then row.playerLease=nil end;return handbackResult(row,retired and current())
 end
 local complete=true
 for i,node in ipairs(lease.nodes) do if node.click and not node.restored then
  phase,index="INPUT",i
  if not playerDescendant(node.frame,row.frame) then handbackConflict(row,"INPUT","PARENT",i);node.restored=true
  else
   local click,clickState=read(node.frame,"IsMouseClickEnabled","boolean")
   local motion,motionState=read(node.frame,"IsMouseMotionEnabled","boolean")
   local last,lastState=read(gate,"GetAttribute","boolean","mirage-player-last"..i)
   local attempted,attemptState=read(gate,"GetAttribute","boolean","mirage-player-pending"..i)
   if clickState~="KNOWN" or motionState~="KNOWN" or lastState~="KNOWN" then
    handbackNote(row,"INPUT",clickState~="KNOWN" and "CLICK_ENABLED" or motionState~="KNOWN" and "MOTION_ENABLED" or "LAST_RECEIPT","READ_UNAVAILABLE",i);complete=false
   elseif (click~=last or motion~=last) and (attemptState~="KNOWN" or click~=attempted or motion~=attempted) then handbackConflict(row,"INPUT","CLICK_MOTION_ENABLED",i);node.restored=true
   else
    if click~=node.click or motion~=node.motion then
     if not write(node.frame,"EnableMouse",node.click) then complete=false end
    end
    if read(node.frame,"IsMouseClickEnabled","boolean")==node.click and read(node.frame,"IsMouseMotionEnabled","boolean")==node.motion then
     node.restored=true
    else handbackNote(row,"INPUT","CLICK_MOTION_ENABLED","RESTORE_UNCONFIRMED",i);complete=false end
   end
  end
 end end
 if not lease.alphaRestored then
  phase,index="ALPHA",0
  local alpha,alphaState=read(row.frame,"GetAlpha","number")
  local last,lastState=read(gate,"GetAttribute","number","mirage-player-alpha-last")
  local attempted,attemptState=read(gate,"GetAttribute","number","mirage-player-alpha-pending")
  if not current() or row.playerLease~=lease then return handbackResult(row,false) end
  if alphaState~="KNOWN" or lastState~="KNOWN" then
   handbackNote(row,"ALPHA",alphaState~="KNOWN" and "ROOT_ALPHA" or "LAST_RECEIPT","READ_UNAVAILABLE");complete=false
  elseif lease.alphaForeign then
   -- Stopping our animation can restore its captured endpoint over a foreign
   -- setter that was visually masked by playback. Return only that exact
   -- observed scalar, only when Stop left our known endpoint in its place.
   local foreign=lease.alphaForeignValue;local revision=lease.alphaForeignRevision
   local ownValue=(S:Number(stoppedTarget) and math.abs(alpha-stoppedTarget)<=.00001
    or lastState=="KNOWN" and math.abs(alpha-last)<=.00001 or attemptState=="KNOWN" and math.abs(alpha-attempted)<=.00001)
   if not S:Number(foreign) then
    handbackNote(row,"ALPHA","FOREIGN_ALPHA","READ_UNAVAILABLE");complete=false
   else
    if ownValue and math.abs(alpha-foreign)>.00001 then
     if not write(row.frame,"SetAlpha",foreign) or not current() or row.playerLease~=lease
      or lease.alphaForeignRevision~=revision then return handbackResult(row,false) end
     local actual,known=read(row.frame,"GetAlpha","number")
     if not current() or row.playerLease~=lease or lease.alphaForeignRevision~=revision then return handbackResult(row,false) end
     if known~="KNOWN" or math.abs(actual-foreign)>.00001 then
      handbackNote(row,"ALPHA","ROOT_ALPHA",known~="KNOWN" and "READ_UNAVAILABLE" or "RESTORE_UNCONFIRMED");complete=false
     else handbackConflict(row,"ALPHA","ROOT_ALPHA");lease.alphaRestored=true end
    else handbackConflict(row,"ALPHA","ROOT_ALPHA");lease.alphaRestored=true end
   end
  elseif math.abs(alpha-last)>.00001 and (attemptState~="KNOWN" or math.abs(alpha-attempted)>.00001)
   and (not S:Number(residue) or math.abs(alpha-residue)>.00001 or not residueCurrent()
    or effects.protectedState[inverseFrame]~=nil) then
   -- An unavailable animation receipt is not evidence of a newer owner.
   -- Preserve this unverified value, return input, and require a fresh
   -- baseline admission. A positively observed foreign setter takes the
   -- separate conflict branch above and is never cleared automatically.
   if S:Number(residue) and S:Number(lease.alpha) and math.abs(alpha-lease.alpha)>.00001 then
    -- Unlike an absent receipt, an exact owned pre-Stop observation followed
    -- by a different non-baseline scalar is a concrete mutation boundary.
    -- Preserve it and require explicit recovery after the baseline returns.
    handbackConflict(row,"ALPHA","ROOT_ALPHA")
    row.recoveryStatus="POST_STOP_VALUE_CHANGED"
   else
    row.alphaUnverified=true;row.recoveryStatus="ALPHA_OBSERVATION_UNVERIFIED"
    handbackNote(row,"ALPHA","ROOT_ALPHA","UNVERIFIED_VALUE_PRESERVED")
   end
   lease.alphaRestored=true
  else
   if alpha~=lease.alpha and not write(row.frame,"SetAlpha",lease.alpha) then complete=false end
   local actual,known=read(row.frame,"GetAlpha","number")
   if not current() or row.playerLease~=lease or lease.alphaForeign then return handbackResult(row,false) end
   if known=="KNOWN" and math.abs(actual-lease.alpha)<=.00001 then lease.alphaRestored=true
   else handbackNote(row,"ALPHA","ROOT_ALPHA","RESTORE_UNCONFIRMED");complete=false end
  end
 end
 -- Finish independent input/alpha handback even when a marker flag refuses
 -- restoration. A retained marker receipt must never keep a group invisible.
 local alphaRevision=lease.alphaForeignRevision
 complete=self:RestoreGroupMarkers(row,current) and complete
 if row.playerLease~=lease or not current() then return handbackResult(row,false) end
 if lease.alphaForeignRevision~=alphaRevision then lease.alphaRestored=nil;complete=false end
 if not lease.alphaRestored then complete=false end
 if complete and current() then
  if retired then row.playerLease=nil
  elseif gate and not row.contested then
   -- If a driver could not be retired, hold its existing secure emergency
   -- route open. A missing callback/program cannot conceal the native root.
   write(gate,"SetAttribute","mirage-emergency",true)
  end
 end
 return handbackResult(row,complete and retired and current())
end
local function managedPoints(frame)
 local count,state=read(frame,"GetNumPoints","number")
 if state~="KNOWN" or count<0 or count>8 or count%1~=0 then return nil end
 local points={}
 for i=1,count do
  local ok,point,relative,relativePoint,x,y=pcall(frame.GetPoint,frame,i)
  if not ok or not S:Text(point) or not S:Readable(relative) or not S:Text(relativePoint) or not S:Number(x) or not S:Number(y) then return nil end
  points[i]={point,relative,relativePoint,x,y}
 end
 return points
end
local function sameManagedPoints(frame,points)
 local current=managedPoints(frame)
 if not current or #current~=#points then return false end
 local leases=M.Rework and M.Rework.CombatLeases
 local geometryEqual=leases and type(leases.GeometryEqual)=="function" and leases.GeometryEqual
 for i,row in ipairs(points) do for j=1,5 do
  if row[j]~=current[i][j] and (j<4 or not geometryEqual or not geometryEqual(leases,row[j],current[i][j])) then return false end
 end end
 return true
end
function C:DetachManagedCooldown(row,profile,serial)
 if not bottomManagedCooldowns[row.name] then return true end
 local frame=row.frame
 local manager,state=S:FieldAccess(frame,"layoutParent")
 if state=="ABSENT" then row.managerState="UNMANAGED";return true end
 if state~="KNOWN" or manager~=_G.BottomManagedFrameContainer or not S:Frame(manager,false)
  or type(manager.RemoveManagedFrame)~="function" or type(manager.AddManagedFrame)~="function" then return false end
 local members,known=S:FieldAccess(manager,"showingFrames")
 local flag,flagState=S:FieldAccess(frame,"ignoreFramePositionManager")
 if known~="KNOWN" or type(members)~="table" or (flagState~="ABSENT" and (flagState~="KNOWN" or type(flag)~="boolean")) then return false end
 local member,memberState=S:FieldAccess(members,frame)
 if memberState~="ABSENT" and (memberState~="KNOWN" or member~=frame) then return false end
 if flag==true then
  row.managerState="NATIVE_OPT_OUT_RETAINED"
  return memberState=="ABSENT" and valid(row,profile,serial)
 end
 local points=managedPoints(frame);local shown,shownState=read(frame,"IsShown","boolean")
 if not points or shownState~="KNOWN" or not valid(row,profile,serial) then return false end
 -- These three viewers inherit BottomManagedFrameTemplate. Its native
 -- UpdateManagedFrames reparents every retained member, even when hidden.
 -- Use the reviewed per-frame opt-out AND remove the retained registration
 -- before acquiring our parent. Never replace a native layout callback.
 row.managerLease={manager=manager,members=members,original=flag,registered=member==frame,shown=shown,points=points}
 row.attempted=true
 frame.ignoreFramePositionManager=true
 if not valid(row,profile,serial) then return false end
 manager:RemoveManagedFrame(frame)
 local current,access=S:FieldAccess(members,frame)
 local applied,appliedState=S:FieldAccess(frame,"ignoreFramePositionManager")
 local exact=S:FieldAccess(frame,"layoutParent")
 local ready=access=="ABSENT" and current==nil and appliedState=="KNOWN" and applied==true and exact==manager
  and _G.BottomManagedFrameContainer==manager and valid(row,profile,serial)
 row.managerState=ready and "DETACHED" or "DETACH_PENDING"
 return ready
end
function C:RestoreManagedCooldown(row,current)
 local lease=row.managerLease;if not lease then return true end
 local frame,manager=row.frame,lease.manager
 if not current() or not S:Frame(frame,false) or not S:Frame(manager,false) then return false end
 local function sealed()
  return current() and S:FieldAccess(frame,"layoutParent")==manager and _G.BottomManagedFrameContainer==manager
   and _G[row.name]==frame and S:FieldAccess(manager,"showingFrames")==lease.members and current()
 end
 local function membership()
  local member,state=S:FieldAccess(lease.members,frame)
  if not sealed() or state~="ABSENT" and (state~="KNOWN" or member~=frame) then return nil end
  return member==frame
 end
 local function nativeEligible()
  local shown,shownState=read(frame,"IsShown","boolean")
  local method,methodState=S:FieldAccess(frame,"IsInDefaultPosition")
  if not sealed() or shownState~="KNOWN" then return nil end
  if not shown then return false end
  if methodState=="ABSENT" then return true end
  if methodState~="KNOWN" or type(method)~="function" then return nil end
  local position,positionState=read(frame,"IsInDefaultPosition","boolean")
  if not sealed() or positionState~="KNOWN" then return nil end
  return position
 end
 local function nativeParent()
  local bottom,bottomState=S:FieldAccess(frame,"layoutOnBottom")
  if bottomState~="ABSENT" and (bottomState~="KNOWN" or type(bottom)~="boolean") then return nil end
  local wanted=manager
  if bottom then wanted=S:FieldAccess(manager,"BottomManagedLayoutContainer") end
  local parent,parentState=read(frame,"GetParent")
  return sealed() and S:Frame(wanted,false) and parentState=="KNOWN" and parent==wanted
 end
 local function originalLayout()
  local parent,state=read(frame,"GetParent")
  return not row.contested and state=="KNOWN" and parent==row.originalParent and sameManagedPoints(frame,lease.points)
   and read(frame,"GetParent")==row.originalParent and sealed()
 end
 local function finish(status)
  if not sealed() then return false end
  row.managerLease=nil;row.managerState=status;return true
 end
 local flag,state=S:FieldAccess(frame,"ignoreFramePositionManager")
 if not sealed() then
  row.managerState="NATIVE_MANAGER_CHANGED";return false
 end
 if state~="ABSENT" and (state~="KNOWN" or type(flag)~="boolean") then return false end
 -- The inverse flag write and manager registration are separate commits.
 -- After a rejected/reentrant AddManagedFrame, our already-restored nil/false
 -- is not evidence of a newer writer and must not discard pending registration.
 if lease.flagRestored and flag~=lease.original or not lease.flagRestoreAttempted and flag~=true then
  return finish("NEWER_FLAG_PRESERVED")
 end
 if flag~=true and flag~=lease.original then return finish("NEWER_FLAG_PRESERVED") end
 local register=originalLayout() and (lease.registered or lease.shown==false)
 if not sealed() then return false end
 if flag==true then
  lease.flagRestoreAttempted=true
  frame.ignoreFramePositionManager=lease.original
 end
 local observed,observedState=S:FieldAccess(frame,"ignoreFramePositionManager")
 if not sealed() or (observedState~="KNOWN" and observedState~="ABSENT") or observed~=lease.original then return false end
 lease.flagRestored=true
 local member=membership();if member==nil then return false end
 -- A previous Add may have registered before a later callback failed. Observe
 -- that public native custody without running its layout callback twice.
 if lease.registrationAttempted and member and not row.contested then
  local eligible=nativeEligible()
  if eligible and nativeParent() then return finish("NATIVE_REGISTRATION_RESTORED") end
  if eligible==nil or not sealed() then return false end
 end
 -- Re-register only after the owning provider has restored its original
 -- layout. A foreign parent/anchor survives even if it did not change this
 -- flag. Native AddManagedFrame still decides current visibility/eligibility.
 if not register then return finish("NATIVE_LAYOUT_PRESERVED") end
 local eligible=nativeEligible();if eligible==nil then return false end
 if not eligible then return finish("NATIVE_LIFETIME_RETAINED") end
 if member and nativeParent() then return finish("NATIVE_REGISTRATION_RESTORED") end
 -- IsInDefaultPosition is a native callback, not a stored property. Recheck
 -- layout custody after it before letting AddManagedFrame move the root.
 if not originalLayout() then return finish("NATIVE_LAYOUT_PRESERVED") end
 if not sealed() or type(manager.AddManagedFrame)~="function" then return false end
 lease.registrationAttempted=true;row.managerState="NATIVE_REGISTRATION_PENDING"
 local ok,result=pcall(manager.AddManagedFrame,manager,frame)
 if not ok or result==false or not sealed() then return false end
 local finalFlag,finalState=S:FieldAccess(frame,"ignoreFramePositionManager")
 if not sealed() or (finalState~="KNOWN" and finalState~="ABSENT") or finalFlag~=lease.original then return false end
 eligible=nativeEligible();member=membership()
 if eligible==nil or member==nil then return false end
 if eligible then
  if not member or not nativeParent() then return false end
  return finish("NATIVE_REGISTRATION_RESTORED")
 end
 if member then return false end
 return finish("NATIVE_LIFETIME_RETAINED")
end
function C:Handles(name)
 return (name=="BuffFrame" or name=="DebuffFrame") and eligible("Auras")
end
function C:Pending()
 for _,r in pairs(self.rows) do if r.pending then return true end end
 for _,child in pairs(self.nativeChildren) do if child.pending then return true end end
 return false
end
function C:HoldForOwner(row)
 -- A generic handback cannot change ancestry underneath another owner's
 -- property receipts. Reveal first; that owner releases its own journals and
 -- then explicitly releases this parent. Secure emergency reveal also works
 -- while combat prevents the ordinary handback.
 if row.contextTerminal then return false end
 if not row.active and not row.pending and not row.attempted then return true end
 if S:InCombat() then self.status[row.name]="OWNER_HANDOFF_AFTER_COMBAT";return false end
 if row.ownerHandback and read(row.gate,"IsShown","boolean")==true then
  if row.contested and row.handbackResult=="COMPLETE" and not row.playerLease then self.status[row.name]="CONTEXT_RELEASED_NEWER_OWNER_RETAINED" end
  return false
 end
 if row.playerPresentation then
  if (row.playerHandbackAttempts or 0)>=3 then self.status[row.name]="OWNER_HANDOFF_PENDING";return false end
  row.playerHandbackAttempts=(row.playerHandbackAttempts or 0)+1
  local serial=row.serial
  local function current() return source(row) and row.serial==serial and not S:InCombat() end
  row.ownerHandback=self:RestorePlayerPresentation(row,current)==true or nil
 elseif S:Frame(row.gate,false) then
  if M.Effects and M.Effects.CancelProtected then M.Effects:CancelProtected(row,row.gate,false) end
  local ok=pcall(function()
   row.gate:SetAttribute("mirage-live",false);row.gate:SetAttribute("mirage-emergency",true);row.gate:SetAlpha(1);row.gate:Show()
  end)
  row.ownerHandback=ok and read(row.gate,"IsShown","boolean")==true
   and read(row.gate,"GetAttribute","boolean","mirage-live")==false
   and read(row.gate,"GetAttribute","boolean","mirage-emergency")==true or nil
 end
 self.status[row.name]=row.contested and row.handbackResult=="COMPLETE" and not row.playerLease
  and "CONTEXT_RELEASED_NEWER_OWNER_RETAINED" or "OWNER_HANDOFF_PENDING"
 if row.ownerHandback and row.handbackResult=="COMPLETE" and not row.playerLease then
  row.contextTerminal=true;row.active=false;row.pending=nil;row.groupDirty=nil;row.playerDirty=nil
  if row.alphaUnverified and not row.contested then self.status[row.name]="CONTEXT_RELEASED_ALPHA_UNVERIFIED" end
 end
 local owner=row.ownedOwner
 if owner and owner.active and not row.healthNotified then
  row.healthNotified=true;owner.pendingWork=true
  if type(owner.OnNativeContextHealthChanged)=="function" then pcall(owner.OnNativeContextHealthChanged,owner,row.name) end
 end
 return false
end
function C:Restore(name,ownedOwner)
 observationCycle=nil
 local r=self.rows[name]
 if not r then
  local child=self.nativeChildren[name]
  if not child then return true end
  if child.owner~=ownedOwner then
   -- UnitFrames first returns its authored pet geometry and artwork. A
   -- generic cleanup cannot move the native parent underneath those leases.
   child.pending=true;self.status[name]="OWNER_HANDOFF_PENDING"
   if child.owner then child.owner.pendingWork=true end
   return false
  end
  return self:ReleaseOwned(ownedOwner,name)
 end
 if r.ownedOwner and r.ownedOwner~=ownedOwner then return self:HoldForOwner(r) end
 if delegated(name,r.frame) and not r.ownedContract and (r.gate or r.attempted) then
  self.status[name]="NATIVE_GEOMETRY_RELOAD_REQUIRED";r.pending=true;r.failures=3;return false
 end
 r.serial=(r.serial or 0)+1;r.cancelled=true
 if r.busy then r.pending=true;return false end
 if not r.active and not r.pending and not r.attempted and not r.managerLease then return true end
 if S:InCombat() then r.pending=true;self.status[name]="RESTORE_AFTER_COMBAT";return false end
 r.busy=true
 local serial=r.serial
 local function current() return source(r) and r.serial==serial and not S:InCombat() end
 local function write(f,key,...)
  if not current() or not S:Frame(f,false) or type(f[key])~="function" then return false end
  local ok,result=pcall(f[key],f,...);return ok and result~=false and current()
 end
 local complete=true
 if r.playerPresentation then
  local ok,done=pcall(self.RestorePlayerPresentation,self,r,current)
  if not ok then handbackNote(r,"INVERSE","CALLBACK","CALL_FAILED");handbackResult(r,false) end
  complete=ok and done==true and current()
 elseif r.gate then
  if M.Effects and M.Effects.CancelProtected then M.Effects:CancelProtected(r,r.gate,false) end
  -- Retire future concealment before detaching; failed cleanup retains this row.
  complete=write(r.gate,"SetAttribute","mirage-live",false) and complete
  complete=write(r.gate,"SetAttribute","mirage-emergency",true) and complete
  complete=write(r.gate,"SetAlpha",1) and complete
  complete=write(r.gate,"Show") and complete
  complete=read(r.gate,"IsShown","boolean")==true and complete
  if current() and type(UnregisterStateDriver)=="function" then
   local ok,result=pcall(UnregisterStateDriver,r.gate,"miragecontext");complete=ok and result~=false and current() and complete
  else complete=false end
 end
 if r.playerPresentation then
  -- Native PLAYER ancestry and visibility are never part of this journal.
 elseif current() and S:Frame(r.frame,false) then
  local parent,known=read(r.frame,"GetParent")
  if not current() or known~="KNOWN" then complete=false
  elseif parent==r.gate then
   if not S:Frame(r.originalParent,false) or not write(r.frame,"SetParent",r.originalParent) then complete=false end
   local observed,state=read(r.frame,"GetParent")
   if not current() or state~="KNOWN" or observed~=r.originalParent then complete=false end
  elseif parent~=r.originalParent then
   -- Never overwrite a newer parent's custody or force the native root shown.
   handbackConflict(r,"ROOT","PARENT")
  end
 else complete=false end
 if complete then
  local ok,restored=pcall(self.RestoreManagedCooldown,self,r,current)
  complete=ok and restored==true and current()
 end
 r.busy=nil
 r.pending=not complete or nil
 if complete then
  r.active=false;r.attempted=nil;r.ownerHandback=nil;r.healthNotified=nil;r.failures=0
  r.contextTerminal=r.contested or r.alphaUnverified or nil
  self.status[name]=r.contested and "NEWER_PARENT_PRESERVED" or r.alphaUnverified and "CONTEXT_RELEASED_ALPHA_UNVERIFIED" or "RESTORED"
 else r.failures=(r.failures or 0)+1;self.status[name]="RESTORE_PENDING" end
 return complete
end
function C:RestoreAll(module)
 local complete=true
 for name,child in pairs(self.nativeChildren) do if not module or ownedContracts[name]==module then
  local ok,done=pcall(self.Restore,self,name)
  if not ok or not done then complete=false end
 end end
 for name,r in pairs(self.rows) do if not module or r.module==module then
  local ok,done=pcall(self.Restore,self,name)
  if not ok then
   if r.playerPresentation then handbackNote(r,"INVERSE","CALLBACK","CALL_FAILED");handbackResult(r,false) end
   r.pending=true;self.status[name]="RESTORE_PENDING"
  end
  if not ok or not done then complete=false end
 end end
 return complete
end
local function nativePetAncestry(frame)
 -- Reviewed PetFrame is a PlayerBottomManagedFrameTemplate. Its native
 -- OnShow/AddManagedFrame normally reparents it into the managed container.
 -- Beta52 separately leases that membership and keeps Pet directly below
 -- PlayerFrame. There is no second contextual gate or replacement lifetime.
 local player,container=_G.PlayerFrame,_G.PlayerBottomManagedFrameContainer
 if frame~=_G.PetFrame or not S:Frame(frame,false) or not S:Frame(player,false) or not S:Frame(container,false) then return false end
 local layoutParent,state=S:FieldAccess(frame,"layoutParent")
 local managed,managedState=S:FieldAccess(frame,"isPlayerFrameBottomManagedFrame")
 if state~="KNOWN" or layoutParent~=container or managedState~="KNOWN" or managed~=true then return false end
 if read(container,"GetParent")~=player then return false end
 local parent,parentState=read(frame,"GetParent")
 if parentState~="KNOWN" then return false end
 if parent==player or parent==container then return true end
 local bottom,bottomState=S:FieldAccess(container,"BottomManagedLayoutContainer")
 return bottomState=="KNOWN" and S:Frame(bottom,false) and parent==bottom and read(bottom,"GetParent")==container
end
local function nativeChildStructure(self,owner,child)
 if not child or child.owner~=owner or not owner or owner.active~=true or M.state.safe then return false,"PET_NATIVE_PARENT_CONTEXT_UNAVAILABLE" end
 if not nativePetAncestry(child.frame) then return false,"PET_NATIVE_PARENT_CONTEXT_UNAVAILABLE" end
 local parent=self.rows.PlayerFrame
 if not parent or parent.ownedOwner~=owner or not parent.active or parent.pending or parent.ownerHandback or parent.cancelled
  or parent.frame~=_G.PlayerFrame or read(parent.frame,"GetParent")~=expectedParent(parent) then return false,"PET_PLAYER_CONTEXT_UNAVAILABLE" end
 return true,parent.playerPresentation and "NATIVE_PLAYER_PRESENTATION" or "INHERITED_PLAYER_CONTEXT",parent
end
local function nativeChildContext(self,owner,child)
 local ready,why,parent=nativeChildStructure(self,owner,child)
 if not ready then return false,why end
 if parent.playerPresentation and not self:PlayerPresentationCurrent(parent,false) then return false,"PET_PLAYER_CONTEXT_UNAVAILABLE" end
 return true,why
end
function C:NativeChildReady(owner,name)
 local child=self.nativeChildren[name]
 local ready,why=nativeChildContext(self,owner,child)
 if not ready then return false,why end
 local pet=M.Rework and M.Rework.PetLayout
 if not pet or child.petLayout~=pet then return false,"PET_LAYOUT_NOT_ACQUIRED" end
 local leased,reason=pet:Ready(owner)
 if not leased then return false,reason end
 return true,why
end
function C:AcquireNativePet(owner,element)
 local child=self.nativeChildren.PetFrame
 if child and child.owner~=owner then self.status.PetFrame="CONTEXT_OWNER_RETAINED";return false end
 local prior=self.rows.PetFrame
 if prior then
  if prior.ownedOwner and prior.ownedOwner~=owner then self.status.PetFrame="CONTEXT_OWNER_RETAINED";return false end
  if not self:Restore("PetFrame",owner) then return false end
  -- The retired gate has no native child and its secure driver was removed.
  -- Native managed layout resumes without a new wrapper or retry loop.
  self.rows.PetFrame=nil
 end
 if not child or child.frame~=_G.PetFrame then
  if child and child.petLayout and not child.petLayout:Release(owner) then self.status.PetFrame="PET_LAYOUT_HANDOFF_PENDING";return false end
  child={owner=owner,frame=_G.PetFrame,parentName="PlayerFrame",element=element};self.nativeChildren.PetFrame=child
 else child.element=element or child.element end
 local parentReady,parentWhy=nativeChildContext(self,owner,child)
 if not parentReady then self.status.PetFrame=parentWhy;return false end
 local pet=M.Rework and M.Rework.PetLayout
 if not pet then self.status.PetFrame="PET_LAYOUT_UNAVAILABLE";return false end
 child.petLayout=pet
 local detached,detachWhy=pet:Acquire(owner)
 child.pending=not detached or nil
 if not detached then self.status.PetFrame=detachWhy;return false end
 local ready,why=self:NativeChildReady(owner,"PetFrame")
 self.status.PetFrame=why
 return ready
end
local function acquire(self,name,id,owner,element,elements)
 observationCycle=nil
 -- Native geometry delegation also prohibits the fallback's indirect parent
 -- writer. These controls use the independent, non-reparenting utility owner.
 if delegated(name,_G[name]) and not owner then self.status[name]="NATIVE_GEOMETRY_DELEGATED";return false end
 if owner and (ownedContracts[name]~=id or type(owner)~="table") then return false end
 local admission=owner and {name=name,ownedOwner=owner}
 if S:InCombat() or not eligible(id,admission) then return false end
 if name=="PetFrame" then
  if owner then return self:AcquireNativePet(owner,element) end
  -- The fallback must not reintroduce the same managed-child parent conflict.
  -- Detached native Edit Mode layouts retain their native lifetime explicitly.
  self.status[name]="NATIVE_MANAGED_LIFETIME";return false
 end
 local frame=_G[name];if not frame or not S:Frame(frame,false) then self.status[name]="NATIVE_UNAVAILABLE";return false end
 local managed=N.rows[name]
 -- A released primary lease may have yielded to a newer parent's custody.
 -- That is not permission for the fallback to reclaim the same native root.
 if managed and managed.frame==frame and managed.contested then
  self:Restore(name,owner);self.status[name]="NEWER_MANAGED_OWNER_RETAINED";return false
 end
 if managed and not (owner and managed.mode=="adopt" and not managed.restorePending and not managed.parentAttempt)
  and (managed.active or managed.restorePending or managed.parentAttempt or managed.editSuspended or nativeEditPending(N,managed)) then
  self:Restore(name,owner);self.status[name]="MANAGED_PRIMARY";return false
 end
 local r=self.rows[name]
 if r and r.ownedOwner and r.ownedOwner~=owner then self.status[name]="CONTEXT_OWNER_RETAINED";return false end
 if r and r.frame~=frame then
  if not self:Restore(name,owner) then return false end
  -- Retire the former root before reusing the already-registered emergency gate.
  -- No new gate allocation or accumulated recovery reference on a successor.
  r={name=name,module=id,frame=frame,gate=r.gate};self.rows[name]=r
 end
 if r and r.recoveryBaseline and not r.playerLease and not r.active then
  if not self:RevalidateRecovery(r,owner) then return false end
 end
 if r and (r.contested or r.contextTerminal or r.busy or r.pending or (r.failures or 0)>=3 or (r.acquireFailures or 0)>=3) then return false end
 if r and r.active then
  local parent,known=read(frame,"GetParent")
  if known~="KNOWN" or parent~=expectedParent(r)
   or r.playerPresentation and not self:PlayerPresentationCurrent(r,true) then self:Restore(name,owner);return false end
  if r.ownerHandback then return false end
  r.ownedElement=element or r.ownedElement;r.ownedElements=elements or r.ownedElements
  return true
 end
 local parent,known=read(frame,"GetParent")
 if known~="KNOWN" or not parent or not S:Frame(parent,false) then return false end
 if not r then r={name=name,module=id,frame=frame};self.rows[name]=r end
 r.ownedOwner=owner;r.lastOwnedOwner=owner or r.lastOwnedOwner;r.ownedContract=owner and true or r.ownedContract;r.ownedElement=element;r.ownedElements=elements
 r.alphaUnverified=nil;r.recoveryBaseline=nil;r.contextTerminal=nil
 -- Group roots own pooled native controllers too. Their OnShow/OnHide must
 -- remain native: PartyFrame.OnShow rebuilds the pool and invokes Layout.
 r.groupPresentation=groupPresentationRoots[name]==true or nil
 r.playerPresentation=name=="PlayerFrame" or r.groupPresentation or nil
 r.auditLease=nil;r.auditProfile=nil;r.auditDeadline=nil
 r.held=nil;r.forced=nil;r.inputHeld=nil;r.pressHeld=nil;r.dragHeld=nil
 r.inputRevision=(r.inputRevision or 0)+1;r.inputReleaseStatus=nil
 r.originalParent=parent;r.serial=(r.serial or 0)+1;r.cancelled=nil;r.busy=true
 r.acquiring=true;r.acquireResult="ATTEMPTING";r.acquireCurrent=nil;r.acquirePhase="GATE_CREATE"
 r.acquireAttempts=math.min(9999,(r.acquireAttempts or 0)+1)
 local profile,serial=M.profile,r.serial
 local ok=pcall(function()
  if not r.gate then
   r.gate=CreateFrame("Frame",nil,parent,r.playerPresentation and "SecureHandlerAttributeTemplate" or "SecureHandlerStateTemplate")
   S:Passive(r.gate)
  end
  local gate=r.gate
  r.acquirePhase="GATE_SETUP"
  acquireCheck(r,S:InitializeSecureHandler(gate),"SECURE_HANDLER","INITIALIZATION_UNCONFIRMED")
  acquireCheck(r,read(gate,"IsProtected","boolean")==true,"PROTECTION","READBACK_UNCONFIRMED")
  assert(request(r,profile,serial,gate,"SetParent",parent))
  assert(request(r,profile,serial,gate,"ClearAllPoints"))
  assert(request(r,profile,serial,gate,"SetAllPoints",parent))
  assert(request(r,profile,serial,gate,"SetAttribute","mirage-live",false))
  assert(request(r,profile,serial,gate,"SetAttribute","mirage-held",true))
  assert(request(r,profile,serial,gate,"SetAttribute","mirage-force",false))
  assert(request(r,profile,serial,gate,"SetAttribute","mirage-group",r.groupPresentation==true))
  local unitProvider=M.Rework and M.Rework.UnitFrames
  local observePlayer=name=="PlayerFrame" and owner~=nil and owner==unitProvider
   and owner.nativeBacked==true and owner.initialized==true
  assert(request(r,profile,serial,gate,"SetAttribute","mirage-player-refresh-combat",observePlayer))
  assert(request(r,profile,serial,gate,"SetAttribute","mirage-group-pending",false))
  local sidebar=name=="StatusTrackingBarManager" and profile.managed and profile.preset=="Immersive"
  r.navigationRecipient=sidebar and "PROGRESS" or nil
  assert(request(r,profile,serial,gate,"SetAttribute","mirage-sidebar-combat",sidebar==true))
  assert(request(r,profile,serial,gate,"SetAttribute","mirage-layout-ready",true))
  local emergency=N.recovery and read(N.recovery,"GetAttribute","boolean","mirage-emergency")==true
  assert(request(r,profile,serial,gate,"SetAttribute","mirage-emergency",emergency==true))
  if r.playerPresentation then
   r.acquirePhase="INPUT_CENSUS"
   acquireCheck(r,self:PreparePlayerPresentation(r,profile,serial),"INPUT_CONTRACT","CONTRACT_UNAVAILABLE")
   if r.groupPresentation then
    r.acquirePhase="GROUP_OBSERVATION"
    acquireCheck(r,self:ObserveGroupPresentation(r),"NATIVE_LIFETIME","OBSERVATION_UNAVAILABLE")
   end
   if observePlayer then
    r.acquirePhase="PLAYER_OBSERVATION"
    acquireCheck(r,self:ObservePlayerPresentation(r),"NATIVE_LIFETIME","OBSERVATION_UNAVAILABLE")
   end
  end
  r.acquirePhase="CONTEXT_STYLE_PREPARE"
  self:PrepareFade(r,profile,serial)
  r.acquirePhase="CONTEXT_STYLE"
  if not r.playerPresentation then
   assert(request(r,profile,serial,gate,"SetAttribute","_onstate-miragecontext",r.fadePrepared and self.fadeProgram or self.program))
  end
  r.acquirePhase="STATE_DRIVER_SETUP"
  acquireCheck(r,type(RegisterStateDriver)=="function","REGISTER","METHOD_UNAVAILABLE")
  acquireCheck(r,type(UnregisterStateDriver)=="function","UNREGISTER","METHOD_UNAVAILABLE")
  -- UnregisterStateDriver retains state-*; a same-context reacquisition must
  -- actually run its snippet before any hide is authorized.
  assert(request(r,profile,serial,gate,"SetAttribute","state-miragecontext",nil))
  assert(request(r,profile,serial,gate,"SetAttribute","mirage-state",nil))
  acquireCheck(r,valid(r,profile,serial),"ROW","CURRENTNESS_CHANGED")
  local driver=self:DriverFor(r,profile)
  r.acquirePhase="STATE_DRIVER_REGISTER"
  local registered=RegisterStateDriver(gate,"miragecontext",driver)
  r.acquirePhase="STATE_DRIVER_READBACK"
  local state=read(gate,"GetAttribute","string","mirage-state")
  acquireCheck(r,registered~=false,"REGISTER","WRITE_REFUSED")
  acquireCheck(r,state=="quiet" or state=="show","STATE","READBACK_UNCONFIRMED")
  acquireCheck(r,read(gate,"IsShown","boolean")==true,"GATE_SHOWN","READBACK_UNCONFIRMED")
  r.driver=driver
  acquireCheck(r,valid(r,profile,serial),"ROW","CURRENTNESS_CHANGED")
  r.acquirePhase="NATIVE_MANAGER"
  acquireCheck(r,self:DetachManagedCooldown(r,profile,serial),"COOLDOWN_MANAGER","CONTRACT_UNAVAILABLE")
  r.attempted=true
  r.acquirePhase="NATIVE_PARENT"
  if not r.playerPresentation then assert(request(r,profile,serial,frame,"SetParent",gate)) end
  acquireCheck(r,read(frame,"GetParent")==expectedParent(r),"PARENT","READBACK_UNCONFIRMED")
  acquireCheck(r,valid(r,profile,serial),"ROW","CURRENTNESS_CHANGED")
  r.active=true
  r.acquirePhase="COMMIT"
  assert(request(r,profile,serial,gate,"SetAttribute","mirage-live",true))
  if r.groupPresentation then r.groupDirty=nil end
  if name=="PlayerFrame" then r.playerDirty=nil end
 end)
 r.busy=nil
 if not ok or not valid(r,profile,serial) then
  acquireNote(r,nil,"CALLBACK",not ok and "CALL_FAILED" or "CURRENTNESS_CHANGED")
  r.acquireFirst=r.acquireFirst or r.acquireCurrent;r.acquireLast=r.acquireCurrent
  r.acquiring=nil;r.acquireResult="REFUSED"
  r.acquireFailures=(r.acquireFailures or 0)+1
  r.failures=(r.failures or 0)+1;r.pending=true;self:Restore(name,owner);self.status[name]="ACQUIRE_REFUSED_NATIVE_RETAINED";return false
 end
 r.acquiring=nil;r.acquireResult="COMPLETE";r.acquireCurrent=nil
 r.acquireFailures=0
 self:PrepareInput(r)
 self.status[name]="SECURE_CONTEXT_READY";return true
end
function C:InvalidateGroupPresentation(row)
 if not row or not row.groupPresentation or not source(row) or not row.active
  or row.pending or row.cancelled or row.ownerHandback or _G[row.name]~=row.frame then return end
 row.inputTreeRevision=(row.inputTreeRevision or 0)+1
 row.groupDirty=true
 if row.ownedOwner then row.ownedOwner.pendingWork=true end
 -- Native post-hooks never Show/Hide, reparent or lay out a protected root.
 -- In combat the predeclared access floor is already visible. Outside combat
 -- open the existing alpha/input controller before returning to native code,
 -- so a new clickable descendant is not left underneath an invisible root.
 if not S:InCombat() and not row.busy then
  if not request(row,M.profile,row.serial,row.gate,"SetAttribute","mirage-group-pending",true) then
   self.status[row.name]="GROUP_INPUT_REFRESH_PENDING"
  end
 end
end
function C:ObserveGroupNode(frame)
 for name in pairs(groupPresentationRoots) do
  local row=self.rows[name]
  if row and row.active and row.groupPresentation and row.playerLease
   and source(row) and playerDescendant(frame,row.frame) then
   row.inputTreeRevision=(row.inputTreeRevision or 0)+1
   if row.groupDirty then
    -- An already queued census may be executing through a native getter.
    -- Its revision still needs to observe this newer pool notification.
   elseif S:InCombat() then
    -- Combat creates no ordinary protected writes. The next out-of-combat
    -- refresh includes any new aura/controller nodes before concealment.
    row.groupDirty=true
   else
    local nodes=collectPlayerNodes(frame,true)
    local changed=nodes==nil or not self:GroupMarkersCurrent(row)
    for _,node in ipairs(nodes or {}) do
     if not row.playerLease.seen[node.frame] then changed=true;break end
    end
    if changed then self:InvalidateGroupPresentation(row) end
   end
  end
 end
end
function C:ObserveGroupPresentation(row)
 if S:InCombat() then acquireNote(row,nil,"COMBAT","CURRENTNESS_CHANGED");return false end
 if type(hooksecurefunc)~="function" then acquireNote(row,nil,"hooksecurefunc","METHOD_UNAVAILABLE");return false end
 if type(SecureHandlerWrapScript)~="function" then acquireNote(row,nil,"SecureHandlerWrapScript","METHOD_UNAVAILABLE");return false end
 local frame,gate=row.frame,row.gate
 self.groupHooks=self.groupHooks or setmetatable({},{__mode="k"})
 local hooks=self.groupHooks[frame]
 if not hooks then hooks={};self.groupHooks[frame]=hooks end
 local function current()
  return C.rows[row.name]==row and row.frame==frame and row.gate==gate and source(row)
 end
 gate.MirageGroupInvalidated=function()
  if current() and row.active then
   row.inputTreeRevision=(row.inputTreeRevision or 0)+1
   row.groupDirty=true;if row.ownedOwner then row.ownedOwner.pendingWork=true end
  end
 end
 if hooks.gate~=gate then
  if hooks.gate then acquireNote(row,nil,"NATIVE_SHOW_HOOK","DIFFERENT_GATE_RETAINED");return false end
  local ok=pcall(SecureHandlerWrapScript,frame,"OnShow",gate,self.groupShowProgram)
  if not ok then acquireNote(row,nil,"OnShow","HOOK_CALL_FAILED");return false end
  hooks.gate=gate
 end
 local methods=row.name=="PartyFrame" and {"InitializePartyMemberFrames"} or {"GetUnitFrame","AddGroup","LayoutFrames"}
 for _,method in ipairs(methods) do
  if type(frame[method])~="function" then acquireNote(row,nil,method,"METHOD_UNAVAILABLE");return false end
  if not hooks[method] then
   local ok=pcall(hooksecurefunc,frame,method,function()
    local active=C.rows[row.name]
    if active and active.frame==frame then C:InvalidateGroupPresentation(active) end
   end)
   if not ok then acquireNote(row,nil,method,"HOOK_CALL_FAILED");return false end
   hooks[method]=true
  end
 end
 -- Party member/pet aura pools are created by their native UpdateAuras;
 -- compact units use the global function below. Observe the completed tree,
 -- never the aura data or native target assignment.
 self.groupNodeHooks=self.groupNodeHooks or setmetatable({},{__mode="k"})
 for index,node in ipairs(row.playerLease.nodes) do
  local f=node.frame
  if type(f.UpdateAuras)=="function" and not self.groupNodeHooks[f] then
   local ok=pcall(hooksecurefunc,f,"UpdateAuras",function() C:ObserveGroupNode(f) end)
   if not ok then acquireNote(row,nil,"UpdateAuras","HOOK_CALL_FAILED",index);return false end
   self.groupNodeHooks[f]=true
  end
 end
 self.groupGlobalHooks=self.groupGlobalHooks or {}
 for _,name in ipairs({"CompactUnitFrame_SetUpFrame","CompactUnitFrame_UpdateAuras"}) do
  if type(_G[name])=="function" and not self.groupGlobalHooks[name] then
   local ok=pcall(hooksecurefunc,name,function(f) C:ObserveGroupNode(f) end)
   if not ok then acquireNote(row,nil,name,"HOOK_CALL_FAILED");return false end
   self.groupGlobalHooks[name]=true
  end
 end
 return current()
end
function C:RetainInputReview(row)
 -- Combat conservatively opens the existing input floor until its native
 -- pool is observed again. A completed, unchanged census does not require
 -- returning every input/alpha lease and registering its driver again.
 -- Retain only the exact current lease; real tree growth, unknown properties
 -- and foreign input still take the existing renewal/handback path.
 if not row or not row.playerPresentation or not row.playerLease or row.busy then return false end
 local profile,serial,lease,owner=M.profile,row.serial,row.playerLease,row.ownedOwner
 local revision=row.inputTreeRevision
 local function current()
  return row.active==true and row.playerLease==lease and row.ownedOwner==owner
   and row.inputTreeRevision==revision and not row.busy and not row.contested
   and valid(row,profile,serial) and row.inputTreeRevision==revision
 end
 if not current() then return false end
 local pending,known=read(row.gate,"GetAttribute","boolean","mirage-group-pending")
 if known~="KNOWN" or not current() or not self:PlayerPresentationCurrent(row,true) or not current() then return false end
 local reviewed=pending or row.playerDirty or row.groupDirty
 if pending then
  if not request(row,profile,serial,row.gate,"SetAttribute","mirage-group-pending",false)
   or not current() or read(row.gate,"GetAttribute","boolean","mirage-group-pending")~=false
   or not current() or not self:PlayerPresentationCurrent(row,false) or not current() then return false end
 end
 row.playerDirty=nil;row.groupDirty=nil
 if reviewed then row.inputReviewsRetained=math.min(999999,(row.inputReviewsRetained or 0)+1) end
 return true
end
function C:RefreshGroupPresentation(row)
 local profile,serial,owner=M.profile,row.serial,row.ownedOwner
 if not row.groupPresentation or not valid(row,profile,serial) or row.busy then return false end
 if self:RetainInputReview(row) then return true,"FRESH_RETAINED_REVIEW" end
 if not valid(row,profile,serial) then return false end
 local element,elements=row.ownedElement,row.ownedElements
 -- First return all current alpha/input receipts. A failed or contested
 -- handback remains visible and pending; no new census borrows that custody.
 if not self:Restore(row.name,owner) or not source(row) or M.profile~=profile or row.contested then return false end
 local ready=acquire(self,row.name,row.module,owner,element,elements)
 if not ready then self.status[row.name]="GROUP_INPUT_REFRESH_UNAVAILABLE_NATIVE_RETAINED" end
 return ready
end
function C:ObservePlayerNode(frame)
 local row=self.rows.PlayerFrame
 if not row or not source(row) or not row.active or not row.ownedOwner or not row.playerLease
  or row.pending or row.cancelled or row.ownerHandback or frame~=_G.PetFrame
  or row.frame~=_G.PlayerFrame or not row.ownedOwner.active
  or not nativePetAncestry(frame) then return end
 row.inputTreeRevision=(row.inputTreeRevision or 0)+1
 if row.playerDirty then return end
 if S:InCombat() then
  -- The predeclared native combat state retains visible access until the
  -- first ordinary post-combat census. This callback writes no protected state.
  row.playerDirty=true;row.ownedOwner.pendingWork=true;return
 end
 local nodes=collectPlayerNodes(frame,false)
 local changed=nodes==nil
 for _,node in ipairs(nodes or {}) do if not row.playerLease.seen[node.frame] then changed=true;break end end
 if not changed then return end
 row.playerDirty=true;row.ownedOwner.pendingWork=true
 if not row.busy and not request(row,M.profile,row.serial,row.gate,"SetAttribute","mirage-group-pending",true) then
  self.status.PlayerFrame="PLAYER_INPUT_REFRESH_PENDING"
 end
end
function C:ObservePlayerPresentation(row)
 -- Pinned PetFrameMixin.UpdateAuras calls UpdateMemberAuras, whose native
 -- pool may add click controls. Observe the completed tree, never aura data,
 -- and never replace native callbacks or native Show/Hide/managed layout.
 local pet=_G.PetFrame
 if not pet then return true end
 if not nativePetAncestry(pet) then acquireNote(row,nil,"PET_ANCESTRY","NATIVE_ANCESTRY_UNCONFIRMED");return false end
 if type(hooksecurefunc)~="function" then acquireNote(row,nil,"hooksecurefunc","METHOD_UNAVAILABLE");return false end
 if type(pet.UpdateAuras)~="function" then acquireNote(row,nil,"UpdateAuras","METHOD_UNAVAILABLE");return false end
 self.playerNodeHooks=self.playerNodeHooks or setmetatable({},{__mode="k"})
 if not self.playerNodeHooks[pet] then
  local ok=pcall(hooksecurefunc,pet,"UpdateAuras",function() C:ObservePlayerNode(pet) end)
  if not ok then acquireNote(row,nil,"UpdateAuras","HOOK_CALL_FAILED");return false end
  self.playerNodeHooks[pet]=true
 end
 return source(row) and row.frame==_G.PlayerFrame
end
function C:SyncOwnedPlayerPresentation(owner,element)
 -- Unit artwork is created lazily beneath the real PlayerFrame/PetFrame.
 -- Those passive children are part of the input census too: finish the
 -- owner's construction first, then renew only this alpha/input journal.
 -- Native ancestry/IsShown and the unit provider's geometry/art are unchanged.
 local row=self.rows.PlayerFrame
 if not row or not row.active then return self:AcquireOwned(owner,"PlayerFrame","UnitFrames",element) end
 local profile,frame,serial,lease=M.profile,row.frame,row.serial,row.playerLease
 local function current()
  return source(row) and self.rows.PlayerFrame==row and row.ownedOwner==owner and owner and owner.active==true
   and row.playerPresentation and not row.groupPresentation and frame==_G.PlayerFrame and row.frame==frame
   and M.profile==profile and not M.state.safe and not row.pending and not row.contested and not row.busy
   and not S:InCombat() and eligible("UnitFrames",row)
 end
 local function sameReview()
  return row.serial==serial and row.playerLease==lease and current()
   and row.serial==serial and row.playerLease==lease
 end
 if not sameReview() or read(frame,"GetParent")~=row.originalParent or not sameReview() then
  return false,self.status.PlayerFrame or "PLAYER_PRESENTATION_UNAVAILABLE"
 end
 local retained=not row.ownerHandback and self:RetainInputReview(row)
 if not sameReview() then return false,"PLAYER_INPUT_REVIEW_SUPERSEDED" end
 if retained then
  return true,self.status.PlayerFrame or "SECURE_CONTEXT_READY"
 end
 if row.ownerHandback then
  -- Only a completed inverse can be renewed. Failed input/alpha retirement
  -- retains its bounded handback debt and is never converted into a fresh lease.
  if row.playerLease then return false,self.status.PlayerFrame or "OWNER_HANDOFF_PENDING" end
 else
  local ready=self:PlayerPresentationCurrent(row,false)
  if not sameReview() then return false,"PLAYER_INPUT_REVIEW_SUPERSEDED" end
  if not ready then
   self:HoldForOwner(row)
   return false,self.status.PlayerFrame or "OWNER_HANDOFF_PENDING"
  end
 end
 local elements=row.ownedElements
 element=element or row.ownedElement
 if not self:Restore("PlayerFrame",owner) or not current() then return false,self.status.PlayerFrame end
 local ready=acquire(self,"PlayerFrame","UnitFrames",owner,element,elements)
 if ready then row.playerRefreshes=(row.playerRefreshes or 0)+1 end
 return ready,self.status.PlayerFrame or "PLAYER_INPUT_REFRESH_UNAVAILABLE_NATIVE_RETAINED"
end
-- Observe input already delivered to the native root. No new hit regions,
-- replacement scripts, or mouse enablement is introduced by this hold.
function C:PrepareInput(row)
 if S:InCombat() or not S:Frame(row.frame,false) or type(row.frame.HookScript)~="function"
  or read(row.frame,"IsMouseEnabled","boolean")~=true then return false end
 if row.inputHooks then return true end
 local frame=row.frame
 local function current() return source(row) and row.frame==frame and row.active and not row.pending and not row.cancelled end
 local function update(key,held)
  if not current() then return end
  if held and (row.playerPresentation and read(row.gate,"GetAttribute","boolean","mirage-player-presented")~=true
   or not row.playerPresentation and read(row.gate,"IsShown","boolean")~=true) then return end
  row.inputRevision=(row.inputRevision or 0)+1
  row[key]=held or nil;row.inputHeld=row.pressHeld==true or row.dragHeld==true
  if not row.inputHeld then row.hoverUntil=S:Now()+.4;row.inputReleaseStatus="NATIVE_RELEASE_EVENT" end
  M.state.forceEvaluate=true
 end
 local hooks={OnMouseDown=function() update("pressHeld",true) end,OnMouseUp=function() update("pressHeld",false) end,
  OnDragStart=function() update("dragHeld",true) end,OnDragStop=function() update("dragHeld",false) end,
  OnHide=function() if current() then
   row.inputRevision=(row.inputRevision or 0)+1
   row.inputHeld=nil;row.pressHeld=nil;row.dragHeld=nil;row.hoverUntil=nil;row.inputReleaseStatus="NATIVE_HIDE_EVENT"
  end end}
 for event,fn in pairs(hooks) do
  local supported=read(frame,"HasScript","boolean",event)
  if supported==true then pcall(frame.HookScript,frame,event,fn) end
 end
 row.inputHooks=true;return true
end
function C:ReconcileInputHold(row,now)
 -- A native control need not receive OnMouseUp/OnDragStop after the pointer
 -- leaves it. A remembered press is only a temporary presentation hold, never
 -- proof that input is still down after a target's native frame disappears.
 -- Reconcile only held controls, outside combat, from public released input.
 if not row or not row.inputHeld or not S:Number(now) then return false end
 local profile,serial,revision=M.profile,row.serial,row.inputRevision
 local mouse,look,cursor=IsMouseButtonDown,IsMouselooking,GetCursorInfo
 local function current()
  return row.active==true and row.inputHeld==true and row.inputRevision==revision
   and IsMouseButtonDown==mouse and IsMouselooking==look and GetCursorInfo==cursor
   and valid(row,profile,serial) and row.inputRevision==revision
 end
 if not current() then return false end
 local down,downState=S:Public(mouse,"boolean")
 if downState~="KNOWN" or down~=false or not current() then return false end
 local looking,lookState=S:Public(look,"boolean")
 if lookState~="KNOWN" or looking~=false or not current() then return false end
 local drag=row.dragHeld
 if drag and type(cursor)=="function" then
  -- Cursor contents are never read; only a public, verified empty cursor can
  -- retire a lost drag-stop. Unknown or occupied cursors retain native access.
  local okay,payload=pcall(cursor)
  if okay and S:Readable(payload) and payload==nil and current() then drag=nil end
 end
 if not current() or not row.pressHeld and drag==row.dragHeld then return false end
 row.inputRevision=(row.inputRevision or 0)+1
 row.pressHeld=nil;row.dragHeld=drag;row.inputHeld=drag==true or nil
 if not row.inputHeld then
  row.hoverUntil=math.max(row.hoverUntil or 0,now+.4)
  row.inputReleaseStatus="PUBLIC_INPUT_RELEASED"
 else row.inputReleaseStatus="NATIVE_DRAG_RETAINED" end
 row.inputReleases=math.min(9999,(row.inputReleases or 0)+1)
 M.state.forceEvaluate=true
 return true
end
function C:Acquire(name,id) return acquire(self,name,id) end
function C:OwnedReady(owner,name)
 if name=="PetFrame" and self.nativeChildren[name] then
  local ready,why=self:NativeChildReady(owner,name);self.status[name]=why;return ready,why
 end
 local row=self.rows[name];local frame=row and row.frame;local gate=row and row.gate
 local function current()
  local native=_G[name]
  return row and self.rows[name]==row and source(row) and row.ownedOwner==owner and owner.active==true
   and row.active==true and not row.pending and not row.ownerHandback and not row.cancelled
   and S:Readable(native) and native==frame and row.frame==frame and row.gate==gate
 end
 local ready=current() and read(frame,"GetParent")==expectedParent(row)
  and (not row.playerPresentation or self:PlayerPresentationCurrent(row,false)) and current() or false
 return ready,self.status[name] or "CONTEXT_UNAVAILABLE"
end
function C:OwnedPlayerPetReady(owner)
 -- Player and pet share one native subtree and one input lease. Observe the
 -- pet's separate geometry first, then audit that shared tree once. This is
 -- one synchronous read, never a timed cache or an admission receipt reused
 -- by a later call. Standalone OwnedReady/NativeChildReady keep full checks.
 local profile,state,rows,children=M.profile,M.state,self.rows,self.nativeChildren
 local parent,child=rows.PlayerFrame,children.PetFrame
 local serial,lease=parent and parent.serial,parent and parent.playerLease
 local generation=owner and owner.generation
 local playerFrame,petFrame=_G.PlayerFrame,_G.PetFrame
 local parentFrame,childFrame=parent and parent.frame,child and child.frame
 local parentOwner,childOwner=parent and parent.ownedOwner,child and child.owner
 local ownerActive=owner and owner.active
 local function stable()
  return M.ContextualNative==self and M.profile==profile and M.state==state
   and self.rows==rows and self.nativeChildren==children
   and rows.PlayerFrame==parent and children.PetFrame==child
   and (not parent or parent.serial==serial and parent.playerLease==lease and parent.ownedOwner==parentOwner and parent.frame==parentFrame)
   and (not owner or owner.active==ownerActive and owner.generation==generation)
   and (not child or child.owner==childOwner and child.frame==childFrame) and _G.PlayerFrame==playerFrame and _G.PetFrame==petFrame
 end
 local function current()
  return stable() and owner and owner.active and parent and parent.ownedOwner==owner and parent.frame==playerFrame
   and child and child.owner==owner and child.frame==petFrame
 end
 local petReady,petWhy=false,"PET_NATIVE_PARENT_CONTEXT_UNAVAILABLE"
 if current() then
  petReady,petWhy=nativeChildStructure(self,owner,child)
  if petReady and current() then
   local pet=M.Rework and M.Rework.PetLayout
   if not pet or child.petLayout~=pet then petReady,petWhy=false,"PET_LAYOUT_NOT_ACQUIRED"
   else
    local ready,why=pet:Ready(owner)
    if not ready then petReady,petWhy=false,why end
   end
  end
 end
 local playerReady,playerWhy=self:OwnedReady(owner,"PlayerFrame")
 if not stable() then return false,"CONTEXT_OBSERVATION_SUPERSEDED",false,"CONTEXT_OBSERVATION_SUPERSEDED" end
 if not playerReady then petReady,petWhy=false,"PET_PLAYER_CONTEXT_UNAVAILABLE" end
 self.sharedPlayerPetAudits=math.min(999999,(self.sharedPlayerPetAudits or 0)+1)
 self.status.PetFrame=petWhy
 return playerReady,playerWhy,petReady,petWhy
end
function C:AcquireOwned(owner,name,id,element,elements)
 local previous=self.rows[name];local already=previous and previous.active==true
 local ready=acquire(self,name,id,owner,element,elements)
 if ready then self:Update(M.Store:Snapshot(),S:Now()) end
 ready=ready and self:OwnedReady(owner,name) or false
 if ready and not already and type(N.RecoveryButton)=="function" then N:RecoveryButton() end
 return ready,self.status[name] or "CONTEXT_UNAVAILABLE"
end
function C:ReleaseOwned(owner,name)
 local child=self.nativeChildren[name]
 if child and child.owner==owner then
  if child.petLayout then
   local restored,why=child.petLayout:Release(owner)
   self.status[name]=why
   if not restored then child.pending=true;return false end
  else self.status[name]="NATIVE_MANAGED_LIFETIME" end
  self.nativeChildren[name]=nil;return true
 end
 local row=self.rows[name]
 if not row or row.ownedOwner~=owner then return true end
 local complete=self:Restore(name,owner)
 if complete then row.lastOwnedOwner=owner;row.ownedOwner=nil;row.ownedElement=nil;row.ownedElements=nil;row.acquireFailures=0 end
 return complete
end
function C:ReleaseOwner(owner)
 local complete=true
 for name,child in pairs(self.nativeChildren) do if child.owner==owner then complete=self:ReleaseOwned(owner,name) and complete end end
 for name,row in pairs(self.rows) do if row.ownedOwner==owner then complete=self:ReleaseOwned(owner,name) and complete end end
 return complete
end
function C:RetryOwned(owner)
 if S:InCombat() then return false end
 local pet=M.Rework and M.Rework.PetLayout
 if pet then pet:Retry(owner) end
 for _,row in pairs(self.rows) do if row.ownedOwner==owner or row.lastOwnedOwner==owner then
  row.failures=0;row.acquireFailures=0;row.playerHandbackAttempts=0;row.recoveryRequested=true;row.autoRecoveryAttempts=0
  -- Revalidate after the provider has returned its artwork/input journals.
  -- Suspend deliberately clears ownedOwner; lastOwnedOwner retains only the
  -- identity needed to find that completed inverse on this same native frame.
  if not row.active and not row.playerLease and row.recoveryBaseline then self:RevalidateRecovery(row,owner) end
 end end
 return true
end
-- A newly loaded native window can add its own internals without changing
-- any root this adapter owns. Record only the bounded named root identities;
-- live ownership/input validation remains in the ordinary current-row paths.
local lifecycleRoots
local function captureLifecycleRoots()
 local profile,rows,children=M.profile,C.rows,C.nativeChildren
 local names,values={},{}
 for _,item in ipairs(base) do names[item[1]]=true end
 for _,name in ipairs({"PartyFrame","CompactRaidFrameContainer","BossTargetFrameContainer",
  "BagsBar","MicroMenuContainer","MicroMenu"}) do names[name]=true end
 for name in pairs(rows) do names[name]=true end
 for name in pairs(children) do names[name]=true end
 for name in pairs(names) do
  local frame=rawget(_G,name)
  if not S:Readable(frame) then return nil end
  values[name]=frame
 end
 if M.ContextualNative~=C or C.rows~=rows or C.nativeChildren~=children or M.profile~=profile then return nil end
 return {profile=profile,rows=rows,children=children,names=names,values=values}
end
local function lifecycleUnchanged()
 local old,fresh=lifecycleRoots,captureLifecycleRoots()
 if not old or not fresh or old.profile~=fresh.profile or old.rows~=fresh.rows or old.children~=fresh.children then return false end
 for name in pairs(fresh.names) do if not old.names[name] or fresh.values[name]~=old.values[name] then return false end end
 for name in pairs(old.names) do if not fresh.names[name] then return false end end
 return true
end
function C:Configure()
 if self.configuring or S:InCombat() or editorState()=="UNKNOWN" then return end
 self.configuring=true
 local desired={}
 local function add(name,id)
  desired[name]=true
  local child=self.nativeChildren[name]
  if child and child.owner and child.owner.active then
   local _,why=self:NativeChildReady(child.owner,name);self.status[name]=why;return
  end
  local row=self.rows[name]
  if row and row.ownedOwner then return end
  if eligible(id) then self:Acquire(name,id) else self:Restore(name) end
 end
 local ok=pcall(function()
  for _,item in ipairs(base) do if _G[item[1]] or self.rows[item[1]] then add(item[1],item[2]) end end
  for name,row in pairs(self.rows) do if not desired[name] and not row.ownedOwner then self:Restore(name) end end
 end)
 self.configuring=nil
 if not ok then self.status.Adapter="CONFIGURE_PARTIAL"
 else lifecycleRoots=captureLifecycleRoots() end
end
-- Called by the suite's event router, never a second update driver. Presence
-- changes coalesce into one current-profile reconciliation outside combat.
function C:OnNativeLifecycle(event)
 if event~="ADDON_LOADED" and event~="PLAYER_ENTERING_WORLD" then return false end
 if event=="ADDON_LOADED" and lifecycleUnchanged() then
  self.unrelatedAddonSkips=(self.unrelatedAddonSkips or 0)+1;return false
 end
 local scheduler=M.RuntimeScheduler
 if not scheduler or type(scheduler.Request)~="function" then return false end
 local profile=M.profile
 scheduler:Request("native.context.lifecycle",function()
  if M.profile~=profile or M.ContextualNative~=C or editorState()~="CLOSED" then return end
  self:Configure();self:Update(M.Store:Snapshot(),S:Now())
  if M.DelegatedNative and M.DelegatedNative.Configure then M.DelegatedNative:Configure() end
 end,{owner="ContextualNative",combat="defer",guard=function() return M.profile==profile and M.ContextualNative==C end})
 return true
end
local function value(snapshot,key)
 local r=snapshot and snapshot[key]
 if r and r.status=="KNOWN" and r.decisionEligible==true and S:Readable(r.value) then return r.value end
end
-- Quiet is only the character's baseline. Local chat, native tasks, selection,
-- casting and input never turn it into a suite-wide reveal permission.
function C:QuietState(snapshot,now)
 if M.PresentationGroups and M.PresentationGroups:Enabled() then
  local state=M.PresentationGroups:State(snapshot,now)
  return state.idle,state.taxi and "FLIGHT_IDLE" or state.idle and "QUIET_IDLE" or "GROUP_ACTIVITY",state.deadline
 end
 local p=M.profile
 if not p or not p.managed or p.preset~="Immersive" then return nil,"UNMANAGED_CONTEXT" end
 now=now or S:Now()
 if self.quietProfile~=p then self.quietProfile=p;self.quietSince=nil;self.selectionUntil=0;self.threatUntil=0 end
 if M.ScopedActivity then M.ScopedActivity:Current(now) end
 for _,key in ipairs({"PLAYER_IN_COMBAT","PLAYER_MOVING"}) do
  local v=value(snapshot,key)
  if type(v)~="boolean" then self.quietSince=nil;return nil,"CONTEXT_UNKNOWN" end
  if v then self.quietSince=nil;return false,key=="PLAYER_MOVING" and "MOVING" or "COMBAT" end
 end
 if value(snapshot,"TEMP_REVEAL")==true or value(snapshot,"EDIT_MODE")==true then self.quietSince=nil;return false,"EXPLICIT_REVEAL" end
 self.quietSince=self.quietSince or now
 return true,"QUIET_IDLE",now
end
function C:Recipient(name,module)
 if name=="TargetFrame" then return "TARGET" end
 if name=="FocusFrame" then return "FOCUS" end
 if name=="PetFrame" then return "PET" end
 if name=="PlayerFrame" then return "PLAYER" end
 if name=="PartyFrame" or name=="CompactRaidFrameContainer" then return "GROUP" end
 if name=="BagsBar" or name=="MicroMenuContainer" or name=="MicroMenu" then return "LAUNCH" end
 if name=="StatusTrackingBarManager" or name=="MainStatusTrackingBarContainer" or name=="SecondaryStatusTrackingBarContainer" then return "PROGRESS" end
 return module=="PartyRaid" and "GROUP" or "COMBAT"
end
function C:HoverFrame(row)
 local surface=row and row.ownedElement and M.surfaces[row.ownedElement]
 if surface and surface.frame==row.frame and surface.reworkProvider==row.ownedOwner and S:Frame(surface.hoverFrame,false) then return surface.hoverFrame end
 return row and row.frame
end
function C:OcclusionFrame(row)
 local surface=row and row.ownedElement and M.surfaces[row.ownedElement]
 -- A native parent can retain its original rectangle while its children are
 -- laid out elsewhere. Only the current owner's explicit presentation bounds
 -- may replace that rectangle; stale/replaced surfaces cannot steer a gate.
 if surface and surface.frame==row.frame and surface.reworkProvider==row.ownedOwner and S:Frame(surface.occlusionFrame,false)
  and type(surface.occlusionFrame.GetRect)=="function" and type(surface.occlusionFrame.GetEffectiveScale)=="function" then return surface.occlusionFrame end
 return row and row.frame
end
function C:LocalHeld(name,module,snapshot,now)
 local activity=M.ScopedActivity
 if not activity then return nil end
 local recipient=self:Recipient(name,module)
 local held,reason,due=activity:Demand(recipient,snapshot,now)
 if recipient=="PROGRESS" and not held then held,reason,due=activity:Demand("STATUS",snapshot,now) end
 if name=="PetActionBar" and not held then
  local inspect,untilAt=activity:Inspect("pet",now)
  if inspect then held,reason,due=true,"LOCAL_PET_INSPECTION",untilAt end
 end
 return held,reason,due
end
function C:PrepareFade(row,profile,serial)
 if S:InCombat() or not M.Effects or not M.Effects.PrepareProtected then return false end
 local gate=row.gate
 local function owns()
  return source(row) and row.gate==gate and row.serial==serial and M.profile==profile
   and not row.cancelled and not row.pending and not row.ownerHandback
   and (not row.ownedOwner or row.ownedOwner.active==true)
 end
 if row.playerPresentation then
  local frame=row.frame
  local lease=row.playerLease;local ceiling=lease and lease.alpha
  local function alphaGuard()
   return owns() and row.frame==frame and _G[row.name]==frame and row.playerLease==lease and lease.alphaObserved==true and not lease.alphaForeign
  end
  local function settle(active,residue,receiptCurrent)
   local function current()
    return alphaGuard() and valid(row,profile,serial) and row.playerLease==lease and not lease.alphaForeign
     and type(receiptCurrent)=="function" and receiptCurrent()==true
   end
   if not current() then return false end
   local last=read(gate,"GetAttribute","number","mirage-player-alpha-last")
   if not current() then return false end
   local shown=read(gate,"GetAttribute","boolean","mirage-player-presented")
   if not current() then return false end
   local value=read(frame,"GetAlpha","number")
   if not current() or last~=active.to or shown~=active.shown or not S:Number(value) or math.abs(value-residue)>.00001 then return false end
   -- This completion request also owns an exact Effects receipt. Generic
   -- context validity alone cannot authorize it after a method/helper lookup
   -- has retired that visual record while retaining the native context.
   local okay,setter=pcall(function() return gate.SetAttribute end)
   if not okay or type(setter)~="function" or not current() then return false end
   local nativeMethod=M.Rework and M.Rework.NativeMethod
   local base
   if type(nativeMethod)=="function" then
    okay,base=pcall(nativeMethod,gate,"SetAttribute")
    if not okay or not current() then return false end
   end
   if not current() then return false end
   row.alphaCompletionRequests=(row.alphaCompletionRequests or 0)+1
   local accepted,result=pcall(base or setter,gate,"mirage-player-alpha-refresh",row.alphaCompletionRequests)
   if not current() then return false end
   if not accepted or result==false then row.alphaCompletionStatus="SECURE_ENDPOINT_REFRESH_REJECTED";return false end
   value=read(frame,"GetAlpha","number")
   if not current() then return false end
   local okay=S:Number(value) and math.abs(value-last)<=.00001
   row.alphaCompletionStatus=okay and "SECURE_ENDPOINT_VERIFIED" or "SECURE_ENDPOINT_REFRESH_UNCONFIRMED"
   return okay
  end
  gate.MiragePlayerPrepareFade=function(_,shown)
   if not owns() or row.frame~=frame then return end
   if M.Effects.BeforePresentationCommit then M.Effects:BeforePresentationCommit(row,frame,shown) end
  end
  gate.MiragePlayerFade=function(_,shown)
   if not owns() or row.frame~=frame then return end
   -- The secure program already committed base alpha and input together.
   -- Animation is visual only: no native Show/Hide or post-animation alpha
   -- setter may invalidate that journal or restart managed player/pet layout.
   local ok=M.Effects:TransitionProtected(row,frame,shown)
   if not ok and owns() then M.Effects:StopProtected(row,frame,shown and ceiling or 0) end
  end
  gate.MirageContextStopFade=function()
   local alpha=read(frame,"GetAlpha","number")
   M.Effects:StopProtected(row,frame,alpha)
  end
  row.fadePrepared=S:Number(ceiling) and M.Effects:PrepareProtected(row,frame,owns,ceiling,{presentationOnly=true,alphaGuard=alphaGuard,
   settle=settle,presentationLease=lease,presentationSerial=serial})==true
  request(row,profile,serial,gate,"SetAttribute","mirage-context-fade",row.fadePrepared==true)
  row.fadeProfile=profile;row.fadeSerial=serial
  return row.fadePrepared
 end
 gate.MirageContextFade=function(_,shown)
  if not owns() then return end
  local ok=M.Effects:TransitionProtected(row,gate,shown)
  if not ok and not S:InCombat() and owns() then gate:SetAlpha(1);gate:SetShown(shown) end
 end
 gate.MirageContextStopFade=function() M.Effects:StopProtected(row,gate) end
 gate.MirageContextHidden=function() M.Effects:ObserveProtectedHidden(row,gate) end
 row.fadePrepared=M.Effects:PrepareProtected(row,gate,owns)==true
 request(row,profile,serial,gate,"SetAttribute","mirage-context-fade",row.fadePrepared)
 row.fadeProfile=profile;row.fadeSerial=serial
 return row.fadePrepared
end
-- Shared ordinary holds for the managed cooldown gate and the fallback gate.
-- These inputs describe public context only; cooldown timers, charges, spell
-- identities and protected native child contents never authorize concealment.
local function explicitReveal(snapshot)
 return value(snapshot,"TEMP_REVEAL")==true or value(snapshot,"EDIT_MODE")==true
end
function C:CooldownHeld(name,snapshot,now,hoverUntil)
 local p=M.profile;local cfg=p and p.modules and p.modules.Cooldowns
 if not cooldowns[name] or not cfg or cfg.enabled~=true then return true end
 now=now or S:Now()
 if explicitReveal(snapshot) or (S:Number(hoverUntil) and hoverUntil>now) then return true end
 local settings=_G.CooldownViewerSettings
 if settings then
  local shown,status=read(settings,"IsShown","boolean")
  if status~="KNOWN" or shown==true then return true end
 end
 local preference=M.ElementRules and M.ElementRules:Preference("Cooldowns."..name,snapshot,p)
 if preference=="HIDE" or cfg.visibility=="Manual" then return false end
 if preference=="SHOW" or cfg.visibility=="Always" then return true end
 if p.managed and p.preset=="Immersive" then return self:LocalHeld(name,"Cooldowns",snapshot,now)~=false end
 return value(snapshot,"PLAYER_IN_COMBAT")~=false
end
function C:ControlHeld(name,snapshot,now,hoverUntil)
 local p=M.profile;local cfg=p and p.modules and p.modules.ActionBars
 if not controls[name] or not cfg or cfg.enabled~=true or cfg.contextual~=true or cfg.utilityContext~=true then return true end
 now=now or S:Now()
 if explicitReveal(snapshot) or (S:Number(hoverUntil) and hoverUntil>now) then return true end
 local preference=M.ElementRules and M.ElementRules:Preference("NativeControls."..name,snapshot,p)
 if preference=="HIDE" or cfg.visibility=="Manual" then return false end
 if preference=="SHOW" or cfg.visibility=="Always" then return true end
 if p.managed and p.preset=="Immersive" then return self:LocalHeld(name,"ActionBars",snapshot,now)~=false end
 return value(snapshot,"PLAYER_IN_COMBAT")~=false
end
function C:ObserveThreat(now)
 -- Threat is combat data for its own subject, never a post-combat global cue.
 self.threatUntil=0;self.nextThreat=nil
end
local function ownedPreference(row,context,profile)
 local rules=M.ElementRules
 if not rules then return nil end
 if row.ownedElements then
  -- A native roster container keeps all of its real member parents. One
  -- member's SHOW may hold that container open; one member's HIDE must never
  -- hide the other native members or make an empty unit exist.
  local allHidden=#row.ownedElements>0
  for _,element in ipairs(row.ownedElements) do
   local preference=rules:Preference(element,context,profile)
   if preference=="SHOW" then return "SHOW" end
   if preference~="HIDE" then allHidden=false end
  end
  return allHidden and "HIDE" or nil
 end
 return rules:Preference(row.ownedElement or ("NativeControls."..row.name),context,profile)
end
local function ownedDriver(row,profile)
 local cfg=profile.modules[row.module]
 local preference=ownedPreference(row,"Combat",profile)
 local combat=(cfg.visibility=="Manual" or preference=="HIDE") and "hide" or "show"
 if row.groupPresentation then combat="show" end -- native roster/pool input access floor; saved preferences are retained
 local recipient=C:Recipient(row.name,row.module)
 -- Navigation/progression and launch controls are not combat readouts. Secure
 -- ancestry retains its ordinary local hold rather than forcing combat Show.
 if (recipient=="PROGRESS" or recipient=="LAUNCH") and cfg.visibility~="Always" and cfg.visibility~="Manual"
  and preference~="SHOW" and preference~="HIDE" then combat="quiet" end
 if recipient=="PROGRESS" and profile.managed and profile.preset=="Immersive" then combat="hide" end
 local special=row.module=="ActionBars" and recipient~="PROGRESS" and recipient~="LAUNCH"
  and "[vehicleui] show; [overridebar] show; [possessbar] show; [petbattle] show; " or ""
 return special.."[combat] "..combat.."; quiet"
end
function C:DriverFor(row,profile)
 return ownedDriver(row,profile)
end
function C:OwnedPolicy(row,snapshot,now,show,uncertain)
 local profile=M.profile;local cfg=profile.modules[row.module]
 if M.state.keybindWorkspace or M.state.trackerWorkspace then
  -- The final quiet branch conceals preparation clutter. The secure combat
  -- branch remains live so unexpected combat immediately restores input.
  return false,false,ownedDriver(row,profile):gsub("; quiet$","; hide")
 end
 local preference=ownedPreference(row,snapshot,profile)
 local force=show==true
 local nativeMode=row.module=="ActionBars" and cfg.contextual~=true
 if row.name=="BagsBar" or row.name=="MicroMenuContainer" then nativeMode=nativeMode or cfg.utilityContext~=true end
 local interaction=(row.hoverUntil or 0)>now or row.inputHeld==true
 local held=interaction or nativeMode or preference=="SHOW" or (cfg.visibility=="Always" and preference~="HIDE")
 if profile.managed and profile.preset=="Immersive" then held=held or self:LocalHeld(row.name,row.module,snapshot,now)~=false end
 if preference=="HIDE" or cfg.visibility=="Manual" then held=interaction end
 if not interaction and not nativeMode and M.DisplayOcclusion and (held or force) then
  local blocked,reason=M.DisplayOcclusion:Blocks(self:OcclusionFrame(row),true)
  row.occlusionReason=blocked and reason or nil
  if blocked then held=false;force=false end
 else row.occlusionReason=nil end
 return held==true,force==true,ownedDriver(row,profile)
end
function C:PrimeOwned(owner,name)
 -- New passive cards are still hidden here. Publish them into the current
 -- ordinary context instead of exposing the acquisition's temporary access
 -- floor for one render frame. This uses the same policy and secure controller
 -- as later transitions; it is not a second startup visibility policy.
 if S:InCombat() or not M.Store then return false end
 if name=="PetFrame" then name="PlayerFrame" end
 local row=self.rows[name]
 if not row or row.ownedOwner~=owner or not row.active then return false end
 if row.primeGeneration==row.serial then return true end
 local profile,serial=M.profile,row.serial
 if not valid(row,profile,serial) then return false end
 if row.playerPresentation and not self:PlayerPresentationCurrent(row,true) then return false end
 local snapshot,now=M.Store:Snapshot(),S:Now()
 local held,force=self:OwnedPolicy(row,snapshot,now,explicitReveal(snapshot),value(snapshot,"PLAYER_IN_COMBAT")==nil)
 if not valid(row,profile,serial) then return false end
 local frame=row.playerPresentation and row.frame or row.gate
 if M.Effects and M.Effects.StopProtected then M.Effects:StopProtected(row,frame) end
 if not valid(row,profile,serial) or row.playerLease and row.playerLease.alphaForeign then return false end
 local fade=row.fadePrepared==true
 if row.playerPresentation and not request(row,profile,serial,row.gate,"SetAttribute","mirage-context-fade",false) then return false end
 if row.playerPresentation and not request(row,profile,serial,row.gate,"SetAttribute","mirage-player-committed",false) then return false end
 local okay=request(row,profile,serial,row.gate,"SetAttribute","mirage-force",force==true)
  and request(row,profile,serial,row.gate,"SetAttribute","mirage-held",held==true)
 if okay and row.playerPresentation then
  local revision=read(row.gate,"GetAttribute","number","mirage-player-refresh") or 0
  okay=request(row,profile,serial,row.gate,"SetAttribute","mirage-player-refresh",revision+1)
 end
 if not okay then return false end
 row.forced=force==true;row.held=held==true
 local state=read(row.gate,"GetAttribute","string","mirage-state")
 local emergency=read(row.gate,"GetAttribute","boolean","mirage-emergency")
 local shown=not ((state=="hide" or state=="quiet" and not held) and not force and emergency==false)
 if row.playerPresentation then
  okay=read(row.gate,"GetAttribute","boolean","mirage-player-presented")==shown
  local alpha=read(row.gate,"GetAttribute","number","mirage-player-alpha-last")
  if M.Effects and M.Effects.StopProtected then M.Effects:StopProtected(row,frame,alpha) end
  okay=request(row,profile,serial,row.gate,"SetAttribute","mirage-context-fade",fade) and okay
 else
  if M.Effects and M.Effects.StopProtected then M.Effects:StopProtected(row,frame,shown and 1 or 0) end
  okay=request(row,profile,serial,frame,"SetAlpha",shown and 1 or 0)
   and request(row,profile,serial,frame,shown and "Show" or "Hide") and okay
 end
 if okay and valid(row,profile,serial) then row.primeGeneration=serial;return true end
 return false
end
function C:Update(snapshot,now)
 if S:InCombat() or editorState()=="UNKNOWN" then return end -- no insecure native visibility mutations in combat
 if not M.Managed:Enabled() or M.Native:Conflict() then self:RestoreAll();return end
 now=now or S:Now();self:ObserveThreat(now)
 local show=explicitReveal(snapshot)
 -- Missing ordinary observations never grant a hide. Secure native conditions
 -- continue to reveal immediately when combat or special gameplay begins.
 local uncertain=value(snapshot,"PLAYER_IN_COMBAT")==nil
 for name,r in pairs(self.rows) do
  if r.pending then if (r.failures or 0)<3 then self:Restore(name) end
  elseif r.active and not r.contextTerminal then
   local groupRefresh=r.groupPresentation and (r.groupDirty or read(r.gate,"GetAttribute","boolean","mirage-group-pending")==true)
   local groupReady,groupReview=true,nil
   if groupRefresh then groupReady,groupReview=self:RefreshGroupPresentation(r) end
   local playerOwner=r.name=="PlayerFrame" and r.ownedOwner and M.Rework and r.ownedOwner==M.Rework.UnitFrames
    and r.ownedOwner.nativeBacked==true and r.ownedOwner.initialized==true
   local playerRefresh=playerOwner
    and (r.playerDirty or read(r.gate,"GetAttribute","boolean","mirage-group-pending")==true)
   local review=r.playerPresentation and not r.groupPresentation and (playerRefresh or now>=(r.playerNextReview or 0))
   if review then r.playerNextReview=now+1 end
   local presentationReady=true
   local reuseAudit=false
   if playerRefresh and review and playerOwner then
    -- The queued review already owns a full current census and validates
    -- again after clearing the secure pending flag. Do not run the same
    -- census and input audit twice before entering that transaction.
    local reviewStatus
    presentationReady,reviewStatus=self:SyncOwnedPlayerPresentation(r.ownedOwner,r.ownedElement)
    if reviewStatus=="PLAYER_INPUT_REVIEW_SUPERSEDED" then return end
   elseif r.playerPresentation and groupReview~="FRESH_RETAINED_REVIEW" then
    -- Unchanged context may reuse a recent descendant audit. Still check the
    -- root and secure flags on every observation. Any transition below must
    -- validate the full current tree before a visibility or input write.
    reuseAudit=not review and not groupRefresh and not r.playerDirty and not r.groupDirty
     and r.auditLease==r.playerLease and r.auditSerial==r.serial and r.auditRevision==r.inputTreeRevision
     and r.auditProfile==M.profile and r.auditDeadline and now<r.auditDeadline
    presentationReady=self:PlayerPresentationCurrent(r,review,reuseAudit)
    if not reuseAudit then
     if presentationReady then
      r.auditLease=r.playerLease;r.auditSerial=r.serial;r.auditRevision=r.inputTreeRevision
      r.auditProfile=M.profile;r.auditDeadline=now+.5
     else r.auditDeadline=nil end
    end
    if not presentationReady and review and playerOwner and self:PlayerPresentationCurrent(r,false) then
     local reviewStatus
     presentationReady,reviewStatus=self:SyncOwnedPlayerPresentation(r.ownedOwner,r.ownedElement)
     if reviewStatus=="PLAYER_INPUT_REVIEW_SUPERSEDED" then return end
    end
   end
   if not groupReady or not eligible(r.module,r) or _G[name]~=r.frame or read(r.frame,"GetParent")~=expectedParent(r)
    or not presentationReady then self:Restore(name)
   else
    local p=M.profile;local serial=r.serial
    if r.inputHeld then
     self:ReconcileInputHold(r,now)
     -- Public input getters can re-enter native callbacks. A changed lease or
     -- profile must restart the ordinary observation, not consume its snapshot.
     if not valid(r,p,serial) then return end
    end
    local cfg=p.modules[r.module]
    local visible=r.playerPresentation and read(r.gate,"GetAttribute","boolean","mirage-player-presented")==true
     or not r.playerPresentation and read(r.gate,"IsShown","boolean")==true
    local hoverFrame=self:HoverFrame(r)
    local actionHover=M.PresentationGroups and M.PresentationGroups.ActionOwnsHover
     and M.PresentationGroups:ActionOwnsHover(r)==true
    if actionHover then r.hoverUntil=nil
    elseif visible and read(hoverFrame,"IsMouseOver","boolean")==true
     and not (M.DisplayOcclusion and M.DisplayOcclusion:Blocks(hoverFrame,true)) then r.hoverUntil=now+.4 end
    if M.PresentationGroups and M.PresentationGroups:Enabled() then
     local hovered,due,suppressed=M.PresentationGroups:Hover(r,hoverFrame,now)
     if suppressed then r.hoverUntil=nil elseif hovered then r.hoverUntil=due end
    end
    local interaction=(r.hoverUntil or 0)>now or r.inputHeld==true
    local held,force,driver
    if r.ownedOwner then
     -- OwnedPolicy is the complete policy for an admitted native root. The
     -- fallback policy below used to observe the same local demand first,
     -- only to discard it; that doubled native hover/roster reads at exit.
     held,force,driver=self:OwnedPolicy(r,snapshot,now,show,uncertain)
    else
     local unit=units[name]
     local element=unit and ("UnitFrames."..unit) or (name=="BuffFrame" or name=="DebuffFrame") and ("Auras."..name) or name=="DamageMeter" and "DamageMeters.native" or cooldowns[name] and ("Cooldowns."..name) or ("NativeControls."..name)
     local preference=M.ElementRules and M.ElementRules:Preference(element,snapshot,p)
     held=show or preference=="SHOW" or (cfg.visibility=="Always" and preference~="HIDE") or interaction
     if p.managed and p.preset=="Immersive" then held=held or self:LocalHeld(name,r.module,snapshot,now)~=false end
     if not show and (preference=="HIDE" or cfg.visibility=="Manual") then held=interaction end
     force,driver=false,self:DriverFor(r,p)
     if cooldowns[name] then held=self:CooldownHeld(name,snapshot,now,r.hoverUntil)
     elseif controls[name] then held=self:ControlHeld(name,snapshot,now,r.hoverUntil) end
    end
    if M.state.keybindWorkspace or M.state.trackerWorkspace then held=false;force=false;driver=driver:gsub("; quiet$","; hide") end
    if not r.ownedOwner and not interaction and held and M.DisplayOcclusion then
     local blocked,reason=M.DisplayOcclusion:Blocks(r.frame,true)
     r.occlusionReason=blocked and reason or nil
     if blocked then held=false;force=false end
    end
    r.contextHover=interaction or (not held and r.contextHover) or false
    if r.navigationRecipient and M.PresentationGroups and M.PresentationGroups:Enabled()
     and M.PresentationGroups:Demand(r.navigationRecipient,snapshot,now)==true then r.contextHover=false end
    local gate=r.gate
    local stable=true
    if reuseAudit then
     local state=read(gate,"GetAttribute","string","mirage-state")
     local emergency=read(gate,"GetAttribute","boolean","mirage-emergency")
     local hide=(state=="hide" or state=="quiet" and not held) and not force and emergency==false
     local presented=read(gate,"GetAttribute","boolean","mirage-player-presented")
     if r.held~=(held==true) or r.forced~=(force==true) or r.driver~=driver or r.fadeProfile~=p
      or r.fadeSerial~=serial or r.navigationRecipient or presented~=(not hide)
      or r.playerDirty or r.groupDirty or r.auditLease~=r.playerLease or r.auditRevision~=r.inputTreeRevision then
      stable=self:PlayerPresentationCurrent(r,false) and valid(r,p,serial)
     end
    end
    if not stable then r.auditDeadline=nil;self:Restore(name)
    else
     if r.navigationRecipient and (held or force) then
      local provider=M.Rework and M.Rework.CombatAlerts
      local ready=provider and provider.PrepareProgressionReveal and provider:PrepareProgressionReveal()
      if not ready then held=false;force=false end
      if read(gate,"GetAttribute","boolean","mirage-layout-ready")~=(ready==true) and not request(r,p,serial,gate,"SetAttribute","mirage-layout-ready",ready==true) then held=false;force=false end
     end
     if r.fadeProfile~=p or r.fadeSerial~=serial then
      self:PrepareFade(r,p,serial)
      if not r.playerPresentation then
       request(r,p,serial,gate,"SetAttribute","_onstate-miragecontext",r.fadePrepared and self.fadeProgram or self.program)
      end
     end
     if driver~=r.driver then
      -- A rejected or unavailable driver cannot authorize concealment. Clear
      -- both state values so a same-state re-registration observes its callback.
      local prepared=request(r,p,serial,gate,"SetAttribute","mirage-live",false)
       and request(r,p,serial,gate,"SetAlpha",1) and request(r,p,serial,gate,"Show") and read(gate,"IsShown","boolean")==true
       and request(r,p,serial,gate,"SetAttribute","state-miragecontext",nil)
       and request(r,p,serial,gate,"SetAttribute","mirage-state",nil)
      local sent,result=false,nil
      if prepared and valid(r,p,serial) then sent,result=pcall(RegisterStateDriver,gate,"miragecontext",driver) end
      local observed=read(gate,"GetAttribute","string","mirage-state")
      if not sent or result==false or not valid(r,p,serial) or (observed~="quiet" and observed~="show" and observed~="hide") then
       r.pending=true;self:Restore(name);self.status[name]="CONTEXT_DRIVER_UNAVAILABLE"
      else
       r.driver=driver
       if not request(r,p,serial,gate,"SetAttribute","mirage-live",true) then r.pending=true;self:Restore(name) end
      end
     end
     local heldWritten=held==true
     local forceWritten=force==true
     local forceReady=r.active and ((r.forced==forceWritten and valid(r,p,serial)) or request(r,p,serial,gate,"SetAttribute","mirage-force",forceWritten))
     if forceReady then r.forced=forceWritten end
     if forceReady and ((r.held==heldWritten and valid(r,p,serial)) or request(r,p,serial,gate,"SetAttribute","mirage-held",heldWritten)) then
      r.held=heldWritten
      local state=read(gate,"GetAttribute","string","mirage-state")
      local emergency=read(gate,"GetAttribute","boolean","mirage-emergency")
      local hide=(state=="hide" or state=="quiet" and not held) and not force and emergency==false
      if r.navigationRecipient and emergency==false and (state=="hide"
       or read(gate,"GetAttribute","boolean","mirage-layout-ready")~=true) then hide=true end
      local shown=r.playerPresentation and read(gate,"GetAttribute","boolean","mirage-player-presented")
       or not r.playerPresentation and read(gate,"IsShown","boolean")
      local applied=(hide and shown==false or not hide and shown==true) and valid(r,p,serial)
      if r.playerPresentation then
       if not applied then
        local revision=read(gate,"GetAttribute","number","mirage-player-refresh") or 0
        applied=(not reuseAudit or self:PlayerPresentationCurrent(r,false)) and request(r,p,serial,gate,"SetAttribute","mirage-player-refresh",revision+1)
         and read(gate,"GetAttribute","boolean","mirage-player-presented")==not hide
         and self:PlayerPresentationCurrent(r,false)
       end
      elseif r.fadePrepared and valid(r,p,serial) then
       applied=M.Effects:TransitionProtected(r,gate,not hide)
      elseif not applied then applied=request(r,p,serial,gate,hide and "Hide" or "Show") end
      self.status[name]=applied and (hide and (r.occlusionReason or "QUIET") or "CONTEXT_VISIBLE") or "VISIBILITY_PENDING"
     end
    end
   end
  end
 end
end
local recoveryFadeProgram=[=[
for i=1,(self:GetAttribute("gate-count") or 0) do
 local gate=self:GetFrameRef("gate"..i)
 if gate and gate:GetAttribute("mirage-context-fade") then
  gate:CallMethod("MirageContextStopFade")
  gate:SetAlpha(1)
  gate:Show()
 end
end
]=]
function C:AppendRecovery()
 local button=N.recovery
 if not button or not N.recoveryPrepared or S:InCombat() then return end
 local count=read(button,"GetAttribute","number","gate-count") or 0
 if count<0 or count>128 or count%1~=0 then return end
 -- RecoveryButton just rebuilt its managed refs. GetFrameRef is a restricted
 -- snippet method, not a public Lua method; use the actual managed ledger.
 local seen={}
 for _,row in pairs(N.rows or {}) do if row.active and row.gate then seen[row.gate]=true end end
 for _,r in pairs(self.rows) do
  if r.active and r.gate and not seen[r.gate] and count<128 then
   count=count+1;button:SetFrameRef("gate"..count,r.gate);seen[r.gate]=true
  end
 end
 -- Extend the existing recovery action only for our own prepared gates. A
 -- previous native animation may have committed alpha0; Show alone cannot
 -- expose that gate. Stop playback before the secure alpha1 recovery commit.
 local program=read(button,"GetAttribute","string","_onclick")
 if program and program~=self.recoveryFadeProgram then
  self.recoveryBaseProgram=program;self.recoveryFadeProgram=program.."\n"..recoveryFadeProgram
 end
 if self.recoveryFadeProgram then button:SetAttribute("_onclick",self.recoveryFadeProgram) end
 button:SetAttribute("gate-count",count);button:Hide()
end
local function handbackTag(value)
 return type(value)=="string" and #value<=64 and value:match("^[A-Za-z_%-]+$") and value or "UNAVAILABLE"
end
local function handbackCount(value,limit)
 return type(value)=="number" and value==value and math.max(0,math.min(limit,math.floor(value))) or 0
end
local function handbackReceipt(receipt)
 if type(receipt)~="table" then return "NONE" end
 return handbackTag(receipt.phase).."/"..handbackTag(receipt.property).."/"..handbackTag(receipt.reason)
  .."/"..handbackCount(receipt.index,6144)
end
function C:HandbackReport(row)
 if not row or not row.playerPresentation then return nil end
 local lease=row.playerLease
 local input,markers=0,0
 if type(lease)=="table" then
  for i,node in ipairs(lease.nodes or {}) do
   if i>2048 then break end
   if lease.armed and node.click and not node.restored then input=input+1 end
  end
  for i,marker in ipairs(lease.groupMarkers or {}) do
   if i>6144 then break end
   if not marker.restored then markers=markers+1 end
  end
 end
 return "state="..handbackTag(row.handbackResult or "NOT_REQUESTED")
  ..";attempts="..handbackCount(row.handbackAttempts,9999)
  ..";current="..handbackReceipt(row.handbackCurrent)
  ..";first="..handbackReceipt(row.handbackFirst)..";last="..handbackReceipt(row.handbackLast)
  ..";lease="..(lease and "RETAINED" or "NONE")
  ..";input_pending="..input..";alpha_pending="..(lease and lease.armed and not lease.alphaRestored and "true" or "false")
  ..";markers_pending="..markers..";contested="..(row.contested and "true" or "false")
  ..";conflict="..handbackReceipt(row.handbackConflict)
end
function C:AcquisitionReport(row)
 if not row or not row.acquireResult then return nil end
 -- Export is a read of cached addon-owned tags only. It cannot probe a native
 -- property, change an input/alpha lease, or restart an exhausted retry budget.
 return "state="..handbackTag(row.acquireResult)
  ..";attempts="..handbackCount(row.acquireAttempts,9999)
  ..";refusals="..handbackCount(row.acquireFailures,9999)
  ..";budget_remaining="..math.max(0,3-handbackCount(row.acquireFailures,9999))
  ..";current="..handbackReceipt(row.acquireCurrent)
  ..";first="..handbackReceipt(row.acquireFirst)..";last="..handbackReceipt(row.acquireLast)
end
function C:Report()
 local lines={"native_context_scope=SECURE_COMBAT_SPECIAL_PLUS_SCOPED_LOCAL_DEMAND",
 "native_player_context=NATIVE_LIFETIME_ALPHA_AND_DECLARED_CLICK_INPUT",
 "native_group_context=NATIVE_LIFETIME_ALPHA_AND_DECLARED_CLICK_INPUT",
 "native_group_combat=NATIVE_INPUT_VISIBLE_COMBAT_HIDE_PREFERENCE_DEFERRED",
 "native_group_refresh=SOURCE_EVENT_INPUT_CENSUS_MAX_2048_VISIBLE_FALLBACK",
 "native_context_targeting=INDEPENDENT_3S_TARGET_FOCUS_INSPECTION_STALE_SUBJECT_QUIET",
 "native_context_occlusion=PUBLIC_OVERLAP_ONLY_COMBAT_ACCESS_FLOOR_RETAINED",
 "native_context_periodic_owner=CVE_WITH_MANAGED_FALLBACK",
 "native_context_input_review=EXACT_CURRENT_CENSUS_RETAINS_EXISTING_LEASE",
 "native_context_recovery=COMPLETED_OWNED_INPUT_BASELINES_THEN_FRESH_FULL_CENSUS",
 "native_context_alpha_observation=SECURE_ENDPOINT_OR_OWNED_ANIMATION_UNKNOWN_DISTINCT_FROM_FOREIGN_SETTER",
 "native_context_audit_scope=LIVE_ROOT_CHECKS_FULL_TREE_BEFORE_CHANGE_AND_EVERY_500MS",
 "native_context_audits="..(self.presentationAudits or 0)..";topology="..(self.topologyAudits or 0)..";input_nodes="..(self.inputNodesAudited or 0)..";paired_player_pet="..(self.sharedPlayerPetAudits or 0),
 "native_context_unrelated_addon_setups_skipped="..(self.unrelatedAddonSkips or 0),
 "native_context_duplicate_passes_skipped="..(self.observationSkips or 0),
 "native_context_fallback_passes="..(self.observationFallbacks or 0)}
 local names={};for name in pairs(self.status) do names[#names+1]=name end;table.sort(names)
 for _,name in ipairs(names) do
  lines[#lines+1]="context_native."..name.."="..self.status[name]
  local row=self.rows[name]
  if row and row.alphaObservation then lines[#lines+1]="context_alpha_observation."..name.."="..handbackTag(row.alphaObservation) end
  if row and row.alphaCompletionStatus then lines[#lines+1]="context_alpha_completion."..name.."="..handbackTag(row.alphaCompletionStatus)..";requests="..handbackCount(row.alphaCompletionRequests,9999) end
  if row and row.presentationFirst then
   local p=row.presentationFirst
   local function scalar(value) return S:Number(value) and string.format("%.5f",value) or "UNAVAILABLE" end
   lines[#lines+1]="context_first_failure."..name.."=reason="..handbackTag(p.reason)..";generation="..handbackCount(p.generation,999999)
    ..";local_alpha="..scalar(p.observed)..";effective_alpha="..scalar(p.effective)..";expected_alpha="..scalar(p.expected)
    ..";writer="..handbackTag(p.writer)..";animation="..handbackTag(p.animation)
  end
  if row and (row.contextTerminal or row.recoveryStatus) then
   lines[#lines+1]="context_recovery."..name.."=terminal="..(row.contextTerminal and "true" or "false")
    ..";state="..handbackTag(row.recoveryStatus or "EXTERNAL_OWNER_RETAINED")
    ..";generation="..handbackCount(row.recoveryGeneration,999999)..";automatic_attempts="..handbackCount(row.autoRecoveryAttempts,1)
    ..";input_blocker="..handbackReceipt(row.recoveryInput)..";unowned_census_nodes="..handbackCount(row.recoveryUnownedNodes,2048)
  end
  if row and row.managerState then lines[#lines+1]="context_manager."..name.."="..row.managerState end
  local handback=self:HandbackReport(row)
  if handback then lines[#lines+1]="context_handback."..name.."="..handback end
  local acquisition=self:AcquisitionReport(row)
  if acquisition then lines[#lines+1]="context_acquire."..name.."="..acquisition end
  if row and row.playerPresentation then
   lines[#lines+1]="context_input_review."..name.."=retained="..handbackCount(row.inputReviewsRetained,999999)
  end
  if row and row.inputHooks then
   lines[#lines+1]="context_input."..name.."=held="..(row.inputHeld and "true" or "false")
    ..";press="..(row.pressHeld and "true" or "false")..";drag="..(row.dragHeld and "true" or "false")
    ..";reconciled="..handbackCount(row.inputReleases,9999)..";last_release="..handbackTag(row.inputReleaseStatus or "NONE")
  end
 end
 return table.concat(lines,"\n")
end
-- Coordinate with the existing replacement owner, not a parallel replacement.
local release=N.ReleaseUnit
function N:ReleaseUnit(unit,current)
 for name,token in pairs(units) do if unit==token and not C:Restore(name) then return nil,"CONTEXT_RELEASE_PENDING" end end
 return release(self,unit,current)
end
local configure=N.Configure
function N:Configure()
 observationCycle=nil
 if editorState()=="UNKNOWN" then return end
 if not S:InCombat() then
  for name in pairs(units) do if not (C.rows[name] and C.rows[name].ownedOwner) then C:Restore(name) end end
 end
 local result=configure(self)
 C:Configure();C:Update(M.Store:Snapshot(),S:Now());if M.Managed:Enabled() then self:RecoveryButton() end
 return result
end
local recovery=N.RecoveryButton
function N:RecoveryButton() recovery(self);C:AppendRecovery() end
local tick=N.Tick
local function observationFresh(snapshot,now)
 local r=observationCycle
 if not M.Managed:Enabled() or M.Native:Conflict() or observationCycle~=r then return false end
 local state,profile,policy=M.state,M.profile,M.Policy
 if not r or not S:Number(now) or now<r.at or now-r.at>.25
  or M.ContextualNative~=C or M.ManagedNative~=N or M.Safety~=S
  or state~=r.state or profile~=r.profile or policy~=r.policy or M.Store~=r.store
  or M.CVE~=r.cve or M.CVE.Tick~=observationTick or C.Update~=r.update or C.rows~=r.rows
  or snapshot~=r.snapshot or state.forceEvaluate or state.safeCleanupPending
  or state.initialized~=true or state.world~=true or state.safe or not profile or profile.enabled~=true
  or not M.Client or M.Client.allowed~=true or state.settingsGeneration~=r.settings
  or policy.contextEpoch~=r.context or policy.scopeEpoch~=r.scope or policy.capabilityEpoch~=r.capability
  or policy.rulesetEpoch~=r.ruleset then return false end
 if M.cleanupModules and next(M.cleanupModules) then return false end
 for _,row in pairs(C.rows) do
  if row.pending and (row.failures or 0)<3 or not row.contextTerminal and (row.ownerHandback or row.groupDirty) then return false end
 end
 return true
end
function N:Tick()
 if editorState()=="UNKNOWN" then return end
 -- The managed and fallback visibility owners consume the same observation in
 -- this tick, so newly observed public threat cannot be delayed by call order.
 if not S:InCombat() and M.Managed:Enabled() and not M.Native:Conflict() then C:ObserveThreat(S:Now()) end
 tick(self)
 -- Configure follows explicit settings/native lifecycle events through the
 -- managed owner. A stable tick never reacquires every root once per second.

 local snapshot,now=M.Store:Snapshot(),S:Now()
 if observationFresh(snapshot,now) then C.observationSkips=math.min(999999,(C.observationSkips or 0)+1)
 else
  observationCycle=nil;C.observationFallbacks=math.min(999999,(C.observationFallbacks or 0)+1)
  C:Update(snapshot,now)
 end
end
local reset=N.ResetEmergency
function N:ResetEmergency()
 local result=reset(self);if S:InCombat() then return result end
 for _,r in pairs(C.rows) do
  if r.pending then C:Restore(r.name) end
  r.failures=0
  if r.active and S:Frame(r.gate,false) then r.gate:SetAttribute("mirage-emergency",false) end
 end
 return result
end
local restore=M.Native.Restore
function M.Native:Restore(module) C:RestoreAll(module);return restore(self,module) end
local cve=M.CVE.Tick
function M.CVE:Tick(immediate)
 observationSerial=observationSerial+1;local serial=observationSerial
 observationCycle=nil
 local state,profile,policy,store,update=M.state,M.profile,M.Policy,M.Store,C.Update
 local context,scope,capability,ruleset=policy.contextEpoch,policy.scopeEpoch,policy.capabilityEpoch,policy.rulesetEpoch
 local settings=state.settingsGeneration
 local snapshot
 local group=M.PresentationGroups
 local now=S:Now()
 local previousNow,previousProfile,previousToken,token,roster
 if group then
  previousNow,previousProfile,previousToken=group.cycleNow,group.cycleProfile,group.cycleToken
  token={};group.cycleToken=token
 end
 local ok,result=pcall(function()
  if group and group:Enabled() then
   group.cycleNow=now;group.cycleProfile=M.profile
   if group.BeginRosterCycle then roster=group:BeginRosterCycle(now) end
  end
  local queue=M.RuntimeScheduler
  local started=queue and queue.StageClock and queue:StageClock()
  local value=cve(self,immediate)
  local afterCVE=started and queue:StageClock()
  snapshot=M.Store:Snapshot();C:Update(snapshot,now)
  if started then
   queue:RecordObservationStage("CVE",started,afterCVE)
   queue:RecordObservationStage("NativeContext",afterCVE,queue:StageClock())
  end
  if group then
   group:FlushNavigation()
   if group.FlushCombat then group:FlushCombat() end
  end
  return value
 end)
 -- Native getters/setters may re-enter or fail. Retire only this invocation's
 -- roster sample and fade clock, even when the original failure propagates.
 if group then
  if roster then group:EndRosterCycle(roster) end
  if group.cycleToken==token then
   group.cycleNow=previousNow;group.cycleProfile=previousProfile;group.cycleToken=previousToken
  end
 end
 if not ok then error(result,0) end
 -- A completed, current synchronous cycle may suppress only a duplicate
 -- maintenance pass. Any changed scope, cleanup work, replaced implementation
 -- or paused/late observation uses the ordinary managed fallback instead.
 if observationSerial==serial and self==M.CVE and M.CVE.Tick==observationTick
  and M.state==state and M.profile==profile and M.Policy==policy and M.Store==store and C.Update==update
  and policy.contextEpoch==context and policy.scopeEpoch==scope and policy.capabilityEpoch==capability
  and policy.rulesetEpoch==ruleset and state.settingsGeneration==settings and S:Number(now) then
  observationCycle={at=now,state=state,profile=profile,policy=policy,store=store,cve=self,update=update,rows=C.rows,
   snapshot=snapshot,settings=settings,context=context,scope=scope,capability=capability,ruleset=ruleset}
 end
 return result
end
observationTick=M.CVE.Tick
