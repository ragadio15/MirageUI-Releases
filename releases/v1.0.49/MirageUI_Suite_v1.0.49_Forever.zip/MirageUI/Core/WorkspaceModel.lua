local _,M=...
-- One transactional model for both the main settings and the data element map.
-- Changes are detached authored preferences. No widget callback writes the live
-- profile or native layout. Publication uses the existing owned profile writer.
local W={historyLimit=20}
M.WorkspaceModel=W
local sessionChanged="The settings session changed. The current draft was retained."
local editBusy="A settings change is already being completed."
local function editingAllowed()
 local ok,allowed,message=pcall(M.Elements.EditingAllowed,M.Elements)
 if not ok then return false,"Editing availability could not be verified. Your draft was retained." end
 return allowed,message
end
local function completeOperation(self,operation,body,rollback)
 local good,accepted,message=pcall(body)
 if not good and rollback then pcall(rollback) end
 -- Never strand the editor in a busy state, and never release a successor's
 -- operation when an exceptional callback closed and reopened this session.
 if self.editOperation==operation then self.editOperation=nil end
 if not good then return false,"The settings operation could not finish. Saved preferences were retained; close and reopen settings before retrying." end
 return accepted,message
end
local function equal(a,b,depth)
 if type(a)~=type(b) then return false end
 if type(a)~="table" then return a==b end
 depth=(depth or 0)+1;if depth>24 then return false end
 for k,v in pairs(a) do if not equal(v,b[k],depth) then return false end end
 for k in pairs(b) do if a[k]==nil then return false end end
 return true
end
function W:Begin()
 if self.draft then return self:Current() end
 if not M.profile then return false,"Settings have not loaded." end
 self.session={}
 self.base=M.profile;self.profileOwner=M.Profiles;self.account=M.Profiles.account;self.character=M.Profiles.character
 self.scope=self.character and self.character.useCharacter
 self.baseSnapshot=M:Copy(M.profile)
 self.savedOwner=self.scope and self.character or self.account
 self.savedProfile=self.savedOwner and self.savedOwner.profile
 self.savedSnapshot=M:Copy(self.savedProfile)
 self.draft=M:Copy(M.profile);self.history={};self.dirty=false;self.context="All";self.selected=nil
 return true
end
function W:Current()
 if not self.draft or not self.baseSnapshot then return false,"Open settings before editing." end
 if M.Profiles~=self.profileOwner or M.profile~=self.base or M.Profiles.account~=self.account or M.Profiles.character~=self.character or (self.character and self.character.useCharacter)~=self.scope
  or (self.savedOwner and self.savedOwner.profile)~=self.savedProfile then
  return false,"The active profile changed. Your draft is retained; cancel it and reopen settings before saving."
 end
 -- Identity alone does not detect a slash command or another settings writer
 -- changing a nested field in place while this detached editor is open.
 if not equal(self.base,self.baseSnapshot) or not equal(self.savedProfile,self.savedSnapshot) then
  return false,"Saved settings changed while this draft was open. Your draft is retained; cancel it and reopen settings before saving."
 end
 return true
end
function W:Remember(before)
 -- Trim only after a real, completed edit. Failed/no-op gestures never evict
 -- the oldest undo record at the bounded-history limit.
 if not equal(self.draft,before) then
  self.history[#self.history+1]=before
  if #self.history>self.historyLimit then table.remove(self.history,1) end
 end
 self:Changed()
end
function W:Checkpoint()
 local ok,why=self:Current();if not ok then return false,why end
 return true,M:Copy(self.draft)
end
function W:Changed()
 self.dirty=self.draft~=nil and not equal(self.draft,self.baseSnapshot)
end
function W:Change(fn,checkpoint)
 if self.editOperation then return false,editBusy end
 local requestDraft=self.draft
 local ok,why=self:Current();if not ok then return false,why end
 if self.draft~=requestDraft then return false,sessionChanged end
 local session,operation=self.session,{};self.editOperation=operation
 local function owned() return self.session==session and self.editOperation==operation and self.draft==requestDraft and requestDraft~=nil end
 local function finish(result,message) if self.editOperation==operation then self.editOperation=nil end;return result,message end
 local before,history,dirty
 return completeOperation(self,operation,function()
 local combat=M.Safety:InCombat()
 if not owned() then return finish(false,sessionChanged) end
 if combat then return finish(false,"Changes are paused during combat.") end
 local editing,message=editingAllowed()
 if not owned() then return finish(false,sessionChanged) end
 if not editing then return finish(false,message) end
 local draft=self.draft
 before=M:Copy(draft)
 if not owned() or self.draft~=draft then return finish(false,sessionChanged) end
 history={};dirty=self.dirty
 for i,value in ipairs(self.history or {}) do history[i]=value end
 local good,result=pcall(fn,draft)
 -- A native getter or an apply callback may close/reopen settings. Only the
 -- session that started this operation may receive its rollback or history.
 if not owned() then return finish(false,sessionChanged) end
 local profileCurrent,reason=self:Current()
 if not owned() then return finish(false,sessionChanged) end
 editing,message=editingAllowed()
 if not owned() then return finish(false,sessionChanged) end
 if not good or result==false or not profileCurrent or not editing then
  self.draft=before;self:Changed()
  return finish(false,reason or message or "The change could not be staged. Previous preferences were retained.")
 end
 if checkpoint==false then self:Changed() else self:Remember(before) end
 return finish(true)
 end,function()
  if owned() and before then self.draft=before;self.history=history or self.history;self.dirty=dirty end
 end)
end
function W:Replace(profile)
 local ok,why=M.Profiles:CheckTransaction(profile);if not ok then return false,why end
 -- An explicit replacement changes the content of the admitted detached
 -- object. A reentrant callback replacing the object itself is never adopted
 -- by an older edit or overwritten by that edit's rollback.
 return self:Change(function(draft)
  local replacement=M:Copy(profile)
  for key in pairs(draft) do draft[key]=nil end
  for key,value in pairs(replacement) do draft[key]=value end
 end)
end
function W:Undo()
 if self.editOperation then return false,editBusy end
 local session=self.session
 if M.Safety:InCombat() then return false,"Undo after combat. Your draft is retained." end
 local editing,message=M.Elements:EditingAllowed();if not editing then return false,message end
 if self.session~=session then return false,sessionChanged end
 local ok,why=self:Current();if not ok then return false,why end
 local last=table.remove(self.history or {})
 if last then self.draft=last;self:Changed();return true end
 return false,"There is no earlier draft change."
end
function W:SetContext(context)
 if context~="All" and not M.ElementRules.contexts[context] then return false end
 self.context=context;return true
end
function W:SetVisibility(id,value)
 if self.context=="All" then return false,"Choose Idle, Moving or Combat first." end
 if value~="AUTO" and value~="SHOW" and value~="HIDE" then return false,"Unknown visibility choice." end
 local row=M.Elements:Get(id,self.draft)
 if not row then return false,"Unknown display." end
 if row.contextSupported==false then return false,row.contextNote end
 return self:Change(function(p)
  p.elementContexts[id]=p.elementContexts[id] or {}
  p.elementContexts[id][self.context]=value~="AUTO" and value or nil
  if not next(p.elementContexts[id]) then p.elementContexts[id]=nil end
 end)
end
-- Legacy fixed-slot controls transform the five member layouts. Rework groups
-- consume their own envelope and retain the old member preferences for fallback.
function W:GroupBounds(row,profile)
 if not row or row.kind~="group" then return nil end
 local group=tonumber(row.id:match("^PartyRaid%.group(%d+)$"))
 if not group or group<1 or group>8 then return nil end
 if M.Rework and M.Rework:Selected("groups",profile) and profile.layouts and profile.layouts[row.id] then
  return M.Layout:Get(row.surface or row,profile),nil
 end
 local cfg=profile.modules and profile.modules.PartyRaid
 if M.NativeGroups and M.NativeGroups.active and cfg and cfg.nativeGroups then return nil end
 local sw,sh=UIParent:GetWidth(),UIParent:GetHeight()
 if not M.Safety:Number(sw) or not M.Safety:Number(sh) or sw<=0 or sh<=0 then return nil end
 local left,right,bottom,top;local members={}
 for i=(group-1)*5+1,group*5 do
  local member=M.Elements:Get("PartyRaid.raid"..i,profile)
  if not member then return nil end
  local l=M.Elements:Layout(member,profile)
  if l.anchorTo then local x,y=M.Layout:Position(l.anchorTo,profile);l.x,l.y=l.x+x,l.y+y end
  local x,y=l.x*sw,l.y*sh;local hw,hh=l.width*l.scale/2,l.height*l.scale/2
  left=left and math.min(left,x-hw) or x-hw;right=right and math.max(right,x+hw) or x+hw
  bottom=bottom and math.min(bottom,y-hh) or y-hh;top=top and math.max(top,y+hh) or y+hh
  members[#members+1]={row=member,layout=l}
 end
 local authored=profile.layouts and profile.layouts[row.id];local scale=authored and authored.scale or 1
 return {x=(left+right)/2/sw,y=(bottom+top)/2/sh,width=(right-left)/scale,height=(top-bottom)/scale,scale=scale},members
end
function W:GroupTransform(row,p,target,source)
 -- The first authored rework envelope has the same semantics as later edits.
 -- Creating it must not resize or rewrite the five preserved member layouts.
 if row and row.kind=="group" and M.Rework and M.Rework:Selected("groups",p) then return false end
 local old,members=self:GroupBounds(row,source or p)
 if not old or not members then return false end
 local sw,sh=UIParent:GetWidth(),UIParent:GetHeight()
 local minW,maxW,minH,maxH,minS,maxS=0,math.huge,0,math.huge,0,math.huge
 for _,member in ipairs(members) do
  local l,s=member.layout,member.row.surface
  minW=math.max(minW,(s and s.minWidth or 24)/l.width);maxW=math.min(maxW,1200/l.width)
  minH=math.max(minH,(s and s.minHeight or 16)/l.height);maxH=math.min(maxH,800/l.height)
  minS=math.max(minS,.6/l.scale);maxS=math.min(maxS,1.6/l.scale)
 end
 local rx=math.max(minW,math.min(maxW,target.width/old.width))
 local ry=math.max(minH,math.min(maxH,target.height/old.height))
 local rs=math.max(minS,math.min(maxS,target.scale/old.scale))
 target.width,target.height,target.scale=old.width*rx,old.height*ry,old.scale*rs
 target.anchorTo=nil;M.Layout:Clamp(target)
 for _,member in ipairs(members) do
  local l=M:Copy(member.layout)
  l.x=target.x+(l.x-old.x)*rx*rs;l.y=target.y+(l.y-old.y)*ry*rs
  l.width=l.width*rx;l.height=l.height*ry;l.scale=l.scale*rs;l.anchorTo=nil
  p.layouts[member.row.id]=M.Layout:Clamp(l)
 end
 return true
end
function W:SetLayout(id,layout,checkpoint,source)
 local editing,message=M.Elements:EditingAllowed();if not editing then return false,message end
 local row=M.Elements:Get(id,self.draft)
 if not row or not row.editable then return false,row and row.provider.capabilityNote or "This entry has no shared placement consumer. Its settings remain available without a movable rectangle." end
 -- A retained drag is measured from its starting draft. A follower's center
 -- changes when its height changes, so compare locked axes to that same origin.
 local editProfile=source or self.draft
 local previous=(M.Elements.EditLayout or M.Elements.Layout)(M.Elements,row,editProfile)
 local surface=row.surface or row
 local compact=M.Layout.CompactViewport and M.Layout:CompactViewport(editProfile)
 local preserveSize=compact and M.Layout.CanFit and M.Layout:CanFit(surface)
 local original
 if compact and (preserveSize or row.sidebar=="MAP") then
  -- A displayed rectangle may be fitted to this screen. Keep its authored
  -- dimensions when a gesture changes only position or a different size axis.
  original=editProfile.layouts and editProfile.layouts[id]
  if not original then
   local owner=M.Rework and M.Rework:ProviderForLayout(id,editProfile)
   if owner and type(owner.object.AuthoredLayout)=="function" then original=owner.object:AuthoredLayout(surface,editProfile) end
   if not original and M.Layout.Unfitted then original=M.Layout:Unfitted(surface,editProfile) end
  end
  if original then original=M:Copy(original) end
 end
 local actionInterface=row.provider and row.provider.geometry=="actionInterface"
 local tooltipAnchor=id=="Tooltips.anchor"
 if row.provider and row.provider.geometry=='unitEnvelope' then
  -- A single width/height edit is a usable uniform resize. Keep the other
  -- dimension proportional instead of requiring a second slider adjustment
  -- before an aspect-fitted native control can grow.
  local widthChanged=layout.width~=previous.width;local heightChanged=layout.height~=previous.height
  if widthChanged~=heightChanged and M.Safety:Number(layout.width) and M.Safety:Number(layout.height) then
   layout=M:Copy(layout)
   local ratio=widthChanged and layout.width/previous.width or layout.height/previous.height
   ratio=math.max(24/previous.width,16/previous.height,math.min(1200/previous.width,800/previous.height,ratio))
   layout.width,layout.height=previous.width*ratio,previous.height*ratio
  end
 end
 if actionInterface then
  -- The action composition has one aspect ratio. A height slider edit must
  -- resize its width too, just as a width edit and a resize gesture do.
  if not M.Safety:Number(layout.width) or not M.Safety:Number(layout.height) then return false,"Choose a valid action interface size." end
  layout=M:Copy(layout)
  if layout.width==previous.width and layout.height~=previous.height then layout.width=previous.width*layout.height/previous.height end
  layout.width=math.max(row.minWidth or 240,math.min(row.maxWidth or 1200,layout.width))
  layout.height=layout.width*previous.height/previous.width
  layout.anchorTo=nil
 end
 if row.movable==false and (layout.x~=previous.x or layout.y~=previous.y or layout.anchorTo~=previous.anchorTo) then return false,"This display follows the minimap sidebar position. Move Minimap to place the column." end
 if row.resizeWidth==false and layout.width~=previous.width then return false,"This display follows the minimap sidebar width." end
 if row.resizeHeight==false and layout.height~=previous.height and not (row.sidebar=="MAP" and layout.height==layout.width) then return false,"The minimap remains square. Change its width to resize the sidebar." end
 if row.sidebar=="MAP" and (not M.Safety:Number(layout.width) or layout.width<row.minWidth or layout.width>row.maxWidth) then return false,"Sidebar width must be between "..row.minWidth.." and "..row.maxWidth.."." end
 if row.sidebar=="OBJECTIVES" and (not M.Safety:Number(layout.height) or layout.height<(row.minHeight or 160) or layout.height>800) then return false,"Choose an objective height between its current text-size minimum and 800." end
 if row.resizable==false and (layout.width~=previous.width or layout.height~=previous.height) then return false,"This provider supports position only; its runtime content determines its size." end
 if row.scalable==false and layout.scale~=previous.scale then return false,row.sidebar and "This display follows the minimap sidebar scale." or "This provider keeps its scale with the game; its saved scale is unchanged." end
 local refusal
 local function change(p)
  local l=M:Copy(layout);if not actionInterface then M.Layout:Clamp(l) end
  if tooltipAnchor then
   local cfg=p.modules.Tooltips
   cfg.tooltipScale=math.floor(math.max(70,math.min(160,l.scale*100))+.5)
   -- Moving is the user's explicit choice of a fixed anchor. A size-only edit
   -- retains cursor/default placement and leaves unrelated auto-layout alone.
   if layout.x~=previous.x or layout.y~=previous.y or layout.anchorTo~=previous.anchorTo then
    cfg.fixedAnchor=true;cfg.cursorAnchor=false
   end
   l.scale=1;p.layouts[id]=l
   return
  end
  if actionInterface and (layout.x~=previous.x or layout.y~=previous.y) then
   -- Moving the composition is an explicit opt-out from the bottom dock.
   -- Resizing alone keeps its lower edge attached to the screen.
   p.modules.ActionBars.interfaceDocked=false
  end
  local unitEnvelope=row.provider and row.provider.geometry=='unitEnvelope'
  if M.NativeLayout and not row.sidebar and not unitEnvelope and not actionInterface then
   local seeded,why=M.NativeLayout:SeedManualLayouts(p)
   if seeded==false and why then refusal=why;return false end
  end
  -- The sidebar has its own runtime layout authority. Editing its consumed
  -- fields must not seed legacy native map/tracker rectangles over preserved
  -- preferences, or disable responsive placement for unrelated controls.
  -- Whole native unit controls have an independent opt-in consumer, so their
  -- edits do not freeze or reseed the surrounding adaptive combat layout.
  if not row.sidebar and not unitEnvelope and not actionInterface then p.autoLayout=false end
  if row.kind=="hud" then
   local c=p.modules.UnderCharacterHUD
   c.x=math.floor(math.max(-500,math.min(500,l.x*UIParent:GetWidth()))+.5)
   c.y=math.floor(math.max(-360,math.min(-60,l.y*UIParent:GetHeight()))+.5)
   c.width=math.floor(math.max(160,math.min(300,l.width))+.5);c.hudScale=math.floor(math.max(75,math.min(150,l.scale*100))+.5)
  else
   local grouped=self:GroupTransform(row,p,l,source)
   -- Very widely separated fallback slots can span more than one legal native
   -- header rectangle. Their member layouts remain authoritative for the map.
   local saved=M:Copy(l)
   if preserveSize and original then
    if layout.width==previous.width then saved.width=original.width end
    if layout.height==previous.height then saved.height=original.height end
    if layout.scale==previous.scale then saved.scale=original.scale end
   end
   if row.sidebar=="OBJECTIVES" then
    -- Height is the only authored field this follower consumes. Retain older
    -- independent geometry for rollback instead of replacing it with a preview.
    saved=M:Copy(p.layouts[id] or previous);saved.height=l.height
   elseif row.sidebar=="MAP" then
    saved=M:Copy(p.layouts[id] or original or previous)
    if layout.x~=previous.x or layout.y~=previous.y or layout.anchorTo~=previous.anchorTo then saved.x,saved.y,saved.anchorTo=l.x,l.y,l.anchorTo end
    if l.width~=previous.width then saved.width,saved.height=l.width,l.width end
    if l.scale~=previous.scale then saved.scale=l.scale end
   end
   if grouped then saved.width=math.min(1200,saved.width);saved.height=math.min(800,saved.height) end
   local layoutID=id
   local owner=M.Rework and M.Rework:ProviderForLayout(id,p)
   if owner and type(owner.object.LayoutKey)=="function" then layoutID=owner.object:LayoutKey(id) end
   p.layouts[layoutID]=saved
   if actionInterface then
    -- Clamp the authored center with the fitted *display* footprint. Saving
    -- its effective scale would apply screen fitting again on every move.
    local shown=M.ActionInterface:Metrics(p)
    saved.x,saved.y=shown.x,shown.y
   end
   if row.kind=="nativePosition" and M.NativeLayout:RequiresMoveOption(row.id) then
    if row.module=="QuestTracker" and row.sidebar~="OBJECTIVES" then p.modules.QuestTracker.matchMinimap=false end
   end
  end
 end
 local ok,why=self:Change(change,checkpoint);return ok,refusal or why
end
function W:Apply()
 if self.editOperation then return false,editBusy end
 local ok,why=self:Current();if not ok then return false,why end
 local session,operation=self.session,{};self.editOperation=operation
 local function owned() return self.session==session and self.editOperation==operation and self.draft~=nil end
 local function finish(result,message) if self.editOperation==operation then self.editOperation=nil end;return result,message end
 return completeOperation(self,operation,function()
 local combat=M.Safety:InCombat()
 if not owned() then return finish(false,sessionChanged) end
 if combat then return finish(false,"Apply after combat. Your draft is retained.") end
 local editing,message=editingAllowed()
 if not owned() then return finish(false,sessionChanged) end
 if not editing then return finish(false,message) end
 local valid,reason=M.Profiles:CheckTransaction(self.draft)
 if not owned() then return finish(false,sessionChanged) end
 if not valid then return finish(false,reason) end
 ok,why=self:Current();if not ok then return finish(false,why) end
 local accepted,message=M.Profiles:Commit(self.draft,false,"PROFILE_COMMIT")
 if not owned() then return finish(false,sessionChanged) end
 if not accepted then return finish(false,message or "The application failed; the draft and original diagnostic are retained.") end
 -- Build the next detached session view before publishing any of its fields.
 -- A post-commit diagnostic/copy failure cannot partially replace the draft.
 local base,profileOwner=M.profile,M.Profiles
 local account,character=profileOwner.account,profileOwner.character
 local scope=character and character.useCharacter;local savedOwner=scope and character or account
 local savedProfile=savedOwner and savedOwner.profile
 local baseSnapshot,savedSnapshot,draft=M:Copy(base),M:Copy(savedProfile),M:Copy(base)
 local state=M.Diagnostics:ActivationState()
 if not owned() or M.profile~=base or M.Profiles~=profileOwner or profileOwner.account~=account
  or profileOwner.character~=character or (character and character.useCharacter)~=scope
  or (savedOwner and savedOwner.profile)~=savedProfile then return finish(false,sessionChanged) end
 self.base=base;self.baseSnapshot=baseSnapshot;self.profileOwner=profileOwner;self.account=account;self.character=character
 self.scope=scope;self.savedOwner=savedOwner;self.savedProfile=savedProfile;self.savedSnapshot=savedSnapshot
 self.draft=draft;self.history={};self.dirty=false
 return finish(true,state.code=="RUNNING" and "Applied. Your shared layout and context preferences are saved." or "Preferences saved. "..state.message)
 end)
end
function W:Discard()
 self.session=nil;self.editOperation=nil
 self.draft=nil;self.base=nil;self.baseSnapshot=nil;self.savedOwner=nil;self.savedProfile=nil;self.savedSnapshot=nil;self.history={};self.dirty=false;self.selected=nil
end
-- Legacy callers receive a clear boundary, never a borrowed standalone profile.
function W:Cursor()
 return nil,"Cursor Companion is a standalone addon. Open /cc for its settings."
end
