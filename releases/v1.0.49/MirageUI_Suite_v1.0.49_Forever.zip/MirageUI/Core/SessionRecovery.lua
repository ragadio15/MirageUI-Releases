local _,M=...
-- PLAYER_ENTERING_WORLD already activates the saved profile. Follow that
-- transaction with one bounded, quiet provider-recovery sweep after native
-- startup has settled. Healthy displays keep their current owners; no second
-- whole-profile apply, settings commit or slash-command execution is needed.
local S=M.Safety
local P={status="NOT_STARTED",reason="NOT_STARTED",attempts=0,waits=0,selected=0}
M.SessionRecovery=P
local key="Core.SessionRecovery"
local function code(value)
 return S:Text(value) and #value<=96 and value:match("^[A-Z][A-Z0-9_]*$") and value or "UNAVAILABLE"
end
function P:Cancel(reason,ticket)
 if not self.ticket or ticket and self.ticket~=ticket then return end
 local queue=self.ticket.queue
 self.ticket=nil;self.status="CANCELLED";self.reason=code(reason or "OWNER_CHANGED")
 if queue then queue:Cancel(key) end
end
function P:Current(ticket)
 return self.ticket==ticket and M.state==ticket.state and M.profile==ticket.profile
  and M.Profiles==ticket.profiles and M.db==ticket.db and M.modules==ticket.modules
  and M.Rework==ticket.rework and M.Client==ticket.client
  and M.RuntimeScheduler==ticket.queue
  and ticket.profiles.account==ticket.account and ticket.profiles.character==ticket.character
end
function P:Allowed(ticket)
 if not self:Current(ticket) then return false,"OWNER_CHANGED" end
 local state,profile,profiles,rework,client=ticket.state,ticket.profile,ticket.profiles,ticket.rework,ticket.client
 if not state.initialized or not state.world then return false,"WORLD_UNAVAILABLE" end
 if state.safe or state.safeCleanupPending or not profile.enabled then return false,"SAVED_STOP_RETAINED" end
 if profiles.readOnly or client.allowed~=true or not rework.storageReady or rework.rolledBack or rework.rollbackPendingReload then
  return false,"ADMISSION_UNAVAILABLE"
 end
 if (rework.nativeBlocksThisSession or 0)>0 then return false,"NATIVE_BLOCK_RETAINED" end
 return true
end
function P:Finish(ticket,status,reason)
 if not self:Current(ticket) then self:Cancel("OWNER_CHANGED",ticket);return end
 self.ticket=nil;self.status=status;self.reason=code(reason)
end
function P:Queue(ticket,delay)
 if not self:Current(ticket) then self:Cancel("OWNER_CHANGED",ticket);return false end
 local queue=M.RuntimeScheduler
 if not queue or queue~=ticket.queue then self:Cancel("SCHEDULER_UNAVAILABLE",ticket);return false end
 local accepted=queue:Request(key,ticket.run,{combat="defer",generation=false,delay=delay,
  priority=4,owner="Core",guard=ticket.guard})
 if not accepted then self:Finish(ticket,"FAILED","QUEUE_UNAVAILABLE") end
 return accepted
end
local function needsRecovery(row)
 return row and (row.failed or row.state=="RECOVERY" or row.pending or row.configureBlocked
  or row.readiness=="FAULT" or row.readiness=="CONFLICT" or row.readiness=="PARTIAL") or false
end
function P:WaitForStartup(ticket,why)
 if self.waits>=12 then self:Finish(ticket,"DEFERRED","STARTUP_NOT_SETTLED");return end
 self.waits=self.waits+1;self.status="WAITING";self.reason=why
 -- Native families can appear several seconds after world entry. Back off
 -- within one finite budget instead of declaring a healthy session before
 -- queued configuration has run, or polling startup every frame.
 self:Queue(ticket,math.min(1,.25*2^(self.waits-1)))
end
local function pendingStartup(rework,queue)
 for _,id in ipairs(rework.order or {}) do
  local row=rework.providers[id]
  if row and rework:Selected(id) and not needsRecovery(row) then
   if rework.pendingConfigure or rework.pendingProviders and rework.pendingProviders[id]
    or row.configurePending or row.state=="PREPARING"
    or queue.jobs and queue.jobs["Rework.Configure."..id] then
    return "PROVIDER_CONFIGURATION_QUEUED"
   end
   if id=="main" and row.started and row.state=="ACTIVE" then
    local action=row.object
    if action.familyPreparing or action.nativeDirty or action.pendingDisable or action.runtimeStopReason
     or row.readinessReason=="ACTION_FAMILIES_PREPARING" then
     return "ACTION_STARTUP_RECONCILING"
    end
   end
  end
 end
end
function P:Run(ticket)
 local allowed,why=self:Allowed(ticket)
 if not allowed then self:Cancel(why,ticket);return end
 if S:InCombat() then self.status="WAITING";self.reason="COMBAT_DEFERRED";self:Queue(ticket,.25);return end
 local rework=ticket.rework
 local editor=rework:NativeEditState()
 allowed,why=self:Allowed(ticket)
 if not allowed then self:Cancel(why,ticket);return end
 local families=rework.ActionFamilies
 local busy=M.applying or ticket.state.applyPending or rework.configuring or editor~="CLOSED"
  or families and families.preparing
 if busy then self:WaitForStartup(ticket,editor~="CLOSED" and "NATIVE_EDIT_DEFERRED" or "STARTUP_SETTLING");return end
 local queued=pendingStartup(rework,ticket.queue)
 if queued then self:WaitForStartup(ticket,queued);return end
 local main=rework.providers.main
 if main and main.started and main.state=="ACTIVE" and not needsRecovery(main)
  and rework:Selected("main") and type(main.object.Tick)=="function" then
  if self.settledMain~=main then
   self.settledMain=main;self.settledMainTicks=main.runtimeTicks or 0
   self:WaitForStartup(ticket,"ACTION_STARTUP_OBSERVING");return
  end
  if (main.runtimeTicks or 0)==self.settledMainTicks
   and (ticket.queue.jobs and ticket.queue.jobs["Rework.Tick.main"] or rework:NeedsProviderTick(main,S:Now())) then
   self:WaitForStartup(ticket,"ACTION_STARTUP_RECONCILING");return
  end
 end
 local selected=0
 for _,id in ipairs(rework.order or {}) do
  if needsRecovery(rework.providers[id]) then selected=selected+1 end
 end
 self.selected=selected
 if selected==0 then self:Finish(ticket,"COMPLETE","NO_RECOVERY_NEEDED");return end
 allowed,why=self:Allowed(ticket)
 if not allowed then self:Cancel(why,ticket);return end
 -- Retry is the same provider cleanup/retry/queue path used by /mirage recover.
 -- It selects only unhealthy displays and retains every unresolved inverse.
 self.attempts=self.attempts+1;self.status="RUNNING";self.reason="RECOVER_SELECTED_DISPLAYS"
 local okay,ready,reason=pcall(rework.Retry,rework)
 if not self:Current(ticket) then self:Cancel("OWNER_CHANGED",ticket);return end
 allowed,why=self:Allowed(ticket)
 if not allowed then self:Cancel(why,ticket);return end
 if okay and ready==true then self:Finish(ticket,"COMPLETE","RECOVERY_QUEUED");return end
 local pending=false
 for _,id in ipairs(rework.order or {}) do
  local row=rework.providers[id]
  if needsRecovery(row) and (row.pending or row.object and row.object.pendingDisable) then pending=true;break end
 end
 if okay and pending and self.attempts<3 then
  self.status="WAITING";self.reason="NATIVE_RESTORE_PENDING";self:Queue(ticket,self.attempts*.5);return
 end
 self:Finish(ticket,"FAILED",okay and reason or "RECOVERY_CALLBACK_FAILED")
end
function P:Begin()
 if self.started then return end
 self.started=true
 local state,profile,profiles,rework,client=M.state,M.profile,M.Profiles,M.Rework,M.Client
 if not state or not profile or not profiles or not rework or not client or type(rework.Retry)~="function" then
  self.status="SKIPPED";self.reason="STARTUP_UNAVAILABLE";return
 end
 local ticket={state=state,profile=profile,profiles=profiles,db=M.db,modules=M.modules,rework=rework,client=client,
  account=profiles.account,character=profiles.character,queue=M.RuntimeScheduler}
 self.ticket=ticket
 local allowed,why=self:Allowed(ticket)
 if not allowed then self:Finish(ticket,"SKIPPED",why);return end
 ticket.guard=function()
  if not P:Current(ticket) then P:Cancel("OWNER_CHANGED",ticket);return false end
  return true
 end
 ticket.run=function()
  local ok=pcall(P.Run,P,ticket)
  if not ok and P:Current(ticket) then P:Finish(ticket,"FAILED","RECOVERY_CALLBACK_FAILED") end
 end
 self.status="WAITING";self.reason="SAVED_CHOICES_ACTIVATED"
 self:Queue(ticket,.75)
end
function P:Report()
 return "startup_recovery="..code(self.status).."; reason="..code(self.reason).."; attempts="..self.attempts
  .."/3; settle_checks="..self.waits.."/12; selected_displays="..self.selected
  .."; settle_backoff=250_500_1000_MS; activation=SAVED_WORLD_PROFILE; recovery=UNHEALTHY_PROVIDERS_ONLY; repeat=ONCE_PER_UI_SESSION"
end

local event=M.Event
function M:Event(name,...)
 if name=="PLAYER_LEAVING_WORLD" or name=="PLAYER_LOGOUT" then P:Cancel("WORLD_LEFT") end
 local a,b=event(self,name,...)
 if name=="PLAYER_ENTERING_WORLD" and self.state.initialized then P:Begin() end
 return a,b
end
-- A subsequent player decision retires the pending automatic transaction.
-- These wrappers do not change the semantics of the original manual routes.
local apply=M.ApplyProfile
function M:ApplyProfile(force,trigger,...)
 if trigger~="WORLD_ENTERED" and trigger~="COMBAT_ENDED" then P:Cancel("NEW_CONFIGURATION") end
 return apply(self,force,trigger,...)
end
local recover=M.Recover
function M:Recover(...) P:Cancel("MANUAL_RECOVERY");return recover(self,...) end
local safe=M.SafeMode
function M:SafeMode(...) P:Cancel("SAVED_STOP_RETAINED");return safe(self,...) end
if M.Experience and M.Experience.ResumeChoices then
 local activate=M.Experience.ResumeChoices
 function M.Experience:ResumeChoices(...) P:Cancel("MANUAL_ACTIVATION");return activate(self,...) end
end
if M.StartupPresentation and M.StartupPresentation.Report then
 local report=M.StartupPresentation.Report
 function M.StartupPresentation:Report(...) return report(self,...).."\n"..P:Report() end
end
