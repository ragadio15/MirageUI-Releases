local _,M=...
-- Read-only reconciliation; no SetCVar, binding, third-party profile or native
-- visibility writes. A configured choice is not proof of native availability.
M.IntegrationReview={}
local I,S=M.IntegrationReview,M.Safety
function I:Inspect(profile)
 local p=profile or M.profile;local rows={}
 local function add(id,state,text) rows[#rows+1]={id=id,state=state,text=text} end
 local fn=C_CVar and C_CVar.GetCVar or GetCVar
 local prd,status=S:Public(fn,"string","nameplateShowSelf")
 if status=="KNOWN" and (prd=="0" or prd=="1") then
  add("PRD",prd=="1" and "ON" or "OFF",prd=="1" and "Blizzard Personal Resource Display is on. A selected Mirage HUD can duplicate it; change Blizzard's setting yourself only after HUD validation." or "Blizzard Personal Resource Display is off. MirageUI has not changed it.")
 else add("PRD","UNKNOWN","Blizzard Personal Resource Display could not be read. Check it manually; unknown does not mean off.") end
 if M.Native:Conflict() then add("UI_OWNER","CONFLICT","Another UI suite owns overlapping surfaces. MirageUI yields; keep the other addon's files and settings.")
 else add("UI_OWNER","NO_KNOWN_CONFLICT","No known total-UI owner detected. This is not an exhaustive conflict test.") end
 if S:Loaded("CursorCompanion") then add("CURSOR","STANDALONE","Cursor Companion is active as an independent suite addon. Its settings and shortcuts remain under /cc.")
 else add("CURSOR","OPTIONAL","Cursor Companion is optional. Enable its separate addon for cursor effects and the Quick Menu.") end
 if p and p.modules then
  if p.modules.UnderCharacterHUD.enabled and p.modules.ResourceBars.enabled then add("PLAYER_DUPLICATES","REVIEW","HUD and Resources are both enabled. Select a primary display below or deliberately allow mirrors.") end
  if p.modules.UnitFrames.enabled then add("SECURE_MIRROR","RETAINED","The optional player unit button retains health and secure actions even when another passive display is primary.") end
  if p.modules.Cooldowns.tracker then add("COOLDOWNS","REVIEW","Selected spell timers supplement the native Cooldown Manager. Review duplicated spells manually; native providers remain enabled.") end
  if p.modules.DamageMeters.summary then add("METER","REVIEW","The Mirage damage/healing summary uses native session data. Avoid two permanent primary meter panels.") end
  if p.modules.Nameplates.cards then add("NAMEPLATES","CANDIDATE","Independent cards replace only eligible native artwork. Native targeting, critical cues and restricted-plate fallback must remain available.") end
  if p.modules.Tooltips.cursorAnchor then add("TOOLTIPS","REVIEW","Cursor-right placement is out of combat and requires native screen clamping. Native comparison/owner placement and combat visibility remain authoritative.")
  elseif p.modules.Tooltips.fixedAnchor then add("TOOLTIPS","REVIEW","The fixed anchor applies to eligible default world tooltips; owned/compare tooltips stay native.") end
 end
 add("SPECIAL_ACTIONS","RETAINED","Keep native pet, stance, vehicle, possess, override and extra-action controls. Mirage's regular action buttons are supplementary.")
 add("NATIVE_SETTINGS","UNCHANGED","Native Edit Mode, PRD, cooldowns, combat text, alerts, click casting and gamepad settings stay under your control. Profile Undo does not restore separately changed native bindings.")
 return rows
end
function I:Report(profile)
 local lines={"Native settings and display ownership","Read-only review; no native settings changed."}
 for _,r in ipairs(self:Inspect(profile)) do lines[#lines+1]=r.id.." ["..r.state.."]: "..r.text end
 lines[#lines+1]="\n"..M.Presentation:Report(profile)
 return table.concat(lines,"\n")
end
