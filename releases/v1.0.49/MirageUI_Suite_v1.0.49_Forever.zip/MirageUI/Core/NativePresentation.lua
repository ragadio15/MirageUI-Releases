local _,M=...
-- Passive Mirage artwork on qualified original native controls. The original
-- controls still own clicks, keybindings, action paging, cooldowns and progress.
-- No script, event or action attribute is replaced. Utility tiles retain the
-- original identifying icons/portrait and native hover, pressed, disabled,
-- tooltip, count and alert channels. Those stateful pixels are never leased.
local S,N=M.Safety,M.ManagedNative
local P={status={},details={}};M.NativePresentation=P
local skins=setmetatable({},{__mode="k"})
local owners=setmetatable({},{__mode="k"})
local reviewedClient=M.Client.RuntimeAvailable or M.Client.IsReviewedPresentationClient
local function exactClient()
 local c=M.Client
 return c and c.allowed==true and type(reviewedClient)=="function" and reviewedClient(c) and S:BoundaryReady() or false
end
local function read(object,key,kind,...)
 if not S:Readable(object) or not object then return nil end
 local value,status=S:Public(S:Field(object,key),kind,object,...)
 if status=="KNOWN" then return value end
end
local function inRoot(object,root)
 local node,seen=object,{}
 for _=1,12 do
  if not S:Frame(node,false) or seen[node] then return false end
  if node==root then return true end
  seen[node]=true;node=read(node,"GetParent")
 end
 return false
end
local function eligible(row,profile)
 return exactClient() and M.NativePresentation==P and M.ManagedNative==N and M.Safety==S and M.profile==profile
  and row and N.rows[row.name]==row and _G[row.name]==row.frame and row.active and not row.failed and not row.restorePending and not row.contested
  and (row.module=="ActionBars" or row.name=="PlayerCastingBarFrame") and M.Managed:Enabled() and M:IsModuleActive(row.module)
  and M:ModuleConfig(row.module).style==true and not M.Native:Conflict() and not S:InCombat() and N:Usable(row.frame)==true
  and M.profile==profile and N.rows[row.name]==row and _G[row.name]==row.frame and not S:InCombat()
end
local function hideSkin(skin)
 skin.pending=true;if skin.row then skin.row.presentationPending=true end
 if S:InCombat() then return false end
 local complete=true
 for _,texture in ipairs(skin.textures) do
  local hide=S:Field(texture,"Hide")
  if S:InCombat() or not S:Frame(texture,false) or type(hide)~="function" or S:InCombat() then complete=false
  else
   local sent=pcall(hide,texture)
   local shown=read(texture,"IsShown","boolean")
   if not sent or shown~=false then complete=false end
  end
 end
 skin.pending=not complete or nil
 skin.failures=complete and 0 or (skin.failures or 0)+1
 if complete then skin.active=false end
 return complete
end
function P:Restore(row,retryConstruction)
 local complete=true
 if M.StyleLease then
  M.StyleLease:Restore(row)
  for _,receipt in ipairs(M.StyleLease.rows) do if receipt.owner==row then complete=false;break end end
 end
 for _,skin in ipairs(owners[row] or {}) do
  if skin.row==row then complete=hideSkin(skin) and complete end
 end
 -- Only explicit recovery opens a fresh construction budget, and only after
 -- every receipt and allocated texture has completed its native handback.
 if complete and retryConstruction then
  for _,skin in ipairs(owners[row] or {}) do if skin.row==row and not skin.ready then skin.buildAttempts=0 end end
 end
 self.status[row.name]=complete and "NATIVE_PRESENTATION_RELEASED" or "NATIVE_PRESENTATION_RELEASE_PENDING"
 if self.details[row.name] then self.details[row.name].complete=false end
 row.presentationPending=not complete or nil
 return complete
end
function P:Pending()
 for _,list in pairs(owners) do for _,skin in ipairs(list) do if skin.pending then return true end end end
 return false
end
function P:RestoreAll()
 local complete=true
 for row in pairs(owners) do complete=self:Restore(row) and complete end
 return complete
end
function P:Retry(now)
 if S:InCombat() then return end
 now=now or S:Now()
 for row,list in pairs(owners) do
  local pending=false
  for _,skin in ipairs(list) do
   if skin.row==row and skin.pending then
    if (skin.failures or 0)>=3 then self.status[row.name]="NATIVE_PRESENTATION_RELOAD_REQUIRED"
    elseif (skin.nextAttempt or 0)<=now then skin.nextAttempt=now+.5;hideSkin(skin) end
    if skin.pending then pending=true end
   end
  end
  row.presentationPending=pending or nil
 end
end
local function skinFrame(row,frame,kind,current)
 if not inRoot(frame,row.frame) then return nil,"CONTROL_OUTSIDE_ROOT" end
 if not current() then return nil,"OWNER_RETIRED" end
 if type(S:Field(frame,"CreateTexture"))~="function" then return nil,"CreateTexture:UNAVAILABLE" end
 local skin=skins[frame]
 if skin and skin.kind~=kind then return nil,"CONTROL_KIND_CHANGED" end
 local buildAttempts=0
 if skin and not skin.ready then
  -- A failed constructor remains responsible for all textures it allocated.
  -- The bounded cleanup retry owns pending hides; never allocate around them.
  if skin.pending then return nil,"CreateTexture:CLEANUP_PENDING" end
  buildAttempts=skin.buildAttempts or 1
  if buildAttempts>=3 then return nil,"CreateTexture:RETRY_LIMIT" end
  if not hideSkin(skin) then return nil,"CreateTexture:CLEANUP_PENDING" end
  if not current() or skins[frame]~=skin or not inRoot(frame,row.frame) or not current() then return nil,"OWNER_RETIRED" end
  -- No native regions are involved. Every retired owned region is confirmed
  -- hidden, so the incomplete cache may be replaced once in this Apply pass.
  local list=owners[skin.row] or {}
  for i=#list,1,-1 do if list[i]==skin then table.remove(list,i) end end
  skins[frame]=nil;skin=nil
 end
 if not skin then
  -- Publish cleanup custody before the first native allocation callback. A
  -- partial skin can enter combat while being built and must remain recoverable.
  skin={frame=frame,kind=kind,textures={},row=row,buildAttempts=buildAttempts+1};skins[frame]=skin
  owners[row]=owners[row] or {};owners[row][#owners[row]+1]=skin
  local function write(object,key,...)
   local fn=S:Field(object,key)
   if not current() or not inRoot(object,row.frame) or type(fn)~="function" or not current() then error("PRESENTATION_RETIRED") end
   skin.failure=key..":SETTER_REJECTED"
   local result=fn(object,...)
   if result==false then error("PRESENTATION_SETTER_REJECTED") end
   if not current() then skin.failure=key..":OWNER_RETIRED";error("PRESENTATION_RETIRED") end
   skin.failure=nil
  end
  local function texture(layer,sublevel)
   local create=S:Field(frame,"CreateTexture")
   if type(create)~="function" or not current() then error("PRESENTATION_RETIRED") end
   skin.failure="CreateTexture:ALLOCATION_REJECTED"
   local t=create(frame,nil,layer,nil,sublevel)
   if not S:Frame(t,false) or not inRoot(t,row.frame) then error("PRESENTATION_ALLOCATION_REJECTED") end
   skin.textures[#skin.textures+1]=t
   if not current() then skin.failure="CreateTexture:OWNER_RETIRED";error("PRESENTATION_RETIRED") end
   skin.failure=nil
   return t
  end
  local ok=pcall(function()
   local palette=M.VisualTokens.world;local stroke=palette.stroke
   local bg=texture("BACKGROUND",-8)
   write(bg,"SetAllPoints",frame);write(bg,"SetColorTexture",.022,.029,.037,kind=="bar" and .76 or .88)
   local alpha=kind=="bar" and .35 or .52
   for _,edge in ipairs({"TOP","BOTTOM","LEFT","RIGHT"}) do
    local t=texture("OVERLAY",5)
    write(t,"SetColorTexture",stroke[1],stroke[2],stroke[3],alpha)
    if edge=="TOP" or edge=="BOTTOM" then
     write(t,"SetPoint",edge.."LEFT",frame,edge.."LEFT",0,0);write(t,"SetPoint",edge.."RIGHT",frame,edge.."RIGHT",0,0);write(t,"SetHeight",1)
    else
     write(t,"SetPoint","TOP"..edge,frame,"TOP"..edge,0,0);write(t,"SetPoint","BOTTOM"..edge,frame,"BOTTOM"..edge,0,0);write(t,"SetWidth",1)
    end
   end
   skin.ready=true
  end)
  if not ok then local why=skin.failure or "CreateTexture:OWNER_UNAVAILABLE";hideSkin(skin);return nil,why end
 end
 if not skin.ready then return nil,skin.failure or "CreateTexture:INCOMPLETE" end
 if not current() then return nil,"OWNER_RETIRED" end
 if skin.row~=row then
  skin.row=row;owners[row]=owners[row] or {};owners[row][#owners[row]+1]=skin
 end
 for _,t in ipairs(skin.textures) do
  local show=S:Field(t,"Show")
  if not current() or not inRoot(t,row.frame) or type(show)~="function" or not current() then hideSkin(skin);return nil,"Show:OWNER_UNAVAILABLE" end
  local sent,result=pcall(show,t)
  if not sent or result==false or not current() or read(t,"IsShown","boolean")~=true then hideSkin(skin);return nil,"Show:READBACK_UNCONFIRMED" end
 end
 skin.active=true
 return skin
end
-- Native micro buttons update their own icon/portrait and highlight on every
-- hover, task-window update and pressed-state transition. The reviewed 70888
-- SetNormal/SetPushed/OnLeave callbacks own those exact source/alpha properties.
-- Mirage supplies the tile frame only, just as it does for equipped bag icons.
-- This prevents a routine native transition from displacing a static cosmetic
-- lease or restoring an old button state during handback.
local function children(frame)
 if not S:Frame(frame,false) or type(frame.GetChildren)~="function" then return {},false end
 local ok,values=pcall(function() return {frame:GetChildren()} end)
 if not ok or #values>64 then return {},false end
 for _,value in ipairs(values) do if not S:Readable(value) then return {},false end end
 return values,true
end
local function buttonList(row)
 local out,seen,complete={},{},true
 local function add(button,required)
  if seen[button] then return end
  if #out>=48 or not button or not inRoot(button,row.frame) then if required then complete=false end;return end
  local kind=read(button,"GetObjectType","string")
  if kind=="Button" or kind=="CheckButton" or kind=="ItemButton" then seen[button]=true;out[#out+1]=button
  elseif required then complete=false end
 end
 local buttons,state=S:FieldAccess(row.frame,"actionButtons")
 if state=="KNOWN" and type(buttons)=="table" then
  for i=1,12 do
   local button,access=S:FieldAccess(buttons,i)
   if access=="KNOWN" then add(button,true) elseif access~="ABSENT" then complete=false end
  end
  -- This explicit native list is authoritative; do not substitute an unrelated
  -- descendant button when one of its declared controls could not be skinned.
  return out,complete
 elseif state~="ABSENT" then return out,false end
 -- Native utility roots have different containers, but no controls below the
 -- second child level are probed. This is a fixed small tree, never a UI scan.
 local first,firstKnown=children(row.frame)
 if not firstKnown then complete=false end
 for _,child in ipairs(first) do
  add(child)
  local second,secondKnown=children(child)
  if not secondKnown then complete=false end
  for _,grandchild in ipairs(second) do add(grandchild) end
 end
 return out,complete
end
local function gap(receipt,property,reason)
 receipt.complete=false;receipt.failureCount=(receipt.failureCount or 0)+1
 local detail=property..":"..reason
 receipt.firstFailure=receipt.firstFailure or detail
 if #receipt.failures<24 then receipt.failures[#receipt.failures+1]=detail end
end
local function decorate(row,parent,field,key,current,receipt)
 local object,state=S:FieldAccess(parent,field)
 -- An absent optional region is different from an unreadable one. Missing
 -- art has nothing to suppress; unknown art cannot prove a finished skin.
 if state=="ABSENT" then return true end
 receipt.artExpected=receipt.artExpected+1
 local why
 if state~="KNOWN" then why="REGION_UNAVAILABLE"
 elseif not current() then why="OWNER_RETIRED"
 elseif not inRoot(object,row.frame) then why="REGION_OUTSIDE_ROOT"
 elseif read(object,"GetAlpha","number")==nil then why="ALPHA_UNAVAILABLE"
 elseif N:SuppressDecoration(row,key,object) then receipt.artCompleted=receipt.artCompleted+1;return true
 else
  local record=row.art and row.art[object]
  why=record and (record.displaced and "NEWER_OWNER" or record.reloadRequired and "RESTORE_RELOAD_REQUIRED"
   or record.pending and "RESTORE_PENDING" or record.failed and "SETTER_REJECTED") or "ALPHA_WRITE_UNCONFIRMED"
 end
 gap(receipt,key,why);return false
end
function P:Apply(row)
 if not row then return false end
 local profile=M.profile
 local function current() return eligible(row,profile) end
 if not current() then
  self:Restore(row)
  if not S:InCombat() and N.rows[row.name]==row and row.active then N:RestoreArt(row) end
  return false
 end
 local result={controlsExpected=0,controlsCompleted=0,artExpected=0,artCompleted=0,complete=true,discoveryComplete=true,failures={},failureCount=0}
 if row.name=="BagsBar" or row.name=="MicroMenuContainer" then result.symbols="NATIVE_ORIGINAL";result.states="NATIVE_ORIGINAL" end
 self.details[row.name]=result
 local function skin(frame,kind)
  result.controlsExpected=result.controlsExpected+1
  local applied,why=skinFrame(row,frame,kind,current)
  if applied then result.controlsCompleted=result.controlsCompleted+1;return true end
  gap(result,"control:"..result.controlsExpected,why or "SKIN_UNCONFIRMED");return false
 end
 if row.name=="PlayerCastingBarFrame" then
  if skin(row.frame,"bar") then
   -- The native fill, icon, label, spark, flash and interruptibility shield keep
   -- their existing approved appearance and native timing/state ownership.
   for _,key in ipairs({"Border","Background"}) do decorate(row,row.frame,key,"cast:"..key,current,result) end
  end
 elseif row.name=="MainStatusTrackingBarContainer" or row.name=="SecondaryStatusTrackingBarContainer" then
  local bars,access=S:FieldAccess(row.frame,"bars")
  if access=="KNOWN" and type(bars)=="table" then
   local visited=0
   for _,bar in pairs(bars) do
    visited=visited+1;if visited>16 then result.complete=false;result.discoveryComplete=false;break end
    if S:Readable(bar) and inRoot(bar,row.frame) then
     local status,state=S:FieldAccess(bar,"StatusBar")
     if state=="KNOWN" and inRoot(status,row.frame) and skin(status,"bar") then
      decorate(row,status,"Background","progress:"..visited,current,result)
     elseif state~="KNOWN" or not inRoot(status,row.frame) then
      result.complete=false;result.discoveryComplete=false
     end
    else result.complete=false;result.discoveryComplete=false end
   end
  elseif access~="ABSENT" then result.complete=false;result.discoveryComplete=false end
 else
  local buttons,known=buttonList(row)
  if not known then result.discoveryComplete=false;gap(result,"controls","DISCOVERY_UNAVAILABLE") end
  for i,button in ipairs(buttons) do
   if skin(button,"button") then
    -- Keep all native menu symbols and state layers. This generic bezel pass
    -- applies only to icon-backed non-menu controls; no launch state is read,
    -- rewritten, or used to certify tile readiness.
    local icon=S:Field(button,"icon") or S:Field(button,"Icon")
    if row.name~="MicroMenuContainer" and icon and inRoot(icon,row.frame) then
     for _,key in ipairs({"NormalTexture","SlotBackground","SlotArt"}) do
      decorate(row,button,key,"button:"..i..":"..key,current,result)
     end
    end
   end
  end
  if result.controlsCompleted>0 then
   -- Both the frame-wide trim and Forever's end-cap container are cosmetic.
   -- Read back the existing managed art lease as part of this receipt too.
   for _,key in ipairs({"BorderArt","EndCaps"}) do decorate(row,row.frame,key,"control:"..key,current,result) end
   if row.name=="MicroMenuContainer" and _G.MicroMenu and inRoot(_G.MicroMenu,row.frame) then
    for _,key in ipairs({"BorderArt","BackgroundArt"}) do decorate(row,_G.MicroMenu,key,"menu:"..key,current,result) end
   end
  end
 end
 if not current() then result.complete=false;self:Restore(row);return false end
 local complete=result.controlsCompleted>0 and result.complete and result.controlsCompleted==result.controlsExpected and result.artCompleted==result.artExpected
 result.complete=complete
 self.status[row.name]=complete and ((row.name=="BagsBar" or row.name=="MicroMenuContainer") and "MIRAGE_UTILITY_TILES_NATIVE_ICONS_AND_INPUT" or "MIRAGE_ART_NATIVE_CONTROLS") or ((result.controlsExpected>0 or not result.discoveryComplete) and "MIRAGE_ART_PARTIAL" or "NATIVE_CONTENT_PRESERVED")
 return complete
end

function P:Diagnostics(name)
 local result=self.details[name]
 if not result then return "NOT_EVALUATED" end
 return "first="..(result.firstFailure or "NONE")..";failures="..(result.failureCount or 0)
  ..";properties="..(#(result.failures or {})>0 and table.concat(result.failures,",") or "NONE")
  ..";symbols="..(result.symbols or "NATIVE_CONTENT")..";states="..(result.states or "NATIVE_CONTENT")
end
