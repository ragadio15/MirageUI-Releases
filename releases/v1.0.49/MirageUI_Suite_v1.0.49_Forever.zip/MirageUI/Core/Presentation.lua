local _,M=...
-- One fact, one declared presentation owner. This layer never reads health,
-- power, duration, aura contents, names or GUIDs, and never changes native UI.
-- KEEP is the migration default. Mirroring and motion changes require Apply.
M.Presentation={schema=1,keys={"schema","health","resource","cast","gcd","healthMirror","resourceMirror","castMirror","gcdMirror","reduceRotation","reduceTrails","rangeShapes"},revision=0}
local P=M.Presentation
local facts={"health","resource","cast","gcd"}
local permitted={
 health={Keep=true,Native=true,UnderCharacterHUD=true,ResourceBars=true,UnitFrames=true},
 resource={Keep=true,Native=true,UnderCharacterHUD=true,ResourceBars=true,UnitFrames=true},
 cast={Keep=true,Native=true,UnderCharacterHUD=true,ResourceBars=true,UnitFrames=true,Cursor=true},
 gcd={Keep=true,Native=true,ResourceBars=true,Cursor=true},
}
P.labels={Keep="Keep current displays",Native="Blizzard / external display",UnderCharacterHUD="Under-Character HUD",ResourceBars="Resources and casts",UnitFrames="Player unit frame",Cursor="Archived cursor choice (standalone)"}
function P:Defaults()
 return {schema=1,health="Keep",resource="Keep",cast="Keep",gcd="Keep",healthMirror=false,resourceMirror=false,castMirror=false,gcdMirror=false,reduceRotation=false,reduceTrails=false,rangeShapes=false}
end
function P:Check(input)
 if input==nil then return true end
 if type(input)~="table" then return false,"Invalid presentation preferences." end
 local d=self:Defaults()
 for k,v in pairs(input) do
  if d[k]==nil then return false,"Unknown presentation preference." end
  if type(v)~=type(d[k]) then return false,"Invalid presentation preference type." end
  if permitted[k] and not permitted[k][v] then return false,"That display cannot own this kind of information." end
  if k=="schema" and v~=1 then return false,"Unknown presentation preference version." end
 end
 return true
end
function P:Normalize(input)
 local d=self:Defaults()
 if type(input)~="table" then return d end
 for k,v in pairs(input) do
  if type(v)==type(d[k]) and ((permitted[k] and permitted[k][v]) or (not permitted[k] and (k~="schema" or v==1))) then d[k]=v end
 end
 -- Retired embedded-owner choices now name the external display without
 -- changing any standalone profile, binding or rendering state.
 for _,fact in ipairs({"cast","gcd"}) do if d[fact]=="Cursor" then d[fact]="Native" end end
 return d
end
function P:Options(fact)
 local result={}
 for _,key in ipairs({"Keep","Native","UnderCharacterHUD","ResourceBars","UnitFrames"}) do
  if permitted[fact] and permitted[fact][key] then result[#result+1]={value=key,label=self.labels[key]} end
 end
 return result
end
function P:Configured(profile,owner,fact)
 if owner=="Native" then return true end -- explicitly chosen, not detected or certified
 if owner=="Keep" then return false end
 local c=profile and profile.modules and profile.modules[owner]
 if not c or not c.enabled then return false end
 if owner=="UnderCharacterHUD" then return c[fact]==true end
 if owner=="ResourceBars" then return true end
 if owner=="UnitFrames" then return fact=="health" or (fact=="resource" and c.showPower) or (fact=="cast" and c.showCast) end
 return false
end
function P:Available(owner,fact)
 if owner=="Native" then return true end
 if not self:Configured(M.profile,owner,fact) or not M:IsModuleActive(owner) then return false end
 if owner=="UnderCharacterHUD" then
  local h=M.UnderCharacterHUD;local r=h and h.view and h.view.rows[fact]
  if not r or h.vehicle or h.petBattle or h.unavailableWorld then return false end
  local state=h.rowStatus and h.rowStatus[fact]
  if state=="DISPLAY_UNAVAILABLE" or state=="DURATION_DISPLAY_UNAVAILABLE" or state=="ROW_QUARANTINED" or state=="EMPOWER_NOT_SUPPORTED" then return false end
  if fact=="cast" then
   if type(h.CastAvailable)=="function" then
    local ok,ready=pcall(h.CastAvailable,h)
    return ok and ready==true
   end
   -- Only explicit healthy states grant duplicate suppression. A new failure
   -- code must keep the native fallback available without needing a deny list.
   local submitted=state=="NATIVE_DURATION_SUBMITTED" and h.castNameOK==true and h.castLifecycleKnown==true
   local idle=state=="IDLE" and not h.activity and h.castPresenceKnown==true
   local feedback=(state=="CAST_ENDED" or type(state)=="string" and state:match("^CAST_FEEDBACK_")~=nil)
    and not h.activity and h.castNameOK==true
   return (submitted or idle or feedback) and type(r.SetTimerDuration)=="function"
    and type(UnitCastingDuration)=="function" and type(UnitChannelDuration)=="function"
    and type(UnitCastingInfo)=="function" and type(UnitChannelInfo)=="function"
    and h.castPresenceKnown~=false and h.castNameOK~=false and (h.rowFaults.cast or 0)==0
  end
  return h.rowStatus and (state=="NATIVE_WIDGET_DISPATCH" or state=="NATIVE_DISPLAY_SUBMITTED")
 end
 if owner=="ResourceBars" then
  local r=M.modules.ResourceBars
  if not r.view then return false end
  if fact=="health" then return r.view.healthOK==true end
  if fact=="resource" then return r.view.powerOK==true and r.view.powerPresence~="ABSENT" end
  if fact=="cast" then return r.cast and type(r.cast.SetTimerDuration)=="function" end
  return r.gcd and type(r.gcd.SetCooldownFromDurationObject)=="function"
 end
 if owner=="UnitFrames" then
  local rework=M.Rework
  if rework and rework:Selected("units") and rework.UnitFrames then
   local v=rework.UnitFrames:GetView("player")
   if not v or not rework.UnitFrames:IsReady("player") then return false end
   if fact=="health" then return v.healthOK==true end
   if fact=="resource" then return v.powerOK==true and v.powerPresence~="ABSENT" end
   return v.castTrack and type(v.castTrack.SetTimerDuration)=="function" or v.castBar and type(v.castBar.SetTimerDuration)=="function" or false
  end
  local v=M.modules.UnitFrames.views and M.modules.UnitFrames.views.player
  if not v or (M.UnitTypography and not M.UnitTypography:PresentationAvailable(v,fact)) then return false end
  if fact=="health" then return v.healthOK==true end
  if fact=="resource" then return v.powerOK==true and v.powerPresence~="ABSENT" end
  return v.castTrack and type(v.castTrack.SetTimerDuration)=="function"
 end
 return false
end
-- M02 resolves Keep for the single central cast role without changing the
-- saved owner, attached unit casts, or the user's deliberate mirror setting.
function P:CastOwner(profile)
 profile=profile or M.profile
 local cfg=profile and profile.presentation
 if cfg and cfg.cast and cfg.cast~="Keep" then return cfg.cast end
 if not M.Rework or not M.Rework:Qualified() then return "Keep" end
 local modules=profile and profile.modules or {}
 local function enabled(id)
  local c=modules[id];local implementation=M.modules and M.modules[id]
  return c and c.enabled and not (implementation and (implementation.quarantined or implementation.initializationFailed or implementation.maintenanceFailed))
 end
 local hud=modules.UnderCharacterHUD
 if enabled("UnderCharacterHUD") and hud.cast then return "UnderCharacterHUD" end
 if enabled("ResourceBars") then return "ResourceBars" end
 if enabled("UnitFrames") and modules.UnitFrames.showCast then return "UnitFrames" end
 return "Native"
end
function P:CentralHUDReady()
 local cfg=M.profile and M.profile.presentation
 local h=M.UnderCharacterHUD
 if not cfg or not h or cfg.health~="UnderCharacterHUD" or cfg.resource~="UnderCharacterHUD"
  or self:CastOwner(M.profile)~="UnderCharacterHUD" or cfg.healthMirror or cfg.resourceMirror or cfg.castMirror
  or cfg.gcd=="ResourceBars" or cfg.gcdMirror then return false end
 local powerReady=self:Available("UnderCharacterHUD","resource") or h.powerState=="ABSENT"
 return self:Available("UnderCharacterHUD","health") and powerReady and self:Available("UnderCharacterHUD","cast") or false
end
function P:LegacyAggregateRetired()
 -- This lower aggregate is a retired presentation, not a fallback readiness
 -- test. A missing cast name, inactive GCD or old mirror setting cannot revive
 -- its empty card. Class resources/runes/totems have independent surfaces.
 local cfg=M.profile and M.profile.presentation
 local hud=M.profile and M.profile.modules and M.profile.modules.UnderCharacterHUD
 return hud and hud.enabled==true and cfg and
  (cfg.health=="UnderCharacterHUD" or cfg.resource=="UnderCharacterHUD" or self:CastOwner(M.profile)=="UnderCharacterHUD") or false
end
local pairQuery
local function plain(v) return type(v)=="table" and getmetatable(v)==nil end
-- This is an authored preference decision only, not configured/available/native
-- Health. Existing owner/fact hot paths never call the envelope validator.
local function cursorHealthPair(profile,cfg)
 if pairQuery then pairQuery.revoked=true;return false,"PAIR_POLICY_REENTRANT" end
 if not plain(profile) or not plain(cfg) then return false,"PAIR_POLICY_UNAVAILABLE" end
 local envelope=rawget(profile,"cursorPreferences")
 if envelope==nil then return nil end
 if not plain(envelope) then return false,"PAIR_POLICY_UNAVAILABLE" end
 if rawget(envelope,"schema")==1 then return nil end
 local policy=rawget(envelope,"presentation")
 if rawget(envelope,"schema")~=2 or not plain(policy) then return false,"PAIR_POLICY_UNAVAILABLE" end
 if rawget(policy,"schema")==1 and rawget(policy,"healthPair")=="None" then return nil end
 local E,S,client=M.CursorPreferenceEnvelope,M.Safety,M.Client
 if not plain(E) or not plain(S) or not plain(client) then return false,"PAIR_POLICY_UNAVAILABLE" end
 local snapshot,validate,seal,readable=rawget(E,"Snapshot"),rawget(E,"Validate"),rawget(E,"Seal"),rawget(S,"Readable")
 if type(snapshot)~="function" or type(validate)~="function" or type(seal)~="function" or type(readable)~="function" then return false,"PAIR_POLICY_UNAVAILABLE" end
 local family=rawget(client,"family");local ticket={rows={},revoked=false};local fields=0
 for _,object in ipairs({P,E,S,client,cfg}) do
  if not plain(object) then return false,"PAIR_POLICY_UNAVAILABLE" end
  local row={object=object,fields={},count=0};ticket.rows[#ticket.rows+1]=row
  for key,value in next,object do
   fields=fields+1;if fields>1024 then return false,"PAIR_POLICY_UNAVAILABLE" end
   row.count=row.count+1;row.fields[#row.fields+1]={key=key,value=value}
  end
 end
 local function current()
  if ticket.revoked or not rawequal(pairQuery,ticket) or not rawequal(M.Presentation,P)
   or not rawequal(M.profile,profile) or not plain(profile) or not rawequal(rawget(profile,"presentation"),cfg)
   or not rawequal(rawget(profile,"cursorPreferences"),envelope) or not rawequal(M.CursorPreferenceEnvelope,E)
   or not rawequal(M.Safety,S) or not rawequal(M.Client,client) then ticket.revoked=true;return false end
  for _,row in ipairs(ticket.rows) do
   if not plain(row.object) then ticket.revoked=true;return false end
   local count=0;for _ in next,row.object do count=count+1;if count>row.count then ticket.revoked=true;return false end end
   if count~=row.count then ticket.revoked=true;return false end
   for _,entry in ipairs(row.fields) do if not rawequal(rawget(row.object,entry.key),entry.value) then ticket.revoked=true;return false end end
  end
  return true
 end
 pairQuery=ticket
 local ok,allowed=pcall(function()
  if not current() then return false end
  local dependencyCurrent=seal(E);if type(dependencyCurrent)~="function" or not current() then return false end
  local function public(value)
   if not current() then return false end
   local good,result=pcall(readable,S,value)
   return good and result==true and current()
  end
  -- Snapshot supplies a retained raw-content guard for the ORIGINAL envelope;
  -- validate the detached copy, then recheck both owner and original content.
  local copy,unchanged=snapshot(E,envelope,public)
  if type(unchanged)~="function" or not current() then return false end
  local clean=validate(E,copy,family,public)
  if not clean or clean.schema~=2 or clean.presentation.healthPair~="CursorUnderCharacterHUD" then return false end
  return current() and dependencyCurrent() and unchanged() and current()
 end)
 pairQuery=nil
 if not ok or allowed~=true then return false,"PAIR_POLICY_UNAVAILABLE" end
 return true,"PAIR_SCOPED_HEALTH_MIRROR"
end
function P:Allows(owner,fact)
 if owner=="Cursor" and fact=="health" and pairQuery then pairQuery.revoked=true;return false,"PAIR_POLICY_REENTRANT" end
 local cfg=M.profile and M.profile.presentation
 if not cfg or not permitted[fact] then return true,"UNCHANGED" end
 if owner=="ResourceBars" and self:LegacyAggregateRetired() then return false,"LEGACY_AGGREGATE_RETIRED" end
 local primary=cfg[fact]
 if fact=="cast" and primary=="Keep" and M.Rework and M.Rework:Qualified() then
  -- F7 retains its established Keep behavior. Only redundant central HUD,
  -- resource and native cast rows participate in this automatic resolution.
  if owner=="Cursor" or owner=="UnitFrames" then return true,"USER_PRESENTATION" end
  primary=self:CastOwner(M.profile)
 end
 -- The approved central player cast is exclusive even if an older profile
 -- retained its mirror flag. Keep the stored preference for compatibility;
 -- it must not revive a second full native cast bar below the active HUD.
 if fact=="cast" and primary=="UnderCharacterHUD" and owner=="Native" then
  if self:Available("UnderCharacterHUD","cast") then return false,"EXCLUSIVE_PLAYER_CAST" end
  return true,"CAST_PRIMARY_UNAVAILABLE_NATIVE_RETAINED"
 end
 if owner=="UnderCharacterHUD" and fact=="cast" and primary=="UnderCharacterHUD" then
  local casts=M.Rework and M.Rework.CombatCasts
  -- Painting a valid duration alone is not an exclusive ownership receipt.
  -- Commit the native presentation switch first; incomplete handoff keeps one
  -- complete native fallback and withholds the competing custom row.
  if not casts or not casts:OwnsPlayerCast() then return false,"PLAYER_CAST_HANDOFF_PENDING" end
 end
 if primary=="Keep" or cfg[fact.."Mirror"] or primary==owner then return true,"USER_PRESENTATION" end
 if owner=="Cursor" and fact=="health" and primary=="UnderCharacterHUD" and cfg.healthMirror==false then
  if self~=P then return false,"PAIR_POLICY_UNAVAILABLE" end
  local allowed,why=cursorHealthPair(M.profile,cfg)
  if allowed~=nil then return allowed,why end
 end
 -- Never remove an interactive unit control or its essential information just
 -- to satisfy cosmetic deduplication. It is an explicit safety mirror.
 if owner=="UnitFrames" then return true,"SECURE_ACCESS_MIRROR" end
 if not self:Available(primary,fact) then return true,"PRIMARY_UNAVAILABLE_KEEP_FALLBACK" end
 return false,"DUPLICATE_OPTIONAL_PRESENTATION"
end
function P:StagePrimary(draft,owner)
 if type(draft)~="table" or not draft.modules then return false,"Open a settings draft first." end
 if owner~="Keep" and owner~="Native" and owner~="UnderCharacterHUD" and owner~="ResourceBars" and owner~="UnitFrames" then return false,"Choose a supported primary display." end
 draft.presentation=self:Normalize(draft.presentation)
 for _,fact in ipairs({"health","resource","cast"}) do draft.presentation[fact]=owner;draft.presentation[fact.."Mirror"]=false end
 if owner=="UnderCharacterHUD" then
  local c=draft.modules.UnderCharacterHUD;c.enabled=true;c.health=true;c.resource=true;c.cast=true
 elseif owner=="ResourceBars" then draft.modules.ResourceBars.enabled=true
 elseif owner=="UnitFrames" then local c=draft.modules.UnitFrames;c.enabled=true;c.showPower=true;c.showCast=true end
 -- GCD is a different fact; user choice and all layouts stay unchanged.
 return true,"Primary display staged. Apply saves; Cancel discards. Native frames and PRD settings are not changed."
end
function P:RefreshHUD()
 local h=M.UnderCharacterHUD
 if h and h.view then for _,fact in ipairs({"health","resource","cast"}) do
  if type(h.RefreshRowVisibility)=="function" then h:RefreshRowVisibility(fact)
  else
   local row=h.view.rows[fact]
   row:SetShown(row.mirageRequestedShown==true and self:Allows("UnderCharacterHUD",fact))
  end
 end end
end
function P:RefreshResources()
 local r=M.modules.ResourceBars
 if r and r.view then
  local any=false
  for _,fact in ipairs(facts) do
   local allowed=self:Allows("ResourceBars",fact);any=any or allowed
   -- Missing widgets must not fall through to another fact's display.
   local frame
   if fact=="health" then frame=r.view.health
   elseif fact=="resource" then frame=r.view.power
   elseif fact=="cast" then frame=r.cast
   elseif fact=="gcd" then frame=r.gcd end
   if frame then frame:SetShown(allowed and (fact~="cast" or frame.mirageRequestedShown==true)) end
   if fact=="gcd" and r.gcdLabel then r.gcdLabel:SetShown(allowed) end
  end
  if r.view.name then r.view.name:SetShown(self:Allows("ResourceBars","health") or self:Allows("ResourceBars","resource")) end
  if r.surface and r.surface.presentationHidden~=(not any) then r.surface.presentationHidden=not any;M.state.forceEvaluate=true end
  if type(r.OnPresentationChanged)=="function" then r:OnPresentationChanged(not any) end
 end
end
function P:Refresh()
 if self.refreshing or not M.profile then return end
 self.refreshing=true
 -- Failure of one passive row must not strand a global refreshing lock or stop
 -- fallback restoration in another module. Repeated errors use module quarantine.
 for _,item in ipairs({{"UnderCharacterHUD",self.RefreshHUD},{"ResourceBars",self.RefreshResources}}) do
  local mod=M.modules[item[1]]
  if mod and not mod.quarantined then M:Guard(item[1],item[2],self) end
 end
 self.revision=self.revision+1;self.refreshing=false
end
function P:RelevantEvent(event,unit)
 if event:sub(1,5)=="UNIT_" then return M.Safety:Text(unit) and unit=="player" end
 return event=="PLAYER_ENTERING_WORLD" or event=="PLAYER_REGEN_ENABLED" or event=="PLAYER_REGEN_DISABLED" or event=="UPDATE_SHAPESHIFT_FORM" or event=="PLAYER_SPECIALIZATION_CHANGED" or event=="PET_BATTLE_CLOSE" or event=="PET_BATTLE_OPENING_START"
end
function P:Report(profile)
 local p=profile or M.profile;local cfg=p and p.presentation or self:Defaults();local lines={}
 for _,fact in ipairs(facts) do
  local primary=cfg[fact];local state=primary=="Keep" and "unchanged" or self:Configured(p,primary,fact) and "configured; native validation pending" or "primary unavailable; backups retained"
  local mirror=cfg[fact.."Mirror"] and "; mirrors allowed" or ""
  if fact=="cast" and self:CastOwner(p)=="UnderCharacterHUD" then mirror="; one central player cast; native fallback retained" end
  lines[#lines+1]=fact..": "..(self.labels[primary] or "Unknown").." — "..state..mirror
 end
 lines[#lines+1]="Native frames and secure player-frame access are retained. These can remain deliberate safety mirrors."
 return table.concat(lines,"\n")
end
