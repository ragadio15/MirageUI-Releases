local _, M = ...
M.Commands={}
function M.Commands:Register()
    SLASH_MIRAGEUI1="/mirage";SLASH_MIRAGEUI2="/mirageui"
    SlashCmdList.MIRAGEUI=function(text) self:Run(text) end
end
function M.Commands:Run(text)
    local command,rest=(text or ""):match("^%s*(%S*)%s*(.-)%s*$");command=command:lower()
    if command=="safe" or command=="off" then M:SafeMode("USER_REQUEST");M:Print("Optional effects stopped. Secure controls remain usable until safe post-combat cleanup.")
    elseif command=="recover" or command=="on" then M:Recover()
    elseif command=="activate" then local _,why=M.Experience:ResumeChoices();M:Print(why)
    elseif command=="check" then M.UI:CopyWindow("MirageUI current display check",M.Diagnostics:Check())
    elseif command=="capture" then
        local action,label=rest:match("^(%S*)%s*(%S*)$")
        if action=="start" then local _,why=M.Profiler:Start(label~="" and label or "ROUTE");M:Print(why)
        elseif action=="stop" then local _,why=M.Profiler:Stop();M:Print(why)
        elseif action=="mark" then M:Print(M.Profiler:Mark(label) and "Capture marker recorded." or "Use an active capture and a ROUTE, QUIET, MOVING, COMBAT, TASKS or EDIT marker.")
        elseif action=="export" or action=="" then M.UI:CopyWindow("MirageUI capture and support",M.Profiler:Export().."\n\n"..M.Diagnostics:Export())
        else M:Print("/mirage capture start, stop, export or mark [QUIET/MOVING/COMBAT/TASKS/EDIT].") end
    elseif command=="measure" then
        if rest=="stop" then M.Profiler:Stop();M.UI:CopyWindow("MirageUI performance",M.Profiler:Export())
        elseif rest=="export" then M.UI:CopyWindow("MirageUI performance",M.Profiler:Export())
        else local scene,extra=rest:match("^(%S+)%s*(%S*)$");local ok,why=M.Profiler:Start(scene,extra=="memory");M:Print(why) end
    elseif command=="verify" then
        if rest=="begin" then local _,why=M.NativeEvidence:Begin();M:Print(why)
        elseif rest=="clear" then local _,why=M.NativeEvidence:Clear();M:Print(why)
        elseif rest=="export" or rest=="" then M.UI:CopyWindow("User-reported validation worksheet",M.NativeEvidence:Export())
        else local id,result=rest:match("^(%S+)%s+(%S+)$");local _,why=M.NativeEvidence:Record(id,result);M:Print(why) end
    elseif command=="candidate" then
        if rest~="on" and rest~="off" then M:Print("Use /mirage candidate on or off outside combat. Build numbers do not block capability mode.")
        else local ok,why=M.Client:SetCandidate(rest=="on");M:Print(why) end
    elseif command=="note" then
        if rest=="clear" then M.ObservedContacts:ForgetNotes();M:Print("Manual combat notes cleared.")
        else
            local kind,seconds=rest:match("^(%a+)%s+(%d+)$")
            local ok,why=M.ObservedContacts:ManualNote(kind,tonumber(seconds));M:Print(why)
        end
    elseif command=="conventions" then M.UI:CopyWindow("Tactical conventions",M.modules.TacticalSignals:ConventionText())
    elseif command=="integration" then
        M:LoadOptions(true)
        if M.Workspace then
            M.Workspace.disclosures=M.Workspace.disclosures or {}
            M.Workspace.disclosures["hud.advanced"]=true
            M.Workspace.disclosures["hud.sources"]=true
            M.Workspace:Open("Modules","UnderCharacterHUD")
        end
    elseif command=="rehearsal" then M.UI:CopyWindow("DEMO — contextual rehearsal",M.FirstTranche:Rehearsal())
    elseif command=="readiness" then M.UI:CopyWindow("MirageUI installation check",M.Readiness:Export())
    elseif command=="experience" then
        M:LoadOptions(true);if M.PlayerSettings then M.PlayerSettings:Open("welcome") end
    elseif command=="frames" then
        M.Experience:Preview()
    elseif command=="advanced" then
        M:LoadOptions(true);if M.PlayerSettings then M.PlayerSettings:Close() end
        if M.Options and M.Options.LegacyOpen then M.Options:LegacyOpen() end
    elseif command=="status" then M:Print(M.Diagnostics:Status())
    elseif command=="why" then M:Print(M.Diagnostics:Why(rest~="" and rest or nil))
    elseif command=="compat" then
        local notice=_G.MirageSuiteCompatibility
        if notice and type(notice.Open)=="function" then notice:Open(true) else M.UI:CopyWindow("MirageUI compatibility",M.Diagnostics:Export()) end
    elseif command=="export" then M.UI:CopyWindow("MirageUI support information",M.Diagnostics:Export())
    elseif command=="reveal" then M.CVE:Reveal(10)
    elseif command=="edit" or command=="unlock" then M:LoadOptions();if M.Editor then M.Editor:Open() end
    elseif command=="setup" then M:LoadOptions();if M.Options then M.Options:Setup() end
    elseif command=="cursor" then M:Print("Cursor Companion is a standalone addon. Use /cc to open its settings.")
    elseif command=="menu" then M:Print("Use /cc menu or your Cursor Companion shortcut for the standalone Quick Menu.")
    elseif command=="addons" then
        if M.SuiteLauncher then local ok,why=M.SuiteLauncher:Toggle();if not ok then M:Print(why) end end
    elseif command=="bags" then local ok,why=M.modules.Bags:OpenBrowser();if not ok then M:Print(why) end
    elseif command=="rescue" then M.Layout:Rescue()
    elseif command=="profileexport" then local text,why=M.Profiles:Export();if text then M.UI:CopyWindow("Profile includes saved reference text — review before sharing",text) else M:Print(why) end
    elseif command=="pin" then
        local id,value=rest:match("^(%w+)%s+(%w+)$")
        if id and M:ModuleConfig(id) and not M.Safety:InCombat() then
            local p=M:Copy(M.profile);p.modules[id].visibility=value=="on" and "Always" or "Contextual";M.Profiles:Commit(p)
        else M:Print("Use /mirage pin ModuleID on or off, outside combat.") end
    elseif command=="" or command=="config" then M:LoadOptions()
    else M:Print("config, setup, edit, reveal, why [module], safe, activate, recover, check, cursor, menu, addons, bags, status, export, rescue, profileexport, integration, rehearsal, capture, measure, verify, candidate") end
end
_G.MirageUI_ToggleSettings=function() if MirageUI then MirageUI:LoadOptions() end end
_G.MirageUI_TemporaryReveal=function() if MirageUI then MirageUI.CVE:Reveal(10) end end
_G.MirageUI_SafeMode=function() if MirageUI then MirageUI:SafeMode("USER_BINDING") end end
