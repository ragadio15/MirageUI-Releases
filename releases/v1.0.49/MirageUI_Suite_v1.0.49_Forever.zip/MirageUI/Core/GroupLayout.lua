local _, M = ...
-- A draft-only arrangement tool. It never alters a unit token, roster order or secure frame.
M.GroupLayout={}
function M.GroupLayout:Arrange(draft,kind)
    if M.Safety:InCombat() then return false,"Arrange frames after combat." end
    if type(draft)~="table" or type(draft.modules)~="table" or type(draft.modules.PartyRaid)~="table" then return false,"Choose a group profile first." end
    if kind~="party" and kind~="raid" then return false,"Choose party or raid." end
    local validated,why=M.Profiles:Validate(draft);if why then return false,why end
    local cfg=validated.modules.PartyRaid
    local count=kind=="party" and 4 or 40
    local columns=kind=="party" and 1 or cfg.raidColumns
    local rows=math.ceil(count/columns)
    local w,h,gap=cfg.cellWidth,cfg.cellHeight,cfg.cellGap
    local sw,sh=UIParent:GetWidth(),UIParent:GetHeight()
    if not M.Safety:Number(sw) or not M.Safety:Number(sh) or sw<=32 or sh<=32 then return false,"Screen size is unavailable." end
    local blockW,blockH=columns*w+(columns-1)*gap,rows*h+(rows-1)*gap
    local scale=1
    if blockW>sw-32 or blockH>sh-32 then return false,"This grid does not fit. Use more columns or smaller frames." end
    local first=validated.layouts["PartyRaid."..kind.."1"]
    local x=first and first.x*sw or -.36*sw
    local y=first and first.y*sh or .23*sh
    -- Clamp the grid as one block so individually clamped rows cannot overlap at an edge.
    local left=math.max(-sw/2+16,math.min(sw/2-16-blockW*scale,x-w*scale/2))
    local top=math.min(sh/2-16,math.max(-sh/2+16+blockH*scale,y+h*scale/2))
    local layouts={}
    for i=1,count do
        local col,row=math.floor((i-1)/rows),(i-1)%rows
        layouts["PartyRaid."..kind..i]={x=(left+(col*(w+gap)+w/2)*scale)/sw,
            y=(top-(row*(h+gap)+h/2)*scale)/sh,width=w,height=h,scale=scale}
    end
    draft.layouts=draft.layouts or {}
    for id,layout in pairs(layouts) do draft.layouts[id]=layout end
    if draft.managed then draft.autoLayout=false end
    return true,"Arrangement staged. Apply to save it; Undo can restore the previous layout."
end

function M.GroupLayout:CompactPreset(draft,count)
 if M.Safety:InCombat() then return false,"Arrange raid frames after combat." end
 if count~=10 and count~=20 and count~=40 then return false,"Choose Raid 10, 20 or 40." end
 if type(draft)~="table" or type(draft.modules)~="table" or type(draft.modules.PartyRaid)~="table" then return false,"A group draft is required." end
 local w,h=count==40 and 125 or 150,count==40 and 32 or 34
 local columns=4
 local gap=6;local blockGap=14
 local sw,sh=UIParent:GetWidth(),UIParent:GetHeight()
 if not M.Safety:Number(sw) or not M.Safety:Number(sh) or sw<=0 or sh<=0 then return false,"Screen size is unavailable." end
 -- Always stage forty legal slots, including overflow beyond a smaller preview.
 -- These are fixed roster-slot blocks, not a claim of native raid subgroup sorting.
 local totalW=columns*w+(columns-1)*blockGap
 local blockH=5*h+4*gap
 local rows=math.ceil(8/columns)
 local totalH=rows*blockH+(rows-1)*blockGap
 if totalW>sw-32 or totalH>sh-32 then return false,"This compact layout does not fit at this scale." end
 local layouts={}
 local left=-sw/2+24
 local top=math.min(sh/2-16,math.max(-sh/2+16+totalH,sh/2-80))
 for i=1,40 do
  local block=math.floor((i-1)/5)
  local col,blockRow
  if count~=40 then col=(block%2)+math.floor(block/4)*2;blockRow=math.floor((block%4)/2)
  else col=block%columns;blockRow=math.floor(block/columns) end
  local row=(i-1)%5
  layouts["PartyRaid.raid"..i]={x=(left+col*(w+blockGap)+w/2)/sw,y=(top-blockRow*(blockH+blockGap)-row*(h+gap)-h/2)/sh,width=w,height=h,scale=1}
 end
 draft.layouts=draft.layouts or {};for id,l in pairs(layouts) do draft.layouts[id]=l end
 for group=1,8 do
  local first=layouts["PartyRaid.raid"..((group-1)*5+1)]
  draft.layouts["PartyRaid.group"..group]={x=first.x,y=first.y-(blockH-h)/2/sh,width=w,height=blockH,scale=1}
 end
 draft.modules.PartyRaid.compactRaid=true
 if draft.managed then draft.autoLayout=false end
 return true,"Compact raid "..count.." staged. Extra roster slots stay accessible; Apply saves the layout."
end
