local _,M=...
-- One keyed, generation-bound queue. A callback cannot be preempted; every
-- priority respects the budget before the next callback starts. Ready work
-- that has waited past fairWaitSeconds joins an oldest-first lane so repeated
-- urgent producers cannot indefinitely starve an existing lower-priority job.
M.RuntimeScheduler={jobs={},count=0,serial=0,budgetMS=.5,maxJobs=512,maxPerFrame=32,fairWaitSeconds=.25,
    counters={requested=0,coalesced=0,debounced=0,executed=0,cancelled=0,stale=0,failed=0,yielded=0,
        scanned=0,ready=0,skippedCombat=0,timedJobs=0,overBudgetJobs=0},
    phase="IDLE",maxAge=0,maxCost=0,maxPending=0,costs={},maxJobCost=0,maxJobCategory="NONE"}
local Q=M.RuntimeScheduler
local function code(v)
    return type(v)=="string" and #v>0 and #v<=128 and v:match("^[%w_.:%-]+$") and v
end
local function now() return M.Safety:Now() end
local function millis()
    if type(debugprofilestop)~="function" then return nil end
    local good,value=pcall(debugprofilestop)
    if good and M.Safety:Number(value) then return value end
end
local observationStages={Signals=true,CVE=true,NativeContext=true}
local costBuckets={.25,.5,1,2,4,8,16,32,64,128,256,512,1024}
local function costSample(row,cost)
    row.histogram=row.histogram or {}
    local bucket=#costBuckets+1
    for i,upper in ipairs(costBuckets) do if cost<=upper then bucket=i;break end end
    row.histogram[bucket]=(row.histogram[bucket] or 0)+1
    if cost>2 then row.over2MS=(row.over2MS or 0)+1 end
    if cost>16 then row.over16MS=(row.over16MS or 0)+1 end
end
local function percentileUpper(row,fraction)
    local wanted=math.ceil(row.count*fraction);local seen=0
    for i=1,#costBuckets+1 do
        seen=seen+(row.histogram and row.histogram[i] or 0)
        if seen>=wanted then return costBuckets[i] and tostring(costBuckets[i]) or "OVER_1024" end
    end
    return "UNAVAILABLE"
end
local function costSummary(row)
    return "calls="..row.count..";totalMS="..string.format("%.3f",row.total)..";maxMS="..string.format("%.3f",row.max)
        ..";p50BucketUpperMS="..percentileUpper(row,.50)..";p95BucketUpperMS="..percentileUpper(row,.95)
        ..";p99BucketUpperMS="..percentileUpper(row,.99)..";over2MS="..(row.over2MS or 0)..";over16MS="..(row.over16MS or 0)
end
function Q:StageClock() return millis() end
function Q:RecordObservationStage(stage,started,finished)
    -- Fixed categories only. These current-session counters diagnose a heavy
    -- observation callback without collecting units, spells or identities.
    if not observationStages[stage] or not started or not finished or finished<started then return end
    self.observationCosts=self.observationCosts or {}
    local row=self.observationCosts[stage]
    if not row then row={count=0,total=0,max=0};self.observationCosts[stage]=row end
    local cost=finished-started
    row.count=row.count+1;row.total=row.total+cost;row.max=math.max(row.max,cost)
    costSample(row,cost)
end
local function generationCurrent(job)
    if job.generation~=false and (job.generation~=(M.state.settingsGeneration or 0) or job.profile~=M.profile) then return false end
    return true
end
local function current(job)
    if not generationCurrent(job) then return false end
    if job.guard then
        local ok,value=pcall(job.guard)
        if not ok or value~=true then return false end
        if job.generation~=false and (job.generation~=(M.state.settingsGeneration or 0) or job.profile~=M.profile) then return false end
    end
    return true
end
-- Only authored categories enter cost diagnostics. Runtime keys may identify
-- individual work items, so never retain an arbitrary key as timing metadata.
local coreCosts={["Core.Observation"]=true,["Core.SecureMaintenance"]=true,["Core.Maintenance"]=true,["Core.SessionRecovery"]=true,
    ["Core.Rework"]=true,["Core.Managed"]=true,["Core.Maintenance.Fonts"]=true,["Core.Maintenance.WorldText"]=true,
    ["Core.Maintenance.Art"]=true,["Core.Maintenance.Hover"]=true,["Core.Maintenance.Cards"]=true}
local providerCosts={main=true,units=true,groups=true,minimap=true,nameplates=true,auras=true,cooldowns=true,meters=true,
    casts=true,alerts=true,chat=true,tooltips=true,maps=true,objectives=true,inventory=true,tasks=true,character=true,system=true}
local moduleCosts={Cursor=true,Minimap=true,Chat=true,Tooltips=true,QuestTracker=true,UnitFrames=true,Nameplates=true,ActionBars=true,
    UnderCharacterHUD=true,ResourceBars=true,Auras=true,Cooldowns=true,PartyRaid=true,BlizzardSkin=true,Bags=true,DataBars=true,
    DamageMeters=true,PvP=true,TacticalSignals=true,Preparations=true,Notifications=true}
local function costCategory(key)
    if coreCosts[key] then return key end
    local action,id=key:match("^Rework%.(Tick)%.([%w_]+)$")
    if not action then action,id=key:match("^Rework%.(Configure)%.([%w_]+)$") end
    if action and providerCosts[id] then return "Rework."..action.."."..id end
    id=key:match("^Module%.([%w_]+)$")
    if id and moduleCosts[id] then return "Module."..id end
    if key:sub(1,23)=="Rework.objectives.scan." then return "Rework.objectives.scan" end
    if key=="Rework.inventory.continue" then return "Rework.inventory.continue" end
    if key=="Rework.auras.continue" then return "Rework.auras.continue" end
    if key=="Rework.main.prepare" then return "Rework.main.prepare" end
    local family=tonumber(key:match("^Rework%.main%.family%.(%d+)$"))
    if family and family>=1 and family<=14 then return "Rework.main.family" end
    if key=="native.context.lifecycle" then return "Native.ContextLifecycle" end
    return "Other"
end
local function recordCost(queue,job,started,finished)
    if not started or not finished or finished<started then return end
    local cost=finished-started;local category=costCategory(job.key)
    local row=queue.costs[category]
    if not row then row={count=0,total=0,max=0};queue.costs[category]=row end
    row.count=row.count+1;row.total=row.total+cost;row.max=math.max(row.max,cost)
    costSample(row,cost)
    queue.counters.timedJobs=queue.counters.timedJobs+1
    if cost>queue.budgetMS then queue.counters.overBudgetJobs=queue.counters.overBudgetJobs+1 end
    if cost>queue.maxJobCost then queue.maxJobCost=cost;queue.maxJobCategory=category end
end
local function dueFor(existing,clock,delay,mode,maxDelay)
    local requested=clock+delay
    if mode=="debounce" then
        local latest=requested
        if M.Safety:Number(maxDelay) and maxDelay>=0 then latest=math.min(latest,(existing.firstRequested or existing.created or clock)+maxDelay) end
        return math.max(existing.due or clock,latest)
    end
    return math.min(existing.due or requested,requested)
end
function Q:Request(key,fn,options)
    if not code(key) or type(fn)~="function" then return false end
    local o=options or {};local clock=now()
    local generation=o.generation
    if generation==nil then generation=M.state.settingsGeneration or 0 end
    if generation~=false and (not M.Safety:Number(generation) or generation<0) then return false end
    local delay=M.Safety:Number(o.delay) and math.max(0,math.min(60,o.delay)) or 0
    local priority=M.Safety:Number(o.priority) and math.max(0,math.min(9,o.priority)) or 5
    local mode=o.mode=="debounce" and "debounce" or "coalesce"
    local maxDelay=M.Safety:Number(o.maxDelay) and math.max(0,math.min(60,o.maxDelay)) or nil
    local existing=self.jobs[key]
    self.counters.requested=self.counters.requested+1
    if existing and existing.generation==generation and (generation==false or existing.profile==M.profile) then
        -- Preserve the original fairness position, but give every request a
        -- fresh dispatch revision. A guard/earlier callback can coalesce this
        -- same table; its successor must not borrow the old ready admission.
        self.serial=self.serial+1;existing.revision=self.serial
        existing.fn=fn;existing.guard=o.guard;existing.due=dueFor(existing,clock,delay,mode,maxDelay)
        existing.priority=math.min(existing.priority,priority)
        existing.combat=o.combat=="allow" and "allow" or "defer"
        existing.owner=code(o.owner) or "Runtime";existing.critical=o.critical==true
        existing.mode=mode;existing.maxDelay=maxDelay
        self.counters.coalesced=self.counters.coalesced+1
        if mode=="debounce" then self.counters.debounced=self.counters.debounced+1 end
        return true
    end
    if not existing and self.count>=self.maxJobs then return false,"QUEUE_FULL" end
    if existing then self.counters.stale=self.counters.stale+1 else self.count=self.count+1 end
    self.serial=self.serial+1
    self.jobs[key]={key=key,fn=fn,guard=o.guard,owner=code(o.owner) or "Runtime",priority=priority,
        due=clock+delay,created=clock,firstRequested=clock,sequence=self.serial,revision=self.serial,generation=generation,profile=M.profile,
        combat=o.combat=="allow" and "allow" or "defer",critical=o.critical==true,mode=mode,maxDelay=maxDelay}
    self.maxPending=math.max(self.maxPending,self.count)
    return true
end
function Q:Cancel(key)
    if not self.jobs[key] then return false end
    self.jobs[key]=nil;self.count=self.count-1;self.counters.cancelled=self.counters.cancelled+1
    return true
end
function Q:CancelPrefix(prefix)
    if not code(prefix) then return end
    for key in pairs(self.jobs) do if key:sub(1,#prefix)==prefix then self:Cancel(key) end end
end
function Q:Invalidate()
    for key,job in pairs(self.jobs) do if job.generation~=false then self:Cancel(key) end end
end
function Q:Tick()
    if self.running or self.count==0 then return end
    self.running=true
    local clock=now();local start=millis();local ran=0
    local fence=self.serial;local combat=M.Safety:InCombat();local ready={}
    -- Pending/deferred jobs need only the cheap generation check. Ownership
    -- guards run once immediately before dispatch, not for every waiting job
    -- every frame. Work created by a callback stays behind this frame's fence.
    for key,job in pairs(self.jobs) do
        self.counters.scanned=self.counters.scanned+1
        local valid=generationCurrent(job)
        if self.jobs[key]==job and not valid then
            self.jobs[key]=nil;self.count=self.count-1;self.counters.stale=self.counters.stale+1
        elseif self.jobs[key]==job and valid and job.revision<=fence and job.due<=clock then
            if job.combat=="allow" or not combat then ready[#ready+1]=job
            else self.counters.skippedCombat=self.counters.skippedCombat+1 end
        end
    end
    table.sort(ready,function(a,b)
        local oldA=clock-a.due>=self.fairWaitSeconds
        local oldB=clock-b.due>=self.fairWaitSeconds
        if oldA~=oldB then return oldA end
        if oldA then return a.sequence<b.sequence end
        return a.priority==b.priority and a.sequence<b.sequence or a.priority<b.priority
    end)
    self.counters.ready=self.counters.ready+#ready
    for i=1,math.min(#ready,self.maxPerFrame) do
        local chosen=ready[i]
        local tick=millis()
        -- Rejected ownership guards also consume callback time. Guarantee one
        -- admission attempt, then budget all attempts rather than only jobs
        -- whose payload eventually ran.
        if i>1 and (start and tick and tick-start>=self.budgetMS or not start and i>4) then
            self.counters.yielded=self.counters.yielded+1;break
        end
        local revision=chosen.revision
        if self.jobs[chosen.key]==chosen and revision<=fence and chosen.due<=clock then
            local legal=chosen.combat=="allow" or not M.Safety:InCombat()
            if self.jobs[chosen.key]==chosen and chosen.revision==revision then
                if not legal then
                    self.counters.skippedCombat=self.counters.skippedCombat+1
                else
                    local admitted=current(chosen)
                    -- A false old guard cannot delete a replacement request,
                    -- including a successor coalesced into the same job table.
                    if self.jobs[chosen.key]==chosen and chosen.revision==revision then
                        if not admitted then
                            self.jobs[chosen.key]=nil;self.count=self.count-1;self.counters.stale=self.counters.stale+1
                        else
                            -- The guard itself may synchronously enter combat.
                            legal=chosen.combat=="allow" or not M.Safety:InCombat()
                            if self.jobs[chosen.key]==chosen and chosen.revision==revision then
                                if not generationCurrent(chosen) then
                                    self.jobs[chosen.key]=nil;self.count=self.count-1;self.counters.stale=self.counters.stale+1
                                elseif not legal then
                                    self.counters.skippedCombat=self.counters.skippedCombat+1
                                else
                                    self.jobs[chosen.key]=nil;self.count=self.count-1
                                    self.phase=chosen.key;self.maxAge=math.max(self.maxAge,clock-chosen.created)
                                    local jobStarted=millis()
                                    local token=M.Profiler and M.Profiler:BeginPhase("Queue."..chosen.key)
                                    local ok=pcall(chosen.fn,clock)
                                    if token then M.Profiler:EndPhase(token,ok) end
                                    recordCost(self,chosen,jobStarted,millis())
                                    self.counters.executed=self.counters.executed+1;ran=ran+1
                                    if not ok then
                                        self.counters.failed=self.counters.failed+1
                                        if M.Incidents then M.Incidents:Record("FAULT",chosen.owner,chosen.key,"CALLBACK_FAILED") end
                                        if chosen.critical then M:Fault("Core","SCHEDULER_CALLBACK_FAILED") end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
    local finish=millis()
    if start and finish and finish>=start then self.maxCost=math.max(self.maxCost,finish-start) end
    self.phase="IDLE";self.running=false
end
function Q:Snapshot()
    local out={pending=self.count,budgetMS=self.budgetMS,maxAgeSeconds=self.maxAge,maxBatchMS=self.maxCost,
        maxPending=self.maxPending,phase=self.phase,settingsGeneration=M.state.settingsGeneration or 0,
        budgetScope="BETWEEN_NON_PREEMPTIBLE_CALLBACKS",maxJobMS=self.maxJobCost,maxJobCategory=self.maxJobCategory,
        costScope="UP_TO_8_SLOWEST_AUTHORED_CATEGORIES_NOT_NATIVE_FPS",
        percentileScope="BOUNDED_HISTOGRAM_BUCKET_UPPER_LIMITS_NOT_EXACT_PERCENTILES"}
    for key,value in pairs(self.counters) do out[key]=value end
    local rows={};for category,row in pairs(self.costs) do rows[#rows+1]={category=category,count=row.count,total=row.total,max=row.max,histogram=row.histogram,over2MS=row.over2MS,over16MS=row.over16MS} end
    table.sort(rows,function(a,b) return a.max==b.max and a.category<b.category or a.max>b.max end)
    for i=1,math.min(8,#rows) do
        local row=rows[i]
        out["cost_"..i]=row.category..";"..costSummary(row)
    end
    for _,stage in ipairs({"Signals","CVE","NativeContext"}) do
        local row=self.observationCosts and self.observationCosts[stage]
        if row then out["observation_"..stage]=costSummary(row) end
    end
    return out
end
