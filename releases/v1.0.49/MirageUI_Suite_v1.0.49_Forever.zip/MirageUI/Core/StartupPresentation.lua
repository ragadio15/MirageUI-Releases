local _,M=...
-- Startup is an ordinary contextual state. This observer never changes a
-- frame, animation, input route, activity receipt or global visibility. Each
-- provider prepares its own artwork and publishes only its locally ready
-- presentation. Optional content cannot hold the rest of the interface.
local S=M.Safety
local P={phase="NOT_STARTED",reason="NOT_STARTED",providers={},events={}}
M.StartupPresentation=P

function P:Initialize()
 self.phase="LOCAL_CONTEXT";self.reason="INDEPENDENT_PROVIDER_PREPARATION"
 self.started=S:Now();self.profile=M.profile;self.providers={}
end
function P:Begin()
 if self.phase=="NOT_STARTED" then self:Initialize() end
 return true
end
function P:BeforeApply() return self:Begin() end
function P:BeforeEvent(event)
 if event=="PLAYER_ENTERING_WORLD" then self:Begin() end
end
-- Retained entry points allow existing fault/setup callers to record their
-- reason. They do not clear real player activity or stop someone else's fade.
function P:Cancel(reason)
 self.reason=S:Text(reason) and reason:match("^[A-Z_]+$") and reason or "CONTEXT_CHANGED"
 return true
end
function P:IsQuiet() return false end
function P:ObserveActivity() end

function P:ProviderState(id,state,reason)
 local r=M.Rework
 if not r or not r.providers or not r.providers[id] then return end
 local row=self.providers[id]
 if not row then row={firstObserved=S:Now()};self.providers[id]=row end
 row.state=state;row.reason=reason
 if state=="READY" and not row.firstReady then row.firstReady=S:Now() end
end
local function code(v)
 return S:Text(v) and #v<=96 and v:match("^[%w_:%-%.]+$") and v or "UNAVAILABLE"
end
function P:Report()
 local lines={"startup_presentation=LOCAL_CONTEXT; reason="..code(self.reason)
  .."; quiet_override=false; mask=NONE; global_wait=NONE; activity_reset=NONE"
  .."; native_root_visibility_and_input=UNMODIFIED; native_rendering=NOT_RUN"}
 for _,id in ipairs(M.Rework and M.Rework.order or {}) do
  local row=self.providers[id]
  if row then
   local ready=row.firstReady and string.format("%.3f",math.max(0,row.firstReady-(self.started or row.firstObserved))) or "NOT_READY"
   lines[#lines+1]="startup_provider_"..code(id).."="..code(row.state).."; reason="..code(row.reason).."; first_ready_seconds="..ready
  end
 end
 return table.concat(lines,"\n")
end
