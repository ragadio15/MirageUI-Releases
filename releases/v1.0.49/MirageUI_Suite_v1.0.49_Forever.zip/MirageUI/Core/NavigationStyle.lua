local _,M=...
-- Public, reversible native appearance only. No quest content, aura payloads,
-- player identity, button handlers, or restricted combat values are inspected.
local S,N=M.Safety,M.ManagedNative
local reviewedClient=M.Client.IsReviewedPresentationClient
local sourcePin=M.Client:NewSourcePinLookup()
local function sourceMask()
 local c,a=M.Client,M.adapter
 if reviewedClient(c) then return "ui-hud-minimap-frame-generic-mask" end
 -- Retain the separately reviewed pre-M06 mask for existing legacy profiles.
 local pin=sourcePin(c.family,c.build)
 if c.family=="Forever" and c.build=="70790" and c.sourceMatched==true and pin
  and c.patch==pin[1] and c.interface==pin[3] and a.family==c.family
  and a.patch==pin[1] and a.build==pin[2] and a.interface==pin[3] and a.sourceCommit==pin[4] then
  return "Textures\\MinimapMask"
 end
end
local V={rows={},status={},maskMonitors=setmetatable({},{__mode="k"}),artMonitors=setmetatable({},{__mode="k"})}
M.NavigationStyle=V
local white="Interface\\Buttons\\WHITE8X8"
local mask="Interface\\AddOns\\MirageUI\\Media\\SquareMask.tga"
local function near(a,b) return S:Number(a) and S:Number(b) and math.abs(a-b)<=.001 end
local function same(a,b)
 if type(a)~="table" or type(b)~="table" or #a~=#b then return false end
 for i=1,#a do
  if not S:Readable(a[i]) or not S:Readable(b[i]) then return false end
  if type(a[i])=="number" and type(b[i])=="number" then if not near(a[i],b[i]) then return false end
  elseif not rawequal(a[i],b[i]) then return false end
 end
 return true
end
local function observe(get,object)
 local ok,data=pcall(get,object)
 if ok and same(data,data) then return data end
end
local function nativeEditing()
 local f=_G.EditModeManagerFrame
 if not f then return false end
 if not S:Readable(f) then return true end
 local shown,status=S:Public(f.IsShown,"boolean",f)
 return status~="KNOWN" or shown==true
end
local function enabled(module)
 local p=M.profile;local cfg=p and p.modules[module]
 return cfg and cfg.style and not nativeEditing() and M:IsModuleActive(module) and M.Managed:Enabled() and not M.Native:Conflict()
end
local function manualQuestLayout()
 local p=M.profile
 return p and not p.autoLayout and p.layouts and p.layouts["QuestTracker.nativePosition"]~=nil
end
function V:Handles(name)
 if name=="ObjectiveTrackerFrame" then return self.manualGeometryBlocked or (enabled("QuestTracker") and not manualQuestLayout() and M.profile.modules.QuestTracker.matchMinimap and M.profile.modules.Minimap.square) end
 if name=="BuffFrame" or name=="DebuffFrame" then return enabled("Auras") and M.profile.modules.Auras.nativeScale~=100 end
 return false
end
function V:Pending()
 for _,r in ipairs(self.rows) do if r.pending then return true end end
 return self.maskPending==true
end
function V:Write(owner,object,key,get,set,value)
 if S:InCombat() or not enabled(owner) or not S:Frame(object,false) then return false end
 local profile=M.profile
 local function current() return M.NavigationStyle==self and M.profile==profile and enabled(owner) and not S:InCombat() and S:Frame(object,false) and M.profile==profile end
 if not current() then return false end
 local before=observe(get,object);if not before or not current() then return false end
 local r
 for _,item in ipairs(self.rows) do if item.object==object and item.key==key then r=item;break end end
 if r and (r.owner~=owner or r.pending or r.displaced) then return false end
 if r and r.last and not same(before,r.last) then r.displaced=true;self.status[owner]="NEWER_STYLE_PRESERVED";return false end
 if not r then r={owner=owner,object=object,key=key,get=get,set=set,original=before};self.rows[#self.rows+1]=r end
 if same(before,value) then r.last=before;return true end
 r.attempt=value;r.writing=true
 local ok=pcall(set,object,value)
 r.writing=nil
 local after=observe(get,object)
 if after and same(after,value) then r.last=after;r.attempt=nil
 elseif after and not same(after,before) then r.last=after end
 if not ok or not after or not same(after,value) or not current() then r.pending=true;self.status[owner]="STYLE_APPLY_INCOMPLETE";return false end
 self.writeCount=(self.writeCount or 0)+1
 return true
end
function V:Restore(owner)
 if S:InCombat() then
  for _,r in ipairs(self.rows) do if not owner or r.owner==owner then r.pending=true end end
  if not owner or owner=="Minimap" then if self.maskRecord then self.maskPending=true end end
  return false
 end
 local kept={};local complete=true
 for _,r in ipairs(self.rows) do
  if owner and r.owner~=owner then kept[#kept+1]=r
  elseif r.writing then r.pending=true;kept[#kept+1]=r;complete=false
  elseif not S:Frame(r.object,false) then r.pending=true;kept[#kept+1]=r;complete=false
  else
   local current=observe(r.get,r.object)
   if not current then r.pending=true;kept[#kept+1]=r;complete=false
   elseif r.displaced or same(current,r.original) then
    -- A newer writer wins; or the original property is already restored.
   elseif r.last and same(current,r.last) or r.attempt and same(current,r.attempt) then
    if S:InCombat() then r.pending=true;kept[#kept+1]=r;complete=false
    else
     local ok=pcall(r.set,r.object,r.original);local after=observe(r.get,r.object)
     if not ok or not after or not same(after,r.original) then
      if after then r.last=after end
      r.pending=true;kept[#kept+1]=r;complete=false
     end
    end
   end
  end
 end
 self.rows=kept
 if not owner or owner=="Minimap" then complete=self:RestoreMask() and complete end
 if complete then self.fingerprint=nil end
 return complete
end
local function scalar(getter,setter)
 return function(o) local v,state=S:Public(o[getter],"number",o);if state=="KNOWN" then return {v} end end,
 function(o,v) o[setter](o,v[1]) end
end
function V:Scalar(owner,object,key,getter,setter,v)
 if not object or type(object[getter])~="function" or type(object[setter])~="function" then return false end
 local get,set=scalar(getter,setter);return self:Write(owner,object,key,get,set,{v})
end
local function shown(object)
 local value,state=S:Public(object.IsShown,"boolean",object)
 if state=="KNOWN" then return {value} end
end
-- Only the four named decorative minimap regions use this lease. Track later
-- Show/Hide calls, including same-value writes, without replacing their scripts.
function V:ArtShown(object,value)
 if not S:Frame(object,false) or S:InCombat() or not enabled("Minimap") then return false end
 if type(object.IsShown)~="function" or type(object.Show)~="function" or type(object.Hide)~="function" or type(hooksecurefunc)~="function" then return false end
 local monitor=self.artMonitors[object]
 if monitor and (monitor.show~=object.Show or monitor.hide~=object.Hide) then return false end
 if not monitor then
  monitor={};self.artMonitors[object]=monitor
  local function changed(current)
   if current~=object or monitor.writing then return end
   for _,r in ipairs(V.rows) do
    if r.object==object and r.key=="shown" then r.displaced=true;V.status.Minimap="NEWER_STYLE_PRESERVED";break end
   end
  end
  local ok=pcall(function() hooksecurefunc(object,"Show",changed);hooksecurefunc(object,"Hide",changed) end)
  monitor.show=object.Show;monitor.hide=object.Hide;monitor.ready=ok
 end
 if not monitor.ready then return false end
 local function putShown(current,state)
  if S:InCombat() or current~=object or monitor.show~=current.Show or monitor.hide~=current.Hide then error("STYLE_VISIBILITY_UNAVAILABLE",0) end
  monitor.writing=true
  local ok,why=pcall(state[1] and monitor.show or monitor.hide,current)
  monitor.writing=nil
  if not ok then error(why,0) end
 end
 return self:Write("Minimap",object,"shown",shown,putShown,{value})
end
local function points(o)
 local n,status=S:Public(o.GetNumPoints,"number",o)
 if status~="KNOWN" or n<0 or n>8 or n%1~=0 then return end
 local out={}
 for i=1,n do
  local ok,p,f,rp,x,y=pcall(o.GetPoint,o,i)
  if not ok or not S:Text(p) or not S:Readable(f) or not S:Text(rp) or not S:Number(x) or not S:Number(y) then return end
  for _,v in ipairs({p,f or false,rp,x,y}) do out[#out+1]=v end
 end
 return out
end
local function putPoints(o,v)
 o:ClearAllPoints()
 for i=1,#v,5 do
  if S:InCombat() then error("STYLE_COMBAT_DEFERRED",0) end
  o:SetPoint(v[i],v[i+1]~=false and v[i+1] or nil,v[i+2],v[i+3],v[i+4])
 end
end
function V:Anchor(owner,frame,point,relative,rpoint,x,y)
 return self:Write(owner,frame,"points",points,putPoints,{point,relative,rpoint,x,y})
end
function V:Square()
 local map=_G.Minimap
 if not map or not S:Frame(map,false) or type(map.SetMaskTexture)~="function" or S:InCombat() then self.status.Minimap="MAP_SHAPE_UNAVAILABLE";return false end
 for _,addon in ipairs({"SexyMap","Chinchilla","BasicMinimap"}) do if S:Loaded(addon) then self.status.Minimap="OTHER_MINIMAP_OWNER";return false end end
 local r=self.maskRecord
 if r and r.map~=map then if not self:RestoreMask() then return false end;r=nil end
 if r and r.displaced then
  -- A newer mask owner also gets back the size/rim properties we changed.
  -- Retain a receipt after handback so periodic Configure cannot reacquire it.
  if not r.stylingReturned then
   local complete=self:Restore("Minimap")
   if self.maskRecord==nil then self.maskRecord=r end
   r.active=nil;r.stylingReturned=complete or nil
  end
  self.status.Minimap="NEWER_MASK_PRESERVED";return false
 end
 if not r then
  local original
  if type(map.GetMaskTexture)=="function" then
   local status;original,status=S:Public(map.GetMaskTexture,nil,map)
   if status~="KNOWN" or (not S:Text(original) and not S:Number(original)) then
    self.status.Minimap="MASK_READBACK_UNAVAILABLE";return false
   end
  end
  -- This API has no getter on the pinned client. Use the source/default circular
  -- mask only for that exact source tuple and monitor future setter ownership.
  if original==nil then
   original=sourceMask()
   if not original or type(hooksecurefunc)~="function" then
    self.status.Minimap="MASK_RESTORE_UNAVAILABLE";return false
   end
   local shape,state=S:Public(GetMinimapShape,"string")
   if state=="KNOWN" and shape~="ROUND" then self.status.Minimap="OTHER_MINIMAP_OWNER";return false end
  end
  r={map=map,original=original,sourceDefault=type(map.GetMaskTexture)~="function"};self.maskRecord=r
  local monitor=self.maskMonitors[map]
  if monitor and monitor.setter~=map.SetMaskTexture then
   self.maskRecord=nil;self.status.Minimap="MASK_MONITOR_CHANGED";return false
  end
  if not monitor and type(hooksecurefunc)=="function" then
   local ok=pcall(hooksecurefunc,map,"SetMaskTexture",function(object,asset)
    local current=V.maskRecord
    if current and current.map==object and object==map and not current.writing then
     current.displaced=true;V.status.Minimap="NEWER_MASK_PRESERVED"
    end
   end)
   if ok then self.maskMonitors[map]={setter=map.SetMaskTexture}
   elseif r.sourceDefault then self.maskRecord=nil;self.status.Minimap="MASK_MONITOR_UNAVAILABLE";return false end
  end
 end
 if self.maskPending then return false end
 local p=M.profile
 if not enabled("Minimap") or not S:Frame(map,false) or S:InCombat() or M.profile~=p then return false end
 if not r.active then
  r.attempted=true;r.writing=true
  local ok=pcall(map.SetMaskTexture,map,mask);r.writing=nil
  if not ok or S:InCombat() or M.profile~=p or self.maskRecord~=r or _G.Minimap~=map or not enabled("Minimap") then
   self.maskPending=true;return false
  end
 end
 r.active=true
 if type(map.GetMaskTexture)=="function" then
  local got,status=S:Public(map.GetMaskTexture,nil,map)
  if status~="KNOWN" or got~=mask then self.maskPending=true;return false end
 end
 if self.maskRecord~=r or M.profile~=p or not enabled("Minimap") or S:InCombat() or not S:Frame(map,false) then self.maskPending=true;return false end
 if not self.border then
  local f=CreateFrame("Frame",nil,map,"BackdropTemplate");self.border=f
  f:SetPoint("TOPLEFT",-2,2);f:SetPoint("BOTTOMRIGHT",2,-2)
  f:SetBackdrop({edgeFile=white,edgeSize=1});f:SetBackdropBorderColor(1,.58,.16,.65);S:Passive(f)
 end
 self.border:SetParent(map);self.border:Show()
 if not self.shapeHook then
  self.originalShape=GetMinimapShape
  self.shapeHook=function(...)
   local row=V.maskRecord
   if row and row.active and not row.displaced and row.map==_G.Minimap then return "SQUARE" end
   if type(V.originalShape)=="function" then return V.originalShape(...) end
   return "ROUND"
  end
  GetMinimapShape=self.shapeHook
 end
 local size=M.profile.modules.Minimap.squareSize
 local good=self:Scalar("Minimap",map,"width","GetWidth","SetWidth",size)
 good=self:Scalar("Minimap",map,"height","GetHeight","SetHeight",size) and good
 for _,name in ipairs({"MinimapCompassTexture","MinimapCompassTextureUnderlay","MinimapBorder","MinimapBorderTop"}) do
  local art=_G[name]
  if art then
   good=self:Scalar("Minimap",art,"alpha","GetAlpha","SetAlpha",0) and good
   good=self:ArtShown(art,false) and good
  end
 end
 self.status.Minimap=good and "SQUARE_NATIVE_MAP" or "SQUARE_LAYOUT_PARTIAL"
 return good
end
function V:RestoreMask()
 local r=self.maskRecord
 if not r then self.maskPending=nil;return true end
 if S:InCombat() or r.writing then self.maskPending=true;return false end
 if self.border and S:Frame(self.border,false) then self.border:Hide() end
 if GetMinimapShape==self.shapeHook then GetMinimapShape=self.originalShape end
 self.shapeHook=nil
 if not S:Frame(r.map,false) or S:InCombat() or self.maskRecord~=r then self.maskPending=true;return false end
 if not r.displaced and (r.active or r.attempted) then
  if type(r.map.GetMaskTexture)=="function" then
   local v,state=S:Public(r.map.GetMaskTexture,nil,r.map)
   if state~="KNOWN" then self.maskPending=true;return false end
   if v~=mask and v~=r.original then r.displaced=true end
  end
  if not r.displaced then
   if S:InCombat() or self.maskRecord~=r then self.maskPending=true;return false end
   r.writing=true;local ok=pcall(r.map.SetMaskTexture,r.map,r.original);r.writing=nil
   if not ok or S:InCombat() or self.maskRecord~=r then self.maskPending=true;return false end
   if type(r.map.GetMaskTexture)=="function" then
    local got,state=S:Public(r.map.GetMaskTexture,nil,r.map)
    if state~="KNOWN" or got~=r.original then self.maskPending=true;return false end
   end
  end
 end
 if self.maskRecord~=r then self.maskPending=true;return false end
 self.maskRecord=nil;self.maskPending=nil;return true
end
function V:QuestColumn()
 if manualQuestLayout() then self.status.QuestTracker="MANUAL_POSITION_PRESERVED";return false end
 local frame,map=_G.ObjectiveTrackerFrame,_G.Minimap
 if not frame or not map or not S:Frame(frame,false) or not S:Frame(map,false) then self.status.QuestTracker="TRACKER_UNAVAILABLE";return false end
 local width,ws=S:Public(map.GetWidth,"number",map)
 local scale,ss=S:Public(map.GetEffectiveScale,"number",map)
 local root,rs=S:Public(UIParent.GetEffectiveScale,"number",UIParent)
 if ws~="KNOWN" or ss~="KNOWN" or rs~="KNOWN" or width<180 or width>360 or scale<=0 or root<=0 then self.status.QuestTracker="COLUMN_GEOMETRY_UNAVAILABLE";return false end
 local startWrites=self.writeCount or 0
 local good=self:Scalar("QuestTracker",frame,"width","GetWidth","SetWidth",width)
 good=self:Scalar("QuestTracker",frame,"scale","GetScale","SetScale",scale/root) and good
 good=self:Anchor("QuestTracker",frame,"TOPRIGHT",map,"BOTTOMRIGHT",0,-14) and good
 local modules,status=S:FieldAccess(frame,"modules")
 local count=0
 if status=="KNOWN" and type(modules)=="table" then
  for _,mod in ipairs(modules) do
   count=count+1;if count>16 then break end
   if S:Frame(mod,false) then
    local before=self.writeCount or 0
    good=self:Scalar("QuestTracker",mod,"width","GetWidth","SetWidth",width) and good
    local header=S:Field(mod,"Header")
    if S:Frame(header,false) then
     good=self:Scalar("QuestTracker",header,"width","GetWidth","SetWidth",width) and good
     local text=S:Field(header,"Text")
     if S:Frame(text,false) then self:Scalar("QuestTracker",text,"width","GetWidth","SetWidth",width-40) end
     local background=S:Field(header,"Background")
     if S:Frame(background,false) then self:Scalar("QuestTracker",background,"width","GetWidth","SetWidth",width) end
    end
    if (self.writeCount or 0)~=before and type(mod.MarkDirty)=="function" and not S:InCombat() then pcall(mod.MarkDirty,mod) end
   end
  end
 end
 if good and (self.writeCount or 0)~=startWrites and type(frame.MarkDirty)=="function" and not S:InCombat() then pcall(frame.MarkDirty,frame) end
 self.status.QuestTracker=good and "MATCHED_MINIMAP_COLUMN" or "COLUMN_PARTIAL"
 return good
end
function V:Configure()
 if self.configuring or S:InCombat() then return end
 self.configuring=true
 local ok=pcall(function()
  if nativeEditing() or not M.Managed:Enabled() or M.Native:Conflict() then self:Restore();return end
  local p=M.profile
  if enabled("Minimap") and p.modules.Minimap.square then self:Square() else self:Restore("Minimap");self.status.Minimap="GAME_DEFAULT" end
  if enabled("QuestTracker") and not manualQuestLayout() and p.modules.QuestTracker.matchMinimap and p.modules.Minimap.square and self.maskRecord and self.maskRecord.active and not self.maskRecord.displaced then
   self:QuestColumn()
  else self:Restore("QuestTracker");self.status.QuestTracker="GAME_DEFAULT" end
  if enabled("Auras") and p.modules.Auras.nativeScale~=100 then
   local good=true;local found=false
   for _,name in ipairs({"BuffFrame","DebuffFrame"}) do
    local f=_G[name]
    if f then found=true;good=self:Scalar("Auras",f,"scale","GetScale","SetScale",p.modules.Auras.nativeScale/100) and good end
   end
   self.status.Auras=found and (good and "ENLARGED_NATIVE_BUFFS" or "AURA_STYLE_PARTIAL") or "AURA_FRAMES_UNAVAILABLE"
  else self:Restore("Auras");self.status.Auras="GAME_DEFAULT" end
 end)
 self.configuring=nil
 if not ok then self.status.Adapter="STYLE_PARTIAL" end
end
function V:Report()
 local scope=self.maskRecord and (self.maskRecord.sourceDefault and "PINNED_DEFAULT_WITH_SETTER_MONITOR" or "GETTER_READBACK") or "NOT_OWNED_BY_LEGACY_ADAPTER"
 return "minimap_style="..(self.status.Minimap or "NOT_RUN").."\nquest_column="..(self.status.QuestTracker or "NOT_RUN")..
  "\naura_style="..(self.status.Auras or "NOT_RUN").."\nminimap_mask_scope="..scope
end
local configure=N.Configure
function N:Configure()
 -- Release automatic column geometry before the manual adapter takes its
 -- snapshot, so recovery cannot restore an intermediate styled position.
 if manualQuestLayout() then V.manualGeometryBlocked=V:Restore("QuestTracker")~=true else V.manualGeometryBlocked=nil end
 local result=configure(self);V:Configure();return result
end
local restore=M.Native.Restore
function M.Native:Restore(module)
 V:Restore(module);return restore(self,module)
end
local tick=N.Tick
function N:Tick()
 tick(self)
 if not S:InCombat() and S:Now()>=(V.nextUpdate or 0) then
  V.nextUpdate=S:Now()+1;V:Configure()
 end
end
