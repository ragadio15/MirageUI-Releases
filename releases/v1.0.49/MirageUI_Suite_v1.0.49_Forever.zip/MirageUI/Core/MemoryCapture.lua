local _, M = ...
local P,S=M.Profiler,M.Safety
M.MemoryCapture={enabled=false,status="NOT_REQUESTED",maximumSamples=122}
local C=M.MemoryCapture
local names={"MirageUI","MirageUIOptions"}
function C:Begin(requested)
 self.enabled=requested==true;self.rows={};self.failures=0;self.attempts=0;self.nextAt=S:Now();self.status=self.enabled and "REQUESTED" or "NOT_REQUESTED"
 if self.enabled then self:Sample(true) end
end
function C:Sample(force)
 if not self.enabled or #self.rows>=self.maximumSamples then return end
 local now=S:Now();if not force and now<self.nextAt then return end
 self.nextAt=now+5;self.attempts=self.attempts+1
 local function failed()
  self.failures=self.failures+1;self.status="NATIVE_MEMORY_UNAVAILABLE"
  if self.failures>=3 then self.enabled=false;self.status="NATIVE_MEMORY_STOPPED_AFTER_FAILURES" end
 end
 if type(UpdateAddOnMemoryUsage)~="function" or type(GetAddOnMemoryUsage)~="function" then failed();return end
 local ok=pcall(UpdateAddOnMemoryUsage)
 if not ok then failed();return end
 local row={elapsed=math.max(0,now-(P.started or now)),packages={}}
 local total=0;local complete=true
 for _,name in ipairs(names) do
  if name=="MirageUI" or S:Loaded(name) then
   local value,status=S:Public(GetAddOnMemoryUsage,"number",name)
   if status=="KNOWN" and value>=0 and value<1e12 then row.packages[name]=value;total=total+value else complete=false end
  end
 end
 if complete then row.total=total end
 self.rows[#self.rows+1]=row
 if complete then self.failures=0;self.status="NATIVE_MEMORY_SAMPLED"
 else self.failures=self.failures+1;self.status="PARTIAL_NATIVE_MEMORY";if self.failures>=3 then self.enabled=false;self.status="NATIVE_MEMORY_STOPPED_AFTER_FAILURES" end end
end
function C:Export()
 local lines={"memory_state="..self.status,"memory_method=NATIVE_ADDON_REPORTED_KB_EVERY_5_SECONDS_OPT_IN",
  "memory_scope=LOADED_MIRAGE_PACKAGES_INCLUDES_MEASUREMENT_OVERHEAD",
  "memory_samples="..#(self.rows or {}),"memory_attempts="..(self.attempts or 0),"memory_allocation_rate=NOT_INFERRED","gc_events=NOT_OBSERVED_OR_FORCED"}
 local function summary(name)
  local first,last,maximum,n=nil,nil,nil,0
  for _,row in ipairs(self.rows or {}) do
   local value=name=="total" and row.total or row.packages[name]
   if S:Number(value) then first=first or value;last=value;maximum=math.max(maximum or value,value);n=n+1 end
  end
  lines[#lines+1]="memory_"..name.."_samples="..n
  if first then
   lines[#lines+1]="memory_"..name.."_first_kb="..string.format("%.3f",first)
   lines[#lines+1]="memory_"..name.."_last_kb="..string.format("%.3f",last)
   lines[#lines+1]="memory_"..name.."_peak_kb="..string.format("%.3f",maximum)
   lines[#lines+1]="memory_"..name.."_net_kb="..string.format("%.3f",last-first)
  end
 end
 summary("total");for _,name in ipairs(names) do summary(name) end
 lines[#lines+1]="memory_interpretation=NET_CHANGE_IS_NOT_LEAK_OR_GC_PROOF"
 return table.concat(lines,"\n")
end
local start,tick,stop,export=P.Start,P.Tick,P.Stop,P.Export
function P:Start(scenario,memory)
 local ok,why=start(self,scenario)
 if ok then C:Begin(memory) end
 return ok,why
end
function P:Tick(dt)
 local running=self.running;tick(self,dt)
 if running and self.running then C:Sample(false) end
end
function P:Stop()
 if self.running then C:Sample(true) end
 return stop(self)
end
function P:Export() return export(self).."\n"..C:Export() end
