local _,M=...
-- Read-only ownership inventory. Declared routes and observed readiness are
-- separate fields; neither a TOC nor a registered provider proves live parity.
M.SurfaceContracts={}
local C=M.SurfaceContracts
local routes={
 main={geometry="MIRAGE_SECURE",paint="MIRAGE",input="SECURE_ACTION_WITH_NATIVE_COMMANDS",visibility="PREDECLARED_SECURE"},
 units={geometry="NATIVE_ANCHORS_COMPACT_BODY",paint="ROLE_FILTERED_MIRAGE_CARD",input="NATIVE_ORIGINAL",visibility="SECURE_CONTEXT_PARENT_NATIVE_LIFETIME"},
 groups={geometry="BLIZZARD_EDIT_HUD",paint="PASSIVE_MIRAGE_CARD",input="NATIVE_ORIGINAL",visibility="SECURE_CONTEXT_PARENT_NATIVE_LIFETIME"},
 minimap={geometry="SQUARE_SHARED_SIDEBAR",paint="MIRAGE_DOCKED_NATIVE_CONTROLS",input="NATIVE_MAP",visibility="CANVAS_CONTEXT_AUX_NATIVE"},
 nameplates={geometry="NATIVE_NAMEPLATE_ANCHOR",paint="MIRAGE",input="NATIVE_PLATE",visibility="NATIVE_PLATE_LIFETIME"},
 auras={geometry="NATIVE_OR_AUTHORED_ROOT",paint="MIRAGE_NATIVE_REGIONS",input="NATIVE_ORIGINAL",visibility="NAMED_SECURE_CONTEXT_PARENTS_NATIVE_LIFETIME"},
 cooldowns={geometry="NATIVE_OR_AUTHORED_ROOT",paint="MIRAGE_NATIVE_REGIONS",input="NATIVE_ORIGINAL",visibility="NAMED_SECURE_CONTEXT_PARENTS_NATIVE_LIFETIME"},
 meters={geometry="OWNED_BOTTOM_RIGHT_VIEWPORT",paint="MIRAGEUI_METERS_NATIVE_API_DATA",input="OWNED_METER_CONTROLS",visibility="SHARED_CONTEXT_NATIVE_UI_CVAR_HANDOFF"},
 chat={geometry="MIRAGE_PRIMARY_NATIVE_OTHER",paint="MIRAGE_MESSAGE_CANVAS",input="NATIVE_ROUTES_OWN_MESSAGE_LINKS",visibility="CONTEXT_WITH_NATIVE_INPUT_FLOOR"},
 objectives={geometry="MIRAGE_VIEWPORT_NATIVE_CONTENT_HEIGHT",paint="MIRAGE",input="NATIVE_QUEST_CONTROLS",visibility="PREDECLARED_VIEWPORT"},
 tooltips={geometry="NATIVE_OR_EXPLICIT_ANCHOR",paint="MIRAGE_NATIVE_REGIONS",input="NATIVE_ORIGINAL",visibility="NATIVE_LIFETIME"},
 inventory={geometry="NATIVE_OR_AUTHORED_ROOT",paint="MIRAGE_NATIVE_REGIONS",input="NATIVE_ORIGINAL",visibility="NATIVE_LIFETIME"},
 maps={geometry="NATIVE_OR_AUTHORED_ROOT",paint="MIRAGE_NATIVE_REGIONS",input="NATIVE_ORIGINAL",visibility="NATIVE_LIFETIME"},
 tasks={geometry="NATIVE_OR_AUTHORED_ROOT",paint="MIRAGE_NATIVE_REGIONS",input="NATIVE_ORIGINAL",visibility="NATIVE_LIFETIME"},
 character={geometry="NATIVE_OR_AUTHORED_ROOT",paint="MIRAGE_NATIVE_REGIONS",input="NATIVE_ORIGINAL",visibility="NATIVE_LIFETIME"},
 system={geometry="NATIVE_OR_AUTHORED_ROOT",paint="MIRAGE_NATIVE_REGIONS",input="NATIVE_ORIGINAL",visibility="NATIVE_LIFETIME"},
}
local fallback={geometry="SCOPED_PROVIDER_CONTRACT",paint="MIRAGE_NATIVE_REGIONS",input="NATIVE_ORIGINAL",visibility="SCOPED_NATIVE_LIFETIME"}
local function token(v) return type(v)=="string" and #v<=128 and v:match("^[%w_.:%-]+$") and v or "UNAVAILABLE" end
function C:Report()
 local lines={"surface_contract_schema=1","surface_contract_scope=DECLARED_PROPERTY_ROUTES_WITH_RECORDED_LOCAL_READINESS",
  "surface_native_qualification=NOT_RUN","surface_independent_subgroup_movers=OPEN_NATIVE_GEOMETRY_EXCEPTION",
  "surface_bag_micro_visibility=SECURE_CONTEXT_PARENT_WHEN_UTILITY_CONTEXT_ENABLED",
  "surface_special_action_visibility=PET_STANCE_POSSESS_CONTEXT_NATIVE_OVERRIDE_AND_EXIT_LIFETIME"}
 local R=M.Rework
 for _,id in ipairs(R and R.order or {}) do
  local row=R.providers[id];local route=routes[id] or fallback;local object=row.object
  local prefix="contract_"..token(id).."_"
  for _,key in ipairs({"geometry","paint","input","visibility"}) do lines[#lines+1]=prefix..key.."="..route[key] end
  lines[#lines+1]=prefix.."readiness="..token(row.readiness)
  local roots={};for name in pairs(object.nativeRoots or {}) do roots[#roots+1]=name end;table.sort(roots)
  for _,name in ipairs(roots) do
   local observed=object.surfaceStates and object.surfaceStates[name]
   -- Combat roots record their authored display ID, while the census is keyed
   -- by native root name. Follow that declared mapping without inventing a
   -- successful observation from the mere presence of a frame.
   local root=object.roots and object.roots[name]
   local surfaceID=root and root.spec and root.spec.id
   if not observed and surfaceID then observed=object.surfaceStates and object.surfaceStates[surfaceID] end
   if id=="meters" and name=="DamageMeter" then
    -- There is intentionally no native frame paint/readback receipt. State
    -- above is provider readiness; this row documents its native relationship.
    lines[#lines+1]=prefix..token(name).."=NATIVE_FRAME_UNMODIFIED/CVAR_HANDOFF_ONLY"
   else
    lines[#lines+1]=prefix..token(name).."="..(observed and token(observed.kind) or "NOT_OBSERVED").."/"..(observed and token(observed.reason) or "ROOT_CENSUS_ONLY")
   end
  end
 end
 if M.DelegatedNative and M.DelegatedNative.Report then lines[#lines+1]=M.DelegatedNative:Report() end
 return table.concat(lines,"\n")
end
