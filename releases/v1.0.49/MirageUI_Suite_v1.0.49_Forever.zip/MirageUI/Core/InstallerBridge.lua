local _,M=...
-- Local, read-only handoff to MirageUI Installer. WoW owns persistence; this
-- module never opens a socket, writes a file, or requests an upload. The
-- installer reads only the designated table after separate local consent.
local S=M.Safety
local B={status="NOT_STARTED",reason="NOT_STARTED",schema=1}
M.InstallerBridge=B
local components={"MirageUI","MirageUIOptions","CursorCompanion","MirageUISanctuary","Wealthcraft",
 "MirageIntel_Core","MirageIntel_Map","MirageIntel_Navigate","MirageIntel_Gather","MirageIntel_Insight"}
local providerIDs={"main","units","groups","minimap","nameplates","auras","cooldowns","meters","casts","alerts",
 "chat","tooltips","maps","objectives","inventory","tasks","character","system"}
local owners={Core=true,Cursor=true,Minimap=true,Chat=true,Tooltips=true,QuestTracker=true,UnitFrames=true,
 Nameplates=true,ActionBars=true,UnderCharacterHUD=true,ResourceBars=true,Auras=true,Cooldowns=true,PartyRaid=true,
 BlizzardSkin=true,Bags=true,DataBars=true,DamageMeters=true,PvP=true,TacticalSignals=true,Preparations=true,Notifications=true}
local function token(value,fallback)
 return S:Text(value) and #value<=96 and value:match("^[A-Za-z][A-Za-z0-9_%.:%-]*$") and value or fallback or "UNKNOWN"
end
local function version(value)
 return S:Text(value) and #value<=64 and value:match("^[0-9][A-Za-z0-9%.%+%-]*$") and value or "UNKNOWN"
end
local function integer(value,maximum)
 if S:Text(value) and #value<=12 and value:match("^%d+$") then value=tonumber(value) end
 return S:Number(value) and value>=0 and value<=(maximum or 2147483647) and math.floor(value) or 0
end
local function epoch()
 local n=S:Public(time,"number") or S:Public(GetServerTime,"number")
 return n and n>=946684800 and n<=4102444800 and math.floor(n) or nil
end
local function publicTable(value)
 return S:Readable(value) and type(value)=="table" and getmetatable(value)==nil
end
function B:Build(trigger)
 if not M.state or not M.state.initialized then return nil,"CORE_NOT_INITIALIZED" end
 local stamp=epoch();if not stamp then return nil,"TIMESTAMP_UNAVAILABLE" end
 local client=M.Client or {}
 local activation="UNAVAILABLE"
 if M.Diagnostics and type(M.Diagnostics.ActivationState)=="function" then
  local ok,row=pcall(M.Diagnostics.ActivationState,M.Diagnostics)
  if ok and publicTable(row) then activation=token(row.code) end
 end
 local animation,recovery=M.StartupAnimation or {},M.SessionRecovery or {}
 local snapshot={schema=1,suiteVersion=version(M.version),packageId=token(M.BuildInfo and M.BuildInfo.id),
  channel="test",snapshotAt=stamp,sessionId=integer(M.Incidents and M.Incidents.session),trigger=token(trigger),activation=activation,
  game={family=token(client.family),version=version(client.patch),build=integer(client.build),interface=integer(client.interface)},
  startup={state=token(animation.state),reason=token(animation.reason),elapsedMs=integer(animation.elapsedMs),
   enabled=type(animation.GetPreference)=="function" and animation:GetPreference("enabled") or false,
   reduceMotion=type(animation.GetPreference)=="function" and animation:GetPreference("reduceMotion") or false},
  recovery={phase=token(recovery.status),reason=token(recovery.reason),attempts=integer(recovery.attempts,3)},
  components={},providers={},incidents={}}
 local metadata=C_AddOns and C_AddOns.GetAddOnMetadata or GetAddOnMetadata
 local loaded=C_AddOns and C_AddOns.IsAddOnLoaded or IsAddOnLoaded
 for _,name in ipairs(components) do
  snapshot.components[name]={version=version(S:Public(metadata,"string",name,"Version")),loaded=S:Public(loaded,"boolean",name)==true}
 end
 local rework=M.Rework
 for _,id in ipairs(providerIDs) do
  local row=rework and rework.providers and rework.providers[id]
  snapshot.providers[id]={state=token(row and (row.readiness or row.state)),reason=token(row and (row.readinessReason or row.failureReason or row.reason))}
 end
 local history=M.Incidents and M.Incidents.history
 if publicTable(history) then
  for i=math.max(1,#history-15),math.min(#history,1024) do
   local row=history[i]
   if publicTable(row) then
    snapshot.incidents[#snapshot.incidents+1]={kind=token(row.kind),owner=owners[row.owner] and row.owner or "Core",
     phase=token(row.phase),reason=token(row.reason),count=integer(row.count),session=integer(row.session)}
   end
  end
 end
 return snapshot
end
function B:Refresh(trigger)
 -- Preserve a future schema rather than destroying data with an older addon.
 local prior=MirageUIInstallerSnapshot
 if prior~=nil and (not publicTable(prior) or prior.schema~=1) then
  self.status="UNAVAILABLE";self.reason="UNKNOWN_SNAPSHOT_PRESERVED";return false
 end
 local ok,snapshot,reason=pcall(self.Build,self,trigger or "STATE_CHANGED")
 if not ok or not snapshot then self.status="UNAVAILABLE";self.reason=ok and reason or "SNAPSHOT_UNAVAILABLE";return false end
 MirageUIInstallerSnapshot=snapshot
 self.status="READY";self.reason="AWAITING_GAME_SAVE";self.snapshotAt=snapshot.snapshotAt
 return true
end
function B:Request(trigger)
 self.requestReason=token(trigger)
 if self.queued then return end
 if not C_Timer or type(C_Timer.After)~="function" then self:Refresh(self.requestReason);return end
 self.queued=true
 local okay=pcall(C_Timer.After,.5,function()
  B.queued=false
  B:Refresh(B.requestReason)
 end)
 if not okay then self.queued=false;self:Refresh(self.requestReason) end
end
function B:Report()
 return "installer_snapshot="..token(self.status).."; reason="..token(self.reason).."; schema=1; transport=LOCAL_SAVED_VARIABLES"
  .."; save_boundary=GAME_OWNED; installer_read=SEPARATE_OPT_IN; upload=NONE; contains_player_identity=false"
end
local event=M.Event
function M:Event(name,...)
 local a,b=event(self,name,...)
 if name=="PLAYER_LOGOUT" then B:Refresh("LOGOUT")
 elseif name=="PLAYER_ENTERING_WORLD" then B:Request("WORLD_ENTERED")
 elseif name=="ADDON_LOADED" and self.state and self.state.initialized then
  local addon=...
  for _,id in ipairs(components) do if addon==id then B:Request("COMPONENT_LOADED");break end end
 end
 return a,b
end
if M.StartupPresentation and M.StartupPresentation.ProviderState then
 local observe=M.StartupPresentation.ProviderState
 function M.StartupPresentation:ProviderState(id,state,reason,...)
  local old=self.providers and self.providers[id]
  local priorState,priorReason=old and old.state,old and old.reason
  local a,b=observe(self,id,state,reason,...)
  local current=self.providers and self.providers[id]
  if current and (priorState~=current.state or priorReason~=current.reason) then B:Request("PROVIDER_STATE") end
  return a,b
 end
end
if M.SessionRecovery and M.SessionRecovery.Finish then
 local finish=M.SessionRecovery.Finish
 function M.SessionRecovery:Finish(...)
  local a,b=finish(self,...);B:Request("SESSION_RECOVERY");return a,b
 end
end
if M.Incidents and M.Incidents.Record then
 local record=M.Incidents.Record
 function M.Incidents:Record(...)
  local a,b=record(self,...)
  if a then B:Request("INCIDENT_RECORDED") end
  return a,b
 end
end
if M.Diagnostics and M.Diagnostics.Export then
 local export=M.Diagnostics.Export
 function M.Diagnostics:Export(...)
  B:Refresh("SUPPORT_REQUEST")
  return export(self,...).."\n"..B:Report()
 end
end
