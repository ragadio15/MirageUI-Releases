local _,M=...
-- Explicit sequential Pet-bank inspection; not ownership, readiness or actions.
local S=M.Safety
local P={epoch=0};M.PetSpellbook=P
local sourcePin=M.Client:NewSourcePinLookup()
local function sourceAllowed()
 local c,a,p,state=M.Client,M.adapter,M.profile,M.state;local pin=c and sourcePin(c.family,c.build)
 local mod=M.modules and M.modules.Preparations;local cfg=p and p.modules and p.modules.Preparations
 return c and type(c.IsRuntimeClient)=="function" and c:IsRuntimeClient() and state.initialized==true and state.world==true and not state.safe and not state.cinematic and p.enabled==true and mod and mod.initialized==true and not mod.quarantined and not mod.suspended and cfg and cfg.enabled==true
end
-- Read supplies its private counted probe; ordinary UI eligibility uses one probe.
function P:Allowed(combatProbe)
 local combat;if combatProbe then combat=combatProbe() else combat=S:InCombat() end
 return combat==false and sourceAllowed() or false
end
function P:Invalidate() self.epoch=self.epoch+1 end
local function counts() return {inspectedSlots=0,shownSpells=0,nonSpellSlots=0,unknownSlots=0,changedSlots=0} end
local function output(self) return {state="UNAVAILABLE",bank="PET",client=M.Client.key,epoch=self.epoch,contextEpoch=M.Policy.contextEpoch,callCount=0,observationCalls=0,counts=counts(),rows={}} end
local function read(self,request,out)
 local client,adapter,profile,state,policy,modules=M.Client,M.adapter,M.profile,M.state,M.Policy,M.modules
 local mod=modules.Preparations;local configs=profile and profile.modules;local cfg=configs and configs.Preparations
 local refs=M.References;local textMethod=refs and refs.Text
 local allowed,readMethod,invalidate=self.Allowed,self.Read,self.Invalidate
 local book,enum=C_SpellBook,Enum
 local exists,guidFn,combatFn=UnitExists,UnitGUID,InCombatLockdown
 local readable,fieldAccess,safetyText=S.Readable,S.FieldAccess,S.Text
 local secret,access,tableAccess=issecretvalue,canaccessvalue,canaccesstable
 local cap,scope=policy.capabilityEpoch,policy.scopeEpoch
 local cancelled,budget=false,false;local bankValues,itemValues
 -- Capture API bindings before any eligibility/readability callback. These are
 -- namespace bindings, not native returned observations or inferred secret data.
 local has=type(book)=="table" and rawget(book,"HasPetSpells")
 local info=type(book)=="table" and rawget(book,"GetSpellBookItemInfo")
 local bankTable=type(enum)=="table" and rawget(enum,"SpellBookSpellBank")
 local itemTable=type(enum)=="table" and rawget(enum,"SpellBookItemType")
 local initialBanks,initialItems={},{}
 -- Opaque source-binding snapshots are qualified below before any value comparison.
 for _,k in ipairs({"Pet","Player"}) do if type(bankTable)=="table" then initialBanks[k]=rawget(bankTable,k) end end
 for _,k in ipairs({"None","Spell","FutureSpell","PetAction","Flyout"}) do if type(itemTable)=="table" then initialItems[k]=rawget(itemTable,k) end end
 local seals={};local function plain(v) return type(v)=="table" and getmetatable(v)==nil end
 local function rawSame(record,values,keys)
  if not plain(record) then return false end
  for _,key in ipairs(keys) do local v=rawget(record,key);if type(v)=="table" and not plain(v) then return false end;if v~=values[key] then return false end end
  return true
 end
 local sourceKeys={"key","family","patch","build","interface","allowed","sourceMatched","experimental"};local clientValues={}
 local adapterKeys={"family","patch","build","interface","sourceCommit"};local adapterValues={}
 for _,k in ipairs(sourceKeys) do clientValues[k]=client[k] end
 for _,k in ipairs(adapterKeys) do adapterValues[k]=adapter[k] end
 local function pure()
  if cancelled then return false end
  local ok=plain(self) and plain(client) and plain(adapter) and plain(profile) and plain(state) and plain(policy) and plain(modules) and plain(mod) and plain(configs) and plain(cfg) and plain(refs) and plain(S) and M.PetSpellbook==self and self.Allowed==allowed and self.Read==readMethod and self.Invalidate==invalidate and self.epoch==out.epoch and M.Client==client and M.adapter==adapter and M.profile==profile and M.state==state and M.Policy==policy and M.modules==modules and modules.Preparations==mod and profile.modules==configs and configs.Preparations==cfg and policy.contextEpoch==out.contextEpoch and policy.capabilityEpoch==cap and policy.scopeEpoch==scope and M.References==refs and refs and refs.Text==textMethod and M.Safety==S and S.Readable==readable and S.FieldAccess==fieldAccess and S.Text==safetyText and issecretvalue==secret and canaccessvalue==access and canaccesstable==tableAccess and C_SpellBook==book and Enum==enum and UnitExists==exists and UnitGUID==guidFn and InCombatLockdown==combatFn and rawSame(client,clientValues,sourceKeys) and rawSame(adapter,adapterValues,adapterKeys) and sourceAllowed()
  if ok then ok=plain(book) and rawget(book,"HasPetSpells")==has and rawget(book,"GetSpellBookItemInfo")==info and plain(enum) and rawget(enum,"SpellBookSpellBank")==bankTable and rawget(enum,"SpellBookItemType")==itemTable end
  if ok and bankValues then ok=plain(enum) and rawget(enum,"SpellBookSpellBank")==bankTable and rawget(enum,"SpellBookItemType")==itemTable and rawSame(bankTable,bankValues,{"Pet","Player"}) and rawSame(itemTable,itemValues,{"None","Spell","FutureSpell","PetAction","Flyout"}) end
  if not ok then cancelled=true end
  return not cancelled
 end
 local function live()
  if not pure() then return false end
  if request then local ok,v=pcall(request);if not ok or not readable(S,v) or v~=true then cancelled=true;return false end end
  return pure()
 end
 local function qualified(v) if not live() then return false end;local ok=readable(S,v);return live() and ok end
 local function field(record,key)
  if not live() then return nil,"UNKNOWN" end
  local v,status=fieldAccess(S,record,key)
  if not live() then return nil,"UNKNOWN" end
  return v,status
 end
 local function integer(v,min,max) return qualified(v) and type(v)=="number" and v==v and v>=min and v<=max and v%1==0 end
 local function text(v,limit,empty)
  if not qualified(v) then return false end
  local ok=textMethod and textMethod(refs,v,limit,false,empty)
  return live() and ok==true
 end
 local function failure(kind,reason)
  out.state=cancelled and "INVALIDATED" or kind;out.reason=cancelled and "REQUEST_RETIRED" or reason;out.rows={};out.counts=counts();return out
 end
 local function combat()
  if not live() then return true end
  if out.callCount>=1024 then budget=true;return true end
  if type(combatFn)~="function" then return true end
  out.callCount=out.callCount+1
  local ok,v=pcall(combatFn)
  if not live() or not ok or not qualified(v) then return true end
  return type(v)~="boolean" or v~=false
 end
 local function gate()
  if not live() then return false end
  local ok=allowed(self,combat)
  return live() and ok==true
 end
 local function observe(fn,...)
  if not gate() then if not budget then cancelled=true end;return false end
  if out.callCount>=1024 or out.observationCalls>=265 then budget=true;return false end
  if type(fn)~="function" then return false end
  out.callCount=out.callCount+1;out.observationCalls=out.observationCalls+1
  local ok,a,b=pcall(fn,...)
  if not gate() then if not budget then cancelled=true end;return false end
  if not ok then return false end
  -- Each native output is independently qualified before comparison/packing.
  if not qualified(a) or not qualified(b) then return false end
  return true,a,b
 end
 if not sourceAllowed() then return failure("UNAVAILABLE","SOURCE_UNAVAILABLE") end
 if not gate() then return failure("UNAVAILABLE",budget and "CALL_BUDGET" or "ELIGIBILITY_UNAVAILABLE") end
 if not qualified(book) or not plain(book) or not qualified(enum) or not plain(enum) then return failure("UNAVAILABLE","ENUM_UNAVAILABLE") end
 local capturedHas=field(book,"HasPetSpells");local capturedInfo=field(book,"GetSpellBookItemInfo")
 if capturedHas~=has or capturedInfo~=info then cancelled=true;return failure("INVALIDATED","REQUEST_RETIRED") end
 if type(has)~="function" or type(info)~="function" then return failure("UNAVAILABLE","BOOK_UNAVAILABLE") end
 if field(enum,"SpellBookSpellBank")~=bankTable or field(enum,"SpellBookItemType")~=itemTable then cancelled=true;return failure("INVALIDATED","REQUEST_RETIRED") end
 if not qualified(bankTable) or not plain(bankTable) or not qualified(itemTable) or not plain(itemTable) then return failure("UNAVAILABLE","ENUM_UNAVAILABLE") end
 local bv,iv={},{};local seen={}
 for _,key in ipairs({"Pet","Player"}) do local v=field(bankTable,key);local initial=initialBanks[key];if not integer(initial,0,2147483647) then return failure("UNAVAILABLE","ENUM_UNAVAILABLE") end;if v~=initial then cancelled=true;return failure("INVALIDATED","REQUEST_RETIRED") end;if not integer(v,0,2147483647) or seen[v] then return failure("UNAVAILABLE","ENUM_UNAVAILABLE") end;bv[key]=v;seen[v]=true end
 seen={}
 for _,key in ipairs({"None","Spell","FutureSpell","PetAction","Flyout"}) do local v=field(itemTable,key);local initial=initialItems[key];if not integer(initial,0,2147483647) then return failure("UNAVAILABLE","ENUM_UNAVAILABLE") end;if v~=initial then cancelled=true;return failure("INVALIDATED","REQUEST_RETIRED") end;if not integer(v,0,2147483647) or seen[v] then return failure("UNAVAILABLE","ENUM_UNAVAILABLE") end;iv[key]=v;seen[v]=true end
 bankValues,itemValues=bv,iv
 if not live() then return failure("INVALIDATED","REQUEST_RETIRED") end
 local function bracket()
  local ok,present=observe(exists,"pet")
  if not ok or present~=true then return nil,"PET_UNAVAILABLE" end
  local good,guid=observe(guidFn,"pet")
  if not good or not text(guid,128,false) then return nil,"PET_UNAVAILABLE" end
  local success,count,token=observe(has)
  if not success then return nil,"BOOK_UNAVAILABLE" end
  if count==nil and token==nil then return {guid=guid,kind="NOT_REPORTED"} end
  if not integer(count,0,math.huge) then return nil,"BOOK_UNAVAILABLE" end
  if count>128 then return nil,"SLOT_LIMIT" end
  if not text(token,128,false) then return nil,"BOOK_UNAVAILABLE" end
  return {guid=guid,kind="COUNT",count=count,token=token}
 end
 local first,why=bracket()
 if not first then return failure(why=="PET_UNAVAILABLE" and "PET_SAMPLE_UNAVAILABLE" or why=="SLOT_LIMIT" and "LIMIT_UNAVAILABLE" or "UNAVAILABLE",budget and "CALL_BUDGET" or why) end
 local function sameBracket(a)
  if not a or a.guid~=first.guid then return false,"PET_CHANGED" end
  if a.kind~=first.kind or a.count~=first.count or a.token~=first.token then return false,"BOOK_CHANGED" end
  return true
 end
 local fields={"itemType","actionID","spellID","name","subName","isPassive"}
 local function sample(slot)
  local ok,record=observe(info,slot,bv.Pet)
  if not ok or not qualified(record) or not plain(record) then return {kind="UNKNOWN"} end
  local kind=field(record,"itemType")
  if not integer(kind,0,2147483647) or not seen[kind] then return {kind="UNKNOWN"} end
  if kind~=iv.Spell then return {kind="NON_SPELL",itemType=kind,record=record,values={itemType=kind},keys={"itemType"}} end
  local values={itemType=kind}
  for _,key in ipairs({"actionID","spellID","name","subName","isPassive"}) do local value,status=field(record,key);if status~="KNOWN" then return {kind="UNKNOWN"} end;values[key]=value end
  if not integer(values.actionID,1,2147483647) or not integer(values.spellID,1,2147483647) or not text(values.name,64,false) or not text(values.subName,64,true) or not qualified(values.isPassive) or type(values.isPassive)~="boolean" then return {kind="UNKNOWN"} end
  if not rawSame(record,values,fields) then return {kind="UNKNOWN"} end
  return {kind="SPELL",record=record,values=values,keys=fields}
 end
 local n=first.count or 0;local initial={}
 -- Reserve every final slot/bracket/gate, never a prefix on budget shortage.
 if out.observationCalls+2*n+6>265 or out.callCount+3*(2*n+6)+1>1024 then budget=true;return failure("LIMIT_UNAVAILABLE","CALL_BUDGET") end
 for slot=1,n do initial[slot]=sample(slot);out.counts.inspectedSlots=slot;if not live() then return failure("INVALIDATED","REQUEST_RETIRED") end end
 local middle,middleWhy=bracket();if not middle then return failure("UNAVAILABLE",budget and "CALL_BUDGET" or middleWhy) end
 local same,reason=sameBracket(middle)
 if not same then return failure("UNAVAILABLE",budget and "CALL_BUDGET" or reason) end
 for slot=1,n do
  local a,b=initial[slot],sample(slot);local category
  if a.kind=="UNKNOWN" then category="unknownSlots"
  elseif a.kind~=b.kind or a.kind=="NON_SPELL" and a.itemType~=b.itemType then category="changedSlots"
  elseif a.kind=="SPELL" then
   local equal=true;for _,key in ipairs(fields) do if a.values[key]~=b.values[key] then equal=false end end
   if equal then local v=a.values;out.rows[#out.rows+1]={slot=slot,actionID=v.actionID,spellID=v.spellID,name=v.name,subName=v.subName,passive=v.isPassive};category="shownSpells" else category="changedSlots" end
  else category="nonSpellSlots" end
  out.counts[category]=out.counts[category]+1
  if category=="shownSpells" or category=="nonSpellSlots" then seals[#seals+1]=a;seals[#seals+1]=b end
  if not live() then return failure("INVALIDATED","REQUEST_RETIRED") end
 end
 local final,finalWhy=bracket();if not final then return failure("UNAVAILABLE",budget and "CALL_BUDGET" or finalWhy) end
 same,reason=sameBracket(final)
 if not same then return failure("UNAVAILABLE",budget and "CALL_BUDGET" or reason) end
 if not gate() then return failure("UNAVAILABLE",budget and "CALL_BUDGET" or "ELIGIBILITY_UNAVAILABLE") end
 -- No callback/security/native probe follows these pure seals.
 if not pure() then return failure("INVALIDATED","REQUEST_RETIRED") end
 for _,entry in ipairs(seals) do if not rawSame(entry.record,entry.values,entry.keys) then return failure("UNAVAILABLE","OBSERVATION_CHANGED") end end
 out.counts.reportedSlots=first.count
 if first.kind=="NOT_REPORTED" then out.state="PET_BOOK_NOT_REPORTED"
 elseif n==0 then out.state="OBSERVED_SCOPED_EMPTY"
 elseif out.counts.shownSpells==n then out.state="OBSERVED_SCOPED_SNAPSHOT"
 else out.state="PARTIAL_UNAVAILABLE" end
 return out
end
function P:Read(request)
 local out=output(self)
 if self.reading then self:Invalidate();out.state="INVALIDATED";out.reason="REQUEST_RETIRED";return out end
 self.reading=true;local ok,result=pcall(read,self,request,out);self.reading=false
 if ok then return result end
 out.state="INVALIDATED";out.reason="REQUEST_RETIRED";out.rows={};out.counts=counts();return out
end
