local _,M=...
-- P17: a temporary preparation workspace over the real action buttons.
-- Shortcut edits are an explicit draft. Native cursor placements and macro
-- edits remain game-owned; they are never advertised as a reversible draft.
local S,K=M.Safety,M.ActionKeys
local W={status="CLOSED"}
M.KeybindWorkspace=W
local function read(o,k,kind,...)
 if o and type(o[k])=="function" then return S:Public(o[k],kind,o,...) end
end
local function call(o,k,...)
 if not o or type(o[k])~="function" then return false end
 local ok,result=pcall(o[k],o,...)
 return ok and result~=false
end
local function invoke(fn,...)
 if type(fn)~="function" then return false end
 local ok,result=pcall(fn,...)
 return ok and result~=false
end
local pointsMatch
-- Panel areas deliberately become nil while the native sources are arranged.
-- Safety:Public treats nil as unknown for scalar consumers; here a successful,
-- readable nil is the required native result, not a failed observation.
local function optionalAttribute(frame,name)
 if not frame or type(frame.GetAttribute)~="function" then return nil,"UNSUPPORTED" end
 local ok,value=pcall(frame.GetAttribute,frame,name)
 if not ok then return nil,"UNKNOWN" end
 if not S:Readable(value) then return nil,"RESTRICTED" end
 if value~=nil and type(value)~="string" then return nil,"UNKNOWN" end
 return value,"KNOWN"
end
local function closeNumber(a,b)
 return S:Number(a) and S:Number(b) and math.abs(a-b)<=math.max(.0001,math.abs(b)*.00001)
end
local function token(key,context) return tostring(context or "legacy")..":"..key end
function W:StoredDraft()
 local db=_G.MirageUIKeybindCharacterDB
 if db==nil then return nil end
 if type(db)~="table" or getmetatable(db)~=nil or rawget(db,"version")~=1 then return nil,"Unfinished keybind data has an unsupported format. It has been preserved." end
 local rows=rawget(db,"changes");local set=rawget(db,"bindingSet")
 if type(rows)~="table" or getmetatable(rows)~=nil or (set~=1 and set~=2) then return nil,"Unfinished keybind data could not be read. It has been preserved." end
 local draft={changes={},placements=rawget(db,"placements")==true,bindingSet=set};local count=0
 for _,p in pairs(rows) do
  count=count+1
  if count>512 or type(p)~="table" or getmetatable(p)~=nil or not K:IsAction(rawget(p,"command")) or not K:KeyValid(rawget(p,"key")) then return nil,"Unfinished keybind data could not be read. It has been preserved." end
  local before,after,context=rawget(p,"before"),rawget(p,"after"),rawget(p,"context")
  if not S:Text(before) or #before>512 or not S:Text(after) or (after~="" and not K:IsAction(after))
   or (context~=nil and (not S:Number(context) or context<0 or context%1~=0)) then return nil,"Unfinished keybind data could not be read. It has been preserved." end
  local clean={command=p.command,key=p.key,before=before,after=after,context=context};clean.id=token(clean.key,context)
  if draft.changes[clean.id] then return nil,"Unfinished keybind data contains duplicate entries. It has been preserved." end
  draft.changes[clean.id]=clean
 end
 return draft
end
function W:Persist()
 local a=self.session
 if M.Profiles.readOnly then return false end
 if not a or not self:IsDirty() then _G.MirageUIKeybindCharacterDB=nil;return true end
 local rows={}
 for _,p in pairs(a.changes) do rows[#rows+1]={command=p.command,key=p.key,before=p.before,after=p.after,context=p.context} end
 table.sort(rows,function(x,y) return token(x.key,x.context)<token(y.key,y.context) end)
 _G.MirageUIKeybindCharacterDB={version=1,bindingSet=a.bindingSet,changes=rows,placements=a.placements==true}
 return true
end
function W:AnnounceRecovered()
 if self.announced or self.session then return end
 local draft,why=self:StoredDraft()
 if draft and (next(draft.changes) or draft.placements) then
  self.announced=true;M:Print("An unfinished keybind draft was recovered. Open Customize UI → Configure keybinds to save or discard it.")
 elseif why then self.announced=true;M:Print(why) end
end
function W:IsActive() return self.session~=nil and M.state.keybindWorkspace==true and not self.suspended end
function W:IsDirty()
 local a=self.session
 return a and (next(a.changes)~=nil or a.placements or (MacroFrame and S:Field(MacroFrame,"textChanged")==true)) or false
end
function W:Current()
 local a=self.session
 if not a or not self:IsActive() then return false,"Keybind mode is not active." end
 local allowed,why=K:Allowed();if not allowed then return false,why end
 if a.profile~=M.profile or a.bindingSet~=K:BindingSet() then return false,"The active profile or binding set changed. Exit and reopen keybind mode." end
 return true
end
function W:Notice(text)
 self.message=text or ""
 if self.notice then self.notice:SetText(self.message) end
end
function W:DraftOwner(key,context)
 local a=self.session;local c=a and a.changes[token(key,context)]
 return c and c.after or K:Owner(key,context,false)
end
function W:Plan(command,key,after)
 local allowed,why=self:Current();if not allowed then return nil,why end
 if not K:IsAction(command) or not K:KeyValid(key) then return nil,"Use a keyboard key, modifier combination, mouse wheel or extra mouse button." end
 local context,valid=K:Context(command);if not valid then return nil,"The shortcut context is unavailable." end
 local before=K:Owner(key,context,false);local effective=K:Owner(key,context,true)
 if before==nil or effective==nil then return nil,"That shortcut cannot be read on this client." end
 if before~=effective then return nil,"A temporary game or addon override controls that key. Leave that mode first." end
 local id=token(key,context);local prior=self.session.changes[id]
 if prior and prior.before~=before then return nil,"That key changed outside this workspace. Save was stopped to preserve the newer assignment." end
 return {id=id,key=key,command=command,context=context,before=before,after=after}
end
function W:Put(plan)
 local a=self.session
 a.changes[plan.id]=plan.before~=plan.after and plan or nil
 a.revision=a.revision+1
 self:Persist()
end
function W:CanStage(plans)
 local present,count={},0
 for id in pairs(self.session.changes) do present[id]=true;count=count+1 end
 for _,plan in ipairs(plans) do
  local wanted=plan.before~=plan.after
  if wanted and not present[plan.id] then count=count+1
  elseif not wanted and present[plan.id] then count=count-1 end
  present[plan.id]=wanted
 end
 if count>512 then return false,"Save your current shortcut draft before adding more changes." end
 return true
end
function W:Assign(command,key)
 local plan,why=self:Plan(command,key,command)
 if not plan then self:Notice(why);return false,why end
 local admitted,message=self:CanStage({plan});if not admitted then self:Notice(message);return false,message end
 local displaced=self:DraftOwner(key,plan.context)
 self:Put(plan)
 self:Notice(K:Label(key).." → "..K:ActionLabel(command)..(displaced and displaced~="" and displaced~=command and " · replaces "..K:ActionLabel(displaced) or "")..". Save to apply.")
 self:RefreshLabels();return true
end
function W:Clear(command)
 local allowed,why=self:Current();if not allowed then self:Notice(why);return false,why end
 local keys,message=K:Keys(command);if not keys then self:Notice(message);return false,message end
 local context,valid=K:Context(command);if not valid then return false end
 local seen,list={},{}
 for _,key in ipairs(keys) do seen[key]=true end
 for _,change in pairs(self.session.changes) do if change.context==context and change.after==command then seen[change.key]=true end end
 for key in pairs(seen) do
  if self:DraftOwner(key,context)==command then
   local plan,errorText=self:Plan(command,key,"")
   if not plan then self:Notice(errorText);return false,errorText end
   list[#list+1]=plan
  end
 end
 local admitted,message=self:CanStage(list);if not admitted then self:Notice(message);return false,message end
 for _,plan in ipairs(list) do self:Put(plan) end
 self:Notice(#list>0 and "Shortcuts cleared for "..K:ActionLabel(command)..". Save to apply." or "This action has no assigned shortcuts.")
 self:RefreshLabels();return true
end
function W:Save()
 local allowed,why=self:Current();if not allowed then self:Notice(why);return false,why end
 local a=self.session;local revision=a.revision;local plans={}
 for _,change in pairs(a.changes) do plans[#plans+1]=change end
 table.sort(plans,function(x,y) return x.id<y.id end)
 local function current() return self.session==a and a.revision==revision and self:Current()==true end
 for _,p in ipairs(plans) do
  local valid,message=K:StillValid({command=p.command,key=p.key,context=p.context,bindingSet=a.bindingSet,before=p.before})
  if not current() or not valid then self:Notice(message or "The shortcut draft changed. Nothing was saved.");return false end
 end
 local written={}
 local function rollback()
  local restored=true
  for i=#written,1,-1 do
   local p=written[i];local owner=K:Owner(p.key,p.context,false)
   if owner~=p.before then
    if S:InCombat() or K:BindingSet()~=a.bindingSet or owner~=p.after or not K:Write(p.key,p.before,p.context)
      or K:Owner(p.key,p.context,false)~=p.before then restored=false end
   end
  end
  if #written>0 and restored then restored=K:Save(a.bindingSet) end
  self.status=restored and "SAVE_FAILED_RESTORED" or "RECOVERY_REQUIRED"
  self:Notice(restored and "The save could not be completed. Previous shortcuts were restored; your draft is retained." or "A shortcut changed during saving. Check the game's Key Bindings before continuing; the draft is retained.")
  return false
 end
 for _,p in ipairs(plans) do
  if not current() then return rollback() end
  written[#written+1]=p
  if not K:Write(p.key,p.after,p.context) or K:Owner(p.key,p.context,false)~=p.after then return rollback() end
 end
 if #plans>0 and (not current() or not K:Save(a.bindingSet)) then return rollback() end
 for _,p in ipairs(plans) do if not current() or K:Owner(p.key,p.context,false)~=p.after then return rollback() end end
 -- The native macro editor owns its pending text and validation.
 if MacroFrame and S:Field(MacroFrame,"textChanged")==true then
  local ok=call(MacroFrame,"SaveMacro")
  if not ok and type(MacroFrame_SaveMacro)=="function" then ok=pcall(MacroFrame_SaveMacro) end
  if not ok or S:Field(MacroFrame,"textChanged")==true then return rollback() end
 end
 if not current() then return rollback() end
 a.changes={};a.placements=false;a.revision=a.revision+1
 self.status="SAVED";if M.modules.ActionBars then M.modules.ActionBars.bindingsDirty=true end
 self:Persist()
 self:Notice("Saved. Native action placements are already applied.");self:RefreshLabels()
 return true
end
function W:PlacementChanged()
 if not self:IsActive() then return end
 if not self.session.placements then self.session.placements=true;self:Persist() end
 if self.saveButton then self.saveButton:SetText("Save") end
end
function W:Buttons()
 local result={};local a=M.Rework and M.Rework.MainAction;local families=M.Rework and M.Rework.ActionFamilies
 for bar=1,8 do
  local row=bar==1 and a or families and families.families and families.families["ActionBars.bar"..bar]
  for _,b in ipairs(row and row.buttons or {}) do result[#result+1]=b end
 end
 return result
end
function W:Hover(button)
 if not self:IsActive() or not K:IsAction(button.nativeCommand) then return end
 self.hovered=button
 if self.focusOutline then self.focusOutline:ClearAllPoints();self.focusOutline:SetAllPoints(button);self.focusOutline:Show() end
 self:RefreshLabels()
end
function W:Leave(button)
 if self.hovered~=button then return end
 self.hovered=nil;if self.focusOutline then self.focusOutline:Hide() end
end
function W:Hovered()
 local b=self.hovered
 if b and read(b,"IsVisible","boolean")==true and read(b,"IsMouseOver","boolean")==true then return b end
 self.hovered=nil;return nil
end
function W:Key(key)
 if not self:IsActive() or S:InCombat() or S:Typing() then return false end
 if self.confirm and self.confirm:IsShown() then
  if key=="ESCAPE" then self.confirm:Hide();return true end
  return false
 end
 local b=self:Hovered()
 if key=="ESCAPE" then
  if b then self:Clear(b.nativeCommand) else self.exitOnRelease=true end
  return true
 end
 if not b then return false end
 local captured=K:Capture(key)
 if captured then self:Assign(b.nativeCommand,captured) end
 -- Modifier-only events also stay in the workspace while over a slot.
 return true
end
function W:Mouse(button,key)
 if not self:IsActive() or S:InCombat() then return end
 self:Hover(button)
 if key=="LeftButton" then
  local kind,known=M.ActionEditing:CursorKind()
  if known and kind then M.ActionEditing:Drop(button) end
 elseif key~="RightButton" then
  local captured=K:Capture(key);if captured then self:Assign(button.nativeCommand,captured) end
 end
end
function W:RefreshLabels()
 if not self.session then return end
 for _,b in ipairs(self.buttons or {}) do
  local command=b.nativeCommand;local keys=K:Keys(command) or {};local context=K:Context(command);local seen,result={},{}
  for _,key in ipairs(keys) do if self:DraftOwner(key,context)==command then seen[key]=true end end
  for _,c in pairs(self.session.changes) do if c.after==command and c.context==context then seen[c.key]=true end end
  for key in pairs(seen) do result[#result+1]=key end;table.sort(result)
  if b.keybindDraftLabel then
   local a=M.Rework and M.Rework.MainAction
   b.keybindDraftLabel:SetText(result[1] and a and a.ShortKey and a:ShortKey(result[1]) or result[1] or "")
   if a and a.FitKeyLabel then a:FitKeyLabel(b.keybindDraftLabel,b,M.profile.modules.ActionBars,true) end
   b.keybindDraftLabel:SetShown(self:IsActive())
  end
  if b==self.hovered and self.selection then
   local summary=#result>0 and table.concat(result," / ",1,math.min(2,#result)) or "Unassigned"
   if #result>2 then summary=summary.." +"..(#result-2) end
   self.selection:SetText(K:ActionLabel(command).."  ·  "..summary)
  end
 end
 if self.saveButton then self.saveButton:SetText(self:IsDirty() and "Save" or "Saved") end
end
function W:CursorCapture(active)
 local bridge=_G.MirageUICursorNavBridge
 if type(bridge)=="table" and type(bridge.SetBindingCapture)=="function" then pcall(bridge.SetBindingCapture,active) end
end
function W:CloseSettings()
 for _,name in ipairs({"Workspace","ElementMap"}) do if M[name] and M[name].HidePreserve then M[name]:HidePreserve() end end
 if M.BindingEditor then M.BindingEditor:Close() end
 for _,name in ipairs({"PlayerSettings","Options","Editor","HUDOptions"}) do
  local o=M[name];if o and o.frame then call(o.frame,"Hide") end
 end
 if M.UI.CloseChoices then M.UI:CloseChoices() end
 if M.SuiteLauncher and M.SuiteLauncher.CloseTransient then M.SuiteLauncher:CloseTransient("KEYBIND_WORKSPACE") end
 local registry=_G.MirageUIAddonSettings
 if type(registry)=="table" then
  for _,name in ipairs({"MirageIntel_Core","MirageIntel_Map","MirageIntel_Navigate","MirageIntel_Gather","MirageIntel_Insight","MirageUISanctuary","Wealthcraft"}) do
   local entry=registry[name]
   if type(entry)=="table" and type(entry.close)=="function" then pcall(entry.close) end
  end
 end
 if WorldMapFrame and type(HideUIPanel)=="function" then pcall(HideUIPanel,WorldMapFrame) end
 local bridge=_G.MirageUICursorNavBridge
 if type(bridge)=="table" and type(bridge.CloseTransient)=="function" then pcall(bridge.CloseTransient) end
 M.state.edit=false
end
function W:Create()
 if self.frame then return end
 local f=CreateFrame("Frame","MirageKeybindWorkspace",UIParent);f:Hide();f:SetAllPoints(UIParent)
 f:SetFrameStrata("FULLSCREEN_DIALOG");f:EnableMouse(false);f:EnableKeyboard(true);f:SetPropagateKeyboardInput(true)
 self.frame=f
 local ts=math.max(.8,math.min(1.5,tonumber(M.profile.textScale) or 1))
 local p=CreateFrame("Frame",nil,f,"BackdropTemplate");p:EnableMouse(true);p:SetFrameLevel(f:GetFrameLevel()+10);p:SetSize(440,112*ts+40);p:SetPoint("BOTTOM",UIParent,"BOTTOM",0,16);M.UI:Backdrop(p,true);self.panel=p
 local hairline=p:CreateTexture(nil,"ARTWORK");hairline:SetColorTexture(.91,.61,.28,.85);hairline:SetPoint("TOPLEFT",16,-1);hairline:SetPoint("TOPRIGHT",-16,-1);hairline:SetHeight(1)
 local title=M.UI:Text(p,"Configure keybinds",16,-13*ts,16,408);M.UI:SetTextRole(title,"heading")
 M.UI:Text(p,"Drag actions to slots. Hover a slot and press a key.\nAdd Shift, Ctrl or Alt. Escape clears the hovered slot.",16,-38*ts,11,408)
 self.selection=M.UI:Text(p,"Choose an action slot",16,-70*ts,11,408);self.selection:SetHeight(15*ts)
 self.notice=M.UI:Text(p,"",16,-91*ts,10,408);self.notice:SetHeight(22*ts)
 self.saveButton=M.UI:Button(p,"Save",204,-112*ts,104,function() self:Save() end)
 self.exitButton=M.UI:Button(p,"Exit",320,-112*ts,104,function() self:RequestExit() end)
 self.focusOutline=CreateFrame("Frame",nil,f,"BackdropTemplate");self.focusOutline:EnableMouse(false)
 self.focusOutline:SetBackdrop({edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1});self.focusOutline:SetBackdropBorderColor(1,.78,.35,1);self.focusOutline:Hide()
 f:SetScript("OnKeyDown",function(_,key)
  if not self:IsActive() or S:InCombat() then if self.session then self:Suspend() end;return end
  local session=self.session
  local handled=self:Key(key)
  if self.session~=session or not self:IsActive() or S:InCombat() then return end
  self.consumedKeys=self.consumedKeys or {}
  if handled then self.consumedKeys[key]=true end
  f:SetPropagateKeyboardInput(not handled)
 end)
 f:SetScript("OnKeyUp",function(_,key)
  if not self:IsActive() or S:InCombat() then if self.session then self:Suspend() end;return end
  local consumed=self.consumedKeys and self.consumedKeys[key]
  if self.consumedKeys then self.consumedKeys[key]=nil end
  f:SetPropagateKeyboardInput(not consumed)
  -- Retain capture for the complete key gesture. Exiting on key-down would
  -- let the unmatched key-up execute a native binding or open the game menu.
  if key=="ESCAPE" and self.exitOnRelease then self.exitOnRelease=nil;self.exitQueued=true end
 end)
 f:SetScript("OnEvent",function(_,event,...)
  if event=="PLAYER_REGEN_DISABLED" or event=="PLAYER_LEAVING_WORLD" or event=="CINEMATIC_START" or event=="PLAY_MOVIE" then self:Suspend()
  elseif event=="PLAYER_REGEN_ENABLED" or event=="PLAYER_ENTERING_WORLD" or event=="CINEMATIC_STOP" then
   if self.suspended and not S:InCombat() and M.state.world and not M.state.cinematic then self:Resume() end
  elseif event=="ACTIONBAR_SLOT_CHANGED" or event=="UPDATE_MACROS" then self:PlacementChanged(...)
  elseif event=="UPDATE_BINDINGS" then if not self.saving then self:RefreshLabels() end
  elseif event=="DISPLAY_SIZE_CHANGED" or event=="UI_SCALE_CHANGED" then self.layoutPending=true end
 end)
 local elapsed=0
 f:SetScript("OnUpdate",function(_,dt)
  elapsed=elapsed+dt;if elapsed<.2 then return end;elapsed=0
  if self.exitQueued then self.exitQueued=nil;self:RequestExit();return end
  if self:IsActive() then
   if self.layoutPending and not S:InCombat() then
    self.layoutPending=nil;local placed,why=self:LayoutSources()
    if not placed then self:StopForLifecycle();self:Notice(why);return end
    M.ActionInterface:Layout(M.profile)
   end
   local ok,why=self:Current();if not ok then self:StopForLifecycle();self:Notice(why);return end
   if self.saveButton then self.saveButton:SetText(self:IsDirty() and "Save" or "Saved") end
  end
 end)
end
function W:SnapshotFrame(frame,shown)
 if not S:Frame(frame,false) then return nil end
 local scale=read(frame,"GetScale","number");local parent=read(frame,"GetParent");local width=read(frame,"GetWidth","number");local height=read(frame,"GetHeight","number")
 local count=read(frame,"GetNumPoints","number")
 if not scale or not parent or not width or not height or width<=0 or height<=0 or not count or count>8 then return nil end
 local points={}
 for i=1,count do
  local values={pcall(frame.GetPoint,frame,i)};if not values[1] then return nil end
  table.remove(values,1);for _,v in ipairs(values) do if not S:Readable(v) then return nil end end
  points[#points+1]=values
 end
 return {frame=frame,scale=scale,parent=parent,width=width,height=height,points=points,shown=shown==true,
  strata=read(frame,"GetFrameStrata","string"),level=read(frame,"GetFrameLevel","number")}
end
function W:DetachPanel(frame,shown,role,lease)
 if lease and lease.frame~=frame then return false,"The native source window changed during preparation." end
 if not lease then
  lease=self:SnapshotFrame(frame,shown);if not lease then return false,"A native source window could not be prepared." end
  self.sources[#self.sources+1]=lease
 end
 local name=read(frame,"GetName","string")
 local definition=name and type(UIPanelWindows)=="table" and S:Field(UIPanelWindows,name)
 local defined=read(frame,"GetAttribute",nil,"UIPanelLayout-defined")==true
 if defined then
  local area,status=optionalAttribute(frame,"UIPanelLayout-area")
  if status~="KNOWN" then return false,"The native window layout cannot be observed." end
  lease.area=area
 elseif type(definition)=="table" then lease.area=S:Field(definition,"area") end
 lease.panel=definition~=nil;lease.role=role
 if lease.panel then
  if type(HideUIPanel)~="function" or type(SetUIPanelAttribute)~="function" then return false,"The native panel manager cannot prepare this workspace." end
  lease.hideAttempt=true
  if not invoke(HideUIPanel,frame) then return false,"The native window could not leave its normal layout." end
  lease.areaAttempt=true
  local wrote=invoke(SetUIPanelAttribute,frame,"area",nil)
  local area,known=optionalAttribute(frame,"UIPanelLayout-area")
  if not wrote or known~="KNOWN" or area~=nil then return false,"The native window layout could not be prepared." end
 elseif not call(frame,"Hide") then return false,"The native source window could not be prepared." end
 lease.parentAttempt=true;lease.appliedParent=UIParent
 if not call(frame,"SetParent",UIParent) or read(frame,"GetParent")~=UIParent then return false,"The native window parent is unavailable." end
 if not call(frame,"SetFrameStrata","DIALOG") or read(frame,"GetFrameStrata","string")~="DIALOG"
  or not call(frame,"Show") or read(frame,"IsShown","boolean")~=true then return false,"The native source window could not be displayed." end
 return true
end
function W:OpenSources()
 if self.restorePending and not self:RestoreSources() then return false,"Native source windows are still restoring. Exit and retry." end
 self.sources={};self.bagsBefore={}
 if type(IsBagOpen)~="function" then return false,"The native bag state is unavailable." end
 for bag=0,math.min(10,tonumber(NUM_TOTAL_EQUIPPED_BAG_SLOTS) or tonumber(NUM_BAG_SLOTS) or 4) do
  local success,v=pcall(IsBagOpen,bag)
  if not success or not S:Readable(v) then return false,"The native bag state cannot be observed." end
  self.bagsBefore[bag]=v~=false and v~=nil
 end
 local spell=PlayerSpellsFrame or SpellBookFrame;local spellShown=spell and read(spell,"IsShown","boolean")==true
 local macroShown=MacroFrame and read(MacroFrame,"IsShown","boolean")==true
 local spellReceipt=spell and self:SnapshotFrame(spell,spellShown)
 if spell and not spellReceipt then return false,"The native spellbook could not be observed." end
 if spellReceipt then spellReceipt.role="spells";self.sources[#self.sources+1]=spellReceipt end
 -- Load with the game's helpers; initialize the spellbook's proper tab before
 -- detaching only its panel-area attribute. No native script is replaced.
 if not spellShown then
  local fn,arg
  if M.ClientUI then fn,arg=M.ClientUI:Route("spellbook") end
  if fn then pcall(fn,arg) elseif type(ToggleSpellBook)=="function" then pcall(ToggleSpellBook,BOOKTYPE_SPELL or "spell") end
 end
 spell=PlayerSpellsFrame or SpellBookFrame
 if not spell then return false,"The native spellbook is unavailable on this client." end
 local ok,why=self:DetachPanel(spell,spellShown,"spells",spellReceipt);if not ok then return false,why end
 if not MacroFrame then
  if type(MacroFrame_LoadUI)=="function" then pcall(MacroFrame_LoadUI)
  elseif type(UIParentLoadAddOn)=="function" then pcall(UIParentLoadAddOn,"Blizzard_MacroUI")
  elseif C_AddOns and type(C_AddOns.LoadAddOn)=="function" then pcall(C_AddOns.LoadAddOn,"Blizzard_MacroUI") end
 end
 if not MacroFrame and type(ShowMacroFrame)=="function" then pcall(ShowMacroFrame) end
 if not MacroFrame then return false,"The native macro window is unavailable on this client." end
 ok,why=self:DetachPanel(MacroFrame,macroShown,"macros");if not ok then return false,why end
 local opened
 if type(OpenAllBags)=="function" then opened=invoke(OpenAllBags)
 elseif type(ToggleAllBags)=="function" then opened=invoke(ToggleAllBags) end
 if not opened then return false,"The native bags could not open." end
 local observedBags=0
 local combined=ContainerFrameCombinedBags
 if combined and read(combined,"IsShown","boolean")==true then
  local bag=self:SnapshotFrame(combined,true);if bag then bag.role="bags";self.sources[#self.sources+1]=bag;observedBags=observedBags+1 end
 end
 for i=1,20 do
  local frame=_G["ContainerFrame"..i]
  if frame and frame~=combined and read(frame,"IsShown","boolean")==true and read(frame,"GetParent")~=combined then
   local bag=self:SnapshotFrame(frame,true);if bag then bag.role="bags";self.sources[#self.sources+1]=bag;observedBags=observedBags+1 end
  end
 end
 if observedBags==0 then return false,"The native bags did not become visible." end
 return self:LayoutSources()
end
function W:LayoutSources()
 if S:InCombat() then return end
 local width=read(UIParent,"GetWidth","number") or 1920;local height=read(UIParent,"GetHeight","number") or 1080
 local panelScale=math.min(1,width*.40/440,(height-32)/self.panel:GetHeight());self.panel:SetScale(panelScale)
 local bagHeight,bagWidth=0,1
 for _,lease in ipairs(self.sources or {}) do if lease.role=="bags" then
  bagHeight=bagHeight+(read(lease.frame,"GetHeight","number") or lease.height)+6;bagWidth=math.max(bagWidth,read(lease.frame,"GetWidth","number") or lease.width)
 end end
 local bagScale=math.min((width*.29-20)/bagWidth,(height*.46-16)/math.max(1,bagHeight));local bagY=16
 for _,lease in ipairs(self.sources or {}) do
  local f=lease.frame;local w=read(f,"GetWidth","number") or lease.width;local h=read(f,"GetHeight","number") or lease.height
  local availableH=lease.role=="spells" and height-32 or height*.46-16
  local scale=math.min(lease.scale,(width*.29-20)/w,availableH/h)
  if lease.role=="bags" then scale=math.min(scale,bagScale) end
  if S:Number(scale) and scale>0 then
   local parent=read(f,"GetParent")
   if parent~=lease.parent and parent~=lease.appliedParent then return false,"The native source window changed owners." end
   lease.appliedScale=scale;lease.appliedParent=parent;lease.geometryAttempt=true
   if not call(f,"SetScale",scale) or not closeNumber(read(f,"GetScale","number"),scale) or not call(f,"ClearAllPoints") then return false,"A native source window could not be positioned." end
   local point
   if lease.role=="spells" then point={"LEFT",UIParent,"LEFT",12/scale,0}
   elseif lease.role=="macros" then point={"TOPRIGHT",UIParent,"TOPRIGHT",-12/scale,-16/scale}
   else point={"BOTTOMRIGHT",UIParent,"BOTTOMRIGHT",-12/scale,bagY/scale};bagY=bagY+(h+6)*scale end
   if not call(f,"SetPoint",unpack(point)) or not pointsMatch(f,{point}) then return false,"A native source window could not be positioned." end
  else return false,"A native source window has unavailable dimensions." end
 end
 return true
end
pointsMatch=function(frame,points)
 if read(frame,"GetNumPoints","number")~=#points then return false end
 for i,point in ipairs(points) do
  local values={pcall(frame.GetPoint,frame,i)};if not values[1] then return false end
  for j=1,5 do
   local value=values[j+1];if not S:Readable(value) then return false end
   if type(value)=="number" and type(point[j])=="number" then
    if math.abs(value-point[j])>.0001 then return false end
   elseif value~=point[j] then return false end
  end
 end
 return true
end
function W:RestoreSources()
 if S:InCombat() then self.restorePending=true;return false end
 local retained={}
 for i=#(self.sources or {}),1,-1 do
  local lease=self.sources[i];local f=lease.frame
  local ok=call(f,"Hide") and read(f,"IsShown","boolean")==false
  if lease.areaAttempt then
   local area,known=optionalAttribute(f,"UIPanelLayout-area")
   if known~="KNOWN" then ok=false
   elseif area==nil then
    local sent=invoke(SetUIPanelAttribute,f,"area",lease.area)
    local restored,status=optionalAttribute(f,"UIPanelLayout-area")
    ok=sent and status=="KNOWN" and restored==lease.area and ok
   elseif area~=lease.area then ok=false end
  end
  local parent=read(f,"GetParent")
  if parent==lease.parent or parent==lease.appliedParent then
   ok=call(f,"SetParent",lease.parent) and read(f,"GetParent")==lease.parent and ok
   ok=call(f,"SetScale",lease.scale) and closeNumber(read(f,"GetScale","number"),lease.scale) and ok
   local positioned=call(f,"ClearAllPoints")
   for _,point in ipairs(lease.points) do positioned=call(f,"SetPoint",unpack(point)) and positioned end
   ok=positioned and pointsMatch(f,lease.points) and ok
   if lease.strata then ok=call(f,"SetFrameStrata",lease.strata) and read(f,"GetFrameStrata","string")==lease.strata and ok end
   if lease.level then ok=call(f,"SetFrameLevel",lease.level) and read(f,"GetFrameLevel","number")==lease.level and ok end
  else ok=false end
  if ok and lease.shown then
   local shown
   if lease.panel and type(ShowUIPanel)=="function" then shown=invoke(ShowUIPanel,f) else shown=call(f,"Show") end
   ok=shown and read(f,"IsShown","boolean")==true
  end
  if not ok then retained[#retained+1]=lease end
 end
 local bags={}
 for bag,wasOpen in pairs(self.bagsBefore or {}) do if not wasOpen then
  local sent=invoke(CloseBag,bag)
  local ok,opened
  if type(IsBagOpen)=="function" then ok,opened=pcall(IsBagOpen,bag) end
  if not sent or not ok or (opened~=false and opened~=nil) then bags[bag]=false end
 end end
 self.sources=retained;self.bagsBefore=bags
 self.restorePending=(#retained>0 or next(bags)~=nil) or nil
 return not self.restorePending
end
function W:ScheduleRestore()
 if not self.restorePending then return end
 if not self.recoveryFrame then
  local f=CreateFrame("Frame",nil,UIParent);f:EnableMouse(false);f:EnableKeyboard(false)
  f:RegisterEvent("PLAYER_REGEN_ENABLED");f:RegisterEvent("PLAYER_ENTERING_WORLD")
  f:SetScript("OnEvent",function() if self.restorePending and not self.session then self:ScheduleRestore() end end)
  self.recoveryFrame=f
 end
 local f=self.recoveryFrame;self.recoveryAttempts=0;self.recoveryElapsed=0
 f:SetScript("OnUpdate",function(_,dt)
  if self.session or not self.restorePending then f:SetScript("OnUpdate",nil);return end
  self.recoveryElapsed=self.recoveryElapsed+dt
  if self.recoveryElapsed<.5 or S:InCombat() then return end
  self.recoveryElapsed=0;self.recoveryAttempts=self.recoveryAttempts+1
  if self:RestoreSources() then self.status="CLOSED";f:SetScript("OnUpdate",nil)
  elseif self.recoveryAttempts>=12 then f:SetScript("OnUpdate",nil) end
 end)
end
function W:ActivateControls()
 self:SetButtons(true)
 local interface=M.ActionInterface
 interface.frame:SetAttribute("mui-keybind-workspace",true);interface.frame:SetAttribute("mui-reserve-open",true)
 interface.frame:SetFrameStrata("DIALOG")
 local laid,why=interface:Layout(M.profile)
 if laid==false then return false,why or "The action controls could not be positioned." end
 interface:Refresh(true)
 -- Refresh exposes every empty destination and computes the expanded height.
 -- Refit once against that completed composition so its visual centre is stable.
 laid,why=interface:Layout(M.profile)
 if laid==false then return false,why or "The expanded action controls could not be positioned." end
 return true
end
function W:SetButtons(active)
 if S:InCombat() then return false end
 self.buttons=self.buttons or self:Buttons()
 for _,b in ipairs(self.buttons) do
  b:SetAttribute("mui-keybind-editing",active==true)
  if active and not b.keybindDraftLabel then
   b.keybindDraftLabel=(b.textLayer or b):CreateFontString(nil,"OVERLAY");b.keybindDraftLabel:SetFont(STANDARD_TEXT_FONT,14,"OUTLINE")
   b.keybindDraftLabel:SetPoint("CENTER",b,"CENTER",0,0);b.keybindDraftLabel:SetJustifyH("CENTER");b.keybindDraftLabel:SetWidth(math.max(1,b:GetWidth()-4))
   b.keybindDraftLabel:SetTextColor(1,.81,.39,1)
   b:HookScript("OnMouseWheel",function(button,delta)
    if self:IsActive() then self:Hover(button);self:Key(delta>0 and "MOUSEWHEELUP" or "MOUSEWHEELDOWN") end
   end)
  end
  if active then
   b.keybindControlLease=true
   if b.keybindPriorWheel==nil then b.keybindPriorWheel=read(b,"IsMouseWheelEnabled","boolean")==true end
   if b.hotkey and b.keybindPriorHotkey==nil then b.keybindPriorHotkey=read(b.hotkey,"GetAlpha","number") or 1 end
   b:EnableMouseWheel(true)
   if b.hotkey then b.hotkey:SetAlpha(0) end
  else
   if b.keybindControlLease then
    b:EnableMouseWheel(b.keybindPriorWheel==true);b.keybindPriorWheel=nil
    if b.hotkey and b.keybindPriorHotkey~=nil then b.hotkey:SetAlpha(b.keybindPriorHotkey);b.keybindPriorHotkey=nil end
    b.keybindControlLease=nil
   end
  end
  local renderer=M.Rework and M.Rework.MainAction
  if renderer and renderer.ArrangeKeyLabels then renderer:ArrangeKeyLabels(b,M.profile.modules.ActionBars,active==true) end
  if b.keybindDraftLabel then
   if renderer and renderer.StyleKeyLabel then renderer:StyleKeyLabel(b.keybindDraftLabel,b,M.profile.modules.ActionBars,true) end
   b.keybindDraftLabel:SetShown(active==true)
  end
 end
 local a=M.Rework and M.Rework.MainAction;local families=M.Rework and M.Rework.ActionFamilies
 for bar=1,8 do
  local row=bar==1 and a or families and families.families and families.families["ActionBars.bar"..bar]
  if row and type(row.RefreshBindings)=="function" then row:RefreshBindings() end
 end
 return true
end
function W:RefreshContext()
 M.state.forceEvaluate=true
 if M.Signals then M.Signals:Observe() end
 if M.CVE then M.CVE:Tick(true) end
 if M.ContextualNative and M.Store then M.ContextualNative:Update(M.Store:Snapshot(),S:Now()) end
end
function W:Enter()
 if not self.session and self.restorePending and not self:RestoreSources() then
  self:ScheduleRestore();return false,"Native windows are still restoring. Close other task windows and try Configure keybinds again."
 end
 if self.session then
  if self.exiting then return self:Finish(self.exiting.discard,self.exiting.keepDraft) end
  if self.suspended then return false,"Finish combat or the current transition to resume your keybind draft." end
  self.frame:Show();return true
 end
 local ok,why=K:Allowed();if not ok then return false,why end
 local interface=M.ActionInterface
 if not interface or not interface.active or not interface.frame or #self:Buttons()~=96 then return false,"Enable all MirageUI action bars before configuring shortcuts." end
 if type(GetCursorInfo)~="function" then return false,"The action cursor is unavailable." end
 local kind,known=M.ActionEditing:CursorKind();if not known or kind then return false,"Place the action currently on your cursor before opening keybind mode." end
 local set=K:BindingSet();if not set then return false,"The current binding set is unavailable." end
 local savedBefore=_G.MirageUIKeybindCharacterDB
 local recovered,storageError=self:StoredDraft();if storageError then return false,storageError end
 if recovered and recovered.bindingSet~=set then return false,"Your unfinished draft belongs to the other game binding set. Select that set in the game's Key Bindings, then reopen this workspace." end
 self:Create();self.session={changes={},placements=false,revision=0,profile=M.profile,bindingSet=set}
 if recovered then self.session.changes=recovered.changes;self.session.placements=recovered.placements end
 self.reserveBefore=read(interface.frame,"GetAttribute","boolean","mui-reserve-open")==true
 self.actionStrata=read(interface.frame,"GetFrameStrata","string")
 interface.frame:SetAttribute("mui-keybind-prior-scale",read(interface.frame,"GetScale","number"))
 interface.frame:SetAttribute("mui-keybind-prior-open",self.reserveBefore)
 for _,key in ipairs({"mui-origin-x","mui-origin-requested","mui-origin-floor","mui-origin-ceiling","mui-reserve-floor"}) do
  interface.frame:SetAttribute("mui-keybind-prior-"..key,read(interface.frame,"GetAttribute","number",key))
 end
 self:CloseSettings();M.state.keybindWorkspace=true;self.suspended=nil
 self:CursorCapture(true)
 local dispatched,opened,message=pcall(function()
  local ready,errorText=self:OpenSources();if not ready then return false,errorText end
  return self:ActivateControls()
 end)
 if not dispatched or not opened then
  self:Finish(true)
  if not M.Profiles.readOnly then _G.MirageUIKeybindCharacterDB=savedBefore end
  return false,(dispatched and message) or "A native source window could not open."
 end
 for _,event in ipairs({"PLAYER_REGEN_DISABLED","PLAYER_REGEN_ENABLED","PLAYER_LEAVING_WORLD","PLAYER_ENTERING_WORLD","CINEMATIC_START","CINEMATIC_STOP","PLAY_MOVIE","ACTIONBAR_SLOT_CHANGED","UPDATE_MACROS","UPDATE_BINDINGS","DISPLAY_SIZE_CHANGED","UI_SCALE_CHANGED"}) do self.frame:RegisterEvent(event) end
 self.frame:EnableKeyboard(true);self.frame:SetPropagateKeyboardInput(true);self.frame:Show()
 self.status="EDITING";self:Notice(recovered and "Recovered your unfinished draft. Save to apply; Exit can discard it." or "Shortcuts are saved together. Dragged actions apply immediately.");self:RefreshLabels();self:RefreshContext();return true
end
function W:RequestExit()
 if not self.session then return true end
 if self.exiting then return self:Finish(self.exiting.discard,self.exiting.keepDraft) end
 if S:InCombat() then self:Suspend();return false end
 if not self:IsDirty() then return self:Finish() end
 if not self.confirm then
  local f=CreateFrame("Frame",nil,self.frame,"BackdropTemplate");f:SetSize(420,174);f:SetPoint("CENTER",UIParent,"CENTER");M.UI:Backdrop(f,true);f:EnableMouse(true);f:SetFrameLevel(self.frame:GetFrameLevel()+20);self.confirm=f
  M.UI:Text(f,"Save your work before leaving?",16,-16,15,388)
  M.UI:Text(f,"Save commits shortcuts and pending macro text. Dragged actions apply immediately. Discard only abandons the shortcut draft; macro edits stay with the native editor.",16,-46,12,388)
  M.UI:Button(f,"Save and exit",16,-106,188,function() if self:Save() then self:Finish() end end)
  M.UI:Button(f,"Keep editing",216,-106,188,function() f:Hide() end)
  M.UI:Button(f,"Discard shortcut draft and exit",16,-140,388,function() self:Finish(true) end)
 end
 self.confirm:Show();return false
end
function W:Suspend()
 if not self.session then return end
 self:Persist()
 self.suspended=true;M.state.keybindWorkspace=false;self.status="SUSPENDED"
 self.hovered=nil;self.consumedKeys=nil;self.exitOnRelease=nil;self.exitQueued=nil
 self.frame:EnableKeyboard(false);self.frame:Hide();self:CursorCapture(false)
 -- Draft labels live over the real secure action cells, not under the footer.
 -- Retire these passive FontStrings immediately so combat never advertises an
 -- unsaved shortcut while the secure handler has restored live actions.
 for _,b in ipairs(self.buttons or {}) do
  if b.keybindDraftLabel then call(b.keybindDraftLabel,"Hide") end
  if b.hotkey and b.keybindPriorHotkey~=nil then call(b.hotkey,"SetAlpha",b.keybindPriorHotkey) end
 end
 -- The predeclared secure combat handler clears per-button edit interception.
 -- Ordinary protected geometry is restored only once combat has ended.
 if not S:InCombat() then self:SetButtons(false);self:RestoreSources() end
 M.state.forceEvaluate=true
end
function W:Resume()
 if not self.session or not self.suspended or S:InCombat() then return false end
 if self.exiting then return self:Finish(self.exiting.discard,self.exiting.keepDraft) end
 self:SetButtons(false)
 if not self:RestoreSources() then
  self:Finish(true,true);self:Notice("Native windows are restoring. Your shortcut draft is retained; reopen Configure keybinds to continue.");return false
 end
 self.suspended=nil;M.state.keybindWorkspace=true;self:CursorCapture(true)
 local sent,ok,why=pcall(function()
  local ready,errorText=self:OpenSources();if not ready then return false,errorText end
  return self:ActivateControls()
 end)
 if not sent or not ok then self:StopForLifecycle();self:Notice(sent and why or "A source window is unavailable. Your shortcut draft is retained.");return false end
 self.frame:EnableKeyboard(true);self.frame:SetPropagateKeyboardInput(true);self.frame:Show();self:RefreshLabels();self:RefreshContext()
 self:Notice("Keybind mode resumed. Your shortcut draft was retained.");return true
end
function W:StopForLifecycle()
 if not self.session then return not self.restorePending or self:RestoreSources() end
 self:Persist();self.exiting={discard=true,keepDraft=true}
 if S:InCombat() then self:Suspend();return false end
 return self:Finish(true,true)
end
function W:RestoreActionLayout()
 local i=M.ActionInterface
 if not i or not i.frame or S:InCombat() then return false end
 i.frame:SetAttribute("mui-keybind-workspace",false);i.frame:SetAttribute("mui-reserve-open",self.reserveBefore==true)
 if self.actionStrata then i.frame:SetFrameStrata(self.actionStrata) end
 i:Layout(M.profile);i:Refresh(true);return true
end
function W:Finish(discard,keepDraft)
 if not self.session then return true end
 if S:InCombat() then self.exiting={discard=discard,keepDraft=keepDraft};self:Suspend();return false end
 if not discard and self:IsDirty() then return self:RequestExit() end
 self:Persist();local stored=_G.MirageUIKeybindCharacterDB
 self:SetButtons(false);self:CursorCapture(false)
 M.state.keybindWorkspace=false;self.hovered=nil
 self.frame:EnableKeyboard(false);self.frame:SetPropagateKeyboardInput(true)
 self:RestoreActionLayout()
 local restored=self:RestoreSources()
 M.state.keybindWorkspace=false;self.session=nil;self.suspended=nil;self.hovered=nil
 self.exiting=nil;self:Persist();if keepDraft and not M.Profiles.readOnly then _G.MirageUIKeybindCharacterDB=stored end
 self.consumedKeys=nil;self.exitOnRelease=nil;self.exitQueued=nil
 self.frame:EnableKeyboard(false);self.frame:SetPropagateKeyboardInput(true);self.frame:Hide();self.frame:UnregisterAllEvents()
 if self.confirm then self.confirm:Hide() end
 self.status=restored and "CLOSED" or "RESTORE_PENDING";self:RefreshContext()
 if not restored then
  self:ScheduleRestore()
  M:Print("Keybind mode closed. Native windows are restoring in the background; input is available normally.")
 end
 return true
end
