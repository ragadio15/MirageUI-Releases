-- Original, opt-in native exploration lease. Never a blanket hide-all manager.
local _, M = ...
local S=M.Safety
M.NativeQuiet={modules={Minimap=true,Chat=true,QuestTracker=true},buttons={},status="DISABLED"}
local Q=M.NativeQuiet
local combatReveal=[=[
if newstate == "show" then
    local frame = self:GetFrameRef("subject")
    if frame then frame:Show(); frame:SetAlpha(self:GetAttribute("restore-alpha") or 1) end
end
]=]
function Q:Guard(surface)
    if surface.revealController then
        if surface.guardReady~=true then return false end
        if surface.controllerSubject~=surface.frame then
            if S:InCombat() then return false end
            local ok=pcall(function()
                surface.revealController:SetFrameRef("subject",surface.frame)
                surface.revealController:SetAttribute("restore-alpha",surface.originalAlpha or 1)
            end)
            if not ok then return false end
            surface.controllerSubject=surface.frame
        end
        return true
    end
    if S:InCombat() or type(RegisterStateDriver)~="function" or not S:Frame(surface.frame,true) or not S:ChildTreePublic(surface.frame) then return false end
    local controller=CreateFrame("Frame",nil,UIParent,"SecureHandlerStateTemplate")
    S:Passive(controller)
    local ok=pcall(function()
        controller:SetFrameRef("subject",surface.frame)
        controller:SetAttribute("restore-alpha",surface.originalAlpha or 1)
        controller:SetAttribute("_onstate-miragecombat",combatReveal)
        RegisterStateDriver(controller,"miragecombat","[combat] show; hold")
    end)
    surface.revealController=controller;surface.guardReady=ok;surface.controllerSubject=surface.frame
    if not ok then
        if type(UnregisterStateDriver)=="function" then pcall(UnregisterStateDriver,controller,"miragecombat") end
        controller:Hide();self.status="GUARD_UNAVAILABLE";return false
    end
    surface.revealController=controller
    return true
end
function Q:CreateButton(module)
    if self.buttons[module] or S:InCombat() then return end
    local index=module=="Minimap" and 1 or module=="Chat" and 2 or 3
    local label=module=="Minimap" and "Map" or module=="Chat" and "Chat" or "Quests"
    local b=M.UI:Button(UIParent,label,0,0,62,function()
        if M:IsModuleActive(module) then
            for _,s in pairs(M.Native.records) do if s.module==module then
                if s.quietRestorePending then self:Restore(s) end
                s.interactingUntil=S:Now()+12
            end end
            M.CVE:Tick(true)
        end
    end)
    b:ClearAllPoints();b:SetPoint("TOPRIGHT",UIParent,"TOPRIGHT",-22,-52-(index-1)*32);b:SetFrameStrata("MEDIUM");b:Hide()
    self.buttons[module]=b
end
function Q:RefreshButtons()
    local hidden={}
    for _,s in pairs(M.Native.records) do if s.quietHidden then hidden[s.module]=true end end
    local quiet=M.profile and M.profile.managed and M.profile.preset=="Immersive"
    local reveal=M.state.edit or (M.state.revealUntil or 0)>S:Now()
    for module,b in pairs(self.buttons) do
        b:SetShown(hidden[module] and M:IsModuleActive(module) and not S:InCombat() and (not quiet or reveal) or false)
    end
end
function Q:Restore(s,automatic)
    if not s.quietHidden then return true end
    if automatic and (s.quietRestoreAttempts or 0)>=3 then return false end
    if not ((not S:InCombat() and S:Frame(s.frame,false)) or (S:Frame(s.frame,true) and S:ChildTreePublic(s.frame))) then s.quietRestorePending=true;return false end
    -- Visibility was changed by this lease only. Never revive a frame that was natively hidden at acquisition.
    s.quietMutation=true
    local ok=pcall(function()
        s.frame:SetAlpha(s.originalAlpha or 1)
        if s.quietWasShown then s.frame:Show() end
    end)
    s.quietMutation=nil
    -- A successful API call is only submission. Keep recovery ownership until
    -- public getters confirm our alpha and (when owed) visibility handback.
    local alpha,alphaStatus=S:Public(s.frame.GetAlpha,"number",s.frame)
    local shown,shownStatus=S:Public(s.frame.IsShown,"boolean",s.frame)
    ok=ok and alphaStatus=="KNOWN" and math.abs(alpha-(s.originalAlpha or 1))<.001
        and (not s.quietWasShown or (shownStatus=="KNOWN" and shown==true))
    if ok then
        s.quietHidden=nil;s.quietWasShown=nil;s.quietRestorePending=nil;s.quietRestoreAttempts=nil;s.lastWrittenAlpha=nil;s.targetAlpha=nil
        s.currentAlpha=s.originalAlpha or 1;s.actual="NATIVE";s.appliedReason="QUIET_RESTORED"
    else
        s.quietRestoreAttempts=(s.quietRestoreAttempts or 0)+1
        s.quietRestorePending=true;s.actual="PRESERVED"
        s.appliedReason=s.quietRestoreAttempts>=3 and "QUIET_RESTORE_RELOAD_REQUIRED" or "QUIET_RESTORE_DEFERRED"
    end
    self:RefreshButtons();return ok
end
function Q:Configure(module)
    local cfg=M:ModuleConfig(module)
    if not self.modules[module] then return end
    if cfg.hideWhenQuiet then self:CreateButton(module) end
    for _,s in pairs(M.Native.records) do if s.module==module then
        if cfg.hideWhenQuiet and M:IsModuleActive(module) then
            self:Guard(s)
            if not s.quietHooked and s.frame.HookScript then
                s.quietHooked=true
                s.frame:HookScript("OnShow",function()
                    if s.quietHidden and not s.quietMutation then
                        -- Native open or secure combat reveal wins over old cosmetic intent.
                        s.quietHidden=nil;s.quietWasShown=nil;s.quietRestorePending=nil;s.quietRestoreAttempts=nil
                        s.interactingUntil=S:Now()+4;s.targetAlpha=nil;M.state.forceEvaluate=true
                        self:RefreshButtons()
                    end
                end)
            end
        else self:Release(s) end
    end end
end
function Q:Release(s,automatic)
    self:Restore(s,automatic)
    if s.revealController and not S:InCombat() and not s.quietRestorePending then
        if type(UnregisterStateDriver)=="function" then pcall(UnregisterStateDriver,s.revealController,"miragecombat") end
        -- Keep the preallocated controller available for later toggles; do not allocate on every profile apply.
        s.controllerDormant=true
    end
end
function Q:Apply(s,state,authorized)
    local function permitted() return not authorized or authorized() end
    if not self.modules[s.module] then return false end
    local cfg=M:ModuleConfig(s.module)
    local wanted=cfg and cfg.hideWhenQuiet and M:IsModuleActive(s.module)
    -- Do not submit another cosmetic effect over an unresolved handback.
    if s.quietRestorePending then self:Restore(s,true);return true end
    if not wanted or state~="HIDDEN" and state~="AMBIENT" or S:InCombat() then
        if s.quietHidden and not self:Restore(s,true) then return true end
        return false
    end
    if M.Native:Conflict() or not S:Frame(s.frame,true) or not S:ChildTreePublic(s.frame) or not s.revealController or s.guardReady~=true or s.controllerSubject~=s.frame then
        self.status="NATIVE_SAFETY_FALLBACK";return false
    end
    if not permitted() then return true end
    if s.controllerDormant then
        if not pcall(RegisterStateDriver,s.revealController,"miragecombat","[combat] show; hold") then return false end
        s.controllerDormant=nil
        if not permitted() then return true end
    end
    if not s.quietHidden then
        local shown,known=S:Public(s.frame.IsShown,"boolean",s.frame)
        if known~="KNOWN" or not shown then return false end
        if not permitted() then return true end
        M.Effects.active[s.id]=nil
        -- Own the attempted visibility change before calling native code: a
        -- callback may throw after Hide has already changed the frame.
        s.quietWasShown=true;s.quietHidden=true
        s.quietMutation=true
        local denied=false
        local ok=pcall(function()
            s.frame:SetAlpha(s.originalAlpha or 1)
            if not permitted() then denied=true;return end
            s.frame:Hide()
        end)
        s.quietMutation=nil
        local hidden,hiddenStatus=S:Public(s.frame.IsShown,"boolean",s.frame)
        if denied or not permitted() then
            -- Do not turn a revoked request into new restore writes. The
            -- independent native handback retry owns subsequent recovery.
            s.quietRestorePending=true;self.status="AUTHORITY_CHANGED";return true
        end
        if not ok or hiddenStatus~="KNOWN" or hidden~=false then
            s.quietRestorePending=true;self:Restore(s);self.status="HIDE_UNAVAILABLE"
            return s.quietRestorePending==true
        end
        s.targetAlpha=nil;s.lastWrittenAlpha=nil
    end
    if not permitted() then return true end
    s.actual="NATIVE_QUIET_HIDDEN";s.appliedReason="EXPLICIT_QUIET_MODE";self.status="CANDIDATE_NOT_NATIVE_CERTIFIED"
    self:RefreshButtons();return true
end
function Q:Retry()
    for _,s in pairs(M.Native.records) do
        if s.quietRestorePending then self:Restore(s,true) end
        local cfg=M:ModuleConfig(s.module)
        if self.modules[s.module] and (not cfg.hideWhenQuiet or not M:IsModuleActive(s.module)) then self:Release(s,true) end
    end
    self:RefreshButtons()
end
