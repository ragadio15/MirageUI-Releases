-- One small launcher, explicit settings destinations, and no gameplay click emulation.
local _, M = ...
local L = {entries={}, byID={}, buttons={}, offset=0, dirty=true, status="READY"}
M.SuiteLauncher=L
local G=_G
local fallbackIcon="Interface\\Icons\\INV_Misc_QuestionMark"
local suiteIcon="Interface\\AddOns\\MirageUI\\Media\\MirageUIBadge.tga"
local menuIcon="Interface\\AddOns\\MirageUI\\Media\\Icons\\addons-launcher.tga"
-- Menu-only white-gold identities. Do not recolor the core launcher or gameplay icons.
local companionMenuIcons={
 MirageUIOptions="Interface\\AddOns\\MirageUI\\Media\\MenuBadges\\mirageui-options.tga",
 CursorCompanion="Interface\\AddOns\\MirageUI\\Media\\MenuBadges\\cursor-companion.tga",
 MirageUISanctuary="Interface\\AddOns\\MirageUI\\Media\\MenuBadges\\sanctuary.tga",
 Wealthcraft="Interface\\AddOns\\MirageUI\\Media\\MenuBadges\\wealthcraft.tga",
 MirageIntel_Core="Interface\\AddOns\\MirageUI\\Media\\MenuBadges\\utility-core.tga",
 MirageIntel_Map="Interface\\AddOns\\MirageUI\\Media\\MenuBadges\\utility-map.tga",
 MirageIntel_Navigate="Interface\\AddOns\\MirageUI\\Media\\MenuBadges\\utility-navigate.tga",
 MirageIntel_Gather="Interface\\AddOns\\MirageUI\\Media\\MenuBadges\\utility-gather.tga",
 MirageIntel_Insight="Interface\\AddOns\\MirageUI\\Media\\MenuBadges\\utility-insight.tga",
}
-- Required implementation folders are not separate user-facing features.
-- Keep their dependencies and legacy entry points; only omit menu duplicates.
local internalAddons={MirageUIOptions=true,MirageIntel_Core=true}
local white="Interface\\Buttons\\WHITE8X8"
local function readable(v) return not M.Safety or M.Safety:Readable(v) end
local function text(v)
 if not readable(v) or type(v)~="string" then return nil end
 return v:gsub("|c%x%x%x%x%x%x%x%x",""):gsub("|r",""):gsub("|T.-|t",""):gsub("|A.-|a",""):sub(1,512)
end
local function label(v)
 local s=text(v);if not s then return nil end
 return s:gsub("^%s*%[MUI%]%s*",""):gsub("^%s+",""):gsub("%s+$","")
end
local function key(v) return (label(v) or ""):lower() end
local function query(fn,...)
 if type(fn)~="function" then return nil end
 local ok,v=pcall(fn,...);if ok and readable(v) then return v end
 return nil
end
local function api(name)
 local a=G.C_AddOns;return a and a[name] or G[name]
end
local function metadata(id,k) return query(api("GetAddOnMetadata"),id,k) end
local function combat()
 if M.Safety and M.Safety.InCombat then return M.Safety:InCombat() end
 return query(G.InCombatLockdown)~=false
end
local function shown(f)
 if not f or not readable(f) then return false end
 local v=query(f.IsVisible or f.IsShown,f);return v==true
end
local function mouseOver(frame)
 if not frame or not readable(frame) then return nil end
 -- Forever's native menu uses the region method. The legacy global is not
 -- guaranteed to exist; requiring it made outside clicks silently do nothing.
 local ok,method=pcall(function()return frame.IsMouseOver end)
 if ok and type(method)=="function" then
  local value=query(method,frame);if type(value)=="boolean" then return value end
 end
 local value=query(G.MouseIsOver,frame)
 return type(value)=="boolean" and value or nil
end
local panelNames={"WorldMapFrame","SpellBookFrame","MacroFrame","CharacterFrame","PlayerTalentFrame",
 "QuestLogFrame","QuestFrame","MerchantFrame","BankFrame","GameMenuFrame","SettingsPanel",
 "ContainerFrameCombinedBags","ContainerFrameCombinedBackpack"}
local function positive(v)
 return type(v)=="number" and v==v and v>0 and v<math.huge and v
end
local function enabled(id)
 local a=G.C_AddOns;local state
 if a and type(a.GetAddOnEnableState)=="function" then state=query(a.GetAddOnEnableState,id,query(G.UnitGUID,"player") or query(G.UnitName,"player"))
 elseif type(G.GetAddOnEnableState)=="function" then state=query(G.GetAddOnEnableState,query(G.UnitName,"player"),id) end
 if type(state)=="number" then return state>0 end
 -- Only actual loaded addons can be enumerated without an enable-state API.
 return query(api("IsAddOnLoaded"),id)==true
end
local function field(o,k)
 if not readable(o) or (type(o)~="table" and type(o)~="userdata") then return nil end
 local ok,v=pcall(function() return o[k] end);if ok and readable(v) then return v end
end
local function registration(id)
 local registry=G.MirageUIAddonSettings
 local value=readable(registry) and type(registry)=="table" and rawget(registry,id)
 return readable(value) and type(value)=="table" and value or nil
end
local function currentIcon(v)
 if not readable(v) then return nil end
 if type(v)=="number" and v>0 then return v end
 if type(v)=="string" and v~="" and not v:find("|",1,true) then return tonumber(v) or v end
end
local function compartmentCallback(id)
 local name=text(metadata(id,"AddonCompartmentFunc"))
 if not name or #name>128 or not name:match("^[%a_][%w_]*$") then return nil end
 local fn=rawget(G,name)
 return type(fn)=="function" and fn or nil
end
local function info(index)
 local id=query(api("GetAddOnName"),index)
 local title=query(api("GetAddOnTitle"),index)
 local notes=query(api("GetAddOnNotes"),index)
 local security=query(api("GetAddOnSecurity"),index)
 if not id then
  local fn=api("GetAddOnInfo")
  if type(fn)=="function" then
   local ok,a,b,c,_,_,secure=pcall(fn,index)
   if ok and readable(a) and readable(b) and readable(c) and readable(secure) then id,title,notes,security=a,b,c,secure end
  end
 end
 id=text(id);if not id or id=="" or internalAddons[id] or id:match("^Blizzard_") or security=="SECURE" or not enabled(id) then return nil end
 local r=registration(id)
 local order=field(r,"order") or tonumber(metadata(id,"X-MirageUI-Order"))
 local suite=id=="MirageUI" or id=="MirageUIOptions" or metadata(id,"Group")=="MirageUI" or metadata(id,"X-MirageUI-Suite")=="1"
 if id=="MirageUI" then order=0 elseif id=="MirageUIOptions" then order=1 end
 return {id=id,index=index,title=label(field(r,"title")) or label(title) or id,
  notes=text(notes) or "",version=text(metadata(id,"Version")) or "",author=text(metadata(id,"Author")) or "",
  icon=companionMenuIcons[id] or currentIcon(field(r,"icon")) or currentIcon(metadata(id,"IconTexture")) or fallbackIcon,
  iconAtlas=not companionMenuIcons[id] and not currentIcon(field(r,"icon")) and not currentIcon(metadata(id,"IconTexture")) and text(metadata(id,"IconAtlas")) or nil,
  suite=suite,order=type(order)=="number" and order==order and math.abs(order)<100000 and order or 1000,
  loaded=query(api("IsAddOnLoaded"),id)==true,loadOnDemand=query(api("IsAddOnLoadOnDemand"),id)==true}
end
function L:Refresh()
 local out,seen={},{}
 local count=query(api("GetNumAddOns"))
 if type(count)~="number" or count~=count or count<0 or count>10000 then self.entries={};self.byID={};self.status="ADDON_CATALOG_UNAVAILABLE";return false,self.status end
 for i=1,math.floor(count) do
  local e=info(i)
  if e and not seen[e.id] then out[#out+1]=e;seen[e.id]=e end
 end
 table.sort(out,function(a,b)
  if a.suite~=b.suite then return a.suite end
  if a.suite and a.order~=b.order then return a.order<b.order end
  local x,y=key(a.title),key(b.title);if x==y then return a.id<b.id end;return x<y
 end)
 self.entries=out;self.byID=seen;self.dirty=nil;self.status="READY"
 return true
end
-- Exact registered category matches only. A partial title match must never open
-- another addon's settings, and arbitrary minimap/Broker OnClick callbacks are not
-- assumed to be settings actions.
function L:FindCategory(entry)
 local panel=G.SettingsPanel
 if not panel or type(panel.GetAllCategories)~="function" then return nil end
 local categories=query(panel.GetAllCategories,panel)
 if type(categories)~="table" then return nil end
 local exact,duplicate=nil,false
 local function consider(c)
  if type(c)~="table" or not readable(c) then return end
  local name=query(field(c,"GetName"),c) or text(field(c,"name"))
  local id=query(field(c,"GetID"),c) or field(c,"ID") or field(c,"id")
  local set=G.Settings and G.Settings.CategorySet and G.Settings.CategorySet.AddOns
  local categorySet=field(c,"categorySet")
  if set~=nil and categorySet~=nil and categorySet~=set then return end
  if (key(name)==key(entry.id) or key(name)==key(entry.title)) and (type(id)=="number" or type(id)=="string") and readable(id) then
   if exact and exact.id~=id then duplicate=true else exact={id=id,category=c} end
  end
 end
 for i,c in ipairs(categories) do
  if i>2048 then break end
  consider(c)
  local subs=query(field(c,"GetSubcategories"),c)
  if type(subs)=="table" then for j,s in ipairs(subs) do if j>128 then break end;consider(s) end end
 end
 return not duplicate and exact or nil
end
function L:CanHandoff()
 local workspace=M.Workspace
 if workspace and (workspace.nativeHandoffPending or shown(workspace.nativeHandoff)) then
  return false,"Finish or cancel the Blizzard Edit HUD handoff before opening addon settings."
 end
 if workspace and (shown(workspace.modal) or shown(workspace.confirm) or workspace.nativeModal or workspace.nativeConfirm) then
  return false,"Finish or cancel the open MirageUI dialog before opening addon settings."
 end
 return true
end
function L:OpenCore()
 local allowed,message=self:CanHandoff();if not allowed then self.status="WORKSPACE_DIALOG_ACTIVE";self:Notice(message);return false,message end
 if combat() then return false,"Open settings after combat." end
 if type(M.LoadOptions)~="function" then return false,"MirageUI settings are unavailable." end
 -- Use the existing load-only entry, then its normal draft-aware Open method.
 M:LoadOptions(true)
 allowed,message=self:CanHandoff();if not allowed then self.status="WORKSPACE_DIALOG_ACTIVE";self:Notice(message);return false,message end
 if not M.Options or type(M.Options.Open)~="function" then return false,"MirageUI Options is missing, disabled, or could not load." end
 local opened=M.Options:Open()
 if opened==true then return true end
 return false, "Apply or cancel the current settings dialog before opening another page."
end
function L:OpenAddon(id,buttonName)
 local allowed,message=self:CanHandoff();if not allowed then self.status="WORKSPACE_DIALOG_ACTIVE";self:Notice(message);return false,message end
 buttonName=buttonName=="RightButton" and "RightButton" or "LeftButton"
 if combat() then self.status="COMBAT_BLOCKED";self:Notice("Open addon settings after combat.");return false,"Open addon settings after combat." end
 if not text(id) then self.status="ADDON_IDENTIFIER_UNAVAILABLE";self:Notice("The addon identifier is unavailable.");return false,"Addon identifier is unavailable." end
 if id=="MirageUIOptions" then return self:OpenCore() end
 if not self:Refresh() then self:Notice("The enabled addon list is unavailable.");return false,"Addon catalog unavailable." end
 local e=self.byID[id]
 if not e or not enabled(id) then self.status="ADDON_DISABLED";self:Notice("This addon is no longer enabled.");return false,"Addon is not enabled." end
 self.status="OPENING_SETTINGS"
 if e.loadOnDemand and not e.loaded then
  local loader=api("LoadAddOn")
  if type(loader)~="function" then self.status="ADDON_LOADER_UNAVAILABLE";self:Notice("This addon cannot be loaded here.");return false,"Addon loader unavailable." end
  local ok,loaded,why=pcall(loader,id)
  if not ok or loaded==false or query(api("IsAddOnLoaded"),id)~=true then
   self.status="ADDON_LOAD_FAILED";self:Notice("This addon could not load. Check its dependencies in the AddOns list.")
   return false,"Addon could not load."
  end
  if not self:Refresh() then self:Notice("The enabled addon list became unavailable while loading.");return false,"Addon catalog unavailable." end
  e=self.byID[id]
  if not e or not enabled(id) then self.status="ADDON_STATE_CHANGED";self:Notice("This addon was disabled while loading. Check the AddOns list.");return false,"Addon state changed while loading." end
  if combat() then self.status="COMBAT_BLOCKED";self:Notice("Combat started while loading. Open addon settings after combat.");return false,"Combat started while loading." end
  allowed,message=self:CanHandoff();if not allowed then self.status="WORKSPACE_DIALOG_ACTIVE";self:Notice(message);return false,message end
 end
 local r=registration(id)
 local ok,opened,reason
 if id=="MirageUI" or id=="MirageUIOptions" then ok,opened,reason=pcall(self.OpenCore,self)
 elseif type(field(r,"open"))=="function" then ok,opened,reason=pcall(field(r,"open"))
 else
  local category=self:FindCategory(e)
  local panel=G.SettingsPanel
  if category and panel and type(panel.OpenToCategory)=="function" then
   ok,opened=pcall(panel.OpenToCategory,panel,category.id)
   opened=ok and opened==true and shown(panel)
  else
   -- Native AddOnCompartment metadata declares an intentional user-click
   -- endpoint. Its purpose is addon-defined: report dispatch, never invent a
   -- successful settings-window observation for this third-party route.
   local callback=compartmentCallback(id)
   if callback then
    local called,result=pcall(callback,id,buttonName)
    if called and readable(result) and (result==nil or result==true) then
     self.status="LAUNCHER_DISPATCHED";self.lastOpened=id;self:Close("LAUNCHER_DISPATCHED")
     return true,"The addon's registered launcher was invoked."
    end
    self.status="LAUNCHER_DISPATCH_FAILED";self:Notice("The addon's registered launcher could not complete.")
    return false,"Addon launcher could not complete."
   end
   self:Close("ADDON_DETAILS");self:ShowDetails(e);self.status="DETAILS_NO_SETTINGS_ENDPOINT"
   return true,"Addon details opened; no settings destination is registered."
  end
 end
 if ok and opened==true then self.status="SETTINGS_OPENED";self.lastOpened=id;self:Close("SETTINGS_OPENED");return true end
 self.status="SETTINGS_OPEN_FAILED"
 local message=ok and text(reason) or nil
 self:Notice(message or "This addon's settings could not open. Its own launcher remains available.")
 return false,message or "Addon settings could not open."
end
function L:Notice(message)
 self.message=text(message) or ""
 if self.notice then self.notice:SetText(self.message) end
end
function L:HideRowTooltip(row)
 local tip=G.GameTooltip
 local owner=tip and query(tip.GetOwner,tip)
 if owner and (row and owner==row or not row and owner==self.tooltipRow) then
  if type(tip.Hide)=="function" then tip:Hide() end
 end
 if not row or self.tooltipRow==row then self.tooltipRow=nil end
end
function L:ShowRowTooltip(row)
 local tip=G.GameTooltip;local e=row and row.entry
 if not tip or not e then return end
 self.tooltipRow=row
 tip:SetOwner(row,"ANCHOR_LEFT");tip:SetText(e.title)
 if e.notes~="" then tip:AddLine(e.notes,.9,.89,.87,true) end
 tip:Show()
end
local function font(parent,size)
 local f=parent:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
 f:SetFont(G.STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",size or 12,"")
 f:SetJustifyH("LEFT");f:SetJustifyV("MIDDLE");f:SetTextColor(.90,.89,.87,1)
 if f.SetWordWrap then f:SetWordWrap(false) end
 return f
end
local function preferredScale()
 local value=M.profile and M.profile.textScale
 return type(value)=="number" and value==value and math.max(.75,math.min(2,value)) or 1
end
local function backdrop(f,quiet)
 if M.UI and type(M.UI.Backdrop)=="function" then M.UI:Backdrop(f,quiet);return end
 f:SetBackdrop({bgFile=white,edgeFile=white,edgeSize=1})
 f:SetBackdropColor(.035,.035,.038,.98);f:SetBackdropBorderColor(.26,.26,.26,1)
end
local function button(parent,title,width,click)
 if M.UI and type(M.UI.Button)=="function" then
  local b=M.UI:Button(parent,title,0,0,width,click);b:ClearAllPoints();b:SetHeight(24)
  b.label:ClearAllPoints();b.label:SetAllPoints(b);b.label:SetJustifyV("MIDDLE")
  return b
 end
 local b=CreateFrame("Button",nil,parent,"BackdropTemplate");b:SetSize(width,24);backdrop(b)
 b.label=font(b,12);b.label:SetAllPoints();b.label:SetJustifyH("CENTER");b.label:SetText(title)
 b:SetScript("OnClick",click)
 b:SetScript("OnEnter",function() b:SetBackdropBorderColor(.91,.55,.18,1) end)
 b:SetScript("OnLeave",function() b:SetBackdropBorderColor(.26,.26,.26,1) end)
 return b
end
function L:Create()
 if self.frame then return true end
 if combat() then return false end
 local f=CreateFrame("Frame","MirageUIAddonMenu",UIParent,"BackdropTemplate");self.frame=f
 f:SetFrameStrata("FULLSCREEN_DIALOG");f:SetClampedToScreen(true);f:EnableMouse(true);backdrop(f)
 -- Every key dismisses this transient menu without consuming its native
 -- action. Mouse wheel and paging provide browsing without a text-focus trap.
 if type(f.EnableKeyboard)=="function" and type(f.SetPropagateKeyboardInput)=="function" then
  f:EnableKeyboard(true);f:SetPropagateKeyboardInput(true)
  f:SetScript("OnKeyDown",function()
   self:Close("KEYBOARD")
  end)
 end
 self.headerIcon=f:CreateTexture(nil,"ARTWORK");self.headerIcon:SetSize(22,22);self.headerIcon:SetPoint("TOPLEFT",12,-10);self.headerIcon:SetTexture(menuIcon)
 self.title=font(f,14);self.title:SetPoint("TOPLEFT",42,-10);self.title:SetPoint("TOPRIGHT",-42,-10);self.title:SetHeight(22);self.title:SetText("AddOns")
 self.close=button(f,"×",24,function() self:Close("CLOSE_BUTTON") end);self.close:SetPoint("TOPRIGHT",-8,-8)
 self.hint=font(f,11);self.hint:SetPoint("TOPLEFT",14,-44);self.hint:SetPoint("TOPRIGHT",-14,-44);self.hint:SetHeight(17);self.hint:SetText("Suite first · Other addons A–Z")
 self.notice=font(f,11);self.notice:SetPoint("BOTTOMLEFT",12,9);self.notice:SetPoint("BOTTOMRIGHT",-12,9);self.notice:SetHeight(28)
 if self.notice.SetWordWrap then self.notice:SetWordWrap(true) end
 self.previous=button(f,"Previous",85,function() self.offset=math.max(0,self.offset-self.visibleRows);self:Render() end)
 self.previous:SetPoint("BOTTOMLEFT",12,43)
 self.next=button(f,"Next",85,function() self.offset=self.offset+self.visibleRows;self:Render() end);self.next:SetPoint("BOTTOMRIGHT",-12,43)
 self.counter=font(f,11);self.counter:SetPoint("BOTTOM",0,48);self.counter:SetSize(90,18);self.counter:SetJustifyH("CENTER")
 f:EnableMouseWheel(true)
 f:SetScript("OnMouseWheel",function(_,delta) self.offset=math.max(0,self.offset-delta*3);self:Render() end)
 f:SetScript("OnHide",function()
  self:HideRowTooltip();self.anchor=nil;self.elapsed=0;self.holdSurface=nil;self.nextHoldRenew=nil
  self.panelState=nil;self.mouseWasDown=nil
  for _,row in ipairs(self.buttons) do row.hovered=nil;if row.press then row.press=false end end
 end)
 f:SetScript("OnUpdate",function(_,elapsed)
  -- Observe the edge every rendered frame, even if event registration succeeds
  -- but that client does not deliver the global mouse event to addons.
  local down=query(G.IsMouseButtonDown)
  if down==true and self.mouseWasDown~=true then self:OutsideClick() end
  self.mouseWasDown=down
  if not shown(f) then return end
  self.elapsed=(self.elapsed or 0)+elapsed;if self.elapsed<.1 then return end;self.elapsed=0
  if combat() then self:Close("COMBAT");return end
  local a=self.anchor
  if a and (not shown(a) or (query(a.GetEffectiveAlpha,a) or 1)<.02) then self:Close("ANCHOR_HIDDEN");return end
  if self:PanelsChanged() then self:Close("MAIN_INTERFACE_CHANGED");return end
  self:RenewMinimapHold()
  local resized=self:Fit()
  if self.dirty then self:Refresh();self:Render() elseif resized then self:Render() end
 end)
 if G.UISpecialFrames then table.insert(G.UISpecialFrames,"MirageUIAddonMenu") end
 f:Hide()
 return true
end
function L:CreateRow(index)
 local b=CreateFrame("Button",nil,self.frame,"BackdropTemplate");self.buttons[index]=b;backdrop(b,true)
 b:SetHeight(36);b:SetPoint("TOPLEFT",10,-66-(index-1)*38);b:SetPoint("TOPRIGHT",-10,-66-(index-1)*38)
 b.icon=b:CreateTexture(nil,"ARTWORK");b.icon:SetSize(24,24);b.icon:SetPoint("LEFT",7,0)
 b.label=font(b,12);b.label:SetPoint("LEFT",b.icon,"RIGHT",9,0);b.label:SetPoint("RIGHT",b,"RIGHT",-10,0);b.label:SetHeight(24)
 b:RegisterForClicks("LeftButtonUp","RightButtonUp")
 b:SetScript("OnMouseDown",function(_,mouse)
  b.press=b.entry and {id=b.entry.id,button=mouse} or false
 end)
 b:SetScript("OnClick",function(_,mouse)
  local press=b.press;b.press=nil
  if press==false or press and (not b.entry or press.id~=b.entry.id or press.button~=mouse) then return end
  if b.entry and shown(b) then self:OpenAddon(b.entry.id,mouse) end
 end)
 b:SetScript("OnEnter",function()
  b.hovered=true
  b:SetBackdropBorderColor(.91,.55,.18,1)
  self:ShowRowTooltip(b)
 end)
 b:SetScript("OnLeave",function() b.hovered=nil;b:SetBackdropBorderColor(.26,.26,.26,1);self:HideRowTooltip(b) end)
 b:SetScript("OnHide",function() b.hovered=nil;if b.press then b.press=false end;self:HideRowTooltip(b) end)
 return b
end
function L:SetEntryIcon(texture,e)
 if e.iconAtlas and type(texture.SetAtlas)=="function" then
  local atlas=G.C_Texture and query(G.C_Texture.GetAtlasInfo,e.iconAtlas)
  if atlas then local ok,result=pcall(texture.SetAtlas,texture,e.iconAtlas);if ok and readable(result) and result~=false then return true end end
 end
 local ok,result=pcall(texture.SetTexture,texture,e.icon or fallbackIcon)
 if ok and readable(result) and result~=false then return true end
 ok,result=pcall(texture.SetTexture,texture,fallbackIcon)
 return ok and readable(result) and result~=false
end
function L:SetFilter(value)
 self.filter=(text(value) or ""):sub(1,80);self.offset=0;self:Render()
end
function L:Render()
 if not self.frame then return end
 local filter=key(self.filter)
 local list={}
 for _,e in ipairs(self.entries) do if filter=="" or key(e.title):find(filter,1,true) or key(e.id):find(filter,1,true) then list[#list+1]=e end end
 self.filtered=list
 local rows=self.visibleRows or 9
 self.offset=math.max(0,math.min(self.offset or 0,math.max(0,#list-rows)))
 for i=1,rows do
  local b=self.buttons[i] or self:CreateRow(i);local e=list[self.offset+i]
  local previous=b.entry
  if b.press and (not e or b.press.id~=e.id) then b.press=false end
  b.entry=e
  if e then
   self:SetEntryIcon(b.icon,e);b.label:SetText(e.title)
   if b.label.SetTextColor then
    if e.id=='MirageUI' then b.label:SetTextColor(.91,.55,.18,1)
    elseif e.suite then b.label:SetTextColor(.96,.79,.36,1)
    else b.label:SetTextColor(.9,.9,.9,1)end
   end
   b:Show()
   -- A pooled row can change under a stationary pointer. Refresh only a tip
   -- that this row still owns; never take over another control's tooltip.
   if b.hovered and G.GameTooltip and shown(G.GameTooltip) and query(G.GameTooltip.GetOwner,G.GameTooltip)==b and
    (not previous or previous.id~=e.id or previous.title~=e.title or previous.notes~=e.notes) then self:ShowRowTooltip(b) end
  else b:Hide() end
 end
 for i=rows+1,#self.buttons do self.buttons[i]:Hide() end
 self.previous:SetEnabled(self.offset>0);self.next:SetEnabled(self.offset+rows<#list)
 self.counter:SetText(#list==0 and "0 addons" or (self.offset+1).."–"..math.min(self.offset+rows,#list).." / "..#list)
 self:Notice(#list==0 and "No enabled addons match this view." or self.message or "")
end
function L:Fit()
 if not self.frame then return false end
 local width=positive(query(UIParent.GetWidth,UIParent)) or 1000
 local height=positive(query(UIParent.GetHeight,UIParent)) or 800
 local requestedScale=preferredScale()
 if self.fitWidth==width and self.fitHeight==height and self.fitTextScale==requestedScale then return false end
 self.fitWidth,self.fitHeight,self.fitTextScale=width,height,requestedScale
 self.visibleRows=math.max(3,math.min(10,math.floor(((height-24)/requestedScale-147)/38)))
 local panelWidth=math.max(240,math.min(360,width-24));local panelHeight=147+self.visibleRows*38
 self.frame:SetSize(panelWidth,panelHeight)
 self.frame:SetScale(math.max(.05,math.min(requestedScale,(width-24)/panelWidth,(height-24)/panelHeight)))
 -- Footer labels reserve three disjoint lanes even at the narrowest width.
 local buttonWidth=math.min(85,math.floor((panelWidth-36)/3))
 self.previous:SetWidth(buttonWidth);self.next:SetWidth(buttonWidth)
 self.counter:SetWidth(panelWidth-buttonWidth*2-36)
 return true
end
function L:Open(anchor)
 local allowed,message=self:CanHandoff();if not allowed then self.status="WORKSPACE_DIALOG_ACTIVE";self:Notice(message);return false,message end
 if combat() then return false,"Open addon settings after combat." end
 if not self:Create() then return false,"Addon menu is unavailable." end
 if self.detailFrame then self.detailFrame:Hide() end
 local ready=self:Refresh();self.anchor=anchor;self.offset=0;self.filter="";self.message=ready and "" or "The enabled addon list is unavailable."
 self:Fit()
 self.frame:ClearAllPoints()
 if anchor then self.frame:SetPoint("TOPRIGHT",anchor,"BOTTOMRIGHT",0,-7)
 else self.frame:SetPoint("TOPRIGHT",UIParent,"TOPRIGHT",-24,-70) end
 self:Render();self.frame:Show();self.mouseWasDown=query(G.IsMouseButtonDown)
 self:SnapshotPanels();self:InstallDismissHooks()
 self:RenewMinimapHold()
 if M.state then M.state.forceEvaluate=true end
 return true
end
function L:IsOpenFor(anchor)
 return anchor~=nil and self.anchor==anchor and self.frame~=nil and shown(self.frame)
end
function L:RenewMinimapHold()
 local n=M.Rework and M.Rework.Minimap
 if not n or not self:IsOpenFor(n.settingsButton) or not n.surface or not M.CVE or type(M.CVE.InputVisible)~="function" then return end
 local now=M.Safety and query(M.Safety.Now,M.Safety)
 if type(now)~="number" or now~=now then return end
 if self.holdSurface==n.surface and self.nextHoldRenew and now<self.nextHoldRenew and now>=self.nextHoldRenew-.5 then return end
 if not M.CVE:InputVisible(n.surface) then return end
 -- Continue this already-visible minimap only. The existing controller reads
 -- interactingUntil on its normal deadline; renewing it must not force a full
 -- visibility-controller pass on every menu mouse/anchor check. On close the
 -- short lease expires naturally, without overwriting another hover owner.
 local untilAt=n.surface.interactingUntil
 n.surface.interactingUntil=math.max(type(untilAt)=="number" and untilAt==untilAt and untilAt or 0,now+.75)
 self.holdSurface=n.surface;self.nextHoldRenew=now+.5
end
function L:Toggle(anchor)
 if self.frame and self.frame:IsShown() then self:Close("TOGGLE");return true end
 return self:Open(anchor)
end
function L:Close(reason)
 self.lastClose=reason
 if self.frame then self.frame:Hide() end
 self:HideRowTooltip()
end
function L:CloseTransient(reason)
 local menuOpen=self.frame and query(self.frame.IsShown,self.frame)==true
 local detailsOpen=self.detailFrame and query(self.detailFrame.IsShown,self.detailFrame)==true
 if not menuOpen and not detailsOpen then return false end
 self:Close(reason or "ESCAPE")
 if self.detailFrame then self.detailFrame:Hide() end
 return true
end
function L:OutsideClick()
 if not self.frame or not self.frame:IsShown() then return end
 if mouseOver(self.frame)==true or (self.anchor and mouseOver(self.anchor)==true) then return end
 self:Close("OUTSIDE_CLICK")
end
function L:SnapshotPanels()
 local state={};self.panelState=state
 for _,name in ipairs(panelNames) do local frame=G[name];state[name]={frame=frame,shown=shown(frame)} end
 for i=1,13 do local name="ContainerFrame"..i;local frame=G[name];state[name]={frame=frame,shown=shown(frame)} end
end
function L:PanelsChanged()
 for name,old in pairs(self.panelState or {}) do
  local frame=G[name]
  if shown(frame)~=old.shown or frame~=old.frame and shown(frame) then return true end
 end
 return false
end
function L:InstallDismissHooks()
 if type(G.hooksecurefunc)~="function" then return end
 self.dismissHooks=self.dismissHooks or {}
 for _,name in ipairs({"ShowUIPanel","HideUIPanel","ToggleWorldMap","ToggleAllBags"}) do
  if not self.dismissHooks[name] and type(G[name])=="function" then
   local hooked=pcall(G.hooksecurefunc,name,function()
    if L.frame and shown(L.frame) then L:Close("MAIN_INTERFACE_CHANGED") end
   end)
   if hooked then self.dismissHooks[name]=true end
  end
 end
end
function L:ShowDetails(e)
 if not self.detailFrame then
  local f=CreateFrame("Frame","MirageUIAddonDetails",UIParent,"BackdropTemplate");self.detailFrame=f
  f:SetSize(420,230);f:SetPoint("CENTER");f:SetFrameStrata("FULLSCREEN_DIALOG");f:SetClampedToScreen(true);f:EnableMouse(true);backdrop(f)
  f.icon=f:CreateTexture(nil,"ARTWORK");f.icon:SetSize(30,30);f.icon:SetPoint("TOPLEFT",16,-16)
  f.title=font(f,15);f.title:SetPoint("TOPLEFT",56,-18);f.title:SetSize(340,26)
  f.body=font(f,12);f.body:SetPoint("TOPLEFT",16,-58);f.body:SetSize(388,116);f.body:SetJustifyV("TOP");if f.body.SetWordWrap then f.body:SetWordWrap(true) end
  f.close=button(f,"Close",90,function() f:Hide() end);f.close:SetPoint("BOTTOMRIGHT",-14,14)
  if G.UISpecialFrames then table.insert(G.UISpecialFrames,"MirageUIAddonDetails") end
 end
 local f=self.detailFrame;self:SetEntryIcon(f.icon,e);f.title:SetText(e.title)
 if f.title.SetTextColor then
  if e.id=='MirageUI' then f.title:SetTextColor(.91,.55,.18,1)
  elseif e.suite then f.title:SetTextColor(.96,.79,.36,1)
  else f.title:SetTextColor(.9,.9,.9,1)end
 end
 local header=e.version~="" and "Version "..e.version.."\n" or ""
 f.body:SetText(header..(e.notes~="" and e.notes:sub(1,160).."\n\n" or "").."This addon has no registered settings destination. Use its documented command or its own launcher for any controls it provides.")
 self:FitDetails();f:Show()
end
function L:FitDetails()
 if not self.detailFrame then return end
 local w=positive(query(UIParent.GetWidth,UIParent)) or 1000;local h=positive(query(UIParent.GetHeight,UIParent)) or 800
 self.detailFrame:SetScale(math.max(.05,math.min(preferredScale(),(w-24)/420,(h-24)/230)))
end
function L:BindButton(b)
 if not b or b.mirageSuiteLauncherBound then return end
 b.mirageSuiteLauncherBound=true
 b:RegisterForClicks("LeftButtonUp","RightButtonUp")
 b:SetScript("OnClick",function(_,mouse)
  if mouse=="RightButton" then
   self:Close("DIRECT_SETTINGS");local called,ok,why=pcall(self.OpenCore,self)
   if (not called or not ok) and M.Print then M:Print(called and text(why) or "MirageUI settings could not open.") end
  else local ok,why=self:Toggle(b);if not ok and M.Print then M:Print(why) end end
 end)
 if b.HookScript then b:HookScript("OnHide",function() if self.anchor==b then self:Close("ANCHOR_HIDDEN") end end) end
 if b.icon and type(b.icon.SetTexture)=="function" then b.icon:SetTexture(suiteIcon) end
 b.tooltip="MirageUI AddOns\nLeft click: addon menu\nRight click: MirageUI settings"
end
function L:Report()
 return "status="..self.status.."; menu="..(self.frame and self.frame:IsShown() and "OPEN" or "CLOSED").."; enabled_addons="..#self.entries.."; last_opened="..(self.lastOpened or "NONE").."; settings_scope=EXPLICIT_REGISTRY_OR_EXACT_NATIVE_CATEGORY; other_routes=PUBLISHED_COMPARTMENT_OR_DETAILS; native_acceptance=NOT_RUN"
end
function L:Initialize()
 if self.eventFrame then return end
 local f=CreateFrame("Frame");self.eventFrame=f
 for _,event in ipairs({"ADDON_LOADED","PLAYER_REGEN_DISABLED","PLAYER_LOGOUT","DISPLAY_SIZE_CHANGED","UI_SCALE_CHANGED"}) do f:RegisterEvent(event) end
 self.mouseEvent=pcall(f.RegisterEvent,f,"GLOBAL_MOUSE_DOWN")
 f:SetScript("OnEvent",function(_,event)
  if event=="ADDON_LOADED" then self.dirty=true
  elseif event=="GLOBAL_MOUSE_DOWN" then self:OutsideClick()
  elseif event=="PLAYER_REGEN_DISABLED" or event=="PLAYER_LOGOUT" then self:Close(event);if self.detailFrame then self.detailFrame:Hide() end
  else
   -- Resizing must not reopen the menu: preserve the filter and page,
   -- anchor and any owned minimap interaction lease.
   if self.frame and self.frame:IsShown() then self:Fit();self:Render() end
   if self.detailFrame and self.detailFrame:IsShown() then self:FitDetails() end
  end
 end)
end
L:Initialize()
