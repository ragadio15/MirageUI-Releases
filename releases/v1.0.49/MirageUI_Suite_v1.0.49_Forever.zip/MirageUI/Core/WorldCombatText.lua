-- Source-supported unit-hit text above admitted Mirage nameplate debuffs.
-- Amounts remain opaque display-only values. Native world damage is the
-- fallback for unavailable routes; native healing is never globally disabled.
-- The original journal below retains native fallback height restoration.
-- C_CVar contract: reviewed Forever 70862, 70888, 70938, 70959 and 71037 source exports.
-- Names confirmed in Forever 70532 CVar dump d1ee569878094270c0ad8d8b00de0762158fd578;
-- Runtime public/writable capability and readback remain mandatory.
local _,M=...
local S,client,adapter=M.Safety,M.Client,M.adapter
local W={status="NOT_RUN",retryCount=0,plateStatus="NOT_PREPARED",plates=setmetatable({},{__mode="k"})};M.WorldCombatText=W
local KEY="worldCombatTextRecovery"
local reviewedClient=client.RuntimeAvailable or client.IsReviewedPresentationClient
local receiptSources={
 ["Forever:1.60.1:70862:16001"]="9dc84f0d3bbae1768ac3405b3716000bd93eda06",
 ["Forever:1.60.1:70888:16001"]="4cd0ab752a77164f654ccbca9d0c1fe8dafceebe",
 ["Forever:1.60.1:70938:16001"]="bebcb6bf309cf41b41bd74f8ca651e6a105b2676",
 ["Forever:1.60.1:70959:16001"]="3d8abb1da73acd38e412e24fb3f99454a6392346",
 ["Forever:1.60.1:71037:16001"]="734f065329cff4992835b01a84f210a297db91b6",
}
local journalClient,journalSource
local function reviewedReceipt(key,source)
 if not S:Text(key) or not S:Text(source) then return false end
 if receiptSources[key]~=nil and receiptSources[key]==source then return true end
 -- This receipt records our original/written CVar values, not source review.
 -- Restoration still requires the current public, writable API and exact
 -- written-value readback; another addon/user value is never overwritten.
 return source=="P18_PUBLIC_CVAR_READBACK" and #key<=160 and
  key:match("^[%w_]+:[%w%.%-]+:[%w%.%-]+:%d+$")~=nil
end
local names={"WorldTextScreenY_v2","WorldTextCritScreenY_v2"}
local floors={WorldTextScreenY_v2="0.06",WorldTextCritScreenY_v2="0.075"}
local rows,root,journal,entries,owner={},nil,nil,nil,nil
local busy,cancelled,loaded,yielded=false,false,false,false
local function plain(v) return S:Readable(v) and type(v)=="table" and getmetatable(v)==nil end
local function equal(v,w) return S:Readable(v) and v==w end
local function fields(v,allowed,maximum)
 if not plain(v) then return false end
 local count=0
 for k in next,v do
  count=count+1;if count>maximum or not S:Text(k) or not allowed[k] then return false end
 end
 return true
end
local journalFields={schema=true,client=true,source=true,entries=true}
local rowFields={original=true,written=true}
local function number(v)
 if not S:Text(v) or #v>64 then return nil end
 local n=tonumber(v);return S:Number(n) and n or nil
end
local function sourceCurrent()
 return M.WorldCombatText==W and M.Safety==S and M.Client==client and M.adapter==adapter
  and reviewedClient(client)==true
end
local function wanted()
 local cfg=M:ModuleConfig("Notifications")
 return sourceCurrent() and client.allowed==true and M:IsModuleActive("Notifications")
  and cfg and cfg.combatText==true, cfg
end
local function api()
 local t=_G.C_CVar
 if not plain(t) then return nil end
 local a={table=t,info=rawget(t,"GetCVarInfo"),get=rawget(t,"GetCVar"),default=rawget(t,"GetCVarDefault"),set=rawget(t,"SetCVar")}
 for _,k in ipairs({"info","get","default","set"}) do if not S:Readable(a[k]) or type(a[k])~="function" then return nil end end
 return a
end
local function apiCurrent(a)
 return a and rawequal(_G.C_CVar,a.table) and plain(a.table) and rawequal(rawget(a.table,"GetCVarInfo"),a.info)
  and rawequal(rawget(a.table,"GetCVar"),a.get) and rawequal(rawget(a.table,"GetCVarDefault"),a.default)
  and rawequal(rawget(a.table,"SetCVar"),a.set)
end
local function read(a,name)
 if not apiCurrent(a) or not sourceCurrent() then return nil end
 local ok,value,default,account,character,locked,secure,readonly=pcall(a.info,name)
 if not ok or not number(value) or not number(default) then return nil end
 for _,box in ipairs({{account},{character},{locked},{secure},{readonly}}) do
  local v=box[1]
  if not S:Readable(v) or type(v)~="boolean" then return nil end
 end
 if locked or secure or readonly then return nil end
 local publicOK,publicDefault=pcall(a.default,name)
 local currentOK,current=pcall(a.get,name)
 if not publicOK or not currentOK or not number(publicDefault) or not number(current)
  or number(publicDefault)~=number(default) or number(current)~=number(value)
  or not apiCurrent(a) or not sourceCurrent() then return nil end
 return {value=value,n=number(value),default=default,account=account,character=character}
end
local function modeCurrent(a)
 -- The _v2 offsets are only admitted for the observed modern world-text mode.
 -- Do not silently switch a player's Classic world-text preference.
 local r=read(a,"classicStyleWorldText")
 return r and r.n==0 or false
end
local function storeCurrent()
 if not root or not plain(root) or not rawequal(M.db,root) or not rawequal(_G.MirageUIDB,root)
  or not rawequal(rawget(root,KEY),journal) or not fields(journal,journalFields,4)
  or not equal(rawget(journal,"schema"),1) or not reviewedReceipt(journalClient,journalSource)
  or not equal(rawget(journal,"client"),journalClient) or not equal(rawget(journal,"source"),journalSource) or not rawequal(rawget(journal,"entries"),entries) or not plain(entries) then return false end
 local count=0
 for k,v in next,entries do
  count=count+1;if count>2 or not S:Text(k) or not floors[k] or not rows[k] or not rawequal(v,rows[k].saved) then return false end
 end
 for name,row in pairs(rows) do
  local s=row.saved
  if not rawequal(rawget(entries,name),s) or not fields(s,rowFields,2)
   or not equal(rawget(s,"original"),row.original) or not equal(rawget(s,"written"),row.written) then return false end
 end
 return true
end
local function clear(name)
 if not storeCurrent() then return false end
 rawset(entries,name,nil);rows[name]=nil
 if not next(rows) then
  rawset(root,KEY,nil);root,journal,entries,owner=nil,nil,nil,nil;journalClient,journalSource=nil,nil
 end
 return true
end
local function adopt()
 if loaded then return true end
 if not sourceCurrent() or not plain(M.db) or not rawequal(_G.MirageUIDB,M.db) or M.Profiles.readOnly then return false end
 local saved=rawget(M.db,KEY)
 if saved==nil then loaded=true;return true end
 if not fields(saved,journalFields,4) or not equal(rawget(saved,"schema"),1)
  or not reviewedReceipt(rawget(saved,"client"),rawget(saved,"source")) or not plain(rawget(saved,"entries")) then W.status="RECOVERY_RECEIPT_UNAVAILABLE";return false end
 local staged={};local count=0
 for name,s in next,rawget(saved,"entries") do
  count=count+1
  if count>2 or not S:Text(name) or not floors[name] or not fields(s,rowFields,2) then W.status="RECOVERY_RECEIPT_UNAVAILABLE";return false end
  local original,written=rawget(s,"original"),rawget(s,"written")
  local n=number(original)
  if not n or n< -1 or n>=tonumber(floors[name]) or not equal(written,floors[name]) then W.status="RECOVERY_RECEIPT_UNAVAILABLE";return false end
  staged[name]={original=original,written=written,saved=s}
 end
 if count==0 then W.status="RECOVERY_RECEIPT_UNAVAILABLE";return false end
 root,journal,entries,rows=M.db,saved,rawget(saved,"entries"),staged
 journalClient,journalSource=rawget(saved,"client"),rawget(saved,"source")
 loaded=true;W.restorePending=true
 return storeCurrent()
end
function W:Pending()
 return next(rows)~=nil or self.restorePending==true or self.plateRestorePending==true or (not loaded and plain(M.db) and rawget(M.db,KEY)~=nil) or false
end
function W:Initialize()
 if adopt() then self:Restore() end
end
function W:Restore()
 local plateRestored=not self.RestorePlateWorld or self:RestorePlateWorld()
 if busy then cancelled=true;self.restorePending=true;return false end
 if not adopt() then return not self:Pending() end
 if not next(rows) then self.restorePending=false;return plateRestored end
 self.restorePending=true
 if S:InCombat() then self.status="RESTORE_DEFERRED_COMBAT";return false end
 local a=owner and owner.api or api()
 if not apiCurrent(a) or not sourceCurrent() or not storeCurrent() then self.status="RESTORE_AUTHORITY_UNAVAILABLE";return false end
 busy=true
 for _,name in ipairs(names) do
  local row=rows[name]
  if row then
   if S:InCombat() or not sourceCurrent() or not apiCurrent(a) or not storeCurrent() then break end
   local current=read(a,name)
   if current and rows[name]==row and storeCurrent() and not S:InCombat() then
    if current.n==number(row.original) then clear(name)
    elseif current.n~=number(row.written) then yielded=true;clear(name)
    elseif sourceCurrent() and apiCurrent(a) then
     pcall(a.set,name,row.original)
     if rows[name]==row and apiCurrent(a) and sourceCurrent() and storeCurrent() and not S:InCombat() then
      local after=read(a,name)
      if after and rows[name]==row and storeCurrent() then
       if after.n==number(row.original) then clear(name)
       elseif after.n~=number(row.written) then yielded=true;clear(name) end
      end
     end
    end
   end
  end
 end
 busy=false;self.restorePending=next(rows)~=nil
 if not self.restorePending then self.retryCount=0;self.status=yielded and "FOREIGN_VALUE_PRESERVED" or "RESTORED" end
 return not self.restorePending and plateRestored
end

-- 70888 UnitDocumentation.UNIT_COMBAT exposes a public unit/event and an opaque
-- amount. The amount goes straight to a native text sink; it is never added,
-- compared, rounded, attributed to an attacker, read back or stored in a log.
-- These are hits received by the displayed unit, including other attackers.
local worldChannels={"floatingCombatTextCombatDamage_v2"}
local numericEvents={WOUND=true,DAMAGE=true,HEAL=true}
local words={MISS="Miss",DODGE="Dodge",PARRY="Parry",IMMUNE="Immune",EVADE="Evade",RESIST="Resist",BLOCK="Block",ABSORB="Absorb"}
local normalSize,criticalSize=26,35
function W:InvalidatePlates()
 self.plateRevision=(self.plateRevision or 0)+1
 self.platePolicyDirty=true
 self.plateRetryAt=nil;self.plateRetryAttempts=0
end
local transientPlateReasons={TARGET_STATE_UNAVAILABLE=true,NATIVE_PLATE_COLLECTION_UNAVAILABLE=true,
 NATIVE_PLATE_COLLECTION_INCOMPLETE=true,EMITTED_PLATE_ROUTE_UNAVAILABLE=true,CVAR_STATE_UNAVAILABLE=true,
 CVAR_API_UNAVAILABLE=true,CVAR_NOT_WRITABLE=true,CVAR_WRITE_UNCONFIRMED=true,CVAR_STATE_CHANGED=true,
 ROUTE_RECONCILIATION_FAILED=true,CVAR_OWNERSHIP_UNAVAILABLE=true,NATIVE_DAMAGE_CVAR_UNAVAILABLE=true}
function W:SchedulePlateRetry(reason)
 self.plateRetryAt=nil
 if transientPlateReasons[reason] and (self.plateRetryAttempts or 0)<3 then
  self.plateRetryAt=S:Now()+.25*2^(self.plateRetryAttempts or 0)
  self.platePolicyDeferred=true
 end
end
local function routeRecovered(self)
 -- A recovered route retires old native handback debt; otherwise its next
 -- maintenance pass could restore native text over this healthy custom route.
 self.plateRestorePending=nil;self.plateRestoreAttempts=0;self.plateRestoreAt=nil
 self.plateRetryAt=nil;self.plateRetryAttempts=0
 self.platePolicyDirty=nil;self.platePolicyDeferred=nil
end
local function hitFont(font,size)
 if not S:Frame(font,false) then return false end
 local path=STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"
 local okay,written=pcall(font.SetFont,font,path,size,"")
 if not okay or not S:Readable(written) or written~=true then return false end
 local read,file,height,flags=pcall(font.GetFont,font)
 return read and S:Text(file) and file==path and S:Number(height) and math.abs(height-size)<.001
  and S:Readable(flags) and (flags==nil or flags=="")
end
local function plateCurrent(view)
 local n=M.Rework and M.Rework.Nameplates
 return n and n.active and not view.filterOnly and view.admitted~=false and view.visibleDemand~=false and n:Current(view) and view.combatText and view.combatText.active
  and view.combatText.generation==view.generation and view.combatText.unit==view.unit
end
local function ordinary(frame)
 return S:Frame(frame,false) and S:Public(frame.IsProtected,"boolean",frame)==false
end
local function sinkParent(frame,parent)
 return ordinary(frame) and S:Public(frame.GetParent,nil,frame)==parent
end
local function sinkReady(view,text)
 if not text or not text.ready or not sinkParent(text.frame,view.frame) or #text.lines~=6 then return false end
 if type(text.frame.RegisterUnitEvent)~="function" or type(text.frame.UnregisterEvent)~="function"
  or type(text.frame.IsEventRegistered)~="function" then return false end
 for _,line in ipairs(text.lines) do
  if not sinkParent(line.frame,text.frame) or not S:Frame(line.font,false)
   or S:Public(line.font.GetParent,nil,line.font)~=line.frame or type(line.font.SetFont)~="function"
   or type(line.font.GetFont)~="function" or type(line.font.SetText)~="function"
   or type(line.font.SetFormattedText)~="function" or type(line.font.SetTextColor)~="function"
   or type(line.frame.SetAlpha)~="function" or type(line.frame.Show)~="function" or type(line.frame.Hide)~="function"
   or not line.animation or type(line.animation.Stop)~="function" or type(line.animation.Play)~="function" then return false end
 end
 return true
end
function W:WakePlateRoute()
 -- UNIT_COMBAT is fresh activity, not permission to hide an uncovered route.
 -- It only rearms the exhausted transient-observation budget for the next
 -- ordinary nameplate tick. The triggering event remains native, avoiding a
 -- duplicate if the engine has already rendered it. No idle polling is added.
 local now=S:Now()
 if self.platePolicyDirty or self.plateRetryAt or self.plateRestorePending
  or (self.plateRetryAttempts or 0)<3 or now<(self.plateEventWakeAt or 0)
  or not transientPlateReasons[self.plateCoverageReason] then return false end
 self.plateEventWakeAt=now+2
 self.plateEventWakes=(self.plateEventWakes or 0)+1
 self:InvalidatePlates()
 return true
end
local function friendlyWithoutDamageRoute(unit)
 -- Friendly and neutral nonattackable units have no hostile damage route.
 -- Require public attackability and disposition; a restricted/missing value
 -- is not evidence that an unknown unit may be ignored.
 if S:Public(UnitCanAttack,"boolean","player",unit)~=false then return false end
 if S:Public(UnitIsFriend,"boolean","player",unit)==true then return true end
 return S:Public(UnitReaction,"number","player",unit)==4
  and S:Public(UnitCanAttack,"boolean",unit,"player")==false
end
local function nativePlateExemption(plate)
 -- Native bases outlive their pooled UnitFrame. The removal callback clears
 -- GetUnit() and releases UnitFrame before the engine's emitted-base list is
 -- necessarily updated. That empty base is not a missing live damage route.
 -- Beta57 also leaves friendly bases wholly native, without a Mirage byPlate
 -- entry. Verify their current public identity rather than requiring a fake
 -- filtered owner merely to keep unrelated enemy numbers working.
 if not S:Frame(plate,false) then return nil end
 local getUnit,known=S:FieldAccess(plate,"GetUnit")
 if known~="KNOWN" or type(getUnit)~="function" then return nil end
 local okay,unit=pcall(getUnit,plate)
 if not okay or not S:Readable(unit) then return nil end
 if unit==nil then
  local _,state=S:FieldAccess(plate,"UnitFrame")
  if state~="ABSENT" then return nil end
  local after,latest=pcall(getUnit,plate)
  return after and S:Readable(latest) and latest==nil and "CLEARED_NATIVE_BASE" or nil
 end
 if not S:Text(unit) or not unit:match("^nameplate%d+$") then return nil end
 local getter=C_NamePlate and C_NamePlate.GetNamePlateForUnit
 if S:Public(getter,nil,unit)~=plate or not friendlyWithoutDamageRoute(unit) then return nil end
 -- A native callback can recycle the base while observations are in flight.
 local after,latest=pcall(getUnit,plate)
 if after and S:Text(latest) and latest==unit and S:Public(getter,nil,unit)==plate then
  return "NATIVE_FRIENDLY"
 end
end
function W:ClearPlateLines(view)
 local text=view and view.combatText
 if not text then return end
 local generation,unit=text.generation,text.unit
 local function current() return view.combatText==text and text.generation==generation and text.unit==unit end
 for _,line in ipairs(text.lines) do
  if not current() then return false end
  if line.animation and type(line.animation.Stop)=="function" then pcall(line.animation.Stop,line.animation) end
  if not current() then return false end
  if ordinary(line.frame) then
   pcall(line.frame.Hide,line.frame)
   if not current() then return false end
   if line.font and type(line.font.SetText)=="function" then pcall(line.font.SetText,line.font,"") end
  end
 end
 return current()
end
function W:ClearVisibleLines()
 -- Handoff retires already-flying custom numbers too, so they cannot linger
 -- beside the engine renderer after its global damage switch is restored.
 for view in pairs(self.plates) do self:ClearPlateLines(view) end
end
function W:PreparePlate(view)
 local text=view.combatText
 if text and text.ready then return true end
 if S:InCombat() or not sourceCurrent() or not ordinary(view.frame) then return false end
 if not text then text={lines={},nextLine=0,active=false,ready=false};view.combatText=text end
 if (text.prepareAttempts or 0)>=3 or S:Now()<(text.prepareAt or 0) then return false end
 text.prepareAttempts=(text.prepareAttempts or 0)+1;text.prepareAt=S:Now()+.25
 if text.prepareAttempts>1 then self.platePreparationRetries=(self.platePreparationRetries or 0)+1 end
 local frame,upper,unit,generation=view.frame,view.upper,view.unit,view.generation
 local function current()
  return view.combatText==text and view.frame==frame and view.upper==upper and view.unit==unit
   and view.generation==generation and not S:InCombat() and sourceCurrent() and ordinary(frame)
   and (not text.frame or sinkParent(text.frame,frame))
 end
 local ok=pcall(function()
  assert(current(),"CUSTOM_HIT_OWNER_CHANGED")
  local f=text.frame
  if not f then f=CreateFrame("Frame",nil,frame);text.frame=f end
  assert(current(),"CUSTOM_HIT_OWNER_CHANGED");S:Passive(f)
  assert(current(),"CUSTOM_HIT_OWNER_CHANGED")
  f:SetSize(280,44);f:SetPoint("BOTTOM",view.upper,"TOP",0,12)
  for i=1,6 do
   assert(current(),"CUSTOM_HIT_OWNER_CHANGED")
   local entry=text.lines[i]
   if not entry then entry={};text.lines[i]=entry end
   local line=entry.frame
   if not line then line=CreateFrame("Frame",nil,f);entry.frame=line end
   local function owns()
    return current() and text.lines[i]==entry and sinkParent(line,f)
     and (not entry.font or S:Frame(entry.font,false) and S:Public(entry.font.GetParent,nil,entry.font)==line)
   end
   assert(owns(),"CUSTOM_HIT_OWNER_CHANGED");S:Passive(line);line:SetSize(220,44)
   line:SetPoint("CENTER",f,"CENTER",(i%2==0 and 1 or -1)*40,math.floor((i-1)/2)*28);line:Hide()
   assert(owns(),"CUSTOM_HIT_OWNER_CHANGED")
   local font=entry.font
   if not font then font=line:CreateFontString(nil,"OVERLAY");entry.font=font end
   assert(owns(),"CUSTOM_HIT_OWNER_CHANGED");font:SetAllPoints();font:SetJustifyH("CENTER")
   assert(owns() and hitFont(font,normalSize) and owns(),"CUSTOM_HIT_FONT_UNCONFIRMED");font:SetTextColor(1,.88,.62,1)
   if font.SetShadowColor then font:SetShadowColor(0,0,0,.9);font:SetShadowOffset(1,-1) end
   assert(owns(),"CUSTOM_HIT_OWNER_CHANGED")
   local group=entry.animation
   if not group then group=line:CreateAnimationGroup();entry.animation=group end
   local move=entry.move
   if not move then move=group:CreateAnimation("Translation");entry.move=move end
   assert(owns(),"CUSTOM_HIT_OWNER_CHANGED");move:SetOrder(1);move:SetDuration(1.05);move:SetOffset(0,36)
   local fade=entry.fade
   if not fade then fade=group:CreateAnimation("Alpha");entry.fade=fade end
   assert(owns(),"CUSTOM_HIT_OWNER_CHANGED");fade:SetOrder(1);fade:SetStartDelay(.55);fade:SetDuration(.5);fade:SetFromAlpha(1);fade:SetToAlpha(0)
   group:SetScript("OnFinished",function()
    if ordinary(line) then line:Hide();font:SetText("") end
   end)
   assert(owns(),"CUSTOM_HIT_OWNER_CHANGED")
  end
  assert(current(),"CUSTOM_HIT_OWNER_CHANGED")
  f:SetScript("OnEvent",function(_,event,unit,kind,flags,amount)
   if event=="UNIT_COMBAT" then W:PlateEvent(view,unit,kind,flags,amount) end
  end)
  assert(type(f.RegisterUnitEvent)=="function" and type(f.IsEventRegistered)=="function","NATIVE_UNIT_EVENT_UNAVAILABLE")
 end)
 if not current() then return false end
 text.ready=ok;self.plateStatus=ok and "CUSTOM_SINKS_PREPARED" or "CUSTOM_SINK_UNAVAILABLE_KEEP_NATIVE"
 if ok then text.prepareAt=nil else self.plateLastSinkFailure="PREPARATION_UNAVAILABLE" end
 return ok
end
function W:AttachPlate(view)
 local text=view.combatText
 local provider=M.Rework and M.Rework.Nameplates
 if not text or not S:Text(view.unit) or not view.unit:match("^nameplate%d+$")
  or not provider or not provider.active or not sourceCurrent() or not provider:Current(view) then return false end
 local unit,generation=view.unit,view.generation
 local function current()
  return view.combatText==text and view.unit==unit and view.generation==generation and sourceCurrent()
   and M.Rework and M.Rework.Nameplates==provider and provider.active and provider:Current(view)
   and M.Rework and M.Rework.Nameplates==provider and provider.active
   and view.combatText==text and view.unit==unit and view.generation==generation
   and text.unit==unit and text.generation==generation
 end
 if text.unit~=unit or text.generation~=generation then text.repairAttempts=0;text.repairAt=nil end
 text.unit=unit;text.generation=generation;text.active=false
 self.plates[view]=true;self:InvalidatePlates()
 if not text.ready or not sinkReady(view,text) then
  self.plateStatus="CUSTOM_SINK_UNAVAILABLE_KEEP_NATIVE";return false
 end
 if not current() then return false end
 pcall(text.frame.UnregisterEvent,text.frame,"UNIT_COMBAT")
 if not sinkReady(view,text) or not current() then return false end
 local ok,result=pcall(text.frame.RegisterUnitEvent,text.frame,"UNIT_COMBAT",unit)
 if not sinkReady(view,text) or not current() then return false end
 local registered=S:Public(text.frame.IsEventRegistered,"boolean",text.frame,"UNIT_COMBAT")
 if not sinkReady(view,text) or not current() then return false end
 text.active=ok and result~=false and registered==true
 if text.active then text.failed=nil;text.repairAt=nil
 else text.repairAt=S:Now()+.25;self.plateLastSinkFailure="UNIT_EVENT_UNAVAILABLE" end
 self.plateStatus=text.active and "CUSTOM_UNIT_HITS_READY" or "UNIT_EVENT_UNAVAILABLE_KEEP_NATIVE"
 return text.active
end
function W:RepairPlate(view,provider)
 local text=view and view.combatText
 if not text or not (text.failed or text.active==false)
  or not provider or not provider.active or not provider:Current(view)
  or text.generation~=view.generation or text.unit~=view.unit or not sourceCurrent() then return false end
 local generation,unit=text.generation,text.unit
 local function current()
  return sourceCurrent() and view.combatText==text and text.generation==generation
   and text.unit==unit and view.generation==generation and view.unit==unit
   and M.Rework and M.Rework.Nameplates==provider and provider.active and provider:Current(view)
   and M.Rework and M.Rework.Nameplates==provider and provider.active
   and view.combatText==text and text.generation==generation and text.unit==unit
   and view.generation==generation and view.unit==unit
 end
 if not text.ready then
  -- Allocation remains outside combat. Each partial widget is reused, and
  -- routine Configure calls do not renew the three-attempt preparation budget.
  if not current() or not self:PreparePlate(view) or not current() then return false end
  return self:AttachPlate(view)
 end
 if (text.repairAttempts or 0)>=2 or S:Now()<(text.repairAt or 0) or not sinkReady(view,text) or not current() then return false end
 text.repairAttempts=(text.repairAttempts or 0)+1
 text.repairAt=S:Now()+.25
 self.plateSinkRepairAttempts=(self.plateSinkRepairAttempts or 0)+1
 self:ClearPlateLines(view)
 for _,line in ipairs(text.lines) do
  if not sinkReady(view,text) or not current() or not hitFont(line.font,normalSize)
   or not sinkReady(view,text) or not current() then return false end
 end
 -- The old binding remains attached until the same prepared sink is verified.
 -- Two repairs per assignment bound recurring setter failures; later plate
 -- reuse gets a fresh allowance without allocating more frames.
 local okay=current() and self:AttachPlate(view) or false
 if okay then self.plateSinkRepairs=(self.plateSinkRepairs or 0)+1 end
 return okay
end
function W:RearmPlate(view)
 -- Explicit recovery only, after the provider has completed native handback.
 local text=view and view.combatText
 if S:InCombat() or not sourceCurrent() or not text or text.active or text.unit~=nil then return false end
 text.prepareAttempts=0;text.prepareAt=nil;text.repairAttempts=0;text.repairAt=nil
 return true
end
function W:DetachPlate(view)
 local text=view and view.combatText;if not text then return end
 text.active=false;text.unit=nil;text.generation=nil
 if text.frame then pcall(text.frame.UnregisterEvent,text.frame,"UNIT_COMBAT") end
 self:ClearPlateLines(view)
 self.plates[view]=nil;self:InvalidatePlates()
 if self.plateWorldSuppressed and S:InCombat() then self:ReconcilePlates(M.Rework and M.Rework.Nameplates) end
end
function W:PlateEvent(view,unit,kind,flags,amount)
 self.plateEvents=(self.plateEvents or 0)+1
 if not wanted() or not plateCurrent(view) or not S:Text(unit) or not S:Text(kind) then return false end
 if unit~=view.unit then
  -- RegisterUnitEvent filters the underlying unit, but a public alias may
  -- still be supplied. Resolve it to the same live native anchor; never bind
  -- a card to a target/mouseover alias or accept an old recycled identity.
  local plate=view.lease and view.lease.plate
  if (unit~="target" and unit~="focus" and unit~="mouseover")
   or S:Public(UnitIsUnit,"boolean",unit,view.unit)~=true
   or S:Public(C_NamePlate and C_NamePlate.GetNamePlateForUnit,nil,unit)~=plate
   or not plateCurrent(view) then return false end
  self.plateAliasEvents=(self.plateAliasEvents or 0)+1
 end
 local text=view.combatText
 if not numericEvents[kind] and not words[kind] then return false end
 if text.failed then self:WakePlateRoute();return false end
 -- A public presentation CVar is the final duplication gate, including when
 -- legal activation is deferred until combat ends. Native healing is never
 -- disabled: player/friendly/off-screen healing often has no nameplate route.
 local channel=kind=="HEAL" and "floatingCombatTextCombatHealing_v2" or "floatingCombatTextCombatDamage_v2"
 local native=S:Public(C_CVar and C_CVar.GetCVar,"string",channel)
 if native~="0" then
  self.plateNativeEvents=(self.plateNativeEvents or 0)+1;self:ClearPlateLines(view)
  self:WakePlateRoute();return false
 end
 text.nextLine=text.nextLine%#text.lines+1
 local line=text.lines[text.nextLine]
 if not ordinary(line.frame) then
  text.failed=true;text.repairAt=S:Now()+.25;self.platePolicyDirty=true;self.plateStatus="CUSTOM_SINK_UNAVAILABLE_KEEP_NATIVE"
  self.plateLastSinkFailure="SINK_NOT_ORDINARY"
  self:ReconcilePlates(M.Rework and M.Rework.Nameplates);return false
 end
 local critical=S:Text(flags) and flags=="CRITICAL"
 local generation,unitIdentity=text.generation,text.unit
 local function current() return view.combatText==text and text.generation==generation and text.unit==unitIdentity and plateCurrent(view) end
 local ok=pcall(function()
  assert(current() and ordinary(line.frame),"CUSTOM_HIT_OWNER_CHANGED")
  line.animation:Stop();assert(current(),"CUSTOM_HIT_OWNER_CHANGED")
  line.frame:SetAlpha(1)
  assert(current() and hitFont(line.font,critical and criticalSize or normalSize) and current(),"CUSTOM_HIT_FONT_UNCONFIRMED")
  if kind=="HEAL" then line.font:SetTextColor(.5,1,.65,1)
  elseif numericEvents[kind] then line.font:SetTextColor(1,.88,.62,1)
  else line.font:SetTextColor(.84,.86,.9,1) end
  assert(current(),"CUSTOM_HIT_OWNER_CHANGED")
  if numericEvents[kind] then
   -- Use the engine formatter itself; %s deliberately avoids arithmetic and
   -- preserves the supplied native amount exactly, even when it is secret.
   line.font:SetFormattedText(kind=="HEAL" and "+%s" or "%s",amount)
  else line.font:SetText(words[kind]) end
  assert(current(),"CUSTOM_HIT_OWNER_CHANGED")
  line.frame:Show();assert(current(),"CUSTOM_HIT_OWNER_CHANGED");line.animation:Play()
 end)
 if not current() then return false end
 if not ok then
  self:ClearPlateLines(view)
  if not current() then return false end
  text.failed=true;text.repairAt=S:Now()+.25;self.platePolicyDirty=true;self.plateStatus="CUSTOM_SINK_UNAVAILABLE_KEEP_NATIVE"
  self.plateLastSinkFailure="FONT_OR_TEXT_WRITE_FAILED"
  self:ReconcilePlates(M.Rework and M.Rework.Nameplates);return false
 end
 text.received=true;self.plateDrawn=(self.plateDrawn or 0)+1;self.plateStatus="CUSTOM_UNIT_HITS_DISPLAYED"
 return true
end
function W:RestorePlateWorld()
 self:ClearVisibleLines()
 local r=M.Rework
 if not r or not r.RestoreCVars then return true end
 if S:InCombat() then
  local now=S:Now()
  if (self.plateRestoreAttempts or 0)>=3 or now<(self.plateRestoreAt or 0) then self.plateRestorePending=true;return false end
  self.plateRestoreAttempts=(self.plateRestoreAttempts or 0)+1;self.plateRestoreAt=now+.5
  local okay=type(r.RestoreWorldDamage)=="function" and r:RestoreWorldDamage()==true
  self.plateWorldSuppressed=not okay or nil;self.plateRestorePending=not okay or nil
  if okay then self.plateRestoreAttempts=0;self.plateRestoreAt=nil end
  return okay
 end
 self.plateRestoreAttempts=0;self.plateRestoreAt=nil
 local complete=true
 for _,key in ipairs(worldChannels) do complete=r:RestoreCVars("nameplates",key)~=false and complete end
 self.plateWorldSuppressed=not complete or nil
 self.plateRestorePending=not complete or nil
 return complete
end
local function reconcilePlates(self,provider)
 if self.plateRestorePending and not self.platePolicyDirty and S:InCombat() then
  if (self.plateRestoreAttempts or 0)<3 and S:Now()>=(self.plateRestoreAt or 0) and self:RestorePlateWorld() then
   self.plateStatus="NATIVE_FALLBACK_NO_COMPLETE_PLATE_COVERAGE"
  end
  return
 end
 if not self.platePolicyDirty then return end
 local combat=S:InCombat()
 local r,profile=M.Rework,M.profile
 local mapped=provider and provider.byPlate
 local store=r and r.store
 local ready=wanted() and provider and provider.active and sourceCurrent()
 if ready then for view in pairs(self.plates) do self:RepairPlate(view,provider) end end
 -- A completed same-owner repair reattaches its event subscription. Begin
 -- the coverage snapshot afterward so that deliberate repair is included.
 local revision=self.plateRevision or 0
 local count,targetCovered,clearedBases,nativeFriends=0,false,0,0
 local covered={}
 local targetExists,targetState=S:Public(UnitExists,"boolean","target")
 local nativeDamage,nativeState=S:Public(C_CVar and C_CVar.GetCVar,"string","floatingCombatTextCombatDamage_v2")
 local reason=not ready and "CUSTOM_ROUTE_DISABLED" or nil
 self.plateUpstreamReason=nil;self.plateUpstreamStage=nil;self.plateUpstreamState=nil
 if ready then
  if targetState~="KNOWN" then ready=false;reason="TARGET_STATE_UNAVAILABLE" end
  local plates,state=S:Public(C_NamePlate and C_NamePlate.GetNamePlates,"table")
  if state~="KNOWN" then ready=false;reason="NATIVE_PLATE_COLLECTION_UNAVAILABLE"
  elseif type(canaccesstable)=="function" and S:Public(canaccesstable,"boolean",plates)~=true then
   ready=false;reason="NATIVE_PLATE_COLLECTION_UNAVAILABLE"
  else
  -- The native driver enumerates a collection, not a dense numeric array.
  -- A hole must not omit an uncovered route before the global damage channel
  -- is acquired. Public access and the shared 80-plate bound still apply.
  local collectionKey
  for i=1,81 do
   local okay,nextKey,plate=pcall(next,plates,collectionKey)
   if not okay or not S:Readable(nextKey) or not S:Readable(plate) then ready=false;reason="NATIVE_PLATE_COLLECTION_INCOMPLETE";break end
   if nextKey==nil then break end
   if i>80 then ready=false;reason="NATIVE_PLATE_COLLECTION_INCOMPLETE";break end
   collectionKey=nextKey
   local view=provider.byPlate[plate]
   -- Deliberately filtered categories have no combat-text obligation. They
   -- must still have a current owner and confirmed cleared native hit region;
   -- an absent or failed takeover is not equivalent to a filtered plate.
   if view and provider:Current(view) and (view.filterOnly or view.admitted==false) and not view.hitPending then
    -- No payload is routed into a hidden card.
   elseif not view or not plateCurrent(view) or view.combatText.failed then
    local exempt=nativePlateExemption(plate)
    if exempt=="CLEARED_NATIVE_BASE" then clearedBases=clearedBases+1
    elseif exempt=="NATIVE_FRIENDLY" then nativeFriends=nativeFriends+1
    else
     ready=false;reason="EMITTED_PLATE_ROUTE_UNAVAILABLE"
     if type(provider.InputBlocker)=="function" then
      local upstream,stage,availability=provider:InputBlocker(plate)
      if upstream then
       reason=availability=="NATIVE_POLICY" and "NATIVE_INPUT_POLICY_RETAINED" or "NAMEPLATE_INPUT_DEPENDENCY"
       self.plateUpstreamReason=upstream;self.plateUpstreamStage=stage;self.plateUpstreamState=availability
      end
     end
     break
    end
   else
    if S:Public(UnitIsUnit,"boolean",view.unit,"target")==true then targetCovered=true end
    count=count+1
    covered[count]={view=view,unit=view.unit,generation=view.generation,text=view.combatText,plate=plate}
   end
  end end
 end
 -- A target gap or a nonattackable selection does not remove emitted hostile
 -- routes. Acquisition remains tied to complete current route coverage, and
 -- a real selected enemy without an emitted route still gets native fallback.
 local friendlyTarget=targetState=="KNOWN" and targetExists==true and friendlyWithoutDamageRoute("target")
 -- Public getters can trigger native lifecycle callbacks. Do not continue an
 -- old coverage decision after its profile/provider was withdrawn, or write
 -- through a replacement service's CVar journal.
 if not sourceCurrent() or M.Rework~=r or r and r.store~=store or r and r.Nameplates~=provider then
  self.platePolicyDirty=true;self.platePolicyDeferred=nil
  self.plateCoverageReason="ROUTE_CONTEXT_CHANGED";return false
 end
 if ready and (M.profile~=profile or not provider.active or provider.byPlate~=mapped or not wanted()) then
  ready=false;reason="ROUTE_CONTEXT_CHANGED"
 end
 local continued=ready and combat and (targetExists==false or friendlyTarget) and count>0
 if ready and (self.plateRevision or 0)~=revision then
  self.platePolicyDirty=true;self.plateCoverageReason="ROUTE_CONTEXT_CHANGED"
  self:RestorePlateWorld();return false
 end
 self.plateClearedBases=clearedBases;self.plateNativeFriends=nativeFriends
 self.plateActiveRoutes=count
 if ready and count==0 then reason="NO_VISIBLE_CUSTOM_PLATES"
 elseif ready and targetExists==true and not targetCovered then reason="SELECTED_TARGET_ROUTE_UNAVAILABLE"
 elseif ready and targetExists==false and not continued then reason="NO_SELECTED_TARGET" end
 if not ready or count==0 or not targetCovered and not continued then
  self.platePolicyDirty=nil
  self.platePolicyDeferred=nil;self.plateCoverageReason=reason or "CUSTOM_COVERAGE_UNAVAILABLE"
  local restored=self:RestorePlateWorld()
  self.plateFallbacks=(self.plateFallbacks or 0)+1
  self:SchedulePlateRetry(self.plateCoverageReason)
  self.plateStatus=restored and "NATIVE_FALLBACK_NO_COMPLETE_PLATE_COVERAGE" or "NATIVE_DAMAGE_RESTORE_PENDING";return false
 end
 self.plateCoverageReason=continued and (friendlyTarget and "CURRENT_VISIBLE_ROUTES_FRIENDLY_TARGET" or "CURRENT_VISIBLE_ROUTES_TARGET_GAP")
  or "VISIBLE_PLATES_AND_TARGET_COVERED"
 if combat then
  if self.plateWorldSuppressed and nativeState=="KNOWN" and nativeDamage=="0" then
   routeRecovered(self)
   self.plateStatus="CUSTOM_VISIBLE_UNIT_DAMAGE; NATIVE_HEALING_RETAINED; OFFSCREEN_UNATTRIBUTED"
   return true
  end
  if type(r.AcquireWorldDamage)~="function" then
   self.platePolicyDirty=nil;self.platePolicyDeferred=true;self.plateStatus="NATIVE_FALLBACK_COMBAT_ACTIVATION_DEFERRED";return
  end
 end
 self.platePolicyDirty=nil;self.platePolicyDeferred=nil
 local complete=true
 local function routeCurrent()
  if not sourceCurrent() or M.Rework~=r or r.store~=store or M.profile~=profile or r.Nameplates~=provider
   or not provider.active or provider.byPlate~=mapped or (self.plateRevision or 0)~=revision or not wanted() then return false end
  for _,entry in ipairs(covered) do
   local view=entry.view
   if mapped[entry.plate]~=view or view.unit~=entry.unit or view.generation~=entry.generation or view.combatText~=entry.text
    or not plateCurrent(view) or view.combatText.failed then return false end
  end
  local exists,state=S:Public(UnitExists,"boolean","target")
  if state~="KNOWN" or exists~=targetExists then return false end
  if targetCovered then
   local selected=false
   for _,entry in ipairs(covered) do
    if S:Public(UnitIsUnit,"boolean",entry.unit,"target")==true then selected=true;break end
   end
   if not selected then return false end
  elseif friendlyTarget and not friendlyWithoutDamageRoute("target") then return false end
  return (self.plateRevision or 0)==revision and M.profile==profile and provider.active and wanted()
 end
 local okay,why
 if type(r.AcquireWorldDamage)=="function" then okay,why=r:AcquireWorldDamage(routeCurrent)
 else okay,why=r:WriteCVar("nameplates",worldChannels[1],0) end
 if not okay then self.plateCoverageReason=S:Text(why) and why or "NATIVE_DAMAGE_CVAR_UNAVAILABLE" end
 complete=okay==true and routeCurrent()
 if not complete then
  self:RestorePlateWorld();self:SchedulePlateRetry(self.plateCoverageReason)
  self.plateStatus="CUSTOM_WITH_NATIVE_CVAR_FALLBACK";return false
 end
 self.plateAcquisitions=(self.plateAcquisitions or 0)+1
 if combat then self.plateCombatRecoveries=(self.plateCombatRecoveries or 0)+1 end
 routeRecovered(self)
 self.plateWorldSuppressed=true;self.plateStatus="CUSTOM_VISIBLE_UNIT_DAMAGE; NATIVE_HEALING_RETAINED; OFFSCREEN_UNATTRIBUTED"
 return true
end
function W:ReconcilePlates(provider)
 if self.plateReconciling then self:InvalidatePlates();return false end
 if not self.platePolicyDirty and self.plateRetryAt and S:Now()>=self.plateRetryAt then
  self.plateRetryAt=nil;self.plateRetryAttempts=(self.plateRetryAttempts or 0)+1
  self.plateScheduledRetries=(self.plateScheduledRetries or 0)+1;self.platePolicyDirty=true
 end
 self.plateReconciling=true
 local okay,result=pcall(reconcilePlates,self,provider)
 self.plateReconciling=nil
 if not okay then
  self.platePolicyDirty=true;self.plateCoverageReason="ROUTE_RECONCILIATION_FAILED"
  self.plateReconcileFailures=(self.plateReconcileFailures or 0)+1
  self.platePolicyDirty=nil
  self:RestorePlateWorld();self:SchedulePlateRetry(self.plateCoverageReason);self.plateStatus="CUSTOM_WITH_NATIVE_CVAR_FALLBACK"
  return false
 end
 return result
end
function W:PlateSummary()
 -- Cached authored state only: /check must not enumerate native plates,
 -- reconcile a route, repair a sink or touch gameplay input/CVars.
 local active,failed=0,0
 local provider=M.Rework and M.Rework.Nameplates
 for view in pairs(self.plates) do
  local text=view.combatText;local lease=view.lease
  local mapped=provider and provider.byPlate
  if provider and provider.active and not view.retiring and view.admitted~=false and not view.filterOnly and view.visibleDemand~=false
   and lease and mapped and mapped[lease.plate]==view and text and text.active
   and text.unit==view.unit and text.generation==view.generation then
   if text.failed then failed=failed+1 else active=active+1 end
  end
 end
 local mode=self.plateRestorePending and "NATIVE_RESTORE_PENDING"
  or self.platePolicyDirty and "RECONCILIATION_PENDING"
  or self.plateWorldSuppressed and active>0 and failed==0 and not (M.state and M.state.safe) and "CUSTOM_VISIBLE_UNIT_DAMAGE"
  or "NATIVE_FALLBACK"
 local function tag(value,default)
  return type(value)=="string" and #value<=96 and value:match("^[A-Z0-9_]+$") and value or default
 end
 return "mode="..mode.."; reason="..tag(self.plateCoverageReason,"NOT_OBSERVED")
  .."; active_routes="..active.."; failed_routes="..failed.."; upstream="..tag(self.plateUpstreamReason,"NONE")
  .."; native_healing=RETAINED; scope=PUBLIC_UNIT_RECEIVED_HITS; offscreen_coverage=NOT_CLAIMED; native_qualification=NOT_RUN"
end
function W:PlateReport()
 -- Fixed classification tags and aggregate counts only; never unit identities,
 -- native event payloads, amounts or formatted text.
 local active,failed=0,0
 for view in pairs(self.plates) do
  local text=view.combatText
  if text and text.active and text.unit==view.unit and text.generation==view.generation then
   active=active+1;if text.failed then failed=failed+1 end
  end
 end
 return "plate_hit_scope=PUBLIC_UNIT_RECEIVED_HITS_NOT_PLAYER_ATTRIBUTION; plate_hit_route_reason="..(self.plateCoverageReason or "NOT_OBSERVED")
  .."; plate_hit_active_routes="..active.."; plate_hit_failed_routes="..failed
  .."; plate_hit_cleared_native_bases="..(self.plateClearedBases or 0).."; plate_hit_native_friendly_bases="..(self.plateNativeFriends or 0)
  .."; plate_hit_normal_size="..normalSize.."; plate_hit_critical_size="..criticalSize
  .."; plate_hit_events="..(self.plateEvents or 0).."; plate_hit_drawn="..(self.plateDrawn or 0).."; plate_hit_native_events="..(self.plateNativeEvents or 0)
  .."; plate_hit_alias_events="..(self.plateAliasEvents or 0).."; plate_hit_combat_recoveries="..(self.plateCombatRecoveries or 0)
  .."; plate_hit_fallbacks="..(self.plateFallbacks or 0).."; plate_hit_reconcile_failures="..(self.plateReconcileFailures or 0)
  .."; plate_hit_scheduled_retries="..(self.plateScheduledRetries or 0).."; plate_hit_retry_pending="..tostring(self.plateRetryAt~=nil)
  .."; plate_hit_event_wakes="..(self.plateEventWakes or 0).."; plate_hit_sink_repairs="..(self.plateSinkRepairs or 0)
  .."; plate_hit_sink_repair_attempts="..(self.plateSinkRepairAttempts or 0).."; plate_hit_preparation_retries="..(self.platePreparationRetries or 0)
  .."; plate_hit_last_sink_failure="..(self.plateLastSinkFailure or "NONE")
  .."; plate_hit_upstream="..(self.plateUpstreamReason or "NONE").."; plate_hit_upstream_stage="..(self.plateUpstreamStage or "NONE")
  .."; plate_hit_upstream_availability="..(self.plateUpstreamState or "NONE")
  .."; plate_hit_native_healing=RETAINED; plate_hit_offscreen_coverage=NOT_CLAIMED; plate_hit_native_qualification=NOT_RUN"
end
local function contextCurrent(o)
 if not o or not modeCurrent(o.api) then return false end
 local enabled,cfg=wanted()
 return not cancelled and enabled and rawequal(M.profile,o.profile) and rawequal(cfg,o.cfg)
  and rawequal(M.modules.Notifications,o.module) and apiCurrent(o.api) and storeCurrent() and not S:InCombat()
end
function W:Apply()
 if busy then cancelled=true;self.restorePending=true;return false end
 if not adopt() then return false end
 local enabled,cfg=wanted()
 if not enabled then return self:Restore() end
 if S:InCombat() then self.status="APPLY_DEFERRED_COMBAT";return false end
 if self.restorePending then if not self:Restore() then return false end end
 if next(rows) then
  -- A new profile/configuration starts from the original, never from our floor.
  if not owner or not contextCurrent(owner) then if not self:Restore() then return false end
  else
   local valid=true
   for name,row in pairs(rows) do local r=read(owner.api,name);if not r or r.n~=number(row.written) then valid=false end end
   if valid and contextCurrent(owner) then self.status="NATIVE_WORLD_TEXT_HEIGHT_RAISED";return true end
   self:Restore();return false
  end
 end
 if yielded then self.status="FOREIGN_VALUE_PRESERVED";return false end
 local a=api();if not a then self.status="CVAR_API_UNAVAILABLE";return false end
 if not modeCurrent(a) then self.status="NATIVE_WORLD_TEXT_MODE_UNAVAILABLE";return false end
 local staged={}
 for _,name in ipairs(names) do
  local r=read(a,name)
  if not r or r.n< -1 then self.status="NATIVE_HEIGHT_UNAVAILABLE";return false end
  staged[name]=r
 end
 enabled,cfg=wanted()
 if not enabled or S:InCombat() or not sourceCurrent() or not apiCurrent(a) or not modeCurrent(a)
  or not plain(M.db) or not rawequal(_G.MirageUIDB,M.db) or M.Profiles.readOnly or rawget(M.db,KEY)~=nil then return false end
 local changed=false;local newEntries={};local newRows={}
 for _,name in ipairs(names) do
  if staged[name].n<tonumber(floors[name]) then
   local s={original=staged[name].value,written=floors[name]};newEntries[name]=s
   newRows[name]={original=s.original,written=s.written,saved=s};changed=true
  end
 end
 if not changed then self.status="EXISTING_HIGHER_HEIGHT_PRESERVED";return true end
 root=M.db;entries=newEntries;rows=newRows
 journalClient,journalSource=client.key,client.sourceMatched and adapter.sourceCommit or "P18_PUBLIC_CVAR_READBACK"
 journal={schema=1,client=journalClient,source=journalSource,entries=entries}
 -- Persist the bounded recovery receipt BEFORE the first native write. A legal
 -- logout restores immediately; a combat logout/reload restores at next startup.
 rawset(root,KEY,journal)
 owner={api=a,profile=M.profile,cfg=cfg,module=M.modules.Notifications}
 busy=true;cancelled=false
 local good=true
 for _,name in ipairs(names) do
  if not contextCurrent(owner) then good=false;break end
  -- Stage BOTH variables and recheck the entire pair before each mutation.
  for _,key in ipairs(names) do
   local r=read(a,key)
   if not r or r.n~=staged[key].n or r.default~=staged[key].default
    or r.account~=staged[key].account or r.character~=staged[key].character then good=false;break end
  end
  if not good or not contextCurrent(owner) then good=false;break end
  local row=rows[name]
  if row then
   local ok,success=pcall(a.set,name,row.written)
   if not ok or not S:Readable(success) or success~=true or not contextCurrent(owner) then good=false;break end
   local after=read(a,name)
   if not after or after.n~=number(row.written) or not contextCurrent(owner) then good=false;break end
   staged[name]=after
  end
 end
 if good then
  for _,name in ipairs(names) do local r=read(a,name);if not r or r.n~=staged[name].n then good=false;break end end
  good=good and contextCurrent(owner)
 end
 busy=false
 if not good then self.restorePending=true;self:Restore();self.status=self.restorePending and "RESTORE_PENDING" or "WRITE_NOT_CONFIRMED";return false end
 self.status="NATIVE_WORLD_TEXT_HEIGHT_RAISED";self.retryCount=0;return true
end
function W:Retry(now)
 if busy or not S:Number(now) or now<(self.retryAt or 0) or S:InCombat() then return end
 self.retryAt=now+.5
 if not next(rows) and not self:Pending() then return end
 if not self.restorePending and next(rows) then
  local enabled,cfg=wanted()
  local valid=enabled and owner and rawequal(owner.profile,M.profile) and rawequal(owner.cfg,cfg) and contextCurrent(owner)
  if valid then
   for name,row in pairs(rows) do local r=read(owner.api,name);if not r or r.n~=number(row.written) then valid=false;break end end
  end
  if valid then return end
  self.restorePending=true
 end
 if (self.retryCount or 0)>=3 then return end
 self.retryCount=(self.retryCount or 0)+1;self:Restore()
end
