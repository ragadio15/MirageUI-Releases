local _,M=...
-- Private literal reference data. Never source authority, executable text or history.
local R={};M.References=R;local S=M.Safety
local reason="Reference data is unsupported or invalid; original content was preserved."
R.reason=reason
function R:Empty() return {schema=1,builds={},strategies={}} end
local function plain(value)
 if not S:Readable(value) or type(value)~="table" then return false end
 local ok,meta=pcall(getmetatable,value)
 return ok and S:Readable(meta) and meta==nil
end
local function field(value,key)
 if not plain(value) then return nil,false end
 local ok,result=pcall(rawget,value,key)
 if not ok then return nil,false end
 return result,S:Readable(result)
end
local function integer(value,min,max) return S:Number(value) and value%1==0 and value>=min and value<=max end
function R:Text(value,limit,body,allowEmpty)
 if not S:Text(value) or #value>limit then return false end
 local i,lines,content=1,0,false
 while i<=#value do
  local a=value:byte(i);local cp,size
  if a<128 then cp,size=a,1
  elseif a>=194 and a<=223 then cp,size=a-192,2
  elseif a>=224 and a<=239 then cp,size=a-224,3
  elseif a>=240 and a<=244 then cp,size=a-240,4
  else return false end
  if i+size-1>#value then return false end
  for j=1,size-1 do local b=value:byte(i+j);if b<128 or b>191 then return false end;cp=cp*64+b-128 end
  if size==2 and cp<128 or size==3 and cp<2048 or size==4 and cp<65536 or cp>1114111 or cp>=55296 and cp<=57343 then return false end
  if cp==124 or cp<32 and not (body and cp==10) or cp>=127 and cp<=159 or cp==8232 or cp==8233 then return false end
  if cp==10 then lines=lines+1;if lines>32 then return false end end
  local whitespace=cp==32 or cp==10 or cp==160 or cp==5760 or cp>=8192 and cp<=8202 or cp==8239 or cp==8287 or cp==12288
  if not whitespace then content=true end
  i=i+size
 end
 return allowEmpty or content
end
local function keys(value,allowed,seen,maximum)
 if not plain(value) or seen[value] then return false end
 seen[value]=true;local key,count=nil,0
 while true do
  local ok,k=pcall(next,value,key)
  if not ok or not S:Readable(k) then return false end
  if k==nil then break end
  count=count+1;if count>maximum or not allowed[k] then return false end
  key=k
 end
 return plain(value)
end
local function client(value,seen)
 if not keys(value,{family=true,build=true,interface=true},seen,3) then return nil end
 local family,fs=field(value,"family");local build,bs=field(value,"build");local interface,is=field(value,"interface")
 if not fs or not bs or not is or (family~="Midnight" and family~="Forever") or not R:Text(build,32,false,false) or not integer(interface,1,2147483647) then return nil end
 return {family=family,build=build,interface=interface}
end
function R:CreatedClient()
 local c=M.Client
 if not c then return nil,reason end
 local result=client({family=c.family,build=c.build,interface=c.interface},{})
 if not result or c~=M.Client or c.family~=result.family or c.build~=result.build or c.interface~=result.interface then return nil,reason end
 return result
end
function R:Validate(value)
 if not S:Readable(value) then return nil,reason end
 if value==nil then return self:Empty() end
 local seen={}
 if not keys(value,{schema=true,builds=true,strategies=true},seen,3) then return nil,reason end
 local schema,known=field(value,"schema");if not known or schema~=1 then return nil,reason end
 local result=self:Empty();local total=0
 for _,kind in ipairs({"builds","strategies"}) do
  local list,access=field(value,kind)
  if not access or not plain(list) or seen[list] then return nil,reason end
  seen[list]=true;local count,key=0,nil
  while true do
   local ok,k=pcall(next,list,key)
   if not ok or not S:Readable(k) then return nil,reason end
   if k==nil then break end
   count=count+1;if count>8 or not integer(k,1,8) then return nil,reason end
   key=k
  end
  local ids={}
  for i=1,count do
   local record,rs=field(list,i)
   if not rs or not keys(record,{id=true,name=true,text=true,source=true,createdClient=true},seen,5) then return nil,reason end
   local id,a=field(record,"id");local name,b=field(record,"name");local text,c=field(record,"text");local source,d=field(record,"source");local origin,e=field(record,"createdClient")
   if not a or not b or not c or not d or not e or not integer(id,1,8) or ids[id] then return nil,reason end
   if source==nil then source="" end
   if not self:Text(name,48,false,false) or not self:Text(text,1024,true,false) or not self:Text(source,96,false,true) then return nil,reason end
   local created=client(origin,seen);if not created then return nil,reason end
   total=total+#name+#text+#source;if total>8192 then return nil,reason end
   ids[id]=true;result[kind][i]={id=id,name=name,text=text,source=source,createdClient=created}
  end
  if not plain(list) then return nil,reason end
 end
 if not plain(value) then return nil,reason end
 return result
end
function R:Profile(profile)
 if not S:Readable(profile) then return nil,reason end
 if profile==nil then return self:Empty() end
 local value,ok=field(profile,"preparationReferences")
 if not ok then return nil,reason end
 return self:Validate(value)
end
-- Bounded raw SavedVariables comparison only. No native/readability callbacks run
-- after this guard; opaque other-family data is never traversed or interpreted.
local function capture(value,expected,nodes)
 if type(expected)~="table" then return value==expected end
 if type(value)~="table" or getmetatable(value)~=nil then return false end
 local node={object=value,fields={},count=0};nodes[#nodes+1]=node
 for key,item in pairs(expected) do
  local actual=rawget(value,key)
  -- The only optional scalar is source; its absent form is not an empty string
  -- in the raw snapshot even though the validated copy canonicalizes it.
  if not (key=="source" and actual==nil and item=="") and not capture(actual,item,nodes) then return false end
  node.fields[#node.fields+1]={key=key,value=actual}
 end
 for key in next,value do
  if rawget(expected,key)==nil then return false end
  node.count=node.count+1;if node.count>#node.fields then return false end
 end
 return true
end
function R:SavedPreflight(account,character,family)
 local chains,nodes={},{}
 local function remember(object,key,value) chains[#chains+1]={object=object,key=key,value=value} end
 local function guard()
  local ok,same=pcall(function()
   for _,entry in ipairs(chains) do
    if type(entry.object)~="table" or getmetatable(entry.object)~=nil or rawget(entry.object,entry.key)~=entry.value then return false end
   end
   for _,node in ipairs(nodes) do
    if getmetatable(node.object)~=nil then return false end
    local count=0;for _ in next,node.object do count=count+1;if count>node.count then return false end end
    if count~=node.count then return false end
    for _,entry in ipairs(node.fields) do if rawget(node.object,entry.key)~=entry.value then return false end end
   end
   return true
  end)
  return ok and same==true
 end
 for _,root in ipairs({{account},{character}}) do
  local value=root[1]
  if not S:Readable(value) then return false,reason end
  if value~=nil then
   local clients,ok=field(value,"clients");if not ok then return false,reason end;remember(value,"clients",clients)
   if clients~=nil then
    local branch,known=field(clients,family);if not known then return false,reason end;remember(clients,family,branch)
    if branch~=nil then
     local profile,present=field(branch,"profile");if not present then return false,reason end;remember(branch,"profile",profile)
     if profile~=nil then
      local references,readable=field(profile,"preparationReferences");if not readable then return false,reason end
      remember(profile,"preparationReferences",references)
      local valid=self:Validate(references);if not valid then return false,reason end
      if references~=nil then
       local ok,captured=pcall(capture,references,valid,nodes);if not ok or captured~=true then return false,reason end
      end
     end
    end
   end
  end
 end
 if not guard() then return false,reason end
 return true,nil,guard
end
