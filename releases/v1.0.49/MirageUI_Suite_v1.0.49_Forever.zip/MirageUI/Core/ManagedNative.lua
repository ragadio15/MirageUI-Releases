local _,M=...
-- Original, explicit-consent native display leases. This is NOT a blanket
-- unregister/hide loop. No Blizzard scripts, events, bindings or action slots
-- are replaced. Reparent/geometry writes happen outside combat only.
M.ManagedNative={rows={},status={},maxRows=40}
local N,S=M.ManagedNative,M.Safety
local function delegated(name,frame)
 if name=="BagsBar" or name=="MicroMenuContainer" or name=="MicroMenu" then return true end
 if not S:Readable(frame) then return true end
 if frame==nil then return false end
 for _,key in ipairs({"BagsBar","MicroMenuContainer","MicroMenu"}) do
  local native=_G[key]
  if S:Readable(native) and native~=nil and frame==native then return true end
 end
 return false
end
local function editorState()
    if M.Elements and M.Elements.NativeEditorState then return M.Elements:NativeEditorState() end
    local f=_G.EditModeManagerFrame
    if not S:Readable(f) then return "UNKNOWN" end
    if f==nil then return "CLOSED" end
    local shown,known=S:Public(S:Field(f,"IsShown"),"boolean",f)
    if known~="KNOWN" then return "UNKNOWN" end
    return shown and "OPEN" or "CLOSED"
end
local actionLayoutValidator,layoutValidatorCurrent
local nativeEditDebt=setmetatable({},{__mode="k"})
-- Ordinary-unit release/admission observations are request-bound. Other lease
-- families retain their existing policy. These receipts are not native pixels,
-- atomic engine ownership, or a query of the private state-driver registry.
local unitNames={player="PlayerFrame",target="TargetFrame",focus="FocusFrame",pet="PetFrame"}
for i=1,5 do unitNames["boss"..i]="Boss"..i.."TargetFrame" end
local unitForName={};for unit,name in pairs(unitNames) do unitForName[name]=unit end
local unitEpoch,unitWriting,releaseRecords={},{},setmetatable({},{__mode="k"})
local observedRoots,releaseNotifications={},{}
-- Warm group cleanup debt is private and is retired before callback-bearing
-- work. It is not a new admission policy or a native visibility receipt.
local groupRestoreDebt,groupRestoreWriting,groupGateWriting={},{},{}
local groupAcquireWriting={}
local groupDispatchDebt={}
local groupAcquireCancelled={}
-- Only a request which attempted retirement may recognize its recovery program.
-- Retained across completed handback so a reused gate requires fresh rearming.
local groupRecoveryPolicies={}
local groupGateCustody={}
local groupRoots={PartyFrame=true,CompactRaidFrameContainer=true}
local function groupDispatchForRow(row)
    if not row then return nil end
    for name,debt in pairs(groupDispatchDebt) do
        if rawequal(row,debt.row) or (type(row)=="table" and
            (rawget(row,"name")==name or rawequal(rawget(row,"frame"),debt.frame))) then return name end
    end
end
local function queueUnitBoundary(name)
    local unit=unitForName[name]
    if unit then releaseNotifications[unit]={unit=unit,root=rawget(_G,name)} end
end
local treeUsable,guardedTree
local restoreArtSource
local groupRestoreSource
local function pack(...) return {n=select("#",...),...} end
local function routeCurrent(binding)
    for _,r in ipairs(binding.route) do
        if not rawequal(rawget(r.object,binding.key),r.value) or not rawequal(getmetatable(r.object),r.meta)
            or (r.meta and not rawequal(rawget(r.meta,"__index"),r.index)) then return false end
    end
    return true
end
local function guardCurrent(g)
    if not g then return true end
    if g.retired or g.malformed or not rawequal(rawget(M,"ManagedNative"),N) or not rawequal(rawget(M,"Safety"),S)
        or not rawequal(rawget(M,"profile"),g.profile) or not rawequal(rawget(N,"rows"),g.rows) or not rawequal(getmetatable(g.rows),g.rowsMeta)
        or not rawequal(rawget(g.rows,g.name),g.row) or not rawequal(rawget(_G,g.name),g.namedRoot)
        or (g.row and not rawequal(rawget(g.row,"gate"),g.gate))
        or unitEpoch[g.name]~=g.epoch or (g.row and not rawequal(rawget(g.row,"frame"),g.root))
        or not rawequal(rawget(S,"InCombat"),g.combat) or not rawequal(rawget(S,"Readable"),g.readable)
        or not rawequal(rawget(_G,"InCombatLockdown"),g.nativeCombat) then return false end
    for key,method in pairs(g.safetyMethods) do if not rawequal(rawget(S,key),method) then return false end end
    for _,key in ipairs({"issecretvalue","canaccessvalue","canaccesstable"}) do if not rawequal(rawget(_G,key),g.globals[key]) then return false end end
    if g.row and g.original then
        for key,value in pairs(g.original) do if key~="pointsSnapshot" and not rawequal(rawget(g.row,key),value) then return false end end
        if g.original.pointsSnapshot then
            local points=rawget(g.row,"originalPoints")
            if type(points)~="table" or #points~=#g.original.pointsSnapshot then return false end
            for i,p in ipairs(g.original.pointsSnapshot) do
                local actual=rawget(points,i);if type(actual)~="table" then return false end
                for j=1,5 do if not rawequal(rawget(actual,j),p[j]) then return false end end
            end
        end
    end
    if g.artRecord and (not rawequal(rawget(g.artRecord,"object"),g.artObject) or rawget(g.artRecord,"original")~=g.artOriginal
        or not rawequal(rawget(g.row,"art"),g.artMap) or not rawequal(rawget(g.artMap,g.artObject),g.artRecord)) then return false end
    if g.artExpected then
        for _,key in ipairs({"written","attempt","uncertain","displaced"}) do
            if not rawequal(rawget(g.artRecord,key),g.artExpected[key]) then return false end
        end
    end
    for _,binding in ipairs(g.bindings) do if not routeCurrent(binding) then return false end end
    if g.owner then local ok,value=pcall(g.owner);if not ok or value~=true then return false end end
    return true
end
local function originalSeal(row)
    if not row then return nil end
    local record={originalParent=row.originalParent,originalPoints=row.originalPoints,originalScale=row.originalScale,
        originalWidth=row.originalWidth,originalHeight=row.originalHeight}
    if type(row.originalPoints)=="table" and getmetatable(row.originalPoints)==nil and #row.originalPoints<=8 then
        record.pointsSnapshot={}
        for i=1,#row.originalPoints do
            local point=rawget(row.originalPoints,i)
            if type(point)~="table" or getmetatable(point)~=nil then return nil end
            record.pointsSnapshot[i]={rawget(point,1),rawget(point,2),rawget(point,3),rawget(point,4),rawget(point,5)}
        end
    elseif row.originalPoints~=nil then return nil end
    return record
end
local function newGuard(name,root,row,owner)
    unitEpoch[name]=(unitEpoch[name] or 0)+1
    local originals=originalSeal(row)
    return {malformed=row and not originals,name=name,root=root,namedRoot=rawget(_G,name),row=row,gate=row and row.gate,owner=owner,rows=N.rows,rowsMeta=getmetatable(N.rows),profile=M.profile,
        epoch=unitEpoch[name],original=originals,bindings={},combat=S.InCombat,readable=S.Readable,nativeCombat=InCombatLockdown,
        safetyMethods={Frame=S.Frame,Public=S.Public,Text=S.Text,Number=S.Number},
        globals={issecretvalue=issecretvalue,canaccessvalue=canaccessvalue,canaccesstable=canaccesstable}}
end
local function bind(g,object,key)
    if not guardCurrent(g) then return nil end
    local ok,fn=pcall(function() return object[key] end)
    if not ok or type(fn)~="function" or not guardCurrent(g) then return nil end
    for _,known in ipairs(g.bindings) do
        if rawequal(known.object,object) and known.key==key then return rawequal(known.fn,fn) and known or nil end
    end
    if #g.bindings>=128 then return nil end
    local b={object=object,key=key,fn=fn,route={},complete=false};local node,seen=object,{}
    for _=1,8 do
        if type(node)~="table" or seen[node] then break end
        seen[node]=true;local value,meta=rawget(node,key),getmetatable(node)
        if meta~=nil and type(meta)~="table" then break end
        local index=meta and rawget(meta,"__index")
        b.route[#b.route+1]={object=node,value=value,meta=meta,index=index}
        if value~=nil then b.complete=rawequal(value,fn);break end
        if type(index)~="table" then break end
        node=index
    end
    if not guardCurrent(g) or not routeCurrent(b) then return nil end
    g.bindings[#g.bindings+1]=b;return b
end
local function opaqueRoutesCurrent(g)
    for _,binding in ipairs(g.bindings) do
        if not binding.complete then
            local ok,fn=pcall(function() return binding.object[binding.key] end)
            if not ok or not rawequal(fn,binding.fn) or not guardCurrent(g) then return false end
        end
    end
    return true
end
local function guardedCall(g,object,key,write,...)
    local base=write and M.Rework and M.Rework.NativeMethod and M.Rework.NativeMethod(object,key)
    if not g then return pcall(base or object[key],object,...) end
    local b=bind(g,object,key);if not b then return false end
    if write then
        if not guardedTree(g,object) or not guardCurrent(g) or not opaqueRoutesCurrent(g) then return false end
        local ok,combat=pcall(g.combat,S)
        if not ok or combat~=false or not guardCurrent(g) then return false end
    end
    local result=pack(pcall(base or b.fn,object,...))
    if not guardCurrent(g) then return false end
    return unpack(result,1,result.n)
end
local function guardedGlobal(g,key,target,...)
    if not g then return pcall(_G[key],target,...) end
    local b=bind(g,_G,key);if not b or not guardedTree(g,target) or not guardCurrent(g) or not opaqueRoutesCurrent(g) then return false end
    local ok,combat=pcall(g.combat,S)
    if not ok or combat~=false or not guardCurrent(g) then return false end
    local result=pack(pcall(b.fn,target,...))
    if not guardCurrent(g) then return false end
    return unpack(result,1,result.n)
end
local function qualified(g,value,kind)
    local ok,read=pcall(S.Readable,S,value)
    if not ok or read~=true or not guardCurrent(g) then return false end
    if kind=="number" then return type(value)=="number" and value==value and value~=math.huge and value~=-math.huge end
    return kind==nil or type(value)==kind
end
local function publicRead(g,object,key,kind,...)
    if not g then return S:Public(object[key],kind,object,...) end
    local ok,v=guardedCall(g,object,key,false,...)
    if ok and qualified(g,v,kind) then return v,"KNOWN" end
    return nil,"UNKNOWN"
end
guardedTree=function(g,object)
    local node,seen=object,{}
    for _=1,32 do
        if node==nil then return true end
        if not qualified(g,node) or (type(node)~="table" and type(node)~="userdata") or seen[node] then return false end
        seen[node]=true
        local forbidden,fs=publicRead(g,node,"IsForbidden","boolean")
        local protected,ps=publicRead(g,node,"IsProtected","boolean")
        if fs~="KNOWN" or forbidden~=false or ps~="KNOWN" or type(protected)~="boolean" then return false end
        local parent,status=publicRead(g,node,"GetParent",nil)
        if status~="KNOWN" or not guardCurrent(g) then return false end
        node=parent
    end
    return node==nil and guardCurrent(g)
end
local function replacementReceipt(unit)
    local mod=M.modules.UnitFrames;local view=mod and mod.views and mod.views[unit]
    local T=M.UnitTypography
    if type(T)~="table" or type(T.NativeReplacementReceipt)~="function" or type(T.Current)~="function"
        or not M:IsModuleActive("UnitFrames") or not view or not view.frame or view.healthOK~=true or mod.maintenanceFailed then return nil end
    local method,current=T.NativeReplacementReceipt,T.Current
    local ok,receipt=pcall(method,T,view)
    if not ok or not receipt or not rawequal(M.UnitTypography,T) or not rawequal(T.NativeReplacementReceipt,method) or not rawequal(T.Current,current) then return nil end
    local good,live=pcall(current,T,receipt)
    if not good or live~=true then return nil end
    return receipt,T,view,method,current
end
local function admissionOwner(unit,receipt)
    local found,T,view,method,current=replacementReceipt(unit)
    if not rawequal(found,receipt) or not receipt then return nil end
    local modules,state,client,profile=M.modules,M.state,M.Client,M.profile
    local mod=modules.UnitFrames;local configs=profile.modules;local cfg=configs.UnitFrames
    local function active()
        return rawequal(rawget(M,"modules"),modules) and rawequal(rawget(modules,"UnitFrames"),mod)
            and rawequal(rawget(M,"state"),state) and rawequal(rawget(M,"Client"),client) and rawequal(rawget(M,"profile"),profile)
            and rawequal(rawget(profile,"modules"),configs) and rawequal(rawget(configs,"UnitFrames"),cfg)
            and rawget(state,"initialized")==true and rawget(state,"world")==true and rawget(client,"allowed")==true
            and rawget(profile,"enabled")==true and not rawget(state,"safe") and rawget(mod,"initialized")==true
            and not rawget(mod,"quarantined") and not rawget(mod,"suspended") and rawget(cfg,"enabled")==true
            and type(rawget(mod,"views"))=="table" and rawequal(rawget(rawget(mod,"views"),unit),view)
            and rawget(view,"healthOK")==true and not rawget(mod,"maintenanceFailed")
    end
    return function()
        if not rawequal(rawget(M,"UnitTypography"),T) or not rawequal(rawget(T,"Current"),current)
            or not rawequal(rawget(T,"NativeReplacementReceipt"),method) or not active() then return false end
        local ok,live=pcall(current,T,receipt)
        return ok and live==true and active()
    end
end
local actions={"MainActionBar","MultiBarBottomLeft","MultiBarBottomRight","MultiBarRight","MultiBarLeft","MultiBar5","MultiBar6","MultiBar7"}
local controls={"PetActionBar","StanceBar","BagsBar","MicroMenuContainer","MainStatusTrackingBarContainer","SecondaryStatusTrackingBarContainer"}
N.actionNames=actions
local stateProgram=[=[
self:SetAttribute("mirage-state",newstate)
if newstate == "show" or self:GetAttribute("mirage-held") or self:GetAttribute("mirage-emergency") then
    self:Show()
else
    self:Hide()
end
]=]
-- Group recovery retires this gate's future hiding capability independently of
-- the public emergency latch. It cannot cancel an already-entered secure call,
-- authenticate arbitrary host methods, or contain another writer's program.
local groupRecoveryProgram=[=[
self:SetAttribute("mirage-state",newstate)
self:Show()
]=]
local function retireGroupProgram(name,row,g)
    local gate=rawget(row,"gate");local policy=groupRecoveryPolicies[name]
    local custody=groupGateCustody[name]
    if not custody or not rawequal(custody.row,row) or not rawequal(custody.gate,gate) then return false end
    if policy and (not rawequal(policy.row,row) or not rawequal(policy.gate,gate)) then return false end
    local program,known=publicRead(g,gate,"GetAttribute","string","_onstate-mirage")
    if known~="KNOWN" or not guardCurrent(g) then return false end
    if program==groupRecoveryProgram then
        -- Text equality alone does not adopt a foreign show-only program.
        if not policy then return false end
        policy.phase="retired";policy.released=false;return true
    end
    if program~=stateProgram then return false end
    if not policy then
        policy={row=row,gate=gate,phase="retiring",released=false};groupRecoveryPolicies[name]=policy
    else policy.phase="retiring";policy.released=false end
    -- Keep the attempt even on a throw after the setter's side effect. A later
    -- guarded retry may recognize only this same row/gate and exact program.
    if not guardedCall(g,gate,"SetAttribute",true,"_onstate-mirage",groupRecoveryProgram)
        or publicRead(g,gate,"GetAttribute","string","_onstate-mirage")~=groupRecoveryProgram
        or not guardCurrent(g) then return false end
    policy.phase="retired";return true
end
local special="[vehicleui] show; [overridebar] show; [possessbar] show; [petbattle] show; "
local actionDriver=special.."[combat] show; hide"
local replaceDriver=special.."hide"
N.actionDriver=actionDriver;N.replaceDriver=replaceDriver
local function points(f,g)
    local count,status=publicRead(g,f,"GetNumPoints","number")
    if status~="KNOWN" or count<0 or count>8 or count%1~=0 then return nil end
    local list={}
    for i=1,count do
        local ok,a,b,c,x,y=guardedCall(g,f,"GetPoint",false,i)
        if not ok or not S:Text(a) or not S:Readable(b) or not S:Text(c) or not S:Number(x) or not S:Number(y) then return nil end
        list[i]={a,b,c,x,y}
    end
    return list
end
-- Native widgets round authored geometry to single precision. Only numeric
-- readback uses a small tolerance; frame identities and anchor names stay exact.
local function near(a,b,epsilon)
    return S:Number(a) and S:Number(b) and math.abs(a-b)<=(epsilon or .001)
end
local function same(a,b)
    if not a or not b or #a~=#b then return false end
    for i=1,#a do for j=1,5 do
        if j<=3 then if not rawequal(a[i][j],b[i][j]) then return false end
        elseif not near(a[i][j],b[i][j]) then return false end
    end end
    return true
end
local function frameObject(value)
    if not S:Readable(value) or (type(value)~="table" and type(value)~="userdata") then return false end
    local ok,usable=pcall(function() return type(value.GetParent)=="function" and S:Frame(value,false) end)
    return ok and usable==true
end
local function parentOf(f,g)
    local parent,status=publicRead(g,f,"GetParent",nil)
    if status=="KNOWN" and frameObject(parent) and guardCurrent(g) then return parent end
end
local function observePoints(row,g)
    local current=points(row.frame,g)
    if not guardCurrent(g) then return nil end
    if current then
        if row.pointsAttempt and same(current,row.pointsAttempt) then row.writtenPoints=current end
        row.pointsAttempt=nil
    end
    return current
end
local function setPoints(row,list,g,requestCurrent)
    if not guardCurrent(g) or (requestCurrent and not requestCurrent()) then return false end
    row.pointsAttempt={}
    local ok=guardedCall(g,row.frame,"ClearAllPoints",true)
    if requestCurrent and not requestCurrent() then return false end
    local current=observePoints(row,g)
    if not guardCurrent(g) or not ok or not same(current,{}) then return false end
    local prefix={}
    for i,pt in ipairs(list) do
        if requestCurrent and not requestCurrent() then return false end
        prefix[i]=pt;row.pointsAttempt=prefix
        ok=guardedCall(g,row.frame,"SetPoint",true,unpack(pt,1,5))
        if requestCurrent and not requestCurrent() then return false end
        current=observePoints(row,g)
        if not guardCurrent(g) or not ok or not same(current,prefix) then return false end
    end
    return true
end
local function sizeOf(f,g)
    local w,ws=publicRead(g,f,"GetWidth","number");local h,hs=publicRead(g,f,"GetHeight","number")
    if ws=="KNOWN" and hs=="KNOWN" and w>0 and h>0 and guardCurrent(g) then return {w,h} end
end
local function sameSize(a,b) return a and b and near(a[1],b[1]) and near(a[2],b[2]) end
local function observeScale(row,g)
    local v,status=publicRead(g,row.frame,"GetScale","number")
    if not guardCurrent(g) then return nil end
    if status~="KNOWN" or v<=0 then return nil end
    if row.scaleAttempt and near(v,row.scaleAttempt,.00001) then row.writtenScale=v end
    row.scaleAttempt=nil;return v
end
local function observeSize(row,g)
    local v=sizeOf(row.frame,g)
    if not guardCurrent(g) then return nil end
    if v then
        -- Only a throwing setter may own mixed before/intended dimensions;
        -- a successful but divergent readback belongs to a newer writer.
        local partial=row.sizePartialAllowed and row.sizeBefore and row.sizeAttempt
            and (v[1]==row.sizeBefore[1] or v[1]==row.sizeAttempt[1])
            and (v[2]==row.sizeBefore[2] or v[2]==row.sizeAttempt[2])
        if sameSize(v,row.sizeAttempt) or partial then row.sizeWritten=v end
        row.sizeAttempt=nil;row.sizeBefore=nil;row.sizePartialAllowed=nil
    end
    return v
end
treeUsable=function(frame)
    if not frameObject(frame) then return false end
    local node,seen=frame,{}
    for depth=1,32 do
        if not node then return true end
        if seen[node] or not frameObject(node) or type(node.GetParent)~="function" then return false end
        seen[node]=true
        local ok,nextParent=pcall(node.GetParent,node)
        if not ok or not S:Readable(nextParent) or (nextParent~=nil and not frameObject(nextParent)) then return false end
        node=nextParent
    end
    return node==nil
end
function N:Usable(frame)
    if S:InCombat() or not treeUsable(frame) then return false end
    local parent=parentOf(frame)
    return parent~=nil,parent
end
function N:Replacement(unit)
    return replacementReceipt(unit)~=nil
end
local function usableGroupView(view)
    return view and view.owner=="PartyRaid" and view.frame and S:Frame(view.frame,false)
end
local function groupSurface(surface,frame,id)
    return S:Readable(surface) and type(surface)=="table"
        and S:Text(surface.id) and surface.id==id and S:Readable(surface.frame) and rawequal(surface.frame,frame)
        and rawequal(M.surfaces[id],surface) and rawequal(M.Policy.owners[id],surface)
end
local function groupRead(frame,key,...)
    local ok,value,called=pcall(function(...)
        local method=frame[key]
        if type(method)~="function" then return nil,false end
        return method(frame,...),true
    end,...)
    if not ok or not called or not S:Readable(value) then return nil,false end
    return value,true
end
local function groupSlots(values,count)
    -- Reuse table-access eligibility and preserve unknown/restricted as refusal.
    local _,status=S:FieldAccess(values,1)
    if status~="KNOWN" then return false end
    local ok,exact=pcall(function()
        local found=0
        for key in next,values do
            if not S:Number(key) or key%1~=0 or key<1 or key>count then return false end
            found=found+1;if found>count then return false end
        end
        return found==count
    end)
    return ok and exact==true
end
local function groupRaidToken(unit)
    if not S:Text(unit) then return false end
    local n=unit:match("^raid([1-9]%d?)$")
    return n and tonumber(n)<=40
end
-- Private observations survive the caller's callback-bearing preflight. The
-- public token carries no editable authority. Current checks use owned tables
-- and source generations only; they do not repeat native getters or claim
-- atomic engine custody, future secure-driver readiness or visible input proof.
local groupReceipts=setmetatable({},{__mode="k"})
local groupDisplay=M.Display
local groupGeneration=groupDisplay and rawget(groupDisplay,"GroupGeneration")
local viewGeneration=groupDisplay and rawget(groupDisplay,"ViewGeneration")
local groupNative,groupFixed=M.NativeGroups,M.modules.PartyRaid
local nativeLifetime=groupNative and rawget(groupNative,"CaptureLifetime")
local nativeLifetimeCurrent=groupNative and rawget(groupNative,"IsLifetimeCurrent")
local fixedLifetime=groupFixed and rawget(groupFixed,"CaptureLifetime")
local fixedLifetimeCurrent=groupFixed and rawget(groupFixed,"IsLifetimeCurrent")
local function plain(value) return type(value)=="table" and getmetatable(value)==nil end
local function exactSlots(values,count)
    if not plain(values) then return false end
    local found=0
    for key in next,values do
        if type(key)~="number" or key%1~=0 or key<1 or key>count then return false end
        found=found+1;if found>count then return false end
    end
    return found==count
end
local function groupStateCurrent(r)
    if not r or not rawequal(rawget(M,"profile"),r.profile) or not rawequal(rawget(M,"modules"),r.modules)
        or not rawequal(rawget(r.modules,"PartyRaid"),r.group) or not rawequal(rawget(M,"state"),r.state)
        or not rawequal(rawget(M,"Client"),r.client) or not rawequal(rawget(M,"surfaces"),r.surfaces)
        or not rawequal(rawget(M,"Policy"),r.policy) or not rawequal(rawget(r.policy,"owners"),r.owners)
        or not rawequal(rawget(r.profile,"modules"),r.configs) or not rawequal(rawget(r.configs,"PartyRaid"),r.config)
        or not rawget(r.state,"initialized") or not rawget(r.state,"world") or rawget(r.state,"safe")
        or rawget(r.client,"allowed")~=true or not rawget(r.profile,"enabled")
        or rawget(r.config,"enabled")~=true or not rawget(r.group,"initialized")
        or rawget(r.group,"quarantined") or rawget(r.group,"suspended") or rawget(r.group,"pendingDisable")
        or rawget(r.group,"maintenanceFailed") or rawget(r.group,"cleanupPending")
        or not rawequal(rawget(r.group,"views"),r.fixedViews)
        or not rawequal(rawget(M,"NativeGroups"),r.native)
        or not rawequal(rawget(M,"Display"),groupDisplay) or rawget(groupDisplay,"GroupGeneration")~=groupGeneration
        or rawget(groupDisplay,"ViewGeneration")~=viewGeneration
        or not rawequal(groupGeneration(groupDisplay,r.kind),r.generation)
        or not rawequal(r.native,groupNative) or not rawequal(r.group,groupFixed)
        or rawget(groupNative,"CaptureLifetime")~=nativeLifetime or rawget(groupNative,"IsLifetimeCurrent")~=nativeLifetimeCurrent
        or rawget(groupFixed,"CaptureLifetime")~=fixedLifetime or rawget(groupFixed,"IsLifetimeCurrent")~=fixedLifetimeCurrent
        or nativeLifetimeCurrent(groupNative,r.nativeLifetime)~=true or fixedLifetimeCurrent(groupFixed,r.fixedLifetime)~=true then return false end
    if r.headerMode then
        if rawget(r.native,"active")~=true or rawget(r.native,"ready")~=true or rawget(r.native,"failed")
            or rawget(r.native,"cleanupPending") or not rawequal(rawget(r.native,"headers"),r.headers)
            or not rawequal(rawget(r.native,"views"),r.views) or not exactSlots(r.headers,8) or not exactSlots(r.views,40) then return false end
        for i=1,8 do
            local h=r.headerRows[i]
            if not rawequal(rawget(r.headers,i),h.row) or not rawequal(rawget(h.row,"frame"),h.frame)
                or not rawequal(rawget(h.row,"surface"),h.surface) or not rawequal(rawget(h.row,"children"),h.children)
                or not exactSlots(h.children,5) then return false end
        end
    elseif r.kind=="raid" and r.native and rawget(r.native,"active") then return false end
    for i=1,#r.entries do
        local e=r.entries[i];local v=e.view;local surface=e.surface
        if not rawequal(viewGeneration(groupDisplay,v),e.generation)
            or not rawequal(rawget(v,"frame"),e.frame) or not rawequal(rawget(v,"health"),e.health)
            or not rawequal(rawget(v,"power"),e.power) or rawget(v,"unit")~=e.unit
            or rawget(v,"owner")~=e.owner or rawget(v,"healthOK")~=e.healthOK
            or not rawequal(rawget(surface,"frame"),e.surfaceFrame) or rawget(surface,"id")~=e.id
            or not rawequal(rawget(r.surfaces,e.id),surface) or not rawequal(rawget(r.owners,e.id),surface) then return false end
        if r.headerMode then
            if not rawequal(rawget(e.children,e.slot),v) or not rawequal(rawget(r.views,i),v)
                or rawget(v,"assignmentStatus")~=e.assignment or rawget(v,"nativeGroup")~=e.groupIndex
                or rawget(v,"childKey")~=e.childKey then return false end
        elseif not rawequal(rawget(r.fixedViews,e.unit),v) or not rawequal(rawget(v,"surface"),surface) then return false end
    end
    return true
end
local function groupReceiptCurrent(token)
    local r=groupReceipts[token]
    if not r then return false end
    local ok,current=pcall(groupStateCurrent,r)
    return ok and current==true
end
local function captureGroupView(r,view,surface,children,slot,groupIndex)
    if not plain(view) or not plain(surface) then return false end
    local generation=viewGeneration(groupDisplay,view)
    if type(generation)~="table" then return false end
    r.entries[#r.entries+1]={view=view,generation=generation,frame=rawget(view,"frame"),health=rawget(view,"health"),power=rawget(view,"power"),
        unit=rawget(view,"unit"),owner=rawget(view,"owner"),healthOK=rawget(view,"healthOK"),surface=surface,
        surfaceFrame=rawget(surface,"frame"),id=rawget(surface,"id"),assignment=rawget(view,"assignmentStatus"),
        children=children,slot=slot,groupIndex=groupIndex,childKey=rawget(view,"childKey")}
    return true
end
local function observedGroupView(r,index,view,surface,children,slot,groupIndex)
    local entry=r.entries[index]
    return entry and rawequal(entry.view,view) and rawequal(entry.surface,surface)
        and rawequal(entry.children,children) and entry.slot==slot and entry.groupIndex==groupIndex
end
local function groupSnapshot(kind,profile,modules,group,native)
    local state,client,policy=M.state,M.Client,M.Policy
    local configs=profile and profile.modules;local config=configs and configs.PartyRaid
    if type(groupGeneration)~="function" or type(viewGeneration)~="function" or type(nativeLifetime)~="function" or type(nativeLifetimeCurrent)~="function"
        or type(fixedLifetime)~="function" or type(fixedLifetimeCurrent)~="function"
        or not plain(profile) or not plain(modules) or not plain(group)
        or not plain(native) or not plain(state) or not plain(client) or not plain(policy) or not plain(policy.owners)
        or not plain(M.surfaces) or not plain(configs) or not plain(config) or not plain(group.views) then return nil end
    local r={kind=kind,profile=profile,modules=modules,group=group,native=native,fixedViews=group.views,
        state=state,client=client,policy=policy,owners=policy.owners,surfaces=M.surfaces,configs=configs,config=config,
        generation=groupGeneration(groupDisplay,kind),nativeLifetime=nativeLifetime(groupNative),
        fixedLifetime=fixedLifetime(groupFixed),entries={}}
    -- Capture every owned reference before the first callback-bearing probe.
    -- A getter may not substitute a different frame and have it sealed after
    -- the old frame's parent/unit observations were already accepted.
    if kind=="raid" and rawget(native,"active")==true then
        r.headerMode=true;r.headers=rawget(native,"headers");r.views=rawget(native,"views");r.headerRows={}
        if not exactSlots(r.headers,8) or not exactSlots(r.views,40) then return nil end
        for i=1,8 do
            local row=rawget(r.headers,i)
            if not plain(row) then return nil end
            local frame,surface,children=rawget(row,"frame"),rawget(row,"surface"),rawget(row,"children")
            if not plain(surface) or not exactSlots(children,5) then return nil end
            r.headerRows[i]={row=row,frame=frame,surface=surface,children=children}
            for j=1,5 do
                local view=rawget(children,j)
                if not rawequal(rawget(r.views,(i-1)*5+j),view) or not captureGroupView(r,view,surface,children,j,i) then return nil end
            end
        end
    else
        for i=1,(kind=="party" and 4 or 40) do
            local view=rawget(r.fixedViews,kind..i)
            if not plain(view) or not captureGroupView(r,view,rawget(view,"surface")) then return nil end
        end
    end
    return r
end
local function issueGroupReceipt(r)
    local ok,current=pcall(groupStateCurrent,r)
    if not ok or not current then return false end
    local token={};groupReceipts[token]=r
    return true,token
end
function N:GroupReplacement(kind)
    if kind~="party" and kind~="raid" then return false end
    local profile,modules=M.profile,M.modules
    local group=modules.PartyRaid
    if not M:IsModuleActive("PartyRaid") or group.maintenanceFailed then return false end
    local native=M.NativeGroups
    local observed,receipt=pcall(groupSnapshot,kind,profile,modules,group,native)
    if not observed or not receipt then return false end
    local seen={}
    -- Sequential native observations plus a source-owned lifetime seal. This is
    -- not atomic engine input proof or authority for future secure transitions.
    if kind=="raid" and native and native.active then
        local headers,views=native.headers,native.views
        if not native.ready or native.failed or not groupSlots(headers,8) or not groupSlots(views,40) then return false end
        if not receipt.headerMode or not rawequal(receipt.headers,headers) or not rawequal(receipt.views,views) then return false end
        local seenUnits={}
        for i=1,8 do
            local row=headers[i]
            if not row or not S:Frame(row.frame,false) or not groupSlots(row.children,5)
                or not groupSurface(row.surface,row.frame,"PartyRaid.group"..i) then return false end
            local rootParent,parentOK=groupRead(row.frame,"GetParent")
            if not parentOK or not rawequal(rootParent,UIParent) then return false end
            for j=1,5 do
                local view=row.children[j]
                if not usableGroupView(view) or seen[view.frame] or not rawequal(views[(i-1)*5+j],view)
                    or view.nativeGroup~=i or view.childKey~="child"..j then return false end
                seen[view.frame]=true
                local parent,parentOK=groupRead(view.frame,"GetParent")
                local child,childOK=groupRead(row.frame,"GetAttribute","child"..j)
                local unit,unitOK=groupRead(view.frame,"GetAttribute","unit")
                if not parentOK or not childOK or not unitOK or not rawequal(parent,row.frame)
                    or not rawequal(child,view.frame) then return false end
                if view.assignmentStatus=="EMPTY" then
                    if unit~=nil or not S:Readable(view.unit) or view.unit~=nil then return false end
                elseif view.assignmentStatus~="KNOWN" or not groupRaidToken(unit)
                    or not S:Text(view.unit) or unit~=view.unit or view.healthOK~=true or seenUnits[unit] then return false end
                if unit~=nil then seenUnits[unit]=true end
                if not groupSurface(row.surface,row.frame,"PartyRaid.group"..i) then return false end
                if not observedGroupView(receipt,(i-1)*5+j,view,row.surface,row.children,j,i) then return false end
            end
        end
        return issueGroupReceipt(receipt)
    end
    local views=group.views
    if not views then return false end
    for i=1,(kind=="party" and 4 or 40) do
        local unit=kind..i;local view=views[unit]
        if not usableGroupView(view) or seen[view.frame] or view.healthOK~=true then return false end
        seen[view.frame]=true
        local assigned,known=groupRead(view.frame,"GetAttribute","unit")
        local parent,parentOK=groupRead(view.frame,"GetParent")
        if not parentOK or not rawequal(parent,UIParent) or not known or not S:Text(assigned) or assigned~=unit or not S:Text(view.unit) or view.unit~=unit
            or not groupSurface(view.surface,view.frame,"PartyRaid."..unit) or view.healthOK~=true then return false end
        if not observedGroupView(receipt,i,view,view.surface) then return false end
    end
    return issueGroupReceipt(receipt)
end
local function acquireLegacy(self,name,mode,module)
    if S:InCombat() or M.Native:Conflict() then return nil end
    local acquisitionProfile=M.profile
    local f=_G[name];local good,parent=self:Usable(f)
    if not good then self.status[name]="NATIVE_FALLBACK";return nil end
    local row=self.rows[name]
    local contextualMode=mode=="cooldowns" or mode=="controls"
    local editAcquisition=row and (nativeEditDebt[row]~=nil or row.editSuspended==true)
    local validator=editAcquisition and layoutValidatorCurrent()
    if editAcquisition then
        local ok,ready=false,false
        if validator then ok,ready=pcall(validator.editAcquire,validator.component,row,"begin") end
        if not ok or ready~=true then
            if self.status[name]~="NATIVE_EDIT_OWNER_CHANGED" then self.status[name]="NATIVE_EDIT_REACQUIRE_PENDING" end
            return nil
        end
    end
    local guardedMode=contextualMode or editAcquisition
    local function contextualCurrent()
        if M.profile~=acquisitionProfile or _G[name]~=f or self.rows[name]~=row
            or not M.Managed:Enabled() or not M:IsModuleActive(module) or M.Native:Conflict() or S:InCombat() then return false end
        if editAcquisition then
            if layoutValidatorCurrent()~=validator then return false end
            local ok,ready=pcall(validator.editAcquire,validator.component,row,"current")
            if not ok or ready~=true then return false end
        end
        return true
    end
    local function guardedMutation(object,key,...)
        if guardedMode and not contextualCurrent() then error("CONTEXT_HANDOFF_RETIRED") end
        object[key](object,...)
        if guardedMode and not contextualCurrent() then error("CONTEXT_HANDOFF_RETIRED") end
    end
    -- Geometry-only cooldown leases from an earlier configuration must retire
    -- before a secure visibility parent is introduced. Never nest it under a
    -- contextual fallback gate or reinterpret an active lease's original parent.
    if contextualMode then
        if M.ContextualNative and M.ContextualNative:Restore(name)~=true then self.status[name]="CONTEXT_HANDOFF_PENDING";return nil end
        if not contextualCurrent() then return nil end
        good,parent=self:Usable(f);if not good then return nil end
        if not contextualCurrent() then return nil end
        if row and row.active and row.mode~=mode then
            if not self:Restore(name,true) then return nil end
            if self.rows[name]~=row or M.profile~=acquisitionProfile or _G[name]~=f then return nil end
            good,parent=self:Usable(f);if not good then return nil end
        end
    end
    if row and row.frame~=f then
        if not self:Restore(name,true) then return nil end
        -- Named secure gates belong to MirageUI, not to the native root's
        -- lifetime. Reuse only after both old geometry and art were released.
        row={name=name,frame=f,mode=mode,module=module,gate=row.gate};self.rows[name]=row
    end
    if row and (row.failed or row.restorePending) then return nil end
    if row and row.active then
        local currentParent=parentOf(f)
        if not currentParent then self.status[name]="PARENT_UNAVAILABLE";return nil end
        if row.gate and currentParent~=row.gate then row.contested=true;self.status[name]="NEWER_OWNER";return nil end
        if guardedMode and not contextualCurrent() then return nil end
        local hover=M.ManagedActionHover
        if mode=="actions" and hover and (row.hoverMode or hover:Requested()) then
            local policyGate=row.gate
            if M.profile~=acquisitionProfile or self.rows[name]~=row or row.frame~=f or _G[name]~=f then return nil end
            local ok,prepared=pcall(hover.ConfigurePolicy,hover,row,stateProgram,actionDriver)
            if M.profile~=acquisitionProfile or self.rows[name]~=row or row.frame~=f or _G[name]~=f or row.gate~=policyGate then return nil end
            if not ok or prepared~=true then
                row.failed=true;local restored=self:Restore(name)
                self.status[name]=restored and "HOVER_POLICY_FAILED_NATIVE_RESTORED" or "RESTORE_RELOAD_REQUIRED";return nil
            end
        end
        return row
    end
    if row and row.contested then return nil end
    if not row then
        local n=0;for _ in pairs(self.rows) do n=n+1 end
        if n>=self.maxRows then self.status[name]="LEASE_LIMIT";return nil end
        row={name=name,frame=f,mode=mode,module=module};self.rows[name]=row
    end
    local original=points(f);local scale,ss=S:Public(f.GetScale,"number",f)
    if not original or ss~="KNOWN" or scale<=0 or type(f.SetParent)~="function" then self.status[name]="NATIVE_FALLBACK";return nil end
    row.originalParent=parent;row.originalPoints=original;row.originalScale=scale
    row.originalWidth=S:Public(f.GetWidth,"number",f);row.originalHeight=S:Public(f.GetHeight,"number",f)
    if mode=="adopt" then
        row.active=true;row.mode=mode
        if editAcquisition then
            local ok,ready=pcall(validator.editAcquire,validator.component,row,"complete")
            if not ok or ready~=true then row.failed=true;row.restorePending=true;return nil end
            nativeEditDebt[row]=nil
        end
        self.status[name]="ADOPTED_NATIVE";return row
    end
    local staged=pcall(function()
        if guardedMode and not contextualCurrent() then error("CONTEXT_HANDOFF_RETIRED") end
        if not row.gate then
            row.gate=CreateFrame("Frame","MirageManaged_"..name,parent,"SecureHandlerStateTemplate")
            if guardedMode then
                guardedMutation(row.gate,"EnableMouse",false)
                if row.gate.EnableKeyboard then guardedMutation(row.gate,"EnableKeyboard",false) end
                if row.gate.EnableMouseWheel then guardedMutation(row.gate,"EnableMouseWheel",false) end
            else S:Passive(row.gate) end
            guardedMutation(row.gate,"SetAllPoints",parent)
            guardedMutation(row.gate,"SetAttribute","_onstate-mirage",stateProgram)
        else
            guardedMutation(row.gate,"SetParent",parent);guardedMutation(row.gate,"ClearAllPoints");guardedMutation(row.gate,"SetAllPoints",parent)
        end
    end)
    if not staged then
        row.failed=true;self:Restore(name);self.status[name]="CONTEXT_GATE_PREPARATION_DEFERRED";return nil
    end
    -- Recovery belongs to the whole experience, not just the gates that existed
    -- when it was clicked. Native Edit Mode and late-loaded roots may reacquire.
    local emergency=self.recovery and S:Public(self.recovery.GetAttribute,"boolean",self.recovery,"mirage-emergency")==true
    local driver=(mode=="actions" or mode=="controls" or mode=="cooldowns") and actionDriver or mode=="replace" and replaceDriver or "show"
    -- Stage a visible parent first. Only the last commit grants hiding authority.
    local hoverPolicy=false;local policyGate=row.gate
    local function policyCurrent()
        return M.profile==acquisitionProfile and self.rows[name]==row and row.frame==f and _G[name]==f and row.gate==policyGate
    end
    local ok=pcall(function()
        guardedMutation(row.gate,"SetAttribute","mirage-held",false);guardedMutation(row.gate,"SetAttribute","mirage-emergency",emergency==true)
        guardedMutation(row.gate,"Show")
        row.active=true;row.parentAttempt=row.gate
        local hover=M.ManagedActionHover
        hoverPolicy=mode=="actions" and hover and (row.hoverMode or hover:Requested()) or false
        if hoverPolicy then
            if not policyCurrent() then error("HOVER_OWNER_CHANGED") end
            -- Reused gates may retain an older snippet. Stage the non-hiding
            -- program before reparenting can dispatch any native callback.
            policyGate:SetAttribute("_onstate-mirage",hover.program)
            if not policyCurrent() then error("HOVER_OWNER_CHANGED") end
        end
        guardedMutation(f,"SetParent",row.gate)
        if parentOf(f)~=row.gate then error("PARENT_WRITE_REJECTED") end
        if hoverPolicy and not policyCurrent() then error("HOVER_OWNER_CHANGED") end
        if type(RegisterStateDriver)~="function" or type(UnregisterStateDriver)~="function" then error("NO_SECURE_DRIVER") end
        if hoverPolicy then
            -- No legacy quiet registration may precede the opt-in reveal-only
            -- program. Its sole optional hiding writer is the group controller.
            if hover:ConfigurePolicy(row,stateProgram,actionDriver)~=true then error("HOVER_POLICY_UNAVAILABLE") end
            if not policyCurrent() then error("HOVER_OWNER_CHANGED") end
            driver=row.driver
        else
            if guardedMode and not contextualCurrent() then error("CONTEXT_HANDOFF_RETIRED") end
            RegisterStateDriver(row.gate,"mirage",driver)
            if guardedMode and not contextualCurrent() then error("CONTEXT_HANDOFF_RETIRED") end
        end
    end)
    if hoverPolicy and not policyCurrent() then return nil end
    if not ok then
        row.failed=true;local restored=self:Restore(name);self.status[name]=restored and "HANDOFF_FAILED_NATIVE_RESTORED" or "RESTORE_RELOAD_REQUIRED";return nil
    end
    row.active=true;row.parentAttempt=nil;row.mode=mode;row.driver=driver;row.held=nil;row.writtenPoints=nil
    if editAcquisition then
        local ok,ready=pcall(validator.editAcquire,validator.component,row,"complete")
        if not ok or ready~=true then row.failed=true;row.restorePending=true;self.status[name]="NATIVE_EDIT_REACQUIRE_PENDING";return nil end
        nativeEditDebt[row]=nil
    end
    self.status[name]="MANAGED_CANDIDATE"
    return row
end
-- Exact ordinary-unit acquisition. One per-native-root writer refuses nested
-- admission; mandatory controller retirement still invalidates the receipt.
local function acquireUnit(self,name,receipt)
    local unit=unitForName[name];local owner=unit and admissionOwner(unit,receipt)
    if not owner or unitWriting[name] then return nil end
    local f=rawget(_G,name);local row=self.rows[name]
    if not frameObject(f) or not rawequal(rawget(_G,name),f) or not owner() then return nil end
    if row and not rawequal(row.frame,f) then
        -- Old-root restoration is separate from permission to hide its successor.
        self:Restore(name,true);return nil
    end
    if row and (row.failed or row.restorePending or row.contested) then return nil end
    if not row then
        local count=0;for _ in pairs(self.rows) do count=count+1 end
        if count>=self.maxRows then return nil end
        row={name=name,frame=f,mode="replace",module="UnitFrames"};self.rows[name]=row
    end
    local g=newGuard(name,f,row,owner);unitWriting[name]=g
    local ok,result=pcall(function()
        if S:InCombat() or M.Native:Conflict() or not guardedTree(g,f) or not guardCurrent(g) then return nil end
        local parent=parentOf(f,g);if not parent or not guardCurrent(g) then return nil end
        if row.active then
            if not rawequal(parent,row.gate) then row.contested=true;self.status[name]="NEWER_OWNER";return nil end
            row.unitReceipt=receipt;return row
        end
        local original=points(f,g);local scale,ss=publicRead(g,f,"GetScale","number")
        local size=sizeOf(f,g)
        if not original or ss~="KNOWN" or scale<=0 or not size or not guardCurrent(g) then return nil end
        row.originalParent=parent;row.originalPoints=original;row.originalScale=scale
        row.originalWidth,row.originalHeight=size[1],size[2];g.original=originalSeal(row)
        if not row.gate then
            local create=bind(g,_G,"CreateFrame")
            if not create or not guardCurrent(g) then return nil end
            local legal,combat=pcall(g.combat,S)
            if not legal or combat~=false or not guardCurrent(g) then return nil end
            local made,gate=pcall(create.fn,"Frame","MirageManaged_"..name,parent,"SecureHandlerStateTemplate")
            if not made or not guardCurrent(g) then return nil end
            row.gate=gate;g.gate=gate
            -- Only owned passive gate input flags are changed; no native input.
            if not guardedCall(g,gate,"EnableMouse",true,false) then return nil end
            if not guardedCall(g,gate,"SetAllPoints",true,parent) then return nil end
            if not guardedCall(g,gate,"SetAttribute",true,"_onstate-mirage",stateProgram) then return nil end
        else
            if not guardedCall(g,row.gate,"SetParent",true,parent) or
                not guardedCall(g,row.gate,"ClearAllPoints",true) or not guardedCall(g,row.gate,"SetAllPoints",true,parent) then return nil end
        end
        local gate=row.gate
        local emergency=self.recovery and publicRead(g,self.recovery,"GetAttribute","boolean","mirage-emergency")==true
        if not guardCurrent(g) then return nil end
        if not guardedCall(g,gate,"SetAttribute",true,"mirage-held",false) or
            not guardedCall(g,gate,"SetAttribute",true,"mirage-emergency",emergency==true) or
            not guardedCall(g,gate,"Show",true) then return nil end
        if publicRead(g,gate,"IsShown","boolean")~=true or not guardCurrent(g) then return nil end
        row.active=true;row.parentAttempt=gate;row.unitReceipt=receipt
        if not guardedCall(g,f,"SetParent",true,gate) or not rawequal(parentOf(f,g),gate) or not guardCurrent(g) then return nil end
        -- Last hiding dispatch requires the exact receipt after all native reads.
        if not guardedGlobal(g,"RegisterStateDriver",gate,"mirage",replaceDriver) then return nil end
        if not guardCurrent(g) or not rawequal(row.gate,gate) then return nil end
        row.parentAttempt=nil;row.mode="replace";row.driver=replaceDriver;row.held=nil;row.writtenPoints=nil
        self.status[name]="MANAGED_CANDIDATE";return row
    end)
    if unitWriting[name]==g then unitWriting[name]=nil end
    if ok and result and guardCurrent(g) then return result end
    if rawequal(self.rows[name],row) and unitEpoch[name]==g.epoch then
        row.unitReceipt=nil
        if row.active then row.restorePending=true;self.status[name]="UNIT_HANDOFF_UNCONFIRMED" end
    end
    return nil
end
-- A group request binds its producer observation through ordinary Lua dispatch.
-- Restore retires it before callbacks; an entered setter/helper and the secure
-- program can still finish their own work. Native all-writer acceptance is separate.
local function groupAcquireOwner(q)
    return rawequal(rawget(M,"ManagedNative"),N) and rawequal(rawget(M,"profile"),q.profile)
        and rawequal(rawget(N,"rows"),q.rows) and getmetatable(q.rows)==nil
        and rawequal(rawget(q.rows,q.name),q.row) and rawequal(rawget(_G,q.name),q.root)
        and (not q.row or (getmetatable(q.row)==nil and rawget(q.row,"name")==q.name
            and rawget(q.row,"module")=="PartyRaid" and rawget(q.row,"mode")=="replace"
            and rawequal(rawget(q.row,"frame"),q.frame) and rawequal(rawget(q.row,"gate"),q.gate)))
end
local function groupAcquireCurrent(q,allowRetired)
    return (allowRetired or (not q.retired and (not q.producer or groupReceiptCurrent(q.producer))))
        and rawequal(groupAcquireWriting[q.name],q) and groupAcquireOwner(q)
end
-- Dispatch debt outlives the acquisition lock, but never its captured custody.
-- Its snapshot is independent of cleanup epochs; each cleanup still obtains a
-- fresh ordinary guard. A mutated baseline cannot become restoration authority.
local function groupOriginalCurrent(row,original)
    if not original then return false end
    for _,key in ipairs({"originalParent","originalPoints","originalScale","originalWidth","originalHeight"}) do
        if not rawequal(rawget(row,key),rawget(original,key)) then return false end
    end
    if original.pointsSnapshot then
        local points=rawget(row,"originalPoints")
        if type(points)~="table" or getmetatable(points)~=nil or #points~=#original.pointsSnapshot then return false end
        for i,p in ipairs(original.pointsSnapshot) do
            local actual=rawget(points,i)
            if type(actual)~="table" or getmetatable(actual)~=nil then return false end
            for j=1,5 do if not rawequal(rawget(actual,j),p[j]) then return false end end
        end
    end
    return true
end
local function groupDispatchCurrent(q)
    if not groupAcquireOwner(q) then return false end
    local g=q.cleanupGuard
    if not g or g.malformed or not rawequal(rawget(M,"Safety"),S)
        or not rawequal(rawget(S,"InCombat"),g.combat) or not rawequal(rawget(S,"Readable"),g.readable)
        or not rawequal(rawget(_G,"InCombatLockdown"),g.nativeCombat)
        or not rawequal(rawget(N,"Restore"),q.restoreEntry) then return false end
    for key,value in pairs(g.safetyMethods) do if not rawequal(rawget(S,key),value) then return false end end
    for _,key in ipairs({"issecretvalue","canaccessvalue","canaccesstable"}) do
        if not rawequal(rawget(_G,key),g.globals[key]) then return false end
    end
    return groupOriginalCurrent(q.row,g.original)
end
local function groupAcquireRequest(name,rows,row,chain)
    return {name=name,rows=rows,row=row,root=rawget(_G,name),profile=rawget(M,"profile"),
        frame=row and rawget(row,"frame"),gate=row and rawget(row,"gate"),restores=0,chain=chain}
end
local function acquireGroupRequest(q,replaced)
    local name,rows,f=q.name,q.rows,q.root
    local function current()
        local originalLost=q.original and not groupOriginalCurrent(q.row,q.original)
        local dispatchLost=q.cleanupGuard and not groupDispatchCurrent(q)
        if not groupAcquireCurrent(q) or originalLost or dispatchLost then
            -- Retire forward authority first. An entered writer retains its
            -- original dispatch snapshot, including a displaced baseline; the
            -- post-unwind path may restore only if that snapshot is still current.
            -- Read-side refusal without retained cleanup custody authorizes no
            -- fresh Restore snapshot or native mutation from this continuation.
            if not q.retired and (originalLost or dispatchLost or (q.producer and not groupReceiptCurrent(q.producer))) then
                q.retired=true
                if q.cleanupGuard then
                    q.cleanupRequested=true;groupDispatchDebt[name]=q
                    if groupAcquireOwner(q) and (not groupRestoreDebt[name] or rawequal(groupRestoreDebt[name],q.row)) then
                        groupRestoreDebt[name]=q.row;rawset(q.row,"restorePending",true)
                        local target=rawget(N,"status")
                        if type(target)=="table" then rawset(target,name,"GROUP_ACQUIRE_RESTORE_PENDING") end
                    end
                end
            end
            error(groupAcquireCancelled,0)
        end
    end
    local function call(fn,...)
        current();local result=pack(fn(...));current();return unpack(result,1,result.n)
    end
    local function method(object,key,...)
        current();local fn=object[key];current();return call(fn,object,...)
    end
    local function global(key,...)
        current();local fn=_G[key];current();return call(fn,...)
    end
    -- Native acquisition dispatch cannot be cancelled after entry. Retain a
    -- private custody snapshot so Restore defers until this operation unwinds,
    -- instead of claiming a handback that its late effect could undo.
    local function entered(fn,...)
        current()
        if not q.cleanupGuard then
            q.restoreEntry=rawget(N,"Restore")
            if type(q.restoreEntry)~="function" then error(groupAcquireCancelled,0) end
            q.cleanupGuard=newGuard(name,f,q.row,function() return groupAcquireCurrent(q,true) end)
            q.cleanupGuard.original=q.original
        end
        if not guardCurrent(q.cleanupGuard) then error(groupAcquireCancelled,0) end
        q.inflight=true
        local result=pack(pcall(fn,...))
        q.inflight=false
        current()
        if not result[1] then error(result[2],0) end
        return unpack(result,2,result.n)
    end
    local function enteredMethod(object,key,...)
        current();local fn=object[key];current();return entered(fn,object,...)
    end
    local function enteredGlobal(key,...)
        current();local fn=_G[key];current();return entered(fn,...)
    end
    local function public(object,key,kind,...)
        current();local fn=object[key];current();return method(S,"Public",fn,kind,object,...)
    end
    local function status(value)
        current();local target=rawget(N,"status")
        if type(target)=="table" then rawset(target,name,value) end
    end
    if method(S,"InCombat") or method(M.Native,"Conflict") then return nil end
    if not q.producer then
        local accepted,receipt=method(N,"GroupReplacement",name=="PartyFrame" and "party" or "raid")
        if accepted~=true or not groupReceiptCurrent(receipt) then status("GROUP_PRODUCER_UNAVAILABLE");return nil end
        q.producer=receipt;current()
    end
    local good,parent=method(N,"Usable",f)
    if not good then status("NATIVE_FALLBACK");return nil end
    local row=q.row
    if row and not rawequal(row.frame,f) then
        if not replaced then
            -- Planned old-root cleanup precedes the next acquisition phase.
            -- Never revive this token. A second Restore, even for an inactive
            -- row, invalidates promotion to a distinct successor request.
            current();local restore=N.Restore;current();local count=q.restores
            local restored=restore(N,name,true)
            if restored~=true or not groupAcquireCurrent(q,true) or q.restores~=count+1
                or not q.retired or groupRestoreDebt[name] or rawget(row,"active")
                or rawget(row,"restorePending") then return nil end
            local nextRequest=groupAcquireRequest(name,rows,row,q.chain)
            groupAcquireWriting[name]=nextRequest
            -- Fresh usability/parent observations, not values from cleanup.
            return acquireGroupRequest(nextRequest,true)
        end
        local policy=groupRecoveryPolicies[name]
        local custody=groupGateCustody[name]
        if row.gate and (not custody or not rawequal(custody.row,row) or not rawequal(custody.gate,row.gate)) then
            status("GROUP_POLICY_OWNER_CHANGED");return nil
        end
        if policy and (not rawequal(policy.row,row) or not rawequal(policy.gate,row.gate) or not policy.released) then
            status("GROUP_POLICY_OWNER_CHANGED");return nil
        end
        local replacement={name=name,frame=f,mode="replace",module="PartyRaid",gate=row.gate}
        q.row=replacement;q.frame=f;q.gate=replacement.gate;rawset(rows,name,replacement);row=replacement
        if policy then policy.row=replacement end
        if custody then custody.row=replacement end
    end
    if row and (row.failed or row.restorePending) then return nil end
    if row and row.active then
        local parent=call(parentOf,f)
        if not parent then status("PARENT_UNAVAILABLE");return nil end
        if row.gate and not rawequal(parent,row.gate) then row.contested=true;status("NEWER_OWNER");return nil end
        current();return row
    end
    if row and row.contested then return nil end
    local recoveryPolicy=groupRecoveryPolicies[name]
    if recoveryPolicy then
        if not rawequal(recoveryPolicy.row,row) or not rawequal(recoveryPolicy.gate,row.gate)
            or not recoveryPolicy.released or recoveryPolicy.phase~="retired"
            or public(row.gate,"GetAttribute","string","_onstate-mirage")~=groupRecoveryProgram then
            status("GROUP_POLICY_REARM_REFUSED");return nil
        end
    end
    if not row then
        local count=0;for _ in pairs(rows) do count=count+1 end
        if count>=rawget(N,"maxRows") then status("LEASE_LIMIT");return nil end
        row={name=name,frame=f,mode="replace",module="PartyRaid"}
        q.row=row;q.frame=f;rawset(rows,name,row)
    end
    local original=call(points,f);local scale,ss=public(f,"GetScale","number")
    current();local setter=f.SetParent;current()
    if not original or ss~="KNOWN" or scale<=0 or type(setter)~="function" then status("NATIVE_FALLBACK");return nil end
    local width=public(f,"GetWidth","number");local height=public(f,"GetHeight","number")
    row.originalParent=parent;row.originalPoints=original;row.originalScale=scale
    row.originalWidth=width;row.originalHeight=height
    q.original=originalSeal(row);current()
    if not row.gate then
        local gate=global("CreateFrame","Frame","MirageManaged_"..name,parent,"SecureHandlerStateTemplate")
        q.gate=gate;row.gate=gate
        -- Issuance is captured at creation, never inferred later from a mutable
        -- row or an identical snippet found on another controller's gate.
        groupGateCustody[name]={row=row,gate=gate}
        method(S,"Passive",gate);method(gate,"SetAllPoints",parent)
        method(gate,"SetAttribute","_onstate-mirage",stateProgram)
    else
        method(row.gate,"SetParent",parent);method(row.gate,"ClearAllPoints");method(row.gate,"SetAllPoints",parent)
    end
    local gate=row.gate
    local emergency=N.recovery and public(N.recovery,"GetAttribute","boolean","mirage-emergency")==true
    method(gate,"SetAttribute","mirage-held",false);method(gate,"SetAttribute","mirage-emergency",emergency==true)
    method(gate,"Show")
    row.active=true;row.parentAttempt=gate
    local ok=pcall(function()
        enteredMethod(f,"SetParent",gate)
        if not rawequal(call(parentOf,f),gate) then error("PARENT_WRITE_REJECTED") end
        current()
        if recoveryPolicy then
            -- Preserve Acquire's existing caller-admission contract. This is
            -- recovery custody, not a new producer-readiness receipt/filter.
            if public(gate,"GetAttribute","string","_onstate-mirage")~=groupRecoveryProgram then error("GROUP_POLICY_REARM_OWNER_CHANGED") end
            -- Keep the old gate show-only through fresh parenting. Rearming is
            -- itself an entered writer: nested Restore defers until it unwinds.
            recoveryPolicy.phase="rearming";recoveryPolicy.released=false
            enteredMethod(gate,"SetAttribute","_onstate-mirage",stateProgram)
            if public(gate,"GetAttribute","string","_onstate-mirage")~=stateProgram then error("GROUP_POLICY_REARM_UNCONFIRMED") end
        end
        if type(RegisterStateDriver)~="function" or type(UnregisterStateDriver)~="function" then error("NO_SECURE_DRIVER") end
        enteredGlobal("RegisterStateDriver",gate,"mirage",replaceDriver)
    end)
    current()
    if not ok then
        row.failed=true
        -- This is terminal cleanup, not permission to resume acquisition.
        local restore=N.Restore;current();local count=q.restores
        local restored=restore(N,name)
        if groupAcquireCurrent(q,true) and q.restores==count+1 then
            local target=rawget(N,"status")
            if type(target)=="table" then rawset(target,name,restored and "HANDOFF_FAILED_NATIVE_RESTORED" or "RESTORE_RELOAD_REQUIRED") end
        end
        return nil
    end
    if recoveryPolicy and rawequal(groupRecoveryPolicies[name],recoveryPolicy) then groupRecoveryPolicies[name]=nil end
    row.active=true;row.parentAttempt=nil;row.mode="replace";row.driver=replaceDriver;row.held=nil;row.writtenPoints=nil
    status("MANAGED_CANDIDATE");return row
end
local function acquireGroup(self,name,mode,module,receipt)
    if not rawequal(self,N) or not rawequal(rawget(M,"ManagedNative"),N) then return nil end
    local function refused(reason)
        local status=rawget(N,"status")
        if type(status)=="table" then rawset(status,name,reason) end
        return nil
    end
    if mode~="replace" or module~="PartyRaid" then return refused("GROUP_REQUEST_REJECTED") end
    if groupRestoreDebt[name] or groupDispatchDebt[name] then return refused("GROUP_RESTORE_PENDING") end
    if groupAcquireWriting[name] or groupRestoreWriting[name] or groupGateWriting[name] then
        return refused("GROUP_WRITER_BUSY")
    end
    local rows=rawget(N,"rows")
    if type(rows)~="table" or getmetatable(rows)~=nil then return refused("GROUP_REQUEST_REJECTED") end
    local row=rawget(rows,name)
    if row~=nil and (type(row)~="table" or getmetatable(row)~=nil or rawget(row,"name")~=name
        or rawget(row,"module")~="PartyRaid" or rawget(row,"mode")~="replace") then
        return refused("GROUP_REQUEST_REJECTED")
    end
    local policy=groupRecoveryPolicies[name]
    if policy and (not rawequal(policy.row,row) or not rawequal(policy.gate,row and rawget(row,"gate"))
        or not policy.released or (row and rawget(row,"active"))) then return refused("GROUP_POLICY_REARM_REFUSED") end
    local custody=groupGateCustody[name]
    if (custody and (not rawequal(custody.row,row) or not rawequal(custody.gate,row and rawget(row,"gate"))))
        or (row and rawget(row,"gate") and not custody) then return refused("GROUP_POLICY_OWNER_CHANGED") end
    local chain={};local request=groupAcquireRequest(name,rows,row,chain)
    if receipt~=nil then
        local observed=groupReceipts[receipt]
        if not observed or observed.kind~=(name=="PartyFrame" and "party" or "raid") or not groupReceiptCurrent(receipt) then
            return refused("GROUP_PRODUCER_UNAVAILABLE")
        end
        request.producer=receipt
    end
    groupAcquireWriting[name]=request
    local ok,result=pcall(acquireGroupRequest,request)
    local current=groupAcquireWriting[name]
    if current and rawequal(current.chain,chain) then
        -- Exactly one post-unwind cleanup attempt, through the existing legal
        -- Restore policy. The acquisition lock remains held throughout. A
        -- displaced custody snapshot authorizes no write to its replacement.
        pcall(function()
            if current.cleanupRequested and current.retired and not current.inflight
                and groupDispatchCurrent(current) and guardCurrent(current.cleanupGuard) then
                groupRestoreSource(N,name,true)
            end
        end)
        groupAcquireWriting[name]=nil
    end
    if not ok then if rawequal(result,groupAcquireCancelled) then return nil end;error(result,0) end
    return result
end
function N:Acquire(name,mode,module,receipt)
    if editorState()~="CLOSED" then return nil end
    if delegated(name,_G[name]) then
        -- A cosmetic adoption never installs a visibility parent or a native
        -- geometry journal. NativeUtility separately owns qualified visibility.
        local prior=self.rows[name]
        if prior and (prior.gate or prior.writtenPoints or prior.writtenScale or prior.sizeWritten) then
            self.status[name]="NATIVE_GEOMETRY_RELOAD_REQUIRED";return nil
        end
        local row=acquireLegacy(self,name,"adopt",module)
        if row then self.status[name]="NATIVE_GEOMETRY_DELEGATED" end
        return row
    end
    if groupRoots[name] then return acquireGroup(self,name,mode,module,receipt) end
    if module=="UnitFrames" and mode=="replace" then return acquireUnit(self,name,receipt) end
    return acquireLegacy(self,name,mode,module)
end
-- Sealed once by the following packaged source component. Mutable public
-- replacements cannot mint the exception to normal newer-layout protection.
function N:BindActionLayoutValidator(component,accept,current,editAccept,editCurrent,editComplete,editAcquire)
    if actionLayoutValidator or component~=M.NativeActionLayout or type(accept)~="function" or type(current)~="function" then return false end
    if type(editAccept)~="function" or type(editCurrent)~="function" or type(editComplete)~="function" or type(editAcquire)~="function" then return false end
    actionLayoutValidator={component=component,accept=accept,current=current,editAccept=editAccept,editCurrent=editCurrent,editComplete=editComplete,editAcquire=editAcquire};return true
end
layoutValidatorCurrent=function()
    local v=actionLayoutValidator
    return v and M.NativeActionLayout==v.component and v.component.Accept==v.accept and v.component.Current==v.current
        and v.component.EditAccept==v.editAccept and v.component.EditCurrent==v.editCurrent and v.component.EditComplete==v.editComplete
        and v.component.EditAcquire==v.editAcquire and v
end
-- A private source receipt distinguishes native Edit Mode's known layout from
-- an arbitrary later owner. The handback itself uses the guarded restore path.
function N:NativeEditPending(row) return self==N and nativeEditDebt[row]~=nil end
function N:ReleaseNativeEdit(row,token)
    if row and delegated(row.name,row.frame) then return false end
    if self~=N or not row or self.rows[row.name]~=row or row.contested or row.failed or S:InCombat() then return false end
    local v=layoutValidatorCurrent();if not v then return false end
    local ok,target=pcall(v.editAccept,v.component,token,row)
    if not ok or type(target)~="table" or layoutValidatorCurrent()~=v then return false end
    local function owner()
        if layoutValidatorCurrent()~=v then return false end
        local legal,current=pcall(v.editCurrent,v.component,token,row);return legal and current==true
    end
    if not owner() then return false end
    nativeEditDebt[row]=true
    -- These are restoration journals, not either editor's saved profile. Known
    -- native output becomes the handback destination; unrelated data is never
    -- adopted as a new baseline and no contested flag is cleared.
    row.originalPoints=target.points;row.originalScale=target.scale
    row.originalWidth,row.originalHeight=target.size[1],target.size[2]
    if target.before then
        row.writtenPoints=target.before.points;row.pointsAttempt=nil
        row.writtenScale=target.before.scale;row.scaleAttempt=nil
        row.sizeWritten=target.before.size;row.sizeAttempt=nil
    end
    if row.active then row.restorePending=true end
    local guard=newGuard(row.name,row.frame,row,owner);guard.nativeEdit=true
    -- Native access precedes cosmetic cleanup, including a callback that may
    -- defer the remaining handback until combat ends.
    if row.gate and (not guardedCall(guard,row.gate,"Show",true) or publicRead(guard,row.gate,"IsShown","boolean")~=true or not guardCurrent(guard)) then return false end
    local restored=self:Restore(row.name,true,guard)
    if layoutValidatorCurrent()~=v then return false end
    local done,complete=pcall(v.editComplete,v.component,token,row,restored==true)
    return done and complete==true
end
function N:Position(row,geometry,nativeReceipt)
    if row and delegated(row.name,row.frame) then self.status[row.name]="NATIVE_GEOMETRY_DELEGATED";return false end
    if editorState()~="CLOSED" then return false end
    if groupDispatchForRow(row) then return false end
    if not row or not geometry or not row.active or row.contested or row.restorePending or row.failed or S:InCombat() then return false end
    local f=row.frame;local profile=M.profile;local rows=self.rows;local gate=row.gate
    local strict=nativeReceipt~=nil or row.mode=="controls" or row.mode=="cooldowns" or row.editPositionPending==true
    local bindings={}
    if strict then
        for _,key in ipairs({"GetNumPoints","GetPoint","GetScale","GetWidth","GetHeight","GetParent","SetScale","SetSize","ClearAllPoints","SetPoint"}) do
            bindings[key]=S:Field(f,key)
        end
    end
    local function requestCurrent()
        if not strict then return true end
        if M.ManagedNative~=N or M.Safety~=S or M.profile~=profile or self.rows~=rows or rows[row.name]~=row or row.frame~=f or _G[row.name]~=f or row.gate~=gate
            or not row.active or row.failed or row.restorePending or row.contested or not M.Managed:Enabled() or not M:IsModuleActive(row.module) or M.Native:Conflict() then return false end
        for key,fn in pairs(bindings) do if S:Field(f,key)~=fn then return false end end
        if nativeReceipt then
            local v=layoutValidatorCurrent();if not v then return false end
            local ok,value=pcall(v.current,v.component,nativeReceipt,row)
            if not ok or value~=true then return false end
        end
        return not S:InCombat()
    end
    local function retired()
        -- Keep readback/attempt journals for the ordinary deferred restoration
        -- path, but never continue this retired request into another writer.
        if self.rows==rows and rows[row.name]==row then row.failed=true;row.restorePending=true;self.status[row.name]="LAYOUT_REQUEST_RETIRED" end
        return false
    end
    if not requestCurrent() then return false end
    local before=observePoints(row)
    if not requestCurrent() then return retired() end
    if not before then self.status[row.name]="ANCHOR_UNAVAILABLE";return false end
    local currentScale=observeScale(row)
    if not requestCurrent() then return retired() end
    local currentSize=observeSize(row)
    if not requestCurrent() then return retired() end
    if not currentScale or not currentSize then self.status[row.name]="NATIVE_SIZE_UNAVAILABLE";return false end
    local nativeReflow=false
    if nativeReceipt then
        local v=layoutValidatorCurrent()
        local ok,accepted=false,false
        if v then ok,accepted=pcall(v.accept,v.component,nativeReceipt,row,before,currentScale,currentSize) end
        if not ok or accepted~=true or not requestCurrent() then return false end
        nativeReflow=true
    end
    if not nativeReflow and ((row.writtenPoints and not same(before,row.writtenPoints)) or
        (row.writtenScale and not near(currentScale,row.writtenScale,.00001)) or
        (row.sizeWritten and not sameSize(currentSize,row.sizeWritten))) then
        row.contested=true;self.status[row.name]="NEWER_LAYOUT_PRESERVED";return false
    end
    local scale=math.min(geometry.maxW/currentSize[1],geometry.maxH/currentSize[2],1.2)
    if scale<.45 and not (geometry.width and geometry.height) then self.status[row.name]="NATIVE_LAYOUT_FALLBACK";return false end
    local ok=true
    if geometry.width and geometry.height then
        if not requestCurrent() then return retired() end
        if not row.sizeWritten then row.originalWidth=currentSize[1];row.originalHeight=currentSize[2] end
        row.sizeBefore=currentSize;row.sizeAttempt={geometry.width,geometry.height}
        local sent=pcall(f.SetSize,f,geometry.width,geometry.height)
        if not requestCurrent() then return retired() end
        row.sizePartialAllowed=not sent
        local observed=observeSize(row)
        ok=sent and sameSize(observed,{geometry.width,geometry.height});scale=1
    end
    if ok then
        if not requestCurrent() then return retired() end
        if not row.writtenScale then row.originalScale=currentScale end
        local base=M.Rework and M.Rework.NativeMethod and M.Rework.NativeMethod(f,"SetScale")
        row.scaleAttempt=scale;local sent=pcall(base or f.SetScale,f,scale)
        if not requestCurrent() then return retired() end
        ok=sent and near(observeScale(row),scale,.00001)
        if not sent then observeScale(row) end
    end
    if ok then
        ok=setPoints(row,{{"CENTER",UIParent,"CENTER",geometry.x/scale,geometry.y/scale}},nil,strict and requestCurrent or nil)
        if not requestCurrent() then return retired() end
    end
    if not ok then
        row.failed=true;local restored=self:Restore(row.name)
        self.status[row.name]=restored and "POSITION_FAILED_NATIVE_RESTORED" or "RESTORE_RELOAD_REQUIRED";return false
    end
    row.layoutGeometry=M:Copy(geometry);row.layoutProfile=M.profile;row.layoutSize={currentSize[1],currentSize[2]};row.editPositionPending=nil
    return true
end
function N:Restore(name,automatic,g)
    local utility=self.rows[name]
    if utility and delegated(name,utility.frame) and (utility.gate or utility.writtenPoints or utility.writtenScale or utility.sizeWritten) then
        -- A hot-swapped old runtime journal is not a license to reclaim native
        -- geometry. A normal reload retires that obsolete process-local owner.
        self.status[name]="NATIVE_GEOMETRY_RELOAD_REQUIRED";utility.restorePending=true;utility.restoreFailures=3;return false
    end
    if not guardCurrent(g) then return false end
    local row=self.rows[name]
    if not row or (not row.active and not (g and g.groupRestore)) then return true end
    if automatic and (row.restoreFailures or 0)>=3 then return false end
    if S:InCombat() then row.restorePending=true;self.status[name]="RESTORE_AFTER_COMBAT";return false end
    local complete=true;local f=row.frame
    local parent=treeUsable(f) and parentOf(f,g)
    if not guardCurrent(g) then return false end
    if not parent or not treeUsable(row.originalParent) then complete=false
    elseif not guardCurrent(g) then return false
    else
        if row.gate then
            -- Optional rows retain their predeclared combat fallback until
            -- released-input handback has observed the parent shown. A stale
            -- callback cannot strand a hidden gate with its driver removed.
            if row.hoverMode then
                local shown=guardedCall(g,row.gate,"Show",true) and publicRead(g,row.gate,"IsShown","boolean")==true
                if not guardCurrent(g) then return false end
                if not shown then
                    row.restoreFailures=(row.restoreFailures or 0)+1;row.restorePending=true
                    self.status[name]="RESTORE_RELOAD_REQUIRED";return false
                end
            end
            if g and g.groupRestore and type(UnregisterStateDriver)~="function" then complete=false
            elseif UnregisterStateDriver and not guardedGlobal(g,"UnregisterStateDriver",row.gate,"mirage") then complete=false end
            if not guardCurrent(g) then return false end
            -- Reveal first, even when a later property cannot be restored.
            if not row.hoverMode and not guardedCall(g,row.gate,"Show",true) then complete=false end
            if not guardCurrent(g) then return false end
            local current=parent
            if not current then complete=false
            elseif current==row.gate then
                row.parentAttempt=row.originalParent;guardedCall(g,f,"SetParent",true,row.originalParent)
                current=parentOf(f,g);parent=current
                if not guardCurrent(g) then return false end
                if not current or current==row.gate then complete=false
                else row.parentAttempt=nil;if current~=row.originalParent then row.contested=true end end
            else row.parentAttempt=nil;if current~=row.originalParent then row.contested=true end end
        end
        -- Unknown parent/ancestry cannot authorize geometry mutation.
        if parent and treeUsable(f) and guardCurrent(g) then
            if row.writtenPoints or row.pointsAttempt then
                local current=observePoints(row,g)
                if not current then complete=false
                elseif not same(current,row.originalPoints) and same(current,row.writtenPoints) then
                    setPoints(row,row.originalPoints,g);current=observePoints(row,g)
                    if not current or (not same(current,row.originalPoints) and same(current,row.writtenPoints)) then complete=false end
                end
                if not guardCurrent(g) then return false end
                if current and (same(current,row.originalPoints) or not same(current,row.writtenPoints)) then
                    if not same(current,row.originalPoints) then row.contested=true end
                    row.writtenPoints=nil;row.pointsAttempt=nil
                end
            end
            if row.writtenScale or row.scaleAttempt then
                local current=observeScale(row,g)
                if not current then complete=false
                elseif current~=row.originalScale and current==row.writtenScale then
                    row.scaleAttempt=row.originalScale;guardedCall(g,f,"SetScale",true,row.originalScale);current=observeScale(row,g)
                    if not current or (current~=row.originalScale and current==row.writtenScale) then complete=false end
                end
                if not guardCurrent(g) then return false end
                if current and (current==row.originalScale or current~=row.writtenScale) then
                    if current~=row.originalScale then row.contested=true end
                    row.writtenScale=nil;row.scaleAttempt=nil
                end
            end
            if row.sizeWritten or row.sizeAttempt then
                local original={row.originalWidth,row.originalHeight};local current=observeSize(row,g)
                if not current then complete=false
                elseif not sameSize(current,original) and sameSize(current,row.sizeWritten) then
                    row.sizeBefore=current;row.sizeAttempt=original
                    row.sizePartialAllowed=not guardedCall(g,f,"SetSize",true,original[1],original[2]);current=observeSize(row,g)
                    if not current or (not sameSize(current,original) and sameSize(current,row.sizeWritten)) then complete=false end
                end
                if not guardCurrent(g) then return false end
                if current and (sameSize(current,original) or not sameSize(current,row.sizeWritten)) then
                    if not sameSize(current,original) then row.contested=true end
                    row.sizeWritten=nil;row.sizeAttempt=nil
                end
            end
        else complete=false end
    end
    if not guardCurrent(g) then return false end
    if g and g.groupRestore then
        -- A cleanup dispatch is not an observation of handback. Recheck after
        -- geometry/art callbacks before publishing completion.
        local node,seen=f,{}
        local detached=false
        for _=1,32 do
            if not qualified(g,node) or seen[node] or rawequal(node,row.gate) then break end
            seen[node]=true
            local nextParent,status=publicRead(g,node,"GetParent",nil)
            if status~="KNOWN" or not guardCurrent(g) then break end
            if nextParent==nil then detached=true;break end
            node=nextParent
        end
        if not detached then complete=false end
        if not guardCurrent(g) then return false end
    end
    if complete then
        row.restoreFailures=0;row.active=false;row.restorePending=nil
        row.layoutGeometry=nil;row.layoutProfile=nil;row.layoutSize=nil
        self.status[name]="RESTORED";return true
    end
    row.restoreFailures=(row.restoreFailures or 0)+1;row.restorePending=true;self.status[name]="RESTORE_RELOAD_REQUIRED";return false
end
function N:RestoreAll(automatic)
    for name in pairs(self.rows) do self:Restore(name,automatic) end
    if self.recovery and not S:InCombat() then self.recovery:Hide() end
end
function N:RestoreModule(module)
    for name,row in pairs(self.rows) do if row.module==module then self:Restore(name) end end
    if module=="UnderCharacterHUD" then self:ResourcePreference(false) end
end
-- Cosmetic leases deliberately remain separate from StyleLease's stricter
-- unprotected-frame contract. Only these two decorative alpha properties use
-- the managed tree's guarded, nonforbidden ancestry check outside combat.
local function artAlpha(r,g)
    if not treeUsable(r.object) or not guardCurrent(g) then return nil end
    local value,status=publicRead(g,r.object,"GetAlpha","number")
    if status=="KNOWN" and value>=0 and value<=1 then return value end
end
local function artPending(r)
    r.retries=(r.retries or 0)+1
    r.pending=r.retries<3 or nil;r.reloadRequired=r.retries>=3 or nil
end
local function restoreArtRecord(r,g)
    if not guardCurrent(g) then return false end
    if S:InCombat() then r.pending=not r.reloadRequired or nil;return false end
    local oldWritten,oldAttempt,oldUncertain,oldDisplaced=r.written,r.attempt,r.uncertain,r.displaced
    if g then g.artRecord=r;g.artObject=r.object;g.artOriginal=r.original;g.artMap=g.row.art end
    local current=artAlpha(r,g)
    if not guardCurrent(g) or (g and (r.written~=oldWritten or r.attempt~=oldAttempt or r.uncertain~=oldUncertain or r.displaced~=oldDisplaced)) then return false end
    if current==r.original then r.released=true;r.pending=nil;return true end
    if r.displaced then r.released=true;r.pending=nil;return true end
    if current~=nil and not r.uncertain and current~=r.written and current~=r.attempt then
        r.displaced=true;r.released=true;r.pending=nil;return true
    end
    if (r.retries or 0)>=3 then r.pending=nil;r.reloadRequired=true;return false end
    if current==nil then artPending(r);return false end
    if r.uncertain and current~=r.written and current~=r.attempt then
        -- A later opaque partial result cannot establish ownership.
        artPending(r);return false
    end
    if current~=r.written and current~=r.attempt then
        r.displaced=true;r.released=true;r.pending=nil;return true
    end
    r.written=current;r.uncertain=nil;r.attempt=r.original
    if g then g.artExpected={written=r.written,attempt=r.attempt,uncertain=r.uncertain,displaced=r.displaced} end
    local sent=guardedCall(g,r.object,"SetAlpha",true,r.original)
    local observed=artAlpha(r,g)
    if g then g.artExpected=nil end
    if not guardCurrent(g) then return false end
    if observed==r.original then r.released=true;r.pending=nil;r.attempt=nil;return true end
    if observed==nil then r.uncertain=true
    elseif not sent then r.written=observed;r.attempt=nil
    elseif observed~=current then r.displaced=true;r.released=true;r.pending=nil;return true
    else r.attempt=nil end
    artPending(r);return false
end
local function artStatus(row)
    local status=next(row.art or {}) and "ART_OWNED" or "ART_RESTORED"
    for _,r in pairs(row.art or {}) do
        if r.reloadRequired then return "ART_RESTORE_RELOAD_REQUIRED" end
        if r.pending then status="ART_RESTORE_PENDING" end
    end
    return status
end
function N:SkinActions(row)
    if not row or S:InCombat() then return end
    if M:ModuleConfig("ActionBars").style~=true then self:RestoreArt(row);return end
    row.art=row.art or {};row.artSlots=row.artSlots or {}
    for _,key in ipairs({"BorderArt","EndCaps"}) do
        local t=S:Field(row.frame,key)
        local previous=row.artSlots[key]
        local ready=true
        if previous and previous.object~=t and not previous.released then
            ready=restoreArtRecord(previous)
            if ready then row.art[previous.object]=nil end
        end
        if previous and previous.object==t and (previous.pending or previous.reloadRequired or previous.displaced or previous.failed) then ready=false end
        if ready and t and treeUsable(t) and type(t.GetAlpha)=="function" and type(t.SetAlpha)=="function" then
            local r=row.art[t]
            local current=artAlpha({object=t})
            if r then
                if current~=nil and current~=r.written then r.displaced=true end
            elseif current~=nil then
                r={object=t,original=current,attempt=0};row.art[t]=r;row.artSlots[key]=r
                local sent=pcall(t.SetAlpha,t,0)
                local observed=artAlpha(r)
                if observed==0 then r.written=0;r.attempt=nil
                elseif observed==nil then r.uncertain=true
                elseif not sent then r.written=observed;r.attempt=nil
                elseif observed~=current then r.displaced=true;r.attempt=nil
                else r.attempt=nil end
                if not sent or observed~=0 then
                    r.failed=true;r.pending=true
                    if observed~=nil and restoreArtRecord(r) then row.art[t]=nil end
                end
            end
        end
    end
end
-- Explicitly identified cosmetic regions only. Native controls, icons, labels,
-- timers, value fills and meaningful state overlays are never suppression targets.
function N:SuppressDecoration(row,key,object)
    if not row or self.rows[row.name]~=row or row.frame~=_G[row.name] or not row.active or row.failed or row.contested or row.restorePending
        or (row.module~="ActionBars" and row.module~="UnderCharacterHUD") or S:InCombat() then return false end
    local profile=M.profile
    local function current()
        return M.profile==profile and self.rows[row.name]==row and row.frame==_G[row.name] and row.active
            and not row.failed and not row.contested and not row.restorePending and not S:InCombat()
    end
    if not object or not treeUsable(object) or not current() or type(object.GetAlpha)~="function" or type(object.SetAlpha)~="function" then return false end
    local node=object;local descendant=false
    for _=1,12 do
        if node==row.frame then descendant=true;break end
        node=parentOf(node);if not node or not current() then return false end
    end
    if not descendant then return false end
    row.art=row.art or {};row.artSlots=row.artSlots or {}
    local previous=row.artSlots[key]
    if previous and previous.object~=object and not previous.released then
        if not restoreArtRecord(previous) or not current() then return false end
        row.art[previous.object]=nil
    end
    local record=row.art[object]
    local alpha=artAlpha({object=object})
    if not current() or alpha==nil then return false end
    if record then
        if record.written~=alpha then record.displaced=true end
        return not record.displaced and not record.pending and not record.reloadRequired and not record.failed
    end
    record={object=object,original=alpha,attempt=0};row.art[object]=record;row.artSlots[key]=record
    if not current() then return false end
    local sent=pcall(object.SetAlpha,object,0)
    local observed=artAlpha(record)
    if not current() then record.uncertain=true;record.pending=true;return false end
    if observed==0 then record.written=0;record.attempt=nil
    elseif observed==nil then record.uncertain=true
    elseif not sent then record.written=observed;record.attempt=nil
    elseif observed~=alpha then record.displaced=true;record.attempt=nil
    else record.attempt=nil end
    if not sent or observed~=0 then
        record.failed=true;record.pending=true
        if observed~=nil and restoreArtRecord(record) then row.art[object]=nil end
        return false
    end
    return true
end
function N:RestoreArt(row,g)
    if not row then return end
    if not g and row.module=="UnitFrames" then
        -- Periodic and direct art cleanup must preserve the same displacement
        -- evidence as a controller handback, even when the art record is removed.
        if unitWriting[row.name] or not rawequal(self.rows[row.name],row) then return false end
        g=newGuard(row.name,row.frame,row,nil);unitWriting[row.name]=g
        local ok,complete=pcall(restoreArtSource,self,row,g)
        if unitWriting[row.name]==g then unitWriting[row.name]=nil end
        return ok and complete==true and guardCurrent(g)
    end
    if not g then
        local complete=not M.NativePresentation or M.NativePresentation:Restore(row)~=false
        for object,r in pairs(row.art or {}) do
            if restoreArtRecord(r) then row.art[object]=nil else complete=false end
        end
        row.artStatus=artStatus(row);return complete
    end
    if not guardCurrent(g) then return false end
    local complete=true
    if g.nativeEdit and M.NativePresentation then
        complete=M.NativePresentation:Restore(row)~=false
        if not guardCurrent(g) then return false end
    end
    local art=row.art;local records={}
    for object,r in pairs(art or {}) do
        if #records>=64 then return false end
        records[#records+1]={object,r}
    end
    for _,entry in ipairs(records) do
        local object,r=entry[1],entry[2]
        if not guardCurrent(g) or row.art~=art or art[object]~=r then return false end
        if g and r.displaced then g.artDisplaced=true;if row.module=="UnitFrames" then row.unitArtContested=true end end
        local restored=restoreArtRecord(r,g)
        if not guardCurrent(g) or row.art~=art or art[object]~=r then return false end
        -- Displacement is a release, but never proof of an uncontested handback.
        if g and r.displaced then g.artDisplaced=true;if row.module=="UnitFrames" then row.unitArtContested=true end end
        if restored then art[object]=nil else complete=false end
        g.artRecord=nil;g.artObject=nil;g.artOriginal=nil;g.artMap=nil;g.artExpected=nil
    end
    if not guardCurrent(g) then return false end
    row.artStatus=artStatus(row)
    return complete
end
function N:RetryArt()
    if S:InCombat() then return end
    if M.NativePresentation then M.NativePresentation:Retry() end
    for name,row in pairs(self.rows) do
        if row.module=="UnitFrames" then
            local pending=false
            for _,r in pairs(row.art or {}) do if r.pending then pending=true;break end end
            if pending then self:RestoreArt(row) end
        else
            for object,r in pairs(row.art or {}) do
                if r.pending and restoreArtRecord(r) then row.art[object]=nil end
            end
        end
        row.artStatus=artStatus(row)
        if self.status[name]=="ART_RESTORE_PENDING" or self.status[name]=="ART_RESTORE_RELOAD_REQUIRED" then self.status[name]=row.artStatus end
    end
end
restoreArtSource=N.RestoreArt
local restoreOne=N.Restore
function N:Restore(name,automatic,g)
    -- Any call through this restoration entry retires the named request before
    -- row lookup/callbacks. A borrowed receiver may alias our rows; revocation
    -- must not depend on that receiver having acquisition authority.
    local acquisition=groupAcquireWriting[name]
    if acquisition then acquisition.retired=true;acquisition.restores=acquisition.restores+1 end
    local gateWriter=groupGateWriting[name]
    local gateRequest=gateWriter and gateWriter.dispatch
    if gateRequest then gateRequest.retired=true end
    local enteredRequest=acquisition and acquisition.inflight and acquisition
        or gateRequest and gateRequest.inflight and gateRequest
    if enteredRequest then
        -- Even a borrowed receiver can retire the request, but cannot grant
        -- custody. Do not perform native cleanup while its writer is entered.
        -- Repeated calls retain one debt and do not consume failure retries.
        -- Retain private revocation even if custody was displaced before this
        -- call. Such debt may refuse later cleanup, never adopt a new baseline.
        groupDispatchDebt[name]=enteredRequest;enteredRequest.cleanupRequested=true
        if groupDispatchCurrent(enteredRequest) and guardCurrent(enteredRequest.cleanupGuard)
            and (not groupRestoreDebt[name] or rawequal(groupRestoreDebt[name],enteredRequest.row)) then
            groupRestoreDebt[name]=enteredRequest.row
            enteredRequest.row.restorePending=true
            local status=rawget(N,"status")
            if type(status)=="table" then rawset(status,name,gateRequest==enteredRequest and "GROUP_RESTORE_AFTER_GATE" or "GROUP_RESTORE_AFTER_ACQUIRE") end
        end
        return false
    end
    local dispatchDebt=groupDispatchDebt[name]
    if dispatchDebt and (not rawequal(self,N) or not groupDispatchCurrent(dispatchDebt)) then return false end
    local row=self.rows[name]
    if groupRoots[name] and groupRestoreDebt[name] and not rawequal(groupRestoreDebt[name],row) then
        self.status[name]="GROUP_RESTORE_OWNER_CHANGED";return false
    end
    local hover=M.ManagedActionHover
    if row and row.mode=="actions" and hover then
        local restoreProfile=M.profile
        if row.hoverMode and automatic and (row.restoreFailures or 0)>=3 then return false end
        -- Retire owned acquisition before releasing its native geometry/parent.
        -- A failed out-of-combat retirement cannot authorize stale handback.
        local ok,retired=pcall(hover.Retire,hover,row)
        if self.rows[name]~=row or M.profile~=restoreProfile then return false end
        if (not ok or retired~=true) and not S:InCombat() then
            row.restoreFailures=(row.restoreFailures or 0)+1
            row.restorePending=true;self.status[name]="HOVER_RETIRE_UNCONFIRMED";return false
        end
    end
    local wasActive=row and row.active
    local ownGuard=false
    local groupGuard=false
    local groupFailures
    if groupRoots[name] and row and (row.active or groupRestoreDebt[name]) then
        if groupRestoreDebt[name] and not rawequal(groupRestoreDebt[name],row) then
            self.status[name]="GROUP_RESTORE_OWNER_CHANGED";return false
        end
        local expectedMode,expectedModule=rawget(row,"mode"),rawget(row,"module")
        if expectedMode~="replace" or expectedModule~="PartyRaid" or rawget(row,"name")~=name then
            self.status[name]="GROUP_RESTORE_OWNER_CHANGED";return false
        end
        groupRestoreDebt[name]=row;row.restorePending=true
        local function groupOwner()
            return rawequal(groupRestoreDebt[name],row)
                and (not dispatchDebt or (rawequal(groupDispatchDebt[name],dispatchDebt) and groupDispatchCurrent(dispatchDebt)))
                and rawget(row,"mode")==expectedMode
                and rawget(row,"module")==expectedModule and rawget(row,"name")==name
        end
        -- A nested restore invalidates the older writer before refusing entry.
        g=newGuard(name,row.frame,row,groupOwner);g.groupRestore=true
        if groupRestoreWriting[name] or (automatic and (row.restoreFailures or 0)>=3) then return false end
        groupRestoreWriting[name]=g;groupGuard=true;groupFailures=row.restoreFailures or 0
    end
    if row and row.active and row.hoverMode and hover and not S:InCombat() then
        -- Handback changes native hit targets too. Retiring our motion region
        -- is safe while held, but revealing/reparenting/positioning must wait.
        local profile,frame,gate=M.profile,row.frame,row.gate
        local function releasedOwner()
            return self.rows[name]==row and M.profile==profile and row.frame==frame and row.gate==gate
                and M.ManagedActionHover==hover and hover:InputReleased()==true
        end
        row.restorePending=true
        if not releasedOwner() then self.status[name]="RESTORE_AFTER_INPUT";return false end
        if not g then g=newGuard(name,frame,row,releasedOwner) end
    end
    if not g and (not row or row.module~="UnitFrames") then
        local art=not row or self:RestoreArt(row)
        local geometry=restoreOne(self,name,automatic)
        if not art and geometry then self.status[name]=row.artStatus end
        return geometry and art
    end
    if not g and row and row.module=="UnitFrames" then
        -- A mandatory restore invalidates in-flight hiding permission even when
        -- the old writer has to unwind before native cleanup can proceed.
        g=newGuard(name,row.frame,row,nil)
        if unitWriting[name] then row.restorePending=true;return false end
        unitWriting[name]=g;ownGuard=true
    end
    if not guardCurrent(g) then
        if groupGuard and groupRestoreWriting[name]==g then groupRestoreWriting[name]=nil end
        return false
    end
    local ok,geometryComplete,artComplete=pcall(function()
        if groupGuard then
            -- Retire only our known group program before any reveal callback.
            -- Failure retains debt. The latch remains a separate recovery aid.
            if not retireGroupProgram(name,row,g) then return false,false end
            if not guardedCall(g,row.gate,"SetAttribute",true,"mirage-emergency",true)
                or publicRead(g,row.gate,"GetAttribute","boolean","mirage-emergency")~=true
                or not guardedCall(g,row.gate,"Show",true)
                or publicRead(g,row.gate,"IsShown","boolean")~=true then return false,false end
        end
        if not rawequal(rawget(self,"RestoreArt"),restoreArtSource) then return false,false end
        local art=not row or restoreArtSource(self,row,g)
        if not guardCurrent(g) then return false,art end
        local geometry=restoreOne(self,name,automatic,g)
        if not guardCurrent(g) then return false,art end
        if not art and geometry then self.status[name]=row.artStatus end
        return geometry,art
    end)
    if ownGuard and unitWriting[name]==g then unitWriting[name]=nil end
    local completed=ok and geometryComplete and artComplete and guardCurrent(g)
    if groupGuard then
        if completed and rawequal(groupRestoreDebt[name],row) then
            local policy=groupRecoveryPolicies[name]
            if policy and rawequal(policy.row,row) and rawequal(policy.gate,row.gate) then policy.released=true end
            groupRestoreDebt[name]=nil
            if rawequal(groupDispatchDebt[name],dispatchDebt) then groupDispatchDebt[name]=nil end
        elseif rawequal(rawget(self.rows,name),row) then
            -- Failed prelude writes/readbacks must obey the same bounded retry
            -- policy as later geometry failures. Deferred/invalidated requests
            -- are not counted, and restoreOne's own failure is not double-counted.
            if guardCurrent(g) and (row.restoreFailures or 0)==groupFailures then
                local legal,combat=pcall(g.combat,S)
                if legal and combat==false and guardCurrent(g) then row.restoreFailures=groupFailures+1 end
            end
            if rawequal(rawget(self.rows,name),row) and rawequal(groupRestoreDebt[name],row) then
                row.restorePending=true;self.status[name]="GROUP_RESTORE_UNCONFIRMED"
            end
        end
        if groupRestoreWriting[name]==g then groupRestoreWriting[name]=nil end
    end
    if not ok then return false end
    -- Completing a previously deferred handback during Resume may happen
    -- after this configuration pass already refused acquisition. Schedule one
    -- current reconciliation; safe/disabled Tick never acquires new rows.
    if completed and wasActive and row and row.hoverMode then self.reconcilePending=true end
    if completed and wasActive and row and not row.active and not row.contested and not (g and g.artDisplaced) then queueUnitBoundary(name) end
    return completed,g and g.artDisplaced==true or false
end
groupRestoreSource=N.Restore
-- Narrow cleanup-only maintenance. Unlike Tick/Configure, this never acquires,
-- positions or re-enables a module and must run even when safe/disabled.
function N:RetryHoverRestore()
    if S:InCombat() then return end
    for _,name in ipairs(actions) do
        local row=self.rows[name]
        if row and row.active and row.hoverMode and row.restorePending and (row.restoreFailures or 0)<3 then self:Restore(name,true) end
    end
end
local restoreMethod=N.Restore
function N:ReleaseUnit(unit,current)
    local name=unitNames[unit]
    if not name or type(current)~="function" then return nil,"UNIT_RELEASE_INVALID" end
    if unitWriting[name] then return nil,"UNIT_WRITER_ACTIVE" end
    local root=rawget(_G,name);local row=self.rows[name]
    if row and not rawequal(row.frame,root) then
        -- Settle only the old root before reusing its owned gate. A foreign
        -- handback on that retired root is not a certificate for the successor.
        local previous=newGuard(name,row.frame,row,current);unitWriting[name]=previous
        local settled=false
        local good=pcall(function()
            if not treeUsable(root) or not guardCurrent(previous) then return end
            if not restoreMethod(self,name,true,previous) or not guardCurrent(previous) then return end
            if row.active or row.restorePending or row.parentAttempt or row.pointsAttempt or row.scaleAttempt or row.sizeAttempt or next(row.art or {}) then return end
            local parent=parentOf(row.frame,previous)
            if not parent or rawequal(parent,row.gate) or not guardCurrent(previous) then return end
            settled=true
        end)
        if unitWriting[name]==previous then unitWriting[name]=nil end
        if not good or not settled or not guardCurrent(previous) then return nil,"NATIVE_ROOT_REPLACED" end
        row={name=name,frame=root,gate=row.gate,mode="replace",module="UnitFrames"}
        self.rows[name]=row
    end
    local g=newGuard(name,root,row,current);unitWriting[name]=g
    local ok,result,reason=pcall(function()
        if not guardCurrent(g) or S:InCombat() or not guardedTree(g,root) or not guardCurrent(g) then return nil,"NATIVE_ROOT_UNAVAILABLE" end
        if row and (row.contested or row.unitArtContested) then return nil,"NATIVE_HANDOFF_CONTESTED" end
        local released,displaced=restoreMethod(self,name,false,g)
        if not released or displaced or g.artDisplaced or not guardCurrent(g) then return nil,"NATIVE_RELEASE_UNCONFIRMED" end
        if row and (row.active or row.restorePending or row.contested or row.unitArtContested or row.parentAttempt or row.pointsAttempt or row.scaleAttempt or row.sizeAttempt or next(row.art or {})) then return nil,"NATIVE_RELEASE_DEBT" end
        -- Observe the entire bounded ancestry after release. No active owned
        -- hiding gate may remain above this exact native root. IsShown is not a
        -- readiness oracle: a legitimately absent unit can keep its root hidden.
        local node,seen,ancestry=root,{},{}
        for _=1,32 do
            if not node then break end
            if seen[node] or not guardedTree(g,node) or not guardCurrent(g) then return nil,"NATIVE_ANCESTRY_UNAVAILABLE" end
            seen[node]=true
            for _,other in pairs(self.rows) do if other.active and rawequal(other.gate,node) then return nil,"NATIVE_GATE_REMAINS" end end
            local parent,status=publicRead(g,node,"GetParent",nil)
            if status~="KNOWN" or not guardCurrent(g) or (parent~=nil and not frameObject(parent)) then return nil,"NATIVE_ANCESTRY_UNAVAILABLE" end
            ancestry[#ancestry+1]={node=node,parent=parent};node=parent
        end
        if node~=nil or #ancestry<2 or not guardCurrent(g) then return nil,"NATIVE_ANCESTRY_UNAVAILABLE" end
        local receipt={};releaseRecords[receipt]={guard=g,ancestry=ancestry}
        self.status[name]="NATIVE_OWNERSHIP_RETAINED";return receipt
    end)
    if unitWriting[name]==g then unitWriting[name]=nil end
    if not ok then return nil,"NATIVE_RELEASE_UNCONFIRMED" end
    return result,reason
end
function N:ReleaseCurrent(receipt)
    local r=type(receipt)=="table" and releaseRecords[receipt]
    if not r or not guardCurrent(r.guard) then return false end
    local row=r.guard.row
    if row and (row.active or row.restorePending or row.contested or row.unitArtContested or row.parentAttempt or row.pointsAttempt or row.scaleAttempt or row.sizeAttempt or next(row.art or {})) then return false end
    for _,edge in ipairs(r.ancestry) do
        for _,other in next,r.guard.rows do if rawget(other,"active") and rawequal(rawget(other,"gate"),edge.node) then return false end end
    end
    return true
end
function N:RecoveryButton()
    if S:InCombat() then return end
    if not self.recovery then
        self.recovery=CreateFrame("Button","MirageNativeRecovery",UIParent,"SecureHandlerClickTemplate,BackdropTemplate")
        self.recovery:Hide()
    end
    local b=self.recovery
    if not S:InitializeSecureHandler(b) then
        self.status.Recovery="SECURE_HANDLER_UNAVAILABLE"
        error("RECOVERY_HANDLER_UNAVAILABLE",0)
    end
    if not self.recoveryPrepared then
        -- Preserve the named secure handler and its prepared gate references
        -- for compatibility, without a persistent visual control over gameplay.
        b:SetSize(1,1);b:SetPoint("CENTER",UIParent,"CENTER",0,0)
        b:RegisterForClicks("LeftButtonUp")
        b:SetAttribute("mirage-emergency",false)
        b:SetAttribute("_onclick",[=[
            self:SetAttribute("mirage-emergency",true)
            for i=1,(self:GetAttribute("gate-count") or 0) do
                local gate=self:GetFrameRef("gate"..i)
                if gate then gate:SetAttribute("mirage-emergency",true);gate:Show() end
            end
        ]=])
        b:SetScript("OnEnter",function()
            if GameTooltip then GameTooltip:SetOwner(b,"ANCHOR_LEFT");GameTooltip:SetText("Restore Blizzard UI");GameTooltip:AddLine("Restores native access immediately. /mirage safe also stops MirageUI effects.",1,1,1,true);GameTooltip:Show() end
        end)
        b:SetScript("OnLeave",function() if GameTooltip then GameTooltip:Hide() end end)
        self.recoveryPrepared=true
    end
    self.status.Recovery="READY"
    local keys={};for name,row in pairs(self.rows) do if row.active and row.gate then keys[#keys+1]=name end end;table.sort(keys)
    self.recovery:SetAttribute("gate-count",#keys)
    for i,name in ipairs(keys) do self.recovery:SetFrameRef("gate"..i,self.rows[name].gate) end
    self.recovery:Hide()
end
local signatureOwner=M.UnitTypography
local signatureMethod=signatureOwner and signatureOwner.ReplacementSignature
function N:ReplacementSignature()
    local bits={}
    local units={"player","target","focus","pet","boss1","boss2","boss3","boss4","boss5"}
    -- This replaces repeated shared pure-source validation only. No eligibility
    -- is cached across callbacks or used as an Acquire hiding capability.
    local ordinary
    if type(signatureOwner)=="table" and type(signatureMethod)=="function" and
        rawequal(rawget(M,"UnitTypography"),signatureOwner) and rawequal(rawget(signatureOwner,"ReplacementSignature"),signatureMethod) then
        local ok,value=pcall(signatureMethod,signatureOwner)
        if ok and type(value)=="string" and #value==9 and not value:find("[^01]") and
            rawequal(rawget(M,"UnitTypography"),signatureOwner) and rawequal(rawget(signatureOwner,"ReplacementSignature"),signatureMethod) then ordinary=value
        else ordinary="000000000" end
    end
    for i,unit in ipairs(units) do
        local name=unitNames[unit];local root=rawget(_G,name)
        if not rawequal(observedRoots[name],root) then observedRoots[name]=root;queueUnitBoundary(name) end
        bits[#bits+1]=ordinary and ordinary:sub(i,i) or (self:Replacement(unit) and "1" or "0")
    end
    bits[#bits+1]=self:GroupReplacement("party") and "1" or "0"
    bits[#bits+1]=self:GroupReplacement("raid") and "1" or "0"
    return table.concat(bits)
end
function N:Configure()
    local observedEditor=editorState()
    if observedEditor=="UNKNOWN" then self.status.EditMode="NATIVE_EDIT_UNKNOWN";return end
    if S:InCombat() then
        self.status.CentralCooldowns=M:ModuleConfig("Cooldowns").centralGroup and "SUSPENDED_COMBAT" or "LEGACY"
        return
    end
    self.nativeEditorState=observedEditor;self.nativeEditing=observedEditor=="OPEN"
    self.reconcilePending=nil;self.replacementSignature=self:ReplacementSignature()
    if not M.Managed:Enabled() or M.Native:Conflict() then
        self.status.CentralCooldowns="INACTIVE_NATIVE_AUTHORITY";self:RestoreAll(true)
        if M.ManagedActionHover then M.ManagedActionHover:Configure() end
        return
    end
    if M.NativeActionLayout then M.NativeActionLayout:Install() end
    local w,h=M.AdaptiveLayout:Screen()
    if not w then
        self.status.CentralCooldowns="VIEWPORT_UNAVAILABLE"
        if M.ManagedActionHover then M.ManagedActionHover:Configure() end
        return
    end
    -- Packing is setup/resize work, not repeated frame maintenance.
    local profile=M.profile;local hudConfig=M:ModuleConfig("UnderCharacterHUD")
    local selected=M:ModuleConfig("Cooldowns").centralGroup==true
    local manual=selected and not profile.autoLayout
    local active=selected and profile.autoLayout and hudConfig.layoutOrder==2
    local reference=M:ModuleConfig("UnitFrames").referenceLayout
    local signature=M.AdaptiveLayout:Signature(w,h,hudConfig,active,reference)
    local plan=M.AdaptiveLayout.plan or self.cachedPlan
    -- Strict provenance for grouped writes and transitions out of a grouped plan.
    -- Legacy/manual ungrouped behavior is not silently migrated by this feature.
    if not manual and (selected or (plan and plan.centralGroup)) then
        local owner=M.AdaptiveLayout.fingerprint==signature..":"..tostring(profile)
        plan=owner and M.AdaptiveLayout.plan or nil
        if not plan and self.cachedProfile==profile and self.cachedPlan and self.cachedPlan.requestSignature==signature then plan=self.cachedPlan end
    end
    if not plan or plan.width~=w or plan.height~=h then plan=M.AdaptiveLayout:Plan(w,h,hudConfig,active,reference) end
    self.cachedPlan=plan;self.cachedProfile=profile
    self.status.CentralCooldowns=manual and "SUSPENDED_MANUAL" or active and "PLANNED_ENVELOPES_ONLY" or selected and "REQUIRES_RESERVED_ORDER" or "LEGACY"
    if plan then plan=M:Copy(plan) end
    self.plan=plan
    local hud=M:ModuleConfig("UnderCharacterHUD")
    if not plan then
        self.status.Layout="LAYOUT_UNAVAILABLE";self.status.CentralCooldowns="LAYOUT_UNAVAILABLE";self:RestoreAll(true)
        if M.ManagedActionHover then M.ManagedActionHover:Configure() end
        return
    end
    if not M.profile.autoLayout then
        plan.native.PlayerCastingBarFrame=M.AdaptiveLayout:CastPlacement(hud,plan.scale)
    end
    -- Editor geometry and native rendering share one mapping. In manual mode
    -- missing navigation/action layouts preserve the native placement. Explicit
    -- moveNative=false also blocks automatic placement for the three nav roots.
    if M.NativeLayout then
        for name in pairs(M.NativeLayout.rootIDs or {}) do
            plan.native[name]=M.NativeLayout:Geometry(name,profile,plan.native[name])
        end
    end
    self.nativeEditing=observedEditor=="OPEN";self.nativeEditorState=observedEditor
    if self.nativeEditing then
        if M.NativeActionLayout then M.NativeActionLayout:ReleaseEditing() end
        if selected then self.status.CentralCooldowns="SUSPENDED_NATIVE_EDIT_MODE" end
        self:RestoreAll(true);self.status.EditMode="NATIVE_EDIT_MODE"
        if M.ManagedActionHover then M.ManagedActionHover:Configure() end
        return
    end
    local wanted={}
    local centralResults={};local centralRoots={PlayerCastingBarFrame=_G.PlayerCastingBarFrame}
    local function cooldownReady(name)
        local frame=_G[name];centralRoots[name]=frame
        if not S:Frame(frame,false) then return false end
        local row=self.rows[name]
        if row and row.frame==frame and (row.contested or row.failed or row.restorePending) then return false end
        local width,ws=S:Public(frame.GetWidth,"number",frame);local height,hs=S:Public(frame.GetHeight,"number",frame)
        local geometry=plan.native[name]
        return ws=="KNOWN" and hs=="KNOWN" and width>0 and height>0 and geometry and
            math.min(geometry.maxW/width,geometry.maxH/height,1.2)>=.45
    end
    local function centralCurrent()
        local sw,sh=M.AdaptiveLayout:Screen()
        if sw~=w or sh~=h or M.profile~=profile or self.plan~=plan or S:InCombat() or
            not M.Managed:Enabled() or M.Native:Conflict() or not M:IsModuleActive("Cooldowns") or not M:IsModuleActive("UnderCharacterHUD") or
            not M:ModuleConfig("Cooldowns").centralGroup or not M.profile.autoLayout or
            M.AdaptiveLayout:Signature(w,h,M:ModuleConfig("UnderCharacterHUD"),true,M:ModuleConfig("UnitFrames").referenceLayout)~=signature then return false end
        for name,frame in pairs(centralRoots) do if _G[name]~=frame then return false end end
        return true
    end
    local pairReady=true
    if active then
        local mainReady=cooldownReady("EssentialCooldownViewer")
        local utilityReady=cooldownReady("UtilityCooldownViewer")
        pairReady=mainReady and utilityReady
    end
    if M:IsModuleActive("ActionBars") then
        for _,name in ipairs(actions) do
            local row=self:Acquire(name,"actions","ActionBars")
            if row then
                wanted[name]=true
                local hover=M.ManagedActionHover
                local optional=hover and (row.hoverMode or hover:Requested())
                local retired=true
                if optional then
                    local ok,value=pcall(hover.Retire,hover,row);retired=ok and value==true
                    if self.rows[name]~=row or row.frame~=_G[name] or M.profile~=profile or self.plan~=plan then retired=false end
                    if not retired and self.rows[name]==row then self.status[name]="HOVER_RETIRE_UNCONFIRMED" end
                end
                -- Do not move controls under an already-started mouse press.
                -- The ordinary legacy path is unchanged when the opt-in is off.
                local released=not optional or hover:InputReleased()==true
                local current=not optional or (self.rows[name]==row and row.frame==_G[name] and M.profile==profile and self.plan==plan)
                if retired and released and current then self:Position(row,plan.native[name]) end
                if optional and self.rows[name]==row and row.frame==_G[name] and M.profile==profile and self.plan==plan
                    and (row.contested or row.failed or row.restorePending) then wanted[name]=nil end
                current=not optional or (self.rows[name]==row and row.frame==_G[name] and M.profile==profile and self.plan==plan
                    and row.active and not row.failed and not row.restorePending)
                if current then self:SkinActions(row) end
                if current and M.NativePresentation then M.NativePresentation:Apply(row) end
            end
        end
        for _,name in ipairs(controls) do
            local row=self:Acquire(name,"controls","ActionBars")
            if row then
                wanted[name]=true
                if not delegated(name) then self:Position(row,plan.native[name]) end
                if M.NativePresentation then M.NativePresentation:Apply(row) end
            end
        end
    end
    -- Interactive native unit roots are hidden only after their secure Mirage
    -- replacement has been constructed and has a successful health display sink.
    for name,unit in pairs({PlayerFrame="player",TargetFrame="target",FocusFrame="focus",PetFrame="pet"}) do
        local receipt=replacementReceipt(unit)
        if receipt then local row=self:Acquire(name,"replace","UnitFrames",receipt);if row then wanted[name]=true end end
    end
    for i=1,5 do
        local name="Boss"..i.."TargetFrame"
        local receipt=replacementReceipt("boss"..i)
        if _G[name] and receipt then local row=self:Acquire(name,"replace","UnitFrames",receipt);if row then wanted[name]=true end end
    end
    -- Party and raid are independent providers. Object allocation alone is not
    -- a usable replacement: require successful health sinks from the active path.
    for name,kind in pairs({PartyFrame="party",CompactRaidFrameContainer="raid"}) do
        local ready,receipt=self:GroupReplacement(kind)
        if ready then
            local row=self:Acquire(name,"replace","PartyRaid",receipt);if row then wanted[name]=true end
        end
    end
    -- Navigation/task/aura roots are moved, not removed. Existing CVE adapters
    -- still handle their public visibility and native aura content stays native.
    local moduleFor={PlayerCastingBarFrame="UnderCharacterHUD",MinimapCluster="Minimap",ChatFrame1="Chat",ObjectiveTrackerFrame="QuestTracker",BuffFrame="Auras",DebuffFrame="Auras",EssentialCooldownViewer="Cooldowns",UtilityCooldownViewer="Cooldowns",BuffIconCooldownViewer="Cooldowns",BuffBarCooldownViewer="Cooldowns"}
    for name,id in pairs(moduleFor) do
        if M.ContextualNative and M.ContextualNative:Handles(name) then
            -- The contextual aura adapter owns only the visibility parent;
            -- NavigationStyle owns scale. Do not create a competing adopt lease.
            local row=self.rows[name]
            if row and (row.active or row.restorePending) then self:Restore(name,true) end
        elseif M:IsModuleActive(id) then
            local pair=name=="EssentialCooldownViewer" or name=="UtilityCooldownViewer"
            local member=pair or name=="PlayerCastingBarFrame"
            if id=="Cooldowns" then
                -- Context concealment is independent from optional central
                -- placement. A manual/cold viewer receives only its visibility
                -- gate; its current native position remains untouched.
                local row=self:Acquire(name,"cooldowns",id)
                if row then
                    wanted[name]=true
                    local placed
                    if not (pair and (manual or (active and not pairReady))) and (not (active and member) or (centralCurrent() and row.frame==centralRoots[name])) then
                        placed=self:Position(row,plan.native[name])
                    end
                    if active and member then centralResults[name]=placed==true end
                end
            elseif (pair and (manual or (active and not pairReady))) or (active and member and not centralCurrent()) then
                -- Preserve warm manual/native fallback placement. A cold manual
                -- session must not acquire or reconstruct an unsaved native layout.
                local row=self.rows[name];if row and row.active then wanted[name]=true end
            else
                local row=self:Acquire(name,"adopt",id)
                if row then
                    wanted[name]=true
                    local placed
                    local polished=M.NavigationStyle and M.NavigationStyle:Handles(name)
                    if polished then placed=true
                    elseif not (active and member) or (centralCurrent() and row.frame==centralRoots[name]) then placed=self:Position(row,plan.native[name]) end
                    if active and member then centralResults[name]=placed==true end
                    if name=="PlayerCastingBarFrame" and M.NativePresentation then M.NativePresentation:Apply(row) end
                end
            end
        end
    end
    if active then
        local current=pairReady
        -- A live lease alone proves no geometry. Recheck only public root
        -- configuration we wrote, never native children, text or cooldown data.
        for _,name in ipairs({"EssentialCooldownViewer","UtilityCooldownViewer","PlayerCastingBarFrame"}) do
            local frame=centralRoots[name];local row=self.rows[name];local geometry=plan.native[name]
            if not centralResults[name] or not frame or _G[name]~=frame or not row or row.frame~=frame or
                row.contested or row.failed or row.restorePending or not same(points(frame),row.writtenPoints) then current=false
            else
                local scale,ss=S:Public(frame.GetScale,"number",frame)
                local width,ws=S:Public(frame.GetWidth,"number",frame);local height,hs=S:Public(frame.GetHeight,"number",frame)
                if ss~="KNOWN" or ws~="KNOWN" or hs~="KNOWN" or not near(scale,row.writtenScale,.00001) or width<=0 or height<=0 or
                    width*scale>geometry.maxW+.001 or height*scale>geometry.maxH+.001 or parentOf(frame)~=(row.gate or row.layoutNativeParent or row.originalParent) then current=false end
            end
        end
        current=current and centralCurrent()
        self.status.CentralCooldowns=current and "ROOT_ENVELOPES_SUBMITTED_NATIVE_NOT_RUN" or "PARTIAL_UNAVAILABLE"
    end
    for name,row in pairs(self.rows) do if row.active and not wanted[name] then self:Restore(name,true) end end
    if M.ManagedActionHover then M.ManagedActionHover:Configure() end
    self:RecoveryButton();self:Tick()
end
local function contextualGateTick(self,name,row,open,now)
    local profile,rows,frame,gate=M.profile,self.rows,row.frame,row.gate
    local function owns()
        return M.ManagedNative==N and M.Safety==S and M.profile==profile and self.rows==rows and rows[name]==row
            and row.frame==frame and _G[name]==frame and row.gate==gate and row.active
    end
    local function gateWritable()
        return owns() and not S:InCombat() and gate and treeUsable(gate) and owns() and not S:InCombat()
    end
    local function revealDebt(reason)
        if not owns() then return false end
        row.restorePending=true;self.status[name]=reason
        -- An unreadable native child cannot authorize a hide or reparent. The
        -- independently public parent is revealed first and cleanup stays due.
        if gateWritable() then
            pcall(gate.SetAttribute,gate,"mirage-emergency",true)
            if gateWritable() then pcall(gate.Show,gate) end
        end
        return false
    end
    local function current()
        if not owns() or row.failed or row.contested or row.restorePending or not M.Managed:Enabled() or not M:IsModuleActive(row.module)
            or M.Native:Conflict() or S:InCombat() then return false end
        local usable,parent=self:Usable(frame)
        return usable and parent==gate and owns() and not S:InCombat()
    end
    if not current() then return revealDebt("CONTEXT_PARENT_UNAVAILABLE") end
    local hovered=S:Public(frame.IsMouseOver,"boolean",frame)
    if not current() then return revealDebt("CONTEXT_PARENT_UNAVAILABLE") end
    local shown=S:Public(gate.IsShown,"boolean",gate)
    if not current() then return false end
    if hovered and shown then row.holdUntil=now+.4 end
    if M.PresentationGroups and M.PresentationGroups:Enabled() then
        local inside,due=M.PresentationGroups:Hover(row,frame,now)
        if inside then row.holdUntil=due end
    end
    local snapshot=M.Store:Snapshot()
    local c=M.ContextualNative
    local helper=c and (row.mode=="cooldowns" and c.CooldownHeld or c.ControlHeld)
    local held,known=S:Public(helper,"boolean",c,name,snapshot,now,row.holdUntil)
    held=open or known~="KNOWN" or held==true
    if not current() then return false end
    local written,status=S:Public(gate.GetAttribute,"boolean",gate,"mirage-held")
    if not current() then return false end
    if status~="KNOWN" then return revealDebt("CONTEXT_HOLD_UNAVAILABLE") end
    if written~=held then
        if not current() then return false end
        local ok=pcall(gate.SetAttribute,gate,"mirage-held",held)
        if not current() then return false end
        local observed=S:Public(gate.GetAttribute,"boolean",gate,"mirage-held")
        if not current() then return false end
        if not ok or observed~=held then return revealDebt("CONTEXT_HOLD_UNCONFIRMED") end
    end
    row.held=held
    local state=S:Public(gate.GetAttribute,"string",gate,"mirage-state")
    if not current() then return false end
    local emergency=S:Public(gate.GetAttribute,"boolean",gate,"mirage-emergency")
    if not current() then return false end
    local hide=state=="hide" and emergency==false and not held
    local visible=S:Public(gate.IsShown,"boolean",gate)
    if not current() then return false end
    if visible~=(not hide) then
        local method=hide and gate.Hide or gate.Show
        if not current() then return false end
        local ok=pcall(method,gate)
        if not current() then return false end
        local observed=S:Public(gate.IsShown,"boolean",gate)
        if not current() then return false end
        if not ok or observed~=(not hide) then return revealDebt("CONTEXT_VISIBILITY_UNCONFIRMED") end
    end
    return true
end
function N:Tick()
    local observedEditor=editorState()
    -- An opaque observation does not synthesize an editor transition. Keep the
    -- prior lifecycle and authored state; no retry, cleanup or acquisition runs.
    if observedEditor=="UNKNOWN" then self.status.EditMode="NATIVE_EDIT_UNKNOWN";return end
    if S:InCombat() then
        if M.ManagedActionHover then M.ManagedActionHover:Tick() end
        return
    end
    if observedEditor=="OPEN" then
        if self.nativeEditorState~="OPEN" then self:Configure() end
        return
    end
    self:RetryArt()
    if not M.Managed:Enabled() or M.Native:Conflict() then
        for name,row in pairs(self.rows) do if row.active then self:Restore(name,true) end end
        return
    end
    if M.NativeActionLayout then M.NativeActionLayout:Retry() end
    -- A target first acquired after setup (or a late-loaded native window)
    -- must participate in the same ownership handoff; no broad rescan loop.
    local signature=self:ReplacementSignature()
    local editing=observedEditor=="OPEN"
    if signature~=self.replacementSignature or editing~=self.nativeEditing or self.reconcilePending then
        self:Configure();return
    end
    local now=S:Now()
    local open=(M.state.revealUntil or 0)>now or M.state.edit
    -- Only actual action assignment/flyout input may reveal action recipients.
    -- Native spellbook/settings visibility and unrelated text focus are local
    -- tasks and must not reveal cooldowns, utility bars or the action cluster.
    local cursor,cs=S:Public(GetCursorInfo,"string")
    local actionInput=cs=="KNOWN" and (cursor=="spell" or cursor=="item" or cursor=="macro" or cursor=="flyout")
    if SpellFlyout and S:Public(SpellFlyout.IsShown,"boolean",SpellFlyout)==true then actionInput=true end
    for name,row in pairs(self.rows) do
        if row.restorePending then
            if (row.restoreFailures or 0)<3 then self:Restore(name,true) end
        elseif row.active and (row.mode=="controls" or row.mode=="cooldowns") then
            contextualGateTick(self,name,row,open,now)
        elseif row.active and row.mode=="actions" and not row.hoverMode then
            local hovered=S:Public(row.frame.IsMouseOver,"boolean",row.frame)
            if hovered and S:Public(row.gate.IsShown,"boolean",row.gate)==true then row.holdUntil=now+.4 end
            if M.PresentationGroups and M.PresentationGroups:Enabled() then
                local inside,due=M.PresentationGroups:Hover(row,row.frame,now)
                if inside then row.holdUntil=due end
            end
            local snapshot=M.Store:Snapshot()
            local id=M.NativeLayout and M.NativeLayout.rootIDs[name]
            local preference=M.ElementRules and id and M.ElementRules:Preference(id,snapshot)
            local cfg=M:ModuleConfig(row.module)
            local input=actionInput and cfg.allowRearrange==true or (row.holdUntil or 0)>now
            local hold=open or input or preference=="SHOW" or cfg.contextual~=true or (cfg.visibility=="Always" and preference~="HIDE")
            if M.PresentationGroups and M.PresentationGroups:Enabled() and M.ScopedActivity then
                hold=hold or M.ScopedActivity:Demand("COMBAT",snapshot,now)~=false
            end
            if not open and not input and (preference=="HIDE" or cfg.visibility=="Manual") then hold=false end
            if row.held~=hold then
                row.held=hold;row.gate:SetAttribute("mirage-held",hold==true)
                local state=S:Public(row.gate.GetAttribute,"string",row.gate,"mirage-state")
                if hold or state=="show" or row.gate:GetAttribute("mirage-emergency") then row.gate:Show()
                elseif state=="hide" then row.gate:Hide() end
            end
        end
    end
    if M.ManagedActionHover then M.ManagedActionHover:Tick() end
end
local function unitGateState(self,row,reset)
    if not row.active or not row.gate or unitWriting[row.name] then return false end
    local g=newGuard(row.name,row.frame,row,nil);unitWriting[row.name]=g
    local ok,result=pcall(function()
        local gate=row.gate;local receipt=row.unitReceipt
        local owner=admissionOwner(unitForName[row.name],receipt)
        if reset and not guardedCall(g,gate,"SetAttribute",true,"mirage-emergency",false) then return false end
        local state=publicRead(g,gate,"GetAttribute","string","mirage-state")
        local held=publicRead(g,gate,"GetAttribute","boolean","mirage-held")
        local emergency=publicRead(g,gate,"GetAttribute","boolean","mirage-emergency")
        if not guardCurrent(g) then return false end
        local hide=not row.restorePending and state=="hide" and held==false and emergency==false
            and owner and rawequal(row.unitReceipt,receipt) and owner()
        if hide then
            -- The hiding writer seals eligibility again after its own security
            -- and combat probes; a getter cannot renew a retired unit receipt.
            g.owner=function() return rawequal(rawget(row,"unitReceipt"),receipt) and owner() end
            if guardedCall(g,gate,"Hide",true) then return true end
            -- A failed final eligibility guard cannot authorize a stale hide.
            g.owner=nil
        end
        return guardedCall(g,gate,"Show",true)
    end)
    if unitWriting[row.name]==g then unitWriting[row.name]=nil end
    return ok and result==true
end
-- Ordinary group gate writers are request-bound. This does not change the
-- legacy admission path or the independently evaluated secure state program.
local function groupGateState(self,row,reset)
    if not rawequal(self,N) then return false end
    local name=type(row)=="table" and rawget(row,"name")
    if not groupRoots[name] or not rawequal(rawget(self.rows,name),row)
        or rawget(row,"module")~="PartyRaid" or rawget(row,"mode")~="replace"
        or rawget(row,"active")~=true or not rawget(row,"gate") then return false end
    -- Acquisition already serializes against gate writers; honor the reverse
    -- direction too, before allocating an epoch or a second dispatch request.
    if groupAcquireWriting[name] then return false end
    if groupRestoreDebt[name] or groupDispatchDebt[name] or rawget(row,"restorePending") then return self:Restore(name,not reset) end
    local method=rawget(self,"GroupReplacement")
    local producerReceipt
    local request
    local function owner()
        return (not request or not request.retired) and rawget(row,"name")==name and rawget(row,"module")=="PartyRaid"
            and rawget(row,"mode")=="replace" and rawget(row,"active")==true
            and not rawget(row,"restorePending") and not groupRestoreDebt[name] and not groupDispatchDebt[name]
            and rawequal(rawget(_G,name),rawget(row,"frame"))
    end
    local function filteredOwner()
        return owner() and not rawget(row,"contested") and not rawget(row,"failed")
            and rawequal(rawget(self,"GroupReplacement"),method)
            and groupReceiptCurrent(producerReceipt)
    end
    local g=newGuard(name,row.frame,row,owner)
    if groupGateWriting[name] or groupRestoreWriting[name] then return false end
    -- Retain a separate cleanup guard: ordinary request retirement must stop
    -- future writes without invalidating the original handback snapshot.
    request=groupAcquireRequest(name,self.rows,row)
    request.restoreEntry=rawget(N,"Restore")
    if type(request.restoreEntry)~="function" then return false end
    request.cleanupGuard={}
    for key,value in pairs(g) do request.cleanupGuard[key]=value end
    request.cleanupGuard.owner=function() return groupAcquireOwner(request) end
    g.dispatch=request
    groupGateWriting[name]=g
    local function enteredGate(key,...)
        if request.retired or not groupDispatchCurrent(request) or not guardCurrent(g) then return false end
        -- This window includes the callback-bearing pre-dispatch checks. If
        -- they request Restore, the guard cancels actual dispatch and cleanup
        -- still waits until this window has unwound.
        request.inflight=true
        local result=pack(pcall(guardedCall,g,row.gate,key,true,...))
        request.inflight=false
        if not result[1] or request.retired then return false end
        return unpack(result,2,result.n)
    end
    local ok,result=pcall(function()
        local gate=row.gate
        if publicRead(g,gate,"GetAttribute","string","_onstate-mirage")~=stateProgram
            or not rawequal(publicRead(g,row.frame,"GetParent",nil),gate) then return false end
        local resetReady=not reset
        if reset and type(method)=="function" then
            local good,ready,receipt=pcall(method,self,name=="PartyFrame" and "party" or "raid")
            producerReceipt=receipt
            resetReady=good and ready==true and groupReceiptCurrent(receipt)
                and rawequal(rawget(self,"GroupReplacement"),method) and guardCurrent(g)
        end
        -- An unavailable replacement must not release an existing emergency
        -- latch merely because Resume was requested. This remains a filter,
        -- not a promise about later independently evaluated secure transitions.
        if resetReady and reset then
            g.owner=filteredOwner
            local cleared=enteredGate("SetAttribute","mirage-emergency",false)
                and publicRead(g,gate,"GetAttribute","boolean","mirage-emergency")==false
            g.owner=owner
            if not cleared then
                return guardedCall(g,gate,"Show",true) and publicRead(g,gate,"IsShown","boolean")==true
            end
        end
        local state=publicRead(g,gate,"GetAttribute","string","mirage-state")
        local held=publicRead(g,gate,"GetAttribute","boolean","mirage-held")
        local emergency=publicRead(g,gate,"GetAttribute","boolean","mirage-emergency")
        if not guardCurrent(g) then return false end
        if resetReady and state=="hide" and held==false and emergency==false and type(method)=="function" then
            -- Bind owned producer identities and paint generation through the
            -- later callback-bearing dispatch probes. Future secure transitions
            -- still require separate native qualification.
            local good,ready,receipt=pcall(method,self,name=="PartyFrame" and "party" or "raid")
            producerReceipt=receipt
            if good and ready==true and groupReceiptCurrent(receipt)
                and rawequal(rawget(self,"GroupReplacement"),method) and guardCurrent(g) then
                g.owner=filteredOwner
                local hidden=enteredGate("Hide") and publicRead(g,gate,"IsShown","boolean")==false
                g.owner=owner
                if hidden then return true end
            end
        end
        return guardedCall(g,gate,"Show",true) and publicRead(g,gate,"IsShown","boolean")==true
    end)
    -- Preserve the writer lock through the one automatic post-unwind attempt.
    -- Errors/displacement may retain debt but never poison this lock.
    pcall(function()
        if request.cleanupRequested and request.retired and not request.inflight
            and groupDispatchCurrent(request) and guardCurrent(request.cleanupGuard) then
            groupRestoreSource(N,name,true)
        end
    end)
    if groupGateWriting[name]==g then groupGateWriting[name]=nil end
    return ok and result==true and guardCurrent(g)
end
function N:ApplyGateState(row)
    local dispatchName=groupDispatchForRow(row)
    if dispatchName and (rawget(row,"name")~=dispatchName
        or not rawequal(row,groupDispatchDebt[dispatchName].row)) then return false end
    if groupRoots[row.name] then return groupGateState(self,row,false) end
    if row.module=="UnitFrames" and row.mode=="replace" then return unitGateState(self,row,false) end
    if not row.active or not row.gate or S:InCombat() then return end
    if row.hoverMode and M.ManagedActionHover then return M.ManagedActionHover:Tick() end
    local gate=row.gate
    if row.restorePending then gate:Show();return end
    local state=S:Public(gate.GetAttribute,"string",gate,"mirage-state")
    local held=S:Public(gate.GetAttribute,"boolean",gate,"mirage-held")
    local emergency=S:Public(gate.GetAttribute,"boolean",gate,"mirage-emergency")
    -- Only a known quiet state grants hiding authority; unknown keeps access.
    if state=="hide" and held==false and emergency==false then gate:Hide() else gate:Show() end
end
function N:ResetEmergency()
    if not rawequal(self,N) then return false end
    if S:InCombat() then return false end
    if M.ManagedActionHover then M.ManagedActionHover:ResetFailures() end
    if self.recovery then self.recovery:SetAttribute("mirage-emergency",false) end
    local hoverChanged=false
    for name,row in pairs(self.rows) do
        -- A previous group dispatch may have entered combat before returning.
        -- Do not continue Resume into another row's ordinary native writers.
        if S:InCombat() then return false end
        local dispatchName=groupDispatchForRow(row)
        if dispatchName then
            self:Restore(dispatchName,false)
        elseif groupRoots[name] and groupRestoreDebt[name] then
            -- Explicit Resume may retry cleanup, but cannot clear its latch
            -- and re-hide a row whose prior handback is still unconfirmed.
            self:Restore(name,false)
        elseif groupRoots[name] then
            local held,failed,failures=rawget(row,"held"),rawget(row,"failed"),rawget(row,"restoreFailures")
            if groupGateState(self,row,true) and rawequal(rawget(self.rows,name),row)
                and rawequal(rawget(row,"held"),held) and rawequal(rawget(row,"failed"),failed)
                and rawequal(rawget(row,"restoreFailures"),failures) then
                rawset(row,"held",nil);rawset(row,"failed",nil);rawset(row,"restoreFailures",0)
            end
        elseif row.module=="UnitFrames" and row.mode=="replace" then
            if unitGateState(self,row,true) then row.held=nil;row.failed=nil;row.restoreFailures=0 end
        else
            if row.gate then
                row.gate:SetAttribute("mirage-emergency",false);row.held=nil
                if row.hoverMode and M.ManagedActionHover then hoverChanged=true else self:ApplyGateState(row) end
            end
            row.failed=nil;row.restoreFailures=0
        end
    end
    if S:InCombat() then return false end
    if hoverChanged then M.ManagedActionHover:Tick() end
    return true
end
function N:OwnershipReport()
    -- Fixed roots and category-only public geometry. No unit text, action
    -- identifiers, cooldown contents or protected driver state is inspected.
    local lines={}
    local codes={NATIVE_FALLBACK=true,CONTEXT_HANDOFF_PENDING=true,PARENT_UNAVAILABLE=true,NEWER_OWNER=true,
        HOVER_POLICY_FAILED_NATIVE_RESTORED=true,RESTORE_RELOAD_REQUIRED=true,LEASE_LIMIT=true,ADOPTED_NATIVE=true,NATIVE_GEOMETRY_DELEGATED=true,NATIVE_GEOMETRY_RELOAD_REQUIRED=true,
        CONTEXT_GATE_PREPARATION_DEFERRED=true,HANDOFF_FAILED_NATIVE_RESTORED=true,MANAGED_CANDIDATE=true,
        LAYOUT_REQUEST_RETIRED=true,ANCHOR_UNAVAILABLE=true,NATIVE_SIZE_UNAVAILABLE=true,NEWER_LAYOUT_PRESERVED=true,
        NATIVE_LAYOUT_FALLBACK=true,POSITION_FAILED_NATIVE_RESTORED=true,RESTORE_AFTER_COMBAT=true,RESTORED=true,
        ART_RESTORE_PENDING=true,ART_RESTORE_RELOAD_REQUIRED=true,ART_RESTORED=true,ART_OWNED=true,HOVER_RETIRE_UNCONFIRMED=true,
        RESTORE_AFTER_INPUT=true,CONTEXT_PARENT_UNAVAILABLE=true,CONTEXT_HOLD_UNAVAILABLE=true,CONTEXT_HOLD_UNCONFIRMED=true,CONTEXT_VISIBILITY_UNCONFIRMED=true,
        REFLOW_STATE_CHANGED=true,REFLOW_PARENT_CHANGED=true,REFLOW_POINTS_UNMATCHED=true,REFLOW_SCALE_UNMATCHED=true,REFLOW_LOGICAL_SIZE_CHANGED=true,
        REFLOW_SIZE_UNMATCHED=true,NATIVE_OUTPUT_QUALIFIED=true,NATIVE_REFLOW_RECONCILED=true,NATIVE_SYSTEM_ANCHOR_UNAVAILABLE=true,
        NATIVE_WRITER_CHANGED=true,NATIVE_CAST_OUTPUT_UNAVAILABLE=true,NATIVE_OUTPUT_UNAVAILABLE=true,
        NATIVE_REFLOW_QUEUED=true,NATIVE_EDIT_OUTPUT_OBSERVED=true,NATIVE_EDIT_SUSPENDED=true,NATIVE_EDIT_REACQUIRED=true,
        NATIVE_EDIT_REACQUIRE_PENDING=true,NATIVE_EDIT_RELEASE_PENDING=true,NATIVE_EDIT_OWNER_CHANGED=true}
    local function code(value) return S:Text(value) and codes[value] and value or "UNAVAILABLE" end
    local function flag(value)
        if not S:Readable(value) then return "UNAVAILABLE" end
        if value==true then return "true" end
        if value==false or value==nil then return "false" end
        return "UNAVAILABLE"
    end
    for _,name in ipairs({"MainActionBar","MultiBarBottomLeft","MultiBarBottomRight","MultiBarRight","MultiBarLeft","MultiBar5","MultiBar6","MultiBar7",
        "PetActionBar","StanceBar","BagsBar","MicroMenuContainer","MainStatusTrackingBarContainer","SecondaryStatusTrackingBarContainer","PlayerCastingBarFrame"}) do
        local row=self.rows[name];local parentState,pointState,scaleState,sizeState="UNAVAILABLE","UNAVAILABLE","UNAVAILABLE","UNAVAILABLE"
        if row and _G[name]==row.frame and S:Frame(row.frame,false) then
            local parent,ps=S:Public(row.frame.GetParent,nil,row.frame)
            if ps=="KNOWN" then parentState=parent==row.gate and "LEASE_GATE" or parent==(row.layoutNativeParent or row.originalParent) and "NATIVE_PARENT" or "OTHER_PARENT" end
            local observed=points(row.frame)
            if observed then pointState=not row.writtenPoints and "UNAUTHORED" or same(observed,row.writtenPoints) and "MATCHED" or "DIFFERENT" end
            local scale,ss=S:Public(row.frame.GetScale,"number",row.frame)
            if ss=="KNOWN" then scaleState=not row.writtenScale and "UNAUTHORED" or near(scale,row.writtenScale,.00001) and "MATCHED" or "DIFFERENT" end
            local w,ws=S:Public(row.frame.GetWidth,"number",row.frame);local h,hs=S:Public(row.frame.GetHeight,"number",row.frame)
            if ws=="KNOWN" and hs=="KNOWN" then sizeState=not row.layoutSize and "UNAUTHORED" or sameSize({w,h},row.layoutSize) and "MATCHED" or "DIFFERENT" end
        end
        local reflow=M.NativeActionLayout and M.NativeActionLayout.roots
        lines[#lines+1]="native_ownership."..name.."="..code(self.status[name])..";active="..flag(row and row.active)..";contested="..flag(row and row.contested)
            ..";failed="..flag(row and row.failed)..";restorePending="..flag(row and row.restorePending)..";nativeEditSuspended="..flag(row and row.editSuspended)..";parent="..parentState
            ..";points="..pointState..";scale="..scaleState..";size="..sizeState..";reflow="..code(reflow and reflow[name])
    end
    return table.concat(lines,"\n")
end
function N:Report()
    local keys,lines={},{"native.unrelatedAddonSetupsSkipped="..(self.unrelatedAddonSkips or 0)}
    for name in pairs(self.status) do keys[#keys+1]=name end;table.sort(keys)
    for _,name in ipairs(keys) do lines[#lines+1]="native."..name.."="..self.status[name] end
    if M.NativeActionLayout then lines[#lines+1]="native.layoutObserver="..M.NativeActionLayout.status end
    local presentation=M.NativePresentation and M.NativePresentation.status or {}
    local styled={};for name in pairs(presentation) do styled[#styled+1]=name end;table.sort(styled)
    for _,name in ipairs(styled) do lines[#lines+1]="native.presentation."..name.."="..presentation[name] end
    return table.concat(lines,"\n")
end
-- Only this user-consented preference is written; global UI scale and keybinds
-- are never changed. A newer external/user value wins over our restoration.
function N:ResourcePreference(enable)
    if S:InCombat() then return false end
    local get=(C_CVar and C_CVar.GetCVar) or GetCVar
    local set=(C_CVar and C_CVar.SetCVar) or SetCVar
    if type(get)~="function" or type(set)~="function" or not M.Profiles.account then return false end
    local store=M.Profiles.account
    local current,status=S:Public(get,"string","nameplateShowSelf")
    if status~="KNOWN" then return false end
    if enable then
        if not M.Presentation:Available("UnderCharacterHUD","health") then return self:ResourcePreference(false) end
        if not store.managedPRD then store.managedPRD={original=current,written="0"} end
        -- A later intentional CVar change is not continually fought.
        if store.managedPRD.applied and current~="0" then self.status.PersonalResourceDisplay="NEWER_PREFERENCE";return false end
        if store.managedPRD.applied and current=="0" then return true end
        local ok=pcall(set,"nameplateShowSelf","0")
        if ok and S:Public(get,"string","nameplateShowSelf")=="0" then store.managedPRD.applied=true;self.status.PersonalResourceDisplay="HUD_PRIMARY";return true end
        self.status.PersonalResourceDisplay="NATIVE_PREFERENCE_FALLBACK";return false
    end
    local record=store.managedPRD
    if not record then return true end
    if current==record.written then
        if not pcall(set,"nameplateShowSelf",record.original) then return false end
        if S:Public(get,"string","nameplateShowSelf")~=record.original then return false end
    end
    store.managedPRD=nil;self.status.PersonalResourceDisplay="RESTORED_OR_NEWER_PREFERENCE";return true
end

-- Root/release observations only schedule a bounded existing request drain. They
-- are not readiness receipts, and never measure text or run inside a native writer.
local typography=M.UnitTypography
local nativeReleased=typography and typography.NativeReleased
local drainReleased=typography and typography.DrainReleased
local notifying
local function notifyUnitBoundaries()
    if notifying or next(unitWriting) or S:InCombat() then return end
    if type(nativeReleased)~="function" or type(drainReleased)~="function" or M.UnitTypography~=typography
        or typography.NativeReleased~=nativeReleased or typography.DrainReleased~=drainReleased then return end
    notifying=true
    local pending=releaseNotifications;releaseNotifications={}
    for _,unit in ipairs({"player","target","focus","pet","boss1","boss2","boss3","boss4","boss5"}) do
        if M.UnitTypography~=typography or typography.NativeReleased~=nativeReleased or typography.DrainReleased~=drainReleased then notifying=nil;return end
        local row=pending[unit]
        if row then pcall(nativeReleased,typography,unit,row.root) end
    end
    if M.UnitTypography==typography and typography.NativeReleased==nativeReleased and typography.DrainReleased==drainReleased then pcall(drainReleased,typography) end
    notifying=nil
end
local configureUnits,tickUnits=N.Configure,N.Tick
-- Loading a Blizzard panel does not usually replace any managed gameplay
-- root. Observe the bounded named roots instead of rebuilding every action,
-- aura, unit and navigation lease for each unrelated ADDON_LOADED event.
-- This receipt suppresses setup work only; it never authorizes a native write.
local lifecycleRoots
local lifecycleNames={"PlayerFrame","TargetFrame","FocusFrame","PetFrame","PartyFrame","CompactRaidFrameContainer",
 "PlayerCastingBarFrame","MinimapCluster","ChatFrame1","ObjectiveTrackerFrame","BuffFrame","DebuffFrame",
 "EssentialCooldownViewer","UtilityCooldownViewer","BuffIconCooldownViewer","BuffBarCooldownViewer"}
for _,name in ipairs(actions) do lifecycleNames[#lifecycleNames+1]=name end
for _,name in ipairs(controls) do lifecycleNames[#lifecycleNames+1]=name end
for i=1,5 do lifecycleNames[#lifecycleNames+1]="Boss"..i.."TargetFrame" end
local function captureLifecycleRoots()
 local profile,rows=M.profile,N.rows
 local names,values={},{}
 for _,name in ipairs(lifecycleNames) do names[name]=true end
 for name in pairs(M.NativeLayout and M.NativeLayout.rootIDs or {}) do names[name]=true end
 for name in pairs(rows) do names[name]=true end
 for name in pairs(names) do
  local value=rawget(_G,name)
  if not S:Readable(value) then return nil end
  values[name]=value
 end
 if M.ManagedNative~=N or N.rows~=rows or M.profile~=profile then return nil end
 return {profile=profile,rows=rows,names=names,values=values}
end
function N:OnNativeAddonLoaded()
 local old=lifecycleRoots
 local fresh=captureLifecycleRoots()
 local same=old and fresh and old.profile==fresh.profile and old.rows==fresh.rows
 if same then
  for name in pairs(fresh.names) do if not old.names[name] or fresh.values[name]~=old.values[name] then same=false;break end end
  if same then for name in pairs(old.names) do if not fresh.names[name] then same=false;break end end end
 end
 if same then self.unrelatedAddonSkips=(self.unrelatedAddonSkips or 0)+1;return false end
 self.reconcilePending=true;return true
end
function N:Configure(...)
    local result=pack(pcall(configureUnits,self,...));notifyUnitBoundaries()
    if not result[1] then error(result[2],0) end
    if not S:InCombat() and editorState()=="CLOSED" then lifecycleRoots=captureLifecycleRoots() end
    return unpack(result,2,result.n)
end
function N:Tick(...)
    local result=pack(pcall(tickUnits,self,...));notifyUnitBoundaries()
    if not result[1] then error(result[2],0) end
    return unpack(result,2,result.n)
end
