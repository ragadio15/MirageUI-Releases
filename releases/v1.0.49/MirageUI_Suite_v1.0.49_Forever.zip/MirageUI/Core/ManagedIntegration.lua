local _,M=...
local S=M.Safety
-- Adopt the game's action renderer in automatic mode instead of stacking a
-- second 36-button implementation on the same action slots. Advanced legacy
-- mode retains its existing independent implementation.
local A=M.modules.ActionBars
local initialize,resume,configure,suspend,tick=A.Initialize,A.Resume,A.ApplyConfig,A.Suspend,A.Tick
local function stopSupplement()
    if S:InCombat() then return end
    for _,bar in pairs(A.bars) do
        if UnregisterStateDriver then UnregisterStateDriver(bar,"visibility");UnregisterStateDriver(bar,"page") end
        bar:Hide()
    end
end
function A:Initialize()
    if M.profile.managed then self.status="NATIVE_ACTION_RENDERER_MANAGED";self.nativeMode=true;return end
    self.nativeMode=false;return initialize(self)
end
function A:Resume()
    if M.profile.managed then
        stopSupplement();self.nativeMode=true;self.pendingDisable=nil;self.status="NATIVE_ACTION_RENDERER_MANAGED";return
    end
    if self.nativeMode and next(self.bars)==nil then self.nativeMode=false;return initialize(self) end
    self.nativeMode=false;return resume(self)
end
function A:ApplyConfig()
    if M.profile.managed then stopSupplement();return end
    return configure(self)
end
function A:Suspend()
    if self.nativeMode then
        for _,name in ipairs(M.ManagedNative.actionNames) do M.ManagedNative:Restore(name) end
        self.pendingDisable=S:InCombat() or nil
    end
    return suspend(self)
end
function A:Tick()
    if not self.nativeMode then return tick(self) end
end
-- Restore native leases along with the existing module recovery machinery.
local restore=M.Native.Restore
function M.Native:Restore(module)
    if module then M.ManagedNative:RestoreModule(module) else M.ManagedNative:RestoreAll() end
    return restore(self,module)
end
-- Quiet self/pet buttons use predeclared native conditions. Current combat
-- values never determine these decisions. Target/focus and grouped access keep
-- their existing unit-watch contracts.
local units=M.modules.UnitFrames
local unitConfig,unitSuspend=units.ApplyConfig,units.Suspend
local unitDrivers={
    player="[petbattle] hide; [vehicleui] hide; [overridebar] hide; [combat] show; [@target,exists] show; hide",
    pet="[petbattle] hide; [vehicleui] hide; [@pet,noexists] hide; [combat] show; [@target,exists] show; hide",
}
function units:ApplyConfig()
    unitConfig(self)
    -- Ordinary typography owns both the unit-watch and the unchanged player/pet
    -- visibility submission. Never bypass its admission with a second register.
    if M.UnitTypography then return end
    if S:InCombat() then return end
    for unit,expression in pairs(unitDrivers) do
        local v=self.views[unit]
        if v then
            if M.profile.managed and type(RegisterStateDriver)=="function" then
                UnregisterUnitWatch(v.frame)
                local ok=pcall(RegisterStateDriver,v.frame,"visibility",expression)
                if ok then v.managedVisibility=true
                else RegisterUnitWatch(v.frame);v.managedVisibility=nil end
            elseif v.managedVisibility then
                UnregisterStateDriver(v.frame,"visibility");RegisterUnitWatch(v.frame);v.managedVisibility=nil
            end
        end
    end
end
function units:Suspend()
    if not S:InCombat() then
        for _,v in pairs(self.views) do
            if v.managedVisibility then UnregisterStateDriver(v.frame,"visibility");v.managedVisibility=nil end
        end
    end
    return unitSuspend(self)
end
