local _,M=...
-- P13 revision: large tasks and required dialogs
-- remain game-owned from their first frame. This is evaluated before legacy
-- acquisition, provider selection, tree walks, hooks and queued style work.
-- The inventory provider is the explicit exception: bags/bank retain their
-- existing native transaction controllers with Mirage presentation.
-- Shared tooltips now use the coordinated Mirage/Insight presentation; their
-- original controllers still own content, comparison placement and input.
local P={revision=36,reason="NATIVE_BY_DESIGN",
 providers={tasks=true,maps=true,character=true,system=true},
 modules={BlizzardSkin=true}}
M.NativeWindowPolicy=P
function P:ProviderNative(id) return self.providers[id]==true end
function P:ModuleNative(id) return self.modules[id]==true end
function P:AllowsProvider(id) return not self:ProviderNative(id) end
function P:AllowsModule(id) return not self:ModuleNative(id) end
function P:Reason(id)
 if self:ProviderNative(id) or self:ModuleNative(id) then return self.reason end
end
-- Purposefully no discovery of arbitrary UIParent descendants. An unlisted
-- game task is native by default because no blanket window skinner is admitted.
-- Owned Mirage settings/help and inventory are separate, explicit providers.
