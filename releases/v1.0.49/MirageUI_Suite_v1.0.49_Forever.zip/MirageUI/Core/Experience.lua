local _,M=...
-- The player-facing experience is a reviewed preset over existing modules and
-- the existing resolver. It does not promote the research registry to native
-- approval or override protected/unknown native surfaces.
M.Experience={revision=28,offered=false,idleSince=nil}
local E,S=M.Experience,M.Safety
-- A retry is authorized only inside the current, explicit Yes transaction.
-- First-failure evidence remains intact; this is not a general activation bypass.
local preparedRetry
local function store()
 local p=M.Profiles
 if not p or p.readOnly or not p.account or not p.character then return nil end
 return p.character.useCharacter and p.character or p.account
end
function E:Offered()
 local db=store()
 return self.offered or (db and db.experienceRevision==self.revision and (db.experienceChoice=="YES" or db.experienceChoice=="NO" or db.experienceChoice=="CUSTOM")) or false
end
function E:Welcome()
 M:LoadOptions(true)
 if M.PlayerSettings then return M.PlayerSettings:Open("welcome") end
 return false
end
function E:PreviousChoice()
 local db=store();local choice=db and db.experienceChoice
 if choice=="YES" or choice=="NO" or choice=="CUSTOM" then return choice end
end
function E:KeepChoices()
 local db=store();if not db then return false,"Your saved settings are read-only." end
 db.experienceRevision=self.revision;self.offered=true;self.idleSince=nil
 return true,"Your current choices and layout are retained."
end
function E:MayRetrySetup()
 local t=preparedRetry
 return rawequal(self,E) and E.choosing==true and t~=nil
  and rawequal(M.profile,t.profile) and rawequal(M.Profiles,t.profiles)
  and rawequal(M.Client,t.client) and rawequal(M.state,t.state)
  and rawequal(store(),t.store) and M.Client.allowed==true
  and not M.Profiles.readOnly and not M.state.safe and not M.state.safeCleanupPending
  and not M.applying and not S:InCombat() or false
end
function E:Choose(yes)
 if type(yes)~="boolean" or self.choosing then return false,"The current choice is still being applied." end
 if S:InCombat() then return false,"Finish combat before changing your interface." end
 local db=store();if not db then return false,"Your saved settings are preserved. Use Help to review the recovery information." end
 local profile,profiles,client,state,managed=M.profile,M.Profiles,M.Client,M.state,M.Managed
 local function current() return store()==db and M.profile==profile and M.Profiles==profiles and M.Client==client and M.state==state and M.Managed==managed end
 if yes and (M.Native:Conflict()) then
  return false,"Disable overlapping full interface suites at character selection, then reload. Standalone MirageUI suite addons can remain enabled."
 end
 self.choosing=true
 local ok,result,message=pcall(function()
  if yes then
   if not client.allowed then
    local admitted,why=client:SetCandidate(true,true)
    if not admitted then return false,why end
   end
   if not current() then return false,"Settings changed during setup. No different profile was accepted." end
   local ready,why=M:PrepareExperienceActivation()
   if not ready then return false,why end
   if not current() then return false,"Settings changed during cleanup. Open setup again after reviewing Help." end
   preparedRetry={profile=profile,profiles=profiles,client=client,state=state,store=db}
   local accepted,reason=managed:Accept()
   preparedRetry=nil
   if not accepted then return false,reason end
  else
   local stopped,why=M:SafeMode("USER_REQUEST")
   if not stopped then return false,"MirageUI is stopped, but some cleanup is pending. Your preferences are retained; open Help before retrying." end
   if not current() then return false,"Settings changed during cleanup. No different profile was modified." end
   local p=M:Copy(profile);p.enabled=false
   local committed,reason=profiles:Commit(p,nil,"PROFILE_COMMIT")
   if not committed then return false,reason end
  end
  if store()~=db or M.Profiles~=profiles or M.Client~=client then return false,"The active settings owner changed. Reopen settings to inspect the result." end
  db.experienceRevision=self.revision;db.experienceChoice=yes and "YES" or "NO"
  self.offered=true;self.idleSince=nil;M.state.forceEvaluate=true
  if yes then
   local status=M.Diagnostics:ActivationState()
   if status.code=="RUNNING_PARTIAL" then return true,"MirageUI is enabled, but some displays could not start. Open Help and copy the support report; their original controls remain available." end
   if status.code=="RECOVERING" then return true,status.message.." "..status.help end
   return true,"Your MirageUI experience is enabled. Personalize it whenever you like."
  end
  return true,"MirageUI presentation is off. Your preferences are kept; open /mirage whenever you are ready."
 end)
 preparedRetry=nil;self.choosing=false;M.state.experiencePreparing=nil
 if not ok then M:Fault("Core","EXPERIENCE_APPLY_FAILED");return false,"Setup stopped after an unexpected application failure. Open Help and copy the support report." end
 return result,message
end
-- No is not a dead end: later customization can be enabled without replacing
-- it with the intended preset. Only this deliberate button grants source consent.
function E:ResumeChoices()
 if self.choosing or S:InCombat() then return false,"Finish combat or the current change before enabling your choices." end
 local db=store();if not db then return false,"Your settings are read-only and have been preserved." end
 if M.Native:Conflict() then return false,"Disable overlapping interface suites, then reload. Standalone MirageUI suite addons can remain enabled." end
 local profile,profiles,client,state=M.profile,M.Profiles,M.Client,M.state
 local function current() return store()==db and M.profile==profile and M.Profiles==profiles and M.Client==client and M.state==state end
 self.choosing=true
 local ok,result,message=pcall(function()
  if not client.allowed then local admitted,why=client:SetCandidate(true,true);if not admitted then return false,why end end
  if not current() then return false,"The settings owner changed; your choices were not applied." end
  local ready,why=M:PrepareExperienceActivation();if not ready then return false,why end
  if not current() then return false,"The settings owner changed during cleanup." end
  if not current() then return false,"Settings changed while loading; your choices were not replaced." end
  local candidate=M:Copy(profile);candidate.enabled=true
  local committed,reason=profiles:Commit(candidate,nil,"PROFILE_COMMIT")
  if not committed then return false,reason end
  if store()~=db or M.Profiles~=profiles or M.Client~=client or M.state~=state then return false,"The active settings owner changed. Reopen settings to inspect the result." end
  db.experienceRevision=self.revision;db.experienceChoice="CUSTOM";self.offered=true
  self.idleSince=nil;M.state.forceEvaluate=true
  local status=M.Diagnostics:ActivationState()
  if status.code=="RUNNING_PARTIAL" then return true,"Your choices are enabled, but some displays could not start. Open Help and copy the support report; their original controls remain available." end
  if status.code=="RECOVERING" then return true,status.message.." "..status.help end
  if status.setupBlocked then return false,status.message.." "..status.help end
  return true,"Your current choices are enabled. The intended preset was not reapplied."
 end)
 self.choosing=false;state.experiencePreparing=nil
 if not ok then M:Fault("Core","EXPERIENCE_APPLY_FAILED");return false,"Your choices could not be activated. Copy the support report from Help." end
 return result,message
end
local function value(snapshot,id)
 local row=snapshot[id]
 if row and row.status=="KNOWN" and row.decisionEligible==true and S:Readable(row.value) then return row.value end
end
function E:Recipient(surface)
 if surface.activityRecipient then return surface.activityRecipient end
 local module,id=surface.module,surface.id or ""
 if module=="Chat" then return "CHAT" end
 if module=="Cursor" then return "CURSOR" end
 if module=="Minimap" then return "NAV" end
 if module=="DataBars" then return "STATUS" end
 if module=="QuestTracker" then return "TRACKER" end
 if module=="Nameplates" then return "PLATES" end
 if module=="PartyRaid" then return "GROUP" end
 if module=="Bags" then return "BAGS" end
 if module=="UnitFrames" then
  local role=id:match("^UnitFrames%.([^%.]+)")
  if role=="target" or role=="focus" or role=="pet" then return role:upper() end
  return "PLAYER"
 end
 if id=="NativeControls.progression" or id:find("StatusTrackingBarContainer",1,true) then return "PROGRESS" end
 if id=="NativeControls.BagsBar" or id=="NativeControls.MicroMenuContainer" or id=="NativeControls.MicroMenu" then return "LAUNCH" end
 if module=="UnderCharacterHUD" then return "HUD" end
 if surface.groups then
  if surface.groups.location then return "STATUS" end
  if surface.groups.navigation then return "NAV" end
  if surface.groups.objectives or surface.groups.compactObjectives then return "TRACKER" end
  if surface.groups.progress then return "PROGRESS" end
  if surface.groups.group then return "GROUP" end
  if surface.groups.combat then return "COMBAT" end
 end
 return "QUIET"
end
function E:Intent(surface,snapshot,now)
 local p,activity=M.profile,M.ScopedActivity
 if not p or not p.managed or p.preset~="Immersive" or not activity then return nil end
 if surface.module=="Notifications" and not surface.activityRecipient or surface.userOpened then return nil end
 if value(snapshot,"TEMP_REVEAL")==true or value(snapshot,"EDIT_MODE")==true then return nil end
 local recipient=self:Recipient(surface)
 local wanted,reason,due
 if recipient=="CHAT" then
  local frame=surface.activityChatFrame
  if not frame then
   local index=(surface.id or ""):match("^Chat%.messages(%d+)$") or (surface.id or ""):match("^Chat%.ChatFrame(%d+)$")
   frame=index and _G["ChatFrame"..index] or surface.id=="Chat.nativePosition" and _G.ChatFrame1 or surface.native and surface.frame
  end
  wanted,reason,due=activity:ChatWindow(frame,now)
  if not wanted then local dock,untilAt=activity:ChatDockCue(frame,now);if dock then wanted,reason,due=true,"CHAT_DOCK_UNREAD",untilAt end end
  if wanted and activity:ChatTyping(frame) then return {state="VISIBLE",id=reason,priority=0,tieRank=62,eligible=true},due end
 elseif recipient=="HUD" then
  wanted,reason,due=activity:Demand("COMBAT",snapshot,now)
  if not wanted and M.PresentationGroups and M.PresentationGroups:Enabled() and M.UnderCharacterHUD
   and M.UnderCharacterHUD:RecoveryDemand() then wanted,reason=true,"HUD_RECOVERY" end
  local cast,castReason,castDue=activity:Demand("CAST",snapshot,now)
  if cast then wanted,reason,due=true,castReason,castDue end
 elseif recipient=="PROGRESS" then
  wanted,reason,due=activity:Demand("PROGRESS",snapshot,now)
  if not wanted then wanted,reason,due=activity:Demand("STATUS",snapshot,now) end
 elseif recipient=="PLATES" then
  wanted,reason,due=activity:Demand("PLATES",snapshot,now)
  if wanted==false then
   for _,role in ipairs({"target","focus"}) do
    local inspect,untilAt=activity:Inspect(role,now)
    inspect=inspect or activity:CastInspection(role:upper(),now)
    if inspect then
     wanted,reason=true,"LOCAL_SUBJECT_INSPECTION"
     if untilAt and untilAt>now then due=math.max(due or 0,untilAt) end
    end
   end
  end
 elseif recipient=="QUIET" then wanted,reason=false,"NO_LOCAL_ACTIVITY"
 else wanted,reason,due=activity:Demand(recipient,snapshot,now) end
 if wanted==nil then return nil,due end -- uncertainty remains scoped to its own native access
 return {state=wanted and "VISIBLE" or "HIDDEN",id=reason or "LOCAL_QUIET",priority=1,tieRank=70,eligible=true},due
end
function E:ClosePreview()
 if self.preview then self.preview:Hide() end
end
function E:Preview()
 if S:InCombat() then return false,"Preview unit frames outside combat." end
 M:LoadOptions(true)
 if M.PlayerSettings then return M.PlayerSettings:PreviewFrames() end
 return false,"Settings are unavailable."
end
function E:Report()
 local db=store();local choice=db and db.experienceChoice
 return "experience_revision="..self.revision.."\nexperience_choice="..(choice=="YES" and "YES" or choice=="NO" and "NO" or choice=="CUSTOM" and "CUSTOM" or "NOT_CHOSEN")..
  "\nexperience_scope=SUPPORTED_RUNTIME_MODULES_WITH_NATIVE_SAFETY_FALLBACK\nexperience_registry_scope=REVIEWED_RUNTIME_BINDINGS_NOT_ALL_RESEARCH_RULES"
end

function E:UpdateLauncher(snapshot,now)
 local b=M.launcher;if not b or not S:Frame(b,true) then return end
 local request=self:Intent({module="Minimap"},snapshot,now)
 local shown=M.state.safe or not request or request.state~="HIDDEN"
 -- The fallback is the recovery entry when optional minimap presentation is
 -- stopped. An open menu also keeps its own visible fallback anchor available.
 if M.SuiteLauncher and M.SuiteLauncher:IsOpenFor(b) then shown=true end
 if M.state.cinematic or value(snapshot,"NATIVE_UI_HIDDEN")==true then shown=false end
 local minimap=M.Rework and M.Rework.Minimap
 if minimap and minimap.OwnsSettingsLauncher and minimap:OwnsSettingsLauncher() then shown=false end
 if M.Effects and M.Effects.Transition then
  M.Effects:Transition(self,b,shown,{guard=function() return M.launcher==b and M.state.world end})
 else b:SetShown(shown) end
end
