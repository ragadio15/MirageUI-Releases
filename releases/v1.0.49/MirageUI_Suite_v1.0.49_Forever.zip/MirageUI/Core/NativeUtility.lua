local _,M=...
-- Native Edit HUD keeps utility geometry. A reversible secure parent supplies
-- context visibility without changing the bags/micro controls' own lifetime,
-- click handlers, bindings, mouse state, or alpha. In particular a native Hide
-- while quiet remains hidden when the gate next reveals.
local D={rows={},nativeQualification="NOT_RUN",active=false};M.DelegatedNative=D
local S=M.Safety
local names={BagsBar=true,MicroMenuContainer=true,MicroMenu=true}
function D:Descriptor(idOrRoot)
 local name=type(idOrRoot)=="string" and (idOrRoot:match("^NativeControls%.(.+)$") or idOrRoot)
 if not names[name] then return nil end
 local root=name=="MicroMenu" and "MicroMenuContainer" or name
 local context=M.ContextualNative and M.ContextualNative.rows[root]
 local owned=context and context.ownedOwner==self and (context.active or context.pending or context.attempted)
 local active=M.ContextualNative and M.ContextualNative:OwnedReady(self,root) or false
 return {name=name,position="BLIZZARD_EDIT_HUD",size="BLIZZARD_EDIT_HUD",scale="BLIZZARD_EDIT_HUD",
  parent=owned and "SECURE_CONTEXT_PARENT" or "NATIVE",visibility=active and "SECURE_CONTEXT_NATIVE_LIFETIME" or "NATIVE_LIFETIME",
  input="NATIVE_ORIGINAL",content="NATIVE_ORIGINAL",
  appearance=name=="MicroMenu" and "WITHIN_MICRO_MENU_CONTAINER" or "MIRAGE_ICON_TILES",
  contextOverride=active,nativeQualification=self.nativeQualification}
end
function D:ContextHealth()
 local ready=true
 if self.active then for _,name in ipairs({"BagsBar","MicroMenuContainer"}) do
  local native=_G[name]
  if not S:Readable(native) or native~=nil and not M.ContextualNative:OwnedReady(self,name) then ready=false end
  local cfg=M.profile and M.profile.modules and M.profile.modules.ActionBars
  local paint=M.NativePresentation and M.NativePresentation.details[name]
  if native~=nil and cfg and cfg.style and M.NativePresentation and not (paint and paint.complete) then ready=false end
 end end
 self.contextReady=ready;self.pendingWork=nil
 return ready
end
function D:OnNativeContextHealthChanged()
 self.contextReady=false
 local main=M.Rework and M.Rework.MainAction
 if main and main.active then main.pendingWork=true end
end
function D:Configure()
 local cfg=M.profile and M.profile.modules and M.profile.modules.ActionBars
 self.active=cfg and cfg.enabled==true and cfg.contextual==true and cfg.utilityContext==true
  and M.Managed:Enabled() and M:IsModuleActive("ActionBars") and not M.state.safe or false
 local contexts=M.ContextualNative
 for _,name in ipairs({"BagsBar","MicroMenuContainer"}) do
  local ready,status
  local existing=contexts.rows[name];local clean=true
  -- Utility geometry is native-owned and has no journal in this component.
  -- Configuration is an explicit/lifecycle pass, never a settled polling loop.
  if self.active and existing and existing.ownedOwner==self and (existing.pending or existing.ownerHandback) then
   clean=(existing.failures or 0)<3 and contexts:ReleaseOwned(self,name)
  end
  if not clean then ready=false;status="RESTORE_PENDING"
  elseif self.active then ready,status=contexts:AcquireOwned(self,name,"ActionBars","NativeControls."..name)
  else ready=contexts:ReleaseOwned(self,name);status=ready and "NATIVE_LIFETIME" or "RESTORE_PENDING" end
  local row=self:Descriptor(name)
  local native=M.ManagedNative and M.ManagedNative.rows[name]
  local paint=M.NativePresentation and M.NativePresentation.details[name]
  row.appearanceActive=native and native.active==true and native.mode=="adopt" and paint and paint.complete==true or false
  row.contextStatus=status or (ready and "SECURE_CONTEXT_READY" or "NATIVE_AVAILABLE")
  self.rows[name]=row
 end
 return self:ContextHealth()
end
function D:Retry()
 if S:InCombat() then return false,"COMBAT_LOCKDOWN" end
 M.ContextualNative:RetryOwned(self)
 local presentation=M.NativePresentation
 for _,name in ipairs({"BagsBar","MicroMenuContainer"}) do
  local native=M.ManagedNative and M.ManagedNative.rows[name]
  if presentation and native and native.active and native.mode=="adopt" then
   local clean=presentation:Restore(native,true)
   if not clean then return false,"UTILITY_ART_RESTORE_PENDING" end
   M.ManagedNative:RestoreArt(native)
   presentation:Apply(native)
  end
 end
 return self:Configure(),"NATIVE_UTILITIES_PENDING"
end
function D:Report()
 local lines={"native_utility.geometry_owner=BLIZZARD_EDIT_HUD",
  "native_utility.visibility_owner=SECURE_CONTEXT_PARENT_WITH_NATIVE_LIFETIME",
  "native_utility.context_override=SUPPORTED_NAMED_CONTAINERS",
  "native_utility.native_handlers=UNCHANGED",
  "native_utility.native_input=ORIGINAL_CONTROL",
  "native_utility.native_qualification=NOT_RUN"}
 for _,name in ipairs({"BagsBar","MicroMenuContainer"}) do
  local r=M.ManagedNative and M.ManagedNative.rows[name]
  local context=M.ContextualNative and M.ContextualNative.status[name] or "NOT_CONFIGURED"
  local paint=M.NativePresentation and M.NativePresentation.details[name]
  lines[#lines+1]="native_utility."..name..".appearance="..(r and r.active and r.mode=="adopt" and paint and paint.complete and "MIRAGE_ICON_TILES" or "NATIVE_OR_PARTIAL_PRESENTATION")
  lines[#lines+1]="native_utility."..name..".visibility="..context
  if M.NativePresentation and M.NativePresentation.Diagnostics then
   lines[#lines+1]="native_utility."..name..".presentation="..M.NativePresentation:Diagnostics(name)
  end
 end
 return table.concat(lines,"\n")
end
local N=M.ManagedNative
if N then
 local configure=N.Configure
 function N:Configure(...)
  local result=configure(self,...);D:Configure();return result
 end
 local report=N.Report
 function N:Report(...)
  return (report(self,...) or "").."\n"..D:Report()
 end
end
