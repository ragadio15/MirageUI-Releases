-- WP07 typed data and detached recovery plans only. No Apply, native or saved writes.
local addonName,M=...
local globals=_G
local function plain(v) return type(v)=="table" and getmetatable(v)==nil end
local function owner()
 return addonName=="MirageUI" and plain(M) and rawget(M,"name")=="MirageUI"
  and rawequal(_G,globals) and rawequal(rawget(globals,"MirageUI"),M)
  and rawget(M,"CursorPreferenceEnvelope")==nil
end
if not owner() then return end
local built,prepared,ready=pcall(function()
local D=rawget(M,"CursorPreferenceData")
if not plain(D) or D.contract~="MIRAGE_CURSOR_PREFERENCE_DATA/1" then return end
local S,C=rawget(D,"schema"),rawget(D,"codecFactory")
if not plain(S) or not plain(C) or S.contract~="WP07_CURSOR_PROFILE_SCHEMA/1" or C.contract~="WP07_CCP25_ADAPTER/1" then return end
local dependencies={}
for _,object in ipairs({D,S,C}) do
 local row={object=object,fields={},count=0};dependencies[#dependencies+1]=row
 for key,value in next,object do row.count=row.count+1;row.fields[#row.fields+1]={key=key,value=value} end
end
local function unchanged(rows)
 for _,row in ipairs(rows) do
  if not plain(row.object) then return false end
  local count=0;for _ in next,row.object do count=count+1;if count>row.count then return false end end
  if count~=row.count then return false end
  for _,entry in ipairs(row.fields) do if not rawequal(rawget(row.object,entry.key),entry.value) then return false end end
 end
 return true
end
local E={contract="MIRAGE_CURSOR_PREFERENCE_ENVELOPE/1",storageSchema=2,recoveryKey="cursorPreferenceRecovery"}
local exports
local function current()
 return plain(M) and rawequal(rawget(globals,"MirageUI"),M) and rawequal(_G,globals)
  and rawequal(rawget(M,"CursorPreferenceData"),D) and rawequal(rawget(M,"CursorPreferenceEnvelope"),E)
  and unchanged(dependencies) and (exports==nil or unchanged(exports))
end
local reason="Cursor preference data is unsupported or changed; original data was preserved."
local function finite(v) return type(v)=="number" and v==v and v~=math.huge and v~=-math.huge end
local function exact(t,keys,n)
 if not plain(t) then return false end
 local count=0;for k in next,t do count=count+1;if not keys[k] or count>n then return false end end
 return count==n
end
-- Capture raw membership before any caller readability callback. Copy only after
-- public primitive validation; never use generic lossy suite Copy for archives.
function E:Snapshot(value,readable,kind)
 if self~=E or not current() or type(readable)~="function" then return nil,reason end
 local maxDepth,maxFields,maxText=24,10000,1048576
 if kind=="archive" then maxDepth,maxFields,maxText=64,100000,8388608
 elseif kind=="recovery" then maxDepth,maxFields,maxText=66,100003,8388672
 elseif kind=="root2" then maxDepth,maxFields,maxText=66,200512,16793600 end
 local nodes,seen,visiting,scalars={}, {}, {}, {};local fields=0
 local function scan(v,depth)
  if depth>maxDepth then return false end
  local t=type(v)
  if t~="table" then scalars[#scalars+1]=v;return t=="nil" or t=="boolean" or t=="number" or t=="string" end
  if not plain(v) or visiting[v] then return false end
  if seen[v] then return true end
  local row={object=v,fields={},count=0};nodes[#nodes+1]=row;seen[v]=row;visiting[v]=true
  for k,child in next,v do
   fields=fields+1;if fields>maxFields or (type(k)~="string" and type(k)~="number") then return false end
   scalars[#scalars+1]=k;row.count=row.count+1;row.fields[#row.fields+1]={key=k,value=child}
   if not scan(child,depth+1) then return false end
  end
  visiting[v]=nil;return true
 end
 if not scan(value,0) then return nil,reason end
 for _,row in ipairs(nodes) do if readable(row.object)~=true then return nil,reason end end
 local text=0
 for _,v in ipairs(scalars) do
  if readable(v)~=true then return nil,reason end
  if type(v)=="number" and not finite(v) then return nil,reason end
  if type(v)=="string" then text=text+#v;if text>maxText then return nil,reason end end
 end
 local function guard() return current() and unchanged(nodes) end
 if not guard() then return nil,reason end
 local copies={};for _,row in ipairs(nodes) do copies[row.object]={} end
 for _,row in ipairs(nodes) do
  local out=copies[row.object]
  for _,entry in ipairs(row.fields) do
   local v=entry.value;out[entry.key]=type(v)=="table" and copies[v] or v
  end
 end
 if not guard() then return nil,reason end
 return type(value)=="table" and copies[value] or value,guard,nodes
end
function E:Seal() if self~=E or not current() then return nil end;return current end
function E:Validate(value,flavor,readable)
 if flavor~="Midnight" and flavor~="Forever" then return nil,reason end
 local copy,guard=self:Snapshot(value,readable)
 if type(guard)~="function" or not plain(copy) or copy.flavor~=flavor then return nil,reason end
 local policy
 if copy.schema==1 then
  if not exact(copy,{schema=true,flavor=true,preferences=true},3) then return nil,reason end
 elseif copy.schema==2 then
  if not exact(copy,{schema=true,flavor=true,preferences=true,presentation=true},4)
   or not exact(copy.presentation,{schema=true,healthPair=true},2) or copy.presentation.schema~=1
   or (copy.presentation.healthPair~="CursorUnderCharacterHUD" and copy.presentation.healthPair~="None") then return nil,reason end
  policy={schema=1,healthPair=copy.presentation.healthPair}
 else return nil,reason end
 local preferences=S.Validate(copy.preferences)
 if not preferences then return nil,reason end
 local result={schema=copy.schema,flavor=flavor,preferences=preferences,presentation=policy}
 if not guard() then return nil,reason end
 return result
end
-- Older transfers cannot express this independently versioned policy. Retain
-- current scope's explicit choice; schema2/None is an explicit disable, not an
-- inferred downgrade. Private recorded Undo is handled by the Profiles owner.
function E:CarryPolicy(value,previous,flavor,readable)
 local input,ig=self:Snapshot(value,readable)
 local prior,pg=self:Snapshot(previous,readable)
 if type(ig)~="function" or type(pg)~="function" then return nil,reason end
 local clean=self:Validate(input,flavor,readable)
 if not clean then return nil,reason end
 local old
 if previous~=nil then old=self:Validate(prior,flavor,readable);if not old then return nil,reason end end
 if clean.schema==1 and old and old.schema==2 then
  clean.schema=2;clean.presentation={schema=1,healthPair=old.presentation.healthPair}
 end
 if not ig() or not pg() then return nil,reason end
 return clean
end
function E:Decode(code,flavor,readable)
 if not current() or type(readable)~="function" or readable(code)~=true or type(code)~="string" then return nil,reason end
 if flavor~="Midnight" and flavor~="Forever" then return nil,reason end
 local codec=C.New(S,flavor);if not codec or not current() then return nil,reason end
 local preferences=codec:Decode(code)
 if not preferences or not current() then return nil,reason end
 return self:Validate({schema=1,flavor=flavor,preferences=preferences},flavor,readable)
end
function E:Encode(value,flavor,readable)
 local clean,guard=self:Snapshot(value,readable);if type(guard)~="function" then return nil,reason end
 local envelope=self:Validate(clean,flavor,readable);if not envelope or not guard() then return nil,reason end
 local codec=C.New(S,flavor);if not codec or not guard() then return nil,reason end
 local code=codec:Encode(envelope.preferences)
 if not code or not guard() then return nil,reason end
 return code
end
function E:Root(root,role,readable)
 if self~=E or not current() or (role~="account" and role~="character") then return nil,reason end
 if root==nil then return 1,current,{} end
 if not plain(root) then return nil,reason end
 local version,archive=rawget(root,"schema"),rawget(root,"cursorPreferenceRecovery")
 local function identity() return current() and plain(root) and rawequal(rawget(root,"schema"),version) and rawequal(rawget(root,"cursorPreferenceRecovery"),archive) end
 if type(readable)~="function" or readable(root)~=true or readable(version)~=true or not identity() then return nil,reason end
 if version==1 then if archive~=nil then return nil,reason end;return 1,identity,{} end
 if version~=2 then return nil,reason end
 local copy,guard,nodes=self:Snapshot(archive,readable,"recovery")
 if type(guard)~="function" or not exact(copy,{schema=true,role=true,original=true},3) or copy.schema~=1 or copy.role~=role
  or not plain(copy.original) or rawget(copy.original,"schema")~=1 or rawget(copy.original,"cursorPreferenceRecovery")~=nil then return nil,reason end
 local function sealed() return identity() and guard() end
 if not sealed() then return nil,reason end
 return 2,sealed,nodes
end
function E:Pair(account,character,readable)
 local av,ag,an=self:Root(account,"account",readable);if not av then return nil,reason end
 local cv,cg,cn=self:Root(character,"character",readable);if not cv or (av==1 and cv==2) then return nil,reason end
 local function guard() return ag() and cg() end
 if not guard() then return nil,reason end
 return {account=av,character=cv,accountNodes=an,characterNodes=cn},guard
end
-- Full current roots are sealed for explicit publication. First root1 archive
-- copies are independent; later root2 archives are retained, not replaced.
function E:PlanRoots(account,character,readable)
 local pair,pairGuard=self:Pair(account,character,readable);if not pair or account==nil or character==nil then return nil,reason end
 local ac,ag,an=self:Snapshot(account,readable,pair.account==2 and "root2" or "archive")
 local cc,cg,cn=self:Snapshot(character,readable,pair.character==2 and "root2" or "archive")
 if type(ag)~="function" or type(cg)~="function" then return nil,reason end
 local accountTables={};for _,row in ipairs(an) do accountTables[row.object]=true end
 for _,row in ipairs(cn) do if accountTables[row.object] then return nil,reason end end
 local archives={}
 for _,rows in ipairs({pair.accountNodes,pair.characterNodes}) do for _,row in ipairs(rows) do archives[row.object]=true end end
 local function noArchiveAlias(root)
  local seen={}
  local function visit(node)
   if type(node)~="table" then return true end
   if archives[node] then return false end
   if seen[node] then return true end;seen[node]=true
   for k,v in next,node do
    if not (rawequal(node,root) and k=="cursorPreferenceRecovery") and not visit(v) then return false end
   end
   return true
  end
  return visit(root)
 end
 if not noArchiveAlias(account) or not noArchiveAlias(character) then return nil,reason end
 local function shallow(v) local out={};for k,x in next,v do out[k]=x end;return out end
 local a,c=shallow(account),shallow(character)
 if pair.account==1 then a.schema=2;a.cursorPreferenceRecovery={schema=1,role="account",original=ac} end
 if pair.character==1 then c.schema=2;c.cursorPreferenceRecovery={schema=1,role="character",original=cc} end
 local function guard() return pairGuard() and ag() and cg() end
 if not guard() then return nil,reason end
 return {account=a,character=c},guard
end
function E:Recovery(account,character,readable)
 local pair,guard=self:Pair(account,character,readable);if not pair then return nil,reason end
 local result={schema=1,accountStatus="NOT_MIGRATED",characterStatus="NOT_MIGRATED"};local guards={guard}
 for _,item in ipairs({{account,"account",pair.account},{character,"character",pair.character}}) do
  if item[3]==2 then
   local copy,unchangedArchive=self:Snapshot(rawget(item[1],"cursorPreferenceRecovery"),readable,"recovery")
   if type(unchangedArchive)~="function" then return nil,reason end
   result[item[2]]=copy.original;result[item[2].."Status"]="LEGACY_SNAPSHOT";guards[#guards+1]=unchangedArchive
  end
 end
 for _,same in ipairs(guards) do if not same() then return nil,reason end end
 return result
end
-- Sanitize observed dependency/readability failures at the public data boundary.
for key,fn in next,E do
 if type(fn)=="function" then E[key]=function(self,...)
  local ok,a,b,c=pcall(fn,self,...)
  if not ok then return nil,reason end
  return a,b,c
 end end
end
-- All exported closures and their identity seal are allocated before admission.
exports={{object=E,fields={},count=0}}
for key,value in next,E do local row=exports[1];row.count=row.count+1;row.fields[#row.fields+1]={key=key,value=value} end
return E,function() return unchanged(dependencies) end
end)
if not built or type(prepared)~="table" or type(ready)~="function" or not owner() or not ready() then return end
rawset(M,"CursorPreferenceEnvelope",prepared)
