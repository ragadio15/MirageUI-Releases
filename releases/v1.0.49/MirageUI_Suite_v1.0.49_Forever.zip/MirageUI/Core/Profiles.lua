local _, M = ...
M.Profiles={}
local P=M.Profiles
function P:DelegatedGeometry(profile,id)
    if id~="NativeControls.BagsBar" and id~="NativeControls.MicroMenuContainer" then return nil end
    local source=type(profile)=="table" and type(profile.layouts)=="table" and profile.layouts[id]
    if type(source)~="table" then return nil end
    local result={}
    for _,key in ipairs({"x","y","width","height","scale","anchorTo"}) do
        local value=rawget(source,key)
        if key=="anchorTo" then if M.Safety:Text(value) then result[key]=value end
        elseif M.Safety:Number(value) then result[key]=value end
    end
    return result,"DORMANT_BLIZZARD_GEOMETRY"
end
-- Initialization and every publication share one private reentry boundary.
local writer,initializing
local captureData,dataCurrent
local undoRecord
local function preferenceEnvelope(input)
    local value
    -- Do not use truthiness: false is malformed authored data, not absence.
    if type(input)=="table" then value=rawget(input,"cursorPreferences") end
    if value==nil then return true,nil end
    local E=rawget(M,"CursorPreferenceEnvelope")
    if type(E)~="table" or type(E.Validate)~="function" then return false,"Cursor preference storage is unavailable; original data was preserved." end
    local clean,why=E:Validate(value,M.Client.family,function(v) return M.Safety:Readable(v) end)
    if not clean then return false,why end
    return true,clean
end
local visibilities={Contextual=true,Always=true,Manual=true}
local cooldownModes={Cooldown=true,Recharge=true,Aura=true,Debuff=true,TargetAura=true,TargetDebuff=true,Item=true,ItemAura=true}
local cooldownHighlights={None=true,Accent=true,Glow=true}
local function cooldownID(value)
    return M.Safety:Number(value) and value>0 and value<=2147483647 and value%1==0
end
local function cooldownKey(item)
    return item.mode..":"..item.id..(item.mode=="ItemAura" and ":"..item.auraID or "")
end
local cooldownBars={Primary=true,Secondary=true}
local function cooldownGroupID(value)
    return cooldownID(value) and value<=999999
end
local function cooldownGroupName(value)
    return M.Safety:Text(value) and #value>0 and #value<=40 and not value:find("[%c|]")
        and value:match("%S")~=nil and value==value:match("^%s*(.-)%s*$")
end
local function cooldownGroupMap(groups)
    local map={};for _,group in ipairs(groups or {}) do map[group.id]=group end;return map
end
-- Group IDs are data identities, never array positions. The same identity
-- survives list reordering and renaming; invalid references are unassigned.
local function normalizeCooldownGroups(value)
    local groups,seen={},{}
    if type(value)~="table" then return groups end
    for i=1,math.min(64,#value) do
        local g=value[i]
        if type(g)=="table" and cooldownGroupID(g.id) and not seen[g.id] then
            local name=M.Safety:Text(g.name) and g.name:match("^%s*(.-)%s*$") or ""
            if not cooldownGroupName(name) then name=string.format("%03d",g.id) end
            local clean={id=g.id,name=name}
            for _,key in ipairs({"r","g","b","alpha"}) do
                local fallback=key=="r" and 1 or key=="g" and .6 or key=="b" and 0 or 1
                clean[key]=M.Safety:Number(g[key]) and math.max(0,math.min(1,g[key])) or fallback
            end
            if cooldownBars[g.bar] then clean.bar=g.bar end
            groups[#groups+1]=clean;seen[g.id]=true
        end
    end
    return groups
end
-- The retired embedded addon is not a catalog/runtime module. Its five old
-- settings and valid Cursor rules remain inert data so beta61 portable, named
-- and character profiles can still be selected and copied without data loss.
-- Do not extend this exception to arbitrary unknown modules or fields.
local legacyCursorKeys={"enabled","visibility","alpha","scale","style"}
local legacyCursorSchema={enabled=true,visibility="Contextual",alpha=1,scale=1,style=true}
local function legacyCursorValid(cfg)
    if type(cfg)~="table" or getmetatable(cfg)~=nil then return false end
    for key,value in pairs(cfg) do
        if legacyCursorSchema[key]==nil then return false end
        if key=="enabled" or key=="style" then
            if type(value)~="boolean" then return false end
        elseif key=="visibility" then
            if not M.Safety:Text(value) or not visibilities[value] then return false end
        elseif not M.Safety:Number(value) or value<(key=="alpha" and .2 or .6) or value>(key=="alpha" and 1 or 1.6) then return false end
    end
    return true
end
local presets={Balanced=true,Immersive=true,["Always Informed"]=true,Accessibility=true}
local function number(value,default,low,high)
    if not M.Safety:Number(value) then return default end
    return math.max(low,math.min(high,value))
end
-- beta34 applies the explicitly requested visual refinement once to each
-- active managed scope. The incoming raw roots are checkpointed by Rework
-- before this boot transaction; named profiles, bindings and cursor settings
-- are not rewritten. Later personalization is not re-applied on every reload.
local function refineBeta34(branch)
    local marker=rawget(branch,"beta34VisualRevision")
    if marker~=nil or not branch.profile or branch.profile.b35Revision==1 or branch.profile.managed~=true or branch.profile.enabled~=true then return end
    local p=branch.profile
    for _,fact in ipairs({"health","resource","cast"}) do
        p.presentation[fact]="UnderCharacterHUD";p.presentation[fact.."Mirror"]=false
    end
    p.preset="Immersive";p.fade=.22;p.idle=0;p.movementHold=0;p.combatHold=0
    -- The requested quiet baseline replaces earlier persistent-visibility
    -- choices once. Keep disabled modules disabled and preserve later edits.
    for _,cfg in pairs(p.modules) do if cfg.enabled then cfg.visibility="Contextual" end end
    for _,contexts in pairs(p.elementContexts or {}) do if contexts.Idle=="SHOW" then contexts.Idle=nil end end
    local hud=p.modules.UnderCharacterHUD
    hud.health=true;hud.resource=true;hud.cast=true;hud.backdrop=0;hud.trackOpacity=76;hud.gap=4
    p.modules.Minimap.square=true;p.modules.QuestTracker.matchMinimap=true
    p.modules.Nameplates.cardAuras=true;p.modules.Nameplates.cardCast=true;p.modules.Nameplates.panelOpacity=68
    branch.beta34VisualRevision=1
end
-- b35's approved semantic/layout revision travels with a profile. An inactive
-- or named profile is left byte-for-byte alone until it is selected. Raw saved
-- roots are checkpointed by Rework before any active refinement is published.
local function refineBeta35(p)
    if not p or p.b35Revision==1 or not p.managed or not p.enabled then return false end
    p.preset="Immersive";p.fade=.22;p.idle=0;p.movementHold=0;p.combatHold=0
    for _,cfg in pairs(p.modules) do if cfg.enabled then cfg.visibility="Contextual" end end
    for _,row in pairs(p.elementContexts or {}) do if row.Idle=="SHOW" then row.Idle=nil end end
    for _,fact in ipairs({"health","resource","cast"}) do p.presentation[fact]="UnderCharacterHUD";p.presentation[fact.."Mirror"]=false end
    p.presentation.gcd="Native";p.presentation.gcdMirror=false
    local hud=p.modules.UnderCharacterHUD
    hud.health=true;hud.resource=true;hud.cast=true;hud.policy=2;hud.layoutOrder=1
    hud.y=math.max(-500,(hud.y or -145)-40);hud.rowPitch=14;hud.layoutRevision=1;hud.backdrop=0;hud.trackOpacity=76
    local map=p.layouts["Minimap.nativePosition"] or {x=.39,y=.29,scale=1}
    map.width=300;map.height=354;p.layouts["Minimap.nativePosition"]=map
    p.modules.Minimap.square=true;p.modules.Minimap.hideWhenQuiet=true
    p.modules.QuestTracker.matchMinimap=true;p.modules.QuestTracker.hideWhenQuiet=true
    local tracker=p.layouts["QuestTracker.nativePosition"]
    if tracker then tracker.width=300;tracker.height=math.min(420,tracker.height);tracker.scale=map.scale end
    p.modules.DataBars.showXP=false;p.modules.DataBars.showZone=true;p.modules.DataBars.showCoordinates=true
    p.modules.DataBars.showMoney=true;p.modules.DataBars.showFPS=true
    p.modules.Chat.messageCue=true;p.modules.Chat.hideWhenQuiet=true
    p.modules.Nameplates.panelOpacity=12;p.modules.Nameplates.cardAuras=true;p.modules.Nameplates.cardCast=true
    p.modules.Nameplates.customFriendlyPlayers=true;p.modules.Nameplates.customFriendlyNPCs=true
    p.modules.Nameplates.customPets=true;p.modules.Nameplates.customNeutral=true
    for _,key in ipairs({"friendlyVisibility","friendlyNPCVisibility","enemyPetVisibility","friendlyPetVisibility"}) do p.modules.Nameplates[key]=2 end
    p.modules.UnitFrames.panelOpacity=12
    p.modules.ActionBars.secondaryHover=false
    p.modules.Notifications.duration=4;p.modules.Notifications.maxRows=3
    p.modules.Tooltips.fixedAnchor=false;p.modules.Tooltips.cursorAnchor=false
    p.b35Revision=1
    return true
end
P.RefineBeta35=refineBeta35
-- b44-r2 reduces the existing effective sidebar width once. A saved marker
-- travels with the profile so reloads, editor saves and imports use the new
-- units directly. Followers consume the shared runtime width; their dormant
-- authored geometry, map anchor/height/scale and unrelated layouts stay intact.
local function refineSidebarWidth(p)
    if p.sidebarWidthRevision==1 then return false end
    local map=p.layouts["Minimap.nativePosition"]
    if map then map.width=number(map.width,300,260,420)*.75 end
    p.sidebarWidthRevision=1
    return true
end
-- Earlier managed profiles enabled friendly engine plates, whose nearby
-- outlined name font differs from world names. Adopt native world naming once
-- for that old managed choice. Keep-current and later explicit choices survive;
-- inactive/named profiles are migrated only when they are selected.
local function refineNameplateWorldNames(p)
    if p.nameplateWorldNamesRevision==1 then return false end
    if p.managed then
        for _,key in ipairs({"friendlyVisibility","friendlyNPCVisibility","friendlyPetVisibility"}) do
            if p.modules.Nameplates[key]==2 then p.modules.Nameplates[key]=1 end
        end
    end
    p.nameplateWorldNamesRevision=1
    return true
end
-- Beta48 adopts the requested five-bar interface and selected-friendly plates
-- once per selected profile. Unrelated rectangles, bindings and cursor data
-- remain in the original profile/checkpoint; future user edits are respected.
local function refineBeta48(p)
    if p.beta48Revision==1 then return false end
    if p.managed and p.enabled then
        local n=p.modules.Nameplates
        n.friendlyVisibility=2;n.friendlyNPCVisibility=2
        n.cardAuraCount=6;n.cardAuras=true;n.maximumDistance=60
        local a=p.modules.ActionBars
        a.actionExperience=1;a.interfaceScale=100;a.allowRearrange=true
    end
    p.beta48Revision=1
    return true
end
P.RefineBeta48=refineBeta48
-- Beta49 restores native ambient world names and adopts the user's compact,
-- mouseover action section once. The native action slots and bindings are not
-- profile data and are never moved or rewritten by this migration.
local function refineBeta49(p)
    if p.beta49Revision==1 then return false end
    if p.managed and p.enabled then
        local n=p.modules.Nameplates
        n.friendlyVisibility=1;n.friendlyNPCVisibility=1;n.friendlyPetVisibility=1;n.enemyPetVisibility=2
        p.modules.ActionBars.actionExperience=2
        local l=p.layouts and p.layouts["ActionBars.interface"]
        if l then
            l.width=number(l.width,570,24,4096)*468/570
            l.height=l.width*252/468
        end
    end
    p.beta49Revision=1
    return true
end
P.RefineBeta49=refineBeta49
-- Beta51 upgrades only the selected managed profile. Native slots/bindings,
-- saved profiles and cursor preferences are not action-section geometry.
local function refineBeta51(p)
    if p.beta51Revision==1 then return false end
    if p.managed and p.enabled then
        local n=p.modules.Nameplates
        if n then
            n.friendlyVisibility=2;n.friendlyNPCVisibility=2;n.friendlyPetVisibility=2
            n.enemyVisibility=2;n.enemyPetVisibility=2;n.cardAuras=true
        end
        local a=p.modules.ActionBars
        if a then
            a.interfaceScale=math.max(100,number(a.interfaceScale,100,65,160))
            local l=p.layouts and p.layouts["ActionBars.interface"]
            if l and number(l.width,468,240,1200)/468*number(l.scale,1,.6,1.6)<1 then
                l.width=468;l.height=252;l.scale=1
            end
        end
        local c=p.modules.Cooldowns
        if c then
            c.tracker=false;c.centralGroup=false;c.rowEnabled=true;c.rowFollowHUD=true
            c.rowVisibility=3;c.iconSize=50;c.gap=3;c.showNumbers=true;c.ignoreGCD=false
            c.rowScale=100;c.rowOpacity=100;c.rowMaxIcons=0;c.rowBorder=1;c.rowZoom=8
            c.durationSize=12;c.chargeSize=11;c.rowShowCharges=true;c.rowTooltips=false

        end
    end
    p.beta51Revision=1
    return true
end
P.RefineBeta51=refineBeta51
-- Beta52 adopts the requested persistent hostile plates and bottom action dock
-- once for the active managed profile. Tracking assignments and native action
-- slots are unchanged. Older roots are checkpointed before publication.
local function refineBeta52(p)
    if p.beta52Revision==1 then return false end
    if p.managed and p.enabled then
        local n=p.modules.Nameplates
        if n then
            n.visibility="Always";n.enemyVisibility=2;n.enemyPetVisibility=2
            n.customNeutral=true;n.customPets=true;n.cardAuras=true
            n.maximumDistance=50;n.cardLimit=80
            -- Old per-context hides must not defeat the newly requested
            -- always-visible hostile policy. Later explicit edits still win.
            if p.elementContexts then p.elementContexts["Nameplates.world"]=nil end
        end
        if p.modules.ActionBars then p.modules.ActionBars.interfaceDocked=true end
        if p.modules.Cooldowns then
            p.modules.Cooldowns.rowFollowHUD=true
            -- An authored row rectangle takes precedence over HUD following.
            -- Retire that former low anchor for this requested placement reset.
            if p.layouts then p.layouts["Cooldowns.row"]=nil end
        end
    end
    p.beta52Revision=1
    return true
end
P.RefineBeta52=refineBeta52
-- Beta57 restores Blizzard's own friendly world-name renderer for the active
-- managed profile. Enemy/neutral plates, range emphasis, bindings and layout
-- stay intact. The native name/title/guild preferences are never profile data.
local function refineBeta57NativeNames(p)
    if p.beta57NativeNamesRevision==1 then return false end
    if p.managed and p.enabled and p.modules and p.modules.Nameplates then
        local n=p.modules.Nameplates
        n.friendlyVisibility=1;n.friendlyNPCVisibility=1;n.friendlyPetVisibility=1
        n.customFriendlyPlayers=false;n.customFriendlyNPCs=false
    end
    p.beta57NativeNamesRevision=1
    return true
end
P.RefineBeta57NativeNames=refineBeta57NativeNames
-- Earlier managed setups seeded an explicit 50-yard *plate* preference.
-- Return that seed to the game once; later explicit slider choices survive.
local function refinePlateDistance(p)
    local n=p.modules and p.modules.Nameplates
    if not n or n.plateDistanceRevision==1 then return end
    if p.managed and n.maximumDistance==50 then n.maximumDistance=0 end
    n.plateDistanceRevision=1
end

-- P13 revision 2 enables the requested tooltip presentation once on selection.
-- The marker travels with the module preferences, including exports/imports.
-- Subsequent personal choices and every unrelated module remain untouched.
local function refineP13Tooltips(p)
    local cfg=p and p.modules and p.modules.Tooltips
    if not cfg or cfg.presentationRevision==1 or p.enabled==false then return false end
    cfg.enabled=true;cfg.style=true;cfg.primaryPresentation=1
    cfg.presentationRevision=1
    return true
end
P.RefineP13Tooltips=refineP13Tooltips
local function refineSelectedProfile(p)
    -- The older semantic migration installs its historical 300-unit map.
    -- Apply the current width revision after that legacy step, never before.
    if refineBeta35(p) then p.sidebarWidthRevision=0;p.nameplateWorldNamesRevision=0 end
    refineSidebarWidth(p)
    refineNameplateWorldNames(p)
    refineBeta48(p)
    refineBeta49(p)
    refineBeta51(p)
    refineBeta52(p)
    refineBeta57NativeNames(p)
    refinePlateDistance(p)
    refineP13Tooltips(p)
end
local function profileSchema()
    local p={b35Revision=1,sidebarWidthRevision=1,nameplateWorldNamesRevision=1,beta48Revision=1,beta49Revision=1,beta51Revision=1,beta52Revision=1,beta57NativeNamesRevision=1,enabled=true,managed=false,autoLayout=false,managedDismissed=false,preset="Immersive",textScale=1,fade=.22,idle=0,movementHold=0,combatHold=0,
        elementContexts={},presentation=M.Presentation:Defaults(),preparationReferences=M.References:Empty(),modules={},layouts={},rules={},onboarding=false,onboardingDismissed=false,contrast=false,grid=8,gamepadNavigation=false,spokenLabels=false,speechRate=0,speechVolume=70}
    for _,row in ipairs(M.Catalog) do
        if not row.system then p.modules[row.id]={enabled=row.default==true,visibility="Contextual",alpha=1,scale=1,style=true} end
    end
    p.modules.DataBars.showXP=false; p.modules.DataBars.showZone=true
    p.modules.DataBars.showMoney=true; p.modules.DataBars.showClock=false
    for id,fields in pairs(M.FeatureSettings) do
        for key,definition in pairs(fields) do p.modules[id][key]=type(definition)=="table" and definition[1] or definition end
    end
    p.modules.Tooltips.presentationRevision=1;p.modules.Tooltips.primaryPresentation=1
    p.modules.Nameplates.visibility="Always";p.modules.Nameplates.plateDistanceRevision=1
    p.modules.Cooldowns.spells={};p.modules.Cooldowns.groups={}
    p.modules.Auras.reminders={}
    p.modules.Preparations.supplyIDs={}
    return p
end
function P:Defaults()
    return M:ApplyFactoryDefaults(profileSchema())
end
function P:Validate(input)
    if type(input)~="table" then input={} end
    if input.b35Revision~=nil and (not M.Safety:Number(input.b35Revision) or input.b35Revision%1~=0 or input.b35Revision<0 or input.b35Revision>1) then
        return input,"This profile uses an unknown b35 revision; its original data was preserved."
    end
    if input.sidebarWidthRevision~=nil and (not M.Safety:Number(input.sidebarWidthRevision) or input.sidebarWidthRevision%1~=0 or input.sidebarWidthRevision<0 or input.sidebarWidthRevision>1) then
        return input,"This profile uses an unknown sidebar width revision; its original data was preserved."
    end
    if input.nameplateWorldNamesRevision~=nil and (not M.Safety:Number(input.nameplateWorldNamesRevision) or input.nameplateWorldNamesRevision%1~=0 or input.nameplateWorldNamesRevision<0 or input.nameplateWorldNamesRevision>1) then
        return input,"This profile uses an unknown native world-name revision; its original data was preserved."
    end
    if input.beta48Revision~=nil and (not M.Safety:Number(input.beta48Revision) or input.beta48Revision%1~=0 or input.beta48Revision<0 or input.beta48Revision>1) then
        return input,"This profile uses an unknown beta48 revision; its original data was preserved."
    end
    if input.beta49Revision~=nil and (not M.Safety:Number(input.beta49Revision) or input.beta49Revision%1~=0 or input.beta49Revision<0 or input.beta49Revision>1) then
        return input,"This profile uses an unknown beta49 revision; its original data was preserved."
    end
    if input.beta51Revision~=nil and (not M.Safety:Number(input.beta51Revision) or input.beta51Revision%1~=0 or input.beta51Revision<0 or input.beta51Revision>1) then
        return input,"This profile uses an unknown beta51 revision; its original data was preserved."
    end
    if input.beta52Revision~=nil and (not M.Safety:Number(input.beta52Revision) or input.beta52Revision%1~=0 or input.beta52Revision<0 or input.beta52Revision>1) then
        return input,"This profile uses an unknown beta52 revision; its original data was preserved."
    end
    if input.beta57NativeNamesRevision~=nil and (not M.Safety:Number(input.beta57NativeNamesRevision) or input.beta57NativeNamesRevision%1~=0 or input.beta57NativeNamesRevision<0 or input.beta57NativeNamesRevision>1) then
        return input,"This profile uses an unknown beta57 native-name revision; its original data was preserved."
    end
    local references,referenceWhy=M.References:Profile(input)
    if not references then return input,referenceWhy end -- never normalize authored data away
    local envelopeOK,envelope=preferenceEnvelope(input)
    if not envelopeOK then return input,envelope end
    local contexts,contextWhy=M.ElementRules:Validate(input.elementContexts)
    if not contexts then return input,contextWhy end
    local p=profileSchema();p.b35Revision=math.floor(number(input.b35Revision,0,0,1));p.elementContexts=contexts;p.preparationReferences=references;p.cursorPreferences=envelope
    p.sidebarWidthRevision=number(input.sidebarWidthRevision,0,0,1)
    p.nameplateWorldNamesRevision=number(input.nameplateWorldNamesRevision,0,0,1)
    p.beta48Revision=number(input.beta48Revision,0,0,1)
    p.beta49Revision=number(input.beta49Revision,0,0,1)
    p.beta51Revision=number(input.beta51Revision,0,0,1)
    p.beta52Revision=number(input.beta52Revision,0,0,1)
    p.beta57NativeNamesRevision=number(input.beta57NativeNamesRevision,0,0,1)
    for _,key in ipairs({"enabled","managed","autoLayout","managedDismissed","onboarding","onboardingDismissed","contrast","gamepadNavigation","spokenLabels"}) do
        if type(input[key])=="boolean" then p[key]=input[key] end
    end
    if presets[input.preset] then p.preset=input.preset end
    p.textScale=number(input.textScale,1,.8,1.5);p.fade=number(input.fade,.22,0,.4)
    p.idle=number(input.idle,0,0,15);p.movementHold=number(input.movementHold,0,0,5)
    p.combatHold=number(input.combatHold,0,0,8);p.grid=number(input.grid,8,1,32)
    p.speechRate=number(input.speechRate,0,-10,10);p.speechVolume=number(input.speechVolume,70,0,100)
    p.presentation=M.Presentation:Normalize(input.presentation)
    if type(input.modules)=="table" then
        local legacy=rawget(input.modules,"Cursor")
        if legacy~=nil then
            if not legacyCursorValid(legacy) then return input,"Invalid retired cursor settings; original data was preserved." end
            p.modules.Cursor=M:Copy(legacy)
        end
        for id,default in pairs(p.modules) do
            local v=input.modules[id]
            if id~="Cursor" and type(v)=="table" then
                for _,key in ipairs({"enabled","style"}) do if type(v[key])=="boolean" then default[key]=v[key] end end
                if visibilities[v.visibility] then default.visibility=v.visibility end
                default.alpha=number(v.alpha,1,.2,1);default.scale=number(v.scale,1,.6,1.6)
                for _,key in ipairs({"showXP","showZone","showMoney","showClock"}) do
                    if type(default[key])=="boolean" and type(v[key])=="boolean" then default[key]=v[key] end
                end
                for key,definition in pairs(M.FeatureSettings[id] or {}) do
                    if type(definition)=="table" then default[key]=math.floor(number(v[key],definition[1],definition[2],definition[3]))
                    elseif type(v[key])=="boolean" then default[key]=v[key] end
                end
                if id=="Preparations" and type(v.supplyIDs)=="table" then
                    local seen={}
                    for i=1,math.min(8,#v.supplyIDs) do
                        local item=v.supplyIDs[i]
                        if M.Safety:Number(item) and item>0 and item<=2147483647 and item%1==0 and not seen[item] then default.supplyIDs[#default.supplyIDs+1]=item;seen[item]=true end
                    end
                end
                if id=="Auras" and type(v.reminders)=="table" then
                    local seen={}
                    for i=1,math.min(8,#v.reminders) do
                        local sid=v.reminders[i]
                        if M.Safety:Number(sid) and sid>0 and sid<=2147483647 and sid%1==0 and not seen[sid] then
                            default.reminders[#default.reminders+1]=sid;seen[sid]=true
                        end
                    end
                end
                if id=="Cooldowns" and type(v.spells)=="table" then
                    default.groups=normalizeCooldownGroups(v.groups)
                    local groups=cooldownGroupMap(default.groups)
                    local seen={}
                    for i=1,math.min(160,#v.spells) do
                        local item=v.spells[i]
                        if type(item)=="table" and cooldownID(item.id) then
                            local mode=type(item.mode)=="string" and cooldownModes[item.mode] and item.mode or "Cooldown"
                            local selected={id=item.id,mode=mode}
                            if item.bar=="Secondary" then selected.bar="Secondary" end
                            local group=cooldownGroupID(item.group) and groups[item.group]
                            if group and (group.bar==nil or group.bar==(selected.bar or "Primary")) then
                                selected.group=group.id
                            end
                            if type(item.highlight)=="string" and cooldownHighlights[item.highlight] and item.highlight~="None" then selected.highlight=item.highlight end
                            if mode=="ItemAura" and cooldownID(item.auraID) then selected.auraID=item.auraID end
                            -- Older {id,mode} selections survive unchanged. An item
                            -- and its buff are separate sources, even with equal IDs.
                            if mode~="ItemAura" or selected.auraID then
                                local identity=cooldownKey(selected)
                                if not seen[identity] then
                                    if selected.group then groups[selected.group].bar=selected.bar or "Primary" end
                                    default.spells[#default.spells+1]=selected;seen[identity]=true
                                end
                            end
                        end
                    end
                elseif id=="Cooldowns" then
                    default.groups=normalizeCooldownGroups(v.groups)
                end
            end
        end
    end
    if type(input.layouts)=="table" then
        local n=0
        for id,v in pairs(input.layouts) do
            n=n+1
            if n<=160 and type(id)=="string" and #id<90 and id:match("^[%w_%.]+$") and type(v)=="table" then
                local l={x=number(v.x,0,-.48,.48),y=number(v.y,0,-.48,.48),
                    width=number(v.width,220,24,1200),height=number(v.height,50,16,800),scale=number(v.scale,1,.6,M.LayoutScaleMaximum and M:LayoutScaleMaximum(id) or 1.6)}
                if type(v.anchorTo)=="string" and #v.anchorTo<90 and v.anchorTo:match("^[%w_%.]+$") and v.anchorTo~=id then l.anchorTo=v.anchorTo end
                p.layouts[id]=l
            end
        end
    end
    if type(input.cursorProfile)=="table" then
        -- Archived preferences from the retired embedded cursor are data only.
        p.cursorProfile=M:Copy(input.cursorProfile)
    end
    -- Drop cyclic anchor edges, not entire profiles.
    for id,layout in pairs(p.layouts) do
        local seen={[id]=true};local nextID=layout.anchorTo
        for _=1,161 do
            if not nextID then break end
            if seen[nextID] then layout.anchorTo=nil;break end
            seen[nextID]=true;nextID=p.layouts[nextID] and p.layouts[nextID].anchorTo
        end
    end
    if type(input.rules)=="table" and M.Predicate then
        for i=1,math.min(24,#input.rules) do
            local r=input.rules[i]
            if type(r)=="table" and type(r.module)=="string" and (p.modules[r.module] or r.module=="Cursor") and
                M.States[r.state] and r.state~="PROTECTED_FLOOR" and M.Predicate:UserAllowed(r.when) then
                p.rules[#p.rules+1]={module=r.module,state=r.state,when=M:Copy(r.when),
                    enabled=r.enabled==true,id="USER-"..i,priority=2,tieRank=20,
                    dwell=number(r.dwell,0,0,10)}
            end
        end
    end
    return p
end
function P:Initialize()
    if initializing or writer or M.applying or not rawequal(M.Profiles,P) then return false end
    initializing=true
    local live,state,client,safety=M.profile,M.state,M.Client,M.Safety
    local originalA,originalC=MirageUIDB,MirageUICharacterDB
    local family,clientKey=client.family,client.key
    local function preserve(reason)
        -- Never overwrite a newer live/suite owner while refusing old roots.
        if rawequal(M.Profiles,P) and rawequal(M.profile,live) and rawequal(M.state,state) then
            local fallback=profileSchema();fallback.enabled=false
            if rawequal(M.Profiles,P) and rawequal(M.profile,live) and rawequal(M.state,state) then
                P.readOnly=true;P.readOnlyReason=reason;M.profile=fallback;state.safe=true;state.safeReason=reason
            end
        end
        return false
    end
    local ok,result=pcall(function()
        local boot={data={},count=0};local owners={};local archiveTables={}
        local function slot(object,key) owners[#owners+1]={object=object,key=key,value=rawget(object,key)} end
        local function shallowSeal(object)
            if type(object)~="table" or getmetatable(object)~=nil then return false end
            local row={object=object,fields={},count=0};boot.data[#boot.data+1]=row
            for k,v in next,object do row.count=row.count+1;boot.count=boot.count+1;if row.count>10000 or boot.count>100000 then return false end;row.fields[#row.fields+1]={key=k,value=v} end
            return true
        end
        local function rawProfile(value,depth,seen)
            depth=depth or 0;seen=seen or {}
            if depth>24 then return false end
            if type(value)~="table" then return true end
            if seen[value] then return false end;seen[value]=true
            if not shallowSeal(value) then return false end
            local row=boot.data[#boot.data]
            for _,entry in ipairs(row.fields) do if not rawProfile(entry.value,depth+1,seen) then return false end end
            seen[value]=nil;return true
        end
        for _,key in ipairs({"Profiles","db","Client","Safety","References","Presentation","state","schema","Copy","applying","CursorPreferenceData","CursorPreferenceEnvelope"}) do slot(M,key) end
        for _,key in ipairs({"Defaults","Validate","account","character","readOnly","readOnlyReason","undo"}) do slot(P,key) end
        for _,key in ipairs({"family","key","allowed"}) do slot(client,key) end
        for _,key in ipairs({"BoundaryReady","Readable","Number","Text","Public"}) do slot(safety,key) end
        for _,key in ipairs({"Profile","SavedPreflight","Empty","Validate"}) do slot(M.References,key) end
        slot(M.Presentation,"Defaults");slot(M.Presentation,"Normalize")
        for _,key in ipairs({"initialized","safe","safeReason"}) do slot(state,key) end
        for _,box in ipairs({{originalA},{originalC}}) do
            local root=box[1]
            if root~=nil then
                if not shallowSeal(root) then return preserve("UNKNOWN_SCHEMA_PRESERVED") end
                local clients=rawget(root,"clients")
                if type(clients)=="table" then
                    if not shallowSeal(clients) then return preserve("UNKNOWN_SCHEMA_PRESERVED") end
                    local branch=rawget(clients,family)
                    if type(branch)=="table" then
                        if not shallowSeal(branch) then return preserve("UNKNOWN_SCHEMA_PRESERVED") end
                        local profile=rawget(branch,"profile")
                        if rawequal(root,originalA) or rawget(branch,"useCharacter") then
                            if not rawProfile(profile) then return preserve("PROFILE_DATA_PRESERVED") end
                        end
                        if type(profile)=="table" and rawget(profile,"cursorPreferences")~=nil then
                            if rawget(root,"schema")~=2 or not rawProfile(rawget(profile,"cursorPreferences")) then return preserve("CURSOR_PREFERENCE_DATA_PRESERVED") end
                        end
                    end
                end
            end
        end
        local function owned()
            if not rawequal(M.profile,live) or not rawequal(MirageUIDB,originalA) or not rawequal(MirageUICharacterDB,originalC) then return false end
            for _,row in ipairs(owners) do if type(row.object)~="table" or getmetatable(row.object)~=nil or not rawequal(rawget(row.object,row.key),row.value) then return false end end
            for _,row in ipairs(boot.data) do if archiveTables[row.object] then return false end end
            return dataCurrent(boot.data)
        end
        -- Raw identity/membership capture above performs no saved scalar
        -- arithmetic or normalization before this boundary callback.
        if not safety:BoundaryReady() then return preserve("SECRET_BOUNDARY_UNAVAILABLE") end
        if not owned() then return preserve("PROFILE_OWNERSHIP_CHANGED") end
        if M.Rework and M.Rework.CodeRollbackPending and M.Rework:CodeRollbackPending() then
            -- A mistaken reload before replacing b35 must not refine the just
            -- restored b34 roots again. Keep exact raw roots and native access.
            M.Rework.rollbackPendingReload=true;M.Rework.rolledBack=true
            return preserve("ROLLBACK_CODE_REPLACEMENT_REQUIRED")
        end
        local a,c=originalA,originalC
        local E=rawget(M,"CursorPreferenceEnvelope");local roots,rootsUnchanged
        if type(E)=="table" and type(E.Pair)=="function" then
            roots,rootsUnchanged=E:Pair(a,c,function(v) return safety:Readable(v) end)
        else
            local function legacy(r) return r==nil or (type(r)=="table" and getmetatable(r)==nil and rawget(r,"schema")==1 and rawget(r,"cursorPreferenceRecovery")==nil) end
            if legacy(a) and legacy(c) then roots={account=1,character=1};rootsUnchanged=function() return true end end
        end
        if not roots then return preserve("UNKNOWN_SCHEMA_PRESERVED") end
        for _,rows in ipairs({roots.accountNodes or {},roots.characterNodes or {}}) do for _,row in ipairs(rows) do archiveTables[row.object]=true end end
        if not owned() then return preserve("PROFILE_OWNERSHIP_CHANGED") end
        -- Both current-family slots are checked, including inactive character
        -- envelopes; unrelated named/family bodies remain opaque.
        for _,box in ipairs({{a},{c}}) do
            local root=box[1];local map=type(root)=="table" and rawget(root,"clients")
            local branch=type(map)=="table" and rawget(map,family)
            local profile=type(branch)=="table" and rawget(branch,"profile")
            local valid=preferenceEnvelope(profile)
            if not valid then return preserve("CURSOR_PREFERENCE_DATA_PRESERVED") end
        end
        local referencesOK,_,referencesUnchanged=M.References:SavedPreflight(a,c,family)
        if not referencesOK then return preserve("REFERENCE_DATA_PRESERVED") end
        local function shallow(value) local copy={};for k,v in next,value do copy[k]=v end;return copy end
        a=shallow(a or {schema=M.schema,clients={},safe=false});c=shallow(c or {schema=M.schema,clients={}})
        if type(a.clients)=="table" then a.clients=shallow(a.clients) else a.clients={} end
        if type(c.clients)=="table" then c.clients=shallow(c.clients) else c.clients={} end
        local cc=c.clients[family];if type(cc)~="table" then cc={useCharacter=false} else cc=shallow(cc) end
        local ac=a.clients[family]
        if type(ac)~="table" then ac={profile=self:Defaults(),named={},beta34VisualRevision=1} else ac=shallow(ac) end
        -- Only the selected scope is normalized or refined. Inactive account
        -- and named profile bodies stay opaque until explicitly selected.
        if not cc.useCharacter then
            local accountProfile,accountWhy=self:Validate(ac.profile)
            if accountWhy then return preserve("PROFILE_DATA_PRESERVED") end
            ac.profile=accountProfile;refineBeta34(ac);refineSelectedProfile(ac.profile)
        end
        ac.named=type(ac.named)=="table" and ac.named or {}
        if cc.useCharacter then
            local characterProfile,characterWhy=self:Validate(cc.profile)
            if characterWhy then return preserve("PROFILE_DATA_PRESERVED") end
            cc.profile=characterProfile
            refineBeta34(cc);refineSelectedProfile(cc.profile)
        end
        a.clients[family]=ac;c.clients[family]=cc
        if ac.lastClient~=clientKey then ac.nativeEvidence={};ac.lastClient=clientKey end
        if not owned() or not referencesUnchanged() or not rootsUnchanged() then return preserve("PROFILE_OWNERSHIP_CHANGED") end
        -- Already-built tables only after the final raw custody seal.
        MirageUIDB,MirageUICharacterDB=a,c
        M.db=a;self.account=ac;self.character=cc
        M.profile=cc.useCharacter and cc.profile or ac.profile
        self.readOnly=false;self.readOnlyReason=nil;M.state.safe=a.safe==true or not client.allowed;undoRecord=nil
        return true
    end)
    initializing=nil
    if not ok then return preserve("PROFILE_DATA_PRESERVED") end
    return result==true
end
-- Validate a proposed transaction without repairing it. Boot-time migration may
-- normalize legacy preferences; Apply/import must reject malformed proposals whole.
function P:CheckTransaction(input)
    if type(input)~="table" then return false,"A complete settings draft is required." end
    if input.beta51Revision~=nil and (not M.Safety:Number(input.beta51Revision) or input.beta51Revision%1~=0 or input.beta51Revision<0 or input.beta51Revision>1) then
        return false,"This profile uses an unknown beta51 revision; its original data was preserved."
    end
    if input.beta52Revision~=nil and (not M.Safety:Number(input.beta52Revision) or input.beta52Revision%1~=0 or input.beta52Revision<0 or input.beta52Revision>1) then
        return false,"This profile uses an unknown beta52 revision; its original data was preserved."
    end
    if input.beta57NativeNamesRevision~=nil and (not M.Safety:Number(input.beta57NativeNamesRevision) or input.beta57NativeNamesRevision%1~=0 or input.beta57NativeNamesRevision<0 or input.beta57NativeNamesRevision>1) then
        return false,"This profile uses an unknown beta57 native-name revision; its original data was preserved."
    end
    local references,referenceWhy=M.References:Profile(input);if not references then return false,referenceWhy end
    local visiting,nodes={},0
    local function data(value,depth)
        nodes=nodes+1
        if nodes>10000 or depth>24 or not M.Safety:Readable(value) then return false end
        if type(value)=="table" then
            if visiting[value] or getmetatable(value)~=nil then return false end
            visiting[value]=true
            for k,v in pairs(value) do
                if not M.Safety:Readable(k) or (type(k)~="string" and type(k)~="number") then return false end
                if not data(v,depth+1) then return false end
            end
            visiting[value]=nil;return true
        end
        return type(value)=="boolean" or (type(value)=="string" and #value<=4096) or M.Safety:Number(value)
    end
    if not data(input,0) then return false,"Invalid, cyclic or oversized settings data." end
    local contexts,contextWhy=M.ElementRules:Validate(input.elementContexts)
    if not contexts then return false,contextWhy end
    local schema=profileSchema()
    for key in pairs(input) do
        if schema[key]==nil and key~="cursorProfile" and key~="cursorPreferences" then return false,"Unknown general settings were rejected." end
    end
    local envelopeOK,envelopeWhy=preferenceEnvelope(input);if not envelopeOK then return false,envelopeWhy end
    local presentationOK,presentationWhy=M.Presentation:Check(input.presentation)
    if not presentationOK then return false,presentationWhy end
    -- The bounded plain-data check above applies to this archived subprofile.
    -- It has no live cursor consumer; standalone Cursor Companion owns validation
    -- and publication of its own independent SavedVariables.
    if input.cursorProfile~=nil and type(input.cursorProfile)~="table" then return false,"Invalid archived cursor profile." end
    for _,key in ipairs({"enabled","managed","autoLayout","managedDismissed","onboarding","onboardingDismissed","contrast","gamepadNavigation","spokenLabels"}) do
        if input[key]~=nil and type(input[key])~="boolean" then return false,"Invalid general toggle." end
    end
    if input.preset~=nil and not presets[input.preset] then return false,"Unknown presentation preset." end
    local ranges={b35Revision={0,1},sidebarWidthRevision={0,1},nameplateWorldNamesRevision={0,1},beta48Revision={0,1},beta49Revision={0,1},beta51Revision={0,1},beta52Revision={0,1},beta57NativeNamesRevision={0,1},textScale={.8,1.5},fade={0,.4},idle={0,15},movementHold={0,5},combatHold={0,8},grid={1,32},speechRate={-10,10},speechVolume={0,100}}
    for k,b in pairs(ranges) do local v=input[k];if v~=nil and (not M.Safety:Number(v) or v<b[1] or v>b[2]) then return false,"A settings value is outside its allowed range." end end
    if input.sidebarWidthRevision~=nil and input.sidebarWidthRevision%1~=0 then return false,"A sidebar width revision must be a whole number." end
    if input.nameplateWorldNamesRevision~=nil and input.nameplateWorldNamesRevision%1~=0 then return false,"A native world-name revision must be a whole number." end
    if input.beta48Revision~=nil and input.beta48Revision%1~=0 then return false,"A beta48 revision must be a whole number." end
    if input.beta49Revision~=nil and input.beta49Revision%1~=0 then return false,"A beta49 revision must be a whole number." end
    if input.beta51Revision~=nil and input.beta51Revision%1~=0 then return false,"A beta51 revision must be a whole number." end
    if input.beta52Revision~=nil and input.beta52Revision%1~=0 then return false,"A beta52 revision must be a whole number." end
    if input.beta57NativeNamesRevision~=nil and input.beta57NativeNamesRevision%1~=0 then return false,"A beta57 native-name revision must be a whole number." end
    if input.modules~=nil and type(input.modules)~="table" then return false,"Invalid module settings." end
    for id,cfg in pairs(input.modules or {}) do
        local moduleSchema=id=="Cursor" and legacyCursorSchema or schema.modules[id]
        if not moduleSchema or type(cfg)~="table" then return false,"Unknown module settings." end
        for key in pairs(cfg) do if moduleSchema[key]==nil then return false,"Unknown module settings were rejected." end end
        if cfg.visibility~=nil and not visibilities[cfg.visibility] then return false,"Invalid visibility choice." end
        for _,key in ipairs({"enabled","style","showXP","showZone","showMoney","showClock"}) do
            if cfg[key]~=nil and type(cfg[key])~="boolean" then return false,"Invalid module toggle." end
        end
        for key,bounds in pairs({alpha={.2,1},scale={.6,1.6}}) do
            if cfg[key]~=nil and (not M.Safety:Number(cfg[key]) or cfg[key]<bounds[1] or cfg[key]>bounds[2]) then return false,"Invalid module geometry or opacity." end
        end
        if id=="Preparations" and cfg.supplyIDs~=nil then
            if type(cfg.supplyIDs)~="table" or #cfg.supplyIDs>8 then return false,"Choose up to eight supply item IDs." end
            local seen,count={},0
            for index,item in pairs(cfg.supplyIDs) do
                count=count+1
                if not M.Safety:Number(index) or index%1~=0 or index<1 or index>#cfg.supplyIDs or not M.Safety:Number(item) or item%1~=0 or item<1 or item>2147483647 or seen[item] then return false,"Supply IDs must be unique positive whole numbers in a contiguous list." end
                seen[item]=true
            end
            if count~=#cfg.supplyIDs then return false,"Invalid supply ID sequence." end
        end
        if id=="Cooldowns" then
            local groups={}
            if cfg.groups~=nil then
                if type(cfg.groups)~="table" or getmetatable(cfg.groups)~=nil or #cfg.groups>64 then return false,"Choose up to 64 tracker groups." end
                local count=0
                for index,g in pairs(cfg.groups) do
                    count=count+1
                    if not M.Safety:Number(index) or index%1~=0 or index<1 or index>#cfg.groups or type(g)~="table" or getmetatable(g)~=nil
                        or not cooldownGroupID(g.id) or groups[g.id] or not cooldownGroupName(g.name)
                        or g.bar~=nil and not cooldownBars[g.bar] then return false,"Invalid tracker group identity, name or display." end
                    for key in pairs(g) do if not ({id=true,name=true,r=true,g=true,b=true,alpha=true,bar=true})[key] then return false,"Unknown tracker group setting." end end
                    for _,key in ipairs({"r","g","b","alpha"}) do
                        if not M.Safety:Number(g[key]) or g[key]<0 or g[key]>1 then return false,"Tracker group color and opacity must be between zero and one." end
                    end
                    groups[g.id]=g
                end
                if count~=#cfg.groups then return false,"Invalid tracker group sequence." end
            end
            local spells=cfg.spells;if spells==nil then spells={} end
            if type(spells)~="table" or getmetatable(spells)~=nil or #spells>160 then return false,"Invalid tracked cooldown list." end
            local seen={};local count=0
            for index,item in pairs(spells) do
                count=count+1
                if not M.Safety:Number(index) or index%1~=0 or index<1 or index>#spells or type(item)~="table" or getmetatable(item)~=nil
                    or not cooldownID(item.id) or not M.Safety:Text(item.mode) or not cooldownModes[item.mode]
                    or item.mode=="ItemAura" and not cooldownID(item.auraID)
                    or item.mode~="ItemAura" and item.auraID~=nil
                    or item.highlight~=nil and (not M.Safety:Text(item.highlight) or not cooldownHighlights[item.highlight])
                    or item.bar~=nil and not cooldownBars[item.bar]
                    or item.group~=nil and (not cooldownGroupID(item.group) or not groups[item.group]
                        or groups[item.group].bar~=(item.bar or "Primary")) then return false,"Invalid tracked cooldown entry or group display." end
                for key in pairs(item) do if not ({id=true,mode=true,auraID=true,highlight=true,bar=true,group=true})[key] then return false,"Unknown tracked cooldown entry setting." end end
                local identity=cooldownKey(item)
                if seen[identity] then return false,"Duplicate tracked cooldown source." end
                seen[identity]=true
            end
            if count~=#spells then return false,"Invalid tracked-spell sequence." end
        end
        if id=="Auras" and cfg.reminders~=nil then
            if type(cfg.reminders)~="table" or #cfg.reminders>8 then return false,"Invalid reminder list." end
            local seen={};local count=0
            for index,id in pairs(cfg.reminders) do
                count=count+1
                if not M.Safety:Number(index) or index%1~=0 or index<1 or index>#cfg.reminders or not M.Safety:Number(id) or id%1~=0 or id<=0 or id>2147483647 or seen[id] then return false,"Invalid reminder entry." end
                seen[id]=true
            end
            if count~=#cfg.reminders then return false,"Invalid reminder sequence." end
        end
        for key,definition in pairs(M.FeatureSettings[id] or {}) do
            local v=cfg[key]
            if v~=nil and type(definition)=="table" and (not M.Safety:Number(v) or v%1~=0 or v<definition[2] or v>definition[3]) then return false,"A module value is outside its allowed range." end
            if v~=nil and type(definition)=="boolean" and type(v)~="boolean" then return false,"Invalid module toggle." end
        end
    end
    local layouts=input.layouts or {};local n=0
    if type(layouts)~="table" then return false,"Invalid layout data." end
    for id,l in pairs(layouts) do
        n=n+1;if n>160 or type(id)~="string" or not id:match("^[%w_%.]+$") or type(l)~="table" then return false,"Invalid layout." end
        local layoutKeys={x=true,y=true,width=true,height=true,scale=true,anchorTo=true}
        for key in pairs(l) do if not layoutKeys[key] then return false,"Unknown layout settings were rejected." end end
        for k,b in pairs({x={-.48,.48},y={-.48,.48},width={24,1200},height={16,800},scale={.6,M.LayoutScaleMaximum and M:LayoutScaleMaximum(id) or 1.6}}) do
            if l[k]~=nil and (not M.Safety:Number(l[k]) or l[k]<b[1] or l[k]>b[2]) then return false,"A layout value is outside its allowed range." end
        end
        local seen={[id]=true};local nextID=l.anchorTo
        for _=1,161 do
            if not nextID then break end
            if type(nextID)~="string" or seen[nextID] then return false,"A layout anchor cycle was rejected." end
            if not layouts[nextID] and not M.surfaces[nextID] then return false,"A layout anchor is missing." end
            seen[nextID]=true;nextID=layouts[nextID] and layouts[nextID].anchorTo
        end
    end
    if input.rules~=nil and type(input.rules)~="table" then return false,"Invalid condition list." end
    if #(input.rules or {})>24 then return false,"Too many custom conditions." end
    local ruleCount=0
    for key in pairs(input.rules or {}) do
        ruleCount=ruleCount+1
        if not M.Safety:Number(key) or key%1~=0 or key<1 or key>#input.rules then return false,"Invalid condition sequence." end
    end
    if ruleCount~=#(input.rules or {}) then return false,"Invalid condition sequence." end
    for _,rule in ipairs(input.rules or {}) do
        if type(rule)~="table" or (rule.module~="Cursor" and not M.CatalogByID[rule.module]) or not M.States[rule.state] or rule.state=="PROTECTED_FLOOR" or not M.Predicate:UserAllowed(rule.when) then return false,"An invalid condition was rejected." end
        local keys={module=true,state=true,when=true,enabled=true,id=true,priority=true,tieRank=true,dwell=true}
        for key in pairs(rule) do if not keys[key] then return false,"Unknown condition fields were rejected." end end
        if (rule.priority~=nil and rule.priority~=2) or (rule.tieRank~=nil and rule.tieRank~=20) then return false,"Custom rules cannot change authority tiers." end
        if rule.enabled~=nil and type(rule.enabled)~="boolean" then return false,"Invalid condition toggle." end
        if rule.dwell~=nil and (not M.Safety:Number(rule.dwell) or rule.dwell<0 or rule.dwell>10) then return false,"Invalid condition hold." end
    end
    return true
end
-- Serialize suite profile-slot writes, not native effects or other addons' saved
-- roots. Apply sees a detached provisional live profile; saved slots and mode are
-- published only after successful Apply, validation and a final ownership seal.
local ownershipLost="Settings ownership changed. No saved profile was published; current runtime recovery requires review."
local function plain(value) return type(value)=="table" and getmetatable(value)==nil end
local function raw(object,key) if type(object)=="table" then return rawget(object,key) end end
-- Stop/resume persistence is a tiny data-only write, separate from publication
-- of profile slots. It cannot overwrite a read-only/future or successor root,
-- and waits until an in-flight profile transaction has released its seal.
function P:WriteSafeIntent(enabled)
    if writer or initializing then return false,"PROFILE_BUSY" end
    if not rawequal(self,P) or not rawequal(M.Profiles,P) or type(enabled)~="boolean" then return false,"OWNERSHIP_CHANGED" end
    if P.readOnly then return false,"READ_ONLY" end
    local db,character,client=M.db,MirageUICharacterDB,M.Client
    if not plain(db) or not rawequal(MirageUIDB,db) or not plain(character) or not plain(client) then return false,"OWNERSHIP_CHANGED" end
    if (raw(db,"schema")~=1 and raw(db,"schema")~=2) or (raw(character,"schema")~=1 and raw(character,"schema")~=2) then return false,"READ_ONLY" end
    local family=raw(client,"family");local accounts,characters=raw(db,"clients"),raw(character,"clients")
    if type(family)~="string" or not plain(accounts) or not plain(characters) or not plain(P.account) or not plain(P.character)
        or not rawequal(raw(accounts,family),P.account) or not rawequal(raw(characters,family),P.character) then return false,"OWNERSHIP_CHANGED" end
    rawset(db,"safe",enabled)
    if M.Incidents then M.Incidents:SetStop(enabled and (M.state.safeReason or "SAVED_SAFE_MODE") or false) end
    return true
end
local function remember(t,object,key)
    t.slots[#t.slots+1]={object=object,key=key,value=raw(object,key)}
end
captureData=function(t,value)
    local visiting,done,count={},{},0
    local function walk(item,depth)
        if depth>24 then return false end
        local kind=type(item)
        if kind=="nil" or kind=="boolean" then return true end
        if kind=="string" then return #item<=4096 end
        if kind=="number" then return item==item and item~=math.huge and item~=-math.huge end
        if kind~="table" or not plain(item) or visiting[item] then return false end
        if done[item] then return true end
        visiting[item]=true
        local node={object=item,fields={},count=0};t.data[#t.data+1]=node
        for key,child in next,item do
            count=count+1;if count>10000 then return false end
            if type(key)~="string" and type(key)~="number" then return false end
            if type(key)=="string" and #key>4096 then return false end
            if type(key)=="number" and (key~=key or key==math.huge or key==-math.huge) then return false end
            node.count=node.count+1;node.fields[#node.fields+1]={key=key,value=child}
            if not walk(child,depth+1) then return false end
        end
        visiting[item]=nil;done[item]=true;return true
    end
    return walk(value,0)
end
dataCurrent=function(nodes)
    for _,node in ipairs(nodes) do
        if not plain(node.object) then return false end
        local count=0
        for _ in next,node.object do count=count+1;if count>node.count then return false end end
        if count~=node.count then return false end
        for _,entry in ipairs(node.fields) do
            if not rawequal(rawget(node.object,entry.key),entry.value) then return false end
        end
    end
    return true
end
local function dataSeal(t,value,detached)
    local snapshot={data={}}
    if not captureData(snapshot,value) then return nil end
    if detached then
        local original={};for _,node in ipairs(t.data) do original[node.object]=true end
        for _,node in ipairs(snapshot.data) do if original[node.object] then return nil end end
    end
    return function() return dataCurrent(snapshot.data) end,snapshot.data
end
local function sameData(a,b)
    local count=0
    local function equal(left,right,depth)
        count=count+1;if count>10000 or depth>24 or type(left)~=type(right) then return false end
        if type(left)~="table" then return rawequal(left,right) end
        for key,value in next,left do if not equal(value,rawget(right,key),depth+1) then return false end end
        for key in next,right do if rawget(left,key)==nil then return false end end
        return true
    end
    return equal(a,b,0)
end
local function current(t)
    if not rawequal(writer,t) or not rawequal(M.profile,t.liveExpected)
        or not rawequal(MirageUIDB,t.savedAccount) or not rawequal(MirageUICharacterDB,t.savedCharacter) then return false end
    if t.archiveTables then
        for _,row in ipairs(t.data) do if t.archiveTables[row.object] then return false end end
        for _,row in ipairs(t.slots) do if t.archiveTables[row.object] then return false end end
    end
    for _,entry in ipairs(t.slots) do
        if not plain(entry.object) or not rawequal(rawget(entry.object,entry.key),entry.value) then return false end
    end
    return dataCurrent(t.data) and (not t.envelopeSeal or t.envelopeSeal()) and (not t.rootsSeal or t.rootsSeal())
end
local function capture(t)
    t.slots={};t.data={};t.savedAccount=MirageUIDB;t.savedCharacter=MirageUICharacterDB
    t.account=P.account;t.character=P.character;t.previous=M.profile;t.liveExpected=t.previous
    t.layout=M.AdaptiveLayout;t.oldPlan=raw(t.layout,"plan");t.oldFingerprint=raw(t.layout,"fingerprint")
    t.client=M.Client;t.safety=M.Safety;t.references=M.References
    for _,object in ipairs({M,P}) do if not plain(object) then return false end end
    for _,key in ipairs({"account","character"}) do if not plain(raw(P,key)) then return false end end
    for _,key in ipairs({"profile","Client","Safety","References","state"}) do if not plain(raw(M,key)) then return false end end
    if not plain(t.savedAccount) or not plain(t.savedCharacter) or not rawequal(M.db,t.savedAccount)
        or not rawequal(M.Profiles,P) or type(raw(t.client,"family"))~="string" then return false end
    local family=t.client.family
    local ac,cc=raw(t.savedAccount,"clients"),raw(t.savedCharacter,"clients")
    if not plain(ac) or not plain(cc) or not rawequal(raw(ac,family),t.account) or not rawequal(raw(cc,family),t.character) then return false end
    for _,key in ipairs({"Profiles","db","Client","Safety","References","state","AdaptiveLayout","Copy","ApplyProfile","CursorPreferenceData","CursorPreferenceEnvelope","schema"}) do remember(t,M,key) end
    for _,key in ipairs({"account","character","readOnly","undo","CheckTransaction","Validate"}) do remember(t,P,key) end
    for _,key in ipairs({"family","key","allowed"}) do remember(t,t.client,key) end
    for _,key in ipairs({"InCombat","Readable","Number","Text","Public","BoundaryReady"}) do remember(t,t.safety,key) end
    remember(t,t.references,"Profile");remember(t,M.state,"initialized")
    for _,root in ipairs({t.savedAccount,t.savedCharacter}) do remember(t,root,"schema");remember(t,root,"clients");remember(t,root,"cursorPreferenceRecovery") end
    remember(t,ac,family);remember(t,cc,family)
    remember(t,t.account,"profile");remember(t,t.character,"profile");remember(t,t.character,"useCharacter")
    t.oldMode=raw(t.character,"useCharacter");t.oldUndo=P.undo
    t.copy=M.Copy;t.apply=M.ApplyProfile;t.check=P.CheckTransaction;t.validate=P.Validate
    if type(t.copy)~="function" or type(t.apply)~="function" or type(t.check)~="function" or type(t.validate)~="function"
        or type(t.safety.InCombat)~="function" or type(t.references.Profile)~="function" then return false end
    -- Unselected profile bodies and an unused undo record remain opaque. Seal
    -- their slot identities above, but do not reject unrelated future data.
    local selected=t.oldMode and t.character or t.account
    for _,box in ipairs({{t.previous},{raw(selected,"profile")}}) do
        if not captureData(t,box[1]) then return false end
    end
    t.envelopes=raw(M,"CursorPreferenceEnvelope")
    if t.envelopes~=nil then
        if not plain(t.envelopes) or type(t.envelopes.Seal)~="function" then return false end
        t.envelopeSeal=t.envelopes:Seal();if not t.envelopeSeal then return false end
    elseif raw(t.savedAccount,"schema")~=1 or raw(t.savedCharacter,"schema")~=1 then return false end
    return current(t)
end
local function permitted(t,appliedDataOnly)
    if not current(t) then return false,ownershipLost end
    -- Root readability/archive callbacks run only after each operation has
    -- sealed its draft or source/target data, never inside initial capture.
    if t.envelopes and not t.rootsSeal then
        local pair,seal=t.envelopes:Pair(t.savedAccount,t.savedCharacter,function(v) return t.safety:Readable(v) end)
        if not pair then return false,"Saved root/recovery data is unsupported; original data was preserved." end
        t.rootVersions=pair;t.rootsSeal=seal;t.archiveTables={}
        for _,rows in ipairs({pair.accountNodes,pair.characterNodes}) do for _,row in ipairs(rows) do t.archiveTables[row.object]=true end end
        if not current(t) then return false,ownershipLost end
    end
    if P.readOnly then return false,"A newer or unknown settings format was preserved. Nothing was overwritten." end
    if M.state.initialized~=true or M.applying then return false,"Settings are already applying or not ready. Try again after the current operation." end
    local combat=t.safety:InCombat()
    -- Entry/pre-Apply must be out of combat. Once Apply has returned true,
    -- retain its existing successful preference-save semantics even if combat
    -- or uncertain native legality arose during optional work. The remaining
    -- publication is raw data only; this does not authorize any native action.
    if combat~=false and not (appliedDataOnly and combat==true) then return false,"Save changes after combat." end
    if not current(t) then return false,ownershipLost end
    if M.state.initialized~=true or M.applying then return false,"Settings are already applying or not ready. Try again after the current operation." end
    return true
end
local function rollback(t)
    if not t.provisional or t.committed then return true end
    -- Never reapply an older profile, restore a cache, or write a saved branch
    -- after a callback has handed ownership to a successor or edited the source.
    if not current(t) or M.applying then return false end
    rawset(M,"profile",t.previous);t.liveExpected=t.previous
    if t.layout then rawset(t.layout,"plan",t.oldPlan);rawset(t.layout,"fingerprint",t.oldFingerprint) end
    -- Best-effort existing runtime restoration is not native atomicity. Saved
    -- profile slots/mode/undo have not been written by this transaction.
    pcall(t.apply,M,t.forceLayout,"PROFILE_ROLLBACK",t.applyAttempt)
    return true
end
local function write(receiver,operation)
    if writer or initializing then return false,"Another settings transaction is in progress." end
    if not rawequal(receiver,P) or not rawequal(M.Profiles,P) then return false,ownershipLost end
    if P.readOnly then return false,"A newer or unknown settings format was preserved. Nothing was overwritten." end
    local t={committed=false};writer=t
    local ok,success,why=pcall(function()
        if not capture(t) then return false,"Settings owners or existing profile data are unavailable; original data was preserved." end
        t.captured=true
        return operation(t)
    end)
    if t.captured and not t.committed and not current(t) then success=false;why=ownershipLost end
    local restored=true
    if not ok or success~=true then
        local safe,value=pcall(rollback,t);restored=safe and value==true
    end
    writer=nil
    if not restored then return false,ownershipLost end
    if not ok then return false,"Settings transaction failed. Existing saved profile slots were retained." end
    return success==true,why
end
local function applyCandidate(t,p,forceLayout,publish,extrasCurrent,excludedNodes)
    if not current(t) then return false,ownershipLost end
    if not plain(p) or rawequal(p,t.previous) or rawequal(p,raw(t.account,"profile")) or rawequal(p,raw(t.character,"profile")) then
        return false,"A detached settings candidate is required; original data was preserved."
    end
    local candidateCurrent,candidateNodes=dataSeal(t,p,true)
    local excluded={};for _,node in ipairs(excludedNodes or {}) do excluded[node.object]=true end
    local function independent(nodes)
        for _,node in ipairs(nodes or {}) do if excluded[node.object] then return false end end
        return true
    end
    if not independent(candidateNodes) then return false,"Prepared profile and undo must be independent." end
    if not candidateCurrent then return false,"A detached settings candidate is required; original data was preserved." end
    -- Existing Apply may normalize legacy layout/geometry, but owns no new
    -- authored envelope. Its exact identity/content must survive unchanged.
    local authored=rawget(p,"cursorPreferences");local authoredSeal=dataSeal(t,authored,false)
    if not authoredSeal then return false,"Invalid authored cursor preferences." end
    local function authoredCurrent() return rawequal(rawget(p,"cursorPreferences"),authored) and authoredSeal() end
    local valid,reason=t.check(P,p);if valid~=true then return false,reason end
    if not current(t) then return false,ownershipLost end
    if not candidateCurrent() or (extrasCurrent and not extrasCurrent()) then return false,"Prepared settings changed during validation." end
    local allowed,why=permitted(t);if not allowed then return false,why end
    if not candidateCurrent() or (extrasCurrent and not extrasCurrent()) then return false,"Prepared settings changed before apply." end
    t.forceLayout=forceLayout;t.provisional=true;t.liveExpected=p;rawset(M,"profile",p)
    local result,attempt=t.apply(M,forceLayout,t.trigger or "PROFILE_COMMIT")
    t.applyAttempt=attempt
    if not current(t) then return false,ownershipLost end
    if result~=true then return false,"Settings apply was not confirmed. Previous settings are retained; MirageUI may still require recovery." end
    candidateCurrent,candidateNodes=dataSeal(t,p,true)
    if not candidateCurrent or not independent(candidateNodes) or not authoredCurrent() then return false,"Applied settings changed authored preferences or undo ownership." end
    valid,reason=t.check(P,p);if valid~=true then return false,reason end
    if not candidateCurrent() or (extrasCurrent and not extrasCurrent()) then return false,"Applied settings changed during validation." end
    allowed,why=permitted(t,true);if not allowed then return false,why end
    if not candidateCurrent() or (extrasCurrent and not extrasCurrent()) then return false,"Prepared settings changed before publication." end
    -- No callbacks after the final ownership/combat seal. Publication cannot
    -- select a different scope because of an Apply callback.
    publish(p);t.committed=true;return true
end
local function commit(receiver,input,forceLayout,record,trigger)
    return write(receiver,function(t)
        t.trigger=trigger
        local removeEnvelope=record~=nil and rawequal(record,undoRecord) and rawequal(input,t.oldUndo) and rawequal(input,record.object) and record.current()
        if record~=nil and not removeEnvelope then return false,"The undo record changed; current preferences were preserved." end
        local inputCurrent=dataSeal(t,input,false)
        if not inputCurrent then return false,"Invalid settings data was preserved without publication." end
        local allowed,why=permitted(t);if not allowed then return false,why end
        if not inputCurrent() then return false,"The settings draft changed before validation." end
        local valid,reason=t.check(P,input);if valid~=true then return false,reason end
        if not current(t) then return false,ownershipLost end
        if not inputCurrent() then return false,"The settings draft changed during validation." end
        local previousReferences,referenceWhy=t.references:Profile(t.previous);if not previousReferences then return false,referenceWhy end
        if not current(t) then return false,ownershipLost end
        local p,normalizationWhy=t.validate(P,input);if normalizationWhy then return false,normalizationWhy end
        refineSelectedProfile(p)
        if rawget(p,"cursorPreferences")==nil and rawget(t.previous,"cursorPreferences")~=nil and not removeEnvelope then
            local valid,envelope=preferenceEnvelope(t.previous);if not valid then return false,envelope end
            p.cursorPreferences=envelope
        elseif rawget(p,"cursorPreferences")~=nil and not removeEnvelope then
            local envelope,why=t.envelopes:CarryPolicy(p.cursorPreferences,rawget(t.previous,"cursorPreferences"),t.client.family,function(v) return t.safety:Readable(v) end)
            if not envelope then return false,why end
            p.cursorPreferences=envelope
        end
        local selectedRoot=t.oldMode and t.savedCharacter or t.savedAccount
        if rawget(p,"cursorPreferences")~=nil and rawget(selectedRoot,"schema")~=2 then return false,"Publish cursor preferences explicitly before storing them in this legacy scope." end
        if not current(t) then return false,ownershipLost end
        if not inputCurrent() then return false,"The settings draft changed during preparation." end
        -- Publishing an unchanged normalized profile used to run the full Apply
        -- transaction, rebuilding providers/theme/layout/events for no authored
        -- change. Preserve explicit force-layout requests, but otherwise return
        -- success without consuming Undo or waking the runtime.
        if not forceLayout and sameData(t.previous,p) then return true,"NO_CHANGE" end
        local undo=t.copy(M,t.previous)
        if not current(t) then return false,ownershipLost end
        if not plain(undo) or rawequal(undo,t.previous) then return false,"The previous settings could not be copied safely." end
        local undoCurrent,undoNodes=dataSeal(t,undo,true)
        if not undoCurrent or not sameData(t.previous,undo) then return false,"The previous settings could not be copied faithfully." end
        local nextUndo={object=undo,current=undoCurrent}
        local target=t.oldMode and t.character or t.account
        return applyCandidate(t,p,forceLayout,function(candidate)
            rawset(target,"profile",candidate);rawset(P,"undo",undo);undoRecord=nextUndo
        end,function() return inputCurrent() and undoCurrent() and (record==nil or (rawequal(record,undoRecord) and record.current())) end,undoNodes)
    end)
end
function P:Commit(input,forceLayout,trigger) return commit(self,input,forceLayout,nil,trigger) end
function P:Undo()
    if not self.undo then return false,"There are no applied changes to undo." end
    local present,prior=raw(M.profile,"cursorPreferences"),raw(self.undo,"cursorPreferences")
    local remove=present~=nil and (prior==nil or (raw(present,"schema")==2 and raw(prior,"schema")==1))
    if remove and (not undoRecord or not rawequal(self.undo,undoRecord.object) or not undoRecord.current()) then return false,"The undo record changed; current preferences were preserved." end
    -- Private direct entry: an overridden public Commit cannot capture a permit.
    return commit(self,self.undo,true,remove and undoRecord or nil)
end
function P:UseCharacter(enabled)
    return write(self,function(t)
        if type(enabled)~="boolean" then return false,"Choose shared or character settings explicitly." end
        local source;local newScope=enabled and raw(t.character,"profile")==nil
        if enabled then source=raw(t.character,"profile") else source=raw(t.account,"profile") end
        if enabled and raw(t.character,"profile")==nil then source=t.previous end
        if not captureData(t,source) then return false,"Selected settings are unsupported; original data was preserved." end
        local allowed,why=permitted(t);if not allowed then return false,why end
        local references,referenceWhy=t.references:Profile(source);if not references then return false,referenceWhy end
        if not current(t) then return false,ownershipLost end
        local currentReferences,currentWhy=t.references:Profile(t.previous);if not currentReferences then return false,currentWhy end
        if not current(t) then return false,ownershipLost end
        local valid,reason=t.check(P,source);if valid~=true then return false,reason end
        if not current(t) then return false,ownershipLost end
        -- Both directions detach before Apply: applying the account object itself
        -- could otherwise mutate saved geometry before this transaction commits.
        local candidate,normalizationWhy=t.validate(P,source);if normalizationWhy then return false,normalizationWhy end
        refineSelectedProfile(candidate)
        if newScope then candidate.cursorPreferences=nil end -- no inferred cross-scope authored envelope
        local selectedRoot=enabled and t.savedCharacter or t.savedAccount
        if rawget(candidate,"cursorPreferences")~=nil and rawget(selectedRoot,"schema")~=2 then return false,"Publish cursor preferences explicitly before using this legacy scope." end
        local target=enabled and t.character or t.account
        return applyCandidate(t,candidate,true,function(p)
            rawset(target,"profile",p);rawset(t.character,"useCharacter",enabled);rawset(P,"undo",nil);undoRecord=nil
        end)
    end)
end

-- Explicit authored data publication only. No ApplyProfile, facade, renderer,
-- provider, menu, binding, or native gate is called by this operation.
function P:PublishCursorPreferences(envelope)
    return write(self,function(t)
        -- This operation owns only the new cursor preference field, not a
        -- detached/provisional live settings draft left by another operation.
        -- Existing slot and live seals retain this exact relation thereafter.
        local selected=t.oldMode and t.character or t.account
        if not rawequal(t.previous,raw(selected,"profile")) then
            return false,"Live settings differ from the selected saved profile. Complete settings recovery/review before publishing cursor preferences."
        end
        if not t.envelopes then return false,"Cursor preference storage is unavailable." end
        local inputCurrent=dataSeal(t,envelope,false);if not inputCurrent then return false,"Invalid cursor preference envelope." end
        local allowed,why=permitted(t);if not allowed then return false,why end
        local clean,cleanWhy=t.envelopes:CarryPolicy(envelope,rawget(t.previous,"cursorPreferences"),t.client.family,function(v) return t.safety:Readable(v) end)
        if not clean then return false,cleanWhy end
        if not current(t) or not inputCurrent() then return false,ownershipLost end
        local valid,reason=t.check(P,t.previous);if valid~=true then return false,reason end
        if not current(t) or not inputCurrent() then return false,ownershipLost end
        -- Exact raw snapshots, not the generic/callback-replaceable lossy Copy.
        local candidate,candidateSource=t.envelopes:Snapshot(t.previous,function(v) return t.safety:Readable(v) end)
        local undo,undoSource=t.envelopes:Snapshot(t.previous,function(v) return t.safety:Readable(v) end)
        if not plain(candidate) or not plain(undo) or type(candidateSource)~="function" or type(undoSource)~="function"
            or not candidateSource() or not undoSource() then return false,"Existing profile could not be copied safely." end
        candidate.cursorPreferences=clean
        local candidateCurrent=dataSeal(t,candidate,true);local undoCurrent=dataSeal(t,undo,true)
        local nextUndo={object=undo,current=undoCurrent}
        if not candidateCurrent or not undoCurrent then return false,"Detached preferences are required." end
        valid,reason=t.check(P,candidate);if valid~=true then return false,reason end
        if not current(t) or not inputCurrent() or not candidateCurrent() or not undoCurrent() then return false,ownershipLost end
        local plans,plansCurrent=t.envelopes:PlanRoots(t.savedAccount,t.savedCharacter,function(v) return t.safety:Readable(v) end)
        if not plans then return false,plansCurrent end
        local function shallow(v) local out={};for k,x in next,v do out[k]=x end;return out end
        local a,c=plans.account,plans.character
        a.clients=shallow(a.clients);c.clients=shallow(c.clients)
        local ac,cc=shallow(t.account),shallow(t.character)
        a.clients[t.client.family]=ac;c.clients[t.client.family]=cc
        if t.oldMode then cc.profile=candidate else ac.profile=candidate end
        local _,aCurrent=t.envelopes:Snapshot(a,function(v) return t.safety:Readable(v) end,"root2")
        local _,cCurrent=t.envelopes:Snapshot(c,function(v) return t.safety:Readable(v) end,"root2")
        if type(aCurrent)~="function" or type(cCurrent)~="function" then return false,"Prepared root data could not be sealed." end
        allowed,why=permitted(t);if not allowed then return false,why end
        if not inputCurrent() or not candidateCurrent() or not undoCurrent() or not plansCurrent() or not aCurrent() or not cCurrent() or not current(t) then return false,ownershipLost end
        -- Already-built roots and exact captured scope; no explicit allocation
        -- or callbacks after this seal. This is not disk/native atomicity.
        MirageUIDB,MirageUICharacterDB=a,c
        rawset(M,"db",a);rawset(P,"account",ac);rawset(P,"character",cc)
        rawset(M,"profile",candidate);rawset(P,"undo",undo);undoRecord=nextUndo;t.committed=true
        return true
    end)
end
function P:CopyCursorPreferenceRecovery()
    if writer or initializing or not rawequal(self,P) or not rawequal(M.Profiles,P) then return nil,"Settings are busy or ownership changed." end
    local a,c=MirageUIDB,MirageUICharacterDB
    local E,S=rawget(M,"CursorPreferenceEnvelope"),M.Safety
    if type(E)~="table" or type(E.Recovery)~="function" then return nil,"Cursor preference recovery is unavailable." end
    local seal=E:Seal();if not seal then return nil,"Cursor preference recovery is unavailable." end
    local readable=S.Readable
    local ok,result=pcall(E.Recovery,E,a,c,function(v) return readable(S,v) end)
    if not ok or not result or not seal() or not rawequal(M.Profiles,P) or not rawequal(M.Safety,S) or not rawequal(S.Readable,readable)
        or not rawequal(MirageUIDB,a) or not rawequal(MirageUICharacterDB,c) then return nil,"Recovery data changed or is unsupported; original data was preserved." end
    return result
end

function P:Preset(name,base)
    local source=base or M.profile;local p,why=self:Validate(source)
    if why then return source,why end
    if not presets[name] then return p end
    p.preset=name
    if name=="Accessibility" then p.contrast=true;p.textScale=1.15;p.fade=0 end
    if name=="Always Informed" or name=="Accessibility" then
        for _,v in pairs(p.modules) do v.visibility="Always" end
    else
        for _,v in pairs(p.modules) do v.visibility="Contextual" end
    end
    return p
end
function P:SaveNamed(name)
    return write(self,function(t)
        if type(name)~="string" or #name<1 or #name>32 or name:find("[\r\n|]") then return false,"Use a short profile name." end
        local named=raw(t.account,"named");if not plain(named) then return false,"Named settings are unavailable; original data was preserved." end
        remember(t,t.account,"named")
        -- Seal the library's membership/entry identities, not every unrelated
        -- profile body. An untouched unknown named profile remains opaque.
        local node={object=named,fields={},count=0};t.data[#t.data+1]=node
        for key,value in next,named do
            node.count=node.count+1;if node.count>10000 then return false,"Named settings are oversized; original data was preserved." end
            node.fields[#node.fields+1]={key=key,value=value}
        end
        if not captureData(t,rawget(named,name)) then return false,"Named settings are unsupported; original data was preserved." end
        local allowed,why=permitted(t);if not allowed then return false,why end
        local count=0;for _ in next,named do count=count+1 end
        if count>=12 and rawget(named,name)==nil then return false,"Up to twelve local profiles are supported." end
        local valid,reason=t.check(P,t.previous);if valid~=true then return false,reason end
        if rawget(t.previous,"cursorPreferences")~=nil and rawget(t.savedAccount,"schema")~=2 then return false,"Publish cursor preferences explicitly before naming this legacy profile." end
        if not current(t) then return false,ownershipLost end
        if rawget(named,name)~=nil then
            local envelopeOK,envelopeWhy=preferenceEnvelope(rawget(named,name));if not envelopeOK then return false,envelopeWhy end
            local prior,priorWhy=t.references:Profile(rawget(named,name));if not prior then return false,priorWhy end
            if not current(t) then return false,ownershipLost end
        end
        local copy=t.copy(M,t.previous)
        if not current(t) then return false,ownershipLost end
        if not plain(copy) then return false,"Named settings could not be copied safely." end
        local copyCurrent=dataSeal(t,copy,true)
        if not copyCurrent then return false,"Named settings could not be copied safely." end
        valid,reason=t.check(P,copy);if valid~=true then return false,reason end
        if not copyCurrent() then return false,"Named settings changed during validation." end
        allowed,why=permitted(t);if not allowed then return false,why end
        if not copyCurrent() then return false,"Named settings changed before publication." end
        rawset(named,name,copy);t.committed=true;return true
    end)
end
function P:DeleteNamed(name)
    return write(self,function(t)
        local named=raw(t.account,"named")
        if type(name)~="string" or not plain(named) or rawget(named,name)==nil then return false,"Choose an existing saved profile." end
        remember(t,t.account,"named");remember(t,named,name)
        local allowed,why=permitted(t);if not allowed then return false,why end
        rawset(named,name,nil);t.committed=true;return true
    end)
end
function P:CopyNamed(source,name)
    return write(self,function(t)
        if type(name)~="string" or #name<1 or #name>32 or name:find("[%c|]") then return false,"Use a name of 1-32 characters." end
        local named=raw(t.account,"named")
        if not plain(named) or rawget(named,name)~=nil then return false,"Choose a new profile name." end
        local original=rawget(named,source)
        if not plain(original) then return false,"Choose a saved profile to copy." end
        remember(t,t.account,"named");remember(t,named,source);remember(t,named,name)
        if not captureData(t,original) then return false,"The source profile could not be sealed." end
        local count=0;for _ in next,named do count=count+1 end
        if count>=12 then return false,"Up to twelve saved profiles are supported." end
        local copy=t.copy(M,original)
        local seal=dataSeal(t,copy,true);if not seal then return false,"The copy could not be sealed." end
        local valid,why=t.check(P,copy);if not valid then return false,why end
        local allowed,reason=permitted(t)
        if not allowed or not seal() then return false,reason or "The profile changed during validation." end
        rawset(named,name,copy);t.committed=true;return true
    end)
end
function P:LoadNamed(name)
    local p=self.account and self.account.named[name]
    if not p then return false,"That profile is not available." end
    return self:Commit(p,true)
end
function P:Export()
    if self.readOnly then return nil,"Saved settings are preserved read-only; this version cannot copy them." end
    -- A deliberately small data-only format; no executable Lua or user identities.
    local p=M.profile
    local valid,why=self:CheckTransaction(p);if not valid then return nil,why end
    local references,referenceWhy=M.References:Profile(p);if not references then return nil,referenceWhy end
    local preferenceCode
    if rawget(p,"cursorPreferences")~=nil then
        local E=rawget(M,"CursorPreferenceEnvelope")
        preferenceCode=E and E:Encode(p.cursorPreferences,M.Client.family,function(v) return M.Safety:Readable(v) end)
        if not preferenceCode then return nil,"Cursor preferences could not be copied safely." end
    end
    local format=4 -- additive context preferences; versions 1-3 still import
    local lines={"MIRAGEPROFILE="..format,"preset="..p.preset,"textScale="..p.textScale,"fade="..p.fade,
        "idle="..p.idle,"movementHold="..p.movementHold,"combatHold="..p.combatHold,"contrast="..tostring(p.contrast),"grid="..p.grid,"enabled="..tostring(p.enabled)}
    for _,key in ipairs({"b35Revision","sidebarWidthRevision","nameplateWorldNamesRevision","beta48Revision","beta49Revision","beta51Revision","beta52Revision","beta57NativeNamesRevision","managed","autoLayout","managedDismissed","gamepadNavigation","spokenLabels","speechRate","speechVolume"}) do lines[#lines+1]=key.."="..tostring(p[key]) end
    for _,key in ipairs(M.Presentation.keys) do lines[#lines+1]="presentation."..key.."="..tostring(p.presentation[key]) end
    for _,entry in ipairs(M.Catalog) do local v=p.modules[entry.id]
        if v then for _,key in ipairs(M:ModuleOptionKeys(entry.id)) do
            if v[key]~=nil then lines[#lines+1]="module."..entry.id.."."..key.."="..tostring(v[key]) end
        end end
    end
    if p.modules.Cursor then
        for _,key in ipairs(legacyCursorKeys) do
            local value=p.modules.Cursor[key]
            if value~=nil then lines[#lines+1]="module.Cursor."..key.."="..tostring(value) end
        end
    end
    for i,g in ipairs(p.modules.Cooldowns.groups or {}) do
        local encoded=g.name:gsub(".",function(char) return string.format("%02x",string.byte(char)) end)
        lines[#lines+1]="cooldownGroup."..i.."="..g.id..":"..encoded..":"..(g.bar or "Unassigned")..":"..g.r..":"..g.g..":"..g.b..":"..g.alpha
    end
    for i,item in ipairs(p.modules.Cooldowns.spells) do
        lines[#lines+1]="cooldown."..i.."="..item.id..":"..item.mode..(item.mode=="ItemAura" and ":"..item.auraID or "")
        if item.highlight and item.highlight~="None" then lines[#lines+1]="cooldownHighlight."..i.."="..item.highlight end
        if item.bar=="Secondary" then lines[#lines+1]="cooldownBar."..i.."=Secondary" end
        if item.group then lines[#lines+1]="cooldownGrouping."..i.."="..item.group end
    end
    for i,id in ipairs(p.modules.Auras.reminders) do lines[#lines+1]="reminder."..i.."="..id end
    for i,id in ipairs(p.modules.Preparations.supplyIDs) do lines[#lines+1]="supply."..i.."="..id end
    local contextIDs={};for id in pairs(p.elementContexts or {}) do contextIDs[#contextIDs+1]=id end;table.sort(contextIDs)
    for _,id in ipairs(contextIDs) do for _,context in ipairs({"Idle","Moving","Combat"}) do
        local value=p.elementContexts[id][context]
        if value then lines[#lines+1]="elementContext."..id..":"..context.."="..value end
    end end
    local ids={};for id in pairs(p.layouts) do ids[#ids+1]=id end;table.sort(ids)
    for _,id in ipairs(ids) do
        for _,key in ipairs({"x","y","width","height","scale","anchorTo"}) do
            if p.layouts[id][key]~=nil then lines[#lines+1]="layout."..id..":"..key.."="..tostring(p.layouts[id][key]) end
        end
    end
    for i,r in ipairs(p.rules) do
        local expression=M.Predicate:Encode(r.when)
        if expression then lines[#lines+1]="rule."..i.."="..r.module.."|"..r.state.."|"..tostring(r.enabled).."|"..r.dwell.."|"..expression end
    end
    -- Cursor preferences are bounded scalars only; native key assignments are not profile data.
    if p.cursorProfile then
        local function emit(node,path,depth)
            if depth>8 then return end
            local keys={};for k in pairs(node) do if type(k)=="string" or type(k)=="number" then keys[#keys+1]=k end end
            table.sort(keys,function(a,b) return tostring(a)<tostring(b) end)
            for _,k in ipairs(keys) do
                local name=path=="" and tostring(k) or path.."."..tostring(k);local v=node[k]
                if type(v)=="table" then emit(v,name,depth+1)
                elseif type(v)=="boolean" then lines[#lines+1]="cursor."..name.."=b:"..tostring(v)
                elseif M.Safety:Number(v) then lines[#lines+1]="cursor."..name.."=n:"..tostring(v)
                elseif type(v)=="string" and #v<=512 then
                    lines[#lines+1]="cursor."..name.."=s:"..v:gsub(".",function(c) return string.format("%02x",string.byte(c)) end)
                end
            end
        end
        emit(p.cursorProfile,"",0)
    end
    if preferenceCode then
        lines[#lines+1]="cursorPreference.schema="..p.cursorPreferences.schema
        lines[#lines+1]="cursorPreference.flavor="..p.cursorPreferences.flavor
        lines[#lines+1]="cursorPreference.code="..preferenceCode
        if p.cursorPreferences.schema==2 then
            lines[#lines+1]="cursorPreference.presentationSchema=1"
            lines[#lines+1]="cursorPreference.healthPair="..p.cursorPreferences.presentation.healthPair
        end
    end
    lines[#lines+1]="reference.schema=1"
    local function hex(value) return (value:gsub(".",function(c) return string.format("%02x",string.byte(c)) end)) end
    for _,pair in ipairs({{"build","builds"},{"strategy","strategies"}}) do
        for i,record in ipairs(references[pair[2]]) do
            local prefix="reference."..pair[1].."."..i.."."
            for _,key in ipairs({"id","name","text","source"}) do lines[#lines+1]=prefix..key.."="..(key=="id" and record.id or hex(record[key])) end
            lines[#lines+1]=prefix.."family="..hex(record.createdClient.family)
            lines[#lines+1]=prefix.."build="..hex(record.createdClient.build)
            lines[#lines+1]=prefix.."interface="..record.createdClient.interface
        end
    end
    local text=table.concat(lines,"\n")
    if #lines>2400 or #text>65536 then return nil,"Profile exceeds the supported copy/import size. Reduce saved content or layouts before copying." end
    return text
end
function P:Import(text)
    if type(text)~="string" or #text>65536 then return nil,"Not a MirageUI profile." end
    local wire=text:match("^MIRAGEPROFILE=([1234])[\r\n]")
    if not wire then return nil,"Not a MirageUI profile." end
    local importedPreference={}
    local p=profileSchema();p.onboarding=M.profile.onboarding;p.sidebarWidthRevision=0;p.nameplateWorldNamesRevision=0;p.beta48Revision=0;p.beta49Revision=0;p.beta51Revision=0;p.beta52Revision=0;p.beta57NativeNamesRevision=0
    local count=0;local seenKeys={};local referenceMarker=false;local referenceFields=false;local importedReferences={build={},strategy={}}
    for line in text:gmatch("[^\r\n]+") do
        count=count+1;if count>2400 then return nil,"Too many profile fields." end
        local key,value=line:match("^([^=]+)=(.*)$")
        if not key then return nil,"A profile line is invalid." end
        if seenKeys[key] then return nil,"A profile field was repeated." end;seenKeys[key]=true
        if key:sub(1,15)=="elementContext." then
            if wire~="4" then return nil,"Context preferences require profile format 4." end
            local id,context=key:match("^elementContext%.([%w_%.]+):(%a+)$")
            if not id or #id>89 or not M.ElementRules.contexts[context] or (value~="SHOW" and value~="HIDE") then return nil,"Invalid element context preference." end
            p.elementContexts[id]=p.elementContexts[id] or {};p.elementContexts[id][context]=value
        elseif key:sub(1,17)=="cursorPreference." then
            if wire~="2" and wire~="3" and wire~="4" then return nil,"Cursor preferences require profile format 2, 3 or 4." end
            local field=key:sub(18)
            if field~="schema" and field~="flavor" and field~="code"
                and not ((wire=="3" or wire=="4") and (field=="presentationSchema" or field=="healthPair")) then return nil,"Unknown cursor preference field." end
            importedPreference[field]=value
        elseif key=="preset" then p.preset=value
        elseif key=="b35Revision" or key=="sidebarWidthRevision" or key=="nameplateWorldNamesRevision" or key=="beta48Revision" or key=="beta49Revision" or key=="beta51Revision" or key=="beta52Revision" or key=="beta57NativeNamesRevision" or key=="textScale" or key=="fade" or key=="idle" or key=="movementHold" or key=="combatHold" or key=="grid" or key=="speechRate" or key=="speechVolume" then
            local numeric=tonumber(value);if not M.Safety:Number(numeric) then return nil,"Invalid settings number." end;p[key]=numeric
        elseif key=="contrast" or key=="enabled" or key=="managed" or key=="autoLayout" or key=="managedDismissed" or key=="gamepadNavigation" or key=="spokenLabels" then
            if value~="true" and value~="false" then return nil,"Invalid Boolean setting." end
            p[key]=value=="true"
        elseif key:sub(1,13)=="presentation." then
            local field=key:sub(14);local default=M.Presentation:Defaults()[field]
            if default==nil then return nil,"Unknown presentation setting." end
            if type(default)=="boolean" then
                if value~="true" and value~="false" then return nil,"Invalid presentation toggle." end
                p.presentation[field]=value=="true"
            elseif type(default)=="number" then
                local numeric=tonumber(value);if not M.Safety:Number(numeric) then return nil,"Invalid presentation version." end;p.presentation[field]=numeric
            else p.presentation[field]=value end
        elseif key=="reference.schema" then
            if value~="1" then return nil,"Unsupported reference schema." end;referenceMarker=true
        elseif key:sub(1,10)=="reference." then
            referenceFields=true
            local kind,index,field=key:match("^reference%.(%a+)%.([1-8])%.(%a+)$")
            if not kind or not importedReferences[kind] or not ({id=true,name=true,text=true,source=true,family=true,build=true,interface=true})[field] then return nil,"Unknown reference profile field." end
            index=tonumber(index);local record=importedReferences[kind][index] or {};importedReferences[kind][index]=record
            if record[field]~=nil then return nil,"Duplicate reference profile field." end
            if field=="id" or field=="interface" then
                if not value:match("^%d+$") then return nil,"Invalid reference numeric field." end
                record[field]=tonumber(value)
            else
                local limit=field=="name" and 48 or field=="text" and 1024 or field=="source" and 96 or field=="family" and 8 or 32
                if #value>limit*2 or #value%2~=0 or value:find("[^%x]") then return nil,"Invalid reference encoded text." end
                record[field]=value:gsub("%x%x",function(hex) return string.char(tonumber(hex,16)) end)
            end
        elseif key:sub(1,7)=="module." then
            local id,field=key:match("^module%.(%w+)%.(%w+)$")
            if not id or (id~="Cursor" and not p.modules[id]) then return nil,"An unknown module was included." end
            if id=="Cursor" then
                if legacyCursorSchema[field]==nil then return nil,"An unknown retired cursor setting was included." end
                p.modules.Cursor=p.modules.Cursor or {}
            end
            local feature=M.FeatureSettings[id] and M.FeatureSettings[id][field]
            if type(feature)=="table" then
                local numeric=tonumber(value);if not M.Safety:Number(numeric) then return nil,"Invalid module number." end
                p.modules[id][field]=numeric
            elseif type(feature)=="boolean" then
                if value~="true" and value~="false" then return nil,"Invalid module Boolean." end
                p.modules[id][field]=value=="true"
            elseif field=="visibility" then p.modules[id][field]=value
            elseif field=="alpha" or field=="scale" then
                local numeric=tonumber(value);if not M.Safety:Number(numeric) then return nil,"Invalid module number." end;p.modules[id][field]=numeric
            elseif field=="enabled" or field=="style" or field=="showXP" or field=="showZone" or field=="showMoney" or field=="showClock" then
                if value~="true" and value~="false" then return nil,"Invalid module Boolean." end
                p.modules[id][field]=value=="true"
            else return nil,"An unknown setting was included." end
        elseif key:match("^cooldownGroup%.%d+$") then
            local index=tonumber(key:match("%d+$"));local id,name,bar,r,g,b,alpha=value:match("^(%d+):(%x+):(%a+):([^:]+):([^:]+):([^:]+):([^:]+)$")
            id=tonumber(id)
            if index~=#p.modules.Cooldowns.groups+1 or index>64 or not cooldownGroupID(id)
                or not name or #name>80 or #name%2~=0 or bar~="Unassigned" and not cooldownBars[bar] then return nil,"Invalid tracker group." end
            for _,existing in ipairs(p.modules.Cooldowns.groups) do if existing.id==id then return nil,"Duplicate tracker group identity." end end
            name=name:gsub("%x%x",function(hex) return string.char(tonumber(hex,16)) end)
            if not cooldownGroupName(name) then return nil,"Invalid tracker group name." end
            local group={id=id,name=name,bar=bar~="Unassigned" and bar or nil,r=tonumber(r),g=tonumber(g),b=tonumber(b),alpha=tonumber(alpha)}
            for _,field in ipairs({"r","g","b","alpha"}) do if not M.Safety:Number(group[field]) or group[field]<0 or group[field]>1 then return nil,"Invalid tracker group color or opacity." end end
            p.modules.Cooldowns.groups[index]=group
        elseif key:match("^cooldownBar%.%d+$") then
            local entry=p.modules.Cooldowns.spells[tonumber(key:match("%d+$"))]
            if not entry or entry.bar~=nil or not cooldownBars[value] then return nil,"Invalid tracked cooldown display." end
            entry.bar=value
        elseif key:match("^cooldownGrouping%.%d+$") then
            local entry=p.modules.Cooldowns.spells[tonumber(key:match("%d+$"))];local id=tonumber(value)
            if not entry or entry.group~=nil or not value:match("^%d+$") or not cooldownGroupID(id) then return nil,"Invalid tracked cooldown grouping." end
            entry.group=id
        elseif key:match("^cooldown%.%d+$") then
            local index=tonumber(key:match("%d+$"));local sid,mode,aid=value:match("^(%d+):(%a+):(%d+)$")
            if not sid then sid,mode=value:match("^(%d+):(%a+)$") end
            local numeric=tonumber(sid)
            local auraID=tonumber(aid)
            if index~=#p.modules.Cooldowns.spells+1 or index>160 or not cooldownID(numeric) or not cooldownModes[mode]
                or mode=="ItemAura" and not cooldownID(auraID) or mode~="ItemAura" and aid~=nil then return nil,"Invalid tracked cooldown." end
            local selected={id=numeric,mode=mode,auraID=auraID};local identity=cooldownKey(selected)
            for _,item in ipairs(p.modules.Cooldowns.spells) do if cooldownKey(item)==identity then return nil,"Duplicate tracked cooldown source." end end
            p.modules.Cooldowns.spells[#p.modules.Cooldowns.spells+1]=selected
        elseif key:match("^cooldownHighlight%.%d+$") then
            local index=tonumber(key:match("%d+$"));local entry=p.modules.Cooldowns.spells[index]
            if not entry or not cooldownHighlights[value] or entry.highlight~=nil then return nil,"Invalid tracked cooldown highlight." end
            entry.highlight=value
        elseif key:match("^supply%.%d+$") then
            local index=tonumber(key:match("%d+$"));local id=tonumber(value)
            if index~=#p.modules.Preparations.supplyIDs+1 or index>8 or not M.Safety:Number(id) or id%1~=0 or id<1 or id>2147483647 then return nil,"Invalid supply item ID." end
            for _,existing in ipairs(p.modules.Preparations.supplyIDs) do if existing==id then return nil,"Duplicate supply item ID." end end
            p.modules.Preparations.supplyIDs[index]=id
        elseif key:match("^reminder%.%d+$") then
            local index=tonumber(key:match("%d+$"));local sid=tonumber(value)
            if index~=#p.modules.Auras.reminders+1 or index>8 or not M.Safety:Number(sid) or sid<1 or sid>2147483647 or sid%1~=0 then return nil,"Invalid preparation spell." end
            for _,id in ipairs(p.modules.Auras.reminders) do if id==sid then return nil,"Duplicate preparation spell." end end
            p.modules.Auras.reminders[index]=sid
        elseif key:sub(1,7)=="layout." then
            local id,field=key:match("^layout%.([%w_%.]+):(%w+)$")
            if not id then return nil,"Invalid layout field." end
            p.layouts[id]=p.layouts[id] or {}
            if field=="anchorTo" then p.layouts[id][field]=value
            elseif field=="x" or field=="y" or field=="width" or field=="height" or field=="scale" then
                local numeric=tonumber(value);if not M.Safety:Number(numeric) then return nil,"Invalid layout number." end;p.layouts[id][field]=numeric
            else return nil,"Invalid layout setting." end
        elseif key:sub(1,7)=="cursor." then
            local path=key:sub(8);local tag,body=value:match("^([bns]):(.*)$")
            if #path>140 or not path:match("^[%w_%.]+$") or not tag then return nil,"Invalid cursor profile data." end
            local parsed
            if tag=="b" then if body~="true" and body~="false" then return nil,"Invalid cursor Boolean." end;parsed=body=="true"
            elseif tag=="n" then parsed=tonumber(body);if not M.Safety:Number(parsed) then return nil,"Invalid cursor number." end
            else
                if #body>1024 or #body%2~=0 or body:find("[^%x]") then return nil,"Invalid cursor text." end
                parsed=body:gsub("%x%x",function(hex) return string.char(tonumber(hex,16)) end)
            end
            p.cursorProfile=p.cursorProfile or {};local node=p.cursorProfile;local parts={}
            for part in path:gmatch("[^%.]+") do parts[#parts+1]=tonumber(part) or part end
            if #parts<1 or #parts>8 then return nil,"Invalid cursor field depth." end
            for i=1,#parts-1 do
                local v=node[parts[i]];if v~=nil and type(v)~="table" then return nil,"Conflicting cursor fields." end
                node[parts[i]]=v or {};node=node[parts[i]]
            end
            if node[parts[#parts]]~=nil then return nil,"Duplicate cursor field." end
            node[parts[#parts]]=parsed
        elseif key:match("^rule%.%d+$") then
            local id,state,on,dwell,expression=value:match("^(%w+)|(%w+)|(%w+)|([%d%.]+)|(.+)$")
            local ast=expression and M.Predicate:Decode(expression)
            if not id or (id~="Cursor" and not p.modules[id]) or not ast or not M.Predicate:UserAllowed(ast) or #p.rules>=24 or
                not M.States[state] or state=="PROTECTED_FLOOR" or (on~="true" and on~="false") then
                return nil,"Invalid conditional rule."
            end
            p.rules[#p.rules+1]={module=id,state=state,when=ast,enabled=on=="true",dwell=tonumber(dwell)}
        elseif key~="MIRAGEPROFILE" then return nil,"Unknown profile data was rejected."
        elseif value~=wire then return nil,"Profile format marker changed." end
    end
    if wire=="2" or wire=="3" or (wire=="4" and next(importedPreference)) then
        local expectedSchema=wire=="4" and importedPreference.schema or wire=="3" and "2" or "1"
        if expectedSchema~="1" and expectedSchema~="2" then return nil,"Unsupported cursor preference schema." end
        if importedPreference.schema~=expectedSchema or importedPreference.flavor~=M.Client.family or type(importedPreference.code)~="string" then return nil,"Incomplete or unsupported cursor preference envelope." end
        local E=rawget(M,"CursorPreferenceEnvelope")
        local envelope=E and E:Decode(importedPreference.code,importedPreference.flavor,function(v) return M.Safety:Readable(v) end)
        if not envelope then return nil,"Cursor preference transport was rejected." end
        if wire=="3" or (wire=="4" and expectedSchema=="2") then
            if importedPreference.presentationSchema~="1" then return nil,"Unsupported cursor presentation policy." end
            envelope.schema=2;envelope.presentation={schema=1,healthPair=importedPreference.healthPair}
            envelope=E:Validate(envelope,importedPreference.flavor,function(v) return M.Safety:Readable(v) end)
        else
            envelope=E:CarryPolicy(envelope,raw(M.profile,"cursorPreferences"),importedPreference.flavor,function(v) return M.Safety:Readable(v) end)
        end
        if not envelope then return nil,"Cursor presentation policy was rejected." end
        p.cursorPreferences=envelope
    elseif type(M.profile)=="table" and rawget(M.profile,"cursorPreferences")~=nil then
        local valid,envelope=preferenceEnvelope(M.profile);if not valid then return nil,envelope end
        p.cursorPreferences=envelope
    end
    if referenceFields and not referenceMarker then return nil,"Reference schema marker is required." end
    if referenceMarker then
        for _,pair in ipairs({{"build","builds"},{"strategy","strategies"}}) do
            local rows=importedReferences[pair[1]];local total=0;for _ in pairs(rows) do total=total+1 end
            for i=1,total do
                local r=rows[i]
                if not r or r.id==nil or r.name==nil or r.text==nil or r.source==nil or r.family==nil or r.build==nil or r.interface==nil then return nil,"Incomplete reference record." end
                p.preparationReferences[pair[2]][i]={id=r.id,name=r.name,text=r.text,source=r.source,createdClient={family=r.family,build=r.build,interface=r.interface}}
            end
        end
    end
    local valid,why=self:CheckTransaction(p);if not valid then return nil,why end
    local result,referenceWhy=self:Validate(p);if referenceWhy then return nil,referenceWhy end
    return result
end
