local _,M=...
-- The reviewed Forever native Edit Mode manager continues to arrange default bars
-- after an addon has positioned them. Observe those native writers and the
-- source-qualified individual-system/managed-cast writers described below.
-- No native function, saved layout, default-position flag or secure decision is
-- replaced. A matching public native output grants one OOC geometry retry;
-- unrelated anchors and competing owners retain the normal refusal path.
local S,N=M.Safety,M.ManagedNative
local R={pending={},roots={},status="NOT_INSTALLED"};M.NativeActionLayout=R
local function delegated(name,frame)
 if name=="BagsBar" or name=="MicroMenuContainer" or name=="MicroMenu" then return true end
 if not S:Readable(frame) then return true end
 if frame==nil then return false end
 for _,key in ipairs({"BagsBar","MicroMenuContainer","MicroMenu"}) do
  local native=_G[key]
  if S:Readable(native) and native~=nil and frame==native then return true end
 end
 return false
end
local receipts=setmetatable({},{__mode="k"})
local writerMethods,systemHooks,castHooks={},{},{}
local queued,editRecords=setmetatable({},{__mode="k"}),setmetatable({},{__mode="k"})
local combatPending={}
local editAcceptSource,editCurrentSource,editCompleteSource,editAcquireSource,releaseEditingSource
local expectedSource,nativePassSource,systemPassSource,castPassSource
local reviewedClient=M.Client.RuntimeAvailable or M.Client.IsReviewedPresentationClient
local function exactClient()
 local c=M.Client
 return c and c.allowed==true and type(reviewedClient)=="function" and reviewedClient(c) and S:BoundaryReady() or false
end
local known={MainActionBar=true,MultiBarBottomLeft=true,MultiBarBottomRight=true,MultiBarRight=true,MultiBarLeft=true,
 MultiBar5=true,MultiBar6=true,MultiBar7=true,PetActionBar=true,StanceBar=true,BagsBar=true,MicroMenuContainer=true,
 MainStatusTrackingBarContainer=true,SecondaryStatusTrackingBarContainer=true,PossessActionBar=true,
 MainMenuBarVehicleLeaveButton=true,MultiCastActionBarFrame=true}
local function call(object,key,kind,...)
 if not object or not S:Readable(object) then return nil end
 local fn=S:Field(object,key)
 local value,status=S:Public(fn,kind,object,...)
 if status=="KNOWN" then return value end
end
local function number(value) if S:Number(value) then return value end end
local function constant(key) return number(rawget(_G,key)) end
local function field(object,key)
 if not object or not S:Readable(object) then return nil end
 return S:Field(object,key)
end
-- The two additional source projections bind every reader and optional input.
-- A restricted optional field is not an absent value; an unreadable child slot
-- is not a list terminator. These readers never invoke a native Layout method.
local function capture(q,object,key)
 local value,status=S:FieldAccess(object,key)
 if status~="KNOWN" and status~="ABSENT" then q.invalid=true;return nil end
 q.fields[#q.fields+1]={object,key,value};return value
end
local function readMany(q,object,key,dot,...)
 local fn=field(object,key);if type(fn)~="function" then return nil end
 q.bindings[#q.bindings+1]={object,key,fn}
 local values
 if dot then values={pcall(fn,...)} else values={pcall(fn,object,...)} end
 if values[1]~=true then return nil end
 for i=2,6 do if not S:Readable(values[i]) then return nil end end
 return {values[2],values[3],values[4],values[5],values[6]}
end
local function readOne(q,object,key,kind,...)
 local values=readMany(q,object,key,false,...);local value=values and values[1]
 if kind=="number" then return number(value)
 elseif kind=="boolean" then if type(value)=="boolean" then return value end
 elseif kind=="table" then if type(value)=="table" and S:Readable(value) then return value end
 else return value end
end
local function boundedChildren(q,frame)
 local children=readOne(q,frame,"GetLayoutChildren","table");if not children then return nil end
 local out,seen={},{}
 for i=1,65 do
  local child,status=S:FieldAccess(children,i)
  if status=="ABSENT" then return out end
  if status~="KNOWN" then return nil end
  if i>64 or seen[child] or not S:Frame(child,false) or readOne(q,child,"GetParent")~=frame then return nil end
  seen[child]=true;out[#out+1]=child;q.parents[#q.parents+1]={child,frame}
 end
end
local function inputsCurrent(q)
 if not q then return true end
 if q.invalid then return false end
 for _,b in ipairs(q.bindings) do if field(b[1],b[2])~=b[3] then return false end end
 for _,b in ipairs(q.fields) do
  local value,status=S:FieldAccess(b[1],b[2]);if (status~="KNOWN" and status~="ABSENT") or value~=b[3] then return false end
 end
 for _,b in ipairs(q.parents) do if call(b[1],"GetParent")~=b[2] then return false end end
 if q.system then
  if call(q.system.frame,"GetManagedFrameContainer")~=nil or call(q.system.frame,"IsInDefaultPosition","boolean")~=q.system.default then return false end
 end
 if q.cast then
  local enums=field(_G.Enum,"EditModeCastBarSetting")
  if _G.BottomManagedFrameContainer~=q.container or call(q.cast,"GetManagedFrameContainer")~=q.container
   or call(q.cast,"IsInDefaultPosition","boolean")~=true or call(q.cast,"GetSettingValueBool","boolean",field(enums,"LockToPlayerFrame"))~=false
   or call(q.cast,"GetSettingValue","number",field(enums,"BarSize"))~=q.nativeScaleSetting then return false end
 end
 -- Parent/configuration getters can invalidate an earlier method/field read.
 for _,b in ipairs(q.bindings) do if field(b[1],b[2])~=b[3] then return false end end
 for _,b in ipairs(q.fields) do
  local value,status=S:FieldAccess(b[1],b[2]);if (status~="KNOWN" and status~="ABSENT") or value~=b[3] then return false end
 end
 return true
end
local function newInputs() return {bindings={},fields={},parents={}} end
local function optionalNumber(value) return value==nil or number(value)~=nil end
local function resizeOutput(frame)
 -- MainActionBar inherits ResizeLayout in the active exact-client XML chain.
 -- Native grid updates can renew its size before the bottom writer. Recompute
 -- the same public child union instead of trusting an arbitrary positive size.
 if frame~=_G.MainActionBar then return nil end
 local q=newInputs();local children=boundedChildren(q,frame);if not children or #children==0 then return nil end
 local scale=readOne(q,frame,"GetEffectiveScale","number");if not scale or scale<=0 then return nil end
 local fixed=readMany(q,frame,"GetFixedSize",false);if not fixed or not optionalNumber(fixed[1]) or not optionalNumber(fixed[2]) then return nil end
 local wp,hp=readOne(q,frame,"GetWidthPadding","number"),readOne(q,frame,"GetHeightPadding","number")
 if not wp or not hp then return nil end
 local limits={}
 for _,key in ipairs({"fixedWidth","fixedHeight","widthPadding","heightPadding","minimumWidth","maximumWidth","minimumHeight","maximumHeight"}) do
  limits[key]=capture(q,frame,key);if not optionalNumber(limits[key]) then return nil end
 end
 local left,right,top,bottom
 for _,child in ipairs(children) do
  for _,key in ipairs({"GetScaledRect","GetRect","GetEffectiveScale","GetWidth","GetHeight","GetScale"}) do
   local fn=field(child,key);if type(fn)=="function" then q.bindings[#q.bindings+1]={child,key,fn} end
  end
  local rect=readMany(q,_G,"GetUnscaledFrameRect",true,child,scale)
  -- FrameUtil returns four values on success; the fifth true marks fallback.
  if not rect or not number(rect[1]) or not number(rect[2]) or not number(rect[3]) or not number(rect[4]) or rect[5]~=nil or rect[3]<0 or rect[4]<0 then return nil end
  left=math.min(left or rect[1],rect[1]);right=math.max(right or rect[1]+rect[3],rect[1]+rect[3])
  bottom=math.min(bottom or rect[2],rect[2]);top=math.max(top or rect[2]+rect[4],rect[2]+rect[4])
 end
 local function extent(desired,fixed,min,max)
  min=min or desired;max=math.max(max or desired,min);return fixed or math.max(min,math.min(desired,max))
 end
 local w=extent(right-left+wp,fixed[1],limits.minimumWidth,limits.maximumWidth)
 local h=extent(top-bottom+hp,fixed[2],limits.minimumHeight,limits.maximumHeight)
 if not number(w) or not number(h) or w<=0 or h<=0 or not inputsCurrent(q) then return nil end
 return {w,h},q
end
local function castOutput(frame,row,kind)
 -- The default unlocked cast is a BottomManagedFrame, not a plain anchorInfo
 -- system. Retain its native parent, timing, artwork and player-lock policy.
 local q=newInputs();local container=_G.BottomManagedFrameContainer
 if frame~=_G.PlayerCastingBarFrame or not S:Frame(container,false) or row.mode~="adopt" then return nil end
 q.cast=frame;q.container=container
 if readOne(q,container,"GetParent")~=UIParent then return nil end
 q.parents[#q.parents+1]={container,UIParent}
 if readOne(q,frame,"GetManagedFrameContainer")~=container or readOne(q,frame,"GetParent")~=container
  or readOne(q,frame,"IsInDefaultPosition","boolean")~=true then return nil end
 local enumRoot=capture(q,_G,"Enum");local enums=capture(q,enumRoot,"EditModeCastBarSetting")
 local lockSetting=capture(q,enums,"LockToPlayerFrame");local sizeSetting=capture(q,enums,"BarSize")
 if not number(lockSetting) or not number(sizeSetting) or readOne(q,frame,"GetSettingValueBool","boolean",lockSetting)~=false then return nil end
 local nativeScale=readOne(q,frame,"GetSettingValue","number",sizeSetting);local scale=readOne(q,frame,"GetScale","number")
 if not nativeScale or nativeScale<=0 or not scale or scale<=0 then return nil end
 q.nativeScaleSetting=nativeScale;nativeScale=nativeScale/100
 if kind=="size" then if math.abs(scale-nativeScale)>.00001 then return nil end
 elseif math.abs(scale-nativeScale)>.00001 and (not row.writtenScale or math.abs(scale-row.writtenScale)>.00001) then return nil end
 if capture(q,frame,"isManagedFrame")~=true or capture(q,frame,"isBottomManagedFrame")~=true
  or capture(q,frame,"layoutOnBottom")==true or capture(q,frame,"layoutParent")~=container or capture(q,frame,"look")~="CLASSIC" then return nil end
 local classic=capture(q,frame,"classicStyleCastBar");if classic~=nil and type(classic)~="boolean" then return nil end
 local size=classic and {195,13} or {208,11}
 local width,height=readOne(q,frame,"GetWidth","number"),readOne(q,frame,"GetHeight","number")
 if not width or not height or math.abs(width-size[1])>.001 or math.abs(height-size[2])>.001 then return nil end
 local output={parent=container,scale=scale,scaleWritten=kind=="size",size=size,inputs=q}
 if kind=="size" then
  -- The native size setting changes only scale. It cannot authorize a foreign
  -- point: the previously admitted authored anchor must still be present.
  output.points=row.writtenPoints
  local prior=queued[row]
  if prior and prior.expected and prior.expected.parent==container and prior.row==row and prior.frame==frame
   and prior.profile==M.profile and prior.rows==N.rows and prior.geometry==row.layoutGeometry
   and field(prior.writer,prior.key)==prior.method then
   -- ApplySystemAnchor can Layout first and update scale second in one native
   -- call. The read-only observer must coalesce both source writes without an
   -- intermediate addon SetPoint inside that call stack.
   output.points=prior.observed and prior.observed.points
   local old=prior.expected.inputs
   if not old or old.invalid then return nil end
   for _,key in ipairs({"bindings","fields","parents"}) do
    for _,entry in ipairs(old[key] or {}) do
     local found=false
     for _,present in ipairs(q[key]) do
      if present[1]==entry[1] and present[2]==entry[2] and present[3]==entry[3] then found=true;break end
     end
     if not found then q[key][#q[key]+1]=entry end
     if #q[key]>1024 then return nil end
    end
   end
   q.bindings[#q.bindings+1]={prior.writer,prior.key,prior.method}
  end
  if not output.points then return nil end
 else
  local children=boundedChildren(q,container);if not children then return nil end
  local padding=readMany(q,container,"GetPadding",false);if not padding then return nil end
  for i=1,4 do if not number(padding[i]) then return nil end end
  for _,key in ipairs({"leftPadding","rightPadding","topPadding","bottomPadding"}) do capture(q,container,key) end
  local spacing=capture(q,container,"spacing") or 0;if not number(spacing) then return nil end
  if capture(q,container,"respectChildScale")~=true then return nil end
  local direction=capture(q,container,"childLayoutDirection");if direction~=nil and direction~="topToBottom" and direction~="bottomToTop" then return nil end
  local top,bottom=padding[3],padding[4]
  for _,child in ipairs(children) do
   if capture(q,child,"expand") then return nil end
   local childScale=readOne(q,child,"GetScale","number");local dims=readMany(q,container,"GetChildSize",false,child)
   local pad=readMany(q,container,"GetChildPadding",false,child)
   if not childScale or childScale<=0 or not dims or not number(dims[1]) or not number(dims[2]) or not pad then return nil end
   for i=1,4 do if not number(pad[i]) then return nil end end
   local align=capture(q,child,"align")
   for _,key in ipairs({"leftPadding","rightPadding","topPadding","bottomPadding"}) do capture(q,child,key) end
   if align~=nil and align~="left" and align~="right" and align~="center" then return nil end
   top=top+pad[3];bottom=bottom+pad[4]
   local point,x,y
   if direction=="bottomToTop" then point="BOTTOM";y=bottom/childScale else point="TOP";y=-top/childScale end
   if align=="right" then point=point.."RIGHT";x=-(padding[2]+pad[2])/childScale
   elseif align=="center" then x=(padding[1]-padding[2]+pad[1]-pad[2])/2/childScale
   else point=point.."LEFT";x=(padding[1]+pad[1])/childScale end
   if child==frame then output.points={{point,container,point,x,y}};break end
   top=top+dims[2]*childScale+pad[4]+spacing;bottom=bottom+dims[2]*childScale+pad[3]+spacing
  end
 end
 if not output.points or not inputsCurrent(q) then return nil end
 return output
end
local function array(value)
 if type(value)~="table" or not S:Readable(value) then return nil end
 local out={}
 for i=1,24 do
  local frame=field(value,i)
  if frame==nil then return out end
  local name=call(frame,"GetName","string")
  if not name or not known[name] or rawget(_G,name)~=frame or not S:Frame(frame,false) then return nil end
  out[#out+1]=frame
 end
end
local function current(self,profile,module,allowEdit)
 return exactClient() and M.NativeActionLayout==self and M.ManagedNative==N and M.Safety==S and M.profile==profile
  and M.Managed:Enabled() and M:IsModuleActive(module or "ActionBars") and not M.Native:Conflict()
  and _G.EditModeManagerFrame==self.manager and (call(self.manager,"IsShown","boolean")==false or allowEdit==true and call(self.manager,"IsShown","boolean")==true)
end
local function anchor(info)
 if type(info)~="table" or not S:Readable(info) then return nil end
 local a,b,c,x,y=field(info,"point"),field(info,"relativeTo"),field(info,"relativePoint"),field(info,"offsetX"),field(info,"offsetY")
 if type(b)=="string" and S:Text(b) then b=rawget(_G,b) end
 if S:Text(a) and S:Text(c) and S:Readable(b) and b and number(x) and number(y) then return {{a,b,c,x,y}} end
end
local function layoutAnchor(manager,frame)
 local layout=call(manager,"GetActiveLayoutInfo","table")
 if not layout then return nil end
 local enums=field(_G.Enum,"EditModeLayoutType")
 if field(layout,"layoutType")==field(enums,"Preset") then
  return anchor(call(_G.EditModePresetLayoutManager,"GetPresetLayoutSystemAnchorInfo","table",field(layout,"layoutIndex"),field(frame,"system"),field(frame,"systemIndex")))
 end
 return anchor(call(manager,"GetDefaultAnchor","table",frame))
end
local systemNames={"MainActionBar","MultiBarBottomLeft","MultiBarBottomRight","MultiBarRight","MultiBarLeft",
 "MultiBar5","MultiBar6","MultiBar7","PetActionBar","StanceBar",
 "MainStatusTrackingBarContainer","SecondaryStatusTrackingBarContainer","PlayerCastingBarFrame"}
local function capturedAnchor(q,info)
 if type(info)~="table" or not S:Readable(info) then return nil end
 local a,b,c,x,y=capture(q,info,"point"),capture(q,info,"relativeTo"),capture(q,info,"relativePoint"),capture(q,info,"offsetX"),capture(q,info,"offsetY")
 if type(b)=="string" and S:Text(b) then b=capture(q,_G,b) end
 if not q.invalid and S:Text(a) and S:Text(c) and b and S:Frame(b,false) and number(x) and number(y) then return {a,b,c,x,y} end
end
local function systemAnchor(frame,row)
 -- ApplySystemAnchor's saved-anchor branch covers nondefault primary bars too.
 -- Default bottom/right bars are subsequently arranged by the nested manager
 -- writer; its placeholder TOPLEFT point is never an admitted final output.
 local q=newInputs();local container=readMany(q,frame,"GetManagedFrameContainer",false)
 local default=readOne(q,frame,"IsInDefaultPosition","boolean")
 if not container or container[1]~=nil or default==nil then return nil end
 if default then
  local bottom=readOne(q,_G.EditModeUtil,"IsBottomAnchoredActionBar","boolean",frame)
  local right=readOne(q,_G.EditModeUtil,"IsRightAnchoredActionBar","boolean",frame)
  if bottom==nil or right==nil or bottom or right then return nil end
 end
 if frame==_G.PlayerCastingBarFrame then
  local enum=capture(q,_G,"Enum");local enums=capture(q,enum,"EditModeCastBarSetting")
  if readOne(q,frame,"GetSettingValueBool","boolean",capture(q,enums,"LockToPlayerFrame"))~=false then return nil end
 end
 local info=capture(q,frame,"systemInfo");local first=info and capturedAnchor(q,capture(q,info,"anchorInfo"))
 local scale=readOne(q,frame,"GetScale","number")
 if not first or not scale or scale<=0 then return nil end
 local usedScale=scale;local right=readOne(q,_G.EditModeUtil,"IsRightAnchoredActionBar","boolean",frame)
 local shown=readOne(q,frame,"IsShown","boolean")
 if right==nil or shown==nil then return nil end
 if not default and right and shown then
  -- The nested right-bar writer resets a nondefault shown bar to scale 1
  -- after ApplySystemAnchor divided offsets by its incoming owned scale.
  local prior=editRecords[row]
  usedScale=row.writtenScale or prior and prior.target and prior.target.scale
  if not usedScale or usedScale<=0 or math.abs(scale-1)>.00001 then return nil end
 end
 local points={first};local second=capture(q,info,"anchorInfo2")
 if second~=nil then second=capturedAnchor(q,second);if not second then return nil end;points[2]=second end
 for _,point in ipairs(points) do point[4],point[5]=point[4]/usedScale,point[5]/usedScale end
 q.system={frame=frame,default=default}
 if not inputsCurrent(q) then return nil end
 return {points=points,scale=scale,scaleWritten=not default and right and shown,normalizedOffsets=true,anchorScale=usedScale,inputs=q}
end
local function readState(frame)
 local shown=call(frame,"IsShown","boolean")
 local default=call(frame,"IsInDefaultPosition","boolean")
 local width=call(frame,"GetWidth","number");local height=call(frame,"GetHeight","number")
 if shown==nil or default==nil or not width or not height or width<=0 or height<=0 then return nil end
 return {shown=shown,default=default,width=width,height=height}
end
-- Reconstruct the source writer's public anchor arithmetic. Its full bounded
-- stack is observed before any managed bar moves, so one repaired bar cannot
-- change the recognition of a later bar in the same native layout pass.
function R:Expected(kind)
 local manager=self.manager
 local frames=kind=="bottom" and array(call(_G.EditModeUtil,"GetBottomActionBars","table")) or array(call(manager,"GetRightActionBars","table"))
 if not frames then return nil end
 local states={};for _,f in ipairs(frames) do states[f]=readState(f);if not states[f] then return nil end end
 local result={}
 if kind=="right" then
  local top=call(manager,"GetRightActionBarTopLimit","number");local bottom=call(manager,"GetRightActionBarBottomLimit","number")
  local height=call(_G.MultiBarRight,"GetHeight","number")
  local x,y,padding=constant("RIGHT_ACTION_BAR_DEFAULT_OFFSET_X"),constant("RIGHT_ACTION_BAR_DEFAULT_OFFSET_Y"),constant("RIGHT_ACTION_BAR_DEFAULT_PADDING_X")
  if not top or not bottom or not height or height<=0 or top<=bottom or not x or not y or not padding then return nil end
  local scale=height>top-bottom and (top-bottom)/height or 1
  local previous
  for _,frame in ipairs(frames) do
   local state=states[frame]
   if state.shown then
    if state.default then
     x=x+(previous and -states[previous].width-5+padding or 0)
     result[frame]={points={{"RIGHT",UIParent,"RIGHT",x,y}},scale=scale,scaleWritten=true};previous=frame
    else
     -- That same source writer changes only scale for a nondefault bar.
     -- It cannot authorize a foreign point; retain the last admitted anchor.
     local name=call(frame,"GetName","string");local row=name and N.rows[name];local prior=row and editRecords[row]
     local points=row and row.frame==frame and (row.writtenPoints or prior and prior.target and prior.target.points)
     if points then result[frame]={points=points,scale=1,scaleWritten=true} end
    end
   end
  end
  return result
 end
 if kind~="bottom" then return nil end
 local relative=field(_G,"ACTION_BARS_RELATIVE_TO_BASE_POSITIONING")
 if type(relative)~="boolean" then return nil end
 local gap=constant("BOTTOM_ACTION_BARS_SPACER_Y")
 if not gap then return nil end
 local base,basePoint,x,y
 if relative then
  if #frames==0 then return result end
  base,basePoint,x,y=frames[1],"BOTTOMLEFT",0,0
  if states[base].shown and not states[base].default then y=states[base].height+gap end
 else
  base,basePoint=UIParent,"BOTTOM"
  x,y=constant("MAIN_ACTION_BAR_OFFSET_X"),constant("MAIN_ACTION_BAR_OFFSET_Y")
  if not x or not y then return nil end
  if _G.OverrideActionBar then
   local shown=call(_G.OverrideActionBar,"IsShown","boolean");if shown==nil then return nil end
   if shown then
    local xp=field(_G.OverrideActionBar,"xpBar");local xpShown=call(xp,"IsShown","boolean")
    local height=call(_G.OverrideActionBar,"GetHeight","number");local xpHeight=xpShown and call(xp,"GetHeight","number") or 0
    if xpShown==nil or not height or not xpHeight then return nil end
    y=height+xpHeight+10
   end
  end
  for _,f in ipairs(frames) do
   if states[f].shown and states[f].default then
    local center=call(_G.EditModeUtil,"IsCenterManagedFrame","boolean",f);if center==nil then return nil end
    local width=center and call(_G.EditModeUtil,"CalculateCenterManagedSystemWidth","number") or states[f].width
    if not width then return nil end
    x=x-width/2;break
   end
  end
 end
 for i,f in ipairs(frames) do
  local state=states[f]
  if state.shown and state.default then
   local skip=field(f,"skipAutomaticPositioning")
   if skip~=nil and type(skip)~="boolean" then return nil end
   local expected
   if skip then expected=layoutAnchor(manager,f)
   else
    local info=call(manager,"GetDefaultAnchor","table",f)
    local offset=info and field(info,"bottomBarOffsetX") or 0;offset=offset or 0
    local exclude=info and field(info,"bottomBarExcludeFromStackIncrement") or false
    if not number(offset) or type(exclude)~="boolean" then return nil end
    expected=f==base and layoutAnchor(manager,f) or {{"BOTTOMLEFT",base,basePoint,x+offset,y}}
    if not exclude then
     local spacing=gap
     if i<#frames and f==_G.SecondaryStatusTrackingBarContainer and frames[i+1]==_G.MainStatusTrackingBarContainer then
      spacing=constant("PRIMARY_AND_SECONDARY_STATUS_TRACKING_BAR_SPACER_Y");if not spacing then return nil end
     end
     y=y+state.height+spacing
    end
   end
   if not expected then return nil end
   result[f]={points=expected}
   if f==_G.MainActionBar then result[f].size,result[f].inputs=resizeOutput(f) end
  end
 end
 return result
end
local function same(a,b)
 if not a or not b or #a~=#b then return false end
 for i,p in ipairs(a) do for j=1,5 do
  if j>=4 then if not number(p[j]) or not number(b[i][j]) or math.abs(p[j]-b[i][j])>.001 then return false end
  elseif p[j]~=b[i][j] then return false end
 end end
 return true
end
function R:Accept(receipt,row,points,scale,size)
 local r=receipts[receipt]
 local function refuse(reason) if row and row.name then self.roots[row.name]=reason end;return false end
 if not r or r.row~=row or r.frame~=row.frame or r.profile~=M.profile or r.rows~=N.rows or N.rows[row.name]~=row
  or _G[row.name]~=row.frame or row.layoutGeometry~=r.geometry or row.layoutProfile~=r.profile
  or S:InCombat() or not current(self,r.profile,row.module) or not S:Frame(row.frame,false) or not inputsCurrent(r.expected.inputs) then return refuse("REFLOW_STATE_CHANGED") end
 if call(row.frame,"GetParent")~=(r.expected.parent or row.gate or row.originalParent) then return refuse("REFLOW_PARENT_CHANGED") end
 if not same(points,r.expected.points) then return refuse("REFLOW_POINTS_UNMATCHED") end
 local allowedScale=r.expected.scale or row.writtenScale
 local fitted=r.expected.size or row.layoutSize
 if not allowedScale or math.abs(scale-allowedScale)>.00001 then return refuse("REFLOW_SCALE_UNMATCHED") end
 if not size or not fitted or math.abs(size[1]-fitted[1])>.001 or math.abs(size[2]-fitted[2])>.001 then return refuse("REFLOW_SIZE_UNMATCHED") end
 r.accepted=true;r.acceptedSize={size[1],size[2]};self.roots[row.name]="NATIVE_OUTPUT_QUALIFIED"
 return true
end
function R:Current(receipt,row)
 local r=receipts[receipt]
 local function owns()
  return r and r.row==row and r.frame==row.frame and r.profile==M.profile and r.rows==N.rows and N.rows[row.name]==row
  and _G[row.name]==row.frame and row.layoutGeometry==r.geometry and row.layoutProfile==r.profile
  and self.Expected==expectedSource and self.NativePass==nativePassSource and self.SystemPass==systemPassSource and self.CastPass==castPassSource
 end
 if not owns() or not inputsCurrent(r.expected.inputs) or call(r.frame,"GetParent")~=(r.expected.parent or row.gate or row.originalParent) then return false end
 if r.acceptedSize then
  -- The renewal qualifies one initial native size. SetScale/anchor writes must
  -- not continue if a callback changes that logical size after acceptance.
  local w,h=call(r.frame,"GetWidth","number"),call(r.frame,"GetHeight","number")
  if w~=r.acceptedSize[1] or h~=r.acceptedSize[2] then self.roots[row.name]="REFLOW_LOGICAL_SIZE_CHANGED";return false end
 end
 return field(r.writer,r.key)==r.method and current(self,r.profile,row.module) and not S:InCombat() and owns()
end
-- Post-hooks are observation-only. Protected writes occur later from the
-- ordinary OOC maintenance path, never inside Blizzard's secure editor stack.
local function copyPoints(points)
 local out={};for i,p in ipairs(points or {}) do out[i]={p[1],p[2],p[3],p[4],p[5]} end;return out
end
local function snapshot(row)
 local f=row.frame;local q=newInputs();local count=readOne(q,f,"GetNumPoints","number")
 if not count or count<0 or count>8 or count%1~=0 then return nil end
 local out={points={},inputs=q}
 for i=1,count do
  local p=readMany(q,f,"GetPoint",false,i)
  if not p or not S:Text(p[1]) or not p[2] or not S:Frame(p[2],false) or not S:Text(p[3]) or not number(p[4]) or not number(p[5]) then return nil end
  out.points[i]={p[1],p[2],p[3],p[4],p[5]}
 end
 out.parent=readOne(q,f,"GetParent");out.scale=readOne(q,f,"GetScale","number")
 out.size={readOne(q,f,"GetWidth","number"),readOne(q,f,"GetHeight","number")}
 if not out.parent or not S:Frame(out.parent,false) or not out.scale or out.scale<=0 or not out.size[1] or not out.size[2]
  or out.size[1]<=0 or out.size[2]<=0 or not inputsCurrent(q) then return nil end
 return out
end
local function exactSnapshot(a,b)
 if not a or not b or a.parent~=b.parent or a.scale~=b.scale or a.size[1]~=b.size[1] or a.size[2]~=b.size[2] or #a.points~=#b.points then return false end
 for i,p in ipairs(a.points) do for j=1,5 do if p[j]~=b.points[i][j] then return false end end end
 return true
end
local function methodsCurrent(self)
 return self.Expected==expectedSource and self.NativePass==nativePassSource and self.SystemPass==systemPassSource and self.CastPass==castPassSource
  and self.EditAccept==editAcceptSource and self.EditCurrent==editCurrentSource and self.EditComplete==editCompleteSource
  and self.EditAcquire==editAcquireSource and self.ReleaseEditing==releaseEditingSource
end
local function recordCurrent(self,r,allowEdit)
 return r and current(self,r.profile,r.row.module,allowEdit) and methodsCurrent(self) and not S:InCombat()
  and N.rows==r.rows and N.rows[r.row.name]==r.row and r.row.frame==r.frame and _G[r.row.name]==r.frame
  and not r.row.contested and not r.row.failed and (not r.writer or field(r.writer,r.key)==r.method)
  and inputsCurrent(r.expected and r.expected.inputs) and inputsCurrent(r.observed and r.observed.inputs)
  and current(self,r.profile,r.row.module,allowEdit) and methodsCurrent(self) and not S:InCombat()
  and N.rows==r.rows and N.rows[r.row.name]==r.row and r.row.frame==r.frame and _G[r.row.name]==r.frame
  and (not r.writer or field(r.writer,r.key)==r.method)
end
local function outputMatches(row,output,observed,prior)
 if not observed or not same(observed.points,output.points) then return false end
 local scale=output.scale or row.writtenScale or prior and prior.scale or row.originalScale
 local size=output.size or row.layoutSize or prior and prior.size or {row.originalWidth,row.originalHeight}
 local parent=output.parent or (row.active and row.gate) or prior and prior.parent or row.originalParent
 return observed.parent==parent and scale and math.abs(observed.scale-scale)<=.00001 and size
  and math.abs(observed.size[1]-size[1])<=.001 and math.abs(observed.size[2]-size[2])<=.001
end
local function queueOutput(self,row,output,writer,key,method)
 if not row or delegated(row.name,row.frame) then return end
 local suspended=editRecords[row]
 if not row or row.contested or row.failed or row.restorePending or not output
  or not (row.active and (row.layoutGeometry and row.layoutProfile==M.profile or call(self.manager,"IsShown","boolean")==true) or suspended and suspended.stage=="released") then return end
 local r={row=row,frame=row.frame,rows=N.rows,profile=M.profile,geometry=row.layoutGeometry,expected=output,writer=writer,key=key,method=method}
 local observed=snapshot(row);r.observed=observed
 if not outputMatches(row,output,observed,suspended and suspended.target) or not recordCurrent(self,r,true) then
  self.roots[row.name]="NATIVE_OUTPUT_UNAVAILABLE";return
 end
 queued[row]=r;self.roots[row.name]=call(self.manager,"IsShown","boolean")==true and "NATIVE_EDIT_OUTPUT_OBSERVED" or "NATIVE_REFLOW_QUEUED"
end
local function deferCombat(self,tag,writer,key,method,module)
 if not exactClient() or M.NativeActionLayout~=self or M.ManagedNative~=N or _G.EditModeManagerFrame~=self.manager then return end
 combatPending[tag]={profile=M.profile,manager=self.manager,writer=writer,key=key,method=method,module=module}
end
function R:NativePass(kind)
 if self.busy then return end
 local key=kind=="bottom" and "UpdateBottomActionBarPositions" or "UpdateRightActionBarPositions"
 if S:InCombat() then deferCombat(self,kind,self.manager,key,writerMethods[key],"ActionBars");return end
 local profile=M.profile;if not current(self,profile,"ActionBars",true) or not methodsCurrent(self) then return end
 if field(self.manager,key)~=writerMethods[key] then self.status="NATIVE_WRITER_CHANGED";return end
 local expected=expectedSource(self,kind)
 if not expected or not current(self,profile,"ActionBars",true) or S:InCombat() then self.status="NATIVE_OUTPUT_UNAVAILABLE";return end
 for _,row in pairs(N.rows) do
  if not delegated(row.name,row.frame) and row.module=="ActionBars" and expected[row.frame] then queueOutput(self,row,expected[row.frame],self.manager,key,writerMethods[key]) end
 end
end
function R:SystemPass(name)
 if delegated(name) then return end
 if self.busy then return end
 local profile=M.profile;local hook=systemHooks[name];local row=N.rows[name]
 if S:InCombat() then
  if hook and row then deferCombat(self,"system:"..name,hook.frame,"ApplySystemAnchor",hook.method,row.module) end
  return
 end
 if not row or not hook or _G[name]~=hook.frame or field(hook.frame,"ApplySystemAnchor")~=hook.method
  or not current(self,profile,row.module,true) or not methodsCurrent(self) then return end
 local output=systemAnchor(hook.frame,row)
 -- Container cast and default bottom/right paths are covered by their actual
 -- nested writer. An unavailable plain projection cannot revoke that output.
 if output then queueOutput(self,row,output,hook.frame,"ApplySystemAnchor",hook.method) end
end
function R:CastPass(kind)
 if self.busy then return end
 local row=N.rows.PlayerCastingBarFrame;local hook=castHooks[kind]
 if S:InCombat() then
  if hook and row then deferCombat(self,"cast:"..kind,hook.writer,hook.key,hook.method,row.module) end
  return
 end
 if not row or not hook or not current(self,M.profile,row.module,true) or not methodsCurrent(self) then return end
 if field(hook.writer,hook.key)~=hook.method then self.roots[row.name]="NATIVE_WRITER_CHANGED";return end
 local output=castOutput(row.frame,row,kind)
 if output then queueOutput(self,row,output,hook.writer,hook.key,hook.method) end
end
function R:EditAccept(token,row)
 local r=receipts[token]
 local retry=r and editRecords[row]==r and r.stage=="releasing"
 if not r or r.row~=row or r.kind~="edit" or not recordCurrent(self,r,true) or call(self.manager,"IsShown","boolean")~=true then return nil end
 if not retry and (not row.active or row.restorePending or not exactSnapshot(snapshot(row),r.observed)) then return nil end
 local target=r.target
 if not target or not recordCurrent(self,r,true) then return nil end
 r.stage="releasing";editRecords[row]=r;row.editSuspended=true
 return {points=copyPoints(target.points),scale=target.scale,size={target.size[1],target.size[2]},
  before=not retry and {points=copyPoints(r.observed.points),scale=r.observed.scale,size={r.observed.size[1],r.observed.size[2]}} or nil}
end
function R:EditCurrent(token,row)
 local r=receipts[token]
 if not r or r.row~=row or editRecords[row]~=r or r.stage~="releasing" or not recordCurrent(self,r,true)
  or call(self.manager,"IsShown","boolean")~=true then return false end
 local parent=call(row.frame,"GetParent")
 return (parent==r.observed.parent or parent==r.target.parent) and recordCurrent(self,r,true)
end
function R:EditComplete(token,row,done)
 local r=receipts[token]
 if not r or r.row~=row or editRecords[row]~=r or done~=true or row.active or row.contested or row.failed or row.restorePending
  or not recordCurrent(self,r,true) then return false end
 local observed=snapshot(row)
 if not observed or observed.parent~=r.target.parent or not same(observed.points,r.target.points)
  or math.abs(observed.scale-r.target.scale)>.00001 or math.abs(observed.size[1]-r.target.size[1])>.001
  or math.abs(observed.size[2]-r.target.size[2])>.001 or not recordCurrent(self,r,true) then return false end
 r.target=observed;r.observed=observed;r.stage="released";r.geometry=nil;r.expected=nil
 self.roots[row.name]="NATIVE_EDIT_SUSPENDED";N.status[row.name]="NATIVE_EDIT_SUSPENDED";N.reconcilePending=true;return true
end
function R:EditAcquire(row,phase)
 local r=editRecords[row]
 if not r or r.stage~="released" and r.stage~="acquiring" or not recordCurrent(self,r,false)
  or call(self.manager,"IsShown","boolean")~=false or row.restorePending then return false end
 local observed=snapshot(row);local target=r.target
 if phase~="begin" and r.stage=="acquiring" and observed and row.gate and observed.parent==row.gate then
  observed.parent=target.parent
 end
 if not exactSnapshot(observed,target) or not recordCurrent(self,r,false) then
  self.roots[row.name]="NATIVE_EDIT_OWNER_CHANGED";N.status[row.name]="NATIVE_EDIT_OWNER_CHANGED";return false
 end
 if phase=="begin" then
  if row.active then return false end
  r.stage="acquiring";return true
 elseif phase=="current" then return r.stage=="acquiring"
 elseif phase=="complete" then
  if r.stage~="acquiring" or not row.active or (row.gate and call(row.frame,"GetParent")~=row.gate) then return false end
  editRecords[row]=nil;row.editSuspended=nil;row.editPositionPending=true
  self.roots[row.name]="NATIVE_EDIT_REACQUIRED";return true
 end
 return false
end
function R:ReleaseEditing()
 if self.busy or S:InCombat() or call(self.manager,"IsShown","boolean")~=true or not methodsCurrent(self) then return end
 self.busy=true
 for _,name in ipairs(systemNames) do
  local row=N.rows[name]
  local release= row and editRecords[row]
  if release and release.stage=="releasing" and recordCurrent(self,release,true) then
   local token={};receipts[token]=release;pcall(N.ReleaseNativeEdit,N,row,token);receipts[token]=nil
  elseif row and row.active and not row.contested and not row.failed and not row.restorePending and not release
   and (not row.layoutGeometry or row.layoutProfile==M.profile) and current(self,M.profile,row.module,true) then
   local r=queued[row];local observed=snapshot(row)
   if r and (not recordCurrent(self,r,true) or not exactSnapshot(observed,r.observed)) then r=nil end
   if not r then
    local expected={points=row.writtenPoints or row.originalPoints,scale=row.writtenScale or row.originalScale,
     size=row.sizeWritten or row.layoutSize or {row.originalWidth,row.originalHeight}}
    if outputMatches(row,expected,observed) then r={row=row,frame=row.frame,rows=N.rows,profile=M.profile,geometry=row.layoutGeometry,observed=observed} end
   end
   if r and observed then
    local output=r.expected;local target={parent=row.gate and row.originalParent or observed.parent,
     points=output and copyPoints(observed.points) or copyPoints(row.originalPoints),
     scale=output and output.scaleWritten and observed.scale or row.originalScale,
     size=output and output.size and {observed.size[1],observed.size[2]} or {row.originalWidth,row.originalHeight}}
    if output and output.normalizedOffsets then
     for _,point in ipairs(target.points) do point[4],point[5]=point[4]*(output.anchorScale or observed.scale)/target.scale,point[5]*(output.anchorScale or observed.scale)/target.scale end
    end
    r.kind="edit";r.target=target;local token={};receipts[token]=r
    local ok,done=pcall(N.ReleaseNativeEdit,N,row,token)
    receipts[token]=nil;queued[row]=nil
    if not ok or not done then self.roots[name]="NATIVE_EDIT_RELEASE_PENDING" end
   end
  end
 end
 self.busy=nil
end
function R:InstallSystems()
 for _,name in ipairs(systemNames) do
  local frame=_G[name];local prior=systemHooks[name]
  if not prior and S:Frame(frame,false) and type(field(frame,"ApplySystemAnchor"))=="function" then
   local ok=pcall(hooksecurefunc,frame,"ApplySystemAnchor",function() if _G[name]==frame then systemPassSource(self,name) end end)
   if ok then systemHooks[name]={frame=frame,method=field(frame,"ApplySystemAnchor")} end
  end
 end
 local cast=_G.PlayerCastingBarFrame;local container=_G.BottomManagedFrameContainer
 for kind,entry in pairs({layout={container,"Layout"},size={cast,"UpdateSystemSettingBarSize"}}) do
  local writer,key=entry[1],entry[2]
  if not castHooks[kind] and S:Frame(writer,false) and type(field(writer,key))=="function" then
   local ok=pcall(hooksecurefunc,writer,key,function() castPassSource(self,kind) end)
   if ok then castHooks[kind]={writer=writer,key=key,method=field(writer,key)} end
  end
 end
end
function R:Install()
 if not exactClient() or S:InCombat() or not M.Managed:Enabled() or (not M:IsModuleActive("ActionBars") and not M:IsModuleActive("UnderCharacterHUD")) or M.Native:Conflict() then return false end
 local manager=_G.EditModeManagerFrame
 if not S:Frame(manager,false) or type(hooksecurefunc)~="function" then return false end
 if self.manager then
  if self.manager~=manager then return false end
  self:InstallSystems();return next(writerMethods)~=nil or next(systemHooks)~=nil
 end
 self.manager=manager
 for key,kind in pairs({UpdateBottomActionBarPositions="bottom",UpdateRightActionBarPositions="right"}) do
  if type(field(manager,key))=="function" then
   local ok=pcall(hooksecurefunc,manager,key,function() if self.manager==manager then nativePassSource(self,kind) end end)
   if ok then writerMethods[key]=field(manager,key) end
  end
 end
 self:InstallSystems()
 self.status=(next(writerMethods) or next(systemHooks)) and "NATIVE_REFLOW_OBSERVED" or "NATIVE_WRITER_UNAVAILABLE"
 return next(writerMethods)~=nil or next(systemHooks)~=nil
end
function R:Retry()
 if S:InCombat() or self.busy or not methodsCurrent(self) then return end
 -- A combat callback records only addon-owned identities, not native values.
 -- Observe again OOC only for that still-current source event and profile.
 for tag,event in pairs(combatPending) do
  combatPending[tag]=nil
  if event.profile==M.profile and event.manager==self.manager and field(event.writer,event.key)==event.method
   and current(self,event.profile,event.module,true) and methodsCurrent(self) then
   if tag=="bottom" or tag=="right" then self:NativePass(tag)
   elseif tag:sub(1,7)=="system:" then self:SystemPass(tag:sub(8))
   elseif tag:sub(1,5)=="cast:" then self:CastPass(tag:sub(6)) end
  end
 end
 if call(self.manager,"IsShown","boolean")==true then return end
 self.busy=true
 for row,r in pairs(queued) do
  queued[row]=nil
  if not delegated(row.name,row.frame) and recordCurrent(self,r,false) and exactSnapshot(snapshot(row),r.observed) then
   local suspended=editRecords[row]
   if suspended and suspended.stage=="released" and not row.active then
    suspended.target=r.observed;suspended.observed=r.observed;suspended.expected=r.expected
    suspended.writer,suspended.key,suspended.method=r.writer,r.key,r.method
    self.roots[row.name]="NATIVE_EDIT_REACQUIRE_PENDING"
   elseif row.active and row.layoutGeometry==r.geometry and row.layoutProfile==r.profile and not row.restorePending then
    local token={};receipts[token]=r
    local ok,placed=pcall(N.Position,N,row,row.layoutGeometry,token);receipts[token]=nil
    if ok and placed then
     self.status="NATIVE_REFLOW_RECONCILED";self.roots[row.name]="NATIVE_REFLOW_RECONCILED"
     if r.expected.parent then row.layoutNativeParent=r.expected.parent end
    end
   end
  end
 end
 self.busy=nil
end
expectedSource,nativePassSource,systemPassSource,castPassSource=R.Expected,R.NativePass,R.SystemPass,R.CastPass
editAcceptSource,editCurrentSource,editCompleteSource,editAcquireSource,releaseEditingSource=R.EditAccept,R.EditCurrent,R.EditComplete,R.EditAcquire,R.ReleaseEditing
N:BindActionLayoutValidator(R,R.Accept,R.Current,R.EditAccept,R.EditCurrent,R.EditComplete,R.EditAcquire)
