local _, M = ...
-- Original beta.14 screen-space layout. It never reads world/camera geometry.
-- Stable lanes reserve aura/cast footprints; resize work is out of combat only.
M.AdaptiveLayout = { revision=1 }
local L,S = M.AdaptiveLayout,M.Safety
local function clamp(v,a,b) return math.max(a,math.min(b,v)) end
function L:Screen()
    if M.Managed and M.Managed.Viewport then
        local w,h=M.Managed:Viewport()
        if w and w>=960 and h>=600 then return w,h end
        return nil,"Screen geometry is not available yet."
    end
    local w,ws=S:Public(UIParent.GetWidth,"number",UIParent)
    local h,hs=S:Public(UIParent.GetHeight,"number",UIParent)
    if ws~="KNOWN" or hs~="KNOWN" or w<960 or h<600 then return nil,"Screen geometry is not available yet." end
    return w,h
end
function L:CastPlacement(hud,scale)
    local hs=hud.hudScale/100
    if hud.layoutOrder==2 then
        local width,height=M.HUDView:Geometry(hud)
        return {x=hud.x,y=hud.y+(height-hud.castHeight)*hs/2,maxW=width*hs,maxH=hud.castHeight*hs,group="cast"}
    end
    return {x=hud.x,y=hud.y-38*scale,maxW=hud.width*hs,maxH=32*scale,group="cast"}
end
-- Planned source rectangles, not observed native artwork or collision certification.
function L:Signature(w,h,hud,centralGroup,referenceLayout)
    hud=hud or {}
    return table.concat({tostring(w),tostring(h),referenceLayout==true and "reference" or "classic",centralGroup==true and "central" or "legacy",
        tostring(hud.layoutOrder),tostring(hud.width),tostring(hud.castWidthExtra),
        tostring(hud.healthHeight),tostring(hud.resourceHeight),tostring(hud.castHeight),tostring(hud.gap),tostring(hud.rowPitch),tostring(hud.layoutRevision),tostring(hud.x),tostring(hud.y),tostring(hud.hudScale)},":")
end
function L:Plan(w,h,hudConfig,centralGroup,referenceLayout)
    if not S:Number(w) or not S:Number(h) or w<960 or h<600 then return nil,"Unsupported screen geometry." end
    local scale=clamp(math.min(w/1440,h/900),.6,1.15)
    -- UIParent units already incorporate the player's native UI scale.
    local p={width=w,height=h,scale=scale,layouts={},zones={},native={},centralGroup=centralGroup==true and hudConfig and (hudConfig.layoutOrder==2 or hudConfig.layoutRevision==1) or false,requestSignature=self:Signature(w,h,hudConfig,centralGroup,referenceLayout)}
    local function box(id,x,y,bw,bh,padding,group)
        local s=scale
        local nw,nh=bw*s,bh*s
        x=clamp(x,-w/2+nw/2+8,w/2-nw/2-8)
        y=clamp(y,-h/2+nh/2+8,h/2-nh/2-8)
        x=clamp(x,-w*.48,w*.48);y=clamp(y,-h*.48,h*.48)
        p.layouts[id]={x=x/w,y=y/h,width=bw,height=bh,scale=s}
        p.zones[id]={x=x,y=y,width=nw,height=nh+(padding or 0)*s,group=group or "always"}
    end
    local bottom=-h/2
    -- Combat anchors share a horizontal rhythm without covering the character.
    box("UnitFrames.player",-265*scale,bottom+270*scale,240,55,70)
    box("UnitFrames.target",265*scale,bottom+270*scale,240,55,70)
    box("UnitFrames.pet",-265*scale,bottom+400*scale,190,44,26)
    box("UnitFrames.focus",0,-math.floor(clamp(h*.13,72,210))+265*scale,220,55,60)
    if referenceLayout then
        -- The supplied EUI export places player/target in a compact top-left
        -- lane and focus at right. Adapt that arrangement to the viewport,
        -- keeping existing frame dimensions and native secure handoff rules.
        box("UnitFrames.player",-w/2+140*scale,h/2-75*scale,240,55,70)
        box("UnitFrames.target",-w/2+405*scale,h/2-75*scale,240,55,70)
        box("UnitFrames.pet",-w/2+115*scale,h/2-195*scale,190,44,26)
        box("UnitFrames.focus",w/2-380*scale,h*.12,220,55,60)
    end
    for i=1,5 do
        box("UnitFrames.boss"..i,w/2-425*scale,h/2-(110+(i-1)*90)*scale,210,50,30,"boss")
    end
    -- Party and raid are mutually exclusive, using the same left-side lane.
    local left=-w*.48+14*scale
    for i=1,4 do
        box("PartyRaid.party"..i,left+91*scale,h/2-(118+(i-1)*100)*scale,182,50,36,"party")
    end
    for i=1,40 do
        local col,row=math.floor((i-1)/8),(i-1)%8
        box("PartyRaid.raid"..i,left+(45+col*98)*scale,h/2-(106+row*48)*scale,90,36,6,"raid")
    end
    -- A 2D HUD remains below screen center regardless of camera zoom.
    local reference=hudConfig and hudConfig.layoutOrder==2
    p.hud={x=0,y=math.floor(-clamp(h*(reference and .205 or .13),72,reference and 360 or 210)),width=reference and hudConfig.width or 205,scale=clamp(math.floor(scale*100+.5),75,115)}
    if hudConfig and hudConfig.layoutRevision==1 then
        p.hud.x=hudConfig.x;p.hud.y=hudConfig.y;p.hud.width=hudConfig.width;p.hud.scale=hudConfig.hudScale
    end
    local hud=hudConfig and M:Copy(hudConfig) or {width=p.hud.width}
    hud.x,hud.y,hud.hudScale=p.hud.x,p.hud.y,p.hud.scale
    local hudWidth,hudHeight=205,30
    if hudConfig then hudWidth,hudHeight=M.HUDView:Geometry(hud) end
    p.zones["UnderCharacterHUD.player"]={x=0,y=p.hud.y,width=hudWidth*p.hud.scale/100,height=hudHeight*p.hud.scale/100,group="always"}
    -- Mutually exclusive class systems occupy a shared dedicated lane.
    box("ResourceBars.class",0,p.hud.y+62*scale,200,42,0,"class")
    box("ResourceBars.runes",0,p.hud.y+62*scale,200,62,0,"class")
    box("ResourceBars.totems",0,p.hud.y+155*scale,230,64,0,"summons")
    box("ResourceBars.empower",0,p.hud.y-80*scale,240,54,0,"empower")
    -- This is a fallback only: it is concealed while its selected primary works.
    box("ResourceBars.player",0,bottom+280*scale,220,78,0,"fallback")
    box("Cooldowns.tracked",0,bottom+210*scale,400,44,0,"cooldowns")
    box("Auras.private",0,h/2-75*scale,152,44,0,"private")
    box("Auras.player",100*scale,h/2-104*scale,320,108,0,"manual")
    box("Auras.preparation",-w/2+165*scale,-55*scale,280,118,0,"manual")
    -- SidebarLayout places the public status strip below the square map. Do
    -- not reserve a stale center-screen strip or rewrite its saved rectangle.
    box("QuestTracker.compact",w/2-150*scale,h/2-360*scale,270,300,0,"manual")
    box("DamageMeters.summary",w/2-150*scale,-h/2+165*scale,250,180,0,"manual")
    box("PvP.observed",w/2-150*scale,0,250,220,0,"manual")
    box("PvP.lens",0,h/2-35*scale,200,24,0,"manual")
    -- Native controls are adopted, not duplicated or remapped.
    p.native.MainActionBar={x=0,y=bottom+55*scale,maxW=480*scale,maxH=44*scale,group="actions"}
    p.native.MultiBarBottomLeft={x=0,y=bottom+104*scale,maxW=480*scale,maxH=40*scale,group="actions"}
    p.native.MultiBarBottomRight={x=0,y=bottom+151*scale,maxW=480*scale,maxH=40*scale,group="actions"}
    p.native.MultiBar5={x=-180*scale,y=h/2-34*scale,maxW=340*scale,maxH=32*scale,group="actions"}
    p.native.MultiBar6={x=180*scale,y=h/2-34*scale,maxW=340*scale,maxH=32*scale,group="actions"}
    p.native.MultiBar7={x=0,y=h/2-76*scale,maxW=340*scale,maxH=32*scale,group="actions"}
    p.native.MultiBarRight={x=w/2-26*scale,y=-h/2+202*scale,maxW=38*scale,maxH=380*scale,group="actions"}
    p.native.MultiBarLeft={x=w/2-69*scale,y=-h/2+202*scale,maxW=38*scale,maxH=380*scale,group="actions"}
    p.native.MinimapCluster={x=w/2-119*scale,y=h/2-121*scale,maxW=208*scale,maxH=208*scale,group="navigation"}
    p.native.ObjectiveTrackerFrame={x=w/2-161*scale,y=h/2-389*scale,maxW=285*scale,maxH=280*scale,group="objectives"}
    p.native.ChatFrame1={x=-w/2+176*scale,y=bottom+113*scale,maxW=320*scale,maxH=150*scale,width=320*scale,height=150*scale,group="chat"}
    p.native.BuffFrame={x=0,y=h/2-130*scale,maxW=280*scale,maxH=70*scale,group="auras"}
    p.native.DebuffFrame={x=0,y=h/2-216*scale,maxW=280*scale,maxH=56*scale,group="auras"}
    p.native.EssentialCooldownViewer={x=0,y=bottom+209*scale,maxW=400*scale,maxH=44*scale,group="cooldowns"}
    p.native.UtilityCooldownViewer={x=0,y=bottom+255*scale,maxW=380*scale,maxH=36*scale,group="cooldowns"}
    p.native.BuffIconCooldownViewer={x=0,y=p.hud.y+110*scale,maxW=260*scale,maxH=32*scale,group="cooldowns"}
    p.native.BuffBarCooldownViewer={x=210*scale,y=p.hud.y+155*scale,maxW=180*scale,maxH=64*scale,group="cooldowns"}
    p.native.PlayerCastingBarFrame=self:CastPlacement(hud,scale)
    -- Pack bounded, reserved footprints, not transient unit values. Native-sized
    -- views may decline an unsupported fit; we never infer world-nameplate geometry.
    local occupied={};p.placements={};p.adjusted=0
    local margin,gap=8,3*scale
    local function available(v,x,y)
        if math.abs(x)>w*.48 or math.abs(y)>h*.48 then return false end
        if x-v.width/2 < -w/2+margin or x+v.width/2>w/2-margin or y-v.height/2 < -h/2+margin or y+v.height/2>h/2-margin then return false end
        local test={x=x,y=y,width=v.width,height=v.height}
        for _,o in ipairs(occupied) do if L:Overlap(test,o,gap) then return false end end
        return true
    end
    local function place(id,v,apply)
        local x,y=v.x,v.y
        if not available(v,x,y) then
            local best,bx,by=nil,nil,nil
            local step=math.max(10,16*scale)
            for yy=-h/2+margin+v.height/2,h/2-margin-v.height/2,step do
                for xx=-w/2+margin+v.width/2,w/2-margin-v.width/2,step do
                    local d=(xx-x)^2+(yy-y)^2
                    if (not best or d<best) and available(v,xx,yy) then best,bx,by=d,xx,yy end
                end
            end
            if not best then return false end
            x,y=bx,by;p.adjusted=p.adjusted+1
        end
        local placed={id=id,x=x,y=y,width=v.width,height=v.height}
        occupied[#occupied+1]=placed;p.placements[id]=placed
        if apply then apply(x,y) end
        return true
    end
    local function own(id)
        local z=p.zones[id];local l=p.layouts[id]
        return place(id,z,function(x,y) z.x,z.y=x,y;l.x,l.y=x/w,y/h end)
    end
    local function native(id)
        local v=p.native[id]
        return place(id,{x=v.x,y=v.y,width=v.maxW,height=v.maxH},function(x,y) v.x,v.y=x,y end)
    end
    -- Reserve the primary health/cast pair as one fixed, camera-independent group.
    local hs=p.hud.scale/100;local cast=p.native.PlayerCastingBarFrame
    local hy=p.hud.y;local unionH=hudHeight*hs
    local offset=0
    local unionW=hudWidth*hs
    local main,utility=p.native.EssentialCooldownViewer,p.native.UtilityCooldownViewer
    if p.centralGroup then
        -- One immutable reservation: cast/HUD, main cooldowns, then utility.
        -- Hidden/missing native viewers do not release or collapse these slots.
        local extra=main.maxH+utility.maxH+2*gap
        unionH=unionH+extra;offset=extra/2
        unionW=math.max(unionW,main.maxW,utility.maxW)
    end
    if not place("playerHUD",{x=p.hud.x,y=hy-offset,width=unionW,height=unionH},function(x,y)
        p.hud.x=x;p.hud.y=y+offset;hud.x,hud.y=x,p.hud.y
        local position=self:CastPlacement(hud,scale);cast.x,cast.y=position.x,position.y
        p.zones["UnderCharacterHUD.player"].x=x;p.zones["UnderCharacterHUD.player"].y=p.hud.y
        if p.centralGroup then
            main.x,main.y=x,p.hud.y-hudHeight*hs/2-gap-main.maxH/2
            utility.x,utility.y=x,main.y-main.maxH/2-gap-utility.maxH/2
        end
    end) then return nil,"The player display does not fit this UI scale." end
    for _,id in ipairs({"MainActionBar","MultiBarBottomLeft","MultiBarBottomRight","ChatFrame1","MinimapCluster","ObjectiveTrackerFrame"}) do
        if not native(id) then return nil,"The native interface does not fit this UI scale." end
    end
    for _,id in ipairs({"UnitFrames.player","UnitFrames.target","UnitFrames.focus","UnitFrames.pet"}) do
        if not own(id) then return nil,"The unit frames do not fit this UI scale." end
    end
    -- One shared left-side group slot; party and raid views are mutually exclusive.
    local x=-w*.48+(14+241)*scale;local y=h/2-269*scale
    if not place("groupRoster",{x=x,y=y,width=482*scale,height=388*scale},function(nx,ny)
        for id,z in pairs(p.zones) do if z.group=="party" or z.group=="raid" then
            z.x,z.y=z.x+nx-x,z.y+ny-y;local l=p.layouts[id];l.x,l.y=clamp(z.x/w,-.48,.48),clamp(z.y/h,-.48,.48)
        end end
    end) then return nil,"The 40-player layout does not fit this UI scale." end
    for _,id in ipairs({"ResourceBars.runes","ResourceBars.totems"}) do
        if not own(id) then return nil,"The class displays do not fit this UI scale." end
    end
    p.layouts["ResourceBars.class"].x=p.layouts["ResourceBars.runes"].x;p.layouts["ResourceBars.class"].y=p.layouts["ResourceBars.runes"].y
    for i=1,5 do if not own("UnitFrames.boss"..i) then return nil,"The encounter frames do not fit this UI scale." end end
    for _,id in ipairs({"MultiBarRight","MultiBarLeft","MultiBar5","MultiBar6","MultiBar7","BuffFrame","DebuffFrame","EssentialCooldownViewer","UtilityCooldownViewer","BuffIconCooldownViewer","BuffBarCooldownViewer"}) do
        if not (p.centralGroup and (id=="EssentialCooldownViewer" or id=="UtilityCooldownViewer")) and not native(id) then
            return nil,"The additional panels do not fit this UI scale."
        end
    end
    return p
end
function L:ApplyTo(profile,w,h)
    local central=profile.modules.Cooldowns.centralGroup==true
    if central and profile.modules.UnderCharacterHUD.layoutOrder~=2 and profile.modules.UnderCharacterHUD.layoutRevision~=1 then return false,"Central cooldown refit requires reserved HUD geometry." end
    local plan,why=self:Plan(w,h,profile.modules.UnderCharacterHUD,central,profile.modules.UnitFrames.referenceLayout);if not plan then return false,why end
    for id,l in pairs(plan.layouts) do profile.layouts[id]=M:Copy(l) end
    local hud=profile.modules.UnderCharacterHUD
    hud.x,hud.y,hud.width,hud.hudScale=plan.hud.x,plan.hud.y,plan.hud.width,plan.hud.scale
    profile.modules.Nameplates.cardScale=math.max(75,math.floor(plan.scale*100+.5))
    return true,plan
end
function L:Refresh(profile,force)
    if not profile or not profile.managed or not profile.autoLayout or S:InCombat() then return false end
    local w,h=self:Screen();if not w then return false end
    local fingerprint=self:Signature(w,h,profile.modules.UnderCharacterHUD,profile.modules.Cooldowns.centralGroup,profile.modules.UnitFrames.referenceLayout)..":"..tostring(profile)
    if force or self.fingerprint~=fingerprint then
        local ok,plan=self:ApplyTo(profile,w,h)
        -- Draft projection never changes active native geometry. Publish only
        -- after the actual profile has successfully fitted this viewport.
        if ok then self.plan=plan;self.fingerprint=fingerprint end
        return ok,plan
    end
    return false
end
function L:Overlap(a,b,gap)
    gap=gap or 0
    return math.abs(a.x-b.x)<(a.width+b.width)/2+gap and math.abs(a.y-b.y)<(a.height+b.height)/2+gap
end
L.clamp=clamp
