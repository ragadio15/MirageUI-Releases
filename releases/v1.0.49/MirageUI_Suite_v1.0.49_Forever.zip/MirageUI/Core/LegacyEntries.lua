local _,M=...
-- Selected Legacy tree reported node metadata only; never applied perks/effects.
-- Bounded mechanics intentionally mirror class entries34, with independent identity/source policy.
local S=M.Safety
local sourcePin=M.Client:NewSourcePinLookup()
local E={epoch=0};M.LegacyEntries=E
local MAX=2147483647
local LIMIT={trees=8,nodesPerTree=1024,memberships=1024,nodes=512,entries=32,rows=128,calls=4096}
local choices={[1187]="PROFESSIONS",[1188]="ADVENTURE",[1189]="PROGRESSION"}
local treeConstants={LEGACY_TREE_PROFESSIONS_ID=1187,LEGACY_TREE_ADVENTURE_ID=1188,LEGACY_TREE_PROGRESSION_ID=1189}
function E:Allowed()
 local combat=S:InCombat();local c,a=M.Client,M.adapter;local pin=sourcePin(c.family,c.build)
 return c and type(c.IsRuntimeClient)=="function" and c:IsRuntimeClient() and M.state.world and not M.state.safe and not M.state.cinematic and not combat or false
end
function E:Invalidate() self.epoch=self.epoch+1 end
local function read(self,treeID,requestValid)
 local client,adapter,profile,references=M.Client,M.adapter,M.profile,M.References
 local traits,spells,enum,constants=C_Traits,C_Spell,Enum,Constants
 local legacy=M.Legacy;local legacyAllowed=legacy and legacy.Allowed;local legacyConstants=legacy and legacy.ConstantsValid
 local legacyEpoch=legacy and legacy.epoch;local ownAllowed=self.Allowed
 local out={state="UNAVAILABLE",rows={},client=client.key,epoch=self.epoch,contextEpoch=M.Policy.contextEpoch,limitReached=false,membershipKnown=false,callCount=0,
  counts={shown=0,inspected=0,zeroRank=0,unknown=0,positiveOmitted=0,tiered=0,nameUnavailable=0,changed=0,treeFailures=0,uniqueNodes=0,memberships=0}}
 local capability,scope=M.Policy.capabilityEpoch,M.Policy.scopeEpoch;local cancelled=false;local capturedConstants,capturedValues
 local function constantsCurrent()
  if not capturedConstants then return true end
  if type(constants)~="table" or getmetatable(constants)~=nil or rawget(constants,"LegacyConsts")~=capturedConstants or getmetatable(capturedConstants)~=nil then return false end
  for key,value in pairs(capturedValues) do if rawget(capturedConstants,key)~=value then return false end end
  return true
 end
 local function baseCurrent() return constantsCurrent() and M.LegacyEntries==self and self.Allowed==ownAllowed and M.Legacy==legacy and legacy and legacy.Allowed==legacyAllowed and legacy.ConstantsValid==legacyConstants and legacy.epoch==legacyEpoch end
 local function live()
  if cancelled or not baseCurrent() then cancelled=true;return false end
  if requestValid then local ok,v=pcall(requestValid);if not ok or not S:Readable(v) or v~=true then cancelled=true;return false end end
  if not baseCurrent() then cancelled=true;return false end
  local allowed=ownAllowed(self)
  if not baseCurrent() or not allowed or self.epoch~=out.epoch or M.Client~=client or M.adapter~=adapter or M.profile~=profile or M.References~=references or M.Client.key~=out.client or M.Policy.contextEpoch~=out.contextEpoch or M.Policy.capabilityEpoch~=capability or M.Policy.scopeEpoch~=scope or C_Traits~=traits or C_Spell~=spells or Enum~=enum or Constants~=constants then cancelled=true end
  return not cancelled
 end
 local seals={}
 -- Post-callback comparisons inspect only previously qualified shapes/fields.
 -- Ordinary comparisons remain inside Read pcall: a restricted replacement that
 -- refuses comparison invalidates the sample; never bypass it via raw equality.
 -- Opaque records are omitted; they cannot supply a stable raw association seal.
 local function seal(record,values,keys)
  if type(record)~="table" or getmetatable(record)~=nil then return false end
  local function current()
   if getmetatable(record)~=nil then return false end
   for _,key in ipairs(keys) do
    local value=rawget(record,key)
    if type(value)=="table" and getmetatable(value)~=nil then return false end
    if value~=values[key] then return false end
   end
   return true
  end
  if not current() then return false end
  seals[#seals+1]=current;return true
 end
 local function invalid() return {state="INVALIDATED",rows={}} end
 local function unavailable(reason) out.state="UNAVAILABLE";out.reason=reason;out.rows={};out.counts.shown=0;out.membershipKnown=false;out.counts.uninspected=nil;return live() and out or invalid() end
 if not baseCurrent() then return invalid() end
 local initiallyAllowed=ownAllowed(self)
 if not baseCurrent() then return invalid() end
 if not initiallyAllowed then out.reason="SOURCE_UNAVAILABLE";return out end
 if not live() then return invalid() end
 local function field(data,key)
  if not live() then return nil,"UNKNOWN" end
  local v,status=S:FieldAccess(data,key)
  if not live() then return nil,"UNKNOWN" end
  return v,status
 end
 local function integer(v)
  local ok=S:Number(v) and v%1==0 and v>=0 and v<=MAX
  return live() and ok
 end
 local function text(v)
  local ok=references and references:Text(v,64,false,false)
  return live() and ok
 end
 local function call(namespace,key,...)
  local fn=field(namespace,key)
  if not live() then return nil,"UNKNOWN" end
  if type(fn)~="function" then return nil,"UNSUPPORTED" end
  if out.callCount>=LIMIT.calls then out.limitReached=true;return nil,"LIMIT" end
  out.callCount=out.callCount+1
  local ok,value=pcall(fn,...)
  if not live() then return nil,"UNKNOWN" end
  if not ok or not S:Readable(value) then return nil,"UNKNOWN" end
  if not live() then return nil,"UNKNOWN" end
  return value,"KNOWN"
 end
 local function ids(data,cap)
  if not live() or not S:Readable(data) or type(data)~="table" then return nil,"UNKNOWN" end
  local ok,meta=pcall(getmetatable,data)
  if not live() or not ok or not S:Readable(meta) or meta~=nil then return nil,"UNKNOWN" end
  local key,count=nil,0
  for i=1,cap+1 do
   if not live() then return nil,"UNKNOWN" end
   local success,k=pcall(next,data,key)
   if not success or not S:Readable(k) or not live() then return nil,"UNKNOWN" end
   if k==nil then break end
   if i>cap then return nil,"LIMIT" end
   if not integer(k) or k<1 or k>cap then return nil,"UNKNOWN" end
   key=k;count=count+1
  end
  local result,seen={},{}
  for i=1,count do
   local value,status=field(data,i)
   if status~="KNOWN" or not integer(value) or seen[value] then return nil,"UNKNOWN" end
   seen[value]=true;result[i]=value
  end
  if not live() then return nil,"UNKNOWN" end
  local ordered={};for i,v in ipairs(result) do ordered[i]=v end
  local function current()
   if getmetatable(data)~=nil then return false end
   for i,v in ipairs(ordered) do if rawget(data,i)~=v then return false end end
   local count=0;for _ in next,data do count=count+1;if count>#ordered then return false end end
   return count==#ordered
  end
  if not current() then return nil,"UNKNOWN" end
  seals[#seals+1]=current
  table.sort(result);return result
 end
 local function sameIDs(a,b)
  if not a or not b or #a~=#b then return false end
  for i,v in ipairs(a) do if b[i]~=v then return false end end
  return true
 end
 local function id(namespace,key,...)
  local v,status=call(namespace,key,...)
  if status~="KNOWN" then return {state=status} end
  if v==nil then return {state="NOT_REPORTED"} end
  return integer(v) and {state="OBSERVED",id=v} or {state="UNKNOWN"}
 end
 if not integer(treeID) or not choices[treeID] then return unavailable("CHOICE_UNAVAILABLE") end
 local legacyConsts=field(constants,"LegacyConsts");local constantValues={};local constantKeys={"LEGACY_TREE_PROFESSIONS_ID","LEGACY_TREE_ADVENTURE_ID","LEGACY_TREE_PROGRESSION_ID"}
 for _,key in ipairs(constantKeys) do local value=field(legacyConsts,key);if not integer(value) or value~=treeConstants[key] then return unavailable("CHOICE_UNAVAILABLE") end;constantValues[key]=value end
 if not seal(constants,{LegacyConsts=legacyConsts},{"LegacyConsts"}) or not seal(legacyConsts,constantValues,constantKeys) then return unavailable("CHOICE_UNAVAILABLE") end
 capturedConstants,capturedValues=legacyConsts,constantValues
 local function identity() return id(traits,"GetConfigIDByTreeID",treeID) end
 local function sameIdentity(a,b) return a.state==b.state and a.id==b.id end
 local first=identity();local chosen=first.state=="OBSERVED" and first.id or nil
 if chosen==nil then return unavailable("CONFIG_UNAVAILABLE") end
 out.config={id=chosen,origin="LEGACY_TREE"};out.tree={id=treeID,key=choices[treeID]}
 local function noStaging()
  local v,status=call(traits,"ConfigHasStagedChanges",chosen)
  return status=="KNOWN" and type(v)=="boolean" and v==false
 end
 if not noStaging() then return unavailable("STAGED_OR_UNKNOWN") end
 local nodeEnums=field(enum,"TraitNodeType");local nodeKeys={"Single","Selection","Tiered","SubTreeSelection"};local nodeValues={};local nodeSeen={}
 for _,key in ipairs(nodeKeys) do local v=field(nodeEnums,key);if not integer(v) or nodeSeen[v] then return unavailable("NODE_TYPES_UNAVAILABLE") end;nodeValues[key]=v;nodeSeen[v]=true end
 local tiered,subtree=nodeValues.Tiered,nodeValues.SubTreeSelection
 local configEnums=field(enum,"TraitConfigType");local configKeys={"Invalid","Combat","Profession","Generic","CamelotCombat"};local configValues={};local configSeen={}
 for _,key in ipairs(configKeys) do local v=field(configEnums,key);if not integer(v) or configSeen[v] then return unavailable("CONFIG_TYPES_UNAVAILABLE") end;configValues[key]=v;configSeen[v]=true end
 if not seal(nodeEnums,nodeValues,nodeKeys) or not seal(enum,{TraitNodeType=nodeEnums,TraitConfigType=configEnums},{"TraitNodeType","TraitConfigType"}) or not seal(configEnums,configValues,configKeys) then return unavailable("NODE_TYPES_UNAVAILABLE") end
 local function configTrees()
  local info=call(traits,"GetConfigInfo",chosen);local returned=field(info,"ID");local kind=field(info,"type")
  if not integer(returned) or returned~=chosen or not integer(kind) or (not configSeen[kind] or kind==configValues.Invalid) then return nil,"UNKNOWN" end
  local raw=field(info,"treeIDs");local list,reason=ids(raw,LIMIT.trees)
  if field(info,"type")~=kind or field(info,"ID")~=chosen then return nil,"UNKNOWN" end
  if not seal(info,{ID=chosen,type=kind,treeIDs=raw},{"ID","type","treeIDs"}) then return nil,"UNKNOWN" end
  local contains=false;for _,v in ipairs(list or {}) do if v==treeID then contains=true end end
  if list and not contains then return nil,"UNKNOWN" end
  return list,reason,kind
 end
 local trees,why,configKind=configTrees()
 if not trees then if why=="LIMIT" then out.limitReached=true end;return unavailable("TREE_MEMBERSHIP_UNAVAILABLE") end
 out.membershipKnown=true
 local memberships,nodes,seen={},{},{}
 for _,tree in ipairs({treeID}) do
  local list,reason=ids(call(traits,"GetTreeNodes",tree),LIMIT.nodesPerTree)
  if list and out.counts.memberships+#list<=LIMIT.memberships then
   memberships[tree]=list;out.counts.memberships=out.counts.memberships+#list
   for _,node in ipairs(list) do if not seen[node] then seen[node]=true;nodes[#nodes+1]=node end end
  else
   out.counts.treeFailures=out.counts.treeFailures+1;out.membershipKnown=false
   if reason=="LIMIT" or list then out.limitReached=true end
  end
 end
 if not live() then return invalid() end
 table.sort(nodes);out.counts.uniqueNodes=#nodes
 local function nodeSnapshot(nodeID)
  local data=call(traits,"GetNodeInfo",chosen,nodeID)
  local returned=field(data,"ID");local rank=field(data,"currentRank");local maximum=field(data,"maxRanks");local kind=field(data,"type")
  if not integer(returned) or returned~=nodeID or not integer(rank) then return nil,"UNKNOWN" end
  if rank==0 then return {id=nodeID,rank=0},"ZERO" end
  if not integer(maximum) or not integer(kind) or not nodeSeen[kind] then return nil,"POSITIVE_UNKNOWN" end
  if kind==tiered then return {id=nodeID,rank=rank},"TIERED" end
  local rawMembers=field(data,"entryIDs");local members,reason=ids(rawMembers,LIMIT.entries)
  if not members then if reason=="LIMIT" then out.limitReached=true end;return nil,"POSITIVE_UNKNOWN" end
  local active=field(data,"activeEntry");local entry=field(active,"entryID");local found=false
  if not integer(entry) then return nil,"POSITIVE_UNKNOWN" end
  for _,v in ipairs(members) do if v==entry then found=true end end
  if not found then return nil,"POSITIVE_UNKNOWN" end
  local sub,access=field(data,"subTreeID")
  if access~="ABSENT" and (access~="KNOWN" or not integer(sub)) then return nil,"POSITIVE_UNKNOWN" end
  -- Retire associations changed by later fields/readability callbacks.
  if field(data,"ID")~=nodeID or field(data,"type")~=kind or field(data,"currentRank")~=rank or field(data,"maxRanks")~=maximum or field(active,"entryID")~=entry then return nil,"CHANGED" end
  if not seal(active,{entryID=entry},{"entryID"}) or not seal(data,{ID=nodeID,type=kind,currentRank=rank,maxRanks=maximum,entryIDs=rawMembers,activeEntry=active,subTreeID=sub},{"ID","type","currentRank","maxRanks","entryIDs","activeEntry","subTreeID"}) then return nil,"CHANGED" end
  return {id=nodeID,rank=rank,maximum=maximum,type=kind,entry=entry,entries=members,subTreeID=sub}
 end
 local function sameNode(a,b)
  return a and b and a.id==b.id and a.rank==b.rank and a.maximum==b.maximum and a.type==b.type and a.entry==b.entry and a.subTreeID==b.subTreeID and sameIDs(a.entries,b.entries)
 end
 local function entrySnapshot(entryID)
  local data=call(traits,"GetEntryInfo",chosen,entryID)
  local definition,ds=field(data,"definitionID");local sub,ss=field(data,"subTreeID");local kind=field(data,"type")
  if ds~="ABSENT" and (ds~="KNOWN" or not integer(definition)) or ss~="ABSENT" and (ss~="KNOWN" or not integer(sub)) or not integer(kind) then return nil end
  local finalDefinition,finalDS=field(data,"definitionID");local finalSub,finalSS=field(data,"subTreeID")
  if finalDefinition~=definition or finalDS~=ds or finalSub~=sub or finalSS~=ss or field(data,"type")~=kind then return nil end
  if not seal(data,{definitionID=definition,subTreeID=sub,type=kind},{"definitionID","subTreeID","type"}) then return nil end
  return {definition=definition,subtree=sub,type=kind}
 end
 local function sameEntry(a,b) return a and b and a.definition==b.definition and a.subtree==b.subtree and a.type==b.type end
 local function nameFor(entry,nodeType)
  if nodeType==subtree then
   if entry.subtree==nil or entry.definition~=nil then return nil end
   local info=call(traits,"GetSubTreeInfo",chosen,entry.subtree);local returned=field(info,"ID");local name=field(info,"name")
   if not integer(returned) or returned~=entry.subtree or not text(name) then return nil end
   if field(info,"ID")~=returned or field(info,"name")~=name then return nil end
   if not seal(info,{ID=returned,name=name},{"ID","name"}) then return nil end
   return name
  end
  if entry.subtree~=nil or entry.definition==nil then return nil end
  local data=call(traits,"GetDefinitionInfo",entry.definition)
  local override,access=field(data,"overrideName");local spell,spellAccess=field(data,"spellID")
  local name
  if access=="KNOWN" and text(override) then name=override
  elseif access=="ABSENT" or access=="KNOWN" and S:Text(override) and override=="" then
   if spellAccess~="KNOWN" or not integer(spell) then return nil end
   local value=call(spells,"GetSpellName",spell);if text(value) then name=value end
  else return nil end
  if not live() or not name then return nil end
  local finalOverride,finalAccess=field(data,"overrideName");local finalSpell,finalSpellAccess=field(data,"spellID")
  if finalOverride~=override or finalAccess~=access or finalSpell~=spell or finalSpellAccess~=spellAccess then return nil end
  if not seal(data,{overrideName=override,spellID=spell},{"overrideName","spellID"}) then return nil end
  return name
 end
 local reserve=7
 for _,nodeID in ipairs(nodes) do
  if out.counts.inspected>=LIMIT.nodes or #out.rows>=LIMIT.rows or out.callCount+12+reserve>LIMIT.calls then out.limitReached=true;break end
  if not live() then return invalid() end
  out.counts.inspected=out.counts.inspected+1;local sealStart=#seals;local rowStart=#out.rows
  local node,reason=nodeSnapshot(nodeID)
  if reason=="ZERO" then out.counts.zeroRank=out.counts.zeroRank+1
  elseif reason=="TIERED" then out.counts.tiered=out.counts.tiered+1;out.counts.positiveOmitted=out.counts.positiveOmitted+1
  elseif not node then
   out.counts.unknown=out.counts.unknown+1
   if reason=="CHANGED" or reason=="POSITIVE_UNKNOWN" then out.counts.positiveOmitted=out.counts.positiveOmitted+1 end
   if reason=="CHANGED" then out.counts.changed=out.counts.changed+1 end
  else
   local entry=entrySnapshot(node.entry);local name=entry and nameFor(entry,node.type)
   if not name then out.counts.nameUnavailable=out.counts.nameUnavailable+1;out.counts.positiveOmitted=out.counts.positiveOmitted+1
   else
    local again=entrySnapshot(node.entry);local finalName=again and nameFor(again,node.type);local finalNode=nodeSnapshot(nodeID)
    if not sameEntry(entry,again) or finalName~=name or not sameNode(node,finalNode) then out.counts.changed=out.counts.changed+1;out.counts.positiveOmitted=out.counts.positiveOmitted+1
    else out.rows[#out.rows+1]={nodeID=nodeID,entryID=node.entry,name=name,rank=node.rank,maximum=node.maximum,kind=node.type==subtree and "SUBTREE_CHOICE" or "ENTRY",subtreeAssociated=node.subTreeID~=nil} end
   end
  end
  if #out.rows==rowStart then for i=#seals,sealStart+1,-1 do seals[i]=nil end end
 end
 if not live() then return invalid() end
 out.counts.uninspected=out.membershipKnown and #nodes-out.counts.inspected or nil
 local finalTrees,_,finalKind=configTrees()
 if not sameIDs(trees,finalTrees) or configKind~=finalKind then return unavailable("MEMBERSHIP_CHANGED") end
 for _,tree in ipairs({treeID}) do
  if memberships[tree] then
   local again=ids(call(traits,"GetTreeNodes",tree),LIMIT.nodesPerTree)
   if not sameIDs(memberships[tree],again) then return unavailable("MEMBERSHIP_CHANGED") end
  end
 end
 if not noStaging() then return unavailable("STAGED_OR_UNKNOWN") end
 if not sameIdentity(first,identity()) then return unavailable("IDENTITY_CHANGED") end
 -- Stable runtime type/constants policy is part of this selected-tree sample.
 for _,key in ipairs(nodeKeys) do if field(nodeEnums,key)~=nodeValues[key] then return unavailable("TYPE_CHANGED") end end
 for _,key in ipairs(configKeys) do if field(configEnums,key)~=configValues[key] then return unavailable("TYPE_CHANGED") end end
 for _,key in ipairs(constantKeys) do if field(legacyConsts,key)~=constantValues[key] then return unavailable("IDENTITY_CHANGED") end end
 if field(enum,"TraitNodeType")~=nodeEnums or field(enum,"TraitConfigType")~=configEnums or field(constants,"LegacyConsts")~=legacyConsts then return unavailable("TYPE_CHANGED") end
 if not live() then return invalid() end
 for _,current in ipairs(seals) do
  if not current() then out.state="UNAVAILABLE";out.reason="OBSERVATION_CHANGED";out.rows={};out.counts.shown=0;out.membershipKnown=false;out.counts.uninspected=nil;return out end
 end
 out.counts.shown=#out.rows
 out.state=(out.limitReached or out.counts.treeFailures>0 or out.counts.unknown>0 or out.counts.positiveOmitted>0) and "PARTIAL_UNAVAILABLE" or "OBSERVED_SCOPED_SNAPSHOT"
 return out
end
function E:Read(treeID,requestValid)
 if self.reading then self:Invalidate();return {state="INVALIDATED",rows={}} end
 self.reading=true;local ok,result=pcall(read,self,treeID,requestValid);self.reading=false
 return ok and result or {state="INVALIDATED",rows={}}
end
