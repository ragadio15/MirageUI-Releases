-- Opt-in measurement. Whole-capture histograms never wrap; exact recent
-- samples are separate. Recording does not constitute native qualification.
local _,M=...
local S=M.Safety
M.Profiler={running=false,capacity=8192,status="NOT_RUN",phaseLimit=160,
 scenarios={OFF=true,QUIET=true,MOVING=true,COMBAT=true,TASKS=true,EDIT=true,MAX=true,ROUTE=true}}
local P=M.Profiler
local names={"MirageUI","MirageUIOptions"}
local logStep=math.log(1.04)
local function clock()
 local value,known=S:Public(debugprofilestop,"number")
 return known=="KNOWN" and value or nil
end
local function histogram() return {n=0,sum=0,max=0,bins={}} end
local function add(h,value)
 if not S:Number(value) or value<0 then return end
 local bin=value==0 and 1 or math.max(2,math.min(512,math.ceil(math.log(math.max(.001,value)/.001)/logStep)+2))
 h.n=h.n+1;h.sum=h.sum+value;h.max=math.max(h.max,value);h.bins[bin]=(h.bins[bin] or 0)+1
end
local function appendHistogram(lines,prefix,h)
 h=h or histogram();lines[#lines+1]=prefix.."samples="..h.n
 if h.n==0 then return end
 lines[#lines+1]=prefix.."mean_ms="..string.format("%.5f",h.sum/h.n)
 lines[#lines+1]=prefix.."max_ms="..string.format("%.5f",h.max)
 for _,q in ipairs({50,95,99}) do
  local threshold,count=math.ceil(h.n*q/100),0
  for bin=1,512 do
   count=count+(h.bins[bin] or 0)
   if count>=threshold then
    local upper=bin==1 and 0 or bin==512 and h.max or .001*1.04^(bin-2)
    local lower=bin<=2 and 0 or .001*1.04^(bin-3)
    lines[#lines+1]=prefix.."p"..q.."_lower_ms="..string.format("%.5f",lower)
    lines[#lines+1]=prefix.."p"..q.."_upper_ms="..string.format("%.5f",math.min(h.max,upper))
    break
   end
  end
 end
end
local function appendStats(lines,prefix,samples,count)
 local sorted={}
 for i=1,count do local v=samples[i];if S:Number(v) and v>=0 then sorted[#sorted+1]=v end end
 table.sort(sorted);local n=#sorted;lines[#lines+1]=prefix.."samples="..n
 if n==0 then return end
 for _,q in ipairs({50,95,99}) do lines[#lines+1]=prefix.."p"..q.."_ms="..string.format("%.5f",sorted[math.ceil(n*q/100)]) end
 lines[#lines+1]=prefix.."max_ms="..string.format("%.5f",sorted[n])
end
local function profileScope()
 if not M.Profiles or type(M.Profiles.Export)~="function" then return nil end
 local ok,value=pcall(M.Profiles.Export,M.Profiles)
 return ok and S:Text(value) and value or nil
end
function P:CaptureContext()
 local c=M.Client or {}
 local context={version=M.version,patch=c.patch,build=c.build,interface=c.interface,
  enabled=M.profile and M.profile.enabled,safe=M.state and M.state.safe,generation=M.state and M.state.settingsGeneration or 0}
 if S:Frame(UIParent,false) then
  context.width=S:Public(UIParent.GetWidth,"number",UIParent)
  context.height=S:Public(UIParent.GetHeight,"number",UIParent)
  context.scale=S:Public(UIParent.GetEffectiveScale,"number",UIParent)
 end
 return context
end
function P:Available()
 local enabled,status=S:Public(C_AddOnProfiler and C_AddOnProfiler.IsEnabled,"boolean")
 return status=="KNOWN" and enabled and C_AddOnProfiler and type(C_AddOnProfiler.GetAddOnMetric)=="function"
  and Enum and Enum.AddOnProfilerMetric and S:Number(Enum.AddOnProfilerMetric.LastTime)
end
function P:Start(scenario)
 scenario=type(scenario)=="string" and scenario:upper() or "ROUTE"
 if not self.scenarios[scenario] then return false,"Choose ROUTE, OFF, QUIET, MOVING, COMBAT, TASKS, EDIT or MAX." end
 if S:InCombat() then return false,"Start the capture outside combat; it can continue during combat." end
 if self.running then return false,"A capture is already running. Stop it before starting another." end
 if not self.frame then self.frame=CreateFrame("Frame");S:Passive(self.frame) end
 self.capture=(self.capture or 0)+1
 self.samples={};self.frameSamples={};self.packages={};self.phases={};self.phaseCount=0
 self.whole=histogram();self.wholeFrame=histogram();self.markers={};self.phaseOverflow=0
 for _,name in ipairs(names) do self.packages[name]={samples={},whole=histogram()} end
 self.index=0;self.count=0;self.total=0;self.skipped=0;self.frameCount=0;self.frameIndex=0;self.observedUpdates=0
 self.started=S:Now();self.elapsed=0;self.scenario=scenario;self.lastCoreFrame=nil;self.repeatedCoreBoundary=0
 self.nextNativeSample=self.started;self.nativeSampleInterval=.05;self.nativeSampleSkippedByCadence=0
 self.startContext=self:CaptureContext();self.stopContext=nil;self.scopeProfile=profileScope();self.scopeState="RECORDING"
 self.combatFrames=0;self.noncombatFrames=0;self.unknownCombatFrames=0
 self.nativeAvailableAtStart=self:Available()==true;self.nativeUnavailable=0
 self.running=true;self.status=self.nativeAvailableAtStart and "RECORDING_NATIVE_AND_LOCAL" or "RECORDING_LOCAL_ONLY"
 -- An opt-in observer, not a second provider scheduler. Repeated equal costs
 -- are real observations, never treated as proof of the same native tick.
 self.frame:SetScript("OnUpdate",function(_,dt) self:Tick(dt) end);self.frame:Show()
 return true,"Capture started without changing your settings. Play normally, then use /mirage capture stop and /mirage capture export. The cap is ten minutes."
end
function P:Mark(label)
 label=type(label)=="string" and label:upper() or ""
 if not self.running or not self.scenarios[label] or #self.markers>=64 then return false end
 self.markers[#self.markers+1]={label=label,seconds=math.max(0,S:Now()-self.started),update=self.observedUpdates}
 return true
end
function P:Tick(dt)
 if not self.running then return end
 self.elapsed=math.max(0,S:Now()-self.started)
 if self.elapsed>=600 then self:Stop();return end
 self.observedUpdates=self.observedUpdates+1
 local coreFrame=M.state and M.state.captureFrame
 if coreFrame~=nil and coreFrame==self.lastCoreFrame then self.repeatedCoreBoundary=self.repeatedCoreBoundary+1 end
 self.lastCoreFrame=coreFrame
 local combat,known=S:Public(InCombatLockdown,"boolean")
 if known~="KNOWN" then self.unknownCombatFrames=self.unknownCombatFrames+1
 elseif combat then self.combatFrames=self.combatFrames+1 else self.noncombatFrames=self.noncombatFrames+1 end
 if S:Number(dt) and dt>=0 then
  self.frameIndex=self.frameIndex%self.capacity+1;self.frameSamples[self.frameIndex]=dt*1000
  self.frameCount=math.min(self.capacity,self.frameCount+1);add(self.wholeFrame,dt*1000)
 end
 local sampleNow=S:Now()
 if sampleNow<(self.nextNativeSample or 0) then self.nativeSampleSkippedByCadence=(self.nativeSampleSkippedByCadence or 0)+1;return end
 self.nextNativeSample=sampleNow+(self.nativeSampleInterval or .05)
 if not self:Available() then self.nativeUnavailable=self.nativeUnavailable+1;return end
 local sum=0;self.pending=self.pending or {}
 for _,name in ipairs(names) do
  self.pending[name]=-1
  if name=="MirageUI" or S:Loaded(name) then
   local value,status=S:Public(C_AddOnProfiler.GetAddOnMetric,"number",name,Enum.AddOnProfilerMetric.LastTime)
   if status~="KNOWN" or value<0 then self.skipped=self.skipped+1;return end
   sum=sum+value;self.pending[name]=value
  end
 end
 self.index=self.index%self.capacity+1;self.samples[self.index]=sum
 self.count=math.min(self.capacity,self.count+1);self.total=self.total+1;add(self.whole,sum)
 for _,name in ipairs(names) do
  local row=self.packages[name];local value=self.pending[name]
  row.samples[self.index]=value;if value>=0 then add(row.whole,value) end
 end
end
function P:Stop()
 if not self.running then return false,"No capture is running." end
 self.elapsed=math.max(0,S:Now()-self.started);self.stopContext=self:CaptureContext()
 local current=profileScope()
 if not self.scopeProfile or not current then self.scopeState="UNAVAILABLE"
 elseif current~=self.scopeProfile then self.scopeState="CHANGED"
 else self.scopeState="UNCHANGED_AT_ENDPOINTS" end
 self.scopeProfile=nil
 self.running=false;self.status=self.total>0 and "RECORDED_NOT_ACCEPTANCE" or "LOCAL_ONLY_NOT_NATIVE_CPU"
 if self.frame then self.frame:SetScript("OnUpdate",nil);self.frame:Hide() end
 return true,"Capture stopped. /mirage capture export copies measurements and the support report."
end
local function phaseLabel(label)
 return type(label)=="string" and #label>0 and #label<=128 and label:match("^[%w_.:%-]+$") and label
end
function P:BeginPhase(label)
 if not self.running or not phaseLabel(label) then return nil end
 local started=clock()
 return started and {label=label,started=started,capture=self.capture} or nil
end
function P:RecordPhase(label,started,ok)
 local stopped=clock()
 if not stopped or not S:Number(started) or stopped<started then return end
 local row=self.phases[label]
 if not row then
  if self.phaseCount>=self.phaseLimit then self.phaseOverflow=self.phaseOverflow+1;return end
  row={whole=histogram(),samples={},index=0,count=0,failed=0};self.phases[label]=row;self.phaseCount=self.phaseCount+1
 end
 local cost=stopped-started;add(row.whole,cost)
 row.index=row.index%256+1;row.samples[row.index]=cost;row.count=math.min(256,row.count+1)
 if ok==false then row.failed=row.failed+1 end
end
function P:EndPhase(token,ok)
 if not self.running or type(token)~="table" or token.capture~=self.capture or not phaseLabel(token.label) then return end
 self:RecordPhase(token.label,token.started,ok)
end
function P:BeginCallback(owner)
 if not self.running or not M.CatalogByID or not M.CatalogByID[owner] then return nil end
 return clock()
end
function P:EndCallback(owner,started,ok)
 if self.running and M.CatalogByID and M.CatalogByID[owner] and S:Number(started) then self:RecordPhase("Module."..owner,started,ok) end
end
function P:Export()
 local lines={"MIRAGEPERF=3","addon="..M.version,"client="..M.Client.key,"state="..self.status,
  "scenario="..(self.scenario or "NONE"),"method=OBSERVED_NATIVE_LAST_TIME_SUM_FOR_LOADED_PACKAGES",
  "native_tick_identity=UNAVAILABLE","sampling_boundary=ONCE_PER_CAPTURE_FRAME_ONUPDATE",
  "equal_cost_samples=RETAINED_NOT_DEDUPLICATED","native_metric_freshness=REQUIRES_CLIENT_VALIDATION",
  "whole_session=ALL_VALID_OBSERVATIONS_WITH_BOUNDED_HISTOGRAMS","quantiles=4_PERCENT_BUCKET_BOUNDS",
  "tail=LATEST_8192_VALID_SAMPLES_EXACT","metric_includes_measurement_overhead=true","native_acceptance=NOT_AUTOMATIC",
  "frame_interval=OBSERVED_UPDATE_DELTA_NOT_ADDON_CAUSAL_FPS","phase_tail=LATEST_256_CALLS",
  "native_metric_sampling=20_HZ_MAX_WHILE_FRAME_PACING_REMAINS_PER_FRAME",
  "phase_cost=INCLUSIVE_SCRIPT_OVERLAP_DO_NOT_SUM","allocations=NOT_MEASURED"}
 local function appendContext(prefix,context)
  for _,key in ipairs({"version","patch","build","interface","width","height","scale","enabled","safe","generation"}) do
   local value=context and context[key]
   local valid=S:Readable(value) and (type(value)=="boolean" or S:Number(value) or S:Text(value) and #value<=96 and not value:find("[\r\n]"))
   lines[#lines+1]=prefix..key.."="..(valid and tostring(value) or "UNAVAILABLE")
  end
 end
 appendContext("start_",self.startContext);appendContext("end_",self.running and self:CaptureContext() or self.stopContext)
 local scoped=self.scopeState or "NOT_RUN"
 if self.running then
  local current=profileScope()
  if not self.scopeProfile or not current then scoped="UNAVAILABLE"
  elseif current~=self.scopeProfile then scoped="CHANGED" else scoped="UNCHANGED_AT_OBSERVATION" end
 end
 lines[#lines+1]="settings_scope="..scoped;lines[#lines+1]="settings_values=NOT_EXPORTED"
 lines[#lines+1]="settings_scope_method=START_END_OR_EXPORT_COMPARISON_NOT_CONTINUOUS"
 lines[#lines+1]="ui_dimensions=UI_PARENT_UNITS_NOT_PHYSICAL_PIXELS"
 for _,entry in ipairs({{"observed_combat_frames",self.combatFrames},{"observed_noncombat_frames",self.noncombatFrames},
  {"unknown_combat_frames",self.unknownCombatFrames},{"capture_updates",self.observedUpdates},
  {"repeated_core_boundaries",self.repeatedCoreBoundary},{"valid_samples_total",self.total},
  {"native_samples_skipped_by_cadence",self.nativeSampleSkippedByCadence},{"unavailable_native_updates",self.nativeUnavailable},{"unreadable_native_samples",self.skipped},{"phase_overflow",self.phaseOverflow}}) do
  lines[#lines+1]=entry[1].."="..(entry[2] or 0)
 end
 lines[#lines+1]="elapsed_seconds="..string.format("%.2f",self.running and math.max(0,S:Now()-self.started) or self.elapsed or 0)
 appendHistogram(lines,"whole_cpu_",self.whole);appendHistogram(lines,"whole_frame_",self.wholeFrame)
 appendStats(lines,"tail_cpu_",self.samples or {},self.count or 0)
 appendStats(lines,"tail_frame_",self.frameSamples or {},self.frameCount or 0)
 for _,name in ipairs(names) do
  local row=self.packages and self.packages[name]
  if row then appendHistogram(lines,"whole_package_"..name.."_",row.whole);appendStats(lines,"tail_package_"..name.."_",row.samples,self.count or 0) end
 end
 local labels={};for label in pairs(self.phases or {}) do labels[#labels+1]=label end;table.sort(labels)
 for _,label in ipairs(labels) do
  local row=self.phases[label];local prefix="phase_"..label.."_"
  lines[#lines+1]=prefix.."failed="..row.failed;appendHistogram(lines,prefix.."whole_",row.whole);appendStats(lines,prefix.."tail_",row.samples,row.count)
 end
 for i,mark in ipairs(self.markers or {}) do lines[#lines+1]="mark_"..i.."="..mark.label..":"..string.format("%.2f",mark.seconds)..":"..mark.update end
 if M.RuntimeScheduler then
  local data=M.RuntimeScheduler:Snapshot();local keys={};for k in pairs(data) do keys[#keys+1]=k end;table.sort(keys)
  for _,key in ipairs(keys) do lines[#lines+1]="scheduler_"..key.."="..tostring(data[key]) end
 end
 return table.concat(lines,"\n")
end
