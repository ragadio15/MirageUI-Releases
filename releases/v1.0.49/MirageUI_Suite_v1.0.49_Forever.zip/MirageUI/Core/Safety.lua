local _, M = ...
M.Safety={}
local S=M.Safety
-- Shared roots can be implicitly protected by an unrelated secure child. They
-- are ancestry boundaries, never cosmetic mutation targets. Pin their identity.
local sharedUIParent,sharedWorldFrame=UIParent,WorldFrame
function S:Readable(value)
    -- Missing or malformed capability checks never authorize value inspection.
    if type(issecretvalue)~="function" or type(canaccessvalue)~="function" then return false end
    local ok,secret=pcall(issecretvalue,value)
    if not ok or type(secret)~="boolean" or secret~=false then return false end
    local accessible,allowed=pcall(canaccessvalue,value)
    return accessible and type(allowed)=="boolean" and allowed==true
end
function S:BoundaryReady()
    -- Trusted literal types probe the contract without inspecting game state.
    -- In particular, numeric denial must be caught before saved-data validation.
    return self:Readable(false) and self:Readable(0) and self:Readable("")
        and self:Readable(nil) and self:Readable({})
end
function S:Number(value)
    return self:Readable(value) and type(value)=="number" and value==value and value~=math.huge and value~=-math.huge
end
function S:Text(value)
    return self:Readable(value) and type(value)=="string"
end
function S:Public(fn, kind, ...)
    if type(fn)~="function" then return nil,"UNSUPPORTED" end
    local ok,value=pcall(fn,...)
    if not ok then return nil,"UNKNOWN" end
    if not self:Readable(value) then return nil,"RESTRICTED" end
    if kind=="number" and not self:Number(value) then return nil,"UNKNOWN" end
    if kind and type(value)~=kind then return nil,"UNKNOWN" end
    if value==nil then return nil,"UNKNOWN" end
    return value,"KNOWN"
end
function S:InCombat()
    local value,status=self:Public(InCombatLockdown,"boolean")
    -- Uncertain legal state is locked, never an implicit authorization.
    return status~="KNOWN" or value==true
end
function S:Now()
    local value=self:Public(GetTime,"number")
    return value or 0
end
function S:Frame(frame, requirePublicTree)
    if not self:Readable(frame) then return false,"RESTRICTED_FRAME" end
    if not frame then return false,"NO_FRAME" end
    if type(frame)~="table" and type(frame)~="userdata" then return false,"INVALID_FRAME_TYPE" end
    if frame.IsForbidden then
        local ok,forbidden=pcall(frame.IsForbidden,frame)
        if not ok or not self:Readable(forbidden) or forbidden then return false,"FORBIDDEN_FRAME" end
    end
    if requirePublicTree then
        local node,visited=frame,{}
        for _=1,32 do
            if not self:Readable(node) then return false,"RESTRICTED_ANCESTOR" end
            if type(node)=="nil" then return true end
            if type(node)~="table" and type(node)~="userdata" then return false,"INVALID_ANCESTOR_TYPE" end
            if node.IsForbidden then
                local ok,forbidden=pcall(node.IsForbidden,node)
                if not ok or not self:Readable(forbidden) or forbidden then return false,"FORBIDDEN_ANCESTOR" end
            end
            if visited[node] then return false,"CYCLIC_PARENT" end
            visited[node]=true
            if node.IsProtected then
                local ok,protected=pcall(node.IsProtected,node)
                if not ok or not self:Readable(protected) or type(protected)~="boolean" then return false,"PROTECTED_FRAME" end
                local sharedAncestor=node~=frame and
                    (rawequal(node,sharedUIParent) or (sharedWorldFrame~=nil and rawequal(node,sharedWorldFrame)))
                if protected and not sharedAncestor then return false,"PROTECTED_FRAME" end
            end
            if not node.GetParent then return false,"UNKNOWN_PARENT" end
            local ok,parent=pcall(node.GetParent,node)
            if not ok or not self:Readable(parent) then return false,"UNKNOWN_PARENT" end
            node=parent
        end
        if node then return false,"PARENT_DEPTH_LIMIT" end
    end
    return true
end
function S:CanEdit(frame)
    if self:InCombat() then return false,"COMBAT_LOCKDOWN" end
    return self:Frame(frame,false)
end
function S:ChildTreePublic(frame,depth,seen,budget)
    depth=depth or 0;seen=seen or {};budget=budget or {count=0}
    if depth>12 or not self:Frame(frame,true) then return false end
    if seen[frame] then return false end
    seen[frame]=true;budget.count=budget.count+1
    if budget.count>512 then return false end
    if not frame.GetChildren then return true end
    local ok,children=pcall(function() return {frame:GetChildren()} end)
    if not ok or #children>128 then return false end
    for _,child in ipairs(children) do
        if not self:ChildTreePublic(child,depth+1,seen,budget) then return false end
    end
    return true
end
function S:Loaded(name)
    local fn=C_AddOns and C_AddOns.IsAddOnLoaded or IsAddOnLoaded
    local value,status=self:Public(fn,"boolean",name)
    return status=="KNOWN" and value or false
end
function S:FocusState(fn)
    if type(fn)~="function" then return nil,"UNSUPPORTED" end
    local ok,value=pcall(fn)
    if not ok then return nil,"UNKNOWN" end
    if not self:Readable(value) then return nil,"RESTRICTED" end
    return value~=nil,"KNOWN"
end
function S:Typing()
    local value,status=self:FocusState(GetCurrentKeyBoardFocus)
    return status~="KNOWN" or value==true
end
function S:Passive(frame)
    frame:EnableMouse(false)
    if frame.EnableKeyboard then frame:EnableKeyboard(false) end
    if frame.EnableMouseWheel then frame:EnableMouseWheel(false) end
end

-- Preserve a verified nil separately for bounded list traversal. Failed reads,
-- malformed containers and restricted values never prove an empty list/tail.
function S:FieldAccess(record,key)
    if not self:Readable(record) then return nil,"RESTRICTED" end
    if type(record)~="table" then return nil,"UNKNOWN" end
    if type(canaccesstable)=="function" then
        local ok,allowed=pcall(canaccesstable,record)
        if not ok or not self:Readable(allowed) or not allowed then return nil,"RESTRICTED" end
    end
    local ok,value=pcall(function() return record[key] end)
    if not ok then return nil,"UNKNOWN" end
    if not self:Readable(value) then return nil,"RESTRICTED" end
    if value==nil then return nil,"ABSENT" end
    return value,"KNOWN"
end
function S:Field(record,key)
    local value,status=self:FieldAccess(record,key)
    -- Existing scalar-field consumers retain their original contract.
    return value,status=="ABSENT" and "UNKNOWN" or status
end

-- Called only for freshly created, addon-owned secure handler widgets. A later
-- BackdropTemplate OnLoad may replace the handler OnLoad in a mixed template.
-- Reinstall the documented helper methods out of combat; never replace scripts,
-- alter protection, or use this as permission to operate on a native frame.
function S:InitializeSecureHandler(frame)
    if self:InCombat() or not self:Frame(frame,false) then return false end
    if type(frame.SetFrameRef)=="function" then return true end
    if type(SecureHandler_OnLoad)~="function" then return false end
    local ok=pcall(SecureHandler_OnLoad,frame)
    return ok and not self:InCombat() and self:Frame(frame,false)
        and type(frame.SetFrameRef)=="function" or false
end
