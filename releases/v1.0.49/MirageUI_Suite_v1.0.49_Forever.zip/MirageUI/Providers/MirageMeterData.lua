local _,M=...
-- P21: one data authority, the client's native meter. There is no combat-log
-- reconstruction, copied native widget text, secret-value ranking or second
-- pet merge. Native session order and owner attribution remain authoritative.
local S=M.Safety
local D={maxSources=80,maxSpells=80,maxSessions=30,epoch=0}
M.MirageMeterData=D
local modeSpecs={
 {"DamageDone","Damage","DPS"},{"Dps","DPS","DPS",true},
 {"HealingDone","Healing + absorbs","HPS"},{"Hps","HPS","HPS",true},
 {"Absorbs","Absorbs","APS"},{"Interrupts","Interrupts"},
 {"Dispels","Dispels"},{"DamageTaken","Damage taken","DTPS"},
 {"AvoidableDamageTaken","Avoidable damage","DTPS"},{"Deaths","Deaths"},
 {"EnemyDamageTaken","Enemy damage taken","DPS"},
}
local function field(t,key,kind)
 local value,state=S:Field(t,key)
 if state~="KNOWN" then return nil end
 if kind=="number" then return S:Number(value) and value or nil end
 if kind and type(value)~=kind then return nil end
 return value
end
local function publicTable(t)
 if not S:Readable(t) or type(t)~="table" then return false end
 if type(canaccesstable)=="function" then
  local ok,value=pcall(canaccesstable,t)
  if not ok or not S:Readable(value) or value~=true then return false end
 end
 return true
end
local function displayField(t,key,kind)
 if not publicTable(t) then return {state="UNAVAILABLE"} end
 local ok,value=pcall(function() return t[key] end)
 if not ok then return {state="UNAVAILABLE"} end
 if S:Readable(value) then
  if kind=="number" and S:Number(value) and value>=0 then return {state="PUBLIC",value=value} end
  if kind=="string" and type(value)=="string" and value~="" then return {state="PUBLIC",value=value} end
  return {state="UNAVAILABLE"}
 end
 -- The schema says this is a display scalar. A secret is forwarded only to
 -- the engine APIs explicitly allowing it. Never branch or calculate on it.
 local checked,secret=pcall(issecretvalue,value)
 if checked and S:Readable(secret) and secret==true then return {state="OPAQUE",value=value} end
 return {state="UNAVAILABLE"}
end
local function validID(value) return S:Number(value) and value>0 and value%1==0 and value<=2147483647 end
function D:Mode(index)
 index=S:Number(index) and math.floor(index) or 0
 local spec=modeSpecs[index+1] or modeSpecs[1]
 local enums=Enum and Enum.DamageMeterType
 local id=field(enums,spec[1],"number")
 if id==nil then return nil end
 return {index=index,id=id,key=spec[1],label=spec[2],rateLabel=spec[3],ratePrimary=spec[4]==true}
end
function D:Modes()
 local out={}
 for i=0,#modeSpecs-1 do local mode=self:Mode(i);if mode then out[#out+1]={value=i,label=mode.label} end end
 return out
end
function D:SessionType(index)
 local name=index==0 and "Overall" or "Current"
 return field(Enum and Enum.DamageMeterSessionType,name,"number"),name
end
function D:Sessions()
 local api=C_DamageMeter
 local sessions,state=S:Public(api and api.GetAvailableCombatSessions,"table")
 local out={};if state~="KNOWN" or not publicTable(sessions) then return out,"UNAVAILABLE" end
 for i=1,self.maxSessions do
  local row,access=S:FieldAccess(sessions,i)
  if access=="ABSENT" then break end
  if access~="KNOWN" or not publicTable(row) then return out,"PARTIAL" end
  local id=field(row,"sessionID","number")
  if validID(id) then
   local name=field(row,"name","string")
   local duration=field(row,"durationSeconds","number")
   out[#out+1]={id=id,name=name and name~="" and name or ("Fight "..id),duration=duration}
  end
 end
 return out,"READY"
end
function D:Invalidate(reason)
 self.epoch=self.epoch+1;self.lastReason=reason or "REFRESH"
end
function D:Availability()
 local api=C_DamageMeter
 if not api or type(api.GetCombatSessionFromType)~="function" then return false,"UNSUPPORTED" end
 local okay,available,why=pcall(api.IsDamageMeterAvailable)
 if not okay or not S:Readable(available) or type(available)~="boolean" then return false,"UNAVAILABLE" end
 if not available then return false,"UNAVAILABLE",S:Text(why) and why or nil end
 return true,"READY"
end
local function spellIdentity(source)
 local id=field(source,"spellID","number")
 if not validID(id) then return nil,"Ability",nil end
 local name,icon
 if C_Spell and type(C_Spell.GetSpellInfo)=="function" then
  local info,state=S:Public(C_Spell.GetSpellInfo,"table",id)
  if state=="KNOWN" then name=field(info,"name","string");icon=field(info,"iconID","number") end
 elseif type(GetSpellInfo)=="function" then
  local ok,n,_,texture=pcall(GetSpellInfo,id)
  if ok then name=S:Text(n) and n or nil;icon=S:Number(texture) and texture or nil end
 end
 return id,name or ("Spell "..id),icon
end
function D:Read(request)
 request=request or {}
 local result={rows={},state="UNAVAILABLE",epoch=self.epoch,request=request,source="NATIVE",partial=false}
 local available,why,detail=self:Availability()
 if not available then result.state=why;result.detail=detail;return result end
 local mode=self:Mode(request.mode)
 if not mode then result.state="UNSUPPORTED_MODE";return result end
 result.mode=mode
 local sessionType,sessionLabel=self:SessionType(request.session)
 if sessionType==nil then result.state="UNSUPPORTED_SESSION";return result end
 result.sessionLabel=sessionLabel;result.sessionType=sessionType;result.sessionID=request.sessionID
 if request.sessionID~=nil then
  if not validID(request.sessionID) then result.state="SESSION_EXPIRED";return result end
  local sessions,sessionState=self:Sessions();local found
  if sessionState=="READY" then
   for _,entry in ipairs(sessions) do if entry.id==request.sessionID then found=entry;break end end
   if not found then result.state="SESSION_EXPIRED";return result end
   result.sessionLabel=found.name;result.duration=found.duration
  end
 end
 local api=C_DamageMeter;local actor=request.actor;local okay,data
 if actor then
  -- Actor IDs are inputs to AllowedWhenUntainted APIs. A restricted identity
  -- cannot be promoted to an identifier by guessing, stringifying or lookup.
  if not S:Text(actor.guid) and not validID(actor.creatureID) then result.state="DETAIL_RESTRICTED";return result end
  if request.sessionID then
   if type(api.GetCombatSessionSourceFromID)~="function" then result.state="UNSUPPORTED_DETAIL";return result end
   okay,data=pcall(api.GetCombatSessionSourceFromID,request.sessionID,mode.id,actor.guid,actor.creatureID)
  else
   if type(api.GetCombatSessionSourceFromType)~="function" then result.state="UNSUPPORTED_DETAIL";return result end
   okay,data=pcall(api.GetCombatSessionSourceFromType,sessionType,mode.id,actor.guid,actor.creatureID)
  end
 else
  if request.sessionID then
   if type(api.GetCombatSessionFromID)~="function" then result.state="UNSUPPORTED_SESSION";return result end
   okay,data=pcall(api.GetCombatSessionFromID,request.sessionID,mode.id)
  else okay,data=pcall(api.GetCombatSessionFromType,sessionType,mode.id) end
 end
 if not okay then result.state="UNAVAILABLE";return result end
 if S:Readable(data) and data==nil then result.state="EMPTY";return result end
 if not publicTable(data) then result.state="RESTRICTED";return result end
 local sources=field(data,actor and "combatSpells" or "combatSources","table")
 if not publicTable(sources) then result.state="RESTRICTED";return result end
 result.total=displayField(data,"totalAmount","number")
 result.maximum=displayField(data,"maxAmount","number")
 result.duration=result.duration or field(data,"durationSeconds","number")
 local limit=actor and self.maxSpells or self.maxSources
 for i=1,limit do
  local source,access=S:FieldAccess(sources,i)
  if access=="ABSENT" then break end
  if access~="KNOWN" or not publicTable(source) then result.partial=true;break end
  local row={rank=i,amount=displayField(source,"totalAmount","number"),rate=displayField(source,"amountPerSecond","number")}
  if actor then
   row.spellID,row.publicName,row.icon=spellIdentity(source)
   row.creatureName=field(source,"creatureName","string")
   if row.creatureName and row.creatureName~="" then row.publicName=row.publicName.." ("..row.creatureName..")" end
   row.name={state="PUBLIC",value=row.publicName};row.class=actor.class
   row.overkill=displayField(source,"overkillAmount","number")
   row.avoidable=field(source,"isAvoidable","boolean");row.deadly=field(source,"isDeadly","boolean")
  else
   row.name=displayField(source,"name","string")
   if row.name.state=="PUBLIC" then row.publicName=row.name.value end
   row.class=field(source,"classFilename","string")
   row.localPlayer=field(source,"isLocalPlayer","boolean")==true
   row.guid=field(source,"sourceGUID","string")
   row.creatureID=field(source,"sourceCreatureID","number")
   if not validID(row.creatureID) then row.creatureID=nil end
   row.recapID=field(source,"deathRecapID","number")
   if not validID(row.recapID) then row.recapID=nil end
   row.deathTime=field(source,"deathTimeSeconds","number")
   row.icon=field(source,"specIconID","number")
  end
  -- Share calculations use public nonnegative native amounts only. Restricted
  -- numbers still render through engine sinks, but never become a percentage.
  if row.amount.state=="PUBLIC" and result.total.state=="PUBLIC" and result.total.value>0 then
   row.percent=100*row.amount.value/result.total.value
  end
  if row.name.state=="UNAVAILABLE" or row.amount.state=="UNAVAILABLE" then result.partial=true end
  result.rows[#result.rows+1]=row
 end
 local more,state=S:FieldAccess(sources,limit+1)
 result.truncated=state=="KNOWN"
 result.state=#result.rows==0 and (result.partial and "RESTRICTED" or "EMPTY") or "READY"
 return result
end
function D:VisibleRows(snapshot,count,offset,pinPlayer)
 local rows=snapshot and snapshot.rows or {};local out={}
 count=math.max(1,math.min(15,math.floor(tonumber(count) or 8)))
 local player,playerIndex
 -- A single visible slot must remain scrollable. Pinning into that slot
 -- would replace every selected entry with the local player indefinitely.
 if pinPlayer and count>1 then
  for i,row in ipairs(rows) do if row.localPlayer then player,playerIndex=row,i;break end end
 end
 local range=math.max(0,#rows-count)
 -- When self is above the last native page, reserve one extra scroll step
 -- for the displaced tail. Keep source order/rank and the original first-page
 -- pinning behavior; do not copy or merge the native data to build a new rank.
 if playerIndex and playerIndex<=range then range=range+1 end
 offset=math.max(0,math.min(range,math.floor(tonumber(offset) or 0)))
 for i=offset+1,math.min(#rows,offset+count) do out[#out+1]=rows[i] end
 if player then
  local contained
  for _,row in ipairs(out) do if row==player then contained=true;break end end
  if not contained and #out>0 then out[math.min(count,#out+1)]=player end
 end
 return out,offset,range
end
function D:FormatPublic(value)
 if not S:Number(value) or value<0 then return "—" end
 if value>=1000000000 then return string.format("%.2fb",value/1000000000) end
 if value>=1000000 then return string.format("%.2fm",value/1000000) end
 if value>=10000 then return string.format("%.1fk",value/1000) end
 if value>=1000 then return string.format("%.2fk",value/1000) end
 return string.format("%.0f",value)
end
function D:SetNumber(font,display)
 if not font or type(font.SetText)~="function" then return false end
 if not display or display.state=="UNAVAILABLE" then pcall(font.SetText,font,"—");return false end
 if display.state=="PUBLIC" then return pcall(font.SetText,font,self:FormatPublic(display.value)) end
 if display.state=="OPAQUE" and type(AbbreviateLargeNumbers)=="function" then
  -- Both AbbreviateLargeNumbers and FontString:SetText allow secret arguments.
  local okay,text=pcall(AbbreviateLargeNumbers,display.value)
  if okay then local shown=pcall(font.SetText,font,text);if shown then return true end end
 end
 pcall(font.SetText,font,"—");return false
end
function D:SetName(font,display)
 if not display or display.state=="UNAVAILABLE" then pcall(font.SetText,font,"Unavailable");return false end
 return pcall(font.SetText,font,display.value)
end
function D:SetBar(bar,amount,maximum)
 if not amount or not maximum or amount.state=="UNAVAILABLE" or maximum.state=="UNAVAILABLE" then
  pcall(bar.SetMinMaxValues,bar,0,1);pcall(bar.SetValue,bar,0);return false
 end
 if maximum.state=="PUBLIC" and maximum.value<=0 then
  pcall(bar.SetMinMaxValues,bar,0,1);pcall(bar.SetValue,bar,0);return true
 end
 -- The engine, rather than addon arithmetic, computes fill for opaque values.
 local range=pcall(bar.SetMinMaxValues,bar,0,maximum.value)
 local value=range and pcall(bar.SetValue,bar,amount.value)
 if not value then pcall(bar.SetMinMaxValues,bar,0,1);pcall(bar.SetValue,bar,0) end
 return value==true
end
function D:Report(snapshot)
 if not snapshot or snapshot.state~="READY" then return nil,"No readable session to copy." end
 local lines={"Meters · "..snapshot.mode.label.." · "..snapshot.sessionLabel}
 local omitted=0
 for _,row in ipairs(snapshot.rows) do
  if row.publicName and row.amount.state=="PUBLIC" then
   local line=row.rank..". "..row.publicName.."  "..self:FormatPublic(row.amount.value)
   if snapshot.mode.rateLabel and row.rate.state=="PUBLIC" then line=line.."  ("..self:FormatPublic(row.rate.value).." "..snapshot.mode.rateLabel..")" end
   if row.percent then line=line..string.format("  %.1f%%",row.percent) end
   lines[#lines+1]=line
  else omitted=omitted+1 end
 end
 if #lines==1 then return nil,"Values can be copied when the game makes them readable." end
 if snapshot.truncated then lines[#lines+1]="Showing the first "..#snapshot.rows.." native entries only." end
 if snapshot.partial then lines[#lines+1]="Some native entries were unavailable." end
 if omitted>0 then lines[#lines+1]="Restricted entries omitted: "..omitted end
 return table.concat(lines,"\n")
end
