local _,M=...
-- Exact-source own config/staging observations, never a complete applied build.
local S=M.Safety
local T={epoch=0};M.Talents=T
local sourcePin=M.Client:NewSourcePinLookup()
local function integer(v,min,max) return S:Number(v) and v%1==0 and v>=min and v<=max end
local function unknown() return {state="UNKNOWN"} end
local function config(state,id) return {state=state or "UNKNOWN",id=id,metadata=unknown(),staged=unknown()} end
function T:Allowed()
 local combat=S:InCombat();local c,a=M.Client,M.adapter;local p=sourcePin(c.family,c.build)
 return c and type(c.IsRuntimeClient)=="function" and c:IsRuntimeClient() and M.state.world and not M.state.safe and not M.state.cinematic and not combat or false
end
function T:Invalidate() self.epoch=self.epoch+1 end
local function read(self,requestValid)
 local client,adapter,profile=M.Client,M.adapter,M.profile
 local out={state="UNAVAILABLE",client=client.key,epoch=self.epoch,contextEpoch=M.Policy.contextEpoch}
 local capability,scope=M.Policy.capabilityEpoch,M.Policy.scopeEpoch
 local class,traits,specialization,enum=C_ClassTalents,C_Traits,C_SpecializationInfo,Enum
 local forever=client.family=="Forever";local cancelled=false
 local function live()
  if cancelled then return false end
  if requestValid then
   local ok,value=pcall(requestValid)
   if not ok or not S:Readable(value) or value~=true then cancelled=true;return false end
  end
  local allowed=self:Allowed()
  if not allowed or M.Client~=client or M.adapter~=adapter or M.profile~=profile or self.epoch~=out.epoch or M.Client.key~=out.client or M.Policy.contextEpoch~=out.contextEpoch or M.Policy.capabilityEpoch~=capability or M.Policy.scopeEpoch~=scope or C_ClassTalents~=class or C_Traits~=traits or Enum~=enum or forever and C_SpecializationInfo~=specialization then cancelled=true end
  return not cancelled
 end
 local function invalid() return {state="INVALIDATED"} end
 if not self:Allowed() then return out end
 if not live() then return invalid() end
 local function field(record,key)
  if not live() then return nil end
  local value=S:Field(record,key)
  if not live() then return nil end
  return value
 end
 local function call(namespace,key,...)
  local fn=field(namespace,key)
  if not live() then return nil,"INVALIDATED" end
  if type(fn)~="function" then return nil,"UNSUPPORTED" end
  local ok,value=pcall(fn,...)
  if not live() then return nil,"INVALIDATED" end
  if not ok or not S:Readable(value) then return nil,"UNKNOWN" end
  if not live() then return nil,"INVALIDATED" end
  return value,"KNOWN"
 end
 local function configID(namespace,key,...)
  local value,status=call(namespace,key,...)
  if status~="KNOWN" then return config(status=="UNSUPPORTED" and "UNSUPPORTED" or "UNKNOWN") end
  if value==nil then return config("NOT_REPORTED") end
  local valid=integer(value,0,2147483647)
  if not live() then return config() end
  return valid and config("OBSERVED",value) or config()
 end
 local function activeGroup()
  local value,status=call(specialization,"GetActiveSpecGroup",false,false)
  if status=="UNSUPPORTED" then return {state="UNSUPPORTED",config=config()} end
  local valid=status=="KNOWN" and integer(value,1,2)
  if not live() then return {state="UNKNOWN",config=config()} end
  if not valid then return {state="UNKNOWN",config=config()} end
  return {state="OBSERVED",index=value,config=configID(specialization,"GetCombatConfigIDForSpecGroup",value)}
 end
 local function same(a,b) return a.state==b.state and a.id==b.id end
 local function staged(id)
  local value,status=call(traits,"ConfigHasStagedChanges",id)
  return status=="KNOWN" and type(value)=="boolean" and {state="OBSERVED",value=value} or unknown()
 end
 local function metadata(id)
  local data,status=call(traits,"GetConfigInfo",id)
  if status~="KNOWN" then return unknown() end
  local returned=field(data,"ID")
  if not integer(returned,0,2147483647) or not live() or returned~=id then return unknown() end
  local kind=field(data,"type");local kinds=field(enum,"TraitConfigType")
  local combat=field(kinds,"Combat");local camelot
  if forever then camelot=field(kinds,"CamelotCombat") end
  local combatOK=integer(combat,0,2147483647);if not live() then return unknown() end
  local camelotOK=forever and integer(camelot,0,2147483647);if not live() then return unknown() end
  if not integer(kind,0,2147483647) or not live() or not (combatOK and kind==combat or camelotOK and kind==camelot) then return unknown() end
  local value=field(data,"name");local name="Config #"..id
  if S:Text(value) and #value>0 and #value<=64 and not value:find("[%c|]") then name=value end
  if not live() then return unknown() end
  -- Readable record/name guards may reenter or expose a changed record. Do not
  -- retain a name whose returned configuration identity/type changed mid-join.
  local finalKind=field(data,"type");local finalID=field(data,"ID")
  if not live() or finalID~=id or finalKind~=kind then return unknown() end
  return {state="OBSERVED",name=name}
 end
 out.common=configID(class,"GetActiveConfigID")
 if forever then out.group=activeGroup() end
 if not live() then return invalid() end
 local conflict=forever and out.common.state=="OBSERVED" and out.group.config.state=="OBSERVED" and out.common.id~=out.group.config.id
 local joined
 if not conflict then
  if out.common.state=="OBSERVED" then joined=out.common
  elseif forever and out.group.config.state=="OBSERVED" then joined=out.group.config end
 end
 if joined then
  local id=joined.id;local first=staged(id);joined.metadata=metadata(id)
  local last=staged(id)
  if first.state=="OBSERVED" and last.state=="OBSERVED" and first.value==last.value then joined.staged=last end
 end
 if not live() then return invalid() end
 local final=configID(class,"GetActiveConfigID")
 if not same(out.common,final) then out.common=config() end
 if forever then
  local group=activeGroup()
  if out.group.state~=group.state or out.group.index~=group.index or not same(out.group.config,group.config) then out.group={state="UNKNOWN",config=config()} end
  out.association="COMMON_NOT_ESTABLISHED"
  if out.common.state=="OBSERVED" and out.group.config.state=="OBSERVED" then
   out.association=out.common.id==out.group.config.id and "MATCH" or "CONFLICT"
   if out.association=="MATCH" then out.group.config.metadata=out.common.metadata;out.group.config.staged=out.common.staged end
  elseif out.group.config.state~="OBSERVED" then out.association="UNKNOWN" end
 end
 if not live() then return invalid() end
 local complete=out.common.state=="NOT_REPORTED" or out.common.state=="OBSERVED" and out.common.metadata.state=="OBSERVED" and out.common.staged.state=="OBSERVED"
 if forever then
  local g=out.group.config
  complete=complete and out.group.state=="OBSERVED" and (g.state=="NOT_REPORTED" or g.state=="OBSERVED" and g.metadata.state=="OBSERVED" and g.staged.state=="OBSERVED") and out.association~="CONFLICT"
 end
 out.state=complete and "OBSERVED_SNAPSHOT" or "PARTIAL_UNAVAILABLE"
 return out
end
function T:Read(requestValid)
 if self.reading then self:Invalidate();return {state="INVALIDATED"} end
 self.reading=true
 local ok,result=pcall(read,self,requestValid)
 self.reading=false
 if not ok then return {state="INVALIDATED"} end
 return result
end
