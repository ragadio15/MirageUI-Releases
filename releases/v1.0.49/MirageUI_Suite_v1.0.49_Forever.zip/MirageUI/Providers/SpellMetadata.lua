local _, M = ...
M.Spells={}
local S=M.Safety
-- User-selected spell metadata, resolved outside combat. This is not a cooldown-state evaluator.
function M.Spells:Resolve(input)
    local result={status="Invalid",reason="Enter a spell name or ID.",ready=false}
    if S:InCombat() then result.status="Unavailable";result.reason="Choose spells after combat.";return result end
    if type(input)~="string" and type(input)~="number" then return result end
    local text=tostring(input):match("^%s*(.-)%s*$")
    if #text==0 or #text>200 then return result end
    local id=text:match("spell:(%d+)") or (text:match("^%d+$") and text) or text
    id=tonumber(id) or id
    local info,status=S:Public(C_Spell and C_Spell.GetSpellInfo,"table",id)
    if status~="KNOWN" then
        if status=="RESTRICTED" or status=="UNSUPPORTED" then result.status="Unavailable";result.reason="Spell information is unavailable." end
        return result
    end
    local spellID=S:Field(info,"spellID");local name=S:Field(info,"name");local icon=S:Field(info,"iconID")
    if not S:Number(spellID) or spellID<1 or spellID%1~=0 or not S:Text(name) or #name>200 then return result end
    result.id=spellID;result.name=name
    result.icon=(S:Number(icon) or S:Text(icon)) and icon or nil
    local known,ks=S:Public(C_SpellBook and C_SpellBook.IsSpellKnown,"boolean",spellID)
    if ks~="KNOWN" then result.status="Unavailable";result.reason="Learned status could not be checked.";return result end
    if not known then result.status="Not Learned";result.reason="This character has not learned this spell.";return result end
    local passive,ps=S:Public(C_Spell and C_Spell.IsSpellPassive,"boolean",spellID)
    if ps~="KNOWN" then result.status="Unavailable";result.reason="Ability type could not be checked.";return result end
    if passive then result.status="Passive";result.reason="Choose an active ability rather than a passive effect.";return result end
    if C_Spell and type(C_Spell.GetOverrideSpell)=="function" then
        local replacement,rs=S:Public(C_Spell.GetOverrideSpell,"number",spellID)
        if rs~="KNOWN" then result.status="Unavailable";result.reason="Spell replacement could not be checked.";return result end
        if replacement~=0 and replacement~=spellID then
            result.status="Replaced";result.reason="Choose the current replacement spell (ID "..replacement..") explicitly.";return result
        end
    end
    result.status="Ready";result.reason="Learned active ability. Ready here is not a castability verdict.";result.ready=true
    return result
end
