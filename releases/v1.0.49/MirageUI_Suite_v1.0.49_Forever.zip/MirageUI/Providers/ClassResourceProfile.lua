local _, M = ...
-- Public class/spec/form metadata selects a display, never a resource threshold.
-- Unknown metadata removes only the optional secondary display. Primary native
-- health/power, rune and summon displays keep their existing ownership.
M.ClassResourceProfile = {}
local P, S = M.ClassResourceProfile, M.Safety
local profiles = {
 ROGUE={power="ComboPoints", label="Combo points"},
 DRUID={power="ComboPoints", label="Combo points", primary="Energy"},
 PALADIN={power="HolyPower", label="Holy Power"},
 MONK={power="Chi", label="Chi", spec="SPEC_MONK_WINDWALKER"},
 WARLOCK={power="SoulShards", label="Soul Shards"},
 MAGE={power="ArcaneCharges", label="Arcane Charges", spec="SPEC_MAGE_ARCANE"},
 EVOKER={power="Essence", label="Essence"},
}
local primaryOnly={WARRIOR=true,HUNTER=true,PRIEST=true,SHAMAN=true,DEATHKNIGHT=true,DEMONHUNTER=true}
local function specialization()
 local fn=C_SpecializationInfo and C_SpecializationInfo.GetSpecialization or GetSpecialization
 if type(fn)~="function" then return nil,"UNSUPPORTED" end
 return S:Public(fn,"number")
end
function P:Resolve()
 if S:InCombat() then return nil,"DEFERRED_LOCKDOWN" end
 local class,status
 if type(UnitClass)=="function" then
  local ok,_,value=pcall(UnitClass,"player")
  if ok and S:Text(value) then class=value;status="KNOWN" else status="UNAVAILABLE_CLASS" end
 end
 if status~="KNOWN" then return nil,status or "UNSUPPORTED_CLASS" end
 local entry=profiles[class]
 if not entry then return nil,primaryOnly[class] and "PRIMARY_OR_DEDICATED_RESOURCE" or "UNSUPPORTED_CLASS" end
 local powerTypes=S:Field(Enum,"PowerType")
 local power=S:Field(powerTypes,entry.power)
 if not S:Number(power) or power<0 or power%1~=0 then return nil,"UNSUPPORTED_POWER_TYPE" end
 if entry.spec then
  local required=_G[entry.spec]
  local spec,why=specialization()
  -- Prefer verified native spec constants. Older candidate clients lacking the
  -- specialization API use an explicit native power-membership query, not a
  -- guessed specialization or a spell/name heuristic.
  if S:Number(required) and why=="KNOWN" then
   if spec~=required then return nil,"OTHER_SPECIALIZATION" end
  elseif why=="UNSUPPORTED" then
   local has,hasStatus=S:Public(UnitHasPowerType,"boolean","player",power)
   if hasStatus~="KNOWN" or not has then return nil,"SPEC_METADATA_UNAVAILABLE" end
  else return nil,"SPEC_METADATA_UNAVAILABLE"
  end
 end
 if entry.primary then
  local expected=S:Field(powerTypes,entry.primary)
  local current,why=S:Public(UnitPowerType,"number","player")
  if not S:Number(expected) or why~="KNOWN" then return nil,"FORM_METADATA_UNAVAILABLE" end
  if current~=expected then return nil,"OTHER_FORM" end
 end
 local maximum,why=S:Public(UnitPowerMax,"number","player",power)
 if why~="KNOWN" or not S:Number(maximum) or maximum<0 then return nil,"CAPACITY_UNAVAILABLE" end
 if maximum==0 then return nil,"NO_SECONDARY_CAPACITY" end
 return {power=power,label=entry.label,maximum=maximum,class=class},"PUBLIC_METADATA_CANDIDATE"
end
function P:Report()
 local value,reason=self:Resolve()
 return "Secondary resource: "..(value and value.label or "native primary / unavailable").." ["..reason.."]"
end
