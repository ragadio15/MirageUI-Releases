local _, M = ...
-- Public, bounded quest-log reads. No coordinates, transactions, tracking changes or persisted quest data.
M.Quests = {maxWatches=64}
local Q, S = M.Quests, M.Safety
local function integer(value,lo,hi)
    return S:Number(value) and value%1==0 and value>=lo and value<=hi
end
function Q:Text(value)
    if not S:Text(value) or value=="" then return nil end
    -- Native text may contain formatting. Treat it as text, never embedded controls or links.
    return value:gsub("|","||"):gsub("[%c]"," "):sub(1,512)
end
local function call(fn,...)
    if type(fn)~="function" then return nil,"UNSUPPORTED" end
    local ok,value=pcall(fn,...)
    if not ok then return nil,"UNAVAILABLE" end
    if not S:Readable(value) then return nil,"RESTRICTED" end
    return value,"READABLE"
end
function Q:Read(limit,objectiveLimit,worldQuests)
    -- Availability describes the bounded readable slice; omitted rows and objective
    -- tails remain explicitly disclosed, not silently claimed complete.
    local snapshot={rows={},status="AVAILABLE",omitted=0,missing=0,total=0}
    if not C_QuestLog or type(C_QuestLog.GetNumQuestWatches)~="function" or type(C_QuestLog.GetQuestIDForQuestWatchIndex)~="function" then
        snapshot.status="UNSUPPORTED";return snapshot
    end
    limit=integer(limit,1,8) and limit or 4
    objectiveLimit=integer(objectiveLimit,1,4) and objectiveLimit or 3
    local seen={}
    local function list(countFn,idFn)
        local count,state=call(countFn)
        if state~="READABLE" or not integer(count,0,1000) then
            snapshot.status=state=="RESTRICTED" and "RESTRICTED" or "PARTIAL";snapshot.missing=snapshot.missing+1;return
        end
        snapshot.total=snapshot.total+count
        local bound=math.min(count,Q.maxWatches)
        for index=1,bound do
            local id=call(idFn,index)
            if integer(id,1,2147483647) and not seen[id] then
                seen[id]=true
                if #snapshot.rows>=limit then snapshot.omitted=snapshot.omitted+1
                else
                    local row={id=id,objectives={},status="UNKNOWN"}
                    row.title=Q:Text(call(C_QuestLog.GetTitleForQuestID,id))
                    if not row.title then snapshot.missing=snapshot.missing+1
                    else
                        local failed,failedState=S:Public(C_QuestLog.IsFailed,"boolean",id)
                        local complete,completeState=S:Public(C_QuestLog.IsComplete,"boolean",id)
                        if failedState=="KNOWN" and completeState=="KNOWN" then
                            row.status=failed and "FAILED" or complete and "COMPLETE" or "ACTIVE"
                        else
                            -- A readable positive flag cannot fill in the other unknown flag.
                            row.partial=true
                        end
                        local items,itemState=call(C_QuestLog.GetQuestObjectives,id)
                        if itemState=="READABLE" and type(items)=="table" then
                            for i=1,objectiveLimit do
                                local item,fieldState=S:FieldAccess(items,i)
                                if fieldState=="ABSENT" then break end
                                if fieldState~="KNOWN" then row.partial=true;break end
                                local text=Q:Text(S:Field(item,"text"))
                                local finished,finishedState=S:Field(item,"finished")
                                if text then
                                    local objective={text=text}
                                    if finishedState=="KNOWN" and type(finished)=="boolean" then
                                        objective.finished=finished
                                    else row.partial=true end
                                    row.objectives[#row.objectives+1]=objective
                                else row.partial=true end
                            end
                            local extra,extraState=S:FieldAccess(items,objectiveLimit+1)
                            if extraState=="KNOWN" then row.moreObjectives=true
                            elseif extraState~="ABSENT" then row.partial=true end
                        else row.partial=true end
                        if row.partial and snapshot.status=="AVAILABLE" then snapshot.status="PARTIAL" end
                        snapshot.rows[#snapshot.rows+1]=row
                    end
                end
            elseif not integer(id,1,2147483647) then snapshot.missing=snapshot.missing+1 end
        end
        snapshot.omitted=snapshot.omitted+math.max(0,count-bound)
    end
    list(C_QuestLog.GetNumQuestWatches,C_QuestLog.GetQuestIDForQuestWatchIndex)
    if worldQuests then list(C_QuestLog.GetNumWorldQuestWatches,C_QuestLog.GetQuestIDForWorldQuestWatchIndex) end
    if snapshot.status=="AVAILABLE" and snapshot.missing>0 then snapshot.status="PARTIAL" end
    return snapshot
end
