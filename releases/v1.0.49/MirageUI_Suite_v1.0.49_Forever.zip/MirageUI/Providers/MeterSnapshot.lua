local _, M = ...
M.MeterData={}
function M.MeterData:Read(cfg)
 local result={rows={},state="UNSUPPORTED"}
 local api=C_DamageMeter
 if not api or type(api.GetCombatSessionFromType)~="function" then return result end
 local available,status=M.Safety:Public(api.IsDamageMeterAvailable,"boolean")
 if status~="KNOWN" or not available then result.state="UNAVAILABLE";return result end
 local meterNames={[0]="DamageDone",[1]="HealingDone"}
 local sessionNames={[0]="Overall",[1]="Current",[2]="Expired"}
 local meter=Enum and Enum.DamageMeterType and Enum.DamageMeterType[meterNames[cfg.meterType]]
 local session=Enum and Enum.DamageMeterSessionType and Enum.DamageMeterSessionType[sessionNames[cfg.sessionType]]
 if not M.Safety:Number(meter) or not M.Safety:Number(session) then return result end
 -- No combat-log reconstruction, source GUID lookup or secret ranking. This view
 -- accepts only public server-provided fields, in the supplied native order.
 local ok,data=pcall(api.GetCombatSessionFromType,session,meter)
 if not ok then result.state="UNAVAILABLE";return result end
 local sources,access=M.Safety:Field(data,"combatSources")
 if access~="KNOWN" or type(sources)~="table" then result.state=access=="RESTRICTED" and "RESTRICTED" or "UNAVAILABLE";return result end
 local maximum=M.Safety:Field(data,"maxAmount")
 if not M.Safety:Number(maximum) or maximum<=0 then maximum=nil end
 local limited=false
 for i=1,cfg.rows do
  local source,state=M.Safety:FieldAccess(sources,i)
  if state=="ABSENT" then break end
  if state~="KNOWN" then limited=true;break end
  local name=M.Safety:Field(source,"name")
  local amount=M.Safety:Field(source,"totalAmount")
  local rate=M.Safety:Field(source,"amountPerSecond")
  local readable=M.Safety:Text(name) and M.Safety:Number(amount) and amount>=0 and M.Safety:Number(rate) and rate>=0 and maximum~=nil
  if readable then result.rows[i]={name=name,amount=amount,rate=rate,maximum=maximum}
  else result.rows[i]={unavailable=true};limited=true end
 end
 result.state=limited and "PARTIAL_UNAVAILABLE" or "PUBLIC_NATIVE_SESSION"
 return result
end
