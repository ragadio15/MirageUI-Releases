local _,M=...
-- Explicit own-equipment observations only. No item use, repair, readiness or history.
local S=M.Safety
local E={epoch=0};M.Equipment=E
local sourcePin=M.Client:NewSourcePinLookup()
local slots={{"HeadSlot","Head"},{"NeckSlot","Neck"},{"ShoulderSlot","Shoulders"},{"BackSlot","Back"},{"ChestSlot","Chest"},{"ShirtSlot","Shirt"},{"TabardSlot","Tabard"},{"WristSlot","Wrists"},{"HandsSlot","Hands"},{"WaistSlot","Waist"},{"LegsSlot","Legs"},{"FeetSlot","Feet"},{"Finger0Slot","Finger 1"},{"Finger1Slot","Finger 2"},{"Trinket0Slot","Trinket 1"},{"Trinket1Slot","Trinket 2"},{"MainHandSlot","Main hand"},{"SecondaryHandSlot","Off hand"},{"RangedSlot","Ranged"},{"AmmoSlot","Ammunition"}}
local function integer(v,minimum) return S:Number(v) and v%1==0 and v>=minimum and v<=2147483647 end
function E:Allowed()
 local combat=S:InCombat();local c,a=M.Client,M.adapter;local p=sourcePin(c.family,c.build)
 return c and type(c.IsRuntimeClient)=="function" and c:IsRuntimeClient() and M.state.world and not M.state.safe and not M.state.cinematic and not combat or false
end
function E:Invalidate() self.epoch=self.epoch+1 end
function E:Current(epoch,client,context)
 return self:Allowed() and self.epoch==epoch and M.Client.key==client and M.Policy.contextEpoch==context
end
local function locationOK(location,slot)
 if type(location)~="table" or S:Field(location,"equipmentSlotIndex")~=slot then return false end
 local _,bag=S:FieldAccess(location,"bagID");local _,index=S:FieldAccess(location,"slotIndex")
 return bag=="ABSENT" and index=="ABSENT"
end
local function durability(slot)
 if type(GetInventoryItemDurability)~="function" then return {state="UNSUPPORTED"} end
 local ok,current,maximum=pcall(GetInventoryItemDurability,slot)
 if not ok or not S:Readable(current) or not S:Readable(maximum) then return {state="UNKNOWN"} end
 if current==nil and maximum==nil then return {state="NOT_REPORTED"} end
 if integer(current,0) and integer(maximum,1) and current<=maximum then return {state="OBSERVED",current=current,maximum=maximum} end
 return {state="UNKNOWN"}
end
local function associatedSpell(id,live)
 local fn=S:Field(C_Item,"GetItemSpell")
 if not live() then return nil end
 if type(fn)~="function" then return {state="UNSUPPORTED"} end
 local ok,name,spellID=pcall(fn,id)
 if not live() then return nil end
 if not ok or not S:Readable(spellID) then return {state="UNKNOWN"} end
 if spellID==nil then
  if S:Readable(name) and name==nil then return {state="NOT_REPORTED"} end
  return {state="UNKNOWN"}
 end
 if not integer(spellID,1) then return {state="UNKNOWN"} end
 local text="Spell #"..spellID
 if S:Text(name) and #name>0 and #name<=64 and not name:find("[%c|]") then text=name end
 return {state="OBSERVED",id=spellID,name=text}
end
local function temporaryEnchant(slot,live)
 local fn=S:Field(C_PaperDollInfo,"GetTemporaryEnchantmentInfo")
 if not live() then return nil end
 if type(fn)~="function" then return {state="UNSUPPORTED"} end
 local ok,data=pcall(fn,slot)
 if not live() then return nil end
 if not ok or not S:Readable(data) then return {state="UNKNOWN"} end
 -- Pinned documentation explicitly specifies no result when no enchant is active.
 if data==nil then return {state="ABSENT"} end
 local id=S:Field(data,"enchantID")
 if integer(id,1) then return {state="OBSERVED",id=id} end
 return {state="UNKNOWN"}
end
function E:ReadDetails(requestValid) return self:Read(true,requestValid) end
function E:Read(details,requestValid)
 local out={state="UNAVAILABLE",rows={},client=M.Client.key,epoch=self.epoch,contextEpoch=M.Policy.contextEpoch}
 if details==true then out.details=true end
 if not self:Allowed() then return out end
 local resolve=S:Field(C_PaperDollInfo,"GetInventorySlotInfo")
 local create=S:Field(ItemLocation,"CreateFromEquipmentSlot")
 local exists=S:Field(C_Item,"DoesItemExist");local itemID=S:Field(C_Item,"GetItemID")
 if type(resolve)~="function" or type(create)~="function" or type(exists)~="function" or type(itemID)~="function" then return out end
 local cancelled=false
 local function live()
  if cancelled then return false end
  if requestValid then local ok,value=pcall(requestValid);if not ok or not S:Readable(value) or value~=true then cancelled=true;return false end end
  if not self:Current(out.epoch,out.client,out.contextEpoch) then cancelled=true;return false end
  return true
 end
 local function stable(location,slot,id)
  if not locationOK(location,slot) or not live() then return false end
  local present,access=S:Public(exists,"boolean",location)
  if not live() or access~="KNOWN" or present~=true or not locationOK(location,slot) or not live() then return false end
  local current=S:Public(itemID,"number",location)
  if not live() or current~=id or not locationOK(location,slot) then return false end
  return live()
 end
 local function invalid() return {state="INVALIDATED",rows={}} end
 local count=M.Client.family=="Forever" and 20 or 18;local resolved,seen={},{}
 for i=1,count do
  if not live() then return invalid() end
  local spec=slots[i];out.rows[i]={slotName=spec[1],label=spec[2],state="UNKNOWN"}
  local slot=S:Public(resolve,"number",spec[1])
  if not live() then return invalid() end
  if integer(slot,0) then
   if seen[slot] then resolved[seen[slot]]=false;resolved[i]=false else seen[slot]=i;resolved[i]=slot end
  end
 end
 local complete=true
 for i=1,count do
  if not live() then return invalid() end
  local row,slot=out.rows[i],resolved[i]
  if slot~=nil and slot~=false then
   local location=S:Public(create,"table",ItemLocation,slot)
   if not live() then return invalid() end
   if locationOK(location,slot) then
    local present,state=S:Public(exists,"boolean",location)
    if not live() then return invalid() end
    if state=="KNOWN" and present==false and locationOK(location,slot) then
     local again,access=S:Public(exists,"boolean",location)
     if not live() then return invalid() end
     if access=="KNOWN" and again==false and locationOK(location,slot) then row.state="EMPTY" end
    elseif state=="KNOWN" and present==true and locationOK(location,slot) then
     local id=S:Public(itemID,"number",location)
     if not live() then return invalid() end
     if integer(id,1) and locationOK(location,slot) then
      local name=S:Public(S:Field(C_Item,"GetItemNameByID"),"string",id)
      if not live() then return invalid() end
      local condition=M.Client.family=="Forever" and durability(slot) or {state="UNSUPPORTED"}
      if not live() then return invalid() end
      local spell,enchant;local unchanged=true
      if details==true then
       unchanged=stable(location,slot,id)
       if not live() then return invalid() end
       if unchanged then spell=associatedSpell(id,live) end
       if not live() then return invalid() end
       if unchanged then unchanged=stable(location,slot,id) end
       if not live() then return invalid() end
       if unchanged then
        local weapon=row.slotName=="MainHandSlot" or row.slotName=="SecondaryHandSlot" or M.Client.family=="Forever" and row.slotName=="RangedSlot"
        enchant=weapon and temporaryEnchant(slot,live) or {state="UNSUPPORTED"}
       end
       if not live() then return invalid() end
      end
      local again,access,current
      if unchanged and locationOK(location,slot) then
       again,access=S:Public(exists,"boolean",location)
       if not live() then return invalid() end
       if access=="KNOWN" and again==true and locationOK(location,slot) then current=S:Public(itemID,"number",location) end
       if not live() then return invalid() end
      end
      if access=="KNOWN" and again==true and current==id and locationOK(location,slot) then
       row.state="OBSERVED";row.id=id;row.name=name and #name<=64 and name or ("Item #"..id);row.durability=condition
       if details==true then row.associatedSpell=spell;row.temporaryEnchant=enchant end
      end
     end
    end
   end
  end
  if row.state=="UNKNOWN" then complete=false end
 end
 if not live() then return invalid() end
 out.state=complete and "OBSERVED_SNAPSHOT" or "PARTIAL_UNAVAILABLE";return out
end
