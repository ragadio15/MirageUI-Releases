local _, M = ...
-- Only public identity/status fields. Health, power and timing never enter this provider.
M.UnitState={}
local U,S=M.UnitState,M.Safety
local roleNames={TANK="Tank",HEALER="Healer",DAMAGER="Damage",NONE=""}
local checkNames={ready="Ready",notready="Not ready",waiting="Waiting"}
function U:Read(unit,readyActive)
    local result={name=nil,role="",state="",ready="",color=nil}
    local exists,access=S:Public(UnitExists,"boolean",unit)
    if access~="KNOWN" then result.availability="UNKNOWN";return result end
    if not exists then result.availability="ABSENT";return result end
    result.availability="PRESENT"
    local name=S:Public(UnitName,"string",unit)
    if name then result.name=name:gsub("|","||"):gsub("[%c]"," ") end
    local connected=S:Public(UnitIsConnected,"boolean",unit)
    local ghost=S:Public(UnitIsGhost,"boolean",unit)
    local dead=S:Public(UnitIsDead,"boolean",unit)
    if connected==false then result.state="Offline"
    elseif ghost==true then result.state="Ghost"
    elseif dead==true then result.state="Dead" end
    local role=S:Public(UnitGroupRolesAssigned,"string",unit)
    result.role=role and roleNames[role] or ""
    if readyActive then
        local ready=S:Public(GetReadyCheckStatus,"string",unit)
        result.ready=ready and checkNames[ready] or ""
    end
    local level=S:Public(UnitLevel,"number",unit)
    if level and level>=1 and level<=1000 and level%1==0 then result.level=level end
    if M.Visual then result.color,result.colorSource=M.Visual:ClassColor(unit) end
    return result
end
