local _,M=...
local S=M.Safety
M.SpellBook={lastState="NOT_RUN"}
local B=M.SpellBook
local function integer(v,lo,hi) return S:Number(v) and v%1==0 and v>=lo and v<=hi end
-- Deliberate settings lookup only. Slot order and native rank/sub-name labels are
-- preserved; rank text is never parsed, compared, or used to silently upgrade IDs.
function B:Read(query)
 local out={rows={},state="UNSUPPORTED",scanned=0,matched=0}
 if S:InCombat() then out.state="COMBAT_LOCKED";self.lastState=out.state;return out end
 if not M.Client.allowed then out.state="CLIENT_NOT_ENABLED";self.lastState=out.state;return out end
 local api=C_SpellBook
 local bank=S:Field(Enum and Enum.SpellBookSpellBank,"Player")
 local spellType=S:Field(Enum and Enum.SpellBookItemType,"Spell")
 if not api or not integer(bank,0,32) or not integer(spellType,0,32) then self.lastState=out.state;return out end
 for _,key in ipairs({"GetNumSpellBookSkillLines","GetSpellBookSkillLineInfo","GetSpellBookItemInfo","IsSpellKnown"}) do
  if type(api[key])~="function" then self.lastState=out.state;return out end
 end
 query=S:Text(query) and query:lower():sub(1,120) or ""
 local lines,state=S:Public(api.GetNumSpellBookSkillLines,"number")
 if state~="KNOWN" or not integer(lines,0,64) then out.state="UNAVAILABLE";self.lastState=out.state;return out end
 local partial,seen,slots=false,{},{}
 for line=1,lines do
  local info=S:Public(api.GetSpellBookSkillLineInfo,"table",line)
  local offset=S:Field(info,"itemIndexOffset");local count=S:Field(info,"numSpellBookItems")
  if not integer(offset,0,16384) or not integer(count,0,2048) then partial=true
  else
   for slot=offset+1,offset+count do
    if out.scanned>=2048 then partial=true;break end
    if not slots[slot] then
     slots[slot]=true;out.scanned=out.scanned+1
     local row=S:Public(api.GetSpellBookItemInfo,"table",slot,bank)
     local kind=S:Field(row,"itemType")
     if not integer(kind,0,32) then partial=true
     elseif kind==spellType then
      local id=S:Field(row,"spellID");local name=S:Field(row,"name")
      local rank,rankState=S:Field(row,"subName");local passive=S:Field(row,"isPassive");local offspec=S:Field(row,"isOffSpec")
      if not integer(id,1,2147483647) or not S:Text(name) or #name>200 or type(passive)~="boolean" or type(offspec)~="boolean" then partial=true
      elseif not passive and not offspec and not seen[id] then
       local known,ks=S:Public(api.IsSpellKnown,"boolean",id,bank)
       if ks~="KNOWN" then partial=true
       elseif known then
        seen[id]=true
        if rankState=="RESTRICTED" then partial=true;rank=nil end
        if not S:Text(rank) or #rank>120 then rank="" end
        if query=="" or name:lower():find(query,1,true) or tostring(id)==query then
         out.matched=out.matched+1
         if #out.rows<48 then
          out.rows[#out.rows+1]={id=id,name=name,subName=rank,slot=slot,bank=bank,
           label=name..(rank~="" and " — "..rank or "").."  #"..id}
         end
        end
       end
      end
     end
    end
   end
  end
  if out.scanned>=2048 then partial=true;break end
 end
 out.state=partial and "PARTIAL_UNAVAILABLE" or out.matched>48 and "REFINE_SEARCH" or "PUBLIC_SPELLBOOK"
 self.lastState=out.state;return out
end
-- A choice is rechecked against its original slot and exact ID at the click.
-- A refreshed spellbook never causes a different rank/replacement to be selected.
function B:StillSame(choice)
 if type(choice)~="table" or S:InCombat() or not M.Client.allowed then return false end
 local bank=S:Field(Enum and Enum.SpellBookSpellBank,"Player")
 local spellType=S:Field(Enum and Enum.SpellBookItemType,"Spell")
 if not integer(choice.slot,1,18432) or not integer(choice.id,1,2147483647) or choice.bank~=bank or not integer(bank,0,32) then return false end
 local api=C_SpellBook
 local row=S:Public(api and api.GetSpellBookItemInfo,"table",choice.slot,choice.bank)
 local kind=S:Field(row,"itemType")
 if not integer(spellType,0,32) or kind~=spellType then return false end
 local id=S:Field(row,"spellID");local offspec=S:Field(row,"isOffSpec");local passive=S:Field(row,"isPassive")
 if id~=choice.id or offspec~=false or passive~=false then return false end
 local known,state=S:Public(api and api.IsSpellKnown,"boolean",choice.id,choice.bank)
 return state=="KNOWN" and known==true
end
