local _,M=...
-- Deliberate own saved-set inspection; no set selection, use, save or history.
local S=M.Safety
local E={epoch=0};M.EquipmentSets=E
local fields={"numItems","numEquipped","numInInventory","numLost","numIgnored"}
local function integer(v,min,max) return S:Number(v) and v%1==0 and v>=min and v<=max end
function E:Allowed() return M.Equipment:Allowed() end
function E:Invalidate() self.epoch=self.epoch+1 end
local function enumeration(data,live)
 if not live() then return nil,true end
 if not S:Readable(data) or type(data)~="table" then return nil end
 if not live() then return nil,true end
 local ok,meta=pcall(getmetatable,data)
 if not ok or not S:Readable(meta) or meta~=nil then return nil end
 local key,count=nil,0
 for i=1,65 do
  if not live() then return nil,true end
  local success,nextKey=pcall(next,data,key)
  if not success or not S:Readable(nextKey) then return nil end
  if nextKey==nil then break end
  if i==65 or not integer(nextKey,1,64) then return nil end
  if not live() then return nil,true end
  key=nextKey;count=count+1
 end
 local ids,seen={},{}
 for i=1,count do
  if not live() then return nil,true end
  local id,access=S:FieldAccess(data,i)
  if access~="KNOWN" or not integer(id,0,2147483647) or seen[id] then return nil end
  if not live() then return nil,true end
  seen[id]=true;ids[i]=id
 end
 table.sort(ids);return ids
end
function E:Read(requestValid)
 local out={state="UNAVAILABLE",rows={},client=M.Client.key,epoch=self.epoch,contextEpoch=M.Policy.contextEpoch}
 local function live()
  if requestValid then local ok,value=pcall(requestValid);if not ok or not S:Readable(value) or value~=true then return false end end
  return self:Allowed() and self.epoch==out.epoch and M.Client.key==out.client and M.Policy.contextEpoch==out.contextEpoch
 end
 local function invalid() return {state="INVALIDATED",rows={}} end
 if not self:Allowed() then return out end
 local list=S:Field(C_EquipmentSet,"GetEquipmentSetIDs");local info=S:Field(C_EquipmentSet,"GetEquipmentSetInfo")
 if not live() then return invalid() end
 if type(list)~="function" then return out end
 local data=S:Public(list,"table")
 if not live() then return invalid() end
 local ids,cancelled=enumeration(data,live)
 if cancelled then return invalid() end
 if not live() then return invalid() end
 if not ids then return out end
 local complete=true
 for _,id in ipairs(ids) do
  if not live() then return invalid() end
  local row={id=id,state="UNKNOWN"};out.rows[#out.rows+1]=row
  local ok,name,icon,returnedID,equipped,a,b,c,d,e=pcall(function() if type(info)=="function" then return info(id) end end)
  if not live() then return invalid() end
  if ok and integer(returnedID,0,2147483647) and returnedID==id then
   if not live() then return invalid() end
   row.state="OBSERVED";row.name="Set #"..id
   if S:Text(name) and #name<=64 and #name>0 and not name:find("[%c|]") then row.name=name end
   if not live() then return invalid() end
   row.equipped={state="UNKNOWN"};row.counts={}
   if S:Readable(equipped) and type(equipped)=="boolean" then row.equipped={state="OBSERVED",value=equipped} else complete=false end
   if not live() then return invalid() end
   local values={a,b,c,d,e}
   for i,field in ipairs(fields) do
    local v=values[i];row.counts[field]={state="UNKNOWN"}
    if integer(v,0,2147483647) then row.counts[field]={state="OBSERVED",value=v} else complete=false end
    if not live() then return invalid() end
   end
  else complete=false end
 end
 if not live() then return invalid() end
 local final=S:Public(list,"table")
 if not live() then return invalid() end
 local again,cancelled=enumeration(final,live)
 if cancelled then return invalid() end
 if not live() then return invalid() end
 if not again or #again~=#ids then return invalid() end
 for i,id in ipairs(ids) do if again[i]~=id then return invalid() end end
 if not live() then return invalid() end
 out.state=#ids==0 and "OBSERVED_EMPTY" or complete and "OBSERVED_SNAPSHOT" or "PARTIAL_UNAVAILABLE"
 return out
end
