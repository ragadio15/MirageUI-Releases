-- Original MirageUI out-of-combat checklist. No result enters combat decision logic.
local _, M = ...
M.PreparationSnapshot = { limit = 128 }
local P, S = M.PreparationSnapshot, M.Safety

function P:Describe(id)
    if not S:Number(id) or id < 1 or id > 2147483647 or id % 1 ~= 0 then return nil end
    local api = C_Spell and C_Spell.GetSpellInfo
    if type(api) ~= "function" then return nil end
    local ok, info = pcall(api, id)
    if not ok then return nil end
    local name, status = S:Field(info, "name")
    local spellID = S:Field(info, "spellID")
    local icon = S:Field(info, "iconID")
    if status ~= "KNOWN" or not S:Text(name) or #name == 0 then return nil end
    -- The checklist records the explicitly requested ID, not an inferred rank or replacement.
    if spellID ~= nil and (not S:Number(spellID) or spellID ~= id) then return nil end
    return { id=id, name=name, icon=S:Number(icon) and icon or nil }
end

function P:Read(ids)
    local snapshot = { state="UNKNOWN", entries={}, reads=0 }
    for i=1, math.min(8, #ids) do snapshot.entries[i]={id=ids[i], state="UNKNOWN"} end
    if S:InCombat() then snapshot.state="COMBAT_PAUSED";return snapshot end
    local api = C_UnitAuras and C_UnitAuras.GetAuraDataByIndex
    if type(api) ~= "function" then snapshot.state="UNSUPPORTED";return snapshot end
    local found, complete = {}, false
    for i=1, self.limit do
        local ok, aura = pcall(api, "player", i, "HELPFUL")
        snapshot.reads=snapshot.reads+1
        if not ok then snapshot.state="READ_FAILED";return snapshot end
        if not S:Readable(aura) then snapshot.state="RESTRICTED";return snapshot end
        if aura == nil then complete=true;break end
        local id, status = S:Field(aura, "spellId")
        if status ~= "KNOWN" or not S:Number(id) or id < 1 or id % 1 ~= 0 then
            snapshot.state="INCOMPLETE";return snapshot
        end
        found[id]=true
    end
    if not complete then snapshot.state="SCAN_LIMIT";return snapshot end
    -- Recheck legality after the scan. Never carry an out-of-combat absence claim into combat.
    if S:InCombat() then snapshot.state="COMBAT_PAUSED";return snapshot end
    snapshot.state="COMPLETE_PUBLIC_SCAN"
    for _, item in ipairs(snapshot.entries) do item.state=found[item.id] and "PRESENT" or "NOT_OBSERVED" end
    return snapshot
end
