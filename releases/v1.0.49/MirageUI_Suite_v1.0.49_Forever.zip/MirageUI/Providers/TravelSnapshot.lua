local _, M = ...
local S=M.Safety
M.TravelSnapshot={}
local T=M.TravelSnapshot
function T:Currency(id)
    if not S:Number(id) or id<1 or id%1~=0 then return nil,"NOT_SELECTED" end
    local api=C_CurrencyInfo and C_CurrencyInfo.GetCurrencyInfo
    if type(api)~="function" then return nil,"UNSUPPORTED" end
    local ok,data=pcall(api,id)
    if not ok then return nil,"UNAVAILABLE" end
    local name,ns=S:Field(data,"name");local quantity,qs=S:Field(data,"quantity")
    if ns~="KNOWN" or qs~="KNOWN" or not S:Text(name) or name=="" or not S:Number(quantity) or quantity<0 then return nil,"UNAVAILABLE" end
    return name..": "..string.format("%.0f",quantity),"PUBLIC_CURRENCY"
end
function T:Coordinates()
    if not C_Map or type(C_Map.GetBestMapForUnit)~="function" or type(C_Map.GetPlayerMapPosition)~="function" then return nil,"UNSUPPORTED" end
    local map,status=S:Public(C_Map.GetBestMapForUnit,"number","player")
    if status~="KNOWN" or map<=0 then return nil,"UNAVAILABLE" end
    local ok,pos=pcall(C_Map.GetPlayerMapPosition,map,"player")
    if not ok or not S:Readable(pos) or pos==nil then return nil,"UNAVAILABLE" end
    local getXY
    local access,fn=pcall(function() return pos.GetXY end)
    if access and type(fn)=="function" then getXY=fn end
    if not getXY then return nil,"UNAVAILABLE" end
    local read,x,y=pcall(getXY,pos)
    if not read or not S:Number(x) or not S:Number(y) or x<0 or x>1 or y<0 or y>1 then return nil,"UNAVAILABLE" end
    return string.format("Map %.1f, %.1f",100*x,100*y),"PUBLIC_MAP_COORDINATES"
end
function T:Travel()
    local taxi,known=S:Public(UnitOnTaxi,"boolean","player")
    if known=="KNOWN" and taxi then return "Taxi flight","PUBLIC_TRAVEL_STATE" end
    local moving=M.Store:Value("PLAYER_MOVING")
    local swimming=M.Store:Value("PLAYER_SWIMMING")
    local mounted=M.Store:Value("PLAYER_MOUNTED")
    if swimming==true then return "Swimming","PUBLIC_TRAVEL_STATE" end
    if mounted==true then return moving==true and "Traveling mounted" or "Mounted","PUBLIC_TRAVEL_STATE" end
    if moving==true then return "Moving","PUBLIC_TRAVEL_STATE" elseif moving==false then return "Stationary","PUBLIC_TRAVEL_STATE" end
    return nil,"UNAVAILABLE"
end
