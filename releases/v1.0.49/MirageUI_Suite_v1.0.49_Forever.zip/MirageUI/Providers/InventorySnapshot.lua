local _, M = ...
M.Inventory={bankEpoch=0}
local I,S=M.Inventory,M.Safety
local sources={carried=true,character=true,account=true}

-- Bank snapshots are request-only and tied to the current native bank session.
-- No inventory history, transactions, remote opening, or saved item data.
function I:BankEvent(event)
 if event=="BANKFRAME_OPENED" then
  self.bankEpoch=self.bankEpoch+1;self.bankOpen=true
 elseif event=="BANKFRAME_CLOSED" then
  self.bankEpoch=self.bankEpoch+1;self.bankOpen=false
 elseif event=="PLAYER_LEAVING_WORLD" or event=="PLAYER_ENTERING_WORLD" then
  self.bankEpoch=self.bankEpoch+1;self.bankOpen=nil
 end
end
function I:Access(source)
 source=source or "carried"
 if not sources[source] then return false,"INVALID_SOURCE" end
 if source=="carried" then return true,"CARRIED" end
 if S:InCombat() then return false,"BANK_UNAVAILABLE_IN_COMBAT" end
 if self.bankOpen==false then return false,"BANK_CLOSED" end
 if not S:Frame(BankFrame,false) then return false,"BANK_UNAVAILABLE" end
 local shown,shownState=S:Public(BankFrame.IsShown,"boolean",BankFrame)
 if shownState~="KNOWN" then return false,"BANK_UNAVAILABLE" end
 if not shown then return false,"BANK_CLOSED" end
 local bankType=S:Field(Enum and Enum.BankType,source=="character" and "Character" or "Account")
 if not S:Number(bankType) then return false,"BANK_UNSUPPORTED" end
 local allowed,state=S:Public(C_Bank and C_Bank.CanViewBank,"boolean",bankType)
 if state~="KNOWN" then return false,"BANK_UNAVAILABLE" end
 if not allowed then return false,"BANK_NOT_ACCESSIBLE" end
 return true,"BANK_OPEN",bankType
end
function I:Containers(source)
 source=source or "carried"
 local allowed,reason,bankType=self:Access(source)
 if not allowed then return nil,reason end
 if source=="carried" then return {0,1,2,3,4,5},"CARRIED" end
 local ids,state=S:Public(C_Bank and C_Bank.FetchPurchasedBankTabIDs,"table",bankType)
 if state~="KNOWN" then return nil,"BANK_TABS_UNAVAILABLE" end
 local result,seen={},{}
 -- Use actual ContainerIDs; neither tab counts nor a guessed legacy layout is a bag ID.
 for index=1,33 do
  local id,fieldState=S:FieldAccess(ids,index)
  if fieldState=="ABSENT" then return result,"BANK_OPEN" end
  if fieldState~="KNOWN" then
   if #result>0 then return result,"BANK_TABS_PARTIAL" end
   return nil,"BANK_TABS_UNAVAILABLE"
  end
  if index==33 then return nil,"BANK_TAB_LIMIT" end
  if not S:Number(id) or id%1~=0 or id<6 or id>1024 or seen[id] then return nil,"BANK_TABS_INVALID" end
  result[#result+1]=id;seen[id]=true
 end
 return result,"BANK_OPEN"
end
function I:Read(query,order,source)
 source=source or "carried"
 local result={items={},state="UNSUPPORTED",scanned=0,source=source,epoch=self.bankEpoch}
 local space=source=="carried" and {state="UNAVAILABLE",observedCapacity=0,observedEmpty=0,observedOccupied=0,containersObserved=0,containersExpected=6} or nil
 result.space=space
 local containers,reason=self:Containers(source)
 if not containers then result.state=reason;return result end
 local api=C_Container
 if not api or type(api.GetContainerNumSlots)~="function" or type(api.GetContainerItemInfo)~="function" then return result end
 query=S:Text(query) and query:lower():sub(1,80) or ""
 local limited=reason=="BANK_TABS_PARTIAL";local cap=source=="carried" and 512 or 1024
 for containerIndex,bag in ipairs(containers) do
  local n,state=S:Public(api.GetContainerNumSlots,"number",bag)
  if state~="KNOWN" or n<0 or n%1~=0 or n>128 then limited=true
  else
   if space then space.observedCapacity=space.observedCapacity+n;space.containersObserved=space.containersObserved+1 end
   for slot=1,n do
    if result.scanned>=cap then limited=true;break end
    result.scanned=result.scanned+1
    local ok,data=pcall(api.GetContainerItemInfo,bag,slot)
    if not ok or not S:Readable(data) then limited=true
    elseif data~=nil then
     local id=S:Field(data,"itemID");local icon=S:Field(data,"iconFileID");local count=S:Field(data,"stackCount")
     if S:Number(id) and id>0 and id%1==0 and (S:Number(icon) or S:Text(icon)) then
      if space then space.observedOccupied=space.observedOccupied+1 end
      local name=S:Public(C_Item and C_Item.GetItemNameByID,"string",id)
      if not name and C_Item and type(C_Item.GetItemInfo)=="function" then name=S:Public(C_Item.GetItemInfo,"string",id) end
      local label=name or ("Item #"..id)
      if query=="" or label:lower():find(query,1,true) or tostring(id)==query then
       result.items[#result.items+1]={bag=bag,slot=slot,id=id,icon=icon,name=label,
        count=S:Number(count) and count>=0 and count or nil,source=source,epoch=result.epoch}
      end
     else limited=true end
    elseif space then space.observedEmpty=space.observedEmpty+1 end
   end
  end
  if result.scanned>=cap then
   if containerIndex<#containers then limited=true end
   break
  end
 end
 if space then
  space.unclassifiedSlots=space.observedCapacity-space.observedEmpty-space.observedOccupied
  if space.containersObserved==space.containersExpected then space.total=space.observedCapacity end
  if space.total~=nil and space.unclassifiedSlots==0 then
   space.empty=space.observedEmpty;space.occupied=space.observedOccupied;space.state="COMPLETE"
  else space.state="PARTIAL" end
  -- World/session transitions during a reentrant read invalidate this snapshot.
  -- Bank open/close can conservatively invalidate carried space too; it never
  -- supplies an alternative capacity or converts uncertainty into zero.
  if result.epoch~=self.bankEpoch then
   result.space={state="INVALIDATED",observedCapacity=0,observedEmpty=0,observedOccupied=0,containersObserved=0,containersExpected=6}
  end
 end
 -- Recheck permission/session before publishing a bank result. A closed bank is not an empty bank.
 if source~="carried" then
  local accessible,why=self:Access(source)
  if not accessible or result.epoch~=self.bankEpoch then
   result.items={};result.state=not accessible and why or "BANK_SESSION_CHANGED";return result
  end
 end
 if order=="name" then
  table.sort(result.items,function(a,b)
   if a.name~=b.name then return a.name<b.name end
   if a.bag~=b.bag then return a.bag<b.bag end
   return a.slot<b.slot
  end)
 end
 result.state=limited and "PARTIAL_UNAVAILABLE" or "PUBLIC_INVENTORY"
 return result
end
function I:SameSlot(item)
 if not item or not C_Container then return false end
 local source=item.source or "carried"
 local epoch=item.epoch
 if source~="carried" and (epoch~=self.bankEpoch or not self:Access(source) or epoch~=self.bankEpoch) then return false end
 local id,state=S:Public(C_Container.GetContainerItemID,"number",item.bag,item.slot)
 if state~="KNOWN" or id~=item.id then return false end
 -- API and permission callbacks can revoke/reopen the bank during observation.
 -- Keep the captured epoch through the final permission probe; a matching ID
 -- alone cannot renew an old row into a successor bank session. This remains
 -- a bounded observation, not atomic ownership of the native slot.
 if source~="carried" and (epoch~=self.bankEpoch or not self:Access(source) or epoch~=self.bankEpoch) then return false end
 return true
end
