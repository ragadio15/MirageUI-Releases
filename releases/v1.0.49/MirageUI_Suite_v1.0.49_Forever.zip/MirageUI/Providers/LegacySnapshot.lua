local _,M=...
-- Exact-source own Legacy observations. Never allocations, readiness or history.
local S=M.Safety
local sourcePin=M.Client:NewSourcePinLookup()
local L={epoch=0};M.Legacy=L
local MAX=9007199254740991
local specs={{1187,"Professions"},{1188,"Adventure"},{1189,"Progression"}}
local constants={LEGACY_REWARD_TRACK_FACTION_ID=2802,LEGACY_POINTS_TRAIT_CURRENCY_ID=4225,LEGACY_TREE_PROFESSIONS_ID=1187,LEGACY_TREE_ADVENTURE_ID=1188,LEGACY_TREE_PROGRESSION_ID=1189}
local function integer(v,min,max) return S:Number(v) and v%1==0 and v>=min and v<=max end
local function unknown() return {state="UNKNOWN"} end
function L:ConstantsValid()
 local c=S:Field(Constants,"LegacyConsts")
 for key,value in pairs(constants) do if S:Field(c,key)~=value then return false end end
 return true
end
function L:Allowed()
 local constantsOK=self:ConstantsValid();local combat=S:InCombat()
 -- Guarded probes may reenter; compare current identities only afterwards.
 local c,a=M.Client,M.adapter;local pin=sourcePin(c.family,c.build)
 return c and type(c.IsRuntimeClient)=="function" and c:IsRuntimeClient() and M.state.world and not M.state.safe and not M.state.cinematic and not combat and constantsOK or false
end
function L:Invalidate() self.epoch=self.epoch+1 end
local function fieldNumber(row,key,optional)
 local v,access=S:FieldAccess(row,key)
 if optional and access=="ABSENT" then return {state="NOT_REPORTED"} end
 if access=="KNOWN" and integer(v,0,MAX) then return {state="OBSERVED",value=v} end
 return unknown()
end
local function renown(data)
 if S:Field(data,"factionID")~=2802 then return unknown() end
 local unlocked=S:Field(data,"isUnlocked")
 if unlocked==false then return {state="LOCKED"} end
 local level=S:Field(data,"renownLevel")
 if unlocked==true and integer(level,0,2147483647) then return {state="OBSERVED",level=level} end
 return unknown()
end
local function currency(data)
 if not S:Readable(data) or type(data)~="table" then return nil end
 -- Only plain, bounded sequences are accepted. A fixed index window alone
 -- cannot rule out a second target at an unseen sparse or named key.
 local ok,meta=pcall(getmetatable,data)
 if not ok or not S:Readable(meta) or meta~=nil then return nil end
 local key
 for count=1,65 do
  local success,nextKey=pcall(next,data,key)
  if not success or not S:Readable(nextKey) then return nil end
  if nextKey==nil then break end
  if count==65 or not integer(nextKey,1,64) then return nil end
  key=nextKey
 end
 local matched,ended
 -- Scan the entire bounded intake, detecting holes and target duplication.
 -- This is an intake limit, not an assertion about native maximum length.
 for i=1,65 do
  local row,access=S:FieldAccess(data,i)
  if access=="ABSENT" then ended=true
  elseif access~="KNOWN" or ended or i==65 then return nil
  else
   local id=S:Field(row,"traitCurrencyID")
   if not integer(id,1,2147483647) then return nil end
   if id==4225 then if matched then return nil end;matched=row end
  end
 end
 if not matched then return nil end
 return {quantity=fieldNumber(matched,"quantity"),spent=fieldNumber(matched,"spent"),spentInTree=fieldNumber(matched,"spentInTree",true)}
end
function L:Read(requestValid)
 local out={state="UNAVAILABLE",client=M.Client.key,epoch=self.epoch,contextEpoch=M.Policy.contextEpoch}
 local function live()
  if requestValid then local ok,value=pcall(requestValid);if not ok or not S:Readable(value) or value~=true then return false end end
  if not self:Allowed() then return false end
  return self.epoch==out.epoch and M.Client.key==out.client and M.Policy.contextEpoch==out.contextEpoch
 end
 local function invalid() return {state="INVALIDATED"} end
 if not self:Allowed() then return out end
 local faction=S:Field(C_MajorFactions,"GetMajorFactionData")
 local config=S:Field(C_Traits,"GetConfigIDByTreeID")
 local read=S:Field(C_Traits,"GetTreeCurrencyInfo")
 -- Missing one API does not erase independently available observations.
 if not live() then return invalid() end
 local first=S:Public(faction,"table",2802)
 if not live() then return invalid() end
 out.renown=renown(first);out.sharedPoints={quantity=unknown(),spent=unknown()};out.trees={}
 local configs,points={},{}
 for i,spec in ipairs(specs) do
  if not live() then return invalid() end
  out.trees[i]={treeID=spec[1],label=spec[2],spentInTree=unknown()}
  local id=S:Public(config,"number",spec[1])
  if not live() then return invalid() end
  if integer(id,0,2147483647) then
   configs[i]=id
   local data=S:Public(read,"table",id,spec[1],true)
   if not live() then return invalid() end
   points[i]=currency(data)
   if not live() then return invalid() end
  end
 end
 local last=S:Public(faction,"table",2802)
 if not live() then return invalid() end
 local again=renown(last)
 if again.state~=out.renown.state or again.level~=out.renown.level then out.renown=unknown() end
 for i,spec in ipairs(specs) do
  if not live() then return invalid() end
  if configs[i] then
   local id=S:Public(config,"number",spec[1])
   if not live() then return invalid() end
   if id~=configs[i] then points[i]=nil end
  end
  if points[i] then out.trees[i].spentInTree=points[i].spentInTree end
 end
 for _,field in ipairs({"quantity","spent"}) do
  local value;local same=true
  for i=1,3 do
   local v=points[i] and points[i][field]
   if not v or v.state~="OBSERVED" then same=false;break end
   if value~=nil and v.value~=value then same=false;break end;value=v.value
  end
  if same then out.sharedPoints[field]={state="OBSERVED",value=value} end
 end
 local complete=out.renown.state~="UNKNOWN" and out.sharedPoints.quantity.state=="OBSERVED" and out.sharedPoints.spent.state=="OBSERVED"
 for _,row in ipairs(out.trees) do if row.spentInTree.state~="OBSERVED" then complete=false end end
 if not live() then return invalid() end
 out.state=complete and "OBSERVED_SNAPSHOT" or "PARTIAL_UNAVAILABLE"
 return out
end
