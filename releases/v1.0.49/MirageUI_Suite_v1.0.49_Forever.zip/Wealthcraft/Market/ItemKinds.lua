-- Commodity identity is item-ID based ONLY after client evidence identifies it.
-- Equipment suffixes, pet species and unknown item levels are never generalized.
local _,W=...
W.ItemKinds={known={}}
local K=W.ItemKinds
function K:Market(key) return key or W.Scope:ReadMarketKey() end
function K:IsCommodity(id,market)
    market=self:Market(market)
    return market and self.known[market] and self.known[market][id]==true or false
end
function K:Key(key,market)
    if type(key)~='table' then return key end
    if (key.itemSuffix or 0)==0 and (key.battlePetSpeciesID or 0)==0 and self:IsCommodity(key.itemID,market) then
        return {itemID=key.itemID,itemLevel=0,itemSuffix=0,battlePetSpeciesID=0}
    end
    return key
end
function K:Learn(id,market)
    market=self:Market(market)
    if not market or not W.Math.ValidInteger(id,1,999999999) then return end
    self.known[market]=self.known[market] or {}
    if self.known[market][id] then return end
    self.known[market][id]=true
    self:RepairWatch(id)
end
function K:RepairWatch(id)
    if not W.Storage:IsWritable() then return end
    local db=W.Storage.account;local items=db.watchlist.items
    local canonical=tostring(id)..':0:0:0';local keep=items[canonical];local changes={}
    for key,item in pairs(items) do
        if item.itemID==id and (item.itemSuffix or 0)==0 and (item.battlePetSpeciesID or 0)==0 then
            if not keep or item.addedAt<keep.addedAt then
                keep={itemID=id,itemLevel=0,itemSuffix=0,battlePetSpeciesID=0,addedAt=item.addedAt}
            end
            if key~=canonical then changes[#changes+1]=key end
        end
    end
    if #changes==0 then return end
    -- Preserve the original removed entries once for non-destructive rollback/audit.
    if db.g8WatchBackup==nil then db.g8WatchBackup={} end
    if type(db.g8WatchBackup)~='table' then return end
    local count=0;for _ in pairs(db.g8WatchBackup) do count=count+1 end
    for _,key in ipairs(changes) do
        if count<80 or db.g8WatchBackup[key] then
            if not db.g8WatchBackup[key] then db.g8WatchBackup[key]=items[key];count=count+1 end
            items[key]=nil
            W.Storage:UpdateWatchListKey(key,canonical)
        end
    end
    if keep then items[canonical]=keep end
end
function K:Initialize()
    self.known={}
    local db=W.Storage.account
    if not db then return end
    for market,data in pairs(db.targeted.markets or {}) do
        for _,rec in pairs(data.records or {}) do
            if rec.kind=='COMMODITY' then self:Learn(rec.itemID,market) end
        end
    end
end
local oldAdd=W.Storage.AddWatch
function W.Storage:AddWatch(key) return oldAdd(self,K:Key(key)) end
local oldCommit=W.Storage.CommitTarget
function W.Storage:CommitTarget(scope,record)
    local ok,why=oldCommit(self,scope,record)
    if ok and record.kind=='COMMODITY' then K:Learn(record.itemID,scope.key) end
    return ok,why
end
local partialToken,partialIndex
local function partialCommodity(id,market)
    local m=W.Storage:GetMarket(market);local snap=m and m.partial
    if not snap then return nil end
    local token=market..'/'..tostring(snap.id)
    if partialToken~=token then
        local index={}
        for identity,item in pairs(snap.items or {})do
            if index[item.itemID]==nil then index[item.itemID]=identity else index[item.itemID]=false end
        end
        partialToken,partialIndex=token,index
    end
    local identity=partialIndex[id]
    if type(identity)=='string' then return W.Quotes:Exact(identity,market),identity end
end
local oldWatch=W.Quotes.ForWatch
function W.Quotes:ForWatch(watch,market)
    watch=K:Key(watch,market)
    if type(watch)=='table' and K:IsCommodity(watch.itemID,market) and
        (watch.itemSuffix or 0)==0 and (watch.battlePetSpeciesID or 0)==0 then
        local q=W.Targeted:QuoteExact('commodity:'..watch.itemID,market or W.Scope:ReadMarketKey())
        if q then return q,nil,'commodity:'..watch.itemID end
        local observed,identity=partialCommodity(watch.itemID,market or W.Scope:ReadMarketKey())
        if observed then return observed,nil,identity end
    end
    return oldWatch(self,watch,market)
end
-- Obtain classification from Blizzard's item-key metadata when exposed, never names.
function K:ObserveKey(key)
    if type(key)~='table' then return key end
    local ok,info=W.SafeCall(W.Compat.auction and W.Compat.auction.GetItemKeyInfo,key)
    if ok and type(info)=='table' and info.isCommodity==true then self:Learn(key.itemID) end
    return self:Key(key)
end
