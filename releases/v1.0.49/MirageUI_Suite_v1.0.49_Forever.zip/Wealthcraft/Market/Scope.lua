-- P29: an observed Auction House interaction permits live reads even when
-- optional realm/map APIs have no value (Forever can use regional rulesets).
-- Freeze one honest namespace per visit; never invent realm IDs or pool
-- unidentified auctioneers. WC2/WC3 history remains in its original namespace.
local _,W=...
W.Scope={}
local S=W.Scope
local function readable(v)
    if type(issecretvalue)=='function' then local ok,x=pcall(issecretvalue,v);if not ok or x~=false then return false end end
    if type(canaccessvalue)=='function' then local ok,x=pcall(canaccessvalue,v);if not ok or x~=true then return false end end
    return true
end
local function read(fn,...)
    local ok,v=W.SafeCall(fn,...)
    if not ok then return nil,type(fn)=='function' and 'API_ERROR' or 'API_MISSING' end
    if not readable(v) then return nil,'UNREADABLE' end
    if v==nil then return nil,'NIL' end
    return v,'OBSERVED'
end
local function field(t,k)
    if not readable(t) or type(t)~='table' then return nil end
    if type(canaccesstable)=='function' then local ok,x=pcall(canaccesstable,t);if not ok or x~=true then return nil end end
    local ok,v=pcall(function()return t[k]end);if ok and readable(v) then return v end
end
local function integer(v,lo,hi)
    if not readable(v) or (type(v)~='number' and type(v)~='string') then return nil end
    local n=tonumber(v);return W.Math.ValidInteger(n,lo or 1,hi or 999999999) and n or nil
end
local function text(v,max)
    if not readable(v) or type(v)~='string' or #v>(max or 100) or v:find('[%c|]') then return nil end
    v=v:match('^%s*(.-)%s*$');return v~='' and v or nil
end
local function decimal(v)return string.format('%.0f',v)end
local function copy(t)
    local out={};for k,v in pairs(t)do
        if type(v)=='table' then local child={};for a,b in pairs(v)do child[a]=b end;out[k]=child else out[k]=v end
    end;return out
end
local function numberObservation(state,name,fn,lo,hi,...)
    local v,why=read(fn,...);local n=integer(v,lo,hi)
    state[name]=n and ('OBSERVED:'..decimal(n)) or
        (why=='OBSERVED' and (type(v)=='number' and 'INVALID:'..tostring(v) or 'INVALID_VALUE') or why)
    return n
end
local function observations()
    local o={metadataState={},missingFields={}};local states=o.metadataState
    o.region=numberObservation(states,'region',GetCurrentRegion,1,999999)
    o.realmID=numberObservation(states,'realmID',GetRealmID,1,100000000)
    o.mapID=numberObservation(states,'mapID',C_Map and C_Map.GetBestMapForUnit,1,10000000,'player')
    o.realm=text((read(GetRealmName)),100) or text((read(GetNormalizedRealmName)),100)
    states.realm=o.realm and 'OBSERVED' or 'EMPTY_OR_UNAVAILABLE'
    local faction=read(UnitFactionGroup,'player')
    o.faction=(faction=='Alliance' or faction=='Horde') and faction or nil
    states.faction=o.faction or 'UNAVAILABLE'
    local guid=read(UnitGUID,'npc')
    o.auctioneerID=type(guid)=='string' and integer(guid:match('^Creature%-%d+%-%d+%-%d+%-%d+%-(%d+)%-'),1,999999999) or nil
    states.auctioneer=o.auctioneerID and ('OBSERVED:'..decimal(o.auctioneerID)) or 'UNAVAILABLE'
    -- This is only the observed server namespace, never a character GUID/name
    -- and never represented as the return value of GetRealmID().
    local playerGUID=read(UnitGUID,'player')
    o.guidNamespace=type(playerGUID)=='string' and integer(playerGUID:match('^Player%-(%d+)%-[%x]+$'),1,100000000) or nil
    states.guidNamespace=o.guidNamespace and ('OBSERVED:'..decimal(o.guidNamespace)) or 'UNAVAILABLE'
    local regional=read(RegionalUniqueNamesEnabled);o.regionalNames=regional==true
    states.regionalNames=type(regional)=='boolean' and tostring(regional) or 'UNAVAILABLE'
    local rules=C_GameRules
    o.gameModeRecordID=numberObservation(states,'gameModeRecordID',rules and rules.GetCurrentGameModeRecordID,1,999999999)
    o.activeGameMode=numberObservation(states,'activeGameMode',rules and rules.GetActiveGameMode,0,999999999)
    local ruleEnum=Enum and Enum.GameRule
    for _,entry in ipairs({{'hardcore','HardcoreRuleset'},{'roleplay','RPRuleset'},{'pvp','PvPRuleset'}})do
        local id=field(ruleEnum,entry[2]);local value,why
        if integer(id,0,999999) then value,why=read(rules and rules.IsGameRuleActive,id) else why='ENUM_UNAVAILABLE' end
        o[entry[1]]=type(value)=='boolean' and value or nil
        -- Successful false is an observation, unavailable never means PvE.
        if value==false then o[entry[1]]=false end
        states[entry[1]]=type(value)=='boolean' and tostring(value) or why
    end
    o.rulesKnown=type(o.hardcore)=='boolean' and type(o.roleplay)=='boolean' and type(o.pvp)=='boolean'
    o.modeObserved=o.gameModeRecordID~=nil or o.activeGameMode~=nil or
        o.hardcore~=nil or o.roleplay~=nil or o.pvp~=nil
    local info=o.mapID and C_Map and read(C_Map.GetMapInfo,o.mapID)
    o.location=text(field(info,'name'),100) or text((read(GetRealZoneText)),100) or text((read(GetZoneText)),100)
    for _,name in ipairs({'region','realmID','mapID','faction','auctioneerID'})do
        if o[name]==nil then o.missingFields[#o.missingFields+1]=name end
    end
    return o
end
local function nextVisit()
    local account=W.Storage and W.Storage:IsWritable() and W.Storage.account
    local serial=account and integer(account.p29VisitSerial,0,9007199254740990) or S.localSerial or 0
    serial=serial+1;S.localSerial=serial
    if account then account.p29VisitSerial=serial end
    local at=integer(W.Clock(),0,9007199254740991) or 0
    return 'S'..decimal(at)..'X'..decimal(serial)
end
local function bit(v)return v==true and '1' or v==false and '0' or 'U'end
local function number(v)return v and decimal(v) or 'U'end
local function buildScope(o,b,visit)
    local server,source='U','UNAVAILABLE'
    if o.realmID then server,source='I'..decimal(o.realmID),'NATIVE_REALM_ID'
    elseif o.regionalNames and (o.gameModeRecordID or o.rulesKnown) then source='REGIONAL_GAME_RULESET'
    elseif o.guidNamespace then server,source='G'..decimal(o.guidNamespace),'PLAYER_GUID_SERVER_NAMESPACE'
    elseif o.realm and #o.realm<=24 then
        server='T'..o.realm:gsub('.',function(c)return string.format('%02X',string.byte(c))end)
        source='OBSERVED_REALM_NAME'
    end
    local durable=o.region and o.mapID and o.faction and o.auctioneerID and source~='UNAVAILABLE' and
        (not o.regionalNames or o.gameModeRecordID~=nil or o.rulesKnown)
    local venue=durable and ('N'..decimal(o.auctioneerID)) or visit
    local region='R'..number(o.region);if not o.region then region='U'end
    local mode='D'..number(o.gameModeRecordID)..'A'..number(o.activeGameMode)..
        'H'..bit(o.hardcore)..'R'..bit(o.roleplay)..'P'..bit(o.pvp)
    local map=o.mapID and ('M'..decimal(o.mapID)) or 'U'
    local flavor=b.marketFlavor or 'Forever'
    local parts={'WC4',flavor,'LIVE',region,server,mode,o.faction or 'Unknown',map,'LOCAL',venue,decimal(b.build)}
    local legacy=o.region and o.region<=999 and o.realmID and o.mapID and o.faction and not o.modeObserved and not o.regionalNames
    local key=legacy and table.concat({'WC3',flavor,'LIVE',o.region,o.realmID,o.faction,o.mapID,'LOCAL',venue,b.build},'/') or table.concat(parts,'/')
    if #key>160 then
        -- No truncation/hashing of names: isolate rather than create a collision.
        server,source,durable,venue='U','KEY_LENGTH_VISIT_FALLBACK',false,visit
        parts[5]=server;parts[10]=venue;key=table.concat(parts,'/')
    end
    local label=o.realm or (o.regionalNames and o.rulesKnown and
        (o.hardcore and 'Hardcore' or o.roleplay and (o.pvp and 'RP-PvP' or 'RP') or o.pvp and 'PvP' or 'PvE')) or 'Current world'
    local location=o.location or (o.mapID and ('Map '..o.mapID)) or 'Current Auction House'
    return {key=key,status=durable and 'AUTOMATIC_AUCTIONEER_SCOPED' or 'AUTOMATIC_SESSION_SCOPED',
        ready=true,venueRole='LOCAL',venueLabel='Local Auction House',venueToken=venue,
        auctioneerID=o.auctioneerID,region=o.region,realmID=o.realmID,realm=o.realm,
        faction=o.faction or 'Unknown',mapID=o.mapID,build=b.build,flavor=flavor,
        regionToken=region,serverToken=server,modeToken=mode,mapToken=map,
        identitySource=source,identityMode=durable and 'DURABLE' or 'VISIT_ISOLATED',
        gameModeRecordID=o.gameModeRecordID,activeGameMode=o.activeGameMode,
        hardcore=o.hardcore,roleplay=o.roleplay,pvp=o.pvp,regionalNames=o.regionalNames,
        guidNamespace=o.guidNamespace,missingFields=o.missingFields,metadataState=o.metadataState,
        location=location,display=label..' · '..(o.faction or 'Faction unavailable')..' · '..location}
end
function S:Opened()
    self.session=W.runtime.ahSession;self.visitToken=nextVisit();self.frozen=nil
    W.runtime.venueRole='LOCAL';W.runtime.venueRemembered=false
    -- Capture before the NPC interaction token disappears, then retain the
    -- same key for all results and commits in this Auction House visit.
    return self:Snapshot()
end
function S:Snapshot()
    local b=W.Compat.build or W.Compat:ReadBuild()
    local known=b.identityKnown==true or b.identityKnown==nil and b.exactTarget==true
    -- A transient identity read during startup must be able to recover from
    -- the actual native provider, rather than waiting for somebody to rewrite
    -- the cached Compat table. Bound retries and keep all query guards active.
    if W.runtime.ahOpen and (not known or not (b.runtimeAllowed or b.exactTarget)) and
        type(W.Compat.ReadBuild)=='function' then
        local value=read(GetTime) or W.Clock()
        local now=W.Math.ValidNumber(value) and value or nil
        if now and (not self.lastBuildProbe or now-self.lastBuildProbe>=1) then
            self.lastBuildProbe=now;b=W.Compat:ReadBuild()
            known=b.identityKnown==true or b.identityKnown==nil and b.exactTarget==true
        end
    end
    local reason
    if not W.runtime.ahOpen then reason='Visit an auctioneer for local prices.'
    elseif self.session~=W.runtime.ahSession or not self.visitToken then reason='Preparing the current Auction House visit.'
    elseif not (b.runtimeAllowed or b.exactTarget) then reason='Client values are not readable for Auction House queries.'
    elseif not known or not integer(b.build,1,999999999) then reason='Waiting for the client build identity.' end
    if reason then return {ready=false,status=W.runtime.ahOpen and 'CONTEXT_PENDING' or 'AUCTION_HOUSE_CLOSED',
        reason=reason,missingFields={not known and 'clientIdentity' or 'auctionVisit'},metadataState={},
        display=reason,venueRole='LOCAL',build=b.build,flavor=b.marketFlavor} end
    if self.frozen and (self.frozen.build~=b.build or self.frozen.flavor~=(b.marketFlavor or 'Forever')) then
        -- A verified client identity change is not optional metadata hydration.
        -- Retire its namespace so pending producers fail their scope fence.
        self.frozen=nil;self.visitToken=nextVisit()
    end
    if not self.frozen then
        self.frozen=buildScope(observations(),b,self.visitToken)
        self.venueToken=self.frozen.venueToken;self.npcID=self.frozen.auctioneerID
        W.runtime.venueSource=self.npcID and 'OBSERVED_AUCTIONEER' or 'ISOLATED_AUCTION_VISIT'
    end
    return copy(self.frozen)
end
function S:ReadinessReason()
    local scope=self:Snapshot()
    if not scope.ready then return scope.reason end
end
function S:ReadMarketKey()
    if W.runtime.ahOpen then return self:Snapshot().key end
    return W.Storage and W.Storage.character and W.Storage.character.lastMarketKey or nil
end
function S:ReadMarket()return W.Storage and W.Storage:GetMarket(self:ReadMarketKey())end
function S:ReadContext()
    local active=self:Snapshot();local key=self:ReadMarketKey();local market=W.Storage:GetMarket(key)
    local targets=W.Storage.account and W.Storage.account.targeted and W.Storage.account.targeted.markets
    local target=targets and key and targets[key]
    local scope=market and market.scope or target and target.scope or (active.ready and active or nil)
    local mode=active.ready and 'CURRENT' or (key and 'LAST_SAVED' or 'NONE')
    local info=scope and scope.mapID and C_Map and read(C_Map.GetMapInfo,scope.mapID)
    local location=text(field(info,'name'),100) or scope and scope.location or (scope and scope.mapID and ('Map '..scope.mapID))
    return {key=key,market=market,scope=scope,active=active,mode=mode,
        label=scope and ((location or 'Local Auction House')..' · '..(scope.faction or 'Faction unavailable')) or active.reason,
        source=mode=='CURRENT' and W.runtime.venueSource or 'SAVED_HISTORY',liveReady=active.ready==true}
end
-- Inert compatibility for retired manual venue controls.
function S:Venue()return false,'The current Auction House is detected automatically.'end
function S:LocationSignature()return self.venueToken end
function S:RememberCurrent()return false end
function S:SetRemember()return false,'Auction House context is automatic.'end
function S:Closed()
    self.npcID=nil;self.venueToken=nil;self.visitToken=nil;self.session=nil;self.frozen=nil
    W.runtime.venueRemembered=false;W.runtime.venueSource=nil
end
