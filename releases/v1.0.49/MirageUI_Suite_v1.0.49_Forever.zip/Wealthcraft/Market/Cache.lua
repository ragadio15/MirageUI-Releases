-- G6 item metadata hydration belongs to ONE user-requested replication lifecycle.
-- It does not send AH queries, create item links, or certify variant identity.
local _,W=...
-- Bounded per-tick item-detail requests; faster than G10's six-per-quarter-second pace,
-- but still capped at twelve requests per tick to avoid flooding the game client.
W.ItemCache={limit=8192,batch=12,interval=0.25}
local C=W.ItemCache
local function clock() return type(GetTime)=='function' and GetTime() or 0 end
function C:Reset()
    self.lastProgress=nil;self.queue={};self.seen={};self.head=1;self.queued=0;self.requests=0
    self.loaded=0;self.failed=0;self.nextAt=0;self.events=0
end
function C:Queue(itemID)
    if not self.seen then self:Reset() end
    if not W.Math.ValidInteger(itemID,1,999999999) or self.seen[itemID] or
        self.queued>=self.limit then return end
    if type(C_Item)~='table' or type(C_Item.RequestLoadItemDataByID)~='function' then return end
    self.seen[itemID]='QUEUED';self.queue[#self.queue+1]=itemID;self.queued=self.queued+1
end
function C:Tick()
    if not self.queue or clock()<self.nextAt then return end
    self.nextAt=clock()+self.interval
    local fn=type(C_Item)=='table' and C_Item.RequestLoadItemDataByID
    if type(fn)~='function' then return end
    local n=0
    local started
    if type(debugprofilestop)=='function' then
        local ok,time=pcall(debugprofilestop)
        if ok and type(time)=='number' then started=time end
    end
    while self.head<=#self.queue and n<self.batch do
        -- A batch limit alone cannot bound expensive native metadata calls.
        -- Keep at least one operation moving, then yield after the measured
        -- per-tick budget. No request is repeated in the same scan generation.
        if n>=1 and started and type(debugprofilestop)=='function' then
            local ok,time=pcall(debugprofilestop)
            if ok and type(time)=='number' and time-started>=1.0 then break end
        end
        local id=self.queue[self.head];self.head=self.head+1;n=n+1
        -- Mark before calling: a client may dispatch its result synchronously.
        self.seen[id]='REQUESTED';self.requests=self.requests+1
        local ok,result=pcall(fn,id)
        if (not ok or result==false) and self.seen[id]=='REQUESTED' then self.failed=self.failed+1;self.seen[id]='FAILED' end
    end
end
function C:OnResult(id,success)
    if not W.Scan or not W.Scan:IsActive() or not self.seen or self.seen[id]~='REQUESTED' then return end
    self.events=self.events+1
    if success==true then self.loaded=self.loaded+1;self.seen[id]='LOADED'
    else self.failed=self.failed+1;self.seen[id]='FAILED' end
    -- Scanner rechecks the original replication row later, within its own budget.
end
function C:Progress()
    if not self.seen and self.lastProgress then return self.lastProgress end
    -- Counters are maintained at submission/result time. Do not rescan thousands
    -- of unique IDs on every recovery frame just to paint a progress label.
    local queued=math.max(0,(self.queued or 0)-(self.requests or 0))
    local loaded,failed=self.loaded or 0,self.failed or 0
    local requested=math.max(0,(self.requests or 0)-loaded-failed)
    return {queued=queued,requested=requested,loaded=loaded,failed=failed,
        limit=self.limit,submitted=self.requests or 0,distinct=self.queued or 0}
end
function C:Release() self.lastProgress=self:Progress();self.queue=nil;self.seen=nil end
