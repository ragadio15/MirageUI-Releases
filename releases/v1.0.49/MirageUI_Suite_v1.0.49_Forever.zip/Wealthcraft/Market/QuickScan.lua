-- One small, read-only queue per auction visit. No full scan and no trade is issued here.
local _,W=...
W.QuickScan={state='IDLE',limit=6,deadlineSeconds=75,queryTimeout=12,queue={},completed=0,issued=0}
local Q=W.QuickScan
local function mono() return type(GetTime)=='function' and GetTime() or W.Clock() end
function Q:Enabled()
    return self.manualEnabled==true or (W.Storage.account and
        W.Storage.account.settings.autoScan~=false and W.Storage.account.settings.quickScan~=false)
end
function Q:Opened()
    self:Closed();self.manualEnabled=false;self.session=W.runtime.ahSession;self.openedAt=mono();self.nextAt=mono()+1.2
    self.completed=0;self.issued=0;self.skipped=0;self.deferAttempts=0
    self.retryCount=0;self.expired=0;self.noData=0;self.alreadyFresh=0;self.queue={};self.cursor=1;self.built=false
    self.timeouts=0;self.guardWaits=0;self.retryPerKey={};self.guardDue=nil
    self.state=self:Enabled() and 'WAITING' or 'OFF';self.reason=nil
    self.contextWait=nil;self.budgetPausedAt=nil;self.pauseKind=nil;self.contextKey=nil
    self:ContextChanged(W.Scope:Snapshot())
    if self:Enabled() then self:StartTicker() end
end
function Q:StartTicker()
    if not self.frame then
        self.frame=CreateFrame('Frame');self.elapsed=0
        self.frame:SetScript('OnUpdate',function(_,elapsed)
            Q.elapsed=(Q.elapsed or 0)+elapsed
            local slow=Q.state=='PAUSED' or Q.state=='WAIT_MARKET' or
                (Q.state=='WAITING' and (Q.nextAt or 0)-mono()>2)
            if Q.elapsed<(slow and 1 or 0.25) then return end;Q.elapsed=0
            local ok=W.Try('quick-refresh',Q.Tick,Q)
            if not ok then Q:Yield('Refresh stopped safely') end
        end)
    end
    self.frame:Show()
end
function Q:Closed()
    if W.QuickTarget:IsActive() then W.QuickTarget:Cancel() end
    self.state='IDLE';self.activeKey=nil;self.autoResume=false;self.resumeAt=nil;self.userPaused=false;self.manualEnabled=false
    self.contextWait=nil;self.budgetPausedAt=nil;self.pauseKind=nil;self.guardDue=nil
    if self.frame then self.frame:Hide() end
end
function Q:Yield(reason,recoverable)
    if self.state=='WAITING' or self.state=='RUNNING' or self.state=='WAIT_MARKET' then
        if W.QuickTarget:IsActive() then W.QuickTarget:Cancel() end
        self.state='PAUSED';self.reason=reason or 'Another request';self.activeKey=nil
        self.autoResume=recoverable==true
        self.pauseKind=recoverable and 'SERVICE' or 'TERMINAL'
        if recoverable then
            self.resumeAt=mono()+6;self:SuspendBudget();self:StartTicker()
        elseif self.frame then self.frame:Hide() end
        W.Refresh()
    end
end
function Q:CombatStarted()
    if not W.runtime.ahOpen or self.session~=W.runtime.ahSession or self.userPaused then return false end
    if self.state=='RUNNING' or self.state=='WAITING' or self.state=='WAIT_MARKET' then
        self:Yield('Waiting for combat to end',true)
        self.pauseKind='COMBAT';self.resumeAt=mono()+1
        return true
    end
    return false
end
function Q:CombatEnded()
    if not W.runtime.ahOpen or self.session~=W.runtime.ahSession or self.userPaused then return false end
    if self.state=='PAUSED' and self.pauseKind=='COMBAT' and self.autoResume then
        self.resumeAt=mono()+1
        self:StartTicker()
        return true
    end
    return false
end
function Q:UserPause()
    if W.QuickTarget:IsActive() then
        W.QuickTarget:Cancel()
    end
    self.activeKey=nil;self.userPaused=true;self.autoResume=false
    self.state='PAUSED';self.pauseKind='USER';self.reason='Paused by you'
    self:SuspendBudget()
    if self.frame then self.frame:Hide()end
    W.Refresh()
end
function Q:UserResume()
    W.Priority.reviewUntil=nil
    self.userPaused=false
    if self.state=='PAUSED' and self.pauseKind=='USER' then
        self.autoResume=true;self.pauseKind='MANUAL';self.reason='Resuming after your pause'
        self.resumeAt=mono()+.5;self:StartTicker()
    end
    W.Refresh()
end
function Q:UserRestart()
    if not W.runtime.ahOpen then return false,'Open an Auction House first.' end
    if W.Scan and W.Scan:IsActive() then return false,'Finish or stop the current full scan first.' end
    -- Start a fresh bounded visit queue without changing account preferences.
    -- Current user queries are not cancelled. Tick waits for their completion.
    W.Priority.reviewUntil=nil
    self:Opened();self.manualEnabled=true;self.userPaused=false
    self.state='WAITING';self.reason='Preparing a quick price check'
    self.nextAt=mono()+.5;self:StartTicker()
    W.Refresh();return true,'Quick price check queued'
end
-- A direct player click interrupts an optional on-open price refresh. The
-- current queue, remaining work, and session stay intact for a later resume.
-- A sent search cannot be unsent, so its temporary state is discarded and a
-- new request waits for Blizzard's next usable query slot.
function Q:PauseForManual()
    if self.userPaused then return false end
    if self.state~='RUNNING' and self.state~='WAITING' and self.state~='WAIT_MARKET' and
        not (self.state=='PAUSED' and self.autoResume) then return false end
    if W.QuickTarget:IsActive() then
        W.QuickTarget:Cancel()
    end
    self.activeKey=nil
    self.state='PAUSED';self.reason='Waiting for your search';self.autoResume=true;self.pauseKind='MANUAL'
    self:SuspendBudget()
    self.resumeAt=mono()+W.Priority:ReviewRemaining()
    self.deferAttempts=0
    self:StartTicker() -- lightweight watchdog; no queries while paused
    W.Refresh()
    return true
end
function Q:ManualBusy()
    return (W.UI and W.UI.pendingSearch~=nil) or (W.Targeted and W.Targeted:IsActive()) or
        (W.Browse and (function()
            if W.Browse.CheckTimeout then W.Browse:CheckTimeout()end
            return W.Browse.state=='REQUESTED'
        end)()) or
        (W.Owned and (function()
            if W.Owned.CheckTimeout then W.Owned:CheckTimeout()end
            return W.Owned.state=='REQUESTED'
        end)()) or
        (W.Trading and W.Trading.state~='IDLE') or
        (W.AuctionDesk and W.AuctionDesk.fallback==true) or
        (W.Scan and W.Scan:IsActive()) or
        (W.Scheduler and W.Scheduler.active~=nil)
end
function Q:SuspendBudget()
    if not self.budgetPausedAt then self.budgetPausedAt=mono()end
end
function Q:ResumeBudget()
    if self.budgetPausedAt then
        self.openedAt=(self.openedAt or mono())+math.max(0,mono()-self.budgetPausedAt)
        self.budgetPausedAt=nil
    end
end
function Q:ContextChanged(scope)
    if self.session~=W.runtime.ahSession or not W.runtime.ahOpen or not self:Enabled() or self.userPaused then return end
    scope=scope or W.Scope:Snapshot()
    if not scope.ready then
        if self.state=='WAITING' or self.state=='RUNNING' or self.state=='WAIT_MARKET' or
            (self.state=='PAUSED' and (self.autoResume or self.pauseKind=='CONTEXT')) then
            self.contextWait=self.contextWait or mono();self:SuspendBudget()
            self.state='WAIT_MARKET';self.reason=W.Automation and W.Automation:ContextReason(scope) or scope.reason or 'Waiting for current Auction House information'
            self.pauseKind=self.autoResume and self.pauseKind or 'CONTEXT'
            if self.activeKey and W.QuickTarget:IsActive() then W.QuickTarget:Cancel()end
            self.activeKey=nil;self.nextContextCheck=mono()+1;self:StartTicker()
        end
        return
    end
    if self.state=='WAIT_MARKET' or self.pauseKind=='CONTEXT' or
        (self.state=='PAUSED' and self.reason=='Auction House context unavailable') then
        self.contextWait=nil;self.nextContextCheck=nil
        if self.contextKey and self.contextKey~=scope.key then
            self.queue={};self.built=false;self.cursor=1;self.activeKey=nil
        end
        if self.autoResume then
            self.state='PAUSED';self.reason=self.pauseKind=='SERVICE' and 'Auction service busy' or 'Waiting for your search'
        else
            self:ResumeBudget();self.state='WAITING';self.reason=nil;self.pauseKind=nil;self.nextAt=mono()+.5
        end
        self:StartTicker()
    end
    self.contextKey=scope.key
end
function Q:VenueReady()
    self:ContextChanged(W.Scope:Snapshot())
    -- Compatibility for an explicitly suspended local queue. This cannot
    -- override a foreground pause or reopen a completed visit.
    if self.session==W.runtime.ahSession and self.issued==0 and self:Enabled() and
        self.state=='PAUSED' and self.reason=='Market changed' then
        self.state='WAITING';self:ResumeBudget();self.nextAt=mono()+1;self:StartTicker()
    end
end
function Q:ManualRejected()
    self:ContextChanged(W.Scope:Snapshot())
    if self.autoResume and self.pauseKind=='MANUAL' and not self:ManualBusy() then
        self.resumeAt=mono()+.5
    end
end
function Q:ServiceBusy(reason)
    if self.state~='WAITING' and self.state~='RUNNING' and self.state~='WAIT_MARKET' then return end
    self:Yield(reason or 'Auction service busy',true)
    self.autoResume=true;self.pauseKind='SERVICE';self.resumeAt=mono()+5;self:SuspendBudget();self:StartTicker()
end
function Q:ServiceReady()
    if self.session==W.runtime.ahSession and self.state=='PAUSED' and self.pauseKind=='SERVICE' then
        self.resumeAt=mono()+.25;self:StartTicker()
    end
end
function Q:Build()
    local candidates,seen={},{}
    local market=W.Scope:ReadMarketKey()
    local function add(key,priority,reason,name)
        key=W.ItemKinds:ObserveKey(key)
        local token,k=W.Storage:WatchKey(key)
        if not token or seen[token] then return end
        seen[token]=true
        local last=W.Storage:GetTarget(market,token)
        if not last and W.ItemKinds:IsCommodity(k.itemID,market) then last=W.Targeted:LastForItem(market,k.itemID) end
        if last and W.Clock()-(last.updatedAt or 0)<300 then return end
        candidates[#candidates+1]={key=k,token=token,priority=priority,reason=reason,name=name}
    end
    for _,entry in ipairs(W.Storage:WatchEntries()) do add(entry.item,1000,'Favorite') end
    local recipe=W.Crafting.last
    if recipe then
        for _,r in ipairs(recipe.reagents or {}) do
            if not r.unitCopper then add({itemID=r.itemID},900,'Recipe material') end
        end
        if recipe.outputID and not recipe.outputUnitCopper then add({itemID=recipe.outputID},850,'Recipe output') end
    end
    local recent=W.Storage.character and W.Storage.character.g8RecentItems
    if type(recent)=='table' then
        for i=1,math.min(12,#recent)do add(recent[i],800-i,'Recent search') end
    end
    for _,r in ipairs(W.PlayerContext:ReadBags())do
        if r.sellable and not r.locked then
            local q=W.Quotes:ForWatch(r.itemKey,market)
            local score=600+math.min(150,math.floor(math.log(1+(q and q.priceCopper or 0)*r.count)/math.log(2))*5)
            add(r.itemKey,score,'Carried item',r.name)
        end
    end
    table.sort(candidates,function(a,b)if a.priority==b.priority then return a.token<b.token end return a.priority>b.priority end)
    self.queue={};for i=1,math.min(self.limit,#candidates)do self.queue[i]=candidates[i] end
    self.built=true;self.cursor=1
end
-- Local query guard: compute a real wait instead of consuming the four
-- service-retry attempts. The 6-per-minute / 5-second native-safe limits stay
-- authoritative in W.Storage:TargetQueryEligibility.
local function nextAutoGuardDelay()
    local db=W.Storage.account
    local times=db and db.queryGuard and db.queryGuard.times
    if type(times)~='table' then return nil end
    local now=W.Clock()
    local count,oldest,latest=0,nil,nil
    for _,t in ipairs(times) do
        if type(t)=='number' and t<=now and now-t<60 then
            count=count+1
            if not oldest or t<oldest then oldest=t end
            if not latest or t>latest then latest=t end
        end
    end
    if count>=6 and oldest then return math.max(1,60-(now-oldest)+.5) end
    if latest and now-latest<5 then return math.max(1,5-(now-latest)+.5) end
end
function Q:Tick()
    if self.userPaused or (W.Automation and W.Automation:IsUserPaused()) then return end
    if not W.runtime.ahOpen or W.runtime.ahSession~=self.session or not self:Enabled() then
        self:Closed();return
    end
    if type(InCombatLockdown)=='function' and InCombatLockdown() then
        if self.state=='RUNNING' or self.state=='WAITING' or self.state=='WAIT_MARKET' then
            self:Yield('Waiting for combat to end',true)
            self.pauseKind='COMBAT';self.resumeAt=mono()+1
        end
        return
    end
    if self.state=='OFF' or self.state=='COMPLETE' then return end
    if not self.activeKey and W.Priority:ReviewRemaining()>0 then
        if self.state=='RUNNING' or self.state=='WAITING' then self:PauseForManual() end
        return
    end
    if self.guardDue and mono()>=self.guardDue and self.state~='PAUSED' then
        self.guardDue=nil;self:ResumeBudget()
    end
    if self.state=='WAIT_MARKET' and mono()<(self.nextContextCheck or 0) then return end
    local scope=W.Scope:Snapshot();self:ContextChanged(scope)
    if not scope.ready then return end
    if self.state=='PAUSED' then
        if not self.autoResume then return end
        if self:ManualBusy() then return end
        if mono()<(self.resumeAt or 0) then return end
        self:ResumeBudget();self.autoResume=false;self.state='WAITING';self.reason=nil;self.pauseKind=nil
        self.nextAt=mono()
    end
    if W.Automation and W.Automation:FullPending() then return end
    if not W.Storage:IsWritable() then
        self.state='PAUSED';self.reason='Saved data is read-only';if self.frame then self.frame:Hide() end;return
    end
    if mono()-self.openedAt>self.deadlineSeconds then
        self.expired=(self.expired or 0)+1
        self:Yield('Refresh time limit reached');return
    end
    if mono()<self.nextAt then return end
    if not self.built then self:Build() end
    if self.activeKey then
        local t=W.QuickTarget
        if t.origin~='QUICK_OPEN' or t.session~=self.session then self:Yield('Another request took priority',true);return end
        if t:IsActive() then
            if mono()-(self.queryAt or 0)>self.queryTimeout then
                t:Cancel() -- no additional unsent or implicit native request
                self.timeouts=(self.timeouts or 0)+1
                local tried=(self.retryPerKey and self.retryPerKey[self.activeKey]) or 0
                if tried<1 then
                    self.retryPerKey[self.activeKey]=tried+1
                    self.activeKey=nil
                    self.state='WAITING';self.reason='Retrying an incomplete price response'
                    self.nextAt=mono()+8;self.deferAttempts=0
                    W.Refresh();return
                end
            else return end
        end
        if t.state=='COMPLETE' then
            self.completed=self.completed+1
        else
            -- A terminal result that was not accepted must not be reported
            -- as a refreshed price; player-preempted queries are retried
            -- separately because PauseForManual clears activeKey before here.
            self.noData=(self.noData or 0)+1
            self.skipped=(self.skipped or 0)+1
        end
        self.activeKey=nil;self.cursor=self.cursor+1;self.deferAttempts=0
        -- Respect the local targeted-query guard without repeatedly probing it
        -- at quarter-second intervals. The next manual action still preempts us.
        local guard=W.Storage.account and W.Storage.account.queryGuard
        local times=guard and guard.times or nil
        local last=type(times)=='table' and times[#times] or nil
        local remain=type(last)=='number' and math.max(0,5-(W.Clock()-last)) or 0
        self.nextAt=mono()+math.max(0.25,remain)
    end
    if not self.queue[self.cursor] then
        self.state='COMPLETE';self.finishedAt=W.Clock()
        if self.frame then self.frame:Hide() end
        if W.Inventory then W.Inventory:Refresh() end
        W.Refresh();return
    end
    if W.Priority:ReviewRemaining()>0 or W.QueryBusy() or W.Scheduler.active then return end
    local entry=self.queue[self.cursor]
    local market=W.Scope:ReadMarketKey()
    local refreshed=W.Storage:GetTarget(market,entry.token)
    if not refreshed and W.ItemKinds:IsCommodity(entry.key.itemID,market) then
        refreshed=W.Targeted:LastForItem(market,entry.key.itemID)
    end
    if refreshed and W.Clock()-(refreshed.updatedAt or 0)<300 then
        -- The user may just have looked up this item. This is not a failure.
        self.alreadyFresh=(self.alreadyFresh or 0)+1
        self.cursor=self.cursor+1;self.nextAt=mono()+0.25;return
    end
    local can,why=W.QuickTarget:Eligibility(entry.key,'QUICK_OPEN')
    if not can then
        local info=tostring(why or '')
        if info:find('Automatic price refresh limit',1,true) or
            info:find('Automatic price refresh waiting',1,true) then
            local wait=nextAutoGuardDelay()
            if wait then
                self.guardDue=mono()+wait;self.guardWaits=(self.guardWaits or 0)+1
                self.reason='Waiting for safe Auction House query interval'
                self.nextAt=self.guardDue
                self:SuspendBudget();self.state='WAITING';W.Refresh();return
            end
        end
        -- Genuine service failures are finite per item, without busy polling.
        self.deferAttempts=(self.deferAttempts or 0)+1
        self.retryCount=(self.retryCount or 0)+1
        self.reason=tostring(why or 'Auction query not ready')
        if self.deferAttempts>=4 then
            self.skipped=(self.skipped or 0)+1
            self.cursor=self.cursor+1;self.deferAttempts=0
            self.nextAt=mono()+0.5
        else
            self.nextAt=mono()+math.min(7,1+self.deferAttempts*2)
        end
        return
    end
    self.deferAttempts=0
    self.state='RUNNING';self.activeKey=entry.token;self.queryAt=mono()
    local ok,reason=W.QuickTarget:Request(W.ItemKinds:ObserveKey(entry.key),'QUICK_OPEN')
    if ok then self.issued=self.issued+1;self.reason=nil
    else
        self.activeKey=nil;self.cursor=self.cursor+1
        self.skipped=(self.skipped or 0)+1;self.reason=reason
    end
    W.Refresh()
end
function Q:Summary()
    if self.state=='RUNNING' then return string.format('Refreshing prices · %d/%d',math.min(#self.queue,(self.cursor or 1)-1),#self.queue) end
    if self.state=='COMPLETE' then
        if self.issued==0 and (self.skipped or 0)>0 then return 'Quick prices unavailable · '..tostring(self.reason or 'see Diagnostics') end
        if self.issued==0 then return (self.alreadyFresh or 0)>0 and
            ((self.alreadyFresh or 0)..' prices already current') or 'No items need a quick refresh' end
        if self.completed==0 then return 'Quick prices unavailable · '..tostring(self.reason or 'no usable response') end
        local missing=self.skipped or 0
        return self.completed..' prices refreshed'..(missing>0 and ' · '..missing..' skipped' or '')
    end
    if self.state=='WAIT_MARKET' then return self.reason or 'Waiting for current Auction House information' end
    if self.state=='WAITING' then
        if (self.deferAttempts or 0)>0 then return 'Quick prices waiting · '..tostring(self.reason or 'Auction House not ready') end
        return 'Preparing quick price check'
    end
    if self.state=='PAUSED' then
        if self.userPaused or self.pauseKind=='USER' then return 'Scanning paused by you' end
        if self.autoResume then
            if self:ManualBusy() then return 'Quick checks waiting for current request' end
            local remaining=math.ceil(math.max(W.Priority:ReviewRemaining(),(self.resumeAt or mono())-mono()))
            return remaining>0 and ('Quick checks resume in '..remaining..'s') or 'Resuming quick price checks'
        end
        return 'Quick refresh stopped · '..tostring(self.reason or 'see Diagnostics')
    end
    if self.state=='OFF' then return 'Quick refresh off' end
    return ''
end
