-- A replication listing has an itemID, not necessarily an AH ItemKey.
-- Derive a conservative identity from item hyperlink fields; never blend unresolved suffixes.
local _, W = ...
W.Identity = {}
local I = W.Identity
local function split(s)
    local out = {}
    for field in (s .. ':'):gmatch('(.-):') do out[#out + 1] = field end
    return out
end
local function fieldNumber(fields, n)
    local v = fields[n]
    if v == nil or v == '' then return 0 end
    local num = tonumber(v)
    if not W.Math.ValidInteger(num, -999999999, 999999999) then return nil end
    return num
end
function I:FromLink(link, itemID)
    if type(link) ~= 'string' or #link > 600 then return nil, 'NO_FULL_ITEM_LINK' end
    local payload = link:match('|Hitem:([^|]+)|h')
    if not payload then payload = link:match('^item:([^|]+)$') end
    if not payload then return nil, 'NOT_ITEM_HYPERLINK' end
    local fields = split(payload)
    local id = fieldNumber(fields, 1)
    if not W.Math.ValidInteger(id, 1, 999999999) or (itemID and id ~= itemID) then
        return nil, 'ITEM_LINK_ID_MISMATCH'
    end
    local enchant = fieldNumber(fields, 2)
    local suffix = fieldNumber(fields, 7)
    local gem = {}
    if enchant == nil or suffix == nil then return nil, 'MALFORMED_LINK' end
    for i = 3, 6 do
        local v = fieldNumber(fields, i)
        if v == nil then return nil, 'MALFORMED_GEM_FIELDS' end
        gem[#gem + 1] = tostring(v)
    end
    -- Encoded bonus fields differ across game families; do not throw them away.
    -- Ignore only instance-specific uniqueID / linkLevel / player spec / instance metadata.
    local bonuses = fieldNumber(fields, 13)
    if bonuses == nil or bonuses < 0 or bonuses > 40 then return nil, 'UNSUPPORTED_BONUS_FIELDS' end
    local bonusValues = {}
    for i = 1, bonuses do
        if not fields[13+i] or fields[13+i]=='' then return nil, 'TRUNCATED_BONUS_FIELDS' end
        local v = fieldNumber(fields, 13 + i)
        if v == nil then return nil, 'TRUNCATED_BONUS_FIELDS' end
        bonusValues[#bonusValues + 1] = tostring(v)
    end
    -- Keep this key distinct from bare item IDs. Unknown link-specific fields are a precision risk.
    -- In Forever the fields after counted bonuses may contain context/quality; preserve them.
    local tail = {}
    for i = 14 + bonuses, #fields do
        if fields[i] ~= '' then tail[#tail + 1] = fields[i] end
    end
    -- Suppress non-semantic tail only for ordinary old-style links with no bonus/context encoding.
    local variant = 'id=' .. tostring(id) .. ';e=' .. tostring(enchant) ..
        ';g=' .. table.concat(gem, ',') .. ';s=' .. tostring(suffix) ..
        ';b=' .. table.concat(bonusValues, ',')
    if #tail > 0 then variant = variant .. ';x=' .. table.concat(tail, ',') end
    if #variant > 260 then return nil, 'VARIANT_KEY_TOO_LONG' end
    return variant, nil
end
function I:ItemID(identity)
    if type(identity) ~= 'string' then return nil end
    return tonumber(identity:match('^id=(%d+);'))
end
