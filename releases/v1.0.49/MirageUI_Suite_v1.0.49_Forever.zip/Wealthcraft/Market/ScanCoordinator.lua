-- G3: One read-only presentation and recovery coordinator for the existing
-- guarded full replication and six-item quick queue. No native query here.
local _,W=...
W.ScanCoordinator={version=1,rearms=0,checks=0,lastStatus=nil}
local R=W.ScanCoordinator
local function now()return type(GetTime)=='function' and GetTime() or W.Clock()end
local function data()
    local a,q,f=W.Automation,W.QuickScan,W.Scan
    return a,q,f
end
function R:Rearm(reason)
    self.checks=self.checks+1
    local a,q,f=data()
    if not W.runtime.ahOpen or not a or a:IsUserPaused() or not q or q.userPaused then return false end
    if q.session~=W.runtime.ahSession then return false end
    if q.state=='PAUSED' and q.autoResume==true and q.pauseKind~='USER' then
        -- A scheduled resume already has its one permitted wakeup.
        if q.frame and q.frame:IsShown() then return false end
        if q:ManualBusy() then
            q.resumeAt=math.max(q.resumeAt or 0,now()+5)
        elseif q.resumeAt==nil then
            q.resumeAt=now()+1
        end
        q:StartTicker()
        self.rearms=self.rearms+1
        self.lastRearmReason=reason or 'FOREGROUND_IDLE'
        return true
    end
    if a.state=='WAITING' or a.state=='WAIT_CONTEXT' then a:Wake() end
    return false
end
function R:Status()
    local a,q,f=data()
    local open=W.runtime.ahOpen and a and a.session==W.runtime.ahSession
    local progress=f and type(f.Progress)=='function' and f:Progress() or nil
    local s={contract=2,readOnly=true,ahOpen=open==true,completed=q and q.completed or 0,
        skipped=q and q.skipped or 0,alreadyFresh=q and q.alreadyFresh or 0,
        issued=q and q.issued or 0,
        retries=q and q.retryCount or 0,waiting=q and q.deferAttempts or 0,expired=q and q.expired or 0,noData=q and q.noData or 0,
        expected=q and #q.queue or 0,scope='CURRENT_VISIT',nativeVerification='NOT_RUN',
        fullGuardSeconds=900,fullStatus=f and f.state or 'UNAVAILABLE',
        quickStatus=q and q.state or 'UNAVAILABLE',fullStage=progress and progress.phase,
        fullProgress=progress,contextReady=a and a.contextReady==true,
        serviceDeferrals=a and a.serviceDeferrals or 0,
        quickTimeouts=q and q.timeouts or 0,quickGuardWaits=q and q.guardWaits or 0}
    local review=W.Priority:ReviewRemaining()
    local quickPending=q and (q.state=='RUNNING' or q.state=='WAITING' or q.state=='PAUSED' and q.autoResume)
    local fullPending=a and (a.state=='WAITING' or a.state=='WAIT_SERVICE')
    if not open then s.state='NO_CONTEXT';s.text='Auction House closed · saved prices only'
    elseif a:IsUserPaused() or (q and q.userPaused) then
        s.state='USER_PAUSED';s.text='Automatic checks paused'
    elseif review>0 and (f and f.pausedForUser or (not f or not f:IsActive()) and (quickPending or fullPending)) then
        s.state='YIELDING';s.retryInSeconds=math.ceil(review)
        s.text='Review time · '..s.retryInSeconds..'s remaining'
    elseif f and f:IsActive() then
        s.state=f.pausedForUser and 'FULL_YIELDING' or 'FULL_RUNNING'
        s.text=progress and progress.label or 'Scanning returned listings'
        if progress and progress.total and progress.total>0 and progress.done then
            s.text=s.text..' · '..math.min(progress.total,progress.done)..'/'..progress.total
        end
    elseif q and q.state=='RUNNING' then
        s.state='QUICK_RUNNING';s.text=string.format('Checking %d of %d items',
            math.min(#q.queue,(q.cursor or 1)),#q.queue)
    elseif q and q.state=='PAUSED' and q.autoResume then
        s.state='YIELDING'
        if q.pauseKind=='COMBAT' then s.text='Checks resume after combat'
        elseif q:ManualBusy() then s.text='Checks waiting for your action'
        else
            local seconds=math.max(0,math.ceil((q.resumeAt or now())-now()))
            s.retryInSeconds=seconds
            s.text=seconds>0 and ('Checks resume in '..seconds..'s') or 'Resuming price checks'
        end
    elseif a.state=='WAIT_CONTEXT' or (q and q.state=='WAIT_MARKET') then
        s.state='NO_CONTEXT';s.text='Waiting for Auction House context'
    elseif a.state=='WAIT_SERVICE' then
        s.state='WAIT_SERVICE';s.retryInSeconds=math.max(0,math.ceil((a.nextAt or now())-now()))
        s.text='Auction House busy · retry in '..s.retryInSeconds..'s'
    elseif a.state=='WAITING' and a.cooldownAt and a.cooldownAt>now() and
        (not q or q.state=='COMPLETE' or q.state=='OFF') then
        s.state='WAIT_THROTTLE';s.retryInSeconds=math.max(0,math.ceil(a.cooldownAt-now()))
        s.text='Full scan available in '..math.ceil(s.retryInSeconds/60)..'m'
    elseif q and q.state=='PAUSED' and not q.autoResume then
        s.state='UNAVAILABLE';s.text='Quick price checks unavailable · retry on next visit'
    elseif q and q.state=='WAITING' then
        s.state='WAIT_THROTTLE';s.text=(q.deferAttempts or 0)>0 and 'Waiting for Auction House query service' or 'Preparing price checks'
    elseif q and q.state=='COMPLETE' then
        s.state='CURRENT';s.text=s.completed>0 and
            (s.completed..' prices refreshed'..(s.alreadyFresh>0 and (' · '..s.alreadyFresh..' already current') or '')..
                (s.skipped>0 and (' · '..s.skipped..' not refreshed') or '')) or
            (s.alreadyFresh>0 and (s.alreadyFresh..' prices already current'..
                (s.skipped>0 and (' · '..s.skipped..' not refreshed') or '')) or
                (s.skipped>0 and 'No quick prices refreshed' or 'Prices checked · nothing pending'))
        s.lastCheckedAt=q.finishedAt
    elseif a.state=='UNAVAILABLE' then
        s.state='UNAVAILABLE';s.text='Full scan unavailable · saved prices retained'
    elseif not a:Enabled() and not(q and q.manualEnabled) then
        s.state='OFF';s.text='Automatic checks off'
    else s.state='IDLE';s.text='Preparing market prices' end
    self.lastStatus=s
    return s
end
function R:Summary()return self:Status().text end
function R:Diagnostics()
    local s=self:Status()
    return {contract=s.contract,state=s.state,ahOpen=s.ahOpen,
        completed=s.completed,skipped=s.skipped,alreadyFresh=s.alreadyFresh,issued=s.issued,
        retries=s.retries,waiting=s.waiting,expired=s.expired,noData=s.noData,expected=s.expected,
        quickStatus=s.quickStatus,fullStatus=s.fullStatus,rearms=self.rearms,
        checks=self.checks,retryInSeconds=s.retryInSeconds,
        fullStage=s.fullStage,fullProgress=s.fullProgress,
        serviceDeferrals=s.serviceDeferrals,quickTimeouts=s.quickTimeouts,quickGuardWaits=s.quickGuardWaits}
end
