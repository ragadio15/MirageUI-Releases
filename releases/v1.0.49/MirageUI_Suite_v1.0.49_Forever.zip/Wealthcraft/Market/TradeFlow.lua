-- G8 commodity orders: one explicit Buy click authorizes ONE exact quantity and
-- a visible maximum total. The server fills cheapest available tiers. A higher
-- quote never widens that authorization automatically. No automatic reposts.
local _,W=...
local A=W.Trading
local function valid(v,min,max)return W.Math.ValidInteger(v,min,max)end
local function affordable(n)local ok,v=W.SafeCall(GetMoney);return ok and valid(v,0) and v>=n end
local function now()return type(GetTime)=='function' and GetTime() or W.Clock() end
local function session(p)return p and W.runtime.ahOpen and p.session==W.runtime.ahSession and
    p.marketKey==W.Scope:Snapshot().key end
local function cancelQuote()W.SafeCall(W.Compat.auction and W.Compat.auction.CancelCommoditiesPurchase)end
local guard=A.Guard
function A:Guard(allowPending)
    if W.QuickScan then W.QuickScan:Yield('Trading',true) end
    if not allowPending and self.state=='IDLE' and W.runtime.ahOpen and W.Scan
        and W.Scan.origin=='AUTO_AH_OPEN' and W.Scan:IsActive() then
        W.Scan:PauseForManual()
    end
    return guard(self,allowPending)
end
function A:Tolerance()
    local s=W.Storage.account and W.Storage.account.settings
    local v=s and s.priceToleranceBps
    return valid(v,0,1000) and v or 200
end
function A:CommodityEstimate(quantity,display)
    local t=W.Targeted;local a=W.Compat.auction or {}
    if t.state~='COMPLETE' or t.kind~='COMMODITY' or not t.scope or not W.runtime.ahOpen or t.scope.key~=W.Scope:ReadMarketKey() or t.session~=W.runtime.ahSession then return nil,'Refresh live offers first.' end
    if not valid(quantity,1,999999) then return nil,'Enter a whole quantity of at least one.' end
    local book=display and t.offerBook
    if display and not book then return nil,'Refresh live offers first.' end
    local ok,n=true,book and #book
    if not book then ok,n=W.SafeCall(a.GetNumCommoditySearchResults,t.itemKey.itemID) end
    if not ok or not valid(n,1,25000) then return nil,'No available offers.' end
    local total,remaining,last=0,quantity,0
    for i=1,math.min(n,500)do
        if remaining==0 then break end
        local good,r=true,book and book[i]
        if not book then good,r=W.SafeCall(a.GetCommoditySearchResultInfo,t.itemKey.itemID,i) end
        local price=good and type(r)=='table' and (book and r.unit or r.unitPrice)
        if not good or type(r)~='table' or (r.itemID~=nil and r.itemID~=t.itemKey.itemID) or not valid(r.quantity,1) or not valid(price,1) or price<last then
            return nil,'Price data changed. Refresh offers.'
        end
        local available=r.quantity
        if valid(r.numOwnerItems,0,r.quantity) then available=available-r.numOwnerItems
        elseif r.owned or r.containsOwnerItem or r.containsAccountItem then return nil,'Owned units make this price tier ambiguous. Use Blizzard view.' end
        local take=math.min(remaining,available)
        if not valid(total+take*price,0) then return nil,'Total exceeds the safe price range.' end
        total=total+take*price;remaining=remaining-take;last=price
    end
    if remaining>0 then return nil,'Not enough available units in the loaded offers.' end
    local bps=self:Tolerance()
    local remainder=total%10000
    local cap=total+((total-remainder)/10000)*bps+math.floor(remainder*bps/10000)
    if not valid(cap,total) then return nil,'Price limit exceeds the safe range.' end
    return {total=total,maxTotal=cap,quantity=quantity,itemID=t.itemKey.itemID,toleranceBps=bps}
end
function A:BuyCommodity(quantity,approvedCap)
    local can,why=self:Guard();if not can then return false,why end
    local e,err=self:CommodityEstimate(quantity);if not e then return false,err end
    -- A changing book must not increase the maximum total shown before the click.
    local cap=approvedCap or e.maxTotal
    if not valid(cap,1) then return false,'Invalid spending limit.' end
    if e.total>cap then return false,'The price moved above your displayed limit. Review the new total.' end
    if not affordable(e.total) then return false,'Not enough gold.' end
    self.pending={kind='COMMODITY_BUY',session=W.runtime.ahSession,marketKey=W.Scope:Snapshot().key,
        itemID=e.itemID,quantity=quantity,price=e.total,originalMax=cap,approvedTotal=cap,
        preparedAt=W.Clock(),authorizedAt=now(),authorizationExpires=now()+15,automaticWithinCap=true}
    return self:RequestAuthorizedQuote()
end
function A:RequestAuthorizedQuote()
    local p=self.pending
    if not session(p) or not p.automaticWithinCap then return false,'The order is no longer valid.' end
    self.state='QUOTE_WAITING';self.quote=nil;self.quoteRequestedAt=W.Clock()
    self.message='Securing the lowest available price…'
    local ok,err=W.SafeCall(W.Compat.auction.StartCommoditiesPurchase,p.itemID,p.quantity)
    if not ok then self:Reset('Could not reserve this purchase. Try again or use Blizzard view.');return false,tostring(err) end
    W.Refresh();return true,self.message
end
function A:AcceptChangedQuote()
    local allowed,reason=self:Guard(true);if not allowed then return false,reason end
    local p=self.pending;local q=self.quote
    if self.state~='PRICE_CHANGED' or not session(p) or not q or not valid(q.total,1) then return false,'Refresh the order first.' end
    if not affordable(q.total) then return false,'Not enough gold for the new price.' end
    -- This function is invoked ONLY by the changed-price dialog's physical button.
    p.originalMax=q.total;p.approvedTotal=q.total;p.authorizedAt=now();p.authorizationExpires=now()+15
    cancelQuote()
    return self:RequestAuthorizedQuote()
end
local oldCommit=A.Commit
function A:Commit()
    local p=self.pending
    if self.state=='PRICE_CHANGED' then return self:AcceptChangedQuote() end
    if p and p.automaticWithinCap then return false,'Wait for the quoted order, or cancel it.' end
    if self.state=='POST_CONFIRM' and self:ReviewRemaining()<=0 then
        self:Reset('Posting review expired. Review your listing again.');return false,self.message
    end
    local post=p and (p.kind=='POST_ITEM' or p.kind=='POST_COMMODITY')
    if post then self.postEvent=nil;self.postError=nil;self.submittingPost=true;self.lastPostCandidate=p end
    local ok,why=oldCommit(self)
    if ok and p and p.kind=='ITEM_BID' and W.UI then
        W.UI.offerSelected=nil
        for _,field in ipairs(W.UI.shopBidAmounts or {})do field:SetText('')end
    end
    if post then
        self.submittingPost=false
        if self.postError then self:Reset(self.postError);return false,self.message end
        if ok and self.state=='IDLE' then
            if self.postEvent then self:Reset('Auction created.');self.lastAction={kind='POST',status='SERVER_CREATED_EVENT',auctionID=self.postEvent,at=W.Clock()}
                if W.UI and W.UI.ClearTradeInputs then W.UI:ClearTradeInputs('POST')end
            else
                self.pending=p;self.state='POST_WAITING';self.postSentAt=now()
                self.message='Listing submitted. Waiting for the Auction House.'
            end
        end
    end
    return ok,self.message or why
end
function A:OnItemPurchased(auctionID)
    local p=self.pending
    if not session(p) or p.kind~='ITEM_BUYOUT' or self.state~='PURCHASE_WAITING'
        or not valid(auctionID,1) or auctionID~=p.auctionID then return end
    self.lastAction={kind='ITEM_BUYOUT',status='SERVER_SUCCESS_EVENT',auctionID=auctionID,at=W.Clock()}
    self:Reset('Buyout complete. Collect your item from the mailbox.')
    if W.UI and W.UI.ClearTradeInputs then W.UI:ClearTradeInputs('BUY')end
    W.Inventory:MarkDirty();W.Targeted.state='STALE';W.Notify(self.message);W.Refresh()
end
function A:OnPosted(id)
    if self.submittingPost or self.state=='POST_WAITING' then
        self.postEvent=id
        if not self.submittingPost then
            self.lastAction={kind='POST',status='SERVER_CREATED_EVENT',auctionID=id,at=W.Clock()}
            self:Reset('Auction created.');W.Inventory:MarkDirty();W.Notify('Auction created.')
            if W.UI and W.UI.ClearTradeInputs then W.UI:ClearTradeInputs('POST')end
        end
    end
end
function A:OnPostError()
    if not self.submittingPost and self.state~='POST_WAITING' and self.state~='POST_CONFIRM' then return end
    self.postError='The Auction House rejected the listing. Check the item and price, then retry or use Blizzard view.'
    self.lastAction={kind='POST',status='SERVER_ERROR_EVENT',at=W.Clock()}
    self:Reset(self.postError);W.Notify(self.postError)
end
local oldEvent=A.OnEvent
function A:OnEvent(event,unit,total)
    local p=self.pending
    if p and p.automaticWithinCap then
        if not session(p) then cancelQuote();self:Reset('Auction session changed.');W.Refresh();return end
        if event=='COMMODITY_PRICE_UPDATED' then
            if self.state~='QUOTE_WAITING' then return end
            if now()>p.authorizationExpires then cancelQuote();self:Reset('The order timed out. No new purchase was sent.');W.Refresh();return end
            if not valid(total,1) or not valid(unit,1) then cancelQuote();self:Reset('The Auction House returned an invalid price.');W.Refresh();return end
            local ok,duration=W.SafeCall(W.Compat.auction.GetQuoteDurationRemaining)
            if not ok or not W.Math.ValidNumber(duration) or duration<=0 then
                cancelQuote();self:Reset('This quote expired. Try the purchase again.');W.Refresh();return
            end
            self.quote={total=total,unit=unit,at=W.Clock()}
            if total>p.originalMax then
                self.state='PRICE_CHANGED';self.message='The price increased beyond your limit. Nothing has been bought.'
                cancelQuote();W.Notify(self.message);W.Refresh();return
            end
            if not affordable(total) then cancelQuote();self:Reset('Not enough gold for this purchase.');W.Refresh();return end
            -- Consume authorization BEFORE calling: synchronous and duplicate events
            -- cannot trigger a second purchase. No retry after a submitted purchase.
            self.state='PURCHASE_WAITING';p.submitted=true;self.purchaseSentAt=now()
            self.message='Purchase submitted. Waiting for confirmation.'
            local good,err=W.SafeCall(W.Compat.auction.ConfirmCommoditiesPurchase,p.itemID,p.quantity)
            if not good then
                self:Reset('The client blocked this purchase. Use Blizzard view; no automatic retry.')
                W.Diagnostics:Record('WARN','Commodity confirmation: '..tostring(err))
                W.RestoreBlizzard('Commodity confirmation rejected.')
            end
        elseif event=='COMMODITY_PRICE_UNAVAILABLE' and self.state=='QUOTE_WAITING' then
            cancelQuote();self:Reset('Those offers changed. Refresh offers and click Buy again.')
        elseif event=='COMMODITY_PURCHASE_SUCCEEDED' and self.state=='PURCHASE_WAITING' then
            self.lastAction={kind='BUY_COMMODITY',status='SERVER_SUCCESS_EVENT',itemID=p.itemID,
                quantity=p.quantity,total=self.quote and self.quote.total,at=W.Clock()}
            self:Reset('Purchase complete. Collect your items from the mailbox.');W.Notify(self.message)
            if W.UI and W.UI.ClearTradeInputs then W.UI:ClearTradeInputs('BUY')end
            W.Inventory:MarkDirty();W.Targeted.state='STALE'
        elseif event=='COMMODITY_PURCHASE_FAILED' and self.state=='PURCHASE_WAITING' then
            self:Reset('The purchase did not complete. Refresh offers before trying again.');W.Notify(self.message)
        elseif event=='AUCTION_HOUSE_SHOW_ERROR' then
            cancelQuote();self:Reset('The Auction House reported an error. Refresh and try again.');W.Notify(self.message)
        end
        W.Refresh();return
    end
    return oldEvent(self,event,unit,total)
end
local closed=A.Closed
function A:Closed()
    if self.pending and self.pending.automaticWithinCap and self.state~='PURCHASE_WAITING' then cancelQuote() end
    return closed(self)
end
function A:Tick()
    if self.state=='QUOTE_WAITING' and self.pending and self.pending.automaticWithinCap and now()>self.pending.authorizationExpires then
        cancelQuote();self:Reset('The quote timed out. No purchase was submitted.');W.Refresh()
    elseif self.state=='PURCHASE_WAITING' and now()-(self.purchaseSentAt or now())>15 then
        self:Reset('Purchase result not received. Check mail and gold before trying again.');W.Notify(self.message);W.Refresh()
    elseif self.state=='POST_WAITING' and now()-(self.postSentAt or now())>15 then
        self:Reset('Listing result not received. Refresh My auctions before posting again.');W.Notify(self.message);W.Refresh()
    end
end


-- G9: an unknown server result must not turn into an invitation to repeat a
-- money-moving action. The hold is additive character data, not an inferred
-- purchase or sale. It persists through /reload and ordinary game saves.
function A:Unverified()
    if type(self.unverified)=='table' then return self.unverified end
    local character=W.Storage and W.Storage.character
    local record=character and character.g9UnverifiedTransaction
    if type(record)=='table' and (record.kind=='PURCHASE' or record.kind=='POST') and
        valid(record.at,1) and (record.itemID==nil or valid(record.itemID,1,999999999)) then
        self.unverified=record
    end
    return self.unverified
end
function A:HoldUnverified(kind,p)
    if not p or (kind~='PURCHASE' and kind~='POST') then return end
    local record={kind=kind,itemID=valid(p.itemID,1,999999999) and p.itemID or nil,
        quantity=valid(p.quantity,1) and p.quantity or nil,at=W.Clock(),
        marketKey=type(p.marketKey)=='string' and p.marketKey:sub(1,180) or nil}
    self.unverified=record
    if W.Storage and W.Storage:IsWritable() and type(W.Storage.character)=='table' then
        W.Storage.character.g9UnverifiedTransaction=record
    end
    W.Diagnostics:Record('WARN','Transaction acknowledgement missing; player verification required before another WealthCraft trade')
end
function A:ClearUnverified()
    if self.state~='IDLE' then return false,'Close the current transaction first.' end
    if not self:Unverified() then return false,'No transaction needs checking.' end
    if not W.Storage:IsWritable() then return false,'Saved data is read only.' end
    -- This must be called by the explicit Settings/Diagnostics user button,
    -- after the player checks My auctions or mail/gold. No event timer clears it.
    self.unverified=nil
    if W.Storage.character then W.Storage.character.g9UnverifiedTransaction=nil end
    W.Diagnostics:Record('INFO','Player acknowledged checking the uncertain auction outcome')
    W.Refresh();return true,'Status checked. You may review another auction action.'
end
local previousGuard=A.Guard
function A:Guard(allowPending)
    if not allowPending and self:Unverified() then
        local rec=self:Unverified()
        local where=rec.kind=='POST' and 'My auctions' or 'mail and your gold'
        return false,'The last action has no confirmed result. Check '..where..', then select Mark checked in Settings > Diagnostics.'
    end
    return previousGuard(self,allowPending)
end
local previousTick=A.Tick
function A:Tick()
    local p=self.pending
    if p and self.state=='PURCHASE_WAITING' and
        now()-(self.purchaseSentAt or now())>15 then self:HoldUnverified('PURCHASE',p)
    elseif p and self.state=='POST_WAITING' and
        now()-(self.postSentAt or now())>15 then self:HoldUnverified('POST',p) end
    return previousTick(self)
end
local previousClosed=A.Closed
function A:Closed()
    -- Closing the panel/session is not proof that a submitted action failed.
    local p=self.pending
    if p and self.state=='PURCHASE_WAITING' then self:HoldUnverified('PURCHASE',p)
    elseif p and self.state=='POST_WAITING' then self:HoldUnverified('POST',p) end
    return previousClosed(self)
end
