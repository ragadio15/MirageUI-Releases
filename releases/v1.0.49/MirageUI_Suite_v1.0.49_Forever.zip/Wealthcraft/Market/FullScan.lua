-- G4: bounded replication; the cache is asynchronous. Exact-identity partial samples never replace completed scans.
-- The replication event is SHARED between addons; temporal association is not ownership proof.
local _, W = ...
W.Scan = {
    state = 'IDLE', message = 'No full scan run', eventAssociation = 'NOT_EVALUATED',
    expected = nil, processed = 0, handled = 0, unresolved = 0, invalid = 0,
    ambiguous = 0, bidOnly = 0, precise = 0, eventCount = 0,
    batchSize = 280, requestTimeout = 50, totalTimeout = 360,
    maxRows = 500000, maxPending = 500000, retryLimit = 6,
}
local S = W.Scan
local COOLDOWN = 900
local function mono() return type(GetTime) == 'function' and GetTime() or 0 end
local function budgetExpired(start)
    if not start or type(debugprofilestop) ~= 'function' then return false end
    local ok, current = pcall(debugprofilestop)
    return ok and type(current) == 'number' and current - start >= 1.7
end
local function startBudget()
    if type(debugprofilestop) ~= 'function' then return nil end
    local ok, v = pcall(debugprofilestop)
    return ok and v or nil
end
local function validPrice(value)
    return W.Math.ValidInteger(value, 0, 9007199254740991)
end
function S:IsActive()
    return self.state == 'REQUESTED' or self.state == 'READING' or
        self.state == 'RESOLVING' or self.state == 'INDEXING' or self.state == 'FINALIZING' or self.state == 'COMMITTING'
end
-- A full replication result is a snapshot-like, shared client buffer. The
-- user may search while we pause our local row work. To resume we verify the
-- buffer size and several previously cached anchor rows; otherwise we abandon
-- the interrupted read rather than mix incompatible market observations.
function S:AnchorRows()
    local anchors,seen={},{}
    if not self.expected or self.expected<1 then return anchors end
    for _,index in ipairs({0,math.floor(self.expected/2),self.expected-1,
        math.max(0,(self.nextIndex or 1)-1)}) do
        if index<self.expected and not seen[index] then
            seen[index]=true
            local ok,_,_,qty,_,_,_,_,_,_,buyout,_,_,_,_,_,_,itemID,complete=
                pcall(W.Compat.auction.GetReplicateItemInfo,index)
            if ok and complete==true and W.Math.ValidInteger(itemID,1,999999999) and
                W.Math.ValidInteger(qty,1,100000000) and validPrice(buyout) then
                local linkOk,link=pcall(W.Compat.auction.GetReplicateItemLink,index)
                anchors[#anchors+1]={index=index,itemID=itemID,qty=qty,buyout=buyout,
                    link=linkOk and type(link)=='string' and link~='' and link or nil}
            end
        end
    end
    return anchors
end
function S:PauseForManual()
    if self.state=='COMMITTING' or not self:IsActive() then return false end
    if self.pausedForUser then self.resumeCheckAt=mono()+2;return true end
    self.pausedForUser=true;self.pauseStarted=mono();self.resumeCheckAt=mono()+2
    self.pauseSession=self.requestSession
    self.pauseAnchors=self:AnchorRows()
    W.Scheduler:Cancel()
    if #self.pauseAnchors==0 then
        self:Stop('PARTIAL','REPLICATION_BUFFER_UNVERIFIED_AFTER_SEARCH')
        return true
    end
    if not self.pauseFrame then
        local frame=CreateFrame('Frame')
        local elapsed=0
        frame:SetScript('OnUpdate',function(_,dt)
            elapsed=elapsed+dt
            if elapsed>=0.25 then elapsed=0;S:TryResume()end
        end)
        self.pauseFrame=frame
    end
    self.pauseFrame:Show()
    self.message='Paused for your search; market data will be checked before resuming.'
    W.Diagnostics:Record('INFO','Paused full-market read for player search')
    W.Refresh()
    return true
end
function S:TryResume()
    if not self.pausedForUser then return false end
    if not W.runtime.ahOpen or self.pauseSession~=W.runtime.ahSession then
        self:Stop('CANCELLED','AUCTION_SESSION_CHANGED_WHILE_PAUSED');return false
    end
    if mono()-(self.pauseStarted or mono())>180 then
        self:Stop('PARTIAL','FOREGROUND_PAUSE_TIMEOUT');return false
    end
    if (W.Targeted and W.Targeted:IsActive()) or
        (W.Browse and W.Browse.state=='REQUESTED') or
        (W.Owned and W.Owned.state=='REQUESTED') or
        (W.Trading and W.Trading.state~='IDLE') or W.Scheduler.active then
        self.resumeCheckAt=mono()+2
        return false
    end
    if W.Priority:ReviewRemaining()>0 or mono()<(self.resumeCheckAt or 0) then return false end
    if not self.expected or not self.pauseAnchors or #self.pauseAnchors==0 then
        -- Replication may have arrived after the foreground query started. In
        -- that case the original buffer cannot be reliably identified.
        self:Stop('PARTIAL','REPLICATION_BUFFER_UNVERIFIED_AFTER_SEARCH')
        return false
    end
    local a=W.Compat.auction
    local counted,count=pcall(a.GetNumReplicateItems)
    if not counted or count~=self.expected then
        self:Stop('PARTIAL','REPLICATION_BUFFER_CHANGED_DURING_SEARCH')
        return false
    end
    for _,anchor in ipairs(self.pauseAnchors) do
        local ok,_,_,qty,_,_,_,_,_,_,buyout,_,_,_,_,_,_,itemID,complete=
            pcall(a.GetReplicateItemInfo,anchor.index)
        if not ok or complete~=true or itemID~=anchor.itemID or
            qty~=anchor.qty or buyout~=anchor.buyout then
            self:Stop('PARTIAL','REPLICATION_ANCHOR_CHANGED_DURING_SEARCH')
            return false
        end
        if anchor.link then
            local linkOk,currentLink=pcall(a.GetReplicateItemLink,anchor.index)
            if not linkOk or currentLink~=anchor.link then
                self:Stop('PARTIAL','REPLICATION_LINK_IDENTITY_CHANGED_DURING_SEARCH')
                return false
            end
        end
    end
    local suspended=mono()-(self.pauseStarted or mono())
    self.requestStarted=self.requestStarted+suspended
    if self.resolveWaitAt then self.resolveWaitAt=self.resolveWaitAt+suspended end
    if self.nextRetryAt then self.nextRetryAt=self.nextRetryAt+suspended end
    if self.finalizationStarted then self.finalizationStarted=self.finalizationStarted+suspended end
    self.pausedForUser=false;self.pauseAnchors=nil;self.pauseStarted=nil
    self.resumeCount=(self.resumeCount or 0)+1
    if self.pauseFrame then self.pauseFrame:Hide()end
    self.message='Continuing your full-market scan.'
    if not W.Scheduler:Start(function()return S:Tick()end) then
        self:Stop('PARTIAL','SCAN_RESUME_SCHEDULER_UNAVAILABLE');return false
    end
    W.Diagnostics:Record('INFO','Resumed validated replication buffer after player search')
    W.Refresh()
    return true
end
function S:Eligibility(preemptQuick)
    local quick=preemptQuick and W.QuickTarget and W.QuickTarget:IsActive() and
        W.Browse.state~='REQUESTED' and W.Owned.state~='REQUESTED' and W.Trading.state=='IDLE'
    if W.QueryBusy and W.QueryBusy('scan') and not quick then return false,'Finish the current query or transaction review first.' end
    if not W.Storage:IsWritable() then return false, 'SavedVariables are not writable.' end
    local ok, reason = W.Compat:CanScan()
    if not ok then return false, reason end
    if not W.runtime.ahOpen then return false, 'Open the native Auction House first.' end
    if type(InCombatLockdown) == 'function' and InCombatLockdown() then
        return false, 'Unavailable during combat.'
    end
    if self:IsActive() then return false, 'A scan is already in progress.' end
    if W.Targeted and W.Targeted:IsActive() and not quick then return false, 'Finish targeted search first.' end
    local scope = W.Scope:Snapshot()
    if not scope.ready then
        return false, scope.reason or 'Preparing the current Auction House visit.'
    end
    local now, last = W.Clock(), W.Storage:LastRequestTime()
    if now <= 0 then return false, 'Server clock is unavailable.' end
    if type(last) == 'number' and last > now then return false, 'Saved request time is in the future.' end
    if type(last) == 'number' and last > 0 and now - last < COOLDOWN then
        return false, ('Local 15-minute scan guard: %d min remaining.'):format(
            math.ceil((COOLDOWN - (now - last)) / 60))
    end
    if W.Compat.APIs.IsThrottledMessageSystemReady then
        local good, ready = pcall(W.Compat.auction.IsThrottledMessageSystemReady)
        if not good or ready ~= true then return false, 'Auction service busy; another addon may have used its query quota.' end
    end
    return true, 'Ready for a full market refresh.'
end
function S:Request(origin)
    if W.QuickScan then W.QuickScan:Yield(origin=='AUTO_AH_OPEN' and 'Full market refresh' or 'Player request',true) end
    local eligible, reason = self:Eligibility()
    if not eligible then
        W.Diagnostics:Record('WARN', 'Full scan blocked: ' .. tostring(reason))
        return false, reason
    end
    local scope = W.Scope:Snapshot()
    self.generation = (self.generation or 0) + 1
    self.scope = scope
    self.origin = origin or 'PLAYER'
    self.requestSession = W.runtime.ahSession
    self.requestStarted = mono()
    self.requestAt = W.Clock()
    self.expected = nil
    self.processed, self.handled, self.invalid = 0, 0, 0
    self.ambiguous, self.precise, self.bidOnly = 0, 0, 0
    self.eventCount, self.unresolved = 0, 0
    self.eventAssociation = 'TEMPORALLY_ASSOCIATED_SHARED_EVENT_NOT_EXCLUSIVE'
    self.groups, self.pending = {}, {}
    self.nextIndex = 0
    self.retries = 0
    self.initialPending=0;self.recovered=0;self.readCalls=0;self.resumeCount=0
    self.cachePasses={};self.maxSliceMS=0;self.stalledPasses=0;self.lastPendingCount=nil
    self.resolveWaitAt=nil;self.metadataWaitSeconds=210
    if W.ItemCache then W.ItemCache:Reset() end
    self.partialMode = false
    self.pausedForUser=false;self.pauseAnchors=nil;self.pauseStarted=nil
    self.lastResult = nil
    self.state = 'REQUESTED'
    self.message = 'Waiting for replication event; no automatic retry.'
    -- Consume our local guard before the call: even a Lua error may have reached the server.
    W.Storage:GuardAttempt()
    local good, err = pcall(W.Compat.auction.ReplicateItems)
    if not good then
        self:Stop('INVALID', 'REPLICATION_API_REJECTED: ' .. tostring(err))
        return false, self.message
    end
    W.Diagnostics:Record('INFO', (self.origin=='AUTO_AH_OPEN' and 'Automatic' or 'Manual')..' full replication issued; shared response provenance unverified')
    if self:IsActive() and not W.Scheduler.active then
        local started = W.Scheduler:Start(function() return S:Tick() end)
        if not started then self:Stop('INVALID', 'SCHEDULER_UNAVAILABLE'); return false, self.message end
    end
    W.Refresh()
    return true
end
function S:OnUpdateEvent()
    if not W.runtime.ahOpen then return end
    if not self:IsActive() then return end
    if self.requestSession ~= W.runtime.ahSession then
        self:Stop('CANCELLED', 'AH_SESSION_CHANGED')
        return
    end
    self.eventCount = self.eventCount + 1
    if self.state ~= 'REQUESTED' then return end
    local ok, count = pcall(W.Compat.auction.GetNumReplicateItems)
    if not ok or not W.Math.ValidInteger(count, 0, self.maxRows) then
        self:Stop('INVALID', 'INVALID_REPLICATE_COUNT')
        return
    end
    if count == 0 then
        -- Some clients can report an empty/unready buffer before population.
        self.message = 'Replication event seen; waiting for nonempty item list.'
        return
    end
    self.expected = count
    self.state = 'READING'
    self.message = 'Reading auction rows in bounded frame slices.'
    W.Diagnostics:Record('INFO', ('Replication event #%d, %d rows to read'):
        format(self.eventCount, count))
end
function S:ReadRow(index)
    -- API exposes 0-based indices, unlike standard WoW Lua arrays.
    local ok, name, texture, count, qualityID, usable, level, levelType,
        minBid, minIncrement, buyout, bidAmount, highBidder, bidderFullName,
        owner, ownerFullName, saleStatus, itemID, hasAllInfo =
        pcall(W.Compat.auction.GetReplicateItemInfo, index)
    self.readCalls=(self.readCalls or 0)+1
    if not ok or hasAllInfo ~= true then
        if W.ItemCache then W.ItemCache:Queue(itemID) end
        return false, 'NOT_CACHED'
    end
    if not W.Math.ValidInteger(count, 1, 100000000) or
        not W.Math.ValidInteger(itemID, 1, 999999999) or
        not validPrice(buyout) or not validPrice(minBid or 0) or
        not validPrice(bidAmount or 0) then
        return false, 'INVALID_ROW'
    end
    local linkOk, link = pcall(W.Compat.auction.GetReplicateItemLink, index)
    local identity
    if not linkOk or type(link)~='string' or link=='' then
        if W.ItemCache then W.ItemCache:Queue(itemID) end
        return false,'NOT_CACHED'
    end
    if linkOk then identity = W.Identity:FromLink(link, itemID) end
    if not identity then
        self.ambiguous = self.ambiguous + 1
        -- This listing is handled but cannot contaminate a precise item-variant price.
    else
        self.precise = self.precise + 1
        local display = type(name) == 'string' and name:gsub('|', ''):sub(1, 86) or ('Item ' .. itemID)
        W.Prices:Add(self.groups, {
            identity = identity, itemID = itemID, name = display,
            count = count, buyout = buyout,
        })
    end
    if buyout == 0 then self.bidOnly = self.bidOnly + 1 end
    self.handled = self.handled + 1
    return true
end
function S:GuardLive()
    if not W.runtime.ahOpen or W.runtime.ahSession ~= self.requestSession then
        self:Stop('CANCELLED', 'AH_CLOSED_OR_SESSION_CHANGED'); return false
    end
    local currentScope = W.Scope:Snapshot()
    if not currentScope.ready or currentScope.key ~= self.scope.key then
        self:Stop('CANCELLED', 'MARKET_SCOPE_CHANGED'); return false
    end
    if type(InCombatLockdown) == 'function' and InCombatLockdown() then
        self:Stop('CANCELLED', 'COMBAT_INTERRUPTED'); return false
    end
    local elapsed = mono() - self.requestStarted
    if elapsed > self.totalTimeout then
        if self.state == 'INDEXING' or self.state == 'FINALIZING' then
            if mono() - (self.finalizationStarted or mono()) > 90 then
                self:Stop('PARTIAL', 'FINALIZATION_TIMEOUT'); return false
            end
        elseif self.precise > 0 and self.invalid == 0 and self.expected then
            -- A slow client must not lose an entire available exact-link sample.
            -- Include unvisited indices in unresolved count. Never call it complete.
            self.unresolved = math.max(1, self.expected - self.handled)
            self.partialMode = true
            self:BeginFinalization()
        else
            self:Stop('PARTIAL', 'SCAN_TIMEOUT_NO_EXACT_SAMPLE'); return false
        end
    end
    return true
end

-- P39-F: truthful progress for the five native scan stages. All counters are
-- local to the active session; this is not evidence of entire market depth.
function S:Progress()
    local state=self.state
    local progress={contract=1,state=state,session=self.requestSession,
        phase=state,processed=self.processed or 0,handled=self.handled or 0,
        expected=self.expected,precise=self.precise or 0,invalid=self.invalid or 0,
        metadataPasses=self.retries or 0,metadataLimit=self.retryLimit,
        resumed=self.resumeCount or 0,partial=self.partialMode==true,
        association=self.eventAssociation or 'NOT_EVALUATED'}
    if state=='REQUESTED' then
        progress.label='Waiting for the Auction House snapshot'
    elseif state=='READING' then
        progress.label='Reading returned listings'
        progress.done=self.nextIndex or 0;progress.total=self.expected
    elseif state=='RESOLVING' then
        local left=math.max(0,(#(self.retryList or {})-(self.retryPos or 1)+1)+#(self.pending or {}))
        progress.label='Loading item details';progress.pendingRows=left
        progress.done=math.max(0,(self.initialPending or 0)-left)
        progress.total=self.initialPending or 0
        local cache=W.ItemCache and W.ItemCache:Progress()
        if cache then progress.metadataQueued=cache.queued;progress.metadataAwaiting=cache.requested end
    elseif state=='INDEXING' then
        progress.label='Organizing observed item variants'
        progress.done=#(self.groupKeys or {})
    elseif state=='FINALIZING' then
        progress.label='Calculating observed market references'
        progress.done=math.max(0,(self.finalizePos or 1)-1)
        progress.total=#(self.groupKeys or {})
    elseif state=='COMPLETE' then progress.label='Full scan saved'
    elseif state=='PARTIAL' then progress.label='Partial observation saved; market depth unknown'
    elseif state=='CANCELLED' then progress.label='Full scan stopped; saved data retained'
    else progress.label=self.message or 'No full scan running' end
    if self.pausedForUser then progress.label='Full scan paused for your search' end
    return progress
end
function S:MaybeRefresh()
    local t = mono()
    if t - (self.lastUIRefresh or -99) >= 0.35 then
        self.lastUIRefresh = t
        W.Refresh()
    end
end
function S:Tick()
    if not self:IsActive() then return true end
    if self.pausedForUser then return false end
    if not self:GuardLive() then return true end
    if self.state == 'REQUESTED' then
        if mono() - self.requestStarted > self.requestTimeout then
            self:Stop('PARTIAL', 'NO_REPLICATION_RESULT_EVENT'); return true
        end
        return false
    end
    local budget, steps = startBudget(), 0
    if W.ItemCache then W.ItemCache:Tick() end
    if self.state == 'READING' then
        while self.nextIndex < self.expected and steps < self.batchSize and not budgetExpired(budget) do
            local ok, reason = self:ReadRow(self.nextIndex)
            if not ok then
                if reason == 'NOT_CACHED' then
                    self.pending[#self.pending + 1] = self.nextIndex
                    -- Do not abort at 25,000 uncached rows. The live realm may expose
                    -- hundreds of thousands of auctions with delayed item metadata.
                    -- Keep indices only; never allocate a whole raw record per row.
                    if #self.pending > self.maxPending then
                        self:Stop('PARTIAL', 'REPLICATION_ROW_SAFETY_LIMIT'); return true
                    end
                else
                    self.invalid = self.invalid + 1
                end
            end
            self.nextIndex = self.nextIndex + 1
            self.processed = self.processed + 1
            steps = steps + 1
        end
        if self.nextIndex >= self.expected then
            if #self.pending > 0 then
                self.state = 'RESOLVING'
                self.initialPending=#self.pending
                self.retryList, self.retryPos, self.pending = self.pending, 1, {}
                self.nextRetryAt = mono() + 3
                self.resolveWaitAt = mono()
                self.message = ('Resolving %d uncached rows; exact links required for price records.'):format(#self.retryList)
            else
                self:BeginFinalization()
            end
        end
    elseif self.state == 'RESOLVING' then
        -- Avoid re-reading tens of thousands of identical uncached indices while
        -- their deduplicated item-ID requests are still in the queue. The wait is
        -- bounded by both the scan deadline and a separate cache-wait ceiling.
        if self.retries == 0 and self.retryPos == 1 and W.ItemCache then
            local cache = W.ItemCache:Progress()
            local elapsed = mono() - (self.resolveWaitAt or mono())
            local left = self.totalTimeout - (mono()-self.requestStarted)
            if (cache.queued > 0 or cache.requested > 0) and
                elapsed < (self.metadataWaitSeconds or 210) and left > 50 then
                self.message = ('Loading item details · %d queued, %d awaiting results.'):format(
                    cache.queued,cache.requested)
                self:MaybeRefresh()
                return false
            end
        end
        if self.retries >= self.retryLimit-1 and self.retryPos == 1 and W.ItemCache then
            local progress=W.ItemCache:Progress()
            local age=mono()-self.requestStarted
            if age < self.totalTimeout-25 and (progress.queued>0 or
                (progress.requested>0 and age < self.totalTimeout-35)) then
                self.message='Finishing item details before the final recovery pass.'
                self:MaybeRefresh()
                return false
            end
        end
        if mono() < self.nextRetryAt then return false end
        while self.retryPos <= #self.retryList and steps < self.batchSize and not budgetExpired(budget) do
            local i = self.retryList[self.retryPos]
            local ok, reason = self:ReadRow(i)
            if not ok then
                if reason == 'NOT_CACHED' then self.pending[#self.pending + 1] = i
                else self.invalid = self.invalid + 1 end
            end
            self.retryPos = self.retryPos + 1
            steps = steps + 1
        end
        if self.retryPos > #self.retryList then
            self.retries = self.retries + 1
            self.recovered=math.max(0,(self.initialPending or 0)-#self.pending)
            self.cachePasses[#self.cachePasses+1]={pass=self.retries,remaining=#self.pending,at=W.Clock()}
            local cache = W.ItemCache and W.ItemCache:Progress()
            local cacheDrained = not cache or (cache.queued == 0 and cache.requested == 0)
            if self.lastPendingCount and #self.pending >= self.lastPendingCount and cacheDrained then
                self.stalledPasses=(self.stalledPasses or 0)+1
            else
                self.stalledPasses=0
            end
            self.lastPendingCount=#self.pending
            if #self.pending == 0 then self:BeginFinalization()
            elseif self.retries >= self.retryLimit or (cacheDrained and self.stalledPasses>=2) then
                self.unresolved = #self.pending
                -- Exact-variant rows that *did* resolve can still be useful. Commit
                -- them in a separate explicitly PARTIAL bucket, never as depth.
                if self.precise > 0 and self.invalid == 0 then
                    self.partialMode = true
                    self:BeginFinalization()
                else
                    self:Stop('PARTIAL', 'UNCACHED_ROWS_REMAIN')
                    return true
                end
            else
                self.retryList, self.retryPos, self.pending = self.pending, 1, {}
                self.nextRetryAt = mono() + math.min(12,3*self.retries)
                self.message=('Loading item details: %d rows left; %d recovered. Pass %d/%d.'):format(
                    #self.retryList,self.recovered,self.retries+1,self.retryLimit)
            end
        end
    elseif self.state == 'INDEXING' then
        -- Build the group-key index incrementally; never traverse a 100k-item map in one frame.
        while steps < self.batchSize and not budgetExpired(budget) do
            local key = next(self.groups, self.groupCursor)
            if not key then
                if #self.groupKeys == 0 then
                    self:Stop('PARTIAL', 'NO_PRECISE_VARIANTS'); return true
                end
                self.candidate.preciseCount = #self.groupKeys
                self.state = 'FINALIZING'
                self.message = 'Calculating quantity-weighted references in bounded slices.'
                break
            end
            self.groupCursor = key
            self.groupKeys[#self.groupKeys + 1] = key
            if #self.groupKeys > 100000 then
                self:Stop('PARTIAL', 'TOO_MANY_VARIANTS'); return true
            end
            steps = steps + 1
        end
    elseif self.state == 'FINALIZING' then
        while self.finalizePos <= #self.groupKeys and steps < 40 and not budgetExpired(budget) do
            local key = self.groupKeys[self.finalizePos]
            local priced=W.Prices:Finalize(self.groups[key])
            self.candidate.items[key]=priced
            if W.MarketPulse and self.candidate.g13Accumulator then
                W.MarketPulse:AddFinalized(self.candidate.g13Accumulator,priced)
            end
            self.finalizePos = self.finalizePos + 1
            steps = steps + 1
        end
        if self.finalizePos > #self.groupKeys then
            self:Complete()
            return true
        end
    end
    if budget then
        local now=startBudget()
        if now then
            local spent=math.max(0,now-budget)
            self.maxSliceMS=math.max(self.maxSliceMS or 0,spent)
            -- Adjust only bounded row-processing work; cap well below the
            -- documented ~2000 replicate-info calls/frame stress threshold.
            if steps>0 and (self.state=='READING' or self.state=='RESOLVING') then
                if spent>2.2 then self.batchSize=math.max(120,math.floor(self.batchSize*0.75))
                elseif spent<0.85 and steps>=self.batchSize then self.batchSize=math.min(480,self.batchSize+20) end
            end
        end
    end
    self:MaybeRefresh()
    return not self:IsActive()
end
function S:BeginFinalization()
    if self.invalid > 0 or (not self.partialMode and self.handled ~= self.expected) then
        self:Stop('PARTIAL', 'INVALID_OR_UNRESOLVED_AUCTIONS'); return
    end
    local ok, count = pcall(W.Compat.auction.GetNumReplicateItems)
    if not ok or count ~= self.expected then
        self:Stop('PARTIAL', 'REPLICATION_COUNT_CHANGED'); return
    end
    if self.precise == 0 then
        self:Stop('PARTIAL', 'NO_PRECISE_ITEM_LINKS'); return
    end
    self.groupKeys = {}
    self.groupCursor = nil
    self.finalizePos = 1
    self.candidate = {
        g13Accumulator=W.MarketPulse and W.MarketPulse:BeginSummary() or nil,
        id = ('%d-%d-%d'):format(self.requestAt, self.requestSession, self.generation),
        startedAt = self.requestAt, finishedAt = W.Clock(),
        count = self.expected, handled = self.handled, unresolved = self.unresolved or 0, invalid = 0,
        ambiguous = self.ambiguous, bidOnly = self.bidOnly, preciseCount = 0, preciseRows = self.precise,
        venueStatus = self.scope.status, source = self.origin=='AUTO_AH_OPEN' and 'AUTO_AH_OPEN_REPLICATION' or 'PLAYER_REQUESTED_REPLICATION',
        eventAssociation = self.eventAssociation,
        status = self.partialMode and 'PARTIAL_COVERAGE' or 'COMPLETE', items = {},
        cacheRecovery={initialPending=self.initialPending,recovered=self.recovered,
            passes=self.retries,readCalls=self.readCalls,
            metadata=W.ItemCache and W.ItemCache:Progress() or nil,
            itemRequests=W.ItemCache and W.ItemCache.requests or 0,
            maxSliceMS=self.maxSliceMS or 0},
    }
    self.state = 'INDEXING'
    self.finalizationStarted = mono()
    self.message = 'Building an index of observed item variants.'
end
function S:Complete()
    if not self:GuardLive() then return end
    self.pausedForUser=false;self.pauseAnchors=nil
    if self.pauseFrame then self.pauseFrame:Hide()end
    self.candidate.finishedAt = W.Clock()
    if W.MarketPulse and self.candidate.g13Accumulator then
        self.candidate.g13Stats=W.MarketPulse:FinishSummary(self.candidate,self.candidate.g13Accumulator)
        self.candidate.g13Accumulator=nil
    end
    if self.candidate.cacheRecovery then self.candidate.cacheRecovery.maxSliceMS=self.maxSliceMS end
    local partial = self.partialMode == true
    local job,candidate=W.Scheduler.generation,self.candidate
    self.state='COMMITTING'
    local ok, reason
    if partial then
        ok, reason = W.Storage:CommitPartial(self.scope, self.candidate)
    else
        ok, reason = W.Storage:CommitSnapshot(self.scope, self.candidate)
    end
    if self.state~='COMMITTING' or self.candidate~=candidate or W.Scheduler.generation~=job then return end
    if not ok then self:Stop('INVALID', 'ATOMIC_COMMIT_BLOCKED: ' .. tostring(reason)); return end
    self.state = partial and 'PARTIAL' or 'COMPLETE'
    if partial then
        self.message = ('Partial sample saved: %d exact rows, %d uncached / %d expected. Not market depth.'):
            format(self.precise, self.unresolved, self.expected)
    else
        self.message = ('Saved %d listings; %d variant groups; %d rows lacked precise links.'):
            format(self.expected, #self.groupKeys, self.ambiguous)
    end
    self.lastResult = {status = self.state, count = self.expected, invalid = 0,
        ambiguous = self.ambiguous, unresolved = self.unresolved,
        at = W.Clock(), scopeKey = self.scope.key}
    self.groups, self.groupKeys, self.pending, self.retryList, self.candidate = nil, nil, nil, nil, nil
    W.Scheduler:Cancel()
    if W.ItemCache then W.ItemCache:Release() end
    W.Diagnostics:Record(partial and 'WARN' or 'INFO', self.message)
    W.Notify(partial and 'Partial sample saved. Use targeted searches for stronger item prices.' or
        'Full scan complete. Market estimates are observed listings, not sales.')
    W.Refresh()
end
function S:Stop(state, reason)
    local ownedScheduler=not self.pausedForUser
    self.pausedForUser=false;self.pauseAnchors=nil;self.pauseStarted=nil
    if self.pauseFrame then self.pauseFrame:Hide()end
    self.state = state
    self.message = tostring(reason)
    if self.unresolved == 0 then
        self.unresolved = self.pending and #self.pending or 0
    end
    self.lastResult = {status = state, reason = reason, count = self.expected,
        handled = self.handled, ambiguous = self.ambiguous, invalid = self.invalid,
        unresolved = self.unresolved, at = W.Clock()}
    -- A paused scan has already handed its scheduler to the foreground request.
    self.groups, self.pending, self.retryList, self.groupKeys, self.candidate = nil, nil, nil, nil, nil
    if ownedScheduler then W.Scheduler:Cancel() end
    if W.ItemCache then W.ItemCache:Release() end
    W.Diagnostics:Record(state == 'INVALID' and 'ERROR' or 'WARN', 'Full scan ' .. state .. ': ' .. tostring(reason))
    W.Refresh()
end
function S:Cancel()
    if not self:IsActive() then return false end
    self:Stop('CANCELLED', 'USER_CANCELLED')
    return true
end
function S:Closed()
    if self:IsActive() then self:Stop('CANCELLED', 'AH_CLOSED_OR_SESSION_CHANGED') end
end

local p39ScanTick=S.Tick
function S:Tick(...)
    local service,started=W.P39TraceBegin()
    local reads=self.readCalls or 0
    local result=p39ScanTick(self,...)
    W.P39TraceEnd(service,started,'wealth.replicate_slice')
    local delta=(self.readCalls or 0)-reads
    if service and delta>0 and type(service.Counter)=='function' then
        pcall(service.Counter,'wealth.replicate_read_calls',delta)
    end
    return result
end
