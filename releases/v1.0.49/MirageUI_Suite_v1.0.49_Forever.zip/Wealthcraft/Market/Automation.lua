-- Read-only visit automation. Context readiness is independent of query retries.
-- A missing client field can recover while the same auctioneer remains open.
local _,W=...
W.Automation={state='IDLE',elapsed=0}
local A=W.Automation
local function mono()return type(GetTime)=='function' and GetTime() or W.Clock()end
local function settings()return W.Storage.account and W.Storage.account.settings or {}end
function A:Enabled()return settings().autoScan~=false end
function A:ContextReason(scope)
    scope=scope or W.Scope:Snapshot()
    if scope.ready then return nil end
    if type(scope.reason)=='string' and scope.reason~='' then return scope.reason end
    if type(W.Scope.ReadinessReason)=='function' then
        local reason=W.Scope:ReadinessReason();if type(reason)=='string' and reason~='' then return reason end
    end
    return W.runtime.ahOpen and 'Waiting for current Auction House information' or 'Auction House is closed'
end
function A:Initialize()
    local api=_G.MirageIntelCoreAPI or _G.MirageIntel_API
    if type(api)=='table' and type(api.Subscribe)=='function' and not self.subscribed then
        local ok,result=pcall(api.Subscribe,'CHARACTER_CONTEXT_UPDATED','Wealthcraft',function(payload)
            local revision=type(payload)=='table' and payload.revision or nil
            -- A repeated notification for the same published revision must not
            -- cause another context read, bag valuation or bank scan.
            if revision~=nil and revision==A.lastContextRevision and
                W.PlayerContext.bagRecord~=nil then
                A.duplicateContextEvents=(A.duplicateContextEvents or 0)+1
                return
            end
            A.lastContextRevision=revision
            local nextBags=type(payload)=='table' and payload.bagsRevision or nil
            local nextBank=type(payload)=='table' and payload.bankRevision or nil
            local bagsChanged=nextBags~=A.lastBagsRevision or
                (type(payload)=='table' and payload.bagsCurrent~=true) or
                W.PlayerContext.bagRecord==nil
            local bankChanged=nextBank~=A.lastBankRevision or
                (type(payload)=='table' and payload.bankCurrent~=true)
            A.lastBagsRevision=nextBags;A.lastBankRevision=nextBank
            W.PlayerContext:Refresh()
            if bagsChanged then
                -- A pending shared scan is not a certified bag snapshot. Do
                -- not use the native fallback to mark stale data as current.
                local shared=W.PlayerContext.shared and W.PlayerContext.shared.bags
                if type(shared)=='table' and shared.current==true then
                    W.PlayerContext:ReadBags()
                end
                if W.Inventory then W.Inventory:MarkDirty() end
            end
            if W.runtime.bankOpen and bankChanged then W.PlayerContext:ReadBank() end
            A:ContextChanged('CHARACTER_CONTEXT_UPDATED')
            if bagsChanged and W.UI and W.UI.frame and W.UI.frame:IsShown() and
                (W.UI.activePage=='inventory' or W.UI.activePage=='sell') then W.UI.dirty=true end
        end)
        self.subscribed=ok and result~=false
    end
end
function A:InventoryEvent(reason,bank,professions)
    local api=_G.MirageIntelCoreAPI or _G.MirageIntel_API
    local bridged=self.subscribed==true and type(api)=='table' and
        type(api.GetCharacterRevision)=='function' and type(api.GetCharacterSnapshot)=='function' and
        type(api.GetCharacterContextEventSupport)=='function'
    if bridged then
        local ok,registered=pcall(api.GetCharacterContextEventSupport,reason)
        bridged=ok and registered==true
    end
    -- MirageIntel Core itself observes these events. A second explicit request
    -- for the identical native event needlessly invalidated work and bag data.
    -- Retain standalone fallback, including native bag and bank observations.
    if not bridged then
        W.PlayerContext:RequestRefresh(reason,bank,professions)
    else
        self.sharedEventReuses=(self.sharedEventReuses or 0)+1
    end
    local recipeOnly=reason=='TRADE_SKILL_LIST_UPDATE' or
        reason=='TRADE_SKILL_DATA_SOURCE_CHANGED' or reason=='SKILL_LINES_CHANGED' or
        reason=='NEW_RECIPE_LEARNED'
    if not recipeOnly and reason~='BAG_UPDATE_DELAYED' and W.Inventory then W.Inventory:MarkDirty()end
    if professions and W.Crafting and type(W.Crafting.OnProfessionEvent)=='function' then
        W.Crafting:OnProfessionEvent(reason)
    end
    self:ContextChanged(reason)
end
function A:Opened()
    self:Closed();self.session=W.runtime.ahSession;self.manualPaused=false;self.openedAt=mono();self.attempts=0
    self.state=self:Enabled() and settings().autoFullScan~=false and 'WAITING' or 'OFF'
    local last=W.Storage:LastRequestTime();local remain=type(last)=='number' and math.max(0,900-(W.Clock()-last)) or 0
    self.nextAt=mono()+math.max(2,remain+1);self.cooldownAt=remain>0 and self.nextAt or nil
    self.reason=nil;self.requestAttempted=false
    self:ContextChanged('AUCTION_HOUSE_SHOW')
    if self.state=='WAITING' or self.state=='WAIT_CONTEXT' then self:Wake()end
end
function A:Wake()
    if not self.frame then
        self.frame=CreateFrame('Frame');self.frame:SetScript('OnUpdate',function(_,dt)
            A.elapsed=A.elapsed+dt
            -- Waiting out a long full-scan guard needs no 2 Hz redraw or
            -- native query polling; a player search still takes priority.
            local wait=(A.state=='WAITING' or A.state=='WAIT_SERVICE') and (A.nextAt or 0)-mono()>10 and
                not (W.UI and W.UI.pendingSearch)
            if A.elapsed<(wait and 2 or .5) then return end;A.elapsed=0
            local ok=W.Try('automatic-market',A.Tick,A)
            if not ok then A.state='UNAVAILABLE';A.reason='Automatic refresh stopped after an error';A.frame:Hide()end
        end)
    end
    self.frame:Show()
end
function A:Closed()
    self.state='IDLE';self.session=nil;self.reason=nil;self.contextReady=nil;self.contextKey=nil
    self.waitKind=nil;self.waitStarted=nil;self.requestAttempted=false;self.manualPaused=false;self.pauseWasRunning=nil
    if self.frame then self.frame:Hide()end
end
function A:ContextChanged(event,scope)
    if not W.runtime.ahOpen then return end
    scope=scope or W.Scope:Snapshot()
    local wasReady=self.contextReady
    self.contextReady=scope.ready==true;self.contextKey=scope.key
    if self.session~=W.runtime.ahSession then return end
    if not scope.ready then
        if self.state=='WAITING' or self.state=='WAIT_CONTEXT' or
            (self.state=='UNAVAILABLE' and self.waitKind=='CONTEXT' and not self.requestAttempted) or
            (self.state=='WAIT_SERVICE' and not self.requestAttempted) then
            self.state='WAIT_CONTEXT';self.waitKind='CONTEXT';self.reason=self:ContextReason(scope)
            self.waitStarted=self.waitStarted or mono();self:Wake()
        end
    elseif self.state=='WAIT_CONTEXT' or
        (self.state=='UNAVAILABLE' and self.waitKind=='CONTEXT' and not self.requestAttempted) then
        self.state='WAITING';self.waitKind=nil;self.reason=nil;self.waitStarted=nil;self.attempts=0
        self.nextAt=math.max(mono()+.5,self.cooldownAt or 0);self:Wake()
    end
    if W.QuickScan and W.QuickScan.ContextChanged then W.QuickScan:ContextChanged(scope)end
    if W.UI and W.UI.pendingSearch then self:Wake()end
    if wasReady~=self.contextReady then W.Refresh()end
end
function A:IsUserPaused()
    return self.manualPaused==true and self.session==W.runtime.ahSession and W.runtime.ahOpen
end
function A:TogglePaused()
    if not W.runtime.ahOpen or self.session~=W.runtime.ahSession then
        return false,'Open an Auction House to control scans.'
    end
    if self:IsUserPaused() then
        W.Priority.reviewUntil=nil
        self.manualPaused=false
        if W.QuickScan then
            if W.QuickScan.state=='PAUSED' and W.QuickScan.pauseKind=='USER' then W.QuickScan:UserResume()
            elseif W.QuickScan.state=='IDLE' or W.QuickScan.state=='OFF' then W.QuickScan:UserRestart()end
        end
        if self.state=='PAUSED' then
            self.state=self.pauseWasRunning and 'OBSERVED' or (self:Enabled() and settings().autoFullScan~=false and 'WAITING' or 'OFF')
            if self.state=='WAITING' then self.nextAt=math.max(mono()+1,self.cooldownAt or 0);self:Wake()end
        end
        self.pauseWasRunning=nil
        W.Refresh();return true,'Scans resumed'
    end
    self.manualPaused=true;self.pauseWasRunning=self.state=='RUNNING'
    if W.Scan and W.Scan:IsActive() then
        -- Replication snapshots cannot be parked indefinitely. Stop safely;
        -- older committed market records remain intact. The 15m guard holds.
        W.Scan:Cancel()
    end
    if W.QuickScan then W.QuickScan:UserPause()end
    self.state='PAUSED';self.reason='Paused by you'
    if self.frame then self.frame:Hide()end
    W.Refresh();return true,'Scanning paused'
end
function A:UserScan(kind)
    if not W.runtime.ahOpen or self.session~=W.runtime.ahSession then
        return false,'Open an Auction House first.'
    end
    if not W.Storage:IsWritable() then return false,'Saved data is read only.'end
    if self:IsUserPaused() then self:TogglePaused()end
    if kind=='quick' then return W.QuickScan:UserRestart()end
    if kind~='full' then return false,'Choose a scan type.'end
    if W.Scan:IsActive() then return false,'A full market scan is already running.'end
    local allowed,reason=W.Scan:Eligibility(true)
    if not allowed then return false,reason end
    local ok,why=W.Scan:Request('USER_REQUESTED_REPLICATION')
    if ok then self.state='RUNNING';self.reason=nil;self.requestAttempted=true;self:Wake()end
    W.Refresh();return ok,why
end
function A:FullPending()
    if self:IsUserPaused() then return false end
    return self.state=='WAITING' and self.session==W.runtime.ahSession and self.contextReady~=false and
        (self.nextAt or math.huge)<=mono()+2 and self:Enabled() and
        not (W.UI and W.UI.pendingSearch)
end
function A:ManualRejected()
    if W.ScanCoordinator then W.ScanCoordinator:Rearm('MANUAL_REJECTED')end
    if self.state=='WAITING' and not (W.UI and W.UI.pendingSearch) then
        self.nextAt=math.max(mono()+.5,self.cooldownAt or 0)
    end
    self:ContextChanged('MANUAL_QUERY_REJECTED')
end
function A:ServiceReady()
    if not W.runtime.ahOpen or self.session~=W.runtime.ahSession then return end
    if (self.state=='WAIT_SERVICE' or (self.state=='UNAVAILABLE' and self.waitKind=='SERVICE')) and not self.requestAttempted then
        self.state='WAITING';self.waitKind=nil;self.reason=nil;self.attempts=0;self.nextAt=math.max(mono()+.5,self.cooldownAt or 0);self:Wake()
    end
    if W.QuickScan and W.QuickScan.ServiceReady then W.QuickScan:ServiceReady()end
    if W.ScanCoordinator then W.ScanCoordinator:Rearm('SERVICE_READY')end
    self:ContextChanged('AUCTION_SERVICE_READY')
end
function A:Tick()
    if self:IsUserPaused() then return end
    if not W.runtime.ahOpen or self.session~=W.runtime.ahSession then self:Closed();return end
    local scope=W.Scope:Snapshot();self:ContextChanged('CONTEXT_RECHECK',scope)
    -- A queued foreground read is authorized by its original click, and is
    -- serviced even when the player disables background market scans.
    if W.UI and W.UI.pendingSearch and W.UI.TryPendingSearch then
        W.UI:TryPendingSearch(scope)
        if W.UI.pendingSearch then return end
    end
    -- A manually requested full scan still needs completion handling when
    -- the account's automatic-full-snapshot preference is disabled.
    if self.state=='RUNNING' then
        if W.Scan:IsActive() then return end
        self.state=W.Scan.state=='COMPLETE' and 'COMPLETE' or 'OBSERVED';self.reason=W.Scan.message
        if self.frame then self.frame:Hide()end
        if W.QuickScan:Enabled() then W.QuickScan:Opened()end
        W.Refresh();return
    end
    if not self:Enabled() or settings().autoFullScan==false then
        self.state='OFF';if self.frame then self.frame:Hide()end;return
    end
    if type(InCombatLockdown)=='function' and InCombatLockdown() then self.reason='Waiting until combat ends';return end
    if not scope.ready then return end
    if self.state~='WAITING' and self.state~='WAIT_SERVICE' then return end
    if W.Priority:ReviewRemaining()>0 or mono()<(self.nextAt or 0) then return end
    self.state='WAITING'
    self.cooldownAt=nil
    if W.QueryBusy() or W.Scheduler.active then self.reason='Waiting for your current Auction House request';self.nextAt=mono()+3;return end
    local can,reason=W.Scan:Eligibility()
    if not can then
        -- Metadata may change inside an eligibility callback. Do not spend a
        -- service retry or require a new visit for a local information wait.
        local current=W.Scope:Snapshot()
        if not current.ready then self:ContextChanged('ELIGIBILITY_CONTEXT_PENDING',current);return end
        self.reason=reason
        local details=tostring(reason or ''):lower()
        local service=details:find('busy',1,true) or details:find('thrott',1,true) or
            details:find('quota',1,true) or details:find('query',1,true)
        if service then
            -- Native service readiness is transient, not a terminal failure.
            -- Long exponential waits are local only; no additional query is
            -- issued until eligibility succeeds. The ready event wakes early.
            self.attempts=math.min(20,(self.attempts or 0)+1)
            self.waitKind='SERVICE';self.state='WAIT_SERVICE'
            self.nextAt=mono()+math.min(60,math.max(5,5*math.min(self.attempts,12)))
            self.serviceDeferrals=(self.serviceDeferrals or 0)+1
            self:Wake()
        else
            self.attempts=(self.attempts or 0)+1
            self.waitKind='ELIGIBILITY'
            if self.attempts>=4 then
                self.state='UNAVAILABLE';if self.frame then self.frame:Hide()end
            else self.nextAt=mono()+self.attempts*3 end
        end
        return
    end
    self.requestAttempted=true;self.waitKind=nil
    local ok,why=W.Scan:Request('AUTO_AH_OPEN')
    self.state=ok and 'RUNNING' or 'UNAVAILABLE';self.reason=why
    if not ok then
        if self.frame then self.frame:Hide()end
        if W.QuickScan:Enabled() then W.QuickScan:Opened()end
    end
    W.Refresh()
end
function A:SettingsChanged()
    if not self:Enabled() then
        self.state='OFF';W.QuickScan:Closed()
        if W.Scan.origin=='AUTO_AH_OPEN' and W.Scan:IsActive() then W.Scan:Cancel()end
        if W.UI and W.UI.pendingSearch then self:Wake()elseif self.frame then self.frame:Hide()end
    elseif W.runtime.ahOpen then self:Opened();W.QuickScan:Opened()end
end
function A:Summary()
    if W.ScanCoordinator then return W.ScanCoordinator:Summary()end
    if self:IsUserPaused() then return self.pauseWasRunning and 'Paused by you · full scan stopped' or 'Scanning paused by you' end
    local scope=W.Scope:Snapshot()
    if W.UI and W.UI.pendingSearch then return 'Search queued · '..(self:ContextReason(scope) or 'waiting for the Auction House')end
    if W.Scan:IsActive() then return W.Scan.pausedForUser and 'Market refresh paused for your search' or 'Updating market prices…'end
    if W.runtime.ahOpen and not scope.ready then return self:ContextReason(scope)end
    local quick=W.QuickScan:Summary()
    if not self:Enabled() and not W.QuickScan.manualEnabled then return 'Automatic market refresh off'end
    if W.QuickScan.state=='RUNNING' or (W.QuickScan.state=='PAUSED' and W.QuickScan.autoResume) then return quick end
    if W.QuickScan.state=='COMPLETE' and (W.QuickScan.completed or 0)>0 then return quick end
    if self.state=='UNAVAILABLE' then return 'Full refresh unavailable · '..tostring(self.reason or 'see Diagnostics')end
    if self.state=='WAIT_CONTEXT' then return self.reason or self:ContextReason(scope)end
    if self.state=='WAITING' and self.reason and W.QuickScan.state~='COMPLETE' then return self.reason end
    if self.state=='WAITING' and self.cooldownAt and mono()<self.cooldownAt then
        return quick~='' and quick or ('Full refresh available in '..math.ceil((self.cooldownAt-mono())/60)..' min')
    end
    if quick~='' then return quick end
    if self.state=='COMPLETE' then return 'Market prices refreshed'end
    return W.runtime.ahOpen and 'Preparing automatic market refresh' or ''
end
