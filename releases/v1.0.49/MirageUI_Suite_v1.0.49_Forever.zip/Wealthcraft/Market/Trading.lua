-- G5: deliberate, two-step player-controlled AH actions.
-- Never invoked by polling, scan events, macros, timers, or addon scripts.
-- All prices and targets must come from the current live client session.
local _, W = ...
W.Trading = {state='IDLE', message='Select an offer or a bag item.', pending=nil, quote=nil,
    reviewTTL={ITEM_BID=45,ITEM_BUYOUT=45,COMMODITY_BUY=60,CANCEL=60,POST_ITEM=120,POST_COMMODITY=120}}
local A = W.Trading
local function owned(r)
    return r.containsOwnerItem==true or r.containsAccountItem==true
end
local function playerHighBid(r)
    local ok,guid=W.SafeCall(UnitGUID,'player')
    return ok and guid~=nil and r.bidder==guid
end
local function affordable(amount)
    -- WoW exposes GetMoney. Fail closed if a supplied API cannot be read.
    if type(GetMoney)~='function' then return false end
    local ok,copper=pcall(GetMoney)
    return ok and W.Math.ValidInteger(copper,0) and copper>=amount
end
local function sameKey(a,b)
    if type(a)~='table' or type(b)~='table' then return false end
    for _,k in ipairs({'itemID','itemLevel','itemSuffix','battlePetSpeciesID'})do
        if (a[k] or 0)~=(b[k] or 0) then return false end
    end
    return true
end
local function valid(v, low, high) return W.Math.ValidInteger(v,low,high) end
function A:Guard(allowPending)
    if not allowPending and self.state~='IDLE' then
        return false,'A transaction review is already open. Confirm or close it before starting another.'
    end
    if W.QueryBusy and W.QueryBusy('trade') then return false,'Finish the active auction request first.' end
    if not W.runtime.ahOpen then return false,'Auction House has closed.' end
    if not W.Compat.build or not (W.Compat.build.runtimeAllowed or W.Compat.build.exactTarget) then return false,'Client build not qualified.' end
    if type(InCombatLockdown)=='function' and InCombatLockdown() then return false,'No trading while in combat.' end
    if type(W.Compat.auction)~='table' then return false,'Auction API unavailable.' end
    return true
end
function A:ArmReview()
    if self.pending then self.pending.preparedAt=W.Clock() end
    self.state='REVIEW'
end
function A:ReviewRemaining()
    local p=self.pending
    if not p then return 0 end
    local ttl=self.reviewTTL[p.kind] or 60
    if not W.Math.ValidInteger(p.preparedAt,0) then return 0 end
    return math.max(0,ttl-math.max(0,W.Clock()-p.preparedAt))
end
function A:Reset(message)
    self.pending=nil;self.quote=nil;self.state='IDLE'
    self.message=message or 'No pending auction transaction.'
end
function A:Closed()
    if self.state=='QUOTE_WAITING' or self.state=='QUOTE_READY' then
        local f=W.Compat.auction and W.Compat.auction.CancelCommoditiesPurchase
        if type(f)=='function' then pcall(f) end
    end
    self:Reset('Auction session ended; pending action discarded.')
end
function A:PrepareItem(index,expectedAuctionID)
    local can,why=self:Guard(); if not can then return false,why end
    local t=W.Targeted
    if t.state~='COMPLETE' or t.kind~='ITEM' or t.session~=W.runtime.ahSession then
        return false,'Request complete item offers before selecting an auction.' end
    local fn=W.Compat.auction.GetItemSearchResultInfo
    if type(fn)~='function' then return false,'Item offers unavailable.' end
    local ok,r=pcall(fn,t.wowKey,index)
    if not ok or type(r)~='table' or not valid(r.auctionID,1) or
        not valid(r.buyoutAmount,1) or not valid(r.quantity,1,100000000) then
        return false,'No valid live buyout at this index.' end
    if expectedAuctionID~=nil and r.auctionID~=expectedAuctionID then return false,'The selected auction moved. Refresh offers and select it again.' end
    if owned(r) then return false,'You cannot buy your own or an account-owned auction.' end
    if not affordable(r.buyoutAmount) then return false,'Not enough gold for this buyout.' end
    if r.itemKey and not sameKey(r.itemKey,t.wowKey) then return false,'Item variant changed; search again.' end
    self.pending={kind='ITEM_BUYOUT',session=W.runtime.ahSession,marketKey=W.Scope:Snapshot().key,
        itemKey=t.wowKey,index=index,auctionID=r.auctionID,quantity=r.quantity,
        price=r.buyoutAmount}
    self.quote=nil;self:ArmReview()
    self.message='Review this specific live item auction. The price may change.'
    return true
end
function A:PrepareBid(index,amount,expectedAuctionID)
    local can,why=self:Guard();if not can then return false,why end
    local t=W.Targeted;local a=W.Compat.auction
    if self.state~='IDLE' then return false,'Close the current review first.' end
    if t.state~='COMPLETE' or t.kind~='ITEM' or t.session~=W.runtime.ahSession or
        not valid(index,1,25000) then return false,'Select an item auction from a complete live search.' end
    local ok,r=W.SafeCall(a.GetItemSearchResultInfo,t.wowKey,index)
    if not ok or type(r)~='table' or not valid(r.auctionID,1) or not valid(r.quantity,1) or
        not valid(r.minBid,1) then return false,'Blizzard has not supplied a valid minimum bid.' end
    if expectedAuctionID~=nil and r.auctionID~=expectedAuctionID then return false,'The selected auction moved. Refresh offers and select it again.' end
    if owned(r) or playerHighBid(r) then return false,'Own auctions and your existing high bids cannot be bid on here.' end
    if r.itemKey and not sameKey(r.itemKey,t.wowKey) then return false,'Item variant changed.' end
    if not valid(amount,r.minBid) then return false,'Enter at least the server minimum bid.' end
    if valid(r.buyoutAmount,1) and amount>=r.buyoutAmount then
        return false,'This would buy out the auction. Use Review buyout instead.' end
    if not affordable(amount) then return false,'Not enough gold for this bid.' end
    self.pending={kind='ITEM_BID',session=W.runtime.ahSession,marketKey=W.Scope:Snapshot().key,
        itemKey=t.wowKey,index=index,auctionID=r.auctionID,quantity=r.quantity,
        price=amount,minBid=r.minBid,buyout=r.buyoutAmount or 0}
    self.quote=nil;self:ArmReview();self.message='Review this bid. Winning is not guaranteed.'
    return true
end
function A:PrepareCommodity(quantity)
    local can,why=self:Guard();if not can then return false,why end
    local t=W.Targeted
    if t.state~='COMPLETE' or t.kind~='COMMODITY' or t.session~=W.runtime.ahSession then
        return false,'Request complete commodity offers before buying.' end
    if not valid(quantity,1,999999) then return false,'Choose a valid quantity.' end
    local a=W.Compat.auction
    local n=type(a.GetNumCommoditySearchResults)=='function' and
        select(2,pcall(a.GetNumCommoditySearchResults,t.itemKey.itemID)) or 0
    if not valid(n,1,25000) then return false,'No commodity offers are available.' end
    local remaining, total=quantity,0
    for i=1,math.min(n,500) do
        if remaining<=0 then break end
        local ok,r=pcall(a.GetCommoditySearchResultInfo,t.itemKey.itemID,i)
        if not ok or type(r)~='table' or not valid(r.quantity,1) or
            not valid(r.unitPrice,1) then return false,'Commodity price rows are unavailable.' end
        local take=math.min(remaining,r.quantity)
        if take*r.unitPrice>9007199254740991-total then return false,'Price overflow.' end
        total=total+take*r.unitPrice;remaining=remaining-take
    end
    if remaining>0 then return false,'Not enough observable quantity to price the request.' end
    if not affordable(total) then return false,'Not enough gold for this commodity quantity.' end
    self.pending={kind='COMMODITY_BUY',session=W.runtime.ahSession,
        marketKey=W.Scope:Snapshot().key,itemID=t.itemKey.itemID,quantity=quantity,
        price=total,originalMax=total}
    self:ArmReview();self.message='Review total observed commodity cost before requesting a quote.'
    return true
end
function A:PrepareCancel(item)
    local can,why=self:Guard();if not can then return false,why end
    if type(item)~='table' or not valid(item.auctionID,1) then
        return false,'Choose an owned auction.' end
    local a=W.Compat.auction
    if type(a.CanCancelAuction)~='function' or type(a.CancelAuction)~='function' then
        return false,'Blizzard cancel action is unavailable.' end
    local ok,allowed=pcall(a.CanCancelAuction,item.auctionID)
    if not ok or allowed~=true then return false,'Auction cannot be canceled or is not loaded.' end
    local costOK,cost=W.SafeCall(a.GetCancelCost,item.auctionID)
    if not costOK or not valid(cost,0) then return false,'Cancellation cost is unavailable. Use Blizzard view to review cancellation.' end
    if not affordable(cost) then return false,'Not enough gold for cancellation fees.' end
    self.pending={kind='CANCEL',auctionID=item.auctionID,session=W.runtime.ahSession,
        marketKey=W.Scope:Snapshot().key,name=item.name,cancelCost=cost}
    self:ArmReview();self.message='Canceling an auction may incur fees. Confirm explicitly.'
    return true
end
-- Read-only quantity check. One Blizzard posting call may include matching bag
-- stacks only when BOTH bag identity and Blizzard's available-post count agree.
-- This never queues multiple protected posting calls.
function A:PostingInventory(bag,slot)
    if type(C_Container)~='table' or type(C_Container.GetContainerItemInfo)~='function' or
        type(ItemLocation)~='table' or type(ItemLocation.CreateFromBagAndSlot)~='function' then
        return nil,'Bag data unavailable.' end
    local ok,info=W.SafeCall(C_Container.GetContainerItemInfo,bag,slot)
    if not ok or type(info)~='table' or not valid(info.itemID,1) or
        not valid(info.stackCount,1) or info.isBound or info.isLocked then
        return nil,'Selected bag item is unavailable.' end
    local identity=W.Identity:FromLink(info.hyperlink,info.itemID)
    if not identity then return nil,'Exact item link is not loaded.' end
    local localCount,stacks=0,0
    for _,row in ipairs(W.PlayerContext:ReadBags())do
        if row.sellable and not row.locked and row.itemID==info.itemID and
            W.Identity:FromLink(row.itemLink,row.itemID)==identity then
            localCount=localCount+row.count;stacks=stacks+1
        end
    end
    local a=W.Compat.auction or {}
    local loc=ItemLocation:CreateFromBagAndSlot(bag,slot)
    if not loc then return nil,'Item location unavailable.' end
    local available=info.stackCount
    local verified=false
    if type(a.GetAvailablePostCount)=='function' then
        local found,count=W.SafeCall(a.GetAvailablePostCount,loc)
        if found and valid(count,0,100000000) then
            available=math.min(localCount,count)
            verified=true
        end
    end
    if available<1 then return nil,'No units available to post.' end
    return {info=info,identity=identity,loc=loc,selectedCount=info.stackCount,
        localCount=localCount,available=available,stacks=stacks,
        crossStackVerified=verified}
end
function A:PostPreview(bag,slot,quantity,duration,unit,bid,selected)
    if not valid(quantity,1,100000) or not valid(duration,1,3) then return nil,'Enter a valid quantity.' end
    local inventory,reason=self:PostingInventory(bag,slot)
    if not inventory then return nil,reason end
    if selected and inventory.identity~=W.Identity:FromLink(selected.itemLink,selected.itemID) then
        return nil,'The selected bag slot changed. Select the item again.' end
    if quantity>inventory.available then return nil,'Quantity exceeds verified available inventory.' end
    if not valid(unit,0) or (bid~=nil and not valid(bid,1)) or (unit==0 and bid==nil) then
        return nil,'Enter a positive buyout or starting bid.' end
    if bid and unit>0 and bid>unit then return nil,'Starting bid cannot exceed buyout.' end
    local a=W.Compat.auction or {}
    local eligibilityOK,allowed=W.SafeCall(a.IsSellItemValid,inventory.loc,false)
    if not eligibilityOK or allowed~=true then return nil,'Blizzard does not permit posting this item.' end
    local statusOK,status=W.SafeCall(a.GetItemCommodityStatus,inventory.loc)
    if not statusOK or (status~=1 and status~=2) then return nil,'Item posting type is not ready.' end
    local commodity=status==2
    if commodity and (unit<1 or bid~=nil) then
        return nil,'Commodities require a buyout; starting bids are unavailable.' end
    local supportsCopper=false
    if type(a.SupportsCopperValues)=='function' then
        local good,supported=W.SafeCall(a.SupportsCopperValues)
        supportsCopper=good and supported==true
    end
    if not supportsCopper and (unit%100~=0 or (bid and bid%100~=0)) then
        return nil,'The client requires whole-silver listing prices.' end
    local calculate=commodity and a.CalculateCommodityDeposit or a.CalculateItemDeposit
    if type(calculate)~='function' then return nil,'Deposit API is unavailable.' end
    local ok,deposit=W.SafeCall(calculate,commodity and inventory.info.itemID or inventory.loc,duration,quantity)
    if not ok or not valid(deposit,0) then return nil,'Deposit is not available yet.' end
    local gross=(unit>0 and unit or bid or 0)*quantity
    if not valid(gross,0) then return nil,'Total price exceeds the safe range.' end
    local feeBps=W.Storage:AssumedFeeBps()
    local fee=math.floor(gross*feeBps/10000+.5)
    local moneyOK,money=W.SafeCall(GetMoney)
    local canAfford=moneyOK and valid(money,0) and money>=deposit
    return {quantity=quantity,deposit=deposit,gross=gross,fee=fee,canAfford=canAfford,
        net=gross-fee,unit=unit,bid=bid,available=inventory.available,
        stacks=inventory.stacks,selectedCount=inventory.selectedCount,
        commodity=commodity,assumedFeeBps=feeBps,
        buyoutTotal=unit>0 and unit*quantity or nil,
        bidTotal=bid and bid*quantity or nil}
end
function A:PreparePost(bag,slot,quantity,unitCopper,duration,bidCopper,selected)
    local can,why=self:Guard();if not can then return false,why end
    local a=W.Compat.auction
    if type(ItemLocation)~='table' or type(ItemLocation.CreateFromBagAndSlot)~='function' or
        type(C_Container)~='table' or type(C_Container.GetContainerItemInfo)~='function' then
        return false,'ItemLocation or bag API unavailable.' end
    if not valid(bag,0,4) or not valid(slot,1,160) or not valid(quantity,1,100000) or
        not valid(unitCopper,0,9007199254740991) or not valid(duration,1,3) then
        return false,'Invalid slot, quantity, unit price or duration.' end
    local ok,info=pcall(C_Container.GetContainerItemInfo,bag,slot)
    if not ok or type(info)~='table' or info.isBound or info.isLocked or not valid(info.stackCount,1) or not valid(info.itemID,1) then
        return false,'Item unavailable, bound, or quantity exceeds the selected stack.' end
    local identity=W.Identity:FromLink(info.hyperlink,info.itemID)
    if not identity or (selected and identity~=W.Identity:FromLink(selected.itemLink,selected.itemID)) then
        return false,'Bag item changed or is unavailable. Refresh bags and select it again.' end
    local inventory,availabilityError=self:PostingInventory(bag,slot)
    if not inventory then return false,availabilityError end
    if inventory.identity~=identity then return false,'The selected bag slot changed. Select the item again.' end
    if quantity>inventory.available then
        return false,'Only '..inventory.available..' matching units are available for this listing.' end
    local loc=ItemLocation:CreateFromBagAndSlot(bag,slot)
    if not loc then return false,'Item location not available.' end
    if type(a.IsSellItemValid)~='function' then return false,'Blizzard item eligibility API unavailable.' end
    local validCall,allowed=pcall(a.IsSellItemValid,loc,false)
    if not validCall or allowed~=true then return false,'Blizzard does not allow this item to be posted.' end
    local supportsCopper=false
    if type(a.SupportsCopperValues)=='function' then
        local success,value=pcall(a.SupportsCopperValues)
        supportsCopper=success and value==true
    end
    if unitCopper%100~=0 and not supportsCopper then
        return false,'Client has not confirmed support for copper-denominated listing prices; use whole silver.' end
    local statusOK,status=W.SafeCall(a.GetItemCommodityStatus,loc)
    if not statusOK or (status~=1 and status~=2) then return false,'Commodity status is not ready; refresh the item.' end
    local commodity=status==2
    if bidCopper~=nil and not valid(bidCopper,1,9007199254740991) then return false,'Invalid starting bid.' end
    if commodity and (unitCopper<1 or bidCopper~=nil) then return false,'Commodities require a buyout price and do not support bids.' end
    if unitCopper<1 and bidCopper==nil then return false,'Enter a buyout or starting bid.' end
    if bidCopper and unitCopper>0 and bidCopper>unitCopper then return false,'Starting bid cannot exceed buyout.' end
    if bidCopper and bidCopper%100~=0 and not supportsCopper then return false,'Starting bid must use whole silver in this client.' end
    if (unitCopper>0 and not valid(unitCopper*quantity,1)) or (bidCopper and not valid(bidCopper*quantity,1)) then
        return false,'Total price overflow.' end
    local kind=commodity and 'POST_COMMODITY' or 'POST_ITEM'
    if type(a[commodity and 'PostCommodity' or 'PostItem'])~='function' then
        return false,'Blizzard posting API missing.' end
    local deposit=nil
    local function calculate()
        if commodity and type(a.CalculateCommodityDeposit)=='function' then
            return a.CalculateCommodityDeposit(info.itemID,duration,quantity)
        elseif not commodity and type(a.CalculateItemDeposit)=='function' then
            return a.CalculateItemDeposit(loc,duration,quantity)
        end
    end
    local good,amount=pcall(calculate)
    if good and valid(amount,0) then deposit=amount end
    if deposit==nil then return false,'Deposit cannot be calculated yet. Use Blizzard view or refresh this item.' end
    if not affordable(deposit) then return false,'Not enough gold for the deposit.' end
    self.pending={kind=kind,session=W.runtime.ahSession,marketKey=W.Scope:Snapshot().key,
        bag=bag,slot=slot,itemID=info.itemID,identity=identity,stack=info.stackCount,
        reviewedAvailable=inventory.available,matchedStacks=inventory.stacks,
        quantity=quantity,unitCopper=unitCopper,bidCopper=bidCopper,duration=duration,deposit=deposit,
        name=(type(info.itemName)=='string' and info.itemName~='' and info.itemName) or (type(info.hyperlink)=='string' and info.hyperlink:match('%[([^%]]+)%]')) or 'Item'}
    self:ArmReview();self.message='Review total price and deposit. Posting needs explicit confirmation.'
    return true
end
local function sessionOK(p)
    return p and p.session==W.runtime.ahSession and p.marketKey==W.Scope:Snapshot().key
end
function A:Commit()
    -- Call ONLY from the physical confirmation Button.OnClick in the user interface.
    local can,why=self:Guard(true);if not can then self:Reset(why);return false,why end
    local p=self.pending
    if p and self.state=='REVIEW' and self:ReviewRemaining()<=0 then
        self:Reset('Review expired; inspect current offers and prepare the transaction again.')
        return false,self.message
    end
    if not sessionOK(p) then self:Reset('Session or venue changed.');return false,self.message end
    if self.state~='REVIEW' and self.state~='QUOTE_READY' and self.state~='POST_CONFIRM' then
        return false,'No manually reviewed action.' end
    local a=W.Compat.auction
    if p.kind=='ITEM_BID' and self.state=='REVIEW' then
        local t=W.Targeted
        if t.state~='COMPLETE' or t.session~=p.session then self:Reset('Item search expired.');return false,self.message end
        local ok,r=W.SafeCall(a.GetItemSearchResultInfo,p.itemKey,p.index)
        if not ok or type(r)~='table' or r.auctionID~=p.auctionID or r.quantity~=p.quantity or
            r.minBid~=p.minBid or (r.buyoutAmount or 0)~=p.buyout or owned(r) or playerHighBid(r) or
            (r.itemKey and not sameKey(r.itemKey,p.itemKey)) or not affordable(p.price) then
            self:Reset('Auction or available gold changed. Refresh and review the bid again.');return false,self.message
        end
        local sent,err=W.SafeCall(a.PlaceBid,p.auctionID,p.price)
        if not sent then self:Reset('Bid refused: '..tostring(err));return false,self.message end
        self:Reset('Bid submitted. Check My bids and Blizzard messages; winning is not assumed.')
        return true,self.message
    elseif p.kind=='ITEM_BUYOUT' and self.state=='REVIEW' then
        local t=W.Targeted
        if t.state~='COMPLETE' or t.session~=p.session then return false,'Item search expired.' end
        local ok,r=pcall(a.GetItemSearchResultInfo,p.itemKey,p.index)
        if not ok or type(r)~='table' or r.auctionID~=p.auctionID or r.buyoutAmount~=p.price or r.quantity~=p.quantity or owned(r) or
            (r.itemKey and not sameKey(r.itemKey,p.itemKey)) or not affordable(p.price) then
            self:Reset('Listing changed. Refresh offers before buying.');return false,self.message
        end
        if type(a.PlaceBid)~='function' then return false,'Blizzard buyout API unavailable.' end
        -- The completion event may fire inside PlaceBid. Arm the existing
        -- purchase wait before dispatch and keep its timeout/manual-check path.
        self.state='PURCHASE_WAITING';p.submitted=true
        self.purchaseSentAt=type(GetTime)=='function' and GetTime() or W.Clock()
        self.message='Buyout submitted. Waiting for the Auction House.'
        local sent,err=pcall(a.PlaceBid,p.auctionID,p.price)
        if not sent and self.pending==p then self:Reset('Blizzard refused buyout: '..tostring(err));return false,self.message end
        return true,self.message
    elseif p.kind=='COMMODITY_BUY' then
        if self.state=='REVIEW' then
            if type(a.StartCommoditiesPurchase)~='function' then return false,'Commodity buying API unavailable.' end
            -- Some clients dispatch quote events synchronously; arm before the call.
            self.state='QUOTE_WAITING';self.message='Waiting for Blizzard final commodity quote; do not assume purchased.'
            self.quote=nil;self.quoteRequestedAt=W.Clock()
            local sent,err=pcall(a.StartCommoditiesPurchase,p.itemID,p.quantity)
            if not sent then self:Reset('Commodity quote request failed: '..tostring(err));return false,self.message end
            return true,self.message
        elseif self.state=='QUOTE_READY' then
            if type(a.ConfirmCommoditiesPurchase)~='function' then
                return false,'Commodity confirmation API unavailable.' end
            local good,remaining=W.SafeCall(a.GetQuoteDurationRemaining)
            if not good or not W.Math.ValidNumber(remaining) or remaining<=0 or not self.quote or
                W.Clock()-(self.quote.at or 0)>30 then
                self:Closed();return false,'Commodity quote expired or could not be verified. Request a new quote.'
            end
            if not self.quote or self.quote.total>p.originalMax or
                self.quote.total>p.approvedTotal or not affordable(self.quote.total) then
                return false,'Price changed. Review the new quote before confirming.' end
            local sent,err=pcall(a.ConfirmCommoditiesPurchase,p.itemID,p.quantity)
            if not sent then self:Reset('Commodity confirmation failed: '..tostring(err));return false,self.message end
            self:Reset('Commodity purchase submitted; verify server result. No ledger entry inferred.')
            return true,self.message
        end
    elseif p.kind=='CANCEL' and self.state=='REVIEW' then
        local ok,allowed=pcall(a.CanCancelAuction,p.auctionID)
        if not ok or allowed~=true then self:Reset('Auction no longer cancelable.');return false,self.message end
        local costOK,cost=W.SafeCall(a.GetCancelCost,p.auctionID)
        if not costOK or cost~=p.cancelCost or not affordable(cost) then
            self:Reset('Cancellation cost changed. Review it again.');return false,self.message
        end
        local sent,err=pcall(a.CancelAuction,p.auctionID)
        if not sent then self:Reset('Cancel rejected: '..tostring(err));return false,self.message end
        self:Reset('Cancel request sent. Await Blizzard auction event.');return true,self.message
    elseif (p.kind=='POST_ITEM' or p.kind=='POST_COMMODITY') then
        local ok,info=pcall(C_Container.GetContainerItemInfo,p.bag,p.slot)
        if not ok or type(info)~='table' or info.itemID~=p.itemID or info.isBound or info.isLocked or
            W.Identity:FromLink(info.hyperlink,info.itemID)~=p.identity or not valid(info.stackCount,1) then
            self:Reset('Bag item moved or became unavailable. Posting canceled.');return false,self.message end
        local inventory= self:PostingInventory(p.bag,p.slot)
        if not inventory or inventory.identity~=p.identity or inventory.available<p.quantity then
            self:Reset('Matching available inventory changed. Review listing again.');return false,self.message end
        local loc=ItemLocation:CreateFromBagAndSlot(p.bag,p.slot)
        local validCall,allowed=W.SafeCall(a.IsSellItemValid,loc,false)
        if not validCall or allowed~=true then self:Reset('Blizzard no longer permits posting this item.');return false,self.message end
        local depositFn=p.kind=='POST_COMMODITY' and a.CalculateCommodityDeposit or a.CalculateItemDeposit
        if p.deposit~=nil then
            local read,cost=W.SafeCall(depositFn,p.kind=='POST_COMMODITY' and p.itemID or loc,p.duration,p.quantity)
            if not read or cost~=p.deposit or not affordable(cost) then
                self:Reset('Deposit or available gold changed. Review the listing again.');return false,self.message
            end
        end
        if self.state=='REVIEW' then
            local fn=a[p.kind=='POST_COMMODITY' and 'PostCommodity' or 'PostItem']
            if type(fn)~='function' then return false,'Posting API unavailable.' end
            local sent,needs
            if p.kind=='POST_COMMODITY' then
                sent,needs=pcall(fn,loc,p.duration,p.quantity,p.unitCopper)
            else
                local total=p.unitCopper>0 and p.unitCopper*p.quantity or nil
                local bid=p.bidCopper and p.bidCopper*p.quantity or nil
                if (total and not valid(total,1)) or (bid and not valid(bid,1)) then return false,'Total price overflow.' end
                sent,needs=pcall(fn,loc,p.duration,p.quantity,bid,total)
            end
            if not sent then self:Reset('Posting API rejected request: '..tostring(needs));return false,self.message end
            if needs==true then
                self.state='POST_CONFIRM';self.message='Blizzard requires another explicit confirmation for this posting.'
            else
                self:Reset('Posting request sent. Check Blizzard confirmation; never infer a sale.')
            end
            return true,self.message
        elseif self.state=='POST_CONFIRM' then
            local fn=a[p.kind=='POST_COMMODITY' and 'ConfirmPostCommodity' or 'ConfirmPostItem']
            if type(fn)~='function' then self:Reset('Confirmation API unavailable; use native controls.')
                return false,self.message end
            local sent,err
            if p.kind=='POST_COMMODITY' then
                sent,err=pcall(fn,loc,p.duration,p.quantity,p.unitCopper)
            else
                sent,err=pcall(fn,loc,p.duration,p.quantity,p.bidCopper and p.bidCopper*p.quantity or nil,p.unitCopper>0 and p.unitCopper*p.quantity or nil)
            end
            if not sent then self:Reset('Posting confirmation failed: '..tostring(err));return false,self.message end
            self:Reset('Posting confirmation sent; verify server status.')
            return true,self.message
        end
    end
    return false,'Unsupported transaction state.'
end
function A:OnEvent(event,unitPrice,totalPrice)
    if not self.pending or not sessionOK(self.pending) then return end
    if event=='AUCTION_HOUSE_SHOW_ERROR' then
        self:Reset('Blizzard rejected the auction action; check the in-game error.');W.Refresh();return
    end
    if self.pending.kind=='COMMODITY_BUY' then
        if event=='COMMODITY_PRICE_UPDATED' and (self.state=='QUOTE_WAITING' or self.state=='QUOTE_READY') and
            valid(totalPrice,1) and valid(unitPrice,1) then
            if totalPrice>self.pending.originalMax then
                local cancel=W.Compat.auction and W.Compat.auction.CancelCommoditiesPurchase
                if type(cancel)=='function' then pcall(cancel) end
                self:Reset('Live commodity price increased beyond your reviewed estimate. Search again before buying.')
                W.Diagnostics:Record('WARN','Commodity quote rejected: live price increased above reviewed estimate')
                W.Refresh();return
            end
            self.quote={unit=unitPrice,total=totalPrice,at=W.Clock()}
            self.pending.approvedTotal=totalPrice -- requires a NEW physical confirmation click.
            self.state='QUOTE_READY';self.message='Blizzard quote ready; review total and click Confirm to buy.'
        elseif event=='COMMODITY_PRICE_UNAVAILABLE' or event=='COMMODITY_PURCHASE_FAILED' then
            self:Reset('Commodity quote or purchase failed; no action recorded.')
        elseif event=='COMMODITY_PURCHASE_SUCCEEDED' then
            self:Reset('Blizzard reports commodity purchase completed; delivery should be checked.')
        end
    elseif event=='AUCTION_HOUSE_SHOW_ERROR' then
        self:Reset('Blizzard rejected the auction action; see in-game error message.')
    end
    W.Refresh()
end
