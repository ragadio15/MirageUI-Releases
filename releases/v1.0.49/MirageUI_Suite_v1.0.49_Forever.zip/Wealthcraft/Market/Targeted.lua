-- G3: player-initiated item-key queries; no auction trading or background polling.
-- Shared AH result events are temporally correlated, not exclusive proof of ownership.
local _, W = ...
local T = {
    state = 'IDLE', message = 'No targeted search run', resultEvents = 0,
    processed = 0, expected = nil, ambiguous = 0, invalid = 0,
    batchSize = 100, maxRows = 25000, maxVariants = 80, timeout = 90,
    association = 'NOT_EVALUATED',
}
-- Independent request records share one scheduler and the account query quota.
-- Only the foreground record can supply an item identity to the trading UI.
local requests = {__index=T}
W.Targeted = setmetatable({},requests)
W.QuickTarget = setmetatable({},requests)
local function mono() return type(GetTime) == 'function' and GetTime() or 0 end
local function elapsed(start) return mono() - (start or 0) end
local function validCopper(v) return W.Math.ValidInteger(v, 0, 9007199254740991) end
function T:IsActive() return self.state == 'REQUESTED' or self.state == 'READING' end
function T:Parse(text)
    if type(text) ~= 'string' or #text > 90 then return nil, 'ENTER_AN_ITEM_ID' end
    text = text:gsub('^%s+', ''):gsub('%s+$', '')
    local id, level, suffix, pet = text:match('^(%d+):(%d+):([%-]?%d+):(%d+)$')
    if not id then id = text:match('^(%d+)$') end
    if not id then return nil, 'USE_ITEM_ID_OR_ID_LEVEL_SUFFIX_PET' end
    local _, key = W.Storage:WatchKey({itemID = tonumber(id), itemLevel = tonumber(level) or 0,
        itemSuffix = tonumber(suffix) or 0, battlePetSpeciesID = tonumber(pet) or 0})
    if key then return key end
    return key,'INVALID_ITEM_KEY'
end
function T:Eligibility(itemKey, origin)
    if W.QueryBusy and W.QueryBusy(self==W.QuickTarget and 'quickTarget' or 'target') then return false,'Finish the current query or transaction review first.' end
    if not W.Storage:IsWritable() then return false, 'SavedVariables are not writable.' end
    local ok, reason = W.Compat:CanTarget()
    if not ok then return false, reason end
    if not W.runtime.ahOpen then return false, 'Open Blizzard Auction House.' end
    if type(InCombatLockdown) == 'function' and InCombatLockdown() then return false, 'Unavailable in combat.' end
    if (W.Scan:IsActive() and not W.Scan.pausedForUser) or self:IsActive() or W.Scheduler.active then
        return false, 'Finish the current market operation first.'
    end
    local scope = W.Scope:Snapshot()
    if not scope.ready then return false, scope.reason or 'Preparing the current Auction House visit.' end
    local _, key = W.Storage:WatchKey(itemKey)
    if not key then return false, 'Enter a numeric item ID or a complete item key.' end
    local quota, why = W.Storage:TargetQueryEligibility(origin=='QUICK_OPEN' and 'AUTO' or 'MANUAL')
    if not quota then return false, why end
    if W.Compat.APIs.IsThrottledMessageSystemReady then
        local good, ready = pcall(W.Compat.auction.IsThrottledMessageSystemReady)
        if not good or ready ~= true then return false, 'AH query service busy; another addon may be using it.' end
    end
    return true, 'Ready for one read-only targeted query.'
end
function T:Request(itemKey, origin, displayItem)
    -- Only a valid explicit item selection takes foreground priority. Never
    -- interrupt an ongoing scan for malformed keys or background requests.
    local _, validKey = W.Storage:WatchKey(itemKey)
    local function rejected(reason)
        if origin~='QUICK_OPEN' and W.Priority then W.Priority:ManualRejected()end
        return false,reason
    end
    if origin~='QUICK_OPEN' and validKey and W.Priority then W.Priority:ManualSearch() end
    local allowed, reason = self:Eligibility(itemKey,origin)
    if not allowed then
        W.Diagnostics:Record('WARN', 'Targeted query blocked: ' .. tostring(reason)); return rejected(reason)
    end
    local queryKey, normalized = W.Storage:WatchKey(itemKey)
    local a = W.Compat.auction
    local ok, wowKey = pcall(a.MakeItemKey, normalized.itemID, normalized.itemLevel,
        normalized.itemSuffix, normalized.battlePetSpeciesID)
    if not ok or type(wowKey) ~= 'table' or wowKey.itemID ~= normalized.itemID then
        return rejected('MAKE_ITEM_KEY_FAILED')
    end
    self.origin = origin or 'PLAYER'
    self.session = W.runtime.ahSession
    self.scope = W.Scope:Snapshot()
    self.queryKey = queryKey
    self.itemKey = normalized
    self.wowKey = wowKey
    self.startedAt = mono()
    self.sentAt = W.Clock()
    self.kind, self.expected, self.processed = nil, nil, 0
    self.ambiguous, self.invalid, self.resultEvents = 0, 0, 0
    self.groups, self.lastResult = {}, nil
    self.offerBook = self == W.Targeted and {} or nil
    self.displayItem = self.offerBook and displayItem and
        {name=displayItem.name,icon=displayItem.icon,itemLink=displayItem.itemLink} or nil
    self.index = 1
    self.moreRequests = 0
    self.association = 'TEMPORAL_EVENT_ASSOCIATION_ONLY_SHARED_AH_RESULT_EVENTS'
    self.state = 'REQUESTED'
    self.message = 'Waiting for matching Blizzard item / commodity result event.'
    -- Consume guard BEFORE sending: an errored call might still reach the server.
    W.Storage:MarkTargetQuery()
    local sent, err = pcall(a.SendSearchQuery, wowKey, {}, false)
    if not sent then self:Stop('INVALID', 'QUERY_CALL_FAILED: ' .. tostring(err)); return rejected(self.message) end
    if self:IsActive() and not W.Scheduler.active then
        if not W.Scheduler:Start(function() return self:Tick() end) then
            self:Stop('INVALID', 'SCHEDULER_UNAVAILABLE'); return rejected(self.message)
        end
    end
    local source=self.origin=='QUICK_OPEN' and 'Automatic quick check' or 'Manual targeted search'
    W.Diagnostics:Record('INFO',source..' issued: '..queryKey)
    W.Refresh()
    return true
end
local function sameKey(a, b)
    return type(a) == 'table' and type(b) == 'table' and
        a.itemID == b.itemID and (a.itemLevel or 0) == (b.itemLevel or 0) and
        (a.itemSuffix or 0) == (b.itemSuffix or 0) and
        (a.battlePetSpeciesID or 0) == (b.battlePetSpeciesID or 0)
end
function T:OnResults(event, value)
    if not self:IsActive() or not W.runtime.ahOpen or
        W.runtime.ahSession ~= self.session then return end
    local kind
    if (event == 'COMMODITY_SEARCH_RESULTS_UPDATED' or event == 'COMMODITY_SEARCH_RESULTS_ADDED') and
        value == self.itemKey.itemID then
        kind = 'COMMODITY'
    elseif (event == 'ITEM_SEARCH_RESULTS_UPDATED' or event == 'ITEM_SEARCH_RESULTS_ADDED') and
        sameKey(value, self.itemKey) then
        kind = 'ITEM'
    else return end
    if self.kind and self.kind ~= kind then
        self:Stop('PARTIAL', 'AMBIGUOUS_RESULT_KIND'); return
    end
    if self.state == 'READING' then
        -- A matching update can reorder native indices between slices. Restart
        -- inside the original deadline before combining rows from two books.
        self.state='REQUESTED'
        self.index,self.processed,self.ambiguous,self.invalid=1,0,0,0
        self.groups={}
        if self.offerBook then self.offerBook={} end
    end
    self.kind = kind
    self.resultEvents = self.resultEvents + 1
    self.message = 'Matching shared result event; waiting for full-result indicator or manual Load more.'
    W.Refresh()
end
function T:Guard()
    if not W.runtime.ahOpen or W.runtime.ahSession ~= self.session then
        self:Stop('CANCELLED', 'AH_CLOSED_OR_SESSION_CHANGED'); return false
    end
    local snapshot = W.Scope:Snapshot()
    if not snapshot.ready or snapshot.key ~= self.scope.key then
        self:Stop('CANCELLED', 'MARKET_SCOPE_CHANGED'); return false
    end
    return true
end
function T:CanLoadMore()
    if self.state ~= 'REQUESTED' or not self.kind or self.moreRequests >= 3 then
        return false, 'No incomplete active query or manual page limit reached.'
    end
    local a = W.Compat.auction
    local hasMore = a[self.kind=='ITEM' and 'RequestMoreItemSearchResults' or 'RequestMoreCommoditySearchResults']
    if type(hasMore) ~= 'function' then return false, 'Request-more API unavailable.' end
    local fullFn = a[self.kind=='ITEM' and 'HasFullItemSearchResults' or 'HasFullCommoditySearchResults']
    local ok, isFull = pcall(fullFn, self.kind == 'ITEM' and self.wowKey or self.itemKey.itemID)
    if ok and isFull == true then return false, 'Full results already available.' end
    return true
end
function T:More()
    local eligible, reason = self:CanLoadMore()
    if not eligible then return false, reason end
    if not self:Guard() then return false, self.message end
    local guard, why = W.Storage:TargetQueryEligibility('MANUAL')
    if not guard then return false, why end
    if W.Compat.APIs.IsThrottledMessageSystemReady then
        local ready, status = pcall(W.Compat.auction.IsThrottledMessageSystemReady)
        if not ready or status ~= true then return false, 'AH message service busy.' end
    end
    local a = W.Compat.auction
    local fn = a[self.kind=='ITEM' and 'RequestMoreItemSearchResults' or 'RequestMoreCommoditySearchResults']
    W.Storage:MarkTargetQuery()
    self.moreRequests = self.moreRequests + 1
    local good, result = pcall(fn, self.kind == 'ITEM' and self.wowKey or self.itemKey.itemID)
    if not good then
        self.message = 'Additional result request rejected; prior data retained.'
        W.Diagnostics:Record('WARN', 'Request-more API failed: ' .. tostring(result))
        W.Refresh()
        return false, self.message
    end
    self.message = 'Manual additional-results request sent; waiting for full result.'
    W.Diagnostics:Record('INFO', 'Manual request-more #' .. self.moreRequests .. ' for ' .. self.queryKey)
    W.Refresh()
    return true
end
function T:ReadRow(index)
    local a = W.Compat.auction
    local row
    if self.kind == 'ITEM' then
        local good, item = pcall(a.GetItemSearchResultInfo, self.wowKey, index)
        if not good or type(item) ~= 'table' then return false, 'UNCACHED_ROW' end
        if item.itemKey and not sameKey(item.itemKey, self.itemKey) then return false, 'KEY_MISMATCH' end
        if not W.Math.ValidInteger(item.quantity, 1, 100000000) or
            not validCopper(item.buyoutAmount or 0) then return false, 'INVALID_ITEM_RESULT' end
        row=item
        local identity = W.Identity:FromLink(item.itemLink, self.itemKey.itemID)
        if not identity then
            self.ambiguous = self.ambiguous + 1
        else
            local name = type(item.itemLink) == 'string' and item.itemLink:match('%[([^%]]+)%]') or nil
            W.Prices:Add(self.groups, {identity=identity, itemID=self.itemKey.itemID,
                name = type(name) == 'string' and name:sub(1, 86) or ('Item ' .. self.itemKey.itemID),
                count = item.quantity, buyout = item.buyoutAmount or 0})
        end
    else
        local good, commodity = pcall(a.GetCommoditySearchResultInfo, self.itemKey.itemID, index)
        if not good or type(commodity) ~= 'table' then return false, 'UNCACHED_ROW' end
        if commodity.itemID ~= self.itemKey.itemID or
            not W.Math.ValidInteger(commodity.quantity, 1, 100000000) or
            not validCopper(commodity.unitPrice) or
            commodity.unitPrice * commodity.quantity > 9007199254740991 then
            return false, 'INVALID_COMMODITY_RESULT'
        end
        row=commodity
        W.Prices:Add(self.groups, {identity='commodity:' .. tostring(self.itemKey.itemID),
            itemID = self.itemKey.itemID, name='Commodity ' .. self.itemKey.itemID,
            count=commodity.quantity, buyout=commodity.unitPrice * commodity.quantity})
    end
    if self.offerBook and index<=1000 then
        local commodity=self.kind=='COMMODITY'
        local total=commodity and row.unitPrice*row.quantity or row.buyoutAmount
        self.offerBook[index]={index=index,itemID=self.itemKey.itemID,itemKey=self.itemKey,
            name=self.displayItem and self.displayItem.name,icon=self.displayItem and self.displayItem.icon,
            itemLink=row.itemLink or (self.displayItem and self.displayItem.itemLink),quantity=row.quantity,unit=commodity and row.unitPrice or
                (total and total>0 and total/row.quantity or nil),total=total,commodity=commodity,
            bid=row.minBid or row.bidAmount,auctionID=row.auctionID,numOwnerItems=row.numOwnerItems,
            owned=row.containsOwnerItem or row.containsAccountItem,
            detail=commodity and 'Price level' or 'Individual auction'}
    end
    return true
end
function T:Tick()
    if not self:IsActive() then return true end
    if not self:Guard() then return true end
    if elapsed(self.startedAt) >= self.timeout then
        self:Stop('PARTIAL', 'TARGET_QUERY_TIMEOUT_NO_COMPLETE_RESULTS'); return true
    end
    local a = W.Compat.auction
    if self.state == 'REQUESTED' then
        if not self.kind then return false end
        local fullFn = a[self.kind=='ITEM' and 'HasFullItemSearchResults' or 'HasFullCommoditySearchResults']
        local good, full = pcall(fullFn, self.kind == 'ITEM' and self.wowKey or self.itemKey.itemID)
        if not good or full ~= true then return false end
        local countFn = a[self.kind=='ITEM' and 'GetNumItemSearchResults' or 'GetNumCommoditySearchResults']
        local counted, number = pcall(countFn, self.kind == 'ITEM' and self.wowKey or self.itemKey.itemID)
        if not counted or not W.Math.ValidInteger(number, 0, self.maxRows) then
            self:Stop('PARTIAL', 'INVALID_OR_EXCESSIVE_TARGET_ROW_COUNT'); return true
        end
        self.expected = number
        self.state = 'READING'
        self.message = ('Reading %d %s results in frame-budgeted slices.'):format(number, self.kind)
    end
    if self.state ~= 'READING' then return false end
    local start
    if type(debugprofilestop) == 'function' then local good, t = pcall(debugprofilestop); if good then start = t end end
    local n = 0
    while self.index <= self.expected and n < self.batchSize do
        if start and type(debugprofilestop) == 'function' then
            local good, current = pcall(debugprofilestop)
            if good and current - start > 1.6 then break end
        end
        local ok, reason = self:ReadRow(self.index)
        if not ok then self.invalid = self.invalid + 1; self:Stop('PARTIAL', reason); return true end
        self.processed = self.processed + 1
        self.index = self.index + 1
        n = n + 1
    end
    if self.index <= self.expected then return false end
    local count=a[self.kind=='ITEM' and 'GetNumItemSearchResults' or 'GetNumCommoditySearchResults']
    local ok,number=pcall(count,self.kind=='ITEM' and self.wowKey or self.itemKey.itemID)
    if not ok or number~=self.expected then
        self:Stop('PARTIAL','TARGET_RESULT_COUNT_CHANGED');return true
    end
    if not self:Guard() then return true end
    local items, nVariants = {}, 0
    for identity, group in pairs(self.groups) do
        nVariants = nVariants + 1
        if nVariants > self.maxVariants then
            self:Stop('PARTIAL', 'TARGET_VARIANTS_OVER_LIMIT'); return true
        end
        items[identity] = W.Prices:Finalize(group)
    end
    local candidate = {
        queryKey = self.queryKey, itemID = self.itemKey.itemID, itemLevel = self.itemKey.itemLevel,
        itemSuffix = self.itemKey.itemSuffix, battlePetSpeciesID = self.itemKey.battlePetSpeciesID,
        updatedAt = W.Clock(), resultCount = self.expected, ambiguous = self.ambiguous,
        source = self.origin=='QUICK_OPEN' and 'AH_OPEN_QUICK_REFRESH' or 'PLAYER_INITIATED_TARGET_SEARCH', kind = self.kind,
        association = self.association, status = 'COMPLETE_TARGET_QUERY',
        items = items, variantCount = nVariants, venueStatus=self.scope.status,
    }
    local job,scope,groups=W.Scheduler.generation,self.scope,self.groups
    local committed, errorText = W.Storage:CommitTarget(scope, candidate)
    -- Commit can publish to subscribers that start another request or close the venue.
    if job~=W.Scheduler.generation or scope~=self.scope or groups~=self.groups or self.state~='READING' then
        return self.state~='REQUESTED' and self.state~='READING'
    end
    if not committed then self:Stop('INVALID', errorText); return true end
    self.state = 'COMPLETE'
    self.message = ('Saved %d %s listings; %d priced variant groups; %d missing exact links.'):
        format(self.expected, self.kind, nVariants, self.ambiguous)
    self.lastResult = {marketKey = self.scope.key, queryKey = self.queryKey,
        at = candidate.updatedAt, count = candidate.resultCount, variants = nVariants}
    self.groups = nil
    W.Scheduler:Cancel()
    W.Diagnostics:Record('INFO', self.message)
    if self.origin~='QUICK_OPEN' then W.Notify('Price refreshed.') end
    W.Refresh()
    return true
end
function T:Stop(state, message)
    self.offerBook=nil
    self.state, self.message = state, tostring(message)
    self.groups = nil
    W.Scheduler:Cancel()
    W.Diagnostics:Record(state == 'INVALID' and 'ERROR' or 'WARN', 'Targeted search ' .. state .. ': ' .. tostring(message))
    W.Refresh()
end
function T:Cancel()
    if not self:IsActive() then return false end
    self:Stop('CANCELLED', 'USER_CANCELLED')
    return true
end
function T:Closed()
    self.offerBook=nil
    if self:IsActive() then self:Stop('CANCELLED', 'AH_CLOSED_OR_SESSION_CHANGED') end
end
function T:LastForItem(marketKey, itemID)
    local db = W.Storage.account
    local market = db and db.targeted.markets[marketKey]
    local latest, matched
    if market then
        for _, rec in pairs(market.records) do
            if rec.itemID == itemID and (not latest or latest < rec.updatedAt) then
                latest, matched = rec.updatedAt, rec
            end
        end
    end
    return matched
end
function T:QuoteExact(identity, marketKey)
    local db = W.Storage.account
    local market = db and db.targeted.markets[marketKey]
    local best, item
    if market then
        for _, rec in pairs(market.records) do
            if rec.items[identity] and rec.items[identity].referenceCopper and
                (not best or best.updatedAt < rec.updatedAt) then
                best, item = rec, rec.items[identity]
            end
        end
    end
    if not best then return nil end
    local age = math.max(0, W.Clock() - best.updatedAt)
    return {status=age > 172800 and 'STALE' or 'LIMITED_EVIDENCE',
        priceCopper=item.referenceCopper, referenceCopper=item.referenceCopper,
        floorCopper=item.floorCopper, listings=item.listings, units=item.units,
        medianCopper=item.medianCopper,p10Copper=item.p10Copper,p75Copper=item.p75Copper,
        averageCopper=item.averageCopper,variationPct=item.variationPct,spreadPct=item.spreadPct,
        nearReferenceUnits=item.nearReferenceUnits,pricedListings=item.pricedListings,
        ageSeconds=age, observedAt=best.updatedAt, marketKey=marketKey,
        source=best.source or 'PLAYER_INITIATED_TARGET_SEARCH', method=item.method,
        identity=identity, venueStatus=best.venueStatus or
            (type(marketKey)=='string' and marketKey:match('^WC[34]/') and
                (marketKey:match('/LOCAL/N%d+/') and 'AUTOMATIC_AUCTIONEER_SCOPED' or 'AUTOMATIC_SESSION_SCOPED') or 'PLAYER_DECLARED_ZONE_SCOPED'),
        eventAssociation='SHARED_EVENT_TEMPORALLY_ASSOCIATED',
        kind=best.kind}
end

-- User input convenience is deliberately separate from the strict numeric parser.
function T:Resolve(text)
    local parsed=self:Parse(text)
    if parsed then return parsed end
    if type(text)~='string' or #text>600 then return nil,'Enter an item name, link, or item ID.' end
    text=text:match('^%s*(.-)%s*$')
    if text=='' then return nil,'Enter an item name, link, or item ID.' end
    local function fromIdentity(identity)
        if type(identity)~='string' then return nil end
        local id,suffix=identity:match('^id=(%d+);e=0;g=0,0,0,0;s=([%-]?%d+);b=$')
        if not id then return nil end
        return {itemID=tonumber(id),itemLevel=0,itemSuffix=tonumber(suffix),battlePetSpeciesID=0}
    end
    if text:find('|Hitem:',1,true) or text:match('^item:') then
        local identity=W.Identity:FromLink(text)
        local key=fromIdentity(identity)
        if key then return key end
        return key,'This link has a specialized variant. Select it from live auction results instead.'
    end
    local market=W.Storage:GetMarket(W.Scope:ReadMarketKey())
    local snapshot=market and ((market.partial and (not market.snapshots[1] or
        market.partial.finishedAt>market.snapshots[1].finishedAt) and market.partial) or market.snapshots[1])
    if not snapshot then return nil,'No saved name index. Use Buy & browse, then Add to watchlist, or enter the item ID.' end
    local match,matchKey
    for identity,entry in pairs(snapshot.items or {}) do
        if type(entry.name)=='string' and entry.name:lower()==text:lower() then
            local key=fromIdentity(identity)
            if not key then return nil,'More precise item selection is required; use the live result or full item key.' end
            local serial=W.Storage:WatchKey(key)
            if matchKey and serial~=matchKey then return nil,'Several variants share this name. Select a live result instead.' end
            match,matchKey=key,serial
        end
    end
    if match then return match end
    return match,'No exact saved name match. Use Buy & browse or enter an item ID.'
end
-- Cache the last human-name lookup for UI redraws. No network request and no unbounded index.
local rawResolve=T.Resolve
local lastToken,lastKey,lastError,lastAccount,lastFull,lastPartial,lastFullItems,lastPartialItems
function T:Resolve(text)
    if type(text)~='string' or text:find('|',1,true) or text:match('^%s*%d') or text:match('^item:') then
        return rawResolve(self,text)
    end
    local key=W.Scope:ReadMarketKey()
    local market=W.Storage:GetMarket(key)
    local full=market and market.snapshots and market.snapshots[1]
    local partial=market and market.partial
    local token=tostring(key)..'/'..tostring(full and full.id)..'/'..tostring(partial and partial.id)..'/'..text:lower():sub(1,601)
    if token~=lastToken or lastAccount~=W.Storage.account or lastFull~=full or lastPartial~=partial or
        lastFullItems~=(full and full.items) or lastPartialItems~=(partial and partial.items) then
        lastToken=token;lastAccount=W.Storage.account;lastFull=full;lastPartial=partial
        lastFullItems=full and full.items;lastPartialItems=partial and partial.items
        lastKey,lastError=rawResolve(self,text)
    end
    if lastKey then return {itemID=lastKey.itemID,itemLevel=lastKey.itemLevel,
        itemSuffix=lastKey.itemSuffix,battlePetSpeciesID=lastKey.battlePetSpeciesID}end
    return nil,lastError
end
