-- G5: query player-owned auctions and bids, no automatic cancellations.
local _,W=...
W.Owned={state='IDLE',mode='auctions',items={},page=0,pageSize=8,message='Refresh to see your auctions.'}
local O=W.Owned
function O:CheckTimeout()
    if self.state=='REQUESTED' and self.requestAt and W.Clock()-self.requestAt>=30 then
        self.state='TIMEOUT';self.message='Auction-list request timed out; refresh manually.';return true
    end
    return false
end
function O:Query(mode)
    if W.QuickScan then W.QuickScan:Yield('Player request',true) end
    self:CheckTimeout()
    if self.state=='REQUESTED' or (W.QueryBusy and W.QueryBusy('owned')) then
        return false,'Finish the current market request or review first.'
    end
    mode=mode=='bids' and 'bids' or 'auctions'
    if not W.runtime.ahOpen then return false,'Open the Auction House first.' end
    if not W.Compat.build or not (W.Compat.build.runtimeAllowed or W.Compat.build.exactTarget) then
        return false,'Unqualified client build.' end
    if type(InCombatLockdown)=='function' and InCombatLockdown() then return false,'Unavailable in combat.' end
    local scope=W.Scope:Snapshot()
    local a=W.Compat.auction
    local fn=a and a[mode=='bids' and 'QueryBids' or 'QueryOwnedAuctions']
    if not scope.ready then return false,scope.reason or 'Waiting for the Auction House.' end
    if type(fn)~='function' then return false,'Blizzard owned/bids query unavailable.' end
    if type(a.IsThrottledMessageSystemReady)=='function' then
        local ok,ready=pcall(a.IsThrottledMessageSystemReady)
        if not ok or ready~=true then return false,'Auction House query service is busy.' end
    end
    local allowed,why=W.Storage:TargetQueryEligibility()
    if not allowed then return false,why end
    self.mode=mode;self.session=W.runtime.ahSession;self.marketKey=scope.key
    self.items={};self.page=0;self.state='REQUESTED'
    self.requestAt=W.Clock()
    self.message='Awaiting Blizzard '..(mode=='bids' and 'bid' or 'owned-auction')..' results.'
    W.Storage:MarkTargetQuery()
    -- QueryBids requires both an empty sort array and an auction-ID array.
    local ok,err
    if mode=='bids' then ok,err=pcall(fn,{},{})
    else ok,err=pcall(fn,{}) end
    if not ok then self.state='ERROR';self.message='Blizzard query failed: '..tostring(err)
        return false,self.message end
    return true
end
function O:OnResults(event)
    if self.state~='REQUESTED' and self.state~='READY' then return end
    if not W.runtime.ahOpen or self.session~=W.runtime.ahSession or
        self.marketKey~=W.Scope:Snapshot().key then self:Closed();return end
    if (event=='OWNED_AUCTIONS_UPDATED' and self.mode~='auctions') or
       (event=='BIDS_UPDATED' and self.mode~='bids') then return end
    local a=W.Compat.auction
    -- GetBidInfo requires an index; use GetBids' array contract instead.
    local fn=a and a[self.mode=='bids' and 'GetBids' or 'GetOwnedAuctions']
    if type(fn)~='function' then self.message='Cannot read the auction result API.';return end
    local ok,rows=pcall(fn)
    if not ok or type(rows)~='table' then self.state='ERROR';self.message='Auction rows unavailable.';return end
    local out={}
    self.returnedCount=#rows;self.truncated=#rows>2000
    for i=1,math.min(2000,#rows) do
        local r=rows[i]
        if type(r)=='table' and W.Math.ValidInteger(r.auctionID or r.bidID,1) then
            local key=r.itemKey
            out[#out+1]={auctionID=r.auctionID or r.bidID,
                itemID=type(key)=='table' and key.itemID or 0,
                name=(type(r.itemLink)=='string' and r.itemLink:match('%[([^%]]+)%]')) or
                    (type(key)=='table' and 'Item '..tostring(key.itemID)) or 'Auction',
                quantity=r.quantity,buyout=r.buyoutAmount or 0,itemKey=key,itemLink=r.itemLink,
                bid=r.bidAmount or 0,minBid=r.minBid,bidder=r.bidder,status=r.status,timeLeft=r.timeLeft,
                timeLeftSeconds=r.timeLeftSeconds}
        end
    end
    self.items=out;self.state='READY'
    local fullFn=a[self.mode=='bids' and 'HasFullBidResults' or 'HasFullOwnedAuctionResults']
    local good,full=W.SafeCall(fullFn)
    self.complete=good and full==true and not self.truncated
    self.message=(#out==0 and 'No '..(self.mode=='bids' and 'bids' or 'auctions')..' returned' or
        (#out..' '..(self.mode=='bids' and 'bids' or 'auctions')..' returned'))..
        (self.complete and ' · complete response.' or ' · incomplete response; use Blizzard view for additional listings.')
    for _,item in ipairs(out) do
        if item.itemKey and type(a.GetItemKeyInfo)=='function' and item.name:match('^Item %d+$') then
            local named,info=pcall(a.GetItemKeyInfo,item.itemKey)
            if named and type(info)=='table' and type(info.itemName)=='string' and info.itemName~='' then item.name=info.itemName end
        end
    end
    W.Refresh()
end
function O:Closed()
    self.session=nil;self.state='IDLE';self.items={};self.page=0
    self.message='Owned auctions and bids are visible only during an AH session.'
end
