-- G5: native-backed, player-initiated browse results. Never treated as a saved price snapshot.
local _, W = ...
W.Browse = {state='IDLE', message='Search by name to browse the live Auction House.',
    results={}, page=0, pageSize=8, resultLimit=2000, association='NOT_EVALUATED'}
local B=W.Browse
-- Verified Enum.AuctionHouseFilter values: 6..12 are actual quality bands;
-- 13 is LegendaryCraftedItemOnly (NOT HeirloomQuality).
local qualityNames={'PoorQuality','CommonQuality','UncommonQuality','RareQuality',
    'EpicQuality','LegendaryQuality','ArtifactQuality'}
local classes={all=nil,weapons=2,armor=4,consumables=0,trade=7,recipes=9,containers=1,ammo=6,quests=12,misc=15}
local function readName(key)
    local a=W.Compat.auction
    if a and type(a.GetItemKeyInfo)=='function' then
        local ok, info=pcall(a.GetItemKeyInfo,key)
        if ok and type(info)=='table' and type(info.itemName)=='string' then return info.itemName end
    end
    if type(GetItemInfo)=='function' then
        local ok, name=pcall(GetItemInfo,key.itemID)
        if ok and type(name)=='string' then return name end
    end
    return 'Item '..tostring(key.itemID)
end
function B:CheckTimeout()
    if (self.state=='REQUESTED' or self.state=='RETIRED') and self.requestAt and W.Clock()-self.requestAt>=30 then
        if self.state=='RETIRED' then
            self.state='IDLE';self.message='Previous search cleared. Ready for a new search.'
            self.results={};self.hasMore=false
            return true
        end
        self.state='TIMEOUT';self.message='Search timed out. Try again manually or use Blizzard view.'
        return true
    end
    return false
end
function B:ArmTimeout()
    self.requestAt=W.Clock();self.generation=(self.generation or 0)+1
    local token=self.generation
    if C_Timer and type(C_Timer.After)=='function' then
        C_Timer.After(30.1,function()
            if B.generation==token and B:CheckTimeout() then W.Refresh() end
        end)
    end
end
function B:Guard()
    self:CheckTimeout()
    if W.HasEvent and not W.HasEvent('AUCTION_HOUSE_BROWSE_RESULTS_UPDATED') then
        return false,'Browse result event unavailable; use Blizzard view.'
    end
    if self.state=='RETIRED' then return false,'Previous search is still settling. Try again when the Auction House is ready.' end
    if self.state=='REQUESTED' then return false,'Wait for the current browse request.' end
    if W.QueryBusy and W.QueryBusy('browse') then return false,'Finish the current market request or review first.' end
    if not W.runtime.ahOpen then return false, 'Auction House is closed.' end
    if not W.Compat.build or not (W.Compat.build.runtimeAllowed or W.Compat.build.exactTarget) then
        return false, 'Browse API has not been verified for this client build.'
    end
    if (W.Scan:IsActive() and not W.Scan.pausedForUser) or W.Targeted:IsActive() then
        return false, 'Finish the active scan or item search.'
    end
    if type(InCombatLockdown)=='function' and InCombatLockdown() then
        return false, 'Unavailable in combat.'
    end
    local scope=W.Scope:Snapshot()
    if not scope.ready then return false, scope.reason or 'Preparing the current Auction House visit.' end
    local a=W.Compat.auction
    if type(a)~='table' or type(a.SendBrowseQuery)~='function' or
        type(a.GetBrowseResults)~='function' then
        return false, 'Blizzard browse API is unavailable.'
    end
    return true
end
function B:Query(search,category,options)
    if type(search)~='string' then return false,'Enter a search phrase.' end
    search=search:match('^%s*(.-)%s*$')
    category=classes[category]~=nil and category or (category=='all' and 'all' or 'all')
    if #search>70 or (#search<2 and category=='all') then
        return false,'Enter at least two letters (or select a category).'
    end
    if W.Priority then W.Priority:ManualSearch() end
    local function rejected(reason)
        if W.Priority then W.Priority:ManualRejected()end
        self.message=reason;return false,reason
    end
    local ok,why=self:Guard()
    if not ok then
        return rejected(why)
    end
    local guard,whyGuard=W.Storage:TargetQueryEligibility('MANUAL')
    if not guard then
        return rejected(whyGuard)
    end
    local a=W.Compat.auction
    if type(a.IsThrottledMessageSystemReady)=='function' then
        local good,ready=pcall(a.IsThrottledMessageSystemReady)
        if not good or ready~=true then return rejected('The Auction House query service is busy.') end
    end
    options=type(options)=='table' and options or {}
    local price=Enum and Enum.AuctionHouseSortOrder and Enum.AuctionHouseSortOrder.Price or 0
    local name=Enum and Enum.AuctionHouseSortOrder and Enum.AuctionHouseSortOrder.Name or 1
    local f=Enum and Enum.AuctionHouseFilter or {}
    local qualities={PoorQuality=6,CommonQuality=7,UncommonQuality=8,RareQuality=9,EpicQuality=10,
        LegendaryQuality=11,ArtifactQuality=12}
    local aliases={poor='PoorQuality',common='CommonQuality',uncommon='UncommonQuality',rare='RareQuality',
        epic='EpicQuality',legendary='LegendaryQuality',artifact='ArtifactQuality'}
    local quality=aliases[options.quality] or options.quality
    local filters={}
    if quality and quality~='all' then
        if not qualities[quality] then return rejected('Choose a supported rarity filter.') end
        filters[#filters+1]=f[quality] or qualities[quality]
    else
        -- Include every supported rarity, not only poor through epic.
        for _,key in ipairs(qualityNames) do
            filters[#filters+1]=f[key] or qualities[key]
        end
    end
    if options.exact then filters[#filters+1]=f.ExactMatch or 5 end
    if options.usable then filters[#filters+1]=f.UsableOnly or 2 end
    local lo,hi=options.minLevel,options.maxLevel
    if lo~=nil and not W.Math.ValidInteger(lo,0,999) then return rejected('Minimum level is invalid.') end
    if hi~=nil and not W.Math.ValidInteger(hi,0,999) then return rejected('Maximum level is invalid.') end
    if lo and hi and lo>hi then return rejected('Minimum level cannot exceed maximum level.') end
    local sort=options.sort=='name' and name or price
    local secondary=sort==price and name or price
    local query={searchString=search,sorts={{sortOrder=sort,reverseSort=options.reverse==true},
        {sortOrder=secondary,reverseSort=false}},filters=filters,minLevel=lo,maxLevel=hi}
    self.options={quality=options.quality,exact=options.exact==true,usable=options.usable==true,
        sort=options.sort or 'price',reverse=options.reverse==true,minLevel=lo,maxLevel=hi}
    if category~='all' then query.itemClassFilters={{classID=classes[category]}} end
    self.session=W.runtime.ahSession
    self.marketKey=W.Scope:ReadMarketKey()
    self.state='REQUESTED';self.hasMore=false;self:ArmTimeout()
    self.message='Waiting for Blizzard browse results.'
    self.search=search;self.category=category;self.results={};self.page=0
    self.association='SHARED_BROWSE_EVENT_TEMPORAL_ONLY'
    -- Consume local guard before sending: failed calls may still reach Blizzard.
    W.Storage:MarkTargetQuery()
    local sent,err=pcall(a.SendBrowseQuery,query)
    if not sent then self.state='ERROR';self.message='Blizzard browse query failed: '..tostring(err)
        W.Diagnostics:Record('WARN',self.message);return rejected(self.message) end
    W.Diagnostics:Record('INFO','Browse query submitted ['..category..', quality '..tostring(options.quality or 'all')..
        ', sort '..tostring(options.sort or 'price')..']; player action')
    W.Refresh()
    return true
end
-- An explicit Clear or filter change retires presentation identity without
-- bypassing native query serialization. Late results cannot revive old rows.
function B:Retire()
    if self.state=='REQUESTED' then
        self.state='RETIRED';self.results={};self.hasMore=false
        self.message='Previous browse search cleared; waiting for its native result.'
        return true
    end
    self.state='IDLE';self.results={};self.hasMore=false;self.requestAt=nil
    return false
end
function B:OnResults(event,addedRows)
    if self.state=='RETIRED' then
        self.state='IDLE';self.results={};self.hasMore=false;self.requestAt=nil
        self.message='Previous browse result discarded after Clear.'
        W.Refresh();return
    end
    -- Only a player search or Load more opens a response window. Shared
    -- notifications after it closes cannot replace the player's visible list.
    if self.state~='REQUESTED' then return end
    if self.session~=W.runtime.ahSession or not W.runtime.ahOpen or
        self.marketKey~=W.Scope:ReadMarketKey() then self:Closed();return end
    local a=W.Compat.auction
    local incremental=event=='AUCTION_HOUSE_BROWSE_RESULTS_ADDED' and type(addedRows)=='table'
    local ok,raw
    if incremental then ok,raw=true,addedRows else ok,raw=pcall(a.GetBrowseResults) end
    if not ok or type(raw)~='table' then
        self.state='ERROR';self.message='Browse result API returned no usable rows.';W.Refresh();return
    end
    local observedAt=W.Clock()
    local out,positions={},{}
    local function keyOf(k)
        return table.concat({k.itemID,k.itemLevel or 0,k.itemSuffix or 0,k.battlePetSpeciesID or 0},':')
    end
    if incremental then
        for _,entry in ipairs(self.results) do
            out[#out+1]=entry;positions[keyOf(entry.itemKey)]=#out
        end
    end
    for i=1,math.min(#raw,self.resultLimit) do
        local r=raw[i]
        local key=type(r)=='table' and r.itemKey
        if type(key)=='table' and W.Math.ValidInteger(key.itemID,1,999999999) and
            W.Math.ValidInteger(r.totalQuantity or 0,0,999999999) and
            W.Math.ValidInteger(r.minPrice or 0,0,9007199254740991) then
            local record={itemKey={itemID=key.itemID,itemLevel=key.itemLevel or 0,
                itemSuffix=key.itemSuffix or 0,battlePetSpeciesID=key.battlePetSpeciesID or 0},
                itemID=key.itemID,name=readName(key),itemLink=r.appearanceLink,quantity=r.totalQuantity or 0,
                observedAt=observedAt,minPrice=r.minPrice or 0,owner=r.containsOwnerItem==true}
            local key=keyOf(record.itemKey)
            local pos=positions[key]
            if pos then out[pos]=record
            elseif #out<self.resultLimit then out[#out+1]=record;positions[key]=#out end
        end
    end
    self.results=out
    self.hasMore=false
    if type(a.HasFullBrowseResults)=='function' then
        local good,full=pcall(a.HasFullBrowseResults)
        self.hasMore=good and full==false and #out<self.resultLimit
    end
    self.state='READY'
    self.message=#out==0 and 'No matches returned. Try a broader name or different filters.' or
        (#out..' items returned'..(self.hasMore and ' · more available' or '')..'. Select an item to inspect offers.')
    W.Refresh()
end
function B:More()
    if self.state~='READY' or not W.runtime.ahOpen or self.session~=W.runtime.ahSession then
        return false,'No active browse session.' end
    if not self.hasMore then return false,'No additional browse results are indicated.' end
    if W.Priority then W.Priority:ManualSearch() end
    local guard,reason=self:Guard()
    if not guard then return false,reason end
    if not self.hasMore then return false,'No additional browse results are indicated.' end
    local a=W.Compat.auction
    if type(a.IsThrottledMessageSystemReady)=='function' then
        local good,ready=pcall(a.IsThrottledMessageSystemReady)
        if not good or ready~=true then return false,'Auction House query service is busy.' end
    end
    if type(a.RequestMoreBrowseResults)~='function' then
        return false,'Additional browse pages unavailable in this client.' end
    local ok,why=W.Storage:TargetQueryEligibility('MANUAL')
    if not ok then return false,why end
    W.Storage:MarkTargetQuery()
    self.state='REQUESTED';self.message='Waiting for more browse results.';self:ArmTimeout()
    local sent,err=pcall(a.RequestMoreBrowseResults)
    if not sent then self.state='ERROR';return false,'Additional browse request failed: '..tostring(err) end
    return true
end
function B:Closed()
    self.session=nil;self.state='IDLE';self.results={};self.page=0;self.hasMore=false
    self.message='Browse results cleared when Auction House closes.'
end
