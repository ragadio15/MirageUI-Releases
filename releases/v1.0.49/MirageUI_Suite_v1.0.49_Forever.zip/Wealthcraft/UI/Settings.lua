local _,W=...
local U,F,C=W.UI,W.Widgets,W.Widgets.palette
function U:ToggleSetting(key)
    if not W.Storage:IsWritable()then self:Message('Settings are read only.');return end
    local s=self:Settings();s[key]=not s[key]
    if key=='autoScan' or key=='autoFullScan' then W.Automation:SettingsChanged()end
    if key=='quickScan' then
        if not s[key] then W.QuickScan:Closed() elseif W.runtime.ahOpen then W.QuickScan:Opened()end
    end
    if key=='personalize' then self.shopUsable=s[key]end
    self:Refresh()
end
function U:CreateSettings()
    local p=self:Page('settings','Settings','Changes save immediately.')
    self.settingButtons={}
    local function toggle(parent,key,title,help,y)
        F:Text(parent,0,y,760,24,title,17,C.text)
        F:Text(parent,0,y+27,785,26,help,13,C.muted)
        self.settingButtons[key]=F:ButtonAt(parent,870,y+4,120,34,'On',function()U:ToggleSetting(key)end)
    end
    F:Text(p,0,68,990,24,'Prices and trading',16,C.secondary)
    toggle(p,'autoScan','Automatic Auction House scans','Refresh local market prices and useful items while you visit an auctioneer.',100)
    toggle(p,'personalize','Filter for my character','Show equipment usable at your level.',162)
    F:Text(p,0,228,260,24,'Buy price tolerance',16,C.text)
    self.toleranceLabel=F:Text(p,316,232,90,24,'',16,C.secondary,'CENTER')
    F:ButtonAt(p,270,225,36,32,'−',function()U:ChangeTolerance(-50)end)
    F:ButtonAt(p,416,225,36,32,'+',function()U:ChangeTolerance(50)end)
    F:Text(p,486,228,500,49,'Prices above your tolerance always need approval.',13,C.muted)
    F:Text(p,0,280,990,24,'Character and inventory',16,C.secondary)
    F:Text(p,0,312,990,50,'Bags, bank and learned professions refresh automatically when you use those services.',14,C.muted)
    F:Text(p,0,384,990,40,'Your character and local Auction House are detected automatically.',14,C.muted)
    F:Text(p,0,438,990,24,'Appearance',16,C.secondary)
    F:Text(p,0,480,110,24,'Window scale',16,C.text)
    F:ButtonAt(p,130,475,36,32,'−',function()W.Storage:Scale(-.05);W.AuctionDesk:ApplyScale();U:Refresh()end)
    self.scaleLabel=F:Text(p,174,480,70,24,'',15,C.secondary,'CENTER')
    F:ButtonAt(p,252,475,36,32,'+',function()W.Storage:Scale(.05);W.AuctionDesk:ApplyScale();U:Refresh()end)
    F:ButtonAt(p,302,475,116,32,'Center',function()W.AuctionDesk:ResetPosition()end)
    self.tooltipButton=F:ButtonAt(p,436,475,260,32,'Tooltip prices: Automatic',function()
        F:Choose(U.tooltipButton,{{'AUTO','Automatic'},{'ON','On'},{'OFF','Off'}},function(value)W.Storage:SetTooltipMode(value);U:Refresh()end)
    end)
    self.deskToggle=F:ButtonAt(p,710,475,280,32,'Custom Auction Desk: On',function()
        W.AuctionDesk:SetEnabled(not W.AuctionDesk:Enabled());U:Refresh()
    end)
    self.layoutButton=F:ButtonAt(p,0,524,240,34,'Layout: Automatic',function()
        F:Choose(U.layoutButton,{{'AUTO','Automatic'},{'COMPACT','Small screen'},{'DESKTOP','Desktop'}},function(value)U:Result(U:SetLayoutPreference(value))end)
    end)
    self.layoutInfo=F:Text(p,255,532,400,28,'',14,C.muted)
    F:ButtonAt(p,674,524,150,34,'Advanced',function()U:Select('settingsAdvanced')end)
    F:ButtonAt(p,836,524,154,34,'Recovery',function()U:Select('diagnostics')end)
    p=self:Page('settingsAdvanced','Advanced settings','Changes save immediately.')
    toggle(p,'showItemIDs','Technical IDs','Include item identifiers in item lists.',82)
    toggle(p,'autoFullScan','Full market snapshots','Update the wider market when the Auction House allows a full scan.',152)
    toggle(p,'quickScan','Quick item checks','Refresh favorites and useful carried items between full scans.',222)
    toggle(p,'journalEnabled','Manual Journal','Show the optional manual transaction journal in the Options menu.',292)
    F:ButtonAt(p,0,362,270,36,'Back to settings',function()U:Select('settings')end)
    p=self:Page('diagnostics','Diagnostics and recovery','')
    F:ButtonAt(p,0,50,210,38,'Copy field report',function()U:ShowReport()end,true)
    F:ButtonAt(p,222,50,220,38,'Copy startup report',function()U:ShowReport(W.StartupReport(),'Startup report')end)
    F:ButtonAt(p,454,50,228,38,'Settings',function()U:Select('settings')end)
    self.acknowledgeTrade=F:ButtonAt(p,694,50,296,38,'Mark unverified trade checked',function()
        local ok,why=W.Trading:ClearUnverified();U:Message(why);U:Refresh()
    end)
    F:ButtonAt(p,0,102,210,34,'Check saved data',function()
        W.Storage:Marker();U:Message('Save checkpoint recorded. Reload the interface, then check its status here.');U:Refresh()
    end)
    F:ButtonAt(p,222,102,220,34,'Use Blizzard interface',function()W.AuctionDesk:NativeFallback()end)
    local box=F:Box(p,0,154,990,416,C.panel)
    self.diagnosticText=F:Text(box,22,18,946,390,'',14,C.text)
end
function U:Refresh_settingsAdvanced() return self:Refresh_settings() end
function U:ChangeTolerance(delta)
    if not W.Storage:IsWritable()then return end
    local s=self:Settings();s.priceToleranceBps=math.max(0,math.min(1000,(s.priceToleranceBps or 200)+delta));self:Refresh()
end
function U:Refresh_settings()
    local s=self:Settings()
    for k,b in pairs(self.settingButtons)do
        b.label:SetText(s[k] and 'On' or 'Off');b:Select(s[k]);b:ApplyAvailability(W.Storage:IsWritable())
    end
    self.toleranceLabel:SetText(string.format('%.1f%%',W.Trading:Tolerance()/100))
    self.scaleLabel:SetText(string.format('%.0f%%',W.AuctionDesk:DisplayScale()*100))
    self.tooltipButton.label:SetText('Tooltip prices: '..(({AUTO='Automatic',ON='On',OFF='Off'})[s.tooltipMode or 'AUTO'] or 'Automatic'))
    self.deskToggle.label:SetText('Custom Auction Desk: '..(W.AuctionDesk:Enabled() and 'On' or 'Off'))
    local pref=s.screenLayout or 'AUTO'
    local name=({AUTO='Automatic',COMPACT='Small screen',DESKTOP='Desktop'})[pref] or 'Automatic'
    self.layoutButton.label:SetText('Layout: '..name)
    self.layoutButton:ApplyAvailability(W.Storage:IsWritable())
    self.layoutInfo:SetText('Using '..(self.layout=='compact' and 'small-screen' or 'desktop')..' layout')
end
function U:Refresh_diagnostics()
    local s=W.Storage;local scan=W.Scan;local cache=W.ItemCache:Progress();local q=W.QuickScan
    local hold=W.Trading:Unverified()
    self.acknowledgeTrade:ApplyAvailability(hold~=nil and W.Storage:IsWritable() and W.Trading.state=='IDLE')
    self.diagnosticText:SetText(table.concat({
        'WealthCraft '..W.version..' · '..W.Compat:Format(),
        'Startup: '..W.runtime.startupStage..' · '..(W.runtime.lastError or 'No caught errors'),'',
        'Save checkpoint: '..(s.restoreObserved and 'Restored from an earlier load' or 'No earlier checkpoint observed'),
        'Stored markets: '..s:MarketCount()..' · schema '..W.schemaVersion,'',
        'Full scan: '..scan.state..' · '..tostring(scan.processed or 0)..' / '..tostring(scan.expected or 0)..' rows',
        'Missing rows recovered: '..tostring(scan.recovered or 0)..' · remaining '..tostring(scan.unresolved or 0),
        'Metadata: '..cache.submitted..' requests / '..cache.distinct..' unique · '..cache.queued..' waiting',
        'Automatic full refresh: '..W.Automation.state..' · '..tostring(W.Automation.reason or 'No blocker'),
        'Quick refresh: '..q.state..' · '..q.completed..' completed / '..q.issued..' issued',
        'Quick refresh reason: '..tostring(q.reason or 'No blocker'),
        'Last target origin: '..tostring(W.Targeted.origin or 'None'),'',
        'Trading: '..W.Trading.state..' · '..W.Trading.message,
        hold and ('LAST TRADE REQUIRES CHECK: '..hold.kind..' / '..tostring(hold.itemID or 'unknown item')..' / '..tostring(hold.at)..
            ' · Check mail or My auctions FIRST, then mark this trade checked above.') or 'Unverified trade hold: none',
        'Market source: '..tostring(W.runtime.venueSource or 'No current venue'),
        'Native interface: '..(W.AuctionDesk.active and 'Visually replaced; underlying session retained' or 'Available'),
        'Layout: '..(U.layout or 'desktop')..' / preference '..tostring(U:Settings().screenLayout or 'AUTO')..' / UIParent '..math.floor(UIParent:GetWidth())..' x '..math.floor(UIParent:GetHeight()),
        'Window fit: '..string.format('%.3f',U.frame and U.frame:GetEffectiveScale()/(UIParent:GetEffectiveScale() or 1) or 0)..
            ' relative / '..tostring(U.width)..' x '..tostring(U.height)..' / inset '..
            string.format('%.1f',W.AuctionDesk:SafeInset(UIParent:GetWidth(),UIParent:GetHeight())),
        'Integration: '..tostring(W.Integration.mode),
        '', 'Use the copy buttons for complete details, including rejected events and price provenance.'
    },'\n'))
end
