-- One player-facing window, shared by the live Auction Desk and offline research.
local _,W=...
W.UI={pages={},section='buy',activePage='buy',dirty=true}
local U=W.UI
local F,C=W.Widgets,W.Widgets.palette
-- P33: Compact viewport with content-aware page extents and disciplined whitespace.
-- Critical controls remain readable; scroll limits are measured from the
-- active page rather than 652 empty desktop units. Navigation and footer are
-- physically outside the scroll clipping rectangle.
U.desktopWidth=1220;U.compactWidth=1050;U.desktopHeight=800;U.compactHeight=744
U.width=U.desktopWidth;U.height=U.desktopHeight
U.contentWidth=990;U.contentHeight=652
-- Authored content height (including padding) is deliberately different per
-- tab. Pages with no overflow must not show a distracting scrollbar.
U.compactPageExtents={buy=530,sell=554,owned=430,research=570,watchlist=554,inventory=495,
    overview=556,market=564,craft=570,ledger=540,reports=578,settings=580,
    settingsAdvanced=435,diagnostics=577}
U.layout='desktop'
local compactTabs={{'buy','Shop'},{'sell','Sell'},{'owned','My auctions'},{'overview','Insights'},{'research','Research'}}
local function safeSize()
    local w,h=UIParent:GetWidth(),UIParent:GetHeight()
    if not W.Math.ValidNumber(w) or w<=0 then w=1600 end
    if not W.Math.ValidNumber(h) or h<=0 then h=900 end
    return w,h
end
function U:PreferredLayout()
    local pref=self:Settings().screenLayout
    if pref=='COMPACT' then return 'compact' end
    if pref=='DESKTOP' then return 'desktop' end
    local w,h=safeSize()
    -- Determine usable *UI* dimensions, not physical pixel resolution: this
    -- catches high-DPI Surface installations with aggressive Blizzard UI scale.
    return (w<1280 or h<780 or w/h<1.65) and 'compact' or 'desktop'
end
function U:ReflowCompactPages(small)
    local tables={
        shopTable={compact=6},sellTable={compact=6},ownedTable={compact=6},
        watchTable={compact=6},inventoryTable={compact=6},historyTable={compact=6},
        recipeTable={compact=5},materialTable={compact=5},ledgerTable={compact=6},
    }
    for name,rule in pairs(tables)do
        local tableFrame=self[name]
        if tableFrame and type(tableFrame.ConfigureRows)=='function' then
            tableFrame:ConfigureRows(small and rule.compact or tableFrame.maxCount)
        end
    end
    local function move(widget,parent,x,y)
        if not widget or not parent then return end
        widget:ClearAllPoints()
        widget:SetPoint('TOPLEFT',parent,'TOPLEFT',x,-y)
    end
    if not small and self.sellBreakdown and self.sellBreakdown:GetParent()==self.pages.sell then
        move(self.sellBreakdown,self.pages.sell,0,494)
    end
    move(self.ownedNote,self.pages.owned,520,small and 445 or 530)
    move(self.watchResearch,self.pages.watchlist,816,small and 512 or 556)
end
function U:SetActivePageExtent()
    if not self.content or not self.scrollViewport then return end
    local compact=self.layout=='compact'
    local height=compact and (self.compactPageExtents[self.section] or 652) or 652
    -- The list, details card and estimate can have different bottom edges.
    -- A content rectangle shorter than the viewport should fill it cleanly.
    if self.section=='buy' and self.comparingSell then
        local listEnd=134+34+self.shopTable.count*self.shopTable.rowHeight+12+30+14+135
        height=math.max(height,134+self.sellForm:GetHeight()+12,listEnd+12)
    elseif compact and self.section=='sell' and not (self.sellSelected and self.sellCompactDetail) then
        local card=self.sellSelected and self.sellForm or self.sellEmpty
        if card then height=math.max(height,100+card:GetHeight()+12)end
        if self.sellSelected then height=math.max(height,494+135+12)end
    elseif self.section=='buy' and self.shopMode=='offers' then
        height=math.max(height,134+416+12)
    end
    height=math.max(height,self.scrollViewport:GetHeight())
    if self.content:GetHeight()~=height then self.content:SetHeight(height) end
    self.contentHeight=height
    self:UpdateScrollBar()
end
function U:ApplyResponsiveLayout()
    if not self.frame then return false end
    local layout=self:PreferredLayout()
    if layout==self.layout and self.layoutInitialized then return false end
    if self.choiceMenu then self.choiceMenu:Hide() end
    if self.nestedMenu then self.nestedMenu:Hide()end
    local small=layout=='compact'
    local r=self.frame
    self.layout=layout;self.layoutInitialized=true
    if small and self.shopSelected and self.shopMode~='offers' then
        self.shopCompactDetail=true
    end
    self.width=small and self.compactWidth or self.desktopWidth
    self.height=small and self.compactHeight or self.desktopHeight
    r:SetSize(self.width,self.height)
    self.topBar:SetSize(self.width,small and 72 or 84)
    self.brandMark:SetSize(small and 46 or 52,small and 46 or 52)
    self.brandMark:ClearAllPoints()
    self.brandMark:SetPoint('TOPLEFT',self.topBar,'TOPLEFT',small and 20 or 22,small and -13 or -16)
    local headingFont,_,headingFlags=self.brandTitle:GetFont()
    if headingFont then self.brandTitle:SetFont(headingFont,small and 27 or 29,headingFlags or '')end
    self.navPanel:SetShown(not small)
    self.compactBar:SetShown(small)
    self.desktopNative:SetShown(not small)
    self.desktopClose:SetShown(not small)
    self.dragHandle:SetSize(small and 460 or 584,small and 72 or 84)
    self.compactBar:ClearAllPoints()
    self.compactBar:SetPoint('TOPLEFT',r,'TOPLEFT',14,-(small and 79 or 91))
    self.contextLabel:ClearAllPoints()
    self.contextLabel:SetPoint('TOPLEFT',self.topBar,'TOPLEFT',small and 596 or 772,small and -12 or -22)
    self.contextLabel:SetWidth(small and 420 or 427)
    self.quickStatus:ClearAllPoints()
    self.quickStatus:SetPoint('TOPLEFT',self.topBar,'TOPLEFT',small and 596 or 772,small and -39 or -47)
    self.quickStatus:SetWidth(small and 420 or 427)
    self.scanMenu:ClearAllPoints()
    if small then
        self.scanMenu:SetPoint('TOPLEFT',r,'TOPLEFT',0,0)
    else
        self.scanMenu:SetPoint('BOTTOMLEFT',self.desktopNative,'TOPLEFT',0,40)
    end
    self.scanMenu:SetFrameLevel(self.dragHandle:GetFrameLevel()+1)
    self.scanMenu:SetShown(not small)

    -- Top, body, and footer are independent bounded regions.
    local inset=small and 30 or 212
    local top=small and 133 or 100
    local viewportHeight=small and (self.height-top-55) or (self.height-top-48)
    self.scrollViewport:ClearAllPoints()
    self.scrollViewport:SetPoint('TOPLEFT',r,'TOPLEFT',inset,-top)
    self.scrollViewport:SetSize(self.contentWidth,viewportHeight)
    self.content:SetScale(1)
    self.viewportPanel:ClearAllPoints()
    self.viewportPanel:SetPoint('TOPLEFT',r,'TOPLEFT',inset-7,-(top-7))
    self.viewportPanel:SetSize(self.contentWidth+21,viewportHeight+13)
    self.scrollBar:ClearAllPoints()
    self.scrollBar:SetPoint('TOPLEFT',r,'TOPLEFT',inset+self.contentWidth+5,-top)
    self.scrollBar:SetHeight(viewportHeight)
    self.footerPanel:ClearAllPoints()
    self.footerPanel:SetPoint('TOPLEFT',r,'TOPLEFT',inset-7,-(self.height-47))
    self.footerPanel:SetSize(self.contentWidth+21,41)
    self.footer:ClearAllPoints()
    self.footer:SetPoint('TOPLEFT',self.footerPanel,'TOPLEFT',7,-12)
    self.footer:SetWidth(self.contentWidth-240)
    self.scrollHint:ClearAllPoints()
    self.scrollHint:SetPoint('TOPLEFT',self.footerPanel,'TOPLEFT',self.contentWidth-214,-12)
    self.scrollHint:SetWidth(214)
    self:ReflowCompactPages(small)
    self.sellGeometry=nil
    self.scrollViewport:SetVerticalScroll(0)
    self:SetActivePageExtent()
    if self.modalBox then
        self.modalBox:ClearAllPoints()
        self.modalBox:SetPoint('CENTER',self.modal,'CENTER',0,0)
    end
    self:RefreshLayoutSelection()
    self.dirty=true
    return true
end
-- Native ScrollFrame owns clipping. On small screens every page can reach
-- its bottom-most control through a visible themed thumb or mouse wheel.
function U:ScrollBy(delta)
    W.Priority:RecordInteraction()
    local scroll=self.scrollViewport
    if not scroll then return end
    local range=math.max(0,scroll:GetVerticalScrollRange() or 0)
    local value=math.max(0,math.min(range,(scroll:GetVerticalScroll() or 0)+delta))
    scroll:SetVerticalScroll(value)
    self:UpdateScrollBar()
    if self.choiceMenu and self.choiceMenu:IsShown() then self.choiceMenu:Hide() end
end
function U:UpdateScrollBar()
    if not self.scrollViewport or not self.scrollBar then return end
    local scroll,bar=self.scrollViewport,self.scrollBar
    local range=math.max(0,scroll:GetVerticalScrollRange() or 0)
    -- During the first pre-render layout the scroll range may be zero even
    -- though viewport and child sizes are known. The native range event
    -- reconciles later, so do not permanently hide the scrollbar.
    if range<1 and scroll:GetHeight()>0 then
        range=math.max(0,(self.content:GetHeight() or self.contentHeight)-scroll:GetHeight())
    end
    self.scrollBarUpdating=true
    bar:SetMinMaxValues(0,range)
    local value=math.min(range,scroll:GetVerticalScroll() or 0)
    bar:SetValue(value)
    self.scrollBarUpdating=false
    bar:SetShown(range>1)
    if self.scrollHint then
        -- Show a cue only if there is a useful amount of unseen content.
        -- P32 displayed SCROLL FOR MORE even with 2-12px of overflow.
        local more=range>76 and value+42<range
        self.scrollHint:SetShown(more)
        if more then self.scrollHint:SetText('Scroll to continue') end
    end
end
local function navParent(section)
    if section=='watchlist' or section=='market' or section=='craft' then return 'research' end
    if section=='inventory' or section=='reports' then return 'overview' end
    return section
end
function U:RefreshLayoutSelection()
    if self.compactTabs then
        for key,b in pairs(self.compactTabs)do b:Select(navParent(self.section)==key)end
    end
    if self.compactMore then
        local direct=self.compactTabs and self.compactTabs[navParent(self.section)]
        self.compactMore:Select(not direct)
    end
end
function U:SetLayoutPreference(pref)
    if pref~='AUTO' and pref~='COMPACT' and pref~='DESKTOP' then return false,'Invalid layout' end
    if not W.Storage:IsWritable() then return false,'Settings are read only.' end
    self:Settings().screenLayout=pref
    W.AuctionDesk:ApplyScale()
    W.AuctionDesk:Position()
    self:Refresh()
    return true
end
U.routes={{'buy','Shop'},{'sell','Sell'},{'owned','My auctions'},{'overview','Insights'},{'research','Research'}}
-- Existing page IDs remain stable for SavedVariables, commands and integrations.
U.secondaryRoutes={{'watchlist','Favorites'},{'market','Recorded prices'},{'craft','Crafting'},
    {'inventory','Carried items'},{'reports','Reports'},{'ledger','Journal'},
    {'settings','Settings'},{'diagnostics','Diagnostics'}}
local aliases={economics='overview',targeted='buy',diagnostics='diagnostics'}
function U:Message(text)
    local messages={ALREADY_WATCHED='Already saved in Favorites.',WATCHLIST_LIMIT_80='Favorites is full (80 items). Remove an item first.',
        FAVORITE_LISTS_UNAVAILABLE='Saved lists could not be read. Your favorites are unchanged.',
        FAVORITE_LIST_NAME='Enter a list name of 1 to 32 characters.',
        FAVORITE_LIST_DUPLICATE='Choose a different list name.',
        FAVORITE_LIST_MISSING='That list is no longer available.',
        FAVORITE_LIST_LIMIT='You can keep up to 8 lists.',
        INVALID_ITEM_KEY='Choose an item from Shop, or enter a valid item link or ID.',STORAGE_READ_ONLY='Saved data is read only. Check Diagnostics.',
        RELOAD_MARKERS_NOT_RESTORED='Verify saved data in Settings.',LEDGER_EMPTY='There are no journal entries to remove.',
        INVALID_AMOUNT='Enter a valid quantity and gold, silver, or copper amount.',LEDGER_FULL_250_ENTRIES='The manual journal is full (250 entries).'}
    self.notice=messages[text] or tostring(text or '');self.noticeAt=W.Clock();self.dirty=true
end
function U:Result(ok,why)
    if not ok then self:Message(why or 'This action is not available right now.')end
    self.dirty=true;self:Refresh();return ok
end
function U:Settings()return W.Storage.account and W.Storage.account.settings or {}end
-- Money shown in the UI always carries Blizzard's denomination icons.
-- Exported reports use MoneyPlain so copied text remains readable elsewhere.
function U:Money(n)
    if not W.Math.ValidNumber(n) or n<0 then return 'Unknown' end
    n=math.floor(n+.5)
    local g,s,c=math.floor(n/10000),math.floor(n%10000/100),n%100
    local coins=F.coinMarks
    local out={}
    if g>0 then out[#out+1]=g..coins[1] end
    if s>0 then out[#out+1]=s..coins[2] end
    if c>0 or #out==0 then out[#out+1]=c..coins[3] end
    return table.concat(out,'  ')
end
function U:MoneyPlain(n)
    if not W.Math.ValidNumber(n) then return 'Unknown' end
    local neg=n<0
    return (neg and '-' or '')..W.Prices:Money(math.floor(math.abs(n)+.5))
end
function U:ItemSub(r)
    if self:Settings().showItemIDs==false then return r.detail or '' end
    local id=r.itemID or (r.itemKey and r.itemKey.itemID)
    return id and ('ID '..id..(r.detail and ' · '..r.detail or '')) or (r.detail or '')
end
function U:Name(id,link)
    if link then local n=link:match('%[([^%]]+)%]');if n then return n end end
    local fn=C_Item and C_Item.GetItemNameByID or GetItemInfo
    local ok,name=W.SafeCall(fn,id);return ok and type(name)=='string' and name or ('Loading item name · #'..tostring(id or '?'))
end
function U:Quote(key,link)
    if not key or (W.runtime.ahOpen and not W.Scope:Snapshot().ready)then return nil end
    local market=W.Scope:ReadMarketKey()
    link=link or (type(key)=='table' and key.itemLink)
    local commodity=type(key)=='table' and (key.itemSuffix or 0)==0 and
        (key.battlePetSpeciesID or 0)==0 and W.ItemKinds:IsCommodity(key.itemID,market)
    if commodity and type(link)=='string' then
        local identity=W.Identity:FromLink(link,key.itemID)
        if not identity then return nil end
        commodity=identity==('id='..key.itemID..';e=0;g=0,0,0,0;s=0;b=')
    end
    if type(link)=='string' and not commodity and W.PriceView then
        -- An unverified exact variant must not fall back to an item-ID average.
        return W.PriceView:Get(link,{marketKey=market})
    end
    local view=W.PriceView and W.PriceView:ForItemKey(key,market)
    if view then return view end
    return W.Quotes:ForWatch(W.ItemKinds:Key(key),market)
end
-- Compare only positive prices for the same observed item key and market.
-- This is an asking-price comparison, never a guaranteed sale margin.
function U:PriceComparison(q,live)
    if not q or not W.Math.ValidNumber(q.priceCopper) or q.priceCopper<=0 or
        not W.Math.ValidNumber(live) or live<=0 then return nil,C.muted end
    local quality=q.quality
    if q.status=='STALE' or (q.ageSeconds or math.huge)>1800 then
        return 'Older market reference · comparison unavailable',C.muted
    end
    if not quality or quality.comparisonEligible~=true or
        not q.item or q.item.precision~='EXACT_WEALTHCRAFT_VARIANT' or
        not q.market or q.market.mode~='CURRENT' or
        q.marketKey~=W.Scope:ReadMarketKey() then
        return 'Limited market evidence · comparison unavailable',C.muted
    end
    local result=W.DataLanguage:Comparison(live,q.priceCopper,q.ageSeconds,1800)
    if not result then return 'Price comparison unavailable',C.muted end
    if result.direction=='EQUAL' then return result.label,C.muted end
    return result.label,result.direction=='ABOVE' and C.danger or C.positive
end
function U:Insight(q,live)
    if not q or not q.priceCopper then return 'No recent market reference' end
    local label=self:PriceComparison(q,live)
    if label then return label end
    local source=q.source=='AH_OPEN_QUICK_REFRESH' and 'Quick check' or
        q.source=='PLAYER_INITIATED_TARGET_SEARCH' and 'Targeted check' or
        q.status=='PARTIAL_SAMPLE' and 'Partial sample' or 'Saved listing'
    -- An absent recording time is UNKNOWN, never an observation from now.
    local observedAt=type(q.observedAt)=='number' and q.observedAt or
        type(q.ageSeconds)=='number' and q.ageSeconds>=0 and (W.Clock()-q.ageSeconds) or nil
    return source..' · '..(observedAt and W.Decision:Age(observedAt) or 'age unavailable')
end
function U:Page(id,title,subtitle)
    local p=CreateFrame('Frame',nil,self.content);p:SetAllPoints(self.content);p:Hide();self.pages[id]=p
    p:EnableMouseWheel(true)
    p:SetScript('OnMouseWheel',function(_,delta)U:ScrollBy(-delta*65)end)
    p.heading=F:Text(p,0,0,970,32,title,25,C.text)
    p.subtitle=F:Text(p,0,34,970,22,subtitle or '',13,C.muted)
    if not subtitle or subtitle=='' then p.subtitle:SetText('');p.subtitle:Hide() end
    return p
end
function U:Create()
    if self.creationComplete then return true end
    if self.frame then return false end
    local r=CreateFrame('Frame','WealthcraftAuctionDesk',UIParent);r:SetSize(self.width,self.height)
    r:SetFrameStrata('DIALOG');r:SetFrameLevel(90);r:SetToplevel(true);r:SetClampedToScreen(true)
    r:EnableMouse(true);r:SetMovable(true);r:RegisterForDrag('LeftButton');r:Hide();self.frame=r
    local bg=r:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints(r);bg:SetColorTexture(unpack(C.background))
    for _,edge in ipairs({'TOP','BOTTOM','LEFT','RIGHT'})do F:Rule(r,edge,C.edge)end
    local top=F:Box(r,0,0,self.width,84,C.panel,false)
    self.topBar=top
    -- The title strip is the drag handle; context and refresh status are automatic.
    -- This fixes root-only dragging, which could be intercepted by its child header.
    local drag=CreateFrame('Frame',nil,top)
    drag:SetPoint('TOPLEFT',top,'TOPLEFT',0,0);drag:SetSize(584,84)
    drag:EnableMouse(true);drag:RegisterForDrag('LeftButton')
    drag:SetFrameLevel(top:GetFrameLevel()+1)
    drag:SetScript('OnDragStart',function()
        if not InCombatLockdown or not InCombatLockdown() then r:StartMoving() end
    end)
    drag:SetScript('OnDragStop',function()
        r:StopMovingOrSizing()
        W.AuctionDesk:SavePosition()
        W.AuctionDesk:Position() -- immediately enforce the current viewport inset
    end)
    self.dragHandle=drag
    local mark=top:CreateTexture(nil,'ARTWORK');mark:SetSize(52,52);mark:SetPoint('TOPLEFT',22,-16)
    mark:SetTexture('Interface\\AddOns\\Wealthcraft\\Media\\WealthCraftBadge.tga');self.brandMark=mark
    -- Anchor the title to the artwork's RIGHT edge and its vertical CENTER.
    -- This holds alignment at every interface scale and title font size.
    local heading=F:Text(top,0,0,470,44,'WealthCraft',29,C.secondary)
    heading:ClearAllPoints();heading:SetPoint('LEFT',mark,'RIGHT',12,0)
    heading:SetJustifyV('MIDDLE');self.brandTitle=heading
    F:Rule(top,'BOTTOM',C.edge)
    self.contextLabel=F:Text(top,610,22,588,22,'',14,C.text,'RIGHT')
    self.quickStatus=F:Text(top,772,47,427,18,'',12,C.secondary,'RIGHT')
    -- Manage scans is a lower-left utility; automation remains default enabled.
    -- Foreground native actions and per-account scan guards remain authoritative.
    self.scanMenu=F:ButtonAt(r,23,685,158,34,'Manage scans',function()
        local state=W.ScanCoordinator and W.ScanCoordinator:Status() or {}
        local paused=state.state=='USER_PAUSED'
        local choice=F:Choose(U.scanMenu,{{'quick','Check selected prices'},
            {'full','Full market scan (when eligible)'},
            {'pause',paused and 'Resume automatic checks' or 'Pause automatic checks'},
            {'status','Scan status and details'}},function(kind)
            if kind=='status' then
                local d=W.ScanCoordinator and W.ScanCoordinator:Diagnostics() or {}
                U:Message((state.text or 'Prices not checked')..' · quick: '..
                    tostring(d.quickStatus or 'unknown')..' · full: '..tostring(d.fullStatus or 'unknown'))
            else
                local ok,why
                if kind=='pause' then ok,why=W.Automation:TogglePaused()
                else ok,why=W.Automation:UserScan(kind) end
                if not ok then U:Message(why) end
            end
            U:Refresh()
        end)
        if choice then
            choice:ClearAllPoints()
            if U.layout=='compact' and U.compactUtility then
                choice:SetPoint('TOPRIGHT',U.compactUtility,'BOTTOMRIGHT',0,-4)
            else
                choice:SetPoint('TOPLEFT',U.scanMenu,'TOPRIGHT',7,0)
            end
        end
    end)

    local nav=F:Box(r,14,98,176,622,C.panel)
    self.navPanel=nav
    self.navigation={}
    for i,s in ipairs(self.routes)do
        local id=s[1];local b=F:ButtonAt(nav,9,10+(i-1)*46,158,38,s[2],function()U:Select(id)end)
        b.label:SetJustifyH('LEFT');self.navigation[id]=b
    end
    self.utilitySettings=F:ButtonAt(nav,9,460,158,34,'Settings',function()U:Select('settings')end)
    self.utilityDiagnostics=F:ButtonAt(nav,9,505,158,34,'Diagnostics',function()U:Select('diagnostics')end)
    self.desktopNative=F:ButtonAt(r,23,728,158,28,'Blizzard view',function()W.AuctionDesk:NativeFallback()end)
    self.desktopClose=F:ButtonAt(r,23,762,158,26,'Close',function()W.AuctionDesk:CloseAuction()end)
    -- Compact navigation: every page stays in the same live UI. Frequently used
    -- actions are one click away; all other pages are in a single More menu.
    local tabs=F:Box(r,14,91,1022,44,C.panel,false)
    self.compactBar=tabs;self.compactTabs={}
    for i,item in ipairs(compactTabs)do
        local key,label=item[1],item[2]
        self.compactTabs[key]=F:ButtonAt(tabs,(i-1)*164,1,156,40,label,function()U:Select(key)end)
    end
    self.compactUtility=F:ButtonAt(tabs,846,1,176,40,'Options',function()
        local choices={{'settings','Settings'},{'diagnostics','Diagnostics'},
            {'_scans','Manage scans'},{'_native','Blizzard view'},{'_close','Close Auction House'}}
        if U:Settings().journalEnabled==true then
            table.insert(choices,1,{'ledger','Journal'})
        end
        F:Choose(U.compactUtility,choices,function(key)
            if key=='_close' then W.AuctionDesk:CloseAuction()
            elseif key=='_native' then W.AuctionDesk:NativeFallback()
            elseif key=='_scans' then if U.scanMenu then
                    local onClick=U.scanMenu:GetScript('OnClick')
                    if onClick then onClick(U.scanMenu,'LeftButton')end
                end
            else U:Select(key)end
        end)
    end)
    self.compactMore=self.compactUtility
    self.compactNative=self.compactUtility
    tabs:Hide()
    -- Opaque surface and full-height frame behind the clipped page. Without
    -- this, the previous black void let world art and action bars show through
    -- under a cropped table, making the Surface edition feel unfinished.
    self.viewportPanel=F:Box(r,205,93,self.contentWidth+21,672,C.panel,false)
    self.viewportPanel:SetFrameLevel(r:GetFrameLevel()+1)
    local scroll=CreateFrame('ScrollFrame',nil,r)
    scroll:SetFrameLevel(r:GetFrameLevel()+2)
    scroll:SetPoint('TOPLEFT',r,'TOPLEFT',212,-100)
    scroll:SetSize(self.contentWidth,652)
    scroll:EnableMouseWheel(true)
    scroll:SetScript('OnMouseWheel',function(_,delta)U:ScrollBy(-delta*65)end)
    scroll:SetScript('OnScrollRangeChanged',function()U:UpdateScrollBar()end)
    self.scrollViewport=scroll
    self.content=CreateFrame('Frame',nil,scroll)
    self.content:SetSize(self.contentWidth,self.contentHeight)
    scroll:SetScrollChild(self.content)
    local bar=CreateFrame('Slider',nil,r)
    bar:SetSize(6,652);bar:SetPoint('TOPLEFT',r,'TOPLEFT',1205,-100)
    bar:SetFrameLevel(r:GetFrameLevel()+3)
    bar:SetOrientation('VERTICAL');bar:SetMinMaxValues(0,0);bar:SetValueStep(12)
    local rail=bar:CreateTexture(nil,'BACKGROUND');rail:SetAllPoints(bar)
    rail:SetColorTexture(.16,.15,.14,.38)
    local thumb=bar:CreateTexture(nil,'OVERLAY');thumb:SetSize(4,60)
    thumb:SetColorTexture(.91,.55,.18,.57);bar:SetThumbTexture(thumb)
    bar:SetScript('OnEnter',function()thumb:SetAlpha(1)end)
    bar:SetScript('OnLeave',function()thumb:SetAlpha(.60)end)
    bar:SetScript('OnMouseWheel',function(_,delta)U:ScrollBy(-delta*65)end)
    bar:EnableMouseWheel(true)
    bar:SetScript('OnValueChanged',function(_,value)
        if not U.scrollBarUpdating and U.scrollViewport then
            W.Priority:RecordInteraction()
            U.scrollViewport:SetVerticalScroll(value)
        end
    end)
    scroll:SetScript('OnVerticalScroll',function(_,value)
        if U.scrollBar and not U.scrollBarUpdating then
            U.scrollBarUpdating=true;U.scrollBar:SetValue(value);U.scrollBarUpdating=false
        end
        U:UpdateScrollBar()
    end)
    self.scrollBar=bar
    self.footerPanel=F:Box(r,205,751,1011,41,C.background,false)
    self.footerPanel:SetFrameLevel(r:GetFrameLevel()+1)
    self.footer=F:Text(self.footerPanel,7,12,740,26,'',13,C.muted)
    self.scrollHint=F:Text(self.footerPanel,770,12,214,22,'Scroll to continue',11,C.muted,'RIGHT')
    self.scrollHint:SetWordWrap(false);self.scrollHint:Hide()
    self.footer:SetWordWrap(false)
    r:SetScript('OnDragStart',function(f)if not InCombatLockdown or not InCombatLockdown()then f:StartMoving()end end)
    r:SetScript('OnDragStop',function(f)
        f:StopMovingOrSizing();W.AuctionDesk:SavePosition();W.AuctionDesk:Position()
    end)
    r:SetScript('OnShow',function()
        if U.creationComplete and W.AuctionDesk then W.AuctionDesk:ViewportChanged()end
    end)
    r:SetScript('OnHide',function()
        if U.CancelPendingSearch then U:CancelPendingSearch()end
        if U.choiceMenu then U.choiceMenu:Hide()end
        if W.AuctionDesk and W.AuctionDesk.active and not W.AuctionDesk.restoring then W.AuctionDesk:NativeFallback()end
    end)
    local function update(_,elapsed)
        U.elapsed=(U.elapsed or 0)+elapsed;if U.elapsed<.2 then return end;U.elapsed=0
        if W.AuctionDesk then W.AuctionDesk:Pulse(.2)end
        if W.Trading then W.Trading:Tick()end
        if U.dirty or (U.lastTick or 0)+1<W.Clock() then U:Refresh();U.lastTick=W.Clock()end
    end
    r:SetScript('OnUpdate',function(f,elapsed)
        local ok=W.Try('interface-update',update,f,elapsed)
        if not ok then U.refreshing=false;W.AuctionDesk:NativeFallback('Interface update failed')end
    end)
    if type(UISpecialFrames)=='table' then UISpecialFrames[#UISpecialFrames+1]='WealthcraftAuctionDesk' end
    self:CreateShop();self:CreateSell();self:CreateOwned();self:CreateResearch();self:CreateTools();self:CreateSettings();self:CreateResearchHub();self:CreateModal()
    W.AuctionDesk.frame=r;W.AuctionDesk:ApplyScale();W.AuctionDesk:Position();self:Select('buy')
    self.creationComplete=true
    return true
end
function U:Select(section,passive)
    section=aliases[section] or section or 'buy';if not self.pages[section]then section='buy'end
    if self.choiceMenu then self.choiceMenu:Hide()end
    if self.nestedMenu then self.nestedMenu:Hide()end
    if section~='buy' and self.CancelPendingSearch then self:CancelPendingSearch()end
    if section~='buy' then
        self:EndSellComparison()
        if self.browseTextBeforeSell~=nil then
            self:RestoreBrowseText()
            self.shopMode='browse';self.offerRows=nil;self.offerSelected=nil;self.offerToken=nil
        end
    end
    local changed=self.section~=section
    self.section=section;self.activePage=section;W.AuctionDesk.section=section
    for k,p in pairs(self.pages)do p:SetShown(k==section)end
    if changed and self.scrollViewport then self.scrollViewport:SetVerticalScroll(0)end
    self:SetActivePageExtent()
    for k,b in pairs(self.navigation)do b:Select(k==navParent(section))end
    self:RefreshLayoutSelection()
    if section=='inventory' then W.Inventory:Refresh()end
    if section=='sell' then self:LoadSellItems()end
    if section=='market' then self:FindHistory()end
    if section=='craft' then W.Crafting:RestoreKnown()end
    if not passive and section=='owned' and W.runtime.ahOpen and W.Owned.state=='IDLE' then
        local ok,why=W.Owned:Query(self.ownedMode or 'auctions');if not ok then self:Message(why)end
    end
    self.dirty=true;self:Refresh()
end
function U:Open(section,passive)
    if not self:Create() then return false end
    if W.runtime.ahOpen and W.AuctionDesk:Enabled()then W.AuctionDesk.fallback=false;W.AuctionDesk:TryOpen()end
    if not W.runtime.ahOpen then W.AuctionDesk:ApplyScale();W.AuctionDesk:Position();self.frame:Show()end
    if not self.frame:IsShown() then self.frame:Show()end
    self:Select(section or self.section,passive)
end
function U:Toggle()if self.frame and self.frame:IsShown()then W.AuctionDesk:CloseAuction()else self:Open()end end
function U:SetEconMode(mode)self:Select(mode=='craft' and 'craft' or mode=='ledger' and 'ledger' or 'overview')end
function U:RefreshInventory()W.Inventory:Refresh();self.dirty=true end
function U:Refresh()
    if not self.frame or not self.frame:IsShown() then self.dirty=true;return end
    if self.refreshing then return end;self.refreshing=true;self.dirty=false
    local s=W.Scope:Snapshot()
    self.contextLabel:SetText(W.runtime.ahOpen and (s.display or 'Current Auction House') or W.Scope:ReadContext().label)
    if W.ScanCoordinator then W.ScanCoordinator:Rearm('VISIBLE_UI_REFRESH')end
    local status=W.ScanCoordinator and W.ScanCoordinator:Status()
    self.quickStatus:SetText(status and status.text or (W.Automation and W.Automation:Summary() or W.QuickScan:Summary()))
    if self.scanMenu then
        self.scanMenu:ApplyAvailability(W.runtime.ahOpen)
        self.scanMenu:Select(status and status.state=='USER_PAUSED' or false)
    end
    local f=self['Refresh_'..self.section];if f then W.Try('page:'..self.section,f,self)end
    self:RefreshModal()
    local unresolved=W.Trading:Unverified()
    self.footer:SetTextColor(unpack(unresolved and C.danger or C.muted))
    self.footer:SetText((unresolved and 'Action not confirmed. Check '..(unresolved.kind=='POST' and 'My auctions' or 'mail and gold')..' before retrying. Details: Settings → Diagnostics.') or
        (self.notice and W.Clock()-(self.noticeAt or 0)<20 and self.notice) or
        (W.Trading.state~='IDLE' and W.Trading.message) or '')
    self.refreshing=false
end
function W.Refresh()if W.UI then W.UI.dirty=true;if W.UI.frame and W.UI.frame:IsShown()then W.UI:Refresh()end end end


-- P39-B: a single Research entrance; stored page IDs and features remain.
function U:CreateResearchHub()
    local page=self:Page('research','Research','Saved items, recorded prices and your known recipes.')
    local destinations={
        {'watchlist','Favorites','Review saved items and check their current asking prices.'},
        {'market','Recorded prices','Explore observed listings and their last recorded prices.'},
        {'craft','Crafting','Compare known recipes, materials and eligible output prices.'},
    }
    self.researchCardDetails={}
    for i,row in ipairs(destinations)do
        local y=72+(i-1)*148
        local card=F:Box(page,0,y,990,126,C.panel)
        F:Text(card,22,22,800,32,row[2],23,C.text)
        self.researchCardDetails[row[1]]=F:Text(card,22,66,760,42,row[3],15,C.muted)
        F:ButtonAt(card,806,44,158,38,'Open',function()U:Select(row[1])end,true)
    end
end
function U:Refresh_research()
    local details=self.researchCardDetails
    if not details then return end
    local state=W.Crafting:CatalogStatus()
    local suffix=state.current and ' · Recently checked; older entries may remain cached' or ' · Saved names, confirm in Professions'
    details.craft:SetText(state.count>0 and (state.count..' recorded recipes'..suffix) or
        'Open Professions once to record your learned recipes.')
    local count=#W.Storage:WatchEntries()
    details.watchlist:SetText(count..' saved items · inspect their current asking prices.')
    details.market:SetText('Inspect saved asking prices and their observation ages; not completed sales.')
end
