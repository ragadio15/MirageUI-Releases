local _,W=...
local U,F,C=W.UI,W.Widgets,W.Widgets.palette
-- Forever accepts a one-based duration index for both deposit and posting.
local foreverHours={2,8,24}
local standardHours={12,24,48}
local function listingHours()
    local build=W.Compat.build
    return build and build.interface and build.interface~=16001 and standardHours or foreverHours
end
function U:ReadSellListing()
    if not W.PostInput then return nil,'Price validation is unavailable.' end
    local row=self.sellSelected
    local mode=row and row.commodity and 'buyout' or self.sellMode
    return W.PostInput:Listing(mode,self.sellQty:GetText(),self.sellAmounts,self.sellBidAmounts)
end
local function sellSignature(items)
    local s={}
    for _,r in ipairs(items or {})do
        s[#s+1]=table.concat({tostring(r.bag or '?'),tostring(r.slot or '?'),
            tostring(r.itemID or '?'),tostring(r.count or '?'),tostring(r.itemLink or '')},':')
    end
    return table.concat(s,'|')
end
function U:RequestSellInventory()
    if not self.sellItems then self:LoadSellItems()end
    local previous=self.sellSnapshotSignature or sellSignature(self.sellItems)
    if W.Inventory then W.Inventory:MarkDirty()end
    local ok=W.PlayerContext:RequestRefresh('WEALTHCRAFT_SELL_PLAYER_REFRESH',false,false)
    if not ok then self.sellRefreshReceipt='Bag check unavailable.';self:Message(self.sellRefreshReceipt);return false end
    self:LoadSellItems()
    local current=W.PlayerContext.bagRecord and W.PlayerContext.bagRecord.current==true
    local changed=sellSignature(self.sellItems)~=previous
    self.sellRefreshPending=not current
    self.sellRefreshBefore=previous
    self.sellRefreshReceipt=not current and 'Checking bags…' or
        (changed and 'Inventory updated.' or 'Bags checked · no changes.')
    self.sellRefreshAt=W.Clock()
    self.dirty=true;self:Refresh()
    return true
end
function U:MoneyInputs(parent,x,y,width)
    local col=(width-16)/3;local out={labels={}}
    for i,label in ipairs({'Gold','Silver','Copper'})do
        out.labels[i]=F:Text(parent,x+(i-1)*(col+8),y,col,20,label,12,C.muted)
        local field=F:Edit(parent,x+(i-1)*(col+8),y+24,col,36,'0')
        -- Coin on each editable denomination, with room reserved for the texture.
        field:SetTextInsets(12,28,4,4)
        local coin=field:CreateTexture(nil,'ARTWORK')
        coin:SetTexture(F.coinPaths[i]);coin:SetSize(16,16)
        coin:SetPoint('RIGHT',field,'RIGHT',-8,0)
        field.coinIcon=coin
        out[i]=field
    end
    return out
end
function U:SellInputSignature()
    local fields={tostring(self.sellMode or ''),tostring(self.sellDuration or ''),self.sellQty and self.sellQty:GetText() or ''}
    for _,group in ipairs({self.sellAmounts or {},self.sellBidAmounts or {}})do
        for i=1,3 do fields[#fields+1]=group[i] and group[i]:GetText() or '' end
    end
    local row=self.sellSelected
    fields[#fields+1]=row and (tostring(row.bag)..':'..tostring(row.slot)..':'..tostring(row.itemID)) or ''
    return table.concat(fields,'|')
end
function U:SelectSellItem(row)
    self.sellSelected=row
    self.sellMode='buyout'
    self.sellCompactDetail=self.layout=='compact'
    self.sellReviewError=nil
    self.sellQty:SetText(tostring(row.count))
    for _,fields in ipairs({self.sellAmounts,self.sellBidAmounts})do
        for _,field in ipairs(fields)do field:SetText('')end
    end
end
function U:EndSellComparison()
    if not self.comparingSell then return end
    self.comparingSell=nil
    self.sellForm:SetParent(self.pages.sell);self.sellForm:Hide()
    self.sellBreakdown:SetParent(self.pages.sell);self.sellBreakdown:Hide()
    self.sellGeometry=nil;self.shopViewLayout=nil
end
function U:OpenSellOffers(compare)
    local row=self.sellSelected
    if not row then return end
    if self.comparingSell then
        if compare then
            self.sellCompactDetail=self.layout=='compact'
            return self:Select('sell')
        end
        self:EndSellComparison()
        self.shopCompactDetail=self.layout=='compact'
        self:Refresh()
        return
    end
    self:CancelPendingSearch()
    self.offerSelected=nil;self.offerToken=nil;self.offerRows=nil;self.shopEstimate=nil
    self.shopQuantity:SetText('')
    for _,field in ipairs(self.shopBidAmounts)do field:SetText('')end
    if self.browseTextBeforeSell==nil then self.browseTextBeforeSell=self.shopInput:GetText() end
    self.shopInput:SetText(row.name or tostring(row.itemID))
    self.shopSelected=row;self.shopMode='offers';self.shopCleared=false;self.shopTable.page=0
    self.shopCompactDetail=false;self.shopAwaitingApply=false
    self.comparingSell=compare==true or nil
    self:Select('buy')
    if W.runtime.ahOpen then self:InspectItem(row,false,compare) end
end
function U:MatchingSellItem(item)
    if not item then return end
    local key=self:FavoriteKey(item)
    if not key then return end
    local identity=W.Identity:FromLink(item.itemLink,item.itemID)
    if item.itemLink and not identity then return end
    if not self.sellItems then self:LoadSellItems()end
    local match,firstIdentity
    for _,row in ipairs(self.sellItems)do
        if row.sellable and not row.locked and not row.isBound and row.itemID==item.itemID
            and (row.observedItemKey or identity) and self:FavoriteKey(row)==key then
            local variant=W.Identity:FromLink(row.itemLink,row.itemID)
            if variant and (not identity or variant==identity or row.commodity) then
                -- An aggregate browse key may cover materially different bag variants.
                if not identity and firstIdentity and firstIdentity~=variant and not row.commodity then return end
                firstIdentity=variant
                if not match or row==self.sellSelected then match=row end
            end
        end
    end
    return match
end
function U:CreateTradeSide(form,side)
    local button
    button=F:ButtonAt(form,74,54,84,23,side,function()
        local selling=side=='Sell'
        local item=selling and U.sellSelected or (not selling and (U.offerSelected or U.shopSelected))
        if not item or (not selling and not U:MatchingSellItem(item)) then return end
        local nextSide=selling and 'Buy' or 'Sell'
        F:Choose(button,{{nextSide,nextSide}},function()
            if selling then
                if U.sellSelected==item then U:OpenSellOffers(false)end
            elseif (U.offerSelected or U.shopSelected)==item then
                -- Check fresh bag eligibility again at the actual menu click.
                U:LoadSellItems()
                local bag=U:MatchingSellItem(item)
                if not bag then U:Message('This item is no longer available to sell.');U:Refresh();return end
                if U.sellSelected~=bag then U:SelectSellItem(bag)end
                U.sellCompactDetail=U.layout=='compact';U:Select('sell')
            end
        end)
    end)
    local arrow=button:CreateTexture(nil,'OVERLAY')
    arrow:SetSize(12,12);arrow:SetPoint('RIGHT',button,'RIGHT',-5,0)
    arrow:SetTexture('Interface\\ChatFrame\\UI-ChatIcon-ScrollDown-Up')
    button.arrow=arrow
    return button
end
function U:ClearTradeInputs(kind)
    self:RestoreBrowseText()
    self:EndSellComparison()
    self:CancelPendingSearch()
    self.shopSelected=nil;self.offerSelected=nil;self.offerRows=nil;self.offerToken=nil
    self.shopEstimate=nil;self.shopMode='browse';self.shopCompactDetail=false
    self.sellSelected=nil;self.sellCompactDetail=false;self.sellGeometry=nil
    self.shopViewLayout=nil
    if kind=='BUY' then
        if self.shopQuantity then self.shopQuantity:SetText('') end
        if self.shopBidAmounts then for _,field in ipairs(self.shopBidAmounts)do field:SetText('')end end
    elseif kind=='POST' then
        if self.sellQty then self.sellQty:SetText('')end
        for _,group in ipairs({self.sellAmounts or {},self.sellBidAmounts or {}})do
            for _,field in ipairs(group)do field:SetText('')end
        end
        self.sellItems=nil;self.sellMode='buyout'
    end
    self.sellReviewError=nil;self.dirty=true
end
-- Responsive Sell uses a dedicated details state on compact viewports.
-- Native bag and posting controls remain unchanged; only ordinary widgets move.
local function place(widget,parent,x,y,width,height)
    if not widget then return end
    widget:ClearAllPoints()
    widget:SetPoint('TOPLEFT',parent,'TOPLEFT',x,-y)
    if width then widget:SetWidth(width) end
    if height then widget:SetHeight(height)end
end
local function moveMoney(fields,parent,x,y,w)
    local col=(w-16)/3
    for i,field in ipairs(fields or {})do
        local px=x+(i-1)*(col+8)
        place(fields.labels[i],parent,px,y,col,20)
        place(field,parent,px,y+24,col,36)
    end
end
function U:ReflowSellCard(compact,bidVisible)
    if not self.sellForm or not self.pages or not self.pages.sell then return end
    local comparing=self.comparingSell and self.section=='buy'
    if comparing then compact=false end
    local drill=compact and self.sellSelected~=nil and self.sellCompactDetail==true
    local geom=(compact and (drill and 'DRILL' or 'LIST') or comparing and 'COMPARE' or 'DESKTOP')..(self.sellSelected and ':ITEM' or ':EMPTY')..(bidVisible and ':BOTH' or ':SINGLE')
    if self.sellGeometry==geom then return end
    self.sellGeometry=geom
    local p,f=self.pages.sell,self.sellForm
    local list=not compact or not drill
    f:SetParent(comparing and self.pages.buy or p)
    self.sellTable:SetShown(list)
    self.sellRefresh:SetShown(list)
    self.sellSummary:SetShown(list)
    self.sellDetailsBack:SetShown(drill)
    self.sellEmpty:SetShown(self.sellSelected==nil and not comparing)
    self.sellBreakdown:SetShown(self.sellSelected~=nil)
    f:SetShown(self.sellSelected~=nil)
    if drill then
        place(f,p,0,55,990,495)
        place(self.sellIcon,f,18,23,44,44)
        place(self.sellTitle,f,76,24,362,25)
        place(self.sellSide,f,76,52,84,23)
        place(self.sellSpotlightLabel,f,18,4,360,16)
        place(self.sellFavorite,f,450,18,34,34)
        place(self.sellPriceHint,f,18,81,462,92)
        place(self.sellModeButton,f,18,177,166,32)
        place(self.sellCheck,f,195,177,174,32)
        place(self.sellQty,f,540,111,82,32)
        place(self.sellAll,f,630,111,118,32)
        place(self.sellStack,f,758,111,120,32)
        place(self.sellQtyLabel,f,540,84,330,20)
        place(self.sellDurationLabel,f,540,155,108,20)
        for i,b in ipairs(self.durationButtons)do place(b,f,653+(i-1)*76,152,70,32)end
        place(self.sellUnitLabel,f,540,204,326,20)
        moveMoney(self.sellAmounts,f,540,230,340)
        place(self.sellBidLabel,f,540,300,334,20)
        moveMoney(self.sellBidAmounts,f,540,325,340)
        place(self.sellTotal,f,540,bidVisible and 396 or 324,356,33)
        place(self.sellReview,f,540,bidVisible and 435 or 373,340,38)
        self.sellBreakdown:SetParent(f)
        place(self.sellBreakdown,f,18,230,498,247)
        place(self.sellBreakTitle,self.sellBreakdown,14,12,460,20)
        place(self.sellBreakLeft,self.sellBreakdown,14,42,226,180)
        place(self.sellBreakRight,self.sellBreakdown,256,42,225,180)
    else
        self.sellTable:SetWidth(618)
        local widths={316,100,176}
        for i,col in ipairs(self.sellTable.columns)do col.width=widths[i]end
        local offset=12
        for i,header in ipairs(self.sellTable.headers)do place(header,self.sellTable,offset,10,widths[i]-12,20);offset=offset+widths[i]end
        for _,button in ipairs(self.sellTable.rows)do
            button:SetWidth(606)
            place(button.name,button,45,5,widths[1]-51,23)
            place(button.sub,button,45,25,widths[1]-51,16)
            place(button.cells[2],button,6+widths[1],12,widths[2]-14,26)
            place(button.cells[3],button,6+widths[1]+widths[2],12,widths[3]-14,26)
        end
        self.sellTable.pageText:SetWidth(504)
        place(f,comparing and self.pages.buy or p,636,comparing and 134 or 100,354,bidVisible and 544 or 468)
        place(self.sellIcon,f,18,30,44,44)
        place(self.sellTitle,f,74,27,226,24)
        place(self.sellSide,f,74,54,84,23)
        place(self.sellSpotlightLabel,f,18,5,300,16)
        place(self.sellFavorite,f,312,24,34,34)
        place(self.sellPriceHint,f,18,88,318,56)
        place(self.sellModeButton,f,18,145,164,30)
        place(self.sellCheck,f,192,145,144,30)
        place(self.sellQtyLabel,f,18,182,86,20)
        place(self.sellQty,f,18,202,78,32)
        place(self.sellAll,f,104,202,112,32)
        place(self.sellStack,f,224,202,112,32)
        place(self.sellDurationLabel,f,18,240,88,20)
        for i,b in ipairs(self.durationButtons)do place(b,f,112+(i-1)*76,238,68,32)end
        place(self.sellUnitLabel,f,18,282,318,20)
        moveMoney(self.sellAmounts,f,18,306,318)
        place(self.sellBidLabel,f,18,377,318,20)
        moveMoney(self.sellBidAmounts,f,18,398,318)
        place(self.sellTotal,f,18,bidVisible and 461 or 379,318,28)
        place(self.sellReview,f,18,bidVisible and 488 or 410,318,32)
        self.sellBreakdown:SetParent(comparing and self.pages.buy or p)
        if comparing then
            self.sellBreakdown:ClearAllPoints()
            self.sellBreakdown:SetPoint('TOPLEFT',self.shopTable.prev,'BOTTOMLEFT',0,-14)
            self.sellBreakdown:SetSize(618,135)
        else
            place(self.sellBreakdown,p,0,494,618,135)
        end
        place(self.sellBreakTitle,self.sellBreakdown,14,9,580,20)
        place(self.sellBreakLeft,self.sellBreakdown,16,33,285,96)
        place(self.sellBreakRight,self.sellBreakdown,316,33,284,96)
    end
    if self.section=='sell' then self:SetActivePageExtent()end
end
function U:CreateSell()
    local p=self:Page('sell','Sell','')
    self.sellRefresh=F:ButtonAt(p,0,50,150,36,'Refresh bags',function()U:RequestSellInventory()end)
    self.sellSummary=F:Text(p,168,58,820,24,'',14,C.muted)
    self.sellDetailsBack=F:ButtonAt(p,800,3,190,34,'Back to items',function()
        U.sellCompactDetail=false;U:Refresh()
    end)
    self.sellTable=F:Table(p,0,100,618,{
        {title='ITEM',width=316,item=true},{title='AVAILABLE',width=100,align='RIGHT'},
        {title='MARKET REF. / UNIT',width=176,align='RIGHT'},
    },7,43,function(row)
        U:SelectSellItem(row)
        U:Refresh()
    end)
    local f=F:Box(p,636,100,354,530,C.panel)
    self.sellEmpty=F:EmptyItemDetails(p,636,100,354,468,'Select a bag item to view its listing details.')
    self.sellForm=f
    self.sellIcon=F:Icon(f,18,18,44)
    self.sellTitle=F:Text(f,74,30,224,44,'Choose an item',18,C.text)
    self.sellTitle:SetWordWrap(false)
    self.sellSide=self:CreateTradeSide(f,'Sell')
    self.sellIcon:ClearAllPoints();self.sellIcon:SetPoint('TOPLEFT',f,'TOPLEFT',18,-30)
    self.sellSpotlightLabel=F:Text(f,18,5,300,16,'ITEM DETAILS',11,C.secondary)
    self.sellFavorite=F:IconAction(f,312,24,34,'FavoriteOutline','Save favorite',function()
        U:ToggleFavoriteFor(U.sellSelected)
    end)
    self.sellPriceHint=F:Text(f,18,68,318,72,'',13,C.muted)
    self.sellMode='buyout';self.sellDuration=2
    self.sellModeButton=F:ButtonAt(f,18,145,164,30,'Buyout',function()
        if U.sellSelected and U.sellSelected.commodity then return end
        U.sellMode=U.sellMode=='buyout' and 'both' or U.sellMode=='both' and 'bid' or 'buyout';U.sellReviewError=nil;U:Refresh()
    end)
    self.sellCheck=F:ButtonAt(f,192,145,144,30,'Compare prices',function()
        U:OpenSellOffers(true)
    end)
    self.sellQtyLabel=F:Text(f,18,182,86,20,'Quantity:',12,C.muted)
    self.sellQty=F:Edit(f,18,202,78,32,'')
    self.sellAll=F:ButtonAt(f,104,202,112,32,'All matching',function()
        local row=U.sellSelected
        if row then
            local stock=W.Trading:PostingInventory(row.bag,row.slot)
            if stock then U.sellQty:SetText(tostring(stock.available))end
        end
        U:Refresh()
    end)
    self.sellStack=F:ButtonAt(f,224,202,112,32,'This stack',function()
        local row=U.sellSelected
        if row then U.sellQty:SetText(tostring(row.count))end
        U:Refresh()
    end)
    self.sellDurationLabel=F:Text(f,18,240,88,20,'Duration:',12,C.muted)
    self.durationButtons={}
    for i,hours in ipairs(listingHours())do local idx=i
        self.durationButtons[i]=F:ButtonAt(f,112+(i-1)*76,238,68,32,hours..'h',function()U.sellDuration=idx;U:Refresh()end)
    end
    self.sellUnitLabel=F:Text(f,18,282,318,20,'Buyout per unit:',13,C.secondary)
    self.sellAmounts=self:MoneyInputs(f,18,306,318)
    self.sellBidLabel=F:Text(f,18,377,318,20,'Starting bid per unit:',13,C.secondary)
    self.sellBidAmounts=self:MoneyInputs(f,18,398,318)
    self.sellTotal=F:Text(f,18,461,318,22,'',13,C.text)
    self.sellReview=F:ButtonAt(f,18,488,318,32,'Review listing',function()
        local row=U.sellSelected;if not row then return end
        local listing,reason=U:ReadSellListing()
        if not listing then U.sellReviewError=reason;U.sellErrorSignature=U:SellInputSignature();U:Message(reason);U:Refresh();return end
        local ok,why=W.Trading:PreparePost(row.bag,row.slot,listing.quantity,
            listing.unitCopper,U.sellDuration,listing.bidCopper,row)
        U.sellReviewError=not ok and why or nil
        U.sellErrorSignature=not ok and U:SellInputSignature() or nil
        U:Result(ok,why);U:RefreshModal()
    end,true)
    -- Financial breakdown is kept outside the form so even bid+buyout mode
    -- retains all three denomination inputs and an explicit review button.
    local breakdown=F:Box(p,0,494,618,135,C.panel)
    self.sellBreakdown=breakdown
    self.sellBreakTitle=F:Text(breakdown,14,9,580,20,'LISTING ESTIMATE',13,C.secondary)
    self.sellBreakLeft=F:Text(breakdown,16,33,285,96,'',13,C.text)
    self.sellBreakRight=F:Text(breakdown,316,33,284,96,'',13,C.text)
    self.sellGeometry=nil;self.sellCompactDetail=false
end
function U:LoadSellItems()
    self.sellItems={}
    for _,row in ipairs(W.PlayerContext:ReadBags())do
        if row.sellable then self.sellItems[#self.sellItems+1]=row end
    end
    self.sellSnapshotSignature=sellSignature(self.sellItems)
    local old=self.sellSelected;self.sellSelected=nil
    if old then for _,row in ipairs(self.sellItems)do
        if old.bag==row.bag and old.slot==row.slot and old.itemID==row.itemID and old.itemLink==row.itemLink then
            self.sellSelected=row
        end
    end end
    if not self.sellSelected then self.sellCompactDetail=false end
end
function U:Refresh_sell()
    if not self.sellItems then self:LoadSellItems()end
    if self.sellRefreshPending and W.PlayerContext.bagRecord and W.PlayerContext.bagRecord.current==true then
        self:LoadSellItems()
        self.sellRefreshPending=false
        self.sellRefreshReceipt=sellSignature(self.sellItems)~=self.sellRefreshBefore and
            'Inventory updated.' or 'Bags checked · no changes.'
        self.sellRefreshAt=W.Clock()
    end
    local refresh=(self.sellRefreshReceipt and self.sellRefreshAt and
        W.Clock()-self.sellRefreshAt<12) and (' · '..self.sellRefreshReceipt) or ''
    self.sellSummary:SetText(#self.sellItems..' sellable bag slots'..refresh)
    self.sellTable:SetData(self.sellItems,function(row)
        local quote=U:Quote(row.itemKey,row.itemLink)
        return {row.name,tostring(row.count),quote and quote.priceCopper and U:Money(quote.priceCopper) or '—'},U:ItemSub(row)
    end,function(row)return U.sellSelected and U.sellSelected.bag==row.bag and U.sellSelected.slot==row.slot end,
        'No sellable bag items.')
    local listVisible=self.layout~='compact' or not self.sellCompactDetail
    self.sellTable.pageText:SetShown(listVisible)
    if not listVisible then self.sellTable.prev:Hide();self.sellTable.next:Hide()end
    self:RefreshSellForm()
end
function U:RefreshSellForm()
    local row=self.sellSelected
    local quote=row and self:Quote(row.itemKey,row.itemLink)
    self.sellIcon:SetItem(row and row.itemID,row and row.itemLink,row and row.icon)
    self.sellTitle:SetText(row and row.name or 'Choose an item')
    if self.sellFavorite then
        local id=U:FavoriteKey(row)
        local saved=U:FavoriteSaved(row)
        self.sellFavorite:SetShown(row~=nil)
        self.sellFavorite:SetIcon(saved and 'FavoriteFilled' or 'FavoriteOutline')
        self.sellFavorite.helpLabel=saved and 'Remove favorite' or 'Save favorite'
        self.sellFavorite:ApplyAvailability(id~=nil and W.Storage:IsWritable())
    end
    if quote and quote.priceCopper then
        local enoughRange=W.Math.ValidNumber(quote.floorCopper) and W.Math.ValidNumber(quote.p75Copper) and
            quote.floorCopper>0 and quote.p75Copper>=quote.floorCopper
        local age=(quote.ageSeconds and quote.ageSeconds>=0) and W.DataLanguage:Age(quote.ageSeconds) or 'age unknown'
        self.sellPriceHint:SetText('Market reference: '..self:Money(quote.priceCopper)..' / unit\n'..
            (enoughRange and ('Measured Range: '..self:Money(quote.floorCopper)..' – '..self:Money(quote.p75Copper)) or
                'Measured Range: unavailable')..'\n'..age)
    else self.sellPriceHint:SetText('Market reference: unavailable\nReview current offers before listing.')end
    if row and row.commodity then self.sellMode='buyout'end
    local labels={buyout='Buyout',both='Bid + buyout',bid='Bid only'}
    self.sellModeButton.label:SetText(row and row.commodity and 'Commodity buyout' or labels[self.sellMode])
    self.sellModeButton:ApplyAvailability(row~=nil and not row.commodity)
    self.sellCheck.label:SetText(self.comparingSell and 'Back to Sell' or 'Compare prices')
    self.sellCheck:ApplyAvailability(row~=nil and (self.comparingSell or W.runtime.ahOpen))
    self.sellSide:ApplyAvailability(row~=nil)
    self.sellUnitLabel:SetText(self.sellMode=='bid' and 'Starting bid per unit:' or 'Buyout per unit:')
    local bidVisible=self.sellMode=='both'
    self.sellBidLabel:SetShown(bidVisible)
    for _,input in ipairs(self.sellBidAmounts)do input:SetShown(bidVisible)end
    for _,label in ipairs(self.sellBidAmounts.labels)do label:SetShown(bidVisible)end
    self:ReflowSellCard(self.layout=='compact',bidVisible)
    for i,button in ipairs(self.durationButtons)do button:Select(i==self.sellDuration)end
    self.sellAll:ApplyAvailability(row~=nil)
    self.sellStack:ApplyAvailability(row~=nil)
    local signature=self:SellInputSignature()
    if self.sellReviewError and self.sellErrorSignature~=signature then
        self.sellReviewError=nil;self.sellErrorSignature=nil
    end
    local listing,reason=self:ReadSellListing()
    local preview
    if row and listing then
        preview,reason=W.Trading:PostPreview(row.bag,row.slot,listing.quantity,self.sellDuration,
            listing.unitCopper,listing.bidCopper,row)
    elseif not row then reason='Choose an item to see its listing details.'end
    if preview then
        self.sellTotal:SetText(preview.canAfford and
            ('Ready to review · '..preview.quantity..' units') or 'Not enough gold for the deposit.')
        local asking=quote and quote.averageCopper
        local compareOK=quote and W.Math.ValidInteger(asking,1) and
            listing.unitCopper>0 and quote.completeDepth==true and (quote.listings or 0)>=3 and
            quote.ageSeconds and quote.ageSeconds>=0 and quote.ageSeconds<=1800 and
            quote.marketKey==W.Scope:ReadMarketKey()
        local delta=compareOK and ((listing.unitCopper/asking)-1)*100 or nil
        local comparison=delta and string.format('%+.0f%% vs recorded asking average',delta) or
            'Price comparison: unavailable'
        local grossName=self.sellMode=='bid' and 'At starting bid*' or 'If sold*'
        local cost=self:Money(listing.unitCopper>0 and listing.unitCopper or listing.bidCopper)
        if self.layout=='compact' then
            self.sellBreakLeft:SetText('Unit ask: '..cost..'\n'..
                'Gross: '..self:Money(preview.gross)..'\n'..
                'Deposit: '..self:Money(preview.deposit)..'\n'..comparison)
            self.sellBreakRight:SetText('Fee*: '..self:Money(preview.fee)..'\n'..
                'Proceeds*: '..self:Money(preview.net)..'\n'..
                'Available: '..preview.available..' units\n'..
                '*Assumes '..(W.Storage:AssumedFeeBps()/100)..'% fee; deposit returned if sold')
        else
            self.sellBreakLeft:SetText('Unit price: '..cost..'\n'..
                'Gross total: '..self:Money(preview.gross)..'\n'..
                'Deposit now: '..self:Money(preview.deposit)..'\n'..comparison)
            self.sellBreakRight:SetText('Estimated fee*: '..self:Money(preview.fee)..'\n'..
                grossName..': '..self:Money(preview.net)..'\n'..
                'Available: '..preview.available..' units\n'..
                '*Assumes '..(W.Storage:AssumedFeeBps()/100)..'% fee; deposit returned if sold')
        end
    else
        self.sellTotal:SetText(reason or 'Enter a quantity and price.')
        self.sellBreakLeft:SetText(row and ('Available: '..tostring(row.count or 0)..' in this stack\n'..
            'Choose a quantity and listing price.') or 'Choose an item to start.')
        self.sellBreakRight:SetText('Estimated deposit, fees, and proceeds will appear when prices are valid.')
    end
    local eligible=preview~=nil and preview.canAfford and W.runtime.ahOpen and row and not row.locked and
        W.Trading.state=='IDLE' and (not W.Scan:IsActive() or W.Scan.pausedForUser or W.Scan.origin=='AUTO_AH_OPEN') and not W.Trading:Unverified()
    self.sellReview:ApplyAvailability(eligible==true)
    if preview and W.Scan:IsActive() and not W.Scan.pausedForUser and W.Scan.origin~='AUTO_AH_OPEN' then
        self.sellTotal:SetText('Finish the manual scan to review this listing.')
    end
    if row and row.locked then self.sellTotal:SetText('Item locked. Refresh bags.')end
    if self.sellReviewError then self.sellTotal:SetText(self.sellReviewError)end
    if self.sellTotal then
        self.sellTotal:SetTextColor(unpack(self.sellReviewError and C.danger or
            eligible and C.positive or preview and C.muted or C.secondary))
    end
end
function U:CreateOwned()
    local p=self:Page('owned','My auctions','')
    self.ownedMode='auctions';self.ownedSort='name'
    self.ownedActive=F:ButtonAt(p,0,50,160,36,'Active listings',function()U:QueryOwned('auctions')end,true)
    self.ownedBids=F:ButtonAt(p,170,50,130,36,'My bids',function()U:QueryOwned('bids')end)
    self.ownedRefresh=F:ButtonAt(p,310,50,130,36,'Refresh',function()U:QueryOwned(U.ownedMode)end)
    self.ownedSortButton=F:ButtonAt(p,450,50,150,36,'Sort: name',function()
        U.ownedSort=U.ownedSort=='name' and 'price' or U.ownedSort=='price' and 'time' or 'name';U:Refresh()
    end)
    self.ownedCancel=F:ButtonAt(p,800,50,190,36,'Review cancellation',function()
        if U.ownedSelected then U:Result(W.Trading:PrepareCancel(U.ownedSelected));U:RefreshModal()end
    end)
    self.ownedTable=F:Table(p,0,100,990,{
        {title='ITEM',width=340,item=true},{title='UNITS',width=75,align='RIGHT'},
        {title='BUYOUT',width=150,align='RIGHT'},{title='CURRENT BID',width=150,align='RIGHT'},
        {title='TIME LEFT',width=120,align='RIGHT'},{title='STATUS',width=129},
    },9,43,function(r)U.ownedSelected=r;U:Refresh()end)
    self.ownedNote=F:Text(p,520,530,470,30,'',12,C.muted,'RIGHT')
end
function U:QueryOwned(mode)
    local ok,why=W.Owned:Query(mode);if ok then self.ownedMode=mode;self.ownedSelected=nil;self.ownedTable.page=0 end
    self:Result(ok,why)
end
function U:Refresh_owned()
    local rows={}
    local selectedID=self.ownedSelected and self.ownedSelected.auctionID
    self.ownedSelected=nil
    for _,r in ipairs(W.Owned.items)do
        rows[#rows+1]=r
        if selectedID==r.auctionID then self.ownedSelected=r end
    end
    table.sort(rows,function(a,b)
        local left,right=a.name or '',b.name or ''
        if U.ownedSort=='price' then left,right=a.buyout or 0,b.buyout or 0
        elseif U.ownedSort=='time' then left,right=a.timeLeftSeconds or math.huge,b.timeLeftSeconds or math.huge end
        if left==right then return a.auctionID<b.auctionID end
        return left<right
    end)
    if self.ownedTable then self.ownedTable:ConfigureRows(#rows==0 and 3 or
        (self.layout=='compact' and 6 or self.ownedTable.maxCount))end
    self.ownedTable:SetData(rows,function(r)
        local buyout=r.buyout and r.buyout>0 and U:Money(r.buyout) or 'No buyout'
        if r.buyout and r.buyout>0 and (r.quantity or 0)>1 and W.ItemKinds:IsCommodity(r.itemID,W.Owned.marketKey) then
            buyout=buyout..' / unit'
        end
        return {r.name,tostring(r.quantity or '—'),buyout,
            U:Money(r.bid),W.Decision:TimeLeft(r),W.Decision:OwnedStatus(r,U.ownedMode)},U:ItemSub(r)
    end,self.ownedSelected,not W.runtime.ahOpen and 'Visit an auctioneer to view your current listings.' or
        W.Owned.state=='REQUESTED' and 'Checking your auctions…' or 'No listings returned. Select Refresh to check the Auction House.')
    self.ownedActive:Select(self.ownedMode=='auctions');self.ownedBids:Select(self.ownedMode=='bids')
    self.ownedSortButton.label:SetText('Sort: '..self.ownedSort)
    self.ownedRefresh:ApplyAvailability(W.runtime.ahOpen and W.Owned.state~='REQUESTED' and not W.Scan:IsActive())
    self.ownedCancel:ApplyAvailability(self.ownedMode=='auctions' and self.ownedSelected~=nil and W.Trading.state=='IDLE')
    self.ownedNote:SetText(W.Owned.state=='READY' and (W.Owned.complete and 'All returned listings shown' or 'Partial response · Blizzard view may show more') or '')
end
function U:CreateModal()
    local overlay=CreateFrame('Frame',nil,self.frame);overlay:SetAllPoints(self.frame);overlay:SetFrameLevel(150);overlay:EnableMouse(true)
    local bg=overlay:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints(overlay);bg:SetColorTexture(0,0,0,.78)
    local box=F:Box(overlay,340,214,540,350,C.panel)
    self.modalBox=box
    self.modal=overlay;self.modalTitle=F:Text(box,24,24,490,36,'Review',24,C.secondary)
    self.modalBody=F:Text(box,24,82,490,155,'',15,C.text)
    self.modalWarning=F:Text(box,24,245,490,36,'',13,C.muted)
    self.modalConfirm=F:ButtonAt(box,282,288,234,38,'Confirm',function()
        local wasPost=W.Trading.pending and
            (W.Trading.pending.kind=='POST_ITEM' or W.Trading.pending.kind=='POST_COMMODITY')
        local ok,why=W.Trading:Commit()
        if wasPost and not ok then
            U.sellReviewError=why or W.Trading.message
            U.sellErrorSignature=U:SellInputSignature()
        end
        U:Result(ok,why)
        if ok and W.Trading.state=='IDLE' then U:Message(W.Trading.message)end
        U:RefreshModal()
    end,true)
    self.modalCancel=F:ButtonAt(box,24,288,234,38,'Cancel',function()
        W.Trading:Closed();U.modal:Hide();U:Message('Review closed.');U:Refresh()
    end)
    overlay:Hide()
end
function U:RefreshModal()
    if not self.modal then return end
    local a,p=W.Trading,W.Trading.pending
    if not p or a.state=='IDLE' then self.modal:Hide();return end
    self.modal:Show()
    local title,body,label,can='Working…',a.message,'Please wait',false
    local warning='' 
    if a.state=='PRICE_CHANGED' then
        title='Price increased';body='Nothing has been bought.\n\nYour limit: '..self:Money(p.originalMax)..
            '\nNew total: '..self:Money(a.quote and a.quote.total)..'\nQuantity: '..p.quantity..'\n\nApprove this revised spending limit or cancel.'
        label='Approve new limit';can=true
        warning='The new total exceeds your previous spending limit.'
    elseif a.state=='REVIEW' or a.state=='POST_CONFIRM' then
        can=a:ReviewRemaining()>0
        if p.kind=='POST_ITEM' or p.kind=='POST_COMMODITY' then
            title=a.state=='POST_CONFIRM' and 'Confirm posting warning' or 'Review your listing'
            local hours=listingHours()[p.duration]
            body=(p.name or 'Item')..' ×'..tostring(p.quantity)..
                '\nDuration: '..(hours and (hours..' hours') or 'Unavailable')..
                '\nBuyout total: '..(p.unitCopper>0 and self:Money(p.unitCopper*p.quantity) or 'None')..
                '\nStarting bid total: '..(p.bidCopper and self:Money(p.bidCopper*p.quantity) or 'None')..
                '\nDeposit due: '..self:Money(p.deposit)
            warning='Deposit may be lost if the listing expires or is canceled.'
            label=a.state=='POST_CONFIRM' and 'Confirm again' or 'Post listing'
        elseif p.kind=='CANCEL' then
            title='Cancel this auction?';body=(p.name or self:Name(p.itemID))..'\nCancellation cost: '..self:Money(p.cancelCost);
            warning='Your deposit may not be returned.';label='Cancel auction'
        else
            title=p.kind=='ITEM_BID' and 'Review your bid' or 'Review buyout'
            body=(p.name or self:Name(p.itemID or (p.itemKey and p.itemKey.itemID)))..' ×'..tostring(p.quantity or 1)..
                '\nTotal: '..self:Money(p.price);
            warning='This action applies to one exact auction only.';label=p.kind=='ITEM_BID' and 'Confirm bid' or 'Confirm buyout'
        end
        if not can then warning='Review expired. Close this window and check current offers.'end
    elseif a.state=='QUOTE_WAITING' then title='Finding the best price';body='Quantity: '..p.quantity..'\nSpending limit: '..self:Money(p.originalMax)..
        '\n\nWe will complete this one order only if the server price stays within your limit.'
    elseif a.state=='PURCHASE_WAITING' then title='Purchase submitted';body='Waiting for the Auction House confirmation.\n\nDo not place the same order again yet.'
    elseif a.state=='POST_WAITING' then title='Listing submitted';body='Waiting for the Auction House confirmation.\n\nDo not post the same item again yet.'end
    if a.state=='QUOTE_WAITING' or a.state=='PURCHASE_WAITING' or a.state=='POST_WAITING' then
        warning='Awaiting Blizzard confirmation. Do not submit another order.'
    end
    self.modalTitle:SetText(title);self.modalBody:SetText(body)
    self.modalWarning:SetText(warning)
    self.modalWarning:SetTextColor(unpack((a.state=='PRICE_CHANGED' or not can and a.state=='REVIEW') and C.danger or C.muted))
    self.modalConfirm.label:SetText(label);self.modalConfirm:ApplyAvailability(can)
    local submitted=a.state=='PURCHASE_WAITING' or a.state=='POST_WAITING'
    self.modalCancel:ApplyAvailability(not submitted)
end
