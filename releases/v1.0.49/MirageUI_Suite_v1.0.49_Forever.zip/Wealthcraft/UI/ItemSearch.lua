-- Additive modified-item hooks; native chat, dressing room and trading stay native.
local _,W=...
W.ItemSearch={}
local L=W.ItemSearch
local function visible(frame)
    if not frame or type(frame.IsShown)~='function' then return false end
    local ok,shown=pcall(frame.IsShown,frame)
    if not ok or not shown then return false end
    if type(frame.IsVisible)=='function' then local good,v=pcall(frame.IsVisible,frame);if not good or not v then return false end end
    return true
end
function L:ChatActive()
    if type(ChatEdit_GetActiveWindow)~='function' then return false end
    local ok,edit=pcall(ChatEdit_GetActiveWindow)
    if not ok or not edit or not visible(edit) then return false end
    if type(edit.HasFocus)=='function' then local good,focus=pcall(edit.HasFocus,edit);return good and focus==true end
    return true
end
function L:Populate(link)
    if not W.runtime.ahOpen or self:ChatActive() then return false end
    local custom=W.AuctionDesk and W.AuctionDesk.active and visible(W.UI and W.UI.frame) and W.UI.shopInput
    local input=custom
    if not input then
        local root=_G.AuctionHouseFrame
        if visible(root) and type(root.SearchBar)=='table' then input=root.SearchBar.SearchBox end
        if not input and visible(_G.AuctionFrame) then input=_G.BrowseName end
        if not input or type(input.SetText)~='function' or not visible(input) then return false end
    end
    if type(IsShiftKeyDown)~='function' or not IsShiftKeyDown() then return false end
    if type(link)~='string' or #link>600 or not link:find('item:',1,true) then return false end
    local name=link:match('|h%[([^%]]+)%]|h')
    if not name and type(GetItemInfo)=='function' then
        local ok,n=pcall(GetItemInfo,link);if ok and type(n)=='string' then name=n end
    end
    if not name or #name==0 or #name>200 or name:find('[%c|]') then return false end
    local u=W.UI
    if custom and u.section~='buy' then u:Select('buy',true)end
    input:SetText(name)
    if type(input.SetFocus)=='function' then input:SetFocus()end
    if type(input.SetCursorPosition)=='function' then input:SetCursorPosition(#name)end
    if u then u.dirty=true end
    return true
end
function L:Install()
    if type(hooksecurefunc)~='function' then return false end
    self.hooks=self.hooks or {}
    for _,name in ipairs({'HandleModifiedItemClick','ChatEdit_InsertLink'})do
        if not self.hooks[name] and type(_G[name])=='function' then
            local ok=pcall(hooksecurefunc,name,function(link)
                W.Try('shift-item-search',L.Populate,L,link)
            end)
            self.hooks[name]=ok
        end
    end
    return self.hooks.HandleModifiedItemClick or self.hooks.ChatEdit_InsertLink or false
end
