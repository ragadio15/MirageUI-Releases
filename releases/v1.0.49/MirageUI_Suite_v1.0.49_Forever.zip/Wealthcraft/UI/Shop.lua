local _,W=...
local U,F,C=W.UI,W.Widgets,W.Widgets.palette
local categories={{'all','All items'},{'weapons','Weapons'},{'armor','Armor'},{'trade','Trade goods'},
    {'consumables','Consumables'},{'recipes','Recipes'},{'containers','Bags'},{'ammo','Ammunition'},{'misc','Other'}}
local rarities={{'all','Any rarity'},{'common','Common'},{'uncommon','Uncommon'},{'rare','Rare'},
    {'epic','Epic'},{'legendary','Legendary'},{'poor','Poor'}}
-- Item context uses a compact summary until a real offer needs transaction
-- fields; a blank live-offer search must not reserve a 416-unit bid form.
function U:ReflowShopCard(showBid,offers,commodity)
    if not self.shopForm then return end
    local blank=not self.shopSelected and not offers
    local short=not showBid and not (offers and commodity)
    local geometry=blank and 'COMPACT_EMPTY' or short and 'COMPACT_SUMMARY' or 'FULL_OFFER'
    if self.shopGeometry==geometry then return end
    self.shopGeometry=geometry
    self.shopForm:SetHeight(blank and 188 or short and 350 or 416)
    local function move(widget,y)
        widget:ClearAllPoints();widget:SetPoint('TOPLEFT',self.shopForm,'TOPLEFT',18,-y)
    end
    move(self.shopWatch,short and 264 or 324)
    self.shopResearch:ClearAllPoints()
    self.shopResearch:SetPoint('TOPLEFT',self.shopForm,'TOPLEFT',161,-(short and 264 or 324))
    move(self.shopBuy,short and 307 or 366)
    self.shopCost:ClearAllPoints()
    self.shopCost:SetPoint('TOPLEFT',self.shopForm,'TOPLEFT',18,-(short and 208 or 243))
    self.shopCost:SetHeight(short and 44 or 66)
end
function U:CreateShop()
    local p=self:Page('buy','Shop','')
    self.shopInput=F:Edit(p,0,50,430,38,'',function()U:SearchShop()end)
    -- Typing a different query immediately retires the former selection and
    -- cached visible rows; no previous item remains actionable while typing.
    self.shopInput:SetScript('OnTextChanged',function(_,user)
        if user then W.Priority:RecordInteraction();U:RetireShopResults(true) end
    end)
    self.shopSearch=F:ButtonAt(p,440,50,110,38,'Search',function()U:SearchShop()end,true)
    self.shopReset=F:ButtonAt(p,560,50,98,38,'Reset',function()
        U.shopCategory=1;U.shopQuality=1;U.shopSort='price';U.shopReverse=false;U.shopExact=false
        U.shopUsable=U:Settings().personalize~=false;U.shopMin:SetText('');U.shopMax:SetText('');U:Refresh()
    end)
    self.shopCategory=1;self.shopQuality=1;self.shopSort='price';self.shopUsable=self:Settings().personalize~=false
    self.categoryButton=F:ButtonAt(p,0,92,154,30,'All items',function()
        local choices={};for i,v in ipairs(categories)do choices[#choices+1]={i,v[2]}end
        F:Choose(U.categoryButton,choices,function(i)U.shopCategory=i;U:Refresh()end)
    end)
    self.qualityButton=F:ButtonAt(p,162,92,126,30,'Any rarity',function()
        local choices={};for i,v in ipairs(rarities)do choices[#choices+1]={i,v[2]}end
        F:Choose(U.qualityButton,choices,function(i)U.shopQuality=i;U:Refresh()end)
    end)
    self.sortButton=F:ButtonAt(p,296,92,128,30,'Price: low',function()
        if U.shopSort=='price' and not U.shopReverse then U.shopReverse=true
        elseif U.shopSort=='price' then U.shopSort='name';U.shopReverse=false
        else U.shopSort='price';U.shopReverse=false end;U:Refresh()
    end)
    self.exactButton=F:ButtonAt(p,432,92,104,30,'Exact: off',function()U.shopExact=not U.shopExact;U:Refresh()end)
    self.usableButton=F:ButtonAt(p,544,92,114,30,'For me',function()U.shopUsable=not U.shopUsable;U:Refresh()end)
    -- Optional level bounds remain editable; the For me preset uses the observed player level for equipment.
    self.shopMin=F:Edit(p,724,50,70,38,'');self.shopMax=F:Edit(p,802,50,70,38,'')
    self.shopMore=F:ButtonAt(p,880,50,110,38,'Load more',function()
        if U.shopMode=='offers' then
            if U:OfferRequestCurrent() then U:Result(W.Targeted:More()) end
        else U:Result(W.Browse:More())end
    end)
    self.offerRefresh=F:ButtonAt(p,674,92,180,30,'Refresh offers',function()U:InspectItem(U.shopSelected,false,U.comparingSell)end)
    self.offerRefresh:Hide()
    self.shopTable=F:Table(p,0,134,658,{
        {title='ITEM',width=260,item=true},{title='UNITS',width=65,align='RIGHT'},
        {title='LOWEST ASK / UNIT',width=150,align='RIGHT'},{title='MARKET REF. / UNIT',width=157,align='RIGHT'},
    },8,43,function(r)
        if U.shopMode=='offers' then U.offerSelected=r
        else U.shopSelected=r;U.offerSelected=nil;U.shopCompactDetail=U.layout=='compact' end
        U:Refresh()
    end)
    self.shopBack=F:ButtonAt(p,490,525,168,30,'Back to search',function()
        U:EndSellComparison();U.shopMode='browse';U.offerSelected=nil;U.shopTable.page=0
        U:RestoreBrowseText();U:Refresh()
    end)
    local form=F:Box(p,674,134,316,416,C.panel)
    self.shopEmpty=F:EmptyItemDetails(p,674,134,316,350,'Select an item from the results to view its details.')
    self.shopForm=form
    self.shopIcon=F:Icon(form,18,20,44)
    self.shopName=F:Text(form,74,20,222,56,'Select an item',18,C.text)
    self.shopHint=F:Text(form,18,89,280,100,'',13,C.muted)
    self.shopProposal=F:Text(form,18,91,280,25,'',13,C.text)
    self.shopRange=F:Text(form,18,119,280,45,'',12,C.muted)
    self.shopComparison=F:Text(form,18,169,280,25,'',13,C.muted)
    self.shopProposal:SetWordWrap(false)
    self.shopRange:SetWordWrap(true)
    self.shopComparison:SetWordWrap(true)
    self.shopComparison:SetHeight(36)
    self.shopQuantityLabel=F:Text(form,18,196,160,23,'Quantity to buy',13,C.muted)
    self.shopQuantity=F:Edit(form,194,187,102,38,'')
    self.shopCost=F:Text(form,18,243,278,66,'',16,C.secondary)
    self.shopWatch=F:ButtonAt(form,18,324,135,30,'Save favorite',function()
        local r=U.shopSelected
        if r then local ok,why=W.Storage:AddWatch(W.ItemKinds:ObserveKey(r.itemKey));U:Result(ok,why)
            if ok then U:Message('Saved to Favorites.')end end
    end)
    self.shopResearch=F:ButtonAt(form,161,324,135,30,'Research item',function()
        U:OpenItemResearch(U.offerSelected or U.shopSelected)
    end)
    self:ResearchHint(self.shopResearch,function()return U.offerSelected or U.shopSelected end)
    self.shopBuy=F:ButtonAt(form,18,366,278,34,'See offers',function()U:ShopAction()end,true)
    self.shopBidAmounts=self:MoneyInputs(form,18,188,278)
    self.shopBid=F:ButtonAt(form,18,278,278,32,'Review bid',function()
        local o=U.offerSelected
        if o and U:OfferRequestCurrent() and W.Math.ValidInteger(o.auctionID,1) then
            U:Result(W.Trading:PrepareBid(o.index,U:ReadMoney(U.shopBidAmounts),o.auctionID));U:RefreshModal()
        end
    end)
    self.shopBid:Hide();self.shopMode='browse'
    self:CreateShopActions(p,form)
end
local function searchClock()return type(GetTime)=='function' and GetTime() or W.Clock()end
function U:SearchSignature()
    return table.concat({self.shopInput and self.shopInput:GetText() or '',tostring(self.shopCategory),
        tostring(self.shopQuality),tostring(self.shopSort),tostring(self.shopReverse),tostring(self.shopExact),
        tostring(self.shopUsable),self.shopMin and self.shopMin:GetText() or '',self.shopMax and self.shopMax:GetText() or ''},'\031')
end
function U:CancelPendingSearch(reason)
    if not self.pendingSearch then return false end
    self.pendingSearch=nil
    if W.Priority then W.Priority:ManualRejected()end
    if reason then self:Message(reason)end
    self.dirty=true;return true
end
function U:QueueForegroundSearch(kind,row,compare)
    if not W.runtime.ahOpen or W.Trading.state~='IDLE' then return false end
    local savedRow
    if row then
        local itemKey=row.itemKey or {itemID=row.itemID,itemLevel=0,itemSuffix=0,battlePetSpeciesID=0}
        local _,normalized=W.Storage:WatchKey(itemKey)
        if not normalized then return self:Result(false,'Choose a valid item to search.')end
        savedRow={itemID=normalized.itemID,itemKey=normalized,name=row.name,itemLink=row.itemLink,icon=row.icon}
    end
    -- "See live offers" may originate in Research, Sell, or another page.
    -- Open its result page before capturing the intent so that our own
    -- navigation cannot invalidate the queued user click.
    if kind=='ITEM' and self.section~='buy' then self:Select('buy')end
    self.pendingSearch={kind=kind,row=savedRow,compare=compare,signature=self:SearchSignature(),selection=self.shopSelected,
        session=W.runtime.ahSession,account=W.Storage.account,character=W.Storage.character,
        createdAt=searchClock(),expiresAt=searchClock()+120}
    if W.Priority then W.Priority:ManualSearch()end
    if W.Automation then
        W.Automation:Wake()
        self:Message('Search queued · '..tostring(W.Automation:ContextReason() or 'waiting for the Auction House'))
    end
    self.dirty=true;return true,'SEARCH_QUEUED'
end
function U:TryPendingSearch(scope)
    local pending=self.pendingSearch
    if not pending then return false end
    if not W.runtime.ahOpen or pending.session~=W.runtime.ahSession or pending.account~=W.Storage.account or
        pending.character~=W.Storage.character or not self.frame or not self.frame:IsShown() or
        self.section~='buy' or pending.signature~=self:SearchSignature() or pending.selection~=self.shopSelected then
        self:CancelPendingSearch();return false
    end
    if searchClock()>pending.expiresAt then
        self:CancelPendingSearch('Search expired while the Auction House was unavailable. Press Search to retry.');return false
    end
    scope=scope or W.Scope:Snapshot()
    if not scope.ready then return false end
    if type(InCombatLockdown)=='function' and InCombatLockdown() then return false end
    if W.Scan and W.Scan:IsActive() and not W.Scan.pausedForUser and W.Priority then W.Priority:ManualSearch()end
    if W.QueryBusy() or W.Scheduler.active then return false end
    local api=W.Compat.auction
    if api and type(api.IsThrottledMessageSystemReady)=='function' then
        local ok,ready=pcall(api.IsThrottledMessageSystemReady);if not ok or ready~=true then return false end
    end
    if W.Storage.TargetQueryEligibility then
        local allowed=W.Storage:TargetQueryEligibility('MANUAL');if not allowed then return false end
    end
    -- Clear before dispatch: a callback may replace the queue, and a native
    -- query failure must not become repeated automatic submissions.
    self.pendingSearch=nil;self.notice=nil
    local ok,why
    if pending.kind=='ITEM' then ok,why=self:InspectItem(pending.row,true,pending.compare)
    else ok,why=self:SearchShop(true)end
    if not ok and not self.pendingSearch and not W.Scope:Snapshot().ready and
        W.runtime.ahOpen and pending.session==W.runtime.ahSession then
        self.pendingSearch=pending
        if W.Automation then W.Automation:Wake()end
    end
    return ok,why
end
function U:SearchShop(replay)
    self.browseTextBeforeSell=nil
    self:EndSellComparison()
    if not replay then self:CancelPendingSearch()end
    local text=self.shopInput:GetText():match('^%s*(.-)%s*$')
    if text:match('^%d+$') or text:find('item:',1,true) or text:match('^%d+:%d+:') then
        local item,why=W.Targeted:Resolve(text)
        if not item then return self:Message(why or 'That item could not be resolved.')end
        return self:InspectItem({itemID=item.itemID,itemKey=item,name=self:Name(item.itemID),itemLink=text:find('|H',1,true) and text or nil},replay)
    end
    local category=categories[self.shopCategory or 1][1]
    if #text>70 or (#text<2 and category=='all') then return self:Result(false,'Enter at least two letters (or select a category).')end
    if not replay and W.runtime.ahOpen and not W.Scope:Snapshot().ready then return self:QueueForegroundSearch('SHOP')end
    local lo,hi=tonumber(self.shopMin:GetText()),tonumber(self.shopMax:GetText())
    local equipment=category=='weapons' or category=='armor'
    if equipment and self.shopUsable and not hi then hi=W.PlayerContext.data.level end
    local ok,why=W.Browse:Query(self.shopInput:GetText(),category,{quality=rarities[self.shopQuality or 1][1],
        sort=self.shopSort,reverse=self.shopReverse,exact=self.shopExact,usable=self.shopUsable and equipment,
        minLevel=lo,maxLevel=hi})
    if ok then
        self.shopMode='browse';self.shopSelected=nil;self.offerSelected=nil;self.shopTable.page=0
        self.shopCleared=false;self.shopAwaitingApply=false;self.shopCompactDetail=false
    end
    return self:Result(ok,why)
end
function U:InspectItem(row,replay,compare)
    if not row then return end
    if not compare then self:EndSellComparison()end
    if not replay then self:CancelPendingSearch()end
    local key=W.ItemKinds:ObserveKey(row.itemKey or {itemID=row.itemID,itemLevel=0,itemSuffix=0,battlePetSpeciesID=0})
    if not replay and W.runtime.ahOpen and not W.Scope:Snapshot().ready then
        return self:QueueForegroundSearch('ITEM',{itemID=row.itemID,itemKey=key,name=row.name,itemLink=row.itemLink,icon=row.icon},compare)
    end
    local ok,why=W.Targeted:Request(key,nil,row)
    if ok then
        self.shopCleared=false
        local t=W.Targeted
        local requested=W.Storage:WatchKey(key)
        if not requested or t.queryKey~=requested or t.session~=W.runtime.ahSession then
            return self:Result(false,'Search changed. Select the item again.')
        end
        self.shopQuantity:SetText('')
        for _,field in ipairs(self.shopBidAmounts or {})do field:SetText('')end
        self.shopSelected={name=row.name or self:Name(key.itemID,row.itemLink),itemID=key.itemID,
            itemKey=key,itemLink=row.itemLink,icon=row.icon,minPrice=row.minPrice,
            queryReceipt=t.itemKey,queryKey=requested,querySession=t.session}
        self.shopMode='offers';self.shopCompactDetail=false;self.shopAwaitingApply=false
        self.offerSelected=nil;self.offerToken=nil;self.offerRows={};self.shopTable.page=0
        self:Select('buy')
    end
    return self:Result(ok,why)
end
function U:OfferRequestCurrent()
    local t,r=W.Targeted,self.shopSelected
    return r~=nil and r.queryReceipt~=nil and t.itemKey==r.queryReceipt and
        t.queryKey==r.queryKey and t.origin~='QUICK_OPEN' and W.runtime.ahOpen and
        t.session==W.runtime.ahSession and r.querySession==t.session and
        t.scope~=nil and t.scope.key==W.Scope:ReadMarketKey()
end
function U:ReadOffers()
    local t=W.Targeted
    if not self:OfferRequestCurrent() or t.state~='COMPLETE' then
        self.offerSelected=nil;self.offerToken=nil;self.offerRows=nil
        return {}
    end
    local rows=t.offerBook
    if not rows then return {} end
    if self.offerToken==rows then return rows end
    self.offerSelected=nil
    self.offerRows=rows;self.offerToken=rows
    return rows
end
function U:ShopAction()
    if self.shopMode~='offers' then return self:InspectItem(self.shopSelected)end
    if not self:OfferRequestCurrent() or W.Targeted.state~='COMPLETE' then return self:Result(false,'Offers changed. Refresh offers first.') end
    if W.Targeted.kind=='COMMODITY' then
        local e=self.shopEstimate;local qty=tonumber(self.shopQuantity:GetText())
        if not e or e.quantity~=qty then self:Refresh();self:Message('Review the updated total, then click Buy.');return end
        local ok,why=W.Trading:BuyCommodity(qty,e.maxTotal)
        self:Result(ok,why)
    elseif self.offerSelected and W.Math.ValidInteger(self.offerSelected.auctionID,1) then
        self:Result(W.Trading:PrepareItem(self.offerSelected.index,self.offerSelected.auctionID))
    end
    self:RefreshModal()
end
function U:Refresh_buy()
    if self.comparingSell and not self.sellItems then self:LoadSellItems()end
    if self.comparingSell and not self.sellSelected then
        self:EndSellComparison()
        self:CancelPendingSearch()
        self.shopSelected=nil;self.offerSelected=nil;self.shopMode='browse'
        self:RestoreBrowseText()
        self:Message('The selected bag slot changed. Select an item to continue.')
    end
    self.categoryButton.label:SetText(categories[self.shopCategory or 1][2])
    self.qualityButton.label:SetText(rarities[self.shopQuality or 1][2])
    self.sortButton.label:SetText(self.shopSort=='name' and 'Name A-Z' or self.shopReverse and 'Price: high' or 'Price: low')
    self.exactButton.label:SetText(self.shopExact and 'Exact: on' or 'Exact: off');self.exactButton:Select(self.shopExact)
    self.usableButton.label:SetText(self.shopUsable and 'For me: on' or 'For me: off');self.usableButton:Select(self.shopUsable)
    local offers=self.shopMode=='offers';local rows=offers and self:ReadOffers() or (self.shopCleared and {} or W.Browse.results)
    if self.shopTable and self.shopTable.headers and self.shopTable.headers[3] then
        self.shopTable.headers[3]:SetText(offers and 'OFFER ASK / UNIT' or 'LOWEST ASK / UNIT')
    end
    if self.shopTable then
        local rowsToShow=#rows<=2 and 2 or #rows<=4 and 4 or
            (self.layout=='compact' and 6 or self.shopTable.maxCount)
        self.shopTable:ConfigureRows(rowsToShow)
    end
    self.shopTable:SetData(rows,function(r)
        local selected=offers and U.shopSelected
        local link=r.itemLink or (selected and selected.itemLink)
        local q=U:Quote(r.itemKey,link)
        local ref=q and q.priceCopper and U:Money(q.priceCopper) or '—'
        local name=r.name or (selected and selected.name)
        if type(name)=='string' and name:match('^Item %d+$') then name='Loading item name · #'..tostring(r.itemID) end
        return {name,tostring(r.quantity or '—'),U:Money(offers and r.unit or r.minPrice),ref},U:ItemSub(r)
    end,offers and self.offerSelected or self.shopSelected,
        not W.runtime.ahOpen and 'Visit an auctioneer to shop.' or
        self.pendingSearch and ('Search queued · '..tostring(W.Automation:ContextReason() or 'waiting for the Auction House')) or
        not W.Scope:Snapshot().ready and W.Automation:ContextReason() or
        (W.Targeted:IsActive() and offers or W.Browse.state=='REQUESTED') and 'Checking offers…' or
        offers and self:OfferRequestCurrent() and W.Targeted.state=='COMPLETE' and 'No offers available.' or
        offers and W.Targeted.state=='PARTIAL' and 'Partial results. Retry or use Blizzard view.' or
        offers and W.Targeted.state=='INVALID' and 'Price unavailable. Retry or use Blizzard view.' or
        offers and W.Targeted.state=='STALE' and 'Offers changed. Refresh prices.' or
        offers and 'Refresh for current offers.' or self.shopAwaitingApply and 'Search to apply the updated query or filters.' or 'Search items or choose a category.')
    self.shopBack:SetShown(offers and not self.comparingSell)
    self.offerRefresh:Hide();self.offerRefresh:ApplyAvailability(offers and W.runtime.ahOpen and W.Trading.state=='IDLE' and not W.Targeted:IsActive())
    self.shopMore:ApplyAvailability(offers and self:OfferRequestCurrent() and W.Targeted:CanLoadMore()==true or not offers and W.Browse.hasMore==true)
    local r=self.shopSelected
    self.shopSearch.label:SetText(self.pendingSearch and 'Queued' or 'Search')
    self.shopSearch:ApplyAvailability(W.runtime.ahOpen and W.Trading.state=='IDLE' and W.Browse.state~='REQUESTED')
    self:RefreshShopActions(offers,r,rows)
    local drill=self.layout=='compact' and not offers and r and self.shopCompactDetail
    self.shopTable.pageText:SetShown(not drill)
    if drill then self.shopTable.prev:Hide();self.shopTable.next:Hide()end
    if self.comparingSell then
        self:LayoutShopView(offers,r)
        self:RefreshSellForm()
        self:SetActivePageExtent()
        return
    end
    local commodity=offers and self:OfferRequestCurrent() and W.Targeted.kind=='COMMODITY'
    self.shopIcon:SetItem(r and r.itemID,r and r.itemLink,r and r.icon)
    self.shopName:SetText(r and r.name or 'Select an item')
    if self.shopDetailsTitle then self.shopDetailsTitle:SetText('ITEM DETAILS')end
    local q=r and self:Quote(r.itemKey,r.itemLink)
    local hasQuote=not offers and r and q and W.Math.ValidNumber(q.priceCopper) and q.priceCopper>0
    self.shopProposal:SetShown(hasQuote==true)
    self.shopRange:SetShown(hasQuote==true)
    self.shopComparison:SetShown(hasQuote==true)
    local hint=r and 'Select See live offers for current asking prices.' or 'Select an item to inspect offers.'
    if hasQuote then
        self.shopProposal:SetText('Market reference: '..self:Money(q.priceCopper)..' / unit' )
        -- Do not synthesize a measured minimum from the separate market reference.
        local low=q.floorCopper
        local high=q.p75Copper
        local range=(W.Math.ValidNumber(low) and W.Math.ValidNumber(high) and high>=low and low>=0) and
            (self:Money(low)..' – '..self:Money(high)) or 'Not enough comparable listings'
        self.shopRange:SetText('Measured Range: '..range)
        local compare,color=self:PriceComparison(q,r.minPrice)
        self.shopComparison:SetText(compare or 'Comparison unavailable')
        self.shopComparison:SetTextColor(unpack(color or C.muted))
    elseif r and not offers then
        hint='No saved market reference for this item. Check current offers.'
    end
    self.shopHint:SetShown(hasQuote~=true)
    self.shopQuantity:SetShown(offers and commodity)
    self.shopQuantityLabel:SetShown(offers and commodity)
    self.shopQuantityLabel:SetText('Quantity to buy')
    local showBid=offers and not commodity and self.offerSelected~=nil
    for _,input in ipairs(self.shopBidAmounts)do input:SetShown(showBid) end
    for _,label in ipairs(self.shopBidAmounts.labels or {})do label:SetShown(showBid) end
    self.shopBid:SetShown(showBid)
    self.shopCost:SetShown(not offers or commodity)
    self:ReflowShopCard(showBid,offers,commodity)
    self.shopBid:ApplyAvailability(self:OfferRequestCurrent() and self.offerSelected~=nil and W.Math.ValidInteger(self.offerSelected.auctionID,1) and not (self.offerSelected and self.offerSelected.owned) and W.Trading.state=='IDLE')
    self.shopEstimate=nil
    if commodity then
        local e,why=W.Trading:CommodityEstimate(tonumber(self.shopQuantity:GetText()),true)
        self.shopEstimate=e
        local trend=q and q.identity and W.Signals:Label(q.marketKey,q.identity)
        hint='Lowest available offers fill your quantity.\nPrice allowance: '..(W.Trading:Tolerance()/100)..'%'..
            (trend and ('\n'..trend..' (asks)') or '')
        self.shopCost:SetText(e and ('Estimated total: '..self:Money(e.total)..'\nSpending limit: '..self:Money(e.maxTotal)) or (why or 'Waiting for offers'))
        self.shopBuy.label:SetText(e and ('Buy '..e.quantity..' units') or 'Buy')
        self.shopBuy:ApplyAvailability(e~=nil and W.Trading.state=='IDLE' and W.runtime.ahOpen)
    elseif offers then
        local o=self.offerSelected
        hint=o and (o.owned and 'Your own auction cannot be purchased.' or
            ('Buyout total: '..self:Money(o.total)..'\nStarting bid: '..self:Money(o.bid)..'\n\nThis purchase is for this exact auction.')) or 'Select an offer to review.'
        self.shopBuy.label:SetText('Review buyout');self.shopBuy:ApplyAvailability(o~=nil and W.Math.ValidInteger(o.auctionID,1) and o.total and o.total>0 and not o.owned and W.Trading.state=='IDLE')
    else
        self.shopCost:SetText(r and ('Lowest ask  '..self:Money(r.minPrice)..' / unit · live') or '')
        self.shopBuy.label:SetText('See live offers');self.shopBuy:ApplyAvailability(r~=nil and W.runtime.ahOpen and W.Trading.state=='IDLE')
    end
    if offers then
        self.shopHint:SetShown(true)
        self.shopProposal:SetShown(false);self.shopRange:SetShown(false);self.shopComparison:SetShown(false)
    end
    self.shopHint:SetText(hint)
    self.shopWatch:Hide()
    self.shopResearch:Hide()
    self.shopBuy:SetShown(r~=nil)
    self.shopWatch:ApplyAvailability(r~=nil and W.Storage:IsWritable())
    self.shopResearch:ApplyAvailability(self:CanResearch(self.offerSelected or r))
    self:LayoutShopView(offers,r)
    local canSell=self:MatchingSellItem(self.offerSelected or r)~=nil
    self.shopSide:ApplyAvailability(canSell)
    self.shopSide.arrow:SetShown(canSell)
    if not canSell and self.choiceMenu and self.choiceMenu.anchor==self.shopSide then self.choiceMenu:Hide()end
    self:SetActivePageExtent()
end


-- The former controls remain created for backward-compatible page functions,
-- but no longer render. All visible discovery controls have a single, legible
-- purpose, and no market data is deleted by Clear.
function U:CreateShopActions(page,form)
    for _,control in ipairs({self.shopSearch,self.shopReset,self.categoryButton,
        self.qualityButton,self.sortButton,self.exactButton,self.usableButton,
        self.shopMin,self.shopMax,self.shopMore,self.offerRefresh,self.shopWatch,
        self.shopResearch})do
        control:Hide()
    end
    self.shopActionSearch=F:IconAction(page,440,50,38,'Search','Search offers',function()U:SearchShop()end)
    self.shopActionClear=F:IconAction(page,486,50,38,'Clear','Clear search and filters',function()U:ClearShopSearch()end)
    self.shopActionFilter=F:IconAction(page,532,50,38,'Filters','Filters',function()U:OpenShopFilters()end)
    self.shopActionRefresh=F:IconAction(page,578,50,38,'Refresh','Refresh current offers',function()
        if U.shopSelected then U:InspectItem(U.shopSelected,false,U.comparingSell) end
    end)
    self.shopActionMore=F:IconAction(page,624,50,38,'LoadMore','Load more results',function()
        if U.shopMode=='offers' then
            if U:OfferRequestCurrent() then U:Result(W.Targeted:More())end
        else U:Result(W.Browse:More())end
    end)
    self.shopFiltersSummary=F:Text(page,0,103,658,24,'All items',12,C.muted)
    self.shopDetailsTitle=F:Text(form,18,5,266,16,'ITEM DETAILS',11,C.secondary)
    self.shopIcon:ClearAllPoints();self.shopIcon:SetPoint('TOPLEFT',form,'TOPLEFT',18,-30)
    self.shopName:ClearAllPoints();self.shopName:SetPoint('TOPLEFT',form,'TOPLEFT',74,-30)
    self.shopFavorite=F:IconAction(form,267,23,34,'FavoriteOutline','Save favorite',function()
        U:ToggleShopFavorite()
    end)
    self.shopName:SetWidth(190);self.shopName:SetWordWrap(false)
    self.shopSide=self:CreateTradeSide(form,'Buy')
    self.shopDetailBack=F:ButtonAt(page,796,0,194,34,'Back to results',function()
        U.shopCompactDetail=false;U:Refresh()
    end)
    self.shopDetailBack:Hide()
end
function U:FavoriteKey(row)
    -- A row lacking a confirmed exact variant must not silently save itemID:0:0:0.
    if type(row)~='table' or type(row.itemKey)~='table' then return nil end
    -- Read-only classification avoids repeated native item-data probes each
    -- time the spotlight repaints; observed commodity identity is cached by
    -- ItemKinds when the client supplies it.
    return W.Storage:WatchKey(W.ItemKinds:Key(row.itemKey))
end
function U:ShopFavoriteKey() return self:FavoriteKey(self.shopSelected)end
function U:FavoriteSaved(row)
    local key=self:FavoriteKey(row)
    return key~=nil and W.Storage.account and W.Storage.account.watchlist and
        W.Storage.account.watchlist.items[key]~=nil
end
function U:ToggleFavoriteFor(row)
    local key=self:FavoriteKey(row)
    if not key then return self:Message('Select an exact item first.')end
    local saved=self:FavoriteSaved(row)
    local ok,why
    if saved then ok,why=W.Storage:RemoveWatch(key)
    else
        local _,normalized=W.Storage:WatchKey(W.ItemKinds:Key(row.itemKey))
        if normalized then ok,why=W.Storage:AddWatch(normalized)
        else return self:Message('Exact item details are unavailable. Select another item.') end
    end
    self:Result(ok,why)
    if ok then self:Message(saved and 'Removed from Favorites.' or 'Saved to Favorites.')end
    self:Refresh()
    return ok,why
end
function U:ToggleShopFavorite() return self:ToggleFavoriteFor(self.shopSelected)end
-- Discard any stale presentation whenever query text or filters change.
-- The native request may still finish; its response is not a new user search.
function U:RestoreBrowseText()
    if self.browseTextBeforeSell~=nil then
        self.shopInput:SetText(self.browseTextBeforeSell)
        self.browseTextBeforeSell=nil
        self.shopSelected=nil
    end
end
function U:RetireShopResults(isTextEdit)
    if isTextEdit then self.browseTextBeforeSell=nil else self:RestoreBrowseText() end
    self:EndSellComparison()
    self:CancelPendingSearch()
    if W.Browse and W.Browse.Retire then W.Browse:Retire() end
    self.shopCleared=true;self.shopAwaitingApply=true;self.shopCompactDetail=false
    self.shopMode='browse';self.shopSelected=nil;self.offerSelected=nil
    self.offerRows=nil;self.offerToken=nil;self.shopEstimate=nil
    if self.shopTable then self.shopTable.page=0 end
    if isTextEdit then self.dirty=true else self:Refresh()end
end
function U:ClearShopSearch()
    self.browseTextBeforeSell=nil
    self:EndSellComparison()
    -- A completed native request cannot be canceled safely; retire its visible
    -- identity immediately, and reject the obsolete result until a new search.
    self:CancelPendingSearch()
    self.shopInput:SetText('')
    self.shopCategory=1;self.shopQuality=1;self.shopSort='price';self.shopReverse=false
    self.shopExact=false;self.shopUsable=self:Settings().personalize~=false
    self.shopMin:SetText('');self.shopMax:SetText('')
    self.shopMode='browse';self.shopSelected=nil;self.offerSelected=nil
    self.shopCompactDetail=false;self.shopAwaitingApply=false
    self.shopEstimate=nil;self.shopCleared=true;self.offerRows=nil;self.offerToken=nil
    if W.Browse and W.Browse.Retire then W.Browse:Retire()end
    self.shopTable.page=0
    if self.nestedMenu then self.nestedMenu:Hide()end
    if self.choiceMenu then self.choiceMenu:Hide()end
    if self.shopLevelPanel then self.shopLevelPanel:Hide()end
    self:Message('Search and filters cleared. Saved prices and Favorites are unchanged.')
    self:Refresh()
end
function U:OpenShopLevelBounds()
    if self.shopLevelPanel then
        self.levelLower:SetText(self.shopMin:GetText())
        self.levelUpper:SetText(self.shopMax:GetText())
        self.shopLevelPanel:Show();return
    end
    local panel=F:Box(self.frame,0,0,274,164,C.panel)
    panel:SetClampedToScreen(true);panel:SetFrameLevel(self.frame:GetFrameLevel()+95)
    panel:SetPoint('TOPLEFT',self.shopActionFilter,'BOTTOMLEFT',0,-5)
    F:Text(panel,14,12,245,25,'Level range',15,C.text)
    F:Text(panel,14,40,105,18,'Minimum:',12,C.muted)
    F:Text(panel,142,40,105,18,'Maximum:',12,C.muted)
    self.levelLower=F:Edit(panel,14,59,112,32,self.shopMin:GetText())
    self.levelUpper=F:Edit(panel,140,59,112,32,self.shopMax:GetText())
    F:ButtonAt(panel,14,105,112,34,'Apply',function()
        local lo,hi=self.levelLower:GetText(),self.levelUpper:GetText()
        if lo~='' and (not W.Math.ValidInteger(tonumber(lo),1,9999)) or
            hi~='' and (not W.Math.ValidInteger(tonumber(hi),1,9999)) or
            (lo~='' and hi~='' and tonumber(lo)>tonumber(hi)) then
            self:Message('Enter a valid minimum and maximum level.');return
        end
        self.shopMin:SetText(lo);self.shopMax:SetText(hi);panel:Hide();self:Refresh()
    end,true)
    F:ButtonAt(panel,140,105,112,34,'Clear',function()
        self.shopMin:SetText('');self.shopMax:SetText('')
        self.levelLower:SetText('');self.levelUpper:SetText('')
        panel:Hide();self:Refresh()
    end)
    self.shopLevelPanel=panel
end
function U:OpenShopFilters()
    local groups={
        {id='category',title='Item type',options=categories},
        {id='rarity',title='Rarity',options=rarities},
        {id='sort',title='Sort by',options={{'low','Lowest price'},{'high','Highest price'},{'name','Name A-Z'}}},
        {id='exact',title='Exact match',options={{true,'On'},{false,'Off'}}},
        {id='usable',title='For my character',options={{true,'On'},{false,'Off'}}},
        {id='level',title='Level range',options={{'edit','Choose minimum and maximum'},{'clear','Clear level range'}}},
        {id='reset',title='Reset filters',options={{'reset','Restore default filters'}}},
    }
    F:ChooseNested(self.shopActionFilter,groups,function(kind,value)
        if kind=='category' then for i,v in ipairs(categories)do if v[1]==value then U.shopCategory=i end end
        elseif kind=='rarity' then for i,v in ipairs(rarities)do if v[1]==value then U.shopQuality=i end end
        elseif kind=='sort' then
            U.shopSort=value=='name' and 'name' or 'price';U.shopReverse=value=='high'
        elseif kind=='exact' then U.shopExact=value
        elseif kind=='usable' then U.shopUsable=value
        elseif kind=='level' then
            if value=='edit' then U:OpenShopLevelBounds()
            else U.shopMin:SetText('');U.shopMax:SetText('')end
        elseif kind=='reset' then
            U.shopCategory=1;U.shopQuality=1;U.shopSort='price';U.shopReverse=false
            U.shopExact=false;U.shopUsable=U:Settings().personalize~=false
            U.shopMin:SetText('');U.shopMax:SetText('')
        end
        U:RetireShopResults(false)
    end,function(kind,value) return U:ShopFilterSelected(kind,value)end)
end
function U:ShopFilterSelected(kind,value)
    if kind=='category' then return categories[self.shopCategory or 1][1]==value end
    if kind=='rarity' then return rarities[self.shopQuality or 1][1]==value end
    if kind=='sort' then return (self.shopSort=='name' and 'name' or self.shopReverse and 'high' or 'low')==value end
    if kind=='exact' then return self.shopExact==value end
    if kind=='usable' then return self.shopUsable==value end
    return false
end
-- Use the full compact viewport for browse rows when the detail view is closed.
-- Re-anchoring is limited to mode changes, not each incoming result/event.
function U:ReflowShopTable()
    local layout=self.comparingSell and 'compare' or 'split'
    if not self.shopTable or self.shopTableWide==layout then return end
    self.shopTableWide=layout
    local t=self.shopTable
    local widths=self.comparingSell and {240,57,144,151} or {260,65,150,157}
    local width=self.comparingSell and 618 or 658
    t:SetWidth(width)
    local off=12
    for j,c in ipairs(t.columns)do
        c.width=widths[j]
        local header=t.headers[j]
        header:ClearAllPoints()
        header:SetPoint('TOPLEFT',t,'TOPLEFT',off,-10)
        header:SetWidth(widths[j]-12)
        off=off+widths[j]
    end
    for _,item in ipairs(t.rows)do
        item:SetWidth(width-12)
        local left=6
        item.name:ClearAllPoints()
        item.name:SetPoint('TOPLEFT',item,'TOPLEFT',left+t.rowHeight-4,-5)
        item.name:SetWidth(widths[1]-t.rowHeight-8)
        item.sub:ClearAllPoints()
        item.sub:SetPoint('TOPLEFT',item,'TOPLEFT',left+t.rowHeight-4,-25)
        item.sub:SetWidth(widths[1]-t.rowHeight-8)
        left=left+widths[1]
        for j=2,#widths do
            local cell=item.cells[j]
            if cell then
                cell:ClearAllPoints()
                cell:SetPoint('TOPLEFT',item,'TOPLEFT',left,-12)
                cell:SetWidth(widths[j]-14)
            end
            left=left+widths[j]
        end
    end
    t.empty:SetWidth(width-48)
    t.pageText:SetWidth(width-114)
end
-- A compact item summary is its own view, rather than a squeezed desktop card.
-- Offer rows retain their protected, explicitly reviewed auction controls.
function U:LayoutShopView(offers,row)
    if not self.shopForm then return end
    local compact=self.layout=='compact'
    local drill=compact and not offers and row~=nil and self.shopCompactDetail==true
    local key=(drill and 'DETAIL' or compact and 'COMPACT_LIST' or 'DESKTOP')..':'..
        (offers and 'OFFERS' or 'BROWSE')..':'..tostring(self.shopGeometry)..(self.comparingSell and ':SELL' or '')..(row and ':ITEM' or ':EMPTY')
    -- Reflow only on a layout transition; do not repaint navigation frames on
    -- each 200 ms UI refresh during market replication.
    if self.shopViewLayout==key then return end
    self.shopViewLayout=key
    self.shopDetailBack:SetShown(drill)
    self.shopBack:ClearAllPoints();self.shopBack:SetPoint('TOPRIGHT',self.pages.buy,'TOPRIGHT',0,-50)
    for _,control in ipairs({self.shopInput,self.shopActionSearch,self.shopActionClear,
        self.shopActionFilter,self.shopFiltersSummary,self.shopTable,self.shopBack})do
        if drill then control:Hide()
        elseif control==self.shopBack then control:SetShown(offers and not self.comparingSell)
        else control:Show()end
    end
    if drill then self.shopActionRefresh:Hide();self.shopActionMore:Hide()end
    self.shopEmpty:SetShown(row==nil and not self.comparingSell)
    self.shopForm:SetShown(row~=nil and not self.comparingSell)
    if not drill then self:ReflowShopTable()end
    local form=self.shopForm
    form:ClearAllPoints()
    form:SetPoint('TOPLEFT',self.pages.buy,'TOPLEFT',drill and 0 or 674,-(drill and 54 or 134))
    form:SetWidth(drill and 990 or 316)
    if not drill then
        form:SetHeight(self.shopGeometry=='COMPACT_EMPTY' and 188 or
            self.shopGeometry=='COMPACT_SUMMARY' and 350 or 416)
    else
        form:SetHeight(435)
    end
    local function place(widget,x,y,width,height)
        if not widget then return end
        widget:ClearAllPoints();widget:SetPoint('TOPLEFT',form,'TOPLEFT',x,-y)
        if width then widget:SetWidth(width)end
        if height then widget:SetHeight(height)end
    end
    place(self.shopDetailsTitle,18,drill and 12 or 5,drill and 900 or 266)
    place(self.shopIcon,18,drill and 47 or 30)
    place(self.shopName,drill and 82 or 74,drill and 44 or 27,drill and 760 or 190,24)
    place(self.shopSide,drill and 82 or 74,drill and 71 or 54,84,23)
    place(self.shopFavorite,drill and 932 or 267,drill and 47 or 23)
    place(self.shopHint,18,drill and 138 or 89,drill and 450 or 280,drill and 105 or 100)
    place(self.shopProposal,18,drill and 126 or 91,drill and 465 or 280)
    place(self.shopRange,18,drill and 168 or 119,drill and 465 or 280)
    place(self.shopComparison,18,drill and 220 or 169,drill and 465 or 280)
    place(self.shopCost,drill and 535 or 18,drill and 265 or
        (self.shopGeometry=='FULL_OFFER' and 243 or 208),drill and 435 or 278,
        drill and 68 or self.shopGeometry=='FULL_OFFER' and 66 or 44)
    place(self.shopBuy,drill and 535 or 18,drill and 350 or
        (self.shopGeometry=='FULL_OFFER' and 366 or 307),drill and 435 or 278)
    place(self.shopQuantityLabel,drill and 535 or 18,drill and 88 or 196)
    place(self.shopQuantity,drill and 760 or 194,drill and 78 or 187)
    -- Legacy actions are intentionally hidden; the Favorite icon owns the toggle.
end
function U:RefreshShopActions(offers,row,rows)
    if not self.shopActionSearch then return end
    local filters=categories[self.shopCategory or 1][2]..' · '..rarities[self.shopQuality or 1][2]..' · '..
        (self.shopSort=='name' and 'Name A-Z' or self.shopReverse and 'Price high' or 'Price low')
    if self.shopExact then filters=filters..' · Exact' end
    if self.shopUsable then filters=filters..' · For me' end
    if self.shopMin:GetText()~='' or self.shopMax:GetText()~='' then
        filters=filters..' · Level '..self.shopMin:GetText()..'–'..self.shopMax:GetText()
    end
    if self.shopAwaitingApply then filters=filters..' · Search to apply' end
    self.shopFiltersSummary:SetText(filters)
    self.shopActionSearch:ApplyAvailability(W.runtime.ahOpen and W.Trading.state=='IDLE' and
        W.Browse.state~='REQUESTED' and W.Browse.state~='RETIRED' and not self.pendingSearch)
    self.shopActionClear:ApplyAvailability(self.shopAwaitingApply or self.shopInput:GetText()~='' or self.shopCategory~=1 or
        self.shopQuality~=1 or self.shopSelected~=nil or self.pendingSearch~=nil or
        self.shopExact or self.shopReverse or self.shopSort~='price' or
        self.shopMin:GetText()~='' or self.shopMax:GetText()~='')
    self.shopActionRefresh:SetShown(offers and row~=nil)
    self.shopActionRefresh:ApplyAvailability(offers and row~=nil and W.runtime.ahOpen and
        W.Trading.state=='IDLE' and not W.Targeted:IsActive())
    local more=offers and self:OfferRequestCurrent() and W.Targeted:CanLoadMore()==true or
        not offers and W.Browse.hasMore==true and not self.shopCleared
    self.shopActionMore:SetShown(more)
    self.shopActionMore:ApplyAvailability(more and W.runtime.ahOpen and W.Trading.state=='IDLE')
    local key=self:ShopFavoriteKey()
    local saved=key and W.Storage.account and W.Storage.account.watchlist and
        W.Storage.account.watchlist.items[key]~=nil
    self.shopFavorite:SetShown(row~=nil)
    self.shopFavorite:ApplyAvailability(row~=nil and key~=nil and W.Storage:IsWritable())
    self.shopFavorite:SetIcon(saved and 'FavoriteFilled' or 'FavoriteOutline')
    self.shopFavorite.helpLabel=saved and 'Remove favorite' or 'Save favorite'
    -- Keep the reference to the old text controls private; all actionable
    -- Shop discovery operations are now represented by distinct icons.
end
