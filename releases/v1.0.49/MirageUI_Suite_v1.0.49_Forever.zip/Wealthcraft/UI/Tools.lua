local _,W=...
local U,F,C=W.UI,W.Widgets,W.Widgets.palette
function U:CreateTools()
    local p=self:Page('craft','Crafting','')
    self.craftStatus=F:Text(p,0,43,990,22,'',13,C.muted)
    self.craftInput=F:Edit(p,0,72,460,38,'',function()U:AnalyzeCraft()end)
    local prompt=F:Text(self.craftInput,12,10,432,20,'Recipe name or ID',14,C.muted)
    self.craftInput:HookScript('OnTextChanged',function(edit)prompt:SetShown(edit:GetText()=='')end)
    self.craftAnalyze=F:ButtonAt(p,472,72,170,38,'Analyze recipe',function()U:AnalyzeCraft()end,true)
    self.craftSelected=F:ButtonAt(p,654,72,166,38,'Use selected recipe',function()
        local id=W.Crafting:SelectedID()
        if not id then U:Message('Open Professions and select a learned recipe first.');return end
        U.craftInput:SetText(tostring(id));U:AnalyzeCraft()
    end)
    self.craftRefresh=F:ButtonAt(p,832,72,158,38,'Check recipes',function()
        local ok,reason,count=W.Crafting:RefreshObserved()
        U:Message(ok and (tostring(count or 0)..' learned recipes checked and saved.') or reason)
        U:Refresh()
    end)
    self.recipeTable=F:Table(p,0,124,476,{{title='LEARNED RECIPES',width=354},{title='SOURCE',width=96,align='RIGHT'}},6,43,function(r)
        U.craftInput:SetText(tostring(r.id));U:AnalyzeCraft()
    end)
    self.materialTable=F:Table(p,494,124,496,{{title='MATERIAL',width=274,item=true},{title='QTY',width=55,align='RIGHT'},{title='COST',width=141,align='RIGHT'}},6,43,function(r)
        U:InspectItem({itemID=r.itemID,itemKey={itemID=r.itemID,itemLevel=0,itemSuffix=0,battlePetSpeciesID=0},name=r.name})
    end)
    -- Both tables have the same row height/count in each viewport. Anchor to
    -- the actual pager so its full hit area stays clear at either density.
    local result=F:Box(p,0,0,990,106,C.panel)
    result:ClearAllPoints();result:SetPoint('TOPLEFT',self.recipeTable.prev,'BOTTOMLEFT',0,-14)
    self.craftSummary=result
    self.craftHeading=F:Text(result,16,12,958,24,'',16,C.secondary)
    self.craftResult=F:Text(result,16,42,958,58,'',14,C.text)
    self.craftResult:SetWordWrap(true)
    p=self:Page('ledger','Journal','')
    self.ledgerKind='SALE'
    local kinds={{'SALE','Sale'},{'PURCHASE','Purchase'},{'INCOME','Income'},{'EXPENSE','Expense'}}
    self.ledgerKinds={}
    for i,s in ipairs(kinds)do local id=s[1]
        self.ledgerKinds[id]=F:ButtonAt(p,(i-1)*130,50,120,34,s[2],function()U.ledgerKind=id;U:Refresh()end)
    end
    self.ledgerSummary=F:Text(p,540,50,450,64,'',15,C.secondary,'RIGHT')
    F:Text(p,0,104,274,20,'Item name, link or ID (optional)',12,C.muted)
    self.ledgerItem=F:Edit(p,0,128,270,36,'')
    F:Text(p,284,104,80,20,'Quantity',12,C.muted);self.ledgerQty=F:Edit(p,284,128,82,36,'1')
    F:Text(p,382,83,324,20,'Amount per unit',12,C.secondary)
    self.ledgerAmounts=self:MoneyInputs(p,382,104,324)
    F:ButtonAt(p,722,128,126,36,'Save entry',function()
        local text=U.ledgerItem:GetText();local id=0
        if text~='' then local key,why=W.Targeted:Resolve(text);if not key then U:Message(why);return end;id=key.itemID end
        local v=U:ReadMoney(U.ledgerAmounts)
        local ok,why=W.Ledger:Add(U.ledgerKind,id,tonumber(U.ledgerQty:GetText()),v)
        U:Result(ok,why);if ok then U:Message('Manual entry saved.');U:Refresh()end
    end,true)
    F:ButtonAt(p,860,128,130,36,'Undo last',function()U:Result(W.Ledger:UndoLatest())end)
    self.ledgerTable=F:Table(p,0,182,990,{{title='ITEM / NOTE',width=360,item=true},{title='TYPE',width=140},
        {title='UNITS',width=90,align='RIGHT'},{title='TOTAL',width=175,align='RIGHT'},{title='WHEN',width=199}},7,43)
    p=self:Page('reports','Reports','')
    self.reportsBack=F:ButtonAt(p,782,0,208,32,'Back to Insights',function()U:Select('overview')end)
    F:ButtonAt(p,0,50,190,38,'Refresh summary',function()W.Inventory:Refresh();U:Refresh()end,true)
    F:ButtonAt(p,202,50,190,38,'Copy summary',function()U:ShowReport(U:PlayerReport(),'Market summary')end)
    F:ButtonAt(p,404,50,212,38,'Detailed data report',function()U:ShowReport(W.Reports:Build(),'Detailed market report')end)
    self.reportBody=F:Box(p,0,104,990,466,C.panel)
    self.reportText=F:Text(self.reportBody,24,24,942,390,'',17,C.text)
end
function U:ReadMoney(inputs)
    local function entry(field) local t=field:GetText();return (t=='' or t==nil) and 0 or tonumber(t)end
    local g,s,c=entry(inputs[1]),entry(inputs[2]),entry(inputs[3])
    if not W.Math.ValidInteger(g,0,100000000) or not W.Math.ValidInteger(s,0,99) or not W.Math.ValidInteger(c,0,99)then return nil end
    return g*10000+s*100+c
end
function U:AnalyzeCraft()
    local id,why=W.Crafting:Resolve(self.craftInput:GetText())
    if not id then self:Message(why);return end
    local result=W.Crafting:Analyze(id)
    if result and result.status=='INCOMPLETE_INPUTS' then
        self:Message('Recipe information is incomplete. See the reasons below; no margin was estimated.')
    end
    self:Refresh()
end
function U:Refresh_craft()
    local recipes=W.Crafting:RecipeList()
    local status=W.Crafting:CatalogStatus()
    local last=W.Crafting:Read()
    local freshness
    if status.observedAt then
        freshness='Last checked '..W.Decision:Age(status.observedAt)
    else freshness='No saved observations' end
    local source=status.current and 'Recently checked; older entries may remain saved' or 'Saved names · validate in Professions'
    self.craftStatus:SetText(tostring(status.count)..' recipes · '..source..' · '..freshness)
    self.recipeTable:SetData(recipes,function(r)
        return {r.name,r.cached and 'Saved' or 'Checked'}
    end,function(r)return last and last.recipeID==r.id end,
        'No recipes recorded yet. Open Professions to capture your learned recipes.')
    local rows,unknown={},0
    for _,r in ipairs(last and last.reagents or {}) do
        rows[#rows+1]={itemID=r.itemID,name=self:Name(r.itemID),quantity=r.quantity,unit=r.unitCopper}
        if not r.unitCopper then unknown=unknown+1 end
    end
    self.materialTable:SetData(rows,function(r)
        return {r.name,tostring(r.quantity),r.unit and U:Money(r.unit*r.quantity) or 'Needs price'}
    end,nil,last and 'Open Professions to check this recipe’s materials.' or 'Select a recipe to see its materials.')
    self.craftSummary:SetShown(last~=nil)
    if not last then return end
    if last.status=='ESTIMATED_MARGIN' then
        self.craftHeading:SetText(last.name or 'Recipe estimate')
        self.craftResult:SetText('Materials: '..self:Money(last.materialCopper)..
            ' · Potential margin: '..self:SignedMoney(last.marginMinCopper)..
            (last.marginMaxCopper~=last.marginMinCopper and (' – '..self:SignedMoney(last.marginMaxCopper)) or '')..
            '\nOne complete market scan · assumed '..(last.assumedFeeBps/100)..'% sale fee. No sale or profit is guaranteed.')
        return
    end
    local details=last.explanation or (unknown>0 and (unknown..' material prices are missing.') or 'Current recipe information is incomplete.')
    local name=last.name or ((W.Crafting.known or {})[last.recipeID] and W.Crafting.known[last.recipeID].name) or 'Recipe'
    self.craftHeading:SetText(name)
    self.craftResult:SetText(details)
end
function U:SignedMoney(n)if type(n)~='number'then return 'Unknown'end;return n<0 and ('−'..self:Money(-n)) or self:Money(n)end
function U:Refresh_ledger()
    for kind,b in pairs(self.ledgerKinds)do b:Select(kind==self.ledgerKind)end
    local s=W.Ledger:Summary()
    self.ledgerSummary:SetText('In '..self:Money(s.incomeCopper)..' · Out '..self:Money(s.expenseCopper)..'\nNet cash flow '..self:SignedMoney(s.netCashFlowCopper))
    local rows={}
    for _,r in ipairs(W.Ledger:Latest(250))do
        rows[#rows+1]={itemID=r.itemID>0 and r.itemID or nil,name=r.itemID>0 and self:Name(r.itemID) or 'Manual cash-flow entry',
            kind=r.kind,quantity=r.quantity,total=r.quantity*r.unitCopper,at=r.at,detail='Player-entered'}
    end
    self.ledgerTable:SetData(rows,function(r)
        local names={SALE='Sale',PURCHASE='Purchase',INCOME='Income',EXPENSE='Expense'}
        return {r.name,names[r.kind],tostring(r.quantity),U:Money(r.total),W.Decision:Age(r.at)},U:ItemSub(r)
    end,nil,'No manual entries yet. This journal does not infer sales from disappearing auctions.')
end
function U:PlayerReport(asDisplay)
    local m=W.Decision:Market();local inv=m.inventory;local ledger=W.Ledger:Summary()
    local moneyText=function(n)return asDisplay and (n<0 and ('−'..self:Money(-n)) or self:Money(n)) or self:MoneyPlain(n)end
    local lines={'WEALTHCRAFT — MARKET SUMMARY',m.label or W.PlayerContext.data.location or 'No market selected','',
        'Prices: '..(m.latest and ((m.latest==m.partial and 'Partial sample' or 'Full snapshot')..', '..m.age) or 'No full-market scan yet'),
        'Coverage: '..(m.coverage and string.format('%.1f%% of scanned listings identified',m.coverage) or 'Not measured'),
        'Favorites: '..m.watchCount..' saved items',
        'Learned recipes recorded: '..tostring(W.Crafting:CatalogStatus().count)..
            (W.Crafting:CatalogStatus().current and ' (checked this session)' or ' (cached; needs validation)'), '',
        'Priced bag subtotal: '..(inv and moneyText(inv.valueCopper) or 'Unavailable'),
        inv and (inv.valuedUnits..' units priced; '..inv.unknownUnits..' unpriced; '..inv.boundUnits..' bound units excluded') or '',
        '', 'Manual cash flow: '..moneyText(ledger.netCashFlowCopper)..' across '..ledger.entries..' entries',
        '', 'Next useful action',
        inv and inv.unknownUnits>0 and 'Check live prices for unpriced items before choosing what to sell.' or
            m.latest and 'Compare live offers before buying or posting. Market references are recorded asks, not sale values.' or 'Visit an auctioneer for automatic market refreshes, or search an item.',
        '', 'Observed listings are not completed sales. Bag estimates are not guaranteed proceeds.'}
    return table.concat(lines,'\n')
end
function U:Refresh_reports()self.reportText:SetText(self:PlayerReport(true))end
function U:FitReport()
    if self.copyFrame then self.copyFrame:SetScale(W.AuctionDesk:FitScale(790,620,.35))end
end
function U:ShowReport(text,title)
    if not self:Create() then return false end
    if not self.copyFrame then
        local r=CreateFrame('Frame','WealthcraftCopyReport',UIParent);r:SetSize(790,620);r:SetPoint('CENTER',UIParent,'CENTER',0,0)
        r:SetFrameStrata('FULLSCREEN_DIALOG');r:SetClampedToScreen(true);r:EnableMouse(true);self.copyFrame=r
        F:Box(r,0,0,790,620,C.panel)
        self.copyTitle=F:Text(r,22,20,640,34,'',23,C.text)
        r:SetMovable(true)
        local copyDrag=CreateFrame('Frame',nil,r)
        copyDrag:SetPoint('TOPLEFT',r,'TOPLEFT',0,0);copyDrag:SetSize(664,56)
        copyDrag:EnableMouse(true);copyDrag:RegisterForDrag('LeftButton')
        copyDrag:SetScript('OnDragStart',function()
            if not InCombatLockdown or not InCombatLockdown() then r:StartMoving() end
        end)
        copyDrag:SetScript('OnDragStop',function()r:StopMovingOrSizing()end)
        self.copyDragHandle=copyDrag
        F:ButtonAt(r,680,18,88,32,'Close',function()r:Hide()end)
        F:Text(r,22,63,740,24,'Press Ctrl+C to copy the selected report.',14,C.muted)
        local scroll=CreateFrame('ScrollFrame',nil,r,'UIPanelScrollFrameTemplate');scroll:SetPoint('TOPLEFT',r,'TOPLEFT',22,-100);scroll:SetSize(720,496)
        local edit=CreateFrame('EditBox',nil,scroll);edit:SetMultiLine(true);edit:SetAutoFocus(false);edit:SetFont('Fonts\\ARIALN.TTF',13,'')
        edit:SetTextColor(unpack(C.text));edit:SetWidth(708);edit:SetHeight(2200);edit:SetMaxLetters(60000)
        edit:SetScript('OnEscapePressed',function()r:Hide()end);scroll:SetScrollChild(edit)
        self.copyEdit=edit
        if UISpecialFrames then UISpecialFrames[#UISpecialFrames+1]='WealthcraftCopyReport'end
    end
    self.copyTitle:SetText(title or 'Diagnostics');self.copyEdit:SetText(text or W.Diagnostics:BuildReport())
    self:FitReport()
    -- An earlier drag location from a larger monitor must not strand the report
    -- outside a smaller Surface viewport when it is opened again.
    self.copyFrame:ClearAllPoints()
    self.copyFrame:SetPoint('CENTER',UIParent,'CENTER',0,0)
    self.copyFrame:Show();self.copyEdit:SetFocus();self.copyEdit:HighlightText()
end
