-- A reversible alpha lease: Blizzard remains shown and owns the AH session.
local _,W=...
W.AuctionDesk={active=false,fallback=false,section='buy'}
local D=W.AuctionDesk
function D:Enabled()return W.Storage.account and W.Storage.account.settings.auctionDeskEnabled~=false end
function D:SetEnabled(yes)
    if not W.Storage:IsWritable()then return false,'Settings are read only.'end
    W.Storage.account.settings.auctionDeskEnabled=yes==true
    if yes and W.runtime.ahOpen then self.fallback=false;return self:TryOpen()elseif not yes then self:NativeFallback()end
    return true
end
function D:FindNative()
    for _,name in ipairs({'AuctionHouseFrame','AuctionFrame'})do local f=_G[name]
        if f and type(f.IsShown)=='function' and f:IsShown()then return f end
    end
end
-- Visual baseline retains the accepted user zoom with viewport fit and scrolling.
-- Applying a factor here preserves the existing schema-4 scale preference.
D.baseScale=0.80
function D:DisplayScale()
    return W.Storage:CurrentScale()*self.baseScale
end
-- Safe inset in *UIParent logical units*, per edge. The P29 fit subtracted
-- only one inset in total, leaving just half a margin at each side; at short
-- Surface aspect ratios the presentation nearly touched the screen boundaries.
-- At truly small sizes we scale down rather than clip an action or close route.
function D:SafeInset(w,h)
    if not W.Math.ValidNumber(w) or not W.Math.ValidNumber(h) or w<=0 or h<=0 then return 18 end
    return math.min(30,math.max(12,math.min(w,h)*.03125),w/5,h/5)
end
function D:FitScale(width,height,preferredFloor)
    local w,h=UIParent:GetWidth(),UIParent:GetHeight()
    local parentScale=UIParent:GetEffectiveScale()
    if not W.Math.ValidNumber(parentScale) or parentScale<=0 then parentScale=1 end
    local desired=math.max(preferredFloor or .30,self:DisplayScale()/parentScale)
    if W.Math.ValidNumber(w) and W.Math.ValidNumber(h) and w>0 and h>0 and width>0 and height>0 then
        local margin=self:SafeInset(w,h)
        return math.max(.05,math.min(desired,(w-2*margin)/width,(h-2*margin)/height))
    end
    return desired
end
function D:ApplyScale()
    local r=W.UI.frame;if not r then return end
    W.UI:ApplyResponsiveLayout()
    r:SetScale(self:FitScale(W.UI.width,W.UI.height,.30))
    if r:IsShown() then self:Position() end
    if W.UI.copyFrame and W.UI.copyFrame:IsShown() then W.UI:FitReport() end
    if W.recoveryFrame and W.recoveryFrame:IsShown() then
        W.recoveryFrame:SetScale(self:FitScale(720,470,.30))
    end
end
-- WoW's resize notification can arrive before the last UIParent scale/extent
-- sample has settled. Refit once immediately and twice after the transition;
-- generation guards prevent stale callbacks from an earlier display change.
function D:ViewportChanged()
    self.viewportGeneration=(self.viewportGeneration or 0)+1
    local generation=self.viewportGeneration
    self:ApplyScale()
    if W.UI.copyFrame and W.UI.copyFrame:IsShown() then
        W.UI.copyFrame:ClearAllPoints()
        W.UI.copyFrame:SetPoint('CENTER',UIParent,'CENTER',0,0)
    end
    if C_Timer and type(C_Timer.After)=='function' then
        for _,delay in ipairs({.08,.35})do
            C_Timer.After(delay,function()
                if self.viewportGeneration==generation and W.UI.frame then self:ApplyScale()end
            end)
        end
    end
end
function D:Position()
    local r=W.UI.frame;if not r then return end;r:ClearAllPoints()
    local key=W.UI.layout=='compact' and 'deskPositionCompact' or 'deskPosition'
    local p=W.Storage.character and W.Storage.character[key]
    local w,h=UIParent:GetWidth(),UIParent:GetHeight()
    local parentScale=UIParent:GetEffectiveScale()
    if not W.Math.ValidNumber(parentScale) or parentScale<=0 then parentScale=1 end
    local scale=r:GetEffectiveScale()/parentScale
    if not W.Math.ValidNumber(scale) or scale<=0 then scale=1 end
    if W.Math.ValidNumber(w) and W.Math.ValidNumber(h) and w>0 and h>0 then
        local margin=self:SafeInset(w,h)
        local hx,hy=W.UI.width*scale/2,W.UI.height*scale/2
        local function clampCenter(fraction,span,half)
            local low,high=half+margin,span-half-margin
            if low>high then return span/2 end
            return math.max(low,math.min(high,span*(fraction or .5)))
        end
        local valid=type(p)=='table' and W.Math.ValidNumber(p.x) and W.Math.ValidNumber(p.y) and
            p.x>=0 and p.x<=1 and p.y>=0 and p.y<=1
        local cx=clampCenter(valid and p.x or .5,w,hx)
        local cy=clampCenter(valid and p.y or .5,h,hy)
        -- WoW applies the anchored region's scale to SetPoint offsets. Convert
        -- the clamped UIParent-space center back into this frame's own units.
        -- The center clamp and the fit MUST share the same relative scale.
        r:SetPoint('CENTER',UIParent,'BOTTOMLEFT',cx/scale,cy/scale)
    else r:SetPoint('CENTER',UIParent,'CENTER',0,0)end
end
function D:SavePosition()
    if not W.Storage:IsWritable()then return end
    local r=W.UI.frame;local x,y=r:GetCenter();local w,h=UIParent:GetWidth(),UIParent:GetHeight()
    local scale=r:GetEffectiveScale()/(UIParent:GetEffectiveScale() or 1)
    if W.Math.ValidNumber(x) and W.Math.ValidNumber(y) and W.Math.ValidNumber(scale) and
        W.Math.ValidNumber(w) and W.Math.ValidNumber(h) and w>0 and h>0 then
        local key=W.UI.layout=='compact' and 'deskPositionCompact' or 'deskPosition'
        -- GetCenter is reported in the region's own units; unlike SetPoint
        -- offsets, these *do* need the region-to-parent scale conversion.
        W.Storage.character[key]={x=math.max(0,math.min(1,x*scale/w)),y=math.max(0,math.min(1,y*scale/h))}
    end
end
function D:ResetPosition()
    if W.Storage:IsWritable()then W.Storage.character[W.UI.layout=='compact' and 'deskPositionCompact' or 'deskPosition']=nil end
    self:ApplyScale();self:Position()
end
function D:RestorePresentation()
    if self.restoring then return end;self.restoring=true;self.active=false
    if self.native and self.nativeAlpha~=nil then W.SafeCall(self.native.SetAlpha,self.native,self.nativeAlpha)end
    if self.mask then self.mask:Hide()end
    if W.UI.frame then W.UI.frame:Hide()end
    if W.UI.modal then W.UI.modal:Hide()end
    self.native=nil;self.nativeAlpha=nil;self.restoring=false
end
function D:NativeFallback(reason)
    self.fallback=true;W.QuickScan:Yield('Blizzard view',true);W.Trading:Closed();self:RestorePresentation()
    W.Diagnostics:Record('INFO',reason or 'Blizzard view restored by player')
end
function D:Release()
    self:RestorePresentation();self.fallback=false;W.Trading:Closed();self.sellItems=nil
    if W.UI.comparingSell then
        W.UI:RestoreBrowseText();W.UI:EndSellComparison()
        W.UI.shopSelected=nil;W.UI.offerSelected=nil;W.UI.shopMode='browse'
    end
    W.UI.sellItems=nil
end
function D:Attach()
    if not W.runtime.ahOpen or not W.Compat.build or not (W.Compat.build.runtimeAllowed or W.Compat.build.exactTarget) or self.fallback or not self:Enabled() or
        (InCombatLockdown and InCombatLockdown())then return false end
    local native=self:FindNative();if not native then return false end
    -- A root left by interrupted construction is not a usable replacement.
    -- Do not hide native controls until every custom page has completed.
    if W.UI:Create()==false or not W.UI.creationComplete or not W.UI.frame then return false end
    self.frame=W.UI.frame
    if self.active then return true end
    self.native=native;self.nativeAlpha=native:GetAlpha()
    local ok=W.SafeCall(native.SetAlpha,native,0);if not ok then self:RestorePresentation();return false end
    if not self.mask then
        self.mask=CreateFrame('Frame','WealthcraftNativeAuctionMask',UIParent)
        self.mask:SetFrameStrata('DIALOG');self.mask:SetFrameLevel(80);self.mask:EnableMouse(true)
    end
    self.mask:ClearAllPoints();self.mask:SetAllPoints(native);self.mask:Show()
    self.active=true;self:ApplyScale();self:Position();self.frame:Show();W.UI:Select('buy')
    return true
end
function D:TryOpen()
    if self.unavailable then return false end
    local ok,result=pcall(self.Attach,self)
    if not ok then self.unavailable=true;W.RecordFault('desk-attach',result);self:NativeFallback('Desk attachment failed');return false end
    return result
end
function D:Opened()
    self.fallback=false
    if self:TryOpen()then return end
    if C_Timer and C_Timer.After then
        local epoch=W.runtime.ahSession
        for _,delay in ipairs({.2,.8,1.8})do C_Timer.After(delay,function()
            if W.runtime.ahOpen and W.runtime.ahSession==epoch and not D.fallback then D:TryOpen()end
        end)end
    end
end
function D:Pulse()
    if self.active then
        if not W.runtime.ahOpen or not self.native or not self.native:IsShown() or self.native:GetAlpha()~=0 or
            (InCombatLockdown and InCombatLockdown())then self:NativeFallback('Native presentation restored');return end
    end
    W.Browse:CheckTimeout();W.Owned:CheckTimeout()
end
function D:CloseAuction()
    if not W.runtime.ahOpen then self:Release();return end
    self:NativeFallback()
    local ok=W.SafeCall(W.Compat.auction and W.Compat.auction.CloseAuctionHouse)
    if not ok then W.Notify('Close the Auction House using its Blizzard close button.')end
end
function D:Select(section)W.UI:Select(section)end
function D:Refresh()W.UI:Refresh()end
function D:OnEvent(event)
    if event=='BAG_UPDATE_DELAYED' then self.sellItems=nil;W.UI.sellItems=nil
        if W.UI.section=='sell' then W.UI:LoadSellItems()end
    end
    W.Refresh()
end

function D:ClearSelections()
    local u=W.UI;u:RestoreBrowseText();u:EndSellComparison();u.shopSelected=nil;u.offerSelected=nil;u.shopMode='browse';u.offerToken=nil
    u.ownedSelected=nil;u.historySelected=nil;u.watchSelected=nil;u.sellSelected=nil
    if u.historyTable then u.historyResults={};u.historyGeneration=(u.historyGeneration or 0)+1 end
end
