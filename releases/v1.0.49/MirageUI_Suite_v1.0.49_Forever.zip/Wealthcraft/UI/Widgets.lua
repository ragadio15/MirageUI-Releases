-- MirageUI options palette, copied from the supplied MirageUI VisualTokens.lua.
-- All artwork is either the supplied Mirage mark or a native game item icon.
local _,W=...
W.Widgets={}
local F=W.Widgets
F.palette={background={.027,.027,.030,.997},panel={.049,.049,.054,.992},edge={.24,.24,.25,1},
    accent={.91,.55,.18,1},secondary={.96,.79,.36,1},text={.90,.89,.87,1},muted={.63,.62,.60,1},
    hover={.145,.110,.071,.995},raised={.051,.050,.052,.992},selected={.145,.110,.071,.995},danger={.92,.49,.38,1},positive={.39,.82,.58,1}}
local C=F.palette
C.warm=C.secondary;C.surface=C.panel;C.surfaceRaised=C.raised
-- Use Blizzard's native MoneyFrame coin icons, rather than bundled graphics.
-- Keep texture paths and display markup centralized for all UI money surfaces.
F.coinPaths={
    'Interface\\MoneyFrame\\UI-GoldIcon',
    'Interface\\MoneyFrame\\UI-SilverIcon',
    'Interface\\MoneyFrame\\UI-CopperIcon',
}
F.coinMarks={}
for i,path in ipairs(F.coinPaths) do
    F.coinMarks[i]='|T'..path..':14:14:0:0|t'
end
local unpack=unpack or table.unpack
local function fontFile()
    -- The client selects a locale-capable face. A Latin-only forced face can
    -- turn localized item names and player-entered list names into missing glyphs.
    return type(STANDARD_TEXT_FONT)=='string' and STANDARD_TEXT_FONT~='' and STANDARD_TEXT_FONT or 'Fonts\\ARIALN.TTF'
end
local function color(t,c)t:SetColorTexture(unpack(c))end
function F:Box(parent,x,y,w,h,c,border)
    local f=CreateFrame('Frame',nil,parent);f:SetSize(w,h);f:SetPoint('TOPLEFT',parent,'TOPLEFT',x,-y)
    local bg=f:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints(f);color(bg,c or C.panel);f.background=bg
    if border~=false then
        for _,edge in ipairs({'TOP','BOTTOM','LEFT','RIGHT'})do
            self:Rule(f,edge,C.edge,'BORDER')
        end
    end
    return f
end
-- Tie both endpoints to the owning frame so a resized surface never leaves
-- a detached rule or border at its former width.
function F:Rule(parent,edge,tint,layer)
    local t=parent:CreateTexture(nil,layer or 'BORDER')
    if edge=='TOP' or edge=='BOTTOM' then
        t:SetPoint(edge..'LEFT',parent,edge..'LEFT')
        t:SetPoint(edge..'RIGHT',parent,edge..'RIGHT')
        t:SetHeight(1)
    else
        t:SetPoint('TOP'..edge,parent,'TOP'..edge)
        t:SetPoint('BOTTOM'..edge,parent,'BOTTOM'..edge)
        t:SetWidth(1)
    end
    color(t,tint or C.edge)
    return t
end
function F:Panel(parent,w,h)
    local f=self:Box(parent,0,0,w,h,C.background)
    local media='Interface\\AddOns\\Wealthcraft\\Media\\'
    local shine=f:CreateTexture(nil,'BACKGROUND');shine:SetAllPoints(f);shine:SetTexture(media..'PanelShine.tga');shine:SetVertexColor(.82,.53,.29,.17)
    local glass=f:CreateTexture(nil,'BACKGROUND');glass:SetAllPoints(f);glass:SetTexture(media..'PanelGlass.tga');glass:SetVertexColor(.72,.53,.33,.23)
    local rule=self:Rule(f,'TOP',{.91,.55,.18,.70});rule:SetHeight(2)
    return f
end
function F:Text(parent,x,y,w,h,text,size,c,align)
    local t=parent:CreateFontString(nil,'OVERLAY')
    t:SetFont(fontFile(),size or 14,'');t:SetTextColor(unpack(c or C.text))
    t:SetPoint('TOPLEFT',parent,'TOPLEFT',x,-y);t:SetSize(w,h or 24)
    t:SetJustifyH(align or 'LEFT');t:SetJustifyV('TOP');t:SetText(text or '')
    return t
end
function F:Label(parent,text,size,c,width,align)return self:Text(parent,0,0,width or 300,70,text,size,c,align)end
function F:ButtonAt(parent,x,y,w,h,text,fn,primary)
    local b=CreateFrame('Button',nil,parent);b:SetSize(w,h);b:SetPoint('TOPLEFT',parent,'TOPLEFT',x,-y)
    b.background=b:CreateTexture(nil,'BACKGROUND');b.background:SetAllPoints(b)
    b.edges={};for _,side in ipairs({'TOP','BOTTOM','LEFT','RIGHT'})do b.edges[#b.edges+1]=self:Rule(b,side,C.edge)end
    b.gloss=b:CreateTexture(nil,'BORDER');b.gloss:SetAllPoints(b);b.gloss:SetTexture('Interface\\AddOns\\Wealthcraft\\Media\\ButtonGloss.tga')
    b.selectionRule=self:Rule(b,'LEFT',C.accent);b.selectionRule:ClearAllPoints();b.selectionRule:SetPoint('TOPLEFT',b,'TOPLEFT',1,-3);b.selectionRule:SetPoint('BOTTOMLEFT',b,'BOTTOMLEFT',1,3);b.selectionRule:SetWidth(2)
    b.selectionRule:SetShown(primary==true)
    b.selected=primary==true
    b.normalColor=primary and C.selected or C.raised;color(b.background,b.normalColor)
    b.label=self:Text(b,10,0,w-20,h,text,13,C.text,'CENTER')
    b.label:ClearAllPoints()
    b.label:SetPoint('TOPLEFT',b,'TOPLEFT',10,0)
    b.label:SetPoint('BOTTOMRIGHT',b,'BOTTOMRIGHT',-10,0)
    b.label:SetJustifyV('MIDDLE');b.label:SetWordWrap(false)
    b:SetScript('PreClick',function() W.Priority:RecordInteraction() end)
    b:SetScript('OnClick',function(_,button)if fn then W.Try('ui-action',fn,button)end end)
    local function repaint()
        b.paintGeneration=(b.paintGeneration or 0)+1
        if b.painting then return false end
        b.painting=true
        local done=false
        for attempt=1,2 do
            local generation=b.paintGeneration
            local ok,result=pcall(function()
                local enabled=b:IsEnabled()==true;local hovered,selected=b.hovered==true,b.selected==true
                local background,edges,stripe,gloss,label,normal=b.background,b.edges,b.selectionRule,b.gloss,b.label,b.normalColor
                local function stable()
                    return generation==b.paintGeneration and b.background==background and b.edges==edges and b.selectionRule==stripe and
                        b.gloss==gloss and b.label==label and b.normalColor==normal and (b.hovered==true)==hovered and (b.selected==true)==selected
                end
                local function current()
                    if not stable() then return false end
                    local available=b:IsEnabled()==true
                    return stable() and available==enabled
                end
                local active=enabled and (hovered or selected)
                if current() then color(background,enabled and (hovered and C.hover or normal) or C.raised) end
                for i,edge in ipairs(edges)do if current() and edges[i]==edge then color(edge,active and C.accent or C.edge) end end
                if current() then stripe:SetShown(active) end
                if current() then gloss:SetVertexColor(.96,.79,.36,enabled and (hovered and .58 or selected and .45 or .22) or .1) end
                if current() then label:SetTextColor(unpack(enabled and C.text or C.muted)) end
                return current()
            end)
            if ok and result then done=true;break end
            if not ok and b.paintGeneration==generation then break end
        end
        b.painting=nil
        return done
    end
    b:SetScript('OnEnter',function()b.hovered=true;repaint()end)
    b:SetScript('OnLeave',function()b.hovered=false;repaint()end)
    b:SetScript('OnHide',function()
        local generation=b.paintGeneration
        local ok,visible=pcall(b.IsVisible or b.IsShown,b)
        if not ok or generation~=b.paintGeneration or visible~=false then return end
        b.hovered=false;repaint()
    end)
    b:SetScript('OnEnable',repaint);b:SetScript('OnDisable',repaint)
    function b:ApplyAvailability(yes)
        self:SetEnabled(yes==true);self:SetAlpha(yes==true and 1 or .43);repaint()
    end
    function b:Select(yes)
        self.selected=yes==true
        self.normalColor=yes and C.selected or C.raised
        self.selectionRule:SetShown(yes==true)
        self.label:SetTextColor(unpack(C.text));repaint()
    end
    b:ApplyAvailability(true);return b
end
function F:Button(parent,text,w,h,fn,primary)return self:ButtonAt(parent,0,0,w,h,text,fn,primary)end
function F:Edit(parent,x,y,w,h,text,enter)
    local b=CreateFrame('EditBox',nil,parent);b:SetSize(w,h);b:SetPoint('TOPLEFT',parent,'TOPLEFT',x,-y)
    local t=b:CreateTexture(nil,'BACKGROUND');t:SetAllPoints(b);color(t,{.028,.028,.030,.95})
    for _,side in ipairs({'TOP','BOTTOM','LEFT','RIGHT'})do self:Rule(b,side,C.edge)end
    b.focusRule=self:Rule(b,'BOTTOM',C.edge)
    b:SetScript('OnMouseDown',function() W.Priority:RecordInteraction() end)
    b:SetScript('OnEditFocusGained',function()color(b.focusRule,C.accent)end)
    b:SetScript('OnEditFocusLost',function()color(b.focusRule,C.edge)end)
    b:SetScript('OnHide',function(f)f:ClearFocus();color(b.focusRule,C.edge)end)
    b:SetFont(fontFile(),15,'');b:SetTextColor(unpack(C.text));b:SetAutoFocus(false)
    b:SetTextInsets(12,12,4,4);b:SetMaxLetters(600);b:SetText(text or '')
    b:SetScript('OnEscapePressed',function(f)f:ClearFocus()end)
    b:SetScript('OnEnterPressed',function(f)W.Priority:RecordInteraction();f:ClearFocus();if enter then W.Try('input-enter',enter)end end)
    b:SetScript('OnTextChanged',function(_,user)if user then W.Priority:RecordInteraction();W.UI.dirty=true end end)
    return b
end
function F:Input(parent,w,h,text,enter)return self:Edit(parent,0,0,w,h,text,enter)end
function F:TooltipSide(owner)
    if not owner or not UIParent or type(UIParent.GetWidth)~='function' or
        type(owner.GetRight)~='function' then return 'ANCHOR_RIGHT' end
    local ok,width=pcall(UIParent.GetWidth,UIParent)
    local rightOK,right=pcall(owner.GetRight,owner)
    local ownerOK,ownerScale=false,nil
    if type(owner.GetEffectiveScale)=='function' then ownerOK,ownerScale=pcall(owner.GetEffectiveScale,owner) end
    local parentOK,parentScale=false,nil
    if type(UIParent.GetEffectiveScale)=='function' then parentOK,parentScale=pcall(UIParent.GetEffectiveScale,UIParent) end
    if ok and rightOK and ownerOK and parentOK and type(right)=='number' and type(width)=='number' and
        type(ownerScale)=='number' and type(parentScale)=='number' and
        ownerScale>0 and parentScale>0 and width>0 then
        local physicalX=right*ownerScale/parentScale
        return physicalX>width*.62 and 'ANCHOR_LEFT' or 'ANCHOR_RIGHT'
    end
    return 'ANCHOR_RIGHT'
end
local function hideItemTooltip(owner)
    local tip=GameTooltip
    if not tip then return end
    local ok,owned
    if type(tip.IsOwned)=='function' then ok,owned=W.SafeCall(tip.IsOwned,tip,owner)
    elseif type(tip.GetOwner)=='function' then
        local value;ok,value=W.SafeCall(tip.GetOwner,tip);owned=value==owner
    end
    if ok and owned==true then W.SafeCall(tip.Hide,tip) end
end
function F:Icon(parent,x,y,size)
    local f=CreateFrame('Frame',nil,parent);f:SetSize(size,size);f:SetPoint('TOPLEFT',parent,'TOPLEFT',x,-y)
    local t=f:CreateTexture(nil,'ARTWORK');t:SetAllPoints(f);t:SetTexture('Interface\\Icons\\INV_Misc_QuestionMark')
    f.texture=t;f:EnableMouse(true)
    f:SetScript('OnEnter',function()
        if f.itemID and GameTooltip and type(GameTooltip.SetOwner)=='function' then
            GameTooltip:SetOwner(f,F:TooltipSide(f))
            if type(GameTooltip.SetClampedToScreen)=='function' then
                W.SafeCall(GameTooltip.SetClampedToScreen,GameTooltip,true)
            end
            W.SafeCall(GameTooltip.SetHyperlink,GameTooltip,f.itemLink or ('item:'..f.itemID))
            if GameTooltip.Show then GameTooltip:Show()end
        end
    end)
    f:SetScript('OnLeave',hideItemTooltip)
    f:SetScript('OnHide',hideItemTooltip)
    function f:SetItem(id,link,icon)
        if self.itemID~=id or self.itemLink~=link then hideItemTooltip(self) end
        self.itemID=id;self.itemLink=link
        if not icon and id then
            if C_Item and C_Item.GetItemIconByID then local ok,v=W.SafeCall(C_Item.GetItemIconByID,id);if ok then icon=v end end
            if not icon and type(GetItemInfoInstant)=='function' then local ok,_,_,_,_,v=pcall(GetItemInfoInstant,id);if ok then icon=v end end
        end
        self.texture:SetTexture(icon or 'Interface\\Icons\\INV_Misc_QuestionMark')
    end
    return f
end
function F:Table(parent,x,y,w,columns,count,rowHeight,onSelect,pressIdentity)
    count=count or 9;rowHeight=rowHeight or 45
    local f=self:Box(parent,x,y,w,34+count*rowHeight+2,C.panel)
    f.columns=columns;f.rows={};f.count=count;f.maxCount=count;f.rowHeight=rowHeight
    f.originX=x;f.originY=y;f.page=0;f.data={};f.onSelect=onSelect
    local headerRule=f:CreateTexture(nil,'BORDER')
    headerRule:SetPoint('TOPLEFT',f,'TOPLEFT',12,-32)
    headerRule:SetPoint('TOPRIGHT',f,'TOPRIGHT',-12,-32)
    headerRule:SetHeight(1);color(headerRule,C.edge)
    local off=12
    f.headers={}
    for _,c in ipairs(columns)do
        f.headers[#f.headers+1]=self:Text(f,off,10,c.width-12,20,c.title,12,C.muted,c.align)
        off=off+c.width
    end
    for i=1,count do
        local row=self:ButtonAt(f,6,34+(i-1)*rowHeight,w-12,rowHeight-3,'',function()
            local button=f.rows[i];local r=button.record
            local press=button.rowPress;button.rowPress=nil
            if pressIdentity and (press==false or (press and
                (press.identity~=pressIdentity(r) or press.page~=(f.page or 0))))then return end
            if r and W.ItemSearch and W.ItemSearch:Populate(r.itemLink or (r.itemID and ('item:'..r.itemID))) then return end
            if r and f.onSelect then f.onSelect(r,(f.page or 0)*f.count+i)end
        end)
        if pressIdentity then
            row:SetScript('OnMouseDown',function(button)
                button.rowPress=button.record and {identity=pressIdentity(button.record),page=f.page or 0} or false
            end)
            local hide=row:GetScript('OnHide')
            row:SetScript('OnHide',function(button)
                if button.rowPress~=nil then button.rowPress=false end
                if hide then hide(button)end
            end)
        end
        row.label:Hide();row.cells={};local px=6
        for j,c in ipairs(columns)do
            if c.item then
                row.icon=self:Icon(row,px,5,rowHeight-12)
                row.name=self:Text(row,px+rowHeight-4,5,c.width-rowHeight-8,23,'',15,C.text)
                row.sub=self:Text(row,px+rowHeight-4,25,c.width-rowHeight-8,16,'',11,C.muted)
                row.name:SetWordWrap(false);row.sub:SetWordWrap(false)
            else
                row.cells[j]=self:Text(row,px,12,c.width-14,26,'',14,C.text,c.align)
                row.cells[j]:SetWordWrap(false)
            end
            px=px+c.width
        end
        row:Hide();f.rows[i]=row
    end
    f.empty=self:Text(f,24,0,w-48,94,'',16,C.muted,'CENTER')
    f.empty:SetJustifyV('MIDDLE')
    -- The empty state is a compact card, not a giant desaturated paragraph.
    -- Its anchors stay inside the table at any configured row count.
    f.empty:SetWordWrap(true)
    function f:SetData(data,formatter,selected,empty)
        self.data=data or {};self.formatter=formatter;self.selected=selected;self.emptyMessage=empty
        local max=math.max(0,math.ceil(#self.data/self.count)-1);self.page=math.min(self.page or 0,max)
        for i,row in ipairs(self.rows)do
            local r=i<=self.count and self.data[self.page*self.count+i] or nil
            if pressIdentity and row.rowPress and (row.rowPress.identity~=pressIdentity(r) or row.rowPress.page~=self.page)then
                row.rowPress=false
            end
            row.record=r
            if r then
                local cells,sub=formatter(r,self.page*self.count+i)
                if row.icon then
                    row.icon:SetItem(r.itemID or (r.itemKey and r.itemKey.itemID),r.itemLink,r.icon)
                    row.name:SetText(cells[1] or r.name or 'Item')
                    row.sub:SetText(sub or '')
                end
                for j,t in pairs(row.cells)do t:SetText(cells[j] or '—')end
                row:Select(selected==r or (type(selected)=='function' and selected(r)));row:Show()
            else row:Hide()end
        end
        self.empty:SetText(#self.data==0 and (empty or 'Nothing here yet.') or '')
        self.empty:ClearAllPoints()
        self.empty:SetPoint('CENTER',self,'CENTER',0,-6)
        self.empty:SetTextColor(unpack(C.muted))
        if self.pageText then self.pageText:SetText(#self.data==0 and '' or
            #self.data<=self.count and (tostring(#self.data)..(#self.data==1 and ' item' or ' items')) or
            string.format('%d–%d of %d',self.page*self.count+1,math.min((self.page+1)*self.count,#self.data),#self.data))end
        if self.prev then
            local paged=#self.data>self.count
            self.prev:SetShown(paged);self.next:SetShown(paged)
            self.prev:ApplyAvailability(self.page>0);self.next:ApplyAvailability(self.page<max)
        end
    end
    function f:Move(delta)
        self.page=math.max(0,self.page+delta)
        self:SetData(self.data,self.formatter,self.selected,self.emptyMessage)
    end
    local by=y+34+count*rowHeight+12
    f.prev=self:ButtonAt(parent,x,by,42,30,'‹',function()f:Move(-1)end)
    f.next=self:ButtonAt(parent,x+48,by,42,30,'›',function()f:Move(1)end)
    f.pageText=self:Text(parent,x+104,by+5,w-114,24,'',12,C.muted)
    -- Compact mode reflows pagination and visible rows; it must not simply
    -- shrink a desktop table or cut its bottom buttons with the viewport.
    function f:ConfigureRows(requested)
        local visible=math.max(1,math.min(self.maxCount,math.floor(requested or self.maxCount)))
        if visible==self.count then return false end
        local first=(self.page or 0)*self.count
        self.count=visible;self.page=math.floor(first/visible)
        self:SetHeight(34+visible*self.rowHeight+2)
        local controlsY=self.originY+34+visible*self.rowHeight+12
        for i,button in ipairs({self.prev,self.next})do
            button:ClearAllPoints()
            button:SetPoint('TOPLEFT',parent,'TOPLEFT',self.originX+(i-1)*48,-controlsY)
        end
        self.pageText:ClearAllPoints()
        self.pageText:SetPoint('TOPLEFT',parent,'TOPLEFT',self.originX+104,-(controlsY+5))
        if self.formatter then self:SetData(self.data,self.formatter,self.selected,self.emptyMessage)end
        return true
    end
    return f
end
function F:EmptyItemDetails(parent,x,y,width,height,hint)
    local card=self:Box(parent,x,y,width,height,C.panel)
    self:Text(card,18,5,width-36,20,'ITEM DETAILS',11,C.secondary)
    local rule=card:CreateTexture(nil,'BORDER')
    rule:SetPoint('TOPLEFT',card,'TOPLEFT',18,-30)
    rule:SetPoint('TOPRIGHT',card,'TOPRIGHT',-18,-30)
    rule:SetHeight(1);color(rule,C.edge)
    local prompt=self:Text(card,0,0,width-48,72,hint,15,C.muted,'CENTER')
    prompt:ClearAllPoints();prompt:SetPoint('CENTER',card,'CENTER',0,-15)
    prompt:SetJustifyV('MIDDLE');prompt:SetWordWrap(true)
    return card
end
function F:Card(parent,x,y,w,label,value,detail)
    local p=self:Box(parent,x,y,w,124)
    p.label=self:Text(p,18,16,w-36,22,label,13,C.muted)
    p.value=self:Text(p,18,45,w-36,35,value,23,C.secondary)
    p.detail=self:Text(p,18,88,w-36,34,detail,12,C.muted)
    p.detail:SetWordWrap(true)
    return p
end
-- A small native-frame choice menu; no cycling through hidden options.
function F:Choose(anchor,choices,onPick)
    local m=W.UI.choiceMenu
    if #choices==0 then
        if m then m:Hide()end
        return nil
    end
    if not m then
        m=self:Box(W.UI.frame,0,0,238,12,C.panel)
        m:SetFrameLevel(170);m:EnableMouse(true);m:SetClampedToScreen(true);m.rows={}
        m:SetScript('OnHide',function()m.onPick=nil;m.anchor=nil end)
        W.UI.choiceMenu=m
    else
        local toggling=m:IsShown() and m.anchor==anchor
        m:Hide()
        if toggling then return nil end
    end
    m:SetHeight(#choices*32+12);m:ClearAllPoints()
    local below=true
    if anchor and type(anchor.GetBottom)=='function' and UIParent and
        type(UIParent.GetEffectiveScale)=='function' then
        local ok,bottom=pcall(anchor.GetBottom,anchor)
        local parentScale=UIParent:GetEffectiveScale() or 1
        local childScale=type(anchor.GetEffectiveScale)=='function' and anchor:GetEffectiveScale() or parentScale
        local menuScale=type(m.GetEffectiveScale)=='function' and m:GetEffectiveScale() or parentScale
        if ok and type(bottom)=='number' and type(childScale)=='number' and type(menuScale)=='number' and
            parentScale>0 and childScale>0 and menuScale>0 then
            -- Region coordinates are measured in their own scaled units.
            local spaceBelow=bottom*childScale/parentScale
            local needed=(#choices*32+12)*menuScale/parentScale+8
            below=spaceBelow>=needed
        end
    end
    if below then m:SetPoint('TOPLEFT',anchor,'BOTTOMLEFT',0,-4)
    else m:SetPoint('BOTTOMLEFT',anchor,'TOPLEFT',0,4)end
    m.onPick=onPick;m.anchor=anchor
    for i,choice in ipairs(choices)do
        local b=m.rows[i]
        if not b then
            b=self:ButtonAt(m,6,6+(i-1)*32,226,30,'',nil)
            b:SetScript('OnClick',function(button)
                local pick,id=m.onPick,button.choiceID
                m:Hide()
                if pick then W.Try('ui-action',pick,id)end
            end)
            m.rows[i]=b
        end
        b.choiceID=choice[1];b.label:SetText(choice[2]);b:Show()
    end
    for i=#choices+1,#m.rows do m.rows[i].choiceID=nil;m.rows[i]:Hide()end
    m:Show()
    return m
end

-- P39-B: shared high-resolution action icons.  Labels remain available as
-- focus/hover help and to accessibility consumers; consequential trade actions
-- remain ordinary labeled buttons.
function F:IconAction(parent,x,y,sz,asset,help,fn)
    local b=self:ButtonAt(parent,x,y,sz,sz,'',fn)
    b.label:Hide()
    local art=b:CreateTexture(nil,'OVERLAY')
    art:SetSize(sz-8,sz-8)
    art:SetPoint('CENTER',b,'CENTER',0,0)
    b.symbol=art
    function b:SetIcon(key)
        if self.iconKey==key then return end
        self.iconKey=key
        art:SetTexture('Interface\\AddOns\\Wealthcraft\\Media\\UIActions\\'..key..'.tga')
    end
    b:SetIcon(asset)
    b.helpLabel=help
    local enter=b:GetScript('OnEnter')
    local leave=b:GetScript('OnLeave')
    b:SetScript('OnEnter',function(button)
        if enter then enter(button)end
        if GameTooltip and GameTooltip.SetOwner then
            local side=F:TooltipSide(button)
            GameTooltip:SetOwner(button,side)
            GameTooltip:SetText(button.helpLabel or '')
            if GameTooltip.SetClampedToScreen then GameTooltip:SetClampedToScreen(true)end
            GameTooltip:Show()
        end
    end)
    b:SetScript('OnLeave',function(button)
        if leave then leave(button)end
        local tip=GameTooltip
        if tip and tip.GetOwner and tip.Hide then
            local ok,owner=pcall(tip.GetOwner,tip)
            if ok and owner==button then tip:Hide()end
        end
    end)
    b:SetScript('OnHide',function(button)
        local tip=GameTooltip
        if tip and tip.GetOwner and tip.Hide then
            local ok,owner=pcall(tip.GetOwner,tip)
            if ok and owner==button then tip:Hide()end
        end
        button.hovered=false
    end)
    b:SetScript('OnDisable',function(button)
        art:SetAlpha(.40)
    end)
    b:SetScript('OnEnable',function(button)
        art:SetAlpha(1)
    end)
    return b
end
-- P39-B: two-stage filter menu. Both hover and click reveal the second level;
-- neither applies a filter until the player selects a definite value. All
-- menus clamp to the screen (including the Surface Pro's 1152x768 viewport).
function F:ChooseNested(anchor,groups,onPick,isSelected)
    local ui=W.UI
    if ui.choiceMenu then ui.choiceMenu:Hide()end
    if ui.nestedMenu then ui.nestedMenu:Hide();ui.nestedMenu=nil;return end
    local menu=ui.nestedMenuCache
    if not menu then
        menu=self:Box(ui.frame,0,0,222,12,C.panel)
        menu:SetFrameLevel(180);menu:SetClampedToScreen(true);menu:EnableMouse(true)
        ui.nestedMenuCache=menu
        menu.submenu=self:Box(menu,0,0,232,12,C.panel)
        menu.submenu:SetFrameLevel(menu:GetFrameLevel()+2)
        menu.submenu:SetClampedToScreen(true)
        menu.submenu:EnableMouse(true)
        menu.topButtons={}
    end
    menu:ClearAllPoints()
    menu:SetPoint('TOPLEFT',anchor,'BOTTOMLEFT',0,-5)
    menu:SetHeight(#groups*36+12)
    ui.nestedMenu=menu
    local sub=menu.submenu
    sub:Hide()
    local function dismiss()
        if ui.nestedMenu==menu then ui.nestedMenu=nil end
        sub:Hide();menu:Hide()
    end
    menu.Dismiss=dismiss
    local function showSub(group,anchorRow)
        if ui.nestedMenu~=menu then return end
        sub:Hide();sub:SetHeight(#group.options*33+12)
        sub:ClearAllPoints()
        local available=(UIParent and type(UIParent.GetWidth)=='function' and UIParent:GetWidth() or 1600)
        local right=type(menu.GetRight)=='function' and menu:GetRight() or 0
        if right and right+244>available then sub:SetPoint('TOPRIGHT',menu,'TOPLEFT',-5,-6)
        else sub:SetPoint('TOPLEFT',menu,'TOPRIGHT',5,-6)end
        if menu.subButtons then for _,button in ipairs(menu.subButtons)do button:Hide()end end
        menu.subButtons=menu.subButtons or {}
        for i,choice in ipairs(group.options)do
            local button=menu.subButtons[i]
            if not button then button=F:ButtonAt(sub,5,6+(i-1)*33,222,31,'',nil);menu.subButtons[i]=button end
            button.label:SetText(choice[2])
            button:Select(isSelected and isSelected(group.id,choice[1])==true or false)
            button:SetScript('OnClick',function()
                local value=choice[1];local kind=group.id
                dismiss();if onPick then W.Try('ui-filter-select',onPick,kind,value)end
            end)
            button:Show()
        end
        sub:Show()
    end
    for i,group in ipairs(groups)do
        local b=menu.topButtons[i]
        if not b then
            b=self:ButtonAt(menu,6,6+(i-1)*36,210,33,'',nil)
            menu.topButtons[i]=b
            local old=b:GetScript('OnEnter')
            b:SetScript('OnEnter',function(f)
                if old then old(f)end
                if f.group then showSub(f.group)end
            end)
        end
        b.group=group;b.label:SetText(group.title..'  ›')
        b:SetScript('OnClick',function()showSub(group)end)
        b:Show()
    end
    for i=#groups+1,#menu.topButtons do menu.topButtons[i]:Hide()end
    -- A visible click-based close route complements outside navigation.
    menu:SetScript('OnHide',function()
        sub:Hide()
        if ui.nestedMenu==menu then ui.nestedMenu=nil end
    end)
    return menu
end
