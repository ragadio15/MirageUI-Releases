local _,W=...
local U,F,C=W.UI,W.Widgets,W.Widgets.palette
-- Optional item research opens only the selected item in Insight. It never
-- starts an auction query, changes the market, or prepares a transaction.
function U:ResearchTarget(row)
    if type(row)~='table' then return nil,'Select an item first.' end
    local key=type(row.itemKey)=='table' and row.itemKey or {}
    local id=row.itemID or key.itemID
    if not W.Math.ValidInteger(id,1,999999999) or (key.itemID and key.itemID~=id) then
        return nil,'This item is not readable yet.'
    end
    local link=row.itemLink
    if link~=nil and link~='' then
        local bridge=W.ItemLinkBridge
        local ok,identity,linkID=W.SafeCall(bridge and bridge.Normalize,bridge,link)
        if not ok or not identity or linkID~=id or (key.battlePetSpeciesID or 0)~=0 or
            (row.identity and row.identity~='commodity:'..id and row.identity~=identity) or
            (key.itemSuffix~=nil and tonumber(identity:match(';s=([%-]?%d+);'))~=key.itemSuffix) then
            return nil,'Select an offer with a complete matching item link.'
        end
        return link
    end
    if (row.identity and not row.itemKey) or (key.itemSuffix or 0)~=0 or
        (key.battlePetSpeciesID or 0)~=0 or (key.itemLevel or 0)~=0 then
        return nil,'Select an offer with a complete item link to research this variant.'
    end
    return id
end
function U:ResearchHint(button,resolve)
    local enter,leave=button:GetScript('OnEnter'),button:GetScript('OnLeave')
    button:SetScript('OnEnter',function(b)
        if enter then enter(b)end
        local tip=GameTooltip
        if not tip or type(tip.SetOwner)~='function' or type(tip.AddLine)~='function' then return end
        local ready,why=U:CanResearch(resolve())
        tip:SetOwner(b,F:TooltipSide(b))
        if type(tip.SetClampedToScreen)=='function' then W.SafeCall(tip.SetClampedToScreen,tip,true)end
        tip:AddLine('Item research',.96,.79,.36)
        tip:AddLine(ready and 'Open recipes, recorded sources and item details in Insight.' or why,.9,.89,.87,true)
        if tip.Show then tip:Show()end
    end)
    local function clear(b)
        if leave then leave(b)end
        if GameTooltip and type(GameTooltip.IsOwned)=='function' and GameTooltip:IsOwned(b) and
            type(GameTooltip.Hide)=='function' then GameTooltip:Hide()end
    end
    button:SetScript('OnLeave',clear)
    local hide=button:GetScript('OnHide')
    button:SetScript('OnHide',function(b)if hide then hide(b)end;clear(b)end)
end
function U:CanResearch(row)
    local target,why=self:ResearchTarget(row)
    if not target then return false,why end
    local provider=MirageInsightAPI
    if type(provider)~='table' or provider.apiVersion~=1 or type(provider.OpenItem)~='function' then
        return false,'Enable Insight to research this item.'
    end
    if not W.runtime.initialized or not W.Compat.build or not (W.Compat.build.runtimeAllowed or W.Compat.build.exactTarget) or
        not W.Storage:IsWritable() then return false,'Research is unavailable while this profile is read only.' end
    local checked,locked=W.SafeCall(InCombatLockdown)
    if not checked or (locked~=false and locked~=nil) then return false,'Open item research after combat.' end
    return true,target,provider
end
function U:OpenItemResearch(row)
    -- Capture context before validation: even a read-only provider may invoke
    -- a callback that changes the selection, profile, or public API instance.
    local storage=W.Storage
    local account,character=storage and storage.account,storage and storage.character
    local providerAtStart=MirageInsightAPI
    local openAtStart=type(providerAtStart)=='table' and providerAtStart.OpenItem
    local section,activePage=self.section,self.activePage
    local watch,history,shop,offer=self.watchSelected,self.historySelected,self.shopSelected,self.offerSelected
    local key=type(row)=='table' and row.itemKey
    local proof={}
    if type(row)=='table' then
        for _,name in ipairs({'itemID','itemLink','identity'})do proof[name]=row[name]end
        if type(key)=='table' then
            for _,name in ipairs({'itemID','itemSuffix','itemLevel','battlePetSpeciesID'})do proof['key.'..name]=key[name]end
        end
    end
    local function unchanged()
        if W.Storage~=storage or not storage or storage.account~=account or storage.character~=character or
            MirageInsightAPI~=providerAtStart or type(providerAtStart)~='table' or providerAtStart.OpenItem~=openAtStart or
            self.section~=section or self.activePage~=activePage or self.watchSelected~=watch or
            self.historySelected~=history or self.shopSelected~=shop or self.offerSelected~=offer then return false end
        if type(row)~='table' or row.itemKey~=key then return false end
        for _,name in ipairs({'itemID','itemLink','identity'})do if row[name]~=proof[name]then return false end end
        if type(key)=='table' then
            for _,name in ipairs({'itemID','itemSuffix','itemLevel','battlePetSpeciesID'})do
                if key[name]~=proof['key.'..name]then return false end
            end
        end
        return true
    end
    local allowed,target,provider=self:CanResearch(row)
    if not allowed then self:Message(target);return false,target end
    if not unchanged() then self:Message('The item context changed. Select it again.');return false,'CONTEXT_CHANGED'end
    local current,value,active=self:CanResearch(row)
    if not current or value~=target or active~=provider or not unchanged() then
        self:Message('The item context changed. Select it again.');return false,'CONTEXT_CHANGED'
    end
    -- Dismiss only WealthCraft's own hover help before opening an Insight panel.
    -- Unrelated or Blizzard-owned tooltip layers remain untouched.
    if GameTooltip and type(GameTooltip.GetOwner)=='function' then
        local ownerOK,owner=W.SafeCall(GameTooltip.GetOwner,GameTooltip)
        if ownerOK and (owner==self.shopResearch or owner==self.watchResearch or owner==self.sellIcon or
            owner==self.shopIcon) and type(GameTooltip.Hide)=='function' then
            W.SafeCall(GameTooltip.Hide,GameTooltip)
        end
    end
    local called,opened=W.SafeCall(provider.OpenItem,target,{userInitiated=true})
    if not called or opened~=true then
        self:Message('Insight could not open this item. Check that it is ready, then try again.')
        return false,'INSIGHT_UNAVAILABLE'
    end
    self:Message('Opened item research in Insight.')
    return true,'ITEM_OPENED'
end
local function keyFromIdentity(identity,id)
    if type(identity)~='string' then return nil end
    local commodity=identity:match('^commodity:(%d+)$')
    if commodity then return {itemID=tonumber(commodity),itemLevel=0,itemSuffix=0,battlePetSpeciesID=0}end
    local a,s=identity:match('^id=(%d+);e=0;g=0,0,0,0;s=([%-]?%d+);b=$')
    if a then return {itemID=tonumber(a),itemLevel=0,itemSuffix=tonumber(s),battlePetSpeciesID=0}end
    return nil
end
function U:CreateResearch()
    local p=self:Page('watchlist','Favorites','')
    self.watchInput=F:Edit(p,0,50,490,38,'',function()U:AddFavorite()end)
    F:ButtonAt(p,500,50,160,38,'Add favorite',function()U:AddFavorite()end,true)
    self.watchInspect=F:ButtonAt(p,670,50,154,38,'See live offers',function()if U.watchSelected then U:InspectItem(U.watchSelected)end end)
    self.watchRemove=F:ButtonAt(p,834,50,156,38,'Remove',function()
        if not U.watchSelected then return end
        local key=U.watchSelected.watchKey
        local ok,why
        if U.watchListID then ok,why=W.Storage:SetWatchListItem(U.watchListID,key,false)
        else ok,why=W.Storage:RemoveWatch(key)end
        if ok then U.watchSelected=nil end
        U:Result(ok,why)
    end)
    self.watchListPicker=F:ButtonAt(p,0,98,202,34,'All favorites',function()
        local choices={{0,'All favorites'}}
        for _,list in ipairs(W.Storage:WatchLists())do choices[#choices+1]={list.id,list.name}end
        F:Choose(U.watchListPicker,choices,function(id)
            U.watchListID=id~=0 and id or nil
            U.watchListName:SetText('');U.watchSelected=nil;U.watchTable.page=0;U:Refresh()
        end)
    end)
    self.watchListName=F:Edit(p,212,98,222,34,'',function()U:SaveFavoriteList()end)
    self.watchListName:SetMaxLetters(32)
    self.watchListSave=F:ButtonAt(p,444,98,112,34,'New list',function()U:SaveFavoriteList()end)
    self.watchListAssign=F:ButtonAt(p,566,98,188,34,'Add selected to…',function()
        if not U.watchSelected then return end
        local choices={}
        for _,list in ipairs(W.Storage:WatchLists())do
            if list.id~=U.watchListID then choices[#choices+1]={list.id,list.name}end
        end
        if #choices==0 then return end
        local key=U.watchSelected.watchKey
        F:Choose(U.watchListAssign,choices,function(id)
            local ok,why=W.Storage:SetWatchListItem(id,key,true)
            if ok then U:Message('Added to list.')end
            U:Result(ok,why)
        end)
    end)
    self.watchListDelete=F:ButtonAt(p,764,98,226,34,'Delete list (keep items)',function()
        local ok,why=W.Storage:DeleteWatchList(U.watchListID)
        if ok then
            U.watchListID=nil;U.watchSelected=nil;U.watchTable.page=0
            U.watchListName:SetText('');U:Message('List deleted. Its items are still in All favorites.')
        end
        U:Result(ok,why)
    end)
    self.watchListHelp=F:Text(p,0,140,990,24,'',13,C.muted)
    self.watchTable=F:Table(p,0,166,990,{
        {title='ITEM',width=380,item=true},{title='MARKET REF. / UNIT',width=160,align='RIGHT'},
        {title='FRESHNESS',width=185},{title='PRICE CHECK',width=239},
    },8,43,function(r)U.watchSelected=r;U:Refresh()end)
    self.watchTable.pageText:SetWidth(650)
    self.watchResearch=F:ButtonAt(p,816,556,174,30,'Research item',function()U:OpenItemResearch(U.watchSelected)end)
    self:ResearchHint(self.watchResearch,function()return U.watchSelected end)
    p=self:Page('inventory','Insights · Bag breakdown','Carried items only; recorded asking prices are not guaranteed proceeds.')
    self.inventoryValue=F:Text(p,0,50,450,34,'',24,C.secondary)
    self.inventoryCoverage=F:Text(p,0,90,650,35,'',14,C.muted)
    F:ButtonAt(p,614,50,190,38,'Back to Insights',function()U:Select('overview')end)
    self.inventoryRefresh=F:ButtonAt(p,816,50,174,38,'Refresh bags',function()
        W.Inventory:MarkDirty();W.Inventory:Refresh();U:Message('Checking the carried-item price breakdown.');U:Refresh()
    end)
    self.inventoryTable=F:Table(p,0,130,990,{
        {title='ITEM',width=372,item=true},{title='UNITS',width=80,align='RIGHT'},
        {title='MARKET REF. / UNIT',width=165,align='RIGHT'},{title='VALUE',width=160,align='RIGHT'},
        {title='PRICE QUALITY',width=187},
    },8,43,function(r)U:InspectItem(r)end)
    p=self:Page('overview','Insights','')
    -- The summary is the only top-level Insights page. Details and reports
    -- are drill-ins that return here; none of the saved data is discarded.
    self.insightInventory=F:ButtonAt(p,0,302,232,38,'Bag breakdown',function()U:Select('inventory')end)
    self.insightPrices=F:ButtonAt(p,246,302,232,38,'Recorded prices',function()U:Select('market')end)
    self.insightFavorites=F:ButtonAt(p,492,302,232,38,'Favorites',function()U:Select('watchlist')end)
    self.insightReports=F:ButtonAt(p,738,302,252,38,'Reports',function()U:Select('reports')end)
    self.insightJournal=F:ButtonAt(p,738,352,252,34,'Manual Journal',function()U:Select('ledger')end)
    self.insightJournal:Hide()
    self.insightMarket=F:Card(p,0,50,316,'FULL SCAN','No full scan','Visit an auctioneer to refresh market prices')
    self.insightBags=F:Card(p,337,50,316,'PRICED BAG SUBTOTAL','Not priced','Refresh bags to estimate carried inventory')
    self.insightWatch=F:Card(p,674,50,316,'FAVORITES','0 items','Your highest-priority quick refresh items')
    self.scanProgress=F:Box(p,0,190,990,86,C.panel)
    self.scanTitle=F:Text(self.scanProgress,18,15,800,25,'',17,C.text)
    self.scanDetail=F:Text(self.scanProgress,18,49,790,22,'',13,C.muted)
    self.scanCancel=F:ButtonAt(self.scanProgress,838,24,132,36,'Stop scan',function()W.Scan:Cancel();U:Refresh()end)
    self.scanBar=self.scanProgress:CreateTexture(nil,'OVERLAY');self.scanBar:SetPoint('BOTTOMLEFT',self.scanProgress,'BOTTOMLEFT',1,1)
    self.scanBar:SetHeight(2);self.scanBar:SetColorTexture(unpack(C.accent))
    p=self:Page('market','Recorded prices','')
    self.historyInput=F:Edit(p,0,50,544,38,'',function()U:FindHistory()end)
    F:ButtonAt(p,556,50,150,38,'Find item',function()U:FindHistory()end,true)
    -- Use the same exact-item star state in Recorded Prices and Shop.
    self.historyWatch=F:IconAction(p,734,50,38,'FavoriteOutline','Save favorite',function()
        local r=U:HistorySelection()
        if r then U:ToggleFavoriteFor(r)end
    end)
    self.historyLive=F:ButtonAt(p,860,50,130,38,'Live offers',function()
        local r=U:HistorySelection()
        if r and r.itemKey then U:InspectItem(r)end
    end)
    self.historyTable=F:Table(p,0,100,990,{
        {title='ITEM',width=370,item=true},{title='MARKET REF. / UNIT',width=165,align='RIGHT'},
        {title='LOWEST',width=150,align='RIGHT'},{title='LISTINGS',width=110,align='RIGHT'},{title='UPDATED',width=169},
    },7,43,function(r)
        if U:IsHistoryCurrent() and U.historyMembers and U.historyMembers[r] then U.historySelected=r;U:Refresh()end
    end,function(r)return r end)
    local details=F:Box(p,0,484,990,72,C.panel)
    self.historyDetails=F:Text(details,18,15,764,50,'',14,C.muted)
    self.historyResearch=F:ButtonAt(details,798,21,174,30,'Research item',function()
        local r=U:HistorySelection();if r then U:OpenItemResearch(r)end
    end)
    self:ResearchHint(self.historyResearch,function()return U:HistorySelection()end)
end
function U:AddFavorite()
    local key,why=W.Targeted:Resolve(self.watchInput:GetText())
    if not key then self:Message(why);return end
    local observed=W.ItemKinds:ObserveKey(key)
    local ok,err=W.Storage:AddWatch(observed)
    if self.watchListID and (ok or err=='ALREADY_WATCHED') then
        local requestKey=ok and err or W.Storage:WatchKey(W.ItemKinds:Key(observed))
        ok,err=W.Storage:SetWatchListItem(self.watchListID,requestKey,true)
    end
    if ok then self.watchInput:SetText('');self:Message(self.watchListID and 'Saved to list.' or 'Saved to Favorites.')end
    self:Result(ok,err)
end
function U:SaveFavoriteList()
    local ok,id=W.Storage:SaveWatchList(self.watchListName:GetText(),self.watchListID)
    if ok then
        self.watchListID=id;self.watchListName:SetText('');self.watchSelected=nil;self.watchTable.page=0
        self:Message('List saved.')
    end
    return self:Result(ok,id)
end
function U:Refresh_watchlist()
    local lists,available=W.Storage:WatchLists()
    local active
    for _,list in ipairs(lists)do if list.id==self.watchListID then active=list;break end end
    if self.watchListID and not active then self.watchListID=nil;self.watchSelected=nil end
    local writable=W.Storage:IsWritable()
    self.watchListPicker.label:SetText(active and active.name or 'All favorites')
    self.watchListPicker:ApplyAvailability(#lists>0)
    self.watchListSave.label:SetText(active and 'Rename' or 'New list')
    self.watchListSave:ApplyAvailability(available and writable and (active~=nil or #lists<8))
    self.watchListDelete:ApplyAvailability(active~=nil and writable)
    self.watchListHelp:SetText(not available and 'Lists unavailable; your favorites are still here.' or
        active and 'Enter a new list name to rename. Add an item above or copy a favorite from another list.' or
        'Enter a list name to organize favorites. Select an item to add it to a list.')
    self.watchRemove.label:SetText(active and 'Remove from list' or 'Remove favorite')
    local rows,nextSelection={}
    for _,entry in ipairs(W.Storage:WatchEntries(self.watchListID))do
        local r={itemID=entry.item.itemID,itemKey=entry.item,watchKey=entry.key,name=self:Name(entry.item.itemID)}
        local key=entry.item
        if (key.itemSuffix or 0)~=0 then r.detail='Variant '..key.itemSuffix end
        if (key.battlePetSpeciesID or 0)>0 then r.detail='Pet '..key.battlePetSpeciesID end
        rows[#rows+1]=r
        if self.watchSelected and self.watchSelected.watchKey==r.watchKey then nextSelection=r end
    end
    self.watchSelected=nextSelection
    self.watchListAssign:ApplyAvailability(writable and self.watchSelected~=nil and #lists>(active and 1 or 0))
    self.watchTable:SetData(rows,function(r)
        local q=U:Quote(r.itemKey)
        return {r.name,q and U:Money(q.priceCopper) or 'No saved quote',q and (W.Math.ValidInteger(q.observedAt,1) and W.Decision:Age(q.observedAt) or
                W.Math.ValidNumber(q.ageSeconds) and q.ageSeconds>=0 and W.Decision:Age(W.Clock()-q.ageSeconds) or
                'Age unknown') or 'Needs a check',
            q and (q.status=='STALE' and 'Older saved price' or
                q.status=='PARTIAL_SAMPLE' and 'Partial sample' or 'Saved asking price') or 'Check at an auctioneer'},U:ItemSub(r)
    end,function(r)return U.watchSelected and r.watchKey==U.watchSelected.watchKey end,
        active and 'No items in this list. Add one above or assign a favorite to this list.' or
        'Add an item name, link, or ID above.\nYou can also save a favorite directly from Shop.')
    self.watchInspect:ApplyAvailability(self.watchSelected~=nil and W.runtime.ahOpen)
    self.watchResearch:ApplyAvailability(self:CanResearch(self.watchSelected))
    self.watchRemove:ApplyAvailability(self.watchSelected~=nil and W.Storage:IsWritable())
end
function U:InventoryRows()
    local snap=W.Inventory.snapshot
    if self.inventoryRowSnapshot==snap and not W.Inventory.dirty then return self.inventoryRows or {}end
    local rows,by={},{}
    for _,bag in ipairs(W.PlayerContext:ReadBags())do
        if not bag.isBound then
            local identity=W.Identity:FromLink(bag.itemLink,bag.itemID)
            local observed=snap and snap.items and (snap.items[identity] or (bag.commodity and snap.items['commodity:'..bag.itemID]))
            local token=identity or ('slot:'..bag.bag..':'..bag.slot)
            local r=by[token]
            if not r then
                r={name=bag.name,itemID=bag.itemID,itemKey=bag.itemKey,itemLink=bag.itemLink,icon=bag.icon,
                    quantity=0,unit=observed and observed.unitCopper,value=observed and 0,source=observed and observed.source}
                by[token]=r;rows[#rows+1]=r
            end
            r.quantity=r.quantity+bag.count;if r.unit then r.value=r.value+bag.count*r.unit end
        end
    end
    table.sort(rows,function(a,b)if (a.value or -1)==(b.value or -1)then return a.name<b.name end return (a.value or -1)>(b.value or -1)end)
    self.inventoryRows=rows;self.inventoryRowSnapshot=snap;return rows
end
function U:Refresh_inventory()
    local s=W.Inventory.snapshot
    if not W.Inventory:IsCurrent() then s=W.Inventory:Refresh()end
    local ready=s and s.status=='READY'
    self.pages.inventory.subtitle:SetText('')
    self.inventoryValue:SetText(ready and ('Priced bag subtotal: '..self:Money(s.valueCopper)) or 'Bag prices unavailable')
    local total=ready and s.valuedUnits+s.unknownUnits or 0
    local percent=total>0 and math.floor(s.valuedUnits*1000/total)/10 or 0
    self.inventoryCoverage:SetText(ready and string.format('%d units priced · %d unpriced · %.1f%% of eligible units priced · %d bound units excluded',
        s.valuedUnits,s.unknownUnits,percent,s.boundUnits)..
        ((s.staleUnits or 0)>0 and (' · '..s.staleUnits..' older units excluded') or '') or
        'Refresh your bags after the client has loaded the item information.')
    self.inventoryTable:SetData(ready and self:InventoryRows() or {},function(r)
        return {r.name,tostring(r.quantity),r.unit and U:Money(r.unit) or 'Unknown',r.value and U:Money(r.value) or 'Unpriced',
            r.source and (r.source:find('PARTIAL',1,true) and 'Partial sample' or 'Saved observation') or 'Needs a check'},U:ItemSub(r)
    end,nil,'No tradeable carried items are available. Bound items are not included.')
end
function U:Refresh_overview()
    if self.insightJournal then self.insightJournal:SetShown(self:Settings().journalEnabled==true)end
    local m=W.Decision:Market();local scan=W.Scan;local context=W.Scope:Snapshot()
    self.insightMarket.value:SetText(m.coverage and string.format('Rows identified: %.1f%%',m.coverage) or 'No full scan')
    local stats=W.MarketPulse and m.key and W.MarketPulse:Latest(m.key)
    self.insightMarket.detail:SetText(stats and ('Full scan · '..string.format('%.1f%%',stats.coveragePct)..' of returned rows identified · '..stats.pricedVariants..' priced variants') or
        (m.latest and ((m.latest==m.partial and 'Partial sample · ' or 'Full snapshot · ')..m.age) or (W.runtime.ahOpen and W.Automation:Summary() or 'Visit an auctioneer to refresh prices')))
    self.insightBags.value:SetText(m.inventory and self:Money(m.inventory.valueCopper) or 'Not priced yet')
    self.insightBags.detail:SetText(m.inventory and ((m.inventory.unknownUnits or 0)..' unpriced units · '..
        (m.inventory.valuedUnits or 0)..' priced units · not guaranteed proceeds') or 'Carried items are checked automatically when available')
    self.insightWatch.value:SetText(m.watchCount..(m.watchCount==1 and ' item' or ' items'))
    local movements={down=0,up=0}
    if m.key and W.Signals then
        for _,favorite in ipairs(W.Storage:WatchEntries())do
            local quote=W.Quotes:ForWatch(favorite.item,m.key)
            local trend=quote and quote.identity and W.Signals:Trend(m.key,quote.identity)
            if trend and trend.prior and trend.freshnessSeconds<=48*3600 then
                if trend.direction=='FALLING' then movements.down=movements.down+1
                elseif trend.direction=='RISING' then movements.up=movements.up+1 end
            end
        end
    end
    local priceMovement=movements.down+movements.up>0 and
        (movements.down..' lower · '..movements.up..' higher asking prices') or nil
    self.insightWatch.detail:SetText(priceMovement or
        (W.QuickScan:Summary()~='' and W.QuickScan:Summary() or 'Favorites refresh first'))
    local title,detail='Your next useful action','Open Favorites to check the items that matter to you.'
    local fraction=0
    if scan:IsActive()then
        title=scan.state=='REQUESTED' and 'Requesting a market snapshot…' or scan.state=='RESOLVING' and 'Filling missing item details…' or
            (scan.state=='INDEXING' or scan.state=='FINALIZING') and 'Saving your prices…' or 'Reading the market…'
        fraction=scan.expected and scan.expected>0 and math.min(1,scan.processed/scan.expected) or 0
        detail=scan.expected and (string.format('%.0f%% of listings checked · you can stop without losing earlier prices',fraction*100)) or 'The Auction House may take a moment to respond.'
    elseif W.runtime.ahOpen and not context.ready then
        title='Waiting for Auction House information'
        detail=W.Automation:ContextReason(context)
    elseif W.runtime.ahOpen and W.Automation.state=='UNAVAILABLE' then
        title='Market refresh is waiting'
        detail=W.Automation.reason or 'Open Diagnostics for the current availability details.'
    elseif m.latest then
        title='Observed prices are available · '..m.age
        local pulse=W.MarketPulse and m.key and W.MarketPulse:Latest(m.key)
        detail=pulse and (pulse.wideSpreadVariants..' variants have wide asking-price spreads · '..pulse.thinVariants..' thin-price variants') or
            (m.latest==m.partial and 'Some items still need a targeted price check.' or 'Check live offers before trading.')
        fraction=(m.coverage or 0)/100
    end
    self.scanTitle:SetText(title);self.scanDetail:SetText(detail);self.scanBar:SetWidth(math.max(1,988*fraction))
    self.scanCancel:SetShown(scan:IsActive())
end
-- A sliced search is a view of one saved book, not a live-auction request.
-- Retain source objects as well as labels: a replacement scan may reuse an ID.
local function historyContext()
    local storage,scope,decision=W.Storage,W.Scope,W.Decision
    local account,character=storage and storage.account,storage and storage.character
    local read=decision and decision.Market
    local ok,m=W.SafeCall(read,decision)
    if not ok or type(m)~='table' or W.Storage~=storage or W.Scope~=scope or W.Decision~=decision or
        not storage or storage.account~=account or storage.character~=character or decision.Market~=read then return nil end
    local snap=m.latest
    if snap and type(snap.items)~='table' then return nil end
    return {storage=storage,account=account,character=character,scope=scope,decision=decision,read=read,
        key=m.key,mode=m.mode,market=m.context and m.context.market,snapshot=snap,items=snap and snap.items,
        partial=snap~=nil and snap==m.partial}
end
local function sameHistory(a,b)
    if not a or not b then return false end
    for _,key in ipairs({'storage','account','character','scope','decision','read','key','mode','market','snapshot','items','partial'})do
        if a[key]~=b[key]then return false end
    end
    return true
end
function U:DiscardHistory(generation)
    if generation and self.historyGeneration~=generation then return false end
    self.historyGeneration=(self.historyGeneration or 0)+1
    self.historyContext=nil;self.historySnapshot=nil;self.historyResults={};self.historyMembers={}
    self.historySelected=nil;self.historyWorking=false;self.dirty=true
    if self.historyTable then
        self.historyTable:SetData({},self.historyTable.formatter,nil,'Saved observations changed. Refresh the list to continue.')
    end
    return true
end
function U:IsHistoryCurrent()
    local generation=self.historyGeneration
    local current=historyContext()
    if generation~=self.historyGeneration then return false end
    if not sameHistory(self.historyContext,current)then self:DiscardHistory(generation);return false end
    return true
end
function U:HistorySelection()
    local r=self.historySelected
    if not r then return nil end
    if not self:IsHistoryCurrent()then return nil end
    if self.historyMembers and self.historyMembers[r]then return r end
    self.historySelected=nil;return nil
end
function U:FindHistory()
    self.historyGeneration=(self.historyGeneration or 0)+1;local generation=self.historyGeneration
    local context=historyContext()
    if self.historyGeneration~=generation then return false end
    if not context then self:DiscardHistory(generation);return false end
    local snap=context.snapshot
    self.historyContext=context;self.historySnapshot=snap;self.historyResults={};self.historyMembers={}
    self.historySelected=nil;self.historyTable.page=0;self.historyWorking=true
    self.historyTable:SetData({},self.historyTable.formatter,nil,'Finding saved observations…')
    local text=self.historyInput:GetText():lower():match('^%s*(.-)%s*$');local cursor;local rows={}
    local function current()
        if U.historyGeneration~=generation then return false end
        return U:IsHistoryCurrent()
    end
    local function finish()
        if not current()then return end
        table.sort(rows,function(a,b)
            local x,y=a.name:lower(),b.name:lower()
            if x~=y then return x<y end
            return tostring(a.identity)<tostring(b.identity)
        end)
        local members={};for _,row in ipairs(rows)do members[row]=true end
        U.historyResults=rows;U.historyMembers=members;U.historyWorking=false;U.dirty=true
    end
    local function step()
        if not current()then return end
        local processed=0
        while snap and processed<400 and #rows<500 do
            local id,entry=next(context.items,cursor);cursor=id
            if not id then finish();return end
            processed=processed+1
            local name=type(entry.name)=='string' and entry.name or ('Item '..tostring(entry.itemID))
            if text=='' or name:lower():find(text,1,true) or tostring(entry.itemID)==text then
                rows[#rows+1]={identity=id,itemID=entry.itemID,name=name,itemKey=keyFromIdentity(id,entry.itemID),
                    price=entry.referenceCopper,average=entry.averageCopper,floor=entry.floorCopper,median=entry.medianCopper,
                    p75=entry.p75Copper,nearRef=entry.nearReferenceUnits,
                    listings=entry.listings,units=entry.units,at=snap.finishedAt,
                    detail=(context.partial and 'Partial observation' or 'Full snapshot')}
            end
        end
        if not snap or #rows>=500 then finish();return end
        if C_Timer and C_Timer.After then C_Timer.After(.01,step)else finish()end
    end
    step();self.dirty=true
    return self.historyGeneration==generation
end
function U:Refresh_market()
    local generation=self.historyGeneration
    local current=historyContext()
    if self.historyGeneration~=generation then return end
    if not sameHistory(current,self.historyContext)then self:FindHistory()end
    self.historyTable:SetData(self.historyResults or {},function(r)
        return {r.name,U:Money(r.price),U:Money(r.floor),tostring(r.listings or '—'),W.Decision:Age(r.at)},U:ItemSub(r)
    end,self.historySelected,self.historyWorking and 'Finding saved observations…' or 'No saved matches. Visit an auctioneer to refresh prices, or try a different name.')
    local r=self:HistorySelection()
    local favoriteReady=r and U:FavoriteKey(r)~=nil
    self.historyWatch:ApplyAvailability(favoriteReady and W.Storage:IsWritable() or false)
    self.historyWatch:SetIcon(favoriteReady and U:FavoriteSaved(r) and 'FavoriteFilled' or 'FavoriteOutline')
    self.historyWatch.helpLabel=favoriteReady and U:FavoriteSaved(r) and 'Remove favorite' or 'Save favorite'
    self.historyLive:ApplyAvailability(r and r.itemKey~=nil and W.runtime.ahOpen or false)
    self.historyResearch:ApplyAvailability(self:CanResearch(r))
    local currentMarket=W.Scope:ReadMarketKey()
    local signalIdentity=r and r.itemID and W.ItemKinds:IsCommodity(r.itemID,currentMarket) and
        ('commodity:'..r.itemID) or r and r.identity
    local extra=signalIdentity and W.Signals and W.Signals:Label(currentMarket,signalIdentity)
    local band=r and r.price and r.p75 and r.p75>=r.price and
        (' · observed Q25–Q75 '..self:Money(r.price)..'–'..self:Money(r.p75)) or ''
    self.historyDetails:SetText(r and (r.name..' · '..tostring(r.units or 0)..' observed units'..(band or '')..
        '\n'..(extra and (extra..' · exact-variant asking prices') or
            (r.itemKey and r.detail..' · check live offers' or 'Specialized variant: select the exact live item.'))) or
        (#(self.historyResults or {})>=500 and 'Showing the first 500 matches. Refine your search to narrow the list.' or
        'Select an item to save it as a favorite or inspect live offers.'))
end
