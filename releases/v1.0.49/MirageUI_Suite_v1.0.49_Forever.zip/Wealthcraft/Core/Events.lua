-- All registrations are individually guarded. One missing optional event must not
-- prevent ADDON_LOADED, commands, saved-data initialization, or the fallback UI.
local addonName, W = ...
W.CommandHandler = function(message)
        local command = string.lower((tostring(message or ''):match('^%s*(%S+)') or ''))
        if command == 'desk' then
            if W.AuctionDesk and W.runtime.ahOpen then
                W.AuctionDesk.fallback=false
                if not W.AuctionDesk:TryOpen() then W.Notify('Native Auction House frame not ready; Blizzard view remains available.') end
            else W.Notify('Visit an auctioneer to open the integrated Auction Desk.') end
        elseif command == 'blizzard' then
            if W.AuctionDesk then W.AuctionDesk:NativeFallback() end
        elseif command == 'help' then
            W.Notify('/wc - toggle | /wc desk | /wc blizzard | /wc startup | /wc report | /wc market | /wc inventory | /wc economics')
        elseif command == 'compact' or command == 'desktop' or command == 'auto' then
            if W.UI and W.UI.SetLayoutPreference then
                local ok,why=W.UI:SetLayoutPreference(string.upper(command))
                if not ok then W.Notify(why or 'Layout could not be changed') end
            end
        elseif command == 'center' then
            if W.AuctionDesk and W.AuctionDesk.ResetPosition then W.AuctionDesk:ResetPosition() end
        elseif command == 'diag' then W.Diagnostics:PrintSummary()
        elseif command == 'report' then W.UI:ShowReport()
        elseif command == 'settings' then W.UI:Open('settings')
        elseif command == 'market' then W.UI:Open('market')
        elseif command == 'target' then W.UI:Open('targeted')
        elseif command == 'watch' then W.UI:Open('watchlist')
        elseif command == 'inventory' then W.UI:Open('inventory')
        elseif command == 'reports' then W.UI:Open('reports')
        elseif command == 'sell' then W.UI:Open('sell')
        elseif command == 'craft' then W.UI:Open('craft')
        elseif command == 'ledger' then W.UI:Open('ledger')
        elseif command == 'economics' then W.UI:Open('overview')
        elseif command == 'marketreport' then W.UI:Open('reports'); W.UI:ShowReport(W.Reports:Build(), 'Local market report')
        elseif command == 'probe' or command == 'scan' then
            W.UI:Open('overview')
            W.Notify('Market scans run automatically while you visit an auctioneer. Change this in Settings.')
        else W.UI:Toggle() end
    end

local requiredModules={'Compat','Diagnostics','Storage','Scheduler','Scope','Identity',
    'Prices','Targeted','Quotes','Sell','Crafting','Ledger','Inventory','Reports',
    'Scan','ItemCache','Decision','Browse','Owned','Trading','Widgets','UI',
    'ItemKinds','PlayerContext','Enhancements','QuickScan','AuctionDesk'}
function W.Initialize()
    if W.runtime.initialized then return true end
    W.runtime.startupStage='CHECKING_MODULES'
    for _,name in ipairs(requiredModules) do
        if type(W[name])~='table' then
            W.runtime.startupStage='FAILED_MODULE_CHECK'
            W.RecordFault('module-check','Missing module: '..name);return false
        end
    end
    W.runtime.startupStage='CLIENT_PROBE'
    if not W.Try('client-probe',W.Compat.Probe,W.Compat) then return false end
    W.runtime.startupStage='SAVED_DATA_LOAD'
    if not W.Try('saved-data-load',W.Storage.Init,W.Storage) then return false end
    W.runtime.initialized=true
    W.runtime.startupStage='CORE_READY'
    -- Item information is independent of the optional Auction Desk window.
    -- A delayed/failed UI construction must not disable the passive tooltip hook.
    if W.Tooltips then W.Try('tooltip-install',W.Tooltips.Install,W.Tooltips) end
    if W.Enhancements then W.Try('g8-initialize',W.Enhancements.Initialize,W.Enhancements) end
    if W.Crafting and type(W.Crafting.RestoreKnown)=='function' then
        W.Try('recipe-cache-restore',W.Crafting.RestoreKnown,W.Crafting)
    end
    if W.ItemSearch then W.Try('item-search-install',W.ItemSearch.Install,W.ItemSearch) end
    if W.Integration then W.Try('mirage-detection',W.Integration.Refresh,W.Integration) end
    W.Diagnostics:Record('INFO','Wealthcraft '..W.version..' core ready; '..W.Compat:Format())
    return true
end
-- Startup work belongs to the enabled addon only. Never enable/load another
-- addon, issue an auction request, or require a slash command to become ready.
local login
local function deferLogin()
    if W.runtime.startupStopped or W.runtime.uiReady then return end
    W.runtime.loginPending=true
    local frame=W.eventFrame
    if not frame or frame:GetScript('OnUpdate') then return end
    local elapsed=0
    frame:SetScript('OnUpdate',function(_,dt)
        elapsed=elapsed+dt
        if elapsed<0.5 then return end
        elapsed=0
        frame:SetScript('OnUpdate',nil)
        login()
    end)
end
login=function()
    local r=W.runtime
    if r.uiReady or r.startupStopped or not r.initialized then return end
    -- Secure item-use controls must not be constructed during late-load combat.
    -- Resume from PLAYER_REGEN_ENABLED instead of polling combat every frame.
    if (type(InCombatLockdown)=='function' and InCombatLockdown()) or r.startupWorldLeaving then
        r.loginPending=true;r.startupStage='WAITING_FOR_SAFE_START'
        return
    end
    if (r.loginAttempts or 0)>=3 then return end
    r.loginPending=false;r.loginAttempts=(r.loginAttempts or 0)+1
    r.startupStage='UI_CREATE'
    local ok,created=W.Try('ui-create',W.UI.Create,W.UI)
    if not ok or created==false or not W.UI.creationComplete then
        r.startupStage='UI_FAILED';W.RestoreBlizzard('UI initialization failed.')
        -- A half-built frame is not a successful UI and cannot safely be rebuilt
        -- in place. Retry only a clean pre-construction failure, at most twice.
        if not W.UI.frame and r.loginAttempts<3 then deferLogin() end
        return
    end
    r.loggedIn=true;r.uiReady=true;r.startupStage='READY'
    if W.Tooltips then W.Try('tooltip-install',W.Tooltips.Install,W.Tooltips) end
    W.RegisterCommands()
    W.Diagnostics:Record('INFO','Player login; UI ready')
end
local function call(owner,method,...)
    if type(owner)=='table' and type(owner[method])=='function' then
        return W.Try(method,owner[method],owner,...)
    end
end
local function closeAuctionVisit(reason)
    if not W.runtime.ahOpen then return false end
    call(W.UI,'CancelPendingSearch')
    call(W.Automation,'Closed');call(W.QuickScan,'Closed')
    W.runtime.ahOpen=false;W.runtime.ahSession=W.runtime.ahSession+1;W.runtime.venueRole=nil
    call(W.Scan,'Closed');call(W.Targeted,'Closed');call(W.Browse,'Closed');call(W.Owned,'Closed')
    call(W.AuctionDesk,'Release');call(W.Trading,'Closed');call(W.Scope,'Closed')
    W.Diagnostics:Record('INFO',reason or 'Auction House visit ended; Blizzard presentation restored')
    return true
end
local function dispatch(event,...)
    if event=='ADDON_LOADED' then
        local loaded=...
        if loaded==addonName then
            if W.Initialize() and type(IsLoggedIn)=='function' and IsLoggedIn() then login() end
        elseif W.runtime.initialized and W.runtime.uiReady then
            if loaded=='MirageUI' then call(W.Integration,'Refresh') end
            if loaded=='MirageIntel_Core' then call(W.Automation,'Initialize') end
            call(W.ItemSearch,'Install')
            if W.runtime.ahOpen and W.AuctionDesk and not W.AuctionDesk.active and
                not W.AuctionDesk.fallback then call(W.AuctionDesk,'TryOpen') end
        end
        if W.runtime.initialized and W.Tooltips and not W.Tooltips.installed then
            call(W.Tooltips,'Install')
        end
        return
    end
    if not W.runtime.initialized then return end
    if event=='PLAYER_LOGIN' then login()
    elseif event=='PLAYER_ENTERING_WORLD' then
        W.runtime.startupWorldLeaving=false
        if not W.runtime.uiReady then login() end
        if W.Tooltips and not W.Tooltips.installed then call(W.Tooltips,'Install') end
        call(W.Automation,'ContextChanged',event)
    elseif event=='PLAYER_REGEN_ENABLED' then
        if W.runtime.loginPending then login() end
        call(W.Automation,'ContextChanged',event)
        call(W.QuickScan,'CombatEnded')
        call(W.ScanCoordinator,'Rearm','COMBAT_ENDED')
    elseif event=='PLAYER_LEAVING_WORLD' then
        W.runtime.professionOpen=false
        W.runtime.startupWorldLeaving=true
        call(W.UI,'CancelPendingSearch')
        if not closeAuctionVisit('World transition retired the Auction House visit; Blizzard presentation restored') then
            call(W.Automation,'Closed');call(W.QuickScan,'Closed')
        end
        if W.eventFrame then W.eventFrame:SetScript('OnUpdate',nil) end
    elseif event=='AUCTION_HOUSE_SHOW' then
        if W.runtime.ahOpen then call(W.Automation,'ContextChanged',event);return end
        W.runtime.ahOpen=true;W.runtime.ahSession=W.runtime.ahSession+1
        W.runtime.venueRole=nil
        call(W.PlayerContext,'Refresh')
        call(W.Scope,'Opened')
        call(W.Automation,'InventoryEvent',event,false,true)
        call(W.Automation,'Opened')
        call(W.QuickScan,'Opened')
        W.Diagnostics:Record('INFO','Auction House opened; preparing custom presentation')
        if W.runtime.uiReady then call(W.AuctionDesk,'Opened') end
    elseif event=='AUCTION_HOUSE_CLOSED' then
        if not closeAuctionVisit('Auction House closed; Blizzard presentation restored') then return end
    elseif event=='AUCTION_HOUSE_DISABLED' then
        if W.runtime.ahOpen then
            call(W.UI,'CancelPendingSearch')
            W.Diagnostics:Record('WARN','Blizzard temporarily disabled the Auction House; restoring native presentation')
            call(W.Automation,'Closed');call(W.QuickScan,'Closed');call(W.Trading,'Closed')
            W.runtime.ahOpen=false;W.runtime.ahSession=W.runtime.ahSession+1;W.runtime.venueRole=nil
            call(W.Scan,'Closed');call(W.Targeted,'Closed');call(W.Browse,'Closed');call(W.Owned,'Closed')
            call(W.AuctionDesk,'Release');call(W.Scope,'Closed')
            W.RestoreBlizzard('Auction House unavailable')
        end
    elseif event=='AUCTION_HOUSE_THROTTLED_MESSAGE_DROPPED' then
        -- Shared auction event: cannot infer which addon sent the dropped message.
        if W.QuickScan and (W.QuickScan.state=='RUNNING' or W.QuickScan.state=='WAITING') then
            W.QuickScan:ServiceBusy('Auction service busy')
        end
        W.Diagnostics:Record('WARN','Shared Auction House throttle event observed; source unknown')
    elseif event=='AUCTION_HOUSE_THROTTLED_SYSTEM_READY' then
        call(W.Automation,'ServiceReady')
    elseif event=='PLAYER_REGEN_DISABLED' then
        call(W.QuickScan,'CombatStarted')
        if W.AuctionDesk and W.AuctionDesk.active then W.RestoreBlizzard('Combat started.') end
        call(W.Trading,'Closed')
    elseif event=='DISPLAY_SIZE_CHANGED' or event=='UI_SCALE_CHANGED' then
        call(W.AuctionDesk,'ViewportChanged')
    elseif event=='ITEM_DATA_LOAD_RESULT' then
        call(W.ItemCache,'OnResult',...)
        call(W.Inventory,'ItemDataLoaded',...);return
    elseif event=='REPLICATE_ITEM_LIST_UPDATE' then
        call(W.Scan,'OnUpdateEvent');return -- no per-row UI redraw
    elseif event=='ITEM_SEARCH_RESULTS_UPDATED' or event=='ITEM_SEARCH_RESULTS_ADDED' or
        event=='COMMODITY_SEARCH_RESULTS_UPDATED' or event=='COMMODITY_SEARCH_RESULTS_ADDED' then
        local request=W.QuickTarget:IsActive() and W.QuickTarget or W.Targeted
        call(request,'OnResults',event,...);return
    elseif event=='AUCTION_HOUSE_BROWSE_RESULTS_UPDATED' or event=='AUCTION_HOUSE_BROWSE_RESULTS_ADDED' then
        call(W.Browse,'OnResults',event,...);return
    elseif event=='AUCTION_HOUSE_BROWSE_FAILURE' then
        if W.Browse and W.Browse.state=='REQUESTED' then
            W.Browse.state='ERROR';W.Browse.message='Auction search failed. Retry manually or use Blizzard view.'
        end
    elseif event=='OWNED_AUCTIONS_UPDATED' or event=='BIDS_UPDATED' then
        call(W.Owned,'OnResults',event);return
    elseif event=='COMMODITY_PRICE_UPDATED' or event=='COMMODITY_PRICE_UNAVAILABLE' or
        event=='COMMODITY_PURCHASE_SUCCEEDED' or event=='COMMODITY_PURCHASE_FAILED' or
        event=='AUCTION_HOUSE_SHOW_ERROR' then
        call(W.Trading,'OnEvent',event,...);return
    elseif event=='AUCTION_HOUSE_PURCHASE_COMPLETED' then
        call(W.Trading,'OnItemPurchased',...)
    elseif event=='AUCTION_HOUSE_POST_ERROR' then
        call(W.Trading,'OnPostError',...)
    elseif event=='ADDON_ACTION_BLOCKED' or event=='ADDON_ACTION_FORBIDDEN' then
        local owner,action=...
        if owner==addonName or owner=='Wealthcraft' then
            W.RecordFault('protected-action',tostring(action));call(W.Trading,'Closed')
            W.RestoreBlizzard('Blizzard blocked this action; use native controls.')
        end
    elseif event=='AUCTION_HOUSE_AUCTION_CREATED' then
        call(W.Trading,'OnPosted',...)
    elseif event=='PLAYER_LEVEL_UP' or event=='ZONE_CHANGED_NEW_AREA' or event=='SKILL_LINES_CHANGED' then
        call(W.PlayerContext,'Refresh');call(W.Automation,'ContextChanged',event)
    elseif event=='TRADE_SKILL_CLOSE' then
        W.runtime.professionOpen=false
    elseif event=='TRADE_SKILL_SHOW' or event=='TRADE_SKILL_LIST_UPDATE' or event=='TRADE_SKILL_DATA_SOURCE_CHANGED' then
        call(W.Automation,'InventoryEvent',event,false,true)
    elseif event=='MERCHANT_SHOW' then
        call(W.Automation,'InventoryEvent',event,false,true)
    elseif event=='BANKFRAME_OPENED' then
        W.runtime.bankOpen=true
        call(W.Automation,'InventoryEvent',event,true,true)
    elseif event=='BANKFRAME_CLOSED' then
        W.runtime.bankOpen=false
        if W.PlayerContext.bank then W.PlayerContext.bank.current=false end
    elseif event=='PLAYERBANKSLOTS_CHANGED' or event=='PLAYERBANKBAGSLOTS_CHANGED' or event=='BANK_TABS_CHANGED' then
        if W.runtime.bankOpen then call(W.Automation,'InventoryEvent',event,true,false)end
    elseif event=='BAG_UPDATE_DELAYED' then
        call(W.Automation,'InventoryEvent',event,W.runtime.bankOpen==true,false)
        call(W.Inventory,'MarkDirty');call(W.AuctionDesk,'OnEvent',event)
        local frame=W.UI and W.UI.frame
        if W.runtime.uiReady and W.UI.activePage=='inventory' and frame and
            type(frame.IsShown)=='function' and frame:IsShown() and
            (type(frame.IsVisible)~='function' or frame:IsVisible()) and
            not W.Inventory:IsCurrent() then
            -- The Auction Desk callback may already have rendered the current
            -- bags. Reuse only a fresh appraisal for this account and market;
            -- a missed render or newer invalidation still needs this refresh.
            call(W.UI,'RefreshInventory')
        end
        return
    elseif event=='PLAYER_LOGOUT' then
        W.runtime.startupStopped=true;W.runtime.loginPending=false
        call(W.UI,'CancelPendingSearch')
        if W.eventFrame then W.eventFrame:SetScript('OnUpdate',nil) end
        call(W.Automation,'Closed');call(W.QuickScan,'Closed')
        if W.Scan:IsActive() then call(W.Scan,'Stop','CANCELLED','CLIENT_LOGOUT') end
        if W.Targeted:IsActive() then call(W.Targeted,'Stop','CANCELLED','CLIENT_LOGOUT') end
        call(W.Scheduler,'Cancel');call(W.AuctionDesk,'Release')
    end
    if W.Publish then W.Publish('STATE_CHANGED',{kind=event}) end
    W.Refresh()
end
local frame=CreateFrame('Frame')
W.eventFrame=frame
-- Install handler BEFORE any registration; never leave a partly registered frame inert.
frame:SetScript('OnEvent',function(_,event,...)
    local ok=W.Try('event:'..event,dispatch,event,...)
    if not ok and W.runtime.ahOpen then W.RestoreBlizzard('Event handler failed.') end
end)
for _,event in ipairs({
    'ADDON_LOADED','PLAYER_LOGIN','PLAYER_ENTERING_WORLD','PLAYER_LEAVING_WORLD',
    'PLAYER_LOGOUT','PLAYER_REGEN_DISABLED','PLAYER_REGEN_ENABLED',
    'DISPLAY_SIZE_CHANGED','UI_SCALE_CHANGED','ITEM_DATA_LOAD_RESULT',
    'AUCTION_HOUSE_SHOW','AUCTION_HOUSE_CLOSED','AUCTION_HOUSE_DISABLED',
    'AUCTION_HOUSE_THROTTLED_MESSAGE_DROPPED','AUCTION_HOUSE_THROTTLED_SYSTEM_READY','REPLICATE_ITEM_LIST_UPDATE',
    'ITEM_SEARCH_RESULTS_UPDATED','COMMODITY_SEARCH_RESULTS_UPDATED',
    'ITEM_SEARCH_RESULTS_ADDED','COMMODITY_SEARCH_RESULTS_ADDED','BAG_UPDATE_DELAYED',
    'AUCTION_HOUSE_BROWSE_RESULTS_UPDATED','AUCTION_HOUSE_BROWSE_RESULTS_ADDED','AUCTION_HOUSE_BROWSE_FAILURE',
    'OWNED_AUCTIONS_UPDATED','BIDS_UPDATED','COMMODITY_PRICE_UPDATED','COMMODITY_PRICE_UNAVAILABLE',
    'COMMODITY_PURCHASE_SUCCEEDED','COMMODITY_PURCHASE_FAILED','AUCTION_HOUSE_SHOW_ERROR',
    'AUCTION_HOUSE_PURCHASE_COMPLETED','AUCTION_HOUSE_POST_ERROR','ADDON_ACTION_BLOCKED','ADDON_ACTION_FORBIDDEN',
    'AUCTION_HOUSE_AUCTION_CREATED','PLAYER_LEVEL_UP','ZONE_CHANGED_NEW_AREA','SKILL_LINES_CHANGED',
    'TRADE_SKILL_SHOW','TRADE_SKILL_CLOSE','TRADE_SKILL_LIST_UPDATE','TRADE_SKILL_DATA_SOURCE_CHANGED',
    'MERCHANT_SHOW','BANKFRAME_OPENED','BANKFRAME_CLOSED','PLAYERBANKSLOTS_CHANGED','PLAYERBANKBAGSLOTS_CHANGED','BANK_TABS_CHANGED',
}) do
    local ok,err=pcall(frame.RegisterEvent,frame,event)
    if ok and err==false then ok=false;err='Client rejected registration.' end
    if ok and type(frame.IsEventRegistered)=='function' then
        local inspected,registered=pcall(frame.IsEventRegistered,frame,event)
        if inspected and registered==false then ok=false;err='Client reports event is not registered.' end
    end
    W.runtime.registeredEvents[event]=ok
    if not ok then
        W.runtime.rejectedEvents[event]=tostring(err)
        -- G9's two new service-status events are optional client probes, not
        -- startup blockers. A missing event must not look like a trading fault.
        if event=='AUCTION_HOUSE_DISABLED' or event=='AUCTION_HOUSE_THROTTLED_MESSAGE_DROPPED' or
            event=='BANK_TABS_CHANGED' or event=='PLAYERBANKBAGSLOTS_CHANGED' or event=='TRADE_SKILL_DATA_SOURCE_CHANGED' or
            event=='AUCTION_HOUSE_THROTTLED_SYSTEM_READY' or event=='TRADE_SKILL_CLOSE' then
            W.runtime.logs[#W.runtime.logs+1]={at=W.Clock(),level='INFO',message='Optional AH event unavailable: '..event}
        else
            W.RecordFault('event-registration',event..': '..tostring(err))
        end
    end
end
W.runtime.startupStage='EVENTS_READY'
W.RegisterCommands()
