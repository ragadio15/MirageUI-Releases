local _, W = ...
W.Scheduler = {generation=0}
local S = W.Scheduler
local schedulerFrame
function S:Init()
    if schedulerFrame then return end
    schedulerFrame = CreateFrame("Frame")
    schedulerFrame:Hide()
    schedulerFrame:SetScript("OnUpdate", function(_, elapsed)
        if not S.active then schedulerFrame:Hide(); return end
        local active,generation=S.active,S.generation
        local complete = false
        local ok, result = pcall(active, elapsed)
        if not ok then
            W.Diagnostics:Record("ERROR", "Scheduled work failed: " .. tostring(result))
            -- A callback (or its failure observer) can cancel this job and
            -- start a replacement. Cleanup belongs only to the captured job.
            if S.active~=active or S.generation~=generation then return end
            S:Cancel()
            if W.Scan and W.Scan.IsActive and W.Scan:IsActive() and not W.Scan.pausedForUser then
                W.Scan:Stop('INVALID', 'BATCH_RUNTIME_ERROR')
            end
            -- Scan cleanup may cancel again. Only a newly active job owns
            -- this scheduler now; an extra Cancel alone is not a handoff.
            if S.active then return end
            local request=W.QuickTarget and W.QuickTarget:IsActive() and W.QuickTarget or W.Targeted
            if request and request:IsActive() then
                request:Stop('INVALID', 'SCHEDULER_RUNTIME_ERROR')
            end
            return
        end
        complete = result == true
        if complete and S.active==active and S.generation==generation then S:Cancel() end
    end)
end
function S:Start(fn)
    if type(fn) ~= "function" then return false end
    self:Init()
    if self.active then return false end
    self.generation=self.generation+1
    self.active = fn
    schedulerFrame:Show()
    return true
end
function S:Cancel()
    self.generation=self.generation+1
    self.active = nil
    if schedulerFrame then schedulerFrame:Hide() end
end

-- Player searches own the foreground. The local scheduler is cooperative:
-- an automatic targeted query may be cancelled; a replication scan can yield
-- its CPU work and resume only after the auction buffer is rechecked.
local function reviewClock() return type(GetTime)=='function' and GetTime() or W.Clock() end
W.Priority = {reviewSeconds=8}
function W.Priority:RecordInteraction()
    if not W.runtime.ahOpen then return end
    self.reviewSession=W.runtime.ahSession
    self.reviewUntil=reviewClock()+self.reviewSeconds
end
function W.Priority:ReviewRemaining()
    if not W.runtime.ahOpen or self.reviewSession~=W.runtime.ahSession then return 0 end
    return math.max(0,(self.reviewUntil or 0)-reviewClock())
end
function W.Priority:ManualSearch()
    self:RecordInteraction()
    if W.QuickScan and W.QuickScan.PauseForManual then
        W.QuickScan:PauseForManual()
    end
    if W.Scan and W.Scan.PauseForManual then
        W.Scan:PauseForManual()
    end
end
function W.Priority:ManualRejected()
    if W.QuickScan and W.QuickScan.ManualRejected then W.QuickScan:ManualRejected()end
    if W.Automation and W.Automation.ManualRejected then W.Automation:ManualRejected()end
    -- A rejected player request must not leave a full scan suspended forever.
    if W.Scan and W.Scan.pausedForUser then
        W.Scan.resumeCheckAt = (type(GetTime)=='function' and GetTime() or W.Clock()) + 0.5
    end
end
