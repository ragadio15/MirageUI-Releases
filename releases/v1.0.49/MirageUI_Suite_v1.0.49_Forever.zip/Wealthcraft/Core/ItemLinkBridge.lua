-- Additive read-only link contract. Identity normalization stays in Wealthcraft;
-- consumers must not reproduce it or fall back from a variant to its item ID.
local _,W=...
W.ItemLinkBridge={contractVersion=1}
local B=W.ItemLinkBridge
local revisions=setmetatable({},{__mode='k'})
local nextRevision=0
local PRICE_MAX=9000000000000

local function readable(v)
    if type(issecretvalue)=='function' then
        local ok,secret=pcall(issecretvalue,v)
        if not ok or secret==true then return false end
    end
    if type(canaccessvalue)=='function' then
        local ok,access=pcall(canaccessvalue,v)
        if not ok or access==false then return false end
    end
    if type(v)=='table' and type(canaccesstable)=='function' then
        local ok,access=pcall(canaccesstable,v)
        if not ok or access==false then return false end
    end
    return true
end
local function field(t,k)
    if not readable(t) or type(t)~='table' then return nil end
    local ok,v=pcall(function()return t[k] end)
    if ok and readable(v) then return v end
end
local function integer(v,lo,hi)
    return readable(v) and type(v)=='number' and v==v and v>=lo and v<=hi and v%1==0
end
local function text(v,max)
    return readable(v) and type(v)=='string' and #v>0 and #v<=max and not v:find('[%c]')
end
local function label(v,max) return text(v,max) and not v:find('|',1,true) end
local function revision(source)
    if not revisions[source] then nextRevision=nextRevision+1;revisions[source]=nextRevision end
    return revisions[source]
end
local function valueTable(t) return readable(t) and type(t)=='table' end
local function remember(record,names)
    local proof={}
    for _,name in ipairs(names) do proof[#proof+1]={key=name,value=field(record,name)} end
    return proof
end
local function unchanged(record,proof)
    for _,entry in ipairs(proof) do if field(record,entry.key)~=entry.value then return false end end
    return true
end
local function marketIdentity(key)
    if key:sub(1,4)=='WC4/' then
        if #key>160 then return nil end
        local flavor,regionToken,serverToken,modeToken,faction,mapToken,role,token,build=
            key:match('^WC4/([%w]+)/LIVE/([A-Z0-9]+)/([A-Z0-9]+)/([A-Z0-9]+)/(%a+)/([A-Z0-9]+)/([A-Z]+)/([A-Z0-9]+)/(%d+)$')
        if not flavor then return nil end
        local interface=tonumber(flavor:match('^Client(%d+)$'))
        local region=tonumber(regionToken:match('^R(%d+)$'))
        local realm=tonumber(serverToken:match('^I(%d+)$'))
        local guid=tonumber(serverToken:match('^G(%d+)$'))
        local realmText=serverToken:match('^T(%x+)$')
        local map=tonumber(mapToken:match('^M(%d+)$'))
        local record,active,hardcore,roleplay,pvp=modeToken:match('^D([%dU]+)A([%dU]+)H([01U])R([01U])P([01U])$')
        if not record then return nil end
        local recordID,activeID=tonumber(record),tonumber(active)
        local npc=tonumber(token:match('^N(%d+)$'))
        local at,serial=token:match('^S(%d+)X(%d+)$')
        local session=integer(tonumber(at),0,9007199254740991) and integer(tonumber(serial),1,9007199254740991)
        local rulesKnown=hardcore~='U' and roleplay~='U' and pvp~='U'
        local knownServer=integer(realm,1,100000000) or integer(guid,1,100000000) or
            (realmText and #realmText>=2 and #realmText<=48 and #realmText%2==0)
        if (flavor~='Forever' and not integer(interface,1,999999999)) or
            (regionToken~='U' and not integer(region,1,999999)) or
            (serverToken~='U' and not knownServer) or
            (mapToken~='U' and not integer(map,1,10000000)) or
            (record~='U' and not integer(recordID,1,999999999)) or
            (active~='U' and not integer(activeID,0,999999999)) or
            (faction~='Horde' and faction~='Alliance' and faction~='Unknown') or role~='LOCAL' or
            (not integer(npc,1,999999999) and not session) or
            not integer(tonumber(build),1,999999999) then return nil end
        -- A durable auctioneer partition must contain every observed dimension.
        -- Incomplete identity is permitted only under a unique visit token.
        if npc and (not region or not map or faction=='Unknown' or
            (not knownServer and not recordID and not rulesKnown)) then return nil end
        local function rule(v)if v=='1' then return true elseif v=='0' then return false end end
        return {flavor=flavor,region=region,realmID=realm,faction=faction,mapID=map,
            venueRole=role,venueToken=token,build=tonumber(build),regionToken=regionToken,
            serverToken=serverToken,modeToken=modeToken,mapToken=mapToken,
            gameModeRecordID=recordID,activeGameMode=activeID,
            hardcore=rule(hardcore),roleplay=rule(roleplay),pvp=rule(pvp),
            status=npc and 'AUTOMATIC_AUCTIONEER_SCOPED' or 'AUTOMATIC_SESSION_SCOPED',
            identityMode=npc and 'DURABLE' or 'VISIT_ISOLATED'}
    end
    local flavor,region,realm,faction,map,role,token,build=key:match('^WC3/([%w]+)/LIVE/(%d+)/(%d+)/(%a+)/(%d+)/([A-Z]+)/([A-Z0-9]+)/(%d+)$')
    local automatic=flavor~=nil
    if not automatic then
        flavor,region,realm,faction,map,role,build=key:match('^WC2/([%w]+)/LIVE/(%d+)/(%d+)/(%a+)/(%d+)/([A-Z]+)/(%d+)$')
    end
    region,realm,map,build=tonumber(region),tonumber(realm),tonumber(map),tonumber(build)
    local interface=flavor and tonumber(flavor:match('^Client(%d+)$'))
    if not integer(region,1,999) or not integer(realm,1,100000000) or not integer(map,1,10000000) or
        (faction~='Horde' and faction~='Alliance') or
        (automatic and (role~='LOCAL' or not token or not (token:match('^N%d+$') or token:match('^S%d+X%d+$'))) or
        not automatic and role~='FACTION' and role~='NEUTRAL' and role~='OTHER') or
        not integer(build,1,999999999) or (flavor~='Forever' and not integer(interface,1,999999999)) then return nil end
    return {flavor=flavor,region=region,realmID=realm,faction=faction,mapID=map,venueRole=role,venueToken=token,build=build}
end
local scopeStatuses={PLAYER_DECLARED_ZONE_SCOPED=true,AUTOMATIC_AUCTIONEER_SCOPED=true,AUTOMATIC_SESSION_SCOPED=true}

-- Validate only the public envelope and complete numeric payload here. The
-- existing Identity service decides semantic equivalence (including variants).
-- No partial hyperlink, embedded sentence, truncated bonus list or itemID-only
-- string can acquire the proof advertised by this bridge.
function B:Normalize(link)
    if not text(link,600) then return nil,nil,'FULL_ITEM_LINK_REQUIRED' end
    local body=link
    if body:sub(1,2)=='|c' then
        local prefix=body:match('^|c%x%x%x%x%x%x%x%x') or body:match('^|cn[%a][%w_]*:')
        if not prefix then return nil,nil,'MALFORMED_ITEM_LINK' end
        body=body:sub(#prefix+1)
        if body:sub(-2)~='|r' then return nil,nil,'MALFORMED_ITEM_LINK' end
        body=body:sub(1,-3)
    elseif body:sub(-2)=='|r' then body=body:sub(1,-3) end
    local payload=body:match('^|Hitem:([^|]+)|h%[[^|]*%]|h$') or body:match('^item:([^|]+)$')
    if not payload or not payload:match('^[%d:%-]+$') then return nil,nil,'MALFORMED_ITEM_LINK' end
    local fields={}
    for part in (payload..':'):gmatch('(.-):') do
        if #fields>=96 then return nil,nil,'UNSUPPORTED_LINK_FIELDS' end
        if part~='' and (not part:match('^%-?%d+$') or not integer(tonumber(part),-999999999,999999999)) then
            return nil,nil,'MALFORMED_ITEM_LINK'
        end
        fields[#fields+1]=part
    end
    if #fields<7 then return nil,nil,'FULL_ITEM_LINK_REQUIRED' end
    local id=tonumber(fields[1])
    if not integer(id,1,999999999) then return nil,nil,'MALFORMED_ITEM_LINK' end
    local bonuses=fields[13] and fields[13]~='' and tonumber(fields[13]) or 0
    if not integer(bonuses,0,40) or #fields<13+bonuses and bonuses>0 then
        return nil,nil,'TRUNCATED_OR_UNSUPPORTED_BONUSES'
    end
    for index=14,13+bonuses do
        if fields[index]=='' then return nil,nil,'TRUNCATED_OR_UNSUPPORTED_BONUSES' end
    end
    local ok,identity,reason=pcall(W.Identity.FromLink,W.Identity,link,id)
    if not ok or not label(identity,260) then return nil,nil,reason or 'IDENTITY_UNAVAILABLE' end
    return identity,id
end

local function readRoots(key)
    local account=W.Storage and W.Storage.account
    local history=field(account,'marketHistory')
    local historyMarkets=field(history,'markets')
    local target=field(account,'targeted')
    local targetMarkets=field(target,'markets')
    return account,historyMarkets,field(historyMarkets,key),targetMarkets,field(targetMarkets,key)
end

-- A bounded invalidation token for visible consumers. No item/auction rows are
-- scanned, and no native auction operation is called. Saved producers replace
-- these roots atomically, so same-time updates still receive a new revision.
function B:GetRevision()
    if not W.Compat or (field(W.Compat.build,'runtimeAllowed')~=true and field(W.Compat.build,'exactTarget')~=true) then return nil,'UNSUPPORTED_CLIENT' end
    if not W.Storage or not W.Storage:IsWritable() then return nil,'STORAGE_UNAVAILABLE' end
    local ok,context=pcall(W.Scope.ReadContext,W.Scope)
    local key=ok and field(context,'key')
    local mode=ok and field(context,'mode')
    if not label(key,250) or not marketIdentity(key) or (mode~='CURRENT' and mode~='LAST_SAVED') then
        return nil,'MARKET_SCOPE_UNKNOWN'
    end
    local account,_,market,_,target=readRoots(key)
    local function id(record) return valueTable(record) and revision(record) or 0 end
    return table.concat({key,mode,id(account),id(market),id(field(field(market,'snapshots'),1)),
        id(field(market,'partial')),id(target),id(field(target,'records'))},':'),'AVAILABLE'
end

-- A quoted source is one committed record, never fields composed from a newer
-- price and an older provenance record. Records are replaced atomically by the
-- producer; the fence below also catches reentrant provider/context updates.
function B:ValidateContext(context)
    if context~=nil and not valueTable(context) then return false,'INVALID_CONTEXT' end
    if not context then return true end
    local ok,stack,contextKey=pcall(function()return context.stackCount,context.marketKey end)
    if not ok then return false,'INVALID_CONTEXT' end
    if not readable(stack) or (stack~=nil and not integer(stack,1,1000000)) then return false,'INVALID_STACK_COUNT' end
    if not readable(contextKey) or (contextKey~=nil and not label(contextKey,250)) then return false,'MARKET_SCOPE_UNKNOWN' end
    return true,nil,stack,contextKey
end
function B:Get(link,context)
    if not W.Compat or (field(W.Compat.build,'runtimeAllowed')~=true and field(W.Compat.build,'exactTarget')~=true) then return nil,'UNSUPPORTED_CLIENT' end
    if not W.Storage or not W.Storage:IsWritable() then return nil,'STORAGE_UNAVAILABLE' end
    local identity,id,problem=self:Normalize(link)
    if not identity then return nil,problem end
    local valid,why,stack,contextKey=self:ValidateContext(context)
    if not valid then return nil,why end
    local ok,current=pcall(W.Scope.ReadContext,W.Scope)
    local key=ok and field(current,'key')
    if not label(key,250) then return nil,'MARKET_SCOPE_UNKNOWN' end
    local encodedScope=marketIdentity(key)
    if not encodedScope then return nil,'MARKET_SCOPE_UNQUALIFIED' end
    if contextKey and contextKey~=key then return nil,'MARKET_SCOPE_MISMATCH' end
    local mode=field(current,'mode')
    if mode~='CURRENT' and mode~='LAST_SAVED' then return nil,'MARKET_SCOPE_UNKNOWN' end
    local account,historyMarkets,market,targetMarkets,targetMarket=readRoots(key)
    if not valueTable(account) then return nil,'STORAGE_UNAVAILABLE' end
    if market and field(market,'key')~=key then return nil,'MARKET_SCOPE_MISMATCH' end
    local marketScope=field(market,'scope') or field(targetMarket,'scope')
    local scope=marketScope or field(current,'scope')
    if scope and not scopeStatuses[field(scope,'status')] then return nil,'VENUE_UNVERIFIED' end
    if scope then
        for name,value in pairs(encodedScope) do
            if field(scope,name)~=value then return nil,'MARKET_SCOPE_MISMATCH' end
        end
        if key:sub(1,4)=='WC4/' then
            -- Unknown dimensions must remain unknown, including false vs nil
            -- rule observations. A nil encoded value cannot be checked by pairs.
            for _,name in ipairs({'region','realmID','mapID','gameModeRecordID','activeGameMode','hardcore','roleplay','pvp'})do
                if field(scope,name)~=encodedScope[name] then return nil,'MARKET_SCOPE_MISMATCH' end
            end
            if encodedScope.serverToken=='U' and encodedScope.identityMode=='DURABLE' and
                field(scope,'regionalNames')~=true then return nil,'MARKET_SCOPE_MISMATCH' end
        end
    end
    local now=W.Clock()
    if not integer(now,1,9007199254740991) then return nil,'CLOCK_UNAVAILABLE' end
    local best,bestAt,bestItem,bestSource,bestCoverage,bestID,bestQuery
    local malformed,seenUnpriced=false,false
    local function consider(record,kind,queryKey)
        if not valueTable(record) then return end
        local items=field(record,'items')
        local item=field(items,identity)
        if not item then return end
        if not valueTable(item) or field(item,'identity')~=identity or field(item,'itemID')~=id then
            malformed=true;return
        end
        local at=field(record,kind=='TARGETED' and 'updatedAt' or 'finishedAt')
        if not integer(at,1,9007199254740991) or at>now then malformed=true;return end
        local source,coverage,snapshotID
        if kind=='FULL' then
            local count=field(record,'count')
            if field(record,'status')~='COMPLETE' or not integer(count,1,500000) or
                field(record,'handled')~=count or field(record,'unresolved')~=0 or field(record,'invalid')~=0 or
                not integer(field(record,'preciseCount'),1,100000) then malformed=true;return end
            source,coverage=field(record,'source')=='AUTO_AH_OPEN_REPLICATION' and 'AUTO_FULL_SCAN' or 'PLAYER_INITIATED_FULL_SCAN','COMPLETE_REPLICATION'
            snapshotID=field(record,'id')
        elseif kind=='PARTIAL' then
            if field(record,'status')~='PARTIAL_COVERAGE' or not integer(field(record,'count'),1,500000) or
                not integer(field(record,'unresolved'),1,500000) or field(record,'invalid')~=0 or
                not integer(field(record,'preciseCount'),1,100000) then malformed=true;return end
            source,coverage='PARTIAL_REPLICATION_EXACT_LINKS','PARTIAL_REPLICATION'
            snapshotID=field(record,'id')
        else
            source=field(record,'source')
            if field(record,'status')~='COMPLETE_TARGET_QUERY' or not label(queryKey,75) or
                field(record,'queryKey')~=queryKey or not integer(field(record,'resultCount'),0,25000) or
                (source~='PLAYER_INITIATED_TARGET_SEARCH' and source~='AH_OPEN_QUICK_REFRESH') then
                malformed=true;return
            end
            coverage='TARGETED_SEARCH'
            snapshotID='target:'..queryKey..':'..at..':'..revision(record)
        end
        if not label(snapshotID,180) then malformed=true;return end
        local price=field(item,'referenceCopper')
        if price==nil or price==0 then seenUnpriced=true;return end
        if not integer(price,1,PRICE_MAX) then malformed=true;return end
        if not best or at>bestAt then
            best,bestAt,bestItem,bestSource,bestCoverage,bestID,bestQuery=
                record,at,item,source,coverage,snapshotID,queryKey
        end
    end
    local snapshots=field(market,'snapshots')
    local full=field(snapshots,1)
    local partial=field(market,'partial')
    consider(full,'FULL')
    consider(partial,'PARTIAL')
    local records=field(targetMarket,'records')
    if valueTable(records) then
        local count=0
        for queryKey,record in pairs(records) do
            count=count+1
            if count>120 then return nil,'SOURCE_LIMIT_EXCEEDED' end
            if readable(queryKey) then consider(record,'TARGETED',queryKey) end
        end
    end
    if not best then
        return nil,malformed and 'SOURCE_RECORD_UNQUALIFIED' or seenUnpriced and 'NO_PRICED_LISTINGS' or 'NO_EXACT_LINK_OBSERVATION'
    end
    local price=field(bestItem,'referenceCopper')
    local method=field(bestItem,'method')
    if not label(method,100) then return nil,'PRICE_BASIS_UNKNOWN' end
    local sourceRevision=revision(best)
    local sourceBuild=encodedScope.build
    local sourceScope=scope and field(scope,'status') or (encodedScope.venueToken and (encodedScope.venueToken:sub(1,1)=='N' and 'AUTOMATIC_AUCTIONEER_SCOPED' or 'AUTOMATIC_SESSION_SCOPED') or 'PLAYER_DECLARED_ZONE_SCOPED')
    local marketLabel=field(current,'label')
    local contextSource=field(current,'source')
    local quote={
        quoteContractVersion=1,sourceAPI='WEALTHCRAFT_EXACT_LINK_QUOTE_1',
        requestedLink=link,itemID=id,identity=identity,identityPrecision='EXACT_WEALTHCRAFT_VARIANT',
        marketKey=key,marketContextMode=mode,marketContextSource=contextSource,
        marketLabel=scope and label(marketLabel,200) and marketLabel or 'Last saved market',
        venueStatus=sourceScope,venueVerified=false,
        venueRole=encodedScope.venueRole,sourceBuild=sourceBuild,
        currentBuild=field(W.Compat.build,'build'),
        source=bestSource,sourceSnapshotID=bestID,snapshotID=bestID,sourceRevision=sourceRevision,
        observedAt=bestAt,ageSeconds=now-bestAt,coverage=bestCoverage,
        completeDepth=bestCoverage=='COMPLETE_REPLICATION',
        priceBasis='OBSERVED_ASK_REFERENCE_PER_UNIT',unitBasis='ONE_ITEM',
        priceCopper=price,referenceCopper=price,stackCount=stack,
        stackCopper=stack and price<=math.floor(PRICE_MAX/stack) and price*stack or nil,
        stackBasis=stack and 'CALLER_OBSERVED_COUNT' or 'NOT_SUPPLIED',
        method=method,readOnly=true,nativeQualification='NOT_RUN',
        status=now-bestAt>172800 and 'STALE' or bestCoverage=='PARTIAL_REPLICATION' and 'PARTIAL_SAMPLE' or 'LIMITED_EVIDENCE',
        confidence='RECORDED_ASKING_PRICES',salesEvidence='NOT_CLAIMED',profitEvidence='NOT_CLAIMED',
    }
    if stack and not quote.stackCopper then quote.stackBasis='TOTAL_EXCEEDS_SUPPORTED_RANGE' end
    for _,name in ipairs({'listings','units','pricedListings','floorCopper','averageCopper','medianCopper','p10Copper','p75Copper'}) do
        local value=field(bestItem,name)
        if integer(value,0,PRICE_MAX) then quote[name]=value end
    end
    local recordProof=remember(best,{'id','status','items','finishedAt','count','handled','unresolved','invalid',
        'preciseCount','updatedAt','queryKey','resultCount','source','kind'})
    local itemProof=remember(bestItem,{'identity','itemID','referenceCopper','method','listings','units','pricedListings',
        'floorCopper','averageCopper','medianCopper','p10Copper','p75Copper'})
    local scopeProof=marketScope and remember(marketScope,{'status','flavor','build','venueRole','venueToken','mapID','region','realmID','faction',
        'regionToken','serverToken','modeToken','mapToken','identityMode','regionalNames',
        'gameModeRecordID','activeGameMode','hardcore','roleplay','pvp'})
    -- Scope reads can call native providers; finish them BEFORE the final pure
    -- source fence so a reentrant save cannot change the meaning of this quote.
    local finalOK,final=pcall(W.Scope.ReadContext,W.Scope)
    if not finalOK or field(final,'key')~=key or field(final,'mode')~=mode then return nil,'MARKET_SCOPE_CHANGED' end
    local a,hm,m,tm,t=readRoots(key)
    if a~=account or hm~=historyMarkets or m~=market or tm~=targetMarkets or t~=targetMarket or
        field(market,'snapshots')~=snapshots or field(snapshots,1)~=full or field(market,'partial')~=partial or
        field(targetMarket,'records')~=records or
        (bestQuery and field(records,bestQuery)~=best) or field(field(best,'items'),identity)~=bestItem or
        field(bestItem,'referenceCopper')~=price or field(bestItem,'method')~=method or
        field(best, bestQuery and 'updatedAt' or 'finishedAt')~=bestAt or
        (field(market,'scope') or field(targetMarket,'scope'))~=marketScope or not unchanged(best,recordProof) or not unchanged(bestItem,itemProof) or
        (marketScope and not unchanged(marketScope,scopeProof)) then
        return nil,'SOURCE_SNAPSHOT_CHANGED'
    end
    return quote,'AVAILABLE'
end
