local _, W = ...
W.Diagnostics = {}
local D = W.Diagnostics
function D:Record(level, message)
    local logs = W.runtime.logs
    logs[#logs + 1] = {at = W.Clock(), level = tostring(level), message = tostring(message)}
    if #logs > W.runtime.logMax then table.remove(logs, 1) end
    if level == 'ERROR' then W.runtime.lastError = tostring(message) end
    W.Refresh()
end
local function yes(v) return v and 'YES' or 'NO' end
function D:BuildReport()
    local b, scope, s, scan = W.Compat.build, W.Scope:Snapshot(), W.Storage, W.Scan
    local dbScope = W.Scope:ReadMarketKey()
    local m = s:GetMarket(dbScope)
    local last = m and m.snapshots[1]
    local a, c = s.restoredAtLoad or {}, s.character and s.character.sentinel or {}
    local lines = {
        'WEALTHCRAFT / FIELD REPORT (no character name)',
        'Addon ' .. W.version .. ' | Schema ' .. W.schemaVersion,
        'Client ' .. b.version .. ' | Build ' .. b.build .. ' | Interface ' .. b.interface,
        'Client classification ' .. b.status,
        'Storage ' .. tostring(s.status) .. ' | Earlier markers loaded: ' .. yes(s.restoreObserved),
        'Full relog/restart recovery: NOT VERIFIED BY ADDON',
        'Schema migration v2->v3 this session: ' .. yes(s.migratedG3),
        'G3->G4 migration this session: ' .. yes(s.migratedG4),
        'Market/history preserved from G2: ' .. yes(s.account and s.account.marketHistory ~= nil),
        'Optional save-marker recovery observation: ' .. (s:PersistenceReady() and 'PASS (reload markers only)' or 'NOT MET'),
        'Migrated alpha v1 to v2 this session: ' .. yes(s.migrated),
        'Marker at load: account=' .. tostring(a.accountCount) .. ' character=' .. tostring(a.characterCount),
        'Marker now: account=' .. tostring(s.account and s.account.sentinel.count) ..
            ' character=' .. tostring(c.count),
        'Native Auction House open: ' .. yes(W.runtime.ahOpen),
        'AH session epoch: ' .. W.runtime.ahSession,
        'Market context: ' .. scope.display,
        'Market scope status: ' .. scope.status,
        'Context readiness: '..yes(scope.ready)..' | '..tostring(scope.reason or 'READY'),
        'Identity source: '..tostring(scope.identitySource or W.runtime.venueSource)..' | Mode: '..tostring(scope.identityMode or 'OBSERVED'),
        'Missing optional metadata: '..(type(scope.missingFields)=='table' and #scope.missingFields>0 and table.concat(scope.missingFields,', ') or 'none'),
        'Region: '..tostring(scope.region)..' | Realm ID: '..tostring(scope.realmID)..' | Realm name: '..tostring(scope.realm),
        'Faction: '..tostring(scope.faction)..' | Map: '..tostring(scope.mapID)..' | Auctioneer: '..tostring(scope.auctioneerID),
        'Automatic location partitions do not assume that separate auctioneers share one market.',
        'Active/last market key: ' .. tostring(dbScope),
        'Distinct stored markets: ' .. tostring(s:MarketCount()),
        'Scan state: ' .. scan.state .. ' | ' .. scan.message,
        'Scan event association: ' .. scan.eventAssociation,
        'Scan result events: ' .. tostring(scan.eventCount),
        'Expected/processed/handled: ' .. tostring(scan.expected) .. '/' .. scan.processed .. '/' .. scan.handled,
        'Precise rows: ' .. scan.precise .. ' | Ambiguous links: ' .. scan.ambiguous,
        'Invalid: ' .. scan.invalid .. ' | Unresolved: ' .. scan.unresolved,
        'Last complete snapshot: ' .. (last and (last.id .. ' ' .. last.finishedAt) or 'none'),
        'Complete snapshot auction count: ' .. (last and last.count or 'n/a'),
        'Complete snapshot variant groups: ' .. (last and last.preciseCount or 'n/a'),
        'Last partial exact-link sample: ' .. (m and m.partial and m.partial.id or 'none'),
        'Partial handled/unresolved/expected: ' .. (m and m.partial and
            (tostring(m.partial.handled)..'/'..tostring(m.partial.unresolved)..'/'..tostring(m.partial.count)) or 'n/a'),
        'Last account replication request: ' .. tostring(s:LastRequestTime()),
        'Local replication guard: 900 seconds; other addons not observable',
        'Source: full and targeted scans; prices are OBSERVED listings, not sales.',
        'Target search: ' .. W.Targeted.state .. ' | ' .. W.Targeted.message,
        'Target event association: ' .. W.Targeted.association,
        'Target rows processed: ' .. W.Targeted.processed .. '/' .. tostring(W.Targeted.expected),
        'Watchlist entries: ' .. #(s:WatchEntries()),
        'Bags: ' .. (W.Inventory.snapshot and W.Inventory.snapshot.status or 'NOT_SCANNED'),
        'Tooltip hook: ' .. (W.Tooltips and W.Tooltips.installStatus or 'NOT_LOADED'),
        'Tooltip preference: ' .. (s.account and s.account.settings.tooltipMode or 'UNAVAILABLE'),
        'External AH tooltip addon conflict: ' .. yes(W.Tooltips and W.Tooltips:Conflicts()),
        'Assumed selling fee (basis points): ' .. tostring(s:AssumedFeeBps()),
        'Manual ledger entries: ' .. tostring(W.Ledger:Summary().entries),
        'Last crafting status: ' .. tostring(W.Crafting.last and W.Crafting.last.status or 'NOT_EVALUATED'),
        'Bounded AH-open read-only refresh; commodity execution only for one user-authorized order within its displayed cap; no inferred sales.',
        'Price method: quantity-weighted lower-quartile approximation, 5% buckets.',
        'G6 Auction Desk active: ' .. yes(W.AuctionDesk and W.AuctionDesk.active),
        'G6 Blizzard visual fallback: ' .. yes(W.AuctionDesk and W.AuctionDesk.fallback),
        'G6 unified auction desk enabled: ' .. yes(s.account and s.account.settings.auctionDeskEnabled~=false),
        'G6 Browse: ' .. (W.Browse and (W.Browse.state..' / '..W.Browse.message) or 'NOT_LOADED'),
        'G6 Owned auctions/bids: ' .. (W.Owned and (W.Owned.state..' / '..W.Owned.message) or 'NOT_LOADED'),
        'G6 Trade: ' .. (W.Trading and (W.Trading.state..' / '..W.Trading.message) or 'NOT_LOADED'),
        'G6 Native action signatures and behavior: NOT YET REAL-CLIENT VALIDATED',
        'Available APIs (presence NOT runtime verification):',
    }
    local keys = {
        'ReplicateItems','GetNumReplicateItems','GetReplicateItemInfo',
        'GetReplicateItemLink','IsThrottledMessageSystemReady',
        'SendSearchQuery','MakeItemKey','SearchForItemKeys','GetItemKeyInfo',
        'GetNumItemSearchResults','GetItemSearchResultInfo','HasFullItemSearchResults',
        'GetNumCommoditySearchResults','GetCommoditySearchResultInfo','HasFullCommoditySearchResults',
        'RequestMoreItemSearchResults','RequestMoreCommoditySearchResults',
        'SendBrowseQuery','GetBrowseResults','RequestMoreBrowseResults',
        'QueryOwnedAuctions','GetOwnedAuctions','QueryBids','GetBids',
        'PlaceBid','PostItem','PostCommodity','CancelAuction','CanCancelAuction',
        'StartCommoditiesPurchase','ConfirmCommoditiesPurchase',
    }
    for _, key in ipairs(keys) do
        lines[#lines + 1] = '  ' .. key .. ': ' .. yes(W.Compat.APIs and W.Compat.APIs[key])
    end
    local ctx=W.Scope:ReadContext()
    lines[#lines+1]='G6 read context: '..tostring(ctx.mode)..' / '..tostring(ctx.key)
    lines[#lines+1]='Identity metadata describes the frozen current visit; unknown fields do not block live reads.'
    for _,key in ipairs({'build','region','realmID','realm','faction','mapID','auctioneerID','guidNamespace',
        'gameModeRecordID','activeGameMode','regionalNames','hardcore','roleplay','pvp'})do
        local value=scope[key]
        local observed=value~=nil and value~='' and value~=0
        local native=scope.metadataState and scope.metadataState[key=='auctioneerID' and 'auctioneer' or key]
        lines[#lines+1]='Identity field '..key..': '..(native or (observed and ('OBSERVED ('..tostring(value)..')') or 'UNAVAILABLE'))
    end
    lines[#lines+1]='Market files loaded this session: '..tostring(W.Storage.loadedMarketCount or 0)
    lines[#lines+1]='Cache rows initially pending / recovered: '..tostring(W.Scan.initialPending or 0)..' / '..tostring(W.Scan.recovered or 0)
    lines[#lines+1]='Cache retry passes: '..tostring(W.Scan.retries or 0)..' / '..tostring(W.Scan.retryLimit)
    lines[#lines+1]='Metadata requests / successes: '..tostring(W.ItemCache.requests or 0)..' / '..tostring(W.ItemCache.loaded or 0)
    local cp=W.ItemCache:Progress()
    lines[#lines+1]='Metadata queue: '..cp.distinct..' unique / '..cp.submitted..' issued / '..cp.queued..' waiting / '..cp.requested..' inflight'
    lines[#lines+1]='Full-scan index coverage is not proof of market depth when rows are uncached.'
    lines[#lines+1]='G7 browse quality filters exclude unsupported HeirloomQuality=13.'
    lines[#lines+1]='G8 commodity quote: an explicit maximum-total authorization is enforced; higher quotes require a new physical approval.'
    lines[#lines+1]='Quick refresh: '..W.QuickScan.state..' / issued '..W.QuickScan.issued..
        ' / complete '..W.QuickScan.completed..' / skipped '..tostring(W.QuickScan.skipped or 0)..
        ' / deferrals '..tostring(W.QuickScan.deferAttempts or 0)
    local hold=W.Trading:Unverified()
    lines[#lines+1]='G9 unverified transaction (requires manual check): '..(hold and
        (hold.kind..' / '..tostring(hold.itemID or 'unknown')..' / '..tostring(hold.at)) or 'none')
    lines[#lines+1]='Venue source: '..tostring(W.runtime.venueSource)
    local automatic=W.Automation or {}
    lines[#lines+1]='Full refresh queue: '..tostring(automatic.state)..' | reason='..tostring(automatic.reason or 'none')..
        ' | wait='..tostring(automatic.waitKind or 'none')..' | readiness attempts='..tostring(automatic.attempts or 0)..
        ' | native request attempted='..yes(automatic.requestAttempted)
    lines[#lines+1]='Quick refresh reason: '..tostring(W.QuickScan.reason or 'none')..' | pause='..tostring(W.QuickScan.pauseKind or 'none')..
        ' | auto resume='..yes(W.QuickScan.autoResume)..' | user paused='..yes(automatic:IsUserPaused())..' | context wait='..yes(W.QuickScan.contextWait~=nil)
    local pending=W.UI and W.UI.pendingSearch
    lines[#lines+1]='Queued foreground search: '..(pending and (tostring(pending.kind)..' | session='..tostring(pending.session)) or 'none')
    lines[#lines+1]='Commodity tolerance basis points: '..W.Trading:Tolerance()
    lines[#lines+1]='Replicate row API calls: '..tostring(W.Scan.readCalls or 0)
    lines[#lines+1]='Measured max slice ms (if profiler available): '..tostring(W.Scan.maxSliceMS or 'not measured')
    lines[#lines+1]='Integration: '..tostring(W.Integration.mode)..'; MirageUI private state never modified'
    lines[#lines + 1] = 'Runtime log (latest first):'
    for i = #W.runtime.logs, math.max(1, #W.runtime.logs - 24), -1 do
        local l = W.runtime.logs[i]
        lines[#lines + 1] = tostring(l.at) .. ' ' .. l.level .. ' ' .. l.message
    end
    lines[#lines+1]=''
    lines[#lines+1]=W.StartupReport()
    return table.concat(lines, '\n')
end
function D:PrintSummary()
    W.Notify('Client: ' .. W.Compat:Format())
    W.Notify('Storage: ' .. tostring(W.Storage.status) .. ' / AH: ' .. (W.runtime.ahOpen and 'open' or 'closed'))
    W.Notify('Full scan: ' .. tostring(W.Scan.state) .. ' / ' .. tostring(W.Scan.message))
    W.Notify('Targeted: ' .. tostring(W.Targeted.state) .. ' / ' .. tostring(W.Targeted.message))
    W.Notify('Use /wc report to copy complete test evidence.')
end
