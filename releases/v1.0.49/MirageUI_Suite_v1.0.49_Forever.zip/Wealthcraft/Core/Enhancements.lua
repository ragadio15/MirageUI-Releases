local _,W=...
W.Enhancements={}
local E=W.Enhancements
function E:Initialize()
    if W.Storage:IsWritable() then
        local s=W.Storage.account.settings
        if s.autoScan==nil then s.autoScan=true end
        for k,v in pairs({quickScan=true,autoFullScan=true,personalize=true,
            priceToleranceBps=200,showItemIDs=true}) do if s[k]==nil then s[k]=v end end
        if not W.Math.ValidInteger(s.priceToleranceBps,0,1000) then s.priceToleranceBps=200 end
    end
    local stored=W.Storage.character and W.Storage.character.p28Bank
    if type(stored)=='table' and type(stored.rows)=='table' then
        W.PlayerContext.bank=stored;stored.current=false;stored.status='CACHED'
    end
    W.ItemKinds:Initialize();W.PlayerContext:Refresh()
    if W.Automation then W.Automation:Initialize() end
end
-- User-friendly recipe lookup limited to known recipes observed in the profession UI.
W.Crafting.known={}
function W.Crafting:CacheKnown()
    local a=C_TradeSkillUI
    if type(a)~='table' then return end
    local ok,ids=W.SafeCall(a.GetAllRecipeIDs)
    if not ok or type(ids)~='table' then return end
    local count=0
    for examined,id in ipairs(ids) do
        if count>=2000 or examined>4000 then break end
        local good,info=W.SafeCall(a.GetRecipeInfo,id)
        if good and type(info)=='table' and info.learned==true and type(info.name)=='string' and
            W.Math.ValidInteger(id,1) then self.known[id]={id=id,name=info.name};count=count+1 end
    end
end
function W.Crafting:Resolve(text)
    local id=tonumber(text)
    if W.Math.ValidInteger(id,1,999999999) then return id end
    self:CacheKnown();local found
    local name=tostring(text or ''):lower():match('^%s*(.-)%s*$')
    for recipeID,r in pairs(self.known)do
        if r.name:lower()==name then
            if found and found~=recipeID then return nil,'Several recipes share that name. Select one in Professions.' end
            found=recipeID
        end
    end
    if found then return found end
    return found,'Open your profession, then choose a learned recipe or enter its recipe ID.'
end

-- Remember a bounded recent-item queue, not a character identity or automatic trade.
local targetRequest=W.Targeted.Request
function W.Targeted:Request(key,origin,displayItem)
    key=W.ItemKinds:ObserveKey(key)
    local ok,why=targetRequest(self,key,origin,displayItem)
    if ok and origin~='QUICK_OPEN' and W.Storage:IsWritable() then
        local db=W.Storage.character;local token=W.Storage:WatchKey(key)
        local old=type(db.g8RecentItems)=='table' and db.g8RecentItems or {};local fresh={key}
        for _,item in ipairs(old)do
            if #fresh>=12 then break end
            if W.Storage:WatchKey(item)~=token then fresh[#fresh+1]=item end
        end
        db.g8RecentItems=fresh
    end
    return ok,why
end

local p39CacheKnown=W.Crafting.CacheKnown
function W.Crafting:CacheKnown(...)
    local service,started=W.P39TraceBegin()
    local result=p39CacheKnown(self,...)
    W.P39TraceEnd(service,started,'wealth.recipe_discovery')
    return result
end
