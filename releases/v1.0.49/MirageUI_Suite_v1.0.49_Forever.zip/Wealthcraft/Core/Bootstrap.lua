-- Loaded FIRST: recovery commands must not depend on market events or the UI.
local addonName, W = ...
W.addonName = addonName
W.version = '0.13.39'
W.schemaVersion = 4 -- G9 uses additive, validated character-only caution state; no migration or reset.
W.targetBuild, W.targetInterface, W.targetVersion = 71037, 16001, '1.60.1'
W.runtime = {
    startedAt = GetTime and GetTime() or 0, initialized = false, loggedIn = false,
    uiReady = false, startupStage = 'BOOTSTRAP', ahOpen = false, ahSession = 0,
    venueRole = nil, logs = {}, logMax = 50, lastError = nil,
    faults = {}, faultNotices = {}, registeredEvents = {}, rejectedEvents = {},
}
function W.Clock()
    if type(GetServerTime) == 'function' then
        local ok, t = pcall(GetServerTime)
        if ok and type(t) == 'number' and t > 0 then return math.floor(t) end
    end
    return type(time) == 'function' and time() or 0
end
W.Math = {}
function W.Math.ValidNumber(v)
    return type(v) == 'number' and v == v and v > -math.huge and v < math.huge
end
function W.Math.ValidInteger(v, low, high)
    return W.Math.ValidNumber(v) and v == math.floor(v) and v >= (low or 0) and v <= (high or 9007199254740991)
end
function W.SafeCall(fn, ...)
    if type(fn) ~= 'function' then return false, 'API_MISSING' end
    return pcall(fn, ...)
end
function W.Notify(message)
    if DEFAULT_CHAT_FRAME and type(DEFAULT_CHAT_FRAME.AddMessage) == 'function' then
        pcall(DEFAULT_CHAT_FRAME.AddMessage, DEFAULT_CHAT_FRAME, '|cffe3bd7eWealthcraft|r  ' .. tostring(message))
    elseif type(print) == 'function' then print('Wealthcraft: ' .. tostring(message)) end
end
function W.RecordFault(stage, errorText)
    local r = W.runtime
    local text = tostring(errorText):sub(1, 750)
    r.lastError = stage .. ': ' .. text
    -- Do not call Diagnostics:Record here: that function refreshes the UI.
    r.faults[#r.faults + 1] = {at=W.Clock(), stage=stage, message=text}
    if #r.faults > 20 then table.remove(r.faults, 1) end
    r.logs[#r.logs + 1] = {at=W.Clock(), level='ERROR', message=r.lastError}
    if #r.logs > r.logMax then table.remove(r.logs, 1) end
    if not r.faultNotices[stage] then
        r.faultNotices[stage] = true
        W.Notify('An error was caught in ' .. stage .. '. Use /wc startup for details; /wc blizzard restores the native Auction House.')
    end
end
function W.Try(stage, fn, ...)
    if type(fn) ~= 'function' then
        W.RecordFault(stage, 'Required function was not loaded.'); return false, 'FUNCTION_NOT_LOADED'
    end
    local ok, a, b, c = pcall(fn, ...)
    if not ok then W.RecordFault(stage, a) end
    return ok, a, b, c
end
function W.HasEvent(name)
    return W.runtime.registeredEvents[name] == true
end
function W.StartupReport()
    local r = W.runtime
    local lines = {'WEALTHCRAFT / STARTUP RECOVERY REPORT',
        'Version: '..W.version..' | Schema: '..W.schemaVersion,
        'Stage: '..tostring(r.startupStage),
        'Core initialized: '..tostring(r.initialized)..' | UI ready: '..tostring(r.uiReady),
        'Commands: /wc /wealthcraft (registered in first TOC file)',
        'Auction session open: '..tostring(r.ahOpen),
        'Latest error: '..tostring(r.lastError or 'none'), 'Event registration:'}
    local names={}
    for name in pairs(r.registeredEvents) do names[#names+1]=name end
    table.sort(names)
    for _,name in ipairs(names) do
        lines[#lines+1]='  '..name..': '..(r.registeredEvents[name] and 'REGISTERED' or
            ('UNAVAILABLE - '..tostring(r.rejectedEvents[name])))
    end
    lines[#lines+1]='Caught errors (oldest first, bounded to 20):'
    for _,f in ipairs(r.faults) do lines[#lines+1]=f.at..' '..f.stage..' '..f.message end
    lines[#lines+1]='No SavedVariables were reset by recovery. Real-client testing remains necessary.'
    return table.concat(lines, '\n')
end
function W.ShowStartupReport()
    -- Independent from Widgets, Storage and UI/Main; usable after their failure.
    local report = W.StartupReport()
    local ok, err = pcall(function()
        local f = W.recoveryFrame
        if not f then
            f=CreateFrame('Frame','WealthcraftRecoveryFrame',UIParent)
            f:SetSize(720,470);f:SetPoint('CENTER');f:SetFrameStrata('FULLSCREEN_DIALOG')
            f:SetClampedToScreen(true);f:EnableMouse(true)
            local bg=f:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints(f);bg:SetColorTexture(0.055,0.065,0.075,1)
            local title=f:CreateFontString(nil,'OVERLAY','GameFontNormalLarge')
            title:SetPoint('TOPLEFT',18,-18);title:SetText('Wealthcraft / Startup report  -  Ctrl+A, Ctrl+C to copy')
            local close=CreateFrame('Button',nil,f,'UIPanelButtonTemplate')
            close:SetSize(75,25);close:SetPoint('BOTTOMRIGHT',-18,12);close:SetText('Close')
            close:SetScript('OnClick',function()f:Hide()end)
            local scroll=CreateFrame('ScrollFrame',nil,f,'UIPanelScrollFrameTemplate')
            scroll:SetPoint('TOPLEFT',18,-55);scroll:SetPoint('BOTTOMRIGHT',-38,48)
            local edit=CreateFrame('EditBox',nil,scroll)
            edit:SetMultiLine(true);edit:SetAutoFocus(false);edit:SetFontObject('ChatFontNormal')
            edit:SetWidth(650);edit:SetHeight(360);edit:SetMaxLetters(0)
            edit:SetScript('OnEscapePressed',function()f:Hide()end)
            scroll:SetScrollChild(edit);f.edit=edit;W.recoveryFrame=f
        end
        f.edit:SetText(report);f:Show();f.edit:SetFocus();f.edit:HighlightText()
    end)
    if not ok then
        W.Notify('Startup stage: '..W.runtime.startupStage..'; '..tostring(W.runtime.lastError or err))
    end
    return report
end
function W.RestoreBlizzard(reason)
    if W.AuctionDesk and type(W.AuctionDesk.NativeFallback)=='function' then
        local ok, err=pcall(W.AuctionDesk.NativeFallback,W.AuctionDesk,reason)
        if not ok then W.RecordFault('native-fallback',err) end
    end
end
function W.RegisterCommands()
    if type(SlashCmdList)~='table' then return false end
    SLASH_WEALTHCRAFT1,SLASH_WEALTHCRAFT2='/wealthcraft','/wc'
    SlashCmdList.WEALTHCRAFT=function(message)
        local cmd=tostring(message or ''):lower():match('^%s*(%S+)') or ''
        if cmd=='startup' then W.ShowStartupReport();return end
        if cmd=='blizzard' then W.RestoreBlizzard('Player requested Blizzard view.');return end
        if not W.runtime.initialized or not W.runtime.uiReady or type(W.CommandHandler)~='function' then
            W.Notify('Startup is incomplete ('..W.runtime.startupStage..'). Opening recovery report; saved data is unchanged.')
            W.ShowStartupReport();return
        end
        local ok=W.Try('slash-command',W.CommandHandler,message)
        if not ok then W.RestoreBlizzard('Command error.');W.ShowStartupReport() end
    end
    return true
end
W.RegisterCommands()
local refreshing=false
function W.Refresh()
    if refreshing or not W.runtime.initialized or not W.runtime.uiReady then return end
    refreshing=true
    if W.UI and type(W.UI.Refresh)=='function' then W.Try('ui-refresh',W.UI.Refresh,W.UI) end
    if W.AuctionDesk and type(W.AuctionDesk.Refresh)=='function' then
        local ok=W.Try('desk-refresh',W.AuctionDesk.Refresh,W.AuctionDesk)
        if not ok then W.RestoreBlizzard('Desk refresh failed.') end
    end
    refreshing=false
end
-- A tiny independent watchdog reports failures even if the last TOC file never runs.
local ok, bootFrame=pcall(CreateFrame,'Frame')
if ok and bootFrame then
    bootFrame:SetScript('OnEvent',function()
        W.RegisterCommands()
        if not W.runtime.initialized then
            W.Notify('Wealthcraft '..W.version..' did not finish loading. Type /wc startup; do not delete saved data.')
        end
    end)
    pcall(bootFrame.RegisterEvent,bootFrame,'PLAYER_LOGIN')
end

function W.QueryBusy(except)
    if except~='scan' and W.Scan and W.Scan:IsActive() and not W.Scan.pausedForUser then return true end
    if except~='quickTarget' and W.QuickTarget and W.QuickTarget:IsActive() then return true end
    if except~='target' and W.Targeted and W.Targeted:IsActive() then return true end
    for _,spec in ipairs({{'browse',W.Browse},{'owned',W.Owned}}) do
        local name,service=spec[1],spec[2]
        if service and service.CheckTimeout then service:CheckTimeout() end
        if name~=except and service and (service.state=='REQUESTED' or service.state=='RETIRED') then return true end
    end
    return except~='trade' and W.Trading and W.Trading.state~='IDLE' or false
end

-- P39-A: read-only, session-only measurement through the public utility API.
function W.P39TraceBegin()
    local core=MirageIntelCoreAPI
    if type(core)~='table' or type(core.GetService)~='function' then return end
    local ok,service=pcall(core.GetService,'Performance',1)
    if not ok or type(service)~='table' or type(service.Begin)~='function' then return end
    local success,started=pcall(service.Begin)
    if success and type(started)=='number' then return service,started end
end
function W.P39TraceEnd(service,started,channel)
    if service and started and type(service.Finish)=='function' then
        pcall(service.Finish,channel,started)
    end
end
