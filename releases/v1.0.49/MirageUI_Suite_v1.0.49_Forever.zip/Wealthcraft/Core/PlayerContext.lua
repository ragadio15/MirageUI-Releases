-- P28: one observed character context shared with the suite, with standalone fallback.
local _,W=...
W.PlayerContext={data={},bags={},bank={status='NOT_OBSERVED',current=false,rows={}}}
local P=W.PlayerContext
local function value(fn,...)
    local ok,v=W.SafeCall(fn,...);if ok then return v end
end
local function core()return _G.MirageIntelCoreAPI or _G.MirageIntel_API end
function P:SyncShared()
    local function unavailable()
        -- A previously copied shared result cannot stay current after its
        -- provider becomes unavailable. Native fallback may establish a fresh
        -- observation, but a failed service read must never certify old rows.
        if self.shared then
            self.shared=nil;self.sharedRevision=nil
            if self.bagRecord then self.bagRecord.current=false end
            if self.bank then self.bank.current=false end
        end
        return false
    end
    local api=core()
    if type(api)~='table' or type(api.GetCharacterSnapshot)~='function' then return unavailable() end
    local revision
    if type(api.GetCharacterRevision)=='function' then
        local valid,reported=pcall(api.GetCharacterRevision)
        if valid and type(reported)=='table' then
            revision=table.concat({tostring(reported.revision),tostring(reported.bagsRevision),
                tostring(reported.bankRevision),tostring(reported.refreshPending),
                tostring(reported.bagsCurrent),tostring(reported.bankCurrent),
                tostring(reported.bankOpen)},':')
            if revision==self.sharedRevision and self.shared then
                self.sharedReuses=(self.sharedReuses or 0)+1
                return true
            end
        end
    end
    local ok,s=pcall(api.GetCharacterSnapshot)
    if not ok or type(s)~='table' then return unavailable() end
    self.sharedRevision=revision
    self.sharedReads=(self.sharedReads or 0)+1
    self.shared=s
    if type(s.bags)=='table' then self.bagRecord=s.bags;self.bagSource='MIRAGEUI_SHARED_CONTEXT' end
    if type(s.bank)=='table' then self.bank=s.bank end
    return true
end
function P:Refresh()
    self:SyncShared()
    local shared=self.shared;local d=shared and (shared.character or shared.data or shared)
    local class,classID
    if type(UnitClass)=='function' then local ok,a,b,id=W.SafeCall(UnitClass,'player');if ok then class,classID=a or b,id end end
    local race,raceToken
    if type(UnitRace)=='function' then local ok,a,b=W.SafeCall(UnitRace,'player');if ok then race,raceToken=a,b end end
    local map=C_Map and value(C_Map.GetBestMapForUnit,'player')
    local info=map and C_Map and value(C_Map.GetMapInfo,map)
    local level=value(UnitLevel,'player');local professions={};local professionsCurrent=false
    if type(d)=='table' and d.professionsCurrent==true and type(d.professions)=='table' then professions=d.professions;professionsCurrent=true
    elseif type(GetProfessions)=='function' and type(GetProfessionInfo)=='function' then
        local ok,a,b,c,e,f=pcall(GetProfessions)
        if ok then professionsCurrent=true;for _,idx in pairs({a,b,c,e,f})do
            local good,name,icon,rank,maximum,_,_,skill=pcall(GetProfessionInfo,idx)
            if good and type(name)=='string' then professions[#professions+1]={name=name,icon=icon,rank=rank,max=maximum,skillLineID=skill}else professionsCurrent=false end
        end end
    end
    self.data={class=class or d and d.class,classID=classID or d and d.classID,race=race,raceToken=raceToken,
        level=W.Math.ValidInteger(level,1,999) and level or d and d.level,
        faction=value(UnitFactionGroup,'player') or d and d.faction,mapID=map or d and d.mapID,
        realm=value(GetRealmName) or d and d.realm,realmID=value(GetRealmID) or d and d.realmID,
        region=value(GetCurrentRegion) or d and d.region,
        location=type(info)=='table' and info.name or value(GetRealZoneText) or d and d.location or 'Current location',
        professions=professions,professionsCurrent=professionsCurrent,at=W.Clock(),source=shared and 'MIRAGEUI_SHARED_CONTEXT' or 'NATIVE_OBSERVATION'}
    if W.Storage:IsWritable() and W.Storage.character then W.Storage.character.g8Context=self.data end
    return self.data
end
local function rawSlots(ids)
    local rows={};local c=C_Container
    if type(c)~='table' or type(c.GetContainerNumSlots)~='function' or type(c.GetContainerItemInfo)~='function' then return nil end
    for _,bag in ipairs(ids)do
        local ok,n=pcall(c.GetContainerNumSlots,bag)
        if not ok or not W.Math.ValidInteger(n,0,256) then return nil end
        for slot=1,n do
            local good,info=pcall(c.GetContainerItemInfo,bag,slot)
            if not good or (info~=nil and type(info)~='table') then return nil end
            if info and W.Math.ValidInteger(info.itemID,1) and W.Math.ValidInteger(info.stackCount,1,100000000) then
                rows[#rows+1]={bag=bag,slot=slot,itemID=info.itemID,count=info.stackCount,
                    name=info.itemName,itemLink=info.hyperlink,icon=info.iconFileID or info.icon,
                    quality=info.quality,isBound=info.isBound,locked=info.isLocked}
            end
        end
    end
    return rows
end
function P:RawBags()
    self:SyncShared()
    local shared=self.shared and self.shared.bags
    if type(shared)=='table' and shared.current==true and shared.status=='READY' and type(shared.rows)=='table' then
        return shared.rows,'MIRAGEUI_SHARED_CONTEXT',shared
    end
    local ids={};local last=tonumber(NUM_BAG_SLOTS) or 4
    last=math.max(0,math.min(6,last))
    for id=0,last do ids[#ids+1]=id end
    local reagent=Enum and Enum.BagIndex and Enum.BagIndex.ReagentBag
    if W.Math.ValidInteger(reagent,last+1,1024) then ids[#ids+1]=reagent end
    local rows=rawSlots(ids)
    return rows,'NATIVE_OBSERVATION',{at=W.Clock(),status=rows and 'READY' or 'UNAVAILABLE',current=rows~=nil,rows=rows or {}}
end
function P:ReadBags()
    local raw,source,record=self:RawBags()
    local revision=record and record.revision
    local market=W.Scope and W.Scope:ReadMarketKey()
    if source=='MIRAGEUI_SHARED_CONTEXT' and record and record.current==true and
        self.bagSource==source and self.bagRecord==record and self.bagRevision==revision and
        self.bagMarketKey==market and type(self.bags)=='table' then
        self.bagCacheHits=(self.bagCacheHits or 0)+1
        return self.bags
    end
    local rows={};local a=W.Compat.auction or {}
    for _,info in ipairs(raw or {})do
        local loc=ItemLocation and value(ItemLocation.CreateFromBagAndSlot,ItemLocation,info.bag,info.slot)
        local key=loc and value(a.GetItemKeyFromItem,loc)
        local status=loc and value(a.GetItemCommodityStatus,loc)
        if status==2 and W.ItemKinds then W.ItemKinds:Learn(info.itemID)end
        local observed=type(key)=='table' and key.itemID==info.itemID
        key=type(key)=='table' and key or {itemID=info.itemID,itemLevel=0,itemSuffix=0,battlePetSpeciesID=0}
        if W.ItemKinds then key=W.ItemKinds:Key(key)end
        local allow=loc and value(a.IsSellItemValid,loc,false)
        local name=info.name or (type(info.itemLink)=='string' and info.itemLink:match('%[([^%]]+)%]'))
        rows[#rows+1]={bag=info.bag,slot=info.slot,itemID=info.itemID,count=info.count,
            name=name or ('Item '..info.itemID),itemLink=info.itemLink,itemKey=key,observedItemKey=observed or status==2,icon=info.icon,
            quality=info.quality,isBound=info.isBound==true,locked=info.locked==true,
            sellable=allow==true and info.isBound~=true,commodity=status==2}
    end
    self.bags=rows;self.bagRecord=record;self.bagSource=source
    self.bagRevision=revision;self.bagMarketKey=market
    self.bagRebuilds=(self.bagRebuilds or 0)+1
    return rows
end
function P:ReadBank()
    if not W.runtime.bankOpen then
        self.bank.current=false;return self.bank
    end
    self:SyncShared()
    if self.shared and type(self.shared.bank)=='table' then return self.bank end
    local ids={};local bankType=Enum and Enum.BankType and Enum.BankType.Character
    if C_Bank and type(C_Bank.FetchPurchasedBankTabIDs)=='function' and bankType~=nil then
        local ok,tabs=pcall(C_Bank.FetchPurchasedBankTabIDs,bankType)
        if ok and type(tabs)=='table' then for _,id in ipairs(tabs)do if W.Math.ValidInteger(id,0,1000)then ids[#ids+1]=id end end end
    elseif type(BANK_CONTAINER)=='number' then
        ids[1]=BANK_CONTAINER
        local n=tonumber(NUM_BANKBAGSLOTS) or 0;local first=(tonumber(NUM_BAG_SLOTS) or 4)+1
        for id=first,first+math.min(n,12)-1 do ids[#ids+1]=id end
    end
    local rows=#ids>0 and rawSlots(ids) or nil
    if rows then
        self.bank={status='READY',current=true,at=W.Clock(),rows=rows,source='OPEN_CHARACTER_BANK'}
        if W.Storage:IsWritable() then W.Storage.character.p28Bank=self.bank end
    else self.bank.current=false;self.bank.status='UNAVAILABLE' end
    return self.bank
end
function P:RequestRefresh(reason,includeBank,includeProfessions)
    local api=core()
    if type(api)=='table' and type(api.RequestCharacterRefresh)=='function' then
        local ok,result=pcall(api.RequestCharacterRefresh,reason,includeBank==true,includeProfessions==true)
        if ok and result~=false then self:Refresh();return true end
    end
    self:Refresh();self:ReadBags()
    if includeBank then self:ReadBank()end
    if W.Storage:IsWritable() then W.Storage.character.p28Bags=self.bagRecord end
    return true
end
function P:Summary()
    local d=self.data;local s={}
    if d.level then s[#s+1]='Level '..d.level end
    if d.race then s[#s+1]=d.race end
    if d.class then s[#s+1]=d.class end
    return table.concat(s,' · ')
end
function P:Snapshot()
    self:SyncShared()
    local function copy(t,depth)
        if type(t)~='table' then return t end
        if depth>6 then return nil end
        local out={};local n=0;for k,v in pairs(t)do n=n+1;if n>2000 then break end;out[k]=copy(v,depth+1)end;return out
    end
    return copy({character=self.data,bags=self.bagRecord,bank=self.bank},0)
end
