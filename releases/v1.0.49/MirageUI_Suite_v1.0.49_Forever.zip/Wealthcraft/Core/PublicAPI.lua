local _, W = ...
local subscriptions, seq = {}, 0
local events = {STATE_CHANGED = true, SETTINGS_CHANGED = true, MARKET_SNAPSHOT_READY = true,
    TARGET_QUERY_READY = true, WATCHLIST_CHANGED = true, INVENTORY_UPDATED = true}
function W.Publish(event, payload)
    if not events[event] then return end
    if event=='MARKET_SNAPSHOT_READY' or event=='TARGET_QUERY_READY' then
        if W.PriceView then W.PriceView:Invalidate(event)end
        if type(payload)=='table' and W.Inventory and W.Inventory.MarketUpdated then
            W.Inventory:MarketUpdated(payload.marketKey)
        end
    end
    -- Subscribers may unsubscribe or add a subscriber from their callback.
    if not next(subscriptions) then return end
    local tokens={}
    for token,record in pairs(subscriptions) do
        if record.event==event then tokens[#tokens+1]=token end
    end
    table.sort(tokens)
    for _,token in ipairs(tokens) do
        local record=subscriptions[token]
        if record then
            -- These notifications carry scalar fields only.
            local delivered=payload
            if type(payload)=='table' then
                delivered={}
                for k,v in pairs(payload) do delivered[k]=v end
            end
            local ok, err = pcall(record.fn, delivered)
            if not ok then W.Diagnostics:Record('WARN', 'Public subscriber error: ' .. tostring(err)) end
        end
    end
end
_G.WealthcraftAPI = {
    apiVersion = 6,
    -- Additive contract: existing v6 callers and base-item crafting estimates
    -- retain their behavior. This operation accepts a complete item link only.
    quoteContractVersion = 1,
    priceViewContractVersion = 1,
    dataLanguageContractVersion = 1,
    scanStatusContractVersion = 2,
    tooltipSectionContractVersion = 1,
    GetDataLanguage = function()return W.DataLanguage:Copy()end,
    GetPriceViewForItemLink = function(link, context)
        if not W.PriceView then return nil,'PRICE_VIEW_UNAVAILABLE'end
        local ok,view,reason=pcall(W.PriceView.Get,W.PriceView,link,context)
        if not ok then return nil,'PROVIDER_DATA_UNREADABLE'end
        return view,reason
    end,
    SelectPriceView = function(kind,link,context)
        if not W.PriceView then return nil,'PRICE_VIEW_UNAVAILABLE'end
        local ok,view,reason=pcall(W.PriceView.Select,W.PriceView,kind,link,context)
        if not ok then return nil,'PROVIDER_DATA_UNREADABLE'end
        return view,reason
    end,
    GetPriceTrace = function(link,context)
        if not W.PriceView then return nil,'PRICE_VIEW_UNAVAILABLE'end
        local ok,trace=pcall(W.PriceView.Trace,W.PriceView,link,context)
        if not ok then return nil,'TRACE_UNAVAILABLE'end
        return trace,'AVAILABLE'
    end,
    GetScanStatus = function()
        if W.ScanCoordinator then return W.ScanCoordinator:Status()end
        return {state='UNAVAILABLE',readOnly=true}
    end,
    GetQuoteForItemLink = function(link, context)
        if not W.ItemLinkBridge then return nil, 'LINK_BRIDGE_UNAVAILABLE' end
        local ok, quote, reason = pcall(W.ItemLinkBridge.Get, W.ItemLinkBridge, link, context)
        if not ok then return nil, 'PROVIDER_DATA_UNREADABLE' end
        return quote, reason
    end,
    GetQuoteRevision = function()
        if not W.ItemLinkBridge then return nil, 'LINK_BRIDGE_UNAVAILABLE' end
        local ok, revision, reason = pcall(W.ItemLinkBridge.GetRevision, W.ItemLinkBridge)
        if not ok then return nil, 'PROVIDER_DATA_UNREADABLE' end
        return revision, reason
    end,
    RegisterTooltipSectionConsumer = function(owner, resolver)
        return W.Tooltips:RegisterConsumer(owner, resolver)
    end,
    UnregisterTooltipSectionConsumer = function(owner, resolver)
        return W.Tooltips:UnregisterConsumer(owner, resolver)
    end,
    HasTooltipSection = function(tooltip, link, section)
        return W.Tooltips:HasSection(tooltip, link, section)
    end,
    RefreshTooltipSections = function(owner)
        return W.Tooltips:RefreshSections(owner)
    end,
    GetPrice = function(itemKey, context) return W.Prices:GetPrice(itemKey, context) end,
    GetHistory = function(itemKey, context, limit) return W.Prices:History(itemKey, context, limit) end,
    GetExactQuote = function(identity, marketKey) return W.Quotes:Exact(identity, marketKey) end,
    GetWatchlist = function()
        local entries, out = W.Storage:WatchEntries(), {}
        for i, entry in ipairs(entries) do
            local item = entry.item
            out[i] = {key = entry.key, itemID = item.itemID, itemLevel = item.itemLevel,
                itemSuffix = item.itemSuffix, battlePetSpeciesID = item.battlePetSpeciesID,
                addedAt = item.addedAt}
        end
        return out
    end,
    GetListingEstimate = function(itemKey, marketKey) return W.Sell:Analyze(itemKey, marketKey) end,
    GetLastCraftAnalysis = function() return W.Crafting:Read() end,
    GetManualLedgerSummary = function() return W.Ledger:Summary() end,
    GetCharacterSnapshot = function() return W.PlayerContext:Snapshot() end,
    GetInventorySummary = function()
        local r = W.Inventory.snapshot
        if not r then return {status='NOT_SCANNED'} end
        local current=W.Inventory:IsCurrent()
        return {status=r.status=='READY' and not current and 'STALE' or r.status, at=r.at, marketKey=r.marketKey,
            observedValueCopper=current and r.valueCopper or nil,
            valuedUnits=r.valuedUnits, unknownUnits=r.unknownUnits,
            boundUnits=r.boundUnits, source=r.source}
    end,
    GetMarketState = function()
        local key = W.Scope:ReadMarketKey()
        local market = W.Storage:GetMarket(key)
        local latest = market and market.snapshots[1]
        local partial = market and market.partial
        local context = W.Scope:ReadContext()
        local scope = context.scope or context.active or {}
        local targetMarket = W.Storage.account and W.Storage.account.targeted.markets[key]
        local targetCount = 0
        if targetMarket then for _ in pairs(targetMarket.records) do targetCount=targetCount+1 end end
        return {
            status = latest and 'HISTORICAL_FULL_SCAN' or
                (partial and 'PARTIAL_EXACT_LINK_SAMPLE' or
                (targetCount > 0 and 'TARGETED_ONLY' or 'NO_COMPLETE_SCAN')),
            targetedQueries = targetCount,
            marketKey = key, scopeStatus = scope.status,
            marketIdentityMode = scope.identityMode, marketIdentitySource = scope.identitySource,
            lastCompleteScan = latest and latest.finishedAt,
            lastPartialSample = partial and partial.finishedAt,
            partialUnresolvedRows = partial and partial.unresolved,
            flavor = W.Compat.build and W.Compat.build.marketFlavor or 'Forever', venueVerified = false,
            marketContextSource = W.runtime.ahOpen and W.runtime.venueSource or 'SAVED_HISTORY',
        }
    end,
    GetCapabilities = function()
        local b = W.Compat.build or W.Compat:ReadBuild()
        local api = {}
        for k, v in pairs(W.Compat.APIs or {}) do api[k] = v end
        return {
            addonVersion = W.version, schemaVersion = W.schemaVersion,
            clientVersion = b.version, build = b.build, interface = b.interface,
            clientStatus = b.status, storageStatus = W.Storage.status,
            nativeAHOwned = false, mirageIntegration = W.Integration.mode,
            visualAuctionDesk = W.AuctionDesk and W.AuctionDesk.active or false,
            nativeFallback = W.AuctionDesk and W.AuctionDesk.fallback or false,
            auctionDeskMode = W.AuctionDesk and W.AuctionDesk:Enabled() and 'INTEGRATED' or 'BLIZZARD',
            availableAPIs = api, scanStatus = W.Scan.state,
            targetedStatus = W.Targeted.state, targetQueryGuard = '6_PER_60S_AND_5S_BETWEEN',
            tooltipHookStatus = W.Tooltips.installStatus,
            exactItemLinkQuote = W.ItemLinkBridge ~= nil,
            quoteContractVersion = 1,priceViewContractVersion=1,dataLanguageContractVersion=1,
            scanStatusContractVersion=2,tooltipSectionContractVersion = 1,
            priceViewCache=W.PriceView and W.PriceView:Status() or nil,
            coordinator=W.ScanCoordinator and W.ScanCoordinator:Diagnostics() or nil,
            sharedCharacterReads=W.PlayerContext and (W.PlayerContext.sharedReads or 0) or 0,
            sharedCharacterReuses=W.PlayerContext and (W.PlayerContext.sharedReuses or 0) or 0,
            duplicateContextEvents=W.Automation and (W.Automation.duplicateContextEvents or 0) or 0,
            sharedNativeEventReuses=W.Automation and (W.Automation.sharedEventReuses or 0) or 0,
            bagCacheHits=W.PlayerContext and (W.PlayerContext.bagCacheHits or 0) or 0,
            bagRebuilds=W.PlayerContext and (W.PlayerContext.bagRebuilds or 0) or 0,
            craftPriceBasis='BASE_ITEMS_ONE_COMPLETE_SCAN',
            priceLookupIndex=W.Prices:IndexStatus(),
            craftingSchematicAPI = type(C_TradeSkillUI)=='table' and
                type(C_TradeSkillUI.GetRecipeSchematic)=='function',
            persistenceVerified = false,
        }
    end,
    RegisterMirageHost = function(host) return W.Integration:RegisterHost(host) end,
    UnregisterMirageHost = function(host) return W.Integration:UnregisterHost(host) end,
    GetIntegrationState = function() return W.Integration:State() end,
    Open = function(section) if W.UI then W.UI:Open(section,true) end end,
    Subscribe = function(event, callback)
        if not events[event] or type(callback) ~= 'function' then return nil, 'UNSUPPORTED_EVENT' end
        seq = seq + 1
        subscriptions[seq] = {event = event, fn = callback}
        return seq
    end,
    Unsubscribe = function(token)
        if subscriptions[token] then subscriptions[token] = nil; return true end
        return false
    end,
}
