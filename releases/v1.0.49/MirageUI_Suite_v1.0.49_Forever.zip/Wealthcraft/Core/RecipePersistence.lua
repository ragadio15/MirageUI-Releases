-- P39-E: bounded per-character, observation-only learned recipe catalogue.
-- Cached names help the player navigate after relog. They are NEVER proof that
-- a recipe is currently learned, available to craft, or safe to price.
local _, W = ...
local C = W.Crafting
local MAX_RECIPES, MAX_EXAMINED = 2000, 4000
local MAX_NAME = 128
local function validID(id)
    return W.Math.ValidInteger(id,1,999999999)
end
local function validName(value)
    return type(value)=='string' and #value>=1 and #value<=MAX_NAME and not value:find('[\r\n]')
end
local function data()
    if not W.Storage:IsWritable() then return nil end
    return W.Storage.character
end
function C:RestoreKnown()
    local character=data()
    if not character then return false,'STORAGE_READ_ONLY' end
    if self.restoredCharacter==character then return true,self.catalogueState end
    self.restoredCharacter=character
    self.known={}
    self.knownCount=0
    self.catalogueRevision=(self.catalogueRevision or 0)+1
    self.observedAt=nil
    self.catalogueState='NO_SAVED_RECIPES'
    local cache=character.p39eRecipes
    if cache==nil then return true,self.catalogueState end
    if type(cache)~='table' or cache.format~=1 or type(cache.rows)~='table' or
        not W.Math.ValidInteger(cache.observedAt,1) then
        self.catalogueState='INVALID_SAVED_CATALOGUE'
        return false,self.catalogueState
    end
    local count=0
    for id,r in pairs(cache.rows) do
        count=count+1
        if count>MAX_RECIPES or not validID(id) or type(r)~='table' or
            not validName(r.name) or not W.Math.ValidInteger(r.seenAt,1) or
            r.seenAt>cache.observedAt then
            self.known={};self.catalogueState='INVALID_SAVED_CATALOGUE'
            return false,self.catalogueState
        end
        self.known[id]={id=id,name=r.name,seenAt=r.seenAt,cached=true}
    end
    self.knownCount=count
    self.observedAt=cache.observedAt
    self.catalogueState=count>0 and 'CACHED_NEEDS_VALIDATION' or 'NO_SAVED_RECIPES'
    return true,self.catalogueState
end
function C:CatalogStatus()
    self:RestoreKnown()
    local count=self.knownCount or 0
    local now=W.Clock()
    local age=self.observedAt and W.Math.ValidInteger(now,1) and now>=self.observedAt and now-self.observedAt or nil
    local mode=self.catalogueState or 'NO_SAVED_RECIPES'
    return {count=count,mode=mode,observedAt=self.observedAt,ageSeconds=age,
        current=mode=='OBSERVED_THIS_SESSION',
        truncated=self.catalogueTruncated==true}
end
function C:RecipeList()
    self:RestoreKnown()
    if self.recipeListRevision==self.catalogueRevision and self.recipeList then
        return self.recipeList
    end
    local result={}
    for _,row in pairs(self.known or {}) do result[#result+1]=row end
    table.sort(result,function(a,b)
        local x,y=a.name:lower(),b.name:lower()
        return x==y and a.id<b.id or x<y
    end)
    self.recipeList=result;self.recipeListRevision=self.catalogueRevision
    return result
end
function C:Resolve(value)
    local text=tostring(value or ''):match('^%s*(.-)%s*$')
    local id=tonumber(text)
    if validID(id) then return id end
    self:RestoreKnown()
    if text=='' then return nil,'Select a learned recipe or enter its recipe ID.' end
    local wanted=text:lower()
    local found
    for recipeID,row in pairs(self.known or {}) do
        if row.name:lower()==wanted then
            if found and found~=recipeID then
                return nil,'Several recipes share that name. Select one in the recipe list.'
            end
            found=recipeID
        end
    end
    if found then return found end
    return found,'Recipe not recorded yet. Open Professions to observe learned recipes.'
end
local function persist(self,observedAt)
    local character=data()
    if not character then return false end
    local rows,ids={},{}
    for id in pairs(self.known or {}) do ids[#ids+1]=id end
    table.sort(ids,function(a,b)
        local ra,rb=self.known[a],self.known[b]
        if ra.seenAt~=rb.seenAt then return ra.seenAt>rb.seenAt end
        return a<b
    end)
    local count=0
    for _,id in ipairs(ids) do
        if count>=MAX_RECIPES then break end
        local row=self.known[id]
        if validID(id) and validName(row.name) and W.Math.ValidInteger(row.seenAt,1) then
            rows[id]={name=row.name,seenAt=row.seenAt};count=count+1
        end
    end
    local nextCache={format=1,observedAt=observedAt,rows=rows}
    local retained={}
    for id in pairs(rows) do retained[id]=self.known[id] end
    self.known=retained
    -- Commit atomically to the existing per-character namespace; no schema reset,
    -- account-wide copying, item links, player names, or unqualified schematics.
    character.p39eRecipes=nextCache
    return true,count
end
function C:CacheKnown(source,force)
    self:RestoreKnown()
    if source~='PROFESSION_EVENT' and source~='PLAYER_REFRESH' then
        return false,'CACHED_ONLY_OPEN_PROFESSIONS_TO_UPDATE'
    end
    if not W.runtime.professionOpen then
        return false,'PROFESSION_NOT_OPEN'
    end
    local mono=type(GetTime)=='function' and GetTime() or nil
    if not force and mono and self.lastObservedMono and mono-self.lastObservedMono<1.2 then
        return false,'RECENTLY_CHECKED'
    end
    local api=C_TradeSkillUI
    if type(api)~='table' then return false,'PROFESSION_API_UNAVAILABLE' end
    local good,ids=W.SafeCall(api.GetAllRecipeIDs)
    if not good or type(ids)~='table' then return false,'RECIPE_LIST_NOT_READY' end
    local now=W.Clock()
    if not W.Math.ValidInteger(now,1) then return false,'OBSERVATION_TIME_UNAVAILABLE' end
    local before=0;for _ in pairs(self.known) do before=before+1 end
    local confirmed,examined,changed=0,0,false
    local seenIDs={}
    for _,id in ipairs(ids) do
        examined=examined+1
        if examined>MAX_EXAMINED or confirmed>=MAX_RECIPES then break end
        if validID(id) and type(api.GetRecipeInfo)=='function' then
            local ok,info=W.SafeCall(api.GetRecipeInfo,id)
            if ok and type(info)=='table' and info.learned==true and
                (info.recipeID==nil or info.recipeID==id) and validName(info.name) then
                seenIDs[id]=true
                local old=self.known[id]
                if not old or old.name~=info.name or old.cached or
                    not W.Math.ValidInteger(old.seenAt,1) or now-old.seenAt>=600 then
                    self.known[id]={id=id,name=info.name,seenAt=now,cached=false}
                    changed=true
                end
                confirmed=confirmed+1
            end
        end
    end
    if confirmed==0 then
        self.catalogueState='RECIPE_DETAILS_NOT_READY'
        return false,self.catalogueState
    end
    -- The visible profession list may contain only one discipline. Entries not
    -- confirmed by this event remain navigable, but cannot be labeled current.
    for id,row in pairs(self.known) do
        if not seenIDs[id] then row.cached=true end
    end
    if mono then self.lastObservedMono=mono end
    self.catalogueTruncated=examined<#ids or #ids>MAX_EXAMINED or confirmed>=MAX_RECIPES
    local shouldWrite=changed or self.catalogueState~='OBSERVED_THIS_SESSION'
    local n=before
    if shouldWrite then
        self.observedAt=now
        local saved,count=persist(self,now)
        if not saved then return false,'STORAGE_READ_ONLY' end
        n=count
        self.knownCount=count
        self.catalogueRevision=(self.catalogueRevision or 0)+1
    end
    self.catalogueState='OBSERVED_THIS_SESSION'
    self.lastObservation={count=confirmed,retained=n,previous=before,at=now,source=source}
    if W.UI then W.UI.dirty=true end
    return true,'RECIPES_SAVED',confirmed
end
-- Preserve the opt-in P39-A performance channel around the replacement scanner.
local observe=C.CacheKnown
function C:CacheKnown(...)
    local service,started
    if type(W.P39TraceBegin)=='function' then service,started=W.P39TraceBegin()end
    local a,b,c=observe(self,...)
    if type(W.P39TraceEnd)=='function' then
        W.P39TraceEnd(service,started,'wealth.recipe_discovery')
    end
    return a,b,c
end
function C:OnProfessionEvent(reason)
    if reason~='TRADE_SKILL_SHOW' and reason~='TRADE_SKILL_LIST_UPDATE' and
        reason~='TRADE_SKILL_DATA_SOURCE_CHANGED' then return false,'NOT_PROFESSION_EVENT' end
    W.runtime.professionOpen=true
    return self:CacheKnown('PROFESSION_EVENT',false)
end
function C:RefreshObserved()
    if not W.runtime.professionOpen then return false,'Open Professions to check learned recipes. Saved names remain available.' end
    return self:CacheKnown('PLAYER_REFRESH',true)
end
