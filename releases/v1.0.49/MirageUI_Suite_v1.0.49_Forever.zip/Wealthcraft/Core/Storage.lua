local _, W = ...
W.Storage = {}
local S = W.Storage
local function copyTable(t)
    local out = {}
    for k, v in pairs(t) do out[k] = v end
    return out
end
-- Keep the complete namespace proof with every producer. WC4 can describe a
-- regional ruleset or an isolated visit without fabricating retail realm IDs.
local function copyScope(scope)
    local out={}
    for _,name in ipairs({'status','region','realmID','realm','faction','mapID','location',
        'venueRole','venueToken','auctioneerID','build','flavor','regionToken','serverToken',
        'modeToken','mapToken','identityMode','identitySource','regionalNames','guidNamespace',
        'gameModeRecordID','activeGameMode','hardcore','roleplay','pvp'})do out[name]=scope[name] end
    return out
end
local function sentinel(v)
    return type(v) == 'table' and W.Math.ValidInteger(v.count, 0, 10000000) and
        W.Math.ValidInteger(v.writtenAt, 0) and type(v.value) == 'string' and #v.value <= 120
end
local function freshAccount()
    return {
        schemaVersion = 4, createdAt = W.Clock(),
        settings = {scale = 1.0, compact = false, assumedFeeBps = 500, tooltipMode = 'AUTO'},
        sentinel = {count = 0, writtenAt = 0, value = ''},
        probe = {lastRequestAt = 0, lastBuild = 0},
        marketHistory = {format = 1, markets = {}},
        watchlist = {format = 1, items = {}},
        targeted = {format = 1, markets = {}},
        queryGuard = {times = {}},
        migration = nil,
    }
end
local function freshCharacter()
    return {
        schemaVersion = 4, createdAt = W.Clock(),
        ui = {x = 0, y = 0}, sentinel = {count = 0, writtenAt = 0, value = ''},
        ledger = {format = 1, nextID = 1, entries = {}},
        lastMarketKey = nil,
    }
end
local function validBasic(db, char)
    if type(db) ~= 'table' or type(char) ~= 'table' or
        type(db.settings) ~= 'table' or type(db.probe) ~= 'table' or
        type(char.ui) ~= 'table' or not sentinel(db.sentinel) or not sentinel(char.sentinel) then
        return false, 'SCHEMA_SHAPE_INVALID'
    end
    if not W.Math.ValidNumber(db.settings.scale) or db.settings.scale < 0.8 or db.settings.scale > 1.5 or
        not W.Math.ValidNumber(char.ui.x) or not W.Math.ValidNumber(char.ui.y) or
        not W.Math.ValidInteger(db.probe.lastRequestAt, 0) then
        return false, 'SAVED_DATA_INVALID'
    end
    return true
end
local function validateHistory(db)
    local hist = db.marketHistory
    if type(hist) ~= 'table' or hist.format ~= 1 or type(hist.markets) ~= 'table' then
        return false, 'MARKET_DB_INVALID'
    end
    local count = 0
    for key, market in pairs(hist.markets) do
        count = count + 1
        if count > 96 or type(key) ~= 'string' or #key > 160 or
            type(market) ~= 'table' or type(market.scope) ~= 'table' or
            type(market.snapshots) ~= 'table' or type(market.daily) ~= 'table' or
            type(market.monthly) ~= 'table' then
            return false, 'MARKET_RECORD_INVALID'
        end
        for _, snap in ipairs(market.snapshots) do
            if type(snap) ~= 'table' or type(snap.items) ~= 'table' or
                not W.Math.ValidInteger(snap.finishedAt, 1) or
                not W.Math.ValidInteger(snap.count, 1, 500000) then
                return false, 'SNAPSHOT_INVALID'
            end
        end
        local p = market.partial
        if p ~= nil and (type(p) ~= 'table' or p.status ~= 'PARTIAL_COVERAGE' or
            type(p.items) ~= 'table' or not W.Math.ValidInteger(p.count, 1, 500000) or
            not W.Math.ValidInteger(p.unresolved, 1, 500000) or
            not W.Math.ValidInteger(p.finishedAt, 1)) then
            return false, 'PARTIAL_SNAPSHOT_INVALID'
        end
    end
    return true
end
function S:Init()
    if self.initialized then return end
    self.initialized = true
    local db, char = WealthcraftDB, WealthcraftCharDB
    if db == nil and char == nil then
        db, char = freshAccount(), freshCharacter()
        WealthcraftDB, WealthcraftCharDB = db, char
        self.firstInstall = true
    elseif db == nil then
        self.status = 'READ_ONLY_ACCOUNT_MISSING'
        W.Diagnostics:Record('ERROR', 'Account SavedVariables missing but character data exists; preserving data')
        return
    elseif char == nil then
        -- Account-wide market history is shared across alts, each of which may have no
        -- per-character SavedVariables on their first login. Never replace account data.
        if type(db) ~= 'table' or (db.schemaVersion ~= 1 and db.schemaVersion ~= 2 and db.schemaVersion ~= 3 and db.schemaVersion ~= 4) then
            self.status = 'READ_ONLY_UNKNOWN_ACCOUNT'
            return
        end
        char = freshCharacter()
        if db.schemaVersion == 1 or db.schemaVersion == 2 or db.schemaVersion == 3 then
            char.schemaVersion = db.schemaVersion
        end
        WealthcraftCharDB = char
        self.firstCharacter = true
    end
    if type(db) ~= 'table' or type(char) ~= 'table' then
        self.status = 'READ_ONLY_INVALID_TABLE'
        W.Diagnostics:Record('ERROR', 'Invalid SavedVariables type; preserving globals')
        return
    end
    if db.schemaVersion == 1 and char.schemaVersion == 1 then
        local valid, reason = validBasic(db, char)
        if not valid or type(db.marketHistory) ~= 'table' or next(db.marketHistory) ~= nil then
            self.status = 'READ_ONLY_LEGACY_INVALID'
            W.Diagnostics:Record('ERROR', 'Alpha schema migration refused: ' .. tostring(reason or 'nonempty legacy history'))
            return
        end
        -- Copy into new tables, keep the immutable legacy alpha payload for rollback/export.
        local migrated, cMigrated = freshAccount(), freshCharacter()
        migrated.schemaVersion, cMigrated.schemaVersion = 3, 3
        migrated.createdAt = db.createdAt
        migrated.settings = copyTable(db.settings)
        migrated.sentinel = copyTable(db.sentinel)
        migrated.probe = copyTable(db.probe)
        migrated.migration = {from = 1, at = W.Clock(),
            original = {schemaVersion = 1, createdAt = db.createdAt,
                settings = copyTable(db.settings), sentinel = copyTable(db.sentinel),
                probe = copyTable(db.probe), marketHistory = {}}}
        cMigrated.createdAt = char.createdAt
        cMigrated.ui = copyTable(char.ui)
        cMigrated.sentinel = copyTable(char.sentinel)
        cMigrated.migration = {from = 1, at = W.Clock(), original = {
            schemaVersion = 1, createdAt = char.createdAt,
            ui = copyTable(char.ui), sentinel = copyTable(char.sentinel)}}
        -- Validate new pair BEFORE swapping persistent globals.
        local good = validBasic(migrated, cMigrated) and validateHistory(migrated)
        if not good then self.status = 'READ_ONLY_MIGRATION_FAILED'; return end
        WealthcraftDB, WealthcraftCharDB = migrated, cMigrated
        db, char = migrated, cMigrated
        self.migrated = true
    end
    if db.schemaVersion == 2 and char.schemaVersion == 2 then
        local good, basicReason = validBasic(db, char)
        if not good then
            self.status = 'READ_ONLY_V2_' .. tostring(basicReason)
            W.Diagnostics:Record('ERROR', 'Invalid G2 data; G3 migration not started')
            return
        end
        local validMarket, marketReason = validateHistory(db)
        if not validMarket then
            self.status = 'READ_ONLY_V2_' .. tostring(marketReason)
            W.Diagnostics:Record('ERROR', 'Invalid G2 market history; preserved without migration')
            return
        end
        -- v2->v3: copy-on-write metadata; preserve the original market-history tree
        -- without duplicating potentially large complete-scan payloads in SavedVariables.
        local upgraded, upgradedChar = copyTable(db), copyTable(char)
        upgraded.schemaVersion, upgradedChar.schemaVersion = 3, 3
        upgraded.watchlist = {format = 1, items = {}}
        upgraded.targeted = {format = 1, markets = {}}
        upgraded.queryGuard = {times = {}}
        upgraded.migrationG3 = {from = 2, at = W.Clock(),
            note = 'Market history preserved by reference; back up SavedVariables before upgrade',
            priorAccountSchema = db.schemaVersion, priorCharacterSchema = char.schemaVersion}
        local validG3, g3reason = self:ValidateG3(upgraded)
        if not validG3 then
            self.status = 'READ_ONLY_V2_MIGRATION_' .. tostring(g3reason)
            W.Diagnostics:Record('ERROR', 'G3 migration validation failed; G2 globals preserved')
            return
        end
        WealthcraftDB, WealthcraftCharDB = upgraded, upgradedChar
        db, char = upgraded, upgradedChar
        self.migratedG3 = true
    end
    if db.schemaVersion == 3 and char.schemaVersion == 3 then
        local basicOK, basicReason = validBasic(db, char)
        local historyOK, historyReason = validateHistory(db)
        local g3OK, g3Reason = self:ValidateG3(db)
        if not basicOK or not historyOK or not g3OK then
            self.status = 'READ_ONLY_G3_UPGRADE_' .. tostring(basicReason or historyReason or g3Reason)
            W.Diagnostics:Record('ERROR', 'G3->G4 migration refused: existing data invalid and preserved')
            return
        end
        -- Copy-on-write: never deep-copy or truncate market history while migrating.
        local upgraded, upgradedChar = copyTable(db), copyTable(char)
        upgraded.schemaVersion, upgradedChar.schemaVersion = 4, 4
        upgraded.settings = copyTable(db.settings)
        upgraded.settings.assumedFeeBps = 500
        upgraded.settings.tooltipMode = 'AUTO'
        upgradedChar.ledger = {format = 1, nextID = 1, entries = {}}
        upgraded.migrationG4 = {from = 3, at = W.Clock(),
            note = 'G3 records retained by reference; back up SavedVariables before upgrade'}
        local good, reason = self:ValidateG4(upgraded, upgradedChar)
        if not good then
            self.status = 'READ_ONLY_G4_MIGRATION_' .. tostring(reason)
            return
        end
        WealthcraftDB, WealthcraftCharDB = upgraded, upgradedChar
        db, char = upgraded, upgradedChar
        self.migratedG4 = true
    end
    if db.schemaVersion ~= 4 or char.schemaVersion ~= 4 then
        self.status = 'READ_ONLY_SCHEMA_MISMATCH'
        W.Diagnostics:Record('ERROR', 'Unknown SavedVariables version; preserving saved data')
        return
    end
    local valid, reason = validBasic(db, char)
    if not valid then
        self.status = 'READ_ONLY_' .. reason
        W.Diagnostics:Record('ERROR', 'Malformed settings/sentinel; preserving saved data')
        return
    end
    valid, reason = validateHistory(db)
    if not valid then
        self.status = 'READ_ONLY_' .. reason
        W.Diagnostics:Record('ERROR', 'Malformed history; preserving saved data')
        return
    end
    local valid3, reason3 = self:ValidateG3(db)
    if not valid3 then
        self.status = 'READ_ONLY_' .. tostring(reason3)
        W.Diagnostics:Record('ERROR', 'Malformed G3 storage; saved data left unchanged')
        return
    end
    local valid4, reason4 = self:ValidateG4(db, char)
    if not valid4 then
        self.status = 'READ_ONLY_' .. tostring(reason4)
        W.Diagnostics:Record('ERROR', 'Malformed G4 records; original SavedVariables preserved')
        return
    end
    self.account, self.character = db, char
    -- Optional G6 preferences. Nil = conservative defaults; do not rewrite old history.
    self.loadedMarketCount = 0
    for _ in pairs(db.marketHistory.markets) do self.loadedMarketCount = self.loadedMarketCount + 1 end
    self.loadedLastMarketKey = char.lastMarketKey
    self.status = 'READY_UNVERIFIED'
    self.restoredAtLoad = {
        accountCount = db.sentinel.count, characterCount = char.sentinel.count,
        accountValue = db.sentinel.value, characterValue = char.sentinel.value,
    }
    self.restoreObserved = not self.firstInstall and
        (db.sentinel.count > 0 and char.sentinel.count > 0)
    local marker = self.migratedG4 and 'G4 schema upgrade: G3 data retained; ledger added' or
        self.migratedG3 and 'G3 schema upgrade with market snapshots preserved' or
        self.migrated and 'Alpha v1->v2->v3 data migrated with metadata backup' or
        self.firstInstall and 'New SavedVariables initialized' or 'SavedVariables loaded'
    W.Diagnostics:Record('INFO', marker)
    if self.firstInstall then
        W.Diagnostics:Record('WARN', 'New saved data; automatic scans may run. Persistence will be observed after a future reload.')
    end
    if self.firstCharacter then
        W.Diagnostics:Record('WARN', 'New/missing per-character SavedVariables; account history preserved. Verify old marker if expected.')
    end
end
function S:IsWritable() return self.status == 'READY_UNVERIFIED' end
function S:PersistenceReady()
    -- Observed restored markers are a necessary minimum, not proof of a full client restart.
    local at = self.restoredAtLoad
    return self:IsWritable() and type(at) == 'table' and
        W.Math.ValidInteger(at.accountCount, 1) and
        W.Math.ValidInteger(at.characterCount, 1) and
        at.accountValue == ('ACCOUNT-' .. tostring(at.accountCount)) and
        at.characterValue == ('CHARACTER-' .. tostring(at.characterCount))
end
function S:Marker()
    if not self:IsWritable() then return false, self.status end
    local a, c, now = self.account.sentinel, self.character.sentinel, W.Clock()
    a.count = a.count + 1; a.writtenAt = now; a.value = 'ACCOUNT-' .. a.count
    c.count = c.count + 1; c.writtenAt = now; c.value = 'CHARACTER-' .. c.count
    W.Diagnostics:Record('INFO', 'Save markers updated (verify after /reload and restart)')
    W.Refresh()
    return true
end
function S:Scale(delta)
    if not self:IsWritable() then return false end
    local v = self.account.settings.scale + delta
    v = math.max(0.8, math.min(1.5, math.floor(v * 20 + 0.5) / 20))
    self.account.settings.scale = v
    return true, v
end
function S:SetWindowOffset(x, y)
    if not self:IsWritable() or not W.Math.ValidNumber(x) or not W.Math.ValidNumber(y) then return false end
    self.character.ui.x = math.floor(math.max(-1100, math.min(1100, x)))
    self.character.ui.y = math.floor(math.max(-1100, math.min(1100, y)))
    return true
end
function S:CurrentScale() return self:IsWritable() and self.account.settings.scale or 1 end
function S:WindowOffset()
    if not self:IsWritable() then return 0, 0 end
    return self.character.ui.x, self.character.ui.y
end
function S:LastRequestTime()
    if not self:IsWritable() then return nil end
    return self.account.probe.lastRequestAt
end
function S:GuardAttempt()
    if not self:IsWritable() then return false end
    self.account.probe.lastRequestAt = W.Clock()
    self.account.probe.lastBuild = W.Compat.build and W.Compat.build.build or 0
    return true
end
function S:GetMarket(key)
    if not self.account or type(key) ~= 'string' then return nil end
    return self.account.marketHistory.markets[key]
end
function S:MarketCount()
    if not self.account then return 0 end
    local n = 0
    for _ in pairs(self.account.marketHistory.markets) do n = n + 1 end
    return n
end
local function period(at, format)
    if type(date) ~= 'function' then return tostring(math.floor(at / 86400)) end
    local ok, value = pcall(date, format, at)
    if ok and type(value) == 'string' then return value end
    return tostring(math.floor(at / 86400))
end
local function chooseRecent(old, entry)
    if not old or (old.at or old.finishedAt or 0) < (entry.at or entry.finishedAt or 0) then return entry end
    return old
end
local function compact(market, now)
    -- Copy-on-write; old snapshot/history references remain intact until final swap.
    local keep = {}
    for _, snap in ipairs(market.snapshots) do
        if #keep < 24 and now - snap.finishedAt <= 14 * 86400 then
            keep[#keep + 1] = snap
        else
            local key = period(snap.finishedAt, '!%Y-%m-%d')
            market.daily[key] = chooseRecent(market.daily[key], {at = snap.finishedAt, items = snap.items})
        end
    end
    market.snapshots = keep
    for key, daily in pairs(market.daily) do
        if now - daily.at > 90 * 86400 then
            local mkey = period(daily.at, '!%Y-%m')
            market.monthly[mkey] = chooseRecent(market.monthly[mkey], daily)
            market.daily[key] = nil
        end
    end
    for key, monthly in pairs(market.monthly) do
        if now - monthly.at > 365 * 86400 then market.monthly[key] = nil end
    end
end
function S:CommitSnapshot(scope, candidate)
    if not self:IsWritable() then return false, 'STORAGE_READ_ONLY' end
    if type(scope) ~= 'table' or scope.ready ~= true or type(scope.key) ~= 'string' or
        type(candidate) ~= 'table' or candidate.status ~= 'COMPLETE' or
        not W.Math.ValidInteger(candidate.count, 1, 500000) or
        candidate.handled ~= candidate.count or candidate.unresolved ~= 0 or candidate.invalid ~= 0 or
        type(candidate.items) ~= 'table' or candidate.preciseCount < 1 then
        return false, 'INCOMPLETE_OR_UNQUALIFIED_SNAPSHOT'
    end
    local old = self:GetMarket(scope.key)
    local totalMarkets = self:MarketCount()
    if not old and totalMarkets >= 96 then return false, 'MARKET_LIMIT_REACHED' end
    local newMarket = {
        key = scope.key,
        scope = copyScope(scope),
        snapshots = {}, daily = old and copyTable(old.daily) or {},
        monthly = old and copyTable(old.monthly) or {},
        partial = old and old.partial or nil,
    }
    local snapshots = newMarket.snapshots
    snapshots[#snapshots + 1] = candidate
    if old then for _, s in ipairs(old.snapshots) do snapshots[#snapshots + 1] = s end end
    compact(newMarket, W.Clock())
    -- Atomic replacement: no partial event mutates the last-good market record.
    self.account.marketHistory.markets[scope.key] = newMarket
    self.character.lastMarketKey = scope.key
    self.lastCommitted = {id = candidate.id, key = scope.key, at = candidate.finishedAt}
    W.Diagnostics:Record('INFO', ('Committed %d/%d rows, %d priced variants (automatic location scope)'):
        format(candidate.handled, candidate.count, candidate.preciseCount))
    if W.Publish then W.Publish('MARKET_SNAPSHOT_READY', {marketKey = scope.key, snapshotID = candidate.id}) end
    W.Refresh()
    return true
end


-- G4 incomplete scans are segregated from completed scan history. These records
-- may support EXACT item-link samples, but may never imply overall market depth.
function S:CommitPartial(scope, candidate)
    if not self:IsWritable() then return false, 'STORAGE_READ_ONLY' end
    if type(scope) ~= 'table' or scope.ready ~= true or type(scope.key) ~= 'string' or
        type(candidate) ~= 'table' or candidate.status ~= 'PARTIAL_COVERAGE' or
        not W.Math.ValidInteger(candidate.count, 1, 500000) or
        not W.Math.ValidInteger(candidate.unresolved, 1, 500000) or
        not W.Math.ValidInteger(candidate.preciseCount, 1, 100000) or
        type(candidate.items) ~= 'table' or candidate.invalid ~= 0 then
        return false, 'PARTIAL_CANDIDATE_INVALID'
    end
    local old = self:GetMarket(scope.key)
    if not old and self:MarketCount() >= 96 then return false, 'MARKET_LIMIT_REACHED' end
    local newMarket
    if old then
        newMarket = copyTable(old)
    else
        newMarket = {key = scope.key, snapshots = {}, daily = {}, monthly = {}, scope = copyScope(scope)}
    end
    newMarket.partial = candidate
    self.account.marketHistory.markets[scope.key] = newMarket
    self.character.lastMarketKey = scope.key
    W.Diagnostics:Record('WARN', ('Saved PARTIAL exact-identity evidence: %d identified, %d uncached / %d auctions'):
        format(candidate.handled, candidate.unresolved, candidate.count))
    if W.Publish then W.Publish('MARKET_SNAPSHOT_READY',
        {marketKey = scope.key, snapshotID = candidate.id, partial = true}) end
    W.Refresh()
    return true
end

function S:ValidateG4(db, char)
    if type(db.settings) ~= 'table' or
        not W.Math.ValidInteger(db.settings.assumedFeeBps, 0, 2000) or
        (db.settings.tooltipMode ~= 'AUTO' and db.settings.tooltipMode ~= 'ON' and
            db.settings.tooltipMode ~= 'OFF') then
        return false, 'G4_SETTINGS_INVALID'
    end
    local ledger = char.ledger
    if type(ledger) ~= 'table' or ledger.format ~= 1 or
        type(ledger.entries) ~= 'table' or
        not W.Math.ValidInteger(ledger.nextID, 1, 10000000) or
        #ledger.entries > 250 then return false, 'LEDGER_SCHEMA_INVALID' end
    for i, entry in ipairs(ledger.entries) do
        if type(entry) ~= 'table' or
            not W.Math.ValidInteger(entry.id, 1, 10000000) or
            not W.Math.ValidInteger(entry.at, 1) or
            (entry.kind ~= 'SALE' and entry.kind ~= 'PURCHASE' and
                entry.kind ~= 'INCOME' and entry.kind ~= 'EXPENSE') or
            not W.Math.ValidInteger(entry.itemID, 0, 999999999) or
            not W.Math.ValidInteger(entry.quantity, 1, 100000000) or
            not W.Math.ValidInteger(entry.unitCopper, 0, 9007199254740991) or
            entry.quantity * entry.unitCopper > 9007199254740991 or
            entry.id >= ledger.nextID then return false, 'LEDGER_ENTRY_INVALID' end
        if i > 1 and entry.id <= ledger.entries[i-1].id then return false, 'LEDGER_ORDER_INVALID' end
    end
    return true
end
function S:AssumedFeeBps()
    return self.account and self.account.settings.assumedFeeBps or 500
end
function S:ChangeAssumedFee(delta)
    if not self:IsWritable() then return false, 'STORAGE_READ_ONLY' end
    local v = math.max(0, math.min(2000, self:AssumedFeeBps() + delta))
    self.account.settings.assumedFeeBps = v
    W.Refresh()
    return true, v
end
function S:SetTooltipMode(mode)
    if not self:IsWritable() or (mode ~= 'AUTO' and mode ~= 'ON' and mode ~= 'OFF') then
        return false, 'INVALID_TOOLTIP_MODE'
    end
    self.account.settings.tooltipMode = mode
    W.Refresh()
    return true
end

-- G3 records are strictly limited and externally untrusted SavedVariables are read-only on invalid shape.
function S:ValidateG3(db)
    if type(db.watchlist) ~= 'table' or db.watchlist.format ~= 1 or
        type(db.watchlist.items) ~= 'table' or type(db.targeted) ~= 'table' or
        db.targeted.format ~= 1 or type(db.targeted.markets) ~= 'table' then
        return false, 'G3_TABLE_INVALID'
    end
    if type(db.queryGuard) ~= 'table' or type(db.queryGuard.times) ~= 'table' then
        return false, 'QUERY_GUARD_INVALID'
    end
    if #db.queryGuard.times > 80 then return false, 'QUERY_GUARD_OVERSIZE' end
    for _, at in ipairs(db.queryGuard.times) do
        if not W.Math.ValidInteger(at, 0) then return false, 'QUERY_GUARD_INVALID_TIME' end
    end
    local n = 0
    for key, value in pairs(db.watchlist.items) do
        n = n + 1
        if n > 80 or type(key) ~= 'string' or #key > 75 or type(value) ~= 'table' or
            not W.Math.ValidInteger(value.itemID, 1, 999999999) or
            not W.Math.ValidInteger(value.itemLevel, 0, 1000000) or
            not W.Math.ValidInteger(value.itemSuffix, -999999999, 999999999) or
            not W.Math.ValidInteger(value.battlePetSpeciesID, 0, 999999999) or
            not W.Math.ValidInteger(value.addedAt, 0) then
            return false, 'WATCHLIST_INVALID'
        end
    end
    local markets = 0
    for key, market in pairs(db.targeted.markets) do
        markets = markets + 1
        if markets > 96 or type(key) ~= 'string' or #key > 160 or
            type(market) ~= 'table' or type(market.records) ~= 'table' then
            return false, 'TARGETED_MARKET_INVALID'
        end
        local queries = 0
        for requestKey, rec in pairs(market.records) do
            queries = queries + 1
            if queries > 120 or type(requestKey) ~= 'string' or #requestKey > 75 or
                type(rec) ~= 'table' or type(rec.items) ~= 'table' or
                not W.Math.ValidInteger(rec.updatedAt, 1) or
                not W.Math.ValidInteger(rec.resultCount, 0, 25000) or
                (rec.kind ~= 'ITEM' and rec.kind ~= 'COMMODITY') or
                rec.status ~= 'COMPLETE_TARGET_QUERY' then
                return false, 'TARGETED_RECORD_INVALID'
            end
        end
    end
    return true
end
function S:WatchKey(key)
    if type(key) ~= 'table' then return nil end
    local id = tonumber(key.itemID)
    local level = tonumber(key.itemLevel or 0)
    local suffix = tonumber(key.itemSuffix or 0)
    local pet = tonumber(key.battlePetSpeciesID or 0)
    if not W.Math.ValidInteger(id, 1, 999999999) or
        not W.Math.ValidInteger(level, 0, 1000000) or
        not W.Math.ValidInteger(suffix, -999999999, 999999999) or
        not W.Math.ValidInteger(pet, 0, 999999999) then return nil end
    return table.concat({id, level, suffix, pet}, ':'),
        {itemID = id, itemLevel = level, itemSuffix = suffix, battlePetSpeciesID = pet}
end
-- Optional account-wide organization; the existing Favorites index remains
-- the authority for item identity, quick scans, and public integrations.
local function listName(v)
    if type(v) ~= 'string' then return nil end
    local name = v:match('^%s*(.-)%s*$')
    if #name < 1 or #name > 32 or name:find('[%c|]') then return nil end
    return name
end
function S:WatchListsData()
    local db = self.account and self.account.watchGroups
    if db == nil then return nil, true end -- old accounts, no migration
    if type(db) ~= 'table' or db.format ~= 1 or type(db.groups) ~= 'table' then return nil, false end
    local names, count = {}, 0
    for id, group in pairs(db.groups) do
        count = count + 1
        if count > 8 or not W.Math.ValidInteger(id, 1, 8) or type(group) ~= 'table' or
            not listName(group.name) or listName(group.name) ~= group.name or type(group.items) ~= 'table' then
            return nil, false
        end
        local lower = group.name:lower()
        if names[lower] or lower == 'all favorites' then return nil, false end
        names[lower] = true
        local members = 0
        for key, value in pairs(group.items) do
            members = members + 1
            if members > 80 or type(key) ~= 'string' or #key > 75 or value ~= true then return nil, false end
        end
    end
    return db, true
end
function S:WatchLists()
    local db, available = self:WatchListsData()
    local out = {}
    for id, group in pairs(db and db.groups or {}) do out[#out+1] = {id=id, name=group.name} end
    table.sort(out, function(a,b) return a.name:lower() < b.name:lower() end)
    return out, available
end
function S:SaveWatchList(name, id)
    if not self:IsWritable() then return false, 'STORAGE_READ_ONLY' end
    local db, available = self:WatchListsData()
    if not available then return false, 'FAVORITE_LISTS_UNAVAILABLE' end
    name = listName(name)
    if not name then return false, 'FAVORITE_LIST_NAME' end
    local groups = db and db.groups or {}
    if id ~= nil and not groups[id] then return false, 'FAVORITE_LIST_MISSING' end
    local lower = name:lower()
    if lower == 'all favorites' then return false, 'FAVORITE_LIST_DUPLICATE' end
    for other, group in pairs(groups) do
        if other ~= id and group.name:lower() == lower then return false, 'FAVORITE_LIST_DUPLICATE' end
    end
    if not id then
        for k = 1, 8 do if not groups[k] then id = k; break end end
        if not id then return false, 'FAVORITE_LIST_LIMIT' end
    end
    if groups[id] then groups[id].name = name else groups[id] = {name=name, items={}} end
    if not db then self.account.watchGroups = {format=1, groups=groups} end
    return true, id
end
function S:DeleteWatchList(id)
    if not self:IsWritable() then return false, 'STORAGE_READ_ONLY' end
    local db = self:WatchListsData()
    if not db or not id or not db.groups[id] then return false, 'FAVORITE_LIST_MISSING' end
    db.groups[id] = nil
    return true
end
function S:SetWatchListItem(id, key, included)
    if not self:IsWritable() then return false, 'STORAGE_READ_ONLY' end
    local db = self:WatchListsData()
    local group = db and id and db.groups[id]
    if not group then return false, 'FAVORITE_LIST_MISSING' end
    if type(key) ~= 'string' or not self.account.watchlist.items[key] then return false, 'NOT_WATCHED' end
    -- Ignore stale members left by rollback to a release without list support.
    for member in pairs(group.items) do
        if not self.account.watchlist.items[member] then group.items[member] = nil end
    end
    group.items[key] = included and true or nil
    return true
end
function S:UpdateWatchListKey(old, new)
    local db = self:WatchListsData()
    if not db then return end
    for _, group in pairs(db.groups) do
        if group.items[old] then
            group.items[old] = nil
            if new then group.items[new] = true end
        end
    end
end
function S:WatchEntries(listID)
    local out = {}
    local db = listID and self:WatchListsData()
    local group = db and db.groups[listID]
    if self.account and (not listID or group) then
        for key, value in pairs(self.account.watchlist.items) do
            if not group or group.items[key] then out[#out + 1] = {key = key, item = value} end
        end
    end
    table.sort(out, function(a, b)
        if a.item.addedAt == b.item.addedAt then return a.key < b.key end
        return a.item.addedAt < b.item.addedAt
    end)
    return out
end
function S:AddWatch(itemKey)
    if not self:IsWritable() then return false, 'STORAGE_READ_ONLY' end
    local key, item = self:WatchKey(itemKey)
    if not key then return false, 'INVALID_ITEM_KEY' end
    if self.account.watchlist.items[key] then return false, 'ALREADY_WATCHED' end
    local count = 0
    for _ in pairs(self.account.watchlist.items) do count = count + 1 end
    if count >= 80 then return false, 'WATCHLIST_LIMIT_80' end
    item.addedAt = W.Clock()
    self.account.watchlist.items[key] = item
    W.Diagnostics:Record('INFO', 'Watchlist item added: ' .. key)
    if W.Publish then W.Publish('WATCHLIST_CHANGED', {queryKey=key, operation='add'}) end
    W.Refresh()
    return true, key
end
function S:RemoveWatch(requestKey)
    if not self:IsWritable() then return false, 'STORAGE_READ_ONLY' end
    if type(requestKey) ~= 'string' or not self.account.watchlist.items[requestKey] then
        return false, 'NOT_WATCHED'
    end
    self.account.watchlist.items[requestKey] = nil
    self:UpdateWatchListKey(requestKey)
    W.Diagnostics:Record('INFO', 'Watchlist item removed: ' .. requestKey)
    if W.Publish then W.Publish('WATCHLIST_CHANGED', {queryKey=requestKey, operation='remove'}) end
    W.Refresh()
    return true
end
function S:GetTarget(marketKey, requestKey)
    local market = self.account and self.account.targeted.markets[marketKey]
    return market and market.records[requestKey] or nil
end
function S:CommitTarget(scope, record)
    if not self:IsWritable() then return false, 'STORAGE_READ_ONLY' end
    if type(scope) ~= 'table' or not scope.ready or type(scope.key) ~= 'string' or
        type(record) ~= 'table' or record.status ~= 'COMPLETE_TARGET_QUERY' or
        not W.Math.ValidInteger(record.updatedAt, 1) or
        not W.Math.ValidInteger(record.resultCount, 0, 25000) or
        type(record.items) ~= 'table' or type(record.queryKey) ~= 'string' or
        #record.queryKey > 75 then return false, 'INVALID_TARGET_RECORD' end
    local db = self.account.targeted.markets
    local old = db[scope.key]
    if not old then
        local markets = 0
        for _ in pairs(db) do markets = markets + 1 end
        if markets >= 96 then return false, 'TARGETED_MARKET_LIMIT' end
    end
    local records = old and copyTable(old.records) or {}
    records[record.queryKey] = record
    local n, earliestKey, earliestTime = 0, nil, math.huge
    for key, rec in pairs(records) do
        n = n + 1
        if rec.updatedAt < earliestTime or (rec.updatedAt == earliestTime and (not earliestKey or key < earliestKey)) then
            earliestKey, earliestTime = key, rec.updatedAt
        end
    end
    if n > 120 and earliestKey then records[earliestKey] = nil end
    db[scope.key] = {records = records, scope = copyScope(scope)}
    self.character.lastMarketKey = scope.key
    W.Diagnostics:Record('INFO', 'Completed targeted result saved for ' .. record.queryKey)
    if W.Publish then W.Publish('TARGET_QUERY_READY', {marketKey=scope.key, queryKey=record.queryKey}) end
    W.Refresh()
    return true
end

function S:TargetQueryEligibility(priority)
    if not self:IsWritable() then return false, 'SavedVariables are not writable.' end
    local now = W.Clock()
    if now <= 0 then return false, 'Server clock unavailable.' end
    local times = self.account.queryGuard.times
    if #times > 0 and times[#times] > now then return false, 'Clock moved backward.' end
    local active, latest = 0, nil
    for _, at in ipairs(times) do
        if now - at < 60 then active = active + 1; latest = at end
    end
    -- Blizzard controls its own throttle. Auto refresh retains a conservative
    -- six-per-minute / five-second budget; a clicked player search does not
    -- inherit that background delay. Keep a separate conservative safety cap
    -- beneath the documented 100 search calls per minute.
    if active >= 80 then return false, 'Local safety limit: too many Auction House queries this minute.' end
    if priority ~= 'MANUAL' then
        if active >= 6 then return false, 'Automatic price refresh limit reached.' end
        if latest and now - latest < 5 then return false, 'Automatic price refresh waiting for query interval.' end
    end
    return true
end
function S:MarkTargetQuery()
    if not self:IsWritable() then return false end
    local times, fresh = self.account.queryGuard.times, {}
    local now = W.Clock()
    for _, at in ipairs(times) do
        if at <= now and now - at < 60 then fresh[#fresh + 1] = at end
    end
    fresh[#fresh + 1] = now
    self.account.queryGuard.times = fresh
    return true
end
