local _, W = ...
W.Compat = {}
local C = W.Compat
-- Reviewed source tuples are diagnostic evidence only. The complete 70938 -> 70959 tree
-- comparison retains every auction UI/API and item/container API blob.
-- The 70959 -> 71037 comparison also retains these API blobs.
-- See Docs/P4_71037_SOURCE_REVIEW.json and the release source review.
-- Source matching is not native runtime qualification.
local reviewedBuilds = {[70938]=true, [70959]=true, [71037]=true}
local function readable(value)
    if type(issecretvalue)=='function' then
        local ok,result=pcall(issecretvalue,value)
        if not ok or result==true then return false end
    end
    if type(canaccessvalue)=='function' then
        local ok,result=pcall(canaccessvalue,value)
        if not ok or result==false then return false end
    end
    return true
end
local function identityNumber(value)
    if not readable(value) or (type(value)~='number' and type(value)~='string') then return 0 end
    local number=tonumber(value)
    return W.Math.ValidInteger(number,1,999999999) and number or 0
end
local function identityText(value)
    return readable(value) and type(value)=='string' and #value>0 and #value<=80 and
        not value:find('[%c|/]') and value or nil
end
local candidateNames = {
    'ReplicateItems', 'GetNumReplicateItems', 'GetReplicateItemInfo',
    'GetReplicateItemLink', 'IsThrottledMessageSystemReady',
    'SendSearchQuery', 'MakeItemKey', 'SearchForItemKeys', 'GetItemKeyInfo',
    'GetNumItemSearchResults', 'GetItemSearchResultInfo', 'HasFullItemSearchResults',
    'GetNumCommoditySearchResults', 'GetCommoditySearchResultInfo', 'HasFullCommoditySearchResults',
    'RequestMoreItemSearchResults', 'RequestMoreCommoditySearchResults',
    'SendBrowseQuery','GetBrowseResults','RequestMoreBrowseResults',
    'QueryOwnedAuctions','GetOwnedAuctions','GetNumOwnedAuctions','QueryBids','GetBids',
    'IsSellItemValid','GetItemCommodityStatus','SupportsCopperValues',
    'PlaceBid','StartCommoditiesPurchase','ConfirmCommoditiesPurchase',
    'PostItem','PostCommodity','ConfirmPostItem','ConfirmPostCommodity',
    'CancelAuction','CanCancelAuction','GetCancelCost','GetQuoteDurationRemaining','CloseAuctionHouse',
    'GetItemKeyFromItem','CalculateItemDeposit','CalculateCommodityDeposit','GetAvailablePostCount',
    'CancelCommoditiesPurchase','CancelSell',
}
function C:ReadBuild()
    local version, build, date, interface
    if type(GetBuildInfo) == 'function' then
        local ok, a, b, c, d = pcall(GetBuildInfo)
        if ok then version, build, date, interface = a, b, c, d end
    end
    self.build = {
        version = identityText(version) or 'unknown',
        build = identityNumber(build), date = identityText(date),
        interface = identityNumber(interface), projectID = identityNumber(WOW_PROJECT_ID),
    }
    local b = self.build
    b.foreverCandidate = b.version == W.targetVersion and b.interface == W.targetInterface
    b.exactTarget = b.foreverCandidate and reviewedBuilds[b.build] == true
    b.runtimeAllowed = readable(false) and readable(0) and readable('') -- operations still check their APIs/context
    b.identityKnown = b.build > 0 and b.interface > 0 and b.version ~= 'unknown'
    b.marketFlavor = b.interface>0 and (b.interface == 16001 and 'Forever' or ('Client'..tostring(b.interface))) or nil
    b.status = not b.runtimeAllowed and 'VALUE_BOUNDARY_UNAVAILABLE' or
        b.exactTarget and 'TARGET_SOURCE_MATCH' or 'UNREVIEWED_CLIENT_API_GUARDED'
    return b
end
function C:Probe()
    self:ReadBuild()
    self.auction = type(C_AuctionHouse) == 'table' and C_AuctionHouse or nil
    local APIs = {}
    for _, name in ipairs(candidateNames) do
        local ok,fn=pcall(function()return self.auction and self.auction[name]end)
        APIs[name] = ok and readable(fn) and type(fn) == 'function' or false
    end
    self.APIs = APIs
    return APIs
end
function C:CanScan()
    if W.HasEvent and not W.HasEvent('REPLICATE_ITEM_LIST_UPDATE') then return false,'Full-scan result event unavailable; see /wc startup.' end
    if not self.build then self:Probe() end
    if not self.build.runtimeAllowed then return false, 'Readable value boundary unavailable.' end
    if not self.build.identityKnown then return false, 'Client identity unavailable for market records.' end
    if not self.APIs or not self.APIs.ReplicateItems or not self.APIs.GetNumReplicateItems or
        not self.APIs.GetReplicateItemInfo or not self.APIs.GetReplicateItemLink then
        return false, 'Replication and item-link APIs required for reliable identity are missing.'
    end
    return true
end
function C:Format()
    local b = self.build or self:ReadBuild()
    return ('%s / %d / %d (%s)'):format(b.version, b.build, b.interface, b.status)
end

function C:CanTarget()
    if W.HasEvent and (not W.HasEvent('ITEM_SEARCH_RESULTS_UPDATED') or not W.HasEvent('COMMODITY_SEARCH_RESULTS_UPDATED')) then return false,'Targeted result events unavailable; use Blizzard view.' end
    if not self.build then self:Probe() end
    if not self.build.runtimeAllowed then return false, 'Readable value boundary unavailable.' end
    if not self.build.identityKnown then return false, 'Client identity unavailable for market records.' end
    for _, name in ipairs({'SendSearchQuery', 'MakeItemKey', 'GetNumItemSearchResults',
        'GetItemSearchResultInfo', 'HasFullItemSearchResults', 'GetNumCommoditySearchResults',
        'GetCommoditySearchResultInfo', 'HasFullCommoditySearchResults'}) do
        if not self.APIs or not self.APIs[name] then
            return false, 'Missing targeted search API: ' .. name
        end
    end
    return true
end
