-- G0/G1/G4: Additive, read-only price view. Exact hyperlink normalization,
-- source qualification and market scope remain owned by ItemLinkBridge.
-- Not a replacement for the v6 public price/quote contract.
local _,W=...
W.PriceView={contractVersion=1,cache={},cacheCount=0,lookups=0,hits=0,invalidations=0}
local V=W.PriceView
local MAX_CACHE=64
local function valid(v)
    return type(v)=='number' and v==v and v>0 and v<=9000000000000 and v%1==0
end
local function age(now,at)
    if type(at)~='number' or at<1 or at>now then return nil end
    return math.max(0,now-at)
end
local function hash(value)
    local h=5381
    for i=1,math.min(500,#value)do h=(h*33+value:byte(i))%2147483647 end
    return tostring(h)
end
function V:Invalidate(reason)
    self.cache={};self.cacheCount=0;self.invalidations=(self.invalidations or 0)+1
    self.lastInvalidation=type(reason)=='string' and reason:sub(1,70) or 'SOURCE_CHANGED'
end
local function role(kind,label,price,details)
    if not valid(price) then return nil end
    local result={kind=kind,label=label,valueCopper=price,basis='ONE_ITEM'}
    if type(details)=='table' then for k,v in pairs(details)do result[k]=v end end
    return result
end
local function fromQuote(link,q,reason)
    local now=W.Clock()
    local observed=age(now,q and q.observedAt) and q.observedAt or nil
    local seconds=observed and age(now,observed) or nil
    if seconds==nil then return nil,'PRICE_AGE_UNKNOWN' end
    local reference=q and q.priceCopper
    if not valid(reference) then return nil,'PRICE_BASIS_UNKNOWN' end
    local average=valid(q.averageCopper) and q.averageCopper or nil
    local low=valid(q.floorCopper) and q.floorCopper or nil
    local high=valid(q.p75Copper) and q.p75Copper or nil
    local range=(low and high and high>=low) and
        {label=W.DataLanguage:Label('measuredRange'),lowerCopper=low,upperCopper=high,
         upperBoundary='APPROXIMATE_P75_NOT_MAX',basis='ONE_ITEM'} or nil
    local stale=seconds>172800 or q.status=='STALE'
    local limited=q.coverage~='COMPLETE_REPLICATION' or q.completeDepth~=true or
        (q.listings or 0)<3 or (q.units or 0)<3
    -- Only a recent, unambiguous full-scan reference can support buyer-facing
    -- red/green comparison. Partial and last-saved observations remain useful
    -- historical information but are not comparable live bargains.
    local comparable=not stale and not limited and seconds<=1800 and
        q.identityPrecision=='EXACT_WEALTHCRAFT_VARIANT' and
        q.marketContextMode=='CURRENT' 
    local model={
        priceViewContractVersion=1,model='WEALTHCRAFT_PRICE_VIEW_1',readOnly=true,
        status=stale and 'STALE' or limited and 'LIMITED' or 'AVAILABLE',reason=stale and 'OLDER_OBSERVATION' or
            limited and 'LIMITED_OBSERVED_SAMPLE' or 'AVAILABLE',
        item={requestedLink=link,itemID=q.itemID,identity=q.identity,
            precision=q.identityPrecision},
        market={key=q.marketKey,label=q.marketLabel,mode=q.marketContextMode,
            source=q.marketContextSource,venueStatus=q.venueStatus,venueVerified=false,
            sourceBuild=q.sourceBuild},
        roles={
            reference=role('HISTORICAL_REFERENCE',W.DataLanguage:Label('marketReference'),reference,
                {method=q.method}),
            average=role('QUANTITY_WEIGHTED_MEAN',W.DataLanguage:Label('averageAsk'),average),
            measuredRange=range,
        },
        quality={status=stale and 'STALE' or limited and 'LIMITED' or 'AVAILABLE',
            reason=stale and 'OLDER_OBSERVATION' or limited and 'LIMITED_OBSERVED_SAMPLE' or 'AVAILABLE',
            exactVariant=q.identityPrecision=='EXACT_WEALTHCRAFT_VARIANT',
            comparisonEligible=comparable,
            comparisonReason=comparable and 'QUALIFIED_REFERENCE' or
                (stale and 'OLDER_OBSERVATION' or limited and 'LIMITED_OBSERVED_SAMPLE' or
                q.marketContextMode~='CURRENT' and 'LAST_SAVED_MARKET' or
                seconds>1800 and 'REFERENCE_TOO_OLD_FOR_COMPARISON' or 'ITEM_VARIANT_UNVERIFIED'),
            noSalesEvidence=true},
        provenance={source=q.source,snapshotID=q.sourceSnapshotID,revision=q.sourceRevision,
            method=q.method,coverage=q.coverage,completeDepth=q.completeDepth==true},
        freshness={observedAt=observed,ageSeconds=seconds,maxComparisonAgeSeconds=1800,
            isCurrentMarket=q.marketContextMode=='CURRENT'},
        sample={listings=q.listings,pricedListings=q.pricedListings,units=q.units,
            completeness=q.coverage,marketDepthClaim='NOT_CLAIMED'},
        basis='ONE_ITEM',salesEvidence='NOT_CLAIMED',profitEvidence='NOT_CLAIMED',
        nativeQualification='NOT_RUN',
        -- Legacy bridge aliases for existing UI presentation only; the public
        -- semantic contract above is authoritative.
        priceCopper=reference,referenceCopper=reference,averageCopper=average,
        floorCopper=low,p75Copper=high,ageSeconds=seconds,observedAt=observed,
        marketKey=q.marketKey,source=q.source,identity=q.identity,statusLegacy=q.status,
        listings=q.listings,units=q.units,sourceRevision=q.sourceRevision,
        requestedLink=link,sourceSnapshotID=q.sourceSnapshotID,
    }
    return model,'AVAILABLE'
end
-- Price views contain only bounded, addon-authored scalar records.
local function copyView(view)
    local copy={}
    for k,v in pairs(view) do
        copy[k]=type(v)=='table' and copyView(v) or v
    end
    return copy
end
function V:Get(link,context)
    self.lookups=self.lookups+1
    local validContext,contextReason,stack,requestedMarket=W.ItemLinkBridge:ValidateContext(context)
    if not validContext then return nil,contextReason end
    local revision,revisionReason=W.ItemLinkBridge:GetRevision()
    if type(revision)~='string' then return nil,revisionReason or 'QUOTE_REVISION_UNAVAILABLE' end
    if type(link)~='string' or #link>600 then return nil,'FULL_ITEM_LINK_REQUIRED' end
    local token=link..'\31'..tostring(stack or '')..'\31'..tostring(requestedMarket or '')
    local entry=self.cache[token]
    if entry and entry.revision==revision and entry.view and age(W.Clock(),entry.observedAt) then
        self.hits=self.hits+1
        local v=entry.view
        -- Every caller receives independent price, quality and provenance records.
        local out=copyView(v)
        local freshness=out.freshness
        freshness.ageSeconds=age(W.Clock(),freshness.observedAt)
        out.ageSeconds=freshness.ageSeconds
        if freshness.ageSeconds and freshness.ageSeconds>172800 then
            out.status='STALE';out.reason='OLDER_OBSERVATION'
            if type(out.quality)=='table' then
                out.quality.status='STALE'
                out.quality.reason='OLDER_OBSERVATION'
            end
        end
        if type(out.quality)=='table' then
            -- Cache hits must not keep a once-eligible buyer comparison fresh.
            if not freshness.ageSeconds or freshness.ageSeconds>1800 then
                out.quality.comparisonEligible=false
                out.quality.comparisonReason=out.status=='STALE' and 'OLDER_OBSERVATION' or
                    out.quality.status=='LIMITED' and 'LIMITED_OBSERVED_SAMPLE' or
                    not freshness.isCurrentMarket and 'LAST_SAVED_MARKET' or 'REFERENCE_TOO_OLD_FOR_COMPARISON'
            end
        end
        return out,'AVAILABLE'
    end
    local ok,q,reason=pcall(W.ItemLinkBridge.Get,W.ItemLinkBridge,link,context)
    if not ok then return nil,'PROVIDER_DATA_UNREADABLE' end
    if not q then return nil,reason or 'NO_SAVED_QUOTE' end
    local result,why=fromQuote(link,q,reason)
    if not result then return nil,why end
    if type(stack)=='number' and stack>=1 and stack<=1000000 and stack%1==0 then
        result.stackCount=stack
        if result.priceCopper<=math.floor(9000000000000/stack) then
            result.stackCopper=result.priceCopper*stack
            result.stackBasis='CALLER_OBSERVED_COUNT'
        else result.stackBasis='TOTAL_EXCEEDS_SUPPORTED_RANGE' end
    else result.stackBasis='NOT_SUPPLIED' end
    -- Cache only a bounded number of qualified observations. Failed lookups
    -- are never cached, so an item-data event can immediately change them.
    if self.cacheCount>=MAX_CACHE and not self.cache[token] then self:Invalidate('CACHE_CAPACITY') end
    if not self.cache[token] then self.cacheCount=self.cacheCount+1 end
    self.cache[token]={revision=revision,view=copyView(result),observedAt=result.freshness.observedAt}
    return result,'AVAILABLE'
end
function V:ForItemKey(itemKey,marketKey)
    -- A base key may be used by existing Shop/recipe paths, but cannot be
    -- presented as a verified EXACT item-link quote to external consumers.
    local q=W.Quotes:ForWatch(W.ItemKinds:Key(itemKey),marketKey)
    if not q or not valid(q.priceCopper) then return nil,'NO_QUALIFIED_OBSERVATION' end
    local now=W.Clock()
    -- Never manufacture a just-recorded timestamp for missing age evidence.
    if type(q.ageSeconds)~='number' or q.ageSeconds~=q.ageSeconds or
        q.ageSeconds<0 or q.ageSeconds>315360000 then return nil,'PRICE_AGE_UNKNOWN' end
    local observed=now-q.ageSeconds
    local ageSeconds=age(now,observed)
    if ageSeconds==nil then return nil,'PRICE_AGE_UNKNOWN' end
    return {priceViewContractVersion=1,model='WEALTHCRAFT_BASE_KEY_VIEW_1',readOnly=true,
        status=(q.status=='STALE' or (ageSeconds or math.huge)>172800) and 'STALE' or 'LIMITED',
        reason='BASE_KEY_NOT_EXACT_LINK_PROOF',item={itemID=itemKey and itemKey.itemID,precision='BASE_KEY_ONLY'},
        market={key=marketKey,mode='CURRENT_OR_LAST_SAVED_UNVERIFIED'},
        roles={reference=role('HISTORICAL_REFERENCE',W.DataLanguage:Label('marketReference'),q.priceCopper),
            average=role('QUANTITY_WEIGHTED_MEAN',W.DataLanguage:Label('averageAsk'),q.averageCopper),
            measuredRange=valid(q.floorCopper) and valid(q.p75Copper) and q.p75Copper>=q.floorCopper and
                {label=W.DataLanguage:Label('measuredRange'),lowerCopper=q.floorCopper,upperCopper=q.p75Copper,
                 upperBoundary='APPROXIMATE_P75_NOT_MAX',basis='ONE_ITEM'} or nil},
        freshness={observedAt=observed,ageSeconds=ageSeconds,maxComparisonAgeSeconds=1800},
        quality={status='LIMITED',reason='BASE_KEY_NOT_EXACT_LINK_PROOF',
            exactVariant=false,comparisonEligible=false,comparisonReason='ITEM_VARIANT_UNVERIFIED'},
        provenance={source=q.source,snapshotID=q.snapshotID,coverage=q.completeDepth and 'COMPLETE_REPLICATION' or 'LIMITED'},
        priceCopper=q.priceCopper,averageCopper=q.averageCopper,floorCopper=q.floorCopper,
        p75Copper=q.p75Copper,ageSeconds=ageSeconds,source=q.source,identity=q.identity,
        listings=q.listings,units=q.units,marketKey=marketKey,variationPct=q.variationPct,spreadPct=q.spreadPct,method=q.method,completeDepth=q.completeDepth},'LIMITED'
end
function V:Select(kind,link,context)
    if kind~='TOOLTIP' and kind~='HISTORICAL_REFERENCE' and kind~='LIVE_BUY' and kind~='CRAFTING' then
        return nil,'UNSUPPORTED_QUOTE_ROLE'
    end
    if kind=='LIVE_BUY' then
        -- Live price is native-result evidence, not a saved historical quote.
        -- It may only be supplied from the active browse results in this visit.
        if not W.runtime.ahOpen or W.Browse.state~='READY' or W.Browse.session~=W.runtime.ahSession or
            W.Browse.marketKey~=W.Scope:ReadMarketKey() then return nil,'NO_CURRENT_LIVE_RESULTS' end
        local identity,id=W.ItemLinkBridge:Normalize(link)
        if not identity then return nil,'FULL_ITEM_LINK_REQUIRED' end
        for _,row in ipairs(W.Browse.results or {})do
            if row.itemLink and row.itemLink==link and row.itemID==id and valid(row.minPrice) and age(W.Clock(),row.observedAt) then
                return {model='WEALTHCRAFT_LIVE_VIEW_1',readOnly=true,status='AVAILABLE',
                    role='LOWEST_ASK',priceCopper=row.minPrice,marketKey=W.Browse.marketKey,
                    itemID=id,identity=identity,unitBasis='ONE_ITEM',
                    observedAt=row.observedAt,source='BROWSE_LIVE',session=W.Browse.session,
                    marketDepthClaim='RETURNED_ROWS_ONLY'},'AVAILABLE'
            end
        end
        return nil,'NO_EXACT_LIVE_LISTING'
    end
    if kind=='CRAFTING' then
        local view,why=self:Get(link,context)
        if not view then return nil,why end
        if view.provenance.coverage~='COMPLETE_REPLICATION' or
            view.provenance.completeDepth~=true then return nil,'CRAFTING_REQUIRES_COMPLETE_SCAN' end
        if view.status=='STALE' or not view.freshness.ageSeconds or
            view.freshness.ageSeconds>172800 then return nil,'CRAFTING_REFERENCE_OLDER_THAN_48H' end
        if (view.sample.listings or 0)<3 or (view.sample.units or 0)<3 then
            return nil,'CRAFTING_REFERENCE_SAMPLE_TOO_SMALL' end
        return view,'AVAILABLE'
    end
    return self:Get(link,context)
end
function V:Trace(link,context)
    -- No character name, realm name, raw hyperlink or market key is emitted.
    local id=type(link)=='string' and tonumber(link:match('item:(%d+)')) or nil
    local view,reason=self:Get(link,context)
    local market=view and view.market or {}
    local provenance=view and view.provenance or {}
    return {contract=1,itemID=id,marketFingerprint=market.key and hash(market.key) or 'UNKNOWN',
        marketMode=market.mode or 'UNKNOWN',identityPrecision=view and view.item.precision or 'UNAVAILABLE',
        source=provenance.source or 'NONE',revision=provenance.revision or 0,
        ageSeconds=view and view.freshness.ageSeconds or nil,
        status=view and view.status or 'UNAVAILABLE',reason=view and view.reason or reason,
        referenceCopper=view and view.priceCopper or nil,
        evidence='RECORDED_ASKS_NOT_SALES'}
end
function V:Status()
    return {contractVersion=self.contractVersion,lookups=self.lookups,hits=self.hits,
        cached=self.cacheCount,invalidations=self.invalidations,lastInvalidation=self.lastInvalidation}
end
