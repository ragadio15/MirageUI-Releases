-- Wealthcraft G4: read-only listing guidance, no protected AH action.
local _, W = ...
W.Sell = {}
local A = W.Sell
function A:Analyze(key, marketKey)
    marketKey = marketKey or W.Scope:ReadMarketKey()
    if not W.Compat.build or not (W.Compat.build.runtimeAllowed or W.Compat.build.exactTarget) then
        return {status='CLIENT_UNQUALIFIED',eligible=false,marketKey=marketKey} end
    if type(marketKey) ~= 'string' or marketKey == '' then
        return {status = 'NO_MARKET_CONTEXT', eligible = false}
    end
    if type(key) ~= 'table' then return {status = 'ITEM_KEY_REQUIRED', eligible = false} end
    local watchKey, normalized = W.Storage:WatchKey(key)
    if not watchKey then return {status = 'INVALID_ITEM_KEY', eligible = false} end
    local quote, reason, identity = W.Quotes:ForWatch(normalized, marketKey)
    if not quote or not W.Math.ValidInteger(quote.priceCopper, 1) then
        return {status = reason or 'NO_PRICE_EVIDENCE', eligible = false,
            marketKey = marketKey, itemID = key.itemID}
    end
    local result = {
        status = 'EVIDENCE_ONLY', eligible = false, marketKey = marketKey,
        itemID = key.itemID, identity = identity,
        observedCopper = quote.priceCopper, floorCopper = quote.floorCopper,
        source = quote.source, ageSeconds = quote.ageSeconds,
        listings = quote.listings or 0, unitCount = quote.units or 0,
        assumedFeeBps = W.Storage:AssumedFeeBps(),
        assumption = 'Assumed sale fee, not observed. Listing deposits excluded.',
    }
    -- A partial full-scan subset may contain useful observed prices but not a
    -- reliable depth basis for suggested listings. Never offer numeric ranges.
    if quote.status == 'PARTIAL_SAMPLE' or quote.source == 'PARTIAL_REPLICATION_EXACT_LINKS' then
        result.status = 'PARTIAL_SAMPLE_NO_RANGE'; return result
    end
    if quote.ageSeconds == nil or quote.ageSeconds > 48 * 3600 then
        result.status = 'STALE_OBSERVATION_NO_RANGE'; return result
    end
    if result.listings < 3 or result.unitCount < 3 then
        result.status = 'THIN_OBSERVATION_NO_RANGE'; return result
    end
    local price, floor = quote.priceCopper, quote.floorCopper or quote.priceCopper
    if not W.Math.ValidInteger(price, 1, 9007199254740991) or
        not W.Math.ValidInteger(floor, 1, 9007199254740991) then
        result.status = 'INVALID_PRICE_EVIDENCE'; return result
    end
    -- A gentle reference range, not a recommended action to post/bid/cancel.
    local low = math.max(1, math.floor(math.min(price, floor * 1.03) + 0.5))
    local p75=quote.p75Copper
    -- Do not stretch the suggested upper range beyond an observed Q75 when
    -- that percentile exists. Legacy scans still use the guarded 10% band.
    local top=price*1.10
    if W.Math.ValidInteger(p75,1,9007199254740991) and p75>=price then top=math.min(top,p75) end
    local high = math.min(9007199254740991, math.floor(top+0.5))
    if high < low then high = low end
    result.lowCopper, result.referenceCopper, result.highCopper = low, price, high
    result.netReferenceCopper = math.floor(price * (10000 - result.assumedFeeBps) / 10000 + 0.5)
    result.status, result.eligible = 'INDICATIVE_RANGE', true
    return result
end
