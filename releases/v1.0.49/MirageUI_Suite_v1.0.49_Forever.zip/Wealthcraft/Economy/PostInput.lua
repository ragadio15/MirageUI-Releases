-- P39-D: shared, integer-copper input grammar for reviewed auction postings.
-- Empty denominations mean zero; malformed, negative and fractional values
-- never silently become a price. All prices are integers in copper.
local _,W=...
W.PostInput={}
local P=W.PostInput
local function text(v)
    if type(v)=='table' and type(v.GetText)=='function' then v=v:GetText()end
    if v==nil then return '' end
    if type(v)~='string' and type(v)~='number' then return nil end
    return tostring(v):match('^%s*(.-)%s*$')
end
local function integer(v,min,max)
    v=text(v)
    if v==nil then return nil end
    if v=='' then return 0 end
    if not v:match('^%d+$') then return nil end
    local n=tonumber(v)
    if not W.Math.ValidInteger(n,min,max) then return nil end
    return n
end
function P:Money(fields)
    if type(fields)~='table' or fields[1]==nil or fields[2]==nil or fields[3]==nil then
        return nil,'Price fields unavailable.' end
    local g=integer(fields[1],0,100000000)
    local s=integer(fields[2],0,99)
    local c=integer(fields[3],0,99)
    if not g or not s or not c then
        return nil,'Use whole gold, silver (0–99), and copper (0–99). Unused boxes may be blank.'
    end
    return g*10000+s*100+c
end
function P:Quantity(value)
    local n=integer(value,1,100000)
    if not n or n<1 then return nil,'Enter a whole quantity of at least one.' end
    return n
end
function P:Listing(mode,quantity,priceFields,bidFields)
    if mode~='buyout' and mode~='bid' and mode~='both' then return nil,'Choose a listing type.' end
    local qty,err=self:Quantity(quantity)
    if not qty then return nil,err end
    local price;price,err=self:Money(priceFields)
    if price==nil then return nil,err end
    if mode=='buyout' then
        if price==0 then return nil,'Enter a buyout price above zero.' end
        return {quantity=qty,unitCopper=price,bidCopper=nil,mode=mode}
    end
    if mode=='bid' then
        if price==0 then return nil,'Enter a starting bid above zero.' end
        return {quantity=qty,unitCopper=0,bidCopper=price,mode=mode}
    end
    local bid;bid,err=self:Money(bidFields)
    if bid==nil then return nil,err end
    if price==0 or bid==0 then return nil,'Bid + buyout requires both positive prices.' end
    if bid>price then return nil,'Starting bid cannot exceed the buyout price.' end
    return {quantity=qty,unitCopper=price,bidCopper=bid,mode=mode}
end
