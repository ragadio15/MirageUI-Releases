-- G6 presentation-only explanations. No pricing formulas, market keys or action ownership change.
local _,W=...
W.Decision={}
local D=W.Decision
function D:Age(at)
    if not W.Math.ValidNumber(at) or at<=0 then return 'not recorded' end
    local age=math.max(0,W.Clock()-at)
    if age<60 then return 'just now' end
    if age<3600 then return math.floor(age/60)..'m ago' end
    if age<86400 then return math.floor(age/3600)..'h ago' end
    return math.floor(age/86400)..'d ago'
end
function D:Money(value)
    if not W.Math.ValidNumber(value) or value<0 then return 'Unknown' end
    return W.UI and W.UI.Money and W.UI:Money(value) or W.Prices:Money(math.floor(value))
end
function D:Market()
    local ctx=W.Scope:ReadContext()
    local m=ctx.market
    local complete=m and m.snapshots and m.snapshots[1]
    local partial=m and m.partial
    local latest=complete
    if partial and (not latest or partial.finishedAt>latest.finishedAt) then latest=partial end
    local coverage=latest and latest.count and latest.count>0 and
        math.min(100,math.max(0,(latest.preciseRows or math.max(0,(latest.handled or 0)-(latest.ambiguous or 0)))*100/latest.count)) or nil
    local inv=W.Inventory and W.Inventory.snapshot
    local current=inv and W.Inventory:IsCurrent(ctx.key)
    local units=current and ((inv.valuedUnits or 0)+(inv.unknownUnits or 0)) or nil
    return {context=ctx,key=ctx.key,complete=complete,partial=partial,latest=latest,
        coverage=coverage,label=ctx.label,mode=ctx.mode,
        age=latest and self:Age(latest.finishedAt) or 'not scanned',
        inventory=current and inv or nil,bagCoverage=units and units>0 and inv.valuedUnits*100/units or nil,
        watchCount=#W.Storage:WatchEntries()}
end
function D:Quote(quote,unitPrice)
    if type(quote)~='table' or not W.Math.ValidNumber(quote.priceCopper) or quote.priceCopper<=0 then
        return 'No market reference.','No price for this item variant.'
    end
    local source=quote.source or ''
    local partial=source:find('PARTIAL',1,true)~=nil or quote.status=='PARTIAL_SAMPLE'
    local age=type(quote.ageSeconds)=='number' and quote.ageSeconds>=0 and quote.ageSeconds or nil
    local quality=partial and 'Partial sample' or not age and 'Age unverified' or
        age>172800 and 'Old price' or 'Saved observation'
    local text='Market reference: '..self:Money(quote.priceCopper)..' / unit · '..quality
    local detail=(age and self:Age(quote.observedAt or (W.Clock()-age)) or 'Time unavailable')..
        '  |  '..tostring(quote.listings or '?')..' asking listings'
    if W.Math.ValidNumber(unitPrice) and unitPrice>0 then
        local eligible=type(quote.quality)=='table' and quote.quality.comparisonEligible==true
        local comparison=eligible and W.DataLanguage:Comparison(unitPrice,quote.priceCopper,age,1800)
        detail=detail..(comparison and ('  |  '..comparison.label) or '  |  Comparison unavailable for this sample')
    end
    if W.Math.ValidNumber(quote.floorCopper) and quote.floorCopper>0 and
        W.Math.ValidNumber(quote.p75Copper) and quote.p75Copper>=quote.floorCopper then
        detail=detail..'  |  Measured Range '..self:Money(quote.floorCopper)..
            ' – '..self:Money(quote.p75Copper)
    else
        detail=detail..'  |  Measured Range unavailable'
    end
    local movement=W.Signals and quote.identity and W.Signals:Label(quote.marketKey,quote.identity)
    if movement then detail=detail..'\n'..movement..' (asking prices)' end
    return text,detail..(partial and '\nIncomplete coverage; not a suggested selling price.' or
        '\nObserved listings, not confirmed sales.')
end
function D:TimeLeft(row)
    local seconds=row and row.timeLeftSeconds
    if W.Math.ValidNumber(seconds) and seconds>=0 then
        if seconds<60 then return '<1m' end
        if seconds<3600 then return math.ceil(seconds/60)..'m' end
        return math.ceil(seconds/3600)..'h'
    end
    local band=row and row.timeLeft
    local a=W.Compat.auction
    if band~=nil and a and type(a.GetTimeLeftBandInfo)=='function' then
        local ok,low,high=pcall(a.GetTimeLeftBandInfo,band)
        if ok and W.Math.ValidNumber(low) and W.Math.ValidNumber(high) and low>=0 and high>=low then
            return math.floor(low/3600)..'-'..math.ceil(high/3600)..'h'
        end
    end
    return 'Unknown'
end
function D:OwnedStatus(row,mode)
    if not row then return 'Unknown' end
    if mode=='bids' then
        local ok,guid=W.SafeCall(UnitGUID,'player')
        if ok and guid and row.bidder==guid then return 'High bidder' end
        return 'Bid listed'
    end
    local statuses=Enum and Enum.AuctionStatus
    if row.status==(statuses and statuses.Sold or 1) then return 'Sold (server status)' end
    if row.status==(statuses and statuses.Active or 0) then return 'Active' end
    return 'Status unknown'
end
