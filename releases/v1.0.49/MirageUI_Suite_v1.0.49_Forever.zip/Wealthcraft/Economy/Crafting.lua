-- G4 craft-versus-sell: interprets one client-returned recipe schematic at a time.
-- Does not assume reagent variants, currency costs, output quality or known recipes.
local _, W = ...
W.Crafting = {last = nil}
local C = W.Crafting
local MAX_AGE=48*3600
local function arrayCount(value,maximum)
    if type(value)~='table' then return nil end
    local count=0
    for key in pairs(value) do
        count=count+1
        if count>maximum or not W.Math.ValidInteger(key,1,maximum) then return nil end
    end
    for index=1,count do if value[index]==nil then return nil end end
    return count
end
local function getQuote(id, marketKey, snapshotID)
    if not W.Math.ValidInteger(id, 1, 999999999) then return nil, 'ITEM_ID_INVALID' end
    -- A recipe reports base item IDs, not exact output/reagent links. As in
    -- Insight, only unambiguous base variants from one complete scan qualify
    -- for an aggregate estimate. Separate targeted observations remain useful
    -- price references, but do not establish a coherent recipe margin.
    local quote = W.Prices:GetPrice(id, marketKey)
    if not quote or not W.Math.ValidInteger(quote.priceCopper, 1) then
        return nil, quote and quote.status or 'PRICE_NOT_OBSERVED'
    end
    if quote.completeDepth~=true or (quote.source~='PLAYER_INITIATED_FULL_SCAN' and quote.source~='AUTO_FULL_SCAN') or
        quote.snapshotID~=snapshotID or quote.marketKey~=marketKey then
        return nil, 'COMPLETE_SHARED_SCAN_REQUIRED'
    end
    if quote.identity~=('id='..id..';e=0;g=0,0,0,0;s=0;b=') then
        return nil,'BASE_ITEM_VARIANT_NOT_ESTABLISHED'
    end
    if not W.Math.ValidNumber(quote.ageSeconds) or quote.ageSeconds<0 or quote.ageSeconds > MAX_AGE then
        return nil, 'QUOTE_OLDER_THAN_48H'
    end
    return quote
end
function C:SelectedID()
    local api = C_TradeSkillUI
    if type(api) ~= 'table' or type(api.GetSelectedRecipeID) ~= 'function' then
        return nil, 'SELECTED_RECIPE_API_NOT_PRESENT'
    end
    local ok, v = pcall(api.GetSelectedRecipeID)
    if not ok or not W.Math.ValidInteger(v,1,999999999) then
        return nil, 'NO_SELECTED_RECIPE'
    end
    return v
end
function C:Analyze(recipeID, marketKey)
    self.generation=(self.generation or 0)+1
    local generation=self.generation
    local result = {status = 'UNAVAILABLE', recipeID = recipeID,
        marketKey = marketKey or W.Scope:ReadMarketKey(), reagents = {},
        missing = {}, source = 'LIVE_PROFESSION_API', at = W.Clock()}
    local account,character=W.Storage.account,W.Storage.character
    local market=W.Storage:GetMarket(result.marketKey)
    local snapshot=market and market.snapshots and market.snapshots[1]
    local function block(reason)
        result.missing[#result.missing + 1] = reason
        result.explanation=result.explanation or reason
        result.status = 'INCOMPLETE_INPUTS'
    end
    local function finish()
        if generation~=self.generation then
            result.status='CONTEXT_CHANGED';result.marginMinCopper=nil;result.marginMaxCopper=nil
            result.explanation='A newer recipe analysis replaced this request.'
            return result
        end
        self.last=result
        self.lastProof={account=account,character=character,snapshot=snapshot,
            snapshotID=snapshot and snapshot.id,finishedAt=snapshot and snapshot.finishedAt}
        return result
    end
    if not W.Math.ValidInteger(recipeID, 1, 999999999) then
        block('Valid recipe ID required'); return finish()
    end
    local b = W.Compat.build
    if not b or not (b.runtimeAllowed or b.exactTarget) then
        block('Client build has not been qualified'); return finish()
    end
    -- Recipe discovery and its material list remain useful even when a market
    -- price is not ready. Do not make the market a prerequisite for reading a
    -- client-confirmed schematic; only a qualified COMPLETE scan can price it.
    local qualifiedSnapshot=true
    if not W.Storage:IsWritable() then
        block('Saved data is read only; prices cannot be verified.')
        qualifiedSnapshot=false
    end
    if type(snapshot)~='table' or type(snapshot.id)~='string' or
        #snapshot.id==0 or not W.Math.ValidInteger(snapshot.finishedAt,1) then
        block('Complete market prices are unavailable; visit an auctioneer before estimating a margin.')
        qualifiedSnapshot=false;result.needsCompleteScan=true
    elseif not W.Math.ValidInteger(result.at,1) or result.at<snapshot.finishedAt or
        result.at-snapshot.finishedAt>MAX_AGE then
        block('Complete market prices are too old; refresh them before estimating a margin.')
        qualifiedSnapshot=false;result.needsCompleteScan=true
    end
    if qualifiedSnapshot then
        result.snapshotID=snapshot.id;result.observedAt=snapshot.finishedAt
        result.expiresAt=snapshot.finishedAt+MAX_AGE
        result.priceBasis='BASE_ITEMS_ONE_COMPLETE_SCAN'
    else
        result.priceBasis='SCHEMATIC_ONLY_NO_QUALIFIED_MARKET'
    end
    result.salesEvidence='NOT_CLAIMED'
    local api = C_TradeSkillUI
    if type(api) ~= 'table' or type(api.GetRecipeSchematic) ~= 'function' then
        block('GetRecipeSchematic API unavailable'); return finish()
    end
    local ok, schematic = pcall(api.GetRecipeSchematic, recipeID, false)
    if not ok or type(schematic) ~= 'table' or schematic.recipeID ~= recipeID then
        block('No matching schematic; open the profession panel and select a known recipe')
        return finish()
    end
    local info
    if type(api.GetRecipeInfo) == 'function' then
        local infoOK, val = pcall(api.GetRecipeInfo,recipeID)
        if infoOK and type(val)=='table' then info = val end
    end
    if not info or info.learned ~= true or (info.recipeID~=nil and info.recipeID~=recipeID) then
        block('The client has not confirmed that this recipe is learned.')
    end
    result.name = (type(schematic.name)=='string' and schematic.name) or
        (info and type(info.name)=='string' and info.name) or ('Recipe '..recipeID)
    local outputID=schematic.outputItemID
    if not W.Math.ValidInteger(outputID,1,999999999) and
        type(api.GetRecipeOutputItemData)=='function' then
        local outputOK, data = pcall(api.GetRecipeOutputItemData,recipeID)
        if outputOK and type(data)=='table' then outputID=data.itemID end
    end
    if not W.Math.ValidInteger(outputID,1,999999999) then block('Output item unavailable') end
    result.outputID = outputID
    local minQty,maxQty = schematic.quantityMin,schematic.quantityMax
    if not W.Math.ValidInteger(minQty,1,100000) or not
        W.Math.ValidInteger(maxQty,1,100000) or maxQty < minQty then
        block('Output yield is invalid or unspecified')
    else
        result.minYield, result.maxYield = minQty,maxQty
    end
    local slots=schematic.reagentSlotSchematics
    local slotCount=arrayCount(slots,60)
    if not slotCount or slotCount==0 then
        block('Reagent slots absent or outside safety limit')
    else
        result.materialCopper = 0
        for i,slot in ipairs(slots) do
            local required= type(slot)=='table' and slot.quantityRequired
            local choices= type(slot)=='table' and slot.reagents
            local optional = type(slot)=='table' and (slot.required==false or slot.quantityRequired==0)
            if optional then
                block('Optional material selections are unknown; their costs cannot be omitted from a margin.')
            else
                if not W.Math.ValidInteger(required,1,100000) or
                    arrayCount(choices,1)~=1 then
                    block('Reagent slot '..i..' is variable, missing or ambiguous')
                else
                    local reagent=choices[1]
                    local id=type(reagent)=='table' and reagent.itemID
                    if not W.Math.ValidInteger(id,1,999999999) then
                        block('Reagent slot '..i..' has no single item ID (currency/choice)')
                    else
                        local quote,why
                        if qualifiedSnapshot then quote,why=getQuote(id,result.marketKey,result.snapshotID)
                        else why='COMPLETE_SHARED_SCAN_REQUIRED' end
                        result.reagents[#result.reagents+1] = {
                            itemID=id,quantity=required,
                            unitCopper=quote and quote.priceCopper,
                            reason=not quote and why or nil,
                        }
                        if not quote then block('Material '..id..': '..tostring(why))
                        elseif quote.priceCopper*required > 9007199254740991 - result.materialCopper then
                            block('Material total exceeds safe range')
                        else result.materialCopper = result.materialCopper+quote.priceCopper*required end
                    end
                end
            end
        end
    end
    if outputID then
        local quote,why
        if qualifiedSnapshot then quote,why=getQuote(outputID,result.marketKey,result.snapshotID)
        else why='COMPLETE_SHARED_SCAN_REQUIRED' end
        if not quote then block('Output '..outputID..': '..tostring(why))
        else result.outputUnitCopper=quote.priceCopper;result.outputQuoteSource=quote.source end
    end
    local current=W.Storage:GetMarket(result.marketKey)
    if W.Storage.account~=account or W.Storage.character~=character or
        (qualifiedSnapshot and (not current or not current.snapshots or current.snapshots[1]~=snapshot or
            snapshot.id~=result.snapshotID or snapshot.finishedAt~=result.observedAt)) then
        block('The price source changed during analysis. Analyze this recipe again.')
    end
    local completedAt=W.Clock()
    if qualifiedSnapshot and (not W.Math.ValidInteger(completedAt,1) or
        completedAt<result.at or completedAt>result.expiresAt) then
        block('The complete scan expired during analysis. Visit an auctioneer for a new market refresh before estimating this recipe.')
    end
    if #result.missing==0 and result.outputUnitCopper and result.materialCopper and
        result.maxYield*result.outputUnitCopper <= 9007199254740991 then
        result.grossMinCopper=result.outputUnitCopper*result.minYield
        result.grossMaxCopper=result.outputUnitCopper*result.maxYield
        local bps=W.Storage:AssumedFeeBps()
        result.assumedFeeBps=bps
        local multiplier=(10000-bps)/10000
        result.marginMinCopper=math.floor(result.grossMinCopper*multiplier+0.5)-result.materialCopper
        result.marginMaxCopper=math.floor(result.grossMaxCopper*multiplier+0.5)-result.materialCopper
        result.status='ESTIMATED_MARGIN'
    else result.status='INCOMPLETE_INPUTS' end
    return finish()
end

function C:IsCurrent(marketKey)
    local result,proof=self.last,self.lastProof
    if not result or result.status~='ESTIMATED_MARGIN' or not proof or
        W.Storage.account~=proof.account or W.Storage.character~=proof.character or
        not W.Storage:IsWritable() then return false end
    marketKey=marketKey or W.Scope:ReadMarketKey()
    local market=W.Storage:GetMarket(marketKey)
    local now=W.Clock()
    return marketKey==result.marketKey and market and market.snapshots and market.snapshots[1]==proof.snapshot and
        proof.snapshot.id==proof.snapshotID and proof.snapshot.finishedAt==proof.finishedAt and
        W.Math.ValidInteger(now,1) and now>=result.at and now<=result.expiresAt and
        W.Storage:AssumedFeeBps()==result.assumedFeeBps
end
function C:Read(marketKey)
    local last=self.last
    if not last then return nil end
    -- Public/UI consumers receive their own small value model. They cannot
    -- edit the stored analysis or accidentally retain a current-looking margin
    -- after its market, scan, fee or age has changed.
    local result={}
    for key,value in pairs(last) do if type(value)~='table' then result[key]=value end end
    result.reagents={};result.missing={}
    for index,row in ipairs(last.reagents or {}) do
        local clone={};for key,value in pairs(row) do if type(value)~='table' then clone[key]=value end end
        result.reagents[index]=clone
    end
    for index,value in ipairs(last.missing or {}) do result.missing[index]=value end
    if last.status=='ESTIMATED_MARGIN' and not self:IsCurrent(marketKey) then
        result.status='STALE';result.explanation='Prices or fee assumptions changed. Analyze this recipe again.'
        for _,key in ipairs({'materialCopper','outputUnitCopper','grossMinCopper','grossMaxCopper','marginMinCopper','marginMaxCopper'}) do result[key]=nil end
        for _,row in ipairs(result.reagents) do row.unitCopper=nil end
    end
    return result
end
