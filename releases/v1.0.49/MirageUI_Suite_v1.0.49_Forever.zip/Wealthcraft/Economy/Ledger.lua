-- G4: explicit player-entered cash-flow ledger, no auction/mail/sale inference.
local _, W = ...
W.Ledger = {}
local L = W.Ledger
local types = {SALE=true,PURCHASE=true,INCOME=true,EXPENSE=true}
function L:Add(kind, itemID, quantity, unitCopper)
    if not W.Storage:IsWritable() then return false, 'STORAGE_READ_ONLY' end
    if not W.Storage:PersistenceReady() then return false, 'RELOAD_MARKERS_NOT_RESTORED' end
    if not types[kind] then return false,'INVALID_LEDGER_KIND' end
    itemID=tonumber(itemID) or 0
    quantity=tonumber(quantity)
    unitCopper=tonumber(unitCopper)
    if not W.Math.ValidInteger(itemID,0,999999999) or
        not W.Math.ValidInteger(quantity,1,100000000) or
        not W.Math.ValidInteger(unitCopper,0,9007199254740991) or
        quantity*unitCopper>9007199254740991 then return false,'INVALID_AMOUNT' end
    local ledger=W.Storage.character.ledger
    if #ledger.entries>=250 or ledger.nextID>10000000 then
        return false,'LEDGER_FULL_250_ENTRIES' end
    local entry={id=ledger.nextID,at=W.Clock(),kind=kind,itemID=itemID,
        quantity=quantity,unitCopper=unitCopper,source='PLAYER_MANUAL_UNVERIFIED'}
    if entry.at<1 then return false,'CLOCK_UNAVAILABLE' end
    ledger.nextID=ledger.nextID+1
    ledger.entries[#ledger.entries+1]=entry
    W.Diagnostics:Record('INFO','Manual ledger entry saved ('..kind..'); no sale verification implied')
    W.Refresh()
    return true,entry.id
end
function L:UndoLatest()
    if not W.Storage:IsWritable() then return false,'STORAGE_READ_ONLY' end
    local entries=W.Storage.character.ledger.entries
    if #entries==0 then return false,'LEDGER_EMPTY' end
    local last=table.remove(entries)
    W.Diagnostics:Record('INFO','Latest manual ledger entry removed: '..last.id)
    W.Refresh()
    return true,last.id
end
function L:Summary()
    local entries=W.Storage.character and W.Storage.character.ledger.entries or {}
    local income,expense,counts=0,0,{}
    for _,record in ipairs(entries) do
        local total=record.quantity*record.unitCopper
        if record.kind=='SALE' or record.kind=='INCOME' then income=income+total
        else expense=expense+total end
        counts[record.kind]=(counts[record.kind] or 0)+1
    end
    return {entries=#entries,incomeCopper=income,expenseCopper=expense,
        netCashFlowCopper=income-expense,counts=counts,
        provenance='PLAYER_MANUAL_UNVERIFIED',notProfit=true}
end
function L:Latest(limit)
    local result={}
    local source=W.Storage.character and W.Storage.character.ledger.entries or {}
    for i=#source,math.max(1,#source-(limit or 5)+1),-1 do
        result[#result+1]=source[i]
    end
    return result
end
