-- G1/G2: Public economic vocabulary. These labels describe observed asking
-- prices and authorized limits, never completed sales or guaranteed proceeds.
local _,W=...
W.DataLanguage={version=1}
local D=W.DataLanguage
D.labels={
    lowestAsk='Lowest ask / unit',offerPrice='Offer price / unit',listedUnits='Units listed',
    tierUnits='Units at price',marketReference='Market reference',
    averageAsk='Avg. asking price',measuredRange='Measured Range',
    estimatedTotal='Estimated total',spendingLimit='Spending limit',
    priceAllowance='Allowed price change',pricedBagSubtotal='Priced bag subtotal',
    identifiedRows='Scan rows identified',quickCheck='Quick check',
    potentialCraftMargin='Potential crafting margin',manualCashFlow='Manual cash flow',
}
D.definitions={
    marketReference='A recorded lower-quartile asking-price estimate per item; not a guaranteed sale price.',
    measuredRange='Recorded lowest ask through the approximate 75th-percentile ask. Not the full minimum-to-maximum range.',
    averageAsk='Quantity-weighted arithmetic mean of recorded asking prices; can differ from live offers.',
    estimatedTotal='Current purchase estimate for your chosen quantity, from returned live offer tiers.',
    spendingLimit='The maximum total you authorize for one purchase, including your selected price allowance.',
    pricedBagSubtotal='Indicative value of eligible priced carried items only; excludes bank, bound and unpriced items.',
    identifiedRows='Percentage of returned replication rows identified, NOT the percentage of the entire market scanned.',
}
function D:Label(key) return self.labels[key] or key end
function D:Definition(key) return self.definitions[key] end
function D:Age(seconds)
    if type(seconds)~='number' or seconds<0 or seconds~=seconds then return 'age unavailable' end
    if seconds<60 then return 'under 1m old' end
    if seconds<3600 then return math.floor(seconds/60)..'m old' end
    if seconds<86400 then return math.floor(seconds/3600)..'h old' end
    return math.floor(seconds/86400)..'d old'
end
-- Positive means a buyer would pay more than the recorded reference.
-- Display wording carries the sign as well as color for accessibility.
function D:Comparison(liveCopper,referenceCopper,ageSeconds,maxAge)
    if type(liveCopper)~='number' or type(referenceCopper)~='number' or
        liveCopper<=0 or referenceCopper<=0 or liveCopper~=liveCopper or referenceCopper~=referenceCopper then
        return nil,'NOT_COMPARABLE'
    end
    if type(ageSeconds)~='number' or ageSeconds<0 or ageSeconds>(maxAge or 1800) then
        return nil,'REFERENCE_TOO_OLD'
    end
    local change=(liveCopper/referenceCopper-1)*100
    if change~=change or change==math.huge or change==-math.huge then return nil,'NOT_COMPARABLE' end
    local magnitude=math.abs(change)
    local value=magnitude<.05 and '0%' or string.format('%+.1f%%',change)
    local direction=change>.05 and 'ABOVE' or change<-.05 and 'BELOW' or 'EQUAL'
    return {label=value..' vs market reference',percent=change,direction=direction,
        context='BUYER_COMPARISON',basis='ONE_ITEM'},'AVAILABLE'
end
function D:Copy()
    local out={version=self.version,labels={},definitions={}}
    for k,v in pairs(self.labels)do out.labels[k]=v end
    for k,v in pairs(self.definitions)do out.definitions[k]=v end
    return out
end
