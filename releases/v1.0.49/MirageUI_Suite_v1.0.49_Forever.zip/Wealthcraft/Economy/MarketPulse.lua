-- G13: compact per-scan evidence summaries. These are observations of ASKING
-- prices, never completed sales or a claim of identical market depth for
-- partial scans. No second copy of raw auction items is persisted.
local _,W=...
W.MarketPulse={maxMarkets=96,maxRecords=20}
local M=W.MarketPulse
local function valid(n,min,max)return W.Math.ValidInteger(n,min,max)end
function M:BeginSummary()
    return {variants=0,priced=0,wide=0,thin=0,lists=0,units=0}
end
function M:AddFinalized(summary,r)
    if type(summary)~='table' or type(r)~='table' then return end
    summary.variants=summary.variants+1
    if valid(r.listings,0) then summary.lists=summary.lists+r.listings end
    if valid(r.units,0) then summary.units=summary.units+r.units end
    if valid(r.averageCopper,1) then
        summary.priced=summary.priced+1
        if valid(r.listings,0) and r.listings<3 then summary.thin=summary.thin+1 end
        if type(r.spreadPct)=='number' and r.spreadPct>=50 then summary.wide=summary.wide+1 end
    end
end
function M:FinishSummary(record,summary)
    if type(record)~='table' or type(record.items)~='table' or
        not valid(record.count,1,500000) or type(summary)~='table' then return nil end
    local identified=record.preciseRows or math.max(0,(record.handled or 0)-(record.ambiguous or 0))
    if not valid(identified,0,record.count) then return nil end
    return {id=record.id,at=record.finishedAt or W.Clock(),
        kind=record.status=='COMPLETE' and 'COMPLETE' or 'PARTIAL',
        scanned=record.count,identified=identified,missing=record.unresolved or 0,
        coveragePct=math.floor(identified*10000/record.count+.5)/100,
        variants=summary.variants,pricedVariants=summary.priced,
        listedAuctions=summary.lists,listedUnits=summary.units,
        wideSpreadVariants=summary.wide,thinVariants=summary.thin}
end
function M:Summarize(record)
    if type(record)~='table' or type(record.items)~='table' then return nil end
    local summary=self:BeginSummary()
    for _,item in pairs(record.items)do self:AddFinalized(summary,item)end
    return self:FinishSummary(record,summary)
end
function M:Store(marketKey,stats)
    if not W.Storage:IsWritable() or type(marketKey)~='string' or #marketKey>160 or
        type(stats)~='table' or not valid(stats.at,1) then return false end
    local db=W.Storage.account
    local root=db.g13ScanTimeline
    if root==nil then root={format=1,markets={}};db.g13ScanTimeline=root end
    if type(root)~='table' or root.format~=1 or type(root.markets)~='table' then return false end
    local list=root.markets[marketKey]
    if not list then
        local total=0
        for _ in pairs(root.markets)do total=total+1 end
        if total>=self.maxMarkets then return false end
        list={};root.markets[marketKey]=list
    end
    if type(list)~='table' or #list>self.maxRecords then return false end
    for i=1,#list do if list[i].id==stats.id then list[i]=stats;return true end end
    table.insert(list,1,stats)
    while #list>self.maxRecords do table.remove(list)end
    return true
end
function M:Latest(marketKey)
    local db=W.Storage.account
    local root=db and db.g13ScanTimeline
    if not root or root.format~=1 or type(root.markets)~='table' then return nil end
    local list=type(marketKey)=='string' and root.markets[marketKey]
    if type(list)~='table' then return nil end
    return list[1],list
end
function M:ComparableChange(marketKey)
    local _,list=self:Latest(marketKey)
    if not list then return nil end
    local new,old
    for _,v in ipairs(list) do
        if v.kind=='COMPLETE' then
            if not new then new=v else old=v;break end
        end
    end
    if not new or not old or old.listedAuctions<=0 then return nil end
    return {current=new,previous=old,listingsChangePct=(new.listedAuctions/old.listedAuctions-1)*100}
end
local oldFull=W.Storage.CommitSnapshot
function W.Storage:CommitSnapshot(scope,record)
    local stats=record and record.g13Stats or M:Summarize(record)
    local ok,reason=oldFull(self,scope,record)
    if ok and stats then M:Store(scope.key,stats)end
    return ok,reason
end
local oldPartial=W.Storage.CommitPartial
function W.Storage:CommitPartial(scope,record)
    local stats=record and record.g13Stats or M:Summarize(record)
    local ok,reason=oldPartial(self,scope,record)
    if ok and stats then M:Store(scope.key,stats)end
    return ok,reason
end
