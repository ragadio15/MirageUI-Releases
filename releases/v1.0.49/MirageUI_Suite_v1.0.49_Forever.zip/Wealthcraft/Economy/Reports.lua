-- User-generated text summaries. No claimed sales/profit, no cross-market blending.
local _, W = ...
W.Reports = {}
local R = W.Reports
local function timeLabel(t) return t and tostring(t) or 'none' end
function R:Build(marketKey)
    marketKey = marketKey or W.Scope:ReadMarketKey()
    local market = W.Storage:GetMarket(marketKey)
    local latest = market and market.snapshots[1]
    local partial = market and market.partial
    local watches = W.Storage:WatchEntries()
    local bag = W.Inventory.snapshot
    local lines = {
        'WEALTHCRAFT / LOCAL MARKET REPORT',
        'Addon ' .. W.version .. ' / Forever build ' .. (W.Compat.build and W.Compat.build.build or '?'),
        'Generated at server time ' .. W.Clock(),
        'Market key: ' .. tostring(marketKey or 'NO_MARKET_SELECTED'),
        'Scope: automatic local auctioneer/visit partition; separate markets are never assumed equivalent.',
        'Observed listings only. No confirmed sales, guaranteed profit, or live external feed.',
        '',
        'FULL SCAN / RETURNED ROW QUALITY',
    }
    if latest then
        lines[#lines + 1] = 'Last complete replication: ' .. timeLabel(latest.finishedAt)
        lines[#lines + 1] = 'Auction listings: ' .. tostring(latest.count) .. ' / precise priced variants: ' .. tostring(latest.preciseCount)
        lines[#lines + 1] = 'Ambiguous rows (excluded from pricing): ' .. tostring(latest.ambiguous or 0)
        lines[#lines + 1] = 'Market reference: recorded lower-quartile asking-price estimate from buckets, not actual sales. Measured Range spans the observed low to the approximate upper quartile, not a full min/max.'
    else
        lines[#lines + 1] = 'No complete full scan for this market. Market depth is unknown.'
    end
    if partial then
        lines[#lines + 1] = 'PARTIAL exact-identity sample: '..tostring(partial.handled)..'/'..tostring(partial.count)..
            ' rows; '..tostring(partial.unresolved)..' uncached; '..tostring(partial.preciseCount)..' item variants.'
        lines[#lines + 1] = 'NOT full market depth; incomplete sample never replaces a completed snapshot.'
    end
    local stats,history
    if W.MarketPulse then stats,history=W.MarketPulse:Latest(marketKey) end
    if stats then
        lines[#lines+1]=''
        lines[#lines+1]='SCAN OBSERVATIONS (NOT SALES)'
        lines[#lines+1]=('Observed at %s · %s · %.1f%% of returned rows identified (not entire market)'):
            format(tostring(stats.at),stats.kind,stats.coveragePct)
        lines[#lines+1]=('Priced variants: %d / %d · asks: %d · listed units: %d'):
            format(stats.pricedVariants,stats.variants,stats.listedAuctions,stats.listedUnits)
        lines[#lines+1]=('Wide asking-price spreads: %d variants · sparse quote groups: %d'):
            format(stats.wideSpreadVariants,stats.thinVariants)
        lines[#lines+1]='Partial scan counts describe identified observations, not total market supply.'
        local change=W.MarketPulse:ComparableChange(marketKey)
        if change then lines[#lines+1]=string.format('Two completed scans: observed listing count %+0.1f%% (not a sale or demand measure)',change.listingsChangePct)end
        lines[#lines+1]='Retained scan summaries: '..#history..' (bounded, market-isolated)'
    end
    lines[#lines + 1] = ''
    lines[#lines + 1] = 'PERSONAL WATCHLIST (' .. #watches .. ' items; bounded AH-open refresh when enabled)'
    if #watches == 0 then lines[#lines + 1] = 'Empty' end
    for _, watch in ipairs(watches) do
        local entry, item = watch.key, watch.item
        local quote, identityReason, exactIdentity = W.Quotes:ForWatch(item, marketKey)
        local targeted = W.Storage:GetTarget(marketKey, entry)
        if quote and quote.priceCopper then
            local line = 'ID ' .. item.itemID .. ': ' .. W.Prices:Money(quote.priceCopper) ..
                ' / ' .. (type(quote.ageSeconds)=='number' and quote.ageSeconds>=0 and
                    W.DataLanguage:Age(quote.ageSeconds) or 'age unavailable') .. ' / ' .. quote.source
            local hist = exactIdentity and W.Prices:History(exactIdentity, marketKey, 2) or {}
            if (quote.source == 'PLAYER_INITIATED_FULL_SCAN' or quote.source == 'AUTO_FULL_SCAN') and #hist > 1 and hist[2].priceCopper and hist[2].priceCopper > 0 and
                hist[1].at ~= hist[2].at then
                local change = (hist[1].priceCopper / hist[2].priceCopper - 1) * 100
                line = line .. (' / full-scan asking-price change %+0.1f%%'):format(change)
            end
            if exactIdentity and W.Signals then
                local trend=W.Signals:Trend(marketKey,exactIdentity)
                if trend and trend.prior then
                    line=line..string.format(' / comparable targeted asks %+0.1f%% over %dm',
                        trend.changePct,math.floor(trend.elapsedSeconds/60))
                end
            end
            if quote.averageCopper then line=line..' / quantity-weighted average '..W.Prices:Money(quote.averageCopper)end
            if quote.medianCopper and quote.p75Copper then
                line=line..' / observed median '..W.Prices:Money(quote.medianCopper)..
                    ' / P75 '..W.Prices:Money(quote.p75Copper)
            end
            lines[#lines + 1] = line
        elseif targeted then
            local n = 0; local only
            for _, rec in pairs(targeted.items) do
                if rec.referenceCopper then n = n + 1; only = rec end
            end
            if n == 1 then
                lines[#lines + 1] = 'ID ' .. item.itemID .. ': targeted ' .. W.Prices:Money(only.referenceCopper) ..
                    ' / recorded ' .. timeLabel(targeted.updatedAt) .. ' / not full-market history'
            else
                lines[#lines + 1] = 'ID ' .. item.itemID .. ': targeted variants ' .. n ..
                    ' / no single-variant estimate'
            end
        else
            lines[#lines + 1] = 'ID ' .. item.itemID .. ': ' .. tostring(identityReason or 'NO_COVERAGE')
        end
    end
    lines[#lines + 1] = ''
    lines[#lines + 1] = 'CARRIED-BAG VALUATION (NEVER BANK OR ALT INVENTORY)'
    if not W.Inventory:IsCurrent(marketKey) then
        lines[#lines + 1] = 'Not evaluated for selected market; open Inventory and Refresh bags.'
    else
        lines[#lines + 1] = 'Captured at: ' .. timeLabel(bag.at)
        lines[#lines + 1] = 'Priced bag subtotal (carried only): ' .. (bag.valuedUnits>0 and W.Prices:Money(bag.valueCopper) or 'UNAVAILABLE (no priced units)')
        lines[#lines + 1] = 'Covered units: ' .. bag.valuedUnits .. '; unknown-price units: ' .. bag.unknownUnits ..
            '; bound excluded units: ' .. bag.boundUnits
        lines[#lines + 1] = 'Older-than-48h quote units excluded: '..tostring(bag.staleUnits or 0)
        lines[#lines + 1] = 'This is NOT a complete appraisal or a guaranteed sale value.'
    end
    lines[#lines + 1] = ''
    lines[#lines + 1] = 'SELLING / CRAFTING / MANUAL LEDGER'
    local sale = W.UI and W.UI.sellResult
    if sale and sale.marketKey==marketKey then
        lines[#lines + 1] = 'Last listing analysis: '..tostring(sale.status)..
            ' / item '..tostring(sale.itemID or '?')
        if sale.eligible then lines[#lines + 1] = 'Indicative listing range: '..
            W.Prices:Money(sale.lowCopper)..' to '..W.Prices:Money(sale.highCopper) end
    else lines[#lines + 1] = 'Listing advisor: not evaluated in this session.' end
    local craft = W.Crafting:Read(marketKey)
    if craft and craft.marketKey==marketKey then
        lines[#lines + 1] = 'Last recipe '..tostring(craft.recipeID or '?')..': '..craft.status
        if craft.status == 'ESTIMATED_MARGIN' then
            lines[#lines + 1] = 'Potential margin after assumed fee: '..
                W.Prices:Money(craft.marginMinCopper)..' to '..W.Prices:Money(craft.marginMaxCopper)
        end
    else lines[#lines + 1] = 'Recipe analysis: not evaluated in this session.' end
    local ledger = W.Ledger:Summary()
    lines[#lines + 1] = 'Player-entered ledger: '..ledger.entries..' entries; source MANUAL_UNVERIFIED.'
    lines[#lines + 1] = 'Manual inflows '..W.Prices:Money(ledger.incomeCopper)..
        ' / outflows '..W.Prices:Money(ledger.expenseCopper)
    lines[#lines + 1] = 'Cash flow is NOT realized profit and does not establish actual sales.'
    lines[#lines + 1] = 'Fee assumption: '..(W.Storage:AssumedFeeBps()/100)..
        '%; deposits and unobserved transaction costs excluded.'
    lines[#lines + 1] = ''
    lines[#lines + 1] = 'METHOD / RESTRICTIONS' 
    lines[#lines + 1] = 'Targeted prices require the client full-result indicator and matching item/commodity event.'
    lines[#lines + 1] = 'Auction result events are shared with other addons; association is temporal only.'
    lines[#lines + 1] = 'Auction House scans and character context refresh automatically when enabled. Purchases require a finite user authorization; no uploads or unattended trading.'
    lines[#lines + 1] = 'Repeat-check price movement compares exact item identities in one market only; it does not infer sales or demand.'
    lines[#lines + 1] = 'Economic decisions require exact identity, observed market, validated quantities and known recipes.'
    return table.concat(lines, '\n')
end
