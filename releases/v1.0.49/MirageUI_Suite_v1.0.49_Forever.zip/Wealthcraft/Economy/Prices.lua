local _, W = ...
W.Prices = {}
local P = W.Prices
-- 5%-wide logarithmic buckets above 1000 copper. Under 1000: exact copper.
local LOG_STEP = math.log(1.05)
local function bucket(price)
    if price <= 1000 then return math.floor(price) end
    return 1001 + math.floor(math.log(price / 1001) / LOG_STEP)
end
function P:Add(groups, row)
    local key = row.identity
    local group = groups[key]
    if not group then
        group = {
            identity = key, itemID = row.itemID, name = row.name or ('Item ' .. row.itemID),
            listings = 0, pricedListings = 0, units = 0, bidOnly = 0, floor = nil,
            weightedMean=0,weightedM2=0,
            buckets = {}, minBucket = nil, maxBucket = nil,
        }
        groups[key] = group
    end
    group.listings = group.listings + 1
    if row.buyout and row.buyout > 0 then
        local unitPrice = row.buyout / row.count
        if W.Math.ValidNumber(unitPrice) and unitPrice > 0 then
            local b = bucket(unitPrice)
            local entry = group.buckets[b]
            if not entry then
                entry = {units = 0, floor = unitPrice}
                group.buckets[b] = entry
            end
            entry.units = entry.units + row.count
            if unitPrice < entry.floor then entry.floor = unitPrice end
            if not group.floor or unitPrice < group.floor then group.floor = unitPrice end
            -- Exact quantity-weighted asking-price mean and population dispersion.
            -- Online updates avoid a huge sum of auction totals during large scans.
            local oldUnits=group.units
            local newUnits=oldUnits+row.count
            local delta=unitPrice-group.weightedMean
            local newMean=group.weightedMean+delta*row.count/newUnits
            group.weightedM2=group.weightedM2+row.count*delta*(unitPrice-newMean)
            group.weightedMean=newMean
            group.units=newUnits
            group.pricedListings = group.pricedListings + 1
            if not group.minBucket or b < group.minBucket then group.minBucket = b end
            if not group.maxBucket or b > group.maxBucket then group.maxBucket = b end
        end
    else
        group.bidOnly = group.bidOnly + 1
    end
end
-- Quantity-weighted price percentiles. Below 1000 copper buckets have exact
-- one-copper precision; above that they are 5%-wide logarithmic buckets.
-- These are ASKING-price distributions, not transactions, demand or volume sold.
function P:Finalize(group)
    local quantile, competitiveUnits = {}, 0
    if group.units > 0 and group.minBucket then
        local targets={.10,.25,.50,.75}
        local cumulative, slot=0,1
        for i = group.minBucket, group.maxBucket do
            local b=group.buckets[i]
            if b then
                cumulative=cumulative+b.units
                while slot<=#targets and cumulative >= math.max(1,group.units*targets[slot]) do
                    quantile[slot]=b.floor;slot=slot+1
                end
            end
        end
        local ref=quantile[2]
        if ref then
            for _,b in pairs(group.buckets) do
                if b.floor <= ref * 1.10 then competitiveUnits=competitiveUnits+b.units end
            end
        end
    end
    local function toCopper(n)
        return n and math.max(1,math.floor(n+0.5)) or nil
    end
    local p10,p25,p50,p75=toCopper(quantile[1]),toCopper(quantile[2]),
        toCopper(quantile[3]),toCopper(quantile[4])
    local mean=group.units>0 and toCopper(group.weightedMean) or nil
    local deviation=group.units>0 and math.sqrt(math.max(0,group.weightedM2/group.units)) or nil
    local variancePct=deviation and group.weightedMean>0 and deviation*100/group.weightedMean or nil
    local spreadPct=p25 and p25>0 and p75 and math.max(0,(p75/p25-1)*100) or nil
    return {
        identity=group.identity,itemID=group.itemID,name=group.name,
        floorCopper=toCopper(group.floor),referenceCopper=p25,
        averageCopper=mean,priceDeviationCopper=deviation and math.floor(deviation+0.5) or nil,
        variationPct=variancePct,spreadPct=spreadPct,
        p10Copper=p10,medianCopper=p50,p75Copper=p75,
        nearReferenceUnits=competitiveUnits,pricedListings=group.pricedListings,
        listings=group.listings,units=group.units,bidOnly=group.bidOnly,
        source='FULL_REPLICATION',method='Q10_Q25_Q50_Q75_QTY_5PCT_BUCKET_FLOOR',
    }
end

function P:ResolveIdentity(market, key)
    if not market or not market.snapshots or not market.snapshots[1] then return nil, 'NO_COMPLETE_SCAN' end
    local snapshot=market.snapshots[1]
    local current = snapshot.items
    if type(current)~='table' then return nil,'NO_COMPLETE_SCAN' end
    if type(key) == 'string' and current[key] then return key end
    local id
    if type(key) == 'number' then id = key
    elseif type(key) == 'table' then id = key.itemID
    elseif type(key) == 'string' then id = tonumber(key) end
    if not W.Math.ValidInteger(id, 1, 999999999) then return nil, 'ITEM_ID_REQUIRED' end
    -- Prices and watch lookups share one index of the last queried committed
    -- snapshot. Repeated recipe/material reads no longer scan the entire AH
    -- item table for every base item. Source identities, not a reusable text
    -- snapshot ID, delimit its lifetime across reload/replacement contexts.
    local cache=self.identityIndex
    if not cache or cache.account~=W.Storage.account or cache.snapshot~=snapshot or cache.items~=current then
        local index={}
        for candidate,rec in pairs(current) do
            if type(rec)=='table' and W.Math.ValidInteger(rec.itemID,1,999999999) then
                if index[rec.itemID]==nil then index[rec.itemID]=candidate
                else index[rec.itemID]=false end
            end
        end
        cache={account=W.Storage.account,snapshot=snapshot,items=current,index=index}
        self.identityIndex=cache;self.identityIndexBuilds=(self.identityIndexBuilds or 0)+1
    else self.identityIndexHits=(self.identityIndexHits or 0)+1 end
    local selected=cache.index[id]
    if selected==false then return nil,'AMBIGUOUS_VARIANTS' end
    if selected then return selected end
    return selected,'NO_ITEM_DATA'
end
function P:IndexStatus()
    local cache=self.identityIndex
    return {snapshots=cache and 1 or 0,maximumSnapshots=1,
        builds=self.identityIndexBuilds or 0,hits=self.identityIndexHits or 0}
end
local function resolve(market,key)
    return P:ResolveIdentity(market,key)
end
function P:GetPrice(itemKey, context)
    local marketKey = type(context) == 'table' and context.marketKey or
        type(context) == 'string' and context or W.Scope:ReadMarketKey()
    local market = W.Storage:GetMarket(marketKey)
    if not market then
        return {status = 'NO_COMPLETE_SCAN', priceCopper = nil, source = 'WEALTHCRAFT_NO_OBSERVATIONS'}
    end
    local latest = market.snapshots and market.snapshots[1]
    local partial = market.partial
    -- Partial data is NEVER used for a bare itemID or to resolve which variant
    -- a watch/bag item might mean. A real identity derived from a full link is required.
    local fromPartial = type(itemKey) == 'string' and partial and partial.items and
        partial.items[itemKey] and
        (not latest or partial.finishedAt > latest.finishedAt)
    if fromPartial then
        local item = partial.items[itemKey]
        if not item or not item.referenceCopper then
            return {status = 'NO_BUYOUT_DATA', priceCopper = nil, marketKey = marketKey}
        end
        return {status = 'PARTIAL_SAMPLE', priceCopper = item.referenceCopper,
            floorCopper = item.floorCopper, referenceCopper = item.referenceCopper,
            ageSeconds = math.max(0, W.Clock() - partial.finishedAt),
            listings = item.listings, units = item.units, scanCount = 0,
            medianCopper=item.medianCopper,p10Copper=item.p10Copper,p75Copper=item.p75Copper,
            averageCopper=item.averageCopper,variationPct=item.variationPct,spreadPct=item.spreadPct,
            nearReferenceUnits=item.nearReferenceUnits,pricedListings=item.pricedListings,
            marketKey = marketKey, venueStatus = market.scope.status,
            source = 'PARTIAL_REPLICATION_EXACT_LINKS', method = item.method,
            identity = itemKey, snapshotID = partial.id, completeDepth = false,
            unresolved = partial.unresolved, expected = partial.count}
    end
    if not latest then
        return {status = 'NO_COMPLETE_SCAN', priceCopper = nil, source = 'WEALTHCRAFT_NO_COMPLETE_DEPTH'}
    end
    local identity, problem = resolve(market, itemKey)
    if not identity then return {status = problem, priceCopper = nil, marketKey = marketKey} end
    local item = latest.items[identity]
    if not item or not item.referenceCopper then
        return {status = 'NO_BUYOUT_DATA', priceCopper = nil, marketKey = marketKey}
    end
    local age = math.max(0, W.Clock() - latest.finishedAt)
    local hist = 0
    for _, scan in ipairs(market.snapshots) do if scan.items[identity] then hist = hist + 1 end end
    local quality
    if age > 172800 then quality = 'STALE'
    elseif item.listings < 3 or hist < 3 then quality = 'LIMITED_EVIDENCE'
    else quality = 'STRONG_LOCAL_EVIDENCE' end
    return {
        status = quality, priceCopper = item.referenceCopper,
        floorCopper = item.floorCopper, referenceCopper = item.referenceCopper,
        ageSeconds = age, listings = item.listings, units = item.units, scanCount = hist,
        medianCopper=item.medianCopper,p10Copper=item.p10Copper,p75Copper=item.p75Copper,
            averageCopper=item.averageCopper,variationPct=item.variationPct,spreadPct=item.spreadPct,
        nearReferenceUnits=item.nearReferenceUnits,pricedListings=item.pricedListings,
        marketKey = marketKey, venueStatus = market.scope.status,
        source = latest.source=='AUTO_AH_OPEN_REPLICATION' and 'AUTO_FULL_SCAN' or 'PLAYER_INITIATED_FULL_SCAN', method = item.method,
        identity = identity, snapshotID = latest.id, completeDepth = true,
    }
end
function P:History(identity, marketKey, limit)
    local market = W.Storage:GetMarket(marketKey or W.Scope:ReadMarketKey())
    if not market then return {} end
    local resolved = resolve(market, identity)
    if not resolved then return {} end
    local out = {}
    local function add(rec, kind)
        if rec and rec.items and rec.items[resolved] and rec.items[resolved].referenceCopper then
            out[#out + 1] = {at = rec.finishedAt or rec.at, priceCopper = rec.items[resolved].referenceCopper,
                source = kind, listings = rec.items[resolved].listings}
        end
    end
    for _, rec in ipairs(market.snapshots or {}) do add(rec, 'FULL') end
    for _, rec in pairs(market.daily or {}) do add(rec, 'DAILY') end
    for _, rec in pairs(market.monthly or {}) do add(rec, 'MONTHLY') end
    table.sort(out, function(a, b) return a.at > b.at end)
    while #out > (limit or 6) do table.remove(out) end
    return out
end
function P:Money(copper)
    if not W.Math.ValidNumber(copper) then return '-' end
    local v = math.floor(math.abs(copper) + 0.5)
    local gold, silver = math.floor(v / 10000), math.floor(v % 10000 / 100)
    return (copper<0 and v>0 and '−' or '')..('%dg %02ds %02dc'):format(gold, silver, v % 100)
end
