-- G11: bounded, exact-identity asking-price observations across separate
-- player/quick targeted queries and watched-item replication samples.
-- No sales, demand, guaranteed execution price, or global market inference.
local _,W=...
W.Signals={maxMarkets=96,maxItems=120,maxPoints=12,lookbackSeconds=14*86400}
local S=W.Signals
local function validPrice(v) return W.Math.ValidInteger(v,1,9007199254740991) end
local function rootForWrite()
    if not W.Storage:IsWritable() then return nil end
    local db=W.Storage.account
    if db.g11Signals==nil then db.g11Signals={format=1,markets={}} end
    local root=db.g11Signals
    if type(root)~='table' or root.format~=1 or type(root.markets)~='table' then return nil end
    return root
end
local function marketForWrite(marketKey)
    if type(marketKey)~='string' or #marketKey>160 then return nil end
    local root=rootForWrite()
    if not root then return nil end
    local market=root.markets[marketKey]
    if market==nil then
        local n=0
        for _ in pairs(root.markets)do n=n+1;if n>=S.maxMarkets then return nil end end
        market={items={}};root.markets[marketKey]=market
    end
    if type(market)~='table' or type(market.items)~='table' then return nil end
    return market
end
local function evictOldest(items)
    local count,oldestKey,oldestAt=0,nil,math.huge
    for key,item in pairs(items) do
        if type(key)~='string' then return false end
        count=count+1
        local at=type(item)=='table' and tonumber(item.lastAt) or 0
        if at and (at<oldestAt or at==oldestAt and (not oldestKey or key<oldestKey)) then
            oldestAt,oldestKey=at,key
        end
    end
    if count>=S.maxItems and oldestKey then items[oldestKey]=nil end
    return true
end
function S:Save(marketKey,identity,rec,at,kind,coverage)
    if type(identity)~='string' or #identity>260 or type(rec)~='table' or
        not validPrice(rec.referenceCopper) or
        not W.Math.ValidInteger(at,1) or
        (kind~='TARGETED' and kind~='PARTIAL' and kind~='COMPLETE') then return false end
    local now=W.Clock()
    if at>now+60 or at<now-self.lookbackSeconds then return false end
    local market=marketForWrite(marketKey)
    if not market then return false end
    local item=market.items[identity]
    if item==nil then
        if not evictOldest(market.items) then return false end
        item={lastAt=at,points={}};market.items[identity]=item
    end
    if type(item)~='table' or type(item.points)~='table' then return false end
    local pts=item.points
    if #pts>S.maxPoints then return false end
    local record={at=at,priceCopper=rec.referenceCopper,
        floorCopper=rec.floorCopper,medianCopper=rec.medianCopper,averageCopper=rec.averageCopper,
        listings=rec.listings or 0,units=rec.units or 0,kind=kind,
        coverage=coverage}
    -- Replace a same-time and same-source record instead of inflating history.
    if #pts>0 and pts[#pts].at==at and pts[#pts].kind==kind then
        pts[#pts]=record
    else
        pts[#pts+1]=record
    end
    item.lastAt=at
    while #pts>S.maxPoints do table.remove(pts,1) end
    while #pts>1 and pts[1].at<now-S.lookbackSeconds do table.remove(pts,1) end
    return true
end
function S:RecordTarget(scope,record)
    if not scope or not record or type(record.items)~='table' or
        record.status~='COMPLETE_TARGET_QUERY' then return end
    for identity,rec in pairs(record.items)do
        self:Save(scope.key,identity,rec,record.updatedAt,'TARGETED',100)
    end
end
function S:RecordReplication(scope,record)
    if not scope or not record or type(record.items)~='table' then return end
    -- Only persist historical movement for explicitly followed IDs, rather
    -- than duplicating a huge market snapshot in SavedVariables.
    local watched={}
    for _,watch in ipairs(W.Storage:WatchEntries())do watched[watch.item.itemID]=true end
    if not next(watched)then return end
    local best={}
    for identity,item in pairs(record.items)do
        if watched[item.itemID] and validPrice(item.referenceCopper) then
            local list=best[item.itemID]
            if not list then list={};best[item.itemID]=list end
            local entry={identity=identity,rec=item}
            if #list<3 then list[#list+1]=entry
            else
                local minimum=1
                for i=2,#list do
                    if (list[i].rec.listings or 0)<(list[minimum].rec.listings or 0)then minimum=i end
                end
                if (item.listings or 0)>(list[minimum].rec.listings or 0) then list[minimum]=entry end
            end
        end
    end
    local kind=record.status=='COMPLETE' and 'COMPLETE' or 'PARTIAL'
    local coverage=record.count>0 and math.floor((record.preciseRows or 0)*10000/record.count)/100 or 0
    for _,list in pairs(best) do
        for _,entry in ipairs(list)do
            self:Save(scope.key,entry.identity,entry.rec,record.finishedAt,kind,coverage)
        end
    end
end
function S:Series(marketKey,identity)
    local root=W.Storage.account and W.Storage.account.g11Signals
    local market=type(root)=='table' and root.format==1 and type(root.markets)=='table' and root.markets[marketKey]
    local row=type(market)=='table' and type(market.items)=='table' and market.items[identity]
    if type(row)~='table' or type(row.points)~='table' or #row.points>S.maxPoints then return nil end
    return row.points
end
function S:Trend(marketKey,identity)
    if type(marketKey)~='string' or type(identity)~='string' then return nil end
    local points=self:Series(marketKey,identity)
    if not points then return nil end
    -- Trend comparisons only pair FULL targeted-result observations for the
    -- same exact identity and market, not different partial-scan samples.
    local latest,previous
    for i=#points,1,-1 do
        local p=points[i]
        if type(p)=='table' and p.kind=='TARGETED' and validPrice(p.priceCopper) and
            W.Math.ValidInteger(p.at,1) and W.Math.ValidInteger(p.listings,0) and p.listings>=3 then
            if not latest then latest=p
            elseif latest.at-p.at>=300 then previous=p;break end
        end
    end
    if not latest then return nil end
    if W.Clock()-latest.at > 48*3600 then previous=nil end
    local result={current=latest,prior=previous,count=#points,
        freshnessSeconds=math.max(0,W.Clock()-latest.at),
        status=previous and 'COMPARABLE' or 'ONE_OBSERVATION'}
    if previous then
        local delta=(latest.priceCopper/previous.priceCopper-1)*100
        result.changePct=delta
        result.elapsedSeconds=latest.at-previous.at
        result.direction=math.abs(delta)<1 and 'STABLE' or delta<0 and 'FALLING' or 'RISING'
    end
    return result
end
function S:Label(marketKey,identity)
    local trend=self:Trend(marketKey,identity)
    if not trend or not trend.prior then return nil end
    local change=trend.changePct
    if math.abs(change)<1 then return 'Listed prices stable' end
    return string.format('Listed prices %s%.1f%%',change>0 and '+' or '',change)
end
-- Wrappers preserve all existing persistence semantics and source contracts.
local commitTarget=W.Storage.CommitTarget
function W.Storage:CommitTarget(scope,record)
    local ok,why=commitTarget(self,scope,record)
    if ok then
        local safe=pcall(S.RecordTarget,S,scope,record)
        if not safe and W.Diagnostics then W.Diagnostics:Record('WARN','Optional price trend update unavailable') end
    end
    return ok,why
end
local commitPartial=W.Storage.CommitPartial
function W.Storage:CommitPartial(scope,record)
    local ok,why=commitPartial(self,scope,record)
    if ok then
        local safe=pcall(S.RecordReplication,S,scope,record)
        if not safe and W.Diagnostics then W.Diagnostics:Record('WARN','Optional price trend update unavailable') end
    end
    return ok,why
end
local commitFull=W.Storage.CommitSnapshot
function W.Storage:CommitSnapshot(scope,record)
    local ok,why=commitFull(self,scope,record)
    if ok then
        local safe=pcall(S.RecordReplication,S,scope,record)
        if not safe and W.Diagnostics then W.Diagnostics:Record('WARN','Optional price trend update unavailable') end
    end
    return ok,why
end
