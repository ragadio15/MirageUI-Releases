-- Strict, exact-identity lookup. Targeted commodity records only apply to bags
-- when the client's ItemLocation classifier independently says COMMODITY.
local _, W = ...
W.Quotes = {}
local Q = W.Quotes
function Q:Exact(identity, marketKey)
    if type(identity) ~= 'string' or type(marketKey) ~= 'string' then return nil end
    local full = W.Prices:GetPrice(identity, marketKey)
    if not full or not full.priceCopper then full = nil end
    local target = W.Targeted:QuoteExact(identity, marketKey)
    if not full then return target end
    if not target then return full end
    local timeFull = W.Clock() - (full.ageSeconds or math.huge)
    return target.observedAt > timeFull and target or full
end
function Q:UniqueItemID(itemID, marketKey)
    if not W.Math.ValidInteger(itemID, 1, 999999999) or type(marketKey) ~= 'string' then
        return nil, 'INVALID_ITEM_OR_MARKET'
    end
    local market = W.Storage:GetMarket(marketKey)
    local identity,why=W.Prices:ResolveIdentity(market,itemID)
    if why=='AMBIGUOUS_VARIANTS' then return nil,'MULTIPLE_VARIANTS_NO_SINGLE_PRICE' end
    if not identity then return nil,why end
    return self:Exact(identity, marketKey), identity
end
-- Watch keys may constrain suffix, level or pet. Do not silently replace a
-- suffix-specific watch with a price for an unrelated same-ID variant.
function Q:ForWatch(watch, marketKey)
    if type(watch) ~= 'table' or type(marketKey) ~= 'string' then
        return nil, 'NO_MARKET_OR_ITEM_KEY'
    end
    local requestKey = W.Storage:WatchKey(watch)
    if not requestKey then return nil, 'INVALID_WATCH_KEY' end
    local targeted = W.Storage:GetTarget(marketKey, requestKey)
    local quote, targetIdentity
    if targeted then
        local n = 0
        for identity, item in pairs(targeted.items) do
            if item.referenceCopper then
                n = n + 1
                quote = W.Targeted:QuoteExact(identity, marketKey)
                targetIdentity = identity
            end
        end
        if n ~= 1 then quote, targetIdentity = nil, nil end
    end
    local fromFull, fullIdentity
    if watch.itemLevel == 0 and watch.battlePetSpeciesID == 0 then
        if watch.itemSuffix == 0 then
            fromFull, fullIdentity = self:UniqueItemID(watch.itemID, marketKey)
        else
            local market = W.Storage:GetMarket(marketKey)
            local snap = market and market.snapshots[1]
            local found
            if snap then
                local suffixPattern = ';s=' .. tostring(watch.itemSuffix) .. ';'
                for identity, item in pairs(snap.items) do
                    if item.itemID == watch.itemID and identity:find(suffixPattern, 1, true) then
                        if found then found = false; break end
                        found = identity
                    end
                end
            end
            if type(found) == 'string' then
                fullIdentity = found
                fromFull = W.Prices:GetPrice(found, marketKey)
                if not fromFull.priceCopper then fromFull=nil end
            end
        end
    end
    if fromFull and quote then
        local fullAt = W.Clock() - (fromFull.ageSeconds or math.huge)
        if (quote.observedAt or 0) > fullAt then return quote, nil, targetIdentity end
        return fromFull, nil, fullIdentity
    end
    if quote then return quote, nil, targetIdentity end
    if fromFull then return fromFull, nil, fullIdentity end
    if targeted and targeted.variantCount and targeted.variantCount > 1 then
        return nil, 'MULTIPLE_TARGETED_VARIANTS'
    end
    if watch.itemLevel ~= 0 or watch.battlePetSpeciesID ~= 0 then
        return nil, 'NO_EXACT_KEY_EVIDENCE'
    end
    return nil, watch.itemSuffix ~= 0 and 'NO_MATCHING_SUFFIX_EVIDENCE' or
        'NO_UNAMBIGUOUS_PRICE'
end
