-- Qualified native item postcalls with one owner for each market section.
-- The native tooltip remains responsible for identity, vendor lines, anchoring,
-- comparisons and Show. No hover starts an auction request or transaction.
local _,W=...
W.Tooltips={installed=false,installStatus='NOT_INITIALIZED'}
local T=W.Tooltips
local states=setmetatable({},{__mode='k'})
local hooked=setmetatable({},{__mode='k'})
local consumers={}
local sequence=0
local function readable(v)
    if type(issecretvalue)=='function' then
        local ok,secret=pcall(issecretvalue,v);if not ok or secret==true then return false end
    end
    if type(canaccessvalue)=='function' then
        local ok,access=pcall(canaccessvalue,v);if not ok or access==false then return false end
    end
    if type(v)=='table' and type(canaccesstable)=='function' then
        local ok,access=pcall(canaccesstable,v);if not ok or access==false then return false end
    end
    return true
end
local function field(object,key)
    if not readable(object) or object==nil then return nil end
    local ok,v=pcall(function()return object[key] end)
    if ok and readable(v) then return v end
end
local function text(v,max)
    return readable(v) and type(v)=='string' and #v>0 and #v<=max and not v:find('[%c]')
end
local function loaded(name)
    local f=C_AddOns and C_AddOns.IsAddOnLoaded or IsAddOnLoaded
    if type(f)~='function' then return false end
    local ok,value=pcall(f,name)
    return ok and readable(value) and value==true
end
function T:Conflicts()
    -- MirageUI core retains native tooltips by design. Its presence alone must
    -- not suppress Wealthcraft when Insight is disabled or unavailable.
    return loaded('Auctionator') or loaded('Auctioneer') or loaded('Auc-Advanced') or loaded('aux')
end
function T:ShouldShow()
    local settings=W.Storage.account and W.Storage.account.settings
    local mode=settings and settings.tooltipMode or 'AUTO'
    return W.Compat.build and (W.Compat.build.runtimeAllowed or W.Compat.build.exactTarget) and
        (mode=='ON' or (mode=='AUTO' and not self:Conflicts()))
end
function T:RegisterConsumer(owner,resolver)
    if not text(owner,60) or owner:find('[^%w_]') or type(resolver)~='function' then return false,'INVALID_CONSUMER' end
    local count=0;for _ in pairs(consumers) do count=count+1 end
    if not consumers[owner] and count>=8 then return false,'CONSUMER_LIMIT' end
    consumers[owner]=resolver
    return true
end
function T:UnregisterConsumer(owner,resolver)
    if not text(owner,60) then return false end
    if resolver~=nil and consumers[owner]~=resolver then return false end
    consumers[owner]=nil
    self:RefreshSections(owner)
    return true
end
function T:HasSection(tooltip,link,section)
    if section~=nil and section~='market' then return nil end
    if not text(link,600) then return nil end
    local state=states[tooltip]
    if state and state.link==link then return state.owner end
end
local function installLifecycle(tooltip)
    if hooked[tooltip] then return true end
    local hook=field(tooltip,'HookScript')
    if type(hook)~='function' then return false end
    local ok=pcall(hook,tooltip,'OnTooltipCleared',function(frame)states[frame]=nil end)
    local okHide=pcall(hook,tooltip,'OnHide',function(frame)states[frame]=nil end)
    if ok and okHide then hooked[tooltip]=true;return true end
    return false
end
local function itemContext(tooltip,data)
    if not readable(data) or type(data)~='table' then return nil end
    local primaryGetter=field(tooltip,'GetPrimaryTooltipData')
    if type(primaryGetter)=='function' then
        local ok,primary=pcall(primaryGetter,tooltip)
        if not ok or not readable(primary) or primary~=data then return nil end
    end
    local link=field(data,'hyperlink')
    local guid=field(data,'guid')
    local hasGUID=text(guid,180)
    local fromGUID=false
    local getter=field(tooltip,'GetItem')
    if type(getter)=='function' then
        local ok,_,current=pcall(getter,tooltip)
        if ok and readable(current) and text(current,600) then
            -- Match native TooltipUtil: GetItem resolves GUID first. A GUID
            -- link may be more precise than data.hyperlink for the same ID.
            if not hasGUID and text(link,600) and current~=link then return nil end
            link=current
            fromGUID=hasGUID
        end
    end
    if hasGUID and not fromGUID then return nil end
    if not text(link,600) or not W.ItemLinkBridge then return nil end
    local identity,id=W.ItemLinkBridge:Normalize(link)
    local dataID=field(data,'id')
    if not identity or dataID~=id then return nil end
    return link
end
function T:Render(tooltip,data,refresh)
    if tooltip==nil or type(field(tooltip,'AddLine'))~='function' then return false end
    local link=itemContext(tooltip,data)
    if not link or not installLifecycle(tooltip) then return false end
    local state=states[tooltip]
    if not state or state.link~=link then
        sequence=sequence+1
        state={link=link,data=data,generation=sequence}
        states[tooltip]=state
    end
    state.data=data
    if state.rendering or state.owner=='Wealthcraft' then return state.owner~=nil end
    if not self:ShouldShow() then return false end
    state.rendering=true
    -- Resolve synchronously. A consumer claims only after successfully preparing
    -- its exact current section. Postcalls happen before native Show on 71037.
    local names={};for owner in pairs(consumers) do names[#names+1]=owner end
    table.sort(names)
    for _,owner in ipairs(names) do
        local resolver=consumers[owner]
        local ok,claimed=pcall(resolver,tooltip,data,'market',link)
        if states[tooltip]~=state or itemContext(tooltip,data)~=link then
            state.rendering=nil;return false
        end
        if ok and readable(claimed) and claimed==true and consumers[owner]==resolver then
            state.owner=owner;state.rendering=nil;return true
        end
    end
    state.owner=nil
    local ok,quote=pcall(W.PriceView.Get,W.PriceView,link,{consumer='WealthcraftTooltip',readOnly=true})
    if not ok or not quote then state.rendering=nil;return false end
    if states[tooltip]~=state or itemContext(tooltip,data)~=link then state.rendering=nil;return false end
    local age=quote.ageSeconds
    if type(age)~='number' or age~=age or age<0 or age>315360000 then
        state.rendering=nil;return false
    end
    local ageLabel=W.DataLanguage:Age(age)
    local shown=W.Prices:Money(quote.priceCopper)
    local context=quote.market and quote.market.mode=='LAST_SAVED' and ' · saved market' or ''
    local added=pcall(tooltip.AddLine,tooltip,'Market reference: '..shown..' / item · '..ageLabel..context,0.91,0.69,0.40,true)
    state.rendering=nil
    if added and states[tooltip]==state and itemContext(tooltip,data)==link then
        state.owner='Wealthcraft';state.sourceSnapshotID=quote.sourceSnapshotID;return true
    end
    return false
end
function T:RefreshSections(owner)
    if owner~=nil and not text(owner,60) then return false end
    local changed=0
    for tooltip,state in pairs(states) do
        if state.owner~='Wealthcraft' and (owner==nil or state.owner==owner) then
            state.owner=nil
            -- An already appended native line cannot be surgically removed.
            -- Ownership of that line lasts until native clear/hide; Insight
            -- checks HasSection and omits its own row for the same lifetime.
            local shown=field(tooltip,'IsShown')
            local ok,value=false,false
            if type(shown)=='function' then ok,value=pcall(shown,tooltip) end
            if ok and readable(value) and value==true then
                local rendered=pcall(self.Render,self,tooltip,state.data,true)
                if rendered then changed=changed+1 end
            end
        end
    end
    return true,changed
end
function T:Install()
    if self.installed then return true end
    if type(TooltipDataProcessor)~='table' or
        type(TooltipDataProcessor.AddTooltipPostCall)~='function' or
        type(Enum)~='table' or type(Enum.TooltipDataType)~='table' or
        Enum.TooltipDataType.Item==nil then
        self.installStatus='UNSUPPORTED_TOOLTIP_API';return false
    end
    local ok=pcall(TooltipDataProcessor.AddTooltipPostCall,Enum.TooltipDataType.Item,
        function(tooltip,data)
            local fine=pcall(T.Render,T,tooltip,data)
            if not fine and W.Diagnostics then W.Diagnostics:Record('WARN','Tooltip market section unavailable.') end
        end)
    if not ok then self.installStatus='HOOK_FAILED';return false end
    self.installed=true;self.installStatus='HOOKED_SECTION_CONTRACT_1';return true
end
