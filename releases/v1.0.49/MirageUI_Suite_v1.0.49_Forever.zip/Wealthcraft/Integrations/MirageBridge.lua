-- Optional, explicit public host registration. Never reads private MirageUI tables.
local _,W=...
W.Integration={host=nil,registered=false}
local I=W.Integration
function I:Refresh()
    local fn=C_AddOns and C_AddOns.IsAddOnLoaded or IsAddOnLoaded
    local ok,loaded=W.SafeCall(fn,'MirageUI')
    self.mirageDetected=ok and loaded==true
    self.mode=self.registered and 'PUBLIC_LAUNCHER_REGISTERED' or
        self.mirageDetected and 'MIRAGE_DETECTED_NO_PUBLIC_BRIDGE' or 'STANDALONE'
    return self.mode
end
function I:RegisterHost(host)
    if type(host)~='table' or host.apiVersion~=1 or host.name~='MirageUI' or
        type(host.RegisterLauncher)~='function' or type(host.UnregisterLauncher)~='function' then
        return false,'A MirageUI public host v1 with both launcher callbacks is required.'
    end
    if self.registered then return false,'A launcher host is already registered.' end
    local entry={id='Wealthcraft',title='WealthCraft',icon='Interface\\AddOns\\Wealthcraft\\Media\\WealthCraftBadge.tga',version=W.version,
        Open=function(section)if W.UI then W.UI:Open(section or 'overview',true)end end}
    local ok,accepted=pcall(host.RegisterLauncher,entry)
    if not ok or accepted~=true then return false,'Host did not accept the launcher.' end
    self.host=host;self.registered=true;self:Refresh()
    return true
end
function I:UnregisterHost(host)
    if host~=self.host or not self.registered then return false,'Host does not own this registration.' end
    local ok,err=pcall(host.UnregisterLauncher,'Wealthcraft')
    if not ok then return false,tostring(err)end
    self.host=nil;self.registered=false;self:Refresh();return true
end
function I:State()
    return {contractVersion=1,mode=self.mode,mirageDetected=self.mirageDetected==true,
        launcherRegistered=self.registered==true,theme='MIRAGEUI_OFFICIAL_OPTIONS',modifiesMirageUI=false}
end
