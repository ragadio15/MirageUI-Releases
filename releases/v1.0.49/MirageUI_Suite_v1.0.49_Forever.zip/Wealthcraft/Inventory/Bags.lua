-- Read-only current carried bags (0-4). Never claims to price inaccessible banks.
local _, W = ...
W.Inventory = {dirty = true, snapshot = nil, generation = 0}
local I = W.Inventory
local function isCommodityInBag(bag, slot)
    -- Explicit runtime classification; nil means unknown, not a guessed commodity.
    local ah = C_AuctionHouse
    if type(ItemLocation) ~= 'table' or type(ItemLocation.CreateFromBagAndSlot) ~= 'function' or
        type(ah) ~= 'table' or type(ah.GetItemCommodityStatus) ~= 'function' then return false end
    local ok, loc = pcall(ItemLocation.CreateFromBagAndSlot, ItemLocation, bag, slot)
    if not ok or not loc then return false end
    local okStatus, status = pcall(ah.GetItemCommodityStatus, loc)
    return okStatus and status == 2
end
function I:MarkDirty()
    self.generation=self.generation+1
    self.dirty=true
end
function I:MarketUpdated(marketKey)
    if (self.snapshot and self.snapshot.marketKey==marketKey) or
        (self.activeRefresh and self.activeRefresh.marketKey==marketKey) then self:MarkDirty() end
end
function I:ItemDataLoaded(itemID,success)
    if success~=true or not W.Math.ValidInteger(itemID,1,999999999) then return false end
    local active=self.activeRefresh
    if active then
        -- A synchronous completion can occur inside the native slot read,
        -- before its item ID is returned. Remember only this bounded active
        -- appraisal's completions, then match them against unresolved slots.
        if not active.completedItems[itemID] then
            if active.completedCount<800 then
                active.completedItems[itemID]=true;active.completedCount=active.completedCount+1
            else active.completionOverflow=true end
        end
    end
    if (self.snapshot and self.snapshot.unresolvedItems and self.snapshot.unresolvedItems[itemID]) or
        (active and active.unresolvedItems[itemID]) then
        self:MarkDirty();return true
    end
    return false
end
function I:IsCurrent(marketKey)
    local snapshot=self.snapshot
    if not snapshot or snapshot.status~='READY' or self.dirty or
        self.account~=W.Storage.account then return false end
    if marketKey==nil then marketKey=W.Scope:ReadMarketKey() end
    if snapshot.marketKey~=marketKey then return false end
    -- The cached appraisal expires with its oldest still-priced observation.
    -- Checking freshness never reads a bag or sends an auction request.
    return not snapshot.expiresAt or W.Clock()<=snapshot.expiresAt
end
function I:Refresh(marketKey)
    marketKey = marketKey or W.Scope:ReadMarketKey()
    local generation,account=self.generation,W.Storage.account
    local transaction={marketKey=marketKey,unresolvedItems={},completedItems={},completedCount=0}
    self.activeRefresh=transaction
    local container = type(C_Container) == 'table' and C_Container or nil
    local bagIDs={};local seenBags={}
    for id=0,math.min(6,tonumber(NUM_BAG_SLOTS) or 4) do bagIDs[#bagIDs+1]=id;seenBags[id]=true end
    local reagent=Enum and Enum.BagIndex and Enum.BagIndex.ReagentBag
    if W.Math.ValidInteger(reagent,0,1024) and not seenBags[reagent] then bagIDs[#bagIDs+1]=reagent;seenBags[reagent]=true end
    if W.PlayerContext and W.PlayerContext.SyncShared then W.PlayerContext:SyncShared() end
    local shared=W.PlayerContext and W.PlayerContext.shared and W.PlayerContext.shared.bags
    if type(shared)=='table' and shared.current==true and shared.status=='READY' and type(shared.rows)=='table' then
        local slots,sizes={},{}
        for _,r in ipairs(shared.rows) do
            if W.Math.ValidInteger(r.bag,0,1024) and W.Math.ValidInteger(r.slot,1,256) then
                if not seenBags[r.bag] then bagIDs[#bagIDs+1]=r.bag;seenBags[r.bag]=true end
                slots[r.bag]=slots[r.bag] or {};sizes[r.bag]=math.max(sizes[r.bag] or 0,r.slot)
                slots[r.bag][r.slot]={itemID=r.itemID,stackCount=r.count,itemName=r.name,
                    hyperlink=r.itemLink,isBound=r.isBound,iconFileID=r.icon,isLocked=r.locked,quality=r.quality}
            end
        end
        container={GetContainerNumSlots=function(id)return sizes[id] or 0 end,
            GetContainerItemInfo=function(id,slot)return slots[id] and slots[id][slot] end}
    else shared=nil end
    local result = {status = 'READY', at = W.Clock(), marketKey = marketKey,
        bagsScanned = 0, slotsRead = 0, occupiedSlots = 0, uniqueVariants = 0,
        pricedSlots = 0, valuedUnits = 0, unknownSlots = 0, unknownUnits = 0,
        staleSlots = 0, staleUnits = 0,
        boundSlots = 0, boundUnits = 0, valueCopper = 0, items = {},unresolvedItems=transaction.unresolvedItems,
        source = 'CURRENT_CARRIED_BAGS_ONLY'}
    local function finish(status,dirty)
        result.status=status or result.status
        -- A nested refresh owns its newer publication. An older callback may
        -- return its interrupted result, but cannot overwrite that snapshot.
        if self.activeRefresh~=transaction then result.status='BAG_CONTEXT_CHANGED';return result end
        self.activeRefresh=nil
        if self.generation~=generation or W.Storage.account~=account then
            result.status='BAG_CONTEXT_CHANGED';dirty=true
        end
        self.snapshot=result;self.account=account;self.dirty=dirty==true
        return result
    end
    if not container or type(container.GetContainerNumSlots) ~= 'function' or
        type(container.GetContainerItemInfo) ~= 'function' then
        return finish('CONTAINER_API_UNAVAILABLE',false)
    end
    for _,bag in ipairs(bagIDs) do
        local ok, slots = pcall(container.GetContainerNumSlots, bag)
        if not ok or not W.Math.ValidInteger(slots, 0, 256) then
            return finish('BAG_READ_INCOMPLETE',true)
        end
        result.bagsScanned = result.bagsScanned + 1
        for slot = 1, slots do
            result.slotsRead = result.slotsRead + 1
            local good, info = pcall(container.GetContainerItemInfo, bag, slot)
            if not good or (info ~= nil and type(info) ~= 'table') then
                return finish('BAG_SLOT_UNREADABLE',true)
            end
            if info then
                result.occupiedSlots = result.occupiedSlots + 1
                local qty = info.stackCount
                if not W.Math.ValidInteger(qty, 1, 100000000) then
                    return finish('BAG_COUNT_INVALID',true)
                end
                if info.isBound == true then
                    result.boundSlots = result.boundSlots + 1
                    result.boundUnits = result.boundUnits + qty
                else
                    local identity = W.Identity:FromLink(info.hyperlink, info.itemID)
                    local quote = identity and W.Quotes:Exact(identity, marketKey)
                    if W.Math.ValidInteger(info.itemID, 1, 999999999) and
                        isCommodityInBag(bag, slot) then
                        -- Game-classified commodities may use AH item-ID keyed pricing.
                        -- A valid item link does not override this official classification.
                        local commodityIdentity = 'commodity:' .. info.itemID
                        local commodityQuote = W.Quotes:Exact(commodityIdentity, marketKey)
                        if commodityQuote and (not quote or
                            (commodityQuote.ageSeconds or math.huge) < (quote.ageSeconds or math.huge)) then
                            identity, quote = commodityIdentity, commodityQuote
                        end
                    end
                    if not identity and W.Math.ValidInteger(info.itemID,1,999999999) then
                        result.unresolvedItems[info.itemID]=true
                        if self.activeRefresh==transaction and
                            (transaction.completedItems[info.itemID] or transaction.completionOverflow) then self:MarkDirty() end
                    end
                    -- Old prices are retained in market history, but must not
                    -- silently inflate a current carried-bag appraisal.
                    local tooOld=quote and (not W.Math.ValidNumber(quote.ageSeconds) or
                        quote.ageSeconds>48*3600)
                    if tooOld then
                        result.staleSlots=result.staleSlots+1
                        result.staleUnits=result.staleUnits+qty
                    end
                    if quote and not tooOld and quote.priceCopper and quote.priceCopper > 0 and
                        quote.priceCopper * qty <= 9007199254740991 and
                        result.valueCopper + quote.priceCopper * qty <= 9007199254740991 then
                        result.pricedSlots = result.pricedSlots + 1
                        result.valuedUnits = result.valuedUnits + qty
                        result.valueCopper = result.valueCopper + quote.priceCopper * qty
                        local expires=result.at+48*3600-quote.ageSeconds
                        result.expiresAt=result.expiresAt and math.min(result.expiresAt,expires) or expires
                        local entry = result.items[identity]
                        if not entry then
                            entry = {identity = identity, itemID = info.itemID, name = (type(info.itemName)=='string' and info.itemName~='' and info.itemName) or
                                (type(info.hyperlink) == 'string' and info.hyperlink:match('%[([^%]]+)%]')) or
                                ('Item ' .. tostring(info.itemID or '?')),
                                quantity = 0, unitCopper = quote.priceCopper,
                                source = quote.source, ageSeconds = quote.ageSeconds, unitsValue = 0}
                            result.items[identity] = entry
                            result.uniqueVariants = result.uniqueVariants + 1
                        end
                        entry.quantity = entry.quantity + qty
                        entry.unitsValue = entry.unitsValue + qty * quote.priceCopper
                    else
                        result.unknownSlots = result.unknownSlots + 1
                        result.unknownUnits = result.unknownUnits + qty
                    end
                end
            end
        end
    end
    if shared then
        result.slotsRead=shared.slotsRead or result.slotsRead
        result.bagsScanned=shared.containersObserved or result.bagsScanned
        result.sharedRevision=shared.revision
    end
    finish(nil,false)
    if result.status~='READY' then return result end
    if W.Publish then W.Publish('INVENTORY_UPDATED', {marketKey=marketKey, at=result.at}) end
    return result
end

-- P39-A: preserve the existing refresh result; measure only explicit captures.
local p39BagRefresh=I.Refresh
function I:Refresh(...)
    local service,started=W.P39TraceBegin()
    local result=p39BagRefresh(self,...)
    W.P39TraceEnd(service,started,'wealth.bag_appraisal')
    if service and type(service.Counter)=='function' and type(result)=='table' and
        W.Math.ValidInteger(result.slotsRead,0,2048) then
        pcall(service.Counter,'wealth.bag_slots_read',result.slotsRead)
    end
    return result
end
