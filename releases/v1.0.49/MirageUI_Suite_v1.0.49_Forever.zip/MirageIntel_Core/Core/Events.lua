local _,C=...
local frame=CreateFrame("Frame")
C.eventFrame=frame
frame:RegisterEvent("ADDON_LOADED")
frame:SetScript("OnEvent",function(_,event,name)
    if event=="ADDON_LOADED" and name==C.addonName then
        -- Register diagnostics before client/storage startup, even when startup fails.
        local commandsOK,result=pcall(C.Commands.Install,C.Commands)
        if not commandsOK or result~=true then C:Fault("DIAGNOSTICS_INSTALL_FAILED") end
        local ok=pcall(C.Initialize,C)
        if not ok then
            C:Fault("INITIALIZE_FAILED")
            C.state.status="INITIALIZE_FAILED"
            C.Client.allowed=false
            C.Storage.readOnly=true
            C.Storage.reason="INITIALIZE_FAILED_NO_WRITES"
            return
        end
        if C.Scheduler and not pcall(C.Scheduler.Initialize,C.Scheduler) then C:Fault("SCHEDULER_UNAVAILABLE") end
        if C.CharacterContext and not pcall(C.CharacterContext.Initialize,C.CharacterContext) then C:Fault("CHARACTER_CONTEXT_UNAVAILABLE") end
        if C.Client.allowed and C.TravelGraph and not pcall(C.TravelGraph.Initialize,C.TravelGraph) then C:Fault("TRAVEL_GRAPH_UNAVAILABLE") end
        if C.Client.allowed and C.MinimapPins and not pcall(C.MinimapPins.Initialize,C.MinimapPins) then C:Fault("MINIMAP_PINS_UNAVAILABLE") end
    end
end)
