local _,C=...
-- Runtime API capability and reviewed source identity are independent.
C.Client={flavor="Unknown",nativeVerification="NOT_RUN",capabilities={},
    reviewedLatestSourceCommit="734f065329cff4992835b01a84f210a297db91b6",
    reviewedBuilds="70938,70959,71037",sourceReview="EXACT_UI_SOURCE_DIFF_REVIEWED"}
local function hasAPI(provider,name)
    if not C.Readable(provider) or type(provider)~="table" then return false end
    local ok,fn=pcall(function()return provider[name]end)
    return ok and C.Readable(fn) and type(fn)=="function" or false
end
function C.Client:Probe()
    local patch,ok,build,_,interface=C.Call(GetBuildInfo)
    self.patch=ok and C.Text(patch) and patch or "unknown"
    self.build=ok and C.Text(build) and build or "unknown"
    self.interface=ok and C.Natural(interface) and interface<=999999999 and interface or 0
    self.flavor=self.interface==16001 and "Forever" or self.interface>0 and ("Client"..self.interface) or "Unknown"
    self.identityKnown=self.interface>0 and C.Natural(tonumber(self.build)) and self.patch~="unknown" and self.patch~=""
    self.sourceMatched=self.patch=="1.60.1" and (self.build=="70938" or self.build=="70959" or self.build=="71037") and self.interface==16001
    self.sourceCommit=self.sourceMatched and (self.build=="71037" and "734f065329cff4992835b01a84f210a297db91b6" or
        self.build=="70959" and "3d8abb1da73acd38e412e24fb3f99454a6392346" or
        self.build=="70938" and "bebcb6bf309cf41b41bd74f8ca651e6a105b2676") or nil
    self.allowed=C.Readable(false) and C.Readable(0) and C.Readable("") or false
    self.runtimePolicy="CAPABILITY_GUARDED"
    self.status=self.allowed and (self.sourceMatched and "SOURCE_CANDIDATE_NATIVE_NOT_RUN" or "UNREVIEWED_CLIENT_API_GUARDED") or "VALUE_BOUNDARY_UNAVAILABLE"
    self.capabilities={
        questWaypoint=hasAPI(C_QuestLog,"GetNextWaypoint"),
        supertracked=hasAPI(C_SuperTrack,"GetSuperTrackedQuestID"),
        playerMap=hasAPI(C_Map,"GetBestMapForUnit") and hasAPI(C_Map,"GetPlayerMapPosition"),
        mapWorld=hasAPI(C_Map,"GetWorldPosFromMapPos"),
        nativeWaypoint=hasAPI(C_Map,"SetUserWaypoint"),
    }
end
function C.Client:HasAPI(name)
    return self.allowed==true and self.capabilities[name]==true,
        self.allowed and (self.capabilities[name] and "PRESENT_NATIVE_UNTESTED" or "API_UNAVAILABLE") or "VALUE_BOUNDARY_UNAVAILABLE"
end
