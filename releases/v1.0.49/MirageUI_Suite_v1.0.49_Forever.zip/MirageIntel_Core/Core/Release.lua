local _,C=...
-- Payload digest covers sorted relative paths and their SHA-256, excluding this receipt.
C.Release={phase="V1_0_49_FOREVER_FIELD_FIXES",id="v1.0.49-71139",
    qualification="RUNTIME_API_GUARDED",nativeAcceptance="NOT_RUN",
    payloadSHA256="3d1389d2b99562848272fac87ead94e8c315b84d77566bd39b629548d2cdb090"}
