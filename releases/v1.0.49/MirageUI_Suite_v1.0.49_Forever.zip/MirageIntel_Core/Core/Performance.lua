local _,C=...
-- P39-A: explicitly started, session-only performance evidence. An interval is
-- a WHOLE-CLIENT frame time, never a measurement attributed to one addon.
-- This module neither reads item/character identity nor changes the UI.
local P={apiVersion=1,active=false,channels={},channelCount=0}
C.Performance=P
local BIN_MS=.25
local MAX_BIN=4000
local CHANNEL_LIMIT=48
local MARKER_LIMIT=48
local COUNTER_LIMIT=32
-- P39-G: bounded, opt-in exceptional-frame evidence. The timer is whole-client;
-- neighboring UI events are temporal clues only and never imply causation.
local EXCEPTION_LIMIT=12
local EXCEPTION_THRESHOLD_MS=100
local FOLLOWUP_WINDOW_MS=5000
local SURFACE_CODES={BAGS_SHOWN=true,BAGS_HIDDEN=true,PROFESSIONS_SHOWN=true,
    PROFESSIONS_HIDDEN=true,BAG_WINDOW_EVENT=true,PROFESSION_WINDOW_EVENT=true,
    VIEWPORT_CHANGED=true}
local scenarios={idle=true,bags_cold=true,bags_warm=true,item_hover=true,
    professions_cold=true,professions_warm=true,professions_switch=true,auction_idle=true}
local eventNames={"BAG_OPEN","BAG_CLOSED","BAG_UPDATE_DELAYED","BANKFRAME_OPENED","BANKFRAME_CLOSED",
    "TRADE_SKILL_SHOW","TRADE_SKILL_CLOSE","TRADE_SKILL_LIST_UPDATE","TRADE_SKILL_DATA_SOURCE_CHANGED",
    "SKILL_LINES_CHANGED","ITEM_DATA_LOAD_RESULT","DISPLAY_SIZE_CHANGED","UI_SCALE_CHANGED"}
local scheduleKeys={"completed","cancelled","failed","slices","slowSlices","continued","queueFull","ownerLimit"}
local function clock() local n=C.Call(debugprofilestop);return C.Number(n) and n or nil end
local function memory()
    local n=C.Call(collectgarbage,"count")
    return C.Number(n) and n or nil
end
local function measure() return {count=0,totalMS=0,maxMS=0,histogram={}} end
local function record(m,ms)
    if not C.Number(ms) or ms<0 then return false end
    local bin=math.min(MAX_BIN+1,math.max(1,math.ceil(ms/BIN_MS)))
    m.count=m.count+1;m.totalMS=m.totalMS+ms;m.maxMS=math.max(m.maxMS,ms)
    m.histogram[bin]=(m.histogram[bin] or 0)+1
    return true
end
local function percentile(m,fraction)
    if m.count==0 then return "NO_SAMPLES" end
    local goal=math.ceil(m.count*fraction);local count=0
    for bin=1,MAX_BIN+1 do
        count=count+(m.histogram[bin] or 0)
        if count>=goal then return bin>MAX_BIN and ">1000 ms" or bin*BIN_MS end
    end
    return "NO_SAMPLES"
end
local function summary(m)
    if not m then return {samples=0} end
    return {samples=m.count,meanMS=m.count>0 and m.totalMS/m.count or 0,maxMS=m.maxMS,
        p50UpperBoundMS=percentile(m,.50),p95UpperBoundMS=percentile(m,.95),
        p99UpperBoundMS=percentile(m,.99)}
end
local function environment()
    local w=C.Call(UIParent and UIParent.GetWidth,UIParent)
    local h=C.Call(UIParent and UIParent.GetHeight,UIParent)
    local scale=C.Call(UIParent and UIParent.GetEffectiveScale,UIParent)
    local pw,ok,ph=C.Call(GetPhysicalScreenSize)
    local locale=C.Call(GetLocale)
    local modules={}
    for _,key in ipairs({"MapAddon","Navigate","Gather","Insight"}) do
        local service=C.Services:Get(key,1)
        modules[key]=service and tostring(service.version or "REGISTERED") or "NOT_LOADED"
    end
    return {build=C.Client.build,interface=C.Client.interface,locale=locale,
        uiWidth=C.Number(w) and w or nil,uiHeight=C.Number(h) and h or nil,
        uiScale=C.Number(scale) and scale or nil,
        physicalWidth=ok and C.Number(pw) and pw or nil,
        physicalHeight=ok and C.Number(ph) and ph or nil,
        modules=modules}
end
local function scheduleSnapshot()
    local r={};local m=C.Scheduler and C.Scheduler.metrics or {}
    for _,key in ipairs(scheduleKeys) do r[key]=C.Number(m[key]) and m[key] or 0 end
    return r
end
local function safeShown(frame)
    if not frame or type(frame.IsShown)~="function" then return false end
    local ok,v=pcall(frame.IsShown,frame)
    return ok and v==true
end
local function visible(names)
    for _,name in ipairs(names) do
        if safeShown(_G[name]) then return true end
    end
    return false
end
function P:Marker(code)
    if not self.active or type(code)~="string" or not code:match("^[A-Z_]+$") or #code>40 then return false end
    if #self.markers>=MARKER_LIMIT then self.droppedMarkers=self.droppedMarkers+1;return false end
    local at=math.floor((self.elapsed or 0)*1000+.5)
    self.markers[#self.markers+1]={elapsedMS=at,event=code}
    if SURFACE_CODES[code] then
        self.latestSurfaceEvent={event=code,elapsedMS=at}
        -- A freeze may PRECEDE the first observable frame-open marker. Retain
        -- this relationship rather than falsely classifying the freeze as idle.
        for _,frame in ipairs(self.exceptionFrames or {}) do
            local after=at-frame.elapsedMS
            if frame.followingEvent==nil and after>=0 and after<=FOLLOWUP_WINDOW_MS then
                frame.followingEvent=code;frame.msUntilFollowingEvent=after
            end
        end
    end
    return true
end
function P:Counter(code,count)
    if not self.active or type(code)~="string" or #code>48 or not code:match("^[%w_.]+$") then return false end
    count=count or 1
    if not C.Number(count) or count<1 or count>1000000 then return false end
    if self.counters[code]==nil then
        if self.counterCount>=COUNTER_LIMIT then return false end
        self.counterCount=self.counterCount+1;self.counters[code]=0
    end
    self.counters[code]=math.min(100000000,self.counters[code]+count)
    return true
end
function P:ObserveEvent(event)
    if not self.active or self.eventCounts[event]==nil then return end
    self.eventCounts[event]=math.min(1000000,self.eventCounts[event]+1)
    if event=="BAG_OPEN" or event=="BANKFRAME_OPENED" then
        self:Marker("BAG_WINDOW_EVENT");self.bagWindowUntil=(self.elapsed or 0)+3
    elseif event=="TRADE_SKILL_SHOW" then
        self:Marker("PROFESSION_WINDOW_EVENT");self.professionWindowUntil=(self.elapsed or 0)+3
    elseif event=="DISPLAY_SIZE_CHANGED" or event=="UI_SCALE_CHANGED" then self:Marker("VIEWPORT_CHANGED") end
end
function P:ProbeSurfaces()
    local bags=visible({"ContainerFrameCombinedBags","ContainerFrame1","ContainerFrame2","ContainerFrame3",
        "ContainerFrame4","ContainerFrame5","ContainerFrame6"})
    local professions=visible({"ProfessionsFrame","TradeSkillFrame","ProfessionsBookFrame"})
    local previous=self.surfaceStates
    if previous then
        if previous.bags~=bags then
            self:Marker(bags and "BAGS_SHOWN" or "BAGS_HIDDEN")
            if bags then self.bagWindowUntil=(self.elapsed or 0)+3 end
        end
        if previous.professions~=professions then
            self:Marker(professions and "PROFESSIONS_SHOWN" or "PROFESSIONS_HIDDEN")
            if professions then self.professionWindowUntil=(self.elapsed or 0)+3 end
        end
    end
    self.surfaceStates={bags=bags,professions=professions}
end
function P:Start(seconds,scenario)
    if not C.Client.allowed then return false,"UNSUPPORTED_CLIENT" end
    seconds=seconds or 60
    if not C.Number(seconds) or seconds<5 or seconds>600 then return false,"Use 5 to 600 seconds." end
    if self.active then return false,"A performance capture is already running." end
    if scenario~=nil and not scenarios[scenario] then return false,"Unknown baseline scenario." end
    if not self.frame then
        self.frame=CreateFrame("Frame")
        self.frame:SetScript("OnUpdate",function(_,dt) self:Tick(dt) end)
    end
    if not self.eventsFrame then
        self.eventsFrame=CreateFrame("Frame")
        self.registeredEvents={};self.unsupportedEvents={}
        for _,event in ipairs(eventNames) do
            local ok,accepted=pcall(self.eventsFrame.RegisterEvent,self.eventsFrame,event)
            self.registeredEvents[event]=ok and accepted~=false
            if not self.registeredEvents[event] then self.unsupportedEvents[#self.unsupportedEvents+1]=event end
        end
        self.eventsFrame:SetScript("OnEvent",function(_,event) self:ObserveEvent(event) end)
    end
    self.duration=seconds;self.scenario=scenario or "unclassified";self.elapsed=0;self.frames=measure()
    self.bagWindowFrames=measure();self.professionWindowFrames=measure()
    self.bagWindowUntil=0;self.professionWindowUntil=0
    self.channels={};self.channelCount=0;self.taskChannelCount=0;self.clockDiscontinuities=0
    self.markers={};self.droppedMarkers=0;self.counters={};self.counterCount=0
    self.exceptionFrames={};self.exceptionCounts={above100ms=0,above500ms=0,above1000ms=0}
    self.latestSurfaceEvent=nil
    self.eventCounts={};for _,event in ipairs(eventNames) do self.eventCounts[event]=0 end
    self.probeElapsed=0;self.surfaceStates=nil;self.startedAt=C:Now();self.environment=environment()
    self.startMemoryKB=memory();self.endMemoryKB=nil;self.memoryPeakKB=self.startMemoryKB
    self.memoryElapsed=0;self.memorySamples=0
    self.queuePeak=C.Scheduler and #C.Scheduler.jobs or 0
    self.schedulerStart=scheduleSnapshot();self.schedulerEnd=nil
    self.startFailures=C.Scheduler and C.Scheduler.metrics.failed or 0;self.stopReason=nil
    self.active=true;self:ProbeSurfaces();self:Marker("CAPTURE_START");self.frame:Show()
    return true,"P39-A capture started: "..self.scenario.." for "..seconds.." seconds."
end
function P:Stop(reason)
    if not self.active then return false,"No performance capture is running." end
    self:Marker("CAPTURE_STOP");self.active=false
    self.stopReason=reason or "USER_STOPPED";self.endMemoryKB=memory()
    self.schedulerEnd=scheduleSnapshot();self.endFailures=C.Scheduler.metrics.failed
    self.frame:Hide()
    return true,"Capture saved for this session. Copy /mirageutil report before logging out."
end
function P:Tick(dt)
    if not self.active or not C.Number(dt) or dt<0 then return end
    self.elapsed=self.elapsed+dt;record(self.frames,dt*1000)
    -- No per-frame allocations in the common (<100ms) path. Store only the
    -- twelve largest frame gaps, their time, and fixed UI event codes.
    local durationMS=dt*1000
    if durationMS>=EXCEPTION_THRESHOLD_MS then
        local counts=self.exceptionCounts
        counts.above100ms=counts.above100ms+1
        if durationMS>=500 then counts.above500ms=counts.above500ms+1 end
        if durationMS>=1000 then counts.above1000ms=counts.above1000ms+1 end
        local entries=self.exceptionFrames
        if #entries<EXCEPTION_LIMIT or durationMS>entries[#entries].durationMS then
            local endMS=math.floor(self.elapsed*1000+.5)
            local startMS=math.max(0,endMS-math.floor(durationMS+.5))
            local preceding=self.latestSurfaceEvent
            local priorMS=preceding and startMS-preceding.elapsedMS
            local row={elapsedMS=endMS,durationMS=math.floor(durationMS+.5),
                precedingEvent=preceding and priorMS>=0 and priorMS<=FOLLOWUP_WINDOW_MS and preceding.event or "NONE",
                msSincePrecedingEvent=preceding and priorMS>=0 and priorMS<=FOLLOWUP_WINDOW_MS and priorMS or nil,
                bagsVisibleBefore=self.surfaceStates and self.surfaceStates.bags==true or false,
                professionsVisibleBefore=self.surfaceStates and self.surfaceStates.professions==true or false}
            entries[#entries+1]=row
            table.sort(entries,function(a,b)
                if a.durationMS~=b.durationMS then return a.durationMS>b.durationMS end
                return a.elapsedMS<b.elapsedMS
            end)
            if #entries>EXCEPTION_LIMIT then table.remove(entries) end
        end
    end
    if self.bagWindowUntil>self.elapsed then record(self.bagWindowFrames,dt*1000) end
    if self.professionWindowUntil>self.elapsed then record(self.professionWindowFrames,dt*1000) end
    self.queuePeak=math.max(self.queuePeak,#C.Scheduler.jobs)
    self.memoryElapsed=self.memoryElapsed+dt
    if self.memoryElapsed>=1 then
        self.memoryElapsed=0;local kb=memory();self.memorySamples=self.memorySamples+1
        if kb then self.memoryPeakKB=math.max(self.memoryPeakKB or kb,kb) end
    end
    self.probeElapsed=self.probeElapsed+dt
    if self.probeElapsed>=.20 then self.probeElapsed=0;self:ProbeSurfaces() end
    if self.elapsed>=self.duration then self:Stop("DURATION_COMPLETE") end
end
function P:Sample(name,ms)
    if not self.active or not C.Text(name) or #name>64 or not name:match("^[%w_.%-]+$")
        or not C.Number(ms) or ms<0 then return false end
    local m=self.channels[name]
    if not m then
        if self.channelCount>=CHANNEL_LIMIT then return false end
        if name:match("^task%.") then
            if (self.taskChannelCount or 0)>=24 then return false end
            self.taskChannelCount=(self.taskChannelCount or 0)+1
        end
        m=measure();self.channels[name]=m;self.channelCount=self.channelCount+1
    end
    return record(m,ms)
end
function P:Begin() return self.active and clock() or nil end
function P:Finish(name,started)
    if not self.active or not C.Number(started) then return false end
    local now=clock()
    if now and now<started then self.clockDiscontinuities=self.clockDiscontinuities+1;return false end
    return now and self:Sample(name,now-started) or false
end
function P:GetStatus()
    local channels={};for name,m in pairs(self.channels) do channels[name]=summary(m) end
    local deltas={};local finish=self.schedulerEnd or scheduleSnapshot()
    for _,key in ipairs(scheduleKeys) do
        deltas[key]=math.max(0,(finish[key] or 0)-(self.schedulerStart and self.schedulerStart[key] or 0))
    end
    local marks={};for i,m in ipairs(self.markers or {}) do marks[i]={event=m.event,elapsedMS=m.elapsedMS} end
    return {schemaVersion=2,status=self.active and "CAPTURING" or self.frames and "CAPTURE_COMPLETE" or "NOT_RUN",
        scenario=self.scenario or "NOT_SELECTED",requestedSeconds=self.duration,elapsedSeconds=self.elapsed or 0,
        startedAt=self.startedAt,stopReason=self.stopReason,
        frameIntervals=summary(self.frames),bagOpenWindowIntervals=summary(self.bagWindowFrames),
        professionOpenWindowIntervals=summary(self.professionWindowFrames),
        channels=channels,queuePeak=self.queuePeak or 0,
        schedulerFailures=self.startFailures and ((self.active and C.Scheduler.metrics.failed or self.endFailures or self.startFailures)-self.startFailures) or 0,
        schedulerDelta=deltas,eventCounts=C.Copy(self.eventCounts or {}),counters=C.Copy(self.counters or {}),
        markers=marks,droppedMarkers=self.droppedMarkers or 0,surfaceStates=C.Copy(self.surfaceStates or {}),
        exceptionalFrameCounts=C.Copy(self.exceptionCounts or {}),
        exceptionalFrames=C.Copy(self.exceptionFrames or {}),
        exceptionalFrameScope="WHOLE_CLIENT_GAPS_AND_TEMPORALLY_NEARBY_PUBLIC_UI_EVENTS_NOT_ADDON_ATTRIBUTION",
        unsupportedEvents=C.Copy(self.unsupportedEvents or {}),
        luaMemoryStartKB=self.startMemoryKB,luaMemoryEndKB=self.endMemoryKB,
        luaMemoryPeakKB=self.memoryPeakKB,luaMemorySamples=self.memorySamples or 0,
        luaMemoryDeltaKB=self.startMemoryKB and self.endMemoryKB and self.endMemoryKB-self.startMemoryKB,
        environment=C.Copy(self.environment),histogramResolutionMS=BIN_MS,clockDiscontinuities=self.clockDiscontinuities or 0,
        interpretation="FRAME_INTERVALS_AND_LUA_MEMORY_ARE_WHOLE_CLIENT; CHANNELS_ARE_INSTRUMENTED_SLICES_ONLY",
        acceptance="NOT_QUALIFIED; MATCHED_NATIVE_DESKTOP_AND_SURFACE_CAPTURES_REQUIRED"}
end
local api={apiVersion=1}
function api.GetStatus() return P:GetStatus() end
function api.Start(seconds,scenario) return P:Start(seconds,scenario) end
function api.Stop() return P:Stop() end
function api.Begin() return P:Begin() end
function api.Finish(name,started) return P:Finish(name,started) end
function api.Sample(name,ms) return P:Sample(name,ms) end
function api.Mark(code) return P:Marker(code) end
function api.Counter(code,count) return P:Counter(code,count) end
function api.IsActive() return P.active==true end
C.Services:Register("Performance","MirageIntel_Core",1,api)
