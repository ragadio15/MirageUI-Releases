local _,C=...
-- Owner-scoped short leases, without touching other addons' or native frames.
local leases={}
local function key(v) return C.Text(v) and #v>0 and #v<=64 and not v:find("[%c|]") end
local function notify(k,owner,previous)
    C.Hub:Publish("MAP_LAYER_CHANGED",{key=k,owner=owner,previousOwner=previous})
end
local function live(k)
    local r=leases[k]
    if r and C:Now()>=r.expiresAt then
        leases[k]=nil;notify(k,nil,r.owner)
        -- A listener may take ownership while handling the expiration.
        r=leases[k]
    end
    return r
end
local A={apiVersion=1}
function A.Acquire(k,owner,priority,ttl)
    if not C.Client.allowed then return false,"UNSUPPORTED_CLIENT" end
    if not key(k) or not key(owner) or not C.Number(priority) then return false,"BAD_LEASE" end
    local current=live(k)
    if current and current.owner~=owner and current.priority>=priority then return false,"OWNED_BY_OTHER" end
    if not current then
        local keys={};for id in pairs(leases) do keys[#keys+1]=id end
        for _,id in ipairs(keys) do live(id) end
        -- Expiration notifications can create replacement leases.
        current=live(k)
        if current and current.owner~=owner and current.priority>=priority then return false,"OWNED_BY_OTHER" end
        local n=0;for _ in pairs(leases) do n=n+1 end
        if not current and n>=32 then return false,"LEASE_LIMIT" end
    end
    ttl=C.Number(ttl) and math.max(.5,math.min(10,ttl)) or 3
    leases[k]={owner=owner,priority=priority,expiresAt=C:Now()+ttl}
    if not current or current.owner~=owner then notify(k,owner,current and current.owner) end
    return true,"ACQUIRED"
end
function A.Release(k,owner)
    if not key(k) or not key(owner) then return false end
    local r=leases[k];if not r or r.owner~=owner then return false end
    leases[k]=nil;notify(k,nil,owner);return true
end
function A.GetOwner(k) if not key(k) then return nil end;local r=live(k);return r and r.owner end
function A.GetStatus()
    local result={}
    -- Expiration callbacks may acquire/release other keys. Iterate a snapshot
    -- so those mutations cannot corrupt the status walk or skip an old key.
    local keys={};for k in pairs(leases) do keys[#keys+1]=k end
    table.sort(keys)
    for _,k in ipairs(keys) do local r=live(k);if r then result[k]=C.Copy(r) end end
    return result
end
C.Services:Register("MapLayers","MirageIntel_Core",1,A)
