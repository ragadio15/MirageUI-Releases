local _,C=...
C.Hub={subscriptions={}}
local dispatching={}
local function validKey(s)
    return C.Text(s) and #s>0 and #s<=64 and s:match("^[%w_]+$")~=nil
end
function C.Hub:Subscribe(event,owner,fn)
    if not validKey(event) or not validKey(owner) or not C.Readable(fn) or type(fn)~="function" then return false,"BAD_SUBSCRIPTION" end
    local listeners=self.subscriptions[event]
    if not listeners then listeners={};self.subscriptions[event]=listeners end
    local count=0;for _ in pairs(listeners) do count=count+1 end
    if not listeners[owner] and count>=32 then return false,"LISTENER_LIMIT" end
    listeners[owner]={owner=owner,fn=fn};return true
end
function C.Hub:Unsubscribe(event,owner)
    if not validKey(event) or not validKey(owner) then return false end
    local listeners=self.subscriptions[event]
    if not listeners or not listeners[owner] then return false end
    listeners[owner]=nil
    if next(listeners)==nil then self.subscriptions[event]=nil end
    return true
end
function C.Hub:Publish(event,payload)
    if not validKey(event) or dispatching[event] then return 0 end
    local listeners=self.subscriptions[event]
    if not listeners then return 0 end
    local fired=0
    -- Notification listeners may publish other events. Refuse a cycle back
    -- into the same event rather than repeatedly mutating listener state.
    dispatching[event]=true
    local pending={}
    for _,record in pairs(listeners) do pending[#pending+1]=record end
    for _,record in ipairs(pending) do
        -- Each subscription gets a fresh record, even if the function matches.
        if self.subscriptions[event]==listeners and listeners[record.owner]==record then
            local ok=pcall(function() record.fn(C.Copy(payload)) end)
            if not ok then C:Fault("SUBSCRIBER_FAILED_"..event) end
            fired=fired+1
        end
    end
    dispatching[event]=nil
    C.state.notifications=C.state.notifications+1
    return fired
end
