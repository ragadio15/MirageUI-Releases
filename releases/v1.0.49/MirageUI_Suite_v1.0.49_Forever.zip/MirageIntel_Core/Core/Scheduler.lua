local _,C=...
-- Cooperative jobs: each callback bounds its own work. A time budget checked
-- between callbacks cannot preempt a long Lua function.
C.Scheduler={jobs={},generations={},serial=0,running=false,maxPerTick=12,
    metrics={completed=0,cancelled=0,failed=0,slices=0,slowSlices=0,maxSliceMS=0,
        continued=0,queueFull=0,ownerLimit=0,peakQueued=0}}
local S=C.Scheduler
local capacity=128
local function currentReservation(self,replacingOwner)
    local job=self.current
    -- A yielding callback still owns a slot while it runs. Nested producers
    -- may replace that same owner, but cannot consume its continuation slot.
    return job and not job.cancelled and self.generations[job.owner]==job.epoch
        and job.owner~=replacingOwner and 1 or 0
end
function S:Initialize()
    if self.frame then return end
    self.frame=CreateFrame("Frame")
    self.frame:SetScript("OnUpdate",function() self:Tick() end)
    if #self.jobs>0 then self.frame:Show() else self.frame:Hide() end
end
function S:Cancel(owner)
    if not C.Text(owner) then return false end
    -- Unknown cancellation must not grow retained owner state indefinitely.
    if self.generations[owner]==nil then return true end
    self.generations[owner]=nil
    if self.current and self.current.owner==owner then self.current.cancelled=true end
    for i=#self.jobs,1,-1 do
        if self.jobs[i].owner==owner then
            self.jobs[i].cancelled=true;table.remove(self.jobs,i)
            self.metrics.cancelled=self.metrics.cancelled+1
        end
    end
    if #self.jobs==0 and self.frame and not self.running then self.frame:Hide() end
    return true
end
function S:Queue(owner,fn,generation)
    if not C.Text(owner) or #owner==0 or #owner>64 or type(fn)~="function" then return false,"BAD_JOB" end
    if generation~=nil and not (C.Number(generation) or C.Text(generation)) then return false,"BAD_GENERATION" end
    local occupied=false
    for _,job in ipairs(self.jobs) do if job.owner==owner then occupied=true;break end end
    if #self.jobs+currentReservation(self,owner)>=capacity and not occupied then
        self.metrics.queueFull=self.metrics.queueFull+1;return false,"QUEUE_FULL"
    end
    self:Cancel(owner)
    self.serial=self.serial+1
    local epoch=self.serial
    self.generations[owner]=epoch
    self.jobs[#self.jobs+1]={owner=owner,fn=fn,epoch=epoch,generation=generation or epoch,eligibleTick=(self.tick or 0)+1}
    self.metrics.peakQueued=math.max(self.metrics.peakQueued,#self.jobs+currentReservation(self))
    if self.frame then self.frame:Show() end
    return true,"QUEUED"
end
function S:Tick()
    if self.running then return end
    self.running=true
    self.tick=(self.tick or 0)+1
    local count=math.min(#self.jobs,self.maxPerTick)
    local start=C.Call(debugprofilestop)
    for _=1,count do
        local current,clockOK=C.Call(debugprofilestop)
        if C.Number(start) and clockOK and C.Number(current) and current-start>=1.5 then break end
        local job=table.remove(self.jobs,1)
        if not job then break end
        if not job.cancelled and self.generations[job.owner]==job.epoch and job.eligibleTick>self.tick then
            self.jobs[#self.jobs+1]=job
        elseif not job.cancelled and self.generations[job.owner]==job.epoch then
            self.current=job
            local before=C.Call(debugprofilestop)
            local passed,again=pcall(job.fn,job.generation)
            local after=C.Call(debugprofilestop)
            self.current=nil
            self.metrics.slices=self.metrics.slices+1
            if C.Number(before) and C.Number(after) and after>=before then
                local elapsed=after-before
                self.metrics.maxSliceMS=math.max(self.metrics.maxSliceMS,elapsed)
                if elapsed>.5 then self.metrics.slowSlices=self.metrics.slowSlices+1 end
                if C.Performance and C.Performance.active then C.Performance:Sample("task."..job.owner,elapsed) end
            end
            local continued=false
            if not passed then
                self.metrics.failed=self.metrics.failed+1;C:Fault("TASK_FAILED_"..job.owner)
            elseif again==true and not job.cancelled and self.generations[job.owner]==job.epoch then
                if #self.jobs<capacity then
                    continued=true
                    job.eligibleTick=self.tick+1
                    self.jobs[#self.jobs+1]=job
                    self.metrics.continued=self.metrics.continued+1
                else
                    -- Queue admission reserves this slot. If external state
                    -- violates that invariant, do not claim a completed scan.
                    self.metrics.failed=self.metrics.failed+1;C:Fault("TASK_CONTINUATION_FULL")
                end
            else self.metrics.completed=self.metrics.completed+1 end
            if self.generations[job.owner]==job.epoch and not continued then
                self.generations[job.owner]=nil
            end
        end
    end
    self.running=false
    if #self.jobs==0 and self.frame then self.frame:Hide() end
end
function S:Status()
    return {queued=#self.jobs,active=currentReservation(self),capacity=capacity,
        running=self.running,metrics=C.Copy(self.metrics),
        budgetMS=1.5,chunkTargetMS=.5,qualification="HOST_INSTRUMENTATION_NOT_NATIVE_ACCEPTANCE"}
end
