local _,C=...
-- Source-qualified directed travel edges. Coordinates never create edges or
-- connector legs. All search costs in one graph use the same declared unit.
local G={graphs={},revision=0,nativeGeneration=0,status="NO_QUALIFIED_GRAPH",
    maxGraphs=8,maxNodes=256,maxEdges=1024,maxLegs=32,maxExpansions=256,maxRelaxations=2048,
    nativeVerification="NOT_RUN"}
C.TravelGraph=G
local owner="MirageIntel_Core_Taxi"
local nativeID="native:current-taxi"
local modes={WALK=true,FLIGHT=true,BOAT=true,ZEPPELIN=true,TRAM=true,PORTAL=true,ENTRANCE=true}
local costs={QUALIFIED_EDGE_COUNT=true,SOURCE_SECONDS=true,SOURCE_YARDS=true,NATIVE_COPPER_FARE=true}
local function readableTable(v)
    if not C.Readable(v) or type(v)~="table" then return false end
    if type(canaccesstable)=="function" then local ok,yes=pcall(canaccesstable,v);if not ok or yes==false then return false end end
    return true
end
local function field(t,k)
    if not readableTable(t) then return nil end
    local ok,v=pcall(function() return t[k] end)
    if ok and C.Readable(v) then return v end
    return nil
end
local function key(v,max)
    return C.Text(v) and #v>0 and #v<=(max or 128) and not v:find("[|%c]")
end
local function array(t,max)
    if not readableTable(t) then return false end
    local count=0
    for k in pairs(t) do
        if not C.Natural(k) or k>max then return false end
        count=count+1
        if count>max then return false end
    end
    return count==#t and count<=max
end
local function samePoint(a,b)
    return a and b and a.mapID==b.mapID and a.x==b.x and a.y==b.y and a.floorID==b.floorID
end
local function node(v)
    if not readableTable(v) or not key(v.id) or not key(v.label,160) or not C.Map:Valid(v.mapID,v.x,v.y) then return nil end
    if v.kind~=nil and not key(v.kind,32) or v.sourceRecordID~=nil and not key(v.sourceRecordID) then return nil end
    if v.floorID~=nil and not (key(v.floorID,64) or C.Natural(v.floorID)) then return nil end
    if v.taxiNodeID~=nil and not C.Natural(v.taxiNodeID) then return nil end
    local r={id=v.id,label=v.label,mapID=v.mapID,x=v.x,y=v.y,floorID=v.floorID,taxiNodeID=v.taxiNodeID,
        nodeID=v.taxiNodeID,kind=v.kind or "travel",sourceRecordID=v.sourceRecordID}
    if v.world~=nil then
        local w=v.world
        if not readableTable(w) or not C.Number(w.continent) or w.continent<0 or w.continent%1~=0 or
            not C.Number(w.x) or not C.Number(w.y) then return nil end
        r.world={continent=w.continent,x=w.x,y=w.y,mapID=v.mapID}
    end
    return r
end
local function access(v,source)
    if not readableTable(v) or not key(v.state,64) or v.state~=source.access then return nil end
    if v.faction~=nil and (not key(v.faction,16) or v.faction~="Alliance" and v.faction~="Horde" and v.faction~="Any") then return nil end
    if v.classID~=nil and not C.Natural(v.classID) then return nil end
    if v.minLevel~=nil and not C.Natural(v.minLevel) then return nil end
    if v.learnedNodeID~=nil and not C.Natural(v.learnedNodeID) then return nil end
    if v.requirements~=nil then
        if not array(v.requirements,16) then return nil end
        for _,name in ipairs(v.requirements) do if not key(name,64) then return nil end end
    end
    return {state=v.state,faction=v.faction,classID=v.classID,minLevel=v.minLevel,
        learnedNodeID=v.learnedNodeID,requirements=C.Copy(v.requirements)}
end
function G:ValidateGraph(who,definition)
    if not key(who,64) or not readableTable(definition) or not key(definition.id) or not key(definition.sourceID,64) or
        not key(definition.sourceRevision,128) or not key(definition.scope,32) or not key(definition.costBasis,32) then return nil,"INVALID_GRAPH" end
    if definition.generation~=nil and (not C.Number(definition.generation) or definition.generation<0 or definition.generation%1~=0) or
        definition.observedAt~=nil and (not C.Number(definition.observedAt) or definition.observedAt<0) then return nil,"INVALID_GRAPH_GENERATION" end
    local source=readableTable(C.TravelGraphSources) and C.TravelGraphSources[definition.sourceID]
    if not source or source.owner~=who or source.qualification~="NATIVE_API_SOURCE_REVIEWED" and source.qualification~="SOURCE_TRAVERSAL_REVIEWED" then
        return nil,"SOURCE_NOT_QUALIFIED_FOR_OWNER"
    end
    local build=C.Client and tostring(C.Client.build)
    -- A fresh internal native readback establishes current flight bookings.
    -- External/static graph data still needs its declared build alignment.
    -- The public API cannot register this reserved owner/source/scope, and
    -- Install separately fences the live capture generation and map lifetime.
    local liveNative=who==owner and definition.id==nativeID and definition.sourceID=="NATIVE_TAXI_71037" and definition.scope=="LIVE_TAXIMAP"
    local reviewed=source.reviewedBuilds and source.reviewedBuilds[build]==true
    if definition.sourceRevision~=source.revision or not liveNative and not reviewed then
        return nil,"SOURCE_BUILD_OR_REVISION_UNQUALIFIED"
    end
    if not costs[definition.costBasis] or not source.costBases or source.costBases[definition.costBasis]~=true then return nil,"UNQUALIFIED_COST_BASIS" end
    if definition.scope~=source.scope or not array(definition.nodes,self.maxNodes) or not array(definition.edges,self.maxEdges) then
        return nil,"INVALID_GRAPH_SCOPE_OR_BOUNDS"
    end
    local r={id=definition.id,owner=who,sourceID=definition.sourceID,sourceRevision=source.revision,
        sourceURL=source.sourceURL,coverage=source.coverage,limitation=source.limitation,
        costBasis=definition.costBasis,scope=definition.scope,nodes={},nodeOrder={},edges={},adjacency={},edgeCount=0,
        originNodeID=definition.originNodeID,generation=definition.generation,observedAt=definition.observedAt,
        clientBuild=build,clientPatch=C.Client and C.Client.patch,clientInterface=C.Client and C.Client.interface,
        sourceMatched=reviewed and C.Client.sourceMatched==true or false,
        runtimePolicy=liveNative and "CURRENT_NATIVE_READBACK" or "SOURCE_BUILD_QUALIFIED",
        nativeVerification="NOT_RUN"}
    for _,value in ipairs(definition.nodes) do
        local n=node(value)
        if not n or r.nodes[n.id] then return nil,"INVALID_OR_DUPLICATE_NODE" end
        r.nodes[n.id]=n;r.nodeOrder[#r.nodeOrder+1]=n.id;r.adjacency[n.id]={}
    end
    if #r.nodeOrder==0 or r.originNodeID and not r.nodes[r.originNodeID] then return nil,"MISSING_GRAPH_ORIGIN" end
    for _,e in ipairs(definition.edges) do
        if not readableTable(e) or not key(e.id) or not key(e.from) or not key(e.to) or r.edges[e.id] or not r.nodes[e.from] or not r.nodes[e.to] or e.from==e.to then
            return nil,"INVALID_EDGE_IDENTITY"
        end
        if not key(e.mode,32) or not key(e.precision,40) or not modes[e.mode] or not source.modes or source.modes[e.mode]~=true or e.precision~="VALIDATED_GRAPH_ROUTE" then return nil,"UNQUALIFIED_TRAVEL_MODE" end
        if not key(e.sourceID,64) or not key(e.sourceRevision,128) or not key(e.evidenceKind,64) or e.sourceID~=r.sourceID or e.sourceRevision~=r.sourceRevision or e.evidenceKind~=source.evidenceKind then return nil,"EDGE_EVIDENCE_MISSING" end
        if not key(e.costBasis,32) or e.costBasis~=r.costBasis or not C.Number(e.cost) or e.cost<0 or (r.costBasis=="QUALIFIED_EDGE_COUNT" and e.cost~=1) then
            return nil,"MIXED_OR_INVALID_EDGE_COST"
        end
        local a=access(e.access,source)
        if not a then return nil,"ACCESS_NOT_QUALIFIED" end
        local from,to=r.nodes[e.from],r.nodes[e.to]
        if e.mode=="WALK" and (from.mapID~=to.mapID or not from.floorID or from.floorID~=to.floorID or
            from.world and to.world and from.world.continent~=to.world.continent) then return nil,"WALK_GEOMETRY_CONTEXT_UNQUALIFIED" end
        if not key(e.geometry,32) or e.geometry~=source.geometry or e.geometry~="NOT_SUPPLIED" and e.geometry~="SOURCE_POLYLINE" then return nil,"UNQUALIFIED_EDGE_GEOMETRY" end
        local polyline
        if e.geometry=="SOURCE_POLYLINE" then
            if not array(e.polyline,32) or #e.polyline<2 then return nil,"INVALID_SOURCE_POLYLINE" end
            polyline={}
            for index,p in ipairs(e.polyline) do
                if not readableTable(p) or not C.Map:Valid(p.mapID,p.x,p.y) or p.mapID~=from.mapID or p.floorID~=from.floorID then return nil,"POLYLINE_CONTEXT_MISMATCH" end
                polyline[index]={mapID=p.mapID,x=p.x,y=p.y,floorID=p.floorID}
            end
            if not samePoint(polyline[1],from) or not samePoint(polyline[#polyline],to) then return nil,"POLYLINE_ENDPOINT_MISMATCH" end
        elseif e.polyline~=nil then return nil,"GEOMETRY_NOT_SUPPLIED" end
        local edge={id=e.id,from=e.from,to=e.to,mode=e.mode,precision="VALIDATED_GRAPH_ROUTE",cost=e.cost,costBasis=r.costBasis,
            access=a,sourceID=r.sourceID,sourceRevision=r.sourceRevision,evidenceKind=e.evidenceKind,
            geometry=e.geometry,polyline=polyline,instruction=key(e.instruction,180) and e.instruction or nil}
        r.edges[e.id]=edge;r.adjacency[e.from][#r.adjacency[e.from]+1]=edge;r.edgeCount=r.edgeCount+1
    end
    table.sort(r.nodeOrder)
    for _,edges in pairs(r.adjacency) do table.sort(edges,function(a,b)return a.id<b.id end) end
    return r,"SOURCE_QUALIFIED"
end
function G:Diagnostics()
    local diagnostics=C.Services and C.Services:Get("Diagnostics",1)
    if not diagnostics or type(diagnostics.Set)~="function" then return end
    local nodes,edges=0,0
    for _,graph in pairs(self.graphs) do nodes=nodes+#graph.nodeOrder;edges=edges+graph.edgeCount end
    diagnostics.Set("MirageIntel_Core_TravelGraph",{status=self.status,graphRevision=self.revision,
        nativeStatus=self.nativeStatus or "OPEN_FLIGHT_MASTER_TO_OBSERVE",nativeOpen=self.nativeOpen==true,
        currentBuild=C.Client and C.Client.build,sourceMatched=C.Client and C.Client.sourceMatched==true,
        nodes=nodes,edges=edges,algorithm="BOUNDED_DIJKSTRA",maxExpansions=self.maxExpansions,maxRelaxations=self.maxRelaxations,
        coverage="LIVE_NATIVE_FLIGHT_BOOKINGS",geometry="NOT_SUPPLIED",costBasis="QUALIFIED_EDGE_COUNT",nativeVerification="NOT_RUN"})
end
function G:Emit(reason)
    self.revision=self.revision+1
    self.status=reason
    self:Diagnostics()
    if C.Hub then C.Hub:Publish("TRAVEL_GRAPH_CHANGED",{revision=self.revision,graphRevision=self.revision,status=reason,nativeVerification="NOT_RUN"}) end
end
function G:Install(who,definition,nativeGeneration)
    if not C.Client or C.Client.allowed~=true then return false,"UNSUPPORTED_CLIENT" end
    local graph,why=self:ValidateGraph(who,definition)
    if not graph then return false,why end
    if who==owner and (not self.nativeOpen or nativeGeneration~=self.nativeGeneration) then return false,"STALE_NATIVE_CAPTURE" end
    local old=self.graphs[graph.id]
    if old and old.owner~=who then return false,"GRAPH_OWNED_BY_OTHER" end
    local count=0;for _ in pairs(self.graphs) do count=count+1 end
    if not old and count>=self.maxGraphs then return false,"GRAPH_LIMIT" end
    self.graphs[graph.id]=graph
    graph.revision=self.revision+1
    self:Emit("QUALIFIED_GRAPH_AVAILABLE")
    if self.graphs[graph.id]~=graph then return false,"GRAPH_SUPERSEDED_DURING_PUBLICATION" end
    return true,"SOURCE_QUALIFIED"
end
function G:Remove(who,id,reason)
    local graph=self.graphs[id]
    if not graph then return true,"GRAPH_ABSENT" end
    if graph.owner~=who then return false,"GRAPH_OWNED_BY_OTHER" end
    self.graphs[id]=nil;self:Emit(reason or "GRAPH_WITHDRAWN")
    return true,"GRAPH_WITHDRAWN"
end
function G:InvalidateNative(reason,readAt)
    self.nativeGeneration=self.nativeGeneration+1
    self.nativeFingerprint=nil;self.nativePlayer=nil;self.lastNativeRead=readAt
    self.nativeStatus=reason or "TAXI_CONTEXT_CLOSED"
    self:Remove(owner,nativeID,self.nativeStatus)
    self:Diagnostics()
end
function G:CaptureNative()
    if not self.nativeOpen or not C.Client or C.Client.allowed~=true then return false,"TAXI_CONTEXT_CLOSED" end
    local generation=self.nativeGeneration
    local function captureCurrent() return self.nativeOpen and generation==self.nativeGeneration end
    local source=C.TravelGraphSources and C.TravelGraphSources.NATIVE_TAXI_71037
    local states=Enum and Enum.FlightPathState
    local mapID,haveMap=C.Call(GetTaxiMapID)
    local rows,haveRows
    if haveMap and C.Natural(mapID) then rows,haveRows=C.Call(C_TaxiMap and C_TaxiMap.GetAllTaxiNodes,mapID) end
    local function failed(why)
        if not captureCurrent() then return false,"STALE_NATIVE_CAPTURE" end
        self:InvalidateNative(why,C:Now())
        return false,why
    end
    if not captureCurrent() then return false,"STALE_NATIVE_CAPTURE" end
    if not source or not states or not C.Number(states.Current) or not C.Number(states.Reachable) or not C.Number(states.Unreachable) or
        not haveRows or not array(rows,self.maxNodes) then return failed("NATIVE_TAXI_DATA_UNAVAILABLE") end
    local nodes,edges,seen,slots,fingerprint={}, {}, {}, {}, {tostring(mapID)}
    local current
    for _,row in ipairs(rows) do
        local transition=field(row,"isMapLayerTransition")
        if transition~=true and transition~=false then return failed("NATIVE_TAXI_LAYER_CONTEXT_UNREADABLE") end
        if transition==false then
            local id,state,slot=field(row,"nodeID"),field(row,"state"),field(row,"slotIndex")
            local x,y=C.Map:XY(field(row,"position"));local label=field(row,"name")
            if not C.Natural(id) or not C.Natural(slot) or seen[id] or slots[slot] or not key(label,160) or not C.Map:Valid(mapID,x,y) then
                return failed("NATIVE_TAXI_IDENTITY_UNREADABLE")
            end
            if state~=states.Current and state~=states.Reachable and state~=states.Unreachable then return failed("NATIVE_TAXI_STATE_UNREADABLE") end
            seen[id]=true;slots[slot]=true
            local n={id="taxi:"..id,taxiNodeID=id,label=label,mapID=mapID,x=x,y=y,kind="flight"}
            nodes[#nodes+1]=n
            fingerprint[#fingerprint+1]=table.concat({id,slot,state,x,y,label},":")
            if state==states.Current then if current then return failed("NATIVE_TAXI_ORIGIN_AMBIGUOUS") end;current=n
            elseif state==states.Reachable then edges[#edges+1]={target=n} end
        end
    end
    if not current then return failed("NATIVE_TAXI_ORIGIN_UNAVAILABLE") end
    local player=C.Map:Player()
    if not captureCurrent() then return false,"STALE_NATIVE_CAPTURE" end
    if not player or not C.Map:Valid(player.mapID,player.x,player.y) then return failed("PLAYER_CONTEXT_UNAVAILABLE") end
    for i,value in ipairs(edges) do
        local target=value.target
        edges[i]={id=current.id..">"..target.id,from=current.id,to=target.id,mode="FLIGHT",precision="VALIDATED_GRAPH_ROUTE",
            geometry="NOT_SUPPLIED",cost=1,costBasis="QUALIFIED_EDGE_COUNT",access={state="NATIVE_CURRENT_REACHABLE"},
            sourceID="NATIVE_TAXI_71037",sourceRevision=source.revision,evidenceKind="NATIVE_OPEN_MAP_REACHABLE",
            instruction="Choose the flight to "..target.label.." on the native flight map"}
    end
    table.sort(fingerprint)
    local stamp=table.concat(fingerprint,";")
    self.lastNativeRead=C:Now();self.nativePlayer=C.Copy(player);self.nativeStatus="LIVE_FLIGHT_BOOKINGS_ONLY"
    if stamp==self.nativeFingerprint and self.graphs[nativeID] then
        self.graphs[nativeID].observedAt=self.lastNativeRead;return true,"LIVE_SNAPSHOT_UNCHANGED"
    end
    local ok,why=self:Install(owner,{id=nativeID,sourceID="NATIVE_TAXI_71037",sourceRevision=source.revision,
        scope="LIVE_TAXIMAP",nodes=nodes,edges=edges,originNodeID=current.id,generation=self.nativeGeneration,
        observedAt=self.lastNativeRead,costBasis="QUALIFIED_EDGE_COUNT"},generation)
    if not ok then
        if why=="GRAPH_SUPERSEDED_DURING_PUBLICATION" then return false,why end
        return failed(why)
    end
    if not self.nativeOpen or generation~=self.nativeGeneration then return false,"STALE_NATIVE_CAPTURE" end
    self.nativeFingerprint=stamp
    return true,"LIVE_FLIGHT_BOOKINGS_ONLY"
end
function G:EnsureLive()
    if not self.nativeOpen then return end
    local player=C.Map:Player()
    if self.nativePlayer and (not player or player.mapID~=self.nativePlayer.mapID) then
        self.nativeOpen=false;self:InvalidateNative("PLAYER_CONTEXT_CHANGED");return
    end
    local now=C:Now()
    if not self.lastNativeRead or now<self.lastNativeRead or now-self.lastNativeRead>=1 then self:CaptureNative() end
end
local function nodeIDFrom(value)
    if not readableTable(value) then return nil end
    if C.Natural(value.taxiNodeID) then return "taxi:"..value.taxiNodeID end
    if C.Natural(value.nodeID) then return "taxi:"..value.nodeID end
    for _,keyName in ipairs({"graphNodeID","recordID","id"}) do
        local id=field(value,keyName)
        if key(id) then
            local taxi=id:match("^taxiobs:(%d+):") or id:match("^taxi:(%d+)$")
            if taxi then return "taxi:"..taxi end
        end
    end
    return nil
end
function G:Endpoint(graph,value,isStart)
    if not readableTable(value) then return nil end
    if graph.scope=="LIVE_TAXIMAP" and isStart then
        local live=C.Map:Player()
        if not self.nativeOpen or not self.nativePlayer or not live or live.mapID~=self.nativePlayer.mapID or value.mapID~=live.mapID or
            not C.Map:Valid(value.mapID,value.x,value.y) or math.abs(value.x-live.x)>.000001 or math.abs(value.y-live.y)>.000001 then return nil end
        return graph.originNodeID
    end
    local explicit=nodeIDFrom(value) or field(value,"graphNodeID")
    if explicit and graph.nodes[explicit] then return explicit end
    if graph.scope=="LIVE_TAXIMAP" then return nil end
    local identity=field(value,"recordID") or field(value,"id")
    if identity and graph.nodes[identity] then return identity end
    -- Exact registered points may identify graph nodes. No nearest-point
    -- snapping or invented player-to-road connectors are permitted.
    for _,id in ipairs(graph.nodeOrder) do if samePoint(graph.nodes[id],value) then return id end end
end
local function allowed(edge,context)
    if context.modes~=nil and (not readableTable(context.modes) or field(context.modes,edge.mode)~=true) then return false,"TRAVEL_MODE_EXCLUDED" end
    local a=edge.access
    if a.faction and a.faction~="Any" and field(context,"faction")~=a.faction then return false,"FACTION_ACCESS_UNKNOWN_OR_DENIED" end
    if a.classID and field(context,"classID")~=a.classID then return false,"CLASS_ACCESS_UNKNOWN_OR_DENIED" end
    if a.minLevel and (not C.Number(context.level) or context.level<a.minLevel) then return false,"LEVEL_ACCESS_UNKNOWN_OR_DENIED" end
    if a.learnedNodeID and (not readableTable(context.learnedNodes) or field(context.learnedNodes,a.learnedNodeID)~=true) then return false,"LEARNED_ACCESS_UNKNOWN_OR_DENIED" end
    for _,name in ipairs(a.requirements or {}) do if not readableTable(context.capabilities) or field(context.capabilities,name)~=true then return false,"REQUIRED_ACCESS_UNKNOWN_OR_DENIED" end end
    return true
end
local function legRecord(graph,edge,revision)
    local leg=C.Copy(edge)
    leg.from=C.Copy(graph.nodes[edge.from]);leg.to=C.Copy(graph.nodes[edge.to])
    leg.source=graph.sourceID;leg.sourceURL=graph.sourceURL;leg.graphID=graph.id
    leg.clientBuild=graph.clientBuild;leg.sourceMatched=graph.sourceMatched;leg.runtimePolicy=graph.runtimePolicy
    leg.graphRevision=revision;leg.nativeVerification="NOT_RUN"
    return leg
end
local function equivalent(a,b,depth)
    if not C.Readable(a) or not C.Readable(b) or type(a)~=type(b) then return false end
    if type(b)~="table" then return a==b end
    depth=depth or 0
    if depth>=8 or not readableTable(a) or not readableTable(b) then return false end
    local count,expected=0,0
    for k,value in pairs(b) do expected=expected+1;if not equivalent(field(a,k),value,depth+1) then return false end end
    for k in pairs(a) do
        count=count+1
        if count>300 or not (type(k)=="string" or C.Number(k)) or b[k]==nil then return false end
    end
    return count==expected
end
function G:Search(graph,start,goal,context)
    local distance,previous,done={[start]=0},{},{}
    local expanded,relaxed=0,0
    local function failed(reason) return nil,reason,{expansions=expanded,relaxations=relaxed} end
    local expansionLimit=C.Natural(context.maxExpansions) and math.min(context.maxExpansions,self.maxExpansions) or self.maxExpansions
    local relaxationLimit=C.Natural(context.maxRelaxations) and math.min(context.maxRelaxations,self.maxRelaxations) or self.maxRelaxations
    local blocked
    while true do
        local best,bestCost
        for _,id in ipairs(graph.nodeOrder) do
            local value=distance[id]
            if value~=nil and not done[id] and (not best or value<bestCost or value==bestCost and id<best) then best,bestCost=id,value end
        end
        if not best then return failed(blocked or "NO_QUALIFIED_PATH") end
        if best==goal then break end
        if expanded>=expansionLimit then return failed("SEARCH_EXPANSION_LIMIT") end
        done[best]=true;expanded=expanded+1
        for _,edge in ipairs(graph.adjacency[best]) do
            if relaxed>=relaxationLimit then return failed("SEARCH_RELAXATION_LIMIT") end
            relaxed=relaxed+1
            local usable,why=allowed(edge,context)
            if usable then
                local cost=bestCost+edge.cost
                if C.Number(cost) and not done[edge.to] and (distance[edge.to]==nil or cost<distance[edge.to]) then
                    distance[edge.to]=cost;previous[edge.to]=edge
                end
            else blocked=why end
        end
    end
    local reverse,cursor={},goal
    while cursor~=start do
        local edge=previous[cursor]
        if not edge then return failed("BROKEN_GRAPH_PATH") end
        reverse[#reverse+1]=edge
        if #reverse>self.maxLegs then return failed("ROUTE_LEG_LIMIT") end
        cursor=edge.from
    end
    if #reverse==0 then return failed("AT_GRAPH_DESTINATION") end
    local legs={}
    for index=#reverse,1,-1 do
        local edge=reverse[index]
        legs[#legs+1]=legRecord(graph,edge,self.revision)
    end
    return {status="VALIDATED_GRAPH_ROUTE",precision="VALIDATED_GRAPH_ROUTE",graphID=graph.id,graphRevision=self.revision,
        sourceID=graph.sourceID,sourceRevision=graph.sourceRevision,sourceURL=graph.sourceURL,
        clientBuild=graph.clientBuild,sourceMatched=graph.sourceMatched,runtimePolicy=graph.runtimePolicy,
        coverage=graph.coverage,limitation=graph.limitation,scope=graph.scope,
        generation=context.generation,sourceGeneration=graph.generation,cost=distance[goal],costBasis=graph.costBasis,
        legs=legs,nextLeg=legs[1],algorithm="BOUNDED_DIJKSTRA",expansions=expanded,relaxations=relaxed,
        estimatedPath=false,nativeVerification="NOT_RUN"},"VALIDATED_GRAPH_ROUTE",{expansions=expanded,relaxations=relaxed}
end
function G:GetRoute(request)
    if not C.Client or C.Client.allowed~=true then return nil,"UNSUPPORTED_CLIENT" end
    if not readableTable(request) or not readableTable(request.start) or not readableTable(request.destination) then return nil,"INVALID_ROUTE_REQUEST" end
    self:EnsureLive()
    local context=readableTable(request.context) and request.context or {}
    if context.expectedGraphRevision~=nil and context.expectedGraphRevision~=self.revision then return nil,"STALE_GRAPH_REVISION" end
    local revision=self.revision
    local ids={};for id in pairs(self.graphs) do ids[#ids+1]=id end;table.sort(ids)
    local reason="NO_GRAPH_COVERAGE_FOR_ENDPOINTS"
    local expansionLimit=C.Natural(context.maxExpansions) and math.min(context.maxExpansions,self.maxExpansions) or self.maxExpansions
    local relaxationLimit=C.Natural(context.maxRelaxations) and math.min(context.maxRelaxations,self.maxRelaxations) or self.maxRelaxations
    local expanded,relaxed=0,0
    for _,id in ipairs(ids) do
        local graph=self.graphs[id]
        local from,to=self:Endpoint(graph,request.start,true),self:Endpoint(graph,request.destination,false)
        if self.revision~=revision or self.graphs[id]~=graph then return nil,"STALE_GRAPH_REVISION" end
        if from and to then
            if expanded>=expansionLimit then return nil,"SEARCH_EXPANSION_LIMIT" end
            if relaxed>=relaxationLimit then return nil,"SEARCH_RELAXATION_LIMIT" end
            local searchContext={modes=context.modes,faction=context.faction,classID=context.classID,level=context.level,
                learnedNodes=context.learnedNodes,capabilities=context.capabilities,generation=context.generation,
                maxExpansions=expansionLimit-expanded,maxRelaxations=relaxationLimit-relaxed}
            local result,why,work=self:Search(graph,from,to,searchContext)
            if self.revision~=revision or self.graphs[id]~=graph then return nil,"STALE_GRAPH_REVISION" end
            expanded=expanded+(work and work.expansions or 0);relaxed=relaxed+(work and work.relaxations or 0)
            if result then result.expansions=expanded;result.relaxations=relaxed;return C.Copy(result),why end
            if why=="SEARCH_EXPANSION_LIMIT" or why=="SEARCH_RELAXATION_LIMIT" then return nil,why end
            reason=why
        end
    end
    return nil,reason
end
function G:ValidateRoute(route)
    if not C.Client or C.Client.allowed~=true then return false,"UNSUPPORTED_CLIENT" end
    if not readableTable(route) then return false,"INVALID_ROUTE" end
    self:EnsureLive()
    if route.graphRevision~=self.revision then return false,"STALE_GRAPH_REVISION" end
    local graph=self.graphs[route.graphID]
    if not graph or graph.generation~=route.sourceGeneration or not array(route.legs,self.maxLegs) or #route.legs==0 then return false,"GRAPH_UNAVAILABLE" end
    if route.sourceID~=graph.sourceID or route.sourceRevision~=graph.sourceRevision or route.sourceURL~=graph.sourceURL or
        route.clientBuild~=graph.clientBuild or route.sourceMatched~=graph.sourceMatched or route.runtimePolicy~=graph.runtimePolicy or
        route.scope~=graph.scope or route.status~="VALIDATED_GRAPH_ROUTE" then return false,"ROUTE_SOURCE_CHANGED" end
    local previous,cost=nil,0
    for index,leg in ipairs(route.legs) do
        local e=readableTable(leg) and graph.edges[leg.id]
        if not e or not readableTable(leg.from) or not readableTable(leg.to) or leg.from.id~=e.from or leg.to.id~=e.to or
            previous and previous~=e.from then return false,"ROUTE_EDGE_CHANGED" end
        local canonical=legRecord(graph,e,self.revision)
        if not equivalent(leg,canonical) or index==1 and not equivalent(route.nextLeg,canonical) then return false,"ROUTE_EDGE_METADATA_CHANGED" end
        previous=e.to;cost=cost+e.cost
    end
    if route.cost~=cost or route.costBasis~=graph.costBasis or route.precision~="VALIDATED_GRAPH_ROUTE" then return false,"ROUTE_COST_CHANGED" end
    return true,"CURRENT_GRAPH_ROUTE"
end
function G:GetStatus()
    self:EnsureLive()
    local count,nodes,edges=0,0,0
    for _,graph in pairs(self.graphs) do count=count+1;nodes=nodes+#graph.nodeOrder;edges=edges+graph.edgeCount end
    return {apiVersion=1,revision=self.revision,graphRevision=self.revision,status=count>0 and "QUALIFIED_GRAPH_AVAILABLE" or "NO_QUALIFIED_GRAPH",
        graphCount=count,nodeCount=nodes,edgeCount=edges,nativeStatus=self.nativeStatus or "OPEN_FLIGHT_MASTER_TO_OBSERVE",
        currentBuild=C.Client and C.Client.build,sourceMatched=C.Client and C.Client.sourceMatched==true,
        coverage="Live flight-master bookings only; road and terrain graph not supplied",nativeOpen=self.nativeOpen==true,
        algorithm="BOUNDED_DIJKSTRA",maxExpansions=self.maxExpansions,maxRelaxations=self.maxRelaxations,
        maxNodes=self.maxNodes,maxEdges=self.maxEdges,maxLegs=self.maxLegs,nativeVerification="NOT_RUN"}
end
function G:GetNodes()
    self:EnsureLive()
    local graph=self.graphs[nativeID]
    local result={status=graph and "LIVE_FLIGHT_BOOKINGS_ONLY" or self.nativeStatus or "OPEN_FLIGHT_MASTER_TO_OBSERVE",
        graphRevision=self.revision,records={},nativeVerification="NOT_RUN"}
    if not graph then return result end
    result.originNodeID=graph.originNodeID;result.origin=C.Copy(graph.nodes[graph.originNodeID]);result.sourceID=graph.sourceID
    result.clientBuild=graph.clientBuild;result.clientPatch=graph.clientPatch;result.clientInterface=graph.clientInterface
    result.sourceMatched=graph.sourceMatched;result.runtimePolicy=graph.runtimePolicy
    for _,edge in ipairs(graph.adjacency[graph.originNodeID] or {}) do
        local n=C.Copy(graph.nodes[edge.to]);n.mode="FLIGHT";n.access="NATIVE_CURRENT_REACHABLE"
        n.source="NATIVE_TAXI_OPEN_MAP";n.graphRevision=self.revision;n.precision="VALIDATED_GRAPH_ROUTE"
        n.costBasis="QUALIFIED_EDGE_COUNT";n.geometry="NOT_SUPPLIED";n.sourceRevision=graph.sourceRevision
        result.records[#result.records+1]=n
    end
    table.sort(result.records,function(a,b) if a.label~=b.label then return a.label<b.label end;return a.id<b.id end)
    return result
end
function G:Initialize()
    if self.initialized or not C.Client or C.Client.allowed~=true then return end
    self.initialized=true
    local frame=CreateFrame("Frame");self.frame=frame
    for _,event in ipairs({"TAXIMAP_OPENED","TAXIMAP_CLOSED","TAXI_NODE_STATUS_CHANGED","PLAYER_ENTERING_WORLD",
        "PLAYER_LEAVING_WORLD","ZONE_CHANGED_NEW_AREA","PLAYER_DEAD","PLAYER_CONTROL_LOST","PLAYER_REGEN_DISABLED"}) do
        pcall(frame.RegisterEvent,frame,event)
    end
    frame:SetScript("OnEvent",function(_,event)
        if event=="TAXIMAP_OPENED" then
            G.nativeOpen=false;G:InvalidateNative("TAXI_CONTEXT_REOPENED");G.nativeOpen=true;G:CaptureNative()
        elseif event=="TAXI_NODE_STATUS_CHANGED" and G.nativeOpen then
            G:CaptureNative()
        else
            G.nativeOpen=false;G:InvalidateNative(event)
        end
    end)
    self:Diagnostics()
end
local A={apiVersion=1}
local function reserved(who,definition)
    return who==owner or field(definition,"sourceID")=="NATIVE_TAXI_71037" or field(definition,"scope")=="LIVE_TAXIMAP" or field(definition,"id")==nativeID
end
function A.RegisterGraph(who,definition)
    if reserved(who,definition) then return false,"NATIVE_SOURCE_RUNTIME_ONLY" end
    return G:Install(who,definition)
end
function A.RemoveGraph(who,id)
    if who==owner or id==nativeID then return false,"NATIVE_SOURCE_RUNTIME_ONLY" end
    return G:Remove(who,id)
end
function A.ValidateGraph(who,definition)
    if reserved(who,definition) then return false,"NATIVE_SOURCE_RUNTIME_ONLY" end
    local graph,why=G:ValidateGraph(who,definition);return graph~=nil,why
end
function A.GetRoute(request) return G:GetRoute(request) end
function A.GetStatus() return C.Copy(G:GetStatus()) end
function A.GetNodes() return C.Copy(G:GetNodes()) end
function A.ValidateRoute(route) return G:ValidateRoute(route) end
A.Validate=A.ValidateRoute
C.Services:Register("TravelGraph","MirageIntel_Core",1,A)
