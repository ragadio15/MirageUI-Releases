-- Shared, locally observed character facts. No network, remote bank access or
-- trading actions. Bag work is coalesced and sliced by the suite scheduler.
local _,C=...
C.CharacterContext={revision=0,generation=0,bankEpoch=0,bankOpen=false,
    data={professions={},bags={rows={},status="NOT_SCANNED",current=false},
        bank={rows={},status="NOT_OBSERVED",current=false}},metrics={requests=0,scans=0,slots=0}}
local P=C.CharacterContext
local OWNER="CharacterContext"
local function integer(v,low,high)
    return C.Number(v) and v%1==0 and v>=low and v<=(high or 1000000000)
end
local function text(v,limit)
    return C.Readable(v) and type(v)=="string" and #v>0 and #v<=(limit or 240) and v or nil
end
local function fieldAccess(t,k)
    if not C.Readable(t) or type(t)~="table" then return nil,"UNAVAILABLE" end
    if type(canaccesstable)=="function" then
        local ok,allowed=pcall(canaccesstable,t)
        if not ok or allowed==false then return nil,"UNAVAILABLE" end
    end
    local ok,v=pcall(function()return t[k] end)
    if not ok or not C.Readable(v) then return nil,"UNAVAILABLE" end
    return v,v==nil and "ABSENT" or "KNOWN"
end
local function field(t,k)
    return (fieldAccess(t,k))
end
local function now()
    local value,ok=C.Call(GetServerTime or time)
    return ok and integer(value,0,9007199254740991) and value or 0
end
local function value(fn,...)
    return (C.Call(fn,...))
end
local function inventoryCopy(source)
    local result={}
    for k,v in pairs(source or {}) do if k~="rows" then result[k]=C.Copy(v) end end
    result.rows={}
    for i,row in ipairs(source and source.rows or {}) do
        if i>2048 then break end
        result.rows[i]=C.Copy(row)
    end
    return result
end
function P:Snapshot()
    local result={}
    for k,v in pairs(self.data) do
        result[k]=(k=="bags" or k=="bank") and inventoryCopy(v) or C.Copy(v)
    end
    result.revision=self.revision
    result.bankOpen=self.bankOpen==true
    result.refreshPending=self.pending~=nil or self.active~=nil
    result.source="MIRAGE_SHARED_CHARACTER_CONTEXT"
    return result
end
function P:Publish(reason)
    self.revision=self.revision+1
    C.Hub:Publish("CHARACTER_CONTEXT_UPDATED",{revision=self.revision,reason=reason,
        bagsRevision=self.data.bags.revision,bankRevision=self.data.bank.revision,
        bankOpen=self.bankOpen,bagsCurrent=self.data.bags.current,bankCurrent=self.data.bank.current})
end
function P:Metadata(includeProfessions)
    local d=self.data
    d.realm=text(value(GetRealmName));d.realmID=value(GetRealmID);d.region=value(GetCurrentRegion)
    if not integer(d.realmID,1) then d.realmID=nil end
    if not integer(d.region,1,999) then d.region=nil end
    d.faction=text(value(UnitFactionGroup,"player"),32)
    d.level=C.Call(UnitLevel,"player");if not integer(d.level,1,999) then d.level=nil end
    local class,_,classToken,classID=C.Call(UnitClass,"player")
    d.class=text(class);d.classToken=text(classToken);d.classID=integer(classID,1,100) and classID or nil
    local race,__,raceToken=C.Call(UnitRace,"player")
    d.race=text(race);d.raceToken=text(raceToken)
    d.mapID=C.Call(C_Map and C_Map.GetBestMapForUnit,"player")
    if not integer(d.mapID,1,10000000) then d.mapID=nil end
    local info=d.mapID and C.Call(C_Map and C_Map.GetMapInfo,d.mapID)
    d.location=text(field(info,"name")) or text(value(GetRealZoneText))
    d.zone=text(value(GetRealZoneText));d.subzone=text(value(GetSubZoneText));d.at=now()
    if includeProfessions then self:Professions() end
end
function P:Professions()
    if type(GetProfessions)~="function" or type(GetProfessionInfo)~="function" then
        self.data.professionsCurrent=false;return false
    end
    local ok,a,b,c,d,e,f=pcall(GetProfessions)
    if not ok then self.data.professionsCurrent=false;return false end
    local rows,seen={},{}
    for _,id in pairs({a,b,c,d,e,f}) do
        if not integer(id,1,4096) then self.data.professionsCurrent=false;return false end
        if integer(id,1,4096) and not seen[id] then
            seen[id]=true
            local good,name,icon,rank,maximum,_,__,skill=pcall(GetProfessionInfo,id)
            if not good or not text(name) or not integer(rank,0,10000) or not integer(maximum,0,10000) then
                self.data.professionsCurrent=false;return false
            end
            rows[#rows+1]={name=name,icon=(integer(icon,1) or text(icon)) and icon or nil,
                rank=rank,max=maximum,skillLineID=integer(skill,1) and skill or nil}
        end
    end
    self.data.professions=rows;self.data.professionsCurrent=true;self.data.professionsAt=now()
    return true
end
local function bagIDs()
    local result,seen={},{}
    local function add(id)
        if integer(id,0,1024) and not seen[id] then result[#result+1]=id;seen[id]=true end
    end
    local count=integer(NUM_BAG_SLOTS,0,10) and NUM_BAG_SLOTS or 4
    for id=0,count do add(id) end
    add(field(Enum and Enum.BagIndex,"ReagentBag"))
    return result
end
function P:BankAccess()
    if not self.bankOpen then return false,"BANK_CLOSED" end
    local bankType=field(Enum and Enum.BankType,"Character")
    if C_Bank and type(C_Bank.CanViewBank)=="function" and integer(bankType,0,100) then
        local allowed,ok=C.Call(C_Bank.CanViewBank,bankType)
        if not ok or allowed~=true then return false,"BANK_NOT_ACCESSIBLE" end
    end
    return true
end
function P:BankIDs()
    local accessible,why=self:BankAccess()
    if not accessible then return nil,why end
    local bankType=field(Enum and Enum.BankType,"Character")
    if C_Bank and type(C_Bank.FetchPurchasedBankTabIDs)=="function" and integer(bankType,0,100) then
        local ids,ok=C.Call(C_Bank.FetchPurchasedBankTabIDs,bankType)
        if not ok or type(ids)~="table" then return nil,"BANK_NOT_READY" end
        local result,seen={},{}
        for index=1,33 do
            local id,state=fieldAccess(ids,index)
            if state=="ABSENT" then return result end
            if state~="KNOWN" then return nil,"BANK_TABS_UNREADABLE" end
            if index==33 or not integer(id,6,1024) or seen[id] then return nil,"BANK_TABS_INVALID" end
            seen[id]=true;result[#result+1]=id
        end
    end
    local enum=Enum and Enum.BagIndex
    local main=field(enum,"Bank") or BANK_CONTAINER
    if not integer(main,-20,1024) then return nil,"BANK_API_UNAVAILABLE" end
    local result,seen={main},{[main]=true}
    local declared=false
    for n=1,14 do
        local id=field(enum,"BankBag_"..n)
        if integer(id,0,1024) and not seen[id] then result[#result+1]=id;seen[id]=true;declared=true end
    end
    if not declared and integer(NUM_BANKBAGSLOTS,0,14) then
        local first=(integer(NUM_BAG_SLOTS,0,10) and NUM_BAG_SLOTS or 4)+1
        for id=first,first+NUM_BANKBAGSLOTS-1 do if not seen[id] then result[#result+1]=id;seen[id]=true end end
    end
    return result
end
local function containerAPI()
    local api=type(C_Container)=="table" and C_Container
    if api and type(api.GetContainerNumSlots)=="function" and type(api.GetContainerItemInfo)=="function" then return api end
end
function P:Plan(source)
    local ids,reason
    if source=="bags" then ids=bagIDs() else ids,reason=self:BankIDs() end
    local task={source=source,rows={},containers={},index=1,slot=1,slotsRead=0,totalSlots=0,
        status=reason or "READY",current=false,bankEpoch=self.bankEpoch}
    local api=containerAPI()
    if not ids or not api then task.status=reason or "CONTAINER_API_UNAVAILABLE";return task end
    for _,id in ipairs(ids) do
        local size,ok=C.Call(api.GetContainerNumSlots,id)
        if not ok or not integer(size,0,256) then task.status="PARTIAL";size=0 end
        task.totalSlots=task.totalSlots+size
        if task.totalSlots>2048 then task.status="CAPACITY_LIMIT";return task end
        task.containers[#task.containers+1]={id=id,size=size}
    end
    if #ids>0 and task.totalSlots==0 then task.status=source=="bank" and "BANK_NOT_READY" or "BAGS_NOT_READY" end
    return task
end
local function readSlot(api,bag,slot)
    local info,ok=C.Call(api.GetContainerItemInfo,bag,slot)
    if not ok then return nil,false end
    if info==nil then return nil,true end
    local id,count=field(info,"itemID"),field(info,"stackCount")
    if not integer(id,1) or not integer(count,1,100000000) then return nil,false end
    local link=text(field(info,"hyperlink"),1024)
    local name=text(field(info,"itemName")) or (link and link:match("%[([^%]]+)%]"))
    local icon=field(info,"iconFileID") or field(info,"icon")
    local quality=field(info,"quality")
    return {bag=bag,slot=slot,itemID=id,count=count,itemLink=link,name=name or ("Item "..id),
        icon=(integer(icon,1) or text(icon)) and icon or nil,
        quality=integer(quality,0,10) and quality or nil,
        isBound=field(info,"isBound")==true,locked=field(info,"isLocked")==true},true
end
function P:Step(task)
    if task.source=="bank" and (not self.bankOpen or task.bankEpoch~=self.bankEpoch) then
        task.status="BANK_SESSION_CHANGED";task.rows={};return false
    end
    if task.source=="bank" then
        local accessible,why=self:BankAccess()
        if not accessible then task.status=why;task.rows={};return false end
        if not self.bankOpen or task.bankEpoch~=self.bankEpoch then task.status="BANK_SESSION_CHANGED";task.rows={};return false end
    end
    local api=containerAPI()
    if not api then task.status="CONTAINER_API_UNAVAILABLE";return false end
    local reads=0
    while reads<48 and task.index<=#task.containers do
        local container=task.containers[task.index]
        if task.slot>container.size then task.index=task.index+1;task.slot=1
        else
            if task.source=="bank" and (not self.bankOpen or task.bankEpoch~=self.bankEpoch) then
                task.status="BANK_SESSION_CHANGED";task.rows={};return false
            end
            local row,ok=readSlot(api,container.id,task.slot)
            if not ok then task.status="PARTIAL" elseif row then task.rows[#task.rows+1]=row end
            task.slot=task.slot+1;task.slotsRead=task.slotsRead+1;reads=reads+1
        end
    end
    self.metrics.slots=self.metrics.slots+reads
    return task.index<=#task.containers
end
function P:Commit(task)
    if task.source=="bank" and (not self.bankOpen or task.bankEpoch~=self.bankEpoch) then return false end
    if task.source=="bank" then
        local accessible,why=self:BankAccess()
        if not accessible then task.status=why;task.rows={} end
        if not self.bankOpen or task.bankEpoch~=self.bankEpoch then return false end
    end
    local prior=self.data[task.source]
    if task.source=="bank" and task.status~="READY" and prior.at then
        prior.current=false;prior.status="CACHED";prior.lastAttemptStatus=task.status
        return false
    end
    local result={rows=task.rows,status=task.status,current=task.status=="READY",at=now(),
        revision=(prior.revision or 0)+1,slotsRead=task.slotsRead,totalSlots=task.totalSlots,
        containersObserved=#task.containers,source=task.source=="bags" and "CARRIED_BAGS" or "CHARACTER_BANK"}
    self.data[task.source]=result
    if task.source=="bank" and result.current and C.Storage and not C.Storage.readOnly and type(C.Storage.character)=="table" then
        C.Storage.character.characterContextBank={schema=1,snapshot=inventoryCopy(result)}
    end
    return true
end
-- P39-F: source-aware refresh requests. Profession list updates must not
-- invalidate and reread all carried bags unless a bag event also arrived.
-- Repeated native events merged while a refresh is pending never cancel the
-- same scheduler job. A later event after work begins can still invalidate it.
function P:Request(reason,includeBank,includeProfessions,includeBags)
    if not self.initialized then return false,"CONTEXT_NOT_READY" end
    local needBank=includeBank==true
    local needProfession=includeProfessions==true
    local needBags=includeBags~=false
    self.metrics.requests=self.metrics.requests+1
    if self.pending and (not needBank or self.pending.bank) and
        (not needProfession or self.pending.professions) and
        (not needBags or self.pending.bags) then
        self.metrics.coalesced=(self.metrics.coalesced or 0)+1
        return true,"COALESCED_PENDING"
    end
    self.generation=self.generation+1
    local pending=self.pending or {due=C:Now()+.15}
    local active=self.active
    pending.bank=pending.bank or needBank or (active and active.includeBank) or false
    pending.professions=pending.professions or needProfession or (active and active.includeProfessions) or false
    pending.bags=pending.bags or needBags or (active and active.includeBags) or false
    pending.reason=text(reason,80) or "REFRESH"
    self.pending=pending;self.active=nil
    if pending.bags then self.data.bags.current=false end
    if pending.bank then self.data.bank.current=false end
    local generation=self.generation
    local queued,why=C.Scheduler:Queue(OWNER,function()
        if generation~=self.generation or not self.initialized then return false end
        if self.pending then
            if C:Now()<self.pending.due then return true end
            local request=self.pending;self.pending=nil
            self:Metadata(request.professions)
            if generation~=self.generation then return false end
            local tasks={}
            if request.bags then tasks[#tasks+1]=self:Plan("bags") end
            if request.bank and self.bankOpen then tasks[#tasks+1]=self:Plan("bank") end
            if generation~=self.generation then return false end
            if #tasks==0 then
                self.metrics.metadataOnly=(self.metrics.metadataOnly or 0)+1
                self:Publish(request.reason)
                return false
            end
            self.active={reason=request.reason,includeBank=request.bank,includeProfessions=request.professions,
                includeBags=request.bags,tasks=tasks,index=1,generation=generation}
        end
        local job=self.active
        if not job or job.generation~=generation then return false end
        local task=job.tasks[job.index]
        if self:Step(task) then return true end
        if generation~=self.generation or self.active~=job then return false end
        self:Commit(task)
        if generation~=self.generation or self.active~=job then return false end
        job.index=job.index+1
        if job.index<=#job.tasks then return true end
        self.active=nil;self.metrics.scans=self.metrics.scans+1;self:Publish(job.reason)
        return false
    end,generation)
    if not queued then
        self.pending=nil
        if needBags then self.data.bags.status="REFRESH_DEFERRED" end
    end
    return queued,why
end
function P:CloseBank(reason)
    self.bankOpen=false;self.bankEpoch=self.bankEpoch+1
    self.data.bank.current=false
    if self.data.bank.at then self.data.bank.status="CACHED" end
    self:Publish(reason or "BANK_CLOSED")
end
function P:OnEvent(event)
    if not self.initialized then return end
    if event=="BANKFRAME_OPENED" then
        self.bankOpen=true;self.bankEpoch=self.bankEpoch+1;self:Request(event,true,true)
    elseif event=="BANKFRAME_CLOSED" then self:CloseBank(event)
    elseif event=="PLAYER_LEAVING_WORLD" then
        self.generation=self.generation+1;self.pending=nil;self.active=nil
        C.Scheduler:Cancel(OWNER);self.data.bags.current=false;self:CloseBank(event)
    elseif event=="PLAYER_ENTERING_WORLD" or event=="PLAYER_LOGIN" then self:Request(event,false,true)
    elseif event=="ZONE_CHANGED_NEW_AREA" or event=="ZONE_CHANGED" or event=="ZONE_CHANGED_INDOORS" or event=="PLAYER_LEVEL_UP" or event=="UNIT_FACTION" then
        self:Metadata(false);self:Publish(event)
    elseif event=="AUCTION_HOUSE_SHOW" or event=="MERCHANT_SHOW" or event=="TRADE_SKILL_SHOW" or event=="CRAFT_SHOW" then
        self:Request(event,self.bankOpen,true,true)
    elseif event=="SKILL_LINES_CHANGED" or event=="TRADE_SKILL_LIST_UPDATE" or
        event=="TRADE_SKILL_DATA_SOURCE_CHANGED" or event=="NEW_RECIPE_LEARNED" then
        self:Request(event,self.bankOpen,true,false)
    elseif event=="BAG_UPDATE_DELAYED" or event=="BAG_UPDATE" then
        self:Request(event,self.bankOpen,false,true)
    elseif event=="PLAYERBANKSLOTS_CHANGED" or event=="PLAYERBANKBAGSLOTS_CHANGED" or
        event=="BANK_TABS_CHANGED" or event=="PLAYER_ACCOUNT_BANK_TAB_SLOTS_CHANGED" then
        if self.bankOpen then self:Request(event,true,false,false) end
    end
end
function P:Initialize()
    if self.initialized or not (C.Client and C.Client.allowed) then return false end
    self.initialized=true
    local record=C.Storage and C.Storage.character and C.Storage.character.characterContextBank
    local snapshot=field(record,"snapshot")
    if field(record,"schema")==1 and type(snapshot)=="table" and integer(field(snapshot,"at"),0,9007199254740991) then
        local rows=field(snapshot,"rows");local valid=type(rows)=="table";local cloned={}
        if valid then
            for index=1,2049 do
                local row=field(rows,index)
                if row==nil then break end
                if index==2049 or not integer(field(row,"bag"),-20,1024) or not integer(field(row,"slot"),1,256)
                    or not integer(field(row,"itemID"),1) or not integer(field(row,"count"),1,100000000) then valid=false;break end
                cloned[index]=C.Copy(row)
            end
        end
        if valid then self.data.bank={rows=cloned,at=field(snapshot,"at"),revision=0,
            status="CACHED",current=false,source="CHARACTER_BANK"} end
    end
    self.frame=CreateFrame("Frame")
    self.registeredEvents={}
    for _,event in ipairs({"PLAYER_LOGIN","PLAYER_ENTERING_WORLD","PLAYER_LEAVING_WORLD","ZONE_CHANGED_NEW_AREA",
        "ZONE_CHANGED","ZONE_CHANGED_INDOORS","PLAYER_LEVEL_UP","UNIT_FACTION","AUCTION_HOUSE_SHOW","MERCHANT_SHOW",
        "TRADE_SKILL_SHOW","CRAFT_SHOW","SKILL_LINES_CHANGED","TRADE_SKILL_LIST_UPDATE","TRADE_SKILL_DATA_SOURCE_CHANGED",
        "NEW_RECIPE_LEARNED","BANKFRAME_OPENED","BANKFRAME_CLOSED","BAG_UPDATE","BAG_UPDATE_DELAYED",
        "PLAYERBANKSLOTS_CHANGED","PLAYERBANKBAGSLOTS_CHANGED","BANK_TABS_CHANGED","PLAYER_ACCOUNT_BANK_TAB_SLOTS_CHANGED"}) do
        local ok=pcall(self.frame.RegisterEvent,self.frame,event)
        if ok then self.registeredEvents[event]=true end
    end
    self.frame:SetScript("OnEvent",function(_,event,unit)
        if event=="UNIT_FACTION" and unit~="player" then return end
        self:OnEvent(event)
    end)
    self:Metadata(true);self:Request("INITIALIZE",false,true)
    return true
end
C.Public.GetCharacterRevision=function()
    return {revision=P.revision,bagsRevision=P.data.bags.revision,
        bankRevision=P.data.bank.revision,bankOpen=P.bankOpen==true,
        bagsCurrent=P.data.bags.current==true,bankCurrent=P.data.bank.current==true,
        refreshPending=P.pending~=nil or P.active~=nil}
end
-- WealthCraft may suppress its duplicate explicit refresh only for events
-- this exact Core instance successfully registered. Unsupported events keep
-- their independent, guarded fallback rather than silently losing updates.
C.Public.GetCharacterContextEventSupport=function(event)
    return type(event)=='string' and P.initialized==true and
        type(P.registeredEvents)=='table' and P.registeredEvents[event]==true
end
C.Public.GetCharacterSnapshot=function() return P:Snapshot() end
C.Public.RequestCharacterRefresh=function(reason,includeBank,includeProfessions) return P:Request(reason,includeBank,includeProfessions) end
C.Services:Register("CharacterContext",C.addonName,1,{
    GetSnapshot=C.Public.GetCharacterSnapshot,GetRevision=C.Public.GetCharacterRevision,
    RequestRefresh=C.Public.RequestCharacterRefresh})

-- P39-A shared context sampling; no character names or item IDs retained.
-- Retain original return values and do not add native data reads.
local p39Step=P.Step
function P:Step(task)
    local profiler=C.Performance
    local started=profiler and profiler:Begin()
    local result=p39Step(self,task)
    if started then profiler:Finish(task.source=="bank" and "context.bank_slice" or "context.bag_slice",started) end
    return result
end
local p39Professions=P.Professions
function P:Professions(...)
    local profiler=C.Performance
    local started=profiler and profiler:Begin()
    local result=p39Professions(self,...)
    if started then profiler:Finish("context.profession_metadata",started) end
    return result
end
local p39Request=P.Request
function P:Request(...)
    if C.Performance and C.Performance.active then C.Performance:Counter("context.refresh_requests") end
    local before=self.metrics.coalesced or 0
    local result,reason=p39Request(self,...)
    if C.Performance and C.Performance.active and (self.metrics.coalesced or 0)>before then
        C.Performance:Counter("context.refresh_coalesced")
    end
    return result,reason
end
local p39Publish=P.Publish
function P:Publish(...)
    if C.Performance and C.Performance.active then C.Performance:Counter("context.revision_publications") end
    return p39Publish(self,...)
end
