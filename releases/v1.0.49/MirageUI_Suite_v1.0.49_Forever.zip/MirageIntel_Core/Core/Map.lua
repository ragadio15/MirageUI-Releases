local _,C=...
C.Map={transformCache={}}
local M=C.Map
function M:XY(v)
    if not C.Readable(v) then return nil end
    local t=type(v)
    if t~="userdata" and t~="table" then return nil end
    local ok,x,y=pcall(function() return v.x,v.y end)
    if not ok or not C.Number(x) or not C.Number(y) then
        local ok2,method=pcall(function()return v.GetXY end)
        if not ok2 or type(method)~="function" then return nil end
        local good,a,b=pcall(method,v)
        if not good then return nil end
        x,y=a,b
    end
    if C.Number(x) and C.Number(y) then return x,y end
    return nil,nil
end
function M:Valid(mapID,x,y)
    return C.Natural(mapID) and mapID<1000000 and C.Number(x) and C.Number(y) and x>=0 and x<=1 and y>=0 and y<=1
end
function M:RawWorld(mapID,x,y)
    if type(C_Map)~="table" or type(C_Map.GetWorldPosFromMapPos)~="function" then return nil end
    local point={x=x,y=y}
    if type(CreateVector2)=="function" then
        local created,ok=C.Call(CreateVector2,x,y)
        if ok and created~=nil then point=created end
    end
    local ok,c,world=pcall(C_Map.GetWorldPosFromMapPos,mapID,point)
    if not ok or not C.Number(c) or c<0 or c%1~=0 then return nil end
    local wx,wy=self:XY(world)
    if not wx then return nil end
    return {continent=c,x=wx,y=wy,mapID=mapID}
end
function M:MapTransformUsable(mapID)
    local now=C:Now()
    local cached=self.transformCache[mapID]
    if cached and now>=cached.at and now-cached.at<(cached.usable and 60 or 15) then return cached.usable end
    local a=self:RawWorld(mapID,.20,.20)
    local b=self:RawWorld(mapID,.80,.20)
    local c=self:RawWorld(mapID,.20,.80)
    local good=a and b and c and a.continent==b.continent and a.continent==c.continent
    if good then
        local cross=(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x)
        good=C.Number(cross) and math.abs(cross)>.001
    end
    self.transformCache[mapID]={usable=good==true,at=now}
    return good==true
end
function M:World(mapID,x,y)
    if not self:Valid(mapID,x,y) then return nil,"INVALID_COORDINATE" end
    if not self:MapTransformUsable(mapID) then return nil,"WORLD_TRANSFORM_UNVERIFIED" end
    local w=self:RawWorld(mapID,x,y)
    return w,w and "MAP_WORLD_POSITION" or "NO_WORLD_TRANSFORM"
end
function M:Player()
    if type(C_Map)~="table" or type(C_Map.GetBestMapForUnit)~="function" or type(C_Map.GetPlayerMapPosition)~="function" then
        return nil,"PLAYER_MAP_UNAVAILABLE"
    end
    local mapID,ok=C.Call(C_Map.GetBestMapForUnit,"player")
    if not ok or not C.Natural(mapID) then return nil,"PLAYER_MAP_UNAVAILABLE" end
    local point,valid=C.Call(C_Map.GetPlayerMapPosition,mapID,"player")
    if not valid then return nil,"PLAYER_POSITION_UNAVAILABLE" end
    local x,y=self:XY(point)
    if not self:Valid(mapID,x,y) then return nil,"PLAYER_POSITION_UNAVAILABLE" end
    local w,why=self:World(mapID,x,y)
    return {mapID=mapID,x=x,y=y,world=w,worldReason=why},"MAP_POSITION"
end
function M:Measure(player,target)
    if not C.Readable(player) or type(player)~="table" or not C.Readable(target) or type(target)~="table" then
        return nil,"DISTANCE_UNAVAILABLE"
    end
    local a,b=player.world,target.world
    local function valid(world)
        return C.Readable(world) and type(world)=="table" and C.Number(world.continent)
            and world.continent>=0 and world.continent%1==0 and C.Number(world.x) and C.Number(world.y)
    end
    if not valid(a) or not valid(b) then return nil,"DISTANCE_UNAVAILABLE" end
    if a.continent~=b.continent then return nil,"OTHER_WORLD_OR_INSTANCE" end
    local deltaX,deltaY=a.x-b.x,a.y-b.y
    local distance=math.sqrt(deltaX*deltaX+deltaY*deltaY)
    if not C.Number(distance) then return nil,"DISTANCE_UNAVAILABLE" end
    return distance,"SAME_WORLD_STRAIGHT_LINE_YARDS"
end
