local _,C=...
C.Storage={schema=1,readOnly=false,reason="UNINITIALIZED"}
-- Both inputs have passed the bounded storage sanitizer. Equal settings do
-- not create a new revision or wake every subscribed utility.
local function same(a,b)
    if type(a)~=type(b) then return false end
    if type(a)~="table" then return a==b end
    for k,v in pairs(a) do if not same(v,b[k]) then return false end end
    for k in pairs(b) do if a[k]==nil then return false end end
    return true
end
local function newDB()
    return {schemaVersion=1,settings={},modules={},revision=0,sentinel="CORE_V1"}
end
local function newChar()
    return {schemaVersion=1,settings={},revision=0,sentinel="CHAR_V1"}
end
function C.Storage:Initialize()
    -- The originals remain untouched on unsupported schemas or malformed values.
    if MirageIntelCoreDB==nil then MirageIntelCoreDB=newDB() end
    if MirageIntelCoreCharDB==nil then MirageIntelCoreCharDB=newChar() end
    self.account=MirageIntelCoreDB
    self.character=MirageIntelCoreCharDB
    if type(self.account)~="table" or type(self.character)~="table" or
       not C.Readable(self.account) or not C.Readable(self.character) or
       self.account.schemaVersion~=1 or self.character.schemaVersion~=1 or
       type(self.account.settings)~="table" or type(self.account.modules)~="table" or
       type(self.character.settings)~="table" or
       not C.Number(self.account.revision) or not C.Number(self.character.revision) then
        self.readOnly=true;self.reason="SCHEMA_MISMATCH_NO_DESTRUCTIVE_RESET";return
    end
    self.readOnly=false
    self.reason="LOADED_RESTART_VERIFICATION_PENDING"
end
function C.Storage:Get(module,scope)
    if not C.Text(module) or #module>64 or module=="" then return nil,"INVALID_MODULE" end
    if scope~="character" and scope~="account" then return nil,"INVALID_SCOPE" end
    local root=scope=="character" and self.character or self.account
    if not C.Readable(root) or type(root)~="table" or not C.Readable(root.settings) or type(root.settings)~="table" then return nil,"STORAGE_UNAVAILABLE" end
    local value=root.settings[module]
    if not C.Readable(value) then return nil,"INVALID_STORED_PROFILE" end
    if value==nil then value={} end
    if type(value)~="table" then return nil,"INVALID_STORED_PROFILE" end
    local copied,valid=C.Sanitize(value)
    if not valid then return nil,"INVALID_STORED_PROFILE" end
    return copied,self.reason
end
function C.Storage:Set(module,scope,value)
    if self.readOnly then return false,self.reason end
    if not C.Text(module) or #module>64 or module=="" or type(value)~="table" or not C.Readable(value) then
        return false,"INVALID_SETTINGS"
    end
    if scope~="character" and scope~="account" then return false,"INVALID_SCOPE" end
    local copied,valid=C.Sanitize(value)
    if not valid or type(copied)~="table" then return false,"INVALID_OR_OVERSIZED_SETTINGS" end
    local root=scope=="character" and self.character or self.account
    if not C.Readable(root) or type(root)~="table" or not C.Readable(root.settings) or
        type(root.settings)~="table" or not C.Number(root.revision) then return false,"STORAGE_UNAVAILABLE" end
    local prior,priorValid=C.Sanitize(root.settings[module])
    if priorValid and same(prior,copied) then return true,"UNCHANGED" end
    root.settings[module]=copied
    root.revision=math.min(2147483647,root.revision+1)
    if C.Hub then C.Hub:Publish("PROFILE_CHANGED",{module=module,scope=scope,revision=root.revision}) end
    return true,"PENDING_CLIENT_SAVE_ON_RELOAD_OR_LOGOUT"
end
function C.Storage:Diagnostics()
    return {status=self.reason,readOnly=self.readOnly,accountRevision=type(self.account)=="table" and self.account.revision or nil,
        charRevision=type(self.character)=="table" and self.character.revision or nil,
        accountSentinel=type(self.account)=="table" and self.account.sentinel or nil,
        charSentinel=type(self.character)=="table" and self.character.sentinel or nil}
end
