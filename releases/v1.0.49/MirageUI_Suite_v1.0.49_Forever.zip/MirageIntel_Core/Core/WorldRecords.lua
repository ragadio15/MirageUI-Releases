local _,C=...
-- Runtime, indexed records. Persistent observations remain in the owning
-- addon. Staged publication is invisible until commit; public reads are copies.
local W={owners={},prefixes={},revision=0,serial=0,maxOwners=16,maxRecords=4096,queryCache={},cacheOrder={}}
C.WorldRecords=W
local function ownerKey(v) return C.Text(v) and #v>0 and #v<=64 and v:match("^[%w_%-]+$") end
local function prefix(v) return C.Text(v) and #v<=128 and v:match("^([%w_%-]+):[%w_:%-%.]+$") end
local function sourceRev(v) return (C.Number(v) and v>=0) or (C.Text(v) and #v<=96) end
local function data() return {records={},maps={},items={},itemMaps={},count=0} end
-- Only explicit, typed associations enter this index. Object IDs, labels and
-- material names are not item IDs. Sorted buckets make tooltip lookup bounded
-- by the page size; it never walks the full world-record collection on hover.
local itemFields={"materialIDs","questItemIDs","soldItemIDs"}
local function lowerBound(ids,id)
    local lo,hi=1,#ids+1
    while lo<hi do local mid=math.floor((lo+hi)/2)
        if ids[mid] and ids[mid]<id then lo=mid+1 else hi=mid end
    end
    return lo
end
local function indexItem(index,itemID,row,adding)
    local bucket=index[itemID]
    if adding then
        if not bucket then bucket={ids={},rows={}};index[itemID]=bucket end
        if not bucket.rows[row.id] then table.insert(bucket.ids,lowerBound(bucket.ids,row.id),row.id) end
        bucket.rows[row.id]=row
    elseif bucket and bucket.rows[row.id] then
        bucket.rows[row.id]=nil;table.remove(bucket.ids,lowerBound(bucket.ids,row.id))
        if #bucket.ids==0 then index[itemID]=nil end
    end
end
local function itemIndex(d,row,adding)
    if row.hidden then return end
    local seen={}
    for _,field in ipairs(itemFields) do for _,id in ipairs(row[field] or {}) do
        if not seen[id] then
            seen[id]=true
            indexItem(d.items,id,row,adding)
            local map=d.itemMaps[row.mapID]
            if adding and not map then map={};d.itemMaps[row.mapID]=map end
            if map then
                indexItem(map,id,row,adding)
                if not adding and next(map)==nil then d.itemMaps[row.mapID]=nil end
            end
        end
    end end
end
local function cell(row) return math.min(15,math.floor(row.x*16))+16*math.min(15,math.floor(row.y*16)) end
local function unindexMap(d,row)
    local m=d.maps[row.mapID]
    local key=cell(row)
    local bucket=m and m[key]
    if bucket then
        bucket[row.id]=nil
        if next(bucket)==nil then m[key]=nil end
    end
    if m and next(m)==nil then d.maps[row.mapID]=nil end
end
local function insert(d,row)
    local old=d.records[row.id]
    if old then
        unindexMap(d,old)
        itemIndex(d,old,false)
    else d.count=d.count+1 end
    d.records[row.id]=row
    local m=d.maps[row.mapID] or {};d.maps[row.mapID]=m
    local b=m[cell(row)] or {};m[cell(row)]=b;b[row.id]=row
    itemIndex(d,row,true)
end
local function remove(d,id)
    local row=d.records[id];if not row then return false end
    unindexMap(d,row)
    itemIndex(d,row,false)
    d.records[id]=nil;d.count=d.count-1;return true
end
local function getOwner(owner,create)
    if not ownerKey(owner) then return nil,"BAD_OWNER" end
    local o=W.owners[owner]
    if not o and create then
        local n=0;for _ in pairs(W.owners) do n=n+1 end
        if n>=W.maxOwners then return nil,"OWNER_LIMIT" end
        o={data=data(),revision=0,sourceRevision=0,status="SYNC_PENDING",committed=false}
        W.owners[owner]=o
        W.queryCache={};W.cacheOrder={}
    end
    return o,o and "READY" or "NOT_REGISTERED"
end
local function clean(owner,row)
    if not C.Readable(row) or type(row)~="table" then return nil,"INVALID_RECORD" end
    local r,valid=C.Sanitize(row)
    if not valid or type(r)~="table" then return nil,"OVERSIZED_OR_UNREADABLE_RECORD" end
    local p=prefix(r.id)
    if not p or not C.Map:Valid(r.mapID,r.x,r.y) or not C.Text(r.label) or #r.label==0 or #r.label>160
        or r.label:find("[|%c]") or not C.Text(r.kind) or #r.kind==0 or #r.kind>32 then
        return nil,"INVALID_RECORD_IDENTITY"
    end
    if W.prefixes[p] and W.prefixes[p]~=owner then return nil,"NAMESPACE_OWNED_BY_OTHER" end
    if r.world~=nil then
        local a=r.world
        if type(a)~="table" or not C.Number(a.continent) or a.continent<0 or a.continent%1~=0
            or not C.Number(a.x) or not C.Number(a.y) then return nil,"INVALID_WORLD_POSITION" end
    end
    for _,field in ipairs(itemFields) do
        local values=r[field]
        if values~=nil then
            if type(values)~="table" or #values>32 then return nil,"INVALID_ITEM_ASSOCIATIONS" end
            local count,seen=0,{}
            for k,id in pairs(values) do
                count=count+1
                if not C.Natural(k) or k>#values or not C.Natural(id) or id>2147483647 or seen[id] then
                    return nil,"INVALID_ITEM_ASSOCIATIONS"
                end
                seen[id]=true
            end
            if count~=#values then return nil,"INVALID_ITEM_ASSOCIATIONS" end
        end
    end
    r.owner=owner;r.revision=nil;r.sourceRevision=nil
    r.source=r.source or "UNSPECIFIED";r.confidence=r.confidence or "UNKNOWN"
    r.precision=r.precision or "MAP_POINT"
    return r,nil,p
end
local function emit(owner,o,id)
    W.revision=W.revision+1;o.revision=W.revision
    W.queryCache={};W.cacheOrder={}
    C.Hub:Publish("WORLD_RECORDS_CHANGED",{owner=owner,revision=W.revision,sourceRevision=o.sourceRevision,id=id,status=o.status})
end
local function copy(row,o)
    local result=C.Copy(row);result.revision=o.revision;result.sourceRevision=o.sourceRevision
    return result
end
local function writable() return C.Client and C.Client.allowed==true end
local A={apiVersion=1}
function A.BeginSnapshot(owner,revision)
    if not writable() then return nil,"UNSUPPORTED_CLIENT" end
    if revision~=nil and not sourceRev(revision) then return nil,"BAD_REVISION" end
    local o,why=getOwner(owner,true);if not o then return nil,why end
    W.serial=W.serial+1;o.pending={token=W.serial,data=data(),prefixes={},sourceRevision=revision or 0}
    return W.serial,"SNAPSHOT_STARTED"
end
function A.PutBatch(owner,token,rows)
    if not writable() then return false,"UNSUPPORTED_CLIENT" end
    local o=getOwner(owner);local staged=o and o.pending
    if not staged or token~=staged.token then return false,"STALE_SNAPSHOT" end
    if not C.Readable(rows) or type(rows)~="table" or #rows>64 then return false,"BAD_BATCH" end
    local validated,newIDs={},{}
    local count=0
    for k in pairs(rows) do
        if not C.Natural(k) or k>#rows then return false,"BAD_BATCH" end
        count=count+1
    end
    if count~=#rows then return false,"BAD_BATCH" end
    for i,row in ipairs(rows) do
        local r,why,p=clean(owner,row);if not r then return false,why end
        validated[i]={row=r,prefix=p};newIDs[r.id]=true
    end
    local extra=0;for id in pairs(newIDs) do if not staged.data.records[id] then extra=extra+1 end end
    if staged.data.count+extra>W.maxRecords then return false,"RECORD_LIMIT" end
    for _,v in ipairs(validated) do staged.prefixes[v.prefix]=true;insert(staged.data,v.row) end
    return true,"BATCH_STAGED"
end
local function discardStage(owner,o)
    o.pending=nil
    if not o.committed and o.status=="SYNC_PENDING" and o.revision==0 then
        W.owners[owner]=nil
        W.queryCache={};W.cacheOrder={}
    end
end
function A.CommitSnapshot(owner,token)
    if not writable() then return false,"UNSUPPORTED_CLIENT" end
    local o=getOwner(owner);local s=o and o.pending
    if not s or token~=s.token then return false,"STALE_SNAPSHOT" end
    -- A staged batch has no public ownership until the entire snapshot commits.
    for p in pairs(s.prefixes) do
        if W.prefixes[p] and W.prefixes[p]~=owner then
            discardStage(owner,o)
            return false,"NAMESPACE_OWNED_BY_OTHER"
        end
    end
    for p in pairs(s.prefixes) do W.prefixes[p]=owner end
    o.data=s.data;o.sourceRevision=s.sourceRevision;o.pending=nil;o.committed=true;o.status="READY"
    emit(owner,o);return true,"COMMITTED"
end
function A.CancelSnapshot(owner,token)
    local o=getOwner(owner)
    if not o or not o.pending or o.pending.token~=token then return false end
    discardStage(owner,o);return true
end
function A.Upsert(owner,row,revision)
    if not writable() then return false,"UNSUPPORTED_CLIENT" end
    if revision~=nil and not sourceRev(revision) then return false,"BAD_REVISION" end
    local r,why,p=clean(owner,row);if not r then return false,why end
    local o,why=getOwner(owner,true);if not o then return false,why end
    if o.data.count>=W.maxRecords and not o.data.records[r.id] then return false,"RECORD_LIMIT" end
    W.prefixes[p]=owner;o.pending=nil
    insert(o.data,r);o.sourceRevision=revision or o.sourceRevision;o.committed=true;o.status="READY"
    emit(owner,o,r.id);return true,"UPDATED"
end
function A.Remove(owner,id,revision)
    if not writable() then return false,"UNSUPPORTED_CLIENT" end
    if revision~=nil and not sourceRev(revision) then return false,"BAD_REVISION" end
    local o,why=getOwner(owner);if not o then return false,why end
    if not prefix(id) then return false,"BAD_ID" end
    if not remove(o.data,id) then return false,"NOT_FOUND" end
    o.pending=nil
    o.sourceRevision=revision or o.sourceRevision;emit(owner,o,id);return true,"REMOVED"
end
function A.ClearOwner(owner)
    local o=getOwner(owner);if not o then return false end
    W.owners[owner]=nil
    for p,id in pairs(W.prefixes) do if id==owner then W.prefixes[p]=nil end end
    emit(owner,o);return true
end
function A.SetOwnerState(owner,state,reason)
    if not writable() then return false,"UNSUPPORTED_CLIENT" end
    if state~="READY" and state~="DISABLED" and state~="UNAVAILABLE" then return false,"BAD_STATE" end
    local o,why=getOwner(owner,true);if not o then return false,why end
    local nextReason=C.Text(reason) and reason or nil
    -- Reasserting a provider's unchanged state must not evict every indexed
    -- query or invalidate pagination in unrelated map/tooltip consumers.
    if o.status==state and o.reason==nextReason then return true,"UNCHANGED" end
    o.status=state;o.reason=nextReason;emit(owner,o);return true
end
function A.Get(id)
    if not writable() then return nil,"UNSUPPORTED_CLIENT" end
    local p=prefix(id);local o=p and W.owners[W.prefixes[p]]
    if not o or o.status~="READY" then return nil,o and o.status or "NOT_REGISTERED" end
    local row=o and o.data.records[id]
    return row and copy(row,o) or nil
end
local function normalize(q)
    if not C.Readable(q) or type(q)~="table" then return nil,"INVALID_QUERY" end
    local safe,valid=C.Sanitize(q)
    if not valid then return nil,"INVALID_QUERY" end
    q=safe
    if not C.Natural(q.mapID) then return nil,"INVALID_QUERY" end
    if q.owner~=nil and not ownerKey(q.owner) then return nil,"INVALID_QUERY" end
    if q.kind~=nil and not C.Text(q.kind) then return nil,"INVALID_QUERY" end
    if q.category~=nil and not C.Text(q.category) then return nil,"INVALID_QUERY" end
    local function phrase(v,max)
        return C.Text(v) and #v<=max and not v:find("[%c|]")
    end
    if q.layer~=nil and not phrase(q.layer,32) then return nil,"INVALID_LAYER" end
    local layers,layerNames
    if q.layers~=nil then
        if type(q.layers)~="table" or #q.layers>8 then return nil,"INVALID_LAYERS" end
        layers={};layerNames={}
        local count=0
        for k,v in pairs(q.layers) do
            count=count+1
            if not C.Natural(k) or k>#q.layers or not phrase(v,32) or #v==0 or layers[v] then return nil,"INVALID_LAYERS" end
            layers[v]=true;layerNames[#layerNames+1]=v
        end
        if count~=#q.layers then return nil,"INVALID_LAYERS" end
        table.sort(layerNames)
    end
    if q.search~=nil and not phrase(q.search,96) then return nil,"INVALID_SEARCH" end
    if q.material~=nil and not phrase(q.material,96) then return nil,"INVALID_MATERIAL" end
    if q.availability~=nil and q.availability~="all" and q.availability~="usable" and q.availability~="unknown" then return nil,"INVALID_AVAILABILITY" end
    if q.faction~=nil and q.faction~="Alliance" and q.faction~="Horde" then return nil,"INVALID_FACTION" end
    if q.classID~=nil and not C.Natural(q.classID) then return nil,"INVALID_CLASS" end
    if q.professionID~=nil and not C.Natural(q.professionID) then return nil,"INVALID_PROFESSION" end
    if q.minSkill~=nil and (not C.Number(q.minSkill) or q.minSkill<0 or q.minSkill%1~=0 or q.minSkill>10000) then return nil,"INVALID_SKILL" end
    if q.visibility~=nil and (not C.Text(q.visibility) or (q.visibility~="world" and q.visibility~="minimap")) then return nil,"INVALID_QUERY" end
    local b=q.bounds or {left=0,right=1,top=0,bottom=1}
    if not C.Readable(b) or type(b)~="table" or not C.Map:Valid(q.mapID,b.left,b.top)
        or not C.Map:Valid(q.mapID,b.right,b.bottom) or b.left>b.right or b.top>b.bottom then return nil,"INVALID_BOUNDS" end
    local limit=C.Natural(q.limit) and math.min(q.limit,64) or 64
    local layerSignature="*"
    if layerNames then
        local encoded={}
        for i,name in ipairs(layerNames) do encoded[i]=#name..":"..name end
        layerSignature=table.concat(encoded)
    end
    local parts={q.mapID,q.owner or "",q.kind or "",q.category or "",b.left,b.right,b.top,b.bottom,tostring(q.includeHidden==true),q.visibility or "",
        q.layer or "",layerSignature,q.search or "",q.material or "",q.availability or "all",q.faction or "",q.classID or "",q.professionID or "",q.minSkill or ""}
    -- Length prefixes prevent a slash in a search term from colliding with a
    -- different query. A cursor is valid only for the same complete filter.
    for i,v in ipairs(parts) do local s=tostring(v);parts[i]=#s..":"..s end
    local signature=table.concat(parts)
    if q.cursor~=nil and (not C.Readable(q.cursor) or type(q.cursor)~="table" or q.cursor.revision~=W.revision
        or q.cursor.signature~=signature or not C.Text(q.cursor.after)) then return nil,"STALE_CURSOR" end
    return {mapID=q.mapID,owner=q.owner,kind=q.kind,category=q.category,bounds=b,limit=limit,
        signature=signature,after=q.cursor and q.cursor.after,includeHidden=q.includeHidden==true,visibility=q.visibility,
        layer=q.layer,layers=layers,search=q.search and q.search:lower(),material=q.material and q.material:lower(),
        availability=q.availability,faction=q.faction,classID=q.classID,professionID=q.professionID,minSkill=q.minSkill}
end
local function recordLayer(r)
    if C.Text(r.layer) then return r.layer end
    if r.kind=="gather" then return "resources" end
    if r.kind=="quest" then return "quests" end
    if r.kind=="service" or r.kind=="flight" then return "services" end
    if r.kind=="poi" then return "pois" end
    return r.kind
end
local function contains(value,term)
    return C.Text(value) and value:lower():find(term,1,true)~=nil
end
local function matches(r,q)
    local layer=recordLayer(r)
    if (q.layer and layer~=q.layer) or (q.layers and not q.layers[layer]) then return false end
    if q.search and q.search~="" and not (contains(r.label,q.search) or contains(r.category,q.search)
        or contains(r.serviceRoles,q.search) or contains(r.materialText,q.search) or contains(r.details,q.search)
        or contains(r.sourceLabel,q.search)) then return false end
    if q.material and q.material~="" and not (contains(r.materialText,q.material) or contains(r.label,q.material)) then return false end
    if q.availability=="usable" and r.availability~="AVAILABLE" and r.availability~="KNOWN" and r.availability~="ACCEPTED" then return false end
    if q.availability=="unknown" and r.availability~=nil and r.availability~="UNKNOWN" then return false end
    if q.faction and r.faction and r.faction~="Any" and r.faction~="Neutral" and r.faction~=q.faction then return false end
    if q.classID and r.classID and r.classID~=q.classID then return false end
    if q.professionID and r.professionID and r.professionID~=q.professionID then return false end
    if q.minSkill and q.professionID==r.professionID and C.Number(r.requiredSkill) and r.requiredSkill>q.minSkill then return false end
    return true
end
function A.Query(query)
    local q,why=normalize(query)
    if not q then return {records={},revision=W.revision,status=why} end
    if not writable() then return {records={},revision=W.revision,status="UNSUPPORTED_CLIENT"} end
    local cached=W.queryCache[q.signature]
    local rows,ids,anyOwner,pending,blocked={}, {},false,false,nil
    local total,examined=0,0
    local b=q.bounds
    if cached then
        rows,ids,anyOwner,pending,blocked=cached.rows,cached.ids,cached.anyOwner,cached.pending,cached.blocked
        total=#ids
    else
    for owner,o in pairs(W.owners) do
        if not q.owner or q.owner==owner then
            anyOwner=true;pending=pending or not o.committed
            if o.status=="READY" then
                local m=o.data.maps[q.mapID]
                if m then
                    for y=math.min(15,math.floor(b.top*16)),math.min(15,math.floor(b.bottom*16)) do
                        for x=math.min(15,math.floor(b.left*16)),math.min(15,math.floor(b.right*16)) do
                            for id,r in pairs(m[x+y*16] or {}) do
                                examined=examined+1
                                if (not q.kind or r.kind==q.kind)
                                    and (not q.category or r.category==q.category) and (q.includeHidden or not r.hidden)
                                    and (q.visibility~="world" or r.showWorld~=false)
                                    and (q.visibility~="minimap" or r.showMinimap~=false)
                                    and r.x>=b.left and r.x<=b.right and r.y>=b.top and r.y<=b.bottom and matches(r,q) then
                                    total=total+1
                                    rows[id]={row=r,owner=o};ids[#ids+1]=id
                                end
                            end
                        end
                    end
                end
            else blocked=o.status end
        end
    end
    table.sort(ids)
    if #W.cacheOrder>=8 then W.queryCache[table.remove(W.cacheOrder,1)]=nil end
    W.queryCache[q.signature]={rows=rows,ids=ids,anyOwner=anyOwner,pending=pending,blocked=blocked}
    W.cacheOrder[#W.cacheOrder+1]=q.signature
    end
    -- All pages reuse one filtered/sorted index for a stable revision. This
    -- avoids rescanning a dense resource layer for each 64-record UI page.
    local first=1
    if q.after then
        local lo,hi=1,#ids+1
        while lo<hi do
            local mid=math.floor((lo+hi)/2)
            if ids[mid] and ids[mid]<=q.after then lo=mid+1 else hi=mid end
        end
        first=lo
    end
    local last=math.min(#ids,first+q.limit-1)
    local result={records={},revision=W.revision,status="READY",totalMatched=total,
        remainingMatched=math.max(0,#ids-first+1),examined=examined,cacheHit=cached~=nil}
    for i=first,last do local v=rows[ids[i]];result.records[#result.records+1]=copy(v.row,v.owner) end
    if last<#ids then result.nextCursor={revision=W.revision,signature=q.signature,after=ids[last]} end
    if #result.records==0 then result.status=not anyOwner and "NOT_REGISTERED" or pending and "SYNC_PENDING" or blocked or "READY_EMPTY" end
    return result
end
function A.GetStatus()
    local result={revision=W.revision,count=0,pending=0,owners={},perOwnerLimit=W.maxRecords}
    for id,o in pairs(W.owners) do
        result.count=result.count+o.data.count
        if o.pending then result.pending=result.pending+1 end
        result.owners[id]={count=o.data.count,status=o.status,reason=o.reason,revision=o.revision,sourceRevision=o.sourceRevision,pending=o.pending~=nil}
    end
    return result
end
-- Additive API v1 query. A cursor is valid only for the same item, map and
-- committed world revision. Results are historical/source records, not spawns.
function A.QueryItem(itemID,options)
    local function empty(why) return {records={},revision=W.revision,status=why,totalMatched=0} end
    if not writable() then return empty("UNSUPPORTED_CLIENT") end
    if not C.Natural(itemID) or itemID>2147483647 then return empty("INVALID_ITEM") end
    options=options or {}
    if not C.Readable(options) or type(options)~="table" then return empty("INVALID_QUERY") end
    local q,valid=C.Sanitize(options)
    if not valid then return empty("INVALID_QUERY") end
    if q.mapID~=nil and not C.Natural(q.mapID) then return empty("INVALID_MAP") end
    local signature=tostring(itemID)..":"..tostring(q.mapID or "all")
    local after=type(q.cursor)=="table" and q.cursor.after
    if q.cursor~=nil and (type(q.cursor)~="table" or q.cursor.revision~=W.revision or
        q.cursor.signature~=signature or not C.Text(after)) then return empty("STALE_CURSOR") end
    local limit=C.Natural(q.limit) and math.min(64,q.limit) or 16
    local streams,total,pending,registered={},0,false,false
    for _,o in pairs(W.owners) do
        registered=true;pending=pending or not o.committed
        if o.status=="READY" then
            local index=q.mapID and o.data.itemMaps[q.mapID] or (not q.mapID and o.data.items)
            local b=index and index[itemID]
            if b then
                total=total+#b.ids
                local n=after and lowerBound(b.ids,after) or 1
                if b.ids[n]==after then n=n+1 end
                streams[#streams+1]={bucket=b,owner=o,index=n}
            end
        end
    end
    local result={records={},revision=W.revision,status="READY",totalMatched=total,
        coverage="EXPLICIT_RECORDED_ITEM_ASSOCIATIONS",examined=0}
    for _=1,limit+1 do
        local selected,id
        for _,s in ipairs(streams) do
            local candidate=s.bucket.ids[s.index]
            if candidate and (not id or candidate<id) then selected,id=s,candidate end
        end
        if not selected then break end
        if #result.records==limit then
            result.nextCursor={revision=W.revision,signature=signature,after=result.records[limit].id}
            break
        end
        result.examined=result.examined+1
        result.records[#result.records+1]=copy(selected.bucket.rows[id],selected.owner)
        selected.index=selected.index+1
    end
    if #result.records==0 then result.status=not registered and "NOT_REGISTERED" or pending and "SYNC_PENDING" or "READY_EMPTY" end
    return result
end
C.Services:Register("WorldRecords","MirageIntel_Core",1,A)
