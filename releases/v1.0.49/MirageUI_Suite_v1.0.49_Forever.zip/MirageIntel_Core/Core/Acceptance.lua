local _,C=...
-- Acceptance is a bounded per-character journal, opened explicitly by the
-- player. Reading status never creates or resets saved data. A recorded PASS
-- is a user observation, not automatic native qualification or stable promotion.
local A={apiVersion=1}
C.Acceptance=A
local profileKey="releaseAcceptance"
local cases={};for _,entry in ipairs(C.AcceptanceScenarios) do cases[entry.id]=entry end
local function text(value,limit)
    return C.Readable(value) and type(value)=="string" and #value<=(limit or 1024)
end
local function number(value) return C.Number(value) and value>=0 and value%1==0 end
local function counter(value) return number(value) and value<=2147483647 end
local function scalar(value,limit)
    return text(value,limit) and not value:find("[|\r\n%z]")
end
local function now()
    local value=C.Call(GetServerTime)
    return number(value) and value or 0
end
local function clean(value,limit)
    if not text(value,4096) then return "unknown" end
    return C.TextBytes(value:gsub("[|\r\n%z]"," "),limit or 128) or "unknown"
end
local function hash(value)
    -- A compact context-change marker, not an installed-byte attestation.
    local n=5381
    for i=1,#value do n=(n*33+value:byte(i))%4294967296 end
    return string.format("%08x",n)
end
local function dimensions()
    local w=C.Call(UIParent and UIParent.GetWidth,UIParent)
    local h=C.Call(UIParent and UIParent.GetHeight,UIParent)
    local scale=C.Call(UIParent and UIParent.GetEffectiveScale,UIParent)
    return C.Number(w) and C.Number(h) and C.Number(scale) and
        string.format("%.0fx%.0f @ %.3f",w,h,scale) or "unavailable"
end
local function validateRun(run)
    if type(run)~="table" or run.schema~=1 or not scalar(run.releaseID,80) or
        not scalar(run.payloadSHA256,64) or not scalar(run.contextKey,256) or
        not scalar(run.build,32) or not counter(run.sequence) or run.sequence==0 or not counter(run.revision) or
        not number(run.startedAt) or not number(run.updatedAt) or
        type(run.environment)~="table" or type(run.results)~="table" then return false end
    local allowed={schema=true,releaseID=true,payloadSHA256=true,contextKey=true,build=true,
        sequence=true,revision=true,startedAt=true,updatedAt=true,environment=true,results=true}
    for k in pairs(run) do if not allowed[k] then return false end end
    local fields={patch=true,build=true,interface=true,locale=true,class=true,faction=true,
        addons=true,addonCount=true,modules=true,viewport=true}
    for k,v in pairs(run.environment) do
        if not fields[k] or not scalar(v,1024) then return false end
    end
    for k in pairs(fields) do if run.environment[k]==nil then return false end end
    for id,row in pairs(run.results) do
        if not cases[id] or type(row)~="table" or
            (row.status~="PASS" and row.status~="FAIL" and row.status~="NOT_RUN") or
            not scalar(row.note,640) or not number(row.recordedAt) or
            not scalar(row.viewport,80) then return false end
        for k in pairs(row) do if k~="status" and k~="note" and k~="recordedAt" and k~="viewport" then return false end end
        if row.status=="FAIL" and not row.note:find("%S") then return false end
        if row.status=="PASS" and cases[id].noteRequired and not row.note:find("%S") then return false end
    end
    return true
end
function A:Load()
    local profile,why=C.Storage:Get(profileKey,"character")
    if not profile then return nil,why or "Acceptance storage unavailable." end
    if next(profile)==nil then return {schema=1},"EMPTY" end
    if profile.schema~=1 then return nil,"Unknown acceptance schema; existing data retained." end
    for k in pairs(profile) do if k~="schema" and k~="current" and k~="previous" then return nil,"Invalid acceptance data retained." end end
    for _,key in ipairs({"current","previous"}) do
        if profile[key]~=nil and not validateRun(profile[key]) then return nil,"Invalid acceptance data retained." end
    end
    return profile,"READY"
end
function A:Context()
    local locale=C.Call(GetLocale)
    local _,classOK,class=C.Call(UnitClass,"player")
    local faction=C.Call(UnitFactionGroup,"player")
    if not scalar(locale,16) or not classOK or not scalar(class,32) or not scalar(faction,32) then
        return nil,"Character and locale context unreadable."
    end
    local api=type(C_AddOns)=="table" and C_AddOns or {}
    local total,ok=C.Call(api.GetNumAddOns)
    if not ok or not number(total) or total>512 then return nil,"Addon inventory unavailable or over limit." end
    local addons={}
    for index=1,total do
        local name,known=C.Call(api.GetAddOnInfo,index)
        if not known or not scalar(name,128) or name=="" then return nil,"Addon inventory unreadable." end
        local loaded,readable,finished=C.Call(api.IsAddOnLoaded,name)
        if not readable or type(loaded)~="boolean" then return nil,"Addon load state unreadable." end
        if loaded and finished==false then return nil,"An addon is still loading; retry after it finishes." end
        if loaded then
            local version,readVersion=C.Call(api.GetAddOnMetadata,name,"Version")
            if not readVersion or (version~=nil and not scalar(version,128)) then return nil,"Addon version unreadable." end
            addons[#addons+1]=name.."="..(version or "unversioned")
        end
    end
    local finalCount=C.Call(api.GetNumAddOns)
    if finalCount~=total then return nil,"Addon inventory changed; retry." end
    table.sort(addons)
    local modules={}
    for _,key in ipairs({"MapAddon","Navigate","Gather","Insight"}) do
        local service=C.Services:Get(key,1)
        modules[#modules+1]=key.."="..(service and "loaded" or "absent")
    end
    local env={patch=clean(C.Client.patch,32),build=clean(C.Client.build,32),interface=tostring(C.Client.interface),
        locale=clean(locale,16),class=classOK and clean(class,32) or "unknown",faction=clean(faction,32),
        addons=hash(table.concat(addons,"\n")),addonCount=tostring(#addons),modules=table.concat(modules,","),viewport=dimensions()}
    local key=table.concat({env.patch,env.build,env.interface,env.locale,env.class,env.faction,env.addons,env.modules},"/")
    return env,key
end
function A:Writable()
    if not C.Client.allowed then return false,"This client build is not supported." end
    if C.CombatState()~=false then return false,"Record results after combat." end
    if C.Storage.readOnly then return false,"Settings are read-only; existing results are retained." end
    return true
end
local function token(profile)
    local run=profile and profile.current
    if not run then return "EMPTY" end
    return table.concat({run.sequence,run.revision,run.releaseID,run.payloadSHA256,run.contextKey},"/")
end
function A:Start()
    local writable,why=self:Writable();if not writable then return false,why end
    local profile;profile,why=self:Load();if not profile then return false,why end
    local before=token(profile)
    local env,key=self:Context();if not env then return false,key end
    local release=C.Release or {}
    if not scalar(release.id,80) or not scalar(release.payloadSHA256,64) or
        #release.payloadSHA256~=64 or not release.payloadSHA256:match("^[0-9a-f]+$") then
        return false,"This package has no frozen release identity."
    end
    local started=now()
    local previous=profile.current or profile.previous
    if previous and previous.sequence>=2147483647 then return false,"Acceptance history reached its counter limit; existing results retained." end
    local run={schema=1,releaseID=release.id,payloadSHA256=release.payloadSHA256,contextKey=key,
        build=env.build,sequence=(previous and previous.sequence or 0)+1,revision=0,
        startedAt=started,updatedAt=started,environment=env,results={}}
    -- Recheck after callback-capable native observations before the only write.
    writable,why=self:Writable();if not writable then return false,why end
    local finalEnv,finalKey=self:Context()
    if not finalEnv or finalKey~=key or C.Release.id~=run.releaseID or C.Release.payloadSHA256~=run.payloadSHA256 then
        return false,"The test configuration changed. Refresh before starting."
    end
    writable,why=self:Writable();if not writable then return false,why end
    local latest=self:Load()
    if not latest or token(latest)~=before then return false,"The saved check changed. Refresh before starting." end
    local accepted;accepted,why=C.Storage:Set(profileKey,"character",{schema=1,current=run,previous=previous})
    return accepted,accepted and "Check started. Results save with normal reload or logout." or why
end
function A:GetStatus()
    local profile,why=self:Load()
    local out={schemaVersion=1,state="NOT_STARTED",reportedBy="PLAYER",qualification="PENDING_REVIEW",
        packageID=C.Release and C.Release.id or "UNKNOWN",payloadSHA256=C.Release and C.Release.payloadSHA256 or "UNKNOWN",
        evidenceMeaning="PACKAGE_METADATA_NOT_INSTALLED_BYTE_ATTESTATION",passed=0,failed=0,pending=#C.AcceptanceScenarios,
        saveState="CLIENT_SAVES_ON_RELOAD_OR_LOGOUT",results={}}
    if not profile then out.state="STORAGE_UNAVAILABLE";out.reason=why;return out end
    local run=profile.current
    if profile.previous then out.previous={releaseID=profile.previous.releaseID,build=profile.previous.build,
        sequence=profile.previous.sequence,updatedAt=profile.previous.updatedAt} end
    if not run then return out end
    out.runID=run.sequence;out.runRevision=run.revision;out.startedAt=run.startedAt;out.updatedAt=run.updatedAt
    out.recordedPackageID=run.releaseID;out.recordedPayloadSHA256=run.payloadSHA256
    out.environment=C.Copy(run.environment);out.results=C.Copy(run.results)
    for _,row in pairs(run.results) do
        if row.status=="PASS" then out.passed=out.passed+1
        elseif row.status=="FAIL" then out.failed=out.failed+1 end
    end
    out.pending=#C.AcceptanceScenarios-out.passed-out.failed
    local env,key=self:Context()
    if not env then out.state="CONTEXT_UNAVAILABLE";out.reason=key;return out end
    if run.releaseID~=out.packageID or run.payloadSHA256~=out.payloadSHA256 or run.contextKey~=key then
        out.state="CONTEXT_CHANGED";out.reason="Start a new check for this package, client or addon combination.";return out
    end
    if not C.Client.allowed then out.state="UNSUPPORTED_CLIENT";return out end
    if C.Storage.readOnly then out.state="STORAGE_READ_ONLY";return out end
    out.runtimeErrors=C.Number(C.state.errors) and C.state.errors or 0
    out.taskErrors=C.Scheduler and C.Scheduler.metrics and C.Scheduler.metrics.failed or 0
    if out.failed>0 then out.state="ISSUES_RECORDED"
    elseif out.runtimeErrors>0 or out.taskErrors>0 then out.state="RUNTIME_REVIEW_NEEDED"
    elseif out.pending==0 then out.state="USER_REPORTED_COMPLETE"
    else out.state="IN_PROGRESS" end
    return out
end
function A:Record(id,status,note,expectedSequence,expectedRevision)
    local writable,why=self:Writable();if not writable then return false,why end
    local entry=cases[id]
    if not entry or (status~="PASS" and status~="FAIL" and status~="NOT_RUN") then return false,"Invalid check result." end
    note=note or ""
    if not text(note,640) or C.TextClip(note,160)~=note then return false,"Keep the note within 160 characters." end
    note=note:gsub("[|\r\n%z]"," "):match("^%s*(.-)%s*$")
    if (status=="FAIL" or (status=="PASS" and entry.noteRequired)) and not note:find("%S") then
        return false,"Add a short observation or evidence reference before recording this result."
    end
    local profile;profile,why=self:Load();if not profile then return false,why end
    local run=profile.current
    if not run then return false,"Start a check first." end
    if run.revision>=2147483647 then return false,"This check reached its revision limit; start a new check." end
    if expectedSequence~=run.sequence or expectedRevision~=run.revision then return false,"The check changed. Refresh before recording." end
    local before=token(profile)
    local snapshot=self:GetStatus()
    if snapshot.state=="CONTEXT_CHANGED" or snapshot.state=="CONTEXT_UNAVAILABLE" or
        snapshot.state=="UNSUPPORTED_CLIENT" or snapshot.state=="STORAGE_UNAVAILABLE" or
        snapshot.state=="STORAGE_READ_ONLY" then return false,snapshot.reason or snapshot.state end
    if status=="PASS" then
        if entry.service=="suite" then
            for _,key in ipairs({"MapAddon","Navigate","Gather","Insight"}) do
                if not C.Services:Get(key,1) then return false,"Load the complete utility suite before passing this check." end
            end
        elseif not C.Services:Get(entry.service,1) then return false,"The utility needed for this check is not loaded." end
    end
    local recorded=now()
    run.results[id]={status=status,note=note,recordedAt=recorded,viewport=dimensions()}
    run.updatedAt=recorded;run.revision=run.revision+1
    writable,why=self:Writable();if not writable then return false,why end
    local finalEnv,finalKey=self:Context()
    if not finalEnv or finalKey~=run.contextKey or C.Release.id~=run.releaseID or C.Release.payloadSHA256~=run.payloadSHA256 then
        return false,"The test configuration changed. Refresh before recording."
    end
    writable,why=self:Writable();if not writable then return false,why end
    local latest=self:Load()
    if not latest or token(latest)~=before then
        return false,"The saved check changed. Refresh before recording."
    end
    local accepted;accepted,why=C.Storage:Set(profileKey,"character",profile)
    return accepted,accepted and "Observation recorded. Release sign-off remains a separate review." or why
end
function C.Public.GetAcceptanceStatus() return A:GetStatus() end
