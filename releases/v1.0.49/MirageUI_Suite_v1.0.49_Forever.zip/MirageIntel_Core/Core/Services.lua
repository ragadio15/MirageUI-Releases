local _,C=...
C.Services={records={}}
function C.Services:Register(id,owner,version,service)
    if type(id)~="string" or #id>64 or not id:match("^[%w_]+$") or
       type(owner)~="string" or not C.Natural(version) or type(service)~="table" then return false,"BAD_SERVICE" end
    local existing=self.records[id]
    if existing and existing.owner~=owner then return false,"SERVICE_OWNED_BY_OTHER" end
    self.records[id]={owner=owner,version=version,service=service}
    local launcher=C.Commands
    if launcher and launcher.frame and launcher.frame:IsShown() and not pcall(launcher.Refresh,launcher) then
        C:Fault("LAUNCHER_REFRESH_FAILED")
    end
    return true
end
function C.Services:Get(id,minVersion)
    if not C.Text(id) or #id>64 or (minVersion~=nil and not C.Natural(minVersion)) then
        return nil,"BAD_SERVICE_QUERY"
    end
    local record=self.records[id]
    if not record or record.version<(minVersion or 1) then return nil,"SERVICE_UNAVAILABLE" end
    return record.service,"AVAILABLE"
end
C.Modules={records={}}
function C.Modules:Register(id,version,capabilities)
    if type(id)~="string" or #id>64 or not id:match("^MirageIntel_[%w_]+$")
        or not C.Natural(version) or type(capabilities)~="table" then return false,"BAD_MODULE" end
    local existing=self.records[id]
    if existing and version<existing.version then return false,"VERSION_DOWNGRADE" end
    self.records[id]={version=version,capabilities=C.Copy(capabilities),state="PRESENT_NATIVE_UNTESTED"}
    return true
end
C.Public={apiVersion=1}
-- Expose only stable utility methods; no MirageUI private-module access.
C.Public.Map={}
function C.Public.Map:Valid(...) return C.Map:Valid(...) end
function C.Public.Map:XY(...) return C.Map:XY(...) end
function C.Public.Map:World(...) return C.Map:World(...) end
function C.Public.Map:Player(...) return C.Map:Player(...) end
function C.Public.Map:Measure(...) return C.Map:Measure(...) end
function C.Public.Copy(value) return C.Copy(value) end
function C.Public.TextClip(value,characters) return C.TextClip(value,characters) end
function C.Public.TextBytes(value,bytes) return C.TextBytes(value,bytes) end
local A=C.Public
function A.RegisterModule(id,version,capabilities) return C.Modules:Register(id,version,capabilities) end
function A.GetModules() return C.Copy(C.Modules.records) end
function A.GetCapabilities() return C.Copy({version=C.version,apiVersion=1,client=C.Client,storage=C.Storage:Diagnostics(),state=C.state}) end
function A.HasAPI(name) return C.Client:HasAPI(name) end
function A.GetProfile(module,scope) return C.Storage:Get(module,scope) end
function A.SaveProfile(module,scope,value) return C.Storage:Set(module,scope,value) end
function A.Subscribe(event,owner,fn) return C.Hub:Subscribe(event,owner,fn) end
function A.Unsubscribe(event,owner) return C.Hub:Unsubscribe(event,owner) end
function A.Publish(event,payload) return C.Hub:Publish(event,payload) end
function A.RegisterService(id,owner,version,service) return C.Services:Register(id,owner,version,service) end
function A.GetService(id,minVersion) return C.Services:Get(id,minVersion) end
function A.GetPlayerPosition() return C.Copy(C.Map:Player()) end
function A.Open() return C.Commands:Open() end
function A.GetUtilityStatus() return C.Commands:ModuleStatus() end
MirageIntelCoreAPI=A
