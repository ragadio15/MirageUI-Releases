local _,C=...
local U=C.Chrome
local P={selected=1}
C.AcceptancePanel=P
local descriptions={NOT_STARTED="Start when you are ready to check this package.",
    IN_PROGRESS="Record what you observed after each check.",ISSUES_RECORDED="An issue is recorded. Include the report with your findings.",
    RUNTIME_REVIEW_NEEDED="Runtime errors need review before release sign-off.",
    USER_REPORTED_COMPLETE="Your checks are recorded and ready for release review.",
    CONTEXT_CHANGED="The package, client or addon combination changed. Start a new check.",
    CONTEXT_UNAVAILABLE="The current test configuration could not be read.",
    STORAGE_UNAVAILABLE="Existing results could not be read and have been retained.",
    STORAGE_READ_ONLY="Settings are read-only. Existing results are retained.",
    UNSUPPORTED_CLIENT="This client build is not supported."}
local function label(parent,value,x,y,width,role)
    local t=parent:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    t:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y);t:SetWidth(width)
    t:SetJustifyH("LEFT");t:SetJustifyV("TOP");t:SetText(value)
    U.Font(t,role or "body");U.Tint(t,"text")
    return t
end
local function enabled(button,value)
    if value then button:Enable() else button:Disable() end
end
function P:Refresh(preserveNote)
    if not self.frame then return end
    local s=C.Acceptance:GetStatus();self.snapshot=s
    local locked=C.CombatState()~=false
    local writable=C.Acceptance:Writable()
    local invalid=s.state=="CONTEXT_CHANGED" or s.state=="CONTEXT_UNAVAILABLE" or s.state=="STORAGE_UNAVAILABLE" or
        s.state=="STORAGE_READ_ONLY" or s.state=="UNSUPPORTED_CLIENT"
    self.progress:SetText(string.format("%d passed  ·  %d issues  ·  %d not run",s.passed,s.failed,s.pending))
    self.state:SetText(descriptions[s.state] or s.state)
    local entry=C.AcceptanceScenarios[self.selected]
    local row=s.results[entry.id]
    self.title:SetText(entry.title);self.steps:SetText(entry.steps);self.expected:SetText(entry.expected)
    self.noteLabel:SetText(entry.noteRequired and "Observation / evidence reference (required to pass)" or "Observation / evidence reference (optional)")
    if not preserveNote then self.note:SetText(row and row.note or "") end
    self.result:SetText("Recorded: "..(row and (row.status=="PASS" and "Passed" or row.status=="FAIL" and "Issue found" or "Not run") or "Not run"))
    for i,button in ipairs(self.rows) do
        local r=s.results[C.AcceptanceScenarios[i].id]
        local prefix=r and (r.status=="PASS" and "+ " or r.status=="FAIL" and "! " or "· ") or "· "
        button:SetText(prefix..C.AcceptanceScenarios[i].title)
        U.Active(button,i==self.selected)
    end
    enabled(self.start,writable and s.state~="STORAGE_UNAVAILABLE" and not locked)
    self.start:SetText(self.confirmStart and "Start new check?" or s.runID and "New check" or "Start check")
    local canRecord=writable and s.runID~=nil and not invalid and not locked
    for _,b in ipairs(self.recordButtons) do enabled(b,canRecord) end
    enabled(self.launch,not locked and entry.service~="suite" and C.Services:Get(entry.service,1)~=nil)
    self.launch:SetText(entry.service=="suite" and "Use normal gameplay" or "Open utility")
    enabled(self.capture,not locked and C.Client.allowed and not C.Performance.active)
    enabled(self.report,not locked)
end
function P:Select(index)
    if not C.AcceptanceScenarios[index] then return end
    self:SaveDraft()
    self.selected=index;self.confirmStart=false;self.message:SetText("")
    self:Refresh()
    local draft=self.drafts and self.drafts[index]
    if draft and draft.sequence==self.snapshot.runID then self.note:SetText(draft.text) end
end
function P:SaveDraft()
    if not self.note or not self.snapshot then return end
    self.drafts=self.drafts or {}
    self.drafts[self.selected]={text=self.note:GetText() or "",sequence=self.snapshot.runID}
end
function P:Record(status)
    local s=self.snapshot or {}
    local ok,why=C.Acceptance:Record(C.AcceptanceScenarios[self.selected].id,status,self.note:GetText(),s.runID,s.runRevision)
    self.message:SetText(why or "")
    if ok and self.drafts then self.drafts[self.selected]=nil end
    self:Refresh(not ok)
end
function P:Create()
    if self.frame then return end
    local f=CreateFrame("Frame","MirageUtilityAcceptance",UIParent,"BackdropTemplate")
    f:SetSize(760,610);f:SetPoint("CENTER");f:SetFrameStrata("DIALOG");f:SetClampedToScreen(true)
    f:EnableMouse(true);f:SetMovable(true);f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart",function(frame) if C.CombatState()==false then frame:StartMoving() end end)
    f:SetScript("OnDragStop",function(frame) frame:StopMovingOrSizing() end)
    U.Panel(f)
    local heading=label(f,"Release check",18,-18,420,"title");U.Heading(f,heading,18,-18)
    self.progress=label(f,"",18,-53,720,"small")
    self.state=label(f,"",18,-77,720,"small");U.Tint(self.state,"muted")
    local line=f:CreateTexture(nil,"BORDER");line:SetTexture("Interface\\Buttons\\WHITE8x8")
    line:SetPoint("TOPLEFT",f,"TOPLEFT",238,-111);line:SetSize(1,424);line:SetVertexColor(.26,.26,.26,1)
    self.rows={}
    for i,entry in ipairs(C.AcceptanceScenarios) do
        local index=i
        self.rows[i]=U.Button(f,entry.title,18,-111-(i-1)*30,206,26,function() self:Select(index) end)
        self.rows[i].title:SetJustifyH("LEFT")
    end
    self.title=label(f,"",258,-113,484,"title");U.Tint(self.title,"secondary")
    label(f,"Try this",258,-149,484,"small")
    self.steps=label(f,"",258,-172,484,"body");self.steps:SetHeight(90)
    label(f,"Expected result",258,-266,484,"small")
    self.expected=label(f,"",258,-289,484,"body");self.expected:SetHeight(90)
    self.result=label(f,"",258,-382,484,"small");U.Tint(self.result,"secondary")
    self.noteLabel=label(f,"",258,-405,484,"small")
    local note=CreateFrame("EditBox",nil,f,"InputBoxTemplate")
    note:SetPoint("TOPLEFT",f,"TOPLEFT",265,-432);note:SetSize(465,28);note:SetAutoFocus(false)
    note:SetMaxLetters(160);note:SetFontObject("GameFontHighlightSmall");U.Font(note,"body")
    note:SetScript("OnEscapePressed",function() note:ClearFocus() end)
    note:SetScript("OnEnterPressed",function() note:ClearFocus() end)
    self.note=note
    self.recordButtons={}
    for i,entry in ipairs({{"Passed","PASS"},{"Issue found","FAIL"},{"Not run","NOT_RUN"}}) do
        local status=entry[2]
        self.recordButtons[i]=U.Button(f,entry[1],258+(i-1)*164,-475,156,29,function() self:Record(status) end)
    end
    self.message=label(f,"",258,-514,484,"small");self.message:SetHeight(40)
    self.start=U.Button(f,"Start check",18,-563,140,29,function()
        local s=C.Acceptance:GetStatus()
        if s.runID and not self.confirmStart then
            self.confirmStart=true;self.message:SetText("Current results become the previous check. Only the latest two checks are kept.")
            self:Refresh(true);return
        end
        local ok,why=C.Acceptance:Start();self.confirmStart=false
        if ok then self.drafts={} end
        self.message:SetText(why or "");self:Refresh(not ok)
    end)
    self.launch=U.Button(f,"Open utility",168,-563,184,29,function()
        local entry=C.AcceptanceScenarios[self.selected]
        local ok,why=C.Commands:OpenService(entry.service)
        if ok then f:Hide() else self.message:SetText(why or "Utility unavailable.") end
    end)
    self.capture=U.Button(f,"Capture 60 sec",362,-563,140,29,function()
        local ok,why=C.Performance:Start(60)
        if ok then f:Hide() else self.message:SetText(why or "Capture unavailable.") end
    end)
    self.report=U.Button(f,"Copy report",512,-563,140,29,function()
        local ok,why=C.Report:Open()
        if ok then f:Hide() else self.message:SetText(why or "Report unavailable.") end
    end)
    U.Button(f,"Close",662,-563,80,29,function() f:Hide() end)
    self.frame=f
    f:SetScript("OnHide",function() self:SaveDraft();note:ClearFocus();self.confirmStart=false end)
    for _,event in ipairs({"PLAYER_REGEN_DISABLED","PLAYER_REGEN_ENABLED","ADDON_LOADED"}) do pcall(f.RegisterEvent,f,event) end
    f:SetScript("OnEvent",function() if f:IsShown() then self:Refresh(true) end end)
    U.Watch(f);f:Hide()
end
function P:Open()
    if C.CombatState()~=false then return false,"Open the release check after combat." end
    if not UIParent then return false,"Release check unavailable." end
    if self.frame and self.frame:IsShown() then self:SaveDraft() end
    self:Create();self:Refresh()
    local draft=self.drafts and self.drafts[self.selected]
    if draft and draft.sequence==self.snapshot.runID then self.note:SetText(draft.text) end
    if not U.Fit(self.frame) then self.frame:Hide();return false,"Not enough space for the release check." end
    self.frame:Show();return true
end
