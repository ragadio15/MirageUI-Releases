local _,C=...
-- Standalone copy of the core MirageUI options tokens. No runtime read of another addon's private state.
local unpackColor=unpack or table.unpack
local white="Interface\\Buttons\\WHITE8x8"
local colors={
    background={.035,.035,.038,.98}, panel={.060,.060,.065,.97}, edge={.26,.26,.26,1},
    accent={.91,.55,.18,1}, secondary={.96,.79,.36,1},
    text={.90,.89,.87,1}, muted={.63,.62,.60,1},
    fill={.060,.060,.065,.97}, hover={.15,.12,.08,.98}, active={.15,.12,.08,.98},
    hud={.035,.035,.038,.88},
}
local U={}
local sizes={title=14,body=14,small=12,button=12}
-- Preserve the locale's supplied font file and flags, including CJK/Cyrillic.
function U.Font(region,role)
    if not region or type(region.SetFont)~="function" or type(C.Call)~="function" then return false end
    local file,ok,_,flags=C.Call(region.GetFont,region)
    if not ok or type(file)~="string" or file=="" then file=STANDARD_TEXT_FONT end
    if type(file)~="string" or file=="" then return false end
    local size=sizes[role] or sizes.body
    local accepted,called=C.Call(region.SetFont,region,file,size,type(flags)=="string" and flags or "")
    return called and accepted~=false
end
local coreMedia="Interface\\AddOns\\MirageIntel_Core\\Media\\"
local badges={
    core=coreMedia.."Badge",
    map=coreMedia.."map",
    navigate=coreMedia.."navigate",
    gather=coreMedia.."gather",
    insight=coreMedia.."insight",
}
local headingBadges={
    core=coreMedia.."Badge",
    map="Interface\\AddOns\\MirageIntel_Map\\Media\\Badge",
    navigate="Interface\\AddOns\\MirageIntel_Navigate\\Media\\Badge",
    gather="Interface\\AddOns\\MirageIntel_Gather\\Media\\Badge",
    insight="Interface\\AddOns\\MirageIntel_Insight\\Media\\Badge",
}
function U.Heading(frame,region,x,y,key)
    local mark=frame:CreateTexture(nil,"ARTWORK")
    mark:SetSize(20,20);mark:SetPoint("TOPLEFT",frame,"TOPLEFT",x,y+2)
    mark:SetTexture(headingBadges[key] or coreMedia.."MirageUI")
    region:ClearAllPoints();region:SetPoint("LEFT",mark,"RIGHT",4,0)
    region:SetJustifyV("MIDDLE")
    U.Font(region,"title")
    return mark
end
function U.ButtonBadge(button,key)
    if not button or not button.mirageChrome or button.mirageBadge or not badges[key] then return end
    local badge=button:CreateTexture(nil,"ARTWORK")
    badge:SetSize(16,16);badge:SetPoint("LEFT",button,"LEFT",6,0);badge:SetTexture(badges[key])
    button.title:ClearAllPoints()
    button.title:SetPoint("LEFT",button,"LEFT",27,0)
    button.title:SetPoint("RIGHT",button,"RIGHT",-5,0)
    button.mirageBadge=badge
    local shade=(not button.IsEnabled or button:IsEnabled()) and 1 or .55
    badge:SetVertexColor(shade,shade,shade,1)
end
function U.Tint(region,role)
    region:SetTextColor(unpackColor(colors[role] or colors.text))
end
function U.OneLine(region)
    if region.SetWordWrap then region:SetWordWrap(false) end
    if region.SetMaxLines then region:SetMaxLines(1) end
end
function U.Panel(frame,kind)
    frame:SetBackdrop({bgFile=white,edgeFile=white,edgeSize=1})
    frame:SetBackdropColor(unpackColor(colors[kind=="hud" and "hud" or "background"]))
    frame:SetBackdropBorderColor(unpackColor(colors.edge))
    if kind=="hud" then
        if frame.miragePanelRule then frame.miragePanelRule:Hide() end
        if frame.miragePanelShine then frame.miragePanelShine:Hide();frame.miragePanelGlass:Hide() end
        return
    end
    if not frame.miragePanelShine then
        local shine=frame:CreateTexture(nil,"BACKGROUND");shine:SetAllPoints(frame);shine:SetTexture(coreMedia.."PanelShine.tga");shine:SetVertexColor(.82,.53,.29,.17);frame.miragePanelShine=shine
        local glass=frame:CreateTexture(nil,"BACKGROUND");glass:SetAllPoints(frame);glass:SetTexture(coreMedia.."PanelGlass.tga");glass:SetVertexColor(.72,.53,.33,.23);frame.miragePanelGlass=glass
    end
    frame.miragePanelShine:Show();frame.miragePanelGlass:Show()
    -- Reapplying a theme must not grow the region pool.
    local rule=frame.miragePanelRule or frame:CreateTexture(nil,"BORDER")
    frame.miragePanelRule=rule
    rule:SetTexture(white)
    rule:SetPoint("TOPLEFT",frame,"TOPLEFT",1,-1)
    rule:SetPoint("TOPRIGHT",frame,"TOPRIGHT",-1,-1)
    rule:SetHeight(2)
    rule:SetVertexColor(colors.accent[1],colors.accent[2],colors.accent[3],.70)
    rule:Show()
end
local function paint(button)
    button.miragePaintGeneration=(button.miragePaintGeneration or 0)+1
    if button.miragePainting then return false end
    button.miragePainting=true
    local done=false
    for attempt=1,2 do
        local generation=button.miragePaintGeneration
        local ok,result=pcall(function()
            local enabled=not button.IsEnabled or button:IsEnabled()==true
            local hovered,active=button.mirageHover==true,button.mirageActive==true
            local fill,edges,gloss,stripe,badge,title=button.fill,button.mirageEdges,button.mirageGloss,button.mirageSelectionRule,button.mirageBadge,button.title
            local function stable()
                return generation==button.miragePaintGeneration and button.fill==fill and button.mirageEdges==edges and
                    button.mirageGloss==gloss and button.mirageSelectionRule==stripe and button.mirageBadge==badge and button.title==title and
                    (button.mirageHover==true)==hovered and (button.mirageActive==true)==active
            end
            local function current()
                if not stable() then return false end
                local available=not button.IsEnabled or button:IsEnabled()==true
                return stable() and available==enabled
            end
            local selected=enabled and (hovered or active)
            if current() then fill:SetVertexColor(unpackColor(colors[enabled and (hovered and "hover" or active and "active") or "fill"])) end
            if edges then for i,edge in ipairs(edges) do
                if current() and edges[i]==edge then edge:SetVertexColor(unpackColor(selected and colors.accent or colors.edge)) end
            end end
            if current() and gloss then gloss:SetVertexColor(.96,.79,.36,enabled and (hovered and .58 or active and .45 or .22) or .1) end
            if current() and stripe then if selected then stripe:Show() else stripe:Hide() end end
            if current() and badge then local shade=enabled and 1 or .55;badge:SetVertexColor(shade,shade,shade,1) end
            if current() then U.Tint(title,enabled and "text" or "muted") end
            return current()
        end)
        if ok and result then done=true;break end
        -- A newer state gets one bounded cosmetic repair. Native Enable,
        -- Disable and action callbacks are never called again by painting.
        if not ok and button.miragePaintGeneration==generation then break end
    end
    button.miragePainting=nil
    return done
end
function U.Active(button,selected)
    if button and button.mirageChrome then
        button.mirageActive=selected==true
        paint(button)
    end
end
function U.Button(parent,name,x,y,width,height,handler)
    local b=CreateFrame("Button",nil,parent)
    b.mirageChrome=true
    b:SetSize(width,height)
    b:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
    b.fill=b:CreateTexture(nil,"BACKGROUND")
    b.fill:SetAllPoints(b);b.fill:SetTexture(white)
    b.mirageEdges={}
    for _,side in ipairs({"TOP","BOTTOM","LEFT","RIGHT"}) do
        local edge=b:CreateTexture(nil,"BORDER");edge:SetTexture(white)
        if side=="TOP" or side=="BOTTOM" then edge:SetPoint(side.."LEFT",b,side.."LEFT");edge:SetPoint(side.."RIGHT",b,side.."RIGHT");edge:SetHeight(1)
        else edge:SetPoint("TOP"..side,b,"TOP"..side);edge:SetPoint("BOTTOM"..side,b,"BOTTOM"..side);edge:SetWidth(1) end
        b.mirageEdges[#b.mirageEdges+1]=edge
    end
    b.mirageGloss=b:CreateTexture(nil,"BORDER");b.mirageGloss:SetAllPoints(b);b.mirageGloss:SetTexture(coreMedia.."ButtonGloss.tga")
    -- A restrained amber baseline makes the selected tab legible without
    -- changing the authored dimensions or relying only on a dark fill.
    b.mirageSelectionRule=b:CreateTexture(nil,"BORDER")
    b.mirageSelectionRule:SetTexture(white)
    b.mirageSelectionRule:SetPoint("TOPLEFT",b,"TOPLEFT",1,-3)
    b.mirageSelectionRule:SetPoint("BOTTOMLEFT",b,"BOTTOMLEFT",1,3)
    b.mirageSelectionRule:SetWidth(2)
    b.mirageSelectionRule:SetVertexColor(unpackColor(colors.accent))
    local t=b:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    t:SetPoint("LEFT",b,"LEFT",6,0);t:SetPoint("RIGHT",b,"RIGHT",-6,0)
    t:SetJustifyH("CENTER");U.OneLine(t)
    U.Font(t,"button")
    b.title=t;b:SetFontString(t);b:SetText(name)
    b:SetScript("OnClick",handler)
    b:SetScript("OnEnter",function(self) self.mirageHover=true;paint(self) end)
    b:SetScript("OnLeave",function(self) self.mirageHover=false;paint(self) end)
    b:SetScript("OnHide",function(self)
        -- A pooled row may already have been shown/reused by its caller.
        local generation=self.miragePaintGeneration
        local visible,ok=C.Call(self.IsVisible or self.IsShown,self)
        if not ok or generation~=self.miragePaintGeneration or visible~=false then return end
        self.mirageHover=false;paint(self)
    end)
    b:SetScript("OnDisable",paint);b:SetScript("OnEnable",paint)
    paint(b)
    return b
end
-- Fit only addon-owned panels and hints. Never scale native frames or map pins.
function U.Fit(frame,requested)
    if not UIParent or not frame then return false end
    local w=C.Call(UIParent.GetWidth,UIParent)
    local h=C.Call(UIParent.GetHeight,UIParent)
    local fw=C.Call(frame.GetWidth,frame)
    local fh=C.Call(frame.GetHeight,frame)
    if not C.Number(w) or not C.Number(h) or not C.Number(fw) or not C.Number(fh)
        or w<=24 or h<=24 or fw<=0 or fh<=0 then return false end
    -- Hints inherit the scale of their owning row. Compare physical dimensions
    -- in UIParent units, so enlarged owners cannot overflow the viewport and
    -- already reduced owners do not shrink their hints a second time.
    local inherited=1
    if type(frame.GetParent)=="function" then
        local parent,ok=C.Call(frame.GetParent,frame)
        if not ok then return false end
        if parent and parent~=UIParent then
            local parentScale=C.Call(parent.GetEffectiveScale,parent)
            local rootScale=C.Call(UIParent.GetEffectiveScale,UIParent)
            if not C.Number(parentScale) or not C.Number(rootScale) or parentScale<=0 or rootScale<=0 then return false end
            inherited=parentScale/rootScale
            if not C.Number(inherited) or inherited<=0 then return false end
        end
    end
    if C.Number(requested) and requested>0 and requested<=3 then frame.mirageRequestedScale=requested end
    requested=frame.mirageRequestedScale or 1
    local scale=math.min(requested,(w-24)/fw/inherited,(h-24)/fh/inherited)
    if not C.Number(scale) or scale<=0 then return false end
    if C.Call(frame.GetScale,frame)~=scale then frame:SetScale(scale) end
    return true
end
function U.Escape(frame)
    local name=C.Call(frame.GetName,frame)
    if type(UISpecialFrames)~="table" or type(name)~="string" then return end
    for _,key in ipairs(UISpecialFrames) do if key==name then return end end
    UISpecialFrames[#UISpecialFrames+1]=name
end
function U.Watch(frame)
    if frame.mirageFitWatched then return end
    frame.mirageFitWatched=true
    U.Escape(frame)
    for _,event in ipairs({"DISPLAY_SIZE_CHANGED","UI_SCALE_CHANGED","PLAYER_REGEN_ENABLED"}) do
        pcall(frame.RegisterEvent,frame,event)
    end
    local function update(self)
        if self:IsShown() and C.CombatState()==false then U.Fit(self) end
    end
    if type(frame.HookScript)=="function" then frame:HookScript("OnEvent",update)
    else
        local previous=type(frame.GetScript)=="function" and frame:GetScript("OnEvent")
        frame:SetScript("OnEvent",function(self,...)
            if type(previous)=="function" then previous(self,...) end
            update(self)
        end)
    end
end
-- One shared, bounded choice menu for companion settings. Choices are values,
-- never executable labels; a hidden owner or world transition retires the menu.
local choicesMenu
function U.CloseChoices(owner)
    if choicesMenu and (not owner or choicesMenu.owner==owner) then choicesMenu:Hide() end
end
function U.Choose(owner,choices,current,onPick)
    if C.CombatState()~=false or not owner or not owner:IsShown() or
        type(choices)~="table" or #choices==0 or #choices>32 or type(onPick)~="function" then return false end
    local m=choicesMenu
    if not m then
        m=CreateFrame("Frame","MirageUtilityChoices",UIParent,"BackdropTemplate")
        choicesMenu=m;m.rows={};m:SetFrameStrata("FULLSCREEN_DIALOG");m:SetClampedToScreen(true);m:EnableMouse(true)
        U.Panel(m);U.Escape(m)
        m:SetScript("OnHide",function(self)
            self.owner=nil;self.onPick=nil;self.generation=(self.generation or 0)+1
            if type(self.UnregisterEvent)=="function" then pcall(self.UnregisterEvent,self,"GLOBAL_MOUSE_DOWN") end
        end)
        for _,event in ipairs({"PLAYER_REGEN_DISABLED","PLAYER_LEAVING_WORLD","DISPLAY_SIZE_CHANGED","UI_SCALE_CHANGED"}) do pcall(m.RegisterEvent,m,event) end
        m:SetScript("OnEvent",function(self,event)
            if event=="GLOBAL_MOUSE_DOWN" then
                local inside,read=C.Call(self.IsMouseOver,self)
                local ownerInside,ownerRead=C.Call(self.owner and self.owner.IsMouseOver,self.owner)
                if read and ownerRead and inside==false and ownerInside==false then self:Hide() end
            else self:Hide() end
        end)
    end
    local toggle=m:IsShown() and m.owner==owner;m:Hide();if toggle then return true end
    local width=math.max(180,math.min(360,owner:GetWidth() or 180))
    m:SetSize(width,#choices*29+12);m:ClearAllPoints();m:SetPoint("TOPRIGHT",owner,"BOTTOMRIGHT",0,-4)
    m.owner=owner;m.onPick=onPick;local generation=m.generation
    if not owner.mirageChoicesHook and type(owner.HookScript)=="function" then
        owner.mirageChoicesHook=true;owner:HookScript("OnHide",function(self)U.CloseChoices(self)end)
    end
    for i,choice in ipairs(choices) do
        local row=m.rows[i]
        if not row then row=U.Button(m,"",6,-6-(i-1)*29,width-12,27,nil);m.rows[i]=row end
        row:SetWidth(width-12);row:SetText(tostring(choice[2]));U.Active(row,choice[1]==current)
        local value=choice[1]
        row:SetScript("OnClick",function()
            local fn=m.onPick
            local valid=m.generation==generation and m.owner==owner and owner:IsShown() and
                (not owner.IsVisible or owner:IsVisible()) and (not owner.IsEnabled or owner:IsEnabled()) and C.CombatState()==false
            if valid then m:Hide();if fn then fn(value) end end
        end);row:Show()
    end
    for i=#choices+1,#m.rows do m.rows[i]:Hide() end
    U.Fit(m);pcall(m.RegisterEvent,m,"GLOBAL_MOUSE_DOWN");m:Show();return true
end
-- Supplementary hints use one owned popup. They never take over GameTooltip,
-- inspect another addon's frame, or create an update loop. The owning pooled
-- row must withdraw its hint when the record shown by that row changes.
local tip,tipOwner
function U.HideTip(owner)
    if owner and owner~=tipOwner then return false end
    if tip then tip:Hide() end
    tipOwner=nil
    return true
end
function U.Tip(owner,title,body)
    local function refuse()
        -- A reused row that no longer has valid data must not keep its earlier
        -- hint. A failed request from a different owner cannot dismiss it.
        if owner and owner==tipOwner then U.HideTip(owner) end
        return false
    end
    if not UIParent or not owner or type(owner.IsShown)~="function" or
        C.Call(owner.IsShown,owner)~=true then return refuse() end
    if type(owner.IsVisible)=="function" and C.Call(owner.IsVisible,owner)~=true then return refuse() end
    local heading=C.TextClip(title,120)
    local detail=C.TextClip(body,800)
    if not heading or heading=="" or not detail then return refuse() end
    -- Treat records and personal labels as text, never executable font markup.
    heading=heading:gsub("|","||");detail=detail:gsub("|","||")
    if not tip then
        tip=CreateFrame("Frame",nil,UIParent,"BackdropTemplate")
        tip:SetFrameStrata("TOOLTIP");tip:SetClampedToScreen(true);tip:EnableMouse(false)
        U.Panel(tip)
        tip.title=tip:CreateFontString(nil,"OVERLAY","GameFontNormal")
        tip.title:SetPoint("TOPLEFT",tip,"TOPLEFT",14,-12)
        tip.title:SetJustifyH("LEFT");U.Font(tip.title,"body");U.Tint(tip.title,"secondary")
        tip.body=tip:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
        tip.body:SetJustifyH("LEFT");U.Font(tip.body,"small");U.Tint(tip.body,"text")
        if tip.body.SetWordWrap then tip.body:SetWordWrap(true) end
        if tip.title.SetWordWrap then tip.title:SetWordWrap(true) end
        for _,event in ipairs({"PLAYER_REGEN_DISABLED","PLAYER_LEAVING_WORLD","DISPLAY_SIZE_CHANGED","UI_SCALE_CHANGED"}) do
            pcall(tip.RegisterEvent,tip,event)
        end
        tip:SetScript("OnEvent",function()U.HideTip()end)
        -- Native OnHide also fires when an ancestor hides, while IsShown can
        -- still be true. Clear that local shown flag so reopening the owner's
        -- panel cannot resurrect the previous row's hint. No owner hook grows.
        tip:SetScript("OnHide",function(self)
            tipOwner=nil
            if self:IsShown() then self:Hide() end
        end)
        tip:Hide()
    end
    tip:SetParent(owner);tipOwner=owner
    local width=360
    tip:SetWidth(width);tip.title:SetWidth(width-28);tip.body:SetWidth(width-28)
    tip.title:SetHeight(0);tip.body:SetHeight(0)
    tip.title:SetText(heading);tip.body:SetText(detail)
    local headingHeight=C.Call(tip.title.GetStringHeight,tip.title)
    local bodyHeight=C.Call(tip.body.GetStringHeight,tip.body)
    headingHeight=C.Number(headingHeight) and math.max(16,headingHeight) or 32
    bodyHeight=C.Number(bodyHeight) and math.max(16,bodyHeight) or 100
    tip.title:SetHeight(headingHeight);tip.body:SetHeight(bodyHeight)
    tip.body:ClearAllPoints();tip.body:SetPoint("TOPLEFT",tip,"TOPLEFT",14,-18-headingHeight)
    tip:SetHeight(headingHeight+bodyHeight+32)
    tip:ClearAllPoints();tip:SetPoint("TOPLEFT",owner,"TOPRIGHT",8,0)
    if not U.Fit(tip,1) then U.HideTip(owner);return false end
    tip:Show()
    return true
end
-- Plain owned scrolling: no inherited arrow buttons or legacy scrollbar art.
-- A compact scroll thumb and the mouse wheel provide equivalent access.
function U.Scroll(parent)
    local scroll=CreateFrame("ScrollFrame",nil,parent)
    scroll.mirageOffset=0
    local rail=CreateFrame("Slider",nil,parent)
    rail:SetWidth(8);rail:SetPoint("TOPLEFT",scroll,"TOPRIGHT",4,0)
    rail:SetPoint("BOTTOMLEFT",scroll,"BOTTOMRIGHT",4,0)
    local back=rail:CreateTexture(nil,"BACKGROUND");back:SetAllPoints(rail)
    back:SetTexture(white);back:SetVertexColor(.18,.18,.19,.8)
    local thumb=rail:CreateTexture(nil,"ARTWORK");thumb:SetSize(6,28)
    thumb:SetTexture(white);thumb:SetVertexColor(.63,.62,.60,.9)
    if type(rail.SetOrientation)=="function" then rail:SetOrientation("VERTICAL") end
    if type(rail.SetThumbTexture)=="function" then rail:SetThumbTexture(thumb) end
    if type(rail.SetValueStep)=="function" then rail:SetValueStep(24) end
    local syncing=false
    function scroll:MirageScrollTo(value)
        if syncing then return end
        syncing=true
        local range=C.Call(self.GetVerticalScrollRange,self)
        if not C.Number(range) then
            local child=C.Call(self.GetScrollChild,self)
            local height=child and C.Call(child.GetHeight,child) or 0
            local view=C.Call(self.GetHeight,self)
            range=C.Number(height) and C.Number(view) and math.max(0,height-view) or 0
        end
        range=math.max(0,range)
        self.mirageOffset=math.max(0,math.min(range,C.Number(value) and value or self.mirageOffset))
        if type(self.SetVerticalScroll)=="function" then self:SetVerticalScroll(self.mirageOffset) end
        if type(rail.SetMinMaxValues)=="function" then rail:SetMinMaxValues(0,range) end
        if type(rail.SetValue)=="function" then rail:SetValue(self.mirageOffset) end
        rail:SetShown(range>1)
        syncing=false
    end
    if type(scroll.EnableMouseWheel)=="function" then scroll:EnableMouseWheel(true) end
    scroll:SetScript("OnMouseWheel",function(self,delta) if C.Number(delta) then self:MirageScrollTo(self.mirageOffset-delta*36) end end)
    scroll:SetScript("OnScrollRangeChanged",function(self) self:MirageScrollTo(self.mirageOffset) end)
    scroll:SetScript("OnShow",function(self) self:MirageScrollTo(self.mirageOffset) end)
    scroll:SetScript("OnHide",function() rail:Hide() end)
    rail:SetScript("OnValueChanged",function(_,value) scroll:MirageScrollTo(value) end)
    rail:Hide();scroll.mirageRail=rail
    return scroll
end
C.Chrome=U
C.Public.Chrome=U
