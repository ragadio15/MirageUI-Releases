local _,C=...
C.Commands={}
local T=C.Commands
local chrome=C.Chrome
local entries={
    {label="Maps",key="map",alias="map+ ultra",service="MapAddon",addon="MirageIntel_Map"},
    {label="Wayfinder",key="navigate",alias="wayfinder",service="Navigate",addon="MirageIntel_Navigate"},
    {label="Gather Mate",key="gather",service="Gather",addon="MirageIntel_Gather"},
    {label="Insight",key="insight",service="Insight",addon="MirageIntel_Insight"},
}
local function combat()
    return C.CombatState()~=false
end
local function serviceOpener(id)
    local service=C.Services:Get(id,1)
    if not C.Readable(service) or type(service)~="table" then return nil end
    local open=C.Call(function() return service.Open end)
    return type(open)=="function" and open or nil
end
local function label(text,font,parent,x,y)
    local f=parent:CreateFontString(nil,"OVERLAY",font or "GameFontHighlightSmall")
    f:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y);f:SetText(text)
    if chrome then chrome.Tint(f,font and "secondary" or "text") end
    return f
end
local function button(parent,name,dx,dy,w,callback)
    if chrome then return chrome.Button(parent,name,dx,dy,w,25,callback) end
    local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
    b:SetSize(w,25);b:SetPoint("TOPLEFT",parent,"TOPLEFT",dx,dy)
    b:SetText(name);b:SetScript("OnClick",callback)
    return b
end
function T:ModuleStatus()
    local addons=type(C_AddOns)=="table" and C_AddOns or {}
    local result={}
    for i,entry in ipairs(entries) do
        local status
        if serviceOpener(entry.service) then status="registered"
        else
            local loaded,known=C.Call(addons.IsAddOnLoaded,entry.addon)
            local title= C.Call(addons.GetAddOnMetadata,entry.addon,"Title")
            if known and loaded==true then status="loaded, panel unavailable"
            elseif C.Text(title) and title~="" then status="installed, not loaded"
            else status="not detected"
            end
        end
        result[i]={label=entry.label,addon=entry.addon,status=status}
    end
    return result
end
function T:OpenService(id)
    if not C.Client or not C.Client.allowed then return false,"This client build is not supported." end
    if combat() then return false,"Open utilities after combat." end
    local open=serviceOpener(id)
    if not open then
        for i,entry in ipairs(entries) do
            if entry.service==id then return false,entry.label..": "..self:ModuleStatus()[i].status.."." end
        end
        return false,"Utility unavailable."
    end
    local result,ok=C.Call(open)
    if not ok then C:Fault("UTILITY_PANEL_OPEN_FAILED");return false,"Could not open this panel." end
    if result~=true then return false,"This panel is unavailable right now." end
    return true
end
function T:Fit()
    if not self.frame or not UIParent or combat() then return false end
    local w=C.Call(UIParent.GetWidth,UIParent)
    local h=C.Call(UIParent.GetHeight,UIParent)
    if not C.Number(w) or not C.Number(h) or w<176 or h<116 then return false end
    if chrome then return chrome.Fit(self.frame) end
    local scale=math.min(1,(w-24)/304,(h-24)/179)
    if scale~=self.lastScale then
        self.frame:SetScale(scale)
        self.lastScale=scale
    end
    return true
end
function T:Refresh()
    if not self.frame then return end
    local allowed=C.Client and C.Client.allowed
    local locked=combat()
    local n=0
    for i,entry in ipairs(entries) do
        if allowed and not locked and serviceOpener(entry.service) then
            self.buttons[i]:Enable();n=n+1
        else self.buttons[i]:Disable() end
    end
    local info="Choose a utility."
    if not allowed then info="This client build is not supported."
    elseif locked then info="Open utilities after combat."
    elseif n==0 then info="Enable a utility in the AddOns list."
    elseif C.Storage.readOnly then info="Core settings are read-only." end
    self.text:SetText(info)
end
function T:Create()
    if self.frame or not UIParent then return end
    local frame=CreateFrame("Frame","MirageIntelCorePanel",UIParent,"BackdropTemplate")
    frame:SetSize(304,179);frame:SetPoint("CENTER",UIParent,"CENTER",0,70)
    frame:SetFrameStrata("DIALOG");frame:SetClampedToScreen(true)
    if chrome then chrome.Panel(frame) else
    frame:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8x8",edgeFile="Interface\\Buttons\\WHITE8x8",edgeSize=1})
    frame:SetBackdropColor(.055,.065,.075,.97);frame:SetBackdropBorderColor(.28,.30,.32,.9) end
    frame:EnableMouse(true);frame:SetMovable(true);frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart",function(f) f:StartMoving() end)
    frame:SetScript("OnDragStop",function(f) f:StopMovingOrSizing() end)
    local title=label("Utility Core","GameFontNormalLarge",frame,16,-15)
    if chrome and chrome.Heading then chrome.Heading(frame,title,16,-15,"core") end
    if not chrome then title:SetTextColor(.96,.79,.36) end
    self.text=label("",nil,frame,16,-43);self.text:SetWidth(272);self.text:SetJustifyH("LEFT")
    self.buttons={}
    for i,entry in ipairs(entries) do
        local id,name=entry.service,entry.label
        self.buttons[i]=button(frame,name,16+((i-1)%2)*139,-75-math.floor((i-1)/2)*33,133,function()
            local ok,why=self:OpenService(id)
            if ok then frame:Hide() else self.text:SetText(why) end
        end)
        if chrome and chrome.ButtonBadge then chrome.ButtonBadge(self.buttons[i],entry.key) end
    end
    button(frame,"Status",16,-141,62,function() self:PrintStatus() end)
    button(frame,"Report",86,-141,62,function() if C.Report then C.Report:Open() end end)
    button(frame,"Checks",156,-141,62,function()
        if C.AcceptancePanel then local ok=C.AcceptancePanel:Open();if ok then frame:Hide() end end
    end)
    button(frame,"Close",226,-141,62,function() frame:Hide() end)
    frame:Hide();self.frame=frame
    if type(UISpecialFrames)=="table" then
        local name=frame:GetName()
        local present=false
        for _,entry in ipairs(UISpecialFrames) do
            if entry==name then present=true;break end
        end
        if not present then UISpecialFrames[#UISpecialFrames+1]=name end
    end
    for _,event in ipairs({"DISPLAY_SIZE_CHANGED","UI_SCALE_CHANGED","PLAYER_REGEN_DISABLED","PLAYER_REGEN_ENABLED"}) do
        pcall(frame.RegisterEvent,frame,event)
    end
    frame:SetScript("OnEvent",function(_,event)
        if not frame:IsShown() then return end
        if event~="PLAYER_REGEN_DISABLED" and not combat() and not self:Fit() then frame:Hide();return end
        self:Refresh()
    end)
end
function T:PrintStatus()
    local storage=C.Storage:Diagnostics()
    C:Print(C.state.status.."; storage="..tostring(storage.status).."; build="..tostring(C.Client.build or "unknown")
        .."; account / character revisions="..tostring(storage.accountRevision).."/"..tostring(storage.charRevision))
    for _,entry in ipairs(self:ModuleStatus()) do C:Print(entry.label..": "..entry.status) end
    if C.state.lastError then C:Print("Last Core error: "..C.state.lastError) end
end
function T:Open()
    if combat() then return false,"Open utilities after combat." end
    self:Create()
    if not self.frame then return false,"The utility launcher is unavailable." end
    if not self:Fit() then
        self.frame:Hide()
        return false,"The window is too small. Use /mmap, /mnav, /mgather or /minsight."
    end
    self:Refresh();self.frame:Show();return true
end
function T:Dispatch(message)
    local command=type(message)=="string" and #message<=64 and message:match("^%s*(.-)%s*$"):lower() or nil
    if command and command:match("^baseline") then
        local action,scenario,duration=command:match("^baseline%s+(%w+)%s+([%w_]+)%s*(%d*)$")
        local ok,why
        if command=="baseline" or command=="baseline report" then ok,why=C.Report:Open("baseline")
        elseif command=="baseline stop" then ok,why=C.Performance:Stop()
        elseif command=="baseline status" then
            local capture=C.Performance:GetStatus()
            C:Print("P39-A "..tostring(capture.status).."; scenario="..tostring(capture.scenario)
                .."; frames="..tostring(capture.frameIntervals and capture.frameIntervals.samples or 0))
            return true
        elseif action=="start" and scenario then
            ok,why=C.Performance:Start(duration~="" and tonumber(duration) or 30,scenario)
        else
            ok,why=false,"Use /mirageutil baseline start <scenario> [30] | stop | report | status."
        end
        if why then C:Print(why) end
        return ok,why
    end
    if command and command:match("^profile") then
        local action,arg=command:match("^profile%s+(%w+)%s*(%S*)$")
        local ok,why
        if command=="profile" then ok,why=C.Report:Open()
        elseif action=="start" and (arg=="" or tonumber(arg)) then ok,why=C.Performance:Start(arg~="" and tonumber(arg) or 60)
        elseif action=="stop" and arg=="" then ok,why=C.Performance:Stop()
        else ok,why=false,"Use /mirageutil profile [start 60 | stop]." end
        if why then C:Print(why) end
        return ok,why
    end
    if command=="status" then self:PrintStatus();return true end
    if command=="check" or command=="acceptance" then
        local ok,why=C.AcceptancePanel:Open()
        if not ok and why then C:Print(why) end
        return ok,why
    end
    if command=="report" then
        local ok,why=C.Report:Open()
        if not ok and why then C:Print(why) end
        return ok,why
    end
    local ok,why
    if command=="" then
        local suite=_G.MirageUI
        if not combat() and type(suite)=="table" and type(suite.LoadOptions)=="function" then
            suite:LoadOptions();return true
        end
        ok,why=self:Open()
    else
        for _,entry in ipairs(entries) do
            if command==entry.key or command==entry.alias or command==entry.label:lower() then
                ok,why=self:OpenService(entry.service)
                if ok and self.frame then self.frame:Hide() end
                break
            end
        end
        if ok==nil then ok,why=false,"Use /mirageutil [map | navigate | gather | insight | status | report | profile | check]." end
    end
    if not ok and why then C:Print(why) end
    return ok,why
end
function T:Install()
    if type(SlashCmdList)~="table" then return false end
    SLASH_MIRAGEUTILITYCORE1="/mirageutil"
    SLASH_MIRAGEUTILITYCORE2="/micore"
    SlashCmdList.MIRAGEUTILITYCORE=function(msg) self:Dispatch(msg or "") end
    return true
end
