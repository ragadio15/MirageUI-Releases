local _,C=...
-- Original scalable pictograms shared by Map+, Gather Mate and the minimap.
-- Runtime textures are 64px uncompressed RGBA TGA; SVG masters ship alongside.
local A={version=3,sizes={world=32,worldActive=36,minimap=20,minimapActive=24},path="Interface\\AddOns\\MirageIntel_Core\\Media\\MapIcons\\"}
local keys={herb=true,ore=true,fish=true,pool=true,skin=true,treasure=true,quest=true,turnin=true,
    flight=true,repair=true,vendor=true,trainer=true,spirit=true,inn=true,dungeon=true,note=true,
    city=true,place=true,route=true,cluster=true,service=true,danger=true,active=true}
function A.Key(record,role)
    if role=="cluster" then return "cluster" end
    local r=type(record)=="table" and record or {}
    local kind,category=r.kind,r.category
    if kind=="gather" or kind=="resource" or r.layer=="resources" then return keys[category] and category or "herb" end
    if kind=="quest" or r.layer=="quests" then
        return (category=="turn-in" or category=="turnin" or r.stage=="turnin" or r.stage=="TURN_IN" or r.stage=="READY_FOR_TURN_IN" or r.complete==true) and "turnin" or "quest"
    end
    local roles=type(r.serviceRoles)=="string" and r.serviceRoles or ""
    if kind=="flight" or category=="flight" or roles:find("flight",1,true) then return "flight" end
    if category=="spirit-healer" or category=="spirit" or roles:find("spirit",1,true) then return "spirit" end
    if category=="city" then return "city" end
    if category=="entrance" or category=="dungeon" or category=="raid" or category=="instance" then return "dungeon" end
    if category=="inn" or roles:find("innkeeper",1,true) then return "inn" end
    if category=="repair" or roles:find("repair",1,true) then return "repair" end
    if category=="vendor" or roles:find("goods",1,true) or roles:find("vendor",1,true) then return "vendor" end
    if category=="trainer" or roles:find("trainer",1,true) then return "trainer" end
    if kind=="service" or kind=="transport" then return "service" end
    if kind=="note" then return "note" end
    if kind=="danger" then return "danger" end
    if role=="destination" or kind=="destination" or kind=="travel" then return "route" end
    return "place"
end
function A.Path(key) return A.path..(keys[key] and key or "place")..".tga" end
function A.Apply(texture,record,role,alpha)
    if not texture or type(texture.SetTexture)~="function" then return false end
    if texture:SetTexture(A.Path(A.Key(record,role)))==false then return false end
    if type(texture.GetTexture)=="function" and texture:GetTexture()==nil then return false end
    if type(texture.SetVertexColor)=="function" then texture:SetVertexColor(1,1,1,alpha or 1) end
    return true
end
-- Screen-space grouping checks the surrounding cells as well as the current
-- cell. A fixed representative keeps neighboring group centers separated;
-- averaging their positions afterward would introduce collisions again.
-- Callers order points by their display priority and retain every member.
function A.ClusterPoints(points,spacing)
    if type(points)~="table" or not C.Number(spacing) or spacing<=0 then return {} end
    local buckets,groups={},{}
    local radius2=spacing*spacing
    for _,point in ipairs(points) do
        if type(point)=="table" and C.Number(point.x) and C.Number(point.y) then
            local cx,cy=math.floor(point.x/spacing),math.floor(point.y/spacing)
            local nearest,distance
            for x=cx-1,cx+1 do for y=cy-1,cy+1 do
                local bucket=buckets[x..":"..y]
                if bucket then for _,group in ipairs(bucket) do
                    local dx,dy=point.x-group.x,point.y-group.y
                    local d=dx*dx+dy*dy
                    if d<radius2 and (not distance or d<distance or (d==distance and group.order<nearest.order)) then
                        nearest,distance=group,d
                    end
                end end
            end end
            if not nearest then
                nearest={point=point,x=point.x,y=point.y,points={},order=#groups+1}
                groups[#groups+1]=nearest
                local key=cx..":"..cy
                buckets[key]=buckets[key] or {};buckets[key][#buckets[key]+1]=nearest
            end
            nearest.points[#nearest.points+1]=point
        end
    end
    return groups
end
-- Liang-Barsky clipping preserves segments crossing the visible rectangle even
-- when both endpoints are outside it. All coordinates use the same local basis.
function A.ClipSegment(ax,ay,bx,by,rect)
    if not C.Number(ax) or not C.Number(ay) or not C.Number(bx) or not C.Number(by) or type(rect)~="table" then return nil end
    for _,key in ipairs({"left","right","top","bottom"}) do if not C.Number(rect[key]) then return nil end end
    if rect.right<rect.left or rect.bottom<rect.top then return nil end
    local dx,dy=bx-ax,by-ay;local lo,hi=0,1
    if not C.Number(dx) or not C.Number(dy) then return nil end
    for _,v in ipairs({{-dx,ax-rect.left},{dx,rect.right-ax},{-dy,ay-rect.top},{dy,rect.bottom-ay}}) do
        local p,q=v[1],v[2]
        if p==0 then if q<0 then return nil end
        else
            local r=q/p
            if p<0 then lo=math.max(lo,r) else hi=math.min(hi,r) end
            if lo>hi then return nil end
        end
    end
    return ax+dx*lo,ay+dy*lo,ax+dx*hi,ay+dy*hi
end
function A.ClipCircle(ax,ay,bx,by,radius)
    if not C.Number(ax) or not C.Number(ay) or not C.Number(bx) or not C.Number(by) or not C.Number(radius) or radius<=0 then return nil end
    local dx,dy=bx-ax,by-ay
    local a=dx*dx+dy*dy
    if not C.Number(a) then return nil end
    if a<.0000001 then if ax*ax+ay*ay<=radius*radius then return ax,ay,bx,by end;return nil end
    local b=2*(ax*dx+ay*dy);local c=ax*ax+ay*ay-radius*radius
    local d=b*b-4*a*c
    if not C.Number(d) then return nil end
    if d<0 then return nil end
    local root=math.sqrt(d);local low=math.max(0,(-b-root)/(2*a));local high=math.min(1,(-b+root)/(2*a))
    if low>high then return nil end
    return ax+dx*low,ay+dy*low,ax+dx*high,ay+dy*high
end
-- Keep a continuous route on the near side of UI chrome. Rectangles and
-- points share a pixel basis; inset reserves room for the arrow and shadow.
-- An obstacle is never a pin: callers supply explicit UI exclusion regions.
function A.ClipBeforeObstacles(ax,ay,bx,by,obstacles,inset)
    if not C.Number(ax) or not C.Number(ay) or not C.Number(bx) or not C.Number(by) then return nil end
    inset=C.Number(inset) and math.max(0,inset) or 0
    local dx,dy=bx-ax,by-ay
    local length2=dx*dx+dy*dy
    if not C.Number(length2) or length2<.000001 then return nil end
    local finish=1
    for _,rect in ipairs(type(obstacles)=="table" and obstacles or {}) do
        if type(rect)=="table" and C.Number(rect.left) and C.Number(rect.right) and
            C.Number(rect.top) and C.Number(rect.bottom) then
            local x,y=A.ClipSegment(ax,ay,bx,by,{left=rect.left-inset,right=rect.right+inset,
                top=rect.top-inset,bottom=rect.bottom+inset})
            if x then finish=math.min(finish,math.max(0,((x-ax)*dx+(y-ay)*dy)/length2)) end
        end
    end
    if finish<.000001 then return nil end
    return ax,ay,ax+dx*finish,ay+dy*finish,finish<.999999
end
C.MapIcons=A
if C.Public then C.Public.MapIcons=A end
