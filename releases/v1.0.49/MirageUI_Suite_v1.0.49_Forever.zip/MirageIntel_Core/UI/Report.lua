local _,C=...
C.Report={}
local R=C.Report
function R:RefreshText()
    local value=self.mode=="baseline" and self:BaselineText() or self:Text()
    local lines=0
    for line in (value.."\n"):gmatch("(.-)\n") do lines=lines+math.max(1,math.ceil(#line/70)) end
    self.edit:SetText(value)
    -- Own a scrollable body explicitly; do not depend on EditBox auto-height.
    self.edit:SetHeight(math.max(310,lines*18+30))
    if self.scroll and self.scroll.MirageScrollTo then self.scroll:MirageScrollTo(0) end
    self.edit:HighlightText()
end
local function readableText(v,limit)
    local value=tostring(v):gsub("[|\r\n]"," ")
    limit=limit or 300
    return C.TextBytes and C.TextBytes(value,limit) or value:sub(1,limit)
end
function R:Text()
    local data=C.Diagnostics.Probe()
    for _,name in ipairs({"WorldRecords","MapLayers","TravelGraph"}) do
        local api=C.Services:Get(name,1)
        if api and type(api.GetStatus)=="function" then
            local value,ok=C.Call(api.GetStatus);data[name]=ok and C.Copy(value) or "UNAVAILABLE"
        end
    end
    local nav=C.Services:Get("Navigate",1)
    if nav and type(nav.GetNavigationSnapshot)=="function" then
        local value,ok=C.Call(nav.GetNavigationSnapshot);data.navigation=ok and C.Copy(value) or "UNAVAILABLE"
    end
    if type(data.navigation)=="table" then
        local n=data.navigation
        data.P4={mode=n.mode,status=n.status,revision=n.revision,routeRevision=n.routeRevision,
            sessionID=n.sessionID,generation=n.generation,renderer=n.renderer,suspended=n.suspended,
            destinationID=n.destination and n.destination.id,
            precision=n.destination and n.destination.precision,leg=n.nextLeg,
            gatherStatus=n.gatherStatus,providerStatus=n.providerStatus,completedStops=n.completedStops,
            itineraryStops=n.itinerary and n.itinerary.stops and #n.itinerary.stops or 0,
            itineraryPrecision=n.itinerary and n.itinerary.precision,
            graph=data.TravelGraph,nativeAcceptance="NOT_RUN"}
    end
    -- Put bounded P3 evidence ahead of potentially longer owner diagnostics.
    -- No rendered record list, inventory or full history is copied here.
    data.P3={nativeAcceptance="NOT_RUN"}
    local map=C.Services:Get("MapAddon",1)
    if map and type(map.GetStatus)=="function" then
        local value,ok=C.Call(map.GetStatus)
        if ok and type(value)=="table" then
            data.P3.map={catalog=value.catalog,exploration=value.exploration,
                terrainRenderer=value.explorationRenderer,places=value.places}
            data.P6={coverage=value.coverage,interface=value.interface,
                coexistence=value.conflicts,nativeAcceptance="NOT_RUN"}
        end
    end
    local gather=C.Services:Get("Gather",1)
    if gather and type(gather.GetStatus)=="function" then
        local value,ok=C.Call(gather.GetStatus)
        if ok and type(value)=="table" then
            data.P3.gather={schemaVersion=value.schemaVersion,readOnly=value.readOnly,
                personalSites=value.recordCount,catalogSites=value.catalogCount,
                fishing=value.fishing,transfer=value.transfer,publication=value.publication,
                collector=value.collectorReason,lastBlocked=value.lastBlocked}
        end
    end
    local insight=C.Services:Get("Insight",1)
    if insight and type(insight.GetStatus)=="function" then
        local value,ok=C.Call(insight.GetStatus)
        data.P5=ok and C.Copy(value) or {status="UNAVAILABLE"}
    else data.P5={status="INSIGHT_NOT_LOADED"} end
    if nav and type(nav.GetStatus)=="function" then
        local value,ok=C.Call(nav.GetStatus)
        if ok and type(value)=="table" then
            data.P6=data.P6 or {}
            data.P6.navigation={questLocations=value.questLocations,questReadStatus=value.questReadStatus,
                status=value.status,mode=value.mode,questStrategy=value.questStrategy}
        end
    end
    if C.Acceptance then data.P7=C.Acceptance:GetStatus() end
    local packageID=C.Release and C.Text(C.Release.id) and C.Release.id~="" and C.Release.id
    local lines={"MirageUI Utilities "..readableText(C.version,64),
        packageID and "Package: "..readableText(packageID,160) or "Package identity unavailable",
        "Client: Forever "..tostring(C.Client.patch).." / "..tostring(C.Client.build).." / "..tostring(C.Client.interface),
        "Utility source review: "..(C.Client.allowed and "MATCHED" or "UNSUPPORTED"),
        "Native gameplay and performance acceptance: NOT_RUN (published package; player observations below)",
        "This report records observations; it does not certify native input or rendering.",""}
    local function visit(value,path,depth)
        if #lines>=500 or depth>7 then return end
        if type(value)~="table" then
            lines[#lines+1]=path.." = "..readableText(value,path:match("^P7%.results%..+%.note$") and 640 or 300)
            return
        end
        local keys={};for key in pairs(value) do keys[#keys+1]=key end
        table.sort(keys,function(a,b) return tostring(a)<tostring(b) end)
        for _,key in ipairs(keys) do visit(value[key],path=="" and tostring(key) or path.."."..tostring(key),depth+1) end
    end
    -- Current utility evidence precedes generic owner diagnostics. This keeps an
    -- item/provider failure visible even when unrelated services have many rows.
    for _,key in ipairs({"P7","P5","P6","performance","P4","P3","client","runtime","storage","tasks","services","api"}) do
        if data[key]~=nil then visit(data[key],key,0);data[key]=nil end
    end
    visit(data,"",0)
    if #lines>=500 then lines[#lines+1]="Report bounded at 500 lines." end
    local bounded,bytes={},0
    local notice="Report bounded at 90,000 bytes. Refresh after isolating the affected utility."
    for _,line in ipairs(lines) do
        if bytes+#line+1>90000-#notice-1 then bounded[#bounded+1]=notice;break end
        bounded[#bounded+1]=line;bytes=bytes+#line+1
    end
    return table.concat(bounded,"\n")
end
-- P39-A's compact, copyable report isolates the capture from long provider
-- diagnostics. Every field is a fixed metric/event code or bounded scalar.
function R:BaselineText()
    local data=C.Performance and C.Performance:GetStatus() or {status="NOT_RUN"}
    local lines={"MIRAGEUI P39-A / LOCAL PERFORMANCE BASELINE",
        "Whole-client frame times cannot establish which addon caused a frame delay.",
        "No player, chat, item-link or transaction contents are collected.",
        "Native qualification: PENDING_MATCHED_DESKTOP_AND_SURFACE_CAPTURE", ""}
    local function emit(value,path,depth)
        if #lines>=500 or depth>6 then return end
        if type(value)~="table" then
            lines[#lines+1]=path.." = "..readableText(value,120)
            return
        end
        local keys={};for k in pairs(value) do keys[#keys+1]=k end
        table.sort(keys,function(a,b)return tostring(a)<tostring(b) end)
        for _,key in ipairs(keys) do
            emit(value[key],path=="" and tostring(key) or path.."."..tostring(key),depth+1)
        end
    end
    for _,key in ipairs({"schemaVersion","scenario","status","requestedSeconds","elapsedSeconds",
        "stopReason","startedAt","environment","frameIntervals","bagOpenWindowIntervals",
        "professionOpenWindowIntervals","exceptionalFrameCounts","exceptionalFrames",
        "exceptionalFrameScope","eventCounts","counters","schedulerDelta",
        "markers","droppedMarkers","queuePeak","schedulerFailures","luaMemoryStartKB","luaMemoryPeakKB",
        "luaMemoryEndKB","luaMemoryDeltaKB","luaMemorySamples",
        "clockDiscontinuities","unsupportedEvents","interpretation","acceptance","channels"}) do
        if data[key]~=nil then emit(data[key],key,0) end
    end
    if #lines>=500 then lines[#lines+1]="Capture report bounded at 500 lines." end
    return table.concat(lines,"\n")
end
function R:Open(mode)
    self.mode=mode=="baseline" and "baseline" or "all"
    if C.CombatState()~=false then return false,"Open the utility report after combat." end
    if not UIParent then return false,"Report unavailable." end
    if not self.frame then
        local f=CreateFrame("Frame","MirageUtilityReport",UIParent,"BackdropTemplate")
        f:SetSize(660,450);f:SetPoint("CENTER");f:SetFrameStrata("DIALOG");f:SetClampedToScreen(true)
        f:EnableMouse(true);C.Chrome.Panel(f)
        local title=f:CreateFontString(nil,"OVERLAY","GameFontNormalLarge")
        title:SetText("Utility report");C.Chrome.Heading(f,title,18,-18);self.title=title
        local hint=f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
        hint:SetPoint("TOPLEFT",f,"TOPLEFT",18,-49);hint:SetWidth(624);hint:SetJustifyH("LEFT")
        hint:SetText("Click the report, then Ctrl+A and Ctrl+C to copy. Native validation is still pending.")
        if C.Chrome.Font then C.Chrome.Font(hint,"small") end
        local scroll=C.Chrome.Scroll and C.Chrome.Scroll(f) or CreateFrame("ScrollFrame",nil,f)
        scroll:SetPoint("TOPLEFT",f,"TOPLEFT",18,-76);scroll:SetPoint("BOTTOMRIGHT",f,"BOTTOMRIGHT",-36,52)
        local edit=CreateFrame("EditBox",nil,scroll)
        edit:SetSize(600,310);edit:SetMultiLine(true);edit:SetAutoFocus(false);edit:SetFontObject("GameFontHighlightSmall")
        if C.Chrome.Font then C.Chrome.Font(edit,"small") end
        edit:SetMaxLetters(100000);edit:SetScript("OnEscapePressed",function() f:Hide() end)
        scroll:SetScrollChild(edit)
        C.Chrome.Button(f,"Refresh",18,-408,100,26,function() self:RefreshText() end)
        C.Chrome.Button(f,"Capture 60 sec",130,-408,142,26,function()
            local ok,why=C.Performance:Start(60)
            if why then C:Print(why) end
            if ok then f:Hide() end
        end)
        C.Chrome.Button(f,"Stop capture",284,-408,132,26,function()
            local _,why=C.Performance:Stop();if why then C:Print(why) end;self:RefreshText()
        end)
        C.Chrome.Button(f,"Checks",428,-408,100,26,function()
            if C.AcceptancePanel then local ok=C.AcceptancePanel:Open();if ok then f:Hide() end end
        end)
        C.Chrome.Button(f,"Close",542,-408,100,26,function() f:Hide() end)
        C.Chrome.Watch(f);self.frame=f;self.edit=edit;self.scroll=scroll
        f:SetScript("OnHide",function() edit:ClearFocus() end)
    end
    self:RefreshText()
    if self.title then self.title:SetText(self.mode=="baseline" and "P39-A performance baseline" or "Utility report") end
    if not C.Chrome.Fit(self.frame) then self.frame:Hide();return false,"Not enough space to fit the utility report." end
    self.frame:Show();return true
end
function C.Public.GetUtilityReport() return R:Text() end
function C.Public.GetP39BaselineReport() return R:BaselineText() end
