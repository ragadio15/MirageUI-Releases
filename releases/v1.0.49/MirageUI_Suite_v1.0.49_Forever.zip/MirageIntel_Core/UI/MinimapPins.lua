-- Shared passive utility layer. Native Minimap retains its mask, scripts,
-- zoom, parent, input and contextual visibility. No tracking-dot scanning.
-- Radius and skill API contracts reviewed in Forever 1.60.1.70959 source;
-- their readable runtime results still require native placement acceptance.
local _,C=...
C.MinimapPins={owner="MirageIntel_Core_MinimapPins",pins={},status="NOT_INITIALIZED",elapsed=0,
    interval=.2,siteCap=32,dirty=true,nativeVerification="NOT_RUN"}
local M=C.MinimapPins
local motionAgreementYards=6
local glyphs={herb="Interface\\Icons\\INV_Misc_Herb_01",ore="Interface\\Icons\\INV_Ore_Copper_01",
    skin="Interface\\Icons\\INV_Misc_LeatherScrap_01",fish="Interface\\Icons\\INV_Misc_Fish_02",
    pool="Interface\\Icons\\INV_Misc_Fish_02",treasure="Interface\\Icons\\INV_Misc_TreasureChest01"}
local function service(name)
    return C.Services and C.Services:Get(name,1)
end
local function call(object,method,...)
    if not C.Readable(object) or (type(object)~="table" and type(object)~="userdata") then return nil,false end
    local ok,fn=pcall(function() return object[method] end)
    if not ok then return nil,false end
    return C.Call(fn,object,...)
end
-- A native texture setter may synchronously publish a newer navigation or
-- visibility state. Continue a motion paint only while its captured owner is
-- still current; never finish old artwork over a newer pass.
local function paint(current,object,method,...)
    if current and not current() then return false end
    local result=object[method](object,...)
    if current then return current() and result~=false end
    return true
end
local function atan2(y,x)
    if math.atan2 then return math.atan2(y,x) end
    if x>0 then return math.atan(y/x) end
    if x<0 then return math.atan(y/x)+(y>=0 and math.pi or -math.pi) end
    return y>0 and math.pi/2 or y<0 and -math.pi/2 or 0
end
function M:Diagnostics()
    local d=service("Diagnostics")
    if d and type(d.Set)=="function" then
        d.Set(self.owner,{status=self.status,sites=self.visibleSites or 0,route=self.routeShown==true,
            routeOnEdge=self.routeOnEdge==true,shape=self.shape,queryTruncated=self.queryTruncated==true,
            radius=self.radius,mapID=self.mapID,geometry="PUBLIC_RUNTIME_READBACK",historyStatus=self.historyStatus,
            navigationRevision=self.navigationRevision,routeIdentity=self.routeIdentity,destinationIdentity=self.destinationIdentity,siteIdentities=self.siteIdentities,
            routeStatus=self.routeStatus,nextLegID=self.nextLeg and self.nextLeg.id,routePrecision=self.routePrecision,
            routeEndpoint="MINIMAL_ARROW",navigationExclusions=self.navigationExclusions or 0,
            routeClippedByChrome=self.routeClippedByChrome==true,
            representedSites=self.representedSites or 0,clusters=self.visibleClusters or 0,
            omittedClusters=self.omittedClusters or 0,scanPending=self.scanPending==true,
            siteBudget=self.effectiveSiteCap or self.siteCap,routeSegments=self.routeLineCount or 0,routeStops=self.visibleRouteStops or 0,
            historyQueries=self.historyQueries or 0,paintPasses=self.paintPasses or 0,idlePaints=self.idlePaints or 0,
            refreshStage=self.refreshStage,refreshFailures=self.refreshFailures or 0,layerLevel=self.layerLevel,
            layerStrata=self.layerStrata,minimapMapContext=self.minimapMapContext,
            motionUpdates=self.motionPasses or 0,motionSource=self.motionPositionSource or "NOT_SAMPLED",
            motionFallback=self.motionPositionReason or "NONE",motionClock="EACH_RENDERED_FRAME",
            routeCanvas="PUBLIC_PIXEL_BOUNDS_AND_VISIBLE_CONTROL_EXCLUSIONS",
            input="PASSIVE_CHILD_NO_NATIVE_MUTATION",nativeVerification="NOT_RUN"})
    end
end
function M:HidePins()
    self.paintKey=nil
    self.motionGeometry=nil;self.motionSites=nil;self.motionDestination=nil;self.motionPose=nil
    for _,pin in ipairs(self.pins) do pin:Hide() end
    for _,label in ipairs(self.labels or {}) do label:Hide() end
    if self.route then self.route:Hide() end
    if self.routeHalo then self.routeHalo:Hide() end
    for _,pin in ipairs(self.routeStops or {}) do pin:Hide() end
    for _,line in ipairs(self.routeLines or {}) do line:Hide() end
    for _,line in ipairs(self.routeShadows or {}) do line:Hide() end
    self.routeLineCount=0;self.visibleRouteStops=0
    self.visibleSites=0;self.routeShown=false;self.routeOnEdge=false
    self.routeEndpoint=nil;self.routeClippedByChrome=false
    self.siteIdentities={};self.routeIdentity=nil;self.destinationIdentity=nil
    self.routeStatus="NO_DESTINATION"
    self.representedSites=0;self.visibleClusters=0;self.omittedClusters=0
end
function M:NewPin(route)
    local t=self.frame:CreateTexture(nil,"OVERLAY")
    t:SetTexture(route and "Interface\\AddOns\\MirageIntel_Navigate\\UI\\Arrow.tga" or "Interface\\Buttons\\WHITE8x8")
    t:SetSize(route and 16 or 5,route and 16 or 5)
    t:SetVertexColor(.93,.72,.36,route and 1 or .78)
    t:Hide()
    return t
end
function M:SyncLayer()
    if not self.frame or self.minimap~=Minimap then return end
    local level,read=call(self.minimap,"GetFrameLevel")
    local strata,have=call(self.minimap,"GetFrameStrata")
    if read and C.Number(level) and self.layerLevel~=level+2 then
        local _,written=call(self.frame,"SetFrameLevel",level+2)
        if written then self.layerLevel=level+2 end
    end
    if have and C.Text(strata) and self.layerStrata~=strata then
        local _,written=call(self.frame,"SetFrameStrata",strata)
        if written then self.layerStrata=strata end
    end
end
function M:Create()
    if self.frame and self.minimap==Minimap then self:SyncLayer();return true end
    self:HidePins()
    local map=Minimap
    if not C.Readable(map) or not map then return false,"MINIMAP_UNAVAILABLE" end
    local locked=C.CombatState()
    if locked~=false then return false,"WAITING_FOR_UNLOCKED_FRAME_CREATION" end
    local ok,frame=pcall(CreateFrame,"Frame",nil,map)
    if not ok or not frame then return false,"MINIMAP_CHILD_UNAVAILABLE" end
    local ready=pcall(function()
        frame:SetAllPoints(map)
        frame:EnableMouse(false)
        if type(frame.EnableMouseMotion)=="function" then frame:EnableMouseMotion(false) end
        if type(frame.EnableMouseClicks)=="function" then frame:EnableMouseClicks(false) end
        local level,read=call(map,"GetFrameLevel")
        if read and C.Number(level) then frame:SetFrameLevel(level+2) end
    end)
    if not ready then frame:Hide();return false,"MINIMAP_CHILD_LAYOUT_UNAVAILABLE" end
    if self.frame then self.frame:Hide();self.frame:SetScript("OnUpdate",nil) end
    self.frame=frame;self.minimap=map;self.pins={};self.labels={}
    self.layerLevel=nil;self.layerStrata=nil;self:SyncLayer()
    for i=1,self.siteCap do
        self.pins[i]=self:NewPin(false)
        if type(frame.CreateFontString)=="function" then
            local label=frame:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            label:Hide();self.labels[i]=label
        end
    end
    self.route=self:NewPin(true)
    self.routeStops={};self.routeLines={};self.routeShadows={}
    if C.MapIcons then
        -- The endpoint is a single directional arrow. No halo or circular
        -- waypoint can intrude into the minimap's zone/time header.
        for i=1,10 do self.routeStops[i]=self:NewPin(false) end
        if type(frame.CreateLine)=="function" then
            for i=1,64 do
                self.routeShadows[i]=frame:CreateLine(nil,"ARTWORK",nil,0)
                self.routeLines[i]=frame:CreateLine(nil,"ARTWORK",nil,1)
                self.routeShadows[i]:Hide();self.routeLines[i]:Hide()
            end
        end
    end
    frame:SetScript("OnHide",function()
        M:HidePins();M.dirty=true;M:CancelScan()
    end)
    frame:SetScript("OnShow",function() M.dirty=true end)
    return true
end
-- The native API explicitly permits nil outside a minimap-specific map.
-- The player's independently validated outdoor world transform remains the
-- positioning authority; optional metadata is not an activation requirement.
function M:MapContext(player)
    self.minimapMapContext="PLAYER_WORLD"
    if not C_Minimap or type(C_Minimap.GetUiMapID)~="function" then return true end
    local id,read=C.Call(C_Minimap.GetUiMapID)
    if not read then return false,"MINIMAP_MAP_UNREADABLE" end
    if id==nil then return true end
    if not C.Natural(id) then return false,"MINIMAP_MAP_UNREADABLE" end
    if id==player.mapID then self.minimapMapContext="SAME_MAP";return true end
    -- A city/subzone may have a different best UI map than its outdoor parent.
    -- Accept only a public ancestor relationship, never a same-continent guess.
    local function ancestor(child,parent)
        if not C_Map or type(C_Map.GetMapInfo)~="function" then return false end
        local seen={}
        for _=1,8 do
            if child==parent then return true end
            if seen[child] then return false end;seen[child]=true
            local info,ok=C.Call(C_Map.GetMapInfo,child)
            if not ok or type(info)~="table" or not C.Natural(info.parentMapID) then return false end
            child=info.parentMapID
        end
        return false
    end
    local world=C.Map:World(id,.5,.5)
    if world and world.continent==player.world.continent and (ancestor(player.mapID,id) or ancestor(id,player.mapID)) then
        self.minimapMapContext="RELATED_OUTDOOR_MAP";return true
    end
    return false,"MINIMAP_MAP_CONTEXT_MISMATCH"
end
-- UI-map coordinates can be delivered at a coarser cadence than the rendered
-- terrain. UnitPosition is a current public sample, never an extrapolation.
-- Admit it only against the already qualified outdoor map transform: same
-- world identifier and within six yards of that independently observed point.
-- A different coordinate system, restricted value or missing API keeps the
-- map-derived sample. This refinement is local to minimap drawing; shared
-- navigation distances, floor decisions and saved coordinates remain unchanged.
function M:MotionPlayer(player)
    self.motionPositionSource="MAP_TRANSFORM";self.motionPositionReason="UNIT_POSITION_UNAVAILABLE"
    if type(player)~="table" or type(player.world)~="table" then return player end
    local x,known,y,z,worldID=C.Call(UnitPosition,"player")
    if not known or not C.Number(x) or not C.Number(y) or not C.Number(z) or
        not C.Number(worldID) or worldID<0 or worldID%1~=0 then return player end
    if worldID~=player.world.continent then self.motionPositionReason="UNIT_WORLD_MISMATCH";return player end
    local dx,dy=x-player.world.x,y-player.world.y
    if not C.Number(dx) or not C.Number(dy) or dx*dx+dy*dy>motionAgreementYards*motionAgreementYards then
        self.motionPositionReason="UNIT_MAP_POSITION_MISMATCH";return player
    end
    self.motionPositionSource="CURRENT_UNIT_POSITION";self.motionPositionReason=nil
    return {mapID=player.mapID,floorID=player.floorID,x=player.x,y=player.y,
        world={continent=worldID,x=x,y=y,mapID=player.mapID},worldReason="MAP_VALIDATED_UNIT_POSITION"}
end
function M:Geometry()
    local map=self.minimap
    if map~=Minimap then return nil,"MINIMAP_FRAME_CHANGED" end
    local visible,known=call(map,"IsVisible")
    if not known or visible~=true then return nil,"MINIMAP_HIDDEN" end
    local alpha,readAlpha=call(map,"GetEffectiveAlpha")
    if readAlpha and C.Number(alpha) and alpha<=.01 then return nil,"MINIMAP_CONTEXT_QUIET" end
    local inside,readInstance=C.Call(IsInInstance)
    if not readInstance or inside~=false then return nil,"OUTDOOR_GEOMETRY_REQUIRED" end
    local radius,read=C.Call(C_Minimap and C_Minimap.GetViewRadius)
    if not read or not C.Number(radius) or radius<=0 or radius>100000 then return nil,"MINIMAP_RADIUS_UNREADABLE" end
    local width,wok=call(map,"GetWidth")
    local height,hok=call(map,"GetHeight")
    if not wok or not hok or not C.Number(width) or not C.Number(height) or width<16 or height<16 then
        return nil,"MINIMAP_GEOMETRY_UNREADABLE"
    end
    local rotate,rok=C.Call(C_CVar and C_CVar.GetCVarBool or GetCVarBool,"rotateMinimap")
    if not rok or type(rotate)~="boolean" then
        local raw,rread=C.Call(C_CVar and C_CVar.GetCVar or GetCVar,"rotateMinimap")
        if not rread or (raw~="0" and raw~="1") then return nil,"MINIMAP_ROTATION_UNREADABLE" end
        rotate=raw=="1"
    end
    if rotate and C_Minimap and type(C_Minimap.IsRotateMinimapIgnored)=="function" then
        local ignored,known=C.Call(C_Minimap.IsRotateMinimapIgnored)
        if known and ignored==true then rotate=false end
    end
    local facing=0
    if rotate then
        local readable
        facing,readable=C.Call(GetPlayerFacing)
        if not readable or not C.Number(facing) then return nil,"PLAYER_FACING_UNREADABLE" end
    end
    local player,why=C.Map:Player()
    if not player or not player.world then return nil,why or "PLAYER_WORLD_POSITION_UNREADABLE" end
    player.floorID=player.floorID or player.mapID
    local matched,reason=self:MapContext(player)
    if not matched then return nil,reason end
    player=self:MotionPlayer(player)
    local shape,readShape=C.Call(GetMinimapShape)
    shape=readShape and shape or "ROUND"
    if shape~="SQUARE" and shape~="ROUND" then shape="CONSERVATIVE_ROUND" end
    local geometry={player=player,radius=radius,width=width,height=height,facing=facing,shape=shape,rotate=rotate,
        cos=math.cos(facing),sin=math.sin(facing)}
    geometry.obstacles,geometry.obstacleKey=self:ReadNavigationObstacles(geometry)
    return geometry
end
function M:ReadNavigationObstacles(g)
    local main=type(MirageUI)=="table" and MirageUI.Rework and MirageUI.Rework.Minimap
    local regions,have=call(main,"GetNavigationObstacles",self.minimap)
    if not have or type(regions)~="table" then self.navigationExclusions=0;return {},"none" end
    local cx,center,cy=call(self.minimap,"GetCenter")
    local mapScale,scaled=call(self.minimap,"GetEffectiveScale")
    if not center or not scaled or not C.Number(cx) or not C.Number(cy) or not C.Number(mapScale) or mapScale<=0 then
        self.navigationExclusions=0;return {},"unreadable"
    end
    cx,cy=cx*mapScale,cy*mapScale
    local obstacles,keys={},{}
    for index,region in ipairs(regions) do
        if index>16 then break end
        local visible,shown=call(region,"IsVisible")
        if not shown then visible,shown=call(region,"IsShown") end
        if shown and visible then
            local scale,known=call(region,"GetEffectiveScale")
            if not known then
                local parent,read=call(region,"GetParent")
                if read then scale,known=call(parent,"GetEffectiveScale") end
            end
            local left,a=call(region,"GetLeft");local right,b=call(region,"GetRight")
            local top,c=call(region,"GetTop");local bottom,d=call(region,"GetBottom")
            if a and b and c and d and known and C.Number(scale) and scale>0 and
                C.Number(left) and C.Number(right) and C.Number(top) and C.Number(bottom) and right>left and top>bottom then
                local r={left=(left*scale-cx)/mapScale,right=(right*scale-cx)/mapScale,
                    top=(bottom*scale-cy)/mapScale,bottom=(top*scale-cy)/mapScale}
                if r.right>-g.width/2 and r.left<g.width/2 and r.bottom>-g.height/2 and r.top<g.height/2 then
                    obstacles[#obstacles+1]=r
                    keys[#keys+1]=string.format("%.2f:%.2f:%.2f:%.2f",r.left,r.right,r.top,r.bottom)
                end
            end
        end
    end
    self.navigationExclusions=#obstacles
    return obstacles,table.concat(keys,";")
end
-- WoW world X points north, world Y points west. UI offsets point right/up.
function M:Project(world,g,edge)
    local p=g.player.world
    if type(world)~="table" or not C.Number(world.x) or not C.Number(world.y) or world.continent~=p.continent then return nil end
    local north,west=world.x-p.x,world.y-p.y
    local x=(-west*g.cos+north*g.sin)/g.radius
    local y=(west*g.sin+north*g.cos)/g.radius
    if not C.Number(x) or not C.Number(y) then return nil end
    local inset=12 -- actual icon/arrow half-size plus a small edge clearance
    local limitX=math.max(1,g.width/2-inset);local limitY=math.max(1,g.height/2-inset)
    local px,py=x*g.width/2,y*g.height/2
    local extent=g.shape=="SQUARE" and math.max(math.abs(px)/limitX,math.abs(py)/limitY)
        or math.sqrt((px/limitX)^2+(py/limitY)^2)
    local clamped=extent>1
    if clamped then
        if not edge then return nil end
        px=px/extent;py=py/extent
    end
    return px,py,clamped
end
function M:Bounds(g)
    local id=g.player.mapID
    local basis=self.basis
    if not basis or basis.mapID~=id then
        local a=C.Map:World(id,0,0)
        local b=C.Map:World(id,1,0)
        local d=C.Map:World(id,0,1)
        if not a or not b or not d or a.continent~=b.continent or a.continent~=d.continent then return nil end
        local bx,by=b.x-a.x,b.y-a.y
        local dx,dy=d.x-a.x,d.y-a.y
        local determinant=bx*dy-by*dx
        if not C.Number(determinant) or math.abs(determinant)<.001 then return nil end
        basis={mapID=id,xPerYard=math.sqrt(dx*dx+dy*dy)/math.abs(determinant),
            yPerYard=math.sqrt(bx*bx+by*by)/math.abs(determinant)}
        self.basis=basis
    end
    -- Rotated square corners reach beyond an unrotated radius. A conservative
    -- square envelope also leaves room for movement before the next query.
    local envelope=g.shape=="SQUARE" and math.sqrt(2) or 1
    -- Current position may lead the normalized map sample slightly. Include
    -- its admitted disagreement envelope when querying history, so an icon
    -- entering the newly usable edge is not omitted by a coarse query center.
    local slack=g.player.worldReason=="MAP_VALIDATED_UNIT_POSITION" and motionAgreementYards or 0
    local dx,dy=(g.radius*envelope+slack)*basis.xPerYard,(g.radius*envelope+slack)*basis.yPerYard
    return {left=math.max(0,g.player.x-dx),right=math.min(1,g.player.x+dx),
        top=math.max(0,g.player.y-dy),bottom=math.min(1,g.player.y+dy)}
end
function M:CancelScan()
    self.scanGeneration=(self.scanGeneration or 0)+1
    if self.scanPending then local tasks=service("Tasks");if tasks then tasks.Cancel(self.owner.."_Scan") end end
    self.scanPending=false
end
function M:ClearSites(reason)
    if self.scanPending or self.lastQuery or #(self.sites or {})>0 then
        self:CancelScan();self.sites={};self.lastQuery=nil;self.siteGeneration=(self.siteGeneration or 0)+1
    end
    self.dirty=true;self.historyStatus=reason;self.queryTruncated=false
end
function M:ReadSites(g,historyRevision)
    local records=service("WorldRecords")
    if not records then return {} end
    local now=C:Now()
    local p=g.player
    local last=self.lastQuery
    local moved=not last or last.mapID~=p.mapID or not last.world or last.world.continent~=p.world.continent or
        (p.world.x-last.world.x)^2+(p.world.y-last.world.y)^2>(g.radius*.12)^2
    if not self.dirty and not moved and last and now>=last.at and last.radius==g.radius and
        last.floorID==p.floorID and last.shape==g.shape and last.ownerRevision==historyRevision then return self.sites or {} end
    local bounds=self:Bounds(g)
    if not bounds then self.sites={};self.historyStatus="MAP_BASIS_UNAVAILABLE";return self.sites end
    local query={mapID=p.mapID,owner="MirageIntel_Gather",kind="gather",visibility="minimap",bounds=bounds,limit=64}
    self:CancelScan()
    local generation=self.scanGeneration;local minimap=self.minimap
    local function current(checkPosition)
        if generation~=M.scanGeneration or M.minimap~=minimap or service("WorldRecords")~=records or
            not C.state.initialized or not C.Client.allowed or C.Storage.readOnly then return false end
        local visible,known=call(minimap,"IsVisible")
        if not known or visible~=true then return false end
        local alpha,read=call(minimap,"GetEffectiveAlpha")
        if read and C.Number(alpha) and alpha<=.01 then return false end
        local radius,valid=C.Call(C_Minimap and C_Minimap.GetViewRadius)
        if not valid or radius~=g.radius then return false end
        if not M:MapContext(p) then return false end
        if checkPosition then
            local player=C.Map:Player()
            if not player or player.mapID~=p.mapID or (player.floorID or player.mapID)~=p.floorID or not player.world or
                player.world.continent~=p.world.continent or
                (player.world.x-p.world.x)^2+(player.world.y-p.world.y)^2>(g.radius*.12)^2 then return false end
        end
        return true
    end
    local function abandon()
        if generation==M.scanGeneration then M.scanPending=false;M.dirty=true;M.lastQuery=nil end
        return false
    end
    self.historyQueries=(self.historyQueries or 0)+1
    local result,read=C.Call(records.Query,query)
    if not read or type(result)~="table" or not current(false) then abandon();return {} end
    local sites={}
    local function append(page)
    for _,record in ipairs(type(page)=="table" and page.records or {}) do
        if not record.hidden and record.showMinimap~=false and record.scope=="OUTDOOR" and record.instanceID==0 and
            (record.floorID or record.mapID)==(p.floorID or p.mapID) then
            local world=C.Map:World(record.mapID,record.x,record.y)
            local distance=world and C.Map:Measure(p,{world=world})
            if distance then sites[#sites+1]={id=record.id,category=record.category,world=world,distance=distance,
                revision=record.revision,sourceRevision=record.sourceRevision} end
        end
    end
    end
    local function sortSites()table.sort(sites,function(a,b) if a.distance~=b.distance then return a.distance<b.distance end return a.id<b.id end)end
    append(result);sortSites()
    if not current(false) then abandon();return {} end
    self.queryTruncated=type(result)=="table" and result.nextCursor~=nil
    self.historyStatus=type(result)=="table" and result.status or "RECORD_QUERY_UNAVAILABLE"
    self.lastQuery={at=now,mapID=p.mapID,floorID=p.floorID,radius=g.radius,shape=g.shape,ownerRevision=historyRevision,
        world={x=p.world.x,y=p.world.y,continent=p.world.continent}}
    local firstPage={};for i,row in ipairs(sites) do firstPage[i]=row end
    self.sites=firstPage;self.dirty=false;self.siteGeneration=(self.siteGeneration or 0)+1
    -- Process dense local histories cooperatively. The first page is available
    -- immediately; later pages may replace far/lexically earlier candidates.
    -- A changed record revision, map, bounds or generation cancels old results.
    local tasks=service("Tasks")
    if tasks and self.queryTruncated then
        local cursor=result.nextCursor;local revision=result.revision;local pages=1
        local queued,why=tasks.Queue(self.owner.."_Scan",function()
            if not current(false) then return abandon() end
            query.cursor=cursor
            M.historyQueries=(M.historyQueries or 0)+1
            local page,read=C.Call(records.Query,query)
            if not read or type(page)~="table" or page.revision~=revision or page.status=="STALE_CURSOR" or not current(false) then return abandon() end
            append(page);pages=pages+1;cursor=page.nextCursor
            if not current(false) then return abandon() end
            if cursor and pages<64 then return true end
            if not current(true) then return abandon() end
            sortSites();M.sites=sites;M.scanPending=false;M.queryTruncated=cursor~=nil
            M.siteGeneration=(M.siteGeneration or 0)+1
            M.historyStatus=page.status
            return false
        end,generation)
        self.scanPending=queued==true
        if not queued then self.historyStatus=why or "SITE_SCAN_QUEUE_UNAVAILABLE";self.dirty=true end
    end
    return self.sites
end
function M:SiteBudget()
    local api=MirageGatherAPI
    local budget=self.siteCap
    if type(api)=="table" then
        local p,ok
        if type(api.GetPreferences)=="function" then p,ok=C.Call(api.GetPreferences) end
        if not ok or type(p)~="table" then
            local status,read=C.Call(api.GetStatus)
            p=read and type(status)=="table" and status.preferences
        end
        if type(p)=="table" then
            if p.showMinimapPins==false then return 0 end
            if C.Natural(p.maxPins) then budget=math.min(budget,p.maxPins) end
        end
    end
    return budget
end
function M:Clusters(sites,g,destination)
    if C.MapIcons and type(C.MapIcons.ClusterPoints)=="function" then
        local points={}
        for _,site in ipairs(sites) do
            if not destination or (site.id~=destination.id and site.id~=destination.siteID and site.id~=destination.recordID) then
                local x,y=self:Project(site.world,g,false)
                if x then
                    local dx,dy=site.world.x-g.player.world.x,site.world.y-g.player.world.y
                    points[#points+1]={site=site,x=x,y=y,distance=dx*dx+dy*dy}
                end
            end
        end
        table.sort(points,function(a,b) if a.distance~=b.distance then return a.distance<b.distance end;return a.site.id<b.site.id end)
        local result={}
        for _,cluster in ipairs(C.MapIcons.ClusterPoints(points,24)) do
            local group={site=cluster.point.site,x=cluster.x,y=cluster.y,count=#cluster.points,mixed=false}
            for _,point in ipairs(cluster.points) do if point.site.category~=group.site.category then group.mixed=true;break end end
            result[#result+1]=group
        end
        return result
    end
    local groups,keys={},{}
    for _,site in ipairs(sites) do
        if not destination or (site.id~=destination.id and site.id~=destination.siteID and site.id~=destination.recordID) then
            local x,y=self:Project(site.world,g,false)
            if x then
                local key=(site.category or "other")..":"..math.floor(x/12)..":"..math.floor(y/12)
                local group=groups[key]
                if not group then group={site=site,x=x,y=y,count=0};groups[key]=group;keys[#keys+1]=key end
                group.count=group.count+1
                if site.distance<group.site.distance then group.site=site;group.x=x;group.y=y end
            end
        end
    end
    local result={};for _,key in ipairs(keys) do result[#result+1]=groups[key] end
    table.sort(result,function(a,b)if a.site.distance~=b.site.distance then return a.site.distance<b.site.distance end;return a.site.id<b.site.id end)
    return result
end
function M:Navigation()
    self.navigationRevision=nil;self.nextLeg=nil;self.directionTarget=nil;self.routePrecision=nil;self.overlay=nil
    local nav=service("Navigate") or MirageNavigateAPI
    if type(nav)~="table" or nav.navigationVersion~=2 or type(nav.GetNavigationSnapshot)~="function" then return nil end
    local snap,ok=C.Call(nav.GetNavigationSnapshot)
    if not ok or type(snap)~="table" then return nil end
    self.navigationRevision=snap.revision
    if snap.mode=="Pause" or snap.mode=="Off" then return nil end
    if type(nav.GetRouteOverlay)=="function" then
        local overlay,read=C.Call(nav.GetRouteOverlay)
        if read and type(overlay)=="table" and overlay.revision==snap.revision then self.overlay=overlay end
    end
    self.overlay=self.overlay or {revision=snap.revision,stops=snap.itinerary and snap.itinerary.stops or {}}
    if self.overlay.showMinimap==false then return nil end
    self.nextLeg=snap.nextLeg
    self.routePrecision=snap.route and snap.route.precision or snap.nextLeg and snap.nextLeg.precision or "DIRECT_BEARING"
    if snap.nextLeg or snap.route then self.directionTarget=snap.directionTarget
    else self.directionTarget=snap.destination end
    return snap.destination
end
-- Project without edge clamping; segment clipping belongs to the renderer.
function M:RoutePoint(stop,g,current)
    if type(stop)~="table" or stop.mapID~=g.player.mapID or
        (stop.floorID or stop.mapID)~=(g.player.floorID or g.player.mapID) or not C.Map:Valid(stop.mapID,stop.x,stop.y) then return nil end
    local key=tostring(stop.mapID)..":"..tostring(stop.x)..":"..tostring(stop.y)
    self.routeWorld=self.routeWorld or {}
    local cache=self.routeWorld
    local world=cache[key]
    if not world then
        world=C.Map:World(stop.mapID,stop.x,stop.y)
        if current and not current() then return nil end
        cache[key]=world
    end
    if not world or world.continent~=g.player.world.continent then return nil end
    local north,west=world.x-g.player.world.x,world.y-g.player.world.y
    return (-west*g.cos+north*g.sin)/g.radius,(west*g.sin+north*g.cos)/g.radius,world
end
function M:ClipRouteSegment(ax,ay,bx,by,g)
    local icons=C.MapIcons
    if not icons then return nil end
    local inset=12 -- 16px arrow, 4px breathing room; also contains the line shadow
    local x1,y1,x2,y2
    if g.shape=="SQUARE" then
        x1,y1,x2,y2=icons.ClipSegment(ax*g.width/2,ay*g.height/2,bx*g.width/2,by*g.height/2,
            {left=-math.max(1,g.width/2-inset),right=math.max(1,g.width/2-inset),
                top=-math.max(1,g.height/2-inset),bottom=math.max(1,g.height/2-inset)})
    else
        x1,y1,x2,y2=icons.ClipCircle(ax,ay,bx,by,math.max(.1,1-2*inset/math.min(g.width,g.height)))
        if x1 then x1,y1,x2,y2=x1*g.width/2,y1*g.height/2,x2*g.width/2,y2*g.height/2 end
    end
    if not x1 then return nil end
    local chrome=false
    if type(icons.ClipBeforeObstacles)=="function" then
        x1,y1,x2,y2,chrome=icons.ClipBeforeObstacles(x1,y1,x2,y2,g.obstacles,inset)
    end
    if not x1 then return nil end
    local clipped=math.abs(x2-bx*g.width/2)+math.abs(y2-by*g.height/2)>.001
    return x1,y1,x2,y2,clipped,chrome
end
function M:PaintRouteEndpoint(g,destination,current)
    if current and not current() then return false end
    local endpoint=self.routeEndpoint
    if not endpoint and self.routePrecision~="VALIDATED_GRAPH_ROUTE" and self.directionTarget then
        local x,y,world=self:RoutePoint(self.directionTarget,g,current)
        if current and not current() then return false end
        if x then
            local ax,ay,bx,by,edge,chrome=self:ClipRouteSegment(0,0,x,y,g)
            if ax then endpoint={x=bx,y=by,dx=bx-ax,dy=by-ay,edge=edge,chrome=chrome} end
            if not C.MapIcons then
                local px,py,clamped=self:Project(world,g,true)
                if px then endpoint={x=px,y=py,dx=px,dy=py,edge=clamped} end
            end
        end
    end
    if not endpoint or math.abs(endpoint.x)+math.abs(endpoint.y)<=.5 then return end
    local route=self.route
    if not paint(current,route,"ClearAllPoints") or not paint(current,route,"SetPoint","CENTER",self.frame,"CENTER",endpoint.x,endpoint.y)
        or not paint(current,route,"SetTexture","Interface\\AddOns\\MirageIntel_Navigate\\UI\\Arrow.tga")
        or not paint(current,route,"SetVertexColor",1,1,1,1) or not paint(current,route,"SetSize",16,16) then return false end
    if type(route.SetRotation)=="function" and not paint(current,route,"SetRotation",-atan2(endpoint.dx,endpoint.dy)) then return false end
    if not paint(current,route,"Show") then return false end
    self.routeShown=true;self.routeOnEdge=endpoint.edge==true
    self.routeClippedByChrome=self.routeClippedByChrome or endpoint.chrome==true
    self.routeStatus=self.routePrecision=="VALIDATED_GRAPH_ROUTE" and "VALIDATED_NEXT_LEG_PASSIVE" or "DIRECT_BEARING_PASSIVE"
    self.routeIdentity=C.Copy(self.destinationIdentity)
end
function M:RenderRoute(g,current)
    if current and not current() then return false end
    local icons=C.MapIcons;local overlay=self.overlay
    if not icons or not overlay or overlay.showMinimap==false or not self.routeLines or #self.routeLines==0 then return end
    local graph=self.routePrecision=="VALIDATED_GRAPH_ROUTE"
    local leg=self.nextLeg
    if graph and (not leg or leg.geometry~="SOURCE_POLYLINE" or type(leg.polyline)~="table") then return end
    if self.routeWorldRevision~=overlay.revision or self.routeWorldMap~=g.player.mapID then
        self.routeWorld={};self.routeWorldRevision=overlay.revision;self.routeWorldMap=g.player.mapID
    end
    local stops=graph and leg.polyline or type(overlay.stops)=="table" and overlay.stops or {}
    if not graph and #stops==0 and self.directionTarget then stops={self.directionTarget} end
    local lastX,lastY=0,0
    if graph then lastX,lastY=nil,nil end
    for index,stop in ipairs(stops) do
        if index>(graph and 32 or 12) then break end
        local x,y,world=self:RoutePoint(stop,g,current)
        if current and not current() then return false end
        -- Repeated source-polyline vertices and an arrived first stop carry
        -- no segment. Skip them rather than interpreting a zero-length clip
        -- as an obstacle which would discard the rest of the visible route.
        local segmentDX=x and lastX and (x-lastX)*g.width/2
        local segmentDY=y and lastY and (y-lastY)*g.height/2
        if segmentDX and segmentDY and segmentDX*segmentDX+segmentDY*segmentDY>=.000001 then
            local ax,ay,bx,by,edge,chrome=self:ClipRouteSegment(lastX,lastY,x,y,g)
            if ax then
                local dx,dy=bx-ax,by-ay;local length=math.sqrt(dx*dx+dy*dy)
                self.routeClippedByChrome=self.routeClippedByChrome or chrome==true
                if graph or index==1 then
                    self.routeEndpoint={x=bx,y=by,dx=dx,dy=dy,edge=edge,chrome=chrome}
                end
                local maxDashes=math.max(4,math.floor(60/math.max(1,math.min(12,#stops))))
                local count=graph and 1 or math.min(24,maxDashes,math.max(1,math.ceil(length/12)))
                for dash=0,count-1 do
                    local row=(self.routeLineCount or 0)+1
                    local line,shadow=self.routeLines[row],self.routeShadows[row]
                    if not line then break end
                    local start,finish=dash/count,(dash+(graph and 1 or .7))/count
                    local function paintLine(value,outline)
                        if not paint(current,value,"SetStartPoint","CENTER",M.frame,ax+dx*start,ay+dy*start)
                            or not paint(current,value,"SetEndPoint","CENTER",M.frame,ax+dx*finish,ay+dy*finish) then return false end
                        local colored
                        if outline then colored=paint(current,value,"SetColorTexture",.025,.02,.015,.85)
                        elseif graph or index==1 then colored=paint(current,value,"SetColorTexture",.96,.79,.36,.96)
                        else colored=paint(current,value,"SetColorTexture",.91,.55,.18,.84) end
                        if not colored then return false end
                        if type(value.SetThickness)=="function" and not paint(current,value,"SetThickness",outline and 6 or 3.5) then return false end
                        return paint(current,value,"Show")
                    end
                    if shadow and not paintLine(shadow,true) then return false end
                    if not paintLine(line,false) then return false end
                    self.routeLineCount=row
                end
                -- No disconnected line may reappear past the header, toolbar,
                -- or map boundary. The arrow terminates the visible active leg.
                if edge then break end
            else
                break
            end
            if not graph and index>1 and self.visibleRouteStops<10 then
                local px,py=self:Project(world,g,false)
                local clear=px~=nil
                for _,r in ipairs(g.obstacles or {}) do
                    if px and px>=r.left-11 and px<=r.right+11 and py>=r.top-11 and py<=r.bottom+11 then clear=false;break end
                end
                if clear then
                    local pin=self.routeStops[self.visibleRouteStops+1]
                    if pin then
                        if not paint(current,pin,"ClearAllPoints") or not paint(current,pin,"SetPoint","CENTER",self.frame,"CENTER",px,py) then return false end
                        if current then
                            if not paint(current,pin,"SetTexture",icons.Path(icons.Key(stop,"route")))
                                or not paint(current,pin,"SetVertexColor",1,1,1,1) then return false end
                        else icons.Apply(pin,stop,"route") end
                        if not paint(current,pin,"SetSize",20,20) or not paint(current,pin,"Show") then return false end
                        self.visibleRouteStops=self.visibleRouteStops+1
                    end
                end
            end
        end
        lastX,lastY=x,y
    end
end
function M:PaintIdentity(g,destination,budget)
    local target=self.directionTarget
    local fields={g.player.mapID,g.player.floorID or g.player.mapID,g.player.world.continent,
        string.format("%.4f:%.4f:%.4f:%.4f:%.4f:%.5f",g.player.world.x,g.player.world.y,g.radius,g.width,g.height,g.facing),
        g.shape,g.obstacleKey or "none",budget,self.siteGeneration or 0,tostring(self.navigationRevision),self.nextLeg and self.nextLeg.id or "",
        tostring(self.routePrecision),destination and destination.id or "",destination and destination.category or "",
        destination and destination.label or "",target and target.mapID or "",target and target.floorID or "",
        target and target.x or "",target and target.y or ""}
    for index,value in ipairs(fields) do fields[index]=tostring(value) end
    return table.concat(fields,"|")
end
function M:RefreshPass()
    if self.inWorld==false then self:HidePins();self.interval=1;self.status="WORLD_TRANSITION";return end
    local wake=self.wakeRevision or 0
    if not C.state.initialized or not C.Client.allowed or C.Storage.readOnly then
        self:HidePins();self:ClearSites("CLIENT_OR_STORAGE_UNAVAILABLE");self.status="CLIENT_OR_STORAGE_UNAVAILABLE";return
    end
    self.refreshStage="CREATE"
    local made,reason=self:Create()
    if not made then self.status=reason;self:Diagnostics();return end
    self.refreshStage="CONTENT"
    local destination=self:Navigation()
    local navigationRevision=self.navigationRevision
    local nextLegID=self.nextLeg and self.nextLeg.id
    local budget=self:SiteBudget();self.effectiveSiteCap=budget
    local records=service("WorldRecords")
    local summary=budget>0 and records and records.GetStatus()
    local history=summary and summary.owners and summary.owners.MirageIntel_Gather
    if not destination and not (history and history.count and history.count>0) then
        self:HidePins();self:ClearSites(budget==0 and "HISTORY_DISPLAY_DISABLED" or "NO_UTILITY_CONTENT")
        self.status="NO_UTILITY_CONTENT";self.interval=2;self.frame:Hide();self:Diagnostics();return
    end
    self.refreshStage="GEOMETRY"
    local g,why=self:Geometry()
    if not g then self:HidePins();self:CancelScan();self.dirty=true;self.status=why;self.interval=1;self:Diagnostics();return end
    self.frame:Show()
    self.refreshStage="HISTORY"
    self.interval=.2;self.radius=g.radius;self.mapID=g.player.mapID;self.shape=g.shape
    local sites
    if budget>0 and history and history.count>0 then sites=self:ReadSites(g,history.revision)
    else self:ClearSites(budget==0 and "HISTORY_DISPLAY_DISABLED" or "NO_LOCAL_HISTORY");sites={} end
    if wake~=(self.wakeRevision or 0) then self:HidePins();self.status="REFRESH_REQUEUED";return end
    local paintKey=self:PaintIdentity(g,destination,budget)
    if self.paintKey==paintKey then
        local latest=self:Navigation()
        if self.navigationRevision==navigationRevision and (self.nextLeg and self.nextLeg.id)==nextLegID and
            ((not latest and not destination) or (latest and destination and latest.id==destination.id and
            latest.mapID==destination.mapID and latest.x==destination.x and latest.y==destination.y)) then
            self.idlePaints=(self.idlePaints or 0)+1
            return
        end
    end
    self:HidePins()
    self.refreshStage="PAINT"
    self.paintPasses=(self.paintPasses or 0)+1
    local groups=self:Clusters(sites,g,destination)
    self.motionSites={}
    local shown=0
    for _,group in ipairs(groups) do
        if shown>=budget then break end
                local site,x,y=group.site,group.x,group.y
                shown=shown+1
                local pin=self.pins[shown]
                pin:ClearAllPoints();pin:SetPoint("CENTER",self.frame,"CENTER",x,y)
                if C.MapIcons then
                    C.MapIcons.Apply(pin,{kind="gather",category=site.category},group.mixed and "cluster" or nil)
                    pin:SetSize(group.count>1 and 22 or 20,group.count>1 and 22 or 20)
                else
                    pin:SetTexture(glyphs[site.category] or "Interface\\Buttons\\WHITE8x8")
                    pin:SetSize(group.count>1 and 11 or 8,group.count>1 and 11 or 8)
                    pin:SetVertexColor(.87,.72,.42,.9)
                end
                pin:Show()
                self.siteIdentities[shown]={id=site.id,revision=site.revision,sourceRevision=site.sourceRevision,count=group.count}
                self.motionSites[shown]={world=site.world,count=group.count,x=x,y=y,visible=true}
                self.representedSites=self.representedSites+group.count
                if group.count>1 then
                    self.visibleClusters=self.visibleClusters+1
                    local label=self.labels and self.labels[shown]
                    if label then label:ClearAllPoints();label:SetPoint("CENTER",self.frame,"CENTER",x+6,y-5)
                        label:SetText(group.count>99 and "99+" or tostring(group.count));label:Show() end
                end
    end
    self.visibleSites=shown
    self.omittedClusters=math.max(0,#groups-shown)
    -- Map/record readbacks may synchronously publish a newer player intent.
    -- Retire this frame's old route before any texture can display it.
    if destination then
        local latest=self:Navigation()
        if not latest or self.navigationRevision~=navigationRevision or (self.nextLeg and self.nextLeg.id)~=nextLegID or
            latest.id~=destination.id or latest.mapID~=destination.mapID or latest.x~=destination.x or latest.y~=destination.y then
            destination=nil;self.routeStatus="NAVIGATION_REVISION_CHANGED"
        end
    end
    if type(destination)=="table" then
        self.destinationIdentity={id=destination.id,recordID=destination.recordID,siteID=destination.siteID,
            revision=destination.revision,sourceRevision=destination.sourceRevision,navigationRevision=self.navigationRevision,
            nextLegID=self.nextLeg and self.nextLeg.id,precision=self.routePrecision}
        local target=self.directionTarget
        -- Equal continent alone cannot prove an outdoor floor/zone route.
        -- Retain shared intent, but match Wayfinder's exact-map display gate.
        if type(target)~="table" then
            self.routeStatus=self.routePrecision=="VALIDATED_GRAPH_ROUTE" and "TRANSPORT_ACTION_NO_GEOMETRY" or "DIRECTION_CONTEXT_UNAVAILABLE"
        elseif target.mapID~=g.player.mapID or (target.floorID or target.mapID)~=(g.player.floorID or g.player.mapID) then
            self.routeStatus="DESTINATION_MAP_CONTEXT_MISMATCH"
        else
            -- Rebuild from the qualified public map transform rather than
            -- projecting a possibly retained world coordinate from a floor
            -- or geometry context which has since changed.
            local world=C.Map:Valid(target.mapID,target.x,target.y) and
                C.Map:World(target.mapID,target.x,target.y) or nil
            local x,y=self:Project(world,g,true)
            self.routeStatus=x and "DESTINATION_NEAR_PLAYER" or "DESTINATION_WORLD_UNAVAILABLE"
        end
    end
    self.refreshStage="ROUTE"
    if destination then self:RenderRoute(g);self:PaintRouteEndpoint(g,destination) end
    self.status=self.routeShown and "ROUTE_AND_HISTORY_PASSIVE" or shown>0 and "HISTORICAL_SITES_PASSIVE" or
        destination and "DESTINATION_ACTION_ONLY" or "NO_LOCAL_UTILITY_CONTENT"
    if not self.routeShown and shown==0 and self.routeLineCount==0 then self.interval=1 end
    if self.routeStatus~="NAVIGATION_REVISION_CHANGED" and wake==(self.wakeRevision or 0) then self.paintKey=paintKey end
    if self.paintKey and (shown>0 or self.routeShown or self.routeLineCount>0) then
        self.motionGeometry=g;self.motionDestination=destination
        self.motionPose={x=g.player.world.x,y=g.player.world.y,facing=g.facing}
    end
    self.refreshStage="READY"
    self:Diagnostics()
end
-- Motion and content have different clocks. Reproject only the admitted,
-- bounded pin pool and cached route on each rendered frame. History queries,
-- clustering, provider snapshots and diagnostic publishing remain on the
-- slower maintenance tick. Direct public coordinates avoid tween lag or
-- invented positions after a teleport, stop or direction change.
function M:MotionPass()
    local g=self.motionGeometry
    if not g or self.refreshing or self.inWorld==false then return end
    local frame,map,sites,destination=self.frame,self.minimap,self.motionSites,self.motionDestination
    local wake=self.wakeRevision or 0
    local function current()
        return self.motionGeometry==g and self.frame==frame and self.minimap==map and map==Minimap
            and self.motionSites==sites and self.motionDestination==destination and (self.wakeRevision or 0)==wake
            and self.inWorld~=false and C.state.initialized and C.Client.allowed and not C.Storage.readOnly
    end
    if not C.state.initialized or not C.Client.allowed or C.Storage.readOnly or self.minimap~=Minimap then
        self:HidePins();return
    end
    local visible,known=call(self.minimap,"IsVisible")
    if not current() then return false end
    local alpha,read=call(self.minimap,"GetEffectiveAlpha")
    if not current() then return false end
    if not known or visible~=true or read and C.Number(alpha) and alpha<=.01 then self:HidePins();return end
    local player=C.Map:Player()
    if not current() then return false end
    if not player or not player.world or player.mapID~=g.player.mapID or
        (player.floorID or player.mapID)~=(g.player.floorID or g.player.mapID) or player.world.continent~=g.player.world.continent then
        self:HidePins();self.elapsed=self.interval;return
    end
    player=self:MotionPlayer(player)
    if not current() then return false end
    local facing=0
    if g.rotate then
        local readable
        facing,readable=C.Call(GetPlayerFacing)
        if not current() then return false end
        if not readable or not C.Number(facing) then self:HidePins();self.elapsed=self.interval;return end
    end
    -- A callback can retire this geometry while native coordinates are read.
    if not current() then return false end
    local pose=self.motionPose
    if pose and pose.x==player.world.x and pose.y==player.world.y and pose.facing==facing then return end
    g.player=player;g.facing=facing;g.cos=math.cos(facing);g.sin=math.sin(facing)
    self.motionPose={x=player.world.x,y=player.world.y,facing=facing}
    self.motionPasses=(self.motionPasses or 0)+1
    for i,row in ipairs(sites or {}) do
        local x,y=self:Project(row.world,g,false)
        local pin,label=self.pins[i],self.labels and self.labels[i]
        if x then
            if row.x~=x or row.y~=y then
                if not paint(current,pin,"ClearAllPoints") or not paint(current,pin,"SetPoint","CENTER",frame,"CENTER",x,y) then return false end
                if label and row.count>1 and (not paint(current,label,"ClearAllPoints")
                    or not paint(current,label,"SetPoint","CENTER",frame,"CENTER",x+6,y-5)) then return false end
                row.x=x;row.y=y
            end
            if not row.visible then
                if not paint(current,pin,"Show") then return false end
                if label and row.count>1 and not paint(current,label,"Show") then return false end
            end
            row.visible=true
        else
            if row.visible then
                if not paint(current,pin,"Hide") then return false end
                if label and not paint(current,label,"Hide") then return false end
            end
            row.visible=false
        end
    end
    if destination then
        local oldLines,oldStops=self.routeLineCount or 0,self.visibleRouteStops or 0
        self.routeLineCount=0;self.visibleRouteStops=0;self.routeEndpoint=nil;self.routeClippedByChrome=false
        self.routeShown=false;self.routeOnEdge=false
        if self:RenderRoute(g,current)==false or self:PaintRouteEndpoint(g,destination,current)==false then return false end
        if not self.routeShown and self.route and not paint(current,self.route,"Hide") then return false end
        for i=self.routeLineCount+1,oldLines do
            if self.routeLines[i] and not paint(current,self.routeLines[i],"Hide") then return false end
            if self.routeShadows[i] and not paint(current,self.routeShadows[i],"Hide") then return false end
        end
        for i=self.visibleRouteStops+1,oldStops do
            if self.routeStops[i] and not paint(current,self.routeStops[i],"Hide") then return false end
        end
    end
end
function M:Motion()
    local g=self.motionGeometry
    if not g or self.motionPainting then return end
    self.motionPainting=true
    local ok,completed=pcall(self.MotionPass,self)
    self.motionPainting=false
    if not ok or completed==false then
        -- A newer successful refresh owns its own paint. Only the old current
        -- geometry may be retired after a failed/refused setter.
        if self.motionGeometry==g then
            self:HidePins();self.elapsed=self.interval;self.motionFailures=(self.motionFailures or 0)+1
        elseif not ok then self.motionFailures=(self.motionFailures or 0)+1 end
    end
end
function M:Refresh()
    if self.refreshing then self.pendingWake=true;return end
    self.refreshing=true
    local ok=pcall(self.RefreshPass,self)
    self.refreshing=false
    if not ok then
        self.refreshFailures=(self.refreshFailures or 0)+1
        self:HidePins();self:CancelScan();self.dirty=true;self.status="MINIMAP_REFRESH_UNAVAILABLE";self.interval=1;self:Diagnostics()
    end
    if self.pendingWake then self.pendingWake=false;self.elapsed=self.interval end
end
function M:Wake(historyChanged)
    self.wakeRevision=(self.wakeRevision or 0)+1;self.paintKey=nil
    if historyChanged~=false then self.dirty=true;self:CancelScan() end
    if self.refreshing then self.pendingWake=true;return end
    local ok=self:Create()
    if ok then self.frame:Show();self:Refresh() end
end
function M:Initialize()
    if self.initialized then return end
    self.initialized=true
    C.Hub:Subscribe("WORLD_RECORDS_CHANGED",self.owner,function(event)
        if type(event)~="table" or not event.owner or event.owner=="MirageIntel_Gather" then M:Wake() end
    end)
    C.Hub:Subscribe("NAV_SESSION_CHANGED",self.owner,function() M:Wake(false) end)
    local events=CreateFrame("Frame")
    self.events=events
    -- Keep the heartbeat outside the native minimap's visibility ancestry.
    -- A child OnUpdate cannot repair its own concealment, deferred creation or
    -- a native reparent/reveal. Only owned regions are shown by this updater.
    events:SetScript("OnUpdate",function(_,dt)
        if not C.Number(dt) or dt<0 then return end
        M:Motion()
        M.elapsed=M.elapsed+math.min(dt,.25)
        if M.elapsed<M.interval then return end
        M.elapsed=0
        M:Refresh()
    end)
    for _,event in ipairs({"PLAYER_ENTERING_WORLD","PLAYER_LEAVING_WORLD","ZONE_CHANGED_NEW_AREA",
        "MINIMAP_UPDATE_ZOOM","CVAR_UPDATE","PLAYER_REGEN_ENABLED","ADDON_LOADED"}) do pcall(events.RegisterEvent,events,event) end
    events:SetScript("OnEvent",function(_,event,cvar)
        if event=="CVAR_UPDATE" and cvar~="rotateMinimap" and cvar~="minimapZoom" and cvar~="minimapInsideZoom" then return end
        if event=="PLAYER_LEAVING_WORLD" then
            M.inWorld=false;M:HidePins();M:CancelScan();if M.frame then M.frame:Hide() end;M.status="WORLD_TRANSITION";M.basis=nil
        else
            if event=="PLAYER_ENTERING_WORLD" then M.inWorld=true end
            if event=="PLAYER_ENTERING_WORLD" or event=="ZONE_CHANGED_NEW_AREA" then M.basis=nil;M.lastQuery=nil;M.routeWorld=nil end
            local ok=pcall(M.Wake,M)
            if not ok then M:HidePins();M.status="MINIMAP_REFRESH_UNAVAILABLE";M:Diagnostics() end
        end
    end)
    self:Wake()
end
