local _,C=...
-- This is an API-source qualification manifest, not a set of inferred roads.
-- The first live graph contains only bookings which the open native flight
-- master reports as Current -> Reachable. A booking may contain several
-- native flight hops; its air path and elapsed time are not supplied here.
C.TravelGraphSources={
    NATIVE_TAXI_71037={
        owner="MirageIntel_Core_Taxi",revision="734f065329cff4992835b01a84f210a297db91b6",
        sourceURL="https://github.com/Gethe/wow-ui-source/blob/734f065329cff4992835b01a84f210a297db91b6/Interface/AddOns/Blizzard_APIDocumentationGenerated/TaxiMapDocumentation.lua",
        companionURL="https://github.com/Gethe/wow-ui-source/blob/734f065329cff4992835b01a84f210a297db91b6/Interface/AddOns/Blizzard_FlightMap/FM_FlightPathDataProvider.lua",
        reviewedBuilds={['70959']=true,['71037']=true},
        qualification="NATIVE_API_SOURCE_REVIEWED",evidenceKind="NATIVE_OPEN_MAP_REACHABLE",
        modes={FLIGHT=true},costBases={QUALIFIED_EDGE_COUNT=true},
        access="NATIVE_CURRENT_REACHABLE",geometry="NOT_SUPPLIED",scope="LIVE_TAXIMAP",
        coverage="Current flight master to native-reachable destinations while its map remains open",
        limitation="Booking connectivity only; no walking approaches, flight trajectory, fare or travel-time estimate",
        nativeVerification="NOT_RUN",
    },
}
