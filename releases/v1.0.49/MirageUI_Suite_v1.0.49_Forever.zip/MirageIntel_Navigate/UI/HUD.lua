local _,N=...
-- Guidance is presented inside MirageUI's minimap header. This module supplies
-- a small read-only snapshot; it owns no floating frame or cursor-arrow lease.
N.HUD={}
local H=N.HUD
local states={PAUSED="Navigation paused",OFF="Navigation off",NO_DESTINATION="No destination",
    STARTING="Starting navigation",NO_POSITION="Position unavailable",NO_FACING="Direction unavailable",
    OTHER_MAP_OR_FLOOR="Continue on the next map",TRANSPORT_ACTION_REQUIRED="Take transport to the next stop",
    NO_DIRECTION_GEOMETRY="Open the map for the next step",REVALIDATING="Updating destination",
    PLAYER_DEAD="Navigation resumes after resurrection",PLAYER_ON_TAXI="Travelling by flight path",
    PLAYER_STATE_UNREADABLE="Player status unavailable"}
function H:Hide()
    if self.frame then self.frame:Hide() end
    if N.Session then N.Session:ReleaseRenderer("Wayfinder") end
end
function H:Snapshot(player,hasObservation)
    local result={schemaVersion=1,status="STARTING",title="Wayfinder",detail=states.STARTING,active=false}
    if not N.Controller or not N.Controller:Ready() then return result end
    local conf=N.Storage.account
    if N.Storage.readOnly then result.status="READ_ONLY";result.detail="Navigation unavailable";return result end
    if not conf or conf.showHUD==false then result.status="HIDDEN";result.detail="";return result end
    local active=N.active
    local target=N.Session and N.Session.directionTarget or active
    local navigationRevision=N.state.navigationRevision
    local guidance=N.Guidance and N.Guidance:Snapshot(player,hasObservation)
    -- A provider read can publish a different destination. Never combine an
    -- old title with the newly measured direction/distance.
    local currentTarget=N.Session and N.Session.directionTarget or N.active
    if active~=N.active or target~=currentTarget or navigationRevision~=N.state.navigationRevision then
        result.status="REVALIDATING";result.detail=states.REVALIDATING;return result
    end
    if not guidance then result.detail="Navigation unavailable";return result end
    result.status=guidance.status
    if guidance.status=="REVALIDATING" then result.detail=states.REVALIDATING;return result end
    local label=target and target.label
    if type(label)=="string" and #label>0 then result.title=label end
    result.detail=states[guidance.status] or "Waiting for navigation"
    result.destinationID=guidance.destinationID;result.destinationRevision=guidance.destinationRevision
    result.revision=guidance.revision;result.sampledAt=guidance.sampledAt
    if (guidance.status=="GUIDING" or guidance.status=="NEAR_DESTINATION") and target
        and active and guidance.destinationRevision==active.revision and N:Number(guidance.distance) and guidance.distance>=0 then
        -- The minimap has a single guidance line. Quest stage remains in the
        -- quest log/map; the header reserves its trailing lane for distance.
        result.detail=string.format("%.0f yards",guidance.distance)
        result.distance=guidance.distance;result.active=true
        if N:Number(guidance.relativeAngle) then result.angle=guidance.relativeAngle end
    end
    return result
end
function H:Update(player,hasObservation)
    self:Hide()
    self.header=self:Snapshot(player,hasObservation)
end
