local _,N=...
N.UI={view="journey",page=1}
local U=N.UI
local chrome=N.core and N.core.Chrome
local function text(parent,x,y,width,role)
    local t=parent:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    t:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y);t:SetWidth(width);t:SetJustifyH("LEFT")
    if chrome then chrome.Font(t,role or "body");chrome.Tint(t,role=="title" and "secondary" or role=="small" and "muted" or "text") end
    return t
end
local function button(parent,label,x,y,width,fn)
    if chrome then return chrome.Button(parent,label,x,y,width,28,fn) end
    local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
    b:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y);b:SetSize(width,28);b:SetText(label);b:SetScript("OnClick",fn);return b
end
local function choose(owner,values,current,fn)
    if not (chrome and chrome.Choose) then return false end
    local account,character=N.Storage.account,N.Storage.character
    return chrome.Choose(owner,values,current,function(value)
        if N.Storage.account~=account or N.Storage.character~=character or N.Storage.readOnly or N:InCombat() then return end
        fn(value)
    end)
end
local function sameRow(a,b)
    if type(a)~="table" or type(b)~="table" then return false end
    for key,value in pairs(a) do if b[key]~=value then return false end end
    for key,value in pairs(b) do if a[key]~=value then return false end end
    return true
end
local function retireRow(button)
    button.rowBinding=nil
    if button.rowPress~=nil then button.rowPress=false end
end
function U:RowBinding(index)
    local entry=self.entries[index];local row=entry and entry.candidate
    if not row then return nil end
    return {account=N.Storage.account,character=N.Storage.character,view=self.view,mode=N.state.mode,
        id=row.id,kind=entry.kind,siteID=row.siteID,questID=row.questID,nodeID=row.nodeID,taxiNodeID=row.taxiNodeID,
        mapID=row.mapID,floorID=row.floorID,x=row.x,y=row.y}
end
function U:RowClickAllowed(button,index,mouse,pressed)
    if not N.state.clientAllowed or N.Storage.readOnly or N:InCombat() or self.view~="journey" or
        not self.frame:IsShown() or not button:IsShown() or not button:IsEnabled() or
        not sameRow(button.rowBinding,self:RowBinding(index)) then return false end
    return pressed==nil or (pressed~=false and pressed.binding==button.rowBinding and pressed.mouse==mouse)
end
function U:BindRows()
    for index,entry in ipairs(self.entries) do
        local button=entry.pin
        local binding=button:IsShown() and self:RowBinding(index) or nil
        if not sameRow(button.rowBinding,binding) then retireRow(button);button.rowBinding=binding end
    end
end
local function result(ok,why)
    if ok then U.message=nil;N.Controller:Refresh(true)
    else U.message=U:Reason(why);U:Update() end
end
local interactionManualText={SHIFT_BYPASS="Shift bypass: finish this conversation yourself.",
        CHOOSE_REWARD_IN_QUEST_WINDOW="Choose your reward and complete the quest in its window.",
        MONEY_CONFIRMATION_REQUIRED="Review the money cost and confirm in the quest window.",
        CURRENCY_CONFIRMATION_REQUIRED="Review the currency cost and confirm in the quest window.",
        ITEM_CONFIRMATION_REQUIRED="Review the required items and confirm in the quest window.",
        REPEATABLE_MANUAL="Repeatable quests need your input in the quest window.",
        QUEST_NOT_COMPLETE="Finish this quest's objectives before turning it in.",
        NATIVE_ACCEPT_CONFIRMATION="Review the acceptance confirmation in the quest window."}
local interactionReadyState={IDLE=true,SETTINGS_CHANGED=true,QUEST_PANEL_PENDING=true,QUEST_PANEL_TRANSITION=true,
        ACTION_REQUESTED=true,NO_AUTOMATIC_QUEST=true,CONVERSATION_CLOSED=true,NATIVE_AUTO_ACCEPT=true,
        ALREADY_ACCEPTED=true,QUEST_ALREADY_FINISHED=true,AUTO_ACCEPT_OFF=true,AUTO_TURN_IN_OFF=true}
function U:QuestInteractionSummary()
    local interaction=N.QuestInteraction
    if not interaction or not N.state.clientAllowed or N.Storage.readOnly then
        return "Quest interaction is unavailable for this session. Use the quest window."
    end
    local pref=interaction:Preferences()
    if not pref.autoAccept and not pref.autoTurnIn then
        return "Automatic quest interaction is off. Use the quest window as usual."
    end
    if N:InCombat() then return "Quest interaction pauses during combat. Use the quest window if needed." end
    local state=interaction.status
    if interactionManualText[state] then return interactionManualText[state] end
    if state and not interactionReadyState[state] then return "This conversation needs your input in the quest window." end
    if not pref.autoTurnIn then return "Quests are accepted automatically. Turn in completed quests yourself." end
    if not pref.autoAccept then return "Completed quests turn in automatically. Accept new quests yourself." end
    return "Normal quests continue automatically during an NPC conversation."
end
local messages={PLAYER_DEAD="Your route resumes when you revive.",PLAYER_ON_TAXI="Your route resumes after your flight.",
    CLIENT_OR_COMBAT_UNAVAILABLE="Try again after combat.",BAGS_FULL="Make room in your bags to continue gathering.",
    PROFESSION_REQUIRED="Choose a resource for a learned profession.",PAUSED="Resume whenever you're ready.",
    OFF="Turn navigation on in Settings.",NO_DESTINATION="Choose a location on the map.",
    EXPLORE_AREA="Explore, accept a quest, or choose a destination on your map.",
    GATHER_SITE_SCAN_PENDING="Finding your next gathering stop…",PLAYER_SKIPPED="Moving to the next stop."}
function U:Reason(code)
    if messages[code] then return messages[code] end
    if type(code)=="string" and code:find(" ") then return code end
    return "Choose another stop or try again shortly."
end
function U:DestinationSummary(d)
    if N.state.mode=="Pause" then return "Navigation paused","Resume whenever you're ready." end
    if N.state.mode=="Off" then return "Navigation is off","Turn navigation on in Settings." end
    if N.state.suspended then return "Journey on hold",self:Reason(N.state.suspended) end
    if not d then return "Explore your area",messages.EXPLORE_AREA end
    local info=d.kind=="gather" and "Gathering stop" or d.stage=="READY_FOR_TURN_IN" and "Quest turn-in" or d.stage=="QUEST_GIVER" and "Check quest giver" or d.questID and "Quest objective" or "Your destination"
    if d.status=="NEAR_DESTINATION" then return d.label,d.kind=="gather" and "Search this area for the resource." or d.stage=="QUEST_GIVER" and "Speak to the quest giver to check availability." or d.questID and "You have reached the quest area." or "You have reached your destination." end
    if d.precision=="VALIDATED_GRAPH_ROUTE" then return d.label,d.instruction or "Choose this destination at the flight master." end
    if N:Number(d.distance) then info=info..string.format("  ·  %.0f yd",d.distance)
    else
        local data,ok=N:SafeCall(C_Map and C_Map.GetMapInfo,d.mapID)
        local name=ok and N:Text(N:Field(data,"name"));if name then info=info.."  ·  "..name end
    end
    return d.label or "Your destination",info
end
function U:SelectionDetail(d)
    if not d then return "" end
    if d.intentOrigin=="PLAYER_EXPLICIT" then return "Following your selected destination" end
    if d.selectionTier=="TRACKED_QUEST" then return "Following your tracked quest" end
    if d.selectionTier=="GATHER_FALLBACK" then return "Gathering along the way" end
    if d.selectionTier=="QUEST_FALLBACK" then return "Continuing with nearby quests" end
    if d.policyReason=="FINISH_LOCAL_WORK_BEFORE_MAP_RETURN" then return "Finish nearby work before returning to another area" end
    if d.visitOnly then return "Native quest-giver marker · availability checked when you speak" end
    if d.policyReason=="QUEST_GIVERS_ALONG_THE_WAY" then return "Collect quests along your route" end
    if d.clusterSize and d.clusterSize>1 then return d.clusterSize.." quests in this area" end
    if N.Planner.deferredReturns and next(N.Planner.deferredReturns) and d.stage~="READY_FOR_TURN_IN" then return "Finish nearby work before returning for turn-ins" end
    if N:Number(d.progress) then return string.format("Quest progress  %.0f%%",100*d.progress) end
    return ""
end
function U:Rows(player,snapshot)
    local rows={};snapshot=snapshot or N.Session:Snapshot()
    for i,row in ipairs(snapshot.itinerary and snapshot.itinerary.stops or {}) do
        local d=N.active and row.id==N.active.id and N.active.distance
        rows[#rows+1]={item=row,kind=row.kind=="gather" and "gather" or row.questID and "quest" or "destination",current=i==1,
            text=(i==1 and "Now · " or (i..". "))..(row.label or "Destination"),
            detail=(row.kind=="gather" and "Gathering" or row.stage=="READY_FOR_TURN_IN" and "Turn in" or row.stage=="QUEST_GIVER" and "Check quest giver" or row.questID and "Quest" or "Location")..
                (d and string.format(" · %.0f yd",d) or string.format(" · %.1f, %.1f",row.x*100,row.y*100))}
    end
    return rows
end
function U:JourneyRows(player,snapshot) return self:Rows(player,snapshot) end
function U:JourneySummary(snapshot)
    local stops=snapshot and snapshot.itinerary and snapshot.itinerary.stops or {}
    local summary=#stops==0 and "Your route updates as you play" or (#stops..(#stops==1 and " stop" or " stops").." · updates automatically")
    local p=snapshot and snapshot.progress
    if p and snapshot.destination and snapshot.destination.kind=="gather" then
        local counts={#stops.." stops"}
        if (p.castCompletions or 0)>0 then counts[#counts+1]=p.castCompletions.." completed casts" end
        if (p.confirmedHarvests or 0)>0 then counts[#counts+1]=p.confirmedHarvests.." loot confirmed" end
        if (p.skipped or 0)>0 then counts[#counts+1]=p.skipped.." skipped" end
        if #counts>1 then return table.concat(counts," · ") end
    end
    return summary
end
function U:OpenCompanion(name)
    if not N.state.clientAllowed or N.Storage.readOnly or N:InCombat() then return false,"CLIENT_OR_COMBAT_UNAVAILABLE" end
    local api=name=="Gather" and MirageGatherAPI or MirageMapAPI
    local account=N.Storage.account
    if type(api)~="table" or api.apiVersion~=1 or type(api.Open)~="function" then return false,"The companion is not available." end
    local ok,called,why=N:SafeCall(api.Open)
    if not called or not ok then return false,why or "The companion could not open." end
    if N.state.clientAllowed and not N.Storage.readOnly and not N:InCombat() and account==N.Storage.account then self.frame:Hide() end
    return true
end
function U:FocusRow(index)
    if not N.state.clientAllowed or N.Storage.readOnly or N:InCombat() then return false,"CLIENT_OR_COMBAT_UNAVAILABLE" end
    local entry=self.entries[index];local current=entry and entry.candidate
    if not current then return false,"The selected stop is no longer available." end
    if entry.kind=="flight" then return MirageNavigateAPI.SelectFlightDestination(current.nodeID or current.taxiNodeID) end
    if entry.kind=="gather" then
        local api=MirageGatherAPI
        local account,character,revision,mode=N.Storage.account,N.Storage.character,N.state.navigationRevision,N.state.mode
        if type(api)~="table" or api.apiVersion~=1 or type(api.SelectDestination)~="function" then return false,"Gather Mate is not available." end
        local record,read=N:SafeCall(api.GetSiteRecord,current.siteID)
        if not read or type(record)~="table" or record.hidden or record.mapID~=current.mapID or
            (record.floorID or record.mapID)~=(current.floorID or current.mapID) or record.x~=current.x or record.y~=current.y then
            return false,"This site changed. Refresh the journey before selecting it."
        end
        if N:InCombat() or N.Storage.readOnly or not N.state.clientAllowed or self.entries[index].candidate~=current or MirageGatherAPI~=api or
            N.Storage.account~=account or N.Storage.character~=character or N.state.navigationRevision~=revision or N.state.mode~=mode then
            return false,"The journey changed. Select the stop again."
        end
        local ok,called,why=N:SafeCall(api.SelectDestination,current.siteID)
        return called and ok==true,why or (not called and "Gather Mate is unavailable.") or nil
    end
    if entry.kind=="quest" then
        if current.stage=="QUEST_GIVER" then
            local scanned=N.Quest:Refresh(N.map:Player())
            if not scanned then return false,"Quest information is changing. Try Focus again." end
            for _,row in ipairs(N.candidates) do
                if row.questID==current.questID and row.stage=="QUEST_GIVER" and row.mapID==current.mapID and row.x==current.x and row.y==current.y then
                    return N.API:Request("manual",row,{userInitiated=true})
                end
            end
            return false,"The quest-giver marker changed. Refresh the route."
        end
        return N.API:PinCandidate(current.questID)
    end
    return false,"Your explicit destination is already selected."
end
function U:Initialize() end
function U:Create()
    if self.frame or not UIParent then return end
    local f=CreateFrame("Frame","MirageIntelNavigatePanel",UIParent,"BackdropTemplate")
    f:SetSize(620,620);f:SetPoint("CENTER",UIParent,"CENTER",0,15);f:SetFrameStrata("DIALOG");f:SetClampedToScreen(true)
    if chrome then chrome.Panel(f) else
        f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8x8",edgeFile="Interface\\Buttons\\WHITE8x8",edgeSize=1})
        f:SetBackdropColor(.035,.035,.04,.97);f:SetBackdropBorderColor(.26,.24,.20,1)
    end
    f:EnableMouse(true);f:SetMovable(true);f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart",function(self)self:StartMoving()end);f:SetScript("OnDragStop",function(self)self:StopMovingOrSizing()end)
    local title=text(f,20,-18,470,"title");title:SetText("Wayfinder")
    if chrome and chrome.Heading then chrome.Heading(f,title,20,-18,"navigate") end
    button(f,"Close",520,-14,80,function()f:Hide()end)
    self.status=text(f,20,-51,580,"small")
    self.modeButtons={}
    self.modeButtons[1]=button(f,"Automatic",20,-78,188,function()result(N.Storage:SetMode("Auto"))end)
    self.modeButtons[2]=button(f,"Gathering",216,-78,188,function()result(N.Session:StartGather({userInitiated=true}))end)
    self.modeButtons[3]=button(f,"Pause",412,-78,188,function()
        if N.state.mode=="Pause" then result(N.Session:Resume()) else result(N.Session:Pause()) end
    end)
    local card=CreateFrame("Frame",nil,f,"BackdropTemplate");card:SetPoint("TOPLEFT",f,"TOPLEFT",20,-120);card:SetSize(580,92)
    if chrome then chrome.Panel(card,"hud") end
    self.destination=text(card,14,-12,552,"title");self.distance=text(card,14,-42,552);self.explanation=text(card,14,-66,552,"small")
    if chrome then chrome.OneLine(self.destination);chrome.OneLine(self.distance);chrome.OneLine(self.explanation) end
    self.tabs={}
    for i,row in ipairs({{"Route","journey"},{"Settings","settings"},{"Quest interaction","quests"}}) do
        local b=button(f,row[1],20+(i-1)*196,-226,188,function()U.view=row[2];U.message=nil;U:Update()end)
        b.view=row[2];self.tabs[i]=b
    end
    self.route=CreateFrame("Frame",nil,f);self.route:SetPoint("TOPLEFT",f,"TOPLEFT",20,-266);self.route:SetSize(580,300)
    self.journey=text(self.route,0,0,580,"small")
    self.entries={}
    for i=1,6 do
        local y=-27-(i-1)*39
        local hit=CreateFrame("Frame",nil,self.route,"BackdropTemplate");hit:SetPoint("TOPLEFT",self.route,"TOPLEFT",0,y);hit:SetSize(580,36)
        if chrome then chrome.Panel(hit,"hud") end
        local title=text(hit,9,-4,453);local detail=text(hit,9,-21,453,"small")
        if chrome then chrome.OneLine(title);chrome.OneLine(detail) end
        local focusButton=button(hit,"Focus",482,-4,90,function(self,mouse)
            if not U:RowClickAllowed(self,i,mouse,self.rowPress) then self.rowPress=false;return end
            self.rowPress=nil;result(U:FocusRow(i))
        end)
        focusButton:HookScript("OnMouseDown",function(self,mouse)
            self.rowPress=U:RowClickAllowed(self,i,mouse) and {binding=self.rowBinding,mouse=mouse} or false
        end)
        focusButton:HookScript("OnHide",retireRow)
        self.entries[i]={text=title,detail=detail,pin=focusButton,hit=hit}
    end
    self.questCaption=text(self.route,8,-48,564);self.questCaption:SetHeight(90)
    self.previous=button(self.route,"Previous",0,-269,90,function()U.page=math.max(1,U.page-1);U:Update()end)
    self.next=button(self.route,"Next",98,-269,90,function()U.page=U.page+1;U:Update()end)
    self.pageLabel=text(self.route,204,-277,370,"small")
    self.settings=CreateFrame("Frame",nil,f);self.settings:SetPoint("TOPLEFT",f,"TOPLEFT",20,-266);self.settings:SetSize(580,300)
    local heading=text(self.settings,0,0,580,"small");heading:SetText("DISPLAY")
    self.settingsButtons={}
    local function toggle(label,key,y,x,width)
        local b=button(self.settings,label,x or 0,y,width or 580,function()
            local a=N.Storage.account or {}
            if key=="showHUD" then result(N.Storage:SetHUD(not a.showHUD))
            else result(MirageNavigateAPI.SetRoutePreference(key,not a[key])) end
        end)
        self.settingsButtons[#self.settingsButtons+1]={button=b,key=key,label=label};return b
    end
    self.hud=toggle("Minimap guidance","showHUD",-24)
    toggle("World map route","showMapRoute",-58,0,286);toggle("Minimap route","showMinimapRoute",-58,294,286)
    self.routingHeading=text(self.settings,0,-103,580,"small");self.routingHeading:SetText("AUTOMATIC ROUTING")
    self.gatherFallback=toggle("Gather after quests","gatherFallback",-127,0,286)
    self.finishNearby=button(self.settings,"",294,-127,286,function()
        result(N.Planner:SetPreferences({finishNearby=not N.Planner:Preferences().finishNearby}))
    end)
    self.turnIns=button(self.settings,"",0,-161,286,function()
        result(N.Planner:SetPreferences({preferTurnIns=not N.Planner:Preferences().preferTurnIns}))
    end)
    self.routeLength=button(self.settings,"",0,-127,580,function(owner)
        if chrome and chrome.Choose then choose(owner,{{4,"4 stops"},{8,"8 stops"},{12,"12 stops"}},N.Planner:Preferences().maxStops,function(value)
            local ok,why=N.Planner:SetPreferences({maxStops=value})
            if ok then ok,why=N.Session:SetSettings({circuitStops=value}) end
            result(ok,why)
        end) end
    end)
    self.stability=button(self.settings,"",0,-161,286,function(owner)
        local steady=N.Planner:Preferences().holdSeconds>=10
        if chrome and chrome.Choose then choose(owner,{{true,"Steady"},{false,"Responsive"}},steady,function(value)
            result(N.Planner:SetPreferences({holdSeconds=value and 10 or 5,switchImprovement=value and .30 or .20}))
        end) end
    end)
    self.dwell=button(self.settings,"",294,-161,286,function(owner)
        if chrome and chrome.Choose then choose(owner,{{20,"20 seconds"},{30,"30 seconds"}},N.Session:Settings().dwellSeconds,function(value)
            result(N.Session:SetSettings({dwellSeconds=value}))
        end) end
    end)
    self.off=button(self.settings,"",0,-194,286,function()result(N.Storage:SetMode(N.state.mode=="Off" and "Auto" or "Off"))end)
    self.gather=button(self.settings,"Gathering settings",294,-194,286,function()result(U:OpenCompanion("Gather"))end)
    self.advancedRouting=button(self.settings,"Advanced routing",0,-237,580,function()
        U.showRoutingAdvanced=not U.showRoutingAdvanced;U:Update()
    end)
    local saveHint=text(self.settings,0,-278,580,"small");saveHint:SetText("Changes save immediately.")
    self.questSettings=CreateFrame("Frame",nil,f);self.questSettings:SetPoint("TOPLEFT",f,"TOPLEFT",20,-266);self.questSettings:SetSize(580,300)
    local qheading=text(self.questSettings,0,0,580,"small");qheading:SetText("WHEN YOU SPEAK TO A QUEST GIVER")
    self.questButtons={}
    for index,entry in ipairs({{"Accept quests","autoAccept"},{"Turn in completed quests","autoTurnIn"},{"Include repeatable quests","repeatable"}}) do
        local key,label=entry[2],entry[1]
        local b=button(self.questSettings,"",0,-24-(index-1)*36,580,function()
            local pref=N.QuestInteraction and N.QuestInteraction:Preferences() or {}
            result(MirageNavigateAPI.SetQuestInteractionPreferences({[key]=not pref[key]}))
        end)
        self.questButtons[#self.questButtons+1]={button=b,key=key,label=label}
    end
    self.includeGivers=button(self.questSettings,"",0,-132,580,function()
        result(N.Planner:SetPreferences({includeGivers=not N.Planner:Preferences().includeGivers}))
    end)
    local help=text(self.questSettings,0,-174,580);help:SetHeight(72)
    help:SetText("Hold Shift before speaking to handle that conversation yourself. Choose rewards and confirm money, currency or non-quest-item costs in the quest window. These controls work even when navigation is paused or off.")
    self.questStatus=text(self.questSettings,0,-260,580,"small");self.questStatus:SetHeight(36)
    self.clear=button(f,"Clear focus",20,-576,188,function()
        N.requests.gather=nil;result(N.Storage:Pin(nil))
    end)
    self.skip=button(f,"Skip stop",216,-576,188,function()result(MirageNavigateAPI.SkipDestination())end)
    self.mapButton=button(f,"Open map",412,-576,188,function()
        if N.active and type(MirageMapAPI)=="table" and type(MirageMapAPI.ShowUtilityRecord)=="function" then
            local r=N._copy(N.active);r.kind=r.kind or "poi";r.owner=r.owner or "MirageIntel_Navigate"
            local ok,called=N:SafeCall(MirageMapAPI.ShowUtilityRecord,r,{userInitiated=true})
            if called and ok then return end
        end
        if type(ToggleWorldMap)=="function" then N:SafeCall(ToggleWorldMap) else result(U:OpenCompanion("Map")) end
    end)
    f:SetScript("OnHide",function()
        for _,entry in ipairs(self.entries) do retireRow(entry.pin) end
        N.API:ClearWaypointConfirmation();if chrome and chrome.HideTip then chrome.HideTip() end
    end)
    if chrome then chrome.Watch(f) end
    f:Hide();self.frame=f
end
function U:Open()
    if N:InCombat() then return false,"Open Wayfinder after combat." end
    self:Create();if not self.frame then return false,"Window unavailable." end
    if chrome and not chrome.Fit(self.frame) then return false,"Not enough space to open this panel." end
    if self.view~="settings" and self.view~="quests" then self.view="journey" end
    self.frame:Show();N.Controller:Refresh(true);self:Update();return true
end
function U:Update(player,hasObservation)
    if not self.frame or not self.frame:IsShown() then return end
    local ready=N.state.clientAllowed and not N.Storage.readOnly;local canChange=ready and not N:InCombat()
    local a=type(N.Storage.account)=="table" and N.Storage.account or {};local d=ready and N.active or nil;local mode=N.state.mode
    self.status:SetText(self.message or (not ready and "Navigation is temporarily unavailable." or
        mode=="Pause" and "Navigation paused" or mode=="Off" and "Navigation is off" or
        mode=="Gather" and "Gathering · quests continue between resource routes" or mode=="Manual only" and "Following your chosen destination" or "Automatic navigation"))
    self.modeButtons[1]:SetEnabled(canChange);self.modeButtons[2]:SetEnabled(canChange)
    self.modeButtons[3]:SetEnabled(ready and (mode~="Pause" or canChange));self.modeButtons[3]:SetText(mode=="Pause" and "Resume" or "Pause")
    if chrome then chrome.Active(self.modeButtons[1],mode=="Auto" or mode=="Quest");chrome.Active(self.modeButtons[2],mode=="Gather");chrome.Active(self.modeButtons[3],mode=="Pause") end
    local title,detail=self:DestinationSummary(d);self.destination:SetText(title);self.distance:SetText(detail);self.explanation:SetText(self:SelectionDetail(d))
    local snap=ready and N.Session:Snapshot() or {itinerary={stops={}}};local rows=ready and self:Rows(player,snap) or {}
    self.journey:SetText(self:JourneySummary(snap))
    local pages=math.max(1,math.ceil(#rows/6));self.page=math.max(1,math.min(self.page,pages))
    for i,row in ipairs(self.entries) do
        local entry=rows[(self.page-1)*6+i];row.candidate=entry and entry.item;row.kind=entry and entry.kind
        row.hit:SetShown(entry~=nil)
        if entry then
            row.text:SetText(entry.text);row.detail:SetText(entry.detail);row.fullText=entry.text
            row.pin:SetShown(entry.kind~="destination");row.pin:SetText(entry.kind=="gather" and "Visit" or "Focus");row.pin:SetEnabled(canChange)
            if chrome then chrome.Tint(row.text,entry.current and "secondary" or "text") end
        end
    end
    self.questCaption:SetShown(#rows==0);self.questCaption:SetText(N.state.mode=="Pause" and "Resume to continue your route." or messages.EXPLORE_AREA)
    self.previous:SetEnabled(self.page>1);self.next:SetEnabled(self.page<pages)
    self.pageLabel:SetText(#rows>6 and ("Page "..self.page.." of "..pages) or "Select any stop to make it your focus")
    self.route:SetShown(self.view=="journey");self.settings:SetShown(self.view=="settings");self.questSettings:SetShown(self.view=="quests")
    self:BindRows()
    for _,tab in ipairs(self.tabs) do if chrome then chrome.Active(tab,tab.view==self.view) end end
    for _,setting in ipairs(self.settingsButtons) do
        setting.button:SetText(setting.label.."  ·  "..(a[setting.key]~=false and "On" or "Off"));setting.button:SetEnabled(canChange)
    end
    local advanced=self.showRoutingAdvanced==true
    self.routingHeading:SetText(advanced and "ADVANCED ROUTING" or "AUTOMATIC ROUTING")
    for _,b in ipairs({self.gatherFallback,self.finishNearby,self.turnIns}) do b:SetShown(not advanced) end
    for _,b in ipairs({self.routeLength,self.stability,self.dwell}) do b:SetShown(advanced) end
    self.advancedRouting:SetText(advanced and "Back to routing" or "Advanced routing")
    self.stability:SetText("Route changes: "..(N.Planner:Preferences().holdSeconds>=10 and "Steady" or "Responsive"));self.stability:SetEnabled(canChange)
    self.turnIns:SetText("Turn-ins first: "..(N.Planner:Preferences().preferTurnIns and "On" or "Off"));self.turnIns:SetEnabled(canChange)
    self.finishNearby:SetText("Finish nearby quests: "..(N.Planner:Preferences().finishNearby and "On" or "Off"));self.finishNearby:SetEnabled(canChange)
    self.includeGivers:SetText("Include quest givers in route: "..(N.Planner:Preferences().includeGivers and "On" or "Off"));self.includeGivers:SetEnabled(canChange)
    local pref=N.QuestInteraction and N.QuestInteraction:Preferences() or {}
    for _,setting in ipairs(self.questButtons) do
        setting.button:SetText(setting.label.."  ·  "..(pref[setting.key] and "On" or "Off"));setting.button:SetEnabled(canChange and N.QuestInteraction~=nil)
    end
    self.questStatus:SetText(self:QuestInteractionSummary())
    self.routeLength:SetText("Upcoming stops: "..N.Planner:Preferences().maxStops);self.routeLength:SetEnabled(canChange)
    self.dwell:SetText("Node search: "..N.Session:Settings().dwellSeconds.." seconds");self.dwell:SetEnabled(canChange)
    self.off:SetText(mode=="Off" and "Turn navigation on" or "Turn navigation off");self.off:SetEnabled(canChange)
    self.gather:SetEnabled(canChange);self.mapButton:SetEnabled(canChange)
    self.clear:SetEnabled(canChange and (type(N.Storage.character)=="table" and N.Storage.character.pin~=nil or N.requests.gather~=nil))
    self.skip:SetEnabled(canChange and d~=nil)
end
