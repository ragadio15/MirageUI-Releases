local _,N=...
-- Readable accepted-log facts outrank qualified supplements. Missing evidence
-- stays inspectable; it never becomes an automatic availability claim.
N.Quest={history={},removed={},metadata={},excluded={},inspectable={},generation=0}
local Q=N.Quest
local function isQuest(id) return N:Integer(id) and id<100000000 end
local function put(t,seen,id)
    if #t<64 and isQuest(id) and not seen[id] then seen[id]=true;t[#t+1]=id end
end
local function field(row,key) return N:Field(row,key) end
function Q:WatchedIDs()
    local ids,seen={},{}
    self.metadata={};self.accepted={};self.watched={}
    local log=C_QuestLog
    if type(log)~="table" then return ids end
    -- Explicit intent is reserved within the bounded scan, including the
    -- untracked quest selected through Quest Notes.
    local pin=N.Storage.character and N.Storage.character.pin
    if pin and pin.kind=="quest" then put(ids,seen,pin.questID) end
    local super=self:SupertrackedID();if super then put(ids,seen,super) end
    local count,known=N:SafeCall(log.GetNumQuestLogEntries)
    if known and N:Number(count) and count>=0 then
        for i=1,math.min(128,math.floor(count)) do
            local row,read=N:SafeCall(log.GetInfo,i)
            local id=read and field(row,"questID")
            if isQuest(id) and field(row,"isHeader")~=true then
                self.accepted[id]=true
                self.metadata[id]={level=field(row,"level"),suggestedGroup=field(row,"suggestedGroup"),
                    hidden=field(row,"isHidden"),title=field(row,"title")}
                if N.state.mode=="Auto" or N.state.mode=="Gather" or N.state.mode=="Quest" or N.state.mode=="Nearest quest" then put(ids,seen,id) end
            end
        end
    end
    for _,names in ipairs({{"GetNumQuestWatches","GetQuestIDForQuestWatchIndex"},
        {"GetNumWorldQuestWatches","GetQuestIDForWorldQuestWatchIndex"}}) do
        local n,ok=N:SafeCall(log[names[1]])
        if ok and N:Number(n) and n>=0 then
            for i=1,math.min(64,math.floor(n)) do
                local id,read=N:SafeCall(log[names[2]],i)
                if read and isQuest(id) then put(ids,seen,id);self.watched[id]=true end
            end
        end
    end
    local selected,ok=N:SafeCall(log.GetSelectedQuest)
    if ok then put(ids,seen,selected) end
    return ids
end
function Q:SupertrackedID()
    if type(C_SuperTrack)~="table" then return nil end
    local tracking,ok=N:SafeCall(C_SuperTrack.IsSuperTrackingQuest)
    if ok and tracking==false then return nil end
    local id,known=N:SafeCall(C_SuperTrack.GetSuperTrackedQuestID)
    return known and isQuest(id) and id or nil
end
function Q:Title(id)
    local title,ok=N:SafeCall(C_QuestLog and C_QuestLog.GetTitleForQuestID,id)
    return ok and N:Text(title) or N:Text(self.metadata[id] and self.metadata[id].title) or ("Quest #"..id)
end
function Q:Progress(id)
    local raw,ok=N:SafeCall(C_QuestLog and C_QuestLog.GetQuestObjectives,id)
    if not ok or not N:Table(raw) then return nil,"OBJECTIVE_PROGRESS_UNKNOWN" end
    local count,read=N:SafeCall(function() return #raw end)
    if not read or not N:Integer(count) or count>40 then return nil,"OBJECTIVE_PROGRESS_UNKNOWN" end
    local total=0
    for i=1,count do
        local row=field(raw,i)
        local done,have,need=field(row,"finished"),field(row,"numFulfilled"),field(row,"numRequired")
        if done==true then total=total+1
        elseif N:Number(have) and N:Number(need) and have>=0 and need>0 then total=total+math.min(1,have/need)
        else return nil,"OBJECTIVE_PROGRESS_UNKNOWN" end
    end
    return total/count,"READABLE_OBJECTIVE_COUNTERS"
end
function Q:Character()
    local level,levelOK=N:SafeCall(UnitLevel,"player")
    local faction,factionOK=N:SafeCall(UnitFactionGroup,"player")
    local _,classOK,token,classID=N:SafeCall(UnitClass,"player")
    local size,groupOK=N:SafeCall(GetNumGroupMembers)
    return {level=levelOK and N:Number(level) and level>0 and level or nil,
        faction=factionOK and N:Text(faction) or nil,classID=classOK and N:Integer(classID) and classID or nil,
        classToken=classOK and N:Text(token) or nil,
        groupSize=groupOK and N:Number(size) and size>=0 and math.max(1,size) or nil}
end
function Q:Eligibility(row,character)
    if row.failed==true or row.abandoned==true or self.removed[row.questID] then return false,"QUEST_FAILED_OR_REMOVED" end
    if row.awaitingTurnIn then return false,"TURN_IN_LOCATION_PENDING" end
    if row.stage=="QUEST_GIVER" then
        return row.visitOnly==true and row.locationBasis=="NATIVE_QUEST_START_MARKER",
            "CHECK_GIVER_AVAILABILITY"
    end
    if row.stage~="OBJECTIVES" and row.stage~="READY_FOR_TURN_IN" and row.stage~="AVAILABLE" and row.stage~="ACCEPTED" then return false,"QUEST_STAGE_UNKNOWN" end
    if row.accepted~=true then
        if row.availability~="AVAILABLE" or row.autoRecommend~=true or row.eligibilityConfirmed~=true then
            return false,"CATALOG_ELIGIBILITY_UNKNOWN"
        end
    end
    if row.availableTravel==false or row.reachable==false then return false,"TRAVEL_UNAVAILABLE" end
    if row.requiresTravel==true and row.availableTravel~=true then return false,"TRAVEL_ACCESS_UNKNOWN" end
    if row.prerequisitesMet==false then return false,"PREREQUISITES_UNMET" end
    if row.requiresPrerequisites==true and row.prerequisitesMet~=true then return false,"PREREQUISITES_UNKNOWN" end
    if N:Number(row.requiredLevel) and row.requiredLevel>0 then
        if not character.level then return false,"PLAYER_LEVEL_UNKNOWN" end
        if character.level<row.requiredLevel then return false,"LEVEL_REQUIREMENT_UNMET" end
    end
    if row.faction and row.faction~="Any" and row.faction~="Neutral" then
        if not character.faction then return false,"PLAYER_FACTION_UNKNOWN" end
        if row.faction~=character.faction then return false,"FACTION_REQUIREMENT_UNMET" end
    end
    if N:Integer(row.classID) then
        if not character.classID then return false,"PLAYER_CLASS_UNKNOWN" end
        if row.classID~=character.classID then return false,"CLASS_REQUIREMENT_UNMET" end
    end
    local group=row.requiredGroupSize or row.suggestedGroup
    -- A native suggested group is a suitability gate, not an assertion that
    -- the quest cannot be soloed. Explicit focus remains available to inspect.
    if row.stage~="READY_FOR_TURN_IN" and N:Number(group) and group>1 then
        if not character.groupSize then return false,"GROUP_REQUIREMENT_UNKNOWN" end
        if character.groupSize<group then return false,"GROUP_RECOMMENDED" end
    end
    if row.hidden==true and row.accepted~=true then return false,"HIDDEN_QUEST" end
    return true,row.accepted and "ACCEPTED_QUEST" or "QUALIFIED_AVAILABLE_QUEST"
end
local supplementFields={"requiredLevel","faction","classID","requiredGroupSize","prerequisitesMet","requiresPrerequisites",
    "availableTravel","requiresTravel","reachable","unlockValue","eligibilityConfirmed","autoRecommend","availability"}
function Q:Catalog(player)
    self.catalogByQuest={};self.catalogOffers={};self.catalogStatus="CATALOG_UNAVAILABLE"
    local records=N:Service("WorldRecords")
    if not records or not player then return end
    local cursor
    for _=1,4 do
        local result,ok=N:SafeCall(records.Query,{mapID=player.mapID,kind="quest",limit=64,cursor=cursor})
        if not ok or not N:Table(result) then self.catalogStatus="CATALOG_READ_FAILED";return end
        self.catalogStatus=N:Text(field(result,"status")) or "CATALOG_UNKNOWN"
        local rows=field(result,"records")
        if not N:Table(rows) then return end
        for i=1,math.min(64,#rows) do
            local row=field(rows,i);local id=field(row,"questID")
            if isQuest(id) and field(row,"owner")=="MirageIntel_MapCatalog" then
                local mapID,x,y=field(row,"mapID"),field(row,"x"),field(row,"y")
                if N.map:Valid(mapID,x,y) and mapID==player.mapID then
                    local stage=field(row,"stage")
                    local accepted=field(row,"availability")=="ACCEPTED"
                    if accepted and (stage=="OBJECTIVE_WAYPOINT" or stage=="TURN_IN_WAYPOINT" or stage=="WAYPOINT_STAGE_UNKNOWN") then
                        self.catalogByQuest[id]=row
                    elseif #self.catalogOffers<64 then self.catalogOffers[#self.catalogOffers+1]=row end
                end
            end
        end
        cursor=field(result,"nextCursor");if not cursor then break end
    end
end
-- The native map-pin API is a third location channel on Forever. It is read
-- once per refresh, including with the map closed, and never supplies quest
-- acceptance. Acceptance is independently checked against the current log.
function Q:MapLocations(player)
    self.nativeMapLocations={};self.nativeMapOffers={}
    if not player or not N:Integer(player.mapID) then return end
    local rows,ok=N:SafeCall(C_QuestLog and C_QuestLog.GetQuestsOnMap,player.mapID)
    if not ok or not N:Table(rows) then return end
    local count,read=N:SafeCall(function() return #rows end)
    if not read or not N:Number(count) then return end
    for i=1,math.min(128,count) do
        local row=field(rows,i);local id=field(row,"questID")
        local mapID,x,y=field(row,"mapID"),field(row,"x"),field(row,"y")
        if isQuest(id) and mapID==player.mapID and N.map:Valid(mapID,x,y) then
            self.nativeMapLocations[id]={mapID=mapID,x=x,y=y}
            if field(row,"isQuestStart")==true then
                self.nativeMapOffers[id]={questID=id,mapID=mapID,x=x,y=y,isDaily=field(row,"isDaily")==true}
            end
        end
    end
end
function Q:NativeOffer(row)
    local id=row.questID
    local accepted,known=N:SafeCall(C_QuestLog and C_QuestLog.IsOnQuest,id)
    if not known or accepted~=false or self.accepted[id] or self.removed[id] then return nil end
    local completed,read=N:SafeCall(C_QuestLog and C_QuestLog.IsQuestFlaggedCompleted,id)
    if read and completed==true and not row.isDaily then return nil end
    local result={id="quest:"..id,kind="quest",questID=id,mapID=row.mapID,floorID=row.mapID,x=row.x,y=row.y,
        label=self:Title(id),stage="QUEST_GIVER",accepted=false,availability="UNKNOWN",visitOnly=true,
        source="NATIVE_QUEST_START_MARKER",locationBasis="NATIVE_QUEST_START_MARKER",confidence="NATIVE_MAP_MARKER",
        purpose="CHECK_QUESTS",eligibilityBasis="NPC_CHECK_REQUIRED",nativeVerification="NOT_RUN"}
    result.world,result.worldStatus=N.map:World(row.mapID,row.x,row.y)
    result.eligible,result.eligibilityReason=self:Eligibility(result,self.character)
    return result
end
function Q:Build(id,origin,player)
    if not isQuest(id) or self.removed[id] or type(C_QuestLog)~="table" then return nil,"QUEST_REMOVED_OR_UNAVAILABLE" end
    local generation,worldGeneration=self.generation,N.state.reconciliationGeneration
    local onQuest,ok=N:SafeCall(C_QuestLog.IsOnQuest,id)
    if ok and onQuest==false then return nil,"QUEST_NOT_ACCEPTED" end
    local accepted=onQuest==true or self.accepted and self.accepted[id]==true
    if not accepted then return nil,"ACCEPTED_QUEST_STATE_UNKNOWN" end
    local failed,knownFailure=N:SafeCall(C_QuestLog.IsFailed,id)
    if knownFailure and failed==true then return nil,"QUEST_FAILED_OR_REMOVED" end
    local complete,known=N:SafeCall(C_QuestLog.IsComplete,id)
    local mapID,success,x,y=N:SafeCall(C_QuestLog.GetNextWaypoint,id)
    local locationBasis="NATIVE_QUEST_WAYPOINT"
    -- Forever exposes a separate current-map waypoint. The generic waypoint
    -- can be absent even while native objective pins have a readable location.
    -- Read that public API directly; opening a map panel is not a dependency.
    player=player or N.map:Player()
    if not success or not N.map:Valid(mapID,x,y) or (player and mapID~=player.mapID) then
        if player and N:Integer(player.mapID) then
            local localX,localOK,localY=N:SafeCall(C_QuestLog.GetNextWaypointForMap,id,player.mapID)
            if localOK and N.map:Valid(player.mapID,localX,localY) then
                mapID,x,y=player.mapID,localX,localY;success=true
                locationBasis="NATIVE_CURRENT_MAP_WAYPOINT"
            end
        end
    end
    if not success or not N.map:Valid(mapID,x,y) or (player and mapID~=player.mapID) then
        local native=self.nativeMapLocations and self.nativeMapLocations[id]
        if native and player and native.mapID==player.mapID then
            mapID,x,y=native.mapID,native.x,native.y;success=true
            locationBasis="NATIVE_ACCEPTED_MAP_PIN"
        end
    end
    local supplement=self.catalogByQuest and self.catalogByQuest[id]
    local supplementStage=supplement and field(supplement,"stage")
    local expectedStage=known and type(complete)=="boolean" and (complete and "TURN_IN_WAYPOINT" or "OBJECTIVE_WAYPOINT")
    local source=origin~="ACCEPTED_QUEST_MAP_SUPPLEMENT" and origin or "BLIZZARD_QUEST_WAYPOINT"
    if not success or not N.map:Valid(mapID,x,y) then
        if supplement and (supplementStage==expectedStage or (not expectedStage and supplementStage=="WAYPOINT_STAGE_UNKNOWN")) then
            mapID,x,y=field(supplement,"mapID"),field(supplement,"x"),field(supplement,"y")
            source="ACCEPTED_QUEST_MAP_SUPPLEMENT"
            locationBasis="ACCEPTED_MAP_RECORD"
        else return nil,"QUEST_LOCATION_UNKNOWN" end
    end
    if not N.map:Valid(mapID,x,y) then return nil,"QUEST_LOCATION_UNKNOWN" end
    local w,why=N.map:World(mapID,x,y)
    local meta=self.metadata[id] or {}
    local result={id="quest:"..id,kind="quest",questID=id,mapID=mapID,floorID=mapID,x=x,y=y,world=w,
        worldStatus=why,label=self:Title(id),source=source,quality=locationBasis=="ACCEPTED_MAP_RECORD" and "NATIVE_MAP_SUPPLEMENT" or "BLIZZARD_WAYPOINT",
        stage=known and type(complete)=="boolean" and (complete and "READY_FOR_TURN_IN" or "OBJECTIVES") or "ACCEPTED",
        accepted=true,availability="ACCEPTED",suggestedGroup=meta.suggestedGroup,questLevel=meta.level,
        observedAt=N:Now(),intentOrigin="NATIVE_AUTOMATIC",nativeVerification="NOT_RUN",locationBasis=locationBasis}
    result.confidence=result.quality
    result.progress,result.progressBasis=self:Progress(id)
    local instruction,read=N:SafeCall(C_QuestLog.GetNextWaypointText,id)
    result.instruction=read and N:Text(instruction) or nil
    if supplement then
        result.recordID=N:Text(field(supplement,"id"));result.sourceRevision=field(supplement,"sourceRevision")
        for _,key in ipairs(supplementFields) do local v=field(supplement,key);if v~=nil then result[key]=v end end
    end
    -- Native reads, provider reads and world conversion may invoke callbacks.
    -- Do not join a location from one quest stage with another stage's status.
    local stillOn,stillOnOK=N:SafeCall(C_QuestLog.IsOnQuest,id)
    local stillFailed,stillFailedOK=N:SafeCall(C_QuestLog.IsFailed,id)
    local stillComplete,stillCompleteOK=N:SafeCall(C_QuestLog.IsComplete,id)
    if self.removed[id] or (stillOnOK and stillOn==false) or (stillFailedOK and stillFailed==true) then
        return nil,"QUEST_FAILED_OR_REMOVED"
    end
    if generation~=self.generation or worldGeneration~=N.state.reconciliationGeneration or
        (onQuest==true and (not stillOnOK or stillOn~=true)) or
        (knownFailure and type(failed)=="boolean" and (not stillFailedOK or stillFailed~=failed)) or
        ((type(complete)=="boolean" or type(stillComplete)=="boolean") and
            (not known or not stillCompleteOK or stillComplete~=complete)) then
        return nil,"QUEST_READ_CHANGED"
    end
    local key=tostring(mapID)..":"..tostring(x)..":"..tostring(y)
    local previous=self.history[id]
    if previous and result.stage=="READY_FOR_TURN_IN" and
        (previous.stage=="OBJECTIVES" or previous.blockedKey) and key==(previous.blockedKey or previous.key) and
        result.instruction==previous.instruction then result.awaitingTurnIn=true;result.blockedKey=key end
    self.history[id]={key=key,stage=result.stage,blockedKey=result.blockedKey,instruction=result.instruction}
    result.eligible,result.eligibilityReason=self:Eligibility(result,self.character or self:Character())
    return result
end
function Q:Offer(row)
    local id=field(row,"questID")
    local accepted,ok=N:SafeCall(C_QuestLog and C_QuestLog.IsOnQuest,id)
    if ok and accepted==true then return nil end
    local completed,known=N:SafeCall(C_QuestLog and C_QuestLog.IsQuestFlaggedCompleted,id)
    local result={id="quest:"..id,questID=id,kind="quest",label=N:Text(field(row,"label")) or ("Quest #"..id),
        recordID=N:Text(field(row,"id")),mapID=field(row,"mapID"),x=field(row,"x"),y=field(row,"y"),stage="AVAILABLE",
        accepted=false,source="QUALIFIED_QUEST_CATALOG",confidence=N:Text(field(row,"confidence")) or "UNKNOWN",
        intentOrigin="AUTOMATIC_QUEST_SELECTION",sourceRevision=field(row,"sourceRevision"),nativeVerification="NOT_RUN"}
    for _,key in ipairs(supplementFields) do result[key]=field(row,key) end
    result.world,result.worldStatus=N.map:World(result.mapID,result.x,result.y)
    result.floorID=result.mapID
    if known and completed==true and field(row,"repeatability")~="REPEATABLE_CONFIRMED" then
        result.eligible=false;result.eligibilityReason="QUEST_PREVIOUSLY_COMPLETED"
    else result.eligible,result.eligibilityReason=self:Eligibility(result,self.character) end
    return result
end
function Q:ReadUserWaypoint()
    local point,ok=N:SafeCall(type(C_Map)=="table" and C_Map.GetUserWaypoint)
    if not ok then return nil,false end
    if point==nil then return nil,true end
    local mapID,position=field(point,"uiMapID"),field(point,"position")
    local x,y=N.map:XY(position)
    if not N.map:Valid(mapID,x,y) then return nil,false end
    return {mapID=mapID,x=x,y=y},true
end
function Q:TrackedUserWaypoint()
    local tracked,ok=N:SafeCall(type(C_SuperTrack)=="table" and C_SuperTrack.IsSuperTrackingUserWaypoint)
    if not ok or tracked~=true then return nil end
    local point=self:ReadUserWaypoint();if not point then return nil end
    local record=N.Authority:Record(point.mapID,point.x,point.y,"Blizzard waypoint","waypoint","BLIZZARD_USER_WAYPOINT")
    if record then record.intentOrigin="NATIVE_AUTOMATIC" end
    return record
end
function Q:Refresh(player)
    if not N.state.clientAllowed or N:InCombat() then return false,"READ_DEFERRED" end
    self.excluded={};self.inspectable={}
    local generation,worldGeneration=self.generation,N.state.reconciliationGeneration
    player=player or N.map:Player()
    local ids=self:WatchedIDs();self.character=self:Character();self:Catalog(player);self:MapLocations(player)
    local super=self:SupertrackedID();local candidates,seen={},{}
    self.locationCounts={native=0,currentMap=0,mapPin=0,catalog=0,unavailable=0}
    for _,id in ipairs(ids) do
        local item,why=self:Build(id,id==super and "BLIZZARD_SUPERTRACKED" or "BLIZZARD_WATCHED",player)
        if item then candidates[#candidates+1]=item;seen[id]=true
        else self.excluded[id]=why end
    end
    -- Query only current accepted log identities when filling a missing native
    -- waypoint. A stale published ACCEPTED row is never sufficient by itself.
    for id in pairs(self.catalogByQuest or {}) do if #candidates<64 and not seen[id] then
        local item,why=self:Build(id,"ACCEPTED_QUEST_MAP_SUPPLEMENT",player)
        if item then candidates[#candidates+1]=item;seen[id]=true else self.excluded[id]=why end
    end end
    for _,row in ipairs(self.catalogOffers or {}) do
        local id=field(row,"questID")
        if not seen[id] then
            local offer=self:Offer(row)
            if offer then
                self.inspectable[#self.inspectable+1]=offer
                if offer.eligible and #candidates<64 then candidates[#candidates+1]=offer;seen[id]=true
                else self.excluded[id]=offer.eligibilityReason end
            end
        end
    end
    -- Fresh native start markers are useful destinations for checking a
    -- cluster of quest givers. They never assert that the player can accept a
    -- quest, and historical observations cannot manufacture this live marker.
    local offerIDs={};for id in pairs(self.nativeMapOffers or {}) do offerIDs[#offerIDs+1]=id end
    table.sort(offerIDs)
    for _,id in ipairs(offerIDs) do
        if #candidates<64 and not seen[id] then
            local offer=self:NativeOffer(self.nativeMapOffers[id])
            if offer then candidates[#candidates+1]=offer;seen[id]=true end
        end
    end
    if generation~=self.generation or worldGeneration~=N.state.reconciliationGeneration then
        N.candidates={};N.state.knownCandidates=0
        N:Invalidate("QUEST_READ_CHANGED")
        return false,"QUEST_READ_CHANGED"
    end
    if N:InCombat() then return false,"READ_DEFERRED" end
    for _,item in ipairs(candidates) do
        local key=item.locationBasis=="NATIVE_CURRENT_MAP_WAYPOINT" and "currentMap" or item.locationBasis=="NATIVE_ACCEPTED_MAP_PIN" and "mapPin" or
            item.locationBasis=="ACCEPTED_MAP_RECORD" and "catalog" or "native"
        self.locationCounts[key]=self.locationCounts[key]+1
    end
    for _ in pairs(self.excluded) do self.locationCounts.unavailable=self.locationCounts.unavailable+1 end
    table.sort(candidates,function(a,b) return a.questID<b.questID end)
    N.candidates=candidates;N.state.knownCandidates=#candidates
    N.state.candidateRevision=(N.state.candidateRevision or 0)+1
    -- A temporary location gap must not erase the last objective identity;
    -- otherwise a delayed, unchanged point can masquerade as a turn-in. Keep
    -- only the bounded current accepted/focused identities, never coordinates
    -- as a fallback destination.
    local keep={};for _,id in ipairs(ids) do
        if not self.removed[id] then keep[id]=self.history[id] end
    end;self.history=keep
    return true,#candidates>0 and "ACCEPTED_QUESTS_AND_QUALIFIED_SUPPLEMENTS" or
        (type(C_QuestLog)~="table" and "QUEST_API_MISSING" or "NO_READABLE_QUEST_LOCATION")
end
function Q:InvalidateEligibility(reason)
    -- Group, level and catalog changes can arrive inside a waypoint/distance
    -- read. Retire the qualified snapshot immediately; keeping only a dirty
    -- retry flag would let the old eligibility survive another publication.
    self.generation=self.generation+1
    N.candidates={};N.state.knownCandidates=0
    N.state.candidateRevision=(N.state.candidateRevision or 0)+1
    if N.Planner then N.Planner:Invalidate(reason or "QUEST_ELIGIBILITY_CHANGED",true) end
    -- Saved focus remains intact. Its quest location will be revalidated by
    -- the normal bounded scan, just as the automatically chosen destination.
    if N.active and N.active.kind=="quest" then
        N.Authority:Change(nil,reason or "QUEST_ELIGIBILITY_CHANGED")
    end
end
function Q:OnEvent(event,id,second)
    if event=="GROUP_ROSTER_UPDATE" or event=="PLAYER_LEVEL_UP" then
        self:InvalidateEligibility(event)
    end
    if event=="QUEST_LOG_UPDATE" or event=="QUEST_POI_UPDATE" or event=="QUEST_ACCEPTED" or
        event=="QUEST_REMOVED" or event=="QUEST_TURNED_IN" or event=="SUPER_TRACKING_PATH_UPDATED" then
        self.generation=self.generation+1
    end
    if event=="QUEST_REMOVED" or event=="QUEST_TURNED_IN" then
        if isQuest(id) then
            self.removed[id]=true;self.history[id]=nil
            self.removedOrder=self.removedOrder or {}
            for i=#self.removedOrder,1,-1 do if self.removedOrder[i]==id then table.remove(self.removedOrder,i) end end
            self.removedOrder[#self.removedOrder+1]=id
            while #self.removedOrder>256 do self.removed[table.remove(self.removedOrder,1)]=nil end
            -- Completion/removal is authoritative immediately. Do not let a
            -- retained candidate or future itinerary resurrect this quest
            -- while the next bounded native log refresh is still waiting.
            for i=#N.candidates,1,-1 do
                if N.candidates[i].questID==id then table.remove(N.candidates,i) end
            end
            N.state.knownCandidates=#N.candidates
            N.state.candidateRevision=(N.state.candidateRevision or 0)+1
            if N.Planner then N.Planner:Forget(id) end
            local pin=N.Storage.character and N.Storage.character.pin
            if pin and pin.questID==id then
                -- Clear only the explicitly removed focus; this is a saved
                -- intent reconciliation, not a protected native action.
                if not N.Storage.readOnly then N.Storage.character.pin=nil;N.Storage.character.revision=N.Storage.character.revision+1 end
            end
            if N.active and N.active.questID==id then N.Authority:Change(nil,"QUEST_REMOVED")
            elseif N.active then N.Authority:Change(N.active,N.state.status) end
        end
    elseif event=="QUEST_ACCEPTED" then
        local accepted=isQuest(second) and second or id
        if isQuest(accepted) then
            self.removed[accepted]=nil;self.history[accepted]=nil
            for i=#(self.removedOrder or {}),1,-1 do if self.removedOrder[i]==accepted then table.remove(self.removedOrder,i) end end
        end
    end
end
