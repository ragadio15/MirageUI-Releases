local _,N=...
local f=CreateFrame("Frame");N.eventsFrame=f
local events={"ADDON_LOADED","PLAYER_ENTERING_WORLD","PLAYER_LEAVING_WORLD","ZONE_CHANGED","ZONE_CHANGED_NEW_AREA",
    "ZONE_CHANGED_INDOORS","PLAYER_MAP_CHANGED","QUEST_LOG_UPDATE","QUEST_POI_UPDATE","QUEST_ACCEPTED","QUEST_REMOVED","QUEST_TURNED_IN",
    "QUEST_WATCH_LIST_CHANGED","SUPER_TRACKING_CHANGED","SUPER_TRACKING_PATH_UPDATED","PLAYER_REGEN_DISABLED","PLAYER_REGEN_ENABLED",
    "USER_WAYPOINT_UPDATED","UI_SCALE_CHANGED","PLAYER_DEAD","PLAYER_ALIVE","PLAYER_UNGHOST","PLAYER_CONTROL_LOST","PLAYER_CONTROL_GAINED",
    "UNIT_FLAGS","BAG_UPDATE_DELAYED","GROUP_ROSTER_UPDATE","PLAYER_LEVEL_UP","SKILL_LINES_CHANGED",
    "GOSSIP_SHOW","GOSSIP_CLOSED","QUEST_GREETING","QUEST_DETAIL","QUEST_PROGRESS","QUEST_COMPLETE","QUEST_FINISHED",
    "ADDON_ACTION_BLOCKED","ADDON_ACTION_FORBIDDEN"}
N.state.registeredEvents={};N.state.unavailableEvents={}
for _,event in ipairs(events) do
    local ok=pcall(f.RegisterEvent,f,event)
    if ok then N.state.registeredEvents[event]=true else N.state.unavailableEvents[event]=true end
end
f:SetScript("OnEvent",function(_,event,arg,second)
    if event=="ADDON_LOADED" and arg==N.name then
        local ok=pcall(N.Initialize,N)
        if not ok then N:Fault("INITIALIZATION_FAILED");N.state.status="INITIALIZATION_FAILED" end
        return
    end
    if not N.state.initialized then return end
    if event=="UNIT_FLAGS" and (not N:Readable(arg) or arg~="player") then return end
    if event=="ADDON_LOADED" then
        if arg=="MirageUICursor" or arg=="CursorCompanion" then
            if N.HUD.frame then N.HUD.frame:Hide() end;N:Invalidate("CURSOR_BECAME_AVAILABLE")
        end
        return
    end
    N.state.events=N.state.events+1
    if N.QuestInteraction then
        local ok=pcall(N.QuestInteraction.OnEvent,N.QuestInteraction,event,arg,second)
        if not ok then N.QuestInteraction:Reset("QUEST_INTERACTION_ERROR");N:Fault("QUEST_INTERACTION_EVENT_FAILED") end
    end
    if event=="ADDON_ACTION_BLOCKED" or event=="ADDON_ACTION_FORBIDDEN" or event=="GOSSIP_SHOW" or
        event=="GOSSIP_CLOSED" or event=="QUEST_GREETING" or event=="QUEST_DETAIL" or event=="QUEST_PROGRESS" or
        event=="QUEST_COMPLETE" or event=="QUEST_FINISHED" then return end
    if event=="PLAYER_REGEN_DISABLED" or event=="PLAYER_REGEN_ENABLED" then
        N.state.combatRevision=(N.state.combatRevision or 0)+1
    end
    if N.Quest and N.Quest.OnEvent then N.Quest:OnEvent(event,arg,second) end
    if event=="PLAYER_LEAVING_WORLD" then N.state.inWorld=false;N.Controller:ResetDestinations("WORLD_TRANSITION");return end
    if event=="PLAYER_ENTERING_WORLD" then N.Controller:EnterWorld();return end
    if event=="ZONE_CHANGED" or event=="ZONE_CHANGED_NEW_AREA" or event=="ZONE_CHANGED_INDOORS" or event=="PLAYER_MAP_CHANGED" then
        -- Collapse a zoning event burst into one invalidation and one scan.
        if not N.Controller.settleRemaining then N.Controller:ResetDestinations("MAP_TRANSITION") end
        N.Controller.settleRemaining=.35
    elseif event=="PLAYER_DEAD" then
        N.state.deadEvent=true;N.Controller:Refresh(false)
    elseif event=="PLAYER_ALIVE" or event=="PLAYER_UNGHOST" then
        N.state.deadEvent=false;N.Controller:Refresh(true)
    elseif event=="PLAYER_CONTROL_LOST" or event=="PLAYER_CONTROL_GAINED" or event=="UNIT_FLAGS" then
        N.Controller:Refresh(false)
    elseif event=="USER_WAYPOINT_UPDATED" or event=="PLAYER_REGEN_DISABLED" then
        N.API:ClearWaypointConfirmation()
        if event=="PLAYER_REGEN_DISABLED" then N.Session.nearSince=nil;N.Planner:Invalidate("COMBAT_HOLD") end
    elseif event=="BAG_UPDATE_DELAYED" then
        N.Session.bagCheckedAt=nil;N.Session.nextProbeAt=0
    elseif event=="SKILL_LINES_CHANGED" then N.Session.nextEligibilityAt=0;N.Session.nextProbeAt=0;N.Session.circuitDirty=true end
    if event~="UI_SCALE_CHANGED" then N:Invalidate(event) end
    if event=="PLAYER_REGEN_ENABLED" then N.Controller:Refresh(true) end
end)
f:SetScript("OnUpdate",function(_,elapsed)
    if N.state.initialized then
        if N.QuestInteraction and N.QuestInteraction.pending then
            local ok=pcall(N.QuestInteraction.Tick,N.QuestInteraction,elapsed)
            if not ok then N.QuestInteraction:Reset("QUEST_INTERACTION_ERROR");N:Fault("QUEST_INTERACTION_TICK_FAILED") end
        end
        local ok=pcall(N.Controller.Tick,N.Controller,elapsed)
        if not ok then
            if N.HUD and N.HUD.frame then N.HUD.frame:Hide() end
            N:Fault("CONTROLLER_TICK_FAILED");N.state.status="CONTROLLER_ERROR"
        end
    end
end)
