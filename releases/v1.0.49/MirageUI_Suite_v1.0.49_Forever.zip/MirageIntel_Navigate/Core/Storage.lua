local _,N=...
N.Storage={readOnly=false,reason="UNINITIALIZED"}
local allowed={['Auto']=true,['Quest']=true,['Gather']=true,['Pause']=true,['Follow Blizzard']=true,['Nearest quest']=true,['Manual only']=true,['Off']=true}
-- Schema-1 data is retained. P10 unifies automatic policies below while
-- preserving explicit Pause, Off, Gather and Manual choices.
local function account() return {schemaVersion=1,mode="Auto",showHUD=true,revision=0,sentinel="NAV_ACCOUNT_V1"} end
local function character() return {schemaVersion=1,revision=0,sentinel="NAV_CHAR_V1",pin=nil} end
function N.Storage:Initialize()
    if N.state.clientAllowed==false then
        self.account,self.character=MirageIntelNavigateDB,MirageIntelNavigateCharDB
        self.readOnly=true;self.reason="UNSUPPORTED_CLIENT_PRESERVED";return
    end
    if MirageIntelNavigateDB==nil then MirageIntelNavigateDB=account() end
    if MirageIntelNavigateCharDB==nil then MirageIntelNavigateCharDB=character() end
    self.account,self.character=MirageIntelNavigateDB,MirageIntelNavigateCharDB
    local a,b=self.account,self.character
    if type(a)~="table" or type(b)~="table" or a.schemaVersion~=1 or b.schemaVersion~=1 or
       not allowed[a.mode] or type(a.showHUD)~="boolean" or not N:Number(a.revision) or not N:Number(b.revision) then
        self.readOnly=true;self.reason="SCHEMA_MISMATCH_PRESERVED";return
    end
    if b.pin~=nil and not self:ValidPin(b.pin) then
        self.readOnly=true;self.reason="CORRUPT_PIN_PRESERVED";return
    end
    if b.sessionEpoch~=nil and (not N:Number(b.sessionEpoch) or b.sessionEpoch<0 or b.sessionEpoch%1~=0 or b.sessionEpoch>1000000000) then
        self.readOnly=true;self.reason="SESSION_EPOCH_PRESERVED";return
    end
    b.sessionEpoch=(b.sessionEpoch or 0)+1
    -- P10 folds the older automatic policies into one focus-aware workflow.
    -- Explicit Pause / Off / Gather / Manual choices and all saved pins survive.
    if a.navigationRevision==nil then
        if a.mode=="Quest" or a.mode=="Follow Blizzard" or a.mode=="Nearest quest" then a.mode="Auto" end
        if a.gatherReturnMode=="Quest" or a.gatherReturnMode=="Follow Blizzard" or a.gatherReturnMode=="Nearest quest" then a.gatherReturnMode="Auto" end
        if a.resumeMode=="Quest" or a.resumeMode=="Follow Blizzard" or a.resumeMode=="Nearest quest" then a.resumeMode="Auto" end
        a.navigationRevision=10;a.revision=a.revision+1
    end
    if a.showMapRoute==nil then a.showMapRoute=true end
    if a.showMinimapRoute==nil then a.showMinimapRoute=true end
    if a.gatherFallback==nil then a.gatherFallback=true end
    if a.questInteraction==nil then
        a.questInteraction={autoAccept=true,autoTurnIn=true,repeatable=false}
        a.revision=a.revision+1
    end
    if a.routePolicyRevision==nil or (N:Number(a.routePolicyRevision) and a.routePolicyRevision<19) then
        -- P18 serialized its true turn-in default when *any* planner setting
        -- was saved. Adopt the requested P19 policy once, retaining distances,
        -- route length and stability; subsequent explicit overrides persist.
        if a.planner==nil then a.planner={} end
        if type(a.planner)=="table" then a.planner.finishNearby=true;a.planner.preferTurnIns=false end
        a.routePolicyRevision=19;a.revision=a.revision+1
    end
    N.state.mode=a.mode
    self.freshPolicy=a.mode=="Auto"
    self.reason="RESTORE_NOT_YET_VERIFIED_ON_GAME_CLIENT"
end
function N.Storage:ValidPin(pin)
    if type(pin)~="table" then return false end
    if not N:Text(pin.label) or not N:Text(pin.source) or not N:Integer(pin.mapID) or pin.mapID>=1000000 or
        not N:Number(pin.x) or not N:Number(pin.y) or pin.x<0 or pin.x>1 or pin.y<0 or pin.y>1 then return false end
    if pin.kind~="manual" and pin.kind~="quest" then return false end
    if pin.kind=="quest" and (not N:Integer(pin.questID) or pin.questID>=100000000) then return false end
    if pin.sourceRevision~=nil and not ((N:Number(pin.sourceRevision) and pin.sourceRevision>=0) or N:Text(pin.sourceRevision)) then return false end
    if pin.floorID~=nil and (not N:Integer(pin.floorID) or pin.floorID>=1000000) then return false end
    for _,key in ipairs({"nodeID","taxiNodeID"}) do
        if pin[key]~=nil and (not N:Integer(pin[key]) or pin[key]>=100000000) then return false end
    end
    for _,key in ipairs({"recordID","siteID","purpose","category","name"}) do
        if pin[key]~=nil and not N:Text(pin[key]) then return false end
    end
    return true
end
function N.Storage:SetMode(mode)
    if self.readOnly then return false,self.reason end
    if N.state.clientAllowed==false then return false,"Wayfinder is unavailable on this game build." end
    if mode~="Pause" and N:InCombat() then return false,"Change Wayfinder settings after combat." end
    if not allowed[mode] then return false,"INVALID_MODE" end
    if N.state.mode==mode then return true,"MODE_UNCHANGED" end
    self.account.mode=mode;self.account.revision=self.account.revision+1
    local previous=N.state.mode
    N.state.mode=mode
    if N.Session then N.Session:OnModeChanged(mode,previous) end
    N:Invalidate("MODE_CHANGED")
    return true
end
function N.Storage:SetHUD(value)
    if self.readOnly then return false,self.reason end
    if N.state.clientAllowed==false then return false,"Wayfinder is unavailable on this game build." end
    if N:InCombat() then return false,"Change Wayfinder settings after combat." end
    if type(value)~="boolean" then return false,"INVALID_PREFERENCE" end
    self.account.showHUD=value;self.account.revision=self.account.revision+1
    return true
end
function N.Storage:Pin(record,expected)
    if self.readOnly then return false,self.reason end
    if N.state.clientAllowed==false then return false,"Wayfinder is unavailable on this game build." end
    if N:InCombat() then return false,"COMBAT_PIN_CHANGE_DEFERRED" end
    if record~=nil and not self:ValidPin(record) then return false,"INVALID_PIN" end
    local nextPin=record and {mapID=record.mapID,x=record.x,y=record.y,label=record.label,
        kind=record.kind,source=record.source,questID=N:Integer(record.questID) and record.questID or nil,
        recordID=N:Text(record.recordID),siteID=N:Text(record.siteID),category=N:Text(record.category),name=N:Text(record.name),
        sourceRevision=N:Number(record.sourceRevision) and record.sourceRevision or N:Text(record.sourceRevision),
        purpose=N:Text(record.purpose),floorID=N:Integer(record.floorID) and record.floorID or record.mapID,
        taxiNodeID=N:Integer(record.taxiNodeID) and record.taxiNodeID or nil,
        nodeID=N:Integer(record.nodeID) and record.nodeID or nil,intentOrigin="PLAYER_EXPLICIT"} or nil
    if expected then
        -- Coordinate confirmations and arrival observations carry the exact
        -- saved-state identity they read. Finish callback-capable validation
        -- before checking it, so an old card cannot erase a newer focus.
        local combat=N:InCombat()
        if combat then return false,"COMBAT_PIN_CHANGE_DEFERRED" end
        if self.readOnly or not N.state.clientAllowed or self.character~=expected.character or self.account~=expected.account or
            self.character.revision~=expected.revision or self.character.sessionEpoch~=expected.epoch or
            N.state.reconciliationGeneration~=expected.world or N.state.mode~=expected.mode or
            expected.generation and N.Session.generation~=expected.generation then return false,"WAYPOINT_SELECTION_CHANGED" end
    end
    self.character.pin=nextPin
    self.character.revision=self.character.revision+1
    -- Arrival/confirmation feedback belongs to the previous explicit pin.
    -- Coordinate setters publish their new result after this commit; a later
    -- ordinary map note must not continue reporting that old waypoint reached.
    if N.API then N.API.coordinateResult=nil end
    if N.Session then N.Session:IntentChanged("MANUAL_PIN_CHANGED") end
    N:Invalidate("MANUAL_PIN_CHANGED")
    return true
end
function N.Storage:Status()
    return {reason=self.reason,readOnly=self.readOnly,
       accountRevision=type(self.account)=="table" and self.account.revision or nil,
       characterRevision=type(self.character)=="table" and self.character.revision or nil,
       accountSentinel=type(self.account)=="table" and self.account.sentinel or nil,
       characterSentinel=type(self.character)=="table" and self.character.sentinel or nil}
end
