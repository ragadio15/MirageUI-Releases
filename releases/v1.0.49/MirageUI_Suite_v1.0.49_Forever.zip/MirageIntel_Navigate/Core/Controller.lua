local _,N=...
N.Controller={elapsed=0,scanAt=0,lastScanAttempt=nil}
local WORLD_SETTLE_SECONDS=.65
function N.Controller:Connect()
    if self.connected or not N.core or type(N.core.Subscribe)~="function" then return end
    self.connected=true
    N.core.Subscribe("WORLD_RECORDS_CHANGED","MirageIntel_Navigate",function(event)
        if not N.state.initialized then return end
        local owner=N:Field(event,"owner")
        if owner=="MirageIntel_MapCatalog" then
            -- Retain the immediate retry for a revoked active supplement before
            -- invalidation withdraws the quest and clears its displayed record.
            if N.active and N.active.recordID and (N.active.source=="ACCEPTED_QUEST_MAP_SUPPLEMENT" or
                N.active.confidence=="NATIVE_MAP_SUPPLEMENT") then self.lastScanAttempt=nil end
            N.Quest:InvalidateEligibility("QUEST_CATALOG_REVALIDATING")
            N:Invalidate("QUEST_CATALOG_CHANGED")
        elseif owner=="MirageIntel_Gather" then
            N.Session:RecordsChanged()
            local request=N.requests.gather
            if request and request.requireRecord then
                N:Invalidate("GATHER_RECORD_CHANGED")
                -- Revocation must also withdraw a retained combat arrow. A
                -- later ready snapshot can revalidate the same explicit site.
                local record=N.Authority:Gather()
                if not record and N.active and N.active.source=="GATHER_USER_SELECTED" then
                    N.Authority:Change(nil,"GATHER_RECORD_UNAVAILABLE")
                end
            end
        end
    end)
    N.core.Subscribe("TRAVEL_GRAPH_CHANGED","MirageIntel_Navigate",function()
        if not N.state.initialized then return end
        N.Session.routeKey=nil;N:Invalidate("TRAVEL_GRAPH_CHANGED")
        if N.active and N.active.precision=="VALIDATED_GRAPH_ROUTE" then N.Authority:Change(nil,"GRAPH_REVALIDATION_PENDING") end
    end)
end
function N.Controller:ResetDestinations(reason)
    N.candidates={};N.state.knownCandidates=0;N.state.dirty=true;self.lastScanAttempt=nil
    N.state.reconciliationGeneration=(N.state.reconciliationGeneration or 0)+1
    if N.Session then N.Session:Reconcile(reason,true) end
    if N.Planner then N.Planner:Invalidate(reason,true) end
    if N.API then N.API:ClearWaypointConfirmation() end
    if N.HUD and N.HUD.frame then N.HUD.frame:Hide() end
    N.Authority:Change(nil,reason)
end
function N.Controller:EnterWorld()
    self:ResetDestinations("WORLD_TRANSITION")
    N.state.inWorld=true;self.settleRemaining=WORLD_SETTLE_SECONDS;self.elapsed=0;self.lastScanAttempt=nil
end
function N.Controller:Ready() return N.state.initialized and N.state.inWorld~=false and not self.settleRemaining end
function N.Controller:CanUseCursorQuest() return false end
function N.Controller:MovementState()
    local dead,deadOK=N:SafeCall(UnitIsDeadOrGhost,"player")
    local taxi,taxiOK=N:SafeCall(UnitOnTaxi,"player")
    if deadOK and type(dead)=="boolean" then N.state.deadEvent=dead end
    if taxiOK and type(taxi)=="boolean" then N.state.taxiEvent=taxi end
    if N.state.deadEvent then return "PLAYER_DEAD" end
    if N.state.taxiEvent then return "PLAYER_ON_TAXI" end
    if (type(UnitIsDeadOrGhost)=="function" and (not deadOK or type(dead)~="boolean")) or
        (type(UnitOnTaxi)=="function" and (not taxiOK or type(taxi)~="boolean")) then return "PLAYER_STATE_UNREADABLE" end
end
function N.Controller:Reconcile(force)
    if not self:Ready() then return end
    local suspended=self:MovementState()
    if suspended~=N.state.suspended then
        N.state.suspended=suspended;self:ResetDestinations(suspended or "PLAYER_STATE_RECOVERED");force=true
    end
    if suspended then
        N.Authority:Change(nil,suspended)
        if N.UI then N.UI:Update() end;if N.HUD then N.HUD:Update() end;return
    end
    if not N.state.clientAllowed or N.Storage.readOnly then
        N.Authority:Change(nil,not N.state.clientAllowed and "UNSUPPORTED_BUILD" or "STORAGE_READ_ONLY")
        if N.UI then N.UI:Update() end;if N.HUD then N.HUD:Update() end;return
    end
    local panelVisible=N.UI and N.UI.frame and N.UI.frame:IsShown()
    if N.state.mode=="Pause" or N.state.mode=="Off" then
        N.Authority:Change(nil,N.state.mode=="Pause" and "PAUSED" or "OFF")
        if N.UI then N.UI:Update() end;if N.HUD then N.HUD:Update() end;return
    end
    local worldRevision=N.state.reconciliationGeneration
    local player=N.map:Player();local now=N:Now();local outOfCombat=not N:InCombat()
    if not self:Ready() or worldRevision~=N.state.reconciliationGeneration then return end
    if self.wasCombat~=not outOfCombat then
        if not outOfCombat then N.Session.nearSince=nil;N.Planner:Invalidate("COMBAT_HOLD")
        elseif self.wasCombat then self.lastScanAttempt=nil;force=true end
        self.wasCombat=not outOfCombat
    end
    if not outOfCombat then N.Session.nearSince=nil end
    if not outOfCombat and N.API then N.API.coordinateNear=nil end
    -- A new clock basis cannot leave the prior native-scan timestamp in the
    -- future, otherwise even dirty quest evidence would wait for it to catch up.
    if self.lastScanAttempt and now<self.lastScanAttempt then self.lastScanAttempt=nil end
    local since=self.lastScanAttempt and math.max(0,now-self.lastScanAttempt) or math.huge
    local unbridged=N.Cursor:HasUnbridgedCompanion();local request=N.requests.gather
    if outOfCombat and request and N:Number(request.expiresAt) and now>=request.expiresAt then
        N.requests.gather=nil;N.Session:IntentChanged("EXPLICIT_GATHER_EXPIRED");N.state.dirty=true
    end
    local due=since>=(unbridged and 4.0 or 3.0) or (N.state.dirty and since>=(unbridged and 1.5 or .5))
    local pin=N.Storage.character and N.Storage.character.pin
    local wantsNative=N.state.mode=="Auto" or N.state.mode=="Gather" or N.state.mode=="Quest" or
        N.state.mode=="Follow Blizzard" or N.state.mode=="Nearest quest" or (pin and pin.kind=="quest")
    if outOfCombat and (force or due) and (wantsNative or panelVisible) then
        self.lastScanAttempt=now
        local invalidation=N.state.invalidationRevision
        local scanned,reason=N.Quest:Refresh(player)
        if not self:Ready() or worldRevision~=N.state.reconciliationGeneration then return end
        if scanned then self.scanAt=now;N.state.lastNativeRefresh=now end
        -- The read may itself discover changing quest facts or synchronously
        -- receive newer group/catalog evidence. Only consume the invalidation
        -- that this successful scan began with; the normal dirty interval
        -- bounds the continuation without requiring another event or motion.
        N.state.lastNativeResult=reason
        N.state.dirty=not scanned or invalidation~=N.state.invalidationRevision
        N.state.refreshes=N.state.refreshes+1
    end
    -- A provider/native read may run a combat transition callback. Recheck at
    -- the selection boundary instead of using the pre-scan state.
    outOfCombat=not N:InCombat()
    if not outOfCombat and N.active then
        local old=N.active;local d,reason=N.map:Measure(player,old)
        if not player or player.mapID~=old.mapID or (player.floorID or player.mapID)~=(old.floorID or old.mapID) then d=nil;reason="OTHER_MAP_OR_FLOOR" end
        if old.precision=="VALIDATED_GRAPH_ROUTE" then d=nil;reason="TRANSPORT_ACTION_REQUIRED" end
        old.distance=d;old.distanceBasis=d and reason or nil
        old.status=d and (d<=8 and "NEAR_DESTINATION" or "LOCATED") or (reason or "DISTANCE_UNAVAILABLE")
        N.Session.directionTarget=d and N._copy(old) or nil
        N.Authority:Change(old,old.status)
    elseif outOfCombat then
        if N.API and N.API.ObserveCoordinateArrival then N.API:ObserveCoordinateArrival(player) end
        N.Authority:Refresh(player)
    end
    if N.UI then N.UI:Update(player,true) end;if N.HUD then N.HUD:Update(player,true) end
end
function N.Controller:Refresh(force)
    if self.refreshing then self.refreshQueued=true;return end
    self.refreshing=true
    local ok=pcall(self.Reconcile,self,force)
    self.refreshing=false
    if not ok then
        if N.HUD and N.HUD.frame then N.HUD.frame:Hide() end
        N:Fault("CONTROLLER_REFRESH_FAILED");N.Authority:Change(nil,"CONTROLLER_ERROR")
    end
    -- A provider may publish while being queried. Reconcile on the next
    -- bounded tick instead of recursively selecting an obsolete result.
    if self.refreshQueued then self.refreshQueued=nil;N.state.dirty=true;self.lastScanAttempt=nil end
end
function N.Controller:Tick(dt)
    if not N:Number(dt) or dt<0 or N.state.inWorld==false then return end
    if self.settleRemaining then
        self.settleRemaining=self.settleRemaining-math.min(dt,.25)
        if self.settleRemaining>1e-6 then return end
        self.settleRemaining=nil;self:Refresh(true);return
    end
    self.elapsed=self.elapsed+math.min(dt,.2)
    local quiet=(N.state.mode=="Off" or N.state.mode=="Pause") and not (N.UI.frame and N.UI.frame:IsShown())
    if self.elapsed<(quiet and 1.0 or .15) then return end
    self.elapsed=0;self:Refresh(false)
end
