local _,N=...
N.API={}
local function samePoint(a,b,tolerance)
    return a and b and a.mapID==b.mapID and math.abs(a.x-b.x)<=tolerance and math.abs(a.y-b.y)<=tolerance
end
-- A coordinate destination is one explicit, character-owned focus. It uses
-- the normal authority, route renderer and pause/death rules; it never writes
-- Blizzard's waypoint or changes a player's automatic navigation mode.
function N.API:CoordinateWaypoint()
    local character=N.Storage.character
    local pin=type(character)=="table" and character.pin
    local selected=pin and pin.kind=="manual" and pin.purpose=="COORDINATE_WAYPOINT"
    return N._copy({present=selected==true,pin=selected and pin or nil,
        pinRevision=type(character)=="table" and character.revision,
        epoch=type(character)=="table" and character.sessionEpoch,
        mode=N.state.mode,suspended=N.state.suspended,readOnly=N.Storage.readOnly==true,
        lastResult=self.coordinateResult})
end
function N.API:SetCoordinateWaypoint(mapID,x,y,options)
    if type(options)~="table" or options.userInitiated~=true then return false,"USER_ACTION_REQUIRED" end
    if not N.state.clientAllowed or N.Storage.readOnly or not N.Controller:Ready() then return false,"NAVIGATION_NOT_READY" end
    if N:InCombat() then return false,"COMBAT_PIN_CHANGE_DEFERRED" end
    if not N:Number(x) or not N:Number(y) or x<0 or x>100 or y<0 or y>100 then return false,"INVALID_COORDINATE" end
    local character,account=N.Storage.character,N.Storage.account
    if type(character)~="table" then return false,"NAVIGATION_NOT_READY" end
    local revision,epoch=character.revision,character.sessionEpoch
    if options.expectedRevision~=nil and options.expectedRevision~=revision or
        options.expectedEpoch~=nil and options.expectedEpoch~=epoch then return false,"WAYPOINT_SELECTION_CHANGED" end
    local world=N.state.reconciliationGeneration;local mode=N.state.mode
    local valid=N.map:Valid(mapID,x/100,y/100)
    local label=N:Text(options.label)
    local combat=N:InCombat()
    if character~=N.Storage.character or account~=N.Storage.account or revision~=character.revision or
        epoch~=character.sessionEpoch or world~=N.state.reconciliationGeneration or mode~=N.state.mode or
        not N.state.clientAllowed or N.Storage.readOnly or not N.Controller:Ready() then return false,"WAYPOINT_SELECTION_CHANGED" end
    if combat then return false,"COMBAT_PIN_CHANGE_DEFERRED" end
    if not valid then return false,"INVALID_COORDINATE" end
    local ok,why=N.Storage:Pin({kind="manual",source="USER_SELECTED_COORDINATES",purpose="COORDINATE_WAYPOINT",
        label=label and label~="" and label or string.format("Waypoint · %.2f, %.2f",x,y),
        recordID="coordinate:"..tostring(epoch)..":"..tostring(revision+1),mapID=mapID,floorID=mapID,x=x/100,y=y/100},
        {character=character,account=account,revision=revision,epoch=epoch,world=world,mode=mode})
    if not ok then return false,why end
    self.coordinateNear=nil;self.coordinateResult="SAVED"
    N.Controller:Refresh(true)
    return true,N.state.mode=="Pause" and "WAYPOINT_SAVED_PAUSED" or N.state.mode=="Off" and "WAYPOINT_SAVED_OFF" or
        N.state.suspended=="PLAYER_DEAD" and "WAYPOINT_SAVED_DEAD" or N.state.suspended and "WAYPOINT_SAVED_SUSPENDED" or "WAYPOINT_PRIORITIZED"
end
function N.API:ClearCoordinateWaypoint(expected)
    if type(expected)~="table" or expected.userInitiated~=true then return false,"USER_ACTION_REQUIRED" end
    if not N:Number(expected.x) or not N:Number(expected.y) then return false,"INVALID_COORDINATE" end
    local character=N.Storage.character;local pin=character and character.pin
    if not pin or pin.kind~="manual" or pin.purpose~="COORDINATE_WAYPOINT" then return false,"NO_COORDINATE_WAYPOINT" end
    if expected.pinRevision~=character.revision or expected.epoch~=character.sessionEpoch or
        not samePoint(expected,pin,0) then return false,"WAYPOINT_SELECTION_CHANGED" end
    local ok,why=N.Storage:Pin(nil,{character=character,account=N.Storage.account,revision=character.revision,
        epoch=character.sessionEpoch,world=N.state.reconciliationGeneration,mode=N.state.mode})
    if not ok then return false,why end
    self.coordinateNear=nil;self.coordinateResult="CLEARED"
    N.Controller:Refresh(true)
    return true,"WAYPOINT_CLEARED"
end
function N.API:ObserveCoordinateArrival(player)
    local character=N.Storage.character;local pin=character and character.pin
    if not pin or pin.kind~="manual" or pin.purpose~="COORDINATE_WAYPOINT" or not player or
        N.state.mode=="Pause" or N.state.mode=="Off" or N.state.suspended or N.Storage.readOnly or
        not N.state.clientAllowed or N:InCombat() or player.mapID~=pin.mapID or
        (player.floorID or player.mapID)~=(pin.floorID or pin.mapID) then self.coordinateNear=nil;return false end
    local revision,epoch,world=character.revision,character.sessionEpoch,N.state.reconciliationGeneration
    local sessionToken=N.Session:Token()
    local target=N.Authority:Record(pin.mapID,pin.x,pin.y,pin.label,pin.kind,pin.source)
    local distance=target and N.map:Measure(player,target)
    local now=N:Now()
    if not N.Session:TokenCurrent(sessionToken) or character~=N.Storage.character or character.pin~=pin or
        revision~=character.revision or epoch~=character.sessionEpoch or world~=N.state.reconciliationGeneration or N:InCombat() then
        self.coordinateNear=nil;return false
    end
    if not N:Number(distance) or distance>8 or distance<0 then self.coordinateNear=nil;return false end
    local near=self.coordinateNear
    if not near or near.pin~=pin or near.revision~=revision or near.epoch~=epoch or now<near.at then
        self.coordinateNear={pin=pin,revision=revision,epoch=epoch,at=now};return false
    end
    -- Two seconds inside the measured eight-yard arrival area avoids clearing
    -- a destination on one transient sample. Combat and world changes restart it.
    if now-near.at<2 then return false end
    local ok=N.Storage:Pin(nil,{character=character,account=N.Storage.account,revision=revision,epoch=epoch,
        world=world,mode=N.state.mode,generation=sessionToken.generation})
    self.coordinateNear=nil
    if ok then self.coordinateResult="REACHED";N:Invalidate("COORDINATE_WAYPOINT_REACHED") end
    return ok==true
end
function N.API:ClearWaypointConfirmation()
    self.pendingReplacement=nil
end
function N.API:PlaceBlizzardWaypoint()
    if not N.state.clientAllowed then return false,"Unsupported game build." end
    if N.Storage.readOnly or not N.Controller:Ready() then return false,"Wayfinder is not ready." end
    if N:InCombat() then self:ClearWaypointConfirmation();return false,"Leave combat before placing a waypoint." end
    local d=N._copy(N.active)
    local token=N.Session:Token();local worldRevision=N.state.reconciliationGeneration
    local pinRevision=N.Storage.character and N.Storage.character.revision
    local function stillCurrent()
        -- Complete callback-capable native reads before checking the captured
        -- intent, so their side effects cannot authorize an older waypoint.
        local inCombat=N:InCombat()
        local active=N.active
        return N.Session:TokenCurrent(token) and worldRevision==N.state.reconciliationGeneration and
            pinRevision==(N.Storage.character and N.Storage.character.revision) and active and d and
            active.id==d.id and active.revision==d.revision and samePoint(active,d,0) and
            N.Controller:Ready() and N.state.clientAllowed and not N.Storage.readOnly and not inCombat
    end
    local function stale()
        self:ClearWaypointConfirmation();return false,"Destination changed. Select Place waypoint again for your current destination."
    end
    if not d or not N.map:Valid(d.mapID,d.x,d.y) then
        return false,"No directly mapped destination to place."
    end
    if type(C_Map)~="table" or type(C_Map.SetUserWaypoint)~="function" then
        return false,"Native waypoint API unavailable."
    end
    local permitted,ok=N:SafeCall(C_Map.CanSetUserWaypointOnMap,d.mapID)
    if not stillCurrent() then return stale() end
    if not ok or permitted~=true then return false,"Blizzard does not allow a waypoint on this map." end
    local current,read=N.Quest:ReadUserWaypoint()
    if not stillCurrent() then return stale() end
    if not read then self:ClearWaypointConfirmation();return false,"Could not read Blizzard's current waypoint." end
    if samePoint(d,current,.00001) then
        self:ClearWaypointConfirmation()
        return true,"Blizzard already has a waypoint at this location."
    end
    if current then
        local now,clock=N:SafeCall(GetTime)
        if not clock or not N:Number(now) then
            self:ClearWaypointConfirmation()
            return false,"Could not start a timed waypoint replacement."
        end
        local pending=self.pendingReplacement
        if not pending or now<pending.at or now-pending.at>10 or
           not samePoint(pending.current,current,0) or not samePoint(pending.destination,d,0) then
            self.pendingReplacement={current=current,destination={mapID=d.mapID,x=d.x,y=d.y},at=now}
            return false,"This will replace the current Blizzard waypoint. Select Place waypoint again within 10 seconds."
        end
    end
    self:ClearWaypointConfirmation()
    local factory=type(UiMapPoint)=="table" and UiMapPoint.CreateFromCoordinates
    local point,valid=N:SafeCall(factory,d.mapID,d.x,d.y)
    if not valid or point==nil then
        local vector,v=N:SafeCall(CreateVector2,d.x,d.y)
        factory=type(UiMapPoint)=="table" and UiMapPoint.CreateFromVector2D
        if not v or vector==nil then return false,"Native waypoint format unavailable." end
        point,valid=N:SafeCall(factory,d.mapID,vector)
    end
    if not valid or point==nil then return false,"Native waypoint format unavailable." end
    if not stillCurrent() then return stale() end
    local latest,latestRead=N.Quest:ReadUserWaypoint()
    if not stillCurrent() then return stale() end
    if not latestRead or not ((latest==nil and current==nil) or samePoint(latest,current,0)) then
        self:ClearWaypointConfirmation();return false,"The native waypoint changed. Select Place waypoint again to review it."
    end
    local result,called=N:SafeCall(C_Map.SetUserWaypoint,point)
    if not called or result==false then return false,"Blizzard declined to place the waypoint." end
    local observed,checked=N.Quest:ReadUserWaypoint()
    if checked and samePoint(d,observed,.00001) then return true,"Blizzard waypoint placed." end
    if result==true then return true,"Blizzard accepted the waypoint. Check the map for its position." end
    return false,"Blizzard did not confirm that the waypoint changed. Check the map before retrying."
end
function N.API:PinCandidate(questID)
    if not N.state.clientAllowed or N:InCombat() then return false,"Quest pin changes are unavailable right now." end
    if N.Storage.readOnly or not N:Integer(questID) then return false,"Quest pin changes are unavailable right now." end
    -- A row displayed before a quest update is not click-time evidence. Read
    -- current accepted identities and published supplements before focusing;
    -- a removed quest must not recreate a persistent, unresolvable pin.
    local player=N.map:Player()
    local scanned=N.Quest:Refresh(player)
    if not scanned then return false,"Quest information is changing. Try Focus again." end
    -- A deliberate Quest Notes selection can be outside the current bounded
    -- automatic set. Resolve that one native quest, never invent a location.
    local row=N.Quest:Build(questID,"USER_SELECTED_QUEST",player)
    if row and not row.awaitingTurnIn then
        return N.Storage:Pin({kind="quest",source="USER_SELECTED_QUEST",label=row.label,
            mapID=row.mapID,x=row.x,y=row.y,questID=row.questID})
    end
    return false,"Quest has no eligible native waypoint."
end
function N.API:PinHere()
    if not N.state.clientAllowed or N:InCombat() then return false,"Cannot pin this location right now." end
    local current,why=N.map:Player()
    if not current then return false,why end
    return N.Storage:Pin({kind="manual",source="USER_SELECTED_POSITION",label="My pinned location",
         mapID=current.mapID,x=current.x,y=current.y})
end
function N.API:Request(source,candidate,options)
    if not N.state.clientAllowed or N:InCombat() then return false,"CLIENT_OR_COMBAT_UNAVAILABLE" end
    if N.Storage.readOnly then return false,"STORAGE_READ_ONLY" end
    if source~="gather" and source~="manual" then return false,"UNSUPPORTED_SOURCE" end
    if type(options)~="table" or options.userInitiated~=true then return false,"USER_ACTION_REQUIRED" end
    if type(candidate)~="table" or not N.map:Valid(candidate.mapID,candidate.x,candidate.y) then
        return false,"INVALID_COORDINATE"
    end
    local label=N:Text(candidate.label)
    if not label then return false,"INVALID_LABEL" end
    if source=="manual" then
        return N.Storage:Pin({kind="manual",source="USER_SELECTED_POSITION",label=label,
            mapID=candidate.mapID,x=candidate.x,y=candidate.y,recordID=N:Text(candidate.recordID) or N:Text(candidate.id),
            siteID=N:Text(candidate.siteID),category=N:Text(candidate.category),name=N:Text(candidate.name),
            sourceRevision=candidate.sourceRevision,purpose=N:Text(candidate.purpose),floorID=candidate.floorID,
            taxiNodeID=candidate.taxiNodeID,nodeID=candidate.nodeID})
    end
    local ttl=N:Number(options.ttlSeconds) and math.max(30,math.min(3600,options.ttlSeconds)) or 1800
    if candidate.requireRecord==true and (not N:Text(candidate.recordID) or not N:Text(candidate.siteID) or
        not N:Text(candidate.name) or not N:Text(candidate.category)) then return false,"INVALID_RECORD_IDENTITY" end
    N.requests.gather={mapID=candidate.mapID,x=candidate.x,y=candidate.y,label=label,
      siteID=N:Text(candidate.siteID) or N:Text(candidate.id),recordID=N:Text(candidate.recordID),
      category=N:Text(candidate.category),name=N:Text(candidate.name),
      floorID=N:Integer(candidate.floorID) and candidate.floorID or candidate.mapID,requireRecord=candidate.requireRecord==true,
      sourceRevision=N:Number(candidate.sourceRevision) and candidate.sourceRevision or N:Text(candidate.sourceRevision),
      expiresAt=N:Now()+ttl}
    N.Session:IntentChanged("GATHER_DESTINATION_SELECTED")
    N:Invalidate("GATHER_DESTINATION_SELECTED")
    return true,"USER_REQUEST_ACCEPTED"
end
function N.API:Release(source)
    if not N.state.clientAllowed or N:InCombat() then return false,"CLIENT_OR_COMBAT_UNAVAILABLE" end
    if source=="manual" then return N.Storage:Pin(nil) end
    if source=="gather" then N.requests.gather=nil;N.Session:IntentChanged("GATHER_DESTINATION_CLEARED");N:Invalidate("GATHER_DESTINATION_CLEARED");return true end
    return false,"UNKNOWN_SOURCE"
end
function N.API:CursorOverride()
    if not N.state.clientAllowed or N.Storage.readOnly or N.state.mode=="Off" or N.state.mode=="Pause" or not N.Controller:Ready() then return nil end
    local candidate=N.Session.directionTarget or (not N.Session.route and N.active)
    if not candidate or not candidate.world or not candidate.distance then return nil end
    local w=candidate.world
    if not N:Number(w.x) or not N:Number(w.y) or not N:Number(w.continent) then return nil end
    local player=N.map:Player()
    if not player or not player.world or player.world.continent~=w.continent or player.mapID~=candidate.mapID
        or (player.floorID or player.mapID)~=(candidate.floorID or candidate.mapID) then return nil end
    return {mapID=candidate.mapID,worldX=w.x,worldY=w.y,continent=w.continent,
       label=candidate.label,source=candidate.source or "MANUAL_PIN",stage="OBJECTIVES",
       quality="USER_SELECTED",questID=candidate.questID}
end
function N.API:Install()
    local A={apiVersion=1,navigationVersion=2,guidanceVersion=N.Guidance and 1 or nil,headerVersion=1,questInteractionVersion=N.QuestInteraction and 1 or nil,
        coordinateWaypointVersion=1,version=N.version,targetBuild=N.state.clientBuild or "unknown",nativeVerification="NOT_RUN"}
    function A.GetDestination() return N._copy(N.active) end
    function A.GetCandidates() return N._copy(N.candidates) end
    function A.GetStatus()
        return N._copy({status=N.state.status,mode=N.state.mode,provider=N.state.provider,
         candidateCount=#N.candidates,refreshes=N.state.refreshes,errors=N.state.errors,
         clientAllowed=N.state.clientAllowed,storage=N.Storage:Status(),navigation=N.Session:Snapshot(),
         planner=N.Planner:Snapshot(),questInteraction=N.QuestInteraction and N.QuestInteraction:Snapshot(),questReadStatus=N.state.lastNativeResult,
         catalogStatus=N.Quest.catalogStatus,questLocations=N.Quest.locationCounts,
         reconciliationGeneration=N.state.reconciliationGeneration or 0,
         nativeVerification="NOT_RUN"})
    end
    function A.GetCursorOverride() return N._copy(N.API:CursorOverride()) end
    function A.RequestDestination(source,candidate,options) return N.API:Request(source,candidate,options) end
    function A.ReleaseDestination(source) return N.API:Release(source) end
    function A.GetCoordinateWaypoint() return N.API:CoordinateWaypoint() end
    function A.SetCoordinateWaypoint(mapID,x,y,options) return N.API:SetCoordinateWaypoint(mapID,x,y,options) end
    function A.ClearCoordinateWaypoint(expected) return N.API:ClearCoordinateWaypoint(expected) end
    function A.SetMode(mode) return N.Storage:SetMode(mode) end
    function A.SetShowHUD(value) return N.Storage:SetHUD(value) end
    function A.GetQuestInteractionStatus() return N.QuestInteraction and N.QuestInteraction:Snapshot() end
    function A.SetQuestInteractionPreferences(values)
        if not N.QuestInteraction then return false,"QUEST_INTERACTION_UNAVAILABLE" end
        return N.QuestInteraction:SetPreferences(values)
    end
    function A.PinQuest(questID) return N.API:PinCandidate(questID) end
    function A.PinCurrentPosition() return N.API:PinHere() end
    function A.ClearPin() return N.Storage:Pin(nil) end
    function A.PlaceBlizzardWaypoint() return N.API:PlaceBlizzardWaypoint() end
    function A.Refresh() N:Invalidate("MANUAL_REFRESH");N.Controller:Refresh(true);return true end
    function A.Open() return N.UI:Open() end
    local function changed(ok,reason)
        if ok and N.Controller then N.Controller:Refresh(true) end
        return ok,reason
    end
    function A.GetNavigationSnapshot() return N.Session:Snapshot() end
    function A.GetGuidanceSnapshot() return N.Guidance and N.Guidance:Snapshot() or nil end
    function A.GetHeaderSnapshot() return N.HUD and N.HUD:Snapshot() or nil end
    function A.GetSupportStatus()
        local d=N.active;local g=N.Guidance;local lease=N.Session.renderer
        return {status=N.state.status,mode=N.state.mode,clientAllowed=N.state.clientAllowed==true,
            errors=N.state.errors,lastError=N.state.lastError,navigationRevision=N.state.navigationRevision or 0,
            destinationPresent=d~=nil,kind=d and d.kind,selectionTier=d and d.selectionTier,
            renderer=lease and lease.owner or "NONE",routeStopCount=d and (N.Session.lastItineraryCount or 1) or 0,
            questInteractionStatus=N.QuestInteraction and N.QuestInteraction.status or "UNAVAILABLE",
            questInteractionActions=N.QuestInteraction and N.QuestInteraction.actions or 0,
            guidanceStatus=N.state.mode=="Off" and "OFF" or N.state.mode=="Pause" and "PAUSED" or
                not d and "NO_DESTINATION" or g and g.status or "NOT_SAMPLED",guidanceSamples=g and g.samples or 0}
    end
    function A.GetItinerary() return N.Session:Itinerary() end
    function A.GetRouteOverlay()
        local a=N.Storage.account or {}
        local itinerary=N.Session:Itinerary()
        return N._copy({revision=N.state.navigationRevision or 0,mode=N.Session:Mode(),stops=itinerary.stops,
            activeID=N.active and N.active.id,showMap=a.showMapRoute~=false,showMinimap=a.showMinimapRoute~=false,
            geometry="STOP_GUIDE"})
    end
    function A.SetRoutePreference(key,value)
        if key~="showMapRoute" and key~="showMinimapRoute" and key~="gatherFallback" then return false,"INVALID_PREFERENCE" end
        if type(value)~="boolean" or N.Storage.readOnly or not N.state.clientAllowed or N:InCombat() then return false,"CLIENT_OR_COMBAT_UNAVAILABLE" end
        N.Storage.account[key]=value;N.Storage.account.revision=N.Storage.account.revision+1
        N.state.navigationRevision=(N.state.navigationRevision or 0)+1
        N:Invalidate("ROUTE_PREFERENCE_CHANGED")
        if N.core and N.core.Publish then N.core.Publish("NAV_SESSION_CHANGED",N.Session:Snapshot()) end
        return true
    end
    function A.SkipDestination()
        if N:InCombat() or N.Storage.readOnly or not N.state.clientAllowed then return false,"CLIENT_OR_COMBAT_UNAVAILABLE" end
        local d=N.active;if not d then return false,"NO_DESTINATION" end
        -- The visible stop may be a temporary fallback while a different
        -- saved quest has no current location. Skip that stop, not the focus.
        if d.selectionTier=="PLAYER_FOCUS" and N.Storage.character.pin then N.Storage:Pin(nil) end
        if d.kind=="gather" then return changed(N.Session:Skip("SKIPPED")) end
        if d.questID then return changed(N.Planner:Skip(d.questID)) end
        if d.kind=="waypoint" then return changed(N.Authority:SkipWaypoint(d)) end
        return changed(N.API:Release("manual"))
    end
    function A.GetPlannerExplanation() return N.Planner:Snapshot() end
    function A.SetPlannerPreferences(values) return changed(N.Planner:SetPreferences(values)) end
    function A.SetGatherSessionSettings(values) return changed(N.Session:SetSettings(values)) end
    function A.GetFlightConnections()
        local graph=N:Service("TravelGraph")
        local value,ok=N:SafeCall(graph and graph.GetNodes)
        return ok and N:Table(value) and N._copy(value) or {records={},status="TRAVEL_GRAPH_UNAVAILABLE"}
    end
    function A.SelectFlightDestination(nodeID)
        if not N:Integer(nodeID) then return false,"INVALID_FLIGHT_NODE" end
        local nodes=A.GetFlightConnections()
        for _,row in ipairs(nodes.records or {}) do if row.nodeID==nodeID or row.taxiNodeID==nodeID then
            row.purpose="FLIGHT_PREVIEW"
            return changed(N.API:Request("manual",row,{userInitiated=true}))
        end end
        return false,"FLIGHT_CONNECTION_NO_LONGER_AVAILABLE"
    end
    function A.SetSessionMode(mode,options) return changed(N.Session:SetMode(mode,options)) end
    function A.StartGatherSession(options) return changed(N.Session:StartGather(options)) end
    function A.StopGatherSession() return changed(N.Session:StopGather()) end
    function A.SkipGatherDestination(reason) return changed(N.Session:Skip(reason)) end
    function A.ConfirmGatherOutcome(siteID,sessionID,generation,evidence)
        return changed(N.Session:Confirm(siteID,sessionID,generation,evidence))
    end
    function A.NotifyGatherInteraction(siteID,sessionID,generation,evidence)
        return changed(N.Session:Interaction(siteID,sessionID,generation,evidence))
    end
    function A.Pause() return changed(N.Session:Pause()) end
    function A.Resume() return changed(N.Session:Resume()) end
    function A.RegisterGatherProvider(owner,version,provider) return N.Session:RegisterProvider(owner,version,provider) end
    function A.UnregisterGatherProvider(owner) return N.Session:UnregisterProvider(owner) end
    function A.InvalidateGatherProvider(owner) return N.Session:InvalidateProvider(owner) end
    function A.AcquireRenderer(owner,revision,ttl) return N.Session:AcquireRenderer(owner,revision,ttl) end
    function A.ReleaseRenderer(owner) return N.Session:ReleaseRenderer(owner) end
    MirageNavigateAPI=A
    local accepted,called=N:SafeCall(N.core and N.core.RegisterService,"Navigate","MirageIntel_Navigate",1,A)
    if N.state.clientAllowed and (not called or not accepted) then N:Fault("SERVICE_REGISTRATION_FAILED") end
end
