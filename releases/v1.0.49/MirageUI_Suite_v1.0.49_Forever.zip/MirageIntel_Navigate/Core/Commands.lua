local _,N=...
N.Commands={}
function N.Commands:Install()
    SLASH_MIRAGENAVIGATE1="/miragenav"
    SLASH_MIRAGENAVIGATE2="/mnav"
    SLASH_MIRAGENAVIGATE3="/wayfinder"
    SlashCmdList.MIRAGENAVIGATE=function(msg)
        local cmd=type(msg)=="string" and msg:lower():match("^%s*(.-)%s*$") or ""
        local modes={auto="Auto",quest="Auto",follow="Auto",nearest="Auto",manual="Manual only",off="Off"}
        if cmd=="status" then
            N:Print("mode="..N.state.mode.."; status="..N.state.status.."; provider="..(N.state.provider or "NONE")
               .."; stored="..N.Storage.reason.."; quest interaction="..(N.QuestInteraction and N.QuestInteraction.status or "UNAVAILABLE").."; native=NOT_RUN")
        elseif cmd=="quests" or cmd=="settings" then
            N.UI.view=cmd=="quests" and "quests" or "settings"
            local ok,why=N.UI:Open();if not ok and why then N:Print(why) end
        elseif cmd=="gather" then
            local ok,why
            if N.state.mode=="Gather" then ok,why=N.Session:StopGather() else ok,why=N.Session:StartGather({userInitiated=true}) end
            if ok then N.Controller:Refresh(true) else N:Print(why) end
        elseif cmd=="pause" or cmd=="resume" then
            local ok,why
            if cmd=="pause" then ok,why=N.Session:Pause() else ok,why=N.Session:Resume() end
            if ok then N.Controller:Refresh(true) else N:Print(why) end
        elseif cmd=="why" then
            local d=N.active
            N:Print(d and N.UI:SelectionDetail(d) or N.UI:Reason(N.state.status))

        elseif cmd=="flights" then
            N.UI.view="journey";N.UI.page=1;local ok,why=N.UI:Open();if not ok then N:Print(why) end
        elseif cmd=="skip" then
            local ok,why=MirageNavigateAPI.SkipDestination();if ok then N.Controller:Refresh(true) else N:Print(why) end
        elseif cmd=="refresh" then
            N:Invalidate("PLAYER_REQUESTED")
            N.Controller:Refresh(true)
            N:Print("Quest position refresh requested.")
        elseif cmd=="pin here" then
            local ok,why=N.API:PinHere();if not ok then N:Print(why) else N.Controller:Refresh(true);N:Print("Current map position pinned.") end
        elseif cmd=="clear" then
            local ok,why=N.Storage:Pin(nil);if not ok then N:Print(why) else N.Controller:Refresh(true);N:Print("Addon pin cleared; Blizzard's waypoint unchanged.") end
        elseif cmd=="hud" then
            local value=N.Storage.account and N.Storage.account.showHUD
            local ok,why=N.Storage:SetHUD(not value)
            if not ok then N:Print(why) else N.HUD:Update() end
        elseif modes[cmd] then
            local ok,why=N.Storage:SetMode(modes[cmd]);if not ok then N:Print(why) else N.Controller:Refresh(true);N:Print("Mode: "..modes[cmd]) end
        elseif cmd=="waypoint" then
            local ok,why=N.API:PlaceBlizzardWaypoint();N:Print(why or (ok and "Waypoint set" or "Failed"))
        else
            local ok,why=N.UI:Open()
            if not ok and why then N:Print(why) end
        end
    end
end
