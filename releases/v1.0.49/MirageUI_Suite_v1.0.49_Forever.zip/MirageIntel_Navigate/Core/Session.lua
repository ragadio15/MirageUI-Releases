local _,N=...
-- Intent, evidence and presentation have separate lifetimes. A radius visit
-- never proves harvest; provider callbacks must match the captured generation.
N.Session={serial=0,generation=0,providerRevision=0,excluded={},excludeOrder={},deferrals={},
    nextProbeAt=0,status="IDLE",circuit={},circuitRevision=0,circuitSerial=0,route=nil}
local S=N.Session
local publicModes={Auto=true,Quest=true,Gather=true,Pause=true,Off=true,Manual=true}
local function copy(value) return N._copy and N._copy(value) or nil end
function S:Mode()
    local mode=N.state.mode
    if mode=="Manual only" then return "Manual" end
    return publicModes[mode] and mode or "Auto"
end
function S:Settings()
    local saved=type(N.Storage.account)=="table" and N.Storage.account.gatherSession or {}
    local dwell=N:Field(saved,"dwellSeconds");local stops=N:Field(saved,"circuitStops")
    return {dwellSeconds=N:Number(dwell) and math.max(5,math.min(120,dwell)) or 20,
        circuitStops=N:Integer(stops) and math.max(2,math.min(12,stops)) or 8}
end
function S:SetSettings(values)
    if not N:Table(values) then return false,"INVALID_GATHER_SETTINGS" end
    if N.Storage.readOnly or not N.state.clientAllowed or N:InCombat() then return false,"CLIENT_OR_COMBAT_UNAVAILABLE" end
    local out=self:Settings()
    for key,value in pairs(values) do
        if key=="dwellSeconds" and N:Number(value) and value>=5 and value<=120 then out[key]=value
        elseif key=="circuitStops" and N:Integer(value) and value>=2 and value<=12 then out[key]=value
        else return false,"INVALID_GATHER_SETTING" end
    end
    N.Storage.account.gatherSession=out;N.Storage.account.revision=N.Storage.account.revision+1
    self:CancelCircuit();self.nearSince=nil;self.circuitDirty=true;self.circuitRevision=self.circuitRevision+1;self.itineraryKey=nil;N:Invalidate("GATHER_SETTINGS_CHANGED")
    return true,"GATHER_SETTINGS_UPDATED"
end
function S:Initialize()
    if N.Storage.readOnly then return end
    local a=N.Storage.account
    self.returnMode=type(a)=="table" and N:Text(a.gatherReturnMode) or "Auto"
    self.resumeMode=type(a)=="table" and N:Text(a.resumeMode) or "Auto"
    if N.state.mode=="Gather" then self:NewGather(N:Table(a.gatherFilters) and a.gatherFilters or {}) end
end
function S:Token() return {id=self.id,generation=self.generation,provider=self.provider,providerRevision=self.providerRevision,
    mode=N.state.mode,combat=N:InCombat(),combatRevision=N.state.combatRevision or 0} end
function S:TokenCurrent(token)
    local combat=N:InCombat()
    return token and token.id==self.id and token.generation==self.generation and token.provider==self.provider and
        token.providerRevision==self.providerRevision and token.mode==N.state.mode and token.combat==combat and
        token.combatRevision==(N.state.combatRevision or 0) and not N.state.suspended
end
function S:SameCanonicalSite(retained,row)
    return N:Table(row) and N:Field(row,"owner")=="MirageIntel_Gather" and
        N:Field(row,"kind")=="gather" and N:Field(row,"hidden")~=true and
        N:Field(row,"siteID")==retained.siteID and N:Field(row,"mapID")==retained.mapID and
        N:Field(row,"x")==retained.x and N:Field(row,"y")==retained.y and
        (N:Field(row,"floorID") or N:Field(row,"mapID"))==(retained.floorID or retained.mapID) and
        N:Field(row,"name")==retained.name and N:Field(row,"category")==retained.category
end
function S:CancelCircuit()
    self.circuitSerial=(self.circuitSerial or 0)+1;self.circuitPending=nil
    local tasks=N:Service("Tasks")
    if tasks and type(tasks.Cancel)=="function" then N:SafeCall(tasks.Cancel,"MirageIntel_Navigate.circuit") end
end
function S:RecordsChanged()
    self:CancelCircuit()
    -- A circuit contains positions, not just eligible IDs. Never reuse those
    -- positions after the canonical catalog changes. A normal quality/visit
    -- update to the current site must retain its harvest-correlation token.
    self.circuit={};self.circuitDirty=true;self.circuitRevision=(self.circuitRevision or 0)+1
    local retained=self.current
    if not retained or N.state.mode~="Gather" and N.state.mode~="Auto" then return end
    local token=self:Token();local records=N:Service("WorldRecords")
    local row,read=N:SafeCall(records and records.Get,retained.siteID)
    local unchanged=read and self:SameCanonicalSite(retained,row)
    if not self:TokenCurrent(token) or self.current~=retained then return end
    if unchanged then
        retained.sourceRevision=N:Field(row,"sourceRevision")
        return
    end
    self:Reconcile("GATHER_RECORD_REVALIDATING",true)
    N:Invalidate("GATHER_RECORD_REVALIDATING")
    if N.active and N.active.source=="GATHER_SESSION" then N.Authority:Change(nil,"GATHER_RECORD_REVALIDATING") end
end
function S:Reconcile(reason,clearCurrent)
    self:CancelCircuit()
    if N.API then N.API.coordinateNear=nil end
    self.generation=self.generation+1;self.nearSince=nil;self.nextProbeAt=0;self.nextEligibilityAt=0
    self.route=nil;self.routeKey=nil;self.circuitDirty=true;self:ReleaseRenderer()
    if clearCurrent then self.current=nil
    elseif self.current then self.current.generation=self.generation end
    self.lastReconcile=reason
end
function S:IntentChanged(reason)
    self:Reconcile(reason,false)
    if N.API then N.API:ClearWaypointConfirmation() end
    if N.Authority then N.Authority:Change(nil,"EXPLICIT_INTENT_PENDING") end
end
function S:NewGather(filters,preserveRequest)
    self:CancelCircuit()
    if not preserveRequest then N.requests.gather=nil end
    self.serial=self.serial+1
    local epoch=N.Storage.character and N.Storage.character.sessionEpoch or 0
    self.id="gather:"..tostring(epoch)..":"..self.serial
    self.generation=self.generation+1
    self.filters=copy(filters or {}) or {}
    N.Storage.account.gatherFilters=copy(self.filters)
    self.excluded={};self.excludeOrder={};self.deferrals={};self.current=nil;self.previousSiteID=nil;self.circuit={}
    self.nextProbeAt=0;self.nearSince=nil;self.status="WAITING_GATHER_PROVIDER";self.circuitDirty=true
    self.route=nil;self.routeKey=nil;self.completedStops=0
    self.progress={castCompletions=0,confirmedHarvests=0,visited=0,skipped=0}
end
function S:OnModeChanged(mode,previous)
    self:CancelCircuit()
    local a=N.Storage.account;self.nearSince=nil
    if mode=="Pause" then
        if previous~="Pause" then self.resumeMode=previous or "Auto";a.resumeMode=self.resumeMode end
        self:Reconcile("PLAYER_PAUSED",false)
    elseif mode=="Gather" then
        if previous~="Pause" and previous~="Gather" then
            self.returnMode=previous~="Off" and previous or "Auto";a.gatherReturnMode=self.returnMode
            self:NewGather(self.pendingFilters);self.pendingFilters=nil
        elseif not self.id then self:NewGather(a.gatherFilters)
        else self:Reconcile("PLAYER_RESUMED",true) end
    elseif previous=="Gather" or (previous=="Pause" and self.resumeMode=="Gather") then
        self.current=nil;self.id=nil;self.generation=self.generation+1;self.status="IDLE";self.circuit={}
    else self:Reconcile("MODE_CHANGED",false) end
    if mode=="Off" or (mode~="Pause" and previous~="Pause") then N.requests.gather=nil end
    if N.Planner then N.Planner:Invalidate("MODE_CHANGED") end
    self.route=nil;self.routeKey=nil;self:ReleaseRenderer()
    if N.Authority then N.Authority:Change(nil,mode=="Pause" and "PAUSED" or mode=="Off" and "OFF" or "SELECTION_PENDING") end
    if N.HUD and N.HUD.frame then N.HUD.frame:Hide() end
end
function S:SetMode(mode,options)
    if type(options)~="table" or options.userInitiated~=true then return false,"USER_ACTION_REQUIRED" end
    if not publicModes[mode] then return false,"INVALID_SESSION_MODE" end
    if mode=="Gather" then return self:StartGather(options) end
    return N.Storage:SetMode(mode=="Manual" and "Manual only" or mode)
end
function S:StartGather(options)
    if type(options)~="table" or options.userInitiated~=true then return false,"USER_ACTION_REQUIRED" end
    if N:InCombat() or not N.state.clientAllowed or N.Storage.readOnly then return false,"CLIENT_OR_COMBAT_UNAVAILABLE" end
    if options.filters~=nil and not N:Table(options.filters) then return false,"INVALID_GATHER_FILTERS" end
    self.pendingFilters=copy(options.filters or {}) or {}
    if N.state.mode=="Gather" then
        -- A second enable refreshes the existing session; a deliberate restart
        -- is explicit and cannot silently discard session deferrals.
        if options.restart~=true then self.pendingFilters=nil;return true,"GATHER_SESSION_ALREADY_ACTIVE" end
        self:NewGather(self.pendingFilters);self.pendingFilters=nil;N:Invalidate("GATHER_SESSION_RESTARTED")
        N.Authority:Change(nil,"SELECTION_PENDING");return true,"GATHER_SESSION_STARTED"
    end
    local ok,reason=N.Storage:SetMode("Gather")
    return ok,ok and "GATHER_SESSION_STARTED" or reason
end
function S:StopGather()
    if N:InCombat() then return false,"CLIENT_OR_COMBAT_UNAVAILABLE" end
    if N.state.mode~="Gather" and not (N.state.mode=="Pause" and self.resumeMode=="Gather") then return true,"GATHER_SESSION_INACTIVE" end
    local mode=self.returnMode;N.requests.gather=nil
    if mode~="Auto" and mode~="Quest" and mode~="Follow Blizzard" and mode~="Nearest quest" and mode~="Manual only" then mode="Auto" end
    return N.Storage:SetMode(mode)
end
function S:Pause() if N.state.mode=="Pause" then return true,"PAUSED" end;return N.Storage:SetMode("Pause") end
function S:Resume()
    if N.state.mode~="Pause" then return true,"NOT_PAUSED" end
    local mode=self.resumeMode
    if mode~="Auto" and mode~="Quest" and mode~="Gather" and mode~="Follow Blizzard" and mode~="Nearest quest" and mode~="Manual only" then mode="Auto" end
    return N.Storage:SetMode(mode)
end
function S:RegisterProvider(owner,version,provider)
    if owner~="MirageIntel_Gather" or version~=2 or not N:Table(provider) or type(provider.GetNext)~="function" then
        return false,"INVALID_GATHER_PROVIDER"
    end
    if self.provider and self.provider.owner~=owner then return false,"GATHER_PROVIDER_ALREADY_OWNED" end
    self.provider={owner=owner,GetNext=provider.GetNext,Defer=type(provider.Defer)=="function" and provider.Defer or nil,
        IsEligible=type(provider.IsEligible)=="function" and provider.IsEligible or nil,
        GetCandidates=type(provider.GetCandidates)=="function" and provider.GetCandidates or nil,
        GetStatus=type(provider.GetStatus)=="function" and provider.GetStatus or nil}
    self.providerRevision=self.providerRevision+1;self:Reconcile("GATHER_PROVIDER_READY",true)
    N:Invalidate("GATHER_PROVIDER_READY")
    if N.active and N.active.source=="GATHER_SESSION" then N.Authority:Change(nil,"GATHER_REVALIDATION_PENDING") end
    return true,"REGISTERED"
end
function S:ProviderCall(method,...)
    local fn=self.provider and self.provider[method]
    if type(fn)~="function" then return false,nil,"PROVIDER_METHOD_MISSING" end
    local previous=self.inProvider;self.inProvider=true
    local ok,a,b=pcall(fn,...);self.inProvider=previous
    if ok and (not N:Readable(a) or not N:Readable(b)) then return false,nil,"UNREADABLE_PROVIDER_RESULT" end
    return ok,a,b
end
function S:InvalidateProvider(owner)
    if not self.provider or self.provider.owner~=owner then return false,"PROVIDER_NOT_REGISTERED" end
    self.providerRevision=self.providerRevision+1;self.nextEligibilityAt=0;self.nextProbeAt=0;self.circuitDirty=true
    N:Invalidate("GATHER_PROVIDER_INVALIDATED")
    if self.inProvider then return true,"REVALIDATION_QUEUED" end
    if N:InCombat() then
        self:Reconcile("GATHER_PROVIDER_INVALIDATED",true)
        if N.active and N.active.kind=="gather" and N.active.source=="GATHER_SESSION" then N.Authority:Change(nil,"GATHER_REVALIDATION_PENDING") end
    elseif N.Controller and N.Controller:Ready() then N.Controller:Refresh(false) end
    return true,"REVALIDATION_QUEUED"
end
function S:UnregisterProvider(owner)
    if not self.provider or self.provider.owner~=owner then return false,"PROVIDER_NOT_REGISTERED" end
    self.provider=nil;self.providerRevision=self.providerRevision+1;self:Reconcile("GATHER_PROVIDER_REMOVED",true)
    self.circuit={};self.status="WAITING_GATHER_PROVIDER";N:Invalidate("GATHER_PROVIDER_REMOVED")
    if N.active and N.active.source=="GATHER_SESSION" then N.Authority:Change(nil,self.status) end
    return true
end
function S:Context(player)
    return {player=copy(player),previousSiteID=self.previousSiteID,excludedIDs=copy(self.excluded),filters=copy(self.filters),
        sessionID=self.id,generation=self.generation,providerRevision=self.providerRevision,now=N:Now(),mode="Gather",limit=64}
end
function S:Exclude(siteID,reason)
    if not self.excluded[siteID] then self.excludeOrder[#self.excludeOrder+1]=siteID end
    self.excluded[siteID]=true;self.deferrals[siteID]={reason=reason,at=N:Now(),outcome=reason=="CONFIRMED_HARVEST" and "HARVESTED" or
        reason=="CAST_COMPLETED" and "INTERACTED" or "UNCONFIRMED"}
    while #self.excludeOrder>256 do local old=table.remove(self.excludeOrder,1);self.excluded[old]=nil;self.deferrals[old]=nil end
    if self.provider and self.provider.Defer then
        local ok=self:ProviderCall("Defer",siteID,reason);if not ok then N:Fault("GATHER_DEFER_PROVIDER_ERROR") end
    end
end
function S:Advance(reason)
    local current=self.current;if not current then return false,"NO_GATHER_DESTINATION" end
    self:CancelCircuit()
    -- Invalidate the outcome token before invoking a provider callback.
    self.previousSiteID=current.siteID;self.current=nil;self.nearSince=nil;self.generation=self.generation+1
    self.nextProbeAt=0;self.status=reason;self.completedStops=(self.completedStops or 0)+1
    self.progress=self.progress or {castCompletions=0,confirmedHarvests=0,visited=0,skipped=0}
    local count=reason=="CONFIRMED_HARVEST" and "confirmedHarvests" or reason=="CAST_COMPLETED" and "castCompletions" or
        reason=="VISITED_UNCONFIRMED" and "visited" or "skipped"
    self.progress[count]=(self.progress[count] or 0)+1
    local token=self:Token();self:Exclude(current.siteID,reason);N:Invalidate("GATHER_"..reason)
    if self:TokenCurrent(token) then N.Authority:Change(nil,"GATHER_NEXT_PENDING") end
    return true,reason
end
function S:Skip(reason)
    if N:InCombat() or N.Storage.readOnly or not N.state.clientAllowed then return false,"CLIENT_OR_COMBAT_UNAVAILABLE" end
    if N.state.mode=="Pause" or N.state.mode=="Off" then return false,"GATHER_SESSION_INACTIVE" end
    if N.active and N.active.selectionTier=="PLAYER_FOCUS" and N.Storage.character and N.Storage.character.pin then return false,"MANUAL_PIN_HAS_PRIORITY" end
    if N.requests.gather and N.active and N.active.source=="GATHER_USER_SELECTED" then
        N.requests.gather=nil;self:IntentChanged("EXPLICIT_GATHER_SELECTION_CLEARED");N:Invalidate("EXPLICIT_GATHER_SELECTION_CLEARED")
        N.Authority:Change(nil,"GATHER_NEXT_PENDING");return true,"EXPLICIT_GATHER_SELECTION_CLEARED"
    end
    if N.state.mode~="Gather" and N.state.mode~="Auto" then return false,"GATHER_SESSION_INACTIVE" end
    return self:Advance(reason=="MISSING" and "MISSING" or reason=="DEPLETED" and "PLAYER_REPORTED_DEPLETED" or "SKIPPED")
end
function S:Confirm(siteID,sessionID,generation,evidence)
    if N:InCombat() then return false,"COMBAT_OUTCOME_DEFERRED" end
    local d=N.active
    if N.state.suspended or (N.state.mode~="Gather" and N.state.mode~="Auto") or not self.current or not d or d.kind~="gather" or d.source~="GATHER_SESSION" or
        d.sessionID~=self.id or d.generation~=self.generation or siteID~=self.current.siteID or siteID~=d.siteID or
        sessionID~=self.id or generation~=self.generation then return false,"STALE_GATHER_OUTCOME" end
    if not N:Table(evidence) or evidence.quality~="CONFIRMED" or evidence.sourceMatched~=true or evidence.outcome~="HARVESTED" then
        return false,"UNCONFIRMED_GATHER_OUTCOME"
    end
    return self:Advance("CONFIRMED_HARVEST")
end
function S:Interaction(siteID,sessionID,generation,evidence)
    if N:InCombat() then return false,"COMBAT_OUTCOME_DEFERRED" end
    local d=N.active
    if N.state.suspended or (N.state.mode~="Gather" and N.state.mode~="Auto") or not self.current or not d or
        d.source~="GATHER_SESSION" or d.siteID~=siteID or self.current.siteID~=siteID or
        sessionID~=self.id or generation~=self.generation or d.generation~=generation then return false,"STALE_GATHER_OUTCOME" end
    if not N:Table(evidence) or evidence.outcome~="CAST_COMPLETED" or not N:Text(evidence.castGUID) or
        (evidence.category~="herb" and evidence.category~="ore") or evidence.category~=d.category or
        evidence.name~=d.name or evidence.mapID~=d.mapID or (evidence.floorID or evidence.mapID)~=(d.floorID or d.mapID) or
        not N.map:Valid(evidence.mapID,evidence.x,evidence.y) then return false,"UNMATCHED_GATHER_INTERACTION" end
    local token=self:Token();local player=N.map:Player()
    local world=N.map:World(evidence.mapID,evidence.x,evidence.y)
    local castDistance=world and N.map:Measure({world=world},d)
    local currentDistance=player and N.map:Measure(player,d)
    if not self:TokenCurrent(token) or not player or player.mapID~=d.mapID or
        (player.floorID or player.mapID)~=(d.floorID or d.mapID) or not N:Number(castDistance) or castDistance>8 or
        not N:Number(currentDistance) or currentDistance>8 then return false,"GATHER_INTERACTION_LOCATION_CHANGED" end
    self.interactionIDs=self.interactionIDs or {};self.interactionOrder=self.interactionOrder or {}
    local now=N:Now()
    for i=#self.interactionOrder,1,-1 do
        local old=self.interactionOrder[i]
        if now<old.at or now-old.at>120 then self.interactionIDs[old.guid]=nil;table.remove(self.interactionOrder,i) end
    end
    if self.interactionIDs[evidence.castGUID] then return false,"DUPLICATE_GATHER_INTERACTION" end
    self.interactionIDs[evidence.castGUID]=true
    self.interactionOrder[#self.interactionOrder+1]={guid=evidence.castGUID,at=now}
    while #self.interactionOrder>64 do local old=table.remove(self.interactionOrder,1);self.interactionIDs[old.guid]=nil end
    return self:Advance("CAST_COMPLETED")
end
function S:Inventory()
    -- No unknown inventory result becomes a full-bag claim. Enumerate the
    -- native carried bag range only when its client constant is available.
    local fn=type(C_Container)=="table" and C_Container.GetContainerNumFreeSlots
    local first=N:Field(type(Enum)=="table" and Enum.BagIndex,"Backpack")
    local last=NUM_TOTAL_EQUIPPED_BAG_SLOTS
    if type(fn)~="function" or not N:Number(first) or not N:Number(last) or first<0 or last<first or last>16 or first%1~=0 or last%1~=0 then return nil,"BAG_CAPACITY_UNKNOWN" end
    local free=0
    for bag=first,last do
        local slots,ok=N:SafeCall(fn,bag)
        if not ok or not N:Number(slots) or slots<0 then return nil,"BAG_CAPACITY_UNKNOWN" end
        free=free+slots
    end
    return free==0,free==0 and "BAGS_FULL" or "BAG_SPACE_AVAILABLE"
end
function S:ProviderPause()
    if self.provider and self.provider.GetStatus then
        local token=self:Token();local ok,status=self:ProviderCall("GetStatus",{filters=copy(self.filters),sessionID=self.id,generation=self.generation})
        if not self:TokenCurrent(token) then return "GATHER_REVALIDATION_PENDING" end
        if ok and N:Table(status) then
            self.providerStatus=copy(status)
            if N:Field(status,"bagsFull")==true then return "BAGS_FULL" end
            if N:Field(status,"professionReady")==false then return "PROFESSION_REQUIRED" end
        end
    end
    local now=N:Now()
    if not self.bagCheckedAt or now<self.bagCheckedAt or now-self.bagCheckedAt>=1 then
        self.bagCheckedAt=now;self.bagsFull,self.bagStatus=self:Inventory()
    end
    if self.bagsFull==true then return "BAGS_FULL" end
end
function S:Candidate(candidate,player)
    if not N:Table(candidate) then return nil,"INVALID_GATHER_CANDIDATE" end
    local mapID,x,y=N:Field(candidate,"mapID"),N:Field(candidate,"x"),N:Field(candidate,"y")
    local floor=N:Field(candidate,"floorID") or mapID
    if not N.map:Valid(mapID,x,y) or mapID~=player.mapID or floor~=(player.floorID or player.mapID) then return nil,"INVALID_GATHER_CANDIDATE" end
    local siteID=N:Text(N:Field(candidate,"siteID")) or N:Text(N:Field(candidate,"id"))
    if not siteID or #siteID==0 or self.excluded[siteID] then return nil,"INVALID_GATHER_SITE_ID" end
    local record=N.Authority:Record(mapID,x,y,N:Field(candidate,"label"),"gather","GATHER_SESSION")
    if not record or not record.world or record.world.continent~=player.world.continent then return nil,"GATHER_WORLD_UNAVAILABLE" end
    record.id=siteID:match("^gather:") and siteID or ("gather:"..siteID)
    record.siteID=siteID;record.recordID=N:Text(N:Field(candidate,"recordID")) or siteID
    record.category=N:Text(N:Field(candidate,"category"));record.name=N:Text(N:Field(candidate,"name"))
    local rev=N:Field(candidate,"sourceRevision");record.sourceRevision=N:Number(rev) and rev or N:Text(rev)
    record.label=N:Text(N:Field(candidate,"label")) or record.name or "Previously recorded site"
    record.quality=N:Text(N:Field(candidate,"confidence")) or "HISTORICAL_SITE";record.confidence=record.quality
    record.floorID=floor;record.intentOrigin="AUTOMATIC_GATHER_SITE";record.purpose="GATHER"
    record.harvestability="UNKNOWN";record.spawnState="HISTORICAL_ONLY"
    -- A provider's cached suggestion cannot undo a canonical withdrawal or
    -- geometry correction. Older standalone provider contracts can operate
    -- without this optional service; the integrated suite always rechecks it.
    local records=N:Service("WorldRecords")
    if records and type(records.Get)=="function" then
        local row,read=N:SafeCall(records.Get,siteID)
        if not read or not self:SameCanonicalSite(record,row) then return nil,"GATHER_RECORD_REVALIDATING" end
        record.sourceRevision=N:Field(row,"sourceRevision")
    end
    return record
end
function S:BuildCircuit(player)
    if not self.current then self:CancelCircuit();self.circuit={};return end
    if not self.circuitDirty then return end
    local token=self:Token();local retained=self.current
    local worldRevision=N.state.reconciliationGeneration
    local records=N:Service("WorldRecords");local tasks=N:Service("Tasks")
    local context=self:Context(player)
    local rows,coverage
    if self.provider and self.provider.GetCandidates then
        local ok,result,reason=self:ProviderCall("GetCandidates",context)
        if not self:TokenCurrent(token) or self.current~=retained then return end
        if not ok or not N:Table(result) then
            self.circuit={copy(retained)};self.circuitCoverage="CURRENT_PROVIDER_SITE";return
        end
        rows=result;coverage=N:Text(reason) or "BOUNDED_PROVIDER_POOL"
    elseif records and self.provider and self.provider.IsEligible then
        local result,ok=N:SafeCall(records.Query,{mapID=player.mapID,kind="gather",owner="MirageIntel_Gather",limit=64})
        if not self:TokenCurrent(token) or self.current~=retained then return end
        rows=ok and N:Field(result,"records")
        coverage=N:Field(result,"nextCursor") and "BOUNDED_FIRST_64_RECORDS" or "LOCAL_ELIGIBLE_RECORDS"
    end
    self:CancelCircuit();self.circuitDirty=false
    local serial=self.circuitSerial
    local circuit={copy(retained)}
    self.circuit={copy(retained)};self.circuitCoverage="CURRENT_PROVIDER_SITE"
    if not N:Table(rows) or not self.provider or not self.provider.IsEligible then return end
    self.circuitPending=serial
    local candidates,seen={}, {[retained.siteID]=true}
    local cursor=1;local phase="VALIDATE";local from=retained;local settings=self:Settings()
    -- Shared Tasks is present in the suite. A standalone older service host
    -- still gets a small bounded route without owning a new update handler.
    local limit=math.min(tasks and 64 or 16,#rows)
    local function current()
        return serial==self.circuitSerial and self:TokenCurrent(token) and self.current==retained and
            worldRevision==N.state.reconciliationGeneration
    end
    local function abandon()
        if self.circuitPending==serial then self.circuitPending=nil;self.circuitDirty=true end
        return false
    end
    local function finish()
        if not current() then return abandon() end
        self.circuitPending=nil;self.circuit=circuit;self.circuitCoverage=coverage
        self.circuitRevision=(self.circuitRevision or 0)+1;self.itineraryKey=nil
        if N.active and N.active.source=="GATHER_SESSION" and N.active.siteID==retained.siteID then
            N.Authority:Change(N.active,N.state.status)
            if N.UI then N.UI:Update() end
        end
        return false
    end
    local function step()
        if not current() then return abandon() end
        if phase=="VALIDATE" then
            -- At most eight canonical/eligibility checks per scheduler slice.
            for _=1,8 do
                if cursor>limit then phase="ORDER";break end
                local row=self:Candidate(N:Field(rows,cursor),player);cursor=cursor+1
                if not current() then return abandon() end
                if row and not seen[row.siteID] then
                    local read,allowed=self:ProviderCall("IsEligible",row.siteID,context)
                    if not current() then return abandon() end
                    if read and allowed==true then candidates[#candidates+1]=row;seen[row.siteID]=true end
                end
            end
            return true
        end
        if #circuit>=settings.circuitStops or #candidates==0 then return finish() end
        -- One greedy step per slice; the provider pool is at most 32 nodes.
        local best,index,dist
        for i,row in ipairs(candidates) do
            local d=N.map:Measure(from,row)
            if not current() then return abandon() end
            if N:Number(d) and (not dist or d<dist or (d==dist and row.siteID<best.siteID)) then best,index,dist=row,i,d end
        end
        if not best then return finish() end
        circuit[#circuit+1]=best;from=best;table.remove(candidates,index)
        return true
    end
    if tasks and type(tasks.Queue)=="function" then
        local queued,read=N:SafeCall(tasks.Queue,"MirageIntel_Navigate.circuit",step,self.generation)
        if not read or queued~=true then self.circuitPending=nil;self.circuitDirty=true end
    else
        for _=1,16 do if step()~=true then break end end
    end
end
function S:NextCircuit(player)
    if not self.provider or not self.provider.IsEligible then return nil end
    local token=self:Token();local context=self:Context(player)
    for _,row in ipairs(self.circuit or {}) do if not self.excluded[row.siteID] then
        local record=self:Candidate(row,player)
        if not self:TokenCurrent(token) then return nil,"STALE_GATHER_PROVIDER_RESULT" end
        if record then
            local ok,eligible=self:ProviderCall("IsEligible",record.siteID,context)
            if not self:TokenCurrent(token) then return nil,"STALE_GATHER_PROVIDER_RESULT" end
            if ok and eligible==true then return record end
        end
    end end
end
function S:SelectGather(player)
    if N.state.mode~="Gather" and N.state.mode~="Auto" then return nil,"GATHER_SESSION_INACTIVE" end
    if not self.id then self:NewGather(N.Storage.account and N.Storage.account.gatherFilters,true) end
    if not player or not player.world then self.nearSince=nil;return nil,"GATHER_POSITION_UNAVAILABLE" end
    if not self.provider then self.current=nil;self.status="WAITING_GATHER_PROVIDER";return nil,self.status end
    local pauseToken=self:Token();local paused=self:ProviderPause()
    if not self:TokenCurrent(pauseToken) then return nil,"STALE_GATHER_PROVIDER_RESULT" end
    if paused then
        if self.pauseReason~=paused then self:Reconcile(paused,false) end
        self.pauseReason=paused;self.status=paused;return nil,paused
    elseif self.pauseReason then self.pauseReason=nil;self:Reconcile("GATHER_CONDITION_RECOVERED",true) end
    if self.current and (self.current.mapID~=player.mapID or (self.current.floorID or self.current.mapID)~=(player.floorID or player.mapID) or
        not self.current.world or self.current.world.continent~=player.world.continent) then self:Reconcile("GATHER_MAP_CHANGED",true) end
    if self.current and self.provider.IsEligible and N:Now()>=(self.nextEligibilityAt or 0) then
        self.nextEligibilityAt=N:Now()+1
        local token=self:Token();local ok,eligible,why=self:ProviderCall("IsEligible",self.current.siteID,self:Context(player))
        if not self:TokenCurrent(token) then return nil,"STALE_GATHER_PROVIDER_RESULT" end
        if not ok or eligible~=true then
            self:Reconcile("GATHER_ELIGIBILITY_CHANGED",true);self.circuit={}
            self.status=N:Text(why) or "GATHER_ELIGIBILITY_UNAVAILABLE"
            if not ok or eligible~=false then
                self.nextProbeAt=N:Now()+1;if not ok then N:Fault("GATHER_ELIGIBILITY_PROVIDER_ERROR") end;return nil,self.status
            end
        end
    end
    if self.current then
        local visitToken=self:Token();local distance=N.map:Measure(player,self.current);local now=N:Now()
        if not self:TokenCurrent(visitToken) then return nil,"STALE_GATHER_PROVIDER_RESULT" end
        if distance and distance<=8 then
            if not self.nearSince or now<self.nearSince then self.nearSince=now end
            self.status="SEARCHING_HISTORICAL_SITE"
            if now-self.nearSince>=self:Settings().dwellSeconds then self:Advance("VISITED_UNCONFIRMED") end
        else self.nearSince=nil;self.status="GATHER_SESSION" end
        if self.current then
            local token=self:Token();self:BuildCircuit(player)
            if not self:TokenCurrent(token) then return nil,"STALE_GATHER_PROVIDER_RESULT" end
            return self.current,"GATHER_SESSION"
        end
    end
    local now=N:Now();if now<self.nextProbeAt then return nil,self.status end;self.nextProbeAt=now+1
    local candidate,circuitReason=self:NextCircuit(player)
    if circuitReason then return nil,circuitReason end
    local reason
    if not candidate then
        local token=self:Token();local ok
        ok,candidate,reason=self:ProviderCall("GetNext",self:Context(player))
        if not self:TokenCurrent(token) then self.nextProbeAt=0;return nil,"STALE_GATHER_PROVIDER_RESULT" end
        if not ok then self.status="GATHER_PROVIDER_ERROR";N:Fault(self.status);return nil,self.status end
    end
    if candidate==nil then
        reason=N:Text(reason) or "NO_ELIGIBLE_GATHER"
        self.status=#self.excludeOrder>0 and reason:match("^NO_ELIGIBLE") and "ALL_SITES_DEFERRED" or reason
        self.circuit={};return nil,reason
    end
    local transformToken=self:Token();local record,why=self:Candidate(candidate,player)
    if not self:TokenCurrent(transformToken) then return nil,"STALE_GATHER_PROVIDER_RESULT" end
    if not record then self.status=why;return nil,why end
    if self.provider and self.provider.IsEligible then
        local token=self:Token();local ok,eligible,reason=self:ProviderCall("IsEligible",record.siteID,self:Context(player))
        if not self:TokenCurrent(token) then return nil,"STALE_GATHER_PROVIDER_RESULT" end
        if not ok or eligible~=true then
            self.status=N:Text(reason) or "GATHER_ELIGIBILITY_UNAVAILABLE";return nil,self.status
        end
    end
    self.generation=self.generation+1;record.sessionID=self.id;record.generation=self.generation
    self.current=record;self.nextEligibilityAt=0;self.status="GATHER_SESSION";self.circuitDirty=true
    local token=self:Token();self:BuildCircuit(player)
    if not self:TokenCurrent(token) or self.current~=record then return nil,"STALE_GATHER_PROVIDER_RESULT" end
    return record,"GATHER_SESSION"
end
function S:Renderer()
    local lease=self.renderer
    if lease and (lease.expiresAt<=N:Now() or not N.active or lease.revision~=N.active.revision or self:Mode()=="Pause" or self:Mode()=="Off" or N.state.suspended) then self.renderer=nil;lease=nil end
    return lease
end
function S:AcquireRenderer(owner,revision,ttl)
    if owner~="CursorCompanion" and owner~="Wayfinder" then return false,"UNKNOWN_RENDERER" end
    if not N.active or revision~=N.active.revision or self:Mode()=="Pause" or self:Mode()=="Off" or N.state.suspended or
        (self.route and self.route.precision=="VALIDATED_GRAPH_ROUTE" and not self.directionTarget) then return false,"STALE_RENDERER_REVISION" end
    local current=self:Renderer()
    if current and current.owner~=owner and owner~="CursorCompanion" then return false,"RENDERER_OWNED" end
    local duration=N:Number(ttl) and math.max(.15,math.min(1,ttl)) or .5
    self.renderer={owner=owner,revision=revision,expiresAt=N:Now()+duration}
    if owner=="CursorCompanion" and N.HUD and N.HUD.frame then N.HUD.frame:Hide() end
    return true,"RENDERER_GRANTED"
end
function S:ReleaseRenderer(owner)
    if not owner or (self.renderer and self.renderer.owner==owner) then self.renderer=nil;return true end
    return false
end
-- Shared ordered route for every renderer. It starts at the current intent,
-- contains only recorded/native coordinates, and never joins different maps.
function S:Itinerary()
    local out={precision="SUGGESTED_STOP_ORDER",traversability="UNVERIFIED",costBasis="SAME_WORLD_DISTANCE_HEURISTIC",stops={}}
    local active=N.active
    if not active or N.state.mode=="Pause" or N.state.mode=="Off" or N.state.suspended then self.lastItineraryCount=0;return out end
    local cacheKey=table.concat({N.state.navigationRevision or 0,N.Planner.revision or 0,self.generation or 0,
        self.circuitRevision or 0,tostring(active.id),active.mapID,active.floorID or active.mapID,active.x,active.y,N.state.mode},":")
    if self.itineraryKey==cacheKey and self.itineraryCache then return copy(self.itineraryCache) end
    local seen={}
    local function add(row)
        if not row or not N.map:Valid(row.mapID,row.x,row.y) or seen[row.id] then return end
        seen[row.id]=true
        out.stops[#out.stops+1]={id=row.id,siteID=row.siteID,questID=row.questID,mapID=row.mapID,
            floorID=row.floorID or row.mapID,x=row.x,y=row.y,kind=row.kind or (row.questID and "quest" or "gather"),
            category=row.category or (row.stage=="READY_FOR_TURN_IN" and "turn-in" or row.stage=="QUEST_GIVER" and "quest-giver" or row.questID and "objective"),
            label=row.label,stage=row.stage,visitOnly=row.visitOnly,availability=row.availability,
            index=#out.stops+1,precision="SUGGESTED_STOP_ORDER"}
    end
    add(active)
    if N.state.mode=="Manual only" then self.lastItineraryCount=#out.stops;return out end
    if active.kind=="gather" then
        out.coverage=self.circuitCoverage
        for _,row in ipairs(self.circuit or {}) do
            if #out.stops>=self:Settings().circuitStops then break end
            if not self.excluded[row.siteID] and row.mapID==active.mapID and (row.floorID or row.mapID)==active.floorID then add(row) end
        end
    else
        -- The planner has already applied the local-work and quest-giver
        -- policy to every leg. A second nearest-neighbour pass here used to
        -- silently undo its ordering before map/minimap consumers saw it.
        local authored=N.Planner.plan or {}
        local maxStops=N.Planner:Preferences().maxStops
        if authored[1] and authored[1].id==active.id then
            for _,row in ipairs(authored) do
                if #out.stops>=maxStops then break end
                if row.mapID==active.mapID and (row.floorID or row.mapID)==active.floorID then add(row) end
            end
            self.itineraryKey=cacheKey;self.itineraryCache=copy(out);self.lastItineraryCount=#out.stops
            return out
        end
        local remaining={}
        for _,row in ipairs(authored) do
            if row.mapID==active.mapID and (row.floorID or row.mapID)==active.floorID and not seen[row.id] then
                local value=copy(row);value.world=N.map:World(row.mapID,row.x,row.y)
                remaining[#remaining+1]={row=value,world=value.world}
            end
        end
        local world=active.world or N.map:World(active.mapID,active.x,active.y)
        local pref=N.Planner:Preferences()
        while #remaining>0 and #out.stops<maxStops do
            local index,best,bestPriority=1,nil,nil
            for i,entry in ipairs(remaining) do
                local destWorld=entry.world
                local d=world and destWorld and N.map:Measure({world=world},{world=destWorld})
                local priority=d and N.Planner:Priority(entry,{world=world},pref,remaining)
                if d and (not best or priority<bestPriority or (priority==bestPriority and d<best)) then index,best,bestPriority=i,d,priority end
            end
            local entry=table.remove(remaining,index);add(entry.row);world=entry.world
        end
    end
    self.itineraryKey=cacheKey;self.itineraryCache=copy(out);self.lastItineraryCount=#out.stops
    return out
end
function S:Snapshot()
    local itinerary=self:Itinerary()
    local pin=N.Storage.character and N.Storage.character.pin
    return copy({schemaVersion=2,revision=N.state.navigationRevision or 0,routeRevision=N.state.navigationRevision or 0,
        mode=self:Mode(),policy=N.state.mode,status=N.state.status,owner="Wayfinder",intentOrigin=N.active and N.active.intentOrigin or
        (self:Mode()=="Pause" and "PLAYER_PAUSE" or "NONE"),sessionID=self.id,generation=self.generation,destination=N.active,
        renderer=self:Renderer(),focus=pin and {kind=pin.kind,questID=pin.questID,recordID=pin.recordID},
        gatherStatus=self.status,providerStatus=self.providerStatus,returnMode=self.returnMode,
        dwellSeconds=self:Settings().dwellSeconds,nearSince=self.nearSince,deferrals=self.deferrals,completedStops=self.completedStops,
        progress=self.progress,circuitRevision=self.circuitRevision,circuitPreparing=self.circuitPending~=nil,
        route=self.route,nextLeg=self.nextLeg,directionTarget=self.directionTarget,itinerary=itinerary,
        suspended=N.state.suspended,reconciliationGeneration=N.state.reconciliationGeneration or 0,nativeVerification="NOT_RUN"})
end
