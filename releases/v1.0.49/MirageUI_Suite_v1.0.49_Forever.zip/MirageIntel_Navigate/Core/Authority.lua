local _,N=...
N.Authority={lastPublished=nil}
local A=N.Authority
function A:Record(mapID,x,y,label,kind,source,questID)
    if not N.map:Valid(mapID,x,y) then return nil,"INVALID_POSITION" end
    local record={id=questID and ("quest:"..questID) or (kind..":"..mapID..":"..string.format("%.6f:%.6f",x,y)),
        mapID=mapID,floorID=mapID,x=x,y=y,kind=kind,source=source,label=N:Text(label) or "Pinned location",questID=questID,
        intentOrigin="PLAYER_EXPLICIT"}
    local world,why=N.map:World(mapID,x,y)
    record.world=world
    record.worldStatus=why
    return record,"VALIDATED_MAP_POSITION"
end
function A:Manual()
    local stored=N.Storage.character and N.Storage.character.pin
    if not stored then return nil end
    local record
    if stored.kind=="quest" then
        if N.Quest.removed[stored.questID] then return nil,"PINNED_QUEST_UNAVAILABLE" end
        for _,candidate in ipairs(N.candidates) do if candidate.questID==stored.questID then record=N._copy(candidate);break end end
        if not record or record.awaitingTurnIn then return nil,"PINNED_QUEST_LOCATION_PENDING" end
    else record=self:Record(stored.mapID,stored.x,stored.y,stored.label,stored.kind,stored.source,stored.questID) end
    if record then
        if stored.kind~="quest" then
            record.recordID=N:Text(stored.recordID);record.siteID=N:Text(stored.siteID)
            record.sourceRevision=stored.sourceRevision;record.purpose=N:Text(stored.purpose)
            record.name=N:Text(stored.name);record.category=N:Text(stored.category)
            record.floorID=stored.floorID or record.mapID;record.taxiNodeID=stored.taxiNodeID;record.nodeID=stored.nodeID
        end
        if stored.kind~="quest" then record.id=record.recordID or record.id end
        record.intentOrigin="PLAYER_EXPLICIT";record.source=stored.source
    end
    return record
end
function A:Gather()
    local request=N.requests.gather
    if not request then return nil end
    local expires=request.expiresAt
    if N:Number(expires) and N:Now()>=expires then N.requests.gather=nil;return nil end
    local currentRevision=request.sourceRevision
    if request.requireRecord then
        local records=N:Service("WorldRecords")
        local row,read=N:SafeCall(records and records.Get,request.recordID)
        if not read or not N:Table(row) or N:Field(row,"owner")~="MirageIntel_Gather" or
            N:Field(row,"kind")~="gather" or N:Field(row,"hidden")==true then return nil,"GATHER_RECORD_UNAVAILABLE" end
        if N:Field(row,"mapID")~=request.mapID or N:Field(row,"x")~=request.x or N:Field(row,"y")~=request.y or
            N:Field(row,"siteID")~=request.siteID or N:Field(row,"name")~=request.name or
            N:Field(row,"category")~=request.category or
            (N:Field(row,"floorID") or N:Field(row,"mapID"))~=(request.floorID or request.mapID) then return nil,"GATHER_RECORD_CHANGED" end
        currentRevision=N:Field(row,"sourceRevision")
    end
    local record=self:Record(request.mapID,request.x,request.y,request.label,"gather","GATHER_USER_SELECTED",nil)
    if record then
        record.siteID=request.siteID;record.recordID=request.recordID;record.sourceRevision=currentRevision
        record.name=request.name;record.category=request.category;record.purpose="GATHER"
        record.floorID=request.floorID or record.mapID
        record.id=record.siteID and (record.siteID:match("^gather:") and record.siteID or ("gather:"..record.siteID)) or record.id
    end
    return record
end
function A:FromCursor()
    local selection=N.Cursor:GetSelection()
    if type(selection)~="table" or not N:Integer(selection.mapID) or
       not N:Number(selection.worldX) or not N:Number(selection.worldY) or
       not N:Number(selection.continent) or selection.continent<0 or selection.continent%1~=0 then return nil end
    -- The cursor exports world geometry (not normalized map coordinates). It is
    -- the existing quest/route authority when its compass presentation is on.
    return {kind="quest",label=N:Text(selection.label) or "Quest objective",questID=N:Integer(selection.questID) and selection.questID or nil,
       source="CURSOR_"..(N:Text(selection.source) or "QUEST"),quality=N:Text(selection.quality) or "NATIVE_QUEST_SOURCE",
       world={continent=selection.continent,x=selection.worldX,y=selection.worldY,mapID=selection.mapID},
       mapID=selection.mapID,stage=N:Text(selection.stage),observedAt=N:Now(),fromCursor=true}
end
function A:WaypointSkipped(record)
    local skipped=self.skippedWaypoints
    if not skipped then return false end
    local now=N:Now();local matched=false
    for i=#skipped,1,-1 do
        local row=skipped[i]
        if now>=row.untilAt then table.remove(skipped,i)
        elseif row.mapID==record.mapID and row.floorID==(record.floorID or record.mapID)
            and row.x==record.x and row.y==record.y then matched=true end
    end
    return matched
end
function A:SkipWaypoint(record)
    if not record or record.kind~="waypoint" or not N.map:Valid(record.mapID,record.x,record.y) then return false,"NO_DESTINATION" end
    self.skippedWaypoints=self.skippedWaypoints or {}
    -- This is a short local preference. The game's waypoint and tracking stay
    -- intact, and a changed coordinate is eligible even within the same pixel.
    self:WaypointSkipped(record)
    local untilAt=N:Now()+120
    for _,row in ipairs(self.skippedWaypoints) do
        if row.mapID==record.mapID and row.floorID==(record.floorID or record.mapID)
            and row.x==record.x and row.y==record.y then
            row.untilAt=untilAt;N:Invalidate("PLAYER_SKIPPED_WAYPOINT");return true
        end
    end
    if #self.skippedWaypoints>=16 then table.remove(self.skippedWaypoints,1) end
    self.skippedWaypoints[#self.skippedWaypoints+1]={mapID=record.mapID,floorID=record.floorID or record.mapID,
        x=record.x,y=record.y,untilAt=untilAt}
    N:Invalidate("PLAYER_SKIPPED_WAYPOINT");return true
end
function A:Tracked(player)
    local waypoint=N.Quest:TrackedUserWaypoint()
    if waypoint and not self:WaypointSkipped(waypoint) then
        waypoint.selectionTier="WAYPOINT";return waypoint
    end
    local id=N.Quest:SupertrackedID()
    if id and not (N.Planner.skipped and N.Planner.skipped[id] and N:Now()<N.Planner.skipped[id]) then
        for _,row in ipairs(N.candidates) do
            if row.questID==id and not row.awaitingTurnIn and row.eligible~=false then
                local selected=N._copy(row);selected.selectionTier="TRACKED_QUEST"
                return selected
            end
        end
    end
end
function A:Automatic(player)
    local mode=N.state.mode
    if mode=="Manual only" or mode=="Off" or mode=="Pause" then return nil end
    local planned=N.Planner:Choose(player)
    -- The automatic policy follows deliberate game tracking before ordinary
    -- distance scoring. Explicit saved focus and gather selections are handled
    -- by Pick above this tier.
    if mode=="Auto" or mode=="Follow Blizzard" then
        local tracked=self:Tracked(player)
        if tracked then
            local deferred=mode=="Auto" and tracked.stage=="READY_FOR_TURN_IN" and N.Planner.deferredReturns and N.Planner.deferredReturns[tracked.questID]
            local pref=N.Planner:Preferences()
            local otherArea=player and (tracked.mapID~=player.mapID or (tracked.floorID or tracked.mapID)~=(player.floorID or player.mapID))
            if mode=="Auto" and tracked.stage=="READY_FOR_TURN_IN" and pref.finishNearby and not pref.preferTurnIns and
                otherArea and planned and N.Planner.nearbyWorkID then
                -- A return on another map/floor is not local work. This rule
                -- uses only the qualified nearby objective, never a guessed
                -- distance or travel segment to that different area.
                deferred=N.Planner.nearbyWorkID
                planned.policyReason="FINISH_LOCAL_WORK_BEFORE_MAP_RETURN"
                planned.returnDeferredQuestID=tracked.questID;planned.localWorkQuestID=deferred
            end
            if not deferred then return tracked end
        end
    end
    if mode=="Gather" then
        local site=N.Session:SelectGather(player)
        if site then site.selectionTier="GATHER_FOCUS";return site end
        if planned then planned.selectionTier="QUEST_FALLBACK";return planned end
    else
        local localQuest=planned and N.map:Measure(player,planned)
        if planned and (mode~="Auto" or localQuest and localQuest<=N.Planner:Preferences().range) then
            planned.selectionTier=planned.stage=="READY_FOR_TURN_IN" and "TURN_IN" or "QUESTS"
            return planned
        end
        if mode=="Auto" and N.Storage.account and N.Storage.account.gatherFallback~=false then
            local site=N.Session:SelectGather(player)
            if site then site.selectionTier="GATHER_FALLBACK";return site end
        end
        if planned then planned.selectionTier="QUEST_FARTHER_AREA";return planned end
    end
    if mode=="Auto" or mode=="Gather" then
        -- A mapped quest elsewhere still offers a useful destination, but its
        -- coordinates remain on that map; no local travel segment is invented.
        for _,row in ipairs(N.candidates) do
            if row.accepted==true and row.eligible~=false and not row.awaitingTurnIn and row.world and
                player and row.mapID~=player.mapID and
                not (N.Planner.skipped and N.Planner.skipped[row.questID] and N:Now()<N.Planner.skipped[row.questID]) then
                local selected=N._copy(row);selected.selectionTier="QUEST_OTHER_AREA";return selected
            end
        end
    end
end
function A:Pick(player)
    if N.state.suspended then return nil,N.state.suspended end
    if N.state.mode=="Off" then return nil,"OFF" end
    if N.state.mode=="Pause" then return nil,"PAUSED" end
    if N.state.mode~="Manual only" then N.Planner:Choose(player) end
    local manual,manualReason=self:Manual()
    if manual then N.Session.nearSince=nil;manual.selectionTier="PLAYER_FOCUS";return manual,"MANUAL_PIN" end
    local gather,gatherReason=self:Gather()
    if gather then gather.selectionTier="PLAYER_GATHER_FOCUS";return gather,"GATHER_USER_SELECTED" end
    -- A temporarily unresolved focus stays saved while automatic navigation
    -- uses the next useful tier. It becomes first again when its live point returns.
    if N.state.mode=="Manual only" then return nil,manualReason or gatherReason or "NO_ELIGIBLE_DESTINATION" end
    local automatic=self:Automatic(player)
    if automatic then return automatic,automatic.source end
    return nil,"EXPLORE_AREA"
end
function A:GraphRoute(destination,player)
    local token=N.Session:Token()
    local graph=N:Service("TravelGraph")
    if not graph or type(graph.GetRoute)~="function" then return nil,"TRAVEL_GRAPH_UNAVAILABLE" end
    local summary,read=N:SafeCall(graph.GetStatus)
    if not N.Session:TokenCurrent(token) then return nil,"STALE_GRAPH_RESULT" end
    local revision=read and N:Field(summary,"graphRevision") or read and N:Field(summary,"revision")
    local faction=N.Quest.character and N.Quest.character.faction
    if not faction then local value,ok=N:SafeCall(UnitFactionGroup,"player");faction=ok and N:Text(value) end
    if not N.Session:TokenCurrent(token) then return nil,"STALE_GRAPH_RESULT" end
    -- Exact graph endpoints qualify a route. A cached match (or miss) must
    -- follow movement and floor changes inside the same map, not only zoning.
    -- Include every endpoint identity accepted by TravelGraph; length prefixes
    -- preserve separators in externally supplied record/floor identifiers.
    local parts={tostring(revision),tostring(faction),tostring(N.Session.generation),
        tostring(N.state.reconciliationGeneration or 0)}
    for _,point in ipairs({player or {},destination}) do
        for _,field in ipairs({"mapID","floorID","x","y","id","recordID","graphNodeID","taxiNodeID","nodeID"}) do
            local value=point[field]
            -- Lua's ordinary tostring can collapse nearby floating-point map
            -- positions. Keep the exact double round-trip representation.
            parts[#parts+1]=type(value)..":"..(type(value)=="number" and string.format("%.17g",value) or tostring(value))
        end
    end
    for i,value in ipairs(parts) do parts[i]=#value..":"..value end
    local key=table.concat(parts)
    if N.Session.routeKey==key then return N._copy(N.Session.cachedRoute),N.Session.routeReason end
    local route,ok,why=N:SafeCall(graph.GetRoute,{start=N._copy(player),destination=N._copy(destination),
        context={modes={FLIGHT=true,WALK=true},faction=faction,generation=N.Session.generation,expectedGraphRevision=revision}})
    if not N.Session:TokenCurrent(token) then return nil,"STALE_GRAPH_RESULT" end
    local valid=ok and N:Table(route) and N:Field(route,"precision")=="VALIDATED_GRAPH_ROUTE" and
        N:Table(N:Field(route,"legs")) and N:Table(N:Field(route,"nextLeg")) and #route.legs>0 and #route.legs<=64
    if valid then
        route=N._copy(route);route.nativeVerification="NOT_RUN"
        N.Session.cachedRoute=route;N.Session.routeReason="VALIDATED_GRAPH_ROUTE"
    else N.Session.cachedRoute=nil;N.Session.routeReason=N:Text(why) or "NO_QUALIFIED_GRAPH_ROUTE" end
    N.Session.routeKey=key
    return N._copy(N.Session.cachedRoute),N.Session.routeReason
end
function A:Describe(candidate,reason,player)
    if not candidate then return nil,reason end
    local dest={id=candidate.id,kind=candidate.kind,label=candidate.label,source=reason or candidate.source,
        mapID=candidate.mapID,floorID=candidate.floorID or candidate.mapID,x=candidate.x,y=candidate.y,quality=candidate.quality or "USER_SELECTED",
        questID=candidate.questID,siteID=candidate.siteID,recordID=candidate.recordID,sourceRevision=candidate.sourceRevision,
        category=candidate.category,name=candidate.name,purpose=candidate.purpose,taxiNodeID=candidate.taxiNodeID,nodeID=candidate.nodeID,
        stage=candidate.stage,world=candidate.world,confidence=candidate.confidence or candidate.quality or "USER_SELECTED",
        intentOrigin=candidate.intentOrigin or "UNKNOWN",precision="DIRECT_BEARING",sessionID=candidate.sessionID,generation=candidate.generation,
        selectionTier=candidate.selectionTier,clusterSize=candidate.clusterSize,selectionReason=candidate.selectionReason,suitabilityReason=candidate.suitabilityReason,
        policyReason=candidate.policyReason,visitOnly=candidate.visitOnly,availability=candidate.availability,accepted=candidate.accepted,
        returnDeferredQuestID=candidate.returnDeferredQuestID,localWorkQuestID=candidate.localWorkQuestID,
        score=candidate.score,scoreFactors=candidate.scoreFactors,progress=candidate.progress,progressBasis=candidate.progressBasis,
        eligibilityReason=candidate.eligibilityReason,instruction=candidate.instruction,locationBasis=candidate.locationBasis,
        harvestability=candidate.harvestability,nativeVerification="NOT_RUN",estimatedPath=false}
    local d,measurement=N.map:Measure(player,candidate)
    if not player then d=nil;measurement="PLAYER_POSITION_UNAVAILABLE"
    elseif player.mapID~=candidate.mapID or (player.floorID or player.mapID)~=(candidate.floorID or candidate.mapID) then d=nil;measurement="OTHER_MAP_OR_FLOOR" end
    if d then
        dest.distance=d;dest.distanceBasis=measurement;dest.status=d<=8 and "NEAR_DESTINATION" or "LOCATED"
        if d<=8 then dest.arrivalMeaning=dest.kind=="quest" and "REACHED_SUGGESTED_AREA_WAITING_QUEST_EVIDENCE" or
            dest.kind=="gather" and "SEARCH_SITE_HARVEST_UNCONFIRMED" or "NEAR_MANUAL_PIN" end
    else dest.status=measurement or "DISTANCE_UNAVAILABLE" end
    local route,routeReason=self:GraphRoute(dest,player)
    if routeReason=="STALE_GRAPH_RESULT" then return nil,routeReason end
    N.Session.route=route;dest.routeStatus=routeReason
    if route then
        dest.precision="VALIDATED_GRAPH_ROUTE";dest.graphRevision=route.graphRevision;dest.graphID=route.graphID
        dest.routeCostBasis=route.costBasis;dest.routeCost=route.cost
        dest.status="TRANSPORT_ACTION_REQUIRED";dest.distance=nil;dest.distanceBasis=nil
        N.Session.nextLeg=N._copy(route.nextLeg)
        -- The pilot proves a native booking connection, not an interpolated
        -- flight trace or a walkable approach. It has no directional target.
        N.Session.directionTarget=nil
        dest.instruction="Choose flight to "..(N:Text(N:Field(route.nextLeg.to,"label")) or dest.label)
    else
        N.Session.directionTarget=d and N._copy(dest) or nil
        N.Session.nextLeg={id="bearing:"..tostring(dest.id),mode="DIRECT",from=player and
            {mapID=player.mapID,floorID=player.floorID or player.mapID,x=player.x,y=player.y} or nil,
            to={id=dest.id,mapID=dest.mapID,floorID=dest.floorID,x=dest.x,y=dest.y,label=dest.label},
            precision="DIRECT_BEARING",geometry=d and "STRAIGHT_BEARING_UNVERIFIED" or "NOT_SUPPLIED",
            costBasis=d and "SAME_WORLD_STRAIGHT_LINE_YARDS" or "UNKNOWN",distance=d,traversability="UNVERIFIED"}
    end
    return dest,dest.status
end
-- Compare public destination identity and geometry, but not rapidly changing
-- distance. Copy scalar fields so a provider mutating a reused observation
-- cannot rewrite the last destination other modules were told about.
local function snapshot(destination,status)
    if not destination then return {present=false,status=status,mode=N.state.mode,sessionID=N.Session and N.Session.id} end
    local w=destination.world
    return {present=true,status=status,mode=N.state.mode,id=destination.id,source=destination.source,kind=destination.kind,
        mapID=destination.mapID,floorID=destination.floorID,x=destination.x,y=destination.y,questID=destination.questID,
        precision=destination.precision,graphID=destination.graphID,graphRevision=destination.graphRevision,
        nextLegID=N.Session.nextLeg and N.Session.nextLeg.id,planRevision=N.Planner and N.Planner.revision,circuitGeneration=N.Session and N.Session.generation,circuitRevision=N.Session and N.Session.circuitRevision,selectionTier=destination.selectionTier,
        label=destination.label,stage=destination.stage,quality=destination.quality,confidence=destination.confidence,locationBasis=destination.locationBasis,
        visitOnly=destination.visitOnly,availability=destination.availability,
        siteID=destination.siteID,recordID=destination.recordID,sourceRevision=destination.sourceRevision,
        intentOrigin=destination.intentOrigin,sessionID=destination.sessionID,generation=destination.generation,
        worldMap=w and w.mapID,worldX=w and w.x,worldY=w and w.y,continent=w and w.continent}
end
local function same(a,b)
    if not a then return false end
    for k,v in pairs(a) do if b[k]~=v then return false end end
    for k,v in pairs(b) do if a[k]~=v then return false end end
    return true
end
function A:Change(new,reason)
    local old=N.active
    if N.API and N.API.pendingReplacement and
       (not old or not new or old.mapID~=new.mapID or old.x~=new.x or old.y~=new.y) then
        N.API:ClearWaypointConfirmation()
    end
    new=N._copy and N._copy(new) or new
    N.active=new
    if not new and N.Session then N.Session.route=nil;N.Session.nextLeg=nil;N.Session.directionTarget=nil end
    N.state.status=reason or "NO_ELIGIBLE_DESTINATION"
    N.state.provider=new and new.source or "NONE"
    local nextState=snapshot(new,N.state.status)
    if not same(self.lastPublished,nextState) then
        N.state.navigationRevision=(N.state.navigationRevision or 0)+1
        if new then new.revision=N.state.navigationRevision
            if N.Session.directionTarget then N.Session.directionTarget.revision=new.revision end
        end
        if N.Session then N.Session:ReleaseRenderer() end
        self.lastPublished=nextState
        if N.core and N.core.Publish then
            N.core.Publish("NAV_DESTINATION_CHANGED",N._copy(new or {status=N.state.status,source="NONE",revision=N.state.navigationRevision}))
            if N.Session then N.core.Publish("NAV_SESSION_CHANGED",N.Session:Snapshot()) end
        end
    elseif new then new.revision=N.state.navigationRevision
            if N.Session.directionTarget then N.Session.directionTarget.revision=new.revision end
        end
end
function A:Refresh(player)
    -- Selection advances its own evidence generation, but external intent,
    -- provider replacement and world changes must invalidate this entire pass.
    local mode=N.state.mode;local sessionID=N.Session.id;local provider=N.Session.provider
    local providerRevision=N.Session.providerRevision;local worldRevision=N.state.reconciliationGeneration
    local candidateRevision=N.state.candidateRevision;local questGeneration=N.Quest.generation
    local pinRevision=N.Storage.character and N.Storage.character.revision
    local gatherRequest=N.requests.gather
    local function current()
        return mode==N.state.mode and sessionID==N.Session.id and provider==N.Session.provider and
            providerRevision==N.Session.providerRevision and worldRevision==N.state.reconciliationGeneration and
            candidateRevision==N.state.candidateRevision and questGeneration==N.Quest.generation and
            pinRevision==(N.Storage.character and N.Storage.character.revision) and gatherRequest==N.requests.gather and not N.state.suspended
    end
    local candidate,reason=self:Pick(player)
    if not current() then N:Invalidate("STALE_SELECTION_REJECTED");return end
    local described,status=self:Describe(candidate,reason,player)
    if not current() or status=="STALE_GRAPH_RESULT" then N:Invalidate("STALE_SELECTION_REJECTED");return end
    self:Change(described,status or reason)
end
