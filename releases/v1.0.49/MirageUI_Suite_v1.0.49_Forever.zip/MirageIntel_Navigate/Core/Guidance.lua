local _,N=...
-- One measured heading for every suite arrow. World X is north, world Y is
-- west; a positive angle turns north-pointing artwork counterclockwise.
N.Guidance={status="NOT_SAMPLED",samples=0}
local G=N.Guidance
local pi=math.pi
local function atan2(y,x)
    if math.atan2 then return math.atan2(y,x) end
    if x>0 then return math.atan(y/x) end
    if x<0 then return math.atan(y/x)+(y>=0 and pi or -pi) end
    return y>0 and pi/2 or y<0 and -pi/2 or 0
end
local function world(w)
    return N:Table(w) and N:Number(w.x) and N:Number(w.y) and N:Number(w.continent)
        and w.continent>=0 and w.continent%1==0
end
function G:Snapshot(player,hasObservation)
    local now=N:Now()
    local active=N.active
    local target=N.Session and N.Session.directionTarget
    local revision=N.state.navigationRevision or 0
    local generation=N.state.reconciliationGeneration or 0
    local mode=N.Session:Mode()
    local ready=N.Controller and N.Controller:Ready() and N.state.clientAllowed and not N.Storage.readOnly
    -- GetTime is constant within one UI frame. HUD and Cursor can reuse the
    -- same sample, but a destination/world/mode change always invalidates it.
    if not hasObservation and self.cachedAt==now and self.active==active and self.target==target
        and self.revision==revision and self.generation==generation and self.mode==mode
        and self.suspended==N.state.suspended and self.ready==ready and self.cached then
        return N._copy(self.cached)
    end
    local result={schemaVersion=1,revision=revision,sampledAt=now,expiresAt=now+.35,mode=mode,
        destinationID=active and active.id,destinationRevision=active and active.revision,
        coordinateSystem="WORLD_X_NORTH_Y_WEST",angleConvention="POSITIVE_COUNTERCLOCKWISE",
        status="NO_DESTINATION",reconciliationGeneration=generation}
    local function finish(status)
        result.status=status;self.status=status;self.samples=self.samples+1
        self.cachedAt=now;self.active=active;self.target=target;self.revision=revision
        self.generation=generation;self.mode=mode;self.suspended=N.state.suspended;self.ready=ready
        self.cached=N._copy(result)
        return N._copy(result)
    end
    if mode=="Off" or mode=="Pause" then return finish(mode=="Pause" and "PAUSED" or "OFF") end
    if not ready then return finish("STARTING") end
    if N.state.suspended then return finish(N.state.suspended) end
    if not active then return finish("NO_DESTINATION") end
    -- A supplied transport leg without a direction must never become a
    -- straight-line arrow to its final destination.
    if not target then return finish(N.Session.route and "TRANSPORT_ACTION_REQUIRED" or "NO_DIRECTION_GEOMETRY") end
    if not world(target.world) or not N:Integer(target.mapID) then return finish("NO_DIRECTION_GEOMETRY") end
    if not hasObservation then player=N.map:Player() end
    if not N:Table(player) or not N:Integer(player.mapID) or not world(player.world) then return finish("NO_POSITION") end
    if player.mapID~=target.mapID or (player.floorID or player.mapID)~=(target.floorID or target.mapID)
        or player.world.continent~=target.world.continent then return finish("OTHER_MAP_OR_FLOOR") end
    local facing,read=N:SafeCall(GetPlayerFacing)
    if not read or not N:Number(facing) then return finish("NO_FACING") end
    -- Native/provider reads may publish a new intent synchronously. Do not
    -- associate their measurement with the destination captured above.
    if N.active~=active or N.Session.directionTarget~=target or N.state.navigationRevision~=revision
        or (N.state.reconciliationGeneration or 0)~=generation or N.Session:Mode()~=mode
        or N.state.suspended or not N.Controller:Ready() then return finish("REVALIDATING") end
    local north,west=target.world.x-player.world.x,target.world.y-player.world.y
    local distance=math.sqrt(north*north+west*west)
    if not N:Number(distance) then return finish("NO_POSITION") end
    result.mapID=target.mapID;result.floorID=target.floorID or target.mapID
    result.player={mapID=player.mapID,floorID=player.floorID or player.mapID,
        continent=player.world.continent,x=player.world.x,y=player.world.y}
    result.distance=distance;result.facing=facing
    result.distanceBasis="SAME_WORLD_STRAIGHT_LINE_YARDS"
    if distance>=.05 then result.relativeAngle=(atan2(west,north)-facing+pi)%(2*pi)-pi end
    return finish(distance<=8 and "NEAR_DESTINATION" or "GUIDING")
end
