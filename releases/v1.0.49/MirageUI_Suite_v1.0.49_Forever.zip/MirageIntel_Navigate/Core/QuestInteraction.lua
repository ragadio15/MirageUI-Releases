local _,N=...
-- A conversation assistant, not an interaction/movement driver. Only native
-- quest/gossip events admit work. Every action rechecks the displayed panel,
-- NPC identity, quest/list identity, settings and combat immediately before it.
N.QuestInteraction={status="IDLE",generation=0,actions=0,accepted=0,completed=0,failures=0}
local I=N.QuestInteraction
local defaults={autoAccept=true,autoTurnIn=true,repeatable=false}
local panels={GOSSIP_SHOW="GossipFrame",QUEST_GREETING="QuestFrameGreetingPanel",
    QUEST_DETAIL="QuestFrameDetailPanel",QUEST_PROGRESS="QuestFrameProgressPanel",QUEST_COMPLETE="QuestFrameRewardPanel"}
local function integer(v,max) return N:Number(v) and v>=0 and v%1==0 and v<=(max or 64) end
local function id(v) return N:Integer(v) and v<100000000 end
local function clock()
    local value,ok=N:SafeCall(GetTime)
    return ok and N:Number(value) and value>=0 and value or nil
end
local function shown(frame)
    local value,ok=N:SafeCall(frame and frame.IsShown,frame)
    return ok and value==true
end
function I:Preferences()
    local saved=N.Storage.account and N:Field(N.Storage.account,"questInteraction")
    local out={}
    for key,value in pairs(defaults) do
        local stored=N:Field(saved,key)
        if saved~=nil and (not N:Table(saved) or (stored~=nil and type(stored)~="boolean")) then out[key]=false
        elseif stored~=nil then out[key]=stored else out[key]=value end
    end
    return out
end
function I:SetPreferences(values)
    if not N:Table(values) then return false,"INVALID_QUEST_INTERACTION_PREFERENCE" end
    if N.Storage.readOnly or not N.state.clientAllowed or N:InCombat() then return false,"CLIENT_OR_COMBAT_UNAVAILABLE" end
    local out=self:Preferences()
    for key,value in pairs(values) do
        if not N:Text(key) or not N:Readable(value) or defaults[key]==nil or type(value)~="boolean" then return false,"INVALID_QUEST_INTERACTION_PREFERENCE" end
        out[key]=value
    end
    N.Storage.account.questInteraction=out;N.Storage.account.revision=N.Storage.account.revision+1
    -- A toggle never retroactively approves a panel already open.
    self:Reset("SETTINGS_CHANGED")
    return true,"QUEST_INTERACTION_UPDATED"
end
function I:Reset(reason)
    self.generation=self.generation+1;self.pending=nil;self.session=nil
    self.status=reason or "IDLE"
end
function I:NPC(event)
    local unit=event=="GOSSIP_SHOW" and "npc" or "questnpc"
    local guid,ok=N:SafeCall(UnitGUID,unit)
    if not ok or not N:Text(guid) then return nil end
    -- Items, shared quests, area popups and targeting a player are not an NPC
    -- conversation. Game objects with a quest panel are ordinary quest givers.
    if not guid:match("^Creature%-") and not guid:match("^Vehicle%-") and not guid:match("^GameObject%-") then return nil end
    return guid,unit
end
function I:Enabled(session)
    if not N.state.initialized or not N.state.clientAllowed or N.Storage.readOnly or N.state.inWorld==false or
        N:InCombat() then return false,"CLIENT_OR_COMBAT_UNAVAILABLE" end
    local shift,known=N:SafeCall(IsShiftKeyDown)
    if not known or (shift~=false and shift~=nil) then
        if session then session.bypass=true end
        return false,"SHIFT_BYPASS"
    end
    if session and session.bypass then return false,"SHIFT_BYPASS" end
    return true
end
function I:Current(pending,questID)
    local session=self.session
    if not pending or self.pending~=pending or not session or pending.generation~=self.generation or
        pending.session~=session or pending.account~=N.Storage.account or
        pending.revision~=N.Storage.account.revision then return false end
    local enabled,why=self:Enabled(session)
    if not enabled then self.status=why;return false,why end
    local now=clock()
    if not now or now<pending.createdAt or now>pending.expires then return false,"INTERACTION_EXPIRED" end
    local guid=self:NPC(pending.event)
    if guid~=session.guid or not shown(_G[panels[pending.event]]) then return false end
    if questID then
        local current,known=N:SafeCall(GetQuestID)
        if not known or current~=questID then return false end
    end
    return self.pending==pending and self.session==session and pending.generation==self.generation and
        pending.account==N.Storage.account and pending.revision==N.Storage.account.revision and not N:InCombat()
end
function I:Hold(reason,questID)
    self.status=reason;self.lastQuestID=questID
    if self.session and questID then self.session.manual[questID]=reason end
    self.pending=nil
end
function I:Act(pending,key,fn,arg,questID)
    local current,why=self:Current(pending,questID)
    if not current then self:Hold(why or "INTERACTION_CHANGED");return false end
    local s=self.session
    if s.attempted[key] then self:Hold("ALREADY_ATTEMPTED",questID);return false end
    if s.count>=32 then self:Hold("CONVERSATION_LIMIT");return false end
    if type(fn)~="function" then self:Hold("QUEST_API_UNAVAILABLE",questID);return false end
    -- Record before calling: native APIs can synchronously emit the next panel
    -- or a blocked-action event. Never retry a rejected write in a loop.
    s.attempted[key]=true;s.count=s.count+1;self.actions=self.actions+1
    self.pending=nil;self.status="ACTION_REQUESTED";self.lastQuestID=questID
    local result,called
    if arg==nil then result,called=N:SafeCall(fn) else result,called=N:SafeCall(fn,arg) end
    if not called or result==false then
        self.failures=self.failures+1;s.bypass=true;self.pending=nil;self.status="NATIVE_ACTION_DECLINED";return false
    end
    return true
end
local function gossipRow(rows,key)
    if not N:Table(rows) then return nil end
    local count,ok=N:SafeCall(function()return #rows end)
    if not ok or not integer(count,64) then return nil end
    for index=1,count do
        local row=N:Field(rows,index)
        if N:Field(row,"questID")==key then return row end
    end
end
function I:Gossip(pending,pref)
    local api=C_GossipInfo
    if not N:Table(api) then self:Hold("GOSSIP_API_UNAVAILABLE");return end
    for _,kind in ipairs({"active","available"}) do
        if (kind=="active" and pref.autoTurnIn) or (kind=="available" and pref.autoAccept) then
            local readFn=kind=="active" and api.GetActiveQuests or api.GetAvailableQuests
            local selectFn=kind=="active" and api.SelectActiveQuest or api.SelectAvailableQuest
            local rows,ok=N:SafeCall(readFn)
            local count,read=N:SafeCall(function()return N:Table(rows) and #rows end)
            if not ok or not read or not integer(count,64) then self:Hold("GOSSIP_LIST_UNAVAILABLE");return end
            for index=1,count do
                local row=N:Field(rows,index);local q=N:Field(row,"questID")
                local key=kind..":"..tostring(q)
                local repeatable=N:Field(row,"repeatable")==true or (N:Number(N:Field(row,"frequency")) and N:Field(row,"frequency")>0)
                if id(q) and not self.session.attempted[key] and not self.session.finished[q] and
                    not self.session.manual[q] and N:Field(row,"isIgnored")~=true and
                    (kind~="active" or N:Field(row,"isComplete")==true) and (pref.repeatable or not repeatable) then
                    local again,known=N:SafeCall(readFn);local live=known and gossipRow(again,q)
                    if C_GossipInfo~=api or api[kind=="active" and "GetActiveQuests" or "GetAvailableQuests"]~=readFn or
                        api[kind=="active" and "SelectActiveQuest" or "SelectAvailableQuest"]~=selectFn or not live or
                        N:Field(live,"isComplete")~=N:Field(row,"isComplete") or
                        N:Field(live,"repeatable")~=N:Field(row,"repeatable") or N:Field(live,"frequency")~=N:Field(row,"frequency") or
                        N:Field(live,"isIgnored")==true then self:Hold("GOSSIP_LIST_CHANGED");return end
                    self.session.selected={questID=q,repeatable=repeatable,
                        repeatableKnown=type(N:Field(live,"repeatable"))=="boolean" or N:Number(N:Field(live,"frequency"))}
                    self:Act(pending,key,selectFn,q);return
                end
            end
        end
    end
    self:Hold("NO_AUTOMATIC_QUEST")
end
function I:Greeting(pending,pref)
    -- The legacy greeting's selectors take indices, unlike C_GossipInfo's IDs.
    local function identity(kind,fn,index)
        if type(fn)~="function" then return nil end
        local q,ok,repeatable,frequency
        if kind=="active" then q,ok=N:SafeCall(fn,index)
        else
            q,ok,repeatable,frequency=N:SafeCall(function()
                local _,frequency,repeatable,_,questID=fn(index)
                return questID,repeatable,frequency
            end)
        end
        if not ok or not id(q) then return nil end
        return q,repeatable,frequency
    end
    for _,kind in ipairs({"active","available"}) do
        if (kind=="active" and pref.autoTurnIn) or (kind=="available" and pref.autoAccept) then
            local countFn=kind=="active" and GetNumActiveQuests or GetNumAvailableQuests
            local titleFn=kind=="active" and GetActiveTitle or GetAvailableTitle
            local idFn=kind=="active" and GetActiveQuestID or GetAvailableQuestInfo
            local selectFn=kind=="active" and SelectActiveQuest or SelectAvailableQuest
            local count,ok=N:SafeCall(countFn)
            if not ok or not integer(count,64) then self:Hold("GREETING_LIST_UNAVAILABLE");return end
            for index=1,count do
                local title,read,complete=N:SafeCall(titleFn,index)
                local q,repeatable,frequency=identity(kind,idFn,index)
                if not q then self:Hold("GREETING_IDENTITY_UNAVAILABLE");return end
                local repeats=repeatable==true or (N:Number(frequency) and frequency>0)
                local key=kind..":"..q
                if read and N:Text(title) and not self.session.attempted[key] and not self.session.finished[q] and
                    not self.session.manual[q] and (pref.repeatable or not repeats) and (kind~="active" or complete==true or complete==1) then
                    local now,nok=N:SafeCall(countFn);local again,known,ready=N:SafeCall(titleFn,index)
                    local latest,repeatNow,frequencyNow=identity(kind,idFn,index)
                    if not nok or now~=count or not known or again~=title or ready~=complete or latest~=q or
                        repeatNow~=repeatable or frequencyNow~=frequency or
                        (kind=="active" and (GetActiveQuestID~=idFn or GetActiveTitle~=titleFn or GetNumActiveQuests~=countFn or SelectActiveQuest~=selectFn)) or
                        (kind=="available" and (GetAvailableQuestInfo~=idFn or GetAvailableTitle~=titleFn or GetNumAvailableQuests~=countFn or SelectAvailableQuest~=selectFn)) then
                        self:Hold("GREETING_LIST_CHANGED");return
                    end
                    self.session.selected={questID=q,repeatable=repeats,repeatableKnown=type(repeatable)=="boolean" or N:Number(frequency)}
                    self:Act(pending,key,selectFn,index);return
                end
            end
        end
    end
    self:Hold("NO_AUTOMATIC_QUEST")
end
function I:Costs()
    local money,m=N:SafeCall(GetQuestMoneyToGet)
    local currency,c=N:SafeCall(GetNumQuestCurrencies)
    local items,i=N:SafeCall(GetNumQuestItems)
    if not m or not integer(money,2147483647) or not c or not integer(currency,64) or not i or not integer(items,64) then
        return false,"QUEST_COST_UNKNOWN"
    end
    if money>0 then return false,"MONEY_CONFIRMATION_REQUIRED" end
    if currency>0 then return false,"CURRENCY_CONFIRMATION_REQUIRED" end
    for index=1,items do
        local link,ok=N:SafeCall(GetQuestItemLink,"required",index)
        if not ok or not N:Readable(link) or type(link)~="string" or #link>2048 then return false,"ITEM_COST_UNKNOWN" end
        local itemID=tonumber(link:match("item:(%d+):") or link:match("^item:(%d+)$"))
        if not id(itemID) then return false,"ITEM_COST_UNKNOWN" end
        local getter=C_Item and C_Item.GetItemInfoInstant or GetItemInfoInstant
        local good,result,class=pcall(function()
            if type(getter)~="function" then return end
            local current,_,_,_,_,classID=getter(itemID)
            return current,classID
        end)
        -- Class 12 is the native Questitem class. Materials, equipment, money
        -- substitutes and uncached items stay in the native confirmation flow.
        if not good or not N:Readable(result) or not N:Readable(class) or result~=itemID or class~=12 then
            return false,"ITEM_CONFIRMATION_REQUIRED"
        end
    end
    return true,"ORDINARY_QUEST_REQUIREMENTS"
end
function I:QuestPanel(pending,pref)
    local q,ok=N:SafeCall(GetQuestID)
    if not ok or not id(q) then self:Hold("QUEST_ID_UNAVAILABLE");return end
    local s=self.session
    if s.selected and s.selected.questID~=q then self:Hold("QUEST_SELECTION_CHANGED",q);return end
    if s.manual[q] or s.finished[q] then self:Hold(s.manual[q] or "QUEST_ALREADY_FINISHED",q);return end
    local repeatable,r=N:SafeCall(C_QuestLog and C_QuestLog.IsRepeatableQuest,q)
    if not pref.repeatable and ((r and repeatable==true) or (s.selected and s.selected.repeatable)) then
        self:Hold("REPEATABLE_MANUAL",q);return
    end
    if not pref.repeatable and (not r or type(repeatable)~="boolean") and
        not (s.selected and s.selected.repeatableKnown) then self:Hold("REPEATABILITY_UNKNOWN",q);return end
    if pending.event=="QUEST_DETAIL" then
        if not pref.autoAccept then self:Hold("AUTO_ACCEPT_OFF");return end
        local pvp,known=N:SafeCall(QuestFlagsPVP)
        if not known or pvp~=false then self:Hold("NATIVE_ACCEPT_CONFIRMATION",q);return end
        local onQuest,knownQuest=N:SafeCall(C_QuestLog and C_QuestLog.IsOnQuest,q)
        if knownQuest and onQuest==true then self:Hold("ALREADY_ACCEPTED",q);return end
        local auto,knownAuto=N:SafeCall(QuestGetAutoAccept)
        if knownAuto and auto==true then self:Hold("NATIVE_AUTO_ACCEPT",q);return end
        self:Act(pending,"accept:"..q,AcceptQuest,nil,q)
        return
    end
    if not pref.autoTurnIn then self:Hold("AUTO_TURN_IN_OFF");return end
    local accepted,read=N:SafeCall(C_QuestLog and C_QuestLog.IsOnQuest,q)
    if not read or accepted~=true then self:Hold("ACCEPTED_STATE_UNAVAILABLE",q);return end
    local costs,reason=self:Costs()
    if not costs then self:Hold(reason,q);return end
    if pending.event=="QUEST_PROGRESS" then
        local complete,known=N:SafeCall(IsQuestCompletable)
        if not known or complete~=true then self:Hold("QUEST_NOT_COMPLETE",q);return end
        self:Act(pending,"progress:"..q,CompleteQuest,nil,q)
    else
        local choices,known=N:SafeCall(GetNumQuestChoices)
        if not known or not integer(choices,64) then self:Hold("REWARD_CHOICES_UNKNOWN",q);return end
        if choices>1 then self:Hold("CHOOSE_REWARD_IN_QUEST_WINDOW",q);return end
        -- One reward is not a choice between different items. Multiple choices
        -- remain entirely under the player's native selection/complete button.
        self:Act(pending,"reward:"..q,GetQuestReward,choices==1 and 1 or 0,q)
    end
end
function I:Tick(elapsed)
    local p=self.pending
    if not p or not N:Number(elapsed) or elapsed<0 then return end
    p.delay=p.delay-math.min(elapsed,.2)
    if p.delay>0 then return end
    local current,why=self:Current(p)
    if not current then self:Hold(why or "INTERACTION_CHANGED");return end
    local pref=self:Preferences()
    if p.event=="GOSSIP_SHOW" then self:Gossip(p,pref)
    elseif p.event=="QUEST_GREETING" then self:Greeting(p,pref)
    else self:QuestPanel(p,pref) end
end
function I:OnEvent(event,arg,second)
    if event=="PLAYER_REGEN_DISABLED" or event=="PLAYER_LEAVING_WORLD" or event=="PLAYER_DEAD" then self:Reset(event);return end
    if event=="ADDON_ACTION_BLOCKED" or event=="ADDON_ACTION_FORBIDDEN" then
        if arg==N.name then
            if self.session then self.session.bypass=true end
            self.pending=nil;self.failures=self.failures+1;self.status="NATIVE_ACTION_BLOCKED"
        end
        return
    end
    if event=="QUEST_ACCEPTED" or event=="QUEST_TURNED_IN" then
        local q=event=="QUEST_ACCEPTED" and (id(second) and second or arg) or arg
        if id(q) and self.session then
            local key=(event=="QUEST_TURNED_IN" and "reward:" or "accept:")..q
            if self.session.attempted[key] and not self.session.confirmed[key] then
                self.session.confirmed[key]=true
                if event=="QUEST_TURNED_IN" then self.completed=self.completed+1 else self.accepted=self.accepted+1 end
            end
            if event=="QUEST_TURNED_IN" then self.session.finished[q]=true end
            self.session.selected=nil
        end
        return
    end
    if event=="GOSSIP_CLOSED" and N:Readable(arg) and arg==false then self:Reset("CONVERSATION_CLOSED");return end
    if event=="GOSSIP_CLOSED" and N:Readable(arg) and arg==true then
        self.pending=nil;self.status="QUEST_PANEL_TRANSITION";return
    end
    if event=="GOSSIP_CLOSED" or event=="QUEST_FINISHED" then
        self.pending=nil
        if self.session then self.session.closedAt=clock();self.session.selected=nil end
        self.status="CONVERSATION_CLOSED";return
    end
    if not panels[event] then return end
    -- Item/area/shared acceptance is outside the requested NPC interaction.
    if event=="QUEST_DETAIL" and (not N:Readable(arg) or (arg~=nil and arg~=0)) then self:Hold("NON_NPC_QUEST");return end
    local guid=self:NPC(event)
    if not guid then self:Hold("NPC_IDENTITY_UNAVAILABLE");return end
    local now=clock();if not now then self:Hold("INTERACTION_CLOCK_UNAVAILABLE");return end
    local s=self.session
    if not s or s.guid~=guid or now<s.startedAt or now-s.startedAt>120 or
        (s.closedAt and now-s.closedAt>1) then
        self.generation=self.generation+1
        s={guid=guid,startedAt=now,attempted={},confirmed={},manual={},finished={},count=0};self.session=s
    end
    s.closedAt=nil
    local allowed,why=self:Enabled(s)
    if not allowed then self:Hold(why);return end
    local old=self.pending
    if old and old.event==event and old.session==s then return end
    self.pending={event=event,session=s,generation=self.generation,account=N.Storage.account,
        revision=N.Storage.account.revision,delay=.05,createdAt=now,expires=now+2}
    self.status="QUEST_PANEL_PENDING"
end
function I:Snapshot()
    return {status=self.status,preferences=self:Preferences(),actions=self.actions,accepted=self.accepted,
        completed=self.completed,failures=self.failures,lastQuestID=self.lastQuestID,
        conversationActions=self.session and self.session.count or 0,
        pending=self.pending~=nil,bypass=self.session and self.session.bypass==true or false,
        nativeVerification="NOT_RUN"}
end
