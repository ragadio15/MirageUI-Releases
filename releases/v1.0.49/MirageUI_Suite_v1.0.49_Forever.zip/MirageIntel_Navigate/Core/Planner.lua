local _,N=...
-- One bounded selector owns quest order. All scores stay within same-world
-- distance units; progress, turn-in and cluster bonuses are capped factors.
N.Planner={headID=nil,headStage=nil,challengerID=nil,challengerAt=nil,builds=0,candidateCount=0,
    status="IDLE",excluded={},plan={},revision=0}
local P=N.Planner
P.defaults={switchImprovement=.20,holdSeconds=5,range=2000,clusterRadius=60,maxStops=8,
    preferTurnIns=false,finishNearby=true,includeGivers=true,progressWeight=.10,unlockWeight=.08}
local bounds={switchImprovement={.05,.5},holdSeconds={1,30},range={100,10000},clusterRadius={10,150},
    maxStops={1,12},progressWeight={0,.25},unlockWeight={0,.15}}
function P:Preferences()
    local saved=type(N.Storage.account)=="table" and N.Storage.account.planner
    local out=N._copy(self.defaults)
    if type(saved)=="table" then for key,limit in pairs(bounds) do
        local v=N:Field(saved,key);if N:Number(v) and v>=limit[1] and v<=limit[2] then out[key]=v end
    end
    for _,key in ipairs({"preferTurnIns","finishNearby","includeGivers"}) do
        local v=N:Field(saved,key);if type(v)=="boolean" then out[key]=v end
    end end
    out.maxStops=math.floor(out.maxStops)
    return out
end
function P:SetPreferences(values)
    if not N:Table(values) then return false,"INVALID_QUEST_PREFERENCES" end
    if N.Storage.readOnly or not N.state.clientAllowed or N:InCombat() then return false,"CLIENT_OR_COMBAT_UNAVAILABLE" end
    local out=self:Preferences()
    for key,value in pairs(values) do
        local limits=bounds[key]
        if (key=="preferTurnIns" or key=="finishNearby" or key=="includeGivers") and type(value)=="boolean" then out[key]=value
        elseif limits and N:Number(value) and value>=limits[1] and value<=limits[2] then
            if key=="maxStops" and value%1~=0 then return false,"INVALID_STOP_COUNT" end
            out[key]=value
        else return false,"INVALID_QUEST_PREFERENCE" end
    end
    if values.finishNearby==true and values.preferTurnIns==true then return false,"CONFLICTING_RETURN_PREFERENCES" end
    if values.finishNearby==true then out.preferTurnIns=false end
    if values.preferTurnIns==true then out.finishNearby=false end
    N.Storage.account.planner=out;N.Storage.account.revision=N.Storage.account.revision+1
    self:Invalidate("PREFERENCES_CHANGED");N:Invalidate("QUEST_PREFERENCES_CHANGED")
    return true,"QUEST_PREFERENCES_UPDATED"
end
local function distance(a,b)
    local dx,dy=a.world.x-b.world.x,a.world.y-b.world.y
    return math.sqrt(dx*dx+dy*dy)
end
function P:Invalidate(reason,clearHead)
    self.challengerID=nil;self.challengerAt=nil;self.lastEvaluationAt=nil;self.cached=nil
    self.evaluationEpoch=(self.evaluationEpoch or 0)+1;self.nextEvaluationAt=nil
    self.evaluationReady=false
    self.status=reason or "INVALIDATED"
    if clearHead then
        self.headID=nil;self.headStage=nil;self.headAt=nil
        self.nearbyWorkID=nil;self.deferredReturns={}
        if #self.plan>0 then self.revision=self.revision+1 end
        self.plan={};self.planKey=nil
    end
end
function P:Forget(id)
    self.cached=nil;self.evaluationReady=false;self.lastEvaluationAt=nil
    self.evaluationEpoch=(self.evaluationEpoch or 0)+1;self.nextEvaluationAt=nil
    if self.headID==id then self.headID=nil;self.headStage=nil end
    if self.nearbyWorkID==id then self.nearbyWorkID=nil end
    if self.challengerID==id then self.challengerID=nil;self.challengerAt=nil end
    local changed=false
    for i=#self.plan,1,-1 do if self.plan[i].questID==id then table.remove(self.plan,i);changed=true end end
    if changed then
        self.planKey=nil;self.revision=self.revision+1
        for index,row in ipairs(self.plan) do row.index=index end
    end
end
function P:NextEvaluation(now,pref,empty)
    -- Stable exact geometry can wait for the next native evidence sweep.
    -- Local deferrals and the sustained-improvement deadline still wake the
    -- selector on time, even when the player remains completely stationary.
    -- Keep an empty result on the original short retry interval. It provides
    -- no destination to continue following while optional evidence recovers.
    local due=now+(empty and .5 or 3)
    for id,expires in pairs(self.skipped or {}) do
        if not N:Number(expires) or expires<=now then self.skipped[id]=nil
        else due=math.min(due,expires) end
    end
    if self.challengerID and self.challengerAt then
        local switchAt=math.max(self.challengerAt+pref.holdSeconds,(self.headAt or self.challengerAt)+pref.holdSeconds)
        if switchAt>now then due=math.min(due,switchAt) end
    end
    self.nextEvaluationAt=due
end
function P:RejectInput(candidates,revision)
    self:Invalidate("QUEST_PLAN_CHANGED",true)
    -- Authority may consult the planner twice in one pass. Keep the rejected
    -- snapshot unavailable to that second call until a fresh candidate sweep
    -- replaces it; the dirty interval requests that sweep without a busy loop.
    self.rejectedCandidates=candidates;self.rejectedCandidateRevision=revision
    N:Invalidate("QUEST_PLAN_CHANGED")
end
function P:Eligible(row,player,pref)
    if self.skipped and self.skipped[row.questID] and N:Now()<self.skipped[row.questID] then return false,"PLAYER_SKIPPED" end
    if row.eligible==false then return false,row.eligibilityReason or "QUEST_INELIGIBLE" end
    if row.awaitingTurnIn then return false,"TURN_IN_LOCATION_PENDING" end
    if row.accepted==false and not pref.includeGivers then return false,"QUEST_GIVERS_DISABLED" end
    if row.stage~="OBJECTIVES" and row.stage~="READY_FOR_TURN_IN" and row.stage~="AVAILABLE" and row.stage~="ACCEPTED" and row.stage~="QUEST_GIVER" then return false,"QUEST_STAGE_UNKNOWN" end
    if row.mapID~=player.mapID or (row.floorID or row.mapID)~=(player.floorID or player.mapID) then return false,"OTHER_MAP_OR_FLOOR" end
    if not row.world or row.world.continent~=player.world.continent then return false,"WORLD_GEOMETRY_UNAVAILABLE" end
    local d=N.map:Measure(player,row)
    if not N:Number(d) then return false,"DISTANCE_UNAVAILABLE" end
    return true,nil,d
end
local function unfinished(row)
    return row.accepted~=false and (row.stage=="OBJECTIVES" or row.stage=="ACCEPTED")
end
function P:DeferredReturn(entry,from,list,pref,used)
    if not pref.finishNearby or pref.preferTurnIns or entry.row.stage~="READY_FOR_TURN_IN" then return nil end
    local direct=distance(from,entry.row)
    -- A nearby NPC is a useful stop, not a town-return detour. Otherwise finish
    -- close work when it is nearer or adds only a modest detour to that return.
    if direct<=math.max(75,pref.clusterRadius) then return nil end
    for _,other in ipairs(list) do
        if unfinished(other.row) and other.row.world and not (used and used[other.row.questID]) then
            local work=distance(from,other.row)
            local detour=work+distance(other.row,entry.row)-direct
            if work<=math.min(pref.range,800) and (work<=direct*1.1 or
                detour<=math.max(pref.clusterRadius*2,math.min(300,direct*.25))) then
                return other.row.questID
            end
        end
    end
end
function P:Priority(entry,from,pref,list,used)
    local row=entry.row;local d=distance(from,row)
    if pref.preferTurnIns and row.stage=="READY_FOR_TURN_IN" then return 1,"TURN_INS_FIRST" end
    local work=self:DeferredReturn(entry,from,list,pref,used)
    if work then return 5,"FINISH_NEARBY_WORK",work end
    if row.accepted~=false then return 2,row.stage=="READY_FOR_TURN_IN" and "CONVENIENT_TURN_IN" or "UNFINISHED_QUEST" end
    local localGiver=d<=math.max(100,pref.clusterRadius*2)
    for _,other in ipairs(list) do
        if unfinished(other.row) and other.row.world and not (used and used[other.row.questID]) then
            local target=distance(from,other.row);local onward=distance(row,other.row)
            if onward<=pref.clusterRadius or (d<=target and d+onward-target<=pref.clusterRadius*.75) then localGiver=true;break end
        end
    end
    return localGiver and 2 or 4,localGiver and "QUEST_GIVERS_ALONG_THE_WAY" or "QUEST_GIVER_NEXT_AREA"
end
function P:Skip(id)
    if not N:Integer(id) then return false,"NO_DESTINATION" end
    self.skipped=self.skipped or {};self.skipped[id]=N:Now()+120
    self:Invalidate("PLAYER_SKIPPED",true);N:Invalidate("PLAYER_SKIPPED");return true
end
function P:Score(entry,from,pref)
    local d=distance(from,entry.row)
    local cluster=1/(1+.15*math.min(#entry.group-1,3))
    local turnin=pref.preferTurnIns and entry.row.stage=="READY_FOR_TURN_IN" and .88 or 1
    local progress=N:Number(entry.row.progress) and (1-pref.progressWeight*math.max(0,math.min(1,entry.row.progress))) or 1
    local unlock=N:Number(entry.row.unlockValue) and (1-pref.unlockWeight*math.max(0,math.min(1,entry.row.unlockValue))) or 1
    local watched=N.Quest.watched and N.Quest.watched[entry.row.questID] and .94 or 1
    return math.max(1,d)*cluster*turnin*progress*unlock*watched,
        {distanceYards=d,clusterFactor=cluster,turnInFactor=turnin,progressFactor=progress,unlockFactor=unlock,
        watchedFactor=watched,costBasis="SAME_WORLD_DISTANCE_HEURISTIC",progressKnown=entry.row.progress~=nil}
end
function P:BuildOrder(list,head,player,pref)
    local plan,used={},{}
    local nextEntry=head;local from=player
    while #plan<math.min(12,pref.maxStops,#list) do
        if not nextEntry then
            local bestScore,bestPriority
            for _,entry in ipairs(list) do if not used[entry.row.questID] then
                local score=self:Score(entry,from,pref)
                local priority=self:Priority(entry,from,pref,list,used)
                if not nextEntry or priority<bestPriority or (priority==bestPriority and
                    (score<bestScore or (score==bestScore and entry.row.questID<nextEntry.row.questID))) then
                    nextEntry=entry;bestScore=score;bestPriority=priority
                end
            end end
        end
        if not nextEntry then break end
        local row=nextEntry.row
        used[row.questID]=true
        plan[#plan+1]={id=row.id,questID=row.questID,mapID=row.mapID,floorID=row.floorID,x=row.x,y=row.y,
            label=row.label,stage=row.stage,kind="quest",category=row.stage=="READY_FOR_TURN_IN" and "turn-in" or row.accepted==false and "quest-giver" or "objective",
            visitOnly=row.visitOnly,availability=row.availability,accepted=row.accepted,index=#plan+1,clusterSize=#nextEntry.group,
            precision="SUGGESTED_STOP_ORDER",costBasis="SAME_WORLD_DISTANCE_HEURISTIC",traversability="UNVERIFIED"}
        from=row;nextEntry=nil
    end
    local parts={}
    for _,row in ipairs(plan) do parts[#parts+1]=table.concat({row.id,row.mapID,row.floorID or row.mapID,row.x,row.y,row.stage,row.label or ""},":") end
    local key=table.concat(parts,"|")
    if key~=self.planKey then self.planKey=key;self.revision=self.revision+1 end
    self.plan=plan
end
function P:Choose(player)
    if not player or not player.world then self:Invalidate("PLAYER_POSITION_UNAVAILABLE",true);return nil end
    if self.rejectedCandidates==N.candidates and self.rejectedCandidateRevision==N.state.candidateRevision then return nil end
    self.rejectedCandidates=nil;self.rejectedCandidateRevision=nil
    local now=N:Now();local pref=self:Preferences()
    local previousClock=math.max(self.lastClockAt or now,self.lastEvaluationAt or now,self.headAt or now,self.challengerAt or now)
    self.lastClockAt=now
    if now<previousClock then
        self:Invalidate("CLOCK_RESET")
        -- A retained stop must not inherit a mandatory hold from a future
        -- clock. Start its ordinary hold again on the current time basis.
        if self.headID then self.headAt=now end
        for id,expires in pairs(self.skipped or {}) do
            if N:Number(expires) then self.skipped[id]=now+math.min(120,math.max(0,expires-previousClock))
            else self.skipped[id]=nil end
        end
    end
    local previous=self.playerPosition
    local sameArea=previous and previous.mapID==player.mapID and
        (previous.floorID or previous.mapID)==(player.floorID or player.mapID) and
        previous.world and previous.world.continent==player.world.continent
    local stationary=sameArea and previous.x==player.x and previous.y==player.y and
        previous.world.x==player.world.x and previous.world.y==player.world.y
    local account=N.Storage.account
    local accountRevision=type(account)=="table" and account.revision
    if self.evaluationReady and self.lastEvaluationAt and now<(self.nextEvaluationAt or self.lastEvaluationAt+.5) and
        self.inputRevision==N.state.candidateRevision and self.inputCandidates==N.candidates and
        self.inputAccount==account and self.inputAccountRevision==accountRevision and sameArea and
        (stationary or (now-self.lastEvaluationAt<.5 and distance(previous,player)<=8)) then
        self.cacheHits=(self.cacheHits or 0)+1
        return N._copy(self.cached)
    end
    local candidates=N.candidates;local candidateRevision=N.state.candidateRevision
    local questGeneration=N.Quest.generation;local epoch=self.evaluationEpoch
    local worldRevision=N.state.reconciliationGeneration;local mode=N.state.mode
    local function evidenceCurrent()
        return candidates==N.candidates and candidateRevision==N.state.candidateRevision and questGeneration==N.Quest.generation and
            epoch==self.evaluationEpoch and worldRevision==N.state.reconciliationGeneration and mode==N.state.mode and
            account==N.Storage.account and accountRevision==(type(account)=="table" and account.revision)
    end
    self.lastEvaluationAt=now;self.inputRevision=N.state.candidateRevision;self.playerPosition=N._copy(player)
    self.inputCandidates=candidates;self.inputAccount=account;self.inputAccountRevision=accountRevision
    self:NextEvaluation(now,pref)
    local list,byID={},{};self.excluded=N._copy(N.Quest.excluded or {})
    for _,row in ipairs(N.candidates) do
        local ok,why,d=self:Eligible(row,player,pref)
        if ok then list[#list+1]={row=row,distance=d}
        else self.excluded[row.questID]=why end
    end
    -- A provider read can deliver a quest removal/update while eligibility is
    -- being measured. Never replace the newer withdrawal with the old plan.
    if not evidenceCurrent() then self:RejectInput(candidates,candidateRevision);return nil end
    -- Prefer the local working area, but retain the rest of the current map
    -- as a useful fallback when no nearby objective remains.
    local nearby=false
    for _,entry in ipairs(list) do if entry.distance<=pref.range then nearby=true;break end end
    table.sort(list,function(a,b) if a.distance~=b.distance then return a.distance<b.distance end;return a.row.questID<b.row.questID end)
    while #list>64 do self.excluded[list[#list].row.questID]="CANDIDATE_LIMIT";list[#list]=nil end
    -- Complete-link clusters cannot form arbitrarily long waypoint chains.
    local groups={}
    for _,entry in ipairs(list) do
        local chosen
        for _,group in ipairs(groups) do
            local fits=true
            for _,other in ipairs(group) do if distance(entry.row,other.row)>pref.clusterRadius then fits=false;break end end
            if fits then chosen=group;break end
        end
        if not chosen then chosen={};groups[#groups+1]=chosen end
        chosen[#chosen+1]=entry;entry.group=chosen;byID[entry.row.questID]=entry
    end
    local best;self.deferredReturns={};self.nearbyWorkID=nil;self.giverCount=0;self.objectiveCount=0;self.turnInCount=0
    for _,entry in ipairs(list) do
        if not self.nearbyWorkID and unfinished(entry.row) and entry.distance<=math.min(pref.range,800) then self.nearbyWorkID=entry.row.questID end
        local priority,reason,work=self:Priority(entry,player,pref,list)
        entry.priority=priority+(nearby and entry.distance>pref.range and 10 or 0);entry.policyReason=reason
        if work then self.deferredReturns[entry.row.questID]=work end
        if entry.row.stage=="READY_FOR_TURN_IN" then self.turnInCount=self.turnInCount+1
        elseif entry.row.accepted==false then self.giverCount=self.giverCount+1
        else self.objectiveCount=self.objectiveCount+1 end
        entry.score,entry.factors=self:Score(entry,player,pref)
        if not best or entry.priority<best.priority or (entry.priority==best.priority and (entry.score<best.score or (entry.score==best.score and entry.row.questID<best.row.questID))) then best=entry end
    end
    if not evidenceCurrent() then self:RejectInput(candidates,candidateRevision);return nil end
    self.builds=self.builds+1;self.candidateCount=#list
    if not best then
        self:Invalidate("NO_ELIGIBLE_LOCAL_QUEST",true)
        -- An empty local quest set is a valid short-lived result. Automatic
        -- gathering/exploration can ask twice in one reconciliation; do not
        -- repeat the whole eligibility pass until evidence or position changes.
        self.lastEvaluationAt=now;self.inputRevision=N.state.candidateRevision
        self.playerPosition=N._copy(player);self.evaluationReady=true
        self:NextEvaluation(now,pref,true)
        return nil
    end
    local current=self.headID and byID[self.headID]
    local completion=current and self.headStage and current.row.stage~=self.headStage
    local decision=completion and "QUEST_STAGE_CHANGED" or not current and "FIRST_ELIGIBLE_QUEST" or "BEST_LOCAL_SCORE"
    if current and not completion and current.priority==best.priority and current.row.questID~=best.row.questID then
        if best.score>current.score*(1-pref.switchImprovement) then
            self.challengerID=nil;self.challengerAt=nil;best=current;decision="CURRENT_STOP_RETAINED"
        else
            if self.challengerID~=best.row.questID or not self.challengerAt or now<self.challengerAt then
                self.challengerID=best.row.questID;self.challengerAt=now
            end
            if now-self.challengerAt<pref.holdSeconds or (self.headAt and now-self.headAt<pref.holdSeconds) then
                best=current;decision="WAITING_SUSTAINED_IMPROVEMENT"
            else decision="SUSTAINED_SCORE_IMPROVEMENT";self.challengerID=nil;self.challengerAt=nil end
        end
    else self.challengerID=nil;self.challengerAt=nil end
    if self.headID~=best.row.questID or completion then self.headAt=now end
    self.headID=best.row.questID;self.headStage=best.row.stage;self.status="LOCAL_QUEST_SUGGESTION"
    self:BuildOrder(list,best,player,pref)
    local record=N._copy(best.row)
    record.clusterSize=#best.group;record.selectionReason=decision;record.score=best.score;record.scoreFactors=best.factors
    record.policyReason=best.policyReason
    record.suitabilityReason=record.accepted==false and "CHECK_QUEST_GIVER" or record.stage=="READY_FOR_TURN_IN" and "NEARBY_TURN_IN" or #best.group>1 and "USEFUL_LOCAL_CLUSTER" or
        N:Number(record.progress) and record.progress>=.5 and "OBJECTIVE_PROGRESS" or "NEARBY_ELIGIBLE_OBJECTIVE"
    record.intentOrigin="AUTOMATIC_QUEST_SELECTION";record.source="WAYFINDER_QUEST_SUGGESTION"
    if not evidenceCurrent() then self:RejectInput(candidates,candidateRevision);return nil end
    self:NextEvaluation(now,pref)
    self.cached=N._copy(record);self.evaluationReady=true;return record
end
function P:Snapshot()
    return N._copy({status=self.status,builds=self.builds,cacheHits=self.cacheHits or 0,nextEvaluationAt=self.nextEvaluationAt,
        candidateCount=self.candidateCount,revision=self.revision,
        headID=self.headID,challengerID=self.challengerID,challengerSince=self.challengerAt,headSince=self.headAt,
        preferences=self:Preferences(),excluded=self.excluded,inspectable=N.Quest.inspectable or {},
        deferredReturns=self.deferredReturns,nearbyWorkID=self.nearbyWorkID,
        objectiveCount=self.objectiveCount,giverCount=self.giverCount,turnInCount=self.turnInCount,
        plan=self.plan,precision="SUGGESTED_STOP_ORDER",nativeVerification="NOT_RUN"})
end
