local addonName,N=...
N.name=addonName
N.version="1.11.5"
N.apiVersion=1
N.clientRequired="Forever:1.60.1:reviewed-through-71037:16001"
N.core=MirageIntelCoreAPI
N.state={status="STARTING",mode="Auto",dirty=true,refreshes=0,clientVerified="NOT_RUN",navigationRevision=0,
    canPersist=false,errors=0,events=0,provider="NONE"}
N.requests={}
N.candidates={}
N.autoTarget=nil
N.active=nil
N.allowedModes={"Auto","Quest","Gather","Pause","Follow Blizzard","Nearest quest","Manual only","Off"}
function N:Fault(code)
    self.state.errors=self.state.errors+1
    self.state.lastError=code
end
function N:Readable(v)
    if type(issecretvalue)=="function" then
        local ok,secret=pcall(issecretvalue,v)
        if not ok or secret==true then return false end
    end
    if type(canaccessvalue)=="function" then
        local ok,accessible=pcall(canaccessvalue,v)
        if not ok or accessible==false then return false end
    end
    return true
end
function N:Field(row,key)
    if not self:Readable(row) or (type(row)~="table" and type(row)~="userdata") then return nil end
    local ok,value=pcall(function() return row[key] end)
    if ok and self:Readable(value) then return value end
end
function N:Table(value)
    if not self:Readable(value) or type(value)~="table" then return false end
    if type(canaccesstable)=="function" then
        local ok,accessible=pcall(canaccesstable,value)
        if not ok or accessible~=true then return false end
    end
    return true
end
function N:Service(name)
    local api,ok=self:SafeCall(self.core and self.core.GetService,name,1)
    return ok and self:Table(api) and api or nil
end
function N:Number(v)
    return self:Readable(v) and type(v)=="number" and v==v and v>-math.huge and v<math.huge
end
function N:Integer(v) return self:Number(v) and v>0 and v%1==0 end
function N:Text(v) return self:Readable(v) and type(v)=="string" and #v<=160 and not v:find("[|%c]") and v or nil end
function N:SafeCall(fn,...)
    if not self:Readable(fn) or type(fn)~="function" then return nil,false end
    local ok,a,b,c,d=pcall(fn,...)
    if not ok or not self:Readable(a) or not self:Readable(b) or not self:Readable(c) or not self:Readable(d) then return nil,false end
    return a,true,b,c,d
end
function N:Now()
    local t,ok=self:SafeCall(GetTime)
    return ok and self:Number(t) and t or 0
end
function N:Print(message)
    if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage("|cffe8b77dWayfinder:|r "..tostring(message)) end
end
function N:InCombat()
    local value,ok=self:SafeCall(InCombatLockdown)
    -- Unknown combat state is unsafe for new map/waypoint actions.
    -- A successful nil is the legacy WoW unlocked result, not an API failure.
    return not ok or (value~=nil and value~=false)
end
-- Diagnostics remain callable when Core is absent or incompatible. This
-- bounded local copier is a read-only fallback, never a replacement map API.
local function diagnosticCopy(value,depth,seen)
    if not N:Readable(value) then return nil end
    local kind=type(value)
    if kind~="table" then
        if kind=="string" or kind=="boolean" or kind=="nil" or (kind=="number" and N:Number(value)) then return value end
        return nil
    end
    depth=(depth or 0)+1;seen=seen or {}
    if depth>12 or seen[value] or not N:Table(value) then return nil end
    seen[value]=true;local out={};local count=0
    local ok=pcall(function()
        for key,item in pairs(value) do
            count=count+1;if count>512 then break end
            if (type(key)=="string" or type(key)=="number") and N:Readable(key) then out[key]=diagnosticCopy(item,depth,seen) end
        end
    end)
    seen[value]=nil
    return ok and out or nil
end
N._copy=diagnosticCopy
function N:ClientAllowed()
    if not self:Table(self.core) or self:Field(self.core,"apiVersion")~=1 then
        self.state.coreContract="CORE_API_MISMATCH";self.core=nil;return false
    end
    local result,ok=self:SafeCall(self:Field(self.core,"GetCapabilities"))
    local client=ok and self:Field(result,"client")
    if not ok or not self:Table(result) or not self:Table(client) then
        self.state.coreContract="CORE_CAPABILITIES_UNAVAILABLE";self.core=nil;return false
    end
    self.capabilities=result;self.state.coreContract="API1_READABLE"
    local build=self:Field(client,"build")
    return self:Field(client,"allowed")==true
end
function N:Invalidate(event)
    self.state.dirty=true
    self.state.invalidationRevision=(self.state.invalidationRevision or 0)+1
    self.state.reason=event or "REQUESTED_REFRESH"
end
function N:Initialize()
    if self.state.initialized then return end
    self.state.clientAllowed=self:ClientAllowed()
    local info=self.capabilities
    self.state.clientBuild=self:Text(self:Field(self:Field(info,"client"),"build")) or "unknown"
    self.map=self:Field(self.core,"Map")
    local copier=self:Field(self.core,"Copy")
    if type(copier)=="function" then self._copy=copier end
    if not self:Table(self.map) or type(self:Field(self.map,"Valid"))~="function" or
        type(self:Field(self.map,"World"))~="function" or type(self:Field(self.map,"Player"))~="function" or
        type(self:Field(self.map,"Measure"))~="function" or type(copier)~="function" then
        self.state.clientAllowed=false
        self:Fault("CORE_MAP_CONTRACT_MISSING")
    end
    self.Storage:Initialize()
    if self.Session then self.Session:Initialize() end
    self.state.canPersist=not self.Storage.readOnly
    self.state.status=not self.state.clientAllowed and "UNSUPPORTED_BUILD" or
        self.Storage.readOnly and "STORAGE_READ_ONLY" or "READY_NATIVE_UNTESTED"
    self.state.inWorld=false
    self.state.initialized=true
    self.state.dirty=true
    self.API:Install()
    if self.core and self.core.RegisterModule then
        self:SafeCall(self.core.RegisterModule,"MirageIntel_Navigate",1,{navigation=true,navigationVersion=2,blizzardWaypointRead=true,
             manualPin=true,optionalCursor=true,gatherSessions=true,questItinerary=true,questInteraction=true,
             questInteractionVersion=1,graphPreview=true,precision="PER_LEG"})
    end
    if self.Controller and self.Controller.Connect then self.Controller:Connect() end
    self.Commands:Install()
    self.UI:Initialize()
    self:PublishStatus()
end
function N:PublishStatus()
    if self.core and self.core.Publish then
        self:SafeCall(self.core.Publish,"NAV_STATUS_CHANGED",{status=self.state.status,source=self.state.provider,
           build=self.state.clientBuild or "unknown",nativeVerification="NOT_RUN"})
    end
end
