local _,N=...
N.Cursor={}
local function bridge()
    local api=MirageUICursorNavBridge
    return type(api)=="table" and (api.apiVersion==1 or api.apiVersion==2) and api or nil
end
function N.Cursor:IsPresent()
    local f=(type(C_AddOns)=="table" and C_AddOns.IsAddOnLoaded) or IsAddOnLoaded
    if type(f)~="function" then return false end
    for _,name in ipairs({"CursorCompanion","MirageUICursor"}) do
        local ok,loaded=pcall(f,name)
        if ok and loaded==true then return true end
    end
    return false
end
function N.Cursor:HasUnbridgedCompanion()
    local api=bridge()
    if api and (type(api.IsAnyNavigationActive)=="function" or type(api.IsActive)=="function") then return false end
    return self:IsPresent()
end
function N.Cursor:IsActive()
    local api=bridge()
    if not api or type(api.IsActive)~="function" then return false end
    local ok,on=pcall(api.IsActive)
    return ok and on==true
end
function N.Cursor:GetSelection()
    local api=bridge()
    if not api or not self:IsActive() or type(api.GetSelection)~="function" then return nil end
    local good,selection=pcall(api.GetSelection)
    if not good or type(selection)~="table" then return nil end
    -- Copy only the fields of the published contract, not private addon state.
    local ok,result=pcall(function() return {mapID=selection.mapID,worldX=selection.worldX,
        worldY=selection.worldY,continent=selection.continent,label=selection.label,
        questID=selection.questID,stage=selection.stage,source=selection.source,quality=selection.quality} end)
    return ok and result or nil
end
function N.Cursor:Ownership()
    local current=bridge()
    if N.Session and current and current.snapshotConsumer==true then
        local lease=N.Session:Renderer()
        return lease and lease.owner=="CursorCompanion" and "CURSOR" or "WAYFINDER"
    end
    local api=bridge()
    if api and type(api.IsAnyNavigationActive)=="function" then
        local ok,on=pcall(api.IsAnyNavigationActive)
        if ok and type(on)=="boolean" then return on and "CURSOR" or "WAYFINDER" end
    elseif self:IsActive() then return "CURSOR" end
    -- A present but silent/malformed bridge does not establish that rendering
    -- is off. Do not claim Cursor is showing an arrow or accepted a destination.
    return self:IsPresent() and "UNKNOWN" or "WAYFINDER"
end
function N.Cursor:IsAnyActive()
    return self:Ownership()~="WAYFINDER"
end
function N.Cursor:Status()
    if self:Ownership()=="UNKNOWN" then return "F10_UNBRIDGED_DUPLICATE_HUD_SUPPRESSED" end
    local api=bridge()
    if not api or type(api.GetState)~="function" then return "NOT_PRESENT" end
    local ok,result=pcall(api.GetState)
    local read,status=pcall(function() return type(result)=="table" and result.status end)
    return ok and read and type(status)=="string" and status or "UNAVAILABLE"
end
