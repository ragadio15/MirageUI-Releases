local _,M=...
M.Rework=M.Rework or {}
local R,S,V=M.Rework,M.Safety,M.NameplateCard
local N={status="NOT_INITIALIZED",pool={},filteredPool={},nativeMonitors=setmetatable({},{__mode="k"}),observed={},byUnit={},byPlate=setmetatable({},{__mode="k"}),byObject=setmetatable({},{__mode="k"}),monitors=setmetatable({},{__mode="k"}),queue={},events={
 PLAYER_REGEN_ENABLED=true,PLAYER_REGEN_DISABLED=true,PLAYER_ENTERING_WORLD=true,GAME_RULES_CHANGED=true,ADDON_LOADED=true,EDIT_MODE_LAYOUTS_UPDATED=true,
 ACTIONBAR_SLOT_CHANGED=true,UPDATE_MACROS=true,MODIFIER_STATE_CHANGED=true,UPDATE_SHAPESHIFT_FORM=true,SPELLS_CHANGED=true,PLAYER_SPECIALIZATION_CHANGED=true,
 NAME_PLATE_CREATED=true,NAME_PLATE_UNIT_ADDED=true,NAME_PLATE_UNIT_REMOVED=true,PLAYER_TARGET_CHANGED=true,PLAYER_FOCUS_CHANGED=true,UPDATE_MOUSEOVER_UNIT=true,RAID_TARGET_UPDATE=true,UNIT_FACTION=true,CVAR_UPDATE=true,KNOWN_TITLES_UPDATE=true,
 UNIT_HEALTH=true,UNIT_MAXHEALTH=true,UNIT_POWER_UPDATE=true,UNIT_MAXPOWER=true,UNIT_DISPLAYPOWER=true,UNIT_AURA=true,UNIT_NAME_UPDATE=true,UNIT_LEVEL=true,PLAYER_LEVEL_UP=true,
 UNIT_FLAGS=true,UNIT_CONNECTION=true,UNIT_CLASSIFICATION_CHANGED=true,UNIT_THREAT_SITUATION_UPDATE=true,UNIT_THREAT_LIST_UPDATE=true,UNIT_TARGET=true,
 UNIT_SPELLCAST_START=true,UNIT_SPELLCAST_STOP=true,UNIT_SPELLCAST_DELAYED=true,UNIT_SPELLCAST_FAILED=true,UNIT_SPELLCAST_INTERRUPTED=true,
 UNIT_SPELLCAST_CHANNEL_START=true,UNIT_SPELLCAST_CHANNEL_STOP=true,UNIT_SPELLCAST_CHANNEL_UPDATE=true,UNIT_SPELLCAST_EMPOWER_START=true,UNIT_SPELLCAST_EMPOWER_STOP=true,UNIT_SPELLCAST_EMPOWER_UPDATE=true,
 UNIT_SPELLCAST_INTERRUPTIBLE=true,UNIT_SPELLCAST_NOT_INTERRUPTIBLE=true}}
R.Nameplates=N
local function invalidateHitPolicy()
 local world=M.WorldCombatText
 if not world then return end
 if world.InvalidatePlates then world:InvalidatePlates() else world.platePolicyDirty=true end
end
function N:Fallback(unit,reason)
 self.fallbacks=self.fallbacks or {}
 if S:Text(unit) then self.fallbacks[unit]=reason end
 self.lastRefusal=reason or "NATIVE_CONTENT_UNAVAILABLE"
 self.status="PARTIAL_NATIVE_FALLBACK"
end
function N:Outcome()
 local owned,details,retiring,stale,inputPending,constrained,presentationDeferred=false,false,false,false,false,false,false
 for _,v in pairs(self.byUnit) do
  if v.retiring then retiring=true
  elseif v.filterOnly and v.lease and v.lease.ambientName then
   -- Ambient masks are checked by the lifecycle hooks and the rotating audit.
   -- They contribute no custom card or input ownership to this status.
  elseif self:Current(v) then
   -- A lightweight category filter owns no Mirage plate. Its custody alone
   -- must never certify that a custom display is running.
   if not v.filterOnly and v.admitted~=false then
    owned=true;details=details or next(v.detailIssues or {})~=nil
    local h=v.lease.hit;inputPending=inputPending or h and (h.displaced or h.hidePending)
    constrained=constrained or h and h.mode=="PASSIVE_NATIVE_REGION"
    presentationDeferred=presentationDeferred or v.presentationDeferred~=nil
   end
  elseif v.lease then stale=true end
 end
 if retiring then self.status="PLATE_RESTORE_PENDING";return R:Result("DEFERRED_HANDOFF",self.status) end
 if not self.active then return R:Result("WAITING",self.status or "PROVIDER_INACTIVE") end
 local selection=self:SelectionCoverage()
 local nativePolicy=false
 for unit,reason in pairs(self.fallbacks or {}) do
  local entry=self.admissionStates and self.admissionStates[unit]
  local state
  if entry then local _,_,policy=self:InputBlocker(entry.plate);state=policy end
  if reason=="NATIVE_HIT_POLICY_NO_REGION" and state=="NATIVE_POLICY" then nativePolicy=true
  else self.status="PARTIAL_NATIVE_FALLBACK";return R:Result("PARTIAL",self.status) end
 end
 if stale then self.status="PLATE_IDENTITY_REFRESH_PENDING";return R:Result("WAITING",self.status) end
 if inputPending then self.status="NATIVE_HIT_ALIGNMENT_PENDING";return R:Result("PARTIAL",self.status) end
 if presentationDeferred then self.status="NAMEPLATE_PRESENTATION_DEFERRED";return R:Result("PARTIAL",self.status) end
 if details then self.status="PLATE_DETAIL_RETRY_PENDING";return R:Result("PARTIAL",self.status) end
 if constrained then self.status="NAMEPLATE_PRESENTATION_CONSTRAINED";return R:Result("PARTIAL",self.status) end
 if nativePolicy then self.status="NATIVE_NO_HIT_POLICY_RETAINED";return R:Result(owned and "READY" or "WAITING",self.status) end
 if self.friendlyPolicyPending then
  self.status=self.friendlyPolicyBlocked and not self.friendlyPolicyRetry and "FRIENDLY_NATIVE_NAME_EXTERNAL_CHOICE" or "FRIENDLY_NATIVE_NAME_POLICY_PENDING"
  return R:Result(owned and "PARTIAL" or "WAITING",self.status)
 end
 if selection then self.status=selection;return R:Result(owned and "PARTIAL" or "WAITING",self.status) end
 if not owned then self.status="WAITING_FOR_NATIVE_PLATES";return R:Result("WAITING",self.status) end
 self.status="OWNED_CUSTOM_PLATES";return R:Result("READY",self.status)
end
local function field(o,k)
 if not S:Frame(o,false) then return nil end
 local ok,v=pcall(function() return o[k] end)
 if ok and S:Readable(v) then return v end
end
local function call(o,k,...)
 local fn=field(o,k);if type(fn)~="function" then return false end
 return pcall(fn,o,...)
end
local function value(o,k,kind) return S:Public(field(o,k),kind,o) end
-- Forever 1.60.1.70938 BaseNamePlateUnitFrameTemplate. These are the stock
-- body branches/regions, not the native name. Health/cast descendants inherit
-- their container opacity; selectionHighlight explicitly ignores it and is
-- therefore leased separately. The aggro mask is not a visible region.
local friendlyBodyKeys={"HealthBarsContainer","CastBarsContainer","RaidTargetFrame","ClassificationFrame",
 "PlayerLevelDiffFrame","LevelFrame","behindCameraIcon","selectionHighlight","aggroHighlight",
 "aggroHighlightBase","aggroHighlightAdditive","aggroFlash"}
-- Ambient player labels keep their native raid/offscreen/soft-target/widget
-- cues. This list owns body artwork only; it never owns native input bounds.
local ambientBodyKeys={"HealthBarsContainer","CastBarsContainer",
 "PlayerLevelDiffFrame","LevelFrame","selectionHighlight","aggroHighlight",
 "aggroHighlightBase","aggroHighlightAdditive","aggroFlash"}
local function legal(o)
 if not S:Frame(o,false) then return false end
 if not S:InCombat() then return true end
 local protected,state=value(o,"IsProtected","boolean")
 return state=="KNOWN" and not protected
end
local function eligible() return not M.state.safe and R:Qualified() and R:Selected("nameplates",M.profile) end
local function selected() return eligible() and not R:NativeEditing() end
local function config() return M.profile.modules.Nameplates end
local function offset() return (config().cardOffsetY or 0)+12 end
local function capacity() return math.max(16,math.min(80,math.floor(config().cardLimit or 80))) end
local function unitToken(unit) return S:Text(unit) and unit:match("^nameplate%d+$")~=nil end
local function plateFor(unit) return S:Public(C_NamePlate and C_NamePlate.GetNamePlateForUnit,nil,unit) end
local function selectionPlate(unit)
 local fn=C_NamePlate and C_NamePlate.GetNamePlateForUnit
 if type(fn)~="function" then return nil,"UNSUPPORTED" end
 local good,plate=pcall(fn,unit)
 if not good then return nil,"UNKNOWN" end
 if not S:Readable(plate) then return nil,"RESTRICTED" end
 -- A successful public nil proves no emitted plate. S:Public deliberately
 -- merges nil with unknown, which is insufficient for this diagnostic.
 if plate==nil then return nil,"ABSENT" end
 if not S:Frame(plate,false) then return nil,"UNAVAILABLE" end
 return plate,"KNOWN"
end
local function nativeUnit(plate)
 local fn=field(plate,"GetUnit")
 return (type(fn)=="function" and S:Public(fn,"string",plate)) or field(plate,"unitToken") or field(plate,"namePlateUnitToken") or field(field(plate,"UnitFrame"),"unit")
end
-- Friendly players require native full-plate emission for selected custom
-- cards. Ambient players retain their actual native label under a scoped
-- body-art mask; its native hit footprint is deliberately unchanged. Other
-- friendly families keep the existing world-name policy. Native labels are
-- never recolored, resized or reconstructed by this path.
local function nameFont(object)
 local fn=field(object,"GetFont");if type(fn)~="function" then return nil end
 local okay,path,height,flags=pcall(fn,object)
 if not okay or not S:Text(path) or #path==0 or #path>512 or not S:Number(height) or height<=0 or height>128
  or not S:Readable(flags) or flags~=nil and (not S:Text(flags) or #flags>64) then return nil end
 return {path,height,flags or ""}
end
local function nameColor(object)
 local fn=field(object,"GetTextColor");if type(fn)~="function" then return nil end
 local okay,r,g,b,a=pcall(fn,object)
 if not okay then return nil end
 local color={r,g,b,a}
 for i=1,4 do if not S:Number(color[i]) or color[i]<0 or color[i]>1 then return nil end end
 return color
end
function N:AmbientLabelReady(plate,uf,name)
 if value(uf,"IsShowOnlyName","boolean")==true then return false,"NATIVE_NAMES_ONLY_POLICY" end
 if field(uf,"widgetsOnlyMode")==true then return false,"NATIVE_WIDGETS_ONLY_POLICY" end
 if not S:Frame(plate,false) or not S:Frame(uf,false) or field(plate,"UnitFrame")~=uf
  or value(uf,"GetParent")~=plate or not S:Frame(name,false) or field(uf,"name")~=name
  or value(name,"GetParent")~=uf then return false,"NATIVE_LABEL_IDENTITY_UNAVAILABLE" end
 local text,ts=value(name,"GetText","string")
 if ts~="KNOWN" or text=="" then return false,"NATIVE_LABEL_TEXT_UNAVAILABLE" end
 local visible,vs=value(name,"IsVisible","boolean")
 local alpha,as=value(name,"GetAlpha","number")
 -- GetEffectiveAlpha is a Frame API, not a FontString API. The label is a
 -- direct region of this native controller; require its controller hierarchy
 -- to be visible even when a region elects to ignore its parent's alpha.
 local effective,es=value(uf,"GetEffectiveAlpha","number")
 local color=nameColor(name)
 if vs~="KNOWN" or as~="KNOWN" or es~="KNOWN" or not color then return false,"NATIVE_LABEL_VISIBILITY_UNAVAILABLE" end
 if not visible or alpha<=0 or effective<=0 or color[4]<=0 then return false,"NATIVE_LABEL_NOT_VISIBLE" end
 if type(field(name,"GetVertexColor"))=="function" then
  local good,r,g,b,a=call(name,"GetVertexColor")
  if not good or not S:Number(r) or not S:Number(g) or not S:Number(b) or not S:Number(a) then
   return false,"NATIVE_LABEL_COLOR_UNAVAILABLE"
  end
  if a<=0 then return false,"NATIVE_LABEL_NOT_VISIBLE" end
 end
 return true
end
function N:AmbientFallback(unit,plate,reason)
 self.ambientFallbacks=self.ambientFallbacks or {}
 self.ambientFallbacks[unit]={plate=plate,uf=field(plate,"UnitFrame"),reason=reason or "NATIVE_LABEL_UNAVAILABLE"}
 self.lastAmbientFallback=reason or "NATIVE_LABEL_UNAVAILABLE"
end
function N:RetireAmbientLabel(v,reason)
 local r=v and v.lease
 if not r or not r.ambientName then return false end
 local unit,plate=v.unit,r.plate
 self:AmbientFallback(unit,plate,reason)
 local complete=self:Release(v)
 if complete and self.active and selected() and plateFor(unit)==plate and nativeUnit(plate)==unit then
  self:Queue(unit,plate,"AMBIENT_NATIVE_LABEL_PENDING")
 end
 return complete
end
function N:WatchAmbientName(plate,uf,name)
 if type(hooksecurefunc)~="function" or not S:Frame(name,false) then return false end
 self.ambientObservers=self.ambientObservers or setmetatable({},{__mode="k"})
 self.ambientHooks=self.ambientHooks or setmetatable({},{__mode="k"})
 local complete=true
 for _,object in ipairs({name,uf,plate}) do
  self.ambientObservers[object]={plate=plate,uf=uf,name=name,unit=nativeUnit(plate)}
  local watched=self.ambientHooks[object] or {};self.ambientHooks[object]=watched
  for _,method in ipairs({"Hide","Show","SetShown","SetAlpha","SetParent","SetText","SetFormattedText","SetTextColor","SetVertexColor","SetIgnoreParentAlpha"}) do
   if not watched[method] and type(field(object,method))=="function" then
    local good=pcall(hooksecurefunc,object,method,function(changed)
     if N.writing or N.nameWriting or not N.active then return end
     local o=N.ambientObservers and N.ambientObservers[changed]
     if not o then return end
     local v=N.byPlate[o.plate]
     local r=v and v.lease
     if r and r.ambientName==o.name and r.uf==o.uf then
      -- Native UpdateName can hide, change and show the very same label in
      -- one call. Inspect its settled state once, outside all setter hooks.
      r.labelChanged=true
     elseif not v and not N.queue[o.unit] and config().selectedFriendlyPlate~=false
      and selected() and unitToken(o.unit) and plateFor(o.unit)==o.plate
      and nativeUnit(o.plate)==o.unit and field(o.plate,"UnitFrame")==o.uf then
      N:Queue(o.unit,o.plate,"AMBIENT_NATIVE_LABEL_PENDING")
     end
    end)
    if good then watched[method]=true else complete=false end
   end
  end
 end
 return complete
end
local function sameNameValue(a,b)
 if not a or not b or #a~=#b then return false end
 for i=1,#a do if type(a[i])=="number" and type(b[i])=="number" then
  if math.abs(a[i]-b[i])>.00001 then return false end
 elseif a[i]~=b[i] then return false end end
 return true
end
local function nameCustody(r)
 local appearance=r and r.friendlyName;if not appearance then return false end
 local object,state=S:FieldAccess(r.uf,"name")
 if state=="ABSENT" then return false elseif state~="KNOWN" then return nil end
 if object~=appearance.object then return false end
 if not S:Frame(object,false) then return nil end
 local parent,known=value(object,"GetParent")
 if known~="KNOWN" then return nil end
 return parent==r.uf
end
function N:RefreshFriendlyName(v)
 -- Retained cleanup callers may encounter a lease acquired by an older
 -- presentation path. Retire only its written font/color/title properties;
 -- never acquire, recolor, resize or reconstruct a friendly name here.
 local r=v and v.lease
 if not r or not r.nativeBodies then return true end
 local okay=self:RestoreFriendlyName(v,r)
 if v.lease==r then v.friendlyNameStatus=okay and "BLIZZARD_NATIVE" or "NATIVE_LABEL_RESTORE_PENDING" end
 return okay
end
function N:RestoreFriendlyName(v,r)
 local a=r.friendlyName;if not a then return true end
 local custody=nameCustody(r)
 if custody==nil then return false end
 if not custody then a.fontRestored=true;a.colorRestored=true;a.textRestored=true;return true end
 local function current() return v.lease==r and self.byObject[a.object]==v and nameCustody(r)==true end
 if not current() or not legal(a.object) then return false end
 local function write(method,...)
  if not current() or not legal(a.object) then return false end
  local fn=field(a.object,method);if type(fn)~="function" then return false end
  local okay,result=pcall(fn,a.object,...)
  return okay and result~=false and current()
 end
 self.nameWriting=true
 local complete=true
 for _,entry in ipairs({{"font","lastFont","fontRestored",nameFont,"SetFont"},{"color","lastColor","colorRestored",nameColor,"SetTextColor"}}) do
  local original,last,restored,getter,setter=entry[1],entry[2],entry[3],entry[4],entry[5]
  if not a[restored] then
   local actual=getter(a.object)
   if not actual then complete=false
   elseif not a[last] or not sameNameValue(actual,a[last]) then a[restored]=true
   elseif write(setter,unpack(a[original])) and sameNameValue(getter(a.object),a[original]) then a[restored]=true
   else complete=false end
  end
  if not current() then self.nameWriting=nil;return false end
 end
 if not a.textRestored then
  if not a.lastText or not a.text then a.textRestored=true
  else
   local text,state=value(a.object,"GetText","string")
   if state~="KNOWN" then complete=false
   elseif text~=a.lastText then a.textRestored=true
   elseif write("SetText",a.text) and value(a.object,"GetText","string")==a.text then a.textRestored=true
   else complete=false end
  end
 end
 self.nameWriting=nil
 return complete and current()
end
function N:Current(v)
 if not self.active or v.retiring or not v.lease or self.byUnit[v.unit]~=v then return false end
 local r=v.lease
 if not S:Frame(r.plate,false) or not S:Frame(r.uf,false) or field(r.plate,"UnitFrame")~=r.uf then return false end
 -- The engine base and its pooled controller have separate lifetimes. A
 -- recycled controller is no longer ours even when the base handle is reused.
 local unit=nativeUnit(r.plate)
 if not (S:Text(unit) and unit==v.unit and plateFor(v.unit)==r.plate and value(r.uf,"GetParent")==r.plate) then return false end
 if r.nativeBodies then
  if r.friendlyName and nameCustody(r)~=true then return false end
  if r.ambientName and (field(r.uf,"name")~=r.ambientName or value(r.ambientName,"GetParent")~=r.uf) then return false end
  -- Those source-owned branches are fixed for a controller's lifetime. A
  -- replacement or external reparent retires this exact mask and lets the
  -- normal bounded native-reacquisition path validate the successor.
  for _,a in ipairs(r.alpha) do
   if a.bodyKey and (field(r.uf,a.bodyKey)~=a.object or value(a.object,"GetParent")~=a.parent) then return false end
  end
 end
 return true
end
function N:Watch(o)
 if self.monitors[o] then return true end
 if type(hooksecurefunc)~="function" then return false end
 local good=true;self.monitors[o]=true
 for _,key in ipairs({"SetAlpha","Show","SetParent"}) do
  if type(field(o,key))=="function" then
   local ok=pcall(hooksecurefunc,o,key,function(object,to)
    local v=N.byObject[object]
    if not v or N.writing then return end
    -- A retained restoration receipt still needs newer native alpha intent,
    -- including an explicit zero while cleanup is deferred. This observation
    -- never reapplies a mask to a retired/recycled object.
    if key=="SetAlpha" and v.lease and v.lease.nativeBodies then
     local alpha=value(object,"GetAlpha","number")
     if alpha~=nil then
      for _,a in ipairs(v.lease.alpha) do
       if a.object==object and (a.bodyKey or a.friendlyController) then a.original=alpha;break end
      end
     end
    end
    if v.lease and v.lease.ambientName and object==v.lease.uf and key~="SetParent" then
     -- Native distance fades own the controller alpha. No correction is due.
     v.lease.labelChanged=true;return
    end
    if not N:Current(v) then v.dirty=true;return end
    if key=="SetParent" then
     local r=v.lease
     if object==r.uf and to~=r.plate then r.conflict="EXTERNAL_CONTROLLER_PARENT_CHANGE" end
     for _,p in ipairs(r.parents) do
      if p.object==object and S:Readable(to) and to~=p.destination and to~=p.parent then
       -- A pooled dependency already replaced in this controller has left
       -- this lease. Its successor parent is native custody, not a competing
       -- owner of the current card.
       if not p.key or field(r.uf,p.key)==object then r.conflict="EXTERNAL_PARENT_CHANGE" end
       break
      end
     end
    end
    -- Keep observing custody, but do not reapply styling while the native
    -- editor is open or unreadable. A later CLOSED pass repairs this exact
    -- lease; the observation itself is not authority to release it.
    if R:NativeEditState()~="CLOSED" then v.dirty=true;return end
    -- Keep the native controller visible and in its native ancestry. A public
    -- native alpha rewrite needs a small immediate correction; otherwise its
    -- stock artwork flashes until the quarter-second maintenance pass.
    if key~="SetParent" and legal(object) then
     for _,a in ipairs(v.lease.alpha) do
      if a.object==object then
       local alpha=value(object,"GetAlpha","number")
       -- Ambient friendly names keep the complete native alpha hierarchy.
       -- Their controller is observed for recycling, never held at an old
       -- opacity. While its body is masked, retain newer native alpha intent
       -- for exact handback rather than restoring the acquisition snapshot.
       if a.passive then return end
       local desired=a.desired or 0
       if alpha~=nil and alpha~=desired then
        N.writing=true;a.written=call(object,"SetAlpha",desired);N.writing=nil
        if a.written and value(object,"GetAlpha","number")==desired then return end
       elseif alpha==desired then return end
       break
      end
     end
    end
    v.dirty=true
   end)
   good=ok and good
  end
 end
 if not good then self.monitors[o]=nil end
 return good
end
function N:Observe(plate,unit)
 if not S:Frame(plate,false) then return false end
 if unitToken(unit) then
  local count=0;for _ in pairs(self.observed) do count=count+1 end
  if self.observed[unit] or count<80 then self.observed[unit]=plate end
 end
 if type(hooksecurefunc)~="function" then return false end
 local watched=self.nativeMonitors[plate]
 if not watched then watched={};self.nativeMonitors[plate]=watched end
 -- Source-pinned NamePlateBaseMixin acquires a pooled UnitFrame, assigns it,
 -- and clears/releases it before addon removal events can run. Observe those
 -- exact public lifecycle methods; do not replace their scripts or factories.
 for _,key in ipairs({"AcquireUnitFrame","SetUnit","ClearUnit","ReleaseUnitFrame"}) do
  if not watched[key] and type(field(plate,key))=="function" then
   local ok=pcall(hooksecurefunc,plate,key,function(base)
    local prior=N.byPlate[base]
    local uf=field(base,"UnitFrame")
    local pooled=uf and N.byObject[uf]
    if pooled and pooled~=prior and not N:Current(pooled) then N:Release(pooled) end
    if prior and (key=="ClearUnit" or key=="ReleaseUnitFrame" or not N:Current(prior)) then
     local oldUnit=prior.unit
     if unitToken(oldUnit) then
      N.queue[oldUnit]=nil;N.observed[oldUnit]=nil
      N:ClearAdmission(oldUnit)
      if N.fallbacks then N.fallbacks[oldUnit]=nil end
      if N.fallbackProbes then N.fallbackProbes[oldUnit]=nil end
     end
     N:Release(prior)
    end
    -- Acquire finishes before SetUnit applies Blizzard's native hit layout.
    -- Observe that public write while the engine still owns all input.
    if key=="AcquireUnitFrame" and uf and selected() then N:WatchHitPoints(base,uf) end
    if key=="ClearUnit" or key=="ReleaseUnitFrame" then
     local hit=N.hitMonitors and N.hitMonitors[base]
     if hit then hit.nativeReceipt=nil end
    end
    if key~="SetUnit" or not N.active or not selected() then
     if N.active then N:Outcome() end
     return
    end
    local assigned=nativeUnit(base)
    if not unitToken(assigned) then return end
    N:Observe(base,assigned)
    N:RearmAdmission(assigned,base,"NATIVE_SET_UNIT")
    if N.applyingPolicies then N:Queue(assigned,base,"NATIVE_PLATE_PENDING");return end
    local good,why=N:Assign(assigned,base)
    if not good then N:Queue(assigned,base,why) end
    N:Outcome()
   end)
   if ok then watched[key]=true end
  end
 end
 return watched.SetUnit==true and watched.AcquireUnitFrame==true and watched.ReleaseUnitFrame==true
end
function N:ObserveNativeCreation(plate)
 -- Early lifecycle observation is independent of renderer allocation. Core
 -- subscribes after profile/source qualification, before provider Configure;
 -- a plate emitted in that interval must not lose its first native hit layout.
 if not M.state.initialized or M.state.safe or self.active or not selected() then return false end
 self:ObserveNativeDriver()
 return self:Observe(plate)
end
function N:ObserveNativeDriver()
 -- NAME_PLATE_CREATED may reach our event frame before the native driver has
 -- mixed in AcquireUnitFrame/SetUnit. Observing that bare base cannot install
 -- those lifecycle hooks. The completed source-owned initialization boundary
 -- catches this ordering before the first hit layout and unit assignment.
 local driver=_G.NamePlateDriverFrame
 if not S:Frame(driver,false) or type(hooksecurefunc)~="function" then return false end
 local method=field(driver,"OnNamePlateCreatedInternal")
 local observed=self.driverObserver
 if observed and observed.driver==driver then return method==observed.method end
 local native,state=S:FieldAccess(NamePlateDriverMixin,"OnNamePlateCreatedInternal")
 if state~="KNOWN" or type(native)~="function" or method~=native then return false end
 local receipt={driver=driver}
 local okay=pcall(hooksecurefunc,driver,"OnNamePlateCreatedInternal",function(owner,base)
  if owner~=driver or _G.NamePlateDriverFrame~=driver or self.driverObserver~=receipt
   or field(driver,"OnNamePlateCreatedInternal")~=receipt.method
   or not selected() or M.state.safe then return end
  if self.active or M.state.initialized then self:Observe(base) end
 end)
 if not okay then return false end
 receipt.method=field(driver,"OnNamePlateCreatedInternal");self.driverObserver=receipt
 return true
end
-- Selection is public identity evidence only. An unreadable comparison does
-- not turn an otherwise excluded category into an ordinary hostile unit.
function N:Selection(unit)
 local target,ts=S:Public(UnitIsUnit,"boolean",unit,"target")
 local focus,fs=S:Public(UnitIsUnit,"boolean",unit,"focus")
 -- The exact public native base is also identity evidence. This permits a
 -- selected pet whose comparison API is temporarily unavailable, without
 -- inventing a unit token or admitting an unknown ambient creature.
 local plate
 if ts~="KNOWN" or fs~="KNOWN" then plate=plateFor(unit) end
 if S:Frame(plate,false) and nativeUnit(plate)==unit then
  if ts~="KNOWN" then local p,ps=selectionPlate("target");if ps=="KNOWN" or ps=="ABSENT" then target=ps=="KNOWN" and p==plate;ts="KNOWN" end end
  if fs~="KNOWN" then local p,ps=selectionPlate("focus");if ps=="KNOWN" or ps=="ABSENT" then focus=ps=="KNOWN" and p==plate;fs="KNOWN" end end
 end
 return ts=="KNOWN" and target==true,fs=="KNOWN" and focus==true
end
function N:SelectionCoverage()
 self.selectionStatus=self.selectionStatus or {}
 self.selectionKinds=self.selectionKinds or {}
 local missing
 for _,token in ipairs({"target","focus"}) do
  local exists,state=S:Public(UnitExists,"boolean",token)
  local status
  if state~="KNOWN" then status="SELECTION_STATE_UNAVAILABLE";self.selectionKinds[token]="UNKNOWN"
  elseif not exists then status="NOT_SELECTED";self.selectionKinds[token]="NONE"
  else
   local owner
   for _,v in pairs(self.byUnit) do
    if not v.filterOnly and v.admitted~=false and self:Current(v) then
     local target,focus=self:Selection(v.unit)
     if token=="target" and target or token=="focus" and focus then owner=v;break end
    end
   end
   local nativeNeutral,nativeFriendly=false,false
   if owner then
    nativeFriendly=owner.friendlyTarget==true
    nativeNeutral=nativeFriendly and owner.category=="NEUTRAL"
   else
    local outgoing,os=S:Public(UnitCanAttack,"boolean","player",token)
    local incoming,is=S:Public(UnitCanAttack,"boolean",token,"player")
    local friend,fs=S:Public(UnitIsFriend,"boolean","player",token)
    local reaction,rs=S:Public(UnitReaction,"number",token,"player")
    nativeNeutral=os=="KNOWN" and outgoing==false and is=="KNOWN" and incoming==false and rs=="KNOWN" and reaction==4
    nativeFriendly=outgoing~=true and incoming~=true and fs=="KNOWN" and friend==true
   end
   self.selectionKinds[token]=nativeNeutral and "NONATTACKABLE_NEUTRAL" or nativeFriendly and "FRIENDLY" or "HOSTILE_OR_UNKNOWN"
   if owner then status="CUSTOM_SELECTED_PLATE_READY"
   elseif (token=="focus" or config().selectedFriendlyPlate==false) and (nativeFriendly or nativeNeutral) then
    status=nativeNeutral and "NONATTACKABLE_BLIZZARD_NATIVE_NAMES" or "FRIENDLY_BLIZZARD_NATIVE_NAMES"
   else
    local plate,ps=selectionPlate(token)
    if ps=="ABSENT" then status="SELECTED_NATIVE_PLATE_UNAVAILABLE"
    elseif ps~="KNOWN" then status="SELECTED_NATIVE_PLATE_UNREADABLE"
    else
     local unit=nativeUnit(plate)
     local _,stage,policy=self:InputBlocker(plate)
     status=policy=="NATIVE_POLICY" and (stage=="NATIVE_NAMES_ONLY" and "SELECTED_NATIVE_NAMES_ONLY_POLICY" or "SELECTED_NATIVE_NO_HIT_POLICY")
      or unitToken(unit) and plateFor(unit)==plate and "SELECTED_NATIVE_PLATE_PENDING" or "SELECTED_NATIVE_IDENTITY_PENDING"
    end
   end
   if status~="CUSTOM_SELECTED_PLATE_READY" and status~="FRIENDLY_BLIZZARD_NATIVE_NAMES" and status~="NONATTACKABLE_BLIZZARD_NATIVE_NAMES" then missing=missing or status end
  end
  self.selectionStatus[token]=status
 end
 return missing
end
local function friendlyFamily(category)
 if category=="FRIENDLY_PLAYER" then return "friendlyVisibility" end
 if category=="FRIENDLY_NPC" then return "friendlyNPCVisibility" end
 if category=="LESSER" then return "friendlyPetVisibility" end
end
function N:Classify(unit)
 local cfg=config();local target,focus=self:Selection(unit)
 local minion,ms=S:Public(UnitIsMinion,"boolean",unit)
 local pet,ps=S:Public(UnitIsOtherPlayersPet,"boolean",unit)
 local classification,cs=S:Public(UnitClassification,"string",unit)
 local player,us=S:Public(UnitIsPlayer,"boolean",unit)
 local enemy,es=S:Public(UnitCanAttack,"boolean","player",unit)
 local incoming,ins=S:Public(UnitCanAttack,"boolean",unit,"player")
 local friend,fs=S:Public(UnitIsFriend,"boolean","player",unit)
 local reaction,rs=S:Public(UnitReaction,"number",unit,"player")
 local attackable=es=="KNOWN" and enemy==true or ins=="KNOWN" and incoming==true
 local friendly=not attackable and fs=="KNOWN" and friend==true
 local neutral=not friendly and rs=="KNOWN" and reaction==4
 -- Yellow reaction alone does not prove an attackable neutral. A civilian
 -- can be neither a friend nor an enemy. Preserve its native name/controller
 -- when both attack directions publicly say false; unknown reads are not
 -- silently interpreted as nonattackable.
 local passiveNeutral=neutral and es=="KNOWN" and enemy==false and ins=="KNOWN" and incoming==false
 local hostile=attackable or not friendly and rs=="KNOWN" and reaction<=3
 local critter=false
 local enum=S:Field(Enum,"CreatureType");local critterID=S:Field(enum,"Critter")
 if S:Number(critterID) and type(UnitCreatureType)=="function" then
  local ok,_,id=pcall(UnitCreatureType,unit);critter=ok and S:Number(id) and id==critterID
 end
 local lesser=ms=="KNOWN" and minion or ps=="KNOWN" and pet or cs=="KNOWN" and classification=="minus" or critter
 local category,enabled
 if lesser then category="LESSER";enabled=cfg.customPets~=false
 elseif friendly then category=us=="KNOWN" and player and "FRIENDLY_PLAYER" or "FRIENDLY_NPC";enabled=false
 elseif neutral then category="NEUTRAL";enabled=cfg.customNeutral~=false
 elseif hostile then category=us=="KNOWN" and player and "ENEMY_PLAYER" or "ENEMY";enabled=true
 else category="UNKNOWN" end
 -- Public hostility/neutrality is sufficient admission evidence even when
 -- optional pet/player classification is unavailable. A missing classification
 -- must not remove debuffs from a still-owned hostile plate in combat.
 if category=="UNKNOWN" or lesser and not friendly and not hostile and not neutral then
  self.classificationProbe="player="..us..",minion="..ms..",friend="..fs..",reaction="..rs
  if target then return "SELECTED_UNIT","SELECTED_PUBLIC_NATIVE_IDENTITY",true,target,focus end
  return "UNKNOWN","CLASSIFICATION_UNAVAILABLE_KEEP_NATIVE",false,target,focus
 end
 -- Only the current target receives a friendly card. Focus/mouseover and
 -- every unselected friend keep the untouched native world-name policy.
 if friendly or passiveNeutral then
  if target and cfg.selectedFriendlyPlate~=false then return category,"FRIENDLY_SELECTED",true,target,focus end
  -- While the engine is supplying a missing friendly target anchor, other
  -- full plates of that family use the existing plate-only visual filter.
  -- Ordinary world names have no Lua owner here. Dedicated game widgets
  -- keep their native controller throughout.
  if friendly and not target and self.targetFamily and friendlyFamily(category)==self.targetFamily
   and S:Public(UnitNameplateShowsWidgetsOnly,"boolean",unit)~=true
   and field(field(plateFor(unit),"UnitFrame"),"widgetsOnlyMode")~=true then
   return category,"UNSELECTED_FRIENDLY_PLATE",false,target,focus
  end
  return category,passiveNeutral and "NONATTACKABLE_NATIVE" or "FRIENDLY_NATIVE",false,target,focus
 end
 local managed=M.PresentationGroups and M.PresentationGroups:Enabled()
 local admitted=target or (hostile or neutral) and (enabled or managed)
 return category,admitted and "ADMITTED" or "CATEGORY_FILTERED",admitted,target,focus
end
-- Ask for a full native plate only if the target needs an anchor. An
-- existing, usable native target needs no change to any visibility switch.
function N:WantedTargetFamily()
 if config().selectedFriendlyPlate==false or S:Public(UnitExists,"boolean","target")~=true then return end
 local category,classification=self:Classify("target")
 local family=friendlyFamily(category)
 if not family or classification~="FRIENDLY_SELECTED" then return end
 if self.targetFamily==family then return family end
 local plate,status=selectionPlate("target")
 if status=="ABSENT" then return family end
 if status=="KNOWN" then
  local uf=field(plate,"UnitFrame")
  if not uf or field(uf,"widgetsOnlyMode")==true or value(uf,"IsShowOnlyName","boolean")==true then return family end
 end
end
function N:ReadWorldNameRule()
 local rule=S:Field(S:Field(Enum,"GameRule"),"MaxUnitNameDistance")
 self.nativeWorldNameRange=nil
 self.worldNameDistanceStatus="RULE_UNAVAILABLE"
 if not S:Number(rule) then return end
 local active,access=S:Public(C_GameRules and C_GameRules.IsGameRuleActive,"boolean",rule)
 if access~="KNOWN" then return end
 if not active then self.worldNameDistanceStatus="RULE_INACTIVE";return end
 local distance=S:Public(C_GameRules and C_GameRules.GetGameRuleAsFloat,"number",rule,0)
 if not S:Number(distance) or distance<=0 then self.worldNameDistanceStatus="RULE_VALUE_UNAVAILABLE";return end
 self.nativeWorldNameRange=distance
 self.worldNameDistanceStatus=distance==50 and "NATIVE_50_YARDS" or distance<50 and "NATIVE_SHORTER_THAN_50" or "NATIVE_LONGER_THAN_50"
end
local policies={
 {"enemyVisibility","nameplateShowEnemies","choice"},{"friendlyVisibility",{"nameplateShowFriendlyPlayers","nameplateShowFriends"},"choice"},
 {"friendlyNameMode","nameplateShowOnlyNameForFriendlyPlayerUnits","choice"},
 {"friendlyNPCVisibility",{"nameplateShowFriendlyNpcs","nameplateShowFriendlyNPCs"},"choice"},
 {"enemyPetVisibility",{"nameplateShowEnemyMinions","nameplateShowEnemyPets"},"choice"},{"friendlyPetVisibility",{"nameplateShowFriendlyPlayerMinions","nameplateShowFriendlyPets"},"choice"},
 {"globalScale","nameplateGlobalScale","percent"},{"minimumScale","nameplateMinScale","percent"},{"maximumScale","nameplateMaxScale","percent"},
 {"selectedScale","nameplateSelectedScale","percent"},{"maximumDistance","nameplateMaxDistance","number"},
 {"stacking","nameplateMotion","stack"},{"occludedOpacity","nameplateOccludedAlphaMult","alpha"}}
local friendlyPolicies={"friendlyVisibility","friendlyNameMode","friendlyNPCVisibility","friendlyPetVisibility"}
local function friendlyPolicy(setting)
 return setting=="friendlyVisibility" or setting=="friendlyNameMode" or setting=="friendlyNPCVisibility" or setting=="friendlyPetVisibility"
end
-- Presentation satisfaction and write custody are separate. A native switch
-- can return to our requested value without returning ownership to Mirage.
-- Seal every public observation before publishing it or marking an existing
-- journal receipt; native getters may synchronously replace configuration.
local function policyObservation(self)
 local profile,store,state=M.profile,R.store,M.state
 local modules=profile and profile.modules
 local cfg=modules and modules.Nameplates
 if not cfg or not store or type(store.cvars)~="table" then return end
 local journal,status,keys=store.cvars,self.policyStatus,self.policyKeys
 if not status or not keys then return end
 local revision,active,applying=self.configurationRevision,self.active,self.applyingPolicies
 local observationRevision=self.friendlyPolicyObservationRevision
 local npcChoice,selectedFriendly,family=cfg.nativeNPCNames,cfg.selectedFriendlyPlate,self.targetFamily
 local get=C_CVar and C_CVar.GetCVar or GetCVar
 local receipts,states,aliases={},{},{}
 for _,key in ipairs(friendlyPolicies) do states[#states+1]={key,status[key]};aliases[#aliases+1]={key,keys[key]} end
 for _,key in ipairs({"UnitNameFriendlyPlayerName","UnitNamePlayerGuild","UnitNameNPC","UnitNameFriendlyMinionName"}) do states[#states+1]={key,status[key]} end
 local function current()
  if M.profile~=profile or R.store~=store or M.state~=state or profile.modules~=modules or modules.Nameplates~=cfg or cfg.nativeNPCNames~=npcChoice or cfg.selectedFriendlyPlate~=selectedFriendly
   or store.cvars~=journal or self.policyStatus~=status or self.policyKeys~=keys or self.configurationRevision~=revision
   or self.friendlyPolicyObservationRevision~=observationRevision or self.targetFamily~=family
   or self.active~=active or self.applyingPolicies~=applying or M.state.safe
   or (C_CVar and C_CVar.GetCVar or GetCVar)~=get then return false end
  for _,entry in ipairs(states) do if status[entry[1]]~=entry[2] then return false end end
  for _,entry in ipairs(aliases) do if keys[entry[1]]~=entry[2] then return false end end
  for _,r in ipairs(receipts) do
   local row=journal[r.key]
   if row~=r.row or row and (row.owner~=r.owner or row.original~=r.original or row.written~=r.written
    or row.attempt~=r.attempt or row.conflict~=r.conflict) then return false end
  end
  return true
 end
 local function read(key)
  if not current() then return nil,"SUPERSEDED" end
  local row=journal[key]
  if row~=nil and type(row)~="table" then return nil,"SUPERSEDED" end
  receipts[#receipts+1]={key=key,row=row,owner=row and row.owner,original=row and row.original,written=row and row.written,
   attempt=row and row.attempt,conflict=row and row.conflict}
  local value,state=S:Public(get,"string",key)
  if not current() then return nil,"SUPERSEDED" end
  return value,state,row
 end
 return {current=current,read=read,status=status,keys=keys,npcChoice=npcChoice,family=family,selectedFriendly=selectedFriendly~=false}
end
function N:ObserveFriendlyPolicy()
 self.friendlyPolicyObservationRevision=(self.friendlyPolicyObservationRevision or 0)+1
 local observation=policyObservation(self);if not observation then return false end
 local now=S:Now();if not observation.current() then return false end
 local observed,externalStatus,blocked={},{},{}
 local apply,observe,nativeMatch=false,false,false
 local function inspect(setting,key,wanted)
  if not key then observed[setting]="CVAR_UNAVAILABLE";apply=true;return true end
  local value,state,row=observation.read(key)
  if state=="SUPERSEDED" then return false end
  local external=observation.status[setting]=="CVAR_EXTERNAL_CHANGE" or row and (row.owner~="nameplates" or row.conflict)
  if external then externalStatus[setting]=true end
  if state~="KNOWN" or value~="0" and value~="1" then
   observed[setting]="READBACK_UNAVAILABLE";observe=true
  elseif value==wanted then
   local owned=not external and row and row.owner=="nameplates" and row.written==wanted
   observed[setting]=external and "NATIVE_MATCH_EXTERNAL_PRESERVED" or owned and "APPLIED" or "NATIVE_MATCH"
   nativeMatch=nativeMatch or not owned
  elseif external then
   observed[setting]="EXTERNAL_CHOICE";blocked[#blocked+1]=setting
  else observed[setting]=observation.status[setting] or "NOT_OBSERVED";apply=true end
  return true
 end
 for _,setting in ipairs(friendlyPolicies) do
  if not inspect(setting,observation.keys[setting],observation.family==setting and "1" or "0") then return false end
 end
 for _,key in ipairs({"UnitNameFriendlyPlayerName","UnitNamePlayerGuild","UnitNameNPC","UnitNameFriendlyMinionName"}) do
  if key=="UnitNamePlayerGuild" and observation.status[key]=="CVAR_UNAVAILABLE" then
   observed[key]="NATIVE_GUILD_PREFERENCE_UNAVAILABLE"
  elseif key=="UnitNameFriendlyPlayerName" or key=="UnitNamePlayerGuild" or key=="UnitNameNPC" and observation.npcChoice==1 then
   if not inspect(key,key,"1") then return false end
  elseif observation.status[key]~="NATIVE_NAME_PREFERENCE_PRESERVED" then apply=true end
 end
 if not observation.current() then return false end
 for key in pairs(externalStatus) do self.policyStatus[key]="CVAR_EXTERNAL_CHANGE" end
 self.friendlyPolicyObserved=observed
 self.friendlyPolicyBlocked=#blocked>0 and table.concat(blocked,",") or nil
 self.friendlyPolicyPending=apply or observe or #blocked>0 or nil
 self.friendlyPolicyRetry=apply and "APPLY" or observe and "OBSERVE" or nil
 self.friendlyPolicyState=self.friendlyPolicyPending and (#blocked>0 and (self.friendlyPolicyRetry and "EXTERNAL_CHOICE_AND_PENDING" or "EXTERNAL_CHOICE") or "PENDING")
  or nativeMatch and "CURRENT_NATIVE_MATCH" or "APPLIED"
 if self.friendlyPolicyRetry then
  self.friendlyPolicyFailures=math.min(4,(self.friendlyPolicyFailures or 0)+1)
  self.friendlyPolicyRetryAt=now+math.min(8,2^(self.friendlyPolicyFailures-1))
 else self.friendlyPolicyRetryAt=nil;self.friendlyPolicyFailures=nil end
 return true
end
function N:ObserveFriendlyCVarEvent(key)
 self.friendlyPolicyObservationRevision=(self.friendlyPolicyObservationRevision or 0)+1
 local observation=policyObservation(self);if not observation then return false end
 local value,state,row=observation.read(key)
 if state=="SUPERSEDED" then return false end
 local now=S:Now();if not observation.current() then return false end
 -- Record an observed external change now, even in combat. Deferring this
 -- observation until an out-of-combat write loses a native 0->1->0 change
 -- and could later restore a stale original over the user's final choice.
 if state=="KNOWN" and row and row.owner=="nameplates" and (row.written or row.attempt) then
  if row.writeInProgress then
   if value==row.attempt then row.observedAttempt=true
   elseif row.observedAttempt then row.conflict=true;row.status="EXTERNAL_CHANGE" end
   -- An unchanged-only callback can be a silently refused native write.
   -- Without first observing our attempt, it is readback debt, not proof
   -- that another owner deliberately chose the unchanged original value.
  elseif value~=row.written and value~=row.attempt then row.conflict=true;row.status="EXTERNAL_CHANGE" end
 end
 self.friendlyPolicyPending=true;self.friendlyPolicyBlocked=nil;self.friendlyPolicyState="PENDING"
 self.friendlyPolicyRetry="OBSERVE";self.friendlyPolicyRetryAt=now+.25;self.friendlyPolicyFailures=nil
 return true
end
function N:NativeNPCNamePreference()
 -- The native settings dropdown checks UnitNameNPC first. Keep the native
 -- predicate order so INTERACTIVE is not reported as an addon display fault.
 local get=C_CVar and C_CVar.GetCVar or GetCVar
 local all,state=S:Public(get,"string","UnitNameNPC")
 local mode="UNAVAILABLE"
 if state=="KNOWN" and all=="1" then mode="ALL"
 elseif state=="KNOWN" and all=="0" then
  local special,ss=S:Public(get,"string","UnitNameFriendlySpecialNPCName")
  local hostile,hs=S:Public(get,"string","UnitNameHostleNPC")
  local interactive,is=S:Public(get,"string","UnitNameInteractiveNPC")
  if ss=="KNOWN" and hs=="KNOWN" and is=="KNOWN" and (special=="0" or special=="1")
   and (hostile=="0" or hostile=="1") and (interactive=="0" or interactive=="1") then
   mode=special=="1" and (hostile=="1" and (interactive=="1" and "INTERACTIVE" or "HOSTILE_AND_TRACKED") or "TRACKED") or "NONE"
  end
 end
 self.nativeNpcNameMode=mode
 return mode
end
function N:PrepareFriendlyPolicyObservers()
 local seen,count={},0
 local function visit(plate)
  if count>=80 or not S:Frame(plate,false) or seen[plate] then return end
  local unit=nativeUnit(plate);local uf=field(plate,"UnitFrame")
  if not unitToken(unit) or plateFor(unit)~=plate or not S:Frame(uf,false) then return end
  seen[plate]=true;count=count+1
  if S:Public(UnitIsPlayer,"boolean",unit)==true and S:Public(UnitIsFriend,"boolean","player",unit)==true
   and S:Public(UnitIsUnit,"boolean","target",unit)~=true then return end
  self:Observe(plate,unit);self:WatchHitPoints(plate,uf)
 end
 for _,token in ipairs({"target","focus"}) do local plate,known=selectionPlate(token);if known=="KNOWN" then visit(plate) end end
 local list,known=S:Public(C_NamePlate and C_NamePlate.GetNamePlates,"table")
 if known=="KNOWN" and (type(canaccesstable)~="function" or S:Public(canaccesstable,"boolean",list)==true) then
  local key
  for i=1,80 do
   local okay,nextKey,plate=pcall(next,list,key)
   if not okay or not S:Readable(nextKey) or not S:Readable(plate) or nextKey==nil then break end
   key=nextKey;visit(plate)
  end
 end
 for unit,plate in pairs(self.observed) do if plateFor(unit)==plate then visit(plate) end end
 self.friendlyModeObservedBases=count
end
function N:ApplyPolicies(friendlyOnly,selectionOnly)
 if not friendlyOnly then self.policyStatus={};self.policyKeys={}
 else self.policyStatus=self.policyStatus or {};self.policyKeys=self.policyKeys or {} end
 local cfg=config()
 local store=R.store
 if not store then
  self.cvarStatus="STORAGE_UNAVAILABLE";self.friendlyPolicyPending=true;self.friendlyPolicyState="PENDING"
  self.friendlyPolicyRetry="APPLY";self.friendlyPolicyRetryAt=S:Now()+1;return
 end
 local previousFamily=self.targetFamily
 local wanted=self:WantedTargetFamily()
 if selectionOnly then
  if self.applyingPolicies then self.targetPolicyDeferred=true;return end
  if S:InCombat() then self.targetPolicyDeferred=true;return end
  if previousFamily==wanted and not self.targetPolicyDeferred then return end
 end
 self.targetPolicyDeferred=nil
 self.targetFamily=wanted
 self.applyingPolicies=true
 -- Keep input observers for selected/hostile plates already emitted at startup.
 if not friendlyOnly then self:PrepareFriendlyPolicyObservers() end
 store.nameplateIntents=type(store.nameplateIntents)=="table" and store.nameplateIntents or {}
 local friendlyEnabled=cfg.selectedFriendlyPlate~=false
 -- P40.5 requested both ambient player switches on. Retire that specific
 -- intent once, including a recorded conflict with the old policy. A new
 -- conflict after this transition belongs to the player.
 if store.nativeWorldNameRevision~=1 then
  if store.nameplateIntents.friendlyVisibility==2 and store.nameplateIntents.friendlyNameMode==2 then
   store.selectedFriendlyPrerequisitePending={friendlyVisibility=true,friendlyNPCVisibility=true,friendlyPetVisibility=true,friendlyNameMode=true}
  end
  store.nativeWorldNameRevision=1
 end
 if store.selectedFriendlyPrerequisiteIntent~=nil and store.selectedFriendlyPrerequisiteIntent~=friendlyEnabled then
  store.selectedFriendlyPrerequisitePending={friendlyVisibility=true,friendlyNameMode=true}
 end
 store.selectedFriendlyPrerequisiteIntent=friendlyEnabled
 local friendlyIntent=type(store.selectedFriendlyPrerequisitePending)=="table" and store.selectedFriendlyPrerequisitePending or {}
 for _,entry in ipairs(policies) do
  local setting,key,kind=entry[1],entry[2],entry[3]
  if (not friendlyOnly or friendlyPolicy(setting)) and (not selectionOnly or previousFamily==setting or wanted==setting) then
  local authored=cfg[setting]
  if friendlyPolicy(setting) then authored=self.targetFamily==setting and 2 or 1 end
  if authored==nil then authored=setting=="enemyVisibility" and 2 or kind=="alpha" and -1 or 0 end
  local previous=store.nameplateIntents[setting];local explicit=previous~=nil and previous~=authored
  local prerequisite=friendlyPolicy(setting)
  if prerequisite then explicit=friendlyIntent[setting]==true end
  local aliasReason
  if type(key)=="table" then
   local found
   for _,alias in ipairs(key) do local _,known=S:Public(C_CVar and C_CVar.GetCVar or GetCVar,"string",alias);if known=="KNOWN" then found=alias;break end end
   -- A newly documented alias must not acquire the old Mirage-written value
   -- as its native original. Retire prior alias custody before acquisition.
   for _,alias in ipairs(key) do
    local receipt=store.cvars and store.cvars[alias]
    if alias~=found and receipt and receipt.owner=="nameplates" then
     if receipt.conflict and not explicit then aliasReason="CVAR_EXTERNAL_CHANGE"
     else
      local restored,why=R:RestoreCVars("nameplates",alias)
      if not restored then aliasReason=why or "CVAR_RESTORE_PENDING"
      elseif receipt.conflict and not explicit then aliasReason="CVAR_EXTERNAL_CHANGE" end
     end
    end
   end
   key=found
  end
  self.policyKeys[setting]=key
  local keep=kind=="alpha" and authored<0 or kind~="alpha" and authored==0
  if aliasReason then self.policyStatus[setting]=aliasReason
  elseif key then
   store.nameplateIntents[setting]=authored
   local good,why
   if keep then good,why=R:RestoreCVars("nameplates",key)
   else
    local v=kind=="choice" and (authored==2 and 1 or 0) or kind=="stack" and (authored==2 and 1 or 0)
     or (kind=="percent" or kind=="alpha") and authored/100 or authored
    good,why=R:WriteCVar("nameplates",key,v,explicit)
   end
   self.policyStatus[setting]=good and (keep and "KEPT" or "APPLIED") or why or "UNAVAILABLE"
   -- Do not lose a real toggle to an early legal-write deferral; also do not
   -- let repeated retries erase a later external change after an actual try.
   if prerequisite and (good or why~="CVAR_DEFERRED" and why~="COMBAT_LOCKDOWN" and why~="NOT_QUALIFIED"
    and why~="CVAR_UNAVAILABLE" and why~="CVAR_NOT_WRITABLE") then friendlyIntent[setting]=nil end
  else self.policyStatus[setting]="CVAR_UNAVAILABLE" end
  end
 end
 if previousFamily and previousFamily~=wanted then
  -- The client can keep a base alive after disabling its family. Give back
  -- our temporary filter even when no native removal callback arrives.
  for _,v in ipairs(self.filteredPool) do
   if v.targetFamilyFilter==previousFamily and v.lease then
    local unit,plate=v.unit,v.lease.plate
    if self:Release(v) and plateFor(unit)==plate and nativeUnit(plate)==unit then
     self:Queue(unit,plate,"NATIVE_PLATE_PENDING")
    end
   end
  end
 end
 if selectionOnly then
  self.applyingPolicies=nil
  self:ObserveFriendlyPolicy()
  return
 end
 if not friendlyOnly then
  self.cvarStatus=self.policyStatus.enemyVisibility
  local all,why=R:WriteCVar("nameplates","nameplateShowAll",1)
  self.policyStatus.nameplateShowAll=all and "NATIVE_PLATES_AVAILABLE" or why or "UNAVAILABLE"
 end
 -- Request the two world-text preferences with reversible CVar receipts.
 -- Guild visibility is a global Blizzard preference. Later external edits win.
 for _,key in ipairs({"UnitNameFriendlyPlayerName","UnitNamePlayerGuild","UnitNameFriendlyMinionName"}) do
  local manage=key~="UnitNameFriendlyMinionName"
  local good,why
  if manage then good,why=R:WriteCVar("nameplates",key,1)
  else good,why=R:RestoreCVars("nameplates",key) end
  self.policyStatus[key]=good and (manage and "APPLIED" or "NATIVE_NAME_PREFERENCE_PRESERVED") or why or "UNAVAILABLE"
 end
 -- A target has a separate native distance policy. Some clients lock it.
 local key="nameplateCheckDistanceForTarget"
 local distanceOK,distanceReason
 if friendlyEnabled then distanceOK,distanceReason=R:WriteCVar("nameplates",key,0)
 else distanceOK,distanceReason=R:RestoreCVars("nameplates",key) end
 self.policyStatus[key]=distanceOK and (friendlyEnabled and "EXEMPT" or "KEPT") or distanceReason
 if not friendlyOnly then self:ReadWorldNameRule() end
 local npcIntent=cfg.nativeNPCNames==1 and 1 or 0
 local previous=store.nameplateIntents.nativeNPCNames
 local explicit=previous~=nil and previous~=npcIntent
 store.nameplateIntents.nativeNPCNames=npcIntent
 local good,why
 if npcIntent==1 then good,why=R:WriteCVar("nameplates","UnitNameNPC",1,explicit)
 else good,why=R:RestoreCVars("nameplates","UnitNameNPC") end
 self.policyStatus.UnitNameNPC=good and (npcIntent==1 and "ALL_NATIVE_NPC_NAMES" or "NATIVE_NAME_PREFERENCE_PRESERVED") or why or "UNAVAILABLE"
 self:ObserveFriendlyPolicy()
 self:NativeNPCNamePreference()
 self.applyingPolicies=nil
 for unit,plate in pairs(self.observed) do
  local uf=field(plate,"UnitFrame")
  local namesOnly,known=value(uf,"IsShowOnlyName","boolean")
  if S:Public(UnitIsUnit,"boolean","target",unit)==true and plateFor(unit)==plate and nativeUnit(plate)==unit and known=="KNOWN" and not namesOnly
   and S:Public(UnitIsPlayer,"boolean",unit)==true and S:Public(UnitIsFriend,"boolean","player",unit)==true then
   self:RearmAdmission(unit,plate,"FRIENDLY_NATIVE_FULL_MODE_COMPLETED")
  end
 end
 -- The CVar callbacks above can complete native mode/layout on existing
 -- bases. Their observers recorded the result while acquisition was held;
 -- now a bounded discovery pass may admit the completed native controllers.
 if friendlyOnly and self.active and selected() then self:Refresh() end
end

-- Range is relative to applicable known abilities observed on action slots,
-- not a guessed world distance. Resolve the native action spell (or callable
-- legacy GetMacroSpell), never macro text. Six unique references per
-- disposition bound each plate's work.
-- Rebuilding occurs outside lockdown; an action edit does not discard still
-- known, unchanged references while that rebuild is pending in combat.
local function spellID(id) return S:Number(id) and id>0 and id<=2147483647 and id%1==0 end
local function macroSpell(slot,macro)
 local resolved,state=S:Public(C_ActionBar and C_ActionBar.GetSpell,"number",slot)
 if state=="RESTRICTED" then return nil end
 return spellID(resolved) and resolved or S:Public(GetMacroSpell,"number",macro)
end
function N:PublishRange(references,status,hasMacros)
 local keys={}
 for _,kind in ipairs({"harmful","helpful"}) do
  local rows=references[kind]
  table.sort(rows,function(a,b) if a.maximum==b.maximum then return a.id<b.id end;return a.maximum>b.maximum end)
  while #rows>6 do table.remove(rows) end
  for _,row in ipairs(rows) do
   keys[#keys+1]=kind..":"..row.base..":"..row.id..":"..row.maximum..(row.macro and ":macro:"..row.slot..":"..row.macro or "")
  end
 end
 local signature=table.concat(keys,";")
 if signature~=self.rangeSignature then self.rangeRevision=(self.rangeRevision or 0)+1;self.rangeSignature=signature end
 self.rangeReferences=references;self.rangeCatalogStatus=status;self.rangeHasMacros=hasMacros==true;self.rangeDirty=nil
end
function N:PrepareRange()
 self.rangeDirty=true
 if S:InCombat() then return false end
 local references={harmful={},helpful={}}
 local api=C_Spell;local book=C_SpellBook
 local info=type(GetActionInfo)=="function" and GetActionInfo or C_ActionBar and C_ActionBar.GetActionInfo
 if type(info)~="function" or not api or not book then self:PublishRange(references,"UNAVAILABLE");return false end
 local seen={};local hasMacros=false
 for slot=1,180 do
  local ok,kind,id=pcall(info,slot)
  local macro
  if ok and S:Text(kind) and spellID(id) and kind=="macro" then
   macro=id;hasMacros=true;id=macroSpell(slot,macro);kind="spell"
  end
  if ok and S:Text(kind) and kind=="spell" and spellID(id) then
   local base=id
   id=S:Public(api.GetOverrideSpell,"number",base)
   if spellID(id) and not seen[id] then
   seen[id]=true
   local known=S:Public(book.IsSpellKnown,"boolean",id)
   local ranged=S:Public(api.SpellHasRange,"boolean",id)
   local passive=S:Public(api.IsSpellPassive,"boolean",id)
   local metadata=S:Public(api.GetSpellInfo,"table",id)
   local minimum,maximum=S:Field(metadata,"minRange"),S:Field(metadata,"maxRange")
   if known==true and ranged==true and passive==false and S:Number(minimum) and minimum==0 and S:Number(maximum) and maximum>0 and maximum<=200 then
    for _,entry in ipairs({{"harmful","IsSpellHarmful"},{"helpful","IsSpellHelpful"}}) do
     if S:Public(api[entry[2]],"boolean",id)==true then
      local rows=references[entry[1]]
      rows[#rows+1]={base=base,id=id,maximum=maximum,slot=slot,macro=macro}
     end
    end
   end
   end
  end
 end
 self:PublishRange(references,"PUBLIC_SLOTTED_ABILITIES",hasMacros);return true
end
function N:Range(unit)
 if not self.rangeReferences then return "UNKNOWN","CATALOG_PENDING" end
 local attack,access=S:Public(UnitCanAttack,"boolean","player",unit)
 if access~="KNOWN" then return "UNKNOWN","RELATION_UNAVAILABLE" end
 local disposition=attack and "harmful" or "helpful"
 local rows=self.rangeReferences[disposition]
 if not rows or #rows==0 then return "UNKNOWN","NO_RANGE_REFERENCE",disposition end
 local unknown,applicable,invalidReference=false,false,false
 local probe=C_Spell and C_Spell.IsSpellInRange
 for _,row in ipairs(rows) do
  local sameMacro=not row.macro or macroSpell(row.slot,row.macro)==row.base
  if not sameMacro then self.rangeDirty=true end
  local known=S:Public(C_SpellBook and C_SpellBook.IsSpellKnown,"boolean",row.id)
  local override=S:Public(C_Spell and C_Spell.GetOverrideSpell,"number",row.base)
  if not sameMacro or known~=true or override~=row.id then unknown=true;invalidReference=true
  else
   local ok,inside=false,nil
   if type(probe)=="function" then ok,inside=pcall(probe,row.id,unit) end
   if not ok or not S:Readable(inside) then unknown=true
   elseif inside==true then return "IN","SLOTTED_ABILITY_IN_RANGE",disposition
   elseif inside==false then applicable=true
   elseif inside~=nil then unknown=true end
   -- A readable nil explicitly means this spell cannot range-check this
   -- target. It is neither an out-of-range result nor an opaque boolean.
  end
 end
 if invalidReference then return "UNKNOWN","REFERENCE_CHANGED_OR_UNAVAILABLE",disposition end
 if unknown then return "UNKNOWN","RANGE_UNAVAILABLE",disposition end
 if not applicable then return "UNKNOWN","NO_APPLICABLE_RANGE_REFERENCE",disposition end
 return "OUT","SLOTTED_ABILITIES_OUT_OF_RANGE",disposition
end
function N:Presentation(v)
 local lease,generation,unit,profile,revision=v.lease,v.generation,v.unit,M.profile,self.rangeRevision
 local function current()
  return v.lease==lease and v.generation==generation and v.unit==unit and M.profile==profile
   and self.rangeRevision==revision and self:Current(v)
 end
 if not current() then return nil end
 local range,reason,disposition=self:Range(v.unit)
 if not current() then return nil end
 v.rangeStatus=range;v.rangeReason=reason
 local now=S:Public(GetTime,"number")
 if not current() then return nil end
 if not S:Number(now) or now<0 then now=nil end
 local evidence=v.rangeEvidence
 if evidence and (evidence.lease~=v.lease or evidence.unit~=v.unit or evidence.generation~=v.generation
  or evidence.revision~=self.rangeRevision or evidence.disposition~=disposition
  or reason=="REFERENCE_CHANGED_OR_UNAVAILABLE") then evidence=nil;v.rangeEvidence=nil end
 local visual=range
 if range=="IN" or range=="OUT" then
  if evidence and now and now>=evidence.at and now-evidence.at<=1.5 and evidence.state~=range then
   if evidence.pending~=range then evidence.pending=range;evidence.since=now end
   if now-evidence.since<.35 then visual=evidence.state end
  end
  if now then
   evidence=evidence or {lease=v.lease,unit=v.unit,generation=v.generation,revision=self.rangeRevision,disposition=disposition}
   if visual==range then evidence.state=range;evidence.at=now;evidence.pending=nil;evidence.since=nil end
   v.rangeEvidence=evidence
  else v.rangeEvidence=nil end
  v.rangeVisualReason=visual==range and "CURRENT_PUBLIC_RANGE" or "RANGE_TRANSITION_PENDING"
 elseif evidence and now and now>=evidence.at and now-evidence.at<=1.5 then
  evidence.pending=nil;evidence.since=nil
  visual=evidence.state;v.rangeVisualReason="RECENT_PUBLIC_RANGE_GRACE"
 else v.rangeEvidence=nil;v.rangeVisualReason="UNKNOWN_NORMAL_PRESENTATION" end
 v.rangeVisual=visual
 local scale=(config().cardScale or 100)/100
 if v.lease and v.lease.hit and v.lease.hit.mode=="PASSIVE_NATIVE_REGION" then
  local okay=self:FitPassiveHitVisual(v,v.lease,visual)
  if not okay then self:RetirePassiveGeometry(v);return nil end
  v.presentationDeferred=nil;self:Detail(v,"presentation",true)
  if v.rangeTag then v.rangeTag:SetText("") end
  return visual=="OUT" and .55 or 1
 end
 if visual=="OUT" then scale=scale*.82 end
 if v.selectedTarget or v.selectedFocus then scale=scale*1.08 end
 -- The owned card is an ordinary passive frame. The native hit rectangle
 -- references its corners, so a legal visual scale update also moves the
 -- engine input surface without another hit-point write. A blanket combat
 -- check froze both range and selection changes even on these legal targets.
 v.requestedPresentationScale=scale
 if v.presentationScale~=scale then
  if not current() then return nil end
  if not legal(v.frame) then v.presentationDeferred="OWNED_SCALE_TARGET_NOT_LEGAL";self:Detail(v,"presentation",false,v.presentationDeferred);return nil end
  local okay,result=pcall(v.frame.SetScale,v.frame,scale)
  if not current() then return nil end
  if not okay or not S:Readable(result) or result==false or not legal(v.frame) then v.presentationDeferred="OWNED_SCALE_SUBMISSION_UNCONFIRMED";self:Detail(v,"presentation",false,v.presentationDeferred);return nil end
  v.presentationScale=scale
 end
 v.presentationDeferred=nil;self:Detail(v,"presentation",true)
 if v.rangeTag then v.rangeTag:SetText("") end
 return visual=="OUT" and .55 or 1
end
-- Optional content is allowed to retry without transferring a healthy health
-- card back to Blizzard. The former all-or-nothing handback made one temporary
-- aura/clock failure replace the entire plate for the remainder of combat.
function N:Detail(v,key,okay,reason)
 v.detailIssues=v.detailIssues or {}
 v.detailIssues[key]=not okay and (reason or "NATIVE_DETAIL_UNAVAILABLE") or nil
 if not okay then v.detailRetryAt=math.min(v.detailRetryAt or math.huge,S:Now()+.5) end
 return okay
end
function N:PrepareDetails(v)
 if S:InCombat() or v.filterOnly or not config().cardAuras then return false end
 local rebuilt=false
 for _,key in ipairs({"harmful","helpful"}) do
  local rail=v[key]
  if rail and (rail.retired or (rail.failures or 0)>=3 or not M.ManagedAuraRails:Ready(rail)) then
   -- Two automatic replacement allocations per prebuilt slot, plus the
   -- shared native-container budget, prevent a persistent API failure from
   -- allocating indefinitely. Explicit Recover can reset this allowance.
   if (v.detailRebuilds or 0)>=2 then return false end
   if M.ManagedAuraRails:Clear(rail)~=true then return false end
   rail.retired=true;v[key]=nil;rebuilt=true
  end
 end
 if rebuilt then v.detailRebuilds=(v.detailRebuilds or 0)+1;v.auraSetupFailures=0 end
 return V:EnsureAuras(v,config())
end
function N:RetryDetails(v,now)
 if not self:Current(v) or v.filterOnly or now<(v.detailRetryAt or math.huge) then return end
 v.detailRetryAt=now+1
 if v.detailIssues and v.detailIssues.auras then
  if not S:InCombat() then self:PrepareDetails(v) end
  self:Auras(v)
 end
 if v.detailIssues and v.detailIssues.cast then self:RefreshCast(v) end
 if not next(v.detailIssues or {}) then v.detailRetryAt=nil end
end
-- The engine owns targeting and mouseover. Its hit-test anchors are a
-- separate property from the visible card: leaving them on the concealed
-- stock artwork makes the replacement's name/bars miss both input paths.
-- Lease only that documented property; ordinary mouse flags, scripts,
-- stacking dimensions and native selection behavior remain untouched.
local hitPointNames={TOPLEFT=true,TOP=true,TOPRIGHT=true,LEFT=true,CENTER=true,RIGHT=true,BOTTOMLEFT=true,BOTTOM=true,BOTTOMRIGHT=true}
local hitFields={"point","relativeTo","relativePoint","offsetX","offsetY"}
-- The native getter is declared as AnchorBinding[], but accessibility and
-- serialization must be observed on the running client. Only fixed stage tags
-- leave this adapter; no denied value, unit identity or event payload is logged.
local function hitReadback(phase,stage,index,key)
 local d=N.hitDiagnostics
 if not d then d={counts={},order={},reads=0,failures=0};N.hitDiagnostics=d end
 d.reads=d.reads+1
 local code=phase..":"..stage
 if not d.counts[code] then
  if #d.order<32 then d.order[#d.order+1]=code;d.counts[code]=0 else code="OTHER";d.counts.OTHER=d.counts.OTHER or 0 end
 end
 d.counts[code]=math.min(1000000000,(d.counts[code] or 0)+1)
 d.lastPhase=phase;d.lastStage=stage;d.lastIndex=index or 0;d.lastField=key or "NONE"
 d.availability=stage=="READBACK_READY" and "PUBLIC_READBACK_READY"
  or stage=="METHOD_UNAVAILABLE" and "METHOD_UNAVAILABLE"
  or stage:find("RESTRICTED",1,true) and "PUBLIC_ACCESS_DENIED"
  or stage=="IDENTITY_CHANGED" and "IDENTITY_CHANGED" or stage=="LIST_NOT_READY" and "NOT_READY"
  or stage=="GETTER_CALL_FAILED" and "CALL_FAILED" or "CONTRACT_UNAVAILABLE"
 if stage~="READBACK_READY" then
  d.failures=d.failures+1;d.lastFailureAt=S:Now()
  d.failurePhase=phase;d.failureStage=stage;d.failureIndex=index or 0;d.failureField=key or "NONE"
 end
 return nil,stage,index or 0,key or "NONE"
end
local function readHitPoints(plate,current,phase)
 phase=phase or "CHECK"
 local function fail(stage,index,key) return hitReadback(phase,stage,index,key) end
 if not current() then return fail("IDENTITY_CHANGED") end
 if not S:Frame(plate,false) then return fail("FRAME_UNAVAILABLE") end
 local methodOkay,method=pcall(function() return plate.GetHitTestPoints end)
 if not current() then return fail("IDENTITY_CHANGED") end
 if not methodOkay then return fail("METHOD_ACCESS_FAILED") end
 if not S:Readable(method) then return fail("METHOD_RESTRICTED") end
 if type(method)~="function" then return fail("METHOD_UNAVAILABLE") end
 local okay,points=pcall(method,plate)
 if not current() then return fail("IDENTITY_CHANGED") end
 if not okay then return fail("GETTER_CALL_FAILED") end
 if not S:Readable(points) then return fail("LIST_RESTRICTED") end
 if points==nil then return fail("LIST_NOT_READY") end
 if type(points)~="table" then return fail("LIST_TYPE_INVALID") end
 local copy,used={},{}
 for i=1,17 do
  local row,access=S:FieldAccess(points,i)
  if not current() then return fail("IDENTITY_CHANGED",i) end
  if access=="ABSENT" then hitReadback(phase,"READBACK_READY",#copy);return copy end
  if access~="KNOWN" then return fail(access=="RESTRICTED" and "ROW_RESTRICTED" or "ROW_ACCESS_FAILED",i) end
  if i>16 then return fail("LIST_LIMIT",i) end
  if type(row)~="table" then return fail("ROW_TYPE_INVALID",i) end
  local entry={}
  for _,key in ipairs(hitFields) do
   local item,known=S:FieldAccess(row,key)
   if not current() then return fail("IDENTITY_CHANGED",i,key) end
   if known~="KNOWN" then
    return fail(known=="ABSENT" and "FIELD_ABSENT" or known=="RESTRICTED" and "FIELD_RESTRICTED" or "FIELD_ACCESS_FAILED",i,key)
   end
   entry[key]=item
  end
  if not S:Text(entry.point) or not hitPointNames[entry.point] then return fail("POINT_INVALID",i,"point") end
  if used[entry.point] then return fail("POINT_DUPLICATE",i,"point") end
  if not S:Text(entry.relativePoint) or not hitPointNames[entry.relativePoint] then return fail("POINT_INVALID",i,"relativePoint") end
  if not S:Frame(entry.relativeTo,false) then return fail("REGION_UNAVAILABLE",i,"relativeTo") end
  if not S:Number(entry.offsetX) then return fail("OFFSET_INVALID",i,"offsetX") end
  if not S:Number(entry.offsetY) then return fail("OFFSET_INVALID",i,"offsetY") end
  if not current() then return fail("IDENTITY_CHANGED",i) end
  used[entry.point]=true;copy[#copy+1]=entry
 end
end
-- Admission failures are not perpetual paint work. Keep bounded session
-- evidence separately from current native occupants, and rearm only on a
-- meaningful native lifecycle boundary or explicit recovery.
local inputPermanentStages={METHOD_UNAVAILABLE=true,LIST_TYPE_INVALID=true,ROW_TYPE_INVALID=true,
 FIELD_ABSENT=true,POINT_INVALID=true,POINT_DUPLICATE=true,OFFSET_INVALID=true,LIST_LIMIT=true}
local function inputReason(reason) return S:Text(reason) and reason:find("NATIVE_HIT_",1,true)==1 end
local function inputRetryClass(reason,stage)
 if reason=="NATIVE_HIT_POLICY_NO_REGION" then return "NATIVE_POLICY" end
 if reason=="NATIVE_HIT_NEWER_OWNER" then return "EXTERNAL_OWNER" end
 if reason=="NATIVE_HIT_PERMISSION_DEFERRED" then return "NATIVE_EVENT" end
 if reason=="NATIVE_HIT_OBSERVER_UNAVAILABLE" or inputPermanentStages[stage] then return "CAPABILITY_BLOCKED" end
 return "BOUNDED_RETRY"
end
function N:RecordInputIncident(reason,detail,class,origin)
 local session=self.inputSession
 if not session then session={failures=0,successes=0,incidents={}};self.inputSession=session end
 origin=origin or "ADMISSION"
 local now=S:Now();session.lastFailureAt=now
 if origin=="ADMISSION" then session.failures=session.failures+1 else session.lifecycleFailures=(session.lifecycleFailures or 0)+1 end
 local stage=detail and detail.stage or reason
 local phase=detail and detail.phase or "ADMISSION"
 local last=session.incidents[#session.incidents]
 if not last or last.reason~=reason or last.stage~=stage or last.phase~=phase or last.origin~=origin then
  if #session.incidents>=12 then table.remove(session.incidents,1) end
  last={reason=reason,stage=stage,phase=phase,origin=origin,firstAt=now,count=0};session.incidents[#session.incidents+1]=last
 end
 last.count=last.count+1;last.lastAt=now;last.retryClass=class or "OWNED_LIFECYCLE"
 last.index=detail and detail.index or 0;last.field=detail and detail.field or "NONE"
 session.lastFailure=last
end
function N:RecordInputLifecycle(v,r,reason,detail)
 local h=r and r.hit;if not h or v.lease~=r then return end
 local key=reason..":"..(detail and detail.phase or "LIFECYCLE")..":"..(detail and detail.stage or reason)
 if h.lifecycleIncident==key then return end
 h.lifecycleIncident=key
 self:RecordInputIncident(reason,detail,"NATIVE_HANDOFF", "OWNED_LIFECYCLE")
end
function N:ClearAdmission(unit)
 local entry=self.admissionStates and self.admissionStates[unit]
 if not entry then return end
 if self.admissionByPlate and self.admissionByPlate[entry.plate]==entry then self.admissionByPlate[entry.plate]=nil end
 self.admissionStates[unit]=nil
end
function N:AdmissionGate(unit,plate)
 local entry=self.admissionStates and self.admissionStates[unit]
 if not entry then return true end
 if entry.plate~=plate or entry.uf~=field(plate,"UnitFrame") or entry.profile~=M.profile
  or entry.revision~=self.configurationRevision then self:ClearAdmission(unit);return true end
 return not entry.blocked,entry
end
function N:AdmissionFailure(unit,plate,reason,detail)
 if not inputReason(reason) then return end
 local stage=detail and detail.stage or reason
 local class=inputRetryClass(reason,stage)
 if class=="NATIVE_POLICY" then self.nativeInputPolicyPasses=(self.nativeInputPolicyPasses or 0)+1
 else self:RecordInputIncident(reason,detail,class) end
 if not unitToken(unit) or not S:Frame(plate,false) then return end
 self.admissionStates=self.admissionStates or {}
 self.admissionByPlate=self.admissionByPlate or setmetatable({},{__mode="k"})
 local _,entry=self:AdmissionGate(unit,plate)
 if not entry then
  local count=0;for _ in pairs(self.admissionStates) do count=count+1 end
  if count>=80 then return end
  entry={unit=unit,plate=plate,uf=field(plate,"UnitFrame"),profile=M.profile,revision=self.configurationRevision,attempts=0}
  self.admissionStates[unit]=entry;self.admissionByPlate[plate]=entry
 end
 entry.attempts=entry.attempts+1;entry.reason=reason;entry.stage=stage;entry.retryClass=class
 entry.blocked=class~="BOUNDED_RETRY" or entry.attempts>=3
 entry.nextAction=class=="NATIVE_POLICY" and "PRESERVE_NATIVE_NO_HIT_POLICY"
  or class=="EXTERNAL_OWNER" and "PRESERVE_NATIVE_OWNER"
  or entry.blocked and "WAIT_NATIVE_LAYOUT_OR_RECOVER" or "BOUNDED_NATIVE_READ_RETRY"
 if entry.blocked then self.queue[unit]=nil end
 invalidateHitPolicy()
end
function N:InputSucceeded(unit)
 self:ClearAdmission(unit)
 local session=self.inputSession
 if not session then session={failures=0,successes=0,incidents={}};self.inputSession=session end
 session.successes=session.successes+1;session.lastSuccessAt=S:Now()
end
function N:RearmAdmission(unit,plate,why)
 local entry=self.admissionStates and self.admissionStates[unit]
 if not entry or entry.plate~=plate then return false end
 entry.attempts=0;entry.blocked=false;entry.nextAction="NATIVE_EVENT_RECHECK"
 self.admissionRearms=(self.admissionRearms or 0)+1;self.lastAdmissionRearm=why
 return true
end
function N:RearmAdmissions(why,all)
 for unit,entry in pairs(self.admissionStates or {}) do
  if all or entry.retryClass=="BOUNDED_RETRY" or entry.retryClass=="NATIVE_EVENT" then
   if self:RearmAdmission(unit,entry.plate,why) then self:Queue(unit,entry.plate,entry.reason) end
  end
 end
end
function N:InputBlocker(plate)
 local entry=self.admissionByPlate and self.admissionByPlate[plate]
 if not entry or entry.profile~=M.profile or entry.revision~=self.configurationRevision then return nil end
 -- A cached failed attempt is not evidence against a recycled or absent unit.
 if field(plate,"UnitFrame")~=entry.uf or nativeUnit(plate)~=entry.unit or plateFor(entry.unit)~=plate then return nil end
 return entry.reason,entry.stage,entry.retryClass=="NATIVE_POLICY" and "NATIVE_POLICY" or entry.blocked and "BLOCKED" or "RETRY_PENDING"
end
function N:InputCounts()
 local ready,blocked,pending,nativePolicy,debt,oldest,passive,relative,namesOnly,observed=0,0,0,0,0,0,0,0,0,0
 for _,v in pairs(self.byUnit) do
  if not v.filterOnly and not v.retiring and v.admitted~=false and self:Current(v) and v.lease.hit and v.lease.hit.aligned then ready=ready+1 end
  local h=v.lease and v.lease.hit
  if h and h.mode=="PASSIVE_NATIVE_REGION" and not v.retiring and self:Current(v) then passive=passive+1;if h.sourceRelative then relative=relative+1 end end
  if h and h.mode=="OBSERVED_NATIVE_LEASE" and not v.retiring and self:Current(v) and h.aligned then observed=observed+1 end
  if h and h.restorePendingSince then debt=debt+1;oldest=math.max(oldest,S:Now()-h.restorePendingSince) end
 end
 for unit,entry in pairs(self.admissionStates or {}) do
  if self:InputBlocker(entry.plate) then
   if entry.retryClass=="NATIVE_POLICY" then nativePolicy=nativePolicy+1;if entry.stage=="NATIVE_NAMES_ONLY" then namesOnly=namesOnly+1 end
   elseif entry.blocked then blocked=blocked+1 else pending=pending+1 end
  end
 end
 return ready,blocked,pending,nativePolicy,debt,oldest,passive,relative,namesOnly,observed
end
function N:InputSummary()
 local ready,blocked,pending,nativePolicy,debt,oldest,passive,relative,namesOnly,observed=self:InputCounts()
 local session=self.inputSession or {};local last=session.lastFailure
 local current=debt>0 and "NATIVE_INPUT_HANDOFF_PENDING" or not self.active and "PROVIDER_INACTIVE" or blocked>0 and "NATIVE_FALLBACK_INPUT_BLOCKED"
  or pending>0 and "NATIVE_FALLBACK_INPUT_RETRY" or ready>0 and (passive==ready and "NATIVE_INPUT_UNMODIFIED_PASSIVE_VISUALS" or observed==ready and "NATIVE_BODY_LEASE_SUBMISSION_OBSERVED" or "CUSTOM_INPUT_CONTRACT_READY") or nativePolicy>0 and "NATIVE_NO_HIT_POLICY" or "NO_CUSTOM_INPUT_OWNER"
 return "current="..current.."; current_ready="..ready.."; current_blocked="..blocked.."; current_retry="..pending.."; current_native_policy="..nativePolicy
  .."; session_failed_admissions="..(session.failures or 0).."; session_successful_admissions="..(session.successes or 0)
  .."; session_input_lifecycle_failures="..(session.lifecycleFailures or 0).."; current_restore_pending="..debt.."; oldest_restore_age="..string.format("%.1f",oldest)
  .."; last_failure="..(last and last.reason.."/"..last.stage or "NONE")
  .."; next_action="..(debt>0 and "WAIT_LEGAL_NATIVE_HANDOFF" or blocked>0 and "WAIT_NATIVE_LAYOUT_OR_RECOVER" or pending>0 and "BOUNDED_NATIVE_READ_RETRY"
   or passive>0 and "WAIT_AUTHORED_BODY_PERMISSION"
   or namesOnly>0 and (self.friendlyPolicyBlocked and "PRESERVE_EXTERNAL_FRIENDLY_MODE_CHOICE" or self.friendlyPolicyRetry and "WAIT_LEGAL_FRIENDLY_MODE_PREPARATION" or "WAIT_NATIVE_FRIENDLY_MODE_LAYOUT")
   or nativePolicy>0 and "PRESERVE_NATIVE_NO_HIT_POLICY" or "NONE")
  .."; current_passive_native="..passive.."; current_relative_body="..relative.."; current_public_fit="..(passive-relative).."; current_names_only="..namesOnly.."; current_observed_body="..observed.."; native_picking=NOT_RUN"
end
function N:PresentationReport()
 local cfg=config()
 local authored,relative,fit,target,focus,inside,outside,unknown,grace,observed,readback=0,0,0,0,0,0,0,0,0,0,0
 local low,high,requestedLow,requestedHigh
 local deferred,deferredReason=0,"NONE"
 local fallback="NONE"
 for _,v in pairs(self.byUnit) do
  if not v.filterOnly and not v.retiring and v.admitted~=false and self:Current(v) then
   local hit=v.lease and v.lease.hit
   if hit and hit.mode=="PASSIVE_NATIVE_REGION" then
    if hit.sourceRelative then relative=relative+1 else fit=fit+1 end
    fallback=hit.promotionFailure or hit.passiveReason or hit.geometryStage or "NATIVE_PERMISSION_UNAVAILABLE"
   else
    authored=authored+1
    if hit and hit.mode=="OBSERVED_NATIVE_LEASE" then observed=observed+1 else readback=readback+1 end
   end
   if v.selectedTarget then target=target+1 end;if v.selectedFocus then focus=focus+1 end
   if v.presentationDeferred then deferred=deferred+1;deferredReason=v.presentationDeferred end
   if v.rangeStatus=="IN" then inside=inside+1 elseif v.rangeStatus=="OUT" then outside=outside+1 else unknown=unknown+1 end
   if v.rangeVisualReason=="RECENT_PUBLIC_RANGE_GRACE" then grace=grace+1 end
   local requested=((cfg.cardScale or 100)/100)*(v.rangeVisual=="OUT" and .82 or 1)*((v.selectedTarget or v.selectedFocus) and 1.08 or 1)
   requestedLow=not requestedLow and requested or math.min(requestedLow,requested);requestedHigh=not requestedHigh and requested or math.max(requestedHigh,requested)
   local scale=v.presentationScale
   if S:Number(scale) then low=not low and scale or math.min(low,scale);high=not high and scale or math.max(high,scale) end
  end
 end
 local function span(a,b) return a and string.format("%.3f..%.3f",a,b) or "NONE" end
 return "authored="..authored.."; compact_relative="..relative.."; constrained_public_fit="..fit
  .."; width="..(cfg.cardWidth or 240).."; name_size="..(cfg.nameSize or 12).."; percentages="..(cfg.cardPercent and "ON" or "OFF")
  .."; requested_scale="..span(requestedLow,requestedHigh).."; submitted_local_scale="..span(low,high)
  .."; range_in="..inside.."; range_out="..outside.."; range_unknown="..unknown.."; range_grace="..grace
  .."; target="..target.."; focus="..focus.."; observed_body_leases="..observed.."; readback_body_leases="..readback
  .."; presentation_deferred="..deferred.."; deferred_reason="..deferredReason
  .."; fallback_reason="..fallback.."; promotion_attempts="..(self.bodyPromotionAttempts or 0).."; promotion_successes="..(self.bodyPromotionSuccesses or 0)
  .."; geometry=AUTHORED_BODY_CORNERS_WHEN_LEASED; native_pixels_and_picking=NOT_RUN"
end
function N:FriendlyPrerequisiteReport()
 local observed=self.friendlyPolicyObserved or {}
 local missing={}
 local matched={APPLIED=true,NATIVE_MATCH=true,NATIVE_MATCH_EXTERNAL_PRESERVED=true}
 for _,setting in ipairs({"friendlyVisibility","friendlyNameMode"}) do
  if not matched[observed[setting]] then missing[#missing+1]=setting..":"..(observed[setting] or "NOT_OBSERVED") end
 end
 local labels,fallbacks=0,0
 for _,v in pairs(self.byUnit) do if self:Current(v) and v.lease.ambientName then labels=labels+1 end end
 for unit,entry in pairs(self.ambientFallbacks or {}) do
  if plateFor(unit)==entry.plate and field(entry.plate,"UnitFrame")==entry.uf and nativeUnit(entry.plate)==unit then fallbacks=fallbacks+1 end
 end
 local state=not self.active and "PROVIDER_INACTIVE"
  or #missing==0 and "NATIVE_PREREQUISITES_MATCHED" or "NATIVE_PREREQUISITES_PENDING"
 return "friendly_player_prerequisites="..state.."; friendly_player_dependencies="..(#missing>0 and table.concat(missing,",") or "NONE")
  .."; friendly_players_observed="..(observed.friendlyVisibility or "NOT_OBSERVED")
  .."; friendly_names_only_observed="..(observed.friendlyNameMode or "NOT_OBSERVED")
  .."; ambient_native_labels="..labels.."; ambient_native_fallbacks="..fallbacks
  .."; ambient_native_last_fallback="..(self.lastAmbientFallback or "NONE")
  .."; ambient_input=NATIVE_FOOTPRINT_UNCHANGED; ambient_input_visual_equality=NOT_CLAIMED; ambient_aura_presentation="..(labels>0 and "NATIVE_PARKED_WITH_INVERSE" or "NO_CURRENT_AMBIENT_LEASE")
end
function N:InputReport()
 local d=self.hitDiagnostics or {};local session=self.inputSession or {};local last=session.lastFailure
 local out={self:InputSummary(),"getter_last_phase="..(d.lastPhase or "NOT_RUN"),"getter_last_stage="..(d.lastStage or "NOT_RUN"),"getter_availability="..(d.availability or "NOT_OBSERVED"),
  "getter_failure_phase="..(d.failurePhase or "NONE"),"getter_failure_stage="..(d.failureStage or "NONE"),
  "getter_failure_row="..(d.failureIndex or 0),"getter_failure_field="..(d.failureField or "NONE"),
  "getter_reads="..(d.reads or 0),"getter_failures="..(d.failures or 0),"last_failed_admission_at="..(session.lastFailureAt or 0),
  "last_successful_admission_at="..(session.lastSuccessAt or 0),"admission_rearms="..(self.admissionRearms or 0),
  "last_rearm="..(self.lastAdmissionRearm or "NONE"),"blocked_attempts_skipped="..(self.admissionSkipped or 0),
  "native_input_policy=EMPTY_NAME_ONLY_WIDGETS_ONLY_CLICK_THROUGH_RETAINED","getter_scope=PUBLIC_FIXED_STAGE_TAGS_NO_VALUES",
  "passive_native_observations="..(self.passiveNativeObservations or 0),"passive_admissions="..(self.passiveAdmissions or 0),
  "observed_body_admissions="..(self.observedBodyAdmissions or 0),
  "observed_body_contract=COMPLETED_NATIVE_SNAPSHOT_PERMISSION_AND_VOID_SETTER_OBSERVATION; observed_body_readback=UNAVAILABLE_NOT_SYNTHESIZED; observed_body_input=AUTHORED_CARD_CORNERS; native_picking=NOT_RUN",
  "passive_geometry_last_stage="..(self.passiveGeometryLastStage or "NOT_RUN"),
  "passive_input_contract=OBSERVED_COMPLETED_NATIVE_LAYOUT_NO_INPUT_WRITES; passive_geometry=PUBLIC_CONTAINMENT_OR_ENGINE_RELATIVE_CLIPPED_BODY; relative_body=COMPACT_LABEL_HEALTH_RESOURCE_NO_PERCENTAGES; relative_preparation=DETACHED_CLIPPED_GRAPH; relative_legality=ACTUAL_OWNED_TARGET; relative_verification=SUBMISSION_AND_OWNED_MUTATION_GUARDS; relative_label=ENGINE_CONSTRAINED_TRUNCATION_NOT_FULL_NAME_FIT; passive_offsets=NATIVE_INPUT_FOOTPRINT; passive_quiet=NATIVE_ARTWORK_RETAINED"}
 for _,code in ipairs(d.order or {}) do out[#out+1]="stage_"..code.."="..d.counts[code] end
 if d.counts and d.counts.OTHER then out[#out+1]="stage_OTHER="..d.counts.OTHER end
 out[#out+1]=self:FriendlyPrerequisiteReport()
 for i,incident in ipairs(session.incidents or {}) do
  out[#out+1]="incident"..i.."="..incident.reason.."/"..incident.stage.."/"..incident.phase..":"..incident.count..":"..incident.retryClass..":"..incident.origin
 end
 return table.concat(out,"; ")
end
function N:AuraDependencyReport()
 local ready,blocked,pending,nativePolicy=self:InputCounts()
 local state=not self.active and "PROVIDER_INACTIVE" or config().cardAuras==false and "DISABLED"
  or blocked+pending>0 and "BLOCKED_BY_NAMEPLATE_INPUT" or ready>0 and "CURRENT_INPUT_OWNERS" or nativePolicy>0 and "NATIVE_NO_HIT_POLICY" or "NO_CONTENT"
 return "state="..state.."; input_ready="..ready.."; input_blocked="..blocked.."; input_pending="..pending.."; detail_health=REPORTED_BY_NATIVE_AURA_RAILS"
end
local function sameHitPoints(a,b)
 if not a or not b or #a~=#b then return false end
 for _,left in ipairs(a) do
  local match
  for _,right in ipairs(b) do if left.point==right.point then match=right;break end end
  if not match then return false end
  for _,key in ipairs(hitFields) do if left[key]~=match[key] then return false end end
 end
 return true
end
local function cardHitPoints(frame)
 return {{point="TOPLEFT",relativeTo=frame,relativePoint="TOPLEFT",offsetX=0,offsetY=0},
  {point="BOTTOMRIGHT",relativeTo=frame,relativePoint="BOTTOMRIGHT",offsetX=0,offsetY=0}}
end
local canonicalNativeHit,copyPublicHitPoints
local function hitUnit(plate)
 local fn=field(plate,"GetUnit")
 if type(fn)~="function" then return nil,false end
 local okay,unit=pcall(fn,plate)
 return unit,okay and S:Readable(unit) and (unit==nil or S:Text(unit))
end
function N:HitGuard(v,r,forward)
 local h=r.hit;local profile,configuration=M.profile,self.configurationRevision
 local frame,unit,generation=v.frame,v.unit,v.generation
 local original,requested,serial=h.original,h.requested,h.monitor.serial
 return function()
  return v.lease==r and r.hit==h and v.frame==frame and v.unit==unit and v.generation==generation
   and self.byPlate[r.plate]==v and self.byUnit[unit]==v and self.hitMonitors[r.plate]==h.monitor
   and h.monitor.serial==serial and h.original==original and h.requested==requested
   and M.profile==profile and self.configurationRevision==configuration
   and (not forward or self.active and not v.retiring and not M.state.safe and h.profile==profile and h.config==profile.modules.Nameplates)
 end
end
function N:HitIdentity(v,r,current,forward)
 if not current() or not S:Frame(r.plate,false) or not current() then return false end
 local controller=field(r.plate,"UnitFrame")
 local unit,known=hitUnit(r.plate)
 if not current() or not known then return false end
 -- A cleared native base can finish its old inverse. A successor with a
 -- live unit/controller cannot receive anchors from the retired controller.
 if controller~=nil and controller~=r.uf or unit~=nil and (unit~=r.unit or controller~=r.uf) then return false end
 if forward then
  if controller~=r.uf or unit~=r.unit or not selected() or not self:Current(v) or not current() then return false end
  if field(r.uf,"UpdateHitTestArea")~=r.hit.controller.method or not current() then return false end
 end
 local finalUnit,finalKnown=hitUnit(r.plate)
 return current() and finalKnown and finalUnit==unit and field(r.plate,"UnitFrame")==controller and current()
end
function N:WatchHitPoints(plate,uf)
 if type(hooksecurefunc)~="function" then return nil end
 self.hitMonitors=self.hitMonitors or setmetatable({},{__mode="k"})
 self.hitControllers=self.hitControllers or setmetatable({},{__mode="k"})
 local monitor=self.hitMonitors[plate]
 if not monitor then monitor={serial=0,methods={}};self.hitMonitors[plate]=monitor end
 for _,key in ipairs({"SetHitTestPoints","SetAllHitTestPoints","ClearAllHitTestPoints"}) do
  if not monitor.methods[key] then
   if type(field(plate,key))~="function" then return nil end
   local okay=pcall(hooksecurefunc,plate,key,function(base,points)
    local own=N.hitWriting
    local ownCallback=own and own.plate==base and own.method==key and own.points==points
    if ownCallback and not own.seen and monitor.serial==own.serial then
     local copied=copyPublicHitPoints and copyPublicHitPoints(key=="ClearAllHitTestPoints" and {} or points)
     if not own.expectedPoints or sameHitPoints(copied,own.expectedPoints) then
      own.seen=true;own.observedPoints=copied;return
     end
    end
    monitor.serial=monitor.serial+1;monitor.nativeReceipt=nil
    -- Posthooks run after the documented void setter completes. Only public
    -- arguments from secure native methods can feed passive visual fitting;
    -- they are not a fabricated GetHitTestPoints readback.
    local secure,ss=S:Public(issecurevariable,"boolean",base,key)
    local copied=copyPublicHitPoints and copyPublicHitPoints(key=="ClearAllHitTestPoints" and {} or points)
    -- An outer posthook may run after a nested foreign setter. Its outer
    -- arguments are not evidence of the last engine state. Once our own
    -- transaction loses its serial, retain uncertainty instead of replacing
    -- that conflict with apparently safe outer inverse arguments.
    if key=="SetAllHitTestPoints" or ownCallback then copied=nil end
    monitor.lastWrite={serial=monitor.serial,method=key,points=copied,secure=ss=="KNOWN" and secure==true,
     uf=field(base,"UnitFrame"),unit=nativeUnit(base),ambiguous=ownCallback==true}
    local view=N.byPlate[base];local receipt=view and view.lease and view.lease.hit
    if receipt and receipt.monitor==monitor then receipt.displaced=true;view.inputStatus="NATIVE_HIT_UPDATE_PENDING" end
   end)
   if not okay then return nil end
   monitor.methods[key]=field(plate,key)
  elseif field(plate,key)~=monitor.methods[key] then return nil end
 end
 local controller=self.hitControllers[uf]
 if not controller then
  local method=field(uf,"UpdateHitTestArea")
  local native,state=S:FieldAccess(NamePlateUnitFrameMixin,"UpdateHitTestArea")
  if state~="KNOWN" or method~=native then return nil end
  local okay=pcall(hooksecurefunc,uf,"UpdateHitTestArea",function(object,setup)
   N:ObserveNativeHitLayout(object,setup)
   local view=N.byObject[object]
   if view and view.lease and view.lease.uf==object then N:NativeHitChanged(view,setup) end
   if N.active and selected() and not N.applyingPolicies then
    -- A declined/overflow plate may become eligible on a later native update.
    -- Use that exact permission window, not a timer after it has closed. The
    -- first ApplyFrameOptions may precede unit assignment on the controller.
    local base=value(object,"GetNamePlateFrame")
    local unit=base and nativeUnit(base)
    if unitToken(unit) and N.observed[unit]==base and not N.byPlate[base] and field(base,"UnitFrame")==object
     and field(object,"unit")==unit and plateFor(unit)==base then
     N:RearmAdmission(unit,base,"NATIVE_HIT_LAYOUT")
     local good,why=N:Assign(unit,base);if not good then N:Queue(unit,base,why) end
    end
   end
  end)
  if not okay then return nil end
  controller={method=field(uf,"UpdateHitTestArea")};self.hitControllers[uf]=controller
 elseif field(uf,"UpdateHitTestArea")~=controller.method then return nil end
 return monitor,controller
end
function N:NativeNoHitPolicy(r)
 local namesOnly,known=value(r.uf,"IsShowOnlyName","boolean")
 local stage=known=="KNOWN" and namesOnly and "NATIVE_NAMES_ONLY" or field(r.uf,"widgetsOnlyMode")==true and "NATIVE_WIDGETS_ONLY" or "NATIVE_NO_HIT_REGION"
 self.acquisitionReadback={phase="PREPARE",stage=stage}
 return false,"NATIVE_HIT_POLICY_NO_REGION"
end
function N:PrepareHitPoints(v,r)
 local profile,configuration,frame,generation=M.profile,self.configurationRevision,v.frame,v.generation
 local function pending()
  return self.active and M.profile==profile and self.configurationRevision==configuration and not v.lease
   and v.frame==frame and v.generation==generation
 end
 local monitor,controller=self:WatchHitPoints(r.plate,r.uf)
 if not pending() or not monitor then return false,"NATIVE_HIT_OBSERVER_UNAVAILABLE" end
 local serial=monitor.serial
 local function current() return pending() and monitor.serial==serial and self.hitMonitors[r.plate]==monitor end
 if field(r.plate,"UnitFrame")~=r.uf or nativeUnit(r.plate)~=r.unit or plateFor(r.unit)~=r.plate or not current() then return false,"NATIVE_HIT_OWNER_CHANGED" end
 local original,stage,index,key=readHitPoints(r.plate,current,"PREPARE")
 if not original then
  self.acquisitionReadback={stage=stage,index=index,field=key,phase="PREPARE"}
  -- A throwing getter is not made readable by changing arguments. The
  -- source-pinned native callback independently supplies the exact inverse
  -- as public completed setter arguments. The documented void setter has
  -- its own capability predicate; an unavailable getter does not revoke a
  -- positively observed permission. Retain that distinct observation
  -- contract instead of squeezing every card into native compact bounds.
  if stage=="GETTER_CALL_FAILED" then
   local receipt=monitor.nativeReceipt
   if receipt and receipt.serial==serial and receipt.unit==r.unit and receipt.uf==r.uf and current() then
    if #receipt.points==0 then return self:NativeNoHitPolicy(r) end
    local allowed,access=value(r.plate,"CanChangeHitTestPoints","boolean")
    if not current() then return false,"NATIVE_HIT_OWNER_CHANGED" end
    local observed=access=="KNOWN" and allowed==true
    r.hit={original=receipt.points,monitor=monitor,controller=controller,serial=serial,profile=profile,
     config=profile.modules.Nameplates,mode=observed and "OBSERVED_NATIVE_LEASE" or "PASSIVE_NATIVE_REGION",nativeReceipt=receipt}
    if observed then
     r.hit.observedPoints=receipt.points;r.hit.observedSerial=serial;r.hit.observation="COMPLETED_NATIVE_LAYOUT"
     self.observedBodyAdmissions=(self.observedBodyAdmissions or 0)+1
    else
     r.hit.passiveReason=access=="KNOWN" and "NATIVE_HIT_PERMISSION_DEFERRED" or "NATIVE_HIT_PERMISSION_UNAVAILABLE"
     self.passiveAdmissions=(self.passiveAdmissions or 0)+1
    end
    return true
   end
  end
  return false,"NATIVE_HIT_READBACK_UNAVAILABLE"
 end
 -- Empty native points are an intentional name-only/widgets-only input
 -- policy (and are also used by noninteractive previews). Keep that policy.
 if #original==0 then return self:NativeNoHitPolicy(r) end
 local native=canonicalNativeHit(r,NamePlateSetupOptions,current)
 if not current() or not sameHitPoints(original,native) then return false,"NATIVE_HIT_NEWER_OWNER" end
 local allowed,state=value(r.plate,"CanChangeHitTestPoints","boolean")
 if state~="KNOWN" or not allowed or not current() then return false,"NATIVE_HIT_PERMISSION_DEFERRED" end
 r.hit={original=original,monitor=monitor,controller=controller,serial=serial,profile=profile,config=profile.modules.Nameplates}
 return true
end
-- This receipt proves which public arguments completed under exclusive
-- observed setter custody. It never pretends to be GetHitTestPoints, a pixel
-- rectangle, a native mouseover result, or proof of in-game target picking.
-- Every relevant native setter is observed. A changed setter identity, an
-- unknown foreign write, or an unconfirmed partial attempt keeps the slot
-- retained until a safe inverse or a proven non-referencing successor exists.
local function currentNativeOrPublicHit(r,current)
 local h=r.hit;local monitor=h.monitor
 local native=monitor.nativeReceipt
 if native and native.serial==monitor.serial then return native.points,"NEWER_COMPLETED_NATIVE_LAYOUT" end
 -- An arbitrary posthook may be an outer callback following a nested
 -- writer. One genuine public read is permitted for this changed serial;
 -- a throwing/opaque read is not polled again on every cleanup pass.
 if h.displacedReadSerial==monitor.serial and h.displacedReadFailure then return nil,h.displacedReadFailure end
 local serial=monitor.serial
 local actual,stage=readHitPoints(r.plate,current,"DISPLACED_OBSERVATION")
 if actual then return actual,"NEWER_PUBLIC_READBACK" end
 if current() and monitor.serial==serial then h.displacedReadSerial=serial;h.displacedReadFailure=stage or "NEWER_WRITER_UNOBSERVED" end
 return nil,stage or "NEWER_WRITER_UNOBSERVED"
end
function N:ObservedHitPoints(v,r,current)
 local h=r.hit;local monitor=h and h.monitor
 if not h or h.mode~="OBSERVED_NATIVE_LEASE" or not monitor or not current() or not S:Frame(r.plate,false) then return nil,"IDENTITY_CHANGED" end
 for key,method in pairs(monitor.methods) do
  if field(r.plate,key)~=method or not current() then return nil,"OBSERVER_METHOD_CHANGED" end
 end
 if not h.displaced and monitor.serial==h.serial then
  if h.observedSerial==monitor.serial and h.observedPoints then return h.observedPoints,"CURRENT_SUBMISSION_RECEIPT" end
  return nil,h.writeUncertain and "SETTER_COMPLETION_UNCONFIRMED" or "SUBMISSION_RECEIPT_UNAVAILABLE"
 end
 -- Arbitrary foreign posthooks may themselves have nested writers. Only
 -- the single-write native callback receipt or real public readback can
 -- prove that a displaced body is no longer referenced. Preserve foreign
 -- input without using its setter arguments to grant premature pool reuse.
 return currentNativeOrPublicHit(r,current)
end
function N:WriteHitPoints(v,r,points,current,forward)
 local h=r.hit
 if self.hitWriting or not self:HitIdentity(v,r,current,forward) then return false end
 local method=#points==0 and "ClearAllHitTestPoints" or "SetHitTestPoints"
 local fn=field(r.plate,method)
 if fn~=h.monitor.methods[method] or not current() then return false end
 local allowed,state=value(r.plate,"CanChangeHitTestPoints","boolean")
 if not current() then return false end
 if state~="KNOWN" then return false,"NATIVE_HIT_PERMISSION_UNAVAILABLE" end
 if not allowed then return false,"NATIVE_HIT_PERMISSION_DEFERRED" end
 if field(r.plate,method)~=fn or not current() or not self:HitIdentity(v,r,current,forward) then return false end
 local observed=h.mode=="OBSERVED_NATIVE_LEASE"
 local writing={plate=r.plate,method=method,points=#points>0 and points or nil,serial=h.monitor.serial,
  expectedPoints=observed and copyPublicHitPoints(points) or nil}
 if observed and not writing.expectedPoints then return false end
 if observed then h.observedPoints=nil;h.writeUncertain=true;h.observation="SETTER_COMPLETION_PENDING" end
 self.hitWriting=writing
 local okay,result=pcall(fn,r.plate,writing.points)
 self.hitWriting=nil
 if not okay or not S:Readable(result) or result==false or not current() or not self:HitIdentity(v,r,current,forward) then return false end
 if observed then
  if result~=nil or not writing.seen or not sameHitPoints(writing.observedPoints,writing.expectedPoints)
   or h.monitor.serial~=writing.serial or field(r.plate,method)~=fn or not current() then return false end
  for key,pinned in pairs(h.monitor.methods) do if field(r.plate,key)~=pinned or not current() then return false end end
  h.observedPoints=writing.observedPoints;h.observedSerial=writing.serial;h.writeUncertain=nil
  h.observation="VOID_SETTER_COMPLETION_OBSERVED"
  return true
 end
 local actual=readHitPoints(r.plate,current,"WRITE_VERIFY")
 return current() and sameHitPoints(actual,points) and self:HitIdentity(v,r,current,forward)
end
function N:AlignHitPoints(v,r)
 local h=r.hit;if not h then return true end
 if h.mode=="PASSIVE_NATIVE_REGION" then
  local okay=self:FitPassiveHitVisual(v,r,v.rangeVisual)
  if not okay then
   self.acquisitionReadback={phase="PASSIVE_FIT",stage=h.geometryStage or "PUBLIC_REGION_CONTAINMENT_UNAVAILABLE"}
   return false,"NATIVE_HIT_PASSIVE_GEOMETRY_UNAVAILABLE"
  end
  h.aligned=true;h.displaced=nil;h.restored=nil;h.suspended=nil;h.hidePending=nil
  v.inputStatus="NATIVE_INPUT_UNMODIFIED_PASSIVE_FIT";return true
 end
 h.requested=cardHitPoints(v.frame)
 local current=self:HitGuard(v,r,true)
 if not self:HitIdentity(v,r,current,true) then return false,"NATIVE_HIT_OWNER_CHANGED" end
 local actual,stage,index,key
 if h.mode=="OBSERVED_NATIVE_LEASE" then actual,stage=self:ObservedHitPoints(v,r,current)
 else actual,stage,index,key=readHitPoints(r.plate,current,"ALIGN") end
 if not actual then
  self.acquisitionReadback={stage=stage,index=index,field=key,phase="ALIGN"}
  v.inputStatus="NATIVE_HIT_READBACK_UNAVAILABLE";return false,v.inputStatus
 end
 if not current() or h.monitor.serial~=h.serial or not sameHitPoints(actual,h.original) then return false,"NATIVE_HIT_OWNER_CHANGED" end
 -- Prepare a usable visual before any native setter can partially succeed.
 -- If its readback/inverse then becomes unavailable, a retained receipt must
 -- never leave engine input referencing a blank or hidden replacement body.
 if not self:StageHitVisual(v,r,current) then return false,"NATIVE_HIT_VISUAL_UNAVAILABLE" end
 h.attempted=true
 if not self:WriteHitPoints(v,r,h.requested,current,true) then v.inputStatus="NATIVE_HIT_WRITE_UNCONFIRMED";return false,v.inputStatus end
 h.aligned=true;h.displaced=nil;h.restored=nil;h.suspended=nil;h.hidePending=nil
 v.inputStatus=h.mode=="OBSERVED_NATIVE_LEASE" and "NATIVE_BODY_LEASE_SUBMISSION_OBSERVED" or "NATIVE_BODY_ALIGNED"
 return true
end
canonicalNativeHit=function(r,setup,current)
 if not current() or not S:Readable(setup) or setup~=NamePlateSetupOptions then return nil end
 local only,state=value(r.uf,"IsShowOnlyName","boolean")
 local widgets,ws=S:FieldAccess(r.uf,"widgetsOnlyMode")
 if state~="KNOWN" or ws~="KNOWN" and ws~="ABSENT" or ws=="KNOWN" and type(widgets)~="boolean" or not current() then return nil end
 if only or widgets==true then return {} end
 local style,ss=S:FieldAccess(setup,"unitNameAnchorStyle")
 local height,hs=S:FieldAccess(setup,"healthBarHeight")
 local health=field(field(r.uf,"HealthBarsContainer"),"healthBar")
 local name=field(r.uf,"name")
 local styles=S:FieldAccess(NamePlateConstants,"NAME_ANCHOR_STYLES")
 local inside,known=S:FieldAccess(styles,"InsideHealthBar")
 if ss~="KNOWN" or hs~="KNOWN" or known~="KNOWN" or not S:Number(style) or not S:Number(inside)
  or not S:Number(height) or not S:Frame(health,false) or not S:Frame(name,false) or not current() then return nil end
 return {{point="TOPLEFT",relativeTo=style==inside and health or name,relativePoint="TOPLEFT",offsetX=style==inside and -10 or -14,offsetY=style==inside and height/2 or 0},
  {point="BOTTOMRIGHT",relativeTo=health,relativePoint="BOTTOMRIGHT",offsetX=10,offsetY=-height/2}}
end
-- Copy only ordinary, bounded public setter arguments. No restricted value,
-- exception message, native controller callback, or input state is synthesized.
copyPublicHitPoints=function(points)
 if not S:Readable(points) or type(points)~="table" then return nil end
 local copy={}
 for i=1,3 do
  local row,state=S:FieldAccess(points,i)
  if state=="ABSENT" then return copy end
  if i>2 or state~="KNOWN" or type(row)~="table" then return nil end
  local entry={}
  for _,key in ipairs(hitFields) do
   local value,known=S:FieldAccess(row,key)
   if known~="KNOWN" then return nil end
   entry[key]=value
  end
  if not S:Text(entry.point) or not hitPointNames[entry.point] or not S:Text(entry.relativePoint)
   or not hitPointNames[entry.relativePoint] or not S:Frame(entry.relativeTo,false)
   or not S:Number(entry.offsetX) or not S:Number(entry.offsetY) then return nil end
  copy[#copy+1]=entry
 end
end
function N:ObserveNativeHitLayout(uf,setup)
 local base=value(uf,"GetNamePlateFrame")
 local monitor=base and self.hitMonitors and self.hitMonitors[base]
 local controller=self.hitControllers and self.hitControllers[uf]
 local wrote=monitor and monitor.lastWrite
 local priorBoundary=monitor and (monitor.nativeBoundarySerial or 0)
 if monitor then monitor.nativeBoundarySerial=monitor.serial end
 if not controller or not wrote or not wrote.secure or not wrote.points or wrote.serial~=monitor.serial
  or monitor.serial-priorBoundary~=1
  or wrote.uf~=uf or field(base,"UnitFrame")~=uf or field(uf,"UpdateHitTestArea")~=controller.method then return false end
 local secure,state=S:Public(issecurevariable,"boolean",uf,"UpdateHitTestArea")
 if state~="KNOWN" or secure~=true then return false end
 local unit=nativeUnit(base);local serial=monitor.serial
 local function current()
  return monitor.serial==serial and field(base,"UnitFrame")==uf and nativeUnit(base)==unit
   and field(uf,"UpdateHitTestArea")==controller.method
 end
 if not unitToken(unit) or unit~=wrote.unit then return false end
 local expected=canonicalNativeHit({plate=base,uf=uf,unit=unit},setup,current)
 if not current() or not sameHitPoints(wrote.points,expected) then return false end
 monitor.nativeReceipt={serial=serial,unit=unit,uf=uf,points=wrote.points}
 self.passiveNativeObservations=(self.passiveNativeObservations or 0)+1
 return true
end
local function publicRect(frame,prefix)
 prefix=prefix or "BODY"
 if not S:Frame(frame,false) then return nil,prefix.."_REGION_UNAVAILABLE" end
 local fn=field(frame,"GetRect")
 if type(fn)~="function" then return nil,prefix.."_RECT_METHOD_UNAVAILABLE" end
 local okay,l,b,w,h=pcall(fn,frame)
 if not okay then return nil,prefix.."_RECT_CALL_FAILED" end
 if not S:Readable(l) or not S:Readable(b) or not S:Readable(w) or not S:Readable(h) then return nil,prefix.."_RECT_RESTRICTED" end
 if not S:Number(l) or not S:Number(b) or not S:Number(w) or not S:Number(h) or w<=0 or h<=0 then return nil,prefix.."_RECT_UNRESOLVED" end
 local scale,known=value(frame,"GetEffectiveScale","number")
 if known~="KNOWN" or scale<=0 then return nil,prefix.."_SCALE_UNAVAILABLE" end
 return {l*scale,b*scale,w*scale,h*scale}
end
local function nativeRegion(r,points)
 if not points or #points~=2 then return nil,nil,"NATIVE_CORNER_CONTRACT_UNAVAILABLE" end
 local top,bottom=points[1],points[2]
 if top.point~="TOPLEFT" or top.relativePoint~="TOPLEFT" or bottom.point~="BOTTOMRIGHT" or bottom.relativePoint~="BOTTOMRIGHT" then return nil,nil,"NATIVE_CORNER_CONTRACT_UNAVAILABLE" end
 local a,ar=publicRect(top.relativeTo,top.relativeTo==bottom.relativeTo and "NATIVE_HEALTH" or "NATIVE_NAME")
 if not a then return nil,nil,ar end
 local b,br=publicRect(bottom.relativeTo,"NATIVE_HEALTH")
 if not b then return nil,nil,br end
 local scale,known=value(r.plate,"GetEffectiveScale","number")
 if known~="KNOWN" or scale<=0 then return nil,nil,"NATIVE_PLATE_SCALE_UNAVAILABLE" end
 local left,upper=a[1]+top.offsetX*scale,a[2]+a[4]+top.offsetY*scale
 local right,lower=b[1]+b[3]+bottom.offsetX*scale,b[2]+bottom.offsetY*scale
 if right<=left or upper<=lower then return nil,nil,"NATIVE_REGION_UNRESOLVED" end
 return {left,lower,right-left,upper-lower},scale
end
function N:PassiveHitCurrent(v,r)
 local h=r.hit
 if not h or h.mode~="PASSIVE_NATIVE_REGION" or not self:Current(v) or not selected()
  or h.profile~=M.profile or h.config~=config() or field(r.uf,"UpdateHitTestArea")~=h.controller.method then return false end
 for key,method in pairs(h.monitor.methods) do if field(r.plate,key)~=method then return false end end
 local receipt=h.monitor.nativeReceipt
 return receipt==h.nativeReceipt and receipt.serial==h.monitor.serial and receipt.serial==h.serial
  and receipt.uf==r.uf and receipt.unit==r.unit and not h.displaced
end
function N:FitPassiveHitVisual(v,r,range)
 local h=r.hit
 if not h or h.mode~="PASSIVE_NATIVE_REGION" or not self:PassiveHitCurrent(v,r) or not legal(v.frame) then return false end
 local receipt=h.nativeReceipt
 if h.sourceRelative and type(V.NativeAnchorsCurrent)=="function" and V:NativeAnchorsCurrent(v,receipt) then
  v.presentationScale=1;v.inputStatus="NATIVE_INPUT_UNMODIFIED_RELATIVE_BODY";return true
 end
 local function sourceRelative(stage)
  h.geometryStage=stage;self.passiveGeometryLastStage=stage
  if type(V.FitNativeAnchors)~="function" then return false end
  local generation=v.generation
  local function current() return v.lease==r and v.generation==generation and self:PassiveHitCurrent(v,r) and legal(v.frame) end
  local okay,why=V:FitNativeAnchors(v,r.plate,receipt,config(),current)
  if not okay then h.geometryStage=why or "RELATIVE_BODY_CONSTRAINT_UNCONFIRMED";return false end
  h.sourceRelative=true;h.passiveFit="ENGINE_RELATIVE_NATIVE_CORNERS_CLIPPED_BODY"
  h.fit=nil;v.presentationScale=1;v.inputStatus="NATIVE_INPUT_UNMODIFIED_RELATIVE_BODY"
  -- A later write to our private body retires its active presentation. Native
  -- input/artwork are returned before the private pool layout is reset; no
  -- new admission is queued against an external layout writer.
  if not h.relativeInvalidated then h.relativeInvalidated=function()
    if v.lease~=r or v.generation~=generation or v.releasing then return end
    r.conflict="NATIVE_HIT_OWNED_LAYOUT_CHANGED"
    self:Fallback(v.unit,r.conflict);self:Release(v)
   end
  end
  v.relativeInvalidated=h.relativeInvalidated
  return true
 end
 -- Once a lease uses engine-relative constraints, movement and native scale
 -- propagate through those constraints. Never poll forbidden screen-space
 -- getters again in an attempt to manufacture a public fit.
 if h.sourceRelative then return sourceRelative(h.geometryStage or "ENGINE_RELATIVE_NATIVE_CORNERS") end
 local bounds,parentScale,stage=nativeRegion(r,receipt.points)
 if not bounds then return sourceRelative(stage) end
 local width,ws=value(v.frame,"GetWidth","number");local height,hs=value(v.frame,"GetHeight","number")
 if ws~="KNOWN" or hs~="KNOWN" or width<=0 or height<=0 then return sourceRelative("BODY_SIZE_UNAVAILABLE") end
 local full=math.min((config().cardScale or 100)/100,bounds[3]/(width*parentScale*1.08),bounds[4]/(height*parentScale*1.08))
 local wanted=full*(range=="OUT" and .82 or 1)*((v.selectedTarget or v.selectedFocus) and 1.08 or 1)
 if not S:Number(wanted) or wanted<=0 then return sourceRelative("PUBLIC_FIT_SCALE_INVALID") end
 local centerX=(bounds[1]+bounds[3]/2)/parentScale
 local centerY=(bounds[2]+bounds[4]/2)/parentScale
 local plateRect,plateStage=publicRect(r.plate,"NATIVE_PLATE")
 if not self:PassiveHitCurrent(v,r) then return false end
 if not plateRect then return sourceRelative(plateStage) end
 local x=(centerX-plateRect[1]/parentScale)/wanted
 local y=(centerY-plateRect[2]/parentScale)/wanted
 local prior=h.fit
 if not prior or prior.x~=x or prior.y~=y or prior.scale~=wanted or prior.width~=width or prior.height~=height then
  if not call(v.frame,"SetScale",wanted) or not self:PassiveHitCurrent(v,r)
   or not call(v.frame,"ClearAllPoints") or not self:PassiveHitCurrent(v,r)
   or not call(v.frame,"SetPoint","CENTER",r.plate,"BOTTOMLEFT",x,y) or not self:PassiveHitCurrent(v,r) then return false end
 end
 local actual,bodyStage=publicRect(v.frame,"BODY")
 if not self:PassiveHitCurrent(v,r) then return false end
 if not actual then return sourceRelative(bodyStage) end
 -- Only the identity/health/resource body is the input surface. Aura/cast
 -- decorations remain passive, as in the existing leased-anchor design.
 local epsilon=.75
 if actual[1]<bounds[1]-epsilon or actual[2]<bounds[2]-epsilon
  or actual[1]+actual[3]>bounds[1]+bounds[3]+epsilon or actual[2]+actual[4]>bounds[2]+bounds[4]+epsilon then return sourceRelative("PUBLIC_BODY_OUTSIDE_NATIVE_REGION") end
 h.fit={x=x,y=y,scale=wanted,width=width,height=height,rect=actual};v.presentationScale=wanted
 h.geometryStage="PUBLIC_RECT_CONTAINMENT_READY";self.passiveGeometryLastStage=h.geometryStage
 h.passiveFit="PUBLIC_NATIVE_REGION_CONTAINMENT";v.inputStatus="NATIVE_INPUT_UNMODIFIED_PASSIVE_FIT"
 return true
end
function N:RetirePassiveGeometry(v)
 local r=v.lease;local unit=v.unit;local plate=r and r.plate
 -- Only a still-current completed native receipt permits bounded geometry
 -- reacquisition. A replaced owner, observer, profile or quiet demand does not.
 local stage=r and r.hit and r.hit.geometryStage or "PUBLIC_REGION_CONTAINMENT_UNAVAILABLE"
 local retry=r and self:PassiveHitCurrent(v,r) and stage~="RELATIVE_BODY_CUSTODY_LOST"
 local reason="NATIVE_HIT_PASSIVE_GEOMETRY_UNAVAILABLE"
 self:Fallback(unit,reason)
 if not self:Release(v) then return false end
 if retry and self.active and selected() and nativeUnit(plate)==unit and plateFor(unit)==plate then
  self:AdmissionFailure(unit,plate,reason,{phase="PASSIVE_FIT",stage=stage})
  self:Queue(unit,plate,reason)
 end
 return true
end
function N:StageHitVisual(v,r,current)
 if not self:HitIdentity(v,r,current,true) or not legal(v.frame) or not current() then return false end
 local alpha,as=value(v.frame,"GetAlpha","number")
 local shown,ss=value(v.frame,"IsShown","boolean")
 if as~="KNOWN" or ss~="KNOWN" or not current() then return false end
 if shown and alpha>0 then return true end
 if self:Metadata(v)==false or not current() then return false end
 V:Health(v);if not current() then return false end
 V:Power(v,true);if not current() then return false end
 r.hit.staged=r.hit.staged or {alpha=alpha,shown=shown}
 if not call(v.frame,"SetAlpha",config().alpha or 1) or not current() then return false end
 if not call(v.frame,"Show") or not current() then return false end
 local actual,known=value(v.frame,"GetAlpha","number")
 local visible,visibility=value(v.frame,"IsShown","boolean")
 return known=="KNOWN" and actual>0 and visibility=="KNOWN" and visible==true and self:HitIdentity(v,r,current,true)
end
function N:PromotePassiveBody(v,reason)
 local r=v and v.lease;local h=r and r.hit
 if not h or h.mode~="PASSIVE_NATIVE_REGION" or not self:PassiveHitCurrent(v,r) then return false end
 local receipt=h.nativeReceipt
 self.bodyPromotions=self.bodyPromotions or setmetatable({},{__mode="k"})
 local previous=self.bodyPromotions[r.plate]
 local epoch=self.bodyPromotionEpoch or 0
 if previous and previous.receipt==receipt and previous.epoch==epoch and previous.profile==M.profile then return false end
 local allowed,state=value(r.plate,"CanChangeHitTestPoints","boolean")
 if state~="KNOWN" or allowed~=true or not self:PassiveHitCurrent(v,r) then return false end
 local unit,plate=v.unit,r.plate
 -- One attempted promotion per native layout/combat-exit epoch. A failed
 -- reacquisition cannot churn a functional compact card every maintenance
 -- tick. A later real native layout, combat exit or explicit recovery rearms.
 self.bodyPromotions[plate]={receipt=receipt,epoch=epoch,profile=M.profile}
 self.bodyPromotionAttempts=(self.bodyPromotionAttempts or 0)+1;self.lastBodyPromotion=reason
 if not self:Release(v) then return false end
 if not self.active or not selected() or nativeUnit(plate)~=unit or plateFor(unit)~=plate then return false end
 self:RearmAdmission(unit,plate,"NATIVE_AUTHORED_BODY_WINDOW")
 local okay,why=self:Assign(unit,plate)
 if not okay then self:Queue(unit,plate,why) end
 local current=self.byUnit[unit];local hit=current and current.lease and current.lease.hit
 if okay and hit and hit.mode~="PASSIVE_NATIVE_REGION" then self.bodyPromotionSuccesses=(self.bodyPromotionSuccesses or 0)+1;return true end
 if hit and hit.mode=="PASSIVE_NATIVE_REGION" then hit.promotionFailure=why or hit.passiveReason or "AUTHORED_REACQUISITION_DEFERRED" end
 return false
end
function N:PromotePassiveBodies(now)
 if S:InCombat() then return end
 local examined,probes=0,0
 while examined<#self.pool and probes<4 do
  self.bodyPromotionCursor=(self.bodyPromotionCursor or 0)%math.max(1,#self.pool)+1
  local v=self.pool[self.bodyPromotionCursor];examined=examined+1
  local hit=v and v.lease and v.lease.hit
  if hit and hit.mode=="PASSIVE_NATIVE_REGION" and not v.retiring and now>=(hit.promotionProbeAt or 0) then
   probes=probes+1;hit.promotionProbeAt=now+1
   self:PromotePassiveBody(v,"LEGAL_OUT_OF_COMBAT_WINDOW")
  end
 end
end
function N:NativeHitChanged(v,setup)
 local r=v.lease;local h=r and r.hit
 if not h or not h.displaced or self.hitWriting then return end
 if v.retiring then
  -- A combat handback may be waiting for the native hit-layout window. The
  -- completed native callback has just replaced our anchors. Finish retirement
  -- now, before that window closes and before the pooled controller is painted
  -- for its successor. Tick-only cleanup kept old cards alongside native art.
  local receipt=h.monitor.nativeReceipt
  if receipt and receipt.serial==h.monitor.serial then self:Release(v) end
  return
 end
 if h.mode=="PASSIVE_NATIVE_REGION" then
  local receipt=h.monitor.nativeReceipt
  if not receipt or receipt.uf~=r.uf or receipt.unit~=r.unit then return end
  if #receipt.points==0 then r.conflict="NATIVE_HIT_POLICY_NO_REGION";v.inputStatus=r.conflict;self:Release(v);return end
  h.nativeReceipt=receipt;h.original=receipt.points;h.serial=receipt.serial;h.displaced=nil
  -- A later native layout can reopen the documented write window. Retire
  -- the compact constraint graph through its ordinary detached reset before
  -- taking a new full-card lease in that same actual permission window.
  if self:PromotePassiveBody(v,"COMPLETED_NATIVE_LAYOUT_WINDOW") or v.lease~=r or v.retiring then return end
  if not self:FitPassiveHitVisual(v,r,v.rangeVisual) then self:RetirePassiveGeometry(v) end
  return
 end
 local current=self:HitGuard(v,r,true)
 if not self:HitIdentity(v,r,current,true) then return end
 local expected=canonicalNativeHit(r,setup,current)
 local actual
 if h.mode=="OBSERVED_NATIVE_LEASE" then
  local receipt=h.monitor.nativeReceipt
  if receipt and receipt.serial==h.monitor.serial and receipt.uf==r.uf and receipt.unit==r.unit then actual=receipt.points;h.nativeReceipt=receipt end
 else actual=readHitPoints(r.plate,current,"NATIVE_UPDATE") end
 -- Only a completed native layout callback with its exact public anchor
 -- contract can provide a new snapshot. A direct or nested foreign writer
 -- remains a boundary; maintenance never recaptures arbitrary current points.
 if not current() or not sameHitPoints(expected,actual) or not self:HitIdentity(v,r,current,true) then return end
 local quiet=h.suspended or h.hidePending
 h.original=actual;h.serial=h.monitor.serial;h.requested=nil;h.attempted=nil;h.aligned=nil;h.displaced=nil
 if h.mode=="OBSERVED_NATIVE_LEASE" then
  h.observedPoints=actual;h.observedSerial=h.serial;h.writeUncertain=nil;h.observation="COMPLETED_NATIVE_LAYOUT"
 end
 if #actual==0 then r.conflict="NATIVE_HIT_POLICY_NO_REGION";v.inputStatus=r.conflict;self:Release(v);return end
 if quiet then
  h.suspended=true;h.restored=true;h.hidePending=nil;v.inputStatus="NATIVE_HIT_QUIET_NATIVE"
  self:Visibility(v);return
 end
 local okay,why=self:AlignHitPoints(v,r)
 if not okay and v.lease==r then v.inputStatus=why;self:Fallback(v.unit,why);self:Release(v) end
end
function N:CheckHitPoints(v)
 local r=v.lease;local h=r and r.hit
 if not h then return true end
 if h.mode=="PASSIVE_NATIVE_REGION" then
  if self:PassiveHitCurrent(v,r) then return true end
  v.inputStatus="NATIVE_HIT_NEWER_OWNER";r.conflict=v.inputStatus
  self:RecordInputLifecycle(v,r,v.inputStatus,{phase="CHECK",stage="PASSIVE_NATIVE_RECEIPT_CHANGED"})
  self:Fallback(v.unit,v.inputStatus);return false,v.inputStatus
 end
 local current=self:HitGuard(v,r,true)
 local actual,stage,index,key
 if self:HitIdentity(v,r,current,true) then
  if h.mode=="OBSERVED_NATIVE_LEASE" then actual,stage=self:ObservedHitPoints(v,r,current)
  else actual,stage,index,key=readHitPoints(r.plate,current,"CHECK") end
 else stage="IDENTITY_CHANGED" end
 if current() and not h.displaced and h.monitor.serial==h.serial
  and (h.aligned and not h.restored and sameHitPoints(actual,h.requested) or h.suspended and sameHitPoints(actual,h.original))
  and self:HitIdentity(v,r,current,true) then if not h.restorePendingSince then h.lifecycleIncident=nil end;return true end
 v.inputStatus=actual and "NATIVE_HIT_NEWER_OWNER" or "NATIVE_HIT_READBACK_UNAVAILABLE"
 if actual then r.conflict=v.inputStatus end
 self:RecordInputLifecycle(v,r,v.inputStatus,{phase="CHECK",stage=stage or v.inputStatus,index=index,field=key})
 self:Fallback(v.unit,v.inputStatus)
 return false,v.inputStatus
end
function N:RestoreHitPoints(v,r)
 local h=r.hit;if not h then return true end
 local current=self:HitGuard(v,r,false)
 local function debt(reason,stage,index,key)
  v.inputStatus=reason;h.restorePendingSince=h.restorePendingSince or S:Now();h.restorePendingReason=reason
  self:RecordInputLifecycle(v,r,reason,{phase="RESTORE",stage=stage or reason,index=index,field=key})
  return false
 end
 local function resolved(reason)
  h.restored=true;h.restorePendingSince=nil;h.restorePendingReason=nil;h.lifecycleIncident=nil;v.inputStatus=reason
  return true
 end
 if h.mode=="PASSIVE_NATIVE_REGION" then
  -- This mode never writes a native hit anchor or creates engine references
  -- to the custom frame. Preserve a later external reference if one is observed.
  for key,method in pairs(h.monitor.methods) do
   if field(r.plate,key)~=method then return debt("NATIVE_HIT_PASSIVE_OBSERVER_CHANGED") end
  end
  local actual,stage=currentNativeOrPublicHit(r,current)
  if not actual or not current() then return debt("NATIVE_HIT_PASSIVE_HANDOFF_UNOBSERVED",stage) end
  for _,point in ipairs(actual) do
   if point.relativeTo==v.frame then return debt("NATIVE_HIT_NEWER_OWNER_REFERENCES_BODY") end
  end
  return resolved("NATIVE_INPUT_UNMODIFIED_PASSIVE_RELEASE")
 end
 if h.mode=="OBSERVED_NATIVE_LEASE" then
  local actual,stage=self:ObservedHitPoints(v,r,current)
  if not current() then return debt("NATIVE_HIT_RESTORE_OBSERVATION_UNAVAILABLE",stage) end
  if not h.displaced and not h.writeUncertain and h.monitor.serial==h.serial and sameHitPoints(actual,h.original) then
   -- Permission may close between preparation and the first setter. A
   -- still-current native receipt proves no inverse is needed in that case;
   -- do not retain a staged full card over an unchanged compact native area.
   return resolved("NATIVE_HIT_ORIGINAL_SUBMISSION_RETAINED")
  end
  -- A failed setter may have committed before it failed. While all writers
  -- remain observed and the exact same native owner is current, the captured
  -- native inverse is safe to submit even if that attempted completion was
  -- unavailable. Never recycle or hide the referenced body before completion.
  local methods=true
  for key,method in pairs(h.monitor.methods) do if field(r.plate,key)~=method then methods=false end end
  local own=h.attempted and not h.restored and not h.displaced and h.monitor.serial==h.serial
   and methods and self:HitIdentity(v,r,current,false)
  if own then
   local written,why=self:WriteHitPoints(v,r,h.original,current,false)
   if not written then return debt("NATIVE_HIT_RESTORE_DEFERRED",why or "OBSERVED_INVERSE_UNCONFIRMED") end
   return resolved("NATIVE_HIT_RESTORE_SUBMISSION_OBSERVED")
  end
  if not actual then return debt("NATIVE_HIT_RESTORE_OBSERVATION_UNAVAILABLE",stage) end
  for _,entry in ipairs(actual) do if entry.relativeTo==v.frame then return debt("NATIVE_HIT_NEWER_OWNER_REFERENCES_BODY") end end
  return resolved("NATIVE_HIT_NEWER_OWNER_RETAINED")
 end
 -- Reading a successor's current anchors can prove this body is no longer
 -- referenced; it grants no permission to write the old inverse to that owner.
 local actual,stage,index,key
 if current() and S:Frame(r.plate,false) and current() then actual,stage,index,key=readHitPoints(r.plate,current,"RESTORE") else stage="IDENTITY_CHANGED" end
 if not actual or not current() then return debt("NATIVE_HIT_RESTORE_READBACK_UNAVAILABLE",stage,index,key) end
 local own=h.attempted and not h.restored and not h.displaced and h.monitor.serial==h.serial and sameHitPoints(actual,h.requested)
 if not own then
  -- A newer owner may deliberately retain a reference to this owned body.
  -- Do not reparent/reuse it underneath that reference or overwrite its points.
  for _,entry in ipairs(actual) do if entry.relativeTo==v.frame then return debt("NATIVE_HIT_NEWER_OWNER_REFERENCES_BODY") end end
  return resolved("NATIVE_HIT_NEWER_OWNER_RETAINED")
 end
 local written,why=self:WriteHitPoints(v,r,h.original,current,false)
 if not written then return debt("NATIVE_HIT_RESTORE_DEFERRED",why) end
 return resolved("NATIVE_HIT_RESTORED")
end
function N:HitDemand(v,visible)
 local r=v.lease;local h=r and r.hit
 if not h then return true end
 if h.mode=="PASSIVE_NATIVE_REGION" then
  -- Concealing Mirage artwork cannot conceal Blizzard's still-live hit area.
  -- Hand presentation back to Blizzard when this card has no contextual demand.
  if not visible then
   return false,"NATIVE_HIT_PASSIVE_QUIET_NATIVE"
  end
  return self:PassiveHitCurrent(v,r),"NATIVE_HIT_PASSIVE_RECEIPT_UNAVAILABLE"
 end
 if not visible then
  if not self:RestoreHitPoints(v,r) then h.hidePending=true;return false,"NATIVE_HIT_HIDE_DEFERRED" end
  h.suspended=true;h.aligned=nil;h.hidePending=nil;v.inputStatus="NATIVE_HIT_QUIET_NATIVE";return true
 end
 if h.suspended then
  -- The previous quiet presentation already returned native anchors. A new
  -- combat reveal may no longer have the source callback's write window.
  -- Detect that before staging a body or creating an uncertain write receipt;
  -- the caller can safely reacquire the unchanged native envelope instead.
  local allowed,state=value(r.plate,"CanChangeHitTestPoints","boolean")
  if state~="KNOWN" then return false,"NATIVE_HIT_PERMISSION_UNAVAILABLE" end
  if not allowed then return false,"NATIVE_HIT_PERMISSION_DEFERRED" end
  h.requested=nil;h.attempted=nil;h.restored=nil;h.suspended=nil
  return self:AlignHitPoints(v,r)
 end
 h.hidePending=nil
 return true
end
function N:Initialize()
 if not R:Qualified() then self.status="UNQUALIFIED_CLIENT";return false end
 self:ObserveNativeDriver()
 if S:InCombat() and not self.holder then self.status="SETUP_COMBAT_DEFERRED";return false end
 if not self.holder then self.holder=CreateFrame("Frame",nil,UIParent);self.holder:Hide();S:Passive(self.holder) end
 if not self.surface then
  local f=CreateFrame("Frame",nil,UIParent);f:SetSize(1,1);f:Hide();S:Passive(f)
  self.surface={id="Nameplates.world",module="Nameplates",frame=f,editable=false,security="SECURE_PREDECLARED",groups={combat=true},fallback="PRESERVE",reworkProvider=self}
  M.CVE:Register(self.surface)
 end
 if not S:InCombat() then
  local cfg=config();local limit=capacity()
  -- Suppressed categories use lightweight holders, not a full card/aura pool.
  -- This lets a crowded friendly hub remain filtered without consuming the
  -- authored full-card cap or manufacturing fallback cards for excess friends.
  for i=#self.filteredPool+1,80 do
   local f=CreateFrame("Frame",nil,UIParent);S:Passive(f);f:SetSize(1,1);f:Hide()
   self.filteredPool[i]={frame=f,generation=0,filterOnly=true,poolSlot=i}
  end
  for i=#self.pool+1,limit do
   local v=V:Create();v.poolSlot=i;self.pool[i]=v
   v.raid=v.frame:CreateTexture(nil,"OVERLAY");v.raid:SetSize(18,18);v.raid:SetPoint("RIGHT",v.frame,"LEFT",-19,0);v.raid:Hide()
   if v.name.SetWordWrap then v.name:SetWordWrap(false) end
   if v.name.SetMaxLines then v.name:SetMaxLines(1) end
   V:Layout(v,cfg)
   -- Prebuild native-owned, custom-painted aura containers before combat.
   if cfg.cardAuras then V:EnsureAuras(v,cfg) end
   if M.WorldCombatText and M.WorldCombatText.PreparePlate then M.WorldCombatText:PreparePlate(v) end
  end
  for _,v in ipairs(self.pool) do if not v.retiring then
   if M.WorldCombatText and M.WorldCombatText.PreparePlate and (not v.combatText or not v.combatText.ready) then
    M.WorldCombatText:PreparePlate(v)
   end
   if cfg.cardAuras then self:PrepareDetails(v) end
  end end
 end
 self.status="READY";return true
end
local function captureAlpha(r,o)
 if not o then return true end
 if not S:Frame(o,false) then return false end
 local a,state=value(o,"GetAlpha","number")
 if state~="KNOWN" or type(field(o,"SetAlpha"))~="function" then return false end
 r.alpha[#r.alpha+1]={object=o,original=a};return true
end
local function captureParent(r,o,destination)
 if not o then return true end
 if not legal(o) then return false end
 local p,state=value(o,"GetParent")
 if state~="KNOWN" or type(field(o,"SetParent"))~="function" then return false end
 r.parents[#r.parents+1]={object=o,parent=p,destination=destination};return true
end
local function captureFriendlyBody(r,key)
 local object=field(r.uf,key)
 -- Use the source-pinned branch, not an unrestricted descendant traversal.
 -- An unavailable/replaced native body keeps complete native presentation.
 if not object or not legal(object) then return false end
 local parent,state=value(object,"GetParent")
 local expected=r.uf
 if key=="selectionHighlight" or key=="aggroFlash" then expected=field(field(r.uf,"HealthBarsContainer"),"healthBar") end
 if state~="KNOWN" or not expected or parent~=expected or not captureAlpha(r,object) then return false end
 local receipt=r.alpha[#r.alpha];receipt.bodyKey=key;receipt.parent=parent
 r.nativeBodies[key]=object
 return true
end
function N:Take(v,plate,unit,friendly)
 self.acquisitionAttempts=(self.acquisitionAttempts or 0)+1
 local uf=field(plate,"UnitFrame")
 if not S:Frame(uf,false) then self.acquisitionProbe="NATIVE_CONTROLLER_MISSING";return false,"NATIVE_PLATE_PENDING" end
 if nativeUnit(plate)~=unit then self.acquisitionProbe="NATIVE_UNIT_IDENTITY_PENDING";return false,"NATIVE_PLATE_PENDING" end
 -- Keep engine geometry, mouse flags and secure selection untouched. The
 -- native hit-anchor property has its own documented permission predicate;
 -- the base's protection flag cannot substitute for that exact capability.
 -- Forbidden bases still fail, and each mutation target retains its own
 -- combat protection check plus the normal engine setter/readback checks.
 if not S:Frame(plate,false) then self.acquisitionProbe="NATIVE_BASE_UNAVAILABLE";return false,"CONTROL_COMBAT_OR_FORBIDDEN" end
 if not legal(uf) then self.acquisitionProbe="NATIVE_CONTROLLER_NOT_LEGAL";return false,"CONTROL_COMBAT_OR_FORBIDDEN" end
 if not legal(v.frame) then self.acquisitionProbe="CUSTOM_CARD_NOT_LEGAL";return false,"CONTROL_COMBAT_OR_FORBIDDEN" end
 if not v.filterOnly and type(V.PreparedBodyReady)=="function" then
  local okay,why=V:PreparedBodyReady(v)
  if not okay then self.acquisitionProbe=why;return false,why end
 end
 if value(uf,"GetParent")~=plate then return false,"NATIVE_CONTROLLER_PARENT_UNAVAILABLE" end
 local cfg=config()
 if not v.filterOnly and cfg.cardAuras and (not M.ManagedAuraRails:Ready(v.harmful) or not M.ManagedAuraRails:Ready(v.helpful)) then
  if not S:InCombat() then V:EnsureAuras(v,cfg) end
  if not M.ManagedAuraRails:Ready(v.harmful) then self.acquisitionProbe="HARMFUL_AURA_INITIALIZATION_UNAVAILABLE";return false,"AURA_CHANNEL_UNAVAILABLE_KEEP_NATIVE" end
  if not M.ManagedAuraRails:Ready(v.helpful) then self.acquisitionProbe="HELPFUL_AURA_INITIALIZATION_UNAVAILABLE";return false,"AURA_CHANNEL_UNAVAILABLE_KEEP_NATIVE" end
 end
 if not v.filterOnly and cfg.cardCast and (type(UnitCastingDuration)~="function" or type(UnitChannelDuration)~="function" or type(v.castBar.SetTimerDuration)~="function") then
  return false,"CAST_CHANNEL_UNAVAILABLE_KEEP_NATIVE"
 end
 local r={plate=plate,uf=uf,unit=unit,alpha={},parents={},dependencies={}}
 if not v.filterOnly then
  local okay,why=self:PrepareHitPoints(v,r)
  if not okay then self.acquisitionProbe=why;return false,why end
 end
 if not captureAlpha(r,uf) then self.acquisitionProbe="CONTROLLER_ALPHA_UNAVAILABLE";return false,"NATIVE_ALPHA_UNAVAILABLE" end
 if friendly then
  local name=field(uf,"name")
  if v.filterOnly then
   local ready,why=self:AmbientLabelReady(plate,uf,name)
   if not ready then self.acquisitionProbe=why;return false,"AMBIENT_NATIVE_LABEL_PENDING" end
   if not self:WatchAmbientName(plate,uf,name) then self.acquisitionProbe="NATIVE_LABEL_OBSERVER_UNAVAILABLE";return false,"AMBIENT_NATIVE_LABEL_PENDING" end
   r.ambientName=name
  end
  r.nativeBodies={};r.friendlyController=r.alpha[1]
  r.friendlyController.friendlyController=true;r.friendlyController.passive=v.filterOnly==true
  for _,key in ipairs(r.ambientName and ambientBodyKeys or friendlyBodyKeys) do
   if not captureFriendlyBody(r,key) then self.acquisitionProbe="FRIENDLY_BODY_UNAVAILABLE_"..key;return false,"NATIVE_CONTROL_SETUP_UNAVAILABLE" end
  end
 elseif not captureAlpha(r,field(uf,"selectionHighlight")) then self.acquisitionProbe="SELECTION_ALPHA_UNAVAILABLE";return false,"NATIVE_ALPHA_UNAVAILABLE" end
 -- The pooled UnitFrame must remain visible under the engine plate: the native
 -- selection code uses that live controller. Only its stock mouse-enabled aura
 -- presentation is parked. Admitted hostile/neutral cards conceal the stock
 -- controller. A selected friendly uses ordinary full-card custody. Ambient
 -- player labels keep their controller and native input without opacity
 -- changes; only their body artwork and aura presentation are concealed.
 -- Keep native special widgets and soft-target input cues on the engine base.
 for _,key in ipairs({"AurasFrame","WidgetContainer","SoftTargetFrame"}) do
  if not r.ambientName or key=="AurasFrame" then
  if not captureParent(r,field(uf,key),key=="AurasFrame" and self.holder or plate) then self.acquisitionProbe="NATIVE_PARENT_UNAVAILABLE_"..key;return false,"NATIVE_CONTROL_SETUP_UNAVAILABLE" end
  local last=r.parents[#r.parents];if last and last.object==field(uf,key) then last.key=key end
  end
 end
 for _,key in ipairs({"AurasFrame","WidgetContainer","SoftTargetFrame"}) do r.dependencies[key]=field(uf,key) end
 for _,a in ipairs(r.alpha) do if not self:Watch(a.object) then return false,"SUPPRESSION_GUARD_UNAVAILABLE" end end
 for _,p in ipairs(r.parents) do if not self:Watch(p.object) then return false,"PARENT_GUARD_UNAVAILABLE" end end
 v.lease=r;v.unit=unit;v.generation=v.generation+1
 if not v.filterOnly and v.relativeSource then
  local generation=v.generation
  v.preparedInvalidated=function()
   if v.lease~=r or v.generation~=generation or v.releasing or v.preparedParking then return end
   r.conflict="OWNED_BODY_LAYOUT_CHANGED"
   self:Fallback(v.unit,r.conflict);self:Release(v)
  end
 end
 -- A full-card slot can return through friendly parking as well as Release.
 -- A successor never inherits the previous occupant's refresh/backoff debt.
 v.auraRefresh=nil;v.auraRefreshFailures=nil;v.auraRefreshRetryAt=nil;v.auraRefreshNextAt=nil;v.auraRefreshLastAt=nil
 if v.detailIssues then v.detailIssues.auraRefresh=nil end
 self.byUnit[unit]=v;self.byPlate[plate]=v
 for _,a in ipairs(r.alpha) do self.byObject[a.object]=v end
 for _,p in ipairs(r.parents) do self.byObject[p.object]=v end
 if r.ambientName then self.byObject[r.ambientName]=v end
 self.writing=true
 local function current() return v.lease==r and self:Current(v) and v.lease==r end
 local function card(method,...)
  if not current() or not legal(v.frame) or not current() then return false end
  local wrote=call(v.frame,method,...)
  return wrote and current() and legal(v.frame) and current()
 end
 -- A legal prebuilt card can become unavailable as SetParent invokes native
 -- callbacks. Recheck the actual target after each mutation; never issue a
 -- raw Hide/alpha write after a denied or newly protected parent operation.
 local ok=card("SetParent",plate) and card("ClearAllPoints")
 -- Keep the authored card location. Its native input anchors follow this
 -- exact passive body, including later range/selection scale changes.
 ok=ok and card("SetPoint","CENTER",plate,"CENTER",0,offset())
 local level=value(plate,"GetFrameLevel","number")
 if level then ok=ok and card("SetFrameLevel",level+5) end
 ok=value(v.frame,"GetParent")==plate and ok
 self.writing=nil
 -- Category filtering affects presentation. Native world targeting retains
 -- its own engine policy; no hidden-input ownership is claimed by Mirage.
 if v.filterOnly then
  v.visibleDemand=false;ok=ok and card("Hide")
 else ok=ok and card("SetAlpha",0) and card("Hide") end
 -- Subscribe native-owned rails before concealing their originals.
 local complete=ok and current()
 if not complete then self.acquisitionProbe="CUSTOM_PARENT_UNCONFIRMED"
 elseif not v.filterOnly and not self:Auras(v) then complete=false;self.acquisitionProbe="NATIVE_AURA_ASSIGNMENT_UNCONFIRMED" end
 if complete then
  local aligned,why=self:AlignHitPoints(v,r)
  if not aligned then complete=false;self.acquisitionProbe=why or v.inputStatus or "NATIVE_HIT_ALIGNMENT_UNCONFIRMED" end
 end
 if complete and not self:Suppress(v,true) then complete=false;self.acquisitionProbe="STOCK_PRESENTATION_UNCONFIRMED" end
 if not complete or not current() then
  if v.lease==r then self:Release(v) end
  return false,"TAKEOVER_INCOMPLETE"
 end
 if not v.filterOnly then self:InputSucceeded(unit) end
 if not v.filterOnly and M.WorldCombatText and M.WorldCombatText.AttachPlate then M.WorldCombatText:AttachPlate(v) end
 return true
end
function N:Dependencies(v)
 local r=v.lease;if not r then return false end
 for _,key in ipairs({"AurasFrame","WidgetContainer","SoftTargetFrame"}) do
  local object=field(r.uf,key)
  if r.ambientName and key~="AurasFrame" then r.dependencies[key]=object
  elseif object and object~=r.dependencies[key] then
   -- Retire the replaced child before watching its successor. Keeping every
   -- old receipt made a reused AuraFrame look like permanent owner conflict.
   local previous=r.dependencies[key]
   for i=#r.parents,1,-1 do
    local receipt=r.parents[i]
    if receipt.object==previous then
     local parent,state=value(previous,"GetParent")
     if state~="KNOWN" then v.dirty=true;return false end
     if parent==receipt.destination then
      if not legal(previous) or not call(previous,"SetParent",receipt.parent) or value(previous,"GetParent")~=receipt.parent then v.dirty=true;return false end
     end
     if self.byObject[previous]==v then self.byObject[previous]=nil end
     table.remove(r.parents,i)
    end
   end
   local destination=key=="AurasFrame" and self.holder or r.plate
   if not captureParent(r,object,destination) or not self:Watch(object) then v.dirty=true;self.status="LATE_CONTROL_SETUP_PENDING";return false end
   r.parents[#r.parents].key=key
   r.dependencies[key]=object;self.byObject[object]=v;v.dirty=true
  end
 end
 return true
end
function N:Suppress(v,parents)
 if not self:Current(v) then return false end
 local r=v.lease;if r.conflict then return false end
 if r.ambientName then
  local ready,why=self:AmbientLabelReady(r.plate,r.uf,r.ambientName)
  if not ready then self:RetireAmbientLabel(v,why);return false end
 end
 local complete=true;self.writing=true
 for _,a in ipairs(r.alpha) do
  if r.nativeBodies and (v.lease~=r or not self:Current(v)) then self.writing=nil;return false end
  if a.passive then
   -- Do not even reapply a remembered native alpha to an ambient controller.
  elseif legal(a.object) then
   local desired=a.desired or 0
   local alpha,state=value(a.object,"GetAlpha","number")
   if state~="KNOWN" then complete=false
   elseif alpha~=desired then
    a.written=call(a.object,"SetAlpha",desired)
    complete=value(a.object,"GetAlpha","number")==desired and a.written and complete
   end
  else complete=false end
 end
 if r.nativeBodies and (v.lease~=r or not self:Current(v)) then self.writing=nil;return false end
 if parents then
  for _,p in ipairs(r.parents) do
   if legal(p.object) then
    local current=value(p.object,"GetParent")
    if current~=p.destination then
     if current~=p.parent then r.conflict="EXTERNAL_PARENT_CHANGE";complete=false
     else p.written=call(p.object,"SetParent",p.destination);complete=value(p.object,"GetParent")==p.destination and p.written and complete end
    else p.written=true end
   else complete=false end
  end
 end
 self.writing=nil;v.dirty=not complete
 if r.ambientName and v.lease==r then
  local ready,why=self:AmbientLabelReady(r.plate,r.uf,r.ambientName)
  if not ready then self:RetireAmbientLabel(v,why);return false end
 end
 if r.nativeBodies and v.lease==r and self:Current(v) then self:RefreshFriendlyName(v,false) end
 return complete
end
function N:FriendlyNameMode(v)
 local r=v.lease;local a=r and r.friendlyController
 if not a then return true end
 local passive=v.filterOnly==true or v.admitted==false
 if a.passive==passive then return true end
 if not self:Current(v) or not legal(a.object) then return false end
 local alpha,state=value(a.object,"GetAlpha","number")
 if state~="KNOWN" then return false end
 self.writing=true
 local complete=true
 if passive then
  -- The body has remained masked throughout the selected card's lifetime.
  -- Return only the controller alpha we still own; never Show/Hide or move
  -- its native name, nor override a newer owner's opacity.
  if alpha==(a.desired or 0) then
   complete=call(a.object,"SetAlpha",a.original) and value(a.object,"GetAlpha","number")==a.original
  else a.original=alpha end
 else
  a.original=alpha
  complete=call(a.object,"SetAlpha",a.desired or 0) and value(a.object,"GetAlpha","number")== (a.desired or 0)
 end
 self.writing=nil
 if not complete or v.lease~=r or not self:Current(v) then v.dirty=true;return false end
 a.passive=passive;a.written=not passive
 return true
end
function N:Threat(v)
 local generation,lease,unit=v.generation,v.lease,v.unit
 local function current() return v.generation==generation and v.lease==lease and v.unit==unit and self.byUnit[unit]==v and not v.retiring end
 if not current() or not self:Current(v) or not current() then return false end
 local threat=S:Public(UnitThreatSituation,"number","player",unit)
 if not current() then return false end
 local aggro=threat~=nil and threat>=2 and threat<=3 or false
 if v.aggro~=aggro then
  v.aggro=aggro
  for _,edge in ipairs(v.aggroEdges or {}) do
   if not current() then return false end
   edge:SetShown(aggro)
  end
 end
 return current()
end
function N:Metadata(v)
 local generation,lease,unit=v.generation,v.lease,v.unit
 local function current() return v.generation==generation and v.lease==lease and v.unit==unit and self.byUnit[unit]==v and not v.retiring end
 if not current() or not self:Current(v) or not current() then return false end
 local cfg=config();local name,status=S:Public(UnitName,"string",v.unit)
 if not current() then return false end
 -- Long, delayed or secret names are custom content states, never a reason to
 -- hand presentation back. A single clipped line keeps authored typography.
 v.namePending=status~="KNOWN"
 M.Visual:Name(v.name,v.unit,status=="KNOWN" and name:gsub("|","||") or "",v.relativeNameSize or cfg.nameSize)
 if not current() then return false end
 local nameColor,nameSource=(M.Visual.NameplateNameColor or M.Visual.ClassColor)(M.Visual,v.unit)
 if not current() then return false end
 v.name:SetTextColor(nameColor[1],nameColor[2],nameColor[3],1);v.nameColorSource=nameSource
 if status~="KNOWN" and type(UnitName)=="function" then
  local ok,opaque=pcall(UnitName,v.unit)
  if not current() then return false end
  if ok then v.namePending=not pcall(v.name.SetText,v.name,opaque) end
 end
 local level,ls=S:Public(UnitLevel,"number",v.unit)
 if not current() then return false end
 v.level:SetText(cfg.showLevel~=false and ls=="KNOWN" and (level<0 and "??" or tostring(level)) or "")
 local levelColor,levelSource=M.Visual.level,"LEGACY_LEVEL_PALETTE"
 if M.Visual.NameplateLevelColor then levelColor,levelSource=M.Visual:NameplateLevelColor(v.unit,level) end
 if not current() then return false end
 v.level:SetTextColor(levelColor[1],levelColor[2],levelColor[3],1);v.levelColorSource=levelSource
 v.separator:SetText(cfg.showLevel~=false and ls=="KNOWN" and "|" or "")
 v.selectedTarget,v.selectedFocus=self:Selection(v.unit)
 if not current() then return false end
 v.selection:SetText(v.selectedTarget and ">" or "")
 if v.focus then v.focus:SetText(v.selectedFocus and "F" or "") end
 if v.targetEdge then v.targetEdge:SetShown(v.selectedTarget==true) end
 if v.focusEdge then v.focusEdge:SetShown(v.selectedFocus==true) end
 local index,is=S:Public(GetRaidTargetIndex,"number",v.unit)
 if not current() then return false end
 if is=="KNOWN" and index>=1 and index<=8 and index%1==0 then
  v.raid:SetTexture("Interface\\TargetingFrame\\UI-RaidTargetingIcons")
  local column=(index-1)%4;local row=math.floor((index-1)/4)
  v.raid:SetTexCoord(column*.25,(column+1)*.25,row*.25,(row+1)*.25);v.raid:Show()
 else v.raid:Hide() end
 if not self:Threat(v) then return false end
 if v.status then
  v.status:SetText("")
  if not v.relativeLayout and not S:InCombat() then v.name:SetWidth(math.max(40,(cfg.cardWidth or 240)-53)) end
 end
 return current()
end
function N:Auras(v)
 local generation,unit,lease=v.generation,v.unit,v.lease
 local function current() return v.generation==generation and v.unit==unit and v.lease==lease and self:Current(v) end
 if not current() then return false end
 local cfg=config()
 if not cfg.cardAuras then
  local debt=v.auraClearDebt
  if debt and debt.lease==lease and debt.generation==generation and S:Now()<debt.at then return false end
  local a,ar,b,br=true,nil,true,nil
  if v.harmful then a,ar=M.ManagedAuraRails:Clear(v.harmful) end
  if not current() then return false end
  if v.helpful then b,br=M.ManagedAuraRails:Clear(v.helpful) end
  if not current() then return false end
  local cleared=a==true and b==true
  v.auraClearDebt=not cleared and {lease=lease,generation=generation,at=S:Now()+.5} or nil
  v.auraRefresh=nil;v.auraRefreshFailures=nil;v.auraRefreshRetryAt=nil;v.auraRefreshNextAt=nil;v.auraRefreshLastAt=nil
  v.auras=cleared and "DISABLED_BY_PROFILE" or "NATIVE_AURA_CLEAR_PENDING"
  self:Detail(v,"auras",cleared,not a and ar or br);self:Detail(v,"auraRefresh",true);return cleared
 end
 v.auraClearDebt=nil
 if not v.harmful or not v.helpful then
  if not S:InCombat() then V:EnsureAuras(v,cfg) end
 end
 if not current() then return false end
 local a,ar=M.ManagedAuraRails:Assign(v.harmful,unit,true)
 if not current() then return false end
 local b,br=M.ManagedAuraRails:Assign(v.helpful,unit,true)
 if not current() then return false end
 v.auras=a and b and "CUSTOM_NATIVE_CONTAINERS" or "AURA_SETUP_PENDING"
 self:Detail(v,"auras",a and b,not a and ar or br)
 return a and b
end
local function auraRefreshIdentity(v,request)
 return request and v.lease==request.lease and v.generation==request.generation and v.unit==request.unit
  and v.harmful==request.rail and not v.retiring and not v.filterOnly and v.admitted~=false
end
local function auraRefreshOwner(self,v,request)
 return auraRefreshIdentity(v,request) and self:Current(v)
end
function N:QueueAuraRefresh(v,reason,now)
 if not self.active or not config().cardAuras or not v or v.filterOnly or v.admitted==false or not self:Current(v)
  or not v.harmful or v.harmful.enabled~=true then return end
 local request=v.auraRefresh
 if not auraRefreshOwner(self,v,request) then
  request={lease=v.lease,generation=v.generation,unit=v.unit,rail=v.harmful}
  v.auraRefresh=request
 end
 request.reason=reason
 request.at=math.max(now or S:Now(),v.auraRefreshRetryAt or 0)
 return request
end
function N:QueueAuraAlias(alias,reason)
 if alias~="target" and alias~="focus" and alias~="mouseover" then return end
 local plate=plateFor(alias)
 local v=plate and self.byPlate[plate]
 if not v or not self:Current(v) or S:Public(UnitIsUnit,"boolean",v.unit,alias)~=true then return end
 return self:QueueAuraRefresh(v,reason),v
end
function N:RefreshAuraOwner(v,request,now)
 if not config().cardAuras or not auraRefreshOwner(self,v,request) then
  if v.auraRefresh==request then v.auraRefresh=nil end
  return false
 end
 local function current() return config().cardAuras and auraRefreshOwner(self,v,request) end
 self.auraRefreshAttempts=(self.auraRefreshAttempts or 0)+1
 local okay,reason=M.ManagedAuraRails:Refresh(request.rail,request.unit,current)
 if not current() then return true end -- the submitted attempt still consumes this Tick's budget
 self.lastAuraRefresh=reason or "NATIVE_AURA_REFRESH_UNAVAILABLE"
 v.auraRefreshLastAt=now
 if okay then
  v.auraRefresh=nil;v.auraRefreshFailures=nil;v.auraRefreshRetryAt=nil
  v.auraRefreshNextAt=now+1
  self.auraRefreshSubmitted=(self.auraRefreshSubmitted or 0)+1
  self:Detail(v,"auraRefresh",true)
 else
  v.auraRefreshFailures=math.min(5,(v.auraRefreshFailures or 0)+1)
  local retryAt=now+math.min(8,.5*2^(v.auraRefreshFailures-1))
  v.auraRefreshRetryAt=retryAt;v.auraRefreshNextAt=retryAt
  request.at=retryAt;v.auraRefresh=request
  self.auraRefreshFailed=(self.auraRefreshFailed or 0)+1
  self:Detail(v,"auraRefresh",false,reason)
 end
 return true
end
function N:ReconcileAuras(now)
 if not self.active or not config().cardAuras or not M.ManagedAuraRails.Refresh then return end
 local count=#self.pool
 if count==0 then return end
 -- At most four native harmful refreshes per existing 250 ms Tick. Two are
 -- reserved for the ordinary sweep when priority events remain busy; unused
 -- priority capacity is borrowed. Healthy helpful rails are never rescanned.
 -- Native events still update immediately; this bounded sweep only repairs
 -- missed/alias-only delivery and same-handle native incarnation changes.
 local budget=4
 local function sweep(priority,limit)
  local key=priority and "auraPriorityCursor" or "auraRefreshCursor"
  local start=self[key] or 1
  local used=0
  for step=0,count-1 do
   local index=(start+step-1)%count+1
   local v=self.pool[index]
   local request=v.auraRefresh
   if request and not auraRefreshIdentity(v,request) then
    v.auraRefresh=nil;v.auraRefreshFailures=nil;v.auraRefreshRetryAt=nil;v.auraRefreshNextAt=nil;v.auraRefreshLastAt=nil
    if v.detailIssues then v.detailIssues.auraRefresh=nil end
    request=nil
   end
   -- Cheap authored state/due checks precede native ancestry validation.
   -- An idle 80-slot pool must not add 160 full owner probes every Tick.
   local due=not v.filterOnly and v.admitted~=false and v.visibleDemand==true
    and (not v.auraRefreshLastAt or now>=v.auraRefreshLastAt+.25)
    and now>=(v.auraRefreshRetryAt or 0)
   if priority then due=due and request~=nil and now>=(request.at or 0)
   else due=due and (request~=nil or now>=(v.auraRefreshNextAt or 0)) end
   if due and self:Current(v) then
    request=request or self:QueueAuraRefresh(v,"BOUNDED_NATIVE_RECONCILE",now)
    if request and self:RefreshAuraOwner(v,request,now) then
     used=used+1;budget=budget-1;self[key]=index%count+1
     if used>=limit or budget==0 then break end
    end
   end
  end
 end
 sweep(true,2)
 if budget>0 then sweep(false,budget) end
end
-- Compact authored-state evidence is exported separately from Coverage's long
-- presentation summary. It does not query native frames or inspect aura data.
function N:AuraEvidenceReport()
 local owners,enabled,stable,unavailable,pending,quarantined,cleanup=0,0,0,0,0,0,0
 for _,v in pairs(self.byUnit) do
  if v.lease and not v.retiring and not v.filterOnly then
   owners=owners+1
   if v.auraRefresh then pending=pending+1 end
   for _,rail in ipairs({v.harmful or false,v.helpful or false}) do
    if rail then
     if rail.enabled then enabled=enabled+1 end
     if rail.stableHolder then stable=stable+1 end
     if rail.wrapperStatus=="HIDDEN_OR_UNREADABLE" then unavailable=unavailable+1 end
     if rail.wrapperQuarantined then quarantined=quarantined+1 end
     if rail.cleanupPending then cleanup=cleanup+1 end
    end
   end
  end
 end
 return "scope=CACHED_SUBSCRIPTIONS_NOT_AURA_CONTENT; binding=INCUMBENT_NAMEPLATE_UNIT; wrapper=PREPARED_VISIBLE_NATIVE_ENABLED_LIFETIME"
  .."; owners="..owners.."; enabled_rails="..enabled.."; stable_wrappers="..stable.."; wrapper_unavailable="..unavailable.."; pending_refresh="..pending
  .."; quarantined_wrappers="..quarantined.."; native_cleanup_pending="..cleanup
  .."; attempted="..(self.auraRefreshAttempts or 0).."; submitted="..(self.auraRefreshSubmitted or 0).."; failed="..(self.auraRefreshFailed or 0)
  .."; last="..(self.lastAuraRefresh or "NOT_REQUESTED").."; content_confirmation=NATIVE_RENDERING_REQUIRED"
end
function N:Cast(v,kind)
 if not config().cardCast then V:ClearCast(v);return false end
 local fn=kind=="channel" and UnitChannelDuration or UnitCastingDuration
 if type(fn)~="function" or type(v.castBar.SetTimerDuration)~="function" then V:ClearCast(v);v.castStatus="TIMER_UNAVAILABLE";return false end
 local ok,d=pcall(fn,v.unit)
 if not ok then v.castStatus="TIMER_UNAVAILABLE";return false end
 if S:Readable(d) and d==nil then return false end
 -- Only public lifecycle evidence can hold an otherwise idle selected plate.
 -- Opaque duration payloads are submitted to native consumers below, never
 -- reclassified as a public combat-state signal.
 if S:Readable(d) then v.castDemand=true end
 local direction=Enum and Enum.StatusBarTimerDirection
 local dir=direction and (kind=="channel" and direction.RemainingTime or direction.ElapsedTime)
 if dir==nil or not pcall(v.castBar.SetTimerDuration,v.castBar,d,Enum.StatusBarInterpolation and Enum.StatusBarInterpolation.Immediate,dir) then v.castStatus="TIMER_UNAVAILABLE";return false end
 local info=kind=="channel" and UnitChannelInfo or UnitCastingInfo
 local success,name,_,icon,startTime,endTime,tradeskill,arg7,arg8=false,nil,nil,nil
 if type(info)=="function" then success,name,_,icon,startTime,endTime,tradeskill,arg7,arg8=pcall(info,v.unit) end
 local label=kind=="channel" and "Channeling" or "Casting"
 if success then
  -- Text and texture APIs are documented opaque-value consumers. Never drop
  -- a legitimate cast icon merely because its payload cannot be inspected.
  local safe=name
  if S:Text(name) then safe=name:gsub("|","||") end
  if not pcall(v.castName.SetText,v.castName,safe) then v.castName:SetText(label) end
  if not pcall(v.castIcon.SetTexture,v.castIcon,icon) then v.castIcon:SetTexture(nil) end
 else v.castName:SetText(label);v.castIcon:SetTexture(nil) end
 local shield=arg8;if kind=="channel" then shield=arg7 end
 local color=M.Visual.cast
 if S:Readable(shield) and shield==true then color={.68,.68,.7} end
 M.UI:BeamColor(v.castBar,color[1],color[2],color[3],1)
 M.DurationDisplay:Bind(v,v.castClock,d,kind)
 v.castKind=kind;V:SetCastVisible(v,true)
 v.castStatus="CUSTOM_TIMER";return true
end
function N:RefreshCast(v)
 local generation,lease=v.generation,v.lease
 local function current() return v.generation==generation and v.lease==lease and self:Current(v) end
 if not current() then return end
 v.castStatus="IDLE"
 local casting=self:Cast(v,"cast")
 if not current() then return end
 local channeling=not casting and self:Cast(v,"channel")
 if not current() then return end
 if not casting and not channeling then v.castDemand=nil;V:ClearCast(v) end
 if not current() then return end
 self:Detail(v,"cast",v.castStatus~="TIMER_UNAVAILABLE",v.castStatus)
end
function N:Paint(v,metadata)
 if not self:Current(v) then return false,"NATIVE_PLATE_PENDING" end
 if v.filterOnly then return self:Visibility(v) end
 local free=legal(v.frame)
 if metadata and free and self:Metadata(v)==false then return false,"NATIVE_PLATE_PENDING" end
 V:Health(v);V:Power(v,metadata and free)
 if metadata and free then
  self:Auras(v)
  if not self:Current(v) then return false,"NATIVE_PLATE_PENDING" end
  self:RefreshCast(v)
 end
 if not self:Current(v) then return false,"NATIVE_PLATE_PENDING" end
 if metadata and free then
  v.paintRevision=self.configurationRevision
  self.fullPaints=(self.fullPaints or 0)+1
 end
 return self:Visibility(v)
end
function N:UnitDemand(v)
 if v.filterOnly or v.admitted==false then return false,"CATEGORY_FILTERED" end
 if v.selectedTarget then return true,"SELECTED_TARGET" end
 if S:Public(UnitIsFriend,"boolean","player",v.unit)==true then return false,"FRIENDLY_NOT_TARGET" end
 if v.selectedFocus then return true,"HOSTILE_FOCUS" end
 -- Classify admits these categories only with public hostile/neutral
 -- evidence. Their presentation follows the emitted native plate's lifetime,
 -- including idle with no target. Neither an encounter context nor another
 -- unit's target data is needed to keep an incumbent's debuffs visible.
 if v.category=="ENEMY" or v.category=="ENEMY_PLAYER" or v.category=="NEUTRAL" or v.category=="LESSER" then
  return true,"HOSTILE_OR_NEUTRAL_ALWAYS"
 end
 return false,"NO_PUBLIC_CATEGORY_DEMAND"
end
function N:Visibility(v)
 if not v.lease then return false end
 if not legal(v.frame) then
  v.presentationDeferred="OWNED_PRESENTATION_TARGET_NOT_LEGAL";self:Detail(v,"presentation",false,v.presentationDeferred)
  return false
 end
 if v.lease.ambientName then
  local r=v.lease
  local ready,why=self:AmbientLabelReady(r.plate,r.uf,r.ambientName)
  if not ready then self:RetireAmbientLabel(v,why);return false,"AMBIENT_NATIVE_LABEL_PENDING" end
  v.visibilityStatus="AMBIENT_NATIVE_LABEL_NATIVE_INPUT_UNCHANGED"
  v.visibleDemand=false
  return call(v.frame,"Hide")
 end
 if not v.filterOnly and type(V.PreparedBodyReady)=="function" then
  local okay,why=V:PreparedBodyReady(v)
  if not okay then self:Fallback(v.unit,why);self:Release(v);return false,why end
 end
 local input,reason=self:CheckHitPoints(v)
 if not input then self:Release(v);return false,reason end
 local nativeLease,generation=v.lease,v.generation
 local nameReady=self:FriendlyNameMode(v)
 -- A native setter/hook can recycle the controller and this owned pool slot.
 -- The old visibility request is complete; it has no custody of a successor.
 if v.lease~=nativeLease or v.generation~=generation then return true end
 if not nameReady then
  -- A deferred native-name handback cannot keep a deselected friendly card
  -- visible beside the new target. The owned card can retire independently.
  if (v.filterOnly or v.admitted==false) and legal(v.frame) then
   if M.Effects and M.Effects.CancelTransition then M.Effects:CancelTransition(self,v.frame,false) end
   call(v.frame,"SetAlpha",0);call(v.frame,"Hide");v.visibleDemand=false
  end
  return false,"FRIENDLY_NATIVE_NAME_HANDOFF_PENDING"
 end
 local snapshot=M.Store and M.Store:Snapshot();local now=S:Now();local cfg=config()
 local preference=M.ElementRules and M.ElementRules:Preference("Nameplates.world",snapshot,M.profile)
 local forced=M.state.edit or (M.state.revealUntil or 0)>now
 local denied=preference=="HIDE" or cfg.visibility=="Manual" and not forced
 local activity=M.ScopedActivity
 local general=activity and activity:Demand("PLATES",snapshot,now)
 local inspect=activity and (v.selectedTarget and (activity:Inspect("target",now) or activity.CastInspection and activity:CastInspection("TARGET",now))
  or v.selectedFocus and (activity:Inspect("focus",now) or activity.CastInspection and activity:CastInspection("FOCUS",now)))
 local selectedCast=(v.selectedTarget or v.selectedFocus) and v.castDemand==true
 local selectedUnit=v.selectedTarget or v.selectedFocus
 local unitDemand,unitReason=self:UnitDemand(v);v.unitDemandReason=unitReason
 local grouped=M.PresentationGroups and M.PresentationGroups:Enabled()
 if grouped then
  -- Selection/casting are already part of the shared group decision. A stale
  -- local inspection must not override flight-path idle or group retirement.
  inspect=false;selectedCast=false
  if general==nil then general=v.visibleDemand==true end
 end
 local visible=not v.filterOnly and v.admitted~=false and not denied and
  (forced or preference=="SHOW" or cfg.visibility=="Always" or general or inspect or selectedCast or selectedUnit or unitDemand)
 -- The aggregate encounter group can be quiet while hostile/neutral plates
 -- remain visible. Explicit user Manual/HIDE overrides still take precedence.
 if not grouped and self.surface and self.surface.desired=="HIDDEN" and not inspect and not selectedCast and not selectedUnit and not unitDemand and not forced and preference~="SHOW" and cfg.visibility~="Always" then visible=false end
 if M.state.cinematic or M.state.safe then visible=false end
 -- Initial login stays quiet while providers finish preparing their owned
 -- surfaces. No lease is released, and ordinary hostile idle policy resumes
 -- once the startup service observes meaningful activity.
 if M.StartupPresentation and M.StartupPresentation:IsQuiet() then visible=false end
 v.occlusionReason=nil
 if visible and M.DisplayOcclusion then
  local blocked,reason=M.DisplayOcclusion:Blocks(v.frame,true)
  if blocked then
   -- A current press over this native plate keeps its input/visual pair until
   -- release. Merely hovering never prevents a required task from taking space.
   local down,downState=S:Public(IsMouseButtonDown,"boolean")
   local over,overState=S:Public(MouseIsOver,"boolean",v.lease.plate)
   local held=downState=="KNOWN" and down==true and overState=="KNOWN" and over==true
   v.occlusionReason=held and "NATIVE_INPUT_HELD" or reason
   if not held then visible=false end
  end
 end
 visible=visible==true
 local inputReady,inputReason=self:HitDemand(v,visible)
 if not inputReady then
  -- A hide may wait for the engine's legal input window. Keep the existing
  -- body/input pair intact until the inverse succeeds; do not fade it away.
  if v.lease and v.lease.hit and v.lease.hit.hidePending then return false,inputReason end
  local unit,plate,uf=v.unit,v.lease and v.lease.plate,v.lease and v.lease.uf
  self:Fallback(unit,inputReason)
  local released=self:Release(v)
  -- A completed handback with a temporarily closed hit-layout window is a
  -- recoverable transition. Keep its verified current unit in the existing
  -- bounded queue; without this wake it stayed native beside healthy cards
  -- until a target change or a later pool lifecycle event happened to occur.
  if released and inputReason=="NATIVE_HIT_PERMISSION_DEFERRED" and self.active and selected()
   and plateFor(unit)==plate and nativeUnit(plate)==unit and field(plate,"UnitFrame")==uf then
   self:RearmAdmission(unit,plate,"QUIET_PRESENTATION_RESUMED")
   self:Queue(unit,plate,inputReason)
  end
  return false,inputReason
 end
 if v.visibleDemand~=visible then
  v.visibleDemand=visible
  invalidateHitPolicy()
 end
 v.visibilityStatus=visible and "VISIBLE_NATIVE_BODY_INPUT" or "HIDDEN_NATIVE_BODY_INPUT"
 if v.filterOnly then return call(v.frame,"Hide") end
 local multiplier=self:Presentation(v)
 if multiplier==nil then return false,"RANGE_OWNER_CHANGED_OR_UNWRITABLE" end
 -- The public owned aura holder stays readable through range fades. Native
 -- children keep their own opaque alpha/Show/Hide state; no aura button is
 -- inspected or restyled after its source-owned initializer has completed.
 local timerAlpha=visible and (cfg.alpha or 1) or 0
 v.durationGuard=v.durationGuard or function() return N:Current(v) end
 local generation,lease=v.generation,v.lease
 local foreground=M.ManagedAuraRails:SetDurationForeground(v.harmful,v.frame,lease.plate,timerAlpha,v.durationGuard)
 if v.generation~=generation or v.lease~=lease or not self:Current(v) then return false,"NATIVE_PLATE_PENDING" end
 if not foreground then
  self.lastForegroundReason=v.harmful and v.harmful.foregroundReason or "NATIVE_AURA_RAIL_UNAVAILABLE"
  self:Detail(v,"foreground",false,self.lastForegroundReason)
 else self:Detail(v,"foreground",true) end
 self.lastForegroundReason=v.harmful and v.harmful.foregroundReason or "NOT_REQUESTED"
 local a=visible and (cfg.alpha or 1)*multiplier or 0
 -- Successful staging was entirely within the acquisition transaction.
 -- Return to its preceding visual scalar before the normal shared fade, so
 -- the input correction does not change ordinary appearance or fade timing.
 local hit=v.lease and v.lease.hit;local staged=hit and hit.staged
 if staged then
  if not call(v.frame,"SetAlpha",staged.alpha) or v.lease~=lease or v.generation~=generation then return false,"NATIVE_HIT_VISUAL_SUPERSEDED" end
  if not staged.shown and not call(v.frame,"Hide") then return false,"NATIVE_HIT_VISUAL_SUPERSEDED" end
  if v.lease~=lease or v.generation~=generation then return false,"NATIVE_HIT_VISUAL_SUPERSEDED" end
  hit.staged=nil
 end
 -- A newly excluded category retires its presentation immediately rather
 -- than retaining a contextual fade with a stale admission decision.
 if v.admitted==false then
  if M.Effects and M.Effects.CancelTransition then M.Effects:CancelTransition(self,v.frame,false) end
  return call(v.frame,"SetAlpha",0) and call(v.frame,"Hide")
 end
 if M.Effects and M.Effects.Transition then
  v.visibilityGuard=v.visibilityGuard or function() return N:Current(v) and legal(v.frame) end
  -- A clicked friend is direct feedback after native admission. Ordinary
  -- contextual transitions keep their configured fade.
  local immediate=visible and v.friendlyTarget and v.selectedTarget
  local okay=M.Effects:Transition(self,v.frame,visible,{alpha=a,ceiling=(cfg.alpha or 1)*multiplier,
   duration=immediate and 0 or nil,guard=v.visibilityGuard})
  if okay then return true end
 end
 local ok=call(v.frame,"SetAlpha",a)
 return call(v.frame,visible and "Show" or "Hide") and ok
end
function N:FriendlyPredecessorHidden(unit)
 -- A failed or combat-deferred Hide must not allow a second selected-friendly
 -- card beside a still-visible retiring card. Ownership status alone is not
 -- visibility evidence: retiring owners are deliberately excluded by Current.
 for other,view in pairs(self.byUnit) do
  if other~=unit and view.lease and view.friendlyTarget then
   local shown,state=value(view.frame,"IsShown","boolean")
   if state~="KNOWN" or shown then
    self:Release(view)
    shown,state=value(view.frame,"IsShown","boolean")
    if state~="KNOWN" or shown then return false end
   end
  end
 end
 return true
end
function N:TryAssign(unit,plate)
 if not selected() or not self.active or not unitToken(unit) then return false,"INELIGIBLE_SCOPE" end
 if not S:Frame(plate,false) then return false,"NATIVE_PLATE_PENDING" end
 if S:Public(UnitExists,"boolean",unit)==false then return false,"NATIVE_PLATE_PENDING" end
 local uf=field(plate,"UnitFrame")
 local pooled=uf and self.byObject[uf]
 if pooled and pooled.lease and (pooled.unit~=unit or pooled.lease.plate~=plate) then
  -- A missed/delayed source callback cannot let two leases own the same
  -- pooled controller. Retire its old receipts before even classifying the
  -- successor, so an unknown successor also receives complete native access.
  if self:Current(pooled) then return false,"NATIVE_CONTROLLER_CURRENT_ELSEWHERE" end
  if not self:Release(pooled) then return false,"POOLED_RELEASE_PENDING" end
 end
 local limit=capacity()
 local category,classification,admitted,target,focus=self:Classify(unit)
 if classification=="FRIENDLY_SELECTED" and not self:FriendlyPredecessorHidden(unit) then
  return false,"FRIENDLY_PREVIOUS_CARD_HIDE_PENDING"
 end
 local existing=self.byUnit[unit]
 if self.ambientFallbacks then self.ambientFallbacks[unit]=nil end
 if classification=="FRIENDLY_NATIVE" or classification=="NONATTACKABLE_NATIVE" then
  -- Allegiance can change on an existing controller. Complete our previous
  -- hostile/legacy-friendly handback before leaving it wholly native.
  if existing and not self:Release(existing) then return false,"CLASSIFICATION_HANDOFF_PENDING" end
  local prior=self.byPlate[plate]
  if prior and not self:Release(prior) then return false,"CLASSIFICATION_HANDOFF_PENDING" end
  if classification=="NONATTACKABLE_NATIVE" then self.nativeNeutralPasses=(self.nativeNeutralPasses or 0)+1
  else self.nativeFriendlyPasses=(self.nativeFriendlyPasses or 0)+1 end
  return true,classification
 end
 if category=="UNKNOWN" then
  -- Absence of public category evidence is not a successful category filter.
  -- Return any prior custody, including a previously known filtered owner,
  -- before reporting the complete native fallback and its explicit limitation.
  if existing and not self:Release(existing) then return false,"CLASSIFICATION_HANDOFF_PENDING" end
  local prior=self.byPlate[plate]
  if prior and not self:Release(prior) then return false,"CLASSIFICATION_HANDOFF_PENDING" end
  return false,classification
 end
 -- Retire an older friendly-body receipt before a now-hostile controller can
 -- acquire ordinary card custody. Friendly successors returned above.
 if existing and existing.lease and (existing.lease.nativeBodies or classification=="UNSELECTED_FRIENDLY_PLATE" and not existing.filterOnly) then
  if not self:Release(existing) then return false,"CLASSIFICATION_HANDOFF_PENDING" end
  existing=nil
 end
 -- Nonfriendly categories deliberately filtered by the profile retain their
 -- existing native-body handoff semantics.
 if existing and not existing.retiring and not existing.filterOnly and not admitted and existing.lease and existing.lease.plate==plate and field(plate,"UnitFrame")==existing.lease.uf then
  existing.category=category;existing.friendlyTarget=classification=="FRIENDLY_SELECTED";existing.admitted=false;existing.selectedTarget=target;existing.selectedFocus=focus
  -- Keep this exact owner through the fade. Native presentation is not an
  -- alternative renderer for a category that the user deliberately filtered.
  return self:Visibility(existing)
 end
 if existing and not existing.retiring and existing.lease and existing.lease.plate==plate and field(plate,"UnitFrame")==existing.lease.uf
  and (existing.filterOnly==true)==(not admitted) and (existing.filterOnly or existing.poolSlot<=limit) then
  existing.targetFamilyFilter=classification=="UNSELECTED_FRIENDLY_PLATE" and self.targetFamily or nil
  local changed=existing.category~=category or existing.selectedTarget~=target or existing.selectedFocus~=focus
  existing.category=category;existing.friendlyTarget=classification=="FRIENDLY_SELECTED";existing.admitted=admitted;existing.selectedTarget=target;existing.selectedFocus=focus
  self.reusedAssignments=(self.reusedAssignments or 0)+1
  if not existing.filterOnly and existing.paintRevision~=self.configurationRevision then return self:Paint(existing,true) end
  if changed and not existing.filterOnly and legal(existing.frame) then self:Metadata(existing) end
  return self:Visibility(existing)
 end
 if existing and not self:Release(existing) then return false,"RELEASE_PENDING" end
 local prior=self.byPlate[plate]
 if prior and not self:Release(prior) then return false,"POOLED_RELEASE_PENDING" end
 if admitted then
  local allowed,blocked=self:AdmissionGate(unit,plate)
  if not allowed then
   self.acquisitionSkipped=true;self.admissionSkipped=(self.admissionSkipped or 0)+1
   return false,blocked.reason
  end
 end
 local v;local pool=admitted and self.pool or self.filteredPool;local cap=admitted and limit or 80
 for i=1,math.min(#pool,cap) do if not pool[i].lease and not pool[i].retiring then v=pool[i];break end end
 if not v then self.status="POOL_EXHAUSTED";return false,"POOL_EXHAUSTED" end
 local ok,why=self:Take(v,plate,unit,false)
 if not ok then self.status=why;return false,why end
 -- A native aura/parent callback can change the target during acquisition.
 -- Publish the current admission, not the selection sampled before Take.
 category,classification,admitted,target,focus=self:Classify(unit)
 if classification=="FRIENDLY_NATIVE" or classification=="NONATTACKABLE_NATIVE" then
  return self:Release(v),classification
 end
 if category=="UNKNOWN" or (v.filterOnly==true)~=(not admitted) then
  self:Release(v);return false,"NATIVE_PLATE_PENDING"
 end
 v.targetFamilyFilter=classification=="UNSELECTED_FRIENDLY_PLATE" and self.targetFamily or nil
 v.category=category;v.friendlyTarget=classification=="FRIENDLY_SELECTED";v.admitted=admitted;v.selectedTarget=target;v.selectedFocus=focus
 self.queue[unit]=nil;local painted,paintReason=self:Paint(v,true)
 if not painted then return false,paintReason end
 self:Outcome();return true
end
local function assignObserved(self,unit,plate)
 self:Observe(plate,unit)
 return self:TryAssign(unit,plate)
end
function N:Assign(unit,plate)
 -- Native setters can deliver lifecycle callbacks synchronously. A second
 -- assignment for the same token must wait until the first lease transaction
 -- has unwound; otherwise both attempts can mutate the same pooled slot.
 self.assigning=self.assigning or {}
 if unitToken(unit) and self.assigning[unit] then return false,"ASSIGNMENT_IN_PROGRESS" end
 local reservation={}
 if unitToken(unit) then self.assigning[unit]=reservation end
 self.assignmentAttempts=(self.assignmentAttempts or 0)+1
 self.acquisitionProbe=nil;self.acquisitionReadback=nil;self.acquisitionSkipped=nil
 local previousWriting=self.writing
 local called,okay,reason=pcall(assignObserved,self,unit,plate)
 self.writing=previousWriting
 if unitToken(unit) and self.assigning[unit]==reservation then self.assigning[unit]=nil end
 if not called then
  okay=false;reason="ASSIGNMENT_CALLBACK_FAILED"
  self.assignmentCallbackFailures=(self.assignmentCallbackFailures or 0)+1
 end
 self.fallbacks=self.fallbacks or {}
 self.fallbackProbes=self.fallbackProbes or {}
 if unitToken(unit) then
  if okay or reason=="CATEGORY_FILTERED" or reason=="INELIGIBLE_SCOPE" or reason=="AMBIENT_NATIVE_LABEL_PENDING" then self.fallbacks[unit]=nil;self.fallbackProbes[unit]=nil;self:ClearAdmission(unit)
  else
   self:Fallback(unit,reason or "NATIVE_CONTENT_UNAVAILABLE")
   self.lastAcquisitionProbe=self.acquisitionProbe or reason or "NATIVE_CONTENT_UNAVAILABLE"
   self.fallbackProbes[unit]=self.lastAcquisitionProbe
   if not self.acquisitionSkipped then self:AdmissionFailure(unit,plate,self.lastAcquisitionProbe,self.acquisitionReadback) end
  end
 end
 return okay,reason
end
local function releaseLease(self,v)
 local r=v.lease;v.retiring=true
 -- A live native hit region must never be left pointing at a hidden,
 -- reparented or recycled body. Finish (or observe displacement of) this
 -- inverse before changing either presentation's lifetime.
 if not self:RestoreHitPoints(v,r) then self.status="RESTORE_PENDING";return false end
 if M.Effects and M.Effects.CancelTransition then M.Effects:CancelTransition(self,v.frame,false) end
 if M.WorldCombatText and M.WorldCombatText.DetachPlate then M.WorldCombatText:DetachPlate(v) end
 if not self:RestoreHitPoints(v,r) then self.status="RESTORE_PENDING";return false end
 local complete=true
 if legal(v.frame) then complete=call(v.frame,"Hide") and value(v.frame,"IsShown","boolean")==false else complete=false end
 if not v.filterOnly and type(V.ConcealPreparedBody)=="function" then complete=V:ConcealPreparedBody(v) and complete end
 self.writing=true
 -- Clear custom native subscriptions before putting a pooled slot back.
 if v.harmful then complete=M.ManagedAuraRails:Clear(v.harmful)==true and complete end
 if v.helpful then complete=M.ManagedAuraRails:Clear(v.helpful)==true and complete end
 for _,p in ipairs(r.parents) do
  if not legal(p.object) then complete=false
  else
   local current,state=value(p.object,"GetParent")
   if state~="KNOWN" then complete=false
   elseif current==p.destination then
    complete=call(p.object,"SetParent",p.parent) and complete
    complete=value(p.object,"GetParent")==p.parent and complete
   end
  end
 end
 for _,a in ipairs(r.alpha) do
  if a.passive then
   -- No controller opacity was held while its native friendly name was live.
  elseif not legal(a.object) then complete=false
  else
   local alpha,state=value(a.object,"GetAlpha","number")
   if state~="KNOWN" then complete=false
   elseif alpha==(a.desired or 0) then
    complete=call(a.object,"SetAlpha",a.original) and complete
    complete=value(a.object,"GetAlpha","number")==a.original and complete
   end
  end
 end
 complete=self:RestoreFriendlyName(v,r) and complete
 if not self:RestoreHitPoints(v,r) then self.writing=nil;self.status="RESTORE_PENDING";return false end
 if legal(v.frame) then complete=call(v.frame,"SetParent",UIParent) and complete;complete=value(v.frame,"GetParent")==UIParent and complete else complete=false end
 if complete and not v.filterOnly and (v.relativeSource or v.relativeResetPending) and type(V.ResetNativeAnchors)=="function" then
  complete=V:ResetNativeAnchors(v,function() return v.lease==r and v.retiring==true end)==true and complete
 end
 if not self:RestoreHitPoints(v,r) then self.writing=nil;self.status="RESTORE_PENDING";return false end
 self.writing=nil
 if not complete then self.status="RESTORE_PENDING";return false end
 for _,a in ipairs(r.alpha) do if self.byObject[a.object]==v then self.byObject[a.object]=nil end end
 for _,p in ipairs(r.parents) do if self.byObject[p.object]==v then self.byObject[p.object]=nil end end
 if r.friendlyName and self.byObject[r.friendlyName.object]==v then self.byObject[r.friendlyName.object]=nil end
 if r.ambientName and self.byObject[r.ambientName]==v then self.byObject[r.ambientName]=nil end
 if self.byUnit[v.unit]==v then self.byUnit[v.unit]=nil end
 if self.byPlate[r.plate]==v then self.byPlate[r.plate]=nil end
 if v.filterOnly then v.frame:Hide();v.unit=nil;v.generation=v.generation+1 else V:Clear(v);v.raid:Hide() end
 v.preparedInvalidated=nil;v.relativeInvalidated=nil
 v.targetFamilyFilter=nil;v.lease=nil;v.retiring=nil;v.dirty=nil;v.friendlyTarget=nil;v.admitted=nil;v.visibleDemand=nil;v.selectedTarget=nil;v.selectedFocus=nil;v.visibilityStatus=nil;v.castDemand=nil;v.occlusionReason=nil;v.inputStatus=nil
 v.rangeStatus=nil;v.rangeReason=nil;v.rangeEvidence=nil;v.rangeVisual=nil;v.rangeVisualReason=nil;v.presentationScale=nil;v.requestedPresentationScale=nil;v.presentationDeferred=nil
 v.detailIssues=nil;v.detailRetryAt=nil;v.powerLayoutPending=nil;v.powerLayoutRetryAt=nil
 v.auraRefresh=nil;v.auraRefreshFailures=nil;v.auraRefreshRetryAt=nil;v.auraRefreshNextAt=nil;v.auraRefreshLastAt=nil
 v.paintRevision=nil
 v.friendlyNameStatus=nil;v.friendlyNameFont=nil;v.friendlyTitleStatus=nil;v.friendlyNameAttempts=nil;v.friendlyNameRetryAt=nil;v.friendlyNamePending=nil
 self.releases=(self.releases or 0)+1
 return true
end
function N:Release(v)
 if not v or not v.lease then return true end
 -- Clear/Hide/SetParent can synchronously reenter native removal or target
 -- dispatch. Keep this slot reserved until all inverse writes finish. A
 -- nested release used to free/reassign it while the outer call still held
 -- its old aura rails, then erase the successor's display and unit mapping.
 if v.releasing then
  self.releaseReentries=(self.releaseReentries or 0)+1
  return false
 end
 v.releasing=true
 local previousWriting=self.writing
 local okay,complete=pcall(releaseLease,self,v)
 self.writing=previousWriting
 v.releasing=nil
 if not okay then
  v.retiring=v.lease and true or nil;self.status="RESTORE_PENDING"
  self.releaseCallbackFailures=(self.releaseCallbackFailures or 0)+1
  return false
 end
 return complete
end
function N:ParkFiltered(v)
 if not v or v.filterOnly or v.admitted~=false or v.retiring or not v.lease or value(v.frame,"IsShown","boolean")~=false then return false end
 local r,unit,generation=v.lease,v.unit,v.generation
 local parked
 for _,entry in ipairs(self.filteredPool) do if not entry.lease and not entry.retiring then parked=entry;break end end
 if not parked or not legal(v.frame) or not legal(parked.frame) then return false end
 local function current()
  return v.lease==r and v.unit==unit and v.generation==generation and v.admitted==false
   and not parked.lease and not parked.retiring and self.byUnit[unit]==v and self.byPlate[r.plate]==v
   and (not r.friendlyName or self.byObject[r.friendlyName.object]==v) and self:Current(v)
 end
 if not current() then return false end
 if not self:RestoreHitPoints(v,r) or not current() then return false end
 r.hit=nil
 if v.harmful and not M.ManagedAuraRails:Clear(v.harmful) or v.helpful and not M.ManagedAuraRails:Clear(v.helpful) then return false end
 if M.WorldCombatText and M.WorldCombatText.DetachPlate then M.WorldCombatText:DetachPlate(v) end
 if M.Effects and M.Effects.CancelTransition then M.Effects:CancelTransition(self,v.frame,false) end
 if not current() then return false end
 -- The full card is already hidden and native input has been returned.
 -- Reset its owned presentation before publishing the lightweight successor;
 -- failed cleanup keeps this slot reserved rather than recycling stale anchors.
 v.preparedParking=true
 local resetOkay,resetDone=pcall(function()
  if not call(v.frame,"SetParent",UIParent) or not current() then return false end
  if type(V.ResetNativeAnchors)=="function" then return V:ResetNativeAnchors(v,current)==true end
  return true
 end)
 v.preparedParking=nil
 if not resetOkay or not resetDone or not current() then v.retiring=true;self.status="RESTORE_PENDING";return false end
 if not call(parked.frame,"SetParent",r.plate) then return false end
 if not current() then return false end
 parked.frame:Hide()
 if not current() then return false end
 parked.lease=r;parked.unit=unit;parked.generation=parked.generation+1
 parked.admitted=false;parked.visibleDemand=false;parked.category=v.category;parked.selectedTarget=v.selectedTarget;parked.selectedFocus=v.selectedFocus
 self.byUnit[unit]=parked;self.byPlate[r.plate]=parked
 for _,a in ipairs(r.alpha) do self.byObject[a.object]=parked end
 for _,entry in ipairs(r.parents) do self.byObject[entry.object]=parked end
 -- This is a transfer of one live native lease, not a new label acquisition.
 -- Its native observer and inverse receipts must follow the parked view too.
 if r.friendlyName then self.byObject[r.friendlyName.object]=parked end
 for _,key in ipairs({"friendlyNameStatus","friendlyNameFont","friendlyTitleStatus","friendlyNameAttempts","friendlyNameRetryAt","friendlyNamePending"}) do
  parked[key]=v[key];v[key]=nil
 end
 V:Clear(v);v.lease=nil;v.retiring=nil;v.dirty=nil;v.raid:Hide()
 v.preparedInvalidated=nil;v.relativeInvalidated=nil
 call(v.frame,"SetParent",UIParent)
 return true
end
function N:EnforceLimit()
 local limit=capacity();local complete=true
 -- Keep prebuilt slots for a later increase, but never retain live takeover
 -- above the current authored cap. A failed handback stays retiring, not free.
 for i=limit+1,#self.pool do
  local v=self.pool[i]
  if v.lease then complete=self:Release(v) and complete end
 end
 self.limitPending=not complete or nil
 if not complete then self.status="POOL_REDUCTION_PENDING";return false,"POOL_REDUCTION_PENDING" end
 self.configuredLimit=limit;return true
end
local retryReasons={NATIVE_PLATE_PENDING=true,REACTION_PENDING=true,FRIENDLY_OR_REGISTRATION_PENDING=true,
 AMBIENT_NATIVE_LABEL_PENDING=true,
 NATIVE_HIT_PERMISSION_DEFERRED=true,NATIVE_HIT_READBACK_UNAVAILABLE=true,NATIVE_HIT_OBSERVER_UNAVAILABLE=true,NATIVE_HIT_OWNER_CHANGED=true,
 NATIVE_HIT_PASSIVE_GEOMETRY_UNAVAILABLE=true,
 CONTROL_COMBAT_OR_FORBIDDEN=true,NATIVE_CONTROL_SETUP_UNAVAILABLE=true,NATIVE_CONTROLLER_PARENT_UNAVAILABLE=true,
 TAKEOVER_INCOMPLETE=true,AURA_CHANNEL_UNAVAILABLE_KEEP_NATIVE=true,CAST_CHANNEL_UNAVAILABLE_KEEP_NATIVE=true,
 AURA_FOREGROUND_UNAVAILABLE_KEEP_NATIVE=true,CLASSIFICATION_UNAVAILABLE_KEEP_NATIVE=true,
 FRIENDLY_NATIVE_NAME_HANDOFF_PENDING=true,FRIENDLY_PREVIOUS_CARD_HIDE_PENDING=true,ASSIGNMENT_IN_PROGRESS=true,ASSIGNMENT_CALLBACK_FAILED=true,
 POOLED_RELEASE_PENDING=true,RELEASE_PENDING=true,CLASSIFICATION_HANDOFF_PENDING=true,POOL_EXHAUSTED=true}
function N:Queue(unit,plate,reason)
 if not unitToken(unit) then return end
 if not retryReasons[reason] then return end
 local allowed,admission=self:AdmissionGate(unit,plate)
 if not allowed then self.queue[unit]=nil;return end
 local count=0;for _ in pairs(self.queue) do count=count+1 end
 if count<80 and not self.queue[unit] then self.queue[unit]={plate=plate,attempts=0,profile=M.profile,nextAt=S:Now()+.1,
  inputAdmission=admission~=nil or reason=="NATIVE_HIT_PERMISSION_DEFERRED",ambientLabel=reason=="AMBIENT_NATIVE_LABEL_PENDING"} end
end
function N:RefreshSelection(token)
 if token~="target" and token~="focus" then return end
 self.selectionRevision=(self.selectionRevision or 0)+1
 local revision,profile=self.selectionRevision,M.profile
 local key=token=="target" and "selectedTarget" or "selectedFocus"
 local previous={}
 -- Read only our cached selection flags here. No native collection traversal
 -- or reclassification of unrelated hostile/aura owners is needed.
 for _,v in pairs(self.byUnit) do
  if v[key] and v.lease then previous[#previous+1]={view=v,unit=v.unit,lease=v.lease,generation=v.generation} end
 end
 local seen={}
 local function current() return self.active and selected() and M.profile==profile and self.selectionRevision==revision end
 local function visit(unit,plate)
  if not current() or not unitToken(unit) or not S:Frame(plate,false) or seen[unit] then return end
  seen[unit]=true
  local okay,reason=self:Assign(unit,plate)
  if not okay and current() then self:Queue(unit,plate,reason) end
 end
 for _,entry in ipairs(previous) do
  local v=entry.view
  if not current() then return end
  if v.lease==entry.lease and v.generation==entry.generation and self.byUnit[entry.unit]==v then
   self:QueueAuraRefresh(v,"SELECTION_LEFT")
   local plate=plateFor(entry.unit)
   local exists,state=S:Public(UnitExists,"boolean",entry.unit)
   if state=="KNOWN" and exists==false then self:Release(v)
   elseif plate==entry.lease.plate then visit(entry.unit,plate)
   else self:Release(v) end
  end
 end
 if not current() then return end
 local plate,state=selectionPlate(token)
 if state=="KNOWN" then visit(nativeUnit(plate),plate) end
 if current() then self:QueueAuraAlias(token,"SELECTION_ENTERED") end
 self.selectionPasses=(self.selectionPasses or 0)+1
end
-- A target event can precede publication of the controller or its unit token.
-- Coalesce changes in one rendered frame. Always resolve the *current* target
-- again. Native add events and the existing bounded queue handle later arrivals.
function N:WakeFriendlySelection()
 if self.friendlySelectionWake or config().selectedFriendlyPlate==false then return end
 local after=C_Timer and C_Timer.After
 if type(after)~="function" or S:Public(UnitExists,"boolean","target")==false
  or S:Public(UnitIsFriend,"boolean","player","target")==false then return end
 local function ready(unit,plate)
  local view=unitToken(unit) and self.byUnit[unit]
  return view and view.selectedTarget and view.friendlyTarget and view.admitted and
   view.lease and view.lease.plate==plate and self:Current(view) and view.visibleDemand==true
 end
 local plate=selectionPlate("target")
 if plate and ready(nativeUnit(plate),plate) then return end
 local ticket={profile=M.profile}
 self.friendlySelectionWake=ticket
 after(0,function()
  if self.friendlySelectionWake~=ticket then return end
  self.friendlySelectionWake=nil
  if not self.active or M.profile~=ticket.profile or not selected() or config().selectedFriendlyPlate==false
   or S:Public(UnitIsFriend,"boolean","player","target")~=true then return end
  -- Classification can become readable one frame after PLAYER_TARGET_CHANGED.
  -- The policy function also handles combat and recomputes the live family.
  self:ApplyPolicies(true,true)
  if not self.active or M.profile~=ticket.profile or not selected() then return end
  local current=selectionPlate("target")
  if not current then return end
  local unit=nativeUnit(current)
  if not unitToken(unit) or plateFor(unit)~=current or ready(unit,current) then return end
  if not self:Selection(unit) or not self:AdmissionGate(unit,current) then return end
  local ok,reason=self:Assign(unit,current)
  if not ok then self:Queue(unit,current,reason) end
 end)
end
function N:Refresh()
 local list,state=S:Public(C_NamePlate and C_NamePlate.GetNamePlates,"table")
 local seen={};local visited=0
 local function visit(plate,unit)
  if not S:Frame(plate,false) or seen[plate] then return end
  unit=unit or nativeUnit(plate)
  if not unitToken(unit) or plateFor(unit)~=plate then return end
  seen[plate]=true;visited=visited+1
  local ok,why=self:Assign(unit,plate);if not ok then self:Queue(unit,plate,why) end
 end
 -- Disabled friendly families can still expose a native widgets-only base.
 -- Probe the two actual selected tokens directly so an omitted collection
 -- entry is not mistaken for absent content. No new world anchor is created.
 for _,token in ipairs({"target","focus"}) do
  local plate,ps=selectionPlate(token)
  if ps=="KNOWN" then visit(plate) end
 end
 self.collectionStatus=state
 if state=="KNOWN" then
  local readable=true
  if type(canaccesstable)=="function" then readable=S:Public(canaccesstable,"boolean",list)==true end
  if not readable then self.collectionStatus="RESTRICTED"
  else
   -- The native driver uses pairs, not a dense array contract. A sparse
   -- engine collection must not stop at its first unused numeric slot.
   local key
   for i=1,81 do
    local ok,nextKey,plate=pcall(next,list,key)
    if not ok or not S:Readable(nextKey) or not S:Readable(plate) then self.collectionStatus="RESTRICTED";break end
    if nextKey==nil then break end
    if i>80 then self.collectionStatus="BOUNDED_NATIVE_COLLECTION";break end
    key=nextKey;visit(plate)
   end
  end
 end
 -- Some native friendly plates arrive through events without appearing in
 -- the collection. Retain only actual emitted handles, verified on each use;
 -- never construct a world plate from target/focus tokens or guessed units.
 for unit,plate in pairs(self.observed) do
  if plateFor(unit)~=plate then self.observed[unit]=nil
  else visit(plate,unit) end
 end
 self.collectionVisited=visited
 return self:Outcome()
end
function N:Configure()
 if not eligible() then return self:Suspend("UNSELECTED") end
 -- An unreadable editor observation denies new work but does not establish
 -- a native edit opening or revoke an already-owned presentation.
 local editing=R:NativeEditState()
 if editing=="UNKNOWN" then return R:Result("DEFERRED_HANDOFF","NATIVE_EDIT_UNKNOWN") end
 if editing=="OPEN" then return self:Suspend("NATIVE_EDIT_HANDOFF") end
 for _,v in pairs(self.byUnit) do if v.retiring and not self:Release(v) then self.status="RESTORE_PENDING";return false end end
 if not self:Initialize() then return false end
 local capped,capReason=self:EnforceLimit();if not capped then return false,capReason end
 self.active=true
 self.configurationRevision=(self.configurationRevision or 0)+1
 self:ApplyPolicies()
 self:PrepareRange()
 if not S:InCombat() then
  for _,v in ipairs(self.pool) do if not v.retiring then V:Layout(v,config());if v.lease and not v.relativeLayout then call(v.frame,"ClearAllPoints");call(v.frame,"SetPoint","CENTER",v.lease.plate,"CENTER",0,offset()) end end end
 end
 self:Refresh()
 if M.WorldCombatText and M.WorldCombatText.ReconcilePlates then invalidateHitPolicy();M.WorldCombatText:ReconcilePlates(self) end
 return self:Outcome()
end
function N:OnEvent(event,unit)
 if event=="NAME_PLATE_CREATED" then self:Observe(unit);return end
 if (event=="NAME_PLATE_UNIT_ADDED" or event=="NAME_PLATE_UNIT_REMOVED" or event=="UNIT_FACTION"
  or event=="PLAYER_REGEN_ENABLED" or event=="PLAYER_REGEN_DISABLED") then invalidateHitPolicy() end
 if event=="NAME_PLATE_UNIT_REMOVED" then
  if unitToken(unit) then
   local v=self.byUnit[unit]
   -- The driver clears/releases before delivering its removal to addons.
   -- A late event for a recycled token must not retire a new verified owner.
   if v and self:Current(v) and plateFor(unit)==v.lease.plate and S:Public(UnitExists,"boolean",unit)==true then
    self.staleRemovals=(self.staleRemovals or 0)+1
    return self:Outcome()
   end
   if self.active and not self.targetFamily and v and v.friendlyTarget and v.selectedTarget then self.targetPolicyDeferred=true end
   self.queue[unit]=nil;self.observed[unit]=nil;self:ClearAdmission(unit)
   if self.ambientFallbacks then self.ambientFallbacks[unit]=nil end
   if self.fallbacks then self.fallbacks[unit]=nil end
   if self.fallbackProbes then self.fallbackProbes[unit]=nil end
   self:Release(self.byUnit[unit])
  end
  return self:Outcome()
 end
 if not self.active or not selected() then return end
 if event=="CVAR_UPDATE" and S:Text(unit) then
  local name=unit:lower()
  if name=="floatingcombattextcombatdamage_v2" and M.WorldCombatText and not M.WorldCombatText.plateReconciling then
   invalidateHitPolicy()
  end
  if name=="unitnamefriendlyplayername" then self:ObserveFriendlyCVarEvent("UnitNameFriendlyPlayerName")
  elseif name=="unitnameplayerguild" then self:ObserveFriendlyCVarEvent("UnitNamePlayerGuild") end
  if name=="unitnamenpc" or name=="unitnamefriendlyspecialnpcname" or name=="unitnamehostlenpc" or name=="unitnameinteractivenpc" then
   if name=="unitnamenpc" and config().nativeNPCNames==1 then self:ObserveFriendlyCVarEvent("UnitNameNPC") end
   self:NativeNPCNamePreference()
  end
  for _,key in ipairs({"nameplateShowFriendlyPlayers","nameplateShowFriends","nameplateShowOnlyNameForFriendlyPlayerUnits","nameplateShowFriendlyNpcs","nameplateShowFriendlyNPCs","nameplateShowFriendlyPlayerMinions","nameplateShowFriendlyPets"}) do
   if name==key:lower() then
    -- Both directions matter: a native return to0 can satisfy presentation
    -- while the external journal still correctly prevents write acquisition.
    -- Prefer the admitted alias when a legacy spelling folds to the same
    -- event name; it holds the actual receipt and public getter contract.
    for _,setting in ipairs(friendlyPolicies) do
     local admitted=self.policyKeys and self.policyKeys[setting]
     if admitted and name==admitted:lower() then key=admitted;break end
    end
    self:ObserveFriendlyCVarEvent(key)
    -- Source callbacks own the actual names-only/full-body transition. Queue
    -- the currently emitted bases after observing that change; never write a
    -- native mode flag or force an input update from this event.
    if not self.applyingPolicies then
     for observedUnit,plate in pairs(self.observed) do
      if plateFor(observedUnit)==plate then self:RearmAdmission(observedUnit,plate,"FRIENDLY_MODE_CVAR_CHANGED");self:Queue(observedUnit,plate,"NATIVE_PLATE_PENDING") end
     end
    end
    return self:Outcome()
   end
  end
 end
 if event=="KNOWN_TITLES_UPDATE" or event=="CVAR_UPDATE" and S:Text(unit) and unit:lower()=="unitnameplayerpvptitle" then
  for _,v in pairs(self.byUnit) do if self:Current(v) and v.lease.nativeBodies then self:RefreshFriendlyName(v,true) end end
  return self:Outcome()
 end
 if event=="GAME_RULES_CHANGED" then self:ReadWorldNameRule();return end
 if event=="PLAYER_REGEN_ENABLED" then
  if self.targetPolicyDeferred then self:ApplyPolicies(true,true) end
  self.bodyPromotionEpoch=(self.bodyPromotionEpoch or 0)+1
  for _,v in pairs(self.byUnit) do
   local hit=v.lease and v.lease.hit
   if hit then hit.displacedReadSerial=nil;hit.displacedReadFailure=nil end
  end
  self:RearmAdmissions("COMBAT_ENDED",false)
  -- Native add/remove events and the ordinary maintenance queue already own
  -- discovery and deferred repairs. Combat exit only updates the two selected
  -- identities; it must not reassign/repaint every nearby plate in one event.
  self:RefreshSelection("target");self:RefreshSelection("focus")
  self.combatExitSelectionPasses=(self.combatExitSelectionPasses or 0)+1
  return self:Outcome()
 end
 if event=="PLAYER_ENTERING_WORLD" or event=="EDIT_MODE_LAYOUTS_UPDATED" or event=="ADDON_LOADED" and unit=="Blizzard_NamePlates" then
  if event=="PLAYER_ENTERING_WORLD" then self:ReadWorldNameRule() end
  self:RearmAdmissions(event,true)
  -- Framework configuration owns CVar/layout transactions. These native
  -- wakes only discover new content and finish already-deferred details.
  -- Reconfiguring every addon/combat event repainted all incumbents and could
  -- self-suspend a provider while its framework row still claimed READY.
  if not S:InCombat() then
   if self.rangeDirty then self:PrepareRange() end
   for _,v in pairs(self.byUnit) do
    if self:Current(v) and v.lease.nativeBodies then self:RefreshFriendlyName(v,true) end
    if not v.filterOnly and self:Current(v) then self:RetryDetails(v,S:Now());if v.powerLayoutPending then V:Power(v,true) end end
   end
  end
  return self:Refresh()
 end
 if event=="MODIFIER_STATE_CHANGED" or event=="UPDATE_SHAPESHIFT_FORM" then
  if self.rangeHasMacros then self.rangeDirty=true end
  return
 end
 if event=="ACTIONBAR_SLOT_CHANGED" or event=="UPDATE_MACROS" or event=="SPELLS_CHANGED" or event=="PLAYER_SPECIALIZATION_CHANGED" then
  self.rangeDirty=true
  if event=="SPELLS_CHANGED" or event=="PLAYER_SPECIALIZATION_CHANGED" then
   -- Spell/talent changes may alter range metadata even if an ID survives.
   -- Retire its evidence until the new catalog can be observed safely.
   self.rangeReferences=nil;self.rangeRevision=(self.rangeRevision or 0)+1
  end
  return
 end
 if event=="PLAYER_REGEN_DISABLED" then for _,v in pairs(self.byUnit) do self:Visibility(v) end;return end
 if event=="NAME_PLATE_UNIT_ADDED" and unitToken(unit) then
  local plate=plateFor(unit);self:RearmAdmission(unit,plate,"NATIVE_UNIT_ADDED")
  local ok,why=self:Assign(unit,plate);if not ok then self:Queue(unit,plate,why) end
  -- Native pools may reuse token, plate and controller together. SetUnit and
  -- our same-owner Assign fast path are both no-ops for that identity; the
  -- new native lifecycle notification must still refresh current aura data.
  self:QueueAuraRefresh(self.byUnit[unit],"NATIVE_UNIT_ADDED")
  return self:Outcome()
 end
 if event=="PLAYER_TARGET_CHANGED" or event=="PLAYER_FOCUS_CHANGED" then
  if event=="PLAYER_TARGET_CHANGED" then self:ApplyPolicies(true,true) end
  if self.rangeHasMacros then self.rangeDirty=true end
  self:RefreshSelection(event=="PLAYER_TARGET_CHANGED" and "target" or "focus")
  if event=="PLAYER_TARGET_CHANGED" then self:WakeFriendlySelection() end
  invalidateHitPolicy()
  return self:Outcome()
 elseif event=="UPDATE_MOUSEOVER_UNIT" then
  local previous=self.auraMouseover
  if previous and auraRefreshOwner(self,previous.view,previous.request) then
   self:QueueAuraRefresh(previous.view,"MOUSEOVER_LEFT")
  end
  local request,view=self:QueueAuraAlias("mouseover","MOUSEOVER_ENTERED")
  self.auraMouseover=request and {view=view,request=request} or nil
  return self:Outcome()
 elseif event=="RAID_TARGET_UPDATE" then
  for _,v in pairs(self.byUnit) do if not v.filterOnly and legal(v.frame) then self:Metadata(v) end end
  return self:Outcome()
 end
 if event=="UNIT_TARGET" then
  -- A bystander's change of target does not change anyone else's plate.
  local v=unitToken(unit) and self.byUnit[unit]
  if v and not v.filterOnly and self:Current(v) then self:Visibility(v) end
  return
 end
 if event=="PLAYER_LEVEL_UP" or event=="UNIT_LEVEL" and unit=="player" then
  -- These rare global invalidations repaint incumbent metadata only; they
  -- do not rediscover plates, rebuild geometry or rescan native aura data.
  for _,v in pairs(self.byUnit) do
   if not v.filterOnly and self:Current(v) and legal(v.frame) then self:Metadata(v) end
  end
  return self:Outcome()
 end
 if event=="UNIT_THREAT_SITUATION_UPDATE" or event=="UNIT_THREAT_LIST_UPDATE" then
  -- Threat can update repeatedly during combat. Only its three texture edges
  -- need repainting; names, level colors, auras and geometry do not change.
  if unit=="player" then
   for _,v in pairs(self.byUnit) do
    if not v.filterOnly and legal(v.frame) then self:Threat(v) end
   end
  else
   if unit=="target" or unit=="focus" or unit=="mouseover" then
    local p=selectionPlate(unit);unit=p and nativeUnit(p)
   end
   local v=unitToken(unit) and self.byUnit[unit]
   if v and not v.filterOnly and legal(v.frame) then self:Threat(v) end
  end
  return
 end
 if event=="UNIT_AURA" and S:Text(unit) and (unit=="target" or unit=="focus" or unit=="mouseover") then
  -- The alias identifies only which verified incumbent needs a native scan.
  -- Never forward, inspect or cache UNIT_AURA payloads in addon Lua.
  self:QueueAuraAlias(unit,"UNIT_AURA_ALIAS")
  return self:Outcome()
 end
 if event=="UNIT_FACTION" or event=="UNIT_CLASSIFICATION_CHANGED" or event=="UNIT_FLAGS" then
  if event=="UNIT_FACTION" and (unit=="target" or unitToken(unit) and S:Public(UnitIsUnit,"boolean",unit,"target")==true) then self:ApplyPolicies(true,true,true) end
  local p
  if unitToken(unit) then p=plateFor(unit)
  elseif unit=="target" or unit=="focus" or unit=="mouseover" then
   p=selectionPlate(unit);unit=p and nativeUnit(p)
  end
  if not unitToken(unit) or not S:Frame(p,false) then return end
  local ok,why=self:Assign(unit,p);if not ok then self:Queue(unit,p,why) end
  local v=self.byUnit[unit]
  if v and not v.filterOnly and self:Current(v) and legal(v.frame) then self:Metadata(v);self:Visibility(v) end
  return self:Outcome()
 end
 if not unitToken(unit) then return end
 local v=self.byUnit[unit]
 if v and self:Current(v) and v.lease.nativeBodies and (event=="UNIT_NAME_UPDATE" or event=="UNIT_FLAGS" or event=="UNIT_CONNECTION") then
  self:RefreshFriendlyName(v,true)
 end
 if not v or not self:Current(v) or v.filterOnly then return end
 if event:find("SPELLCAST",1,true) then
  if event=="UNIT_SPELLCAST_START" or event=="UNIT_SPELLCAST_CHANNEL_START" or event=="UNIT_SPELLCAST_EMPOWER_START" then v.castDemand=true
  elseif event=="UNIT_SPELLCAST_STOP" or event=="UNIT_SPELLCAST_CHANNEL_STOP" or event=="UNIT_SPELLCAST_EMPOWER_STOP" or event=="UNIT_SPELLCAST_FAILED" or event=="UNIT_SPELLCAST_INTERRUPTED" then v.castDemand=nil end
  if legal(v.frame) then self:RefreshCast(v);self:Visibility(v) end
 elseif event=="UNIT_HEALTH" or event=="UNIT_MAXHEALTH" then V:Health(v)
 elseif event=="UNIT_POWER_UPDATE" or event=="UNIT_MAXPOWER" then V:Power(v,false)
 elseif event=="UNIT_AURA" then self:Auras(v)
 elseif event=="UNIT_NAME_UPDATE" or event=="UNIT_LEVEL" or event=="UNIT_DISPLAYPOWER" then self:Paint(v,true)
 elseif event=="UNIT_FLAGS" or event=="UNIT_CONNECTION" or event=="UNIT_CLASSIFICATION_CHANGED" then if legal(v.frame) then self:Metadata(v);self:Visibility(v) end end
end
function N:AuditAmbient(v,r,now)
 r.lastAudit=now;r.labelChanged=nil
 if r.conflict or not self:Current(v) then
  local unit=v.unit
  if self:Release(v) and plateFor(unit)==r.plate and nativeUnit(r.plate)==unit then
   self:Queue(unit,r.plate,"NATIVE_PLATE_PENDING")
  end
  return
 end
 local ready,why=self:AmbientLabelReady(r.plate,r.uf,r.ambientName)
 if v.lease~=r then return end
 if not ready then
  if why=="NATIVE_LABEL_NOT_VISIBLE" or why=="NATIVE_LABEL_TEXT_UNAVAILABLE" then
   r.missingSince=r.missingSince or now
   if now-r.missingSince<.35 then r.labelChanged=true;return end
  end
  self:RetireAmbientLabel(v,why)
  return
 end
 r.missingSince=nil
 self:Dependencies(v)
 if v.lease==r and v.dirty then self:Suppress(v,true) end
end
function N:AuditAmbientBatch(now,periodic)
 local count=#self.filteredPool
 if count==0 then return end
 local cursor=periodic and "ambientAuditCursor" or "ambientChangeCursor"
 local index=self[cursor] or 0
 local used=0
 for i=1,count do
  index=index%count+1
  local v=self.filteredPool[index];local r=v.lease
  if r and r.ambientName and r.lastAudit~=now and not v.retiring and (periodic or r.labelChanged or v.dirty) then
   self:AuditAmbient(v,r,now)
   used=used+1
   if used==6 then break end
  end
 end
 self[cursor]=index
end
function N:RetryQueued(now)
 -- Inspect native identities only for due requests. Direct selection and
 -- lifecycle events still run immediately, independently of this retry pass.
 local remaining,inputRemaining=8,4
 for unit,q in pairs(self.queue) do
  if q.profile~=M.profile then
   self.queue[unit]=nil
  elseif remaining>0 and now>=(q.nextAt or 0) and (not q.inputAdmission or inputRemaining>0) then
   remaining=remaining-1
   local plate=plateFor(unit)
   if q.plate and plate~=q.plate then
    if self.queue[unit]==q then self.queue[unit]=nil end
   elseif self.queue[unit]==q then
    if q.inputAdmission then inputRemaining=inputRemaining-1 end
    q.attempts=q.attempts+1;q.plate=plate
    local ok,why=self:Assign(unit,plate)
    if self.queue[unit]==q then
     local retry=not ok and retryReasons[why] and not (q.ambientLabel and q.attempts>=4)
     if retry then retry=self:AdmissionGate(unit,plate) end
     if self.queue[unit]==q then
      if retry then q.nextAt=now+math.min(8,.25*2^math.min(q.attempts,5))
      else self.queue[unit]=nil end
     end
    end
   end
  end
 end
end
function N:Tick(now)
 now=S:Number(now) and now or S:Now()
 if now<(self.nextTick or 0) then return end;self.nextTick=now+.25
 if not eligible() then self:Suspend("UNSELECTED");return end
 local editing=R:NativeEditState()
 if editing=="UNKNOWN" then return R:Result("DEFERRED_HANDOFF","NATIVE_EDIT_UNKNOWN") end
 if editing=="OPEN" then self:Suspend("NATIVE_EDIT_HANDOFF");return end
 if not self.active then self:Configure();return end
 for unit,entry in pairs(self.ambientFallbacks or {}) do
  if plateFor(unit)~=entry.plate or nativeUnit(entry.plate)~=unit or field(entry.plate,"UnitFrame")~=entry.uf then self.ambientFallbacks[unit]=nil end
 end
 if self.targetPolicyDeferred and not S:InCombat() then self:ApplyPolicies(true,true) end
 if self.friendlyPolicyPending and self.friendlyPolicyRetryAt and now>=self.friendlyPolicyRetryAt then
  if self.friendlyPolicyRetry=="OBSERVE" then self:ObserveFriendlyPolicy()
  elseif not S:InCombat() then self:ApplyPolicies(true) end
 end
 if self.rangeDirty and not S:InCombat() then self:PrepareRange() end
 if self.limitPending or self.configuredLimit~=capacity() then if not self:EnforceLimit() then return end end
 self:PromotePassiveBodies(now)
 local powerLayoutBudget=4
 for _,v in pairs(self.byUnit) do
  if v.retiring then
   local unit,plate=v.unit,v.lease and v.lease.plate
   if self:Release(v) and plateFor(unit)==plate and nativeUnit(plate)==unit then self:Queue(unit,plate,"NATIVE_PLATE_PENDING") end
  elseif v.lease and not v.lease.ambientName then
   local r=v.lease
   if r.conflict or plateFor(v.unit)~=r.plate or not self:Current(v) or not self:CheckHitPoints(v) then
    local unit=v.unit;local p=plateFor(unit);local replacement=p==r.plate and field(p,"UnitFrame")~=r.uf
    if self:Release(v) then
     if replacement then local ok,why=self:Assign(unit,p);if not ok then self:Queue(unit,p,why) end
     elseif not r.conflict and p==r.plate and nativeUnit(p)==unit then self:Queue(unit,p,"NATIVE_PLATE_PENDING") end
    end
   else
    self:Dependencies(v)
    if v.dirty then self:Suppress(v,true) end
    if r.nativeBodies and v.friendlyNamePending then self:RefreshFriendlyName(v,false) end
    if not v.filterOnly and v.namePending and legal(v.frame) then self:Metadata(v) end
    if not v.filterOnly then
     -- Finish only real geometry debt after lockdown. Limit this previously
     -- synchronous combat-exit work to four cards per maintenance pass.
     if v.powerLayoutPending and not S:InCombat() and powerLayoutBudget>0 and now>=(v.powerLayoutRetryAt or 0) then
      powerLayoutBudget=powerLayoutBudget-1
      local lease,generation=v.lease,v.generation
      local okay=pcall(V.Power,V,v,true)
      if v.lease==lease and v.generation==generation then
       if not okay then v.powerLayoutPending=true;v.powerLayoutRetryAt=now+1
       else v.powerLayoutRetryAt=nil end
      end
     end
     self:RetryDetails(v,now)
     -- Explicit content failures may require a native rail resubmission.
     -- Optional opacity observation never clears the live subscription.
     if config().cardAuras and (v.harmful and v.harmful.enabled==false or v.helpful and v.helpful.enabled==false) then
      self:Detail(v,"auras",false,"NATIVE_AURA_REASSIGN_PENDING")
     end
    end
    self:Visibility(v)
    if not v.filterOnly and v.admitted==false then self:ParkFiltered(v) end
   end
  end
 end
 self:RetryQueued(now)
 self:ReconcileAuras(now)
 if M.WorldCombatText and M.WorldCombatText.ReconcilePlates then M.WorldCombatText:ReconcilePlates(self) end
 return self:Outcome()
end
function N:Suspend(reason)
 self.targetFamily=nil;self.targetPolicyDeferred=nil;self.friendlySelectionWake=nil
 if self.active then self.lastActiveSuspendReason=reason or "SUSPENDED";self.lastActiveSuspendAt=S:Now() end
 self.lastSuspendReason=reason or "SUSPENDED";self.lastSuspendAt=S:Now()
 self.suspensions=(self.suspensions or 0)+1
 self.active=false;self.queue={};self.fallbacks={};self.fallbackProbes={};self.ambientFallbacks={};self.observed={};self.auraMouseover=nil;self.admissionStates={};self.admissionByPlate=setmetatable({},{__mode="k"});self.bodyPromotions=nil;local complete=true
 self.selectionStatus={target="PROVIDER_INACTIVE",focus="PROVIDER_INACTIVE"}
 for _,v in pairs(self.byUnit) do complete=self:Release(v) and complete end
 local restored=R:RestoreCVars("nameplates")
 if restored==false then complete=false end
 self.status=complete and (reason or "SUSPENDED") or "RESTORE_PENDING"
 if complete then return complete end
 return complete,"RESTORE_PENDING"
end
function N:Retry()
 if S:InCombat() then return false end
 -- Explicit recovery may recheck a previously failing public getter once.
 -- Ordinary retirement ticks retain the cached failure for that writer serial.
 for _,v in pairs(self.byUnit) do
  local hit=v.lease and v.lease.hit
  if hit then hit.displacedReadSerial=nil;hit.displacedReadFailure=nil end
 end
 if not self:Suspend("RECOVER") then return false end
 for _,v in ipairs(self.pool) do
  for _,key in ipairs({"harmful","helpful"}) do
   local rail=v[key]
   if rail and (not M.ManagedAuraRails:Ready(rail) or rail.failures>=3) then
    if not M.ManagedAuraRails:Clear(rail) then return false end
    v[key]=nil
   end
  end
  v.auraSetupFailures=0;v.nativeTextAttempts=0;v.detailRebuilds=0
  if M.WorldCombatText and M.WorldCombatText.RearmPlate then M.WorldCombatText:RearmPlate(v) end
 end
 return true
end
function N:Status()
 self:Outcome()
 local count,pending,retiring,fallbacks,filtered=0,0,0,0,0
 local selectedFriendly=config().selectedFriendlyPlate~=false
 local foregroundStates,unitDemands={},{}
 for _ in pairs(self.fallbacks or {}) do fallbacks=fallbacks+1 end
 for _,v in pairs(self.byUnit) do
  if v.retiring then retiring=retiring+1
  elseif self:Current(v) then
   if v.filterOnly or v.admitted==false then filtered=filtered+1 else
    count=count+1
    local reason=v.harmful and v.harmful.enabled and v.harmful.foregroundReason or "NO_ACTIVE_AURA_RAIL"
    foregroundStates[reason or "NOT_OBSERVED"]=true
    local demand=v.unitDemandReason or "NOT_OBSERVED";unitDemands[demand]=(unitDemands[demand] or 0)+1
   end
   if v.namePending or next(v.detailIssues or {}) then pending=pending+1 end
  end
 end
 local out={self.status,"active="..count,"capacity="..capacity(),"allocated="..#self.pool,"retiring="..retiring,"pending_content="..pending,"native_fallbacks="..fallbacks,"category_filtered="..filtered,"enemy_visibility="..(self.cvarStatus or "NOT_RUN")}
 local reasons={};for _,reason in pairs(self.fallbacks or {}) do reasons[reason]=(reasons[reason] or 0)+1 end
 local codes={};for reason in pairs(reasons) do codes[#codes+1]=reason end;table.sort(codes)
 for i=1,math.min(16,#codes) do local reason=codes[i];out[#out+1]="fallback_"..reason.."="..reasons[reason] end
 local probes={};for unit,probe in pairs(self.fallbackProbes or {}) do if self.fallbacks and self.fallbacks[unit] then probes[probe]=(probes[probe] or 0)+1 end end
 codes={};for probe in pairs(probes) do codes[#codes+1]=probe end;table.sort(codes)
 for i=1,math.min(16,#codes) do local probe=codes[i];out[#out+1]="acquisition_"..probe.."="..probes[probe] end
 out[#out+1]="last_refusal="..(self.lastRefusal or "NONE")
 out[#out+1]="last_acquisition_probe="..(self.lastAcquisitionProbe or "NONE")
 local foregroundCodes={};for reason in pairs(foregroundStates) do foregroundCodes[#foregroundCodes+1]=reason end;table.sort(foregroundCodes)
 out[#out+1]="duration_foreground="..(#foregroundCodes>0 and table.concat(foregroundCodes,",") or "NO_ACTIVE_AURA_RAILS")
 out[#out+1]="last_duration_foreground_observation="..(self.lastForegroundReason or "NOT_OBSERVED").."; duration_foreground_scope=CURRENT_OWNERS_ONLY"
 out[#out+1]="aura_refresh_attempts="..(self.auraRefreshAttempts or 0).."; aura_refresh_submitted="..(self.auraRefreshSubmitted or 0).."; aura_refresh_failed="..(self.auraRefreshFailed or 0).."; last_aura_refresh="..(self.lastAuraRefresh or "NOT_REQUESTED")
 out[#out+1]="aura_refresh_scope=CURRENT_NATIVE_HARMFUL_ONLY; aura_refresh_budget=4_PER_250MS; aura_refresh_interval=MIN_1S_ROUND_ROBIN; aura_refresh_priority=SELECTION_MOUSEOVER_ALIAS_UNIT_ADDED"
 for _,reason in ipairs({"SELECTED_TARGET","HOSTILE_FOCUS","HOSTILE_OR_NEUTRAL_ALWAYS"}) do out[#out+1]="unit_demand_"..reason.."="..(unitDemands[reason] or 0) end
 out[#out+1]="native_collection="..(self.collectionStatus or "NOT_RUN").."; visited="..(self.collectionVisited or 0).."; assignment_attempts="..(self.assignmentAttempts or 0).."; acquisition_attempts="..(self.acquisitionAttempts or 0)
 out[#out+1]="reused_assignments="..(self.reusedAssignments or 0).."; full_paints="..(self.fullPaints or 0).."; releases="..(self.releases or 0).."; stale_removals_ignored="..(self.staleRemovals or 0).."; native_friendly_passes="..(self.nativeFriendlyPasses or 0)
 out[#out+1]="selection_delta_passes="..(self.selectionPasses or 0).."; combat_exit_selection_passes="..(self.combatExitSelectionPasses or 0).."; release_reentries="..(self.releaseReentries or 0).."; release_callback_failures="..(self.releaseCallbackFailures or 0).."; assignment_callback_failures="..(self.assignmentCallbackFailures or 0)
 out[#out+1]="suspensions="..(self.suspensions or 0).."; last_suspend="..(self.lastSuspendReason or "NONE").."; last_suspend_at="..(self.lastSuspendAt or 0)
 out[#out+1]="last_active_suspend="..(self.lastActiveSuspendReason or "NONE").."; last_active_suspend_at="..(self.lastActiveSuspendAt or 0)
 for _,token in ipairs({"target","focus"}) do out[#out+1]=token.."_plate="..((self.selectionStatus or {})[token] or "NOT_OBSERVED") end
 out[#out+1]="classification_probe="..(self.classificationProbe or "NOT_NEEDED")
 for _,setting in ipairs(friendlyPolicies) do
  local key=self.policyKeys and self.policyKeys[setting]
  local v,state
  if key then v,state=S:Public(C_CVar and C_CVar.GetCVar or GetCVar,"string",key) end
  out[#out+1]=setting.."_native="..(key or "UNRESOLVED")..":"..(state=="KNOWN" and v or "UNAVAILABLE")
 end
 for _,key in ipairs({"UnitNameFriendlyPlayerName","UnitNamePlayerGuild","UnitNameNPC","UnitNameFriendlyMinionName"}) do
  local v,state=S:Public(C_CVar and C_CVar.GetCVar or GetCVar,"string",key)
  out[#out+1]=key.."="..(state=="KNOWN" and v or "UNAVAILABLE")
 end
 local namePreferences={}
 for _,key in ipairs({"UnitNameFriendlySpecialNPCName","UnitNameHostleNPC","UnitNameInteractiveNPC","UnitNamePlayerPVPTitle","nameplateForceShowUnitName"}) do
  local v,state=S:Public(C_CVar and C_CVar.GetCVar or GetCVar,"string",key)
  namePreferences[key]=state=="KNOWN" and (v=="0" or v=="1") and v or nil
  out[#out+1]=key.."="..(namePreferences[key] or "UNAVAILABLE")
 end
 local npcMode=self:NativeNPCNamePreference()
 out[#out+1]="native_npc_name_preference="..npcMode
 local names="BLIZZARD_WORLD_RENDERER"
 out[#out+1]="friendly_label_ownership=BLIZZARD_NATIVE; friendly_selected_label="..(selectedFriendly and "MIRAGE_ON_PUBLIC_NATIVE_PLATE" or "BLIZZARD_NATIVE").."; friendly_label_styling=NONE"
 out[#out+1]="friendly_names="..names.."; range="..(self.rangeCatalogStatus or "NOT_RUN").."; range_refresh="..(self.rangeDirty and "PENDING" or "CURRENT").."; range_unknown=PUBLIC_EVIDENCE_GRACE_1.5S_THEN_NORMAL; selected_scale=1.08; out_of_range_scale=0.82; out_of_range_alpha=0.55"
 local unknown,grace=0,0
 for _,v in pairs(self.byUnit) do
  if v.rangeStatus=="UNKNOWN" then unknown=unknown+1 end
  if v.rangeVisualReason=="RECENT_PUBLIC_RANGE_GRACE" then grace=grace+1 end
 end
 out[#out+1]="range_unknown_plates="..unknown.."; range_grace_plates="..grace
 for _,key in ipairs({"nameplateShowEnemies","nameplateGlobalScale","nameplateMinScale","nameplateMaxScale","nameplateSelectedScale","nameplateMaxDistance"}) do
  local v,state=S:Public(C_CVar and C_CVar.GetCVar or GetCVar,"string",key);out[#out+1]=key.."="..(state=="KNOWN" and v or "UNAVAILABLE")
 end
 local requested=config().maximumDistance or 0
 local observed,observedState=S:Public(C_CVar and C_CVar.GetCVar or GetCVar,"string","nameplateMaxDistance")
 local distance=not self.active and "PROVIDER_INACTIVE" or requested==0 and "NATIVE_VALUE_KEPT"
  or observedState~="KNOWN" and "READBACK_UNAVAILABLE" or tonumber(observed)==requested and "REQUEST_MATCHED" or "REQUEST_NOT_MATCHED"
 out[#out+1]="distance_requested="..tostring(requested).."; distance_observed="..(observedState=="KNOWN" and observed or "UNAVAILABLE").."; distance_readback="..distance.."; distance_scope=NATIVE_CVAR_NOT_EMISSION_GUARANTEE"
 local categories={};for _,v in pairs(self.byUnit) do if self:Current(v) then categories[v.category or "UNKNOWN"]=(categories[v.category or "UNKNOWN"] or 0)+1 end end
 for _,key in ipairs({"ENEMY","ENEMY_PLAYER","NEUTRAL","LESSER","FRIENDLY_PLAYER","FRIENDLY_NPC","SELECTED_UNIT","UNKNOWN"}) do out[#out+1]=key.."="..(categories[key] or 0) end
 for _,entry in ipairs(policies) do out[#out+1]=entry[1].."="..((self.policyStatus or {})[entry[1]] or "NOT_RUN") end
 local input={};for _,v in pairs(self.byUnit) do if v.lease and v.lease.hit then input[v.inputStatus or "NATIVE_HIT_PENDING"]=(input[v.inputStatus or "NATIVE_HIT_PENDING"] or 0)+1 end end
 local inputKeys={};for key in pairs(input) do inputKeys[#inputKeys+1]=key end;table.sort(inputKeys)
 for _,key in ipairs(inputKeys) do out[#out+1]="input_"..key.."="..input[key] end
 out[#out+1]="hostile_visibility=ALWAYS_WHILE_NATIVE_EMITTED; friendly_visibility="..(selectedFriendly and "TARGET_ONLY_CUSTOM_AMBIENT_NATIVE" or "BLIZZARD_NATIVE_NAMES_ALL_SELECTION_STATES").."; visibility_exceptions=EXPLICIT_HIDE_SAFE_NATIVE_EDIT_CINEMATIC_TASK_OCCLUSION; special_widgets=NATIVE_FUNCTIONAL_RETAINED; controller=NATIVE_PARENT_VISIBLE; hit_testing=NATIVE_ENGINE_LEASED_BODY_OR_PASSIVE_NATIVE_REGION; input_permission=CAN_CHANGE_HIT_TEST_POINTS_FOR_LEASED_WRITES_ONLY; input_empty_policy=NATIVE_RETAINED; filtering=VISUAL_ONLY; native_qualification=NOT_CERTIFIED"
 out[#out+1]="auras=NATIVE_HARMFUL_UP_TO_40_SIX_TO_EIGHT_PER_ROW_UPWARD; aura_binding=INCUMBENT_NAMEPLATE_UNIT; important_buffs=RIGHT; detail_recovery=INCUMBENT_BODY_RETAINED; selection=TARGET_HOSTILE_FOCUS; casts=OPAQUE_TIMER_ICON_TEXT; plate_hits="..(M.WorldCombatText and M.WorldCombatText.plateStatus or "UNAVAILABLE")
 if M.WorldCombatText and M.WorldCombatText.PlateReport then out[#out+1]=M.WorldCombatText:PlateReport() end
 local stylePending=0
 for _,v in pairs(self.byUnit) do if self:Current(v) and v.lease.nativeBodies then
  stylePending=stylePending+1
 end end
 out[#out+1]="friendly_label=".."BLIZZARD_WORLD_RENDERER"
  .."; friendly_name_hierarchy=BLIZZARD_WORLD_RENDERER; friendly_body_art="..(self.targetFamily and "NONSELECTED_EMITTED_PLATES_FILTERED" or "BLIZZARD_WORLD_NAMES")
  .."; friendly_name_visibility=NATIVE_WORLD_NAME_AND_GUILD"
  .."; friendly_color=BLIZZARD_NATIVE; friendly_names_styled=0; friendly_ambient_leases="..stylePending.."; friendly_player_titles=BLIZZARD_NATIVE; friendly_npc_subtitles=BLIZZARD_NATIVE"
 out[#out+1]="ambient_friendly=BLIZZARD_WORLD_NAME_AND_GUILD".."; selected_friendly="..(selectedFriendly and "TARGET_ONLY_PUBLIC_NATIVE_PLATE" or "BLIZZARD_NATIVE").."; selected_friendly_anchor=NATIVE_EMISSION_REQUIRED; world_name_visibility=BLIZZARD_NATIVE_PREFERENCES; engine_world_renderer_replaced=false; global_fonts_changed=false; friendly_native_policy="..(self.friendlyPolicyState or "NOT_OBSERVED").."; widgets_only=BLIZZARD_UNMODIFIED; widgets_only_hit_testing=NATIVE_NO_HIT_REGION"
 out[#out+1]=self:FriendlyPrerequisiteReport()
 return table.concat(out,"; ")
end
function N:EvidenceReport()
 -- Compact cached evidence survives the support report's coverage-line cap.
 -- Export does not discover units, touch native controllers or claim that
 -- the engine emitted a selected-friendly anchor when it did not.
 local enabled=config().selectedFriendlyPlate~=false
 local kind=(self.selectionKinds or {}).target or "NOT_OBSERVED"
 local status=(self.selectionStatus or {}).target or "NOT_OBSERVED"
 local result
 if not self.active then result="PROVIDER_INACTIVE"
 elseif not enabled then result="DISABLED"
 elseif kind=="FRIENDLY" or kind=="NONATTACKABLE_NEUTRAL" then
  if status=="CUSTOM_SELECTED_PLATE_READY" then result="CURRENT_SELECTED_FRIENDLY_CUSTOM_PLATE"
  elseif status=="SELECTED_NATIVE_PLATE_UNAVAILABLE" then result="CURRENT_SELECTED_FRIENDLY_NATIVE_ANCHOR_UNAVAILABLE"
  elseif status=="SELECTED_NATIVE_PLATE_UNREADABLE" then result="CURRENT_SELECTED_FRIENDLY_NATIVE_ANCHOR_UNREADABLE"
  else result="CURRENT_SELECTED_FRIENDLY_"..status end
 elseif kind=="NONE" then result="NO_TARGET"
 else result="TARGET_NOT_CLASSIFIED_AS_FRIENDLY" end
 return "selected_friendly_enabled="..tostring(enabled).."; selected_friendly_kind="..kind.."; selected_friendly_result="..result
  .."; selected_friendly_emission="..(enabled and "PLAYER_NATIVE_PREREQUISITES_MANAGED_REQUIRES_PUBLIC_ANCHOR" or "NATIVE_PREFERENCE_HANDOFF")
  .."; ambient_friendly=BLIZZARD_WORLD_NAME_AND_GUILD"
  .."; world_name_range_requested_yards=50; native_world_name_range_yards="..tostring(self.nativeWorldNameRange or "UNAVAILABLE")
  .."; world_name_scope=ALL_UNITS; world_name_distance_status="..(self.worldNameDistanceStatus or "NOT_OBSERVED")
  .."; addon_world_name_distance_enforcement=NONE; ambient_distance_polling=NONE; plate_range_filter=NONE; target_emission_family="..(self.targetFamily or "NONE")
  .."; selected_plate_distance="..((self.policyStatus or {}).nameplateCheckDistanceForTarget or "UNAVAILABLE")
  .."; native_npc_name_preference="..(self.nativeNpcNameMode or "NOT_OBSERVED").."; native_npc_names_choice="..(config().nativeNPCNames==1 and "ALL" or "PRESERVE_CURRENT")
  .."; native_npc_names_policy="..((self.policyStatus or {}).UnitNameNPC or "NOT_OBSERVED").."; nonattackable_native_passes="..(self.nativeNeutralPasses or 0)
  .."; friendly_policy_state="..(self.friendlyPolicyState or "NOT_OBSERVED").."; friendly_policy_retry="..(self.friendlyPolicyRetry or "NONE")
  .."; friendly_policy_external="..(self.friendlyPolicyBlocked or "NONE")
  .."; friendly_players_observed="..((self.friendlyPolicyObserved or {}).friendlyVisibility or "NOT_OBSERVED")
  .."; friendly_npcs_observed="..((self.friendlyPolicyObserved or {}).friendlyNPCVisibility or "NOT_OBSERVED")
  .."; friendly_pets_observed="..((self.friendlyPolicyObserved or {}).friendlyPetVisibility or "NOT_OBSERVED")
  .."; "..self:FriendlyPrerequisiteReport()
end
