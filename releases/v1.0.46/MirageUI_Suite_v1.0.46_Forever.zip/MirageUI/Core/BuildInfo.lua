local _, M = ...
-- An immutable release label, not an attestation of the installed file bytes.
-- The release receipt maps this ID to the verified file manifest and archive SHA-256.
local ID="mirageui-1.0.46-20261125"
local VERSION="1.0.46"
local CURSOR_SOURCE="STANDALONE"
local TARGET="Forever:1.60.1:71091:16001"
M.BuildInfo={id=ID,version=VERSION,milestone="V1",cursorSource=CURSOR_SOURCE,target=TARGET}
local B=M.BuildInfo
local names={"MirageUI","MirageUIOptions"}
local startup,firstReadinessIssue
local statuses={MATCHED=true,MISMATCH=true,UNAVAILABLE=true}
local function status(value)
    return M.Safety:Text(value) and statuses[value] and value or "UNAVAILABLE"
end
local function snapshot(row)
    local result={status=status(row.status),components={}}
    for i,name in ipairs(names) do
        local component=row.components and row.components[i]
        result.components[i]={name=name,status=status(component and component.status)}
    end
    return result
end
local function metadataValue(fn,name,key,expected)
    local value,status=M.Safety:Public(fn,"string",name,key)
    -- Only bounded identifiers enter a support report. Unreadable or arbitrary
    -- metadata never becomes an error payload or a successful package match.
    if status~="KNOWN" or #value>96 or not value:match("^[%w_.:%-]+$") then return "UNAVAILABLE",false end
    -- Metadata may be supplied by a hooked getter. Retain only our authored
    -- value or a fixed mismatch marker, never an arbitrary identifier token.
    return value==expected and expected or "MISMATCH",true
end
function B:Inspect()
    local fn=C_AddOns and C_AddOns.GetAddOnMetadata or GetAddOnMetadata
    local row={id=ID,version=VERSION,cursorSource=CURSOR_SOURCE,target=TARGET,
        components={},available=type(fn)=="function",status="MATCHED"}
    for _,name in ipairs(names) do
        local version,versionKnown=metadataValue(fn,name,"Version",VERSION)
        local build,buildKnown=metadataValue(fn,name,"X-MirageUI-Build",ID)
        local status=(versionKnown and version~=VERSION or buildKnown and build~=ID) and "MISMATCH"
            or (not versionKnown or not buildKnown) and "UNAVAILABLE" or "MATCHED"
        row.components[#row.components+1]={name=name,version=version,build=build,status=status}
        if status=="MISMATCH" or row.status~="MISMATCH" and status=="UNAVAILABLE" then row.status=status end
    end
    if M.version~=VERSION then row.status="MISMATCH" end
    return row
end
-- Keep the first observation separately from the live report: a later matched
-- package read cannot explain away an earlier startup/readiness mismatch.
function B:CaptureStartup()
    if not startup then startup=snapshot(self:Inspect()) end
end
function B:RecordReadiness(package)
    if not firstReadinessIssue and status(package.status)~="MATCHED" then
        firstReadinessIssue=snapshot(package)
    end
end
function B:Report()
    local lines={"package_startup_status="..(startup and startup.status or "NOT_CAPTURED"),
        "package_first_readiness_issue="..(firstReadinessIssue and firstReadinessIssue.status or "NONE")}
    for _,entry in ipairs({{label="startup",value=startup},{label="first_readiness",value=firstReadinessIssue}}) do
        if entry.value then for _,component in ipairs(entry.value.components) do
            lines[#lines+1]="package_"..entry.label.."_"..component.name.."="..component.status
        end end
    end
    return table.concat(lines,"\n")
end
