local _,C=...
-- Payload digest covers sorted relative paths and their SHA-256, excluding this receipt.
C.Release={phase="V1_0_46_PROFILE_DEFAULTS",id="v1.0.46-71091",
    qualification="RUNTIME_API_GUARDED",nativeAcceptance="NOT_RUN",
    payloadSHA256="9e3dadc2547ffc5d6089482235fbc730bfe5cd73b82e736ac14d771c91c15660"}
