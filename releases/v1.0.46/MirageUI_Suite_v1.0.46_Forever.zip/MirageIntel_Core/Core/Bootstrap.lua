local addonName, C = ...
C.addonName = addonName
C.version = "1.12.17"
C.apiVersion = 1
C.schemaVersion = 1
C.state = {initialized=false, status="STARTING", errors=0, notifications=0}
C.services = {}
local function readable(v)
    if v==nil then return true end
    if type(issecretvalue)=="function" then
        local ok,secret=pcall(issecretvalue,v)
        if not ok or secret==true then return false end
    end
    if type(canaccessvalue)=="function" then
        local ok,yes=pcall(canaccessvalue,v)
        if not ok or yes==false then return false end
    end
    return true
end
C.Readable = readable
function C.Number(v)
    if not readable(v) or type(v)~="number" then return false end
    return v==v and v>-math.huge and v<math.huge
end
function C.Natural(v)
    return C.Number(v) and v>0 and v%1==0
end
function C.Text(v)
    return readable(v) and type(v)=="string" and #v<512
end
-- Display clipping must not split a UTF-8 code point. Storage and identity
-- limits remain byte limits; these helpers do not normalize item links/IDs.
local function utf8End(value,characters,bytes)
    if not readable(value) or type(value)~="string" or #value>16384 then return nil end
    local at,count,last=1,0,0
    while at<=#value and count<characters do
        local lead=value:byte(at)
        local length=lead<128 and 1 or lead>=194 and lead<=223 and 2 or
            lead>=224 and lead<=239 and 3 or lead>=240 and lead<=244 and 4 or nil
        if not length or at+length-1>#value or at+length-1>bytes then break end
        local valid=true
        for n=at+1,at+length-1 do
            local b=value:byte(n);if b<128 or b>191 then valid=false;break end
        end
        local second=value:byte(at+1)
        if length==3 and ((lead==224 and second<160) or (lead==237 and second>159)) or
            length==4 and ((lead==240 and second<144) or (lead==244 and second>143)) then valid=false end
        if not valid then break end
        last=at+length-1;at=last+1;count=count+1
    end
    return value:sub(1,last)
end
function C.TextClip(value,characters)
    if not C.Number(characters) or characters<0 or characters>4096 then return nil end
    return utf8End(value,math.floor(characters),16384)
end
function C.TextBytes(value,bytes)
    if not C.Number(bytes) or bytes<0 or bytes>16384 then return nil end
    return utf8End(value,16384,math.floor(bytes))
end
function C.Call(fn,...)
    if not readable(fn) or type(fn)~="function" then return nil,false end
    local ok,a,b,d,e=pcall(fn,...)
    if not ok or not readable(a) or not readable(b) or not readable(d) or not readable(e) then
        return nil,false
    end
    return a,true,b,d,e
end
function C.Copy(v,depth,seen)
    if not readable(v) then return nil end
    local t=type(v)
    if t~="table" then
        if t=="string" and #v<=1024 then return v end
        if t=="number" and C.Number(v) then return v end
        if t=="boolean" then return v end
        return nil
    end
    depth=depth or 0
    if depth>=8 then return nil end
    seen=seen or {}
    if seen[v] then return nil end
    seen[v]=true
    local r,n={},0
    for k,x in pairs(v) do
        n=n+1
        if n>300 then break end
        if (type(k)=="string" and #k<=100) or (type(k)=="number" and C.Number(k)) then
            r[k]=C.Copy(x,depth+1,seen)
        end
    end
    seen[v]=nil
    return r
end
-- Strict storage validator: bad or oversized inputs are rejected, not silently
-- truncated. C.Copy above is only for bounded public read-only snapshots.
function C.Sanitize(value,depth,seen,budget)
    if not readable(value) then return nil,false end
    local kind=type(value)
    if kind=="string" then return value,#value<=1024 end
    if kind=="number" then return value,C.Number(value) end
    if kind=="boolean" then return value,true end
    if kind~="table" then return nil,false end
    depth=depth or 0;seen=seen or {};budget=budget or {remaining=300}
    if depth>=8 or seen[value] then return nil,false end
    seen[value]=true
    local result={}
    for k,v in pairs(value) do
        budget.remaining=budget.remaining-1
        if budget.remaining<0 or not readable(k) or
            not ((type(k)=="string" and #k<=100) or (type(k)=="number" and C.Number(k))) then
            seen[value]=nil;return nil,false
        end
        local cloned,ok=C.Sanitize(v,depth+1,seen,budget)
        if not ok then seen[value]=nil;return nil,false end
        result[k]=cloned
    end
    seen[value]=nil
    return result,true
end
function C:Print(s)
    if DEFAULT_CHAT_FRAME and type(DEFAULT_CHAT_FRAME.AddMessage)=="function" then
        DEFAULT_CHAT_FRAME:AddMessage("|cffe8b77dUtility Core:|r "..tostring(s))
    end
end
function C:Fault(code)
    self.state.errors=self.state.errors+1
    self.state.lastError=type(code)=="string" and code or "UNKNOWN"
end
function C:Now()
    local time,ok=C.Call(GetTime)
    return ok and C.Number(time) and time or 0
end
function C.CombatState()
    local locked,known=C.Call(InCombatLockdown)
    if not known then return nil,"COMBAT_STATE_UNKNOWN" end
    -- Legacy clients may return nil rather than false when unlocked.
    if locked==nil or locked==false then return false end
    if locked==true or locked==1 then return true end
    return nil,"COMBAT_STATE_UNKNOWN"
end
function C:Initialize()
    if self.state.initialized then return end
    self.Client:Probe()
    if self.Client.allowed then
        self.Storage:Initialize()
        self.state.status=self.Storage.readOnly and "STORAGE_READ_ONLY" or "READY_NATIVE_UNTESTED"
    else
        self.Storage.readOnly=true
        self.Storage.reason="UNSUPPORTED_CLIENT_NO_WRITES"
        self.state.status="UNSUPPORTED_CLIENT"
    end
    self.state.initialized=true
end
